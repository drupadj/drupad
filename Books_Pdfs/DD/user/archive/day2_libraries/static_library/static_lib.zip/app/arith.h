int add(int, int);
int sub(int, int);
int mul(int, int);
int div(int, int);
