int func()
{
	return 10;
}
