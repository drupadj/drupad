int mul(int quant1, int quant2)
{
  return(quant1 * quant2);
}
