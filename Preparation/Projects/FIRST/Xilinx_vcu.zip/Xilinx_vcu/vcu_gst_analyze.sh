#!/bin/bash
#
# Script Name:  vcu_gstreamer_analyze.sh
#
# Description:  Analyzes the output of given directory and provides result in
#		in report format, also gives user option to visually verify
#		the results of test case and compare them visually with the
#		corresponding input files


# Variable Declaration for color macro for echo command
Bla='\e[0;30m';
Red='\e[0;31m';
Gre='\e[0;32m';
Yel='\e[0;33m';
Blu='\e[0;34m';
Pur='\e[0;35m';
Cya='\e[0;36m';
Whi='\e[0;37m';
BBla='\e[1;30m';
BRed='\e[1;31m';
BGre='\e[1;32m';
BYel='\e[1;33m';
BBlu='\e[1;34m';
BPur='\e[1;35m';
BCya='\e[1;36m';
BWhi='\e[1;37m';
Reset='\e[0m';


cur_path=$(dirname $(readlink -f $0))
md5_null=$(md5sum /dev/null | grep -Eo "[0-9a-zA-Z]{32}" | tr '[:upper:]' '[:lower:]')

############################################################################
#
# Name:         usage
#
# Argument:     None
#
# Description:  To display script's command line argument help
#
# Return Value: None
#
############################################################################
usage () {
	echo -e $BBlu
	echo '	Usage : ./vcu_gstreamer.sh -l <list_file>  -u <display>'
	echo '	-l or --list-name	: Required Argument'
	echo '				: Possible Values: </Path/To/List/>'
	echo '	-u or --usage-type	: Required Argument'
	echo '				: Possible Values:'
	echo '					: decode_display'
	echo '					: encode_file'
	echo '					: encode_params'
	echo '	-s or --ste		: Required Argument'
	echo '				: Possible Values: <single test number>'
	echo -e $Reset
	exit
}

############################################################################
#
# Name:		ErrorMsg
#
# Argument:
#
# Description:	To display error message
#
# Return Value:	None
#
############################################################################
ErrorMsg() {
        echo -e $BRed
        echo "$1"
        echo -e $Reset
        usage
}

############################################################################
#
# Name:         analyze_decode_display
#
# Argument:
#
# Description:  To validate output log of every test case folder by parsing log
#
#
# Return Value: None
#
############################################################################
analyze_decode_display () {

	source $LIST_NAME

	echo -e $BCya"-----------------------------------------------------------------------------------------------------------------------------------"
	printf '%-7s| %-45s| %-15s| %-7s| %-65s\n' "TEST NO" "              INPUT FILE NAME" "USAGE TYPE" "STATUS" "ERROR"
	echo -e "-----------------------------------------------------------------------------------------------------------------------------------"$Reset
	for tc in $run_list; do

		size=${#single_test_execute}

                TC_NUM=$(echo $tc | awk -F"," '{print $1}' | tr -d " " | tr -d "\t")

                if [ $size -ne 0 -a "$single_test_execute" != "$TC_NUM" ]; then
                        continue
                fi

		INPUT_FILE_NAME=$(echo $tc | awk -F"," '{print $2}' | tr -d " " | tr -d "\t")
		log_file_with_path="output/$U_TYPE/$TC_NUM/output_log_$TC_NUM.log"
		error_line1=$(grep -o -a -m 1 -h -r "A lot of buffers are being dropped" $log_file_with_path)
		error_line=$( grep -E "ERROR" $log_file_with_path | awk "NR==1")
		if [ \( -z "$error_line" \) -a \( -z "$error_line1" \) ] ; then

			STATUS="PASS"
	printf '%-7s| %-45s| %-15s| %-7s| %-65s\n' $TC_NUM $INPUT_FILE_NAME $U_TYPE $STATUS ---
	echo "-----------------------------------------------------------------------------------------------------------------------------------"
		else
			STATUS="FAIL"
	printf '%-7s| %-45s| %-15s| %-7s| %-65s\n' $TC_NUM $INPUT_FILE_NAME $U_TYPE $STATUS "$error_line $error_line1"
	echo "-----------------------------------------------------------------------------------------------------------------------------------"
		fi
	if [ $size -ne 0 ]; then
                        echo ":::::::: Test Complete as single test $single_test_execute :::::::::"
                fi
done
}

############################################################################
#
# Name:         analyze_encode_file
#
# Argument:
#
# Description:  To validate output log of every test case folder by parsing log
#
#
# Return Value: None
#
############################################################################
analyze_encode_file () {

        echo -e $BCya"-----------------------------------------------------------------------------------------------------------------------------------"
        printf '%-7s %-2s %-17s %-2s %-15s %-2s %-7s %-2s %-35s\n' "TEST NO" "|" "INPUT FILE NAME" "|" "USAGE TYPE" "|" "STATUS" "|" "ERROR"
        echo -e "-----------------------------------------------------------------------------------------------------------------------------------"$Reset
        #source $LIST_NAME
	i=1
	while read tc
	do
		test $i -eq 1 && ((i=i+1)) && continue

		size=${#single_test_execute}

                TC_NUM=$(echo $tc | awk -F"," '{print $1}' | tr -d " " | tr -d "\t")

                if [ $size -ne 0 -a "$single_test_execute" != "$TC_NUM" ]; then
                        continue
                fi

                INPUT_FILE_NAME=$(echo $tc | awk -F"," '{print $2}' | tr -d " " | tr -d "\t")
                log_file_with_path="output/$U_TYPE/$TC_NUM/output_log_$TC_NUM.log"
		BIT_RATE=$(echo $tc | awk -F"," '{print $11}' | tr -d " " | tr -d "\t")
		CODEC_TYPE=$(echo $tc | awk -F"," '{print $7}' | tr -d " " | tr -d "\t")
		FRAME_RATE=$(echo $tc | awk -F"," '{print $6}' | awk -F"/" '{print $1}' | tr -d " " | tr -d "\t")

		if [ $CODEC_TYPE = "AVC" ]
		then
			OUTPUT_FILE="output/$U_TYPE/$TC_NUM/$TC_NUM.h264"
		else
			OUTPUT_FILE="output/$U_TYPE/$TC_NUM/$TC_NUM.h265"
		fi

		./validate_enc_stream.py $TC_NUM $INPUT_FILE_NAME $OUTPUT_FILE $U_TYPE $BIT_RATE $FRAME_RATE

		if [ $size -ne 0 ]; then
                        echo ":::::::: Test Complete as single test $single_test_execute :::::::::"
                fi

	done < $LIST_NAME
}

############################################################################
#
# Name:         analyze_encode_params
#
# Argument:
#
# Description:  This function will compare the md5 checksum of expected vs actual
#
#
# Return Value: None
#
############################################################################
analyze_encode_params () {


	# Print header
	echo  -e -n $BCya
	echo "========================================================================================================================================"
	echo -e "Test case| Result (md5sum Difference) |\tExpected MD5 checksum\t\t|\tActual MD5 checksum \t\t|" | tee -a $log_file
	echo "========================================================================================================================================"
	echo -e -n $Reset
        #source $LIST_NAME
	i=1
	while read tc
	do
		test $i -eq 1 && ((i=i+1)) && continue
		size=${#single_test_execute}

                TC_NUM=$(echo $tc | awk -F"," '{print $1}' | tr -d " " | tr -d "\t")

                if [ $size -ne 0 -a "$single_test_execute" != "$TC_NUM" ]; then
                        continue
                fi

		CODEC_TYPE=$(echo $tc | awk -F"," '{print $7}' | tr -d " " | tr -d "\t")

		if [ $CODEC_TYPE = "AVC" ]
		then
			codec="h264"
		else
			codec="h265"
		fi

		md5_ln_exp=$( readlink -f $result/${TC_NUM}/${TC_NUM}_${codec}.gen_bit.exp.md5)
		md5_ln_act=$(  readlink -f $result/${TC_NUM}/${TC_NUM}_${codec}.gen_bit.act.md5)
		md5_exp=""
		md5_act=""

		[ -f $md5_ln_exp ] && md5_exp=$(cat $md5_ln_exp | grep -Eo "[0-9a-zA-Z]{32}" | tr '[:upper:]' '[:lower:]')
		[ -f $md5_ln_act ] && md5_act=$(cat $md5_ln_act | grep -Eo "[0-9a-zA-Z]{32}" | tr '[:upper:]' '[:lower:]')

		# Hardware MCU mode.
		if [ "$md5_act" == "" ] ; then
			res="NOT_RUN" # Does not exist.
			md5_match='NOT_RUN'
		elif [ "$md5_act" == "$md5_exp" ] ; then
			res="SUCCESS" # Matches expected only.
			md5_match='SUCCESS'
		elif [ "$md5_act" == "$md5_null" ] ; then
			res="o" # Empty file.
			md5_match='o'
		else
			res="FAILED" # Does not match.
			md5_match='FAILED'
		fi
		if [ "$md5_match" == "SUCCESS" -a "$res" == "SUCCESS" ]; then
			color=$BGre
		else
			color=$BRed
		fi

		echo -e -n $color
		echo -en "\n$TC_NUM   |\t$res\t\t      |" | tee -a $log_file

		##### Checksums. #####

		# Expected.
		if [ "$md5_exp" == "" ] ; then
			res="--------------------------------" # Does not exist.
		elif [ "$md5_exp" == "$md5_null" ] ; then
			res="oooooooooooooooooooooooooooooooo" # Empty file.
		else
			res="$md5_exp"
		fi

		echo -en "\t$res|" | tee -a $log_file


		# Actual.
		if [ "$md5_act" == "" ] ; then
			res="--------------------------------" # Does not exist.
		elif [ "$md5_act" == "$md5_null" ] ; then
			res="oooooooooooooooooooooooooooooooo" # Empty file.
		else
			res="$md5_act"
		fi
		echo -en "\t$res|\t" | tee -a $log_file
		echo -e -n $Reset

		if [ $size -ne 0 ]; then
                        if [ "$md5_match" == 'SUCCESS' ]; then
				exit 0
	                else
	                        exit 1
	                fi
                fi


	done < $LIST_NAME
}


if [ $# -eq 0 ]; then
        usage
        exit -1
fi

args=$(getopt -o "l:u:hs:" --long "list-name:,usecase-type:,help,ste:" -- "$@")

[ $? -ne 0 ] && usage && exit -1

eval set -- "${args}"

while true; do
	case $1 in
		-h | --help)
			usage; exit 0;
			shift;
			;;
		-l | --list-name)
                        LIST_NAME=$2;
                        if [ ! -f $LIST_NAME ]; then
                                ErrorMsg "List name should not be empty"
                        fi
                        shift; shift;
                        ;;
		-u | --usecase-type)
			U_TYPE=$2;
			if [ $U_TYPE != "decode_display" -a $U_TYPE != "encode_file" -a $U_TYPE != "encode_params" ]; then
				ErrorMsg "Invalid mode type input"
			fi
                        shift; shift;
                        ;;
		-s | --ste)
                        single_test_execute=$2;
                        if [ -z $single_test_execute ]; then
                                ErrorMsg "testcase name must be provided"
                        fi
                        shift; shift;
                        ;;
		--)
                        shift; break;
                        ;;
                *)
                        usage; exit -1;

	esac
done

if [ "$U_TYPE" == "decode_display" ]
then
	analyze_decode_display $LIST_NAME $single_test_execute
elif [ "$U_TYPE" == "encode_file" ]
then
	analyze_encode_file $LIST_NAME $single_test_execute
elif [ "$U_TYPE" == "encode_params" ]
then
	result=$cur_path/output/$U_TYPE
	echo "$result"
	date_time=$(date "+%Y%m%d_%H%M%S")
	log_file=$result/"log_${U_TYPE}_${USER}_${date_time}.log"
	analyze_encode_params $LIST_NAME $single_test_execute
else
	ErrorMsg "Please provide proper usecase-name"
fi
