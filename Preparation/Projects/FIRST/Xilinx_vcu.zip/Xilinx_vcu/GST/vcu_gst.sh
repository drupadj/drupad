#!/bin/bash
#
# Script Name:  vcu_gst.sh
#
# Description:  Perform Testcase execution of following three scenarios
#		1. Decode To Display Usecase
#		2. Encode To File Usecase
#
# Variable Declaration for color macro for echo command

Bla='\e[0;30m';
Red='\e[0;31m';
Gre='\e[0;32m';
Yel='\e[0;33m';
Blu='\e[0;34m';
Pur='\e[0;35m';
Cya='\e[0;36m';
Whi='\e[0;37m';
BBla='\e[1;30m';
BRed='\e[1;31m';
BGre='\e[1;32m';
BYel='\e[1;33m';
BBlu='\e[1;34m';
BPur='\e[1;35m';
BCya='\e[1;36m';
BWhi='\e[1;37m';
Reset='\e[0m';

export OMX_ALLEGRO_PATH=/usr/lib
#Input Files Path
dec_gst_path="../input/decoder/gst_src"

############################################################################
#
# Name:		usage
#
# Argument: 	None
#
# Description:	To display script's command line argument help
#
# Return Value:	None
#
############################################################################
usage () {
	echo -e $BBlu
	echo '	Usage : ./vcu_gst.sh -l <list_file>  -u <display>'
	echo '	-l or --list-name	: Required Argument'
	echo '				: Possible Values: </Path/To/List/>'
	echo '	-u or --usage-type	: Required Argument'
	echo '				: Possible Values:'
	echo '					:decode_display'
	echo '					:encode_file'
	echo '					:encode_params'
	echo '                                  :transcode'
	echo '	-s or --ste		: Required Argument'
	echo '				: Possible Values: <single test number>'
	echo -e $Reset
	exit
}

############################################################################
#
# Name:         prerequisite
#
# Argument:     None
#
# Description:  To display script's command line argument help
#
# Return Value: None
#
############################################################################
prerequisite () {

echo -e $BBlu
echo -e "==================================================================================================================================="
echo -e "Pre-Requisite:"
echo -e "\t1) All encoder YUV files of "$U_TYPE" usecase should exists on hard-disk (/sata) on board"
echo -e "\t2) Please copy YUV files directory from VCU database to SATA hard-disk (/sata) on board"
echo -e "\t\t YUV file location: /group/siv3/staff/andreis/vcu_deploy/deliveries/database/input/encoder/gst_${U_TYPE}_yuv"
echo -e "\t\t SATA hard-disk location: /sata (on board)"
echo "===================================================================================================================================="
echo -e $Reset
}


############################################################################
#
# Name:		ErrorMsg
#
# Argument:
#
# Description:	To display error message
#
# Return Value:	None
#
############################################################################
ErrorMsg() {
	echo -e $BRed
	echo "$1"
	echo -e $Reset
	usage
}

############################################################################
#
# Name:         decode_display
#
# Argument:     List file
#
# Description:  This function will parse list file & executes gstreamer pipeline
#		for decoder diaplay usecase. Also It's analyze every test once it
#		completes.
#
# Return Value: None
#
############################################################################

decode_display () {

	source $LIST_NAME

        for tc in $run_list; do

		size=${#single_test_execute}
                TC_NUM=$(echo $tc | awk -F"," '{print $1}' | tr -d " " | tr -d "\t")

		if [ $size -ne 0 -a "$single_test_execute" != "$TC_NUM" ]; then
                        continue
                fi

		INPUT_FILE_NAME=$(echo $tc | awk -F"," '{print $2}' | tr -d " " | tr -d "\t")
		KP=$(echo $INPUT_FILE_NAME | awk -F"_" '{print $6}' | tr -d " " | tr -d "\t")
                CODEC_TYPE=$(echo $INPUT_FILE_NAME | awk -F"." '{print $2}' | tr -d " " | tr -d "\t")
                WIDTH=$(echo $tc | awk -F"," '{print $4}' | tr -d " " | tr -d "\t")
                HEIGHT=$(echo $tc | awk -F"," '{print $5}' | tr -d " " | tr -d "\t")
                BF_COUNT=$(echo $tc | awk -F"," '{print $6}' | tr -d " " | tr -d "\t")
		STABILITY=$(echo $tc | awk -F"," '{print $7}' | tr -d " " | tr -d "\t")
                EX=$(echo $tc | awk -F"," '{print $3}' | tr -d " " | tr -d "\t")

		op_path="./output/$U_TYPE/$TC_NUM"
		mkdir -p $op_path
		log_file=output_log_$TC_NUM.log
		log_file_with_path="./output/$U_TYPE/$TC_NUM/$log_file"

		rm -rf $log_file_with_path

		echo "::::Test $TC_NUM is started::::" | tee -a $log_file_with_path

		echo "::: copying the test file $INPUT_FILE_NAME into the ram :::"  | tee -a $log_file_with_path
		cp $dec_gst_path/$INPUT_FILE_NAME /run/.
		sync

		echo "::: copied test file successfully :::" | tee -a $log_file_with_path

		GST_LAUNCH="gst-launch-1.0"
                FILE_SRC="filesrc location=/run/$INPUT_FILE_NAME"
                H264PARSE="h264parse"
                H265PARSE="h265parse"
                QUEUE="queue max-size-bytes=0"
                MTDEMUX="matroskademux name=demux demux.video_0"
                OMXH264="omxh264dec ip-mode=1 op-mode=1"
                OMXH265="omxh265dec ip-mode=1 op-mode=1"

		echo "----------------------------------Gst pipeline --------------------------" | tee -a $log_file_with_path

		if [ $KP == "4kp30" ];then
			SINK="kmssink"
			QTDEMUX="qtdemux name=demux demux.video_0"
		elif [ $KP == "4kp60" ];then
			SINK="fpsdisplaysink name=fpssink text-overlay=false video-sink=fakesink sync=true fps-update-interval=${BF_COUNT} -v"
			QTDEMUX="qtdemux"
			if [ $STABILITY == "l" ];then
				FILE_SRC="multifilesrc location=/run/$INPUT_FILE_NAME loop=true"
			elif [ $STABILITY == "v" ];then
				SINK="kmssink=false"
			fi
		else
			echo "provide proper sink and demux"
		fi

		if [ $CODEC_TYPE == "h264" ]; then
			echo "$GST_LAUNCH $FILE_SRC ! $H264PARSE ! $OMXH264 ! $QUEUE ! $SINK" | tee -a $log_file_with_path
			echo "-------------------------------------------------------------------------" | tee -a $log_file_with_path
                        eval "$GST_LAUNCH $FILE_SRC ! $H264PARSE ! $OMXH264 ! $QUEUE ! $SINK" 2>&1 | tee -a $log_file_with_path

                elif [ $CODEC_TYPE == "h265" ];then
			echo "$GST_LAUNCH $FILE_SRC ! $H265PARSE ! $OMXH265 ! $QUEUE ! $SINK" | tee -a $log_file_with_path
			echo "-------------------------------------------------------------------------" | tee -a $log_file_with_path
                        eval "$GST_LAUNCH $FILE_SRC ! $H265PARSE ! $OMXH265 ! $QUEUE ! $SINK" 2>&1 | tee -a $log_file_with_path

                elif [ $CODEC_TYPE == "mp4" ]; then
                        if [ $EX == "AVC" ]; then
				echo "$GST_LAUNCH $FILE_SRC ! $QTDEMUX ! $H264PARSE ! $OMXH264 ! $QUEUE ! $SINK" | tee -a $log_file_with_path
				echo "-------------------------------------------------------------------------" | tee -a $log_file_with_path
                                eval "$GST_LAUNCH $FILE_SRC ! $QTDEMUX ! $H264PARSE ! $OMXH264 ! $QUEUE ! $SINK" 2>&1 | tee -a $log_file_with_path
                        else
				echo "$GST_LAUNCH $FILE_SRC ! $QTDEMUX ! $H265PARSE ! $OMXH265 ! $QUEUE ! $SINK" | tee -a $log_file_with_path
				echo "-------------------------------------------------------------------------" | tee -a $log_file_with_path
                                eval "$GST_LAUNCH $FILE_SRC ! $QTDEMUX ! $H265PARSE ! $OMXH265 ! $QUEUE ! $SINK" 2>&1 | tee -a $log_file_with_path
                        fi

                elif [ $CODEC_TYPE == "mkv" ]; then
                        if [ $EX == "AVC" ]; then
				echo "$GST_LAUNCH $FILE_SRC ! $MTDEMUX ! $H264PARSE ! $OMXH264 ! $QUEUE ! $SINK" | tee -a $log_file_with_path
				echo "-------------------------------------------------------------------------" | tee -a $log_file_with_path
                                eval "$GST_LAUNCH $FILE_SRC ! $MTDEMUX ! $H264PARSE ! $OMXH264 ! $QUEUE ! $SINK" 2>&1 | tee -a $log_file_with_path
                        else
				echo "$GST_LAUNCH $FILE_SRC ! $MTDEMUX ! $H265PARSE ! $OMXH265 ! $QUEUE ! $SINK" | tee -a $log_file_with_path
				echo "-------------------------------------------------------------------------" | tee -a $log_file_with_path
                                eval "$GST_LAUNCH $FILE_SRC ! $MTDEMUX ! $H265PARSE ! $OMXH265 ! $QUEUE ! $SINK" 2>&1 | tee -a $log_file_with_path
                        fi
		else
			ErrorMsg "Incorrect Codec Type Provided"
                fi

		echo "::::Test $TC_NUM is completed::::" | tee -a $log_file_with_path

		analyze_decode_display

		if [ $size -ne 0 ]; then
                        echo ":::::::: Test Complete as single test $single_test_execute :::::::::"
                fi

		PID=$!
		wait $PID
		rm /run/$INPUT_FILE_NAME
	done
}

############################################################################
#
# Name:         encode_params
#
# Argument:     List file
#
# Description:  This function will parse list file & executes gstreamer pipeline
#               for encode-params usecase.
#
# Return Value: None
#
############################################################################
encode_params () {

        #source $LIST_NAME
	i=1
	while read tc
	do
		test $i -eq 1 && ((i=i+1)) && continue

                size=${#single_test_execute}

                TC_NUM=$(echo $tc | awk -F"," '{print $1}' | tr -d " " | tr -d "\t")
		CODEC_TYPE=$(echo $tc | awk -F"," '{print $7}' | tr -d " " | tr -d "\t")
		FORMAT=$(echo $tc | awk -F"," '{print $5}' | tr -d " " | tr -d "\t")

                if [ $size -ne 0 -a "$single_test_execute" != "$TC_NUM" ]; then
                        continue
                fi

		parse_encode_list_param $tc

		op_path="./output/$U_TYPE/$TC_NUM"
		echo "op_path = $op_path"

		mkdir -p $op_path
		chmod -R 777 $op_path
		log_file=output_log_$TC_NUM.log
		echo "log file = $log_file"

                log_file_with_path="./output/$U_TYPE/$TC_NUM/$log_file"
                echo "log file with path = $log_file_with_path"

		if [ $CODEC_TYPE = "AVC" ]
		then
			OUTPUT_FILE="output/$U_TYPE/$TC_NUM/$TC_NUM.h264"
			MD5_FILE="output/$U_TYPE/$TC_NUM/${TC_NUM}_h264.gen_bit.act.md5"
		else
			OUTPUT_FILE="output/$U_TYPE/$TC_NUM/$TC_NUM.h265"
			MD5_FILE="output/$U_TYPE/$TC_NUM/${TC_NUM}_h265.gen_bit.act.md5"
		fi

		rm -rf $OUTPUT_FILE
		rm -rf $MD5_FILE

		declare -a FILESINK_ARR=( "location"="$OUTPUT_FILE"  )
	        export FILE_SINK=$(update_element_properties $FILE_SINK ${FILESINK_ARR[@]})

		VIDEO_CONVERT="videoconvert "

		if [ $FORMAT != "nv12" ]
		then
			GST_ELEMENT=$FILE_SRC"|"$VIDEO_PARSE"|"$VIDEO_CONVERT"|"$OMXH265ENC"|"$OMXH264ENC"|"$VIDEO_X_H264"|"$VIDEO_X_H265"|"$FILE_SINK
		else
			GST_ELEMENT=$FILE_SRC"|"$VIDEO_PARSE"|"$OMXH265ENC"|"$OMXH264ENC"|"$VIDEO_X_H264"|"$VIDEO_X_H265"|"$FILE_SINK
		fi

		GST_COMMAND=$(create_gst_command "${GST_ELEMENT}")

		rm -rf $log_file_with_path

		echo -e "\n\t::::::::: Test $TC_NUM is started :::::::::" | tee -a $log_file_with_path

		echo -e "\n================================== Gst pipeline ==================================\n" | tee -a $log_file_with_path
		echo "$GST_COMMAND" | tee -a $log_file_with_path
		echo -e "\n================================== Gst pipeline ==================================\n" | tee -a $log_file_with_path
		eval $GST_COMMAND | tee -a $log_file_with_path

		md5sum $OUTPUT_FILE > $MD5_FILE
		echo -e "MD5SUM generated..." | tee -a $log_file_with_path

		echo -e "\n\t::::::::: Test $TC_NUM is completed ::::" | tee -a $log_file_with_path

                if [ $size -ne 0 ]; then
                        echo -e "\n\t::::::::: Test Complete as single test $single_test_execute :::::::::" | tee -a $log_file_with_path
                fi

        done < $LIST_NAME
}

############################################################################
#
# Name:         encode_file
#
# Argument:     List file
#
# Description:  This function will parse list file & executes gstreamer pipeline
#               for encode-to-file usecase.
#
# Return Value: None
#
############################################################################
encode_file () {

        #source $LIST_NAME
	i=1
	while read tc
	do
		test $i -eq 1 && ((i=i+1)) && continue

                size=${#single_test_execute}

                TC_NUM=$(echo $tc | awk -F"," '{print $1}' | tr -d " " | tr -d "\t")
		CODEC_TYPE=$(echo $tc | awk -F"," '{print $7}' | tr -d " " | tr -d "\t")
		FORMAT=$(echo $tc | awk -F"," '{print $5}' | tr -d " " | tr -d "\t")

                if [ $size -ne 0 -a "$single_test_execute" != "$TC_NUM" ]; then
                        continue
                fi

		parse_encode_list_param $tc

		op_path="./output/$U_TYPE/$TC_NUM"
		echo "op_path = $op_path"

		mkdir -p $op_path
		log_file=output_log_$TC_NUM.log
		echo "log file = $log_file"

                log_file_with_path="./output/$U_TYPE/$TC_NUM/$log_file"
                echo "log file with path = $log_file_with_path"

		if [ $CODEC_TYPE = "AVC" ]
		then
			OUTPUT_FILE="output/$U_TYPE/$TC_NUM/$TC_NUM.h264"
		else
			OUTPUT_FILE="output/$U_TYPE/$TC_NUM/$TC_NUM.h265"
		fi

		rm -rf $OUTPUT_FILE

		declare -a FILESINK_ARR=( "location"="$OUTPUT_FILE"  )
	        export FILE_SINK=$(update_element_properties $FILE_SINK ${FILESINK_ARR[@]})

		VIDEO_CONVERT="videoconvert "

		if [ $FORMAT != "nv12" ]
		then
			GST_ELEMENT=$FILE_SRC"|"$VIDEO_PARSE"|"$VIDEO_CONVERT"|"$OMXH265ENC"|"$OMXH264ENC"|"$VIDEO_X_H264"|"$VIDEO_X_H265"|"$FILE_SINK
        	else
			GST_ELEMENT=$FILE_SRC"|"$VIDEO_PARSE"|"$OMXH265ENC"|"$OMXH264ENC"|"$VIDEO_X_H264"|"$VIDEO_X_H265"|"$FILE_SINK
		fi

		GST_COMMAND=$(create_gst_command "${GST_ELEMENT}")

		rm -rf $log_file_with_path

		echo -e "\n\t:::::::::Test $TC_NUM is started:::::::::" | tee -a $log_file_with_path

		echo -e "\n================================== Gst pipeline ==================================\n" | tee -a $log_file_with_path
		echo "$GST_COMMAND" | tee -a $log_file_with_path
		echo -e "\n================================== Gst pipeline ==================================\n" | tee -a $log_file_with_path
		eval $GST_COMMAND | tee -a $log_file_with_path

		echo -e "\n\t:::::::::Test $TC_NUM is completed:::::::::" | tee -a $log_file_with_path

                if [ $size -ne 0 ]; then
                        echo -e "\n\t:::::::::Test Complete as single test $single_test_execute :::::::::" | tee -a $log_file_with_path
                fi

        done < $LIST_NAME
}

############################################################################
#
# Name:         parse_encode_list_param
#
# Argument:     TestCase (parameters)
#
# Description:  This function will parse testcase parameters & assign properties
#             	to proper element of gstreamer pipeline
#
# Return Value: None
#
############################################################################
parse_encode_list_param()
{

	tc=$1
	declare -a FILE_SRC_ARR
	declare -a VIDEO_PARSE_ARR
	declare -a OMX_ENC_ARR
	declare -a VIDEO_X

	export GST_COMMAND="gst-launch-1.0"
	export FILE_SRC="filesrc"
	export VIDEO_PARSE="videoparse"
	export OMXH265ENC="omxh265enc"
	export OMXH264ENC="omxh264enc"
	export FILE_SINK="filesink"
	export VIDEO_X_H264="video/x-h264"
	export VIDEO_X_H265="video/x-h265"
	export VIDEO_CONVERT="videoconvert "

        INPUT_FILE_NAME=$(echo $tc | awk -F"," '{print $2}' | tr -d " " | tr -d "\t")
        WIDTH=$(echo $tc | awk -F"," '{print $3}' | tr -d " " | tr -d "\t")
        HEIGHT=$(echo $tc | awk -F"," '{print $4}' | tr -d " " | tr -d "\t")
        FORMAT=$(echo $tc | awk -F"," '{print $5}' | tr -d " " | tr -d "\t")
	FRAME_RATE=$(echo $tc | awk -F"," '{print $6}' | tr -d " " | tr -d "\t")
	CODEC_TYPE=$(echo $tc | awk -F"," '{print $7}' | tr -d " " | tr -d "\t")
        IP_MODE=$(echo $tc | awk -F"," '{print $8}' | tr -d " " | tr -d "\t")
        GOP_LENGTH=$(echo $tc | awk -F"," '{print $9}' | tr -d " " | tr -d "\t")
        B_FRAMES=$(echo $tc | awk -F"," '{print $10}' | tr -d " " | tr -d "\t")
        TARGET_BIT_RATE=$(echo $tc | awk -F"," '{print $11}' | tr -d " " | tr -d "\t")
        CONTROL_RATE=$(echo $tc | awk -F"," '{print $12}' | tr -d " " | tr -d "\t")
        QP_MODE=$(echo $tc | awk -F"," '{print $13}' | tr -d " " | tr -d "\t")
        SLICE=$(echo $tc | awk -F"," '{print $14}' | tr -d " " | tr -d "\t")
	PROFILE=$(echo $tc | awk -F"," '{print $15}' | tr -d " " | tr -d "\t")
	LEVEL=$(echo $tc | awk -F"," '{print $16}' | tr -d " " | tr -d "\t")
	TIER=$(echo $tc | awk -F"," '{print $17}' | tr -d " " | tr -d "\t")
	GOP_FREQ_IDR=$(echo $tc | awk -F"," '{print $18}' | tr -d " " | tr -d "\t")
	PREF_BUFF=$(echo $tc | awk -F"," '{print $19}' | tr -d " " | tr -d "\t")
	MIN_QP=$(echo $tc | awk -F"," '{print $20}' | tr -d " " | tr -d "\t")
	MAX_QP=$(echo $tc | awk -F"," '{print $21}' | tr -d " " | tr -d "\t")
	GDR_MODE=$(echo $tc | awk -F"," '{print $22}' | tr -d " " | tr -d "\t")
	GOP_MODE=$(echo $tc | awk -F"," '{print $23}' | tr -d " " | tr -d "\t")
	QUANT_IFRAME=$(echo $tc | awk -F"," '{print $24}' | tr -d " " | tr -d "\t")
	QUANT_PFRAME=$(echo $tc | awk -F"," '{print $25}' | tr -d " " | tr -d "\t")
	QUANT_BFRAME=$(echo $tc | awk -F"," '{print $26}' | tr -d " " | tr -d "\t")
	INI_DELAY=$(echo $tc | awk -F"," '{print $27}' | tr -d " " | tr -d "\t")
	CPB_SIZE=$(echo $tc | awk -F"," '{print $28}' | tr -d " " | tr -d "\t")
	ENTROPY_MODE=$(echo $tc | awk -F"," '{print $29}' | tr -d " " | tr -d "\t")
	CONST_INTRA_PRED=$(echo $tc | awk -F"," '{print $30}' | tr -d " " | tr -d "\t")
	LOOP_FILTER=$(echo $tc | awk -F"," '{print $31}' | tr -d " " | tr -d "\t")
	SLICE_SIZE=$(echo $tc | awk -F"," '{print $32}' | tr -d " " | tr -d "\t")
	DPEND_SLICE=$(echo $tc | awk -F"," '{print $33}' | tr -d " " | tr -d "\t")

	FILE_SRC_ARR=( "location"="$enc_gst_path/$INPUT_FILE_NAME"  )
        export FILE_SRC=$(update_element_properties $FILE_SRC ${FILE_SRC_ARR[@]})

	VIDEO_PARSE_ARR=( "width"=$WIDTH "height"=$HEIGHT "format"=$FORMAT "framerate"=$FRAME_RATE  )
        export VIDEO_PARSE=$(update_element_properties $VIDEO_PARSE ${VIDEO_PARSE_ARR[@]})

	OMX_ENC_ARR=( "ip-mode"=$IP_MODE "gop-length"=$GOP_LENGTH "b-frames"=$B_FRAMES "target-bitrate"=$TARGET_BIT_RATE "control-rate"=$CONTROL_RATE "qp-mode"=$QP_MODE "num-slices"=$SLICE "gop-freq-idr"=$GOP_FREQ_IDR "prefetch-buffer-size"=$PREF_BUFF "min-qp"=$MIN_QP "max-qp"=$MAX_QP "gdr-mode"=$GDR_MODE "gop-mode"=$GOP_MODE "quant-i-frames"=$QUANT_IFRAME "quant-p-frames"=$QUANT_PFRAME "quant-b-frames"=$QUANT_BFRAME "initial-delay"=$INI_DELAY "cpb-size"=$CPB_SIZE "entropy-mode"=$ENTROPY_MODE "constrained-intra-pred"=$CONST_INTRA_PRED "loop-filter"=$LOOP_FILTER "slice-size"=$SLICE_SIZE "dependent-slice"=$DPEND_SLICE)

	VIDEO_X=( "profile"=$PROFILE "level"=$LEVEL "tier"=$TIER )

	if [ $CODEC_TYPE == "AVC" ]; then

		export OMXH264ENC=$(update_element_properties $OMXH264ENC ${OMX_ENC_ARR[@]})
		export VIDEO_X_H264=$(update_cap_properties $VIDEO_X_H264 ${VIDEO_X[@]})
	else
                export OMXH265ENC=$(update_element_properties $OMXH265ENC ${OMX_ENC_ARR[@]})
		export VIDEO_X_H265=$(update_cap_properties $VIDEO_X_H265 ${VIDEO_X[@]})
	fi

}

############################################################################
#
# Name:         update_element_properties
#
# Argument:     1) gstremer element 2) element properties array with values
#
# Description:  This function will update gstremer element properties for
#               those which has "NA" values
#
# Return Value: Element with properties
#
###########################################################################
update_element_properties()
{
 	element=$1 && shift
	prop_arr=($@)
	return_ele=$element

	for prop in ${prop_arr[@]}; do

		val_c=$(echo $prop | cut -d "=" -f2 )
		if  [ "${val_c}" != "NA" ]
                then
                	return_ele="${return_ele} ${prop}"
                fi

		if [ ${prop_arr[-1]} == $prop ]; then
			echo $return_ele
		fi

	done | sort

}

############################################################################
#
# Name:         update_cap_properties
#
# Argument:     1) gstremer element 2) element properties array with values
#
# Description:  This function will update gstremer element capabilities for
#               those which has "NA" values
#
# Return Value: Element with capabilities
#
###########################################################################
update_cap_properties()
{
        element=$1 && shift
        prop_arr=($@)
        return_ele=$element

        for prop in ${prop_arr[@]}; do

                val_c=$(echo $prop | cut -d "=" -f2 )
                if  [ ${val_c} != "NA" ]
                then
                        return_ele="${return_ele}, ${prop}"
                fi

                if [ ${prop_arr[-1]} == $prop ]; then
                        echo $return_ele
                fi

        done | sort

}

############################################################################
#
# Name:         create_gst_command
#
# Argument:     gstremer elements string separated by pipeline
#
# Description:  This function will create gstremer pipeline command by appending
#               all elements with their properties
#
# Return Value: gstreamer pipeline command
#
###########################################################################
create_gst_command()
{

	GST_ELEMENT=$1
	GST_ELE_COUNT=`echo $GST_ELEMENT | grep -o '|' | wc -l `
	GST_ELE_COUNT=`expr $GST_ELE_COUNT + 1`

	for (( i=1; i<=${GST_ELE_COUNT}; i++ ))
	do
	        element=$(echo $GST_ELEMENT | awk -F"|" "{print \$$i}")
	        prop_occur=$(echo "$element" | grep -o " " | wc -l )
	        if  [ $prop_occur -ge 1 ]
	        then
			if [ $i -eq 1 ]
	                then
	                	GST_COMMAND=$GST_COMMAND" "$element
			else
				GST_COMMAND=$GST_COMMAND" ! "$element
			fi
	        fi
		if [ $i -eq ${GST_ELE_COUNT} ]
		then
			echo $GST_COMMAND
		fi
	done

}

############################################################################
#
# Name:         Transcode
#
# Argument:     List file
#
# Description:  This function will parse list file & executes gstreamer pipeline
#               for Transcode usecase.
#
# Return Value: None
#
############################################################################
transcode () {

source $LIST_NAME

        for tc in $run_list; do

                size=${#single_test_execute}
                TC_NUM=$(echo $tc | awk -F"," '{print $1}' | tr -d " " | tr -d "\t")

                if [ $size -ne 0 -a "$single_test_execute" != "$TC_NUM" ]; then
                        continue
                fi
		entropy_buffer=$(echo $tc | awk -F"," '{print $6}' | tr -d " " | tr -d "\t")
		INPUT_FILE_NAME=$(echo $tc | awk -F"," '{print $2}' | tr -d " " | tr -d "\t")
		CODEC=$(echo $tc | awk -F"," '{print $3}' | tr -d " " | tr -d "\t")
		B_FRAMES=$(echo $tc | awk -F"," '{print $4}' | tr -d " " | tr -d "\t")
		GOP_LENGTH=$(echo $tc | awk -F"," '{print $5}' | tr -d " " | tr -d "\t")
		TYPE=$(echo $INPUT_FILE_NAME | awk -F"." '{print $2}' | tr -d " " | tr -d "\t")
		BIT=$(echo $INPUT_FILE_NAME | awk -F"_" '{print $3}' | tr -d " " | tr -d "\t")
		BIT=$(echo $BIT | awk -F"." '{print $1}' | tr -d " " | tr -d "\t")

		op_path="./output/$U_TYPE/$TC_NUM"
                mkdir -p $op_path
                log_file=output_log_$TC_NUM.log
                log_file_with_path="./output/$U_TYPE/$TC_NUM/$log_file"

                rm -rf $log_file_with_path

		if [ \( $CODEC == "avc_avc" \) -o \( $CODEC == "hevc_avc" \) ] ; then
			OUTPUT_FILE="output/$U_TYPE/$TC_NUM/$TC_NUM.h264"
		elif [ \( $CODEC == "avc_hevc" \) -o \( $CODEC == "hevc_hevc" \) ] ; then
			OUTPUT_FILE="output/$U_TYPE/$TC_NUM/$TC_NUM.h265"
		fi

                rm -rf $OUTPUT_FILE

		echo "::::Test $TC_NUM is started::::" | tee -a $log_file_with_path

		GST_LAUNCH="gst-launch-1.0"
                FILE_SRC="filesrc location=$dec_gst_path/$INPUT_FILE_NAME"
                H264PARSE="h264parse"
                H265PARSE="h265parse"
		OMXH264DEC="omxh264dec ip-mode=1 op-mode=1 internal-entropy-buffers=$entropy_buffer"
                OMXH265DEC="omxh265dec ip-mode=1 op-mode=1 internal-entropy-buffers=$entropy_buffer"
		VIDEO="video/x-h264, profile=high"
		FRAMES="b-frames=$B_FRAMES gop-length=$GOP_LENGTH"

		echo "========================================= Gst pipeline =================================" | tee -a $log_file_with_path

		if [ $BIT == "30" ];then
			if [ \( $CODEC == "avc_avc" \) -o \( $CODEC == "hevc_avc" \) ] ; then
				OMX="omxh264enc ip-mode=2 stride=256 sliceHeight=64 $FRAMES"
			elif [ \( $CODEC == "avc_hevc" \) -o \( $CODEC == "hevc_hevc" \) ] ; then
                                OMX="omxh265enc ip-mode=2 stride=256 sliceHeight=64 $FRAMES"
			fi
			SINK="filesink location=\"$OUTPUT_FILE\""
		else
			if [ \( $CODEC == "avc_avc" \) -o \( $CODEC == "hevc_avc" \) ] ; then
                                OMX="omxh264enc num-slices=4 prefetch-buffer-size=504 ip-mode=2 $FRAMES"
			elif [ \( $CODEC == "avc_hevc" \) -o \( $CODEC == "hevc_hevc" \) ] ; then
                                OMX="omxh265enc ip-mode=2 $FRAMES"
                        fi
			SINK="fakesink"
		fi

		if [ $CODEC == "avc_avc" ];then
			echo "$GST_LAUNCH $FILE_SRC ! $H264PARSE ! $OMXH264DEC ! $OMX ! $VIDEO ! $SINK" | tee -a $log_file_with_path
			echo "=====================================================================================" | tee -a $log_file_with_path
			eval "$GST_LAUNCH $FILE_SRC ! $H264PARSE ! $OMXH264DEC ! $OMX ! $VIDEO ! $SINK" 2>&1 | tee -a $log_file_with_path
		elif [ $CODEC == "avc_hevc" ];then
			echo "$GST_LAUNCH $FILE_SRC ! $H264PARSE ! $OMXH264DEC ! $OMX ! $SINK" | tee -a $log_file_with_path
			echo "=====================================================================================" | tee -a $log_file_with_path
			eval "$GST_LAUNCH $FILE_SRC ! $H264PARSE ! $OMXH264DEC ! $OMX ! $SINK" 2>&1 | tee -a $log_file_with_path
		elif [ $CODEC == "hevc_avc" ];then
			echo "$GST_LAUNCH $FILE_SRC ! $H265PARSE ! $OMXH265DEC ! $OMX ! $VIDEO ! $SINK" | tee -a $log_file_with_path
			echo "=====================================================================================" | tee -a $log_file_with_path
			eval "$GST_LAUNCH $FILE_SRC ! $H265PARSE ! $OMXH265DEC ! $OMX ! $VIDEO ! $SINK" 2>&1 | tee -a $log_file_with_path
		elif [ $CODEC == "hevc_hevc" ];then
                        echo "$GST_LAUNCH $FILE_SRC ! $H265PARSE ! $OMXH265DEC ! $OMX ! $SINK" | tee -a $log_file_with_path
			echo "=====================================================================================" | tee -a $log_file_with_path
			eval "$GST_LAUNCH $FILE_SRC ! $H265PARSE ! $OMXH265DEC ! $OMX ! $SINK" 2>&1 | tee -a $log_file_with_path
		fi

		echo "::::Test $TC_NUM is completed::::" | tee -a $log_file_with_path

		if [ $size -ne 0 ]; then
                        echo ":::::::: Test Complete as single test $single_test_execute :::::::::"
                fi
done

}

############################################################################
#
# Name:         analyze_decode_display
#
# Argument:	None
#
# Description:  This function will analyze decoder display test case by parsing
#               generated output log
#
# Return Value:	None
#
###########################################################################
analyze_decode_display () {

	echo -e $BCya"-----------------------------------------------------------------------------------------------------------------------------------"
	printf '%-7s| %-45s| %-15s| %-7s| %-65s\n' "TEST NO" "              INPUT FILE NAME" "USAGE TYPE" "STATUS" "ERROR"
	echo -e "-----------------------------------------------------------------------------------------------------------------------------------"$Reset

	error_line1=$(grep -o -a -m 1 -h -r "A lot of buffers are being dropped" $log_file_with_path)
	error_line=$( grep -E "ERROR" $log_file_with_path | awk "NR==1")

	if [ \( -z "$error_line" \) -a \( -z "$error_line1" \) ] ; then
		STATUS="PASS"
        	printf '%-7s| %-45s| %-15s| %-7s| %-65s\n' $TC_NUM $INPUT_FILE_NAME $U_TYPE $STATUS ---
        	echo "-----------------------------------------------------------------------------------------------------------------------------------"
	else
		STATUS="FAIL"
		printf '%-7s| %-45s| %-15s| %-7s| %-65s\n' $TC_NUM $INPUT_FILE_NAME $U_TYPE $STATUS "$error_line $error_line1"
		echo "-----------------------------------------------------------------------------------------------------------------------------------"
	fi
}


# Displaying Usage Information if no Argument Provided with Script
if [ $# -eq 0 ]; then
        usage
        exit -1
fi

# Command Line Argument Parsing
args=$(getopt -o "l:u:hs:" --long "list-name:,usecase-type:,help,ste:" -- "$@")

[ $? -ne 0 ] && usage && exit -1

eval set -- "${args}"

while true; do
	case $1 in
		-h | --help)
			usage; exit 0;
			shift;
			;;
		-l | --list-name)
                        LIST_NAME=$2;
                        if [ ! -f $LIST_NAME ]; then
                                ErrorMsg "List file not exist"
                        fi
                        shift; shift;
                        ;;
		-u | --usecase-type)
			U_TYPE=$2;
			if [ $U_TYPE != "decode_display" -a $U_TYPE != "encode_file" -a $U_TYPE != "encode_params" -a $U_TYPE != "transcode" ]; then
				ErrorMsg "Invalid usecase type input"
			fi
                        shift; shift;
                        ;;
		-s | --ste)
                        single_test_execute=$2;
                        if [ -z $single_test_execute ]; then
                                ErrorMsg "testcase name must be provided"
                        fi
                        shift; shift;
                        ;;
		--)
                        shift; break;
                        ;;
                *)
                        usage; exit -1;

	esac
done

export GST_COMMAND="gst-launch-1.0"
export FILE_SRC="filesrc"
export VIDEO_PARSE="videoparse"
export OMXH265ENC="omxh265enc"
export OMXH264ENC="omxh264enc"
export FILE_SINK="filesink"
export VIDEO_X_H264="video/x-h264"
export VIDEO_X_H265="video/x-h265"
export VIDEO_CONVERT="videoconvert "


if [ "$U_TYPE" == "decode_display" ] ; then
	source ./init_vcu.sh
	killall Xorg
	modetest -M xilinx_drm -w 25:alpha:1
	decode_display $LIST_NAME $single_test_execute
	export GST_DEBUG=omx*:3
elif [ "$U_TYPE" == "encode_file" ] ; then
	enc_gst_path="/sata/gst_encode_file_yuv"
	prerequisite
	encode_file $LIST_NAME $single_test_execute
elif [ "$U_TYPE" == "encode_params" ] ; then
	enc_gst_path="/sata/gst_encode_params_yuv"
	prerequisite
        encode_params $LIST_NAME $single_test_execute
elif [ "$U_TYPE" == "transcode" ] ; then
        transcode $LIST_NAME $single_test_execute
else
	ErrorMsg "Provide proper usecase name"
fi
