#!/usr/bin/env python

#
# Copyright (C) 2018 Advanced Micro Devices, Inc. All rights reserved.
#
# The purpose of this script is to prepend a provided psp signature header to
# a provided binary and update the psp header with the provided firmware
# version and optionally type
# The tool can also be used just to update an existing header
#

import sys
import getopt
import os
import binascii
from array import array

image_filename_1 = "bin/amss.bin"
image_filename_2 = "bin/m3.bin"
image_filename_3 = "bin/board.bin"
image_filename_4 = "bin/regdb.bin"
image_filename_5 = "bin/board-2.bin"
output_filename = "amf_wlan.bin"

WLAN_COOKIE = 0x4E414C57
WLAN_COOKIE_OFFSET = 0
NUM_OF_IMAGE = 5
NUM_OF_IMAGE_OFFSET = 8
ENTRY_SIZE_OFFSET = 4
ENTRY_LOCATION_OFFSET = 8
ENTRY_TYPE_OFFSET = 0

def main(argv):
    if os.path.isfile(image_filename_1) != True:
        print("header_tool.py ERROR: " + image_filename_1 + " does not exist")
        sys.exit(2)

    if os.path.isfile(image_filename_2) != True:
        print("header_tool.py ERROR: " + image_filename_2 + " does not exist")
        sys.exit(2)
        
    if os.path.isfile(image_filename_3) != True:
        print("header_tool.py ERROR: " + image_filename_3 + " does not exist")
        sys.exit(2)

    if os.path.isfile(image_filename_4) != True:
        print("header_tool.py ERROR: " + image_filename_4 + " does not exist")
        sys.exit(2)
        
    if os.path.isfile(image_filename_5) != True:
        print("header_tool.py ERROR: " + image_filename_5 + " does not exist")
        sys.exit(2)

    image = array('I', [0] * 24)
    image_bin1 = array('I')
    image_bin2 = array('I')
    image_bin3 = array('I')
    image_bin4 = array('I')
    image_bin5 = array('I')
    
    input_file1 = open(image_filename_1, "rb")
    image_bin1.frombytes(input_file1.read())
    # image.extend(image_bin1)
    BinSize1 = os.path.getsize(image_filename_1)
    
    input_file2 = open(image_filename_2, "rb")
    image_bin2.frombytes(input_file2.read())
    # image.extend(image_bin2)
    BinSize2 = os.path.getsize(image_filename_2)
    
    input_file3 = open(image_filename_3, "rb")
    image_bin3.frombytes(input_file3.read())
    # image.extend(image_bin3)
    BinSize3 = os.path.getsize(image_filename_3)

    input_file4 = open(image_filename_4, "rb")
    image_bin4.frombytes(input_file4.read())
    # image.extend(image_bin4)
    BinSize4 = os.path.getsize(image_filename_4)

    input_file5 = open(image_filename_5, "rb")
    image_bin5.frombytes(input_file5.read())
    # image.extend(image_bin5)
    BinSize5 = os.path.getsize(image_filename_5)

    HeaderSize = 16 + (NUM_OF_IMAGE * 16)

    Count = 0
    
    # Store the ASCI of "WLAN" in header version
    image[int(WLAN_COOKIE_OFFSET/4)] = WLAN_COOKIE
    image[int(NUM_OF_IMAGE_OFFSET/4)] = NUM_OF_IMAGE
    image[int((ENTRY_TYPE_OFFSET + (1*16))/4)] = Count
    image[int((ENTRY_SIZE_OFFSET + (1*16))/4)] = BinSize1
    image[int((ENTRY_LOCATION_OFFSET + (1*16))/4)] = HeaderSize
    Count += 1
    image[int((ENTRY_TYPE_OFFSET + (2*16))/4)] = Count
    image[int((ENTRY_SIZE_OFFSET + (2*16))/4)] = BinSize2
    image[int((ENTRY_LOCATION_OFFSET + (2*16))/4)] = (HeaderSize + BinSize1)
    Count += 1
    image[int((ENTRY_TYPE_OFFSET + (3*16))/4)] = Count
    image[int((ENTRY_SIZE_OFFSET + (3*16))/4)] = BinSize3
    image[int((ENTRY_LOCATION_OFFSET + (3*16))/4)] = (HeaderSize + BinSize1 + BinSize2)
    Count += 1
    image[int((ENTRY_TYPE_OFFSET + (4*16))/4)] = Count
    image[int((ENTRY_SIZE_OFFSET + (4*16))/4)] = BinSize4
    image[int((ENTRY_LOCATION_OFFSET + (4*16))/4)] = (HeaderSize + BinSize1 + BinSize2 + BinSize3)
    Count += 1
    image[int((ENTRY_TYPE_OFFSET + (5*16))/4)] = Count
    image[int((ENTRY_SIZE_OFFSET + (5*16))/4)] = BinSize5
    image[int((ENTRY_LOCATION_OFFSET + (5*16))/4)] = (HeaderSize + BinSize1 + BinSize2 + BinSize3 + BinSize4)


    # Since Input and output files may be the same close all files before doing output
    output_file = open(output_filename, "wb")

    # Write the output
    output_file.write(image)
    output_file.write(image_bin1)
    output_file.write(image_bin2)
    output_file.write(image_bin3)
    output_file.write(image_bin4)
    output_file.write(image_bin5)	
    output_file.close()

    print("package_tool: completed successfully")

if __name__ == "__main__":
    main(sys.argv[1:])
