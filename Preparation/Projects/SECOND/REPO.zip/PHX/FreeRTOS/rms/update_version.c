#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/***
 *
 * USAGE:
 *
 * ./update_version <FW binary> <minor number>
 *
 * 
***/

#define MPM_MFD_COMPONENT   0x28
#define PRODUCT_CODE        0x28
#define BUILD_NUMBER_MASK   0xFFF
#define MINOR_MASK          0xF

int main(int argc, char **argv)
{
  FILE *fp, *outfp;
  unsigned char ch;
  short int version=0;
  int filesize, i=0;
  int component= MPM_MFD_COMPONENT, product_code=PRODUCT_CODE , minor=atoi(argv[2]);
  short buildNumber = 0;
  char opfile[200];
  char buf[4];
  char opfilename[200]="";
  char *ptr,*temp,*ext;
  unsigned char lsb;
  unsigned char msb;

  if(argc < 3) {
    printf("Invalid arguments\n");
    printf("Usage:\n ./update_version <FW binary> <minor number>\n");
    return -1;
  }

  fp = fopen(argv[1], "rb");
  if (fp == NULL)
  {
     printf("Error opening file %s\n", argv[1]);
     return -1;
  }

  //Getting extension of BIN

  strcpy(opfile, strtok(argv[1], "."));
  strcat(opfile, "_");
  ext = strtok(NULL, "\0");

  if(getenv("buildNumber") == NULL)
  {
      printf("Build number is not set!\n");
      return -1;
  }
  
  // Getting BUILD number

  buildNumber = (getenv("buildNumber") == NULL) ? 0 : atoi(getenv("buildNumber"));

  version = (buildNumber & 0xFFF) | ((minor  << 12) & 0xF);
  lsb = version & 0xFF;
  msb = (version & 0xFF00) >> 8;

  //Getting File name

  temp = strtok(argv[1], "/");

  while(temp != NULL)
  {
     ptr = temp;
     temp = strtok(NULL,"/");
  }

  temp = strtok(ptr, "_");

  while(temp != NULL)
  {
     ptr = temp;
     if(i==0)
     {
         strcat(opfilename,ptr);
         strcat(opfilename,"_");
         strcat(opfilename,strtok(NULL,"_"));
     } else if(i==1){
     break;
     }
     i++;
  }

  strcat(opfilename,"_");
  strcat(opfilename,"v");
  snprintf(buf, 4, "%x", component);
  strcat(opfilename,buf);
  strcat(opfilename,".");
  snprintf(buf, 4, "%x", product_code);
  strcat(opfilename,buf);
  strcat(opfilename,".");
  snprintf(buf, 4, "%02x", msb);
  strcat(opfilename,buf);
  strcat(opfilename,".");
  snprintf(buf, 4, "%02x", lsb);
  strcat(opfilename,buf);
  strcat(opfilename,".");
  strcat(opfilename,ext);

  printf("Updated version file name: %s\n",opfilename);
  outfp = fopen(opfilename, "wb");

  fseek(fp, 0, SEEK_END);
  filesize = ftell(fp);

  fseek(fp, 0, SEEK_SET);

  while(--filesize >= 0)
  {
     fread(&ch, 1, 1, fp);
     fwrite(&ch, 1, 1, outfp);
  }

  fseek(outfp, 0x60, SEEK_SET);

  fwrite(&lsb, 1, 1, outfp);
  fwrite(&msb, 1, 1, outfp);
  fwrite(&product_code, 1, 1, outfp);
  fwrite(&component, 1, 1, outfp);

  fclose(fp);
  fclose(outfp);
  return 0;
}
