############################################################
# This script will   modify the python to python3          #  
# and run the build  script                                #
############################################################

CONFIGDIR = build/MPMDEV
FW_SIGN = tools/fw-sign2/bin
#sed -i 's/<uname>/amd/g' AMF/dv/mpm/build.sh
sed -i "s|\/home\/\$USER|$HOME|g" AMF/dv/mpm/build.sh
#sed -i 's/python/python3/g' AMF/dv/mpm/Makefile
cd AMF/dv/mpm

sh build.sh

cd ../../../rms
./update_version ../AMF/dv/mpm/build/MPMDEV/TypeId0x86_MPMDram_RMB.chbin 0
./update_version ../AMF/dv/mpm/build/MPMDEV/TypeId0x85_MPMSram_RMB.hbin 0
./update_version ../rms/MFD_binaries/TypeId0x89_MFD_RMB.hbin 0
./update_version ../rms/WLAN_binaries/TypeId0x88_WLAN_RMB.chbin 0

rm ../AMF/dv/mpm/build/MPMDEV/TypeId0x86_MPMDram_RMB.chbin
rm ../AMF/dv/mpm/build/MPMDEV/TypeId0x85_MPMSram_RMB.hbin

mv TypeId0x86_MPMDram_*.chbin ../AMF/dv/mpm/build/MPMDEV/.
mv TypeId0x85_MPMSram_*.hbin ../AMF/dv/mpm/build/MPMDEV/.
mv TypeId0x89_MFD_*.hbin ../AMF/dv/mpm/build/MPMDEV/.
mv TypeId0x88_WLAN_*.chbin ../AMF/dv/mpm/build/MPMDEV/.

cd ../AMF/dv/mpm
