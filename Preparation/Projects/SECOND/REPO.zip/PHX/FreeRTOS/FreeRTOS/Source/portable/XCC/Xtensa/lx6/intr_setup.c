#include "FreeRTOS.h"
#include "chip_offset_byte.h"
#include "intr_setup.h"

uint32_t IsrL1PreclearMask[NUM_INTCON_INPUT_WORDS];
volatile uint32_t gInterruptContext;

void UnassignedIsr(void) {
  // This will only be executed if an unassigned interrupt that is not masked off fires
  while(1);
}

// Order of items from bits 8 to 31 are subject to change
IsrPtr IsrPICTable[NUM_INTCON_INPUTS] = {
  &UnassignedIsr,         //   0
  &UnassignedIsr,         //   1
  &UnassignedIsr,         //   2
  &UnassignedIsr,         //   3
  &UnassignedIsr,         //   4
  &UnassignedIsr,         //   5
  &UnassignedIsr,         //   6
  &UnassignedIsr,         //   7
  &UnassignedIsr,         //   8
  &UnassignedIsr,         //   9
  &UnassignedIsr,         //   10
  &UnassignedIsr,         //   11
  &UnassignedIsr,         //   12
  &UnassignedIsr,         //   13
  &UnassignedIsr,         //   14
  &UnassignedIsr,         //   15
  &UnassignedIsr,         //   16
  &UnassignedIsr,         //   17
  &UnassignedIsr,         //   18
  &UnassignedIsr,         //   19
  &UnassignedIsr,         //   20
  &UnassignedIsr,         //   21
  &UnassignedIsr,         //   22
  &UnassignedIsr,         //   23
  &UnassignedIsr,         //   24
  &UnassignedIsr,         //   25
  &UnassignedIsr,         //   26
  &UnassignedIsr,         //   27
  &UnassignedIsr,         //   28
  &UnassignedIsr,         //   29
  &UnassignedIsr,         //   30
  &UnassignedIsr,         //   31
  &UnassignedIsr,         //   32
  &UnassignedIsr,         //   33
  &UnassignedIsr,         //   34
  &UnassignedIsr,         //   35
  &UnassignedIsr,         //   36
  &UnassignedIsr,         //   37
  &UnassignedIsr,         //   38
  &UnassignedIsr,         //   39
  &UnassignedIsr,         //   40
  &UnassignedIsr,         //   41
  &UnassignedIsr,         //   42
  &UnassignedIsr,         //   43
  &UnassignedIsr,         //   44
  &UnassignedIsr,         //   45
  &UnassignedIsr,         //   46
  &UnassignedIsr,         //   47
  &UnassignedIsr,         //   48
  &UnassignedIsr,         //   49
  &UnassignedIsr,         //   50
  &UnassignedIsr,         //   51
  &UnassignedIsr,         //   52
  &UnassignedIsr,         //   53
  &UnassignedIsr,         //   54
  &UnassignedIsr,         //   55
  &UnassignedIsr,         //   56
  &UnassignedIsr,         //   57
  &UnassignedIsr,         //   58
  &UnassignedIsr,         //   59
  &UnassignedIsr,         //   60
  &UnassignedIsr,         //   61
  &UnassignedIsr,         //   62
  &UnassignedIsr,         //   63
  &UnassignedIsr,         //   64
  &UnassignedIsr,         //   65
  &UnassignedIsr,         //   66
  &UnassignedIsr,         //   67
  &UnassignedIsr,         //   68
  &UnassignedIsr,         //   69
  &UnassignedIsr,         //   70
  &UnassignedIsr,         //   71
  &UnassignedIsr,         //   72
  &UnassignedIsr,         //   73
  &UnassignedIsr,         //   74
  &UnassignedIsr,         //   75
  &UnassignedIsr,         //   76
  &UnassignedIsr,         //   77
  &UnassignedIsr,         //   78
  &UnassignedIsr,         //   79
  &UnassignedIsr,         //   80
  &UnassignedIsr,         //   81
  &UnassignedIsr,         //   82
  &UnassignedIsr,         //   83
  &UnassignedIsr,         //   84
  &UnassignedIsr,         //   85
  &UnassignedIsr,         //   86
  &UnassignedIsr,         //   87
  &UnassignedIsr,         //   88
  &UnassignedIsr,         //   89
  &UnassignedIsr,         //   90
  &UnassignedIsr,         //   91
  &UnassignedIsr,         //   92
  &UnassignedIsr,         //   93
  &UnassignedIsr,         //   94
  &UnassignedIsr,         //   95
  &UnassignedIsr,         //   96
  &UnassignedIsr,         //   97
  &UnassignedIsr,         //   98
  &UnassignedIsr,         //   99
  &UnassignedIsr,         //  100
  &UnassignedIsr,         //  101
  &UnassignedIsr,         //  102
  &UnassignedIsr,         //  103
  &UnassignedIsr,         //  104
  &UnassignedIsr,         //  105
  &UnassignedIsr,         //  106
  &UnassignedIsr,         //  107
  &UnassignedIsr,         //  108
  &UnassignedIsr,         //  109
  &UnassignedIsr,         //  110
  &UnassignedIsr,         //  111
  &UnassignedIsr,         //  112
  &UnassignedIsr,         //  113
  &UnassignedIsr,         //  114
  &UnassignedIsr,         //  115
  &UnassignedIsr,         //  116
  &UnassignedIsr,         //  117
  &UnassignedIsr,         //  118
  &UnassignedIsr,         //  119
  &UnassignedIsr,         //  120
  &UnassignedIsr,         //  121
  &UnassignedIsr,         //  122
  &UnassignedIsr,         //  123
  &UnassignedIsr,         //  124
  &UnassignedIsr,         //  125
  &UnassignedIsr,         //  126
  &UnassignedIsr,         //  127
};

Pic_t Pic = {
  .PicMask = {
    [0] = 0x0,
    [1] = 0x0,
    [2] = 0x0,
    [3] = 0x0,
  },
  .QueueFullDisableMask = {
    [0] = 0xFFFFFFFF,
    [1] = 0xFFFFFFFF,
    [2] = 0xFFFFFFFF,
    [3] = 0xFFFFFFFF,
  }
};

void ReprogramPICMask(void)
{
#if defined(BUILD_MP1)
  (*(volatile uint32_t*)(mmMP1_PIC1_MASK_0)) = Pic.PicMask[0] & Pic.QueueFullDisableMask[0];
  (*(volatile uint32_t*)(mmMP1_PIC1_MASK_1)) = Pic.PicMask[1] & Pic.QueueFullDisableMask[1];
  (*(volatile uint32_t*)(mmMP1_PIC1_MASK_2)) = Pic.PicMask[2] & Pic.QueueFullDisableMask[2];
  (*(volatile uint32_t*)(mmMP1_PIC1_MASK_3)) = Pic.PicMask[3] & Pic.QueueFullDisableMask[3];
#elif defined(BUILD_MPM)
  (*(volatile uint32_t*)(mmMPM_PIC1_MASK_0)) = Pic.PicMask[0] & Pic.QueueFullDisableMask[0];
  (*(volatile uint32_t*)(mmMPM_PIC1_MASK_1)) = Pic.PicMask[1] & Pic.QueueFullDisableMask[1];
  (*(volatile uint32_t*)(mmMPM_PIC1_MASK_2)) = Pic.PicMask[2] & Pic.QueueFullDisableMask[2];
  (*(volatile uint32_t*)(mmMPM_PIC1_MASK_3)) = Pic.PicMask[3] & Pic.QueueFullDisableMask[3];
#endif
}

// Enable interrupt Globally (in the OS).
// Interrupts are default disabled.
void RTOS_EnableInterrupt(uint32_t InterruptId)
{
  Pic.PicMask[INDEX_FROM_INTR_ID(InterruptId)] |= MASK_FROM_INTR_ID(InterruptId);
  ReprogramPICMask();

}

// Disable interrupt Globally (in the OS).
// Interrupts are default disabled.
void RTOS_DisableInterrupt(uint32_t InterruptId)
{
  Pic.PicMask[INDEX_FROM_INTR_ID(InterruptId)] &= ~(MASK_FROM_INTR_ID(InterruptId));
  ReprogramPICMask();
}

void RTOS_Disable_All_Active_Interrupts()
{
    RTOS_DisableInterrupt(32);
    RTOS_DisableInterrupt(33);
    RTOS_DisableInterrupt(34);
    RTOS_DisableInterrupt(35);
    RTOS_DisableInterrupt(96);
}

void RTOS_Enable_All_Active_Interrupts(uint32_t state)
{
    Pic.PicMask[INDEX_FROM_INTR_ID(PIC_TIMER_0)] = state;
    ReprogramPICMask();
}

//! Clear all PIC interrupts.
void ClearAllPendingInterrupts(void)
{
  INTCON.InterruptPending[0] = 0xFFFFFFFF;
  INTCON.InterruptPending[1] = 0xFFFFFFFF;
  INTCON.InterruptPending[2] = 0xFFFFFFFF;
  INTCON.InterruptPending[3] = 0xFFFFFFFF;
}
//! Set interrupt priority of a particular PIC interrupt specified by an ID.
//! \param Id              Indicates which interrupt to set priority for.
//! \param PriorityLevel   Indicates what priority level to set interrupt.
void SetInterruptPriority(uint32_t InterruptId, uint32_t PriorityLevel)
{
  INTCON.InterruptPriority[PriorityLevel] = InterruptId;
}

void ClearPendingInterrupt(uint32_t InterruptId)
{
  INTCON.InterruptPending[INDEX_FROM_INTR_ID(InterruptId)] = MASK_FROM_INTR_ID(InterruptId);
}

//! Set interrupt level of a particular PIC interrupt specified by an ID
//! \param InterruptId            Indicates which interrupt to set level for.
//! \param IntrTriggerType        Indicates what level to set interrupt. (PIC_TRIGGER_EDGE = 0, PIC_TRIGGER_LEVEL = 1)
void SetInterruptLevel(uint32_t InterruptId, PIC_TRIGGER_TYPE_e IntrTriggerType)
{
  if (IntrTriggerType == PIC_TRIGGER_LEVEL) {
    INTCON.InterruptLevel[INDEX_FROM_INTR_ID(InterruptId)] |= MASK_FROM_INTR_ID(InterruptId);
  } else {
    INTCON.InterruptLevel[INDEX_FROM_INTR_ID(InterruptId)] &= ~(MASK_FROM_INTR_ID(InterruptId));
  }
}

uint32_t IsrContext(void)
{
	return gInterruptContext;
}

// This Interrupt Service Routine will handle all PIC interrupts
void IsrPIC(void)
{
  uint32_t CurrentInterruptID;
  uint8_t IntrPreclear;

  gInterruptContext = 1;
  while (PIC_INTR_STATUS_PENDING == INTCON.InterruptLine) {
    CurrentInterruptID = INTCON.InterruptID;
    IntrPreclear = IsrL1PreclearMask[INDEX_FROM_INTR_ID(CurrentInterruptID)] & (MASK_FROM_INTR_ID(CurrentInterruptID));
    if (IntrPreclear) {
      ClearPendingInterrupt(CurrentInterruptID);
    }
    // Call ISR from table.
    IsrPICTable[CurrentInterruptID]();
    if (!IntrPreclear) {
      ClearPendingInterrupt(CurrentInterruptID);
    }
  }
  gInterruptContext = 0;

}

void RegisterL1PicInterrupt(const uint32_t InterruptId, const PIC_DEFAULT_INTR_e IntrDefaultStatus,
  const PIC_TRIGGER_TYPE_e IntrTriggerType, const PIC_INTR_CLEAR_TYPE_e IntrClearType, const IsrPtr IsrHandler)
{
  IsrPICTable[InterruptId] = IsrHandler; //assign interrupt handler
  SetInterruptPriority(InterruptId, InterruptId); //set priority to interrupt ID, same as HW default
  if (IntrDefaultStatus == PIC_DEFAULT_INTR_ON) {
    RTOS_EnableInterrupt(InterruptId);  //enable interrupt if needed
  } else {
    RTOS_DisableInterrupt(InterruptId); //slightly redundant, interrupts are default disabled
  }
  SetInterruptLevel(InterruptId, IntrTriggerType); //set trigger type
  if (IntrClearType == PIC_INTR_CLEAR_PRE) { //record whether interrupt is a pre or post clear
    IsrL1PreclearMask[INDEX_FROM_INTR_ID(InterruptId)] |= (MASK_FROM_INTR_ID(InterruptId));
  } else {
    IsrL1PreclearMask[INDEX_FROM_INTR_ID(InterruptId)] &= ~(MASK_FROM_INTR_ID(InterruptId));
  }
}
