#ifndef __INTR_SETUP_H
#define __INTR_SETUP_H

#define NUM_INTCON_INPUTS 128
#define NUM_INTCON_INPUT_WORDS (NUM_INTCON_INPUTS / 32)
#define NUM_INTCONS 2

#define INDEX_FROM_INTR_ID(Id)  (((Id) >> 5))           //divide by 32
#define MASK_FROM_INTR_ID(Id) (((uint32_t)(0x1 << ((Id) & 0x1F)))) //get mask for individual dword based on last 5 bits

#define PIC_TIMER_0  96
#define PIC_TIMER_1  97
#define PIC_TIMER_2  98
#define PIC_TIMER_3  99
#define PIC_TIMER_4  100
#define PIC_TIMER_5  101
#define PIC_TIMER_6  102
#define PIC_TIMER_7  103

#define LX6_L1_PIC1_INT_MASK (0x1 << XCHAL_EXTINT0_NUM)
#define LX6_L1_PIC0_INT_MASK (0x1 << XCHAL_EXTINT1_NUM)

typedef unsigned int uint32_t;
typedef unsigned char uint8_t;

typedef void (*IsrPtr)(void);

void UnassignedIsr(void);
typedef enum {
  PIC_DEFAULT_INTR_OFF = 0,
  PIC_DEFAULT_INTR_ON  = 1,
  PIC_DEFAULT_INTR_COUNT
} PIC_DEFAULT_INTR_e ;

typedef enum {
  PIC_TRIGGER_EDGE,
  PIC_TRIGGER_LEVEL,
  PIC_TRIGGER_COUNT,
} PIC_TRIGGER_TYPE_e;

typedef enum {
  PIC_INTR_CLEAR_POST = 0,
  PIC_INTR_CLEAR_PRE  = 1,
  PIC_INTR_CLEAR_COUNT,
} PIC_INTR_CLEAR_TYPE_e;


typedef enum {
  PIC_INTR_STATUS_PENDING = 0,
  PIC_INTR_STATUS_NONE = 1,
  PIC_INTR_STATUS_COUNT
} PIC_INTR_STATUS_e;

typedef struct
{
    uint32_t InterruptMask[NUM_INTCON_INPUT_WORDS];
    uint32_t InterruptLevel[NUM_INTCON_INPUT_WORDS];
    uint32_t InterruptEdge[NUM_INTCON_INPUT_WORDS];
    uint8_t  InterruptPriority[NUM_INTCON_INPUTS];
    uint32_t InterruptPending[NUM_INTCON_INPUT_WORDS];
    uint32_t InterruptLine;
    uint32_t InterruptID;
} intcon_t;

typedef struct {
  uint32_t PicMask[NUM_INTCON_INPUTS];
  uint32_t QueueFullDisableMask[NUM_INTCON_INPUTS];
} Pic_t;

#define ISRDATA_EXTRA_PAGE_0 0x8
#define ISRDATA_EXTRA_PAGE_1 0xFF
#define ISRDATA_EXTRA_PAGE_2 0xFF
#define ISRDATA_EXTRA_PAGE_3 0xFF
#define ISRDATA_EXTRA_PAGE_4 0xFF
#define ISRDATA_EXTRA_PAGE_5 0xFF
#define ISRDATA_EXTRA_PAGE_6 0xFF
#define ISRDATA_EXTRA_PAGE_7 0xFF

#if defined(BUILD_MP1)
#define INTCON (*(volatile intcon_t *) mmMP1_PIC1_MASK_0)
#elif defined(BUILD_MPM)
#define INTCON (*(volatile intcon_t *) mmMPM_PIC1_MASK_0)
#endif

void RegisterL1PicInterrupt(const uint32_t InterruptId, const PIC_DEFAULT_INTR_e IntrDefaultStatus,
  const PIC_TRIGGER_TYPE_e IntrTriggerType, const PIC_INTR_CLEAR_TYPE_e IntrClearType, const IsrPtr IsrHandler);
uint32_t IsrContext(void);

#define REF_CLK_FREQ 25000000 /* 25MHz */
#define REF_CLK_FREQ_MHZ 25
#define US_TO_REFCLK(US)    (US * REF_CLK_FREQ_MHZ)
#define NUM_OCMP_REG                4 //number of Output Compare registers

// -- Copied from timer.h
#define NUM_COUNTERS                4
#define NUM_OCMP_REG                4
#define NUM_TIMER_REG               NUM_OCMP_REG + 5
#define STATIC_COUNTER__READ_OFFSET	5

//! \struct TimerMap_t
//! The data structure provides a memory map into the volatile timer register region and should
//! be used in conjunction with the TIMER macro.
typedef struct {
  uint8_t  Start;                             // 0x00
  uint8_t  Clear;                             // 0x01
  uint8_t  CountUpOrDown;                     // 0x02
  uint8_t  PulseCountEnable;                  // 0x03
  uint8_t  PwmOutputEnable;                   // 0x04
  uint8_t  TimeSliceModeEnable;               // 0x05
  uint8_t  ChronographSaturationEnable;       // 0x06
  uint8_t  Reserved0;                         // 0x07
  uint8_t  IncrementMode;                     // 0x08
  uint8_t  Reserved1[3];                      // 0x09 .. 0x0B
  uint8_t  TimerInterruptConfig;              // 0x0C
  uint8_t  Reserved2[3];                      // 0x0D .. 0x0F
  uint32_t CompareValue[NUM_OCMP_REG];        // 0x10 .. 0x1C
  uint32_t CounterValue;                      // 0x20
} TimerMap_t;

//! \struct timercon_t
//! The data structure provides a memory map into the volatile timer register region and should
//! be used in conjunction with the TIMER macro.
typedef struct
{
    uint8_t  Start;                             // 0x00
    uint8_t  Clear;                             // 0x01
    uint8_t  CountDown;                         // 0x02
    uint8_t  PulseCountEnable;                  // 0x03
    uint8_t  PwmOutputEnable;                   // 0x04
    uint8_t  TimeSliceModeEnable;               // 0x05
    uint8_t  ChronographSaturationEnable;       // 0x06
    uint8_t  Reserved0;                         // 0x07
    uint32_t IncrementMode;                     // 0x08
    uint32_t TimerInterruptEnable;              // 0x0C
    uint32_t CompareValue[NUM_OCMP_REG];        // 0x10 .. 0x1C
    uint32_t CounterValue;                      // 0x20
} timercon_t;

#define TIMERCON_SIZE (sizeof(timercon_t))

#define NUM_L2_INTCON_INPUTS 8
#define NUM_L2_INTCON_INPUT_WORDS 1     // ceil(NUM_L2_INTCON_INPUTS / 32)

typedef struct
{
    uint32_t InterruptMask[NUM_L2_INTCON_INPUT_WORDS];
    uint32_t InterruptLevel[NUM_L2_INTCON_INPUT_WORDS];
    uint32_t InterruptEdge[NUM_L2_INTCON_INPUT_WORDS];
    uint8_t  InterruptPriority[NUM_L2_INTCON_INPUTS];
    uint32_t InterruptPending[NUM_L2_INTCON_INPUT_WORDS];
    uint32_t InterruptLine;
    uint32_t InterruptID;
} l2_intcon_t;

#define INTCON_SIZE (sizeof (intcon_t))

#define RESET_PROCESSOR                 0
#define STOP_SIMULATION                 1
#define TRIGGER_INTERRUPT               2
#define DUMP_TIMER                      3
#define DUMP_PIC                        4
#define PIC_MODEL_RAISE_INTERRUPT       5
#define SET_TIMER0_PERIOD               6
#define PIC_MODEL_LOWER_INTERRUPT       7
#define PIC_MODEL_RAISE_TIMER_INTERRUPT 8
#define PIC_MODEL_RAISE_L2_INTERRUPT    9
#define PIC_MODEL_RAISE_INTERRUPT_N     10
#define PIC_MODEL_LOWER_L2_INTERRUPT    11

// Basic Register Access Macros
#define AR_FIELD_SHIFT(reg, field)                      reg##_##field##_SHIFT
#define AR_FIELD_MASK(reg, field)                       reg##_##field##_MASK
#define AR_GET_FIELD(value, reg, field)                 (((value) & AR_FIELD_MASK(reg, field)) >> AR_FIELD_SHIFT(reg, field))
#define AR_SET_FIELD(origval, reg, field, fieldval)     (((origval) & ~AR_FIELD_MASK(reg, field)) | (AR_FIELD_MASK(reg, field) \
                                                        & (((uint32_t)(fieldval)) << AR_FIELD_SHIFT(reg, field))))


#define REG8(addr)                                      *((volatile uint8_t *) (addr))
#define REG16(addr)                                     *((volatile uint16_t *) (addr))
#define REG32(addr)                                     *((volatile uint32_t *) (addr))
#define DREG32(addr)                                    *((uint32_t *) (addr))
#define REG64(addr)                                     *((volatile uint64_t *) (addr))


#define AR_SET_FIELD_VAR(var, reg, field, fieldval)     var = AR_SET_FIELD(var, reg, field, fieldval)

// General access to either MP1 or MPM
#define GEN_AR_FIELD_SHIFT(reg, field, TYPE)                    TYPE##_##reg##_##field##_SHIFT
#define GEN_AR_FIELD_MASK(reg, field, TYPE)                     TYPE##_##reg##_##field##_MASK
#define GEN_AR_GET_FIELD(value, reg, field, TYPE)               (((value) & GEN_AR_FIELD_MASK(reg, field, TYPE)) >> GEN_AR_FIELD_SHIFT(reg, field, TYPE))
#define GEN_AR_SET_FIELD(origval, reg, field, fieldval, TYPE)   (((origval) & ~GEN_AR_FIELD_MASK(reg, field, TYPE)) | (GEN_AR_FIELD_MASK(reg, field, TYPE) \
                                                          & (((uint32_t)(fieldval)) << GEN_AR_FIELD_SHIFT(reg, field, TYPE))))

#define MAKE_MP_FEATURE(feature, TYPE)                               (MP__##TYPE##__##feature)
#define MAKE_MP_REG(reg, TYPE)                                       (mm##TYPE##_##reg)
#define MAKE_MP_STRUCT(reg, TYPE)                                    TYPE##_##reg
#define MP_REG_EVAL(reg, TYPE)                                       REG32(MAKE_MP_REG(reg, TYPE))
#define MP_REG_ADDR_EVAL(reg, TYPE)                                  REG32(reg)
#define MP_REG64_ADDR_EVAL(reg, TYPE)                                REG64(reg)
#define MP_REG_READ_FIELD_EVAL(reg, field, TYPE)                     GEN_AR_GET_FIELD(MP_REG_EVAL(reg, TYPE), reg, field, TYPE)
#define MP_REG_WRITE_FIELD_EVAL(reg, field, fieldval, TYPE)          MP_REG_EVAL(reg, TYPE) = GEN_AR_SET_FIELD(MP_REG_EVAL(reg, TYPE), reg, field, fieldval, TYPE)

#if defined(BUILD_MP1)
#define GEN_MP_FEATURE(feature)                           MAKE_MP_FEATURE(feature, MP1)
#define GEN_MP_REG(reg)                                   MAKE_MP_REG(reg, MP1)
#define GEN_MP_STRUCT(reg)                                MAKE_MP_STRUCT(reg, mp1)
#define MP_REG(reg)                                       MP_REG_EVAL(reg, MP1)
#define MP_REG_ADDR(reg)                                  MP_REG_ADDR_EVAL(reg, MP1)
#define MP_REG64_ADDR(reg)                                MP_REG64_ADDR_EVAL(reg, MP1)
#define MP_REG_READ_FIELD(reg, field)                     MP_REG_READ_FIELD_EVAL(reg, field, MP1)
#define MP_REG_WRITE_FIELD(reg, field, fieldval)          MP_REG_WRITE_FIELD_EVAL(reg, field, fieldval, MP1)
#elif defined(BUILD_MPM)
#define GEN_MP_FEATURE(feature)                           MAKE_MP_FEATURE(feature, MPM)
#define GEN_MP_REG(reg)                                   MAKE_MP_REG(reg, MPM)
#define GEN_MP_STRUCT(reg)                                MAKE_MP_STRUCT(reg, mpm)
#define MP_REG(reg)                                       MP_REG_EVAL(reg, MPM)
#define MP_REG_ADDR(reg)                                  MP_REG_ADDR_EVAL(reg, MPM)
#define MP_REG64_ADDR(reg)                                MP_REG64_ADDR_EVAL(reg, MPM)
#define MP_REG_READ_FIELD(reg, field)                     MP_REG_READ_FIELD_EVAL(reg, field, MPM)
#define MP_REG_WRITE_FIELD(reg, field, fieldval)          MP_REG_WRITE_FIELD_EVAL(reg, field, fieldval, MPM)
#endif

//! \def TIMER(n)
//! Macro to access timer registers.
//! \param n            Indicates which timer to use
#define TIMER(n)                 (*(volatile TimerMap_t *) (GEN_MP_REG(TIMER_0_CTRL0) + ((n) * TIMERCON_SIZE)))
#define DTIMER(n)                (*(TimerMap_t *) (GEN_MP_REG(TIMER_0_CTRL0) + ((n) * TIMERCON_SIZE)))

typedef enum {
  TIMER_MODE_PULSE_COUNT,
  TIMER_MODE_PWM,   //unsupported per SMU11_MAS
  TIMER_MODE_TIME_SLICE,
  TIMER_MODE_CHRONO_SATURATION,
  TIMER_MODE_COUNT,
} TIMER_MODES_e;


typedef enum {
  TIMER_COUNT_DIRECTION_UP = 0,
  TIMER_COUNT_DIRECTION_DOWN = 1,
  TIMER_COUNT_DIRECTION_COUNT,
} TIMER_COUNT_DIRECTION_e;

typedef enum {
  TIMER_SLICE_TYPE_ONESHOT = 0,
  TIMER_SLICE_TYPE_CONTINUOUS = 1,
  TIMER_SLICE_TYPE_COUNT,
} TIMER_SLICE_TYPE_e;


#define TIMER_INTERRUPTS_ENABLED_NONE  0x0
#define TIMER_INTERRUPTS_ENABLED_OCMP1 0x1
#define TIMER_INTERRUPTS_ENABLED_OCMP2 0x2
#define TIMER_INTERRUPTS_ENABLED_OCMP3 0x4

typedef enum {
  MP_TIMER_ID_0,
  MP_TIMER_ID_1,
  MP_TIMER_ID_2,
  MP_TIMER_ID_3,
  MP_TIMER_ID_4,
  MP_TIMER_ID_5,
  MP_TIMER_ID_6,
  MP_TIMER_ID_7,
  MP_TIMER_COUNT,
} MP_TIMER_ID_e;
#endif
