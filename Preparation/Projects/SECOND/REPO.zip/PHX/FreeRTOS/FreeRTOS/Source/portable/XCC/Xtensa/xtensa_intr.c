/*
 * Copyright (c) 2015-2019 Cadence Design Systems, Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/******************************************************************************
  Xtensa-specific interrupt and exception functions for RTOS ports.
  Also see xtensa_intr_asm.S.
******************************************************************************/

#include <stdlib.h>

#include <xtensa/config/core.h>
#include <xtensa/core-macros.h>
#if XCHAL_HAVE_INTERRUPTS
#include <xtensa/tie/xt_interrupt.h>
#endif

#include "xtensa_api.h"
#include "fch.h"
#include "smn.h"

#define LX6_L1_PIC1_INT_MASK (0x1 << XCHAL_EXTINT0_NUM)
#define LX6_L1_PIC0_INT_MASK (0x1 << XCHAL_EXTINT1_NUM)

void IsrPIC(void);
extern void _exit(int code);

#if XCHAL_HAVE_EXCEPTIONS

/* Handler table is in xtensa_intr_asm.S */
extern xt_exc_handler xt_exception_table[XCHAL_EXCCAUSE_NUM];

extern void amf_printf(const char *fmt, ...);

/*
  Default handler for unhandled exceptions.
*/
void
xt_unhandled_exception( XtExcFrame * frame )
{
    MPM_REG(MPM_PUB_SCRATCH13) = (uint32_t)frame->pc;
    MPM_REG(MPM_PUB_SCRATCH14) = (uint32_t)frame->exccause;
    MPM_REG(MPM_PUB_SCRATCH15) = (uint32_t)frame->excvaddr;
    amf_printf("UNHANDLED EXCEPTION OCCURRED. STACK FRAME BELOW:\n");
    amf_printf("PC  : 0x%x\n", frame->pc);
    amf_printf("PS  : 0x%x\n", frame->ps);
    amf_printf("A0  : 0x%x\n", frame->a0);
    amf_printf("A1  : 0x%x\n", frame->a1);
    amf_printf("A2  : 0x%x\n", frame->a2);
    amf_printf("A3  : 0x%x\n", frame->a3);
    amf_printf("A4  : 0x%x\n", frame->a4);
    amf_printf("A5  : 0x%x\n", frame->a5);
    amf_printf("A6  : 0x%x\n", frame->a6);
    amf_printf("A7  : 0x%x\n", frame->a7);
    amf_printf("A8  : 0x%x\n", frame->a8);
    amf_printf("A9  : 0x%x\n", frame->a9);
    amf_printf("A10 : 0x%x\n", frame->a10);
    amf_printf("A11 : 0x%x\n", frame->a11);
    amf_printf("A12 : 0x%x\n", frame->a12);
    amf_printf("A13 : 0x%x\n", frame->a13);
    amf_printf("A14 : 0x%x\n", frame->a14);
    amf_printf("A15 : 0x%x\n", frame->a15);
    amf_printf("SAR : 0x%x\n", frame->sar);
    amf_printf("EXCCAUSE : 0x%x\n", frame->exccause);
    amf_printf("EXCVADDR : 0x%x\n", frame->excvaddr);
    _exit( -1 );
}


/*
  This function registers a handler for the specified exception.
  The function returns the address of the previous handler.
  On error, it returns NULL.
*/
xt_exc_handler
xt_set_exception_handler( uint32_t n, xt_exc_handler f )
{
    xt_exc_handler old;

    if ( n >= (uint32_t) XCHAL_EXCCAUSE_NUM )
    {
        // Invalid exception number.
        return NULL;
    }

    old = xt_exception_table[n];

    if ( f != NULL )
    {
        xt_exception_table[n] = f;
    }
    else
    {
        xt_exception_table[n] = &xt_unhandled_exception;
    }

    return old;
}

#endif

#if XCHAL_HAVE_INTERRUPTS

#if XCHAL_HAVE_XEA2
/* Defined in xtensa_intr_asm.S */
extern uint32_t xt_intenable;
extern uint32_t xt_vpri_mask;
#endif

/* Handler table is in xtensa_intr_asm.S */
typedef struct xt_handler_table_entry {
    void * handler;
    void * arg;
} xt_handler_table_entry;

#if (XT_USE_INT_WRAPPER || XCHAL_HAVE_XEA3)
extern xt_handler_table_entry xt_interrupt_table[XCHAL_NUM_INTERRUPTS + 1];
#else
extern xt_handler_table_entry xt_interrupt_table[XCHAL_NUM_INTERRUPTS];
#endif


/*
  Default handler for unhandled interrupts.
*/
void
xt_unhandled_interrupt( void * arg )
{
    (void) arg;
    _exit( -1 );
}


/*
  This function registers a handler for the specified interrupt. The "arg"
  parameter specifies the argument to be passed to the handler when it is
  invoked. The function returns the address of the previous handler.
  On error, it returns NULL.
*/
xt_handler
xt_set_interrupt_handler( uint32_t n, xt_handler f, void * arg )
{
    xt_handler_table_entry * entry;
    xt_handler               old;

    if ( n >= (uint32_t) XCHAL_NUM_INTERRUPTS )
    {
        // Invalid interrupt number.
        return NULL;
    }

#if XCHAL_HAVE_XEA2
    if ( Xthal_intlevel[n] > XCHAL_EXCM_LEVEL )
    {
        // Priority level too high to safely handle in C.
        return NULL;
    }
#endif

#if (XT_USE_INT_WRAPPER || XCHAL_HAVE_XEA3)
    entry = xt_interrupt_table + n + 1;
#else
    entry = xt_interrupt_table + n;
#endif
    old   = entry->handler;

    if ( f != NULL )
    {
        entry->handler = f;
        entry->arg     = arg;
    }
    else
    {
        entry->handler = &xt_unhandled_interrupt;
        entry->arg     = (void*)n;
    }

    return old;
}


/*
  This function enables the interrupt whose number is specified as
  the argument.
*/
void
xt_interrupt_enable( uint32_t intnum )
{
#if XCHAL_HAVE_XEA2
    if ( intnum < (uint32_t) XCHAL_NUM_INTERRUPTS )
    {
        uint32_t ps = XT_RSIL( 15 );

        // New INTENABLE = (xt_intenable | mask) & xt_vpri_mask.
        xt_intenable |= ( 1U << intnum );
        XT_WSR_INTENABLE( xt_intenable & xt_vpri_mask );
        XT_WSR_PS( ps );
        XT_RSYNC();
    }
#else
    xthal_interrupt_enable( intnum );
#endif
}


/*
  This function disables the interrupt whose number is specified as
  the argument.
*/
void
xt_interrupt_disable( uint32_t intnum )
{
#if XCHAL_HAVE_XEA2
    if ( intnum < (uint32_t) XCHAL_NUM_INTERRUPTS )
    {
        uint32_t ps = XT_RSIL( 15 );

        // New INTENABLE = (xt_intenable & ~mask) & xt_vpri_mask.
        xt_intenable &= ~( 1U << intnum );
        XT_WSR_INTENABLE( xt_intenable & xt_vpri_mask );
        XT_WSR_PS( ps );
        XT_RSYNC();
    }
#else
    xthal_interrupt_disable( intnum );
#endif
}


/*
  This function returns : 1 if the specified interrupt is enabled, zero
  if the interrupt is disabled, zero if the interrupt number is invalid.
*/
uint32_t
xt_interrupt_enabled( uint32_t intnum )
{
#if XCHAL_HAVE_XEA2
    if ( intnum < (uint32_t) XCHAL_NUM_INTERRUPTS )
    {
        return ( (xt_intenable & (1U << intnum)) != 0 ) ? 1U : 0;
    }
    return 0;
#else
    return xthal_interrupt_enabled( intnum );
#endif
}


/*
  This function triggers the specified interrupt.
*/
void
xt_interrupt_trigger( uint32_t intnum )
{
    xthal_interrupt_trigger( intnum );
}


/*
  This function clears the specified interrupt.
*/
void
xt_interrupt_clear( uint32_t intnum )
{
    xthal_interrupt_clear( intnum );
}



#if defined(BUILD_MP1) || defined(BUILD_MPM)
// --- Interrupt Handling ---
void HandleL1Interrupts(uint32_t Type, uint32_t Arg, uint32_t Pc)
{
  if (Type == EXCCAUSE_LEVEL1INTERRUPT) {
    IsrPIC();
  } else if ((Type == EXCCAUSE_ITLB_MISS) || (Type == EXCCAUSE_DTLB_MISS)) {
    (void)Arg;
    (void)Pc;
    //HandleTLBMissException(Type, Arg);
    _exit(-1); //hang for now
  } else if (Type == EXCCAUSE_LOAD_STORE_DATA_ERROR) {
    _exit(-1); //hang for now
  } else {
    _exit(-1); //hang for now
  }
}

// Enable interrupts atomically with respect to level-3 interrupts
uint32_t EnableLX6Interrupt(uint32_t Mask) {
  uint32_t RetVal;
  uint32_t NewIntEnable;
  __asm__ __volatile__ (
    "rsil a15, 3\n"
    "rsr %0, intenable\n"
    "or %1, %0, %2\n"
    "wsr %1, intenable\n"
    "wsr a15, PS\n"
    "rsync\n"
    :"=&a" (RetVal), "=&a" (NewIntEnable)
    :"a" (Mask)
    :"a15"
  );
  return RetVal;
}
#endif

#endif /* XCHAL_HAVE_INTERRUPTS */

