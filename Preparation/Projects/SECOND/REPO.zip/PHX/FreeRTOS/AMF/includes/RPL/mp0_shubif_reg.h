// Copyright (c) 1994 - 2021 Advanced Micro Devices, Inc. All rights reserved. 
 #if !defined (_MP0_SHUBIF_FIDDLE_H)
#define _MP0_SHUBIF_FIDDLE_H
 /*****************************************************************************************************************
 *
 *  mp0_shubif_reg.h
 *
 *  Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif

 /*******************************************************
 * Values
 *******************************************************/

 /*******************************************************
 * Structures
 *******************************************************/

/*
 * MP0_SYSHUB_SOC_TLB0_1 struct
 */

#define MP0_SYSHUB_SOC_TLB0_1_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_1_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_1_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_1_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_1_MASK \
      (MP0_SYSHUB_SOC_TLB0_1_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_1_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB0_1_GET_SOC_ADDR(mp0_syshub_soc_tlb0_1) \
      ((mp0_syshub_soc_tlb0_1 & MP0_SYSHUB_SOC_TLB0_1_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_1_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_1_SET_SOC_ADDR(mp0_syshub_soc_tlb0_1_reg, soc_addr) \
      mp0_syshub_soc_tlb0_1_reg = (mp0_syshub_soc_tlb0_1_reg & ~MP0_SYSHUB_SOC_TLB0_1_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_1_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_1_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_1_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_1_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_1_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_1_t f;
} mp0_syshub_soc_tlb0_1_u;


/*
 * MP0_SYSHUB_SOC_TLB1_1 struct
 */

#define MP0_SYSHUB_SOC_TLB1_1_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_1_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_1_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_1_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_1_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_1_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_1_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_1_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_1_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_1_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_1_MASK \
      (MP0_SYSHUB_SOC_TLB1_1_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_1_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_1_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_1_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB1_1_GET_COHERENCE(mp0_syshub_soc_tlb1_1) \
      ((mp0_syshub_soc_tlb1_1 & MP0_SYSHUB_SOC_TLB1_1_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_1_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_1_GET_SEG_SIZE(mp0_syshub_soc_tlb1_1) \
      ((mp0_syshub_soc_tlb1_1 & MP0_SYSHUB_SOC_TLB1_1_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_1_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_1_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_1) \
      ((mp0_syshub_soc_tlb1_1 & MP0_SYSHUB_SOC_TLB1_1_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_1_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_1_SET_COHERENCE(mp0_syshub_soc_tlb1_1_reg, coherence) \
      mp0_syshub_soc_tlb1_1_reg = (mp0_syshub_soc_tlb1_1_reg & ~MP0_SYSHUB_SOC_TLB1_1_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_1_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_1_SET_SEG_SIZE(mp0_syshub_soc_tlb1_1_reg, seg_size) \
      mp0_syshub_soc_tlb1_1_reg = (mp0_syshub_soc_tlb1_1_reg & ~MP0_SYSHUB_SOC_TLB1_1_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_1_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_1_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_1_reg, seg_offset) \
      mp0_syshub_soc_tlb1_1_reg = (mp0_syshub_soc_tlb1_1_reg & ~MP0_SYSHUB_SOC_TLB1_1_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_1_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_1_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_1_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_1_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_1_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_1_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_1_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_1_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_1_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_1_t f;
} mp0_syshub_soc_tlb1_1_u;


/*
 * MP0_SYSHUB_SOC_TLB2_1 struct
 */

#define MP0_SYSHUB_SOC_TLB2_1_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_1_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_1_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_1_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_1_MASK \
      (MP0_SYSHUB_SOC_TLB2_1_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_1_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB2_1_GET_AWUSER(mp0_syshub_soc_tlb2_1) \
      ((mp0_syshub_soc_tlb2_1 & MP0_SYSHUB_SOC_TLB2_1_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_1_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_1_SET_AWUSER(mp0_syshub_soc_tlb2_1_reg, awuser) \
      mp0_syshub_soc_tlb2_1_reg = (mp0_syshub_soc_tlb2_1_reg & ~MP0_SYSHUB_SOC_TLB2_1_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_1_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_1_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_1_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_1_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_1_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_1_t f;
} mp0_syshub_soc_tlb2_1_u;


/*
 * MP0_SYSHUB_SOC_TLB3_1 struct
 */

#define MP0_SYSHUB_SOC_TLB3_1_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_1_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_1_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_1_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_1_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_1_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_1_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_1_MASK \
      (MP0_SYSHUB_SOC_TLB3_1_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_1_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_1_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB3_1_GET_ARUSER(mp0_syshub_soc_tlb3_1) \
      ((mp0_syshub_soc_tlb3_1 & MP0_SYSHUB_SOC_TLB3_1_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_1_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_1_GET_WUSER(mp0_syshub_soc_tlb3_1) \
      ((mp0_syshub_soc_tlb3_1 & MP0_SYSHUB_SOC_TLB3_1_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_1_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_1_SET_ARUSER(mp0_syshub_soc_tlb3_1_reg, aruser) \
      mp0_syshub_soc_tlb3_1_reg = (mp0_syshub_soc_tlb3_1_reg & ~MP0_SYSHUB_SOC_TLB3_1_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_1_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_1_SET_WUSER(mp0_syshub_soc_tlb3_1_reg, wuser) \
      mp0_syshub_soc_tlb3_1_reg = (mp0_syshub_soc_tlb3_1_reg & ~MP0_SYSHUB_SOC_TLB3_1_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_1_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_1_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_1_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_1_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_1_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_1_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_1_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_1_t f;
} mp0_syshub_soc_tlb3_1_u;


/*
 * MP0_SYSHUB_SOC_TLB0_2 struct
 */

#define MP0_SYSHUB_SOC_TLB0_2_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_2_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_2_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_2_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_2_MASK \
      (MP0_SYSHUB_SOC_TLB0_2_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_2_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB0_2_GET_SOC_ADDR(mp0_syshub_soc_tlb0_2) \
      ((mp0_syshub_soc_tlb0_2 & MP0_SYSHUB_SOC_TLB0_2_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_2_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_2_SET_SOC_ADDR(mp0_syshub_soc_tlb0_2_reg, soc_addr) \
      mp0_syshub_soc_tlb0_2_reg = (mp0_syshub_soc_tlb0_2_reg & ~MP0_SYSHUB_SOC_TLB0_2_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_2_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_2_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_2_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_2_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_2_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_2_t f;
} mp0_syshub_soc_tlb0_2_u;


/*
 * MP0_SYSHUB_SOC_TLB1_2 struct
 */

#define MP0_SYSHUB_SOC_TLB1_2_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_2_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_2_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_2_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_2_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_2_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_2_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_2_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_2_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_2_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_2_MASK \
      (MP0_SYSHUB_SOC_TLB1_2_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_2_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_2_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_2_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB1_2_GET_COHERENCE(mp0_syshub_soc_tlb1_2) \
      ((mp0_syshub_soc_tlb1_2 & MP0_SYSHUB_SOC_TLB1_2_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_2_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_2_GET_SEG_SIZE(mp0_syshub_soc_tlb1_2) \
      ((mp0_syshub_soc_tlb1_2 & MP0_SYSHUB_SOC_TLB1_2_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_2_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_2_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_2) \
      ((mp0_syshub_soc_tlb1_2 & MP0_SYSHUB_SOC_TLB1_2_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_2_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_2_SET_COHERENCE(mp0_syshub_soc_tlb1_2_reg, coherence) \
      mp0_syshub_soc_tlb1_2_reg = (mp0_syshub_soc_tlb1_2_reg & ~MP0_SYSHUB_SOC_TLB1_2_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_2_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_2_SET_SEG_SIZE(mp0_syshub_soc_tlb1_2_reg, seg_size) \
      mp0_syshub_soc_tlb1_2_reg = (mp0_syshub_soc_tlb1_2_reg & ~MP0_SYSHUB_SOC_TLB1_2_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_2_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_2_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_2_reg, seg_offset) \
      mp0_syshub_soc_tlb1_2_reg = (mp0_syshub_soc_tlb1_2_reg & ~MP0_SYSHUB_SOC_TLB1_2_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_2_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_2_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_2_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_2_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_2_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_2_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_2_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_2_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_2_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_2_t f;
} mp0_syshub_soc_tlb1_2_u;


/*
 * MP0_SYSHUB_SOC_TLB2_2 struct
 */

#define MP0_SYSHUB_SOC_TLB2_2_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_2_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_2_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_2_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_2_MASK \
      (MP0_SYSHUB_SOC_TLB2_2_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_2_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB2_2_GET_AWUSER(mp0_syshub_soc_tlb2_2) \
      ((mp0_syshub_soc_tlb2_2 & MP0_SYSHUB_SOC_TLB2_2_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_2_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_2_SET_AWUSER(mp0_syshub_soc_tlb2_2_reg, awuser) \
      mp0_syshub_soc_tlb2_2_reg = (mp0_syshub_soc_tlb2_2_reg & ~MP0_SYSHUB_SOC_TLB2_2_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_2_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_2_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_2_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_2_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_2_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_2_t f;
} mp0_syshub_soc_tlb2_2_u;


/*
 * MP0_SYSHUB_SOC_TLB3_2 struct
 */

#define MP0_SYSHUB_SOC_TLB3_2_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_2_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_2_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_2_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_2_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_2_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_2_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_2_MASK \
      (MP0_SYSHUB_SOC_TLB3_2_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_2_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_2_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB3_2_GET_ARUSER(mp0_syshub_soc_tlb3_2) \
      ((mp0_syshub_soc_tlb3_2 & MP0_SYSHUB_SOC_TLB3_2_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_2_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_2_GET_WUSER(mp0_syshub_soc_tlb3_2) \
      ((mp0_syshub_soc_tlb3_2 & MP0_SYSHUB_SOC_TLB3_2_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_2_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_2_SET_ARUSER(mp0_syshub_soc_tlb3_2_reg, aruser) \
      mp0_syshub_soc_tlb3_2_reg = (mp0_syshub_soc_tlb3_2_reg & ~MP0_SYSHUB_SOC_TLB3_2_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_2_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_2_SET_WUSER(mp0_syshub_soc_tlb3_2_reg, wuser) \
      mp0_syshub_soc_tlb3_2_reg = (mp0_syshub_soc_tlb3_2_reg & ~MP0_SYSHUB_SOC_TLB3_2_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_2_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_2_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_2_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_2_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_2_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_2_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_2_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_2_t f;
} mp0_syshub_soc_tlb3_2_u;


/*
 * MP0_SYSHUB_SOC_TLB0_3 struct
 */

#define MP0_SYSHUB_SOC_TLB0_3_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_3_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_3_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_3_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_3_MASK \
      (MP0_SYSHUB_SOC_TLB0_3_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_3_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB0_3_GET_SOC_ADDR(mp0_syshub_soc_tlb0_3) \
      ((mp0_syshub_soc_tlb0_3 & MP0_SYSHUB_SOC_TLB0_3_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_3_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_3_SET_SOC_ADDR(mp0_syshub_soc_tlb0_3_reg, soc_addr) \
      mp0_syshub_soc_tlb0_3_reg = (mp0_syshub_soc_tlb0_3_reg & ~MP0_SYSHUB_SOC_TLB0_3_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_3_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_3_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_3_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_3_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_3_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_3_t f;
} mp0_syshub_soc_tlb0_3_u;


/*
 * MP0_SYSHUB_SOC_TLB1_3 struct
 */

#define MP0_SYSHUB_SOC_TLB1_3_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_3_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_3_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_3_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_3_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_3_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_3_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_3_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_3_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_3_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_3_MASK \
      (MP0_SYSHUB_SOC_TLB1_3_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_3_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_3_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_3_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB1_3_GET_COHERENCE(mp0_syshub_soc_tlb1_3) \
      ((mp0_syshub_soc_tlb1_3 & MP0_SYSHUB_SOC_TLB1_3_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_3_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_3_GET_SEG_SIZE(mp0_syshub_soc_tlb1_3) \
      ((mp0_syshub_soc_tlb1_3 & MP0_SYSHUB_SOC_TLB1_3_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_3_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_3_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_3) \
      ((mp0_syshub_soc_tlb1_3 & MP0_SYSHUB_SOC_TLB1_3_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_3_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_3_SET_COHERENCE(mp0_syshub_soc_tlb1_3_reg, coherence) \
      mp0_syshub_soc_tlb1_3_reg = (mp0_syshub_soc_tlb1_3_reg & ~MP0_SYSHUB_SOC_TLB1_3_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_3_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_3_SET_SEG_SIZE(mp0_syshub_soc_tlb1_3_reg, seg_size) \
      mp0_syshub_soc_tlb1_3_reg = (mp0_syshub_soc_tlb1_3_reg & ~MP0_SYSHUB_SOC_TLB1_3_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_3_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_3_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_3_reg, seg_offset) \
      mp0_syshub_soc_tlb1_3_reg = (mp0_syshub_soc_tlb1_3_reg & ~MP0_SYSHUB_SOC_TLB1_3_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_3_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_3_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_3_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_3_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_3_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_3_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_3_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_3_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_3_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_3_t f;
} mp0_syshub_soc_tlb1_3_u;


/*
 * MP0_SYSHUB_SOC_TLB2_3 struct
 */

#define MP0_SYSHUB_SOC_TLB2_3_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_3_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_3_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_3_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_3_MASK \
      (MP0_SYSHUB_SOC_TLB2_3_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_3_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB2_3_GET_AWUSER(mp0_syshub_soc_tlb2_3) \
      ((mp0_syshub_soc_tlb2_3 & MP0_SYSHUB_SOC_TLB2_3_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_3_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_3_SET_AWUSER(mp0_syshub_soc_tlb2_3_reg, awuser) \
      mp0_syshub_soc_tlb2_3_reg = (mp0_syshub_soc_tlb2_3_reg & ~MP0_SYSHUB_SOC_TLB2_3_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_3_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_3_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_3_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_3_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_3_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_3_t f;
} mp0_syshub_soc_tlb2_3_u;


/*
 * MP0_SYSHUB_SOC_TLB3_3 struct
 */

#define MP0_SYSHUB_SOC_TLB3_3_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_3_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_3_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_3_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_3_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_3_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_3_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_3_MASK \
      (MP0_SYSHUB_SOC_TLB3_3_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_3_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_3_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB3_3_GET_ARUSER(mp0_syshub_soc_tlb3_3) \
      ((mp0_syshub_soc_tlb3_3 & MP0_SYSHUB_SOC_TLB3_3_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_3_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_3_GET_WUSER(mp0_syshub_soc_tlb3_3) \
      ((mp0_syshub_soc_tlb3_3 & MP0_SYSHUB_SOC_TLB3_3_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_3_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_3_SET_ARUSER(mp0_syshub_soc_tlb3_3_reg, aruser) \
      mp0_syshub_soc_tlb3_3_reg = (mp0_syshub_soc_tlb3_3_reg & ~MP0_SYSHUB_SOC_TLB3_3_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_3_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_3_SET_WUSER(mp0_syshub_soc_tlb3_3_reg, wuser) \
      mp0_syshub_soc_tlb3_3_reg = (mp0_syshub_soc_tlb3_3_reg & ~MP0_SYSHUB_SOC_TLB3_3_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_3_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_3_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_3_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_3_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_3_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_3_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_3_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_3_t f;
} mp0_syshub_soc_tlb3_3_u;


/*
 * MP0_SYSHUB_SOC_TLB0_4 struct
 */

#define MP0_SYSHUB_SOC_TLB0_4_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_4_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_4_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_4_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_4_MASK \
      (MP0_SYSHUB_SOC_TLB0_4_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_4_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB0_4_GET_SOC_ADDR(mp0_syshub_soc_tlb0_4) \
      ((mp0_syshub_soc_tlb0_4 & MP0_SYSHUB_SOC_TLB0_4_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_4_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_4_SET_SOC_ADDR(mp0_syshub_soc_tlb0_4_reg, soc_addr) \
      mp0_syshub_soc_tlb0_4_reg = (mp0_syshub_soc_tlb0_4_reg & ~MP0_SYSHUB_SOC_TLB0_4_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_4_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_4_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_4_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_4_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_4_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_4_t f;
} mp0_syshub_soc_tlb0_4_u;


/*
 * MP0_SYSHUB_SOC_TLB1_4 struct
 */

#define MP0_SYSHUB_SOC_TLB1_4_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_4_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_4_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_4_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_4_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_4_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_4_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_4_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_4_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_4_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_4_MASK \
      (MP0_SYSHUB_SOC_TLB1_4_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_4_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_4_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_4_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB1_4_GET_COHERENCE(mp0_syshub_soc_tlb1_4) \
      ((mp0_syshub_soc_tlb1_4 & MP0_SYSHUB_SOC_TLB1_4_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_4_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_4_GET_SEG_SIZE(mp0_syshub_soc_tlb1_4) \
      ((mp0_syshub_soc_tlb1_4 & MP0_SYSHUB_SOC_TLB1_4_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_4_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_4_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_4) \
      ((mp0_syshub_soc_tlb1_4 & MP0_SYSHUB_SOC_TLB1_4_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_4_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_4_SET_COHERENCE(mp0_syshub_soc_tlb1_4_reg, coherence) \
      mp0_syshub_soc_tlb1_4_reg = (mp0_syshub_soc_tlb1_4_reg & ~MP0_SYSHUB_SOC_TLB1_4_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_4_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_4_SET_SEG_SIZE(mp0_syshub_soc_tlb1_4_reg, seg_size) \
      mp0_syshub_soc_tlb1_4_reg = (mp0_syshub_soc_tlb1_4_reg & ~MP0_SYSHUB_SOC_TLB1_4_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_4_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_4_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_4_reg, seg_offset) \
      mp0_syshub_soc_tlb1_4_reg = (mp0_syshub_soc_tlb1_4_reg & ~MP0_SYSHUB_SOC_TLB1_4_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_4_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_4_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_4_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_4_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_4_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_4_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_4_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_4_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_4_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_4_t f;
} mp0_syshub_soc_tlb1_4_u;


/*
 * MP0_SYSHUB_SOC_TLB2_4 struct
 */

#define MP0_SYSHUB_SOC_TLB2_4_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_4_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_4_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_4_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_4_MASK \
      (MP0_SYSHUB_SOC_TLB2_4_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_4_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB2_4_GET_AWUSER(mp0_syshub_soc_tlb2_4) \
      ((mp0_syshub_soc_tlb2_4 & MP0_SYSHUB_SOC_TLB2_4_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_4_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_4_SET_AWUSER(mp0_syshub_soc_tlb2_4_reg, awuser) \
      mp0_syshub_soc_tlb2_4_reg = (mp0_syshub_soc_tlb2_4_reg & ~MP0_SYSHUB_SOC_TLB2_4_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_4_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_4_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_4_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_4_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_4_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_4_t f;
} mp0_syshub_soc_tlb2_4_u;


/*
 * MP0_SYSHUB_SOC_TLB3_4 struct
 */

#define MP0_SYSHUB_SOC_TLB3_4_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_4_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_4_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_4_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_4_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_4_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_4_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_4_MASK \
      (MP0_SYSHUB_SOC_TLB3_4_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_4_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_4_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB3_4_GET_ARUSER(mp0_syshub_soc_tlb3_4) \
      ((mp0_syshub_soc_tlb3_4 & MP0_SYSHUB_SOC_TLB3_4_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_4_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_4_GET_WUSER(mp0_syshub_soc_tlb3_4) \
      ((mp0_syshub_soc_tlb3_4 & MP0_SYSHUB_SOC_TLB3_4_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_4_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_4_SET_ARUSER(mp0_syshub_soc_tlb3_4_reg, aruser) \
      mp0_syshub_soc_tlb3_4_reg = (mp0_syshub_soc_tlb3_4_reg & ~MP0_SYSHUB_SOC_TLB3_4_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_4_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_4_SET_WUSER(mp0_syshub_soc_tlb3_4_reg, wuser) \
      mp0_syshub_soc_tlb3_4_reg = (mp0_syshub_soc_tlb3_4_reg & ~MP0_SYSHUB_SOC_TLB3_4_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_4_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_4_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_4_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_4_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_4_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_4_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_4_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_4_t f;
} mp0_syshub_soc_tlb3_4_u;


/*
 * MP0_SYSHUB_SOC_TLB0_5 struct
 */

#define MP0_SYSHUB_SOC_TLB0_5_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_5_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_5_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_5_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_5_MASK \
      (MP0_SYSHUB_SOC_TLB0_5_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_5_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB0_5_GET_SOC_ADDR(mp0_syshub_soc_tlb0_5) \
      ((mp0_syshub_soc_tlb0_5 & MP0_SYSHUB_SOC_TLB0_5_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_5_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_5_SET_SOC_ADDR(mp0_syshub_soc_tlb0_5_reg, soc_addr) \
      mp0_syshub_soc_tlb0_5_reg = (mp0_syshub_soc_tlb0_5_reg & ~MP0_SYSHUB_SOC_TLB0_5_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_5_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_5_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_5_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_5_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_5_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_5_t f;
} mp0_syshub_soc_tlb0_5_u;


/*
 * MP0_SYSHUB_SOC_TLB1_5 struct
 */

#define MP0_SYSHUB_SOC_TLB1_5_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_5_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_5_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_5_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_5_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_5_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_5_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_5_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_5_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_5_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_5_MASK \
      (MP0_SYSHUB_SOC_TLB1_5_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_5_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_5_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_5_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB1_5_GET_COHERENCE(mp0_syshub_soc_tlb1_5) \
      ((mp0_syshub_soc_tlb1_5 & MP0_SYSHUB_SOC_TLB1_5_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_5_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_5_GET_SEG_SIZE(mp0_syshub_soc_tlb1_5) \
      ((mp0_syshub_soc_tlb1_5 & MP0_SYSHUB_SOC_TLB1_5_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_5_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_5_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_5) \
      ((mp0_syshub_soc_tlb1_5 & MP0_SYSHUB_SOC_TLB1_5_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_5_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_5_SET_COHERENCE(mp0_syshub_soc_tlb1_5_reg, coherence) \
      mp0_syshub_soc_tlb1_5_reg = (mp0_syshub_soc_tlb1_5_reg & ~MP0_SYSHUB_SOC_TLB1_5_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_5_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_5_SET_SEG_SIZE(mp0_syshub_soc_tlb1_5_reg, seg_size) \
      mp0_syshub_soc_tlb1_5_reg = (mp0_syshub_soc_tlb1_5_reg & ~MP0_SYSHUB_SOC_TLB1_5_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_5_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_5_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_5_reg, seg_offset) \
      mp0_syshub_soc_tlb1_5_reg = (mp0_syshub_soc_tlb1_5_reg & ~MP0_SYSHUB_SOC_TLB1_5_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_5_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_5_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_5_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_5_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_5_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_5_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_5_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_5_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_5_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_5_t f;
} mp0_syshub_soc_tlb1_5_u;


/*
 * MP0_SYSHUB_SOC_TLB2_5 struct
 */

#define MP0_SYSHUB_SOC_TLB2_5_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_5_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_5_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_5_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_5_MASK \
      (MP0_SYSHUB_SOC_TLB2_5_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_5_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB2_5_GET_AWUSER(mp0_syshub_soc_tlb2_5) \
      ((mp0_syshub_soc_tlb2_5 & MP0_SYSHUB_SOC_TLB2_5_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_5_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_5_SET_AWUSER(mp0_syshub_soc_tlb2_5_reg, awuser) \
      mp0_syshub_soc_tlb2_5_reg = (mp0_syshub_soc_tlb2_5_reg & ~MP0_SYSHUB_SOC_TLB2_5_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_5_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_5_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_5_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_5_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_5_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_5_t f;
} mp0_syshub_soc_tlb2_5_u;


/*
 * MP0_SYSHUB_SOC_TLB3_5 struct
 */

#define MP0_SYSHUB_SOC_TLB3_5_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_5_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_5_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_5_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_5_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_5_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_5_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_5_MASK \
      (MP0_SYSHUB_SOC_TLB3_5_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_5_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_5_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB3_5_GET_ARUSER(mp0_syshub_soc_tlb3_5) \
      ((mp0_syshub_soc_tlb3_5 & MP0_SYSHUB_SOC_TLB3_5_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_5_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_5_GET_WUSER(mp0_syshub_soc_tlb3_5) \
      ((mp0_syshub_soc_tlb3_5 & MP0_SYSHUB_SOC_TLB3_5_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_5_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_5_SET_ARUSER(mp0_syshub_soc_tlb3_5_reg, aruser) \
      mp0_syshub_soc_tlb3_5_reg = (mp0_syshub_soc_tlb3_5_reg & ~MP0_SYSHUB_SOC_TLB3_5_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_5_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_5_SET_WUSER(mp0_syshub_soc_tlb3_5_reg, wuser) \
      mp0_syshub_soc_tlb3_5_reg = (mp0_syshub_soc_tlb3_5_reg & ~MP0_SYSHUB_SOC_TLB3_5_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_5_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_5_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_5_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_5_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_5_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_5_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_5_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_5_t f;
} mp0_syshub_soc_tlb3_5_u;


/*
 * MP0_SYSHUB_SOC_TLB0_6 struct
 */

#define MP0_SYSHUB_SOC_TLB0_6_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_6_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_6_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_6_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_6_MASK \
      (MP0_SYSHUB_SOC_TLB0_6_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_6_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB0_6_GET_SOC_ADDR(mp0_syshub_soc_tlb0_6) \
      ((mp0_syshub_soc_tlb0_6 & MP0_SYSHUB_SOC_TLB0_6_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_6_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_6_SET_SOC_ADDR(mp0_syshub_soc_tlb0_6_reg, soc_addr) \
      mp0_syshub_soc_tlb0_6_reg = (mp0_syshub_soc_tlb0_6_reg & ~MP0_SYSHUB_SOC_TLB0_6_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_6_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_6_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_6_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_6_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_6_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_6_t f;
} mp0_syshub_soc_tlb0_6_u;


/*
 * MP0_SYSHUB_SOC_TLB1_6 struct
 */

#define MP0_SYSHUB_SOC_TLB1_6_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_6_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_6_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_6_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_6_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_6_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_6_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_6_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_6_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_6_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_6_MASK \
      (MP0_SYSHUB_SOC_TLB1_6_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_6_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_6_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_6_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB1_6_GET_COHERENCE(mp0_syshub_soc_tlb1_6) \
      ((mp0_syshub_soc_tlb1_6 & MP0_SYSHUB_SOC_TLB1_6_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_6_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_6_GET_SEG_SIZE(mp0_syshub_soc_tlb1_6) \
      ((mp0_syshub_soc_tlb1_6 & MP0_SYSHUB_SOC_TLB1_6_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_6_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_6_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_6) \
      ((mp0_syshub_soc_tlb1_6 & MP0_SYSHUB_SOC_TLB1_6_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_6_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_6_SET_COHERENCE(mp0_syshub_soc_tlb1_6_reg, coherence) \
      mp0_syshub_soc_tlb1_6_reg = (mp0_syshub_soc_tlb1_6_reg & ~MP0_SYSHUB_SOC_TLB1_6_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_6_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_6_SET_SEG_SIZE(mp0_syshub_soc_tlb1_6_reg, seg_size) \
      mp0_syshub_soc_tlb1_6_reg = (mp0_syshub_soc_tlb1_6_reg & ~MP0_SYSHUB_SOC_TLB1_6_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_6_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_6_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_6_reg, seg_offset) \
      mp0_syshub_soc_tlb1_6_reg = (mp0_syshub_soc_tlb1_6_reg & ~MP0_SYSHUB_SOC_TLB1_6_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_6_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_6_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_6_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_6_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_6_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_6_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_6_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_6_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_6_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_6_t f;
} mp0_syshub_soc_tlb1_6_u;


/*
 * MP0_SYSHUB_SOC_TLB2_6 struct
 */

#define MP0_SYSHUB_SOC_TLB2_6_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_6_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_6_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_6_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_6_MASK \
      (MP0_SYSHUB_SOC_TLB2_6_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_6_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB2_6_GET_AWUSER(mp0_syshub_soc_tlb2_6) \
      ((mp0_syshub_soc_tlb2_6 & MP0_SYSHUB_SOC_TLB2_6_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_6_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_6_SET_AWUSER(mp0_syshub_soc_tlb2_6_reg, awuser) \
      mp0_syshub_soc_tlb2_6_reg = (mp0_syshub_soc_tlb2_6_reg & ~MP0_SYSHUB_SOC_TLB2_6_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_6_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_6_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_6_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_6_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_6_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_6_t f;
} mp0_syshub_soc_tlb2_6_u;


/*
 * MP0_SYSHUB_SOC_TLB3_6 struct
 */

#define MP0_SYSHUB_SOC_TLB3_6_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_6_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_6_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_6_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_6_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_6_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_6_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_6_MASK \
      (MP0_SYSHUB_SOC_TLB3_6_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_6_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_6_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB3_6_GET_ARUSER(mp0_syshub_soc_tlb3_6) \
      ((mp0_syshub_soc_tlb3_6 & MP0_SYSHUB_SOC_TLB3_6_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_6_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_6_GET_WUSER(mp0_syshub_soc_tlb3_6) \
      ((mp0_syshub_soc_tlb3_6 & MP0_SYSHUB_SOC_TLB3_6_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_6_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_6_SET_ARUSER(mp0_syshub_soc_tlb3_6_reg, aruser) \
      mp0_syshub_soc_tlb3_6_reg = (mp0_syshub_soc_tlb3_6_reg & ~MP0_SYSHUB_SOC_TLB3_6_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_6_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_6_SET_WUSER(mp0_syshub_soc_tlb3_6_reg, wuser) \
      mp0_syshub_soc_tlb3_6_reg = (mp0_syshub_soc_tlb3_6_reg & ~MP0_SYSHUB_SOC_TLB3_6_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_6_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_6_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_6_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_6_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_6_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_6_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_6_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_6_t f;
} mp0_syshub_soc_tlb3_6_u;


/*
 * MP0_SYSHUB_SOC_TLB0_7 struct
 */

#define MP0_SYSHUB_SOC_TLB0_7_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_7_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_7_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_7_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_7_MASK \
      (MP0_SYSHUB_SOC_TLB0_7_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_7_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB0_7_GET_SOC_ADDR(mp0_syshub_soc_tlb0_7) \
      ((mp0_syshub_soc_tlb0_7 & MP0_SYSHUB_SOC_TLB0_7_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_7_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_7_SET_SOC_ADDR(mp0_syshub_soc_tlb0_7_reg, soc_addr) \
      mp0_syshub_soc_tlb0_7_reg = (mp0_syshub_soc_tlb0_7_reg & ~MP0_SYSHUB_SOC_TLB0_7_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_7_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_7_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_7_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_7_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_7_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_7_t f;
} mp0_syshub_soc_tlb0_7_u;


/*
 * MP0_SYSHUB_SOC_TLB1_7 struct
 */

#define MP0_SYSHUB_SOC_TLB1_7_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_7_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_7_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_7_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_7_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_7_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_7_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_7_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_7_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_7_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_7_MASK \
      (MP0_SYSHUB_SOC_TLB1_7_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_7_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_7_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_7_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB1_7_GET_COHERENCE(mp0_syshub_soc_tlb1_7) \
      ((mp0_syshub_soc_tlb1_7 & MP0_SYSHUB_SOC_TLB1_7_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_7_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_7_GET_SEG_SIZE(mp0_syshub_soc_tlb1_7) \
      ((mp0_syshub_soc_tlb1_7 & MP0_SYSHUB_SOC_TLB1_7_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_7_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_7_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_7) \
      ((mp0_syshub_soc_tlb1_7 & MP0_SYSHUB_SOC_TLB1_7_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_7_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_7_SET_COHERENCE(mp0_syshub_soc_tlb1_7_reg, coherence) \
      mp0_syshub_soc_tlb1_7_reg = (mp0_syshub_soc_tlb1_7_reg & ~MP0_SYSHUB_SOC_TLB1_7_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_7_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_7_SET_SEG_SIZE(mp0_syshub_soc_tlb1_7_reg, seg_size) \
      mp0_syshub_soc_tlb1_7_reg = (mp0_syshub_soc_tlb1_7_reg & ~MP0_SYSHUB_SOC_TLB1_7_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_7_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_7_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_7_reg, seg_offset) \
      mp0_syshub_soc_tlb1_7_reg = (mp0_syshub_soc_tlb1_7_reg & ~MP0_SYSHUB_SOC_TLB1_7_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_7_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_7_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_7_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_7_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_7_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_7_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_7_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_7_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_7_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_7_t f;
} mp0_syshub_soc_tlb1_7_u;


/*
 * MP0_SYSHUB_SOC_TLB2_7 struct
 */

#define MP0_SYSHUB_SOC_TLB2_7_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_7_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_7_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_7_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_7_MASK \
      (MP0_SYSHUB_SOC_TLB2_7_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_7_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB2_7_GET_AWUSER(mp0_syshub_soc_tlb2_7) \
      ((mp0_syshub_soc_tlb2_7 & MP0_SYSHUB_SOC_TLB2_7_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_7_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_7_SET_AWUSER(mp0_syshub_soc_tlb2_7_reg, awuser) \
      mp0_syshub_soc_tlb2_7_reg = (mp0_syshub_soc_tlb2_7_reg & ~MP0_SYSHUB_SOC_TLB2_7_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_7_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_7_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_7_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_7_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_7_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_7_t f;
} mp0_syshub_soc_tlb2_7_u;


/*
 * MP0_SYSHUB_SOC_TLB3_7 struct
 */

#define MP0_SYSHUB_SOC_TLB3_7_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_7_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_7_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_7_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_7_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_7_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_7_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_7_MASK \
      (MP0_SYSHUB_SOC_TLB3_7_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_7_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_7_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB3_7_GET_ARUSER(mp0_syshub_soc_tlb3_7) \
      ((mp0_syshub_soc_tlb3_7 & MP0_SYSHUB_SOC_TLB3_7_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_7_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_7_GET_WUSER(mp0_syshub_soc_tlb3_7) \
      ((mp0_syshub_soc_tlb3_7 & MP0_SYSHUB_SOC_TLB3_7_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_7_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_7_SET_ARUSER(mp0_syshub_soc_tlb3_7_reg, aruser) \
      mp0_syshub_soc_tlb3_7_reg = (mp0_syshub_soc_tlb3_7_reg & ~MP0_SYSHUB_SOC_TLB3_7_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_7_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_7_SET_WUSER(mp0_syshub_soc_tlb3_7_reg, wuser) \
      mp0_syshub_soc_tlb3_7_reg = (mp0_syshub_soc_tlb3_7_reg & ~MP0_SYSHUB_SOC_TLB3_7_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_7_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_7_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_7_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_7_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_7_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_7_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_7_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_7_t f;
} mp0_syshub_soc_tlb3_7_u;


/*
 * MP0_SYSHUB_SOC_TLB0_8 struct
 */

#define MP0_SYSHUB_SOC_TLB0_8_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_8_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_8_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_8_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_8_MASK \
      (MP0_SYSHUB_SOC_TLB0_8_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_8_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB0_8_GET_SOC_ADDR(mp0_syshub_soc_tlb0_8) \
      ((mp0_syshub_soc_tlb0_8 & MP0_SYSHUB_SOC_TLB0_8_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_8_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_8_SET_SOC_ADDR(mp0_syshub_soc_tlb0_8_reg, soc_addr) \
      mp0_syshub_soc_tlb0_8_reg = (mp0_syshub_soc_tlb0_8_reg & ~MP0_SYSHUB_SOC_TLB0_8_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_8_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_8_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_8_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_8_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_8_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_8_t f;
} mp0_syshub_soc_tlb0_8_u;


/*
 * MP0_SYSHUB_SOC_TLB1_8 struct
 */

#define MP0_SYSHUB_SOC_TLB1_8_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_8_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_8_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_8_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_8_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_8_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_8_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_8_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_8_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_8_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_8_MASK \
      (MP0_SYSHUB_SOC_TLB1_8_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_8_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_8_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_8_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB1_8_GET_COHERENCE(mp0_syshub_soc_tlb1_8) \
      ((mp0_syshub_soc_tlb1_8 & MP0_SYSHUB_SOC_TLB1_8_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_8_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_8_GET_SEG_SIZE(mp0_syshub_soc_tlb1_8) \
      ((mp0_syshub_soc_tlb1_8 & MP0_SYSHUB_SOC_TLB1_8_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_8_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_8_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_8) \
      ((mp0_syshub_soc_tlb1_8 & MP0_SYSHUB_SOC_TLB1_8_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_8_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_8_SET_COHERENCE(mp0_syshub_soc_tlb1_8_reg, coherence) \
      mp0_syshub_soc_tlb1_8_reg = (mp0_syshub_soc_tlb1_8_reg & ~MP0_SYSHUB_SOC_TLB1_8_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_8_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_8_SET_SEG_SIZE(mp0_syshub_soc_tlb1_8_reg, seg_size) \
      mp0_syshub_soc_tlb1_8_reg = (mp0_syshub_soc_tlb1_8_reg & ~MP0_SYSHUB_SOC_TLB1_8_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_8_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_8_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_8_reg, seg_offset) \
      mp0_syshub_soc_tlb1_8_reg = (mp0_syshub_soc_tlb1_8_reg & ~MP0_SYSHUB_SOC_TLB1_8_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_8_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_8_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_8_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_8_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_8_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_8_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_8_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_8_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_8_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_8_t f;
} mp0_syshub_soc_tlb1_8_u;


/*
 * MP0_SYSHUB_SOC_TLB2_8 struct
 */

#define MP0_SYSHUB_SOC_TLB2_8_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_8_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_8_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_8_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_8_MASK \
      (MP0_SYSHUB_SOC_TLB2_8_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_8_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB2_8_GET_AWUSER(mp0_syshub_soc_tlb2_8) \
      ((mp0_syshub_soc_tlb2_8 & MP0_SYSHUB_SOC_TLB2_8_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_8_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_8_SET_AWUSER(mp0_syshub_soc_tlb2_8_reg, awuser) \
      mp0_syshub_soc_tlb2_8_reg = (mp0_syshub_soc_tlb2_8_reg & ~MP0_SYSHUB_SOC_TLB2_8_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_8_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_8_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_8_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_8_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_8_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_8_t f;
} mp0_syshub_soc_tlb2_8_u;


/*
 * MP0_SYSHUB_SOC_TLB3_8 struct
 */

#define MP0_SYSHUB_SOC_TLB3_8_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_8_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_8_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_8_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_8_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_8_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_8_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_8_MASK \
      (MP0_SYSHUB_SOC_TLB3_8_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_8_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_8_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB3_8_GET_ARUSER(mp0_syshub_soc_tlb3_8) \
      ((mp0_syshub_soc_tlb3_8 & MP0_SYSHUB_SOC_TLB3_8_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_8_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_8_GET_WUSER(mp0_syshub_soc_tlb3_8) \
      ((mp0_syshub_soc_tlb3_8 & MP0_SYSHUB_SOC_TLB3_8_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_8_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_8_SET_ARUSER(mp0_syshub_soc_tlb3_8_reg, aruser) \
      mp0_syshub_soc_tlb3_8_reg = (mp0_syshub_soc_tlb3_8_reg & ~MP0_SYSHUB_SOC_TLB3_8_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_8_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_8_SET_WUSER(mp0_syshub_soc_tlb3_8_reg, wuser) \
      mp0_syshub_soc_tlb3_8_reg = (mp0_syshub_soc_tlb3_8_reg & ~MP0_SYSHUB_SOC_TLB3_8_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_8_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_8_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_8_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_8_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_8_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_8_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_8_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_8_t f;
} mp0_syshub_soc_tlb3_8_u;


/*
 * MP0_SYSHUB_SOC_TLB0_9 struct
 */

#define MP0_SYSHUB_SOC_TLB0_9_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_9_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_9_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_9_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_9_MASK \
      (MP0_SYSHUB_SOC_TLB0_9_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_9_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB0_9_GET_SOC_ADDR(mp0_syshub_soc_tlb0_9) \
      ((mp0_syshub_soc_tlb0_9 & MP0_SYSHUB_SOC_TLB0_9_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_9_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_9_SET_SOC_ADDR(mp0_syshub_soc_tlb0_9_reg, soc_addr) \
      mp0_syshub_soc_tlb0_9_reg = (mp0_syshub_soc_tlb0_9_reg & ~MP0_SYSHUB_SOC_TLB0_9_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_9_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_9_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_9_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_9_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_9_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_9_t f;
} mp0_syshub_soc_tlb0_9_u;


/*
 * MP0_SYSHUB_SOC_TLB1_9 struct
 */

#define MP0_SYSHUB_SOC_TLB1_9_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_9_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_9_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_9_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_9_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_9_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_9_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_9_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_9_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_9_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_9_MASK \
      (MP0_SYSHUB_SOC_TLB1_9_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_9_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_9_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_9_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB1_9_GET_COHERENCE(mp0_syshub_soc_tlb1_9) \
      ((mp0_syshub_soc_tlb1_9 & MP0_SYSHUB_SOC_TLB1_9_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_9_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_9_GET_SEG_SIZE(mp0_syshub_soc_tlb1_9) \
      ((mp0_syshub_soc_tlb1_9 & MP0_SYSHUB_SOC_TLB1_9_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_9_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_9_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_9) \
      ((mp0_syshub_soc_tlb1_9 & MP0_SYSHUB_SOC_TLB1_9_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_9_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_9_SET_COHERENCE(mp0_syshub_soc_tlb1_9_reg, coherence) \
      mp0_syshub_soc_tlb1_9_reg = (mp0_syshub_soc_tlb1_9_reg & ~MP0_SYSHUB_SOC_TLB1_9_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_9_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_9_SET_SEG_SIZE(mp0_syshub_soc_tlb1_9_reg, seg_size) \
      mp0_syshub_soc_tlb1_9_reg = (mp0_syshub_soc_tlb1_9_reg & ~MP0_SYSHUB_SOC_TLB1_9_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_9_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_9_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_9_reg, seg_offset) \
      mp0_syshub_soc_tlb1_9_reg = (mp0_syshub_soc_tlb1_9_reg & ~MP0_SYSHUB_SOC_TLB1_9_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_9_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_9_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_9_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_9_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_9_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_9_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_9_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_9_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_9_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_9_t f;
} mp0_syshub_soc_tlb1_9_u;


/*
 * MP0_SYSHUB_SOC_TLB2_9 struct
 */

#define MP0_SYSHUB_SOC_TLB2_9_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_9_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_9_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_9_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_9_MASK \
      (MP0_SYSHUB_SOC_TLB2_9_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_9_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB2_9_GET_AWUSER(mp0_syshub_soc_tlb2_9) \
      ((mp0_syshub_soc_tlb2_9 & MP0_SYSHUB_SOC_TLB2_9_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_9_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_9_SET_AWUSER(mp0_syshub_soc_tlb2_9_reg, awuser) \
      mp0_syshub_soc_tlb2_9_reg = (mp0_syshub_soc_tlb2_9_reg & ~MP0_SYSHUB_SOC_TLB2_9_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_9_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_9_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_9_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_9_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_9_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_9_t f;
} mp0_syshub_soc_tlb2_9_u;


/*
 * MP0_SYSHUB_SOC_TLB3_9 struct
 */

#define MP0_SYSHUB_SOC_TLB3_9_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_9_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_9_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_9_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_9_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_9_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_9_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_9_MASK \
      (MP0_SYSHUB_SOC_TLB3_9_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_9_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_9_DEFAULT  0x00000000

#define MP0_SYSHUB_SOC_TLB3_9_GET_ARUSER(mp0_syshub_soc_tlb3_9) \
      ((mp0_syshub_soc_tlb3_9 & MP0_SYSHUB_SOC_TLB3_9_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_9_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_9_GET_WUSER(mp0_syshub_soc_tlb3_9) \
      ((mp0_syshub_soc_tlb3_9 & MP0_SYSHUB_SOC_TLB3_9_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_9_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_9_SET_ARUSER(mp0_syshub_soc_tlb3_9_reg, aruser) \
      mp0_syshub_soc_tlb3_9_reg = (mp0_syshub_soc_tlb3_9_reg & ~MP0_SYSHUB_SOC_TLB3_9_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_9_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_9_SET_WUSER(mp0_syshub_soc_tlb3_9_reg, wuser) \
      mp0_syshub_soc_tlb3_9_reg = (mp0_syshub_soc_tlb3_9_reg & ~MP0_SYSHUB_SOC_TLB3_9_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_9_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_9_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_9_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_9_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_9_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_9_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_9_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_9_t f;
} mp0_syshub_soc_tlb3_9_u;


/*
 * MP0_SYSHUB_SOC_TLB0_10 struct
 */

#define MP0_SYSHUB_SOC_TLB0_10_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_10_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_10_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_10_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_10_MASK \
      (MP0_SYSHUB_SOC_TLB0_10_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_10_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_10_GET_SOC_ADDR(mp0_syshub_soc_tlb0_10) \
      ((mp0_syshub_soc_tlb0_10 & MP0_SYSHUB_SOC_TLB0_10_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_10_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_10_SET_SOC_ADDR(mp0_syshub_soc_tlb0_10_reg, soc_addr) \
      mp0_syshub_soc_tlb0_10_reg = (mp0_syshub_soc_tlb0_10_reg & ~MP0_SYSHUB_SOC_TLB0_10_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_10_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_10_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_10_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_10_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_10_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_10_t f;
} mp0_syshub_soc_tlb0_10_u;


/*
 * MP0_SYSHUB_SOC_TLB1_10 struct
 */

#define MP0_SYSHUB_SOC_TLB1_10_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_10_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_10_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_10_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_10_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_10_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_10_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_10_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_10_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_10_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_10_MASK \
      (MP0_SYSHUB_SOC_TLB1_10_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_10_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_10_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_10_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_10_GET_COHERENCE(mp0_syshub_soc_tlb1_10) \
      ((mp0_syshub_soc_tlb1_10 & MP0_SYSHUB_SOC_TLB1_10_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_10_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_10_GET_SEG_SIZE(mp0_syshub_soc_tlb1_10) \
      ((mp0_syshub_soc_tlb1_10 & MP0_SYSHUB_SOC_TLB1_10_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_10_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_10_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_10) \
      ((mp0_syshub_soc_tlb1_10 & MP0_SYSHUB_SOC_TLB1_10_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_10_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_10_SET_COHERENCE(mp0_syshub_soc_tlb1_10_reg, coherence) \
      mp0_syshub_soc_tlb1_10_reg = (mp0_syshub_soc_tlb1_10_reg & ~MP0_SYSHUB_SOC_TLB1_10_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_10_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_10_SET_SEG_SIZE(mp0_syshub_soc_tlb1_10_reg, seg_size) \
      mp0_syshub_soc_tlb1_10_reg = (mp0_syshub_soc_tlb1_10_reg & ~MP0_SYSHUB_SOC_TLB1_10_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_10_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_10_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_10_reg, seg_offset) \
      mp0_syshub_soc_tlb1_10_reg = (mp0_syshub_soc_tlb1_10_reg & ~MP0_SYSHUB_SOC_TLB1_10_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_10_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_10_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_10_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_10_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_10_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_10_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_10_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_10_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_10_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_10_t f;
} mp0_syshub_soc_tlb1_10_u;


/*
 * MP0_SYSHUB_SOC_TLB2_10 struct
 */

#define MP0_SYSHUB_SOC_TLB2_10_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_10_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_10_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_10_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_10_MASK \
      (MP0_SYSHUB_SOC_TLB2_10_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_10_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_10_GET_AWUSER(mp0_syshub_soc_tlb2_10) \
      ((mp0_syshub_soc_tlb2_10 & MP0_SYSHUB_SOC_TLB2_10_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_10_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_10_SET_AWUSER(mp0_syshub_soc_tlb2_10_reg, awuser) \
      mp0_syshub_soc_tlb2_10_reg = (mp0_syshub_soc_tlb2_10_reg & ~MP0_SYSHUB_SOC_TLB2_10_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_10_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_10_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_10_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_10_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_10_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_10_t f;
} mp0_syshub_soc_tlb2_10_u;


/*
 * MP0_SYSHUB_SOC_TLB3_10 struct
 */

#define MP0_SYSHUB_SOC_TLB3_10_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_10_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_10_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_10_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_10_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_10_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_10_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_10_MASK \
      (MP0_SYSHUB_SOC_TLB3_10_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_10_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_10_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_10_GET_ARUSER(mp0_syshub_soc_tlb3_10) \
      ((mp0_syshub_soc_tlb3_10 & MP0_SYSHUB_SOC_TLB3_10_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_10_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_10_GET_WUSER(mp0_syshub_soc_tlb3_10) \
      ((mp0_syshub_soc_tlb3_10 & MP0_SYSHUB_SOC_TLB3_10_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_10_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_10_SET_ARUSER(mp0_syshub_soc_tlb3_10_reg, aruser) \
      mp0_syshub_soc_tlb3_10_reg = (mp0_syshub_soc_tlb3_10_reg & ~MP0_SYSHUB_SOC_TLB3_10_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_10_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_10_SET_WUSER(mp0_syshub_soc_tlb3_10_reg, wuser) \
      mp0_syshub_soc_tlb3_10_reg = (mp0_syshub_soc_tlb3_10_reg & ~MP0_SYSHUB_SOC_TLB3_10_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_10_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_10_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_10_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_10_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_10_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_10_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_10_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_10_t f;
} mp0_syshub_soc_tlb3_10_u;


/*
 * MP0_SYSHUB_SOC_TLB0_11 struct
 */

#define MP0_SYSHUB_SOC_TLB0_11_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_11_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_11_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_11_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_11_MASK \
      (MP0_SYSHUB_SOC_TLB0_11_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_11_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_11_GET_SOC_ADDR(mp0_syshub_soc_tlb0_11) \
      ((mp0_syshub_soc_tlb0_11 & MP0_SYSHUB_SOC_TLB0_11_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_11_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_11_SET_SOC_ADDR(mp0_syshub_soc_tlb0_11_reg, soc_addr) \
      mp0_syshub_soc_tlb0_11_reg = (mp0_syshub_soc_tlb0_11_reg & ~MP0_SYSHUB_SOC_TLB0_11_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_11_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_11_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_11_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_11_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_11_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_11_t f;
} mp0_syshub_soc_tlb0_11_u;


/*
 * MP0_SYSHUB_SOC_TLB1_11 struct
 */

#define MP0_SYSHUB_SOC_TLB1_11_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_11_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_11_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_11_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_11_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_11_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_11_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_11_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_11_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_11_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_11_MASK \
      (MP0_SYSHUB_SOC_TLB1_11_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_11_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_11_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_11_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_11_GET_COHERENCE(mp0_syshub_soc_tlb1_11) \
      ((mp0_syshub_soc_tlb1_11 & MP0_SYSHUB_SOC_TLB1_11_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_11_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_11_GET_SEG_SIZE(mp0_syshub_soc_tlb1_11) \
      ((mp0_syshub_soc_tlb1_11 & MP0_SYSHUB_SOC_TLB1_11_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_11_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_11_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_11) \
      ((mp0_syshub_soc_tlb1_11 & MP0_SYSHUB_SOC_TLB1_11_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_11_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_11_SET_COHERENCE(mp0_syshub_soc_tlb1_11_reg, coherence) \
      mp0_syshub_soc_tlb1_11_reg = (mp0_syshub_soc_tlb1_11_reg & ~MP0_SYSHUB_SOC_TLB1_11_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_11_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_11_SET_SEG_SIZE(mp0_syshub_soc_tlb1_11_reg, seg_size) \
      mp0_syshub_soc_tlb1_11_reg = (mp0_syshub_soc_tlb1_11_reg & ~MP0_SYSHUB_SOC_TLB1_11_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_11_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_11_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_11_reg, seg_offset) \
      mp0_syshub_soc_tlb1_11_reg = (mp0_syshub_soc_tlb1_11_reg & ~MP0_SYSHUB_SOC_TLB1_11_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_11_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_11_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_11_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_11_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_11_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_11_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_11_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_11_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_11_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_11_t f;
} mp0_syshub_soc_tlb1_11_u;


/*
 * MP0_SYSHUB_SOC_TLB2_11 struct
 */

#define MP0_SYSHUB_SOC_TLB2_11_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_11_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_11_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_11_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_11_MASK \
      (MP0_SYSHUB_SOC_TLB2_11_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_11_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_11_GET_AWUSER(mp0_syshub_soc_tlb2_11) \
      ((mp0_syshub_soc_tlb2_11 & MP0_SYSHUB_SOC_TLB2_11_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_11_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_11_SET_AWUSER(mp0_syshub_soc_tlb2_11_reg, awuser) \
      mp0_syshub_soc_tlb2_11_reg = (mp0_syshub_soc_tlb2_11_reg & ~MP0_SYSHUB_SOC_TLB2_11_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_11_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_11_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_11_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_11_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_11_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_11_t f;
} mp0_syshub_soc_tlb2_11_u;


/*
 * MP0_SYSHUB_SOC_TLB3_11 struct
 */

#define MP0_SYSHUB_SOC_TLB3_11_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_11_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_11_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_11_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_11_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_11_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_11_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_11_MASK \
      (MP0_SYSHUB_SOC_TLB3_11_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_11_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_11_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_11_GET_ARUSER(mp0_syshub_soc_tlb3_11) \
      ((mp0_syshub_soc_tlb3_11 & MP0_SYSHUB_SOC_TLB3_11_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_11_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_11_GET_WUSER(mp0_syshub_soc_tlb3_11) \
      ((mp0_syshub_soc_tlb3_11 & MP0_SYSHUB_SOC_TLB3_11_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_11_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_11_SET_ARUSER(mp0_syshub_soc_tlb3_11_reg, aruser) \
      mp0_syshub_soc_tlb3_11_reg = (mp0_syshub_soc_tlb3_11_reg & ~MP0_SYSHUB_SOC_TLB3_11_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_11_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_11_SET_WUSER(mp0_syshub_soc_tlb3_11_reg, wuser) \
      mp0_syshub_soc_tlb3_11_reg = (mp0_syshub_soc_tlb3_11_reg & ~MP0_SYSHUB_SOC_TLB3_11_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_11_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_11_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_11_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_11_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_11_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_11_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_11_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_11_t f;
} mp0_syshub_soc_tlb3_11_u;


/*
 * MP0_SYSHUB_SOC_TLB0_12 struct
 */

#define MP0_SYSHUB_SOC_TLB0_12_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_12_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_12_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_12_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_12_MASK \
      (MP0_SYSHUB_SOC_TLB0_12_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_12_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_12_GET_SOC_ADDR(mp0_syshub_soc_tlb0_12) \
      ((mp0_syshub_soc_tlb0_12 & MP0_SYSHUB_SOC_TLB0_12_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_12_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_12_SET_SOC_ADDR(mp0_syshub_soc_tlb0_12_reg, soc_addr) \
      mp0_syshub_soc_tlb0_12_reg = (mp0_syshub_soc_tlb0_12_reg & ~MP0_SYSHUB_SOC_TLB0_12_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_12_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_12_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_12_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_12_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_12_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_12_t f;
} mp0_syshub_soc_tlb0_12_u;


/*
 * MP0_SYSHUB_SOC_TLB1_12 struct
 */

#define MP0_SYSHUB_SOC_TLB1_12_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_12_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_12_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_12_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_12_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_12_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_12_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_12_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_12_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_12_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_12_MASK \
      (MP0_SYSHUB_SOC_TLB1_12_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_12_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_12_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_12_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_12_GET_COHERENCE(mp0_syshub_soc_tlb1_12) \
      ((mp0_syshub_soc_tlb1_12 & MP0_SYSHUB_SOC_TLB1_12_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_12_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_12_GET_SEG_SIZE(mp0_syshub_soc_tlb1_12) \
      ((mp0_syshub_soc_tlb1_12 & MP0_SYSHUB_SOC_TLB1_12_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_12_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_12_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_12) \
      ((mp0_syshub_soc_tlb1_12 & MP0_SYSHUB_SOC_TLB1_12_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_12_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_12_SET_COHERENCE(mp0_syshub_soc_tlb1_12_reg, coherence) \
      mp0_syshub_soc_tlb1_12_reg = (mp0_syshub_soc_tlb1_12_reg & ~MP0_SYSHUB_SOC_TLB1_12_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_12_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_12_SET_SEG_SIZE(mp0_syshub_soc_tlb1_12_reg, seg_size) \
      mp0_syshub_soc_tlb1_12_reg = (mp0_syshub_soc_tlb1_12_reg & ~MP0_SYSHUB_SOC_TLB1_12_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_12_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_12_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_12_reg, seg_offset) \
      mp0_syshub_soc_tlb1_12_reg = (mp0_syshub_soc_tlb1_12_reg & ~MP0_SYSHUB_SOC_TLB1_12_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_12_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_12_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_12_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_12_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_12_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_12_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_12_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_12_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_12_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_12_t f;
} mp0_syshub_soc_tlb1_12_u;


/*
 * MP0_SYSHUB_SOC_TLB2_12 struct
 */

#define MP0_SYSHUB_SOC_TLB2_12_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_12_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_12_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_12_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_12_MASK \
      (MP0_SYSHUB_SOC_TLB2_12_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_12_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_12_GET_AWUSER(mp0_syshub_soc_tlb2_12) \
      ((mp0_syshub_soc_tlb2_12 & MP0_SYSHUB_SOC_TLB2_12_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_12_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_12_SET_AWUSER(mp0_syshub_soc_tlb2_12_reg, awuser) \
      mp0_syshub_soc_tlb2_12_reg = (mp0_syshub_soc_tlb2_12_reg & ~MP0_SYSHUB_SOC_TLB2_12_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_12_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_12_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_12_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_12_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_12_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_12_t f;
} mp0_syshub_soc_tlb2_12_u;


/*
 * MP0_SYSHUB_SOC_TLB3_12 struct
 */

#define MP0_SYSHUB_SOC_TLB3_12_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_12_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_12_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_12_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_12_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_12_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_12_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_12_MASK \
      (MP0_SYSHUB_SOC_TLB3_12_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_12_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_12_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_12_GET_ARUSER(mp0_syshub_soc_tlb3_12) \
      ((mp0_syshub_soc_tlb3_12 & MP0_SYSHUB_SOC_TLB3_12_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_12_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_12_GET_WUSER(mp0_syshub_soc_tlb3_12) \
      ((mp0_syshub_soc_tlb3_12 & MP0_SYSHUB_SOC_TLB3_12_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_12_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_12_SET_ARUSER(mp0_syshub_soc_tlb3_12_reg, aruser) \
      mp0_syshub_soc_tlb3_12_reg = (mp0_syshub_soc_tlb3_12_reg & ~MP0_SYSHUB_SOC_TLB3_12_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_12_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_12_SET_WUSER(mp0_syshub_soc_tlb3_12_reg, wuser) \
      mp0_syshub_soc_tlb3_12_reg = (mp0_syshub_soc_tlb3_12_reg & ~MP0_SYSHUB_SOC_TLB3_12_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_12_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_12_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_12_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_12_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_12_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_12_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_12_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_12_t f;
} mp0_syshub_soc_tlb3_12_u;


/*
 * MP0_SYSHUB_SOC_TLB0_13 struct
 */

#define MP0_SYSHUB_SOC_TLB0_13_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_13_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_13_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_13_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_13_MASK \
      (MP0_SYSHUB_SOC_TLB0_13_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_13_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_13_GET_SOC_ADDR(mp0_syshub_soc_tlb0_13) \
      ((mp0_syshub_soc_tlb0_13 & MP0_SYSHUB_SOC_TLB0_13_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_13_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_13_SET_SOC_ADDR(mp0_syshub_soc_tlb0_13_reg, soc_addr) \
      mp0_syshub_soc_tlb0_13_reg = (mp0_syshub_soc_tlb0_13_reg & ~MP0_SYSHUB_SOC_TLB0_13_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_13_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_13_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_13_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_13_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_13_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_13_t f;
} mp0_syshub_soc_tlb0_13_u;


/*
 * MP0_SYSHUB_SOC_TLB1_13 struct
 */

#define MP0_SYSHUB_SOC_TLB1_13_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_13_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_13_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_13_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_13_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_13_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_13_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_13_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_13_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_13_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_13_MASK \
      (MP0_SYSHUB_SOC_TLB1_13_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_13_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_13_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_13_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_13_GET_COHERENCE(mp0_syshub_soc_tlb1_13) \
      ((mp0_syshub_soc_tlb1_13 & MP0_SYSHUB_SOC_TLB1_13_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_13_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_13_GET_SEG_SIZE(mp0_syshub_soc_tlb1_13) \
      ((mp0_syshub_soc_tlb1_13 & MP0_SYSHUB_SOC_TLB1_13_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_13_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_13_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_13) \
      ((mp0_syshub_soc_tlb1_13 & MP0_SYSHUB_SOC_TLB1_13_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_13_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_13_SET_COHERENCE(mp0_syshub_soc_tlb1_13_reg, coherence) \
      mp0_syshub_soc_tlb1_13_reg = (mp0_syshub_soc_tlb1_13_reg & ~MP0_SYSHUB_SOC_TLB1_13_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_13_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_13_SET_SEG_SIZE(mp0_syshub_soc_tlb1_13_reg, seg_size) \
      mp0_syshub_soc_tlb1_13_reg = (mp0_syshub_soc_tlb1_13_reg & ~MP0_SYSHUB_SOC_TLB1_13_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_13_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_13_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_13_reg, seg_offset) \
      mp0_syshub_soc_tlb1_13_reg = (mp0_syshub_soc_tlb1_13_reg & ~MP0_SYSHUB_SOC_TLB1_13_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_13_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_13_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_13_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_13_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_13_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_13_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_13_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_13_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_13_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_13_t f;
} mp0_syshub_soc_tlb1_13_u;


/*
 * MP0_SYSHUB_SOC_TLB2_13 struct
 */

#define MP0_SYSHUB_SOC_TLB2_13_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_13_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_13_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_13_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_13_MASK \
      (MP0_SYSHUB_SOC_TLB2_13_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_13_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_13_GET_AWUSER(mp0_syshub_soc_tlb2_13) \
      ((mp0_syshub_soc_tlb2_13 & MP0_SYSHUB_SOC_TLB2_13_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_13_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_13_SET_AWUSER(mp0_syshub_soc_tlb2_13_reg, awuser) \
      mp0_syshub_soc_tlb2_13_reg = (mp0_syshub_soc_tlb2_13_reg & ~MP0_SYSHUB_SOC_TLB2_13_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_13_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_13_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_13_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_13_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_13_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_13_t f;
} mp0_syshub_soc_tlb2_13_u;


/*
 * MP0_SYSHUB_SOC_TLB3_13 struct
 */

#define MP0_SYSHUB_SOC_TLB3_13_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_13_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_13_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_13_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_13_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_13_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_13_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_13_MASK \
      (MP0_SYSHUB_SOC_TLB3_13_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_13_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_13_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_13_GET_ARUSER(mp0_syshub_soc_tlb3_13) \
      ((mp0_syshub_soc_tlb3_13 & MP0_SYSHUB_SOC_TLB3_13_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_13_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_13_GET_WUSER(mp0_syshub_soc_tlb3_13) \
      ((mp0_syshub_soc_tlb3_13 & MP0_SYSHUB_SOC_TLB3_13_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_13_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_13_SET_ARUSER(mp0_syshub_soc_tlb3_13_reg, aruser) \
      mp0_syshub_soc_tlb3_13_reg = (mp0_syshub_soc_tlb3_13_reg & ~MP0_SYSHUB_SOC_TLB3_13_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_13_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_13_SET_WUSER(mp0_syshub_soc_tlb3_13_reg, wuser) \
      mp0_syshub_soc_tlb3_13_reg = (mp0_syshub_soc_tlb3_13_reg & ~MP0_SYSHUB_SOC_TLB3_13_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_13_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_13_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_13_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_13_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_13_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_13_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_13_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_13_t f;
} mp0_syshub_soc_tlb3_13_u;


/*
 * MP0_SYSHUB_SOC_TLB0_14 struct
 */

#define MP0_SYSHUB_SOC_TLB0_14_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_14_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_14_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_14_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_14_MASK \
      (MP0_SYSHUB_SOC_TLB0_14_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_14_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_14_GET_SOC_ADDR(mp0_syshub_soc_tlb0_14) \
      ((mp0_syshub_soc_tlb0_14 & MP0_SYSHUB_SOC_TLB0_14_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_14_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_14_SET_SOC_ADDR(mp0_syshub_soc_tlb0_14_reg, soc_addr) \
      mp0_syshub_soc_tlb0_14_reg = (mp0_syshub_soc_tlb0_14_reg & ~MP0_SYSHUB_SOC_TLB0_14_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_14_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_14_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_14_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_14_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_14_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_14_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_14_t f;
} mp0_syshub_soc_tlb0_14_u;


/*
 * MP0_SYSHUB_SOC_TLB1_14 struct
 */

#define MP0_SYSHUB_SOC_TLB1_14_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_14_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_14_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_14_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_14_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_14_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_14_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_14_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_14_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_14_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_14_MASK \
      (MP0_SYSHUB_SOC_TLB1_14_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_14_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_14_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_14_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_14_GET_COHERENCE(mp0_syshub_soc_tlb1_14) \
      ((mp0_syshub_soc_tlb1_14 & MP0_SYSHUB_SOC_TLB1_14_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_14_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_14_GET_SEG_SIZE(mp0_syshub_soc_tlb1_14) \
      ((mp0_syshub_soc_tlb1_14 & MP0_SYSHUB_SOC_TLB1_14_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_14_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_14_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_14) \
      ((mp0_syshub_soc_tlb1_14 & MP0_SYSHUB_SOC_TLB1_14_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_14_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_14_SET_COHERENCE(mp0_syshub_soc_tlb1_14_reg, coherence) \
      mp0_syshub_soc_tlb1_14_reg = (mp0_syshub_soc_tlb1_14_reg & ~MP0_SYSHUB_SOC_TLB1_14_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_14_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_14_SET_SEG_SIZE(mp0_syshub_soc_tlb1_14_reg, seg_size) \
      mp0_syshub_soc_tlb1_14_reg = (mp0_syshub_soc_tlb1_14_reg & ~MP0_SYSHUB_SOC_TLB1_14_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_14_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_14_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_14_reg, seg_offset) \
      mp0_syshub_soc_tlb1_14_reg = (mp0_syshub_soc_tlb1_14_reg & ~MP0_SYSHUB_SOC_TLB1_14_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_14_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_14_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_14_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_14_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_14_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_14_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_14_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_14_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_14_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_14_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_14_t f;
} mp0_syshub_soc_tlb1_14_u;


/*
 * MP0_SYSHUB_SOC_TLB2_14 struct
 */

#define MP0_SYSHUB_SOC_TLB2_14_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_14_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_14_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_14_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_14_MASK \
      (MP0_SYSHUB_SOC_TLB2_14_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_14_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_14_GET_AWUSER(mp0_syshub_soc_tlb2_14) \
      ((mp0_syshub_soc_tlb2_14 & MP0_SYSHUB_SOC_TLB2_14_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_14_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_14_SET_AWUSER(mp0_syshub_soc_tlb2_14_reg, awuser) \
      mp0_syshub_soc_tlb2_14_reg = (mp0_syshub_soc_tlb2_14_reg & ~MP0_SYSHUB_SOC_TLB2_14_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_14_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_14_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_14_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_14_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_14_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_14_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_14_t f;
} mp0_syshub_soc_tlb2_14_u;


/*
 * MP0_SYSHUB_SOC_TLB3_14 struct
 */

#define MP0_SYSHUB_SOC_TLB3_14_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_14_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_14_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_14_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_14_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_14_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_14_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_14_MASK \
      (MP0_SYSHUB_SOC_TLB3_14_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_14_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_14_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_14_GET_ARUSER(mp0_syshub_soc_tlb3_14) \
      ((mp0_syshub_soc_tlb3_14 & MP0_SYSHUB_SOC_TLB3_14_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_14_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_14_GET_WUSER(mp0_syshub_soc_tlb3_14) \
      ((mp0_syshub_soc_tlb3_14 & MP0_SYSHUB_SOC_TLB3_14_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_14_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_14_SET_ARUSER(mp0_syshub_soc_tlb3_14_reg, aruser) \
      mp0_syshub_soc_tlb3_14_reg = (mp0_syshub_soc_tlb3_14_reg & ~MP0_SYSHUB_SOC_TLB3_14_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_14_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_14_SET_WUSER(mp0_syshub_soc_tlb3_14_reg, wuser) \
      mp0_syshub_soc_tlb3_14_reg = (mp0_syshub_soc_tlb3_14_reg & ~MP0_SYSHUB_SOC_TLB3_14_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_14_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_14_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_14_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_14_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_14_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_14_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_14_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_14_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_14_t f;
} mp0_syshub_soc_tlb3_14_u;


/*
 * MP0_SYSHUB_SOC_TLB0_15 struct
 */

#define MP0_SYSHUB_SOC_TLB0_15_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_15_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_15_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_15_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_15_MASK \
      (MP0_SYSHUB_SOC_TLB0_15_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_15_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_15_GET_SOC_ADDR(mp0_syshub_soc_tlb0_15) \
      ((mp0_syshub_soc_tlb0_15 & MP0_SYSHUB_SOC_TLB0_15_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_15_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_15_SET_SOC_ADDR(mp0_syshub_soc_tlb0_15_reg, soc_addr) \
      mp0_syshub_soc_tlb0_15_reg = (mp0_syshub_soc_tlb0_15_reg & ~MP0_SYSHUB_SOC_TLB0_15_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_15_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_15_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_15_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_15_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_15_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_15_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_15_t f;
} mp0_syshub_soc_tlb0_15_u;


/*
 * MP0_SYSHUB_SOC_TLB1_15 struct
 */

#define MP0_SYSHUB_SOC_TLB1_15_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_15_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_15_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_15_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_15_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_15_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_15_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_15_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_15_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_15_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_15_MASK \
      (MP0_SYSHUB_SOC_TLB1_15_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_15_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_15_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_15_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_15_GET_COHERENCE(mp0_syshub_soc_tlb1_15) \
      ((mp0_syshub_soc_tlb1_15 & MP0_SYSHUB_SOC_TLB1_15_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_15_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_15_GET_SEG_SIZE(mp0_syshub_soc_tlb1_15) \
      ((mp0_syshub_soc_tlb1_15 & MP0_SYSHUB_SOC_TLB1_15_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_15_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_15_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_15) \
      ((mp0_syshub_soc_tlb1_15 & MP0_SYSHUB_SOC_TLB1_15_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_15_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_15_SET_COHERENCE(mp0_syshub_soc_tlb1_15_reg, coherence) \
      mp0_syshub_soc_tlb1_15_reg = (mp0_syshub_soc_tlb1_15_reg & ~MP0_SYSHUB_SOC_TLB1_15_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_15_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_15_SET_SEG_SIZE(mp0_syshub_soc_tlb1_15_reg, seg_size) \
      mp0_syshub_soc_tlb1_15_reg = (mp0_syshub_soc_tlb1_15_reg & ~MP0_SYSHUB_SOC_TLB1_15_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_15_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_15_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_15_reg, seg_offset) \
      mp0_syshub_soc_tlb1_15_reg = (mp0_syshub_soc_tlb1_15_reg & ~MP0_SYSHUB_SOC_TLB1_15_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_15_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_15_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_15_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_15_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_15_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_15_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_15_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_15_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_15_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_15_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_15_t f;
} mp0_syshub_soc_tlb1_15_u;


/*
 * MP0_SYSHUB_SOC_TLB2_15 struct
 */

#define MP0_SYSHUB_SOC_TLB2_15_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_15_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_15_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_15_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_15_MASK \
      (MP0_SYSHUB_SOC_TLB2_15_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_15_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_15_GET_AWUSER(mp0_syshub_soc_tlb2_15) \
      ((mp0_syshub_soc_tlb2_15 & MP0_SYSHUB_SOC_TLB2_15_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_15_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_15_SET_AWUSER(mp0_syshub_soc_tlb2_15_reg, awuser) \
      mp0_syshub_soc_tlb2_15_reg = (mp0_syshub_soc_tlb2_15_reg & ~MP0_SYSHUB_SOC_TLB2_15_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_15_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_15_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_15_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_15_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_15_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_15_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_15_t f;
} mp0_syshub_soc_tlb2_15_u;


/*
 * MP0_SYSHUB_SOC_TLB3_15 struct
 */

#define MP0_SYSHUB_SOC_TLB3_15_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_15_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_15_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_15_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_15_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_15_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_15_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_15_MASK \
      (MP0_SYSHUB_SOC_TLB3_15_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_15_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_15_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_15_GET_ARUSER(mp0_syshub_soc_tlb3_15) \
      ((mp0_syshub_soc_tlb3_15 & MP0_SYSHUB_SOC_TLB3_15_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_15_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_15_GET_WUSER(mp0_syshub_soc_tlb3_15) \
      ((mp0_syshub_soc_tlb3_15 & MP0_SYSHUB_SOC_TLB3_15_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_15_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_15_SET_ARUSER(mp0_syshub_soc_tlb3_15_reg, aruser) \
      mp0_syshub_soc_tlb3_15_reg = (mp0_syshub_soc_tlb3_15_reg & ~MP0_SYSHUB_SOC_TLB3_15_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_15_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_15_SET_WUSER(mp0_syshub_soc_tlb3_15_reg, wuser) \
      mp0_syshub_soc_tlb3_15_reg = (mp0_syshub_soc_tlb3_15_reg & ~MP0_SYSHUB_SOC_TLB3_15_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_15_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_15_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_15_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_15_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_15_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_15_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_15_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_15_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_15_t f;
} mp0_syshub_soc_tlb3_15_u;


/*
 * MP0_SYSHUB_SOC_TLB0_16 struct
 */

#define MP0_SYSHUB_SOC_TLB0_16_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_16_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_16_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_16_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_16_MASK \
      (MP0_SYSHUB_SOC_TLB0_16_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_16_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_16_GET_SOC_ADDR(mp0_syshub_soc_tlb0_16) \
      ((mp0_syshub_soc_tlb0_16 & MP0_SYSHUB_SOC_TLB0_16_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_16_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_16_SET_SOC_ADDR(mp0_syshub_soc_tlb0_16_reg, soc_addr) \
      mp0_syshub_soc_tlb0_16_reg = (mp0_syshub_soc_tlb0_16_reg & ~MP0_SYSHUB_SOC_TLB0_16_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_16_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_16_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_16_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_16_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_16_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_16_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_16_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_16_t f;
} mp0_syshub_soc_tlb0_16_u;


/*
 * MP0_SYSHUB_SOC_TLB1_16 struct
 */

#define MP0_SYSHUB_SOC_TLB1_16_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_16_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_16_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_16_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_16_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_16_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_16_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_16_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_16_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_16_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_16_MASK \
      (MP0_SYSHUB_SOC_TLB1_16_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_16_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_16_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_16_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_16_GET_COHERENCE(mp0_syshub_soc_tlb1_16) \
      ((mp0_syshub_soc_tlb1_16 & MP0_SYSHUB_SOC_TLB1_16_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_16_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_16_GET_SEG_SIZE(mp0_syshub_soc_tlb1_16) \
      ((mp0_syshub_soc_tlb1_16 & MP0_SYSHUB_SOC_TLB1_16_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_16_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_16_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_16) \
      ((mp0_syshub_soc_tlb1_16 & MP0_SYSHUB_SOC_TLB1_16_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_16_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_16_SET_COHERENCE(mp0_syshub_soc_tlb1_16_reg, coherence) \
      mp0_syshub_soc_tlb1_16_reg = (mp0_syshub_soc_tlb1_16_reg & ~MP0_SYSHUB_SOC_TLB1_16_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_16_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_16_SET_SEG_SIZE(mp0_syshub_soc_tlb1_16_reg, seg_size) \
      mp0_syshub_soc_tlb1_16_reg = (mp0_syshub_soc_tlb1_16_reg & ~MP0_SYSHUB_SOC_TLB1_16_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_16_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_16_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_16_reg, seg_offset) \
      mp0_syshub_soc_tlb1_16_reg = (mp0_syshub_soc_tlb1_16_reg & ~MP0_SYSHUB_SOC_TLB1_16_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_16_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_16_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_16_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_16_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_16_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_16_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_16_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_16_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_16_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_16_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_16_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_16_t f;
} mp0_syshub_soc_tlb1_16_u;


/*
 * MP0_SYSHUB_SOC_TLB2_16 struct
 */

#define MP0_SYSHUB_SOC_TLB2_16_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_16_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_16_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_16_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_16_MASK \
      (MP0_SYSHUB_SOC_TLB2_16_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_16_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_16_GET_AWUSER(mp0_syshub_soc_tlb2_16) \
      ((mp0_syshub_soc_tlb2_16 & MP0_SYSHUB_SOC_TLB2_16_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_16_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_16_SET_AWUSER(mp0_syshub_soc_tlb2_16_reg, awuser) \
      mp0_syshub_soc_tlb2_16_reg = (mp0_syshub_soc_tlb2_16_reg & ~MP0_SYSHUB_SOC_TLB2_16_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_16_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_16_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_16_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_16_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_16_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_16_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_16_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_16_t f;
} mp0_syshub_soc_tlb2_16_u;


/*
 * MP0_SYSHUB_SOC_TLB3_16 struct
 */

#define MP0_SYSHUB_SOC_TLB3_16_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_16_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_16_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_16_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_16_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_16_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_16_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_16_MASK \
      (MP0_SYSHUB_SOC_TLB3_16_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_16_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_16_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_16_GET_ARUSER(mp0_syshub_soc_tlb3_16) \
      ((mp0_syshub_soc_tlb3_16 & MP0_SYSHUB_SOC_TLB3_16_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_16_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_16_GET_WUSER(mp0_syshub_soc_tlb3_16) \
      ((mp0_syshub_soc_tlb3_16 & MP0_SYSHUB_SOC_TLB3_16_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_16_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_16_SET_ARUSER(mp0_syshub_soc_tlb3_16_reg, aruser) \
      mp0_syshub_soc_tlb3_16_reg = (mp0_syshub_soc_tlb3_16_reg & ~MP0_SYSHUB_SOC_TLB3_16_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_16_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_16_SET_WUSER(mp0_syshub_soc_tlb3_16_reg, wuser) \
      mp0_syshub_soc_tlb3_16_reg = (mp0_syshub_soc_tlb3_16_reg & ~MP0_SYSHUB_SOC_TLB3_16_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_16_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_16_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_16_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_16_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_16_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_16_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_16_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_16_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_16_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_16_t f;
} mp0_syshub_soc_tlb3_16_u;


/*
 * MP0_SYSHUB_SOC_TLB0_17 struct
 */

#define MP0_SYSHUB_SOC_TLB0_17_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_17_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_17_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_17_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_17_MASK \
      (MP0_SYSHUB_SOC_TLB0_17_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_17_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_17_GET_SOC_ADDR(mp0_syshub_soc_tlb0_17) \
      ((mp0_syshub_soc_tlb0_17 & MP0_SYSHUB_SOC_TLB0_17_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_17_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_17_SET_SOC_ADDR(mp0_syshub_soc_tlb0_17_reg, soc_addr) \
      mp0_syshub_soc_tlb0_17_reg = (mp0_syshub_soc_tlb0_17_reg & ~MP0_SYSHUB_SOC_TLB0_17_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_17_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_17_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_17_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_17_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_17_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_17_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_17_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_17_t f;
} mp0_syshub_soc_tlb0_17_u;


/*
 * MP0_SYSHUB_SOC_TLB1_17 struct
 */

#define MP0_SYSHUB_SOC_TLB1_17_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_17_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_17_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_17_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_17_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_17_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_17_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_17_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_17_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_17_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_17_MASK \
      (MP0_SYSHUB_SOC_TLB1_17_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_17_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_17_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_17_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_17_GET_COHERENCE(mp0_syshub_soc_tlb1_17) \
      ((mp0_syshub_soc_tlb1_17 & MP0_SYSHUB_SOC_TLB1_17_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_17_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_17_GET_SEG_SIZE(mp0_syshub_soc_tlb1_17) \
      ((mp0_syshub_soc_tlb1_17 & MP0_SYSHUB_SOC_TLB1_17_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_17_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_17_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_17) \
      ((mp0_syshub_soc_tlb1_17 & MP0_SYSHUB_SOC_TLB1_17_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_17_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_17_SET_COHERENCE(mp0_syshub_soc_tlb1_17_reg, coherence) \
      mp0_syshub_soc_tlb1_17_reg = (mp0_syshub_soc_tlb1_17_reg & ~MP0_SYSHUB_SOC_TLB1_17_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_17_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_17_SET_SEG_SIZE(mp0_syshub_soc_tlb1_17_reg, seg_size) \
      mp0_syshub_soc_tlb1_17_reg = (mp0_syshub_soc_tlb1_17_reg & ~MP0_SYSHUB_SOC_TLB1_17_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_17_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_17_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_17_reg, seg_offset) \
      mp0_syshub_soc_tlb1_17_reg = (mp0_syshub_soc_tlb1_17_reg & ~MP0_SYSHUB_SOC_TLB1_17_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_17_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_17_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_17_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_17_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_17_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_17_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_17_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_17_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_17_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_17_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_17_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_17_t f;
} mp0_syshub_soc_tlb1_17_u;


/*
 * MP0_SYSHUB_SOC_TLB2_17 struct
 */

#define MP0_SYSHUB_SOC_TLB2_17_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_17_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_17_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_17_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_17_MASK \
      (MP0_SYSHUB_SOC_TLB2_17_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_17_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_17_GET_AWUSER(mp0_syshub_soc_tlb2_17) \
      ((mp0_syshub_soc_tlb2_17 & MP0_SYSHUB_SOC_TLB2_17_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_17_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_17_SET_AWUSER(mp0_syshub_soc_tlb2_17_reg, awuser) \
      mp0_syshub_soc_tlb2_17_reg = (mp0_syshub_soc_tlb2_17_reg & ~MP0_SYSHUB_SOC_TLB2_17_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_17_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_17_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_17_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_17_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_17_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_17_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_17_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_17_t f;
} mp0_syshub_soc_tlb2_17_u;


/*
 * MP0_SYSHUB_SOC_TLB3_17 struct
 */

#define MP0_SYSHUB_SOC_TLB3_17_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_17_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_17_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_17_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_17_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_17_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_17_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_17_MASK \
      (MP0_SYSHUB_SOC_TLB3_17_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_17_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_17_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_17_GET_ARUSER(mp0_syshub_soc_tlb3_17) \
      ((mp0_syshub_soc_tlb3_17 & MP0_SYSHUB_SOC_TLB3_17_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_17_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_17_GET_WUSER(mp0_syshub_soc_tlb3_17) \
      ((mp0_syshub_soc_tlb3_17 & MP0_SYSHUB_SOC_TLB3_17_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_17_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_17_SET_ARUSER(mp0_syshub_soc_tlb3_17_reg, aruser) \
      mp0_syshub_soc_tlb3_17_reg = (mp0_syshub_soc_tlb3_17_reg & ~MP0_SYSHUB_SOC_TLB3_17_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_17_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_17_SET_WUSER(mp0_syshub_soc_tlb3_17_reg, wuser) \
      mp0_syshub_soc_tlb3_17_reg = (mp0_syshub_soc_tlb3_17_reg & ~MP0_SYSHUB_SOC_TLB3_17_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_17_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_17_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_17_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_17_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_17_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_17_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_17_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_17_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_17_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_17_t f;
} mp0_syshub_soc_tlb3_17_u;


/*
 * MP0_SYSHUB_SOC_TLB0_18 struct
 */

#define MP0_SYSHUB_SOC_TLB0_18_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_18_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_18_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_18_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_18_MASK \
      (MP0_SYSHUB_SOC_TLB0_18_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_18_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_18_GET_SOC_ADDR(mp0_syshub_soc_tlb0_18) \
      ((mp0_syshub_soc_tlb0_18 & MP0_SYSHUB_SOC_TLB0_18_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_18_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_18_SET_SOC_ADDR(mp0_syshub_soc_tlb0_18_reg, soc_addr) \
      mp0_syshub_soc_tlb0_18_reg = (mp0_syshub_soc_tlb0_18_reg & ~MP0_SYSHUB_SOC_TLB0_18_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_18_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_18_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_18_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_18_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_18_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_18_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_18_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_18_t f;
} mp0_syshub_soc_tlb0_18_u;


/*
 * MP0_SYSHUB_SOC_TLB1_18 struct
 */

#define MP0_SYSHUB_SOC_TLB1_18_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_18_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_18_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_18_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_18_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_18_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_18_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_18_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_18_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_18_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_18_MASK \
      (MP0_SYSHUB_SOC_TLB1_18_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_18_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_18_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_18_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_18_GET_COHERENCE(mp0_syshub_soc_tlb1_18) \
      ((mp0_syshub_soc_tlb1_18 & MP0_SYSHUB_SOC_TLB1_18_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_18_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_18_GET_SEG_SIZE(mp0_syshub_soc_tlb1_18) \
      ((mp0_syshub_soc_tlb1_18 & MP0_SYSHUB_SOC_TLB1_18_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_18_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_18_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_18) \
      ((mp0_syshub_soc_tlb1_18 & MP0_SYSHUB_SOC_TLB1_18_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_18_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_18_SET_COHERENCE(mp0_syshub_soc_tlb1_18_reg, coherence) \
      mp0_syshub_soc_tlb1_18_reg = (mp0_syshub_soc_tlb1_18_reg & ~MP0_SYSHUB_SOC_TLB1_18_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_18_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_18_SET_SEG_SIZE(mp0_syshub_soc_tlb1_18_reg, seg_size) \
      mp0_syshub_soc_tlb1_18_reg = (mp0_syshub_soc_tlb1_18_reg & ~MP0_SYSHUB_SOC_TLB1_18_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_18_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_18_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_18_reg, seg_offset) \
      mp0_syshub_soc_tlb1_18_reg = (mp0_syshub_soc_tlb1_18_reg & ~MP0_SYSHUB_SOC_TLB1_18_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_18_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_18_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_18_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_18_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_18_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_18_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_18_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_18_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_18_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_18_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_18_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_18_t f;
} mp0_syshub_soc_tlb1_18_u;


/*
 * MP0_SYSHUB_SOC_TLB2_18 struct
 */

#define MP0_SYSHUB_SOC_TLB2_18_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_18_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_18_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_18_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_18_MASK \
      (MP0_SYSHUB_SOC_TLB2_18_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_18_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_18_GET_AWUSER(mp0_syshub_soc_tlb2_18) \
      ((mp0_syshub_soc_tlb2_18 & MP0_SYSHUB_SOC_TLB2_18_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_18_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_18_SET_AWUSER(mp0_syshub_soc_tlb2_18_reg, awuser) \
      mp0_syshub_soc_tlb2_18_reg = (mp0_syshub_soc_tlb2_18_reg & ~MP0_SYSHUB_SOC_TLB2_18_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_18_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_18_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_18_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_18_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_18_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_18_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_18_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_18_t f;
} mp0_syshub_soc_tlb2_18_u;


/*
 * MP0_SYSHUB_SOC_TLB3_18 struct
 */

#define MP0_SYSHUB_SOC_TLB3_18_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_18_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_18_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_18_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_18_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_18_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_18_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_18_MASK \
      (MP0_SYSHUB_SOC_TLB3_18_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_18_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_18_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_18_GET_ARUSER(mp0_syshub_soc_tlb3_18) \
      ((mp0_syshub_soc_tlb3_18 & MP0_SYSHUB_SOC_TLB3_18_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_18_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_18_GET_WUSER(mp0_syshub_soc_tlb3_18) \
      ((mp0_syshub_soc_tlb3_18 & MP0_SYSHUB_SOC_TLB3_18_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_18_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_18_SET_ARUSER(mp0_syshub_soc_tlb3_18_reg, aruser) \
      mp0_syshub_soc_tlb3_18_reg = (mp0_syshub_soc_tlb3_18_reg & ~MP0_SYSHUB_SOC_TLB3_18_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_18_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_18_SET_WUSER(mp0_syshub_soc_tlb3_18_reg, wuser) \
      mp0_syshub_soc_tlb3_18_reg = (mp0_syshub_soc_tlb3_18_reg & ~MP0_SYSHUB_SOC_TLB3_18_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_18_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_18_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_18_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_18_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_18_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_18_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_18_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_18_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_18_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_18_t f;
} mp0_syshub_soc_tlb3_18_u;


/*
 * MP0_SYSHUB_SOC_TLB0_19 struct
 */

#define MP0_SYSHUB_SOC_TLB0_19_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_19_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_19_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_19_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_19_MASK \
      (MP0_SYSHUB_SOC_TLB0_19_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_19_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_19_GET_SOC_ADDR(mp0_syshub_soc_tlb0_19) \
      ((mp0_syshub_soc_tlb0_19 & MP0_SYSHUB_SOC_TLB0_19_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_19_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_19_SET_SOC_ADDR(mp0_syshub_soc_tlb0_19_reg, soc_addr) \
      mp0_syshub_soc_tlb0_19_reg = (mp0_syshub_soc_tlb0_19_reg & ~MP0_SYSHUB_SOC_TLB0_19_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_19_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_19_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_19_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_19_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_19_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_19_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_19_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_19_t f;
} mp0_syshub_soc_tlb0_19_u;


/*
 * MP0_SYSHUB_SOC_TLB1_19 struct
 */

#define MP0_SYSHUB_SOC_TLB1_19_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_19_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_19_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_19_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_19_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_19_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_19_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_19_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_19_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_19_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_19_MASK \
      (MP0_SYSHUB_SOC_TLB1_19_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_19_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_19_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_19_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_19_GET_COHERENCE(mp0_syshub_soc_tlb1_19) \
      ((mp0_syshub_soc_tlb1_19 & MP0_SYSHUB_SOC_TLB1_19_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_19_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_19_GET_SEG_SIZE(mp0_syshub_soc_tlb1_19) \
      ((mp0_syshub_soc_tlb1_19 & MP0_SYSHUB_SOC_TLB1_19_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_19_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_19_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_19) \
      ((mp0_syshub_soc_tlb1_19 & MP0_SYSHUB_SOC_TLB1_19_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_19_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_19_SET_COHERENCE(mp0_syshub_soc_tlb1_19_reg, coherence) \
      mp0_syshub_soc_tlb1_19_reg = (mp0_syshub_soc_tlb1_19_reg & ~MP0_SYSHUB_SOC_TLB1_19_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_19_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_19_SET_SEG_SIZE(mp0_syshub_soc_tlb1_19_reg, seg_size) \
      mp0_syshub_soc_tlb1_19_reg = (mp0_syshub_soc_tlb1_19_reg & ~MP0_SYSHUB_SOC_TLB1_19_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_19_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_19_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_19_reg, seg_offset) \
      mp0_syshub_soc_tlb1_19_reg = (mp0_syshub_soc_tlb1_19_reg & ~MP0_SYSHUB_SOC_TLB1_19_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_19_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_19_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_19_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_19_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_19_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_19_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_19_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_19_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_19_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_19_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_19_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_19_t f;
} mp0_syshub_soc_tlb1_19_u;


/*
 * MP0_SYSHUB_SOC_TLB2_19 struct
 */

#define MP0_SYSHUB_SOC_TLB2_19_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_19_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_19_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_19_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_19_MASK \
      (MP0_SYSHUB_SOC_TLB2_19_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_19_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_19_GET_AWUSER(mp0_syshub_soc_tlb2_19) \
      ((mp0_syshub_soc_tlb2_19 & MP0_SYSHUB_SOC_TLB2_19_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_19_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_19_SET_AWUSER(mp0_syshub_soc_tlb2_19_reg, awuser) \
      mp0_syshub_soc_tlb2_19_reg = (mp0_syshub_soc_tlb2_19_reg & ~MP0_SYSHUB_SOC_TLB2_19_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_19_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_19_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_19_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_19_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_19_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_19_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_19_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_19_t f;
} mp0_syshub_soc_tlb2_19_u;


/*
 * MP0_SYSHUB_SOC_TLB3_19 struct
 */

#define MP0_SYSHUB_SOC_TLB3_19_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_19_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_19_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_19_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_19_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_19_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_19_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_19_MASK \
      (MP0_SYSHUB_SOC_TLB3_19_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_19_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_19_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_19_GET_ARUSER(mp0_syshub_soc_tlb3_19) \
      ((mp0_syshub_soc_tlb3_19 & MP0_SYSHUB_SOC_TLB3_19_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_19_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_19_GET_WUSER(mp0_syshub_soc_tlb3_19) \
      ((mp0_syshub_soc_tlb3_19 & MP0_SYSHUB_SOC_TLB3_19_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_19_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_19_SET_ARUSER(mp0_syshub_soc_tlb3_19_reg, aruser) \
      mp0_syshub_soc_tlb3_19_reg = (mp0_syshub_soc_tlb3_19_reg & ~MP0_SYSHUB_SOC_TLB3_19_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_19_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_19_SET_WUSER(mp0_syshub_soc_tlb3_19_reg, wuser) \
      mp0_syshub_soc_tlb3_19_reg = (mp0_syshub_soc_tlb3_19_reg & ~MP0_SYSHUB_SOC_TLB3_19_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_19_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_19_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_19_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_19_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_19_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_19_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_19_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_19_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_19_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_19_t f;
} mp0_syshub_soc_tlb3_19_u;


/*
 * MP0_SYSHUB_SOC_TLB0_20 struct
 */

#define MP0_SYSHUB_SOC_TLB0_20_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_20_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_20_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_20_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_20_MASK \
      (MP0_SYSHUB_SOC_TLB0_20_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_20_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_20_GET_SOC_ADDR(mp0_syshub_soc_tlb0_20) \
      ((mp0_syshub_soc_tlb0_20 & MP0_SYSHUB_SOC_TLB0_20_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_20_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_20_SET_SOC_ADDR(mp0_syshub_soc_tlb0_20_reg, soc_addr) \
      mp0_syshub_soc_tlb0_20_reg = (mp0_syshub_soc_tlb0_20_reg & ~MP0_SYSHUB_SOC_TLB0_20_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_20_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_20_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_20_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_20_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_20_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_20_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_20_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_20_t f;
} mp0_syshub_soc_tlb0_20_u;


/*
 * MP0_SYSHUB_SOC_TLB1_20 struct
 */

#define MP0_SYSHUB_SOC_TLB1_20_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_20_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_20_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_20_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_20_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_20_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_20_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_20_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_20_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_20_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_20_MASK \
      (MP0_SYSHUB_SOC_TLB1_20_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_20_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_20_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_20_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_20_GET_COHERENCE(mp0_syshub_soc_tlb1_20) \
      ((mp0_syshub_soc_tlb1_20 & MP0_SYSHUB_SOC_TLB1_20_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_20_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_20_GET_SEG_SIZE(mp0_syshub_soc_tlb1_20) \
      ((mp0_syshub_soc_tlb1_20 & MP0_SYSHUB_SOC_TLB1_20_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_20_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_20_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_20) \
      ((mp0_syshub_soc_tlb1_20 & MP0_SYSHUB_SOC_TLB1_20_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_20_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_20_SET_COHERENCE(mp0_syshub_soc_tlb1_20_reg, coherence) \
      mp0_syshub_soc_tlb1_20_reg = (mp0_syshub_soc_tlb1_20_reg & ~MP0_SYSHUB_SOC_TLB1_20_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_20_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_20_SET_SEG_SIZE(mp0_syshub_soc_tlb1_20_reg, seg_size) \
      mp0_syshub_soc_tlb1_20_reg = (mp0_syshub_soc_tlb1_20_reg & ~MP0_SYSHUB_SOC_TLB1_20_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_20_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_20_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_20_reg, seg_offset) \
      mp0_syshub_soc_tlb1_20_reg = (mp0_syshub_soc_tlb1_20_reg & ~MP0_SYSHUB_SOC_TLB1_20_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_20_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_20_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_20_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_20_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_20_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_20_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_20_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_20_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_20_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_20_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_20_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_20_t f;
} mp0_syshub_soc_tlb1_20_u;


/*
 * MP0_SYSHUB_SOC_TLB2_20 struct
 */

#define MP0_SYSHUB_SOC_TLB2_20_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_20_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_20_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_20_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_20_MASK \
      (MP0_SYSHUB_SOC_TLB2_20_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_20_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_20_GET_AWUSER(mp0_syshub_soc_tlb2_20) \
      ((mp0_syshub_soc_tlb2_20 & MP0_SYSHUB_SOC_TLB2_20_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_20_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_20_SET_AWUSER(mp0_syshub_soc_tlb2_20_reg, awuser) \
      mp0_syshub_soc_tlb2_20_reg = (mp0_syshub_soc_tlb2_20_reg & ~MP0_SYSHUB_SOC_TLB2_20_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_20_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_20_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_20_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_20_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_20_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_20_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_20_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_20_t f;
} mp0_syshub_soc_tlb2_20_u;


/*
 * MP0_SYSHUB_SOC_TLB3_20 struct
 */

#define MP0_SYSHUB_SOC_TLB3_20_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_20_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_20_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_20_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_20_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_20_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_20_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_20_MASK \
      (MP0_SYSHUB_SOC_TLB3_20_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_20_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_20_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_20_GET_ARUSER(mp0_syshub_soc_tlb3_20) \
      ((mp0_syshub_soc_tlb3_20 & MP0_SYSHUB_SOC_TLB3_20_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_20_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_20_GET_WUSER(mp0_syshub_soc_tlb3_20) \
      ((mp0_syshub_soc_tlb3_20 & MP0_SYSHUB_SOC_TLB3_20_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_20_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_20_SET_ARUSER(mp0_syshub_soc_tlb3_20_reg, aruser) \
      mp0_syshub_soc_tlb3_20_reg = (mp0_syshub_soc_tlb3_20_reg & ~MP0_SYSHUB_SOC_TLB3_20_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_20_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_20_SET_WUSER(mp0_syshub_soc_tlb3_20_reg, wuser) \
      mp0_syshub_soc_tlb3_20_reg = (mp0_syshub_soc_tlb3_20_reg & ~MP0_SYSHUB_SOC_TLB3_20_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_20_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_20_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_20_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_20_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_20_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_20_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_20_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_20_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_20_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_20_t f;
} mp0_syshub_soc_tlb3_20_u;


/*
 * MP0_SYSHUB_SOC_TLB0_21 struct
 */

#define MP0_SYSHUB_SOC_TLB0_21_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_21_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_21_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_21_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_21_MASK \
      (MP0_SYSHUB_SOC_TLB0_21_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_21_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_21_GET_SOC_ADDR(mp0_syshub_soc_tlb0_21) \
      ((mp0_syshub_soc_tlb0_21 & MP0_SYSHUB_SOC_TLB0_21_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_21_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_21_SET_SOC_ADDR(mp0_syshub_soc_tlb0_21_reg, soc_addr) \
      mp0_syshub_soc_tlb0_21_reg = (mp0_syshub_soc_tlb0_21_reg & ~MP0_SYSHUB_SOC_TLB0_21_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_21_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_21_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_21_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_21_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_21_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_21_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_21_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_21_t f;
} mp0_syshub_soc_tlb0_21_u;


/*
 * MP0_SYSHUB_SOC_TLB1_21 struct
 */

#define MP0_SYSHUB_SOC_TLB1_21_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_21_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_21_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_21_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_21_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_21_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_21_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_21_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_21_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_21_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_21_MASK \
      (MP0_SYSHUB_SOC_TLB1_21_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_21_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_21_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_21_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_21_GET_COHERENCE(mp0_syshub_soc_tlb1_21) \
      ((mp0_syshub_soc_tlb1_21 & MP0_SYSHUB_SOC_TLB1_21_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_21_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_21_GET_SEG_SIZE(mp0_syshub_soc_tlb1_21) \
      ((mp0_syshub_soc_tlb1_21 & MP0_SYSHUB_SOC_TLB1_21_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_21_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_21_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_21) \
      ((mp0_syshub_soc_tlb1_21 & MP0_SYSHUB_SOC_TLB1_21_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_21_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_21_SET_COHERENCE(mp0_syshub_soc_tlb1_21_reg, coherence) \
      mp0_syshub_soc_tlb1_21_reg = (mp0_syshub_soc_tlb1_21_reg & ~MP0_SYSHUB_SOC_TLB1_21_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_21_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_21_SET_SEG_SIZE(mp0_syshub_soc_tlb1_21_reg, seg_size) \
      mp0_syshub_soc_tlb1_21_reg = (mp0_syshub_soc_tlb1_21_reg & ~MP0_SYSHUB_SOC_TLB1_21_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_21_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_21_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_21_reg, seg_offset) \
      mp0_syshub_soc_tlb1_21_reg = (mp0_syshub_soc_tlb1_21_reg & ~MP0_SYSHUB_SOC_TLB1_21_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_21_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_21_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_21_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_21_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_21_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_21_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_21_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_21_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_21_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_21_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_21_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_21_t f;
} mp0_syshub_soc_tlb1_21_u;


/*
 * MP0_SYSHUB_SOC_TLB2_21 struct
 */

#define MP0_SYSHUB_SOC_TLB2_21_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_21_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_21_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_21_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_21_MASK \
      (MP0_SYSHUB_SOC_TLB2_21_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_21_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_21_GET_AWUSER(mp0_syshub_soc_tlb2_21) \
      ((mp0_syshub_soc_tlb2_21 & MP0_SYSHUB_SOC_TLB2_21_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_21_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_21_SET_AWUSER(mp0_syshub_soc_tlb2_21_reg, awuser) \
      mp0_syshub_soc_tlb2_21_reg = (mp0_syshub_soc_tlb2_21_reg & ~MP0_SYSHUB_SOC_TLB2_21_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_21_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_21_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_21_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_21_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_21_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_21_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_21_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_21_t f;
} mp0_syshub_soc_tlb2_21_u;


/*
 * MP0_SYSHUB_SOC_TLB3_21 struct
 */

#define MP0_SYSHUB_SOC_TLB3_21_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_21_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_21_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_21_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_21_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_21_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_21_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_21_MASK \
      (MP0_SYSHUB_SOC_TLB3_21_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_21_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_21_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_21_GET_ARUSER(mp0_syshub_soc_tlb3_21) \
      ((mp0_syshub_soc_tlb3_21 & MP0_SYSHUB_SOC_TLB3_21_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_21_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_21_GET_WUSER(mp0_syshub_soc_tlb3_21) \
      ((mp0_syshub_soc_tlb3_21 & MP0_SYSHUB_SOC_TLB3_21_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_21_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_21_SET_ARUSER(mp0_syshub_soc_tlb3_21_reg, aruser) \
      mp0_syshub_soc_tlb3_21_reg = (mp0_syshub_soc_tlb3_21_reg & ~MP0_SYSHUB_SOC_TLB3_21_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_21_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_21_SET_WUSER(mp0_syshub_soc_tlb3_21_reg, wuser) \
      mp0_syshub_soc_tlb3_21_reg = (mp0_syshub_soc_tlb3_21_reg & ~MP0_SYSHUB_SOC_TLB3_21_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_21_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_21_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_21_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_21_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_21_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_21_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_21_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_21_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_21_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_21_t f;
} mp0_syshub_soc_tlb3_21_u;


/*
 * MP0_SYSHUB_SOC_TLB0_22 struct
 */

#define MP0_SYSHUB_SOC_TLB0_22_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_22_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_22_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_22_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_22_MASK \
      (MP0_SYSHUB_SOC_TLB0_22_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_22_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_22_GET_SOC_ADDR(mp0_syshub_soc_tlb0_22) \
      ((mp0_syshub_soc_tlb0_22 & MP0_SYSHUB_SOC_TLB0_22_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_22_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_22_SET_SOC_ADDR(mp0_syshub_soc_tlb0_22_reg, soc_addr) \
      mp0_syshub_soc_tlb0_22_reg = (mp0_syshub_soc_tlb0_22_reg & ~MP0_SYSHUB_SOC_TLB0_22_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_22_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_22_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_22_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_22_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_22_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_22_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_22_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_22_t f;
} mp0_syshub_soc_tlb0_22_u;


/*
 * MP0_SYSHUB_SOC_TLB1_22 struct
 */

#define MP0_SYSHUB_SOC_TLB1_22_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_22_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_22_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_22_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_22_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_22_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_22_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_22_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_22_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_22_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_22_MASK \
      (MP0_SYSHUB_SOC_TLB1_22_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_22_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_22_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_22_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_22_GET_COHERENCE(mp0_syshub_soc_tlb1_22) \
      ((mp0_syshub_soc_tlb1_22 & MP0_SYSHUB_SOC_TLB1_22_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_22_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_22_GET_SEG_SIZE(mp0_syshub_soc_tlb1_22) \
      ((mp0_syshub_soc_tlb1_22 & MP0_SYSHUB_SOC_TLB1_22_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_22_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_22_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_22) \
      ((mp0_syshub_soc_tlb1_22 & MP0_SYSHUB_SOC_TLB1_22_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_22_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_22_SET_COHERENCE(mp0_syshub_soc_tlb1_22_reg, coherence) \
      mp0_syshub_soc_tlb1_22_reg = (mp0_syshub_soc_tlb1_22_reg & ~MP0_SYSHUB_SOC_TLB1_22_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_22_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_22_SET_SEG_SIZE(mp0_syshub_soc_tlb1_22_reg, seg_size) \
      mp0_syshub_soc_tlb1_22_reg = (mp0_syshub_soc_tlb1_22_reg & ~MP0_SYSHUB_SOC_TLB1_22_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_22_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_22_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_22_reg, seg_offset) \
      mp0_syshub_soc_tlb1_22_reg = (mp0_syshub_soc_tlb1_22_reg & ~MP0_SYSHUB_SOC_TLB1_22_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_22_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_22_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_22_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_22_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_22_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_22_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_22_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_22_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_22_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_22_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_22_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_22_t f;
} mp0_syshub_soc_tlb1_22_u;


/*
 * MP0_SYSHUB_SOC_TLB2_22 struct
 */

#define MP0_SYSHUB_SOC_TLB2_22_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_22_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_22_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_22_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_22_MASK \
      (MP0_SYSHUB_SOC_TLB2_22_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_22_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_22_GET_AWUSER(mp0_syshub_soc_tlb2_22) \
      ((mp0_syshub_soc_tlb2_22 & MP0_SYSHUB_SOC_TLB2_22_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_22_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_22_SET_AWUSER(mp0_syshub_soc_tlb2_22_reg, awuser) \
      mp0_syshub_soc_tlb2_22_reg = (mp0_syshub_soc_tlb2_22_reg & ~MP0_SYSHUB_SOC_TLB2_22_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_22_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_22_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_22_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_22_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_22_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_22_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_22_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_22_t f;
} mp0_syshub_soc_tlb2_22_u;


/*
 * MP0_SYSHUB_SOC_TLB3_22 struct
 */

#define MP0_SYSHUB_SOC_TLB3_22_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_22_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_22_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_22_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_22_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_22_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_22_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_22_MASK \
      (MP0_SYSHUB_SOC_TLB3_22_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_22_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_22_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_22_GET_ARUSER(mp0_syshub_soc_tlb3_22) \
      ((mp0_syshub_soc_tlb3_22 & MP0_SYSHUB_SOC_TLB3_22_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_22_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_22_GET_WUSER(mp0_syshub_soc_tlb3_22) \
      ((mp0_syshub_soc_tlb3_22 & MP0_SYSHUB_SOC_TLB3_22_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_22_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_22_SET_ARUSER(mp0_syshub_soc_tlb3_22_reg, aruser) \
      mp0_syshub_soc_tlb3_22_reg = (mp0_syshub_soc_tlb3_22_reg & ~MP0_SYSHUB_SOC_TLB3_22_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_22_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_22_SET_WUSER(mp0_syshub_soc_tlb3_22_reg, wuser) \
      mp0_syshub_soc_tlb3_22_reg = (mp0_syshub_soc_tlb3_22_reg & ~MP0_SYSHUB_SOC_TLB3_22_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_22_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_22_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_22_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_22_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_22_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_22_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_22_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_22_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_22_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_22_t f;
} mp0_syshub_soc_tlb3_22_u;


/*
 * MP0_SYSHUB_SOC_TLB0_23 struct
 */

#define MP0_SYSHUB_SOC_TLB0_23_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_23_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_23_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_23_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_23_MASK \
      (MP0_SYSHUB_SOC_TLB0_23_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_23_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_23_GET_SOC_ADDR(mp0_syshub_soc_tlb0_23) \
      ((mp0_syshub_soc_tlb0_23 & MP0_SYSHUB_SOC_TLB0_23_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_23_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_23_SET_SOC_ADDR(mp0_syshub_soc_tlb0_23_reg, soc_addr) \
      mp0_syshub_soc_tlb0_23_reg = (mp0_syshub_soc_tlb0_23_reg & ~MP0_SYSHUB_SOC_TLB0_23_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_23_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_23_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_23_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_23_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_23_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_23_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_23_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_23_t f;
} mp0_syshub_soc_tlb0_23_u;


/*
 * MP0_SYSHUB_SOC_TLB1_23 struct
 */

#define MP0_SYSHUB_SOC_TLB1_23_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_23_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_23_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_23_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_23_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_23_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_23_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_23_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_23_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_23_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_23_MASK \
      (MP0_SYSHUB_SOC_TLB1_23_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_23_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_23_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_23_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_23_GET_COHERENCE(mp0_syshub_soc_tlb1_23) \
      ((mp0_syshub_soc_tlb1_23 & MP0_SYSHUB_SOC_TLB1_23_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_23_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_23_GET_SEG_SIZE(mp0_syshub_soc_tlb1_23) \
      ((mp0_syshub_soc_tlb1_23 & MP0_SYSHUB_SOC_TLB1_23_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_23_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_23_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_23) \
      ((mp0_syshub_soc_tlb1_23 & MP0_SYSHUB_SOC_TLB1_23_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_23_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_23_SET_COHERENCE(mp0_syshub_soc_tlb1_23_reg, coherence) \
      mp0_syshub_soc_tlb1_23_reg = (mp0_syshub_soc_tlb1_23_reg & ~MP0_SYSHUB_SOC_TLB1_23_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_23_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_23_SET_SEG_SIZE(mp0_syshub_soc_tlb1_23_reg, seg_size) \
      mp0_syshub_soc_tlb1_23_reg = (mp0_syshub_soc_tlb1_23_reg & ~MP0_SYSHUB_SOC_TLB1_23_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_23_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_23_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_23_reg, seg_offset) \
      mp0_syshub_soc_tlb1_23_reg = (mp0_syshub_soc_tlb1_23_reg & ~MP0_SYSHUB_SOC_TLB1_23_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_23_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_23_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_23_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_23_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_23_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_23_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_23_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_23_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_23_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_23_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_23_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_23_t f;
} mp0_syshub_soc_tlb1_23_u;


/*
 * MP0_SYSHUB_SOC_TLB2_23 struct
 */

#define MP0_SYSHUB_SOC_TLB2_23_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_23_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_23_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_23_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_23_MASK \
      (MP0_SYSHUB_SOC_TLB2_23_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_23_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_23_GET_AWUSER(mp0_syshub_soc_tlb2_23) \
      ((mp0_syshub_soc_tlb2_23 & MP0_SYSHUB_SOC_TLB2_23_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_23_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_23_SET_AWUSER(mp0_syshub_soc_tlb2_23_reg, awuser) \
      mp0_syshub_soc_tlb2_23_reg = (mp0_syshub_soc_tlb2_23_reg & ~MP0_SYSHUB_SOC_TLB2_23_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_23_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_23_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_23_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_23_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_23_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_23_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_23_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_23_t f;
} mp0_syshub_soc_tlb2_23_u;


/*
 * MP0_SYSHUB_SOC_TLB3_23 struct
 */

#define MP0_SYSHUB_SOC_TLB3_23_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_23_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_23_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_23_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_23_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_23_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_23_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_23_MASK \
      (MP0_SYSHUB_SOC_TLB3_23_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_23_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_23_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_23_GET_ARUSER(mp0_syshub_soc_tlb3_23) \
      ((mp0_syshub_soc_tlb3_23 & MP0_SYSHUB_SOC_TLB3_23_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_23_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_23_GET_WUSER(mp0_syshub_soc_tlb3_23) \
      ((mp0_syshub_soc_tlb3_23 & MP0_SYSHUB_SOC_TLB3_23_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_23_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_23_SET_ARUSER(mp0_syshub_soc_tlb3_23_reg, aruser) \
      mp0_syshub_soc_tlb3_23_reg = (mp0_syshub_soc_tlb3_23_reg & ~MP0_SYSHUB_SOC_TLB3_23_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_23_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_23_SET_WUSER(mp0_syshub_soc_tlb3_23_reg, wuser) \
      mp0_syshub_soc_tlb3_23_reg = (mp0_syshub_soc_tlb3_23_reg & ~MP0_SYSHUB_SOC_TLB3_23_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_23_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_23_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_23_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_23_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_23_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_23_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_23_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_23_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_23_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_23_t f;
} mp0_syshub_soc_tlb3_23_u;


/*
 * MP0_SYSHUB_SOC_TLB0_24 struct
 */

#define MP0_SYSHUB_SOC_TLB0_24_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_24_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_24_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_24_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_24_MASK \
      (MP0_SYSHUB_SOC_TLB0_24_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_24_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_24_GET_SOC_ADDR(mp0_syshub_soc_tlb0_24) \
      ((mp0_syshub_soc_tlb0_24 & MP0_SYSHUB_SOC_TLB0_24_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_24_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_24_SET_SOC_ADDR(mp0_syshub_soc_tlb0_24_reg, soc_addr) \
      mp0_syshub_soc_tlb0_24_reg = (mp0_syshub_soc_tlb0_24_reg & ~MP0_SYSHUB_SOC_TLB0_24_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_24_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_24_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_24_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_24_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_24_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_24_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_24_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_24_t f;
} mp0_syshub_soc_tlb0_24_u;


/*
 * MP0_SYSHUB_SOC_TLB1_24 struct
 */

#define MP0_SYSHUB_SOC_TLB1_24_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_24_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_24_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_24_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_24_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_24_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_24_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_24_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_24_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_24_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_24_MASK \
      (MP0_SYSHUB_SOC_TLB1_24_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_24_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_24_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_24_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_24_GET_COHERENCE(mp0_syshub_soc_tlb1_24) \
      ((mp0_syshub_soc_tlb1_24 & MP0_SYSHUB_SOC_TLB1_24_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_24_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_24_GET_SEG_SIZE(mp0_syshub_soc_tlb1_24) \
      ((mp0_syshub_soc_tlb1_24 & MP0_SYSHUB_SOC_TLB1_24_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_24_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_24_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_24) \
      ((mp0_syshub_soc_tlb1_24 & MP0_SYSHUB_SOC_TLB1_24_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_24_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_24_SET_COHERENCE(mp0_syshub_soc_tlb1_24_reg, coherence) \
      mp0_syshub_soc_tlb1_24_reg = (mp0_syshub_soc_tlb1_24_reg & ~MP0_SYSHUB_SOC_TLB1_24_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_24_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_24_SET_SEG_SIZE(mp0_syshub_soc_tlb1_24_reg, seg_size) \
      mp0_syshub_soc_tlb1_24_reg = (mp0_syshub_soc_tlb1_24_reg & ~MP0_SYSHUB_SOC_TLB1_24_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_24_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_24_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_24_reg, seg_offset) \
      mp0_syshub_soc_tlb1_24_reg = (mp0_syshub_soc_tlb1_24_reg & ~MP0_SYSHUB_SOC_TLB1_24_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_24_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_24_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_24_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_24_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_24_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_24_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_24_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_24_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_24_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_24_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_24_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_24_t f;
} mp0_syshub_soc_tlb1_24_u;


/*
 * MP0_SYSHUB_SOC_TLB2_24 struct
 */

#define MP0_SYSHUB_SOC_TLB2_24_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_24_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_24_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_24_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_24_MASK \
      (MP0_SYSHUB_SOC_TLB2_24_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_24_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_24_GET_AWUSER(mp0_syshub_soc_tlb2_24) \
      ((mp0_syshub_soc_tlb2_24 & MP0_SYSHUB_SOC_TLB2_24_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_24_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_24_SET_AWUSER(mp0_syshub_soc_tlb2_24_reg, awuser) \
      mp0_syshub_soc_tlb2_24_reg = (mp0_syshub_soc_tlb2_24_reg & ~MP0_SYSHUB_SOC_TLB2_24_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_24_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_24_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_24_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_24_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_24_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_24_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_24_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_24_t f;
} mp0_syshub_soc_tlb2_24_u;


/*
 * MP0_SYSHUB_SOC_TLB3_24 struct
 */

#define MP0_SYSHUB_SOC_TLB3_24_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_24_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_24_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_24_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_24_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_24_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_24_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_24_MASK \
      (MP0_SYSHUB_SOC_TLB3_24_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_24_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_24_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_24_GET_ARUSER(mp0_syshub_soc_tlb3_24) \
      ((mp0_syshub_soc_tlb3_24 & MP0_SYSHUB_SOC_TLB3_24_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_24_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_24_GET_WUSER(mp0_syshub_soc_tlb3_24) \
      ((mp0_syshub_soc_tlb3_24 & MP0_SYSHUB_SOC_TLB3_24_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_24_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_24_SET_ARUSER(mp0_syshub_soc_tlb3_24_reg, aruser) \
      mp0_syshub_soc_tlb3_24_reg = (mp0_syshub_soc_tlb3_24_reg & ~MP0_SYSHUB_SOC_TLB3_24_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_24_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_24_SET_WUSER(mp0_syshub_soc_tlb3_24_reg, wuser) \
      mp0_syshub_soc_tlb3_24_reg = (mp0_syshub_soc_tlb3_24_reg & ~MP0_SYSHUB_SOC_TLB3_24_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_24_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_24_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_24_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_24_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_24_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_24_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_24_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_24_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_24_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_24_t f;
} mp0_syshub_soc_tlb3_24_u;


/*
 * MP0_SYSHUB_SOC_TLB0_25 struct
 */

#define MP0_SYSHUB_SOC_TLB0_25_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_25_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_25_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_25_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_25_MASK \
      (MP0_SYSHUB_SOC_TLB0_25_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_25_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_25_GET_SOC_ADDR(mp0_syshub_soc_tlb0_25) \
      ((mp0_syshub_soc_tlb0_25 & MP0_SYSHUB_SOC_TLB0_25_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_25_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_25_SET_SOC_ADDR(mp0_syshub_soc_tlb0_25_reg, soc_addr) \
      mp0_syshub_soc_tlb0_25_reg = (mp0_syshub_soc_tlb0_25_reg & ~MP0_SYSHUB_SOC_TLB0_25_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_25_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_25_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_25_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_25_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_25_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_25_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_25_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_25_t f;
} mp0_syshub_soc_tlb0_25_u;


/*
 * MP0_SYSHUB_SOC_TLB1_25 struct
 */

#define MP0_SYSHUB_SOC_TLB1_25_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_25_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_25_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_25_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_25_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_25_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_25_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_25_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_25_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_25_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_25_MASK \
      (MP0_SYSHUB_SOC_TLB1_25_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_25_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_25_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_25_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_25_GET_COHERENCE(mp0_syshub_soc_tlb1_25) \
      ((mp0_syshub_soc_tlb1_25 & MP0_SYSHUB_SOC_TLB1_25_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_25_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_25_GET_SEG_SIZE(mp0_syshub_soc_tlb1_25) \
      ((mp0_syshub_soc_tlb1_25 & MP0_SYSHUB_SOC_TLB1_25_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_25_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_25_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_25) \
      ((mp0_syshub_soc_tlb1_25 & MP0_SYSHUB_SOC_TLB1_25_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_25_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_25_SET_COHERENCE(mp0_syshub_soc_tlb1_25_reg, coherence) \
      mp0_syshub_soc_tlb1_25_reg = (mp0_syshub_soc_tlb1_25_reg & ~MP0_SYSHUB_SOC_TLB1_25_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_25_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_25_SET_SEG_SIZE(mp0_syshub_soc_tlb1_25_reg, seg_size) \
      mp0_syshub_soc_tlb1_25_reg = (mp0_syshub_soc_tlb1_25_reg & ~MP0_SYSHUB_SOC_TLB1_25_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_25_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_25_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_25_reg, seg_offset) \
      mp0_syshub_soc_tlb1_25_reg = (mp0_syshub_soc_tlb1_25_reg & ~MP0_SYSHUB_SOC_TLB1_25_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_25_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_25_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_25_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_25_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_25_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_25_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_25_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_25_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_25_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_25_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_25_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_25_t f;
} mp0_syshub_soc_tlb1_25_u;


/*
 * MP0_SYSHUB_SOC_TLB2_25 struct
 */

#define MP0_SYSHUB_SOC_TLB2_25_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_25_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_25_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_25_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_25_MASK \
      (MP0_SYSHUB_SOC_TLB2_25_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_25_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_25_GET_AWUSER(mp0_syshub_soc_tlb2_25) \
      ((mp0_syshub_soc_tlb2_25 & MP0_SYSHUB_SOC_TLB2_25_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_25_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_25_SET_AWUSER(mp0_syshub_soc_tlb2_25_reg, awuser) \
      mp0_syshub_soc_tlb2_25_reg = (mp0_syshub_soc_tlb2_25_reg & ~MP0_SYSHUB_SOC_TLB2_25_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_25_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_25_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_25_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_25_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_25_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_25_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_25_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_25_t f;
} mp0_syshub_soc_tlb2_25_u;


/*
 * MP0_SYSHUB_SOC_TLB3_25 struct
 */

#define MP0_SYSHUB_SOC_TLB3_25_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_25_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_25_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_25_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_25_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_25_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_25_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_25_MASK \
      (MP0_SYSHUB_SOC_TLB3_25_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_25_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_25_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_25_GET_ARUSER(mp0_syshub_soc_tlb3_25) \
      ((mp0_syshub_soc_tlb3_25 & MP0_SYSHUB_SOC_TLB3_25_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_25_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_25_GET_WUSER(mp0_syshub_soc_tlb3_25) \
      ((mp0_syshub_soc_tlb3_25 & MP0_SYSHUB_SOC_TLB3_25_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_25_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_25_SET_ARUSER(mp0_syshub_soc_tlb3_25_reg, aruser) \
      mp0_syshub_soc_tlb3_25_reg = (mp0_syshub_soc_tlb3_25_reg & ~MP0_SYSHUB_SOC_TLB3_25_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_25_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_25_SET_WUSER(mp0_syshub_soc_tlb3_25_reg, wuser) \
      mp0_syshub_soc_tlb3_25_reg = (mp0_syshub_soc_tlb3_25_reg & ~MP0_SYSHUB_SOC_TLB3_25_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_25_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_25_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_25_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_25_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_25_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_25_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_25_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_25_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_25_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_25_t f;
} mp0_syshub_soc_tlb3_25_u;


/*
 * MP0_SYSHUB_SOC_TLB0_26 struct
 */

#define MP0_SYSHUB_SOC_TLB0_26_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_26_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_26_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_26_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_26_MASK \
      (MP0_SYSHUB_SOC_TLB0_26_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_26_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_26_GET_SOC_ADDR(mp0_syshub_soc_tlb0_26) \
      ((mp0_syshub_soc_tlb0_26 & MP0_SYSHUB_SOC_TLB0_26_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_26_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_26_SET_SOC_ADDR(mp0_syshub_soc_tlb0_26_reg, soc_addr) \
      mp0_syshub_soc_tlb0_26_reg = (mp0_syshub_soc_tlb0_26_reg & ~MP0_SYSHUB_SOC_TLB0_26_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_26_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_26_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_26_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_26_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_26_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_26_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_26_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_26_t f;
} mp0_syshub_soc_tlb0_26_u;


/*
 * MP0_SYSHUB_SOC_TLB1_26 struct
 */

#define MP0_SYSHUB_SOC_TLB1_26_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_26_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_26_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_26_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_26_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_26_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_26_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_26_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_26_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_26_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_26_MASK \
      (MP0_SYSHUB_SOC_TLB1_26_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_26_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_26_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_26_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_26_GET_COHERENCE(mp0_syshub_soc_tlb1_26) \
      ((mp0_syshub_soc_tlb1_26 & MP0_SYSHUB_SOC_TLB1_26_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_26_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_26_GET_SEG_SIZE(mp0_syshub_soc_tlb1_26) \
      ((mp0_syshub_soc_tlb1_26 & MP0_SYSHUB_SOC_TLB1_26_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_26_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_26_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_26) \
      ((mp0_syshub_soc_tlb1_26 & MP0_SYSHUB_SOC_TLB1_26_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_26_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_26_SET_COHERENCE(mp0_syshub_soc_tlb1_26_reg, coherence) \
      mp0_syshub_soc_tlb1_26_reg = (mp0_syshub_soc_tlb1_26_reg & ~MP0_SYSHUB_SOC_TLB1_26_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_26_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_26_SET_SEG_SIZE(mp0_syshub_soc_tlb1_26_reg, seg_size) \
      mp0_syshub_soc_tlb1_26_reg = (mp0_syshub_soc_tlb1_26_reg & ~MP0_SYSHUB_SOC_TLB1_26_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_26_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_26_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_26_reg, seg_offset) \
      mp0_syshub_soc_tlb1_26_reg = (mp0_syshub_soc_tlb1_26_reg & ~MP0_SYSHUB_SOC_TLB1_26_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_26_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_26_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_26_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_26_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_26_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_26_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_26_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_26_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_26_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_26_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_26_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_26_t f;
} mp0_syshub_soc_tlb1_26_u;


/*
 * MP0_SYSHUB_SOC_TLB2_26 struct
 */

#define MP0_SYSHUB_SOC_TLB2_26_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_26_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_26_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_26_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_26_MASK \
      (MP0_SYSHUB_SOC_TLB2_26_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_26_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_26_GET_AWUSER(mp0_syshub_soc_tlb2_26) \
      ((mp0_syshub_soc_tlb2_26 & MP0_SYSHUB_SOC_TLB2_26_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_26_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_26_SET_AWUSER(mp0_syshub_soc_tlb2_26_reg, awuser) \
      mp0_syshub_soc_tlb2_26_reg = (mp0_syshub_soc_tlb2_26_reg & ~MP0_SYSHUB_SOC_TLB2_26_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_26_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_26_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_26_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_26_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_26_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_26_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_26_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_26_t f;
} mp0_syshub_soc_tlb2_26_u;


/*
 * MP0_SYSHUB_SOC_TLB3_26 struct
 */

#define MP0_SYSHUB_SOC_TLB3_26_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_26_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_26_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_26_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_26_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_26_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_26_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_26_MASK \
      (MP0_SYSHUB_SOC_TLB3_26_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_26_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_26_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_26_GET_ARUSER(mp0_syshub_soc_tlb3_26) \
      ((mp0_syshub_soc_tlb3_26 & MP0_SYSHUB_SOC_TLB3_26_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_26_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_26_GET_WUSER(mp0_syshub_soc_tlb3_26) \
      ((mp0_syshub_soc_tlb3_26 & MP0_SYSHUB_SOC_TLB3_26_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_26_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_26_SET_ARUSER(mp0_syshub_soc_tlb3_26_reg, aruser) \
      mp0_syshub_soc_tlb3_26_reg = (mp0_syshub_soc_tlb3_26_reg & ~MP0_SYSHUB_SOC_TLB3_26_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_26_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_26_SET_WUSER(mp0_syshub_soc_tlb3_26_reg, wuser) \
      mp0_syshub_soc_tlb3_26_reg = (mp0_syshub_soc_tlb3_26_reg & ~MP0_SYSHUB_SOC_TLB3_26_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_26_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_26_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_26_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_26_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_26_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_26_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_26_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_26_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_26_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_26_t f;
} mp0_syshub_soc_tlb3_26_u;


/*
 * MP0_SYSHUB_SOC_TLB0_27 struct
 */

#define MP0_SYSHUB_SOC_TLB0_27_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_27_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_27_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_27_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_27_MASK \
      (MP0_SYSHUB_SOC_TLB0_27_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_27_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_27_GET_SOC_ADDR(mp0_syshub_soc_tlb0_27) \
      ((mp0_syshub_soc_tlb0_27 & MP0_SYSHUB_SOC_TLB0_27_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_27_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_27_SET_SOC_ADDR(mp0_syshub_soc_tlb0_27_reg, soc_addr) \
      mp0_syshub_soc_tlb0_27_reg = (mp0_syshub_soc_tlb0_27_reg & ~MP0_SYSHUB_SOC_TLB0_27_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_27_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_27_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_27_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_27_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_27_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_27_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_27_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_27_t f;
} mp0_syshub_soc_tlb0_27_u;


/*
 * MP0_SYSHUB_SOC_TLB1_27 struct
 */

#define MP0_SYSHUB_SOC_TLB1_27_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_27_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_27_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_27_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_27_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_27_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_27_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_27_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_27_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_27_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_27_MASK \
      (MP0_SYSHUB_SOC_TLB1_27_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_27_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_27_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_27_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_27_GET_COHERENCE(mp0_syshub_soc_tlb1_27) \
      ((mp0_syshub_soc_tlb1_27 & MP0_SYSHUB_SOC_TLB1_27_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_27_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_27_GET_SEG_SIZE(mp0_syshub_soc_tlb1_27) \
      ((mp0_syshub_soc_tlb1_27 & MP0_SYSHUB_SOC_TLB1_27_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_27_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_27_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_27) \
      ((mp0_syshub_soc_tlb1_27 & MP0_SYSHUB_SOC_TLB1_27_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_27_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_27_SET_COHERENCE(mp0_syshub_soc_tlb1_27_reg, coherence) \
      mp0_syshub_soc_tlb1_27_reg = (mp0_syshub_soc_tlb1_27_reg & ~MP0_SYSHUB_SOC_TLB1_27_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_27_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_27_SET_SEG_SIZE(mp0_syshub_soc_tlb1_27_reg, seg_size) \
      mp0_syshub_soc_tlb1_27_reg = (mp0_syshub_soc_tlb1_27_reg & ~MP0_SYSHUB_SOC_TLB1_27_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_27_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_27_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_27_reg, seg_offset) \
      mp0_syshub_soc_tlb1_27_reg = (mp0_syshub_soc_tlb1_27_reg & ~MP0_SYSHUB_SOC_TLB1_27_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_27_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_27_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_27_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_27_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_27_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_27_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_27_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_27_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_27_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_27_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_27_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_27_t f;
} mp0_syshub_soc_tlb1_27_u;


/*
 * MP0_SYSHUB_SOC_TLB2_27 struct
 */

#define MP0_SYSHUB_SOC_TLB2_27_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_27_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_27_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_27_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_27_MASK \
      (MP0_SYSHUB_SOC_TLB2_27_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_27_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_27_GET_AWUSER(mp0_syshub_soc_tlb2_27) \
      ((mp0_syshub_soc_tlb2_27 & MP0_SYSHUB_SOC_TLB2_27_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_27_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_27_SET_AWUSER(mp0_syshub_soc_tlb2_27_reg, awuser) \
      mp0_syshub_soc_tlb2_27_reg = (mp0_syshub_soc_tlb2_27_reg & ~MP0_SYSHUB_SOC_TLB2_27_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_27_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_27_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_27_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_27_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_27_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_27_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_27_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_27_t f;
} mp0_syshub_soc_tlb2_27_u;


/*
 * MP0_SYSHUB_SOC_TLB3_27 struct
 */

#define MP0_SYSHUB_SOC_TLB3_27_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_27_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_27_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_27_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_27_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_27_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_27_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_27_MASK \
      (MP0_SYSHUB_SOC_TLB3_27_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_27_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_27_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_27_GET_ARUSER(mp0_syshub_soc_tlb3_27) \
      ((mp0_syshub_soc_tlb3_27 & MP0_SYSHUB_SOC_TLB3_27_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_27_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_27_GET_WUSER(mp0_syshub_soc_tlb3_27) \
      ((mp0_syshub_soc_tlb3_27 & MP0_SYSHUB_SOC_TLB3_27_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_27_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_27_SET_ARUSER(mp0_syshub_soc_tlb3_27_reg, aruser) \
      mp0_syshub_soc_tlb3_27_reg = (mp0_syshub_soc_tlb3_27_reg & ~MP0_SYSHUB_SOC_TLB3_27_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_27_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_27_SET_WUSER(mp0_syshub_soc_tlb3_27_reg, wuser) \
      mp0_syshub_soc_tlb3_27_reg = (mp0_syshub_soc_tlb3_27_reg & ~MP0_SYSHUB_SOC_TLB3_27_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_27_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_27_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_27_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_27_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_27_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_27_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_27_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_27_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_27_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_27_t f;
} mp0_syshub_soc_tlb3_27_u;


/*
 * MP0_SYSHUB_SOC_TLB0_28 struct
 */

#define MP0_SYSHUB_SOC_TLB0_28_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_28_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_28_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_28_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_28_MASK \
      (MP0_SYSHUB_SOC_TLB0_28_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_28_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_28_GET_SOC_ADDR(mp0_syshub_soc_tlb0_28) \
      ((mp0_syshub_soc_tlb0_28 & MP0_SYSHUB_SOC_TLB0_28_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_28_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_28_SET_SOC_ADDR(mp0_syshub_soc_tlb0_28_reg, soc_addr) \
      mp0_syshub_soc_tlb0_28_reg = (mp0_syshub_soc_tlb0_28_reg & ~MP0_SYSHUB_SOC_TLB0_28_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_28_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_28_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_28_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_28_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_28_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_28_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_28_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_28_t f;
} mp0_syshub_soc_tlb0_28_u;


/*
 * MP0_SYSHUB_SOC_TLB1_28 struct
 */

#define MP0_SYSHUB_SOC_TLB1_28_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_28_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_28_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_28_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_28_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_28_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_28_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_28_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_28_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_28_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_28_MASK \
      (MP0_SYSHUB_SOC_TLB1_28_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_28_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_28_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_28_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_28_GET_COHERENCE(mp0_syshub_soc_tlb1_28) \
      ((mp0_syshub_soc_tlb1_28 & MP0_SYSHUB_SOC_TLB1_28_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_28_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_28_GET_SEG_SIZE(mp0_syshub_soc_tlb1_28) \
      ((mp0_syshub_soc_tlb1_28 & MP0_SYSHUB_SOC_TLB1_28_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_28_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_28_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_28) \
      ((mp0_syshub_soc_tlb1_28 & MP0_SYSHUB_SOC_TLB1_28_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_28_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_28_SET_COHERENCE(mp0_syshub_soc_tlb1_28_reg, coherence) \
      mp0_syshub_soc_tlb1_28_reg = (mp0_syshub_soc_tlb1_28_reg & ~MP0_SYSHUB_SOC_TLB1_28_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_28_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_28_SET_SEG_SIZE(mp0_syshub_soc_tlb1_28_reg, seg_size) \
      mp0_syshub_soc_tlb1_28_reg = (mp0_syshub_soc_tlb1_28_reg & ~MP0_SYSHUB_SOC_TLB1_28_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_28_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_28_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_28_reg, seg_offset) \
      mp0_syshub_soc_tlb1_28_reg = (mp0_syshub_soc_tlb1_28_reg & ~MP0_SYSHUB_SOC_TLB1_28_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_28_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_28_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_28_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_28_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_28_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_28_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_28_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_28_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_28_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_28_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_28_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_28_t f;
} mp0_syshub_soc_tlb1_28_u;


/*
 * MP0_SYSHUB_SOC_TLB2_28 struct
 */

#define MP0_SYSHUB_SOC_TLB2_28_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_28_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_28_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_28_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_28_MASK \
      (MP0_SYSHUB_SOC_TLB2_28_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_28_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_28_GET_AWUSER(mp0_syshub_soc_tlb2_28) \
      ((mp0_syshub_soc_tlb2_28 & MP0_SYSHUB_SOC_TLB2_28_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_28_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_28_SET_AWUSER(mp0_syshub_soc_tlb2_28_reg, awuser) \
      mp0_syshub_soc_tlb2_28_reg = (mp0_syshub_soc_tlb2_28_reg & ~MP0_SYSHUB_SOC_TLB2_28_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_28_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_28_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_28_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_28_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_28_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_28_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_28_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_28_t f;
} mp0_syshub_soc_tlb2_28_u;


/*
 * MP0_SYSHUB_SOC_TLB3_28 struct
 */

#define MP0_SYSHUB_SOC_TLB3_28_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_28_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_28_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_28_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_28_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_28_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_28_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_28_MASK \
      (MP0_SYSHUB_SOC_TLB3_28_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_28_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_28_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_28_GET_ARUSER(mp0_syshub_soc_tlb3_28) \
      ((mp0_syshub_soc_tlb3_28 & MP0_SYSHUB_SOC_TLB3_28_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_28_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_28_GET_WUSER(mp0_syshub_soc_tlb3_28) \
      ((mp0_syshub_soc_tlb3_28 & MP0_SYSHUB_SOC_TLB3_28_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_28_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_28_SET_ARUSER(mp0_syshub_soc_tlb3_28_reg, aruser) \
      mp0_syshub_soc_tlb3_28_reg = (mp0_syshub_soc_tlb3_28_reg & ~MP0_SYSHUB_SOC_TLB3_28_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_28_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_28_SET_WUSER(mp0_syshub_soc_tlb3_28_reg, wuser) \
      mp0_syshub_soc_tlb3_28_reg = (mp0_syshub_soc_tlb3_28_reg & ~MP0_SYSHUB_SOC_TLB3_28_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_28_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_28_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_28_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_28_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_28_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_28_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_28_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_28_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_28_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_28_t f;
} mp0_syshub_soc_tlb3_28_u;


/*
 * MP0_SYSHUB_SOC_TLB0_29 struct
 */

#define MP0_SYSHUB_SOC_TLB0_29_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_29_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_29_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_29_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_29_MASK \
      (MP0_SYSHUB_SOC_TLB0_29_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_29_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_29_GET_SOC_ADDR(mp0_syshub_soc_tlb0_29) \
      ((mp0_syshub_soc_tlb0_29 & MP0_SYSHUB_SOC_TLB0_29_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_29_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_29_SET_SOC_ADDR(mp0_syshub_soc_tlb0_29_reg, soc_addr) \
      mp0_syshub_soc_tlb0_29_reg = (mp0_syshub_soc_tlb0_29_reg & ~MP0_SYSHUB_SOC_TLB0_29_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_29_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_29_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_29_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_29_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_29_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_29_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_29_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_29_t f;
} mp0_syshub_soc_tlb0_29_u;


/*
 * MP0_SYSHUB_SOC_TLB1_29 struct
 */

#define MP0_SYSHUB_SOC_TLB1_29_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_29_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_29_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_29_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_29_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_29_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_29_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_29_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_29_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_29_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_29_MASK \
      (MP0_SYSHUB_SOC_TLB1_29_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_29_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_29_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_29_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_29_GET_COHERENCE(mp0_syshub_soc_tlb1_29) \
      ((mp0_syshub_soc_tlb1_29 & MP0_SYSHUB_SOC_TLB1_29_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_29_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_29_GET_SEG_SIZE(mp0_syshub_soc_tlb1_29) \
      ((mp0_syshub_soc_tlb1_29 & MP0_SYSHUB_SOC_TLB1_29_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_29_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_29_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_29) \
      ((mp0_syshub_soc_tlb1_29 & MP0_SYSHUB_SOC_TLB1_29_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_29_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_29_SET_COHERENCE(mp0_syshub_soc_tlb1_29_reg, coherence) \
      mp0_syshub_soc_tlb1_29_reg = (mp0_syshub_soc_tlb1_29_reg & ~MP0_SYSHUB_SOC_TLB1_29_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_29_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_29_SET_SEG_SIZE(mp0_syshub_soc_tlb1_29_reg, seg_size) \
      mp0_syshub_soc_tlb1_29_reg = (mp0_syshub_soc_tlb1_29_reg & ~MP0_SYSHUB_SOC_TLB1_29_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_29_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_29_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_29_reg, seg_offset) \
      mp0_syshub_soc_tlb1_29_reg = (mp0_syshub_soc_tlb1_29_reg & ~MP0_SYSHUB_SOC_TLB1_29_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_29_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_29_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_29_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_29_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_29_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_29_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_29_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_29_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_29_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_29_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_29_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_29_t f;
} mp0_syshub_soc_tlb1_29_u;


/*
 * MP0_SYSHUB_SOC_TLB2_29 struct
 */

#define MP0_SYSHUB_SOC_TLB2_29_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_29_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_29_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_29_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_29_MASK \
      (MP0_SYSHUB_SOC_TLB2_29_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_29_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_29_GET_AWUSER(mp0_syshub_soc_tlb2_29) \
      ((mp0_syshub_soc_tlb2_29 & MP0_SYSHUB_SOC_TLB2_29_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_29_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_29_SET_AWUSER(mp0_syshub_soc_tlb2_29_reg, awuser) \
      mp0_syshub_soc_tlb2_29_reg = (mp0_syshub_soc_tlb2_29_reg & ~MP0_SYSHUB_SOC_TLB2_29_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_29_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_29_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_29_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_29_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_29_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_29_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_29_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_29_t f;
} mp0_syshub_soc_tlb2_29_u;


/*
 * MP0_SYSHUB_SOC_TLB3_29 struct
 */

#define MP0_SYSHUB_SOC_TLB3_29_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_29_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_29_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_29_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_29_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_29_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_29_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_29_MASK \
      (MP0_SYSHUB_SOC_TLB3_29_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_29_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_29_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_29_GET_ARUSER(mp0_syshub_soc_tlb3_29) \
      ((mp0_syshub_soc_tlb3_29 & MP0_SYSHUB_SOC_TLB3_29_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_29_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_29_GET_WUSER(mp0_syshub_soc_tlb3_29) \
      ((mp0_syshub_soc_tlb3_29 & MP0_SYSHUB_SOC_TLB3_29_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_29_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_29_SET_ARUSER(mp0_syshub_soc_tlb3_29_reg, aruser) \
      mp0_syshub_soc_tlb3_29_reg = (mp0_syshub_soc_tlb3_29_reg & ~MP0_SYSHUB_SOC_TLB3_29_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_29_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_29_SET_WUSER(mp0_syshub_soc_tlb3_29_reg, wuser) \
      mp0_syshub_soc_tlb3_29_reg = (mp0_syshub_soc_tlb3_29_reg & ~MP0_SYSHUB_SOC_TLB3_29_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_29_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_29_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_29_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_29_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_29_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_29_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_29_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_29_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_29_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_29_t f;
} mp0_syshub_soc_tlb3_29_u;


/*
 * MP0_SYSHUB_SOC_TLB0_30 struct
 */

#define MP0_SYSHUB_SOC_TLB0_30_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_30_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_30_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_30_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_30_MASK \
      (MP0_SYSHUB_SOC_TLB0_30_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_30_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_30_GET_SOC_ADDR(mp0_syshub_soc_tlb0_30) \
      ((mp0_syshub_soc_tlb0_30 & MP0_SYSHUB_SOC_TLB0_30_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_30_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_30_SET_SOC_ADDR(mp0_syshub_soc_tlb0_30_reg, soc_addr) \
      mp0_syshub_soc_tlb0_30_reg = (mp0_syshub_soc_tlb0_30_reg & ~MP0_SYSHUB_SOC_TLB0_30_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_30_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_30_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_30_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_30_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_30_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_30_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_30_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_30_t f;
} mp0_syshub_soc_tlb0_30_u;


/*
 * MP0_SYSHUB_SOC_TLB1_30 struct
 */

#define MP0_SYSHUB_SOC_TLB1_30_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_30_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_30_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_30_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_30_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_30_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_30_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_30_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_30_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_30_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_30_MASK \
      (MP0_SYSHUB_SOC_TLB1_30_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_30_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_30_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_30_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_30_GET_COHERENCE(mp0_syshub_soc_tlb1_30) \
      ((mp0_syshub_soc_tlb1_30 & MP0_SYSHUB_SOC_TLB1_30_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_30_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_30_GET_SEG_SIZE(mp0_syshub_soc_tlb1_30) \
      ((mp0_syshub_soc_tlb1_30 & MP0_SYSHUB_SOC_TLB1_30_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_30_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_30_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_30) \
      ((mp0_syshub_soc_tlb1_30 & MP0_SYSHUB_SOC_TLB1_30_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_30_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_30_SET_COHERENCE(mp0_syshub_soc_tlb1_30_reg, coherence) \
      mp0_syshub_soc_tlb1_30_reg = (mp0_syshub_soc_tlb1_30_reg & ~MP0_SYSHUB_SOC_TLB1_30_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_30_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_30_SET_SEG_SIZE(mp0_syshub_soc_tlb1_30_reg, seg_size) \
      mp0_syshub_soc_tlb1_30_reg = (mp0_syshub_soc_tlb1_30_reg & ~MP0_SYSHUB_SOC_TLB1_30_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_30_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_30_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_30_reg, seg_offset) \
      mp0_syshub_soc_tlb1_30_reg = (mp0_syshub_soc_tlb1_30_reg & ~MP0_SYSHUB_SOC_TLB1_30_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_30_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_30_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_30_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_30_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_30_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_30_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_30_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_30_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_30_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_30_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_30_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_30_t f;
} mp0_syshub_soc_tlb1_30_u;


/*
 * MP0_SYSHUB_SOC_TLB2_30 struct
 */

#define MP0_SYSHUB_SOC_TLB2_30_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_30_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_30_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_30_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_30_MASK \
      (MP0_SYSHUB_SOC_TLB2_30_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_30_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_30_GET_AWUSER(mp0_syshub_soc_tlb2_30) \
      ((mp0_syshub_soc_tlb2_30 & MP0_SYSHUB_SOC_TLB2_30_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_30_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_30_SET_AWUSER(mp0_syshub_soc_tlb2_30_reg, awuser) \
      mp0_syshub_soc_tlb2_30_reg = (mp0_syshub_soc_tlb2_30_reg & ~MP0_SYSHUB_SOC_TLB2_30_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_30_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_30_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_30_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_30_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_30_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_30_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_30_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_30_t f;
} mp0_syshub_soc_tlb2_30_u;


/*
 * MP0_SYSHUB_SOC_TLB3_30 struct
 */

#define MP0_SYSHUB_SOC_TLB3_30_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_30_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_30_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_30_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_30_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_30_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_30_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_30_MASK \
      (MP0_SYSHUB_SOC_TLB3_30_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_30_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_30_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_30_GET_ARUSER(mp0_syshub_soc_tlb3_30) \
      ((mp0_syshub_soc_tlb3_30 & MP0_SYSHUB_SOC_TLB3_30_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_30_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_30_GET_WUSER(mp0_syshub_soc_tlb3_30) \
      ((mp0_syshub_soc_tlb3_30 & MP0_SYSHUB_SOC_TLB3_30_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_30_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_30_SET_ARUSER(mp0_syshub_soc_tlb3_30_reg, aruser) \
      mp0_syshub_soc_tlb3_30_reg = (mp0_syshub_soc_tlb3_30_reg & ~MP0_SYSHUB_SOC_TLB3_30_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_30_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_30_SET_WUSER(mp0_syshub_soc_tlb3_30_reg, wuser) \
      mp0_syshub_soc_tlb3_30_reg = (mp0_syshub_soc_tlb3_30_reg & ~MP0_SYSHUB_SOC_TLB3_30_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_30_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_30_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_30_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_30_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_30_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_30_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_30_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_30_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_30_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_30_t f;
} mp0_syshub_soc_tlb3_30_u;


/*
 * MP0_SYSHUB_SOC_TLB0_31 struct
 */

#define MP0_SYSHUB_SOC_TLB0_31_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_31_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_31_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_31_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_31_MASK \
      (MP0_SYSHUB_SOC_TLB0_31_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_31_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_31_GET_SOC_ADDR(mp0_syshub_soc_tlb0_31) \
      ((mp0_syshub_soc_tlb0_31 & MP0_SYSHUB_SOC_TLB0_31_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_31_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_31_SET_SOC_ADDR(mp0_syshub_soc_tlb0_31_reg, soc_addr) \
      mp0_syshub_soc_tlb0_31_reg = (mp0_syshub_soc_tlb0_31_reg & ~MP0_SYSHUB_SOC_TLB0_31_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_31_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_31_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_31_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_31_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_31_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_31_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_31_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_31_t f;
} mp0_syshub_soc_tlb0_31_u;


/*
 * MP0_SYSHUB_SOC_TLB1_31 struct
 */

#define MP0_SYSHUB_SOC_TLB1_31_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_31_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_31_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_31_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_31_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_31_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_31_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_31_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_31_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_31_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_31_MASK \
      (MP0_SYSHUB_SOC_TLB1_31_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_31_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_31_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_31_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_31_GET_COHERENCE(mp0_syshub_soc_tlb1_31) \
      ((mp0_syshub_soc_tlb1_31 & MP0_SYSHUB_SOC_TLB1_31_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_31_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_31_GET_SEG_SIZE(mp0_syshub_soc_tlb1_31) \
      ((mp0_syshub_soc_tlb1_31 & MP0_SYSHUB_SOC_TLB1_31_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_31_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_31_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_31) \
      ((mp0_syshub_soc_tlb1_31 & MP0_SYSHUB_SOC_TLB1_31_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_31_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_31_SET_COHERENCE(mp0_syshub_soc_tlb1_31_reg, coherence) \
      mp0_syshub_soc_tlb1_31_reg = (mp0_syshub_soc_tlb1_31_reg & ~MP0_SYSHUB_SOC_TLB1_31_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_31_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_31_SET_SEG_SIZE(mp0_syshub_soc_tlb1_31_reg, seg_size) \
      mp0_syshub_soc_tlb1_31_reg = (mp0_syshub_soc_tlb1_31_reg & ~MP0_SYSHUB_SOC_TLB1_31_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_31_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_31_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_31_reg, seg_offset) \
      mp0_syshub_soc_tlb1_31_reg = (mp0_syshub_soc_tlb1_31_reg & ~MP0_SYSHUB_SOC_TLB1_31_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_31_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_31_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_31_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_31_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_31_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_31_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_31_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_31_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_31_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_31_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_31_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_31_t f;
} mp0_syshub_soc_tlb1_31_u;


/*
 * MP0_SYSHUB_SOC_TLB2_31 struct
 */

#define MP0_SYSHUB_SOC_TLB2_31_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_31_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_31_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_31_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_31_MASK \
      (MP0_SYSHUB_SOC_TLB2_31_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_31_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_31_GET_AWUSER(mp0_syshub_soc_tlb2_31) \
      ((mp0_syshub_soc_tlb2_31 & MP0_SYSHUB_SOC_TLB2_31_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_31_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_31_SET_AWUSER(mp0_syshub_soc_tlb2_31_reg, awuser) \
      mp0_syshub_soc_tlb2_31_reg = (mp0_syshub_soc_tlb2_31_reg & ~MP0_SYSHUB_SOC_TLB2_31_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_31_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_31_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_31_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_31_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_31_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_31_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_31_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_31_t f;
} mp0_syshub_soc_tlb2_31_u;


/*
 * MP0_SYSHUB_SOC_TLB3_31 struct
 */

#define MP0_SYSHUB_SOC_TLB3_31_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_31_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_31_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_31_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_31_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_31_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_31_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_31_MASK \
      (MP0_SYSHUB_SOC_TLB3_31_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_31_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_31_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_31_GET_ARUSER(mp0_syshub_soc_tlb3_31) \
      ((mp0_syshub_soc_tlb3_31 & MP0_SYSHUB_SOC_TLB3_31_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_31_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_31_GET_WUSER(mp0_syshub_soc_tlb3_31) \
      ((mp0_syshub_soc_tlb3_31 & MP0_SYSHUB_SOC_TLB3_31_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_31_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_31_SET_ARUSER(mp0_syshub_soc_tlb3_31_reg, aruser) \
      mp0_syshub_soc_tlb3_31_reg = (mp0_syshub_soc_tlb3_31_reg & ~MP0_SYSHUB_SOC_TLB3_31_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_31_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_31_SET_WUSER(mp0_syshub_soc_tlb3_31_reg, wuser) \
      mp0_syshub_soc_tlb3_31_reg = (mp0_syshub_soc_tlb3_31_reg & ~MP0_SYSHUB_SOC_TLB3_31_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_31_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_31_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_31_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_31_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_31_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_31_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_31_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_31_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_31_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_31_t f;
} mp0_syshub_soc_tlb3_31_u;


/*
 * MP0_SYSHUB_SOC_TLB0_32 struct
 */

#define MP0_SYSHUB_SOC_TLB0_32_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_32_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_32_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_32_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_32_MASK \
      (MP0_SYSHUB_SOC_TLB0_32_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_32_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_32_GET_SOC_ADDR(mp0_syshub_soc_tlb0_32) \
      ((mp0_syshub_soc_tlb0_32 & MP0_SYSHUB_SOC_TLB0_32_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_32_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_32_SET_SOC_ADDR(mp0_syshub_soc_tlb0_32_reg, soc_addr) \
      mp0_syshub_soc_tlb0_32_reg = (mp0_syshub_soc_tlb0_32_reg & ~MP0_SYSHUB_SOC_TLB0_32_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_32_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_32_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_32_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_32_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_32_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_32_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_32_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_32_t f;
} mp0_syshub_soc_tlb0_32_u;


/*
 * MP0_SYSHUB_SOC_TLB1_32 struct
 */

#define MP0_SYSHUB_SOC_TLB1_32_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_32_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_32_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_32_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_32_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_32_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_32_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_32_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_32_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_32_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_32_MASK \
      (MP0_SYSHUB_SOC_TLB1_32_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_32_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_32_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_32_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_32_GET_COHERENCE(mp0_syshub_soc_tlb1_32) \
      ((mp0_syshub_soc_tlb1_32 & MP0_SYSHUB_SOC_TLB1_32_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_32_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_32_GET_SEG_SIZE(mp0_syshub_soc_tlb1_32) \
      ((mp0_syshub_soc_tlb1_32 & MP0_SYSHUB_SOC_TLB1_32_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_32_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_32_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_32) \
      ((mp0_syshub_soc_tlb1_32 & MP0_SYSHUB_SOC_TLB1_32_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_32_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_32_SET_COHERENCE(mp0_syshub_soc_tlb1_32_reg, coherence) \
      mp0_syshub_soc_tlb1_32_reg = (mp0_syshub_soc_tlb1_32_reg & ~MP0_SYSHUB_SOC_TLB1_32_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_32_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_32_SET_SEG_SIZE(mp0_syshub_soc_tlb1_32_reg, seg_size) \
      mp0_syshub_soc_tlb1_32_reg = (mp0_syshub_soc_tlb1_32_reg & ~MP0_SYSHUB_SOC_TLB1_32_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_32_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_32_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_32_reg, seg_offset) \
      mp0_syshub_soc_tlb1_32_reg = (mp0_syshub_soc_tlb1_32_reg & ~MP0_SYSHUB_SOC_TLB1_32_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_32_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_32_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_32_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_32_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_32_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_32_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_32_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_32_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_32_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_32_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_32_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_32_t f;
} mp0_syshub_soc_tlb1_32_u;


/*
 * MP0_SYSHUB_SOC_TLB2_32 struct
 */

#define MP0_SYSHUB_SOC_TLB2_32_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_32_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_32_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_32_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_32_MASK \
      (MP0_SYSHUB_SOC_TLB2_32_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_32_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_32_GET_AWUSER(mp0_syshub_soc_tlb2_32) \
      ((mp0_syshub_soc_tlb2_32 & MP0_SYSHUB_SOC_TLB2_32_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_32_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_32_SET_AWUSER(mp0_syshub_soc_tlb2_32_reg, awuser) \
      mp0_syshub_soc_tlb2_32_reg = (mp0_syshub_soc_tlb2_32_reg & ~MP0_SYSHUB_SOC_TLB2_32_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_32_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_32_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_32_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_32_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_32_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_32_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_32_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_32_t f;
} mp0_syshub_soc_tlb2_32_u;


/*
 * MP0_SYSHUB_SOC_TLB3_32 struct
 */

#define MP0_SYSHUB_SOC_TLB3_32_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_32_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_32_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_32_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_32_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_32_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_32_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_32_MASK \
      (MP0_SYSHUB_SOC_TLB3_32_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_32_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_32_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_32_GET_ARUSER(mp0_syshub_soc_tlb3_32) \
      ((mp0_syshub_soc_tlb3_32 & MP0_SYSHUB_SOC_TLB3_32_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_32_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_32_GET_WUSER(mp0_syshub_soc_tlb3_32) \
      ((mp0_syshub_soc_tlb3_32 & MP0_SYSHUB_SOC_TLB3_32_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_32_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_32_SET_ARUSER(mp0_syshub_soc_tlb3_32_reg, aruser) \
      mp0_syshub_soc_tlb3_32_reg = (mp0_syshub_soc_tlb3_32_reg & ~MP0_SYSHUB_SOC_TLB3_32_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_32_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_32_SET_WUSER(mp0_syshub_soc_tlb3_32_reg, wuser) \
      mp0_syshub_soc_tlb3_32_reg = (mp0_syshub_soc_tlb3_32_reg & ~MP0_SYSHUB_SOC_TLB3_32_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_32_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_32_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_32_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_32_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_32_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_32_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_32_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_32_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_32_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_32_t f;
} mp0_syshub_soc_tlb3_32_u;


/*
 * MP0_SYSHUB_SOC_TLB0_33 struct
 */

#define MP0_SYSHUB_SOC_TLB0_33_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_33_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_33_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_33_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_33_MASK \
      (MP0_SYSHUB_SOC_TLB0_33_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_33_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_33_GET_SOC_ADDR(mp0_syshub_soc_tlb0_33) \
      ((mp0_syshub_soc_tlb0_33 & MP0_SYSHUB_SOC_TLB0_33_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_33_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_33_SET_SOC_ADDR(mp0_syshub_soc_tlb0_33_reg, soc_addr) \
      mp0_syshub_soc_tlb0_33_reg = (mp0_syshub_soc_tlb0_33_reg & ~MP0_SYSHUB_SOC_TLB0_33_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_33_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_33_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_33_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_33_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_33_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_33_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_33_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_33_t f;
} mp0_syshub_soc_tlb0_33_u;


/*
 * MP0_SYSHUB_SOC_TLB1_33 struct
 */

#define MP0_SYSHUB_SOC_TLB1_33_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_33_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_33_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_33_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_33_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_33_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_33_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_33_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_33_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_33_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_33_MASK \
      (MP0_SYSHUB_SOC_TLB1_33_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_33_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_33_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_33_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_33_GET_COHERENCE(mp0_syshub_soc_tlb1_33) \
      ((mp0_syshub_soc_tlb1_33 & MP0_SYSHUB_SOC_TLB1_33_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_33_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_33_GET_SEG_SIZE(mp0_syshub_soc_tlb1_33) \
      ((mp0_syshub_soc_tlb1_33 & MP0_SYSHUB_SOC_TLB1_33_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_33_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_33_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_33) \
      ((mp0_syshub_soc_tlb1_33 & MP0_SYSHUB_SOC_TLB1_33_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_33_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_33_SET_COHERENCE(mp0_syshub_soc_tlb1_33_reg, coherence) \
      mp0_syshub_soc_tlb1_33_reg = (mp0_syshub_soc_tlb1_33_reg & ~MP0_SYSHUB_SOC_TLB1_33_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_33_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_33_SET_SEG_SIZE(mp0_syshub_soc_tlb1_33_reg, seg_size) \
      mp0_syshub_soc_tlb1_33_reg = (mp0_syshub_soc_tlb1_33_reg & ~MP0_SYSHUB_SOC_TLB1_33_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_33_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_33_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_33_reg, seg_offset) \
      mp0_syshub_soc_tlb1_33_reg = (mp0_syshub_soc_tlb1_33_reg & ~MP0_SYSHUB_SOC_TLB1_33_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_33_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_33_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_33_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_33_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_33_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_33_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_33_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_33_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_33_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_33_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_33_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_33_t f;
} mp0_syshub_soc_tlb1_33_u;


/*
 * MP0_SYSHUB_SOC_TLB2_33 struct
 */

#define MP0_SYSHUB_SOC_TLB2_33_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_33_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_33_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_33_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_33_MASK \
      (MP0_SYSHUB_SOC_TLB2_33_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_33_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_33_GET_AWUSER(mp0_syshub_soc_tlb2_33) \
      ((mp0_syshub_soc_tlb2_33 & MP0_SYSHUB_SOC_TLB2_33_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_33_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_33_SET_AWUSER(mp0_syshub_soc_tlb2_33_reg, awuser) \
      mp0_syshub_soc_tlb2_33_reg = (mp0_syshub_soc_tlb2_33_reg & ~MP0_SYSHUB_SOC_TLB2_33_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_33_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_33_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_33_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_33_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_33_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_33_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_33_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_33_t f;
} mp0_syshub_soc_tlb2_33_u;


/*
 * MP0_SYSHUB_SOC_TLB3_33 struct
 */

#define MP0_SYSHUB_SOC_TLB3_33_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_33_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_33_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_33_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_33_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_33_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_33_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_33_MASK \
      (MP0_SYSHUB_SOC_TLB3_33_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_33_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_33_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_33_GET_ARUSER(mp0_syshub_soc_tlb3_33) \
      ((mp0_syshub_soc_tlb3_33 & MP0_SYSHUB_SOC_TLB3_33_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_33_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_33_GET_WUSER(mp0_syshub_soc_tlb3_33) \
      ((mp0_syshub_soc_tlb3_33 & MP0_SYSHUB_SOC_TLB3_33_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_33_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_33_SET_ARUSER(mp0_syshub_soc_tlb3_33_reg, aruser) \
      mp0_syshub_soc_tlb3_33_reg = (mp0_syshub_soc_tlb3_33_reg & ~MP0_SYSHUB_SOC_TLB3_33_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_33_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_33_SET_WUSER(mp0_syshub_soc_tlb3_33_reg, wuser) \
      mp0_syshub_soc_tlb3_33_reg = (mp0_syshub_soc_tlb3_33_reg & ~MP0_SYSHUB_SOC_TLB3_33_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_33_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_33_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_33_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_33_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_33_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_33_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_33_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_33_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_33_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_33_t f;
} mp0_syshub_soc_tlb3_33_u;


/*
 * MP0_SYSHUB_SOC_TLB0_34 struct
 */

#define MP0_SYSHUB_SOC_TLB0_34_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_34_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_34_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_34_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_34_MASK \
      (MP0_SYSHUB_SOC_TLB0_34_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_34_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_34_GET_SOC_ADDR(mp0_syshub_soc_tlb0_34) \
      ((mp0_syshub_soc_tlb0_34 & MP0_SYSHUB_SOC_TLB0_34_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_34_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_34_SET_SOC_ADDR(mp0_syshub_soc_tlb0_34_reg, soc_addr) \
      mp0_syshub_soc_tlb0_34_reg = (mp0_syshub_soc_tlb0_34_reg & ~MP0_SYSHUB_SOC_TLB0_34_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_34_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_34_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_34_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_34_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_34_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_34_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_34_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_34_t f;
} mp0_syshub_soc_tlb0_34_u;


/*
 * MP0_SYSHUB_SOC_TLB1_34 struct
 */

#define MP0_SYSHUB_SOC_TLB1_34_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_34_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_34_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_34_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_34_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_34_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_34_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_34_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_34_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_34_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_34_MASK \
      (MP0_SYSHUB_SOC_TLB1_34_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_34_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_34_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_34_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_34_GET_COHERENCE(mp0_syshub_soc_tlb1_34) \
      ((mp0_syshub_soc_tlb1_34 & MP0_SYSHUB_SOC_TLB1_34_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_34_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_34_GET_SEG_SIZE(mp0_syshub_soc_tlb1_34) \
      ((mp0_syshub_soc_tlb1_34 & MP0_SYSHUB_SOC_TLB1_34_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_34_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_34_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_34) \
      ((mp0_syshub_soc_tlb1_34 & MP0_SYSHUB_SOC_TLB1_34_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_34_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_34_SET_COHERENCE(mp0_syshub_soc_tlb1_34_reg, coherence) \
      mp0_syshub_soc_tlb1_34_reg = (mp0_syshub_soc_tlb1_34_reg & ~MP0_SYSHUB_SOC_TLB1_34_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_34_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_34_SET_SEG_SIZE(mp0_syshub_soc_tlb1_34_reg, seg_size) \
      mp0_syshub_soc_tlb1_34_reg = (mp0_syshub_soc_tlb1_34_reg & ~MP0_SYSHUB_SOC_TLB1_34_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_34_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_34_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_34_reg, seg_offset) \
      mp0_syshub_soc_tlb1_34_reg = (mp0_syshub_soc_tlb1_34_reg & ~MP0_SYSHUB_SOC_TLB1_34_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_34_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_34_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_34_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_34_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_34_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_34_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_34_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_34_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_34_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_34_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_34_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_34_t f;
} mp0_syshub_soc_tlb1_34_u;


/*
 * MP0_SYSHUB_SOC_TLB2_34 struct
 */

#define MP0_SYSHUB_SOC_TLB2_34_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_34_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_34_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_34_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_34_MASK \
      (MP0_SYSHUB_SOC_TLB2_34_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_34_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_34_GET_AWUSER(mp0_syshub_soc_tlb2_34) \
      ((mp0_syshub_soc_tlb2_34 & MP0_SYSHUB_SOC_TLB2_34_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_34_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_34_SET_AWUSER(mp0_syshub_soc_tlb2_34_reg, awuser) \
      mp0_syshub_soc_tlb2_34_reg = (mp0_syshub_soc_tlb2_34_reg & ~MP0_SYSHUB_SOC_TLB2_34_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_34_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_34_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_34_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_34_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_34_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_34_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_34_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_34_t f;
} mp0_syshub_soc_tlb2_34_u;


/*
 * MP0_SYSHUB_SOC_TLB3_34 struct
 */

#define MP0_SYSHUB_SOC_TLB3_34_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_34_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_34_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_34_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_34_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_34_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_34_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_34_MASK \
      (MP0_SYSHUB_SOC_TLB3_34_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_34_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_34_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_34_GET_ARUSER(mp0_syshub_soc_tlb3_34) \
      ((mp0_syshub_soc_tlb3_34 & MP0_SYSHUB_SOC_TLB3_34_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_34_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_34_GET_WUSER(mp0_syshub_soc_tlb3_34) \
      ((mp0_syshub_soc_tlb3_34 & MP0_SYSHUB_SOC_TLB3_34_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_34_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_34_SET_ARUSER(mp0_syshub_soc_tlb3_34_reg, aruser) \
      mp0_syshub_soc_tlb3_34_reg = (mp0_syshub_soc_tlb3_34_reg & ~MP0_SYSHUB_SOC_TLB3_34_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_34_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_34_SET_WUSER(mp0_syshub_soc_tlb3_34_reg, wuser) \
      mp0_syshub_soc_tlb3_34_reg = (mp0_syshub_soc_tlb3_34_reg & ~MP0_SYSHUB_SOC_TLB3_34_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_34_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_34_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_34_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_34_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_34_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_34_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_34_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_34_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_34_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_34_t f;
} mp0_syshub_soc_tlb3_34_u;


/*
 * MP0_SYSHUB_SOC_TLB0_35 struct
 */

#define MP0_SYSHUB_SOC_TLB0_35_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_35_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_35_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_35_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_35_MASK \
      (MP0_SYSHUB_SOC_TLB0_35_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_35_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_35_GET_SOC_ADDR(mp0_syshub_soc_tlb0_35) \
      ((mp0_syshub_soc_tlb0_35 & MP0_SYSHUB_SOC_TLB0_35_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_35_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_35_SET_SOC_ADDR(mp0_syshub_soc_tlb0_35_reg, soc_addr) \
      mp0_syshub_soc_tlb0_35_reg = (mp0_syshub_soc_tlb0_35_reg & ~MP0_SYSHUB_SOC_TLB0_35_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_35_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_35_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_35_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_35_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_35_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_35_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_35_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_35_t f;
} mp0_syshub_soc_tlb0_35_u;


/*
 * MP0_SYSHUB_SOC_TLB1_35 struct
 */

#define MP0_SYSHUB_SOC_TLB1_35_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_35_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_35_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_35_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_35_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_35_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_35_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_35_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_35_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_35_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_35_MASK \
      (MP0_SYSHUB_SOC_TLB1_35_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_35_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_35_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_35_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_35_GET_COHERENCE(mp0_syshub_soc_tlb1_35) \
      ((mp0_syshub_soc_tlb1_35 & MP0_SYSHUB_SOC_TLB1_35_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_35_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_35_GET_SEG_SIZE(mp0_syshub_soc_tlb1_35) \
      ((mp0_syshub_soc_tlb1_35 & MP0_SYSHUB_SOC_TLB1_35_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_35_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_35_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_35) \
      ((mp0_syshub_soc_tlb1_35 & MP0_SYSHUB_SOC_TLB1_35_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_35_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_35_SET_COHERENCE(mp0_syshub_soc_tlb1_35_reg, coherence) \
      mp0_syshub_soc_tlb1_35_reg = (mp0_syshub_soc_tlb1_35_reg & ~MP0_SYSHUB_SOC_TLB1_35_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_35_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_35_SET_SEG_SIZE(mp0_syshub_soc_tlb1_35_reg, seg_size) \
      mp0_syshub_soc_tlb1_35_reg = (mp0_syshub_soc_tlb1_35_reg & ~MP0_SYSHUB_SOC_TLB1_35_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_35_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_35_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_35_reg, seg_offset) \
      mp0_syshub_soc_tlb1_35_reg = (mp0_syshub_soc_tlb1_35_reg & ~MP0_SYSHUB_SOC_TLB1_35_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_35_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_35_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_35_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_35_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_35_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_35_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_35_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_35_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_35_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_35_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_35_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_35_t f;
} mp0_syshub_soc_tlb1_35_u;


/*
 * MP0_SYSHUB_SOC_TLB2_35 struct
 */

#define MP0_SYSHUB_SOC_TLB2_35_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_35_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_35_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_35_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_35_MASK \
      (MP0_SYSHUB_SOC_TLB2_35_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_35_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_35_GET_AWUSER(mp0_syshub_soc_tlb2_35) \
      ((mp0_syshub_soc_tlb2_35 & MP0_SYSHUB_SOC_TLB2_35_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_35_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_35_SET_AWUSER(mp0_syshub_soc_tlb2_35_reg, awuser) \
      mp0_syshub_soc_tlb2_35_reg = (mp0_syshub_soc_tlb2_35_reg & ~MP0_SYSHUB_SOC_TLB2_35_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_35_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_35_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_35_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_35_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_35_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_35_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_35_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_35_t f;
} mp0_syshub_soc_tlb2_35_u;


/*
 * MP0_SYSHUB_SOC_TLB3_35 struct
 */

#define MP0_SYSHUB_SOC_TLB3_35_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_35_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_35_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_35_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_35_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_35_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_35_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_35_MASK \
      (MP0_SYSHUB_SOC_TLB3_35_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_35_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_35_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_35_GET_ARUSER(mp0_syshub_soc_tlb3_35) \
      ((mp0_syshub_soc_tlb3_35 & MP0_SYSHUB_SOC_TLB3_35_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_35_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_35_GET_WUSER(mp0_syshub_soc_tlb3_35) \
      ((mp0_syshub_soc_tlb3_35 & MP0_SYSHUB_SOC_TLB3_35_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_35_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_35_SET_ARUSER(mp0_syshub_soc_tlb3_35_reg, aruser) \
      mp0_syshub_soc_tlb3_35_reg = (mp0_syshub_soc_tlb3_35_reg & ~MP0_SYSHUB_SOC_TLB3_35_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_35_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_35_SET_WUSER(mp0_syshub_soc_tlb3_35_reg, wuser) \
      mp0_syshub_soc_tlb3_35_reg = (mp0_syshub_soc_tlb3_35_reg & ~MP0_SYSHUB_SOC_TLB3_35_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_35_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_35_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_35_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_35_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_35_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_35_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_35_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_35_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_35_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_35_t f;
} mp0_syshub_soc_tlb3_35_u;


/*
 * MP0_SYSHUB_SOC_TLB0_36 struct
 */

#define MP0_SYSHUB_SOC_TLB0_36_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_36_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_36_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_36_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_36_MASK \
      (MP0_SYSHUB_SOC_TLB0_36_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_36_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_36_GET_SOC_ADDR(mp0_syshub_soc_tlb0_36) \
      ((mp0_syshub_soc_tlb0_36 & MP0_SYSHUB_SOC_TLB0_36_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_36_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_36_SET_SOC_ADDR(mp0_syshub_soc_tlb0_36_reg, soc_addr) \
      mp0_syshub_soc_tlb0_36_reg = (mp0_syshub_soc_tlb0_36_reg & ~MP0_SYSHUB_SOC_TLB0_36_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_36_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_36_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_36_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_36_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_36_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_36_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_36_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_36_t f;
} mp0_syshub_soc_tlb0_36_u;


/*
 * MP0_SYSHUB_SOC_TLB1_36 struct
 */

#define MP0_SYSHUB_SOC_TLB1_36_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_36_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_36_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_36_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_36_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_36_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_36_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_36_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_36_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_36_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_36_MASK \
      (MP0_SYSHUB_SOC_TLB1_36_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_36_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_36_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_36_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_36_GET_COHERENCE(mp0_syshub_soc_tlb1_36) \
      ((mp0_syshub_soc_tlb1_36 & MP0_SYSHUB_SOC_TLB1_36_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_36_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_36_GET_SEG_SIZE(mp0_syshub_soc_tlb1_36) \
      ((mp0_syshub_soc_tlb1_36 & MP0_SYSHUB_SOC_TLB1_36_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_36_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_36_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_36) \
      ((mp0_syshub_soc_tlb1_36 & MP0_SYSHUB_SOC_TLB1_36_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_36_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_36_SET_COHERENCE(mp0_syshub_soc_tlb1_36_reg, coherence) \
      mp0_syshub_soc_tlb1_36_reg = (mp0_syshub_soc_tlb1_36_reg & ~MP0_SYSHUB_SOC_TLB1_36_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_36_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_36_SET_SEG_SIZE(mp0_syshub_soc_tlb1_36_reg, seg_size) \
      mp0_syshub_soc_tlb1_36_reg = (mp0_syshub_soc_tlb1_36_reg & ~MP0_SYSHUB_SOC_TLB1_36_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_36_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_36_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_36_reg, seg_offset) \
      mp0_syshub_soc_tlb1_36_reg = (mp0_syshub_soc_tlb1_36_reg & ~MP0_SYSHUB_SOC_TLB1_36_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_36_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_36_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_36_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_36_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_36_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_36_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_36_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_36_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_36_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_36_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_36_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_36_t f;
} mp0_syshub_soc_tlb1_36_u;


/*
 * MP0_SYSHUB_SOC_TLB2_36 struct
 */

#define MP0_SYSHUB_SOC_TLB2_36_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_36_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_36_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_36_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_36_MASK \
      (MP0_SYSHUB_SOC_TLB2_36_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_36_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_36_GET_AWUSER(mp0_syshub_soc_tlb2_36) \
      ((mp0_syshub_soc_tlb2_36 & MP0_SYSHUB_SOC_TLB2_36_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_36_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_36_SET_AWUSER(mp0_syshub_soc_tlb2_36_reg, awuser) \
      mp0_syshub_soc_tlb2_36_reg = (mp0_syshub_soc_tlb2_36_reg & ~MP0_SYSHUB_SOC_TLB2_36_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_36_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_36_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_36_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_36_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_36_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_36_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_36_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_36_t f;
} mp0_syshub_soc_tlb2_36_u;


/*
 * MP0_SYSHUB_SOC_TLB3_36 struct
 */

#define MP0_SYSHUB_SOC_TLB3_36_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_36_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_36_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_36_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_36_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_36_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_36_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_36_MASK \
      (MP0_SYSHUB_SOC_TLB3_36_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_36_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_36_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_36_GET_ARUSER(mp0_syshub_soc_tlb3_36) \
      ((mp0_syshub_soc_tlb3_36 & MP0_SYSHUB_SOC_TLB3_36_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_36_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_36_GET_WUSER(mp0_syshub_soc_tlb3_36) \
      ((mp0_syshub_soc_tlb3_36 & MP0_SYSHUB_SOC_TLB3_36_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_36_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_36_SET_ARUSER(mp0_syshub_soc_tlb3_36_reg, aruser) \
      mp0_syshub_soc_tlb3_36_reg = (mp0_syshub_soc_tlb3_36_reg & ~MP0_SYSHUB_SOC_TLB3_36_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_36_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_36_SET_WUSER(mp0_syshub_soc_tlb3_36_reg, wuser) \
      mp0_syshub_soc_tlb3_36_reg = (mp0_syshub_soc_tlb3_36_reg & ~MP0_SYSHUB_SOC_TLB3_36_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_36_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_36_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_36_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_36_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_36_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_36_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_36_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_36_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_36_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_36_t f;
} mp0_syshub_soc_tlb3_36_u;


/*
 * MP0_SYSHUB_SOC_TLB0_37 struct
 */

#define MP0_SYSHUB_SOC_TLB0_37_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_37_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_37_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_37_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_37_MASK \
      (MP0_SYSHUB_SOC_TLB0_37_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_37_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_37_GET_SOC_ADDR(mp0_syshub_soc_tlb0_37) \
      ((mp0_syshub_soc_tlb0_37 & MP0_SYSHUB_SOC_TLB0_37_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_37_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_37_SET_SOC_ADDR(mp0_syshub_soc_tlb0_37_reg, soc_addr) \
      mp0_syshub_soc_tlb0_37_reg = (mp0_syshub_soc_tlb0_37_reg & ~MP0_SYSHUB_SOC_TLB0_37_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_37_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_37_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_37_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_37_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_37_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_37_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_37_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_37_t f;
} mp0_syshub_soc_tlb0_37_u;


/*
 * MP0_SYSHUB_SOC_TLB1_37 struct
 */

#define MP0_SYSHUB_SOC_TLB1_37_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_37_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_37_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_37_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_37_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_37_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_37_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_37_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_37_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_37_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_37_MASK \
      (MP0_SYSHUB_SOC_TLB1_37_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_37_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_37_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_37_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_37_GET_COHERENCE(mp0_syshub_soc_tlb1_37) \
      ((mp0_syshub_soc_tlb1_37 & MP0_SYSHUB_SOC_TLB1_37_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_37_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_37_GET_SEG_SIZE(mp0_syshub_soc_tlb1_37) \
      ((mp0_syshub_soc_tlb1_37 & MP0_SYSHUB_SOC_TLB1_37_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_37_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_37_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_37) \
      ((mp0_syshub_soc_tlb1_37 & MP0_SYSHUB_SOC_TLB1_37_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_37_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_37_SET_COHERENCE(mp0_syshub_soc_tlb1_37_reg, coherence) \
      mp0_syshub_soc_tlb1_37_reg = (mp0_syshub_soc_tlb1_37_reg & ~MP0_SYSHUB_SOC_TLB1_37_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_37_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_37_SET_SEG_SIZE(mp0_syshub_soc_tlb1_37_reg, seg_size) \
      mp0_syshub_soc_tlb1_37_reg = (mp0_syshub_soc_tlb1_37_reg & ~MP0_SYSHUB_SOC_TLB1_37_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_37_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_37_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_37_reg, seg_offset) \
      mp0_syshub_soc_tlb1_37_reg = (mp0_syshub_soc_tlb1_37_reg & ~MP0_SYSHUB_SOC_TLB1_37_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_37_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_37_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_37_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_37_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_37_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_37_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_37_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_37_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_37_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_37_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_37_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_37_t f;
} mp0_syshub_soc_tlb1_37_u;


/*
 * MP0_SYSHUB_SOC_TLB2_37 struct
 */

#define MP0_SYSHUB_SOC_TLB2_37_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_37_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_37_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_37_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_37_MASK \
      (MP0_SYSHUB_SOC_TLB2_37_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_37_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_37_GET_AWUSER(mp0_syshub_soc_tlb2_37) \
      ((mp0_syshub_soc_tlb2_37 & MP0_SYSHUB_SOC_TLB2_37_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_37_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_37_SET_AWUSER(mp0_syshub_soc_tlb2_37_reg, awuser) \
      mp0_syshub_soc_tlb2_37_reg = (mp0_syshub_soc_tlb2_37_reg & ~MP0_SYSHUB_SOC_TLB2_37_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_37_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_37_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_37_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_37_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_37_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_37_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_37_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_37_t f;
} mp0_syshub_soc_tlb2_37_u;


/*
 * MP0_SYSHUB_SOC_TLB3_37 struct
 */

#define MP0_SYSHUB_SOC_TLB3_37_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_37_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_37_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_37_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_37_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_37_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_37_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_37_MASK \
      (MP0_SYSHUB_SOC_TLB3_37_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_37_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_37_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_37_GET_ARUSER(mp0_syshub_soc_tlb3_37) \
      ((mp0_syshub_soc_tlb3_37 & MP0_SYSHUB_SOC_TLB3_37_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_37_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_37_GET_WUSER(mp0_syshub_soc_tlb3_37) \
      ((mp0_syshub_soc_tlb3_37 & MP0_SYSHUB_SOC_TLB3_37_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_37_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_37_SET_ARUSER(mp0_syshub_soc_tlb3_37_reg, aruser) \
      mp0_syshub_soc_tlb3_37_reg = (mp0_syshub_soc_tlb3_37_reg & ~MP0_SYSHUB_SOC_TLB3_37_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_37_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_37_SET_WUSER(mp0_syshub_soc_tlb3_37_reg, wuser) \
      mp0_syshub_soc_tlb3_37_reg = (mp0_syshub_soc_tlb3_37_reg & ~MP0_SYSHUB_SOC_TLB3_37_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_37_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_37_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_37_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_37_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_37_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_37_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_37_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_37_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_37_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_37_t f;
} mp0_syshub_soc_tlb3_37_u;


/*
 * MP0_SYSHUB_SOC_TLB0_38 struct
 */

#define MP0_SYSHUB_SOC_TLB0_38_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_38_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_38_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_38_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_38_MASK \
      (MP0_SYSHUB_SOC_TLB0_38_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_38_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_38_GET_SOC_ADDR(mp0_syshub_soc_tlb0_38) \
      ((mp0_syshub_soc_tlb0_38 & MP0_SYSHUB_SOC_TLB0_38_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_38_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_38_SET_SOC_ADDR(mp0_syshub_soc_tlb0_38_reg, soc_addr) \
      mp0_syshub_soc_tlb0_38_reg = (mp0_syshub_soc_tlb0_38_reg & ~MP0_SYSHUB_SOC_TLB0_38_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_38_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_38_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_38_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_38_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_38_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_38_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_38_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_38_t f;
} mp0_syshub_soc_tlb0_38_u;


/*
 * MP0_SYSHUB_SOC_TLB1_38 struct
 */

#define MP0_SYSHUB_SOC_TLB1_38_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_38_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_38_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_38_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_38_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_38_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_38_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_38_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_38_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_38_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_38_MASK \
      (MP0_SYSHUB_SOC_TLB1_38_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_38_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_38_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_38_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_38_GET_COHERENCE(mp0_syshub_soc_tlb1_38) \
      ((mp0_syshub_soc_tlb1_38 & MP0_SYSHUB_SOC_TLB1_38_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_38_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_38_GET_SEG_SIZE(mp0_syshub_soc_tlb1_38) \
      ((mp0_syshub_soc_tlb1_38 & MP0_SYSHUB_SOC_TLB1_38_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_38_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_38_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_38) \
      ((mp0_syshub_soc_tlb1_38 & MP0_SYSHUB_SOC_TLB1_38_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_38_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_38_SET_COHERENCE(mp0_syshub_soc_tlb1_38_reg, coherence) \
      mp0_syshub_soc_tlb1_38_reg = (mp0_syshub_soc_tlb1_38_reg & ~MP0_SYSHUB_SOC_TLB1_38_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_38_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_38_SET_SEG_SIZE(mp0_syshub_soc_tlb1_38_reg, seg_size) \
      mp0_syshub_soc_tlb1_38_reg = (mp0_syshub_soc_tlb1_38_reg & ~MP0_SYSHUB_SOC_TLB1_38_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_38_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_38_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_38_reg, seg_offset) \
      mp0_syshub_soc_tlb1_38_reg = (mp0_syshub_soc_tlb1_38_reg & ~MP0_SYSHUB_SOC_TLB1_38_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_38_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_38_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_38_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_38_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_38_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_38_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_38_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_38_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_38_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_38_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_38_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_38_t f;
} mp0_syshub_soc_tlb1_38_u;


/*
 * MP0_SYSHUB_SOC_TLB2_38 struct
 */

#define MP0_SYSHUB_SOC_TLB2_38_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_38_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_38_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_38_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_38_MASK \
      (MP0_SYSHUB_SOC_TLB2_38_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_38_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_38_GET_AWUSER(mp0_syshub_soc_tlb2_38) \
      ((mp0_syshub_soc_tlb2_38 & MP0_SYSHUB_SOC_TLB2_38_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_38_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_38_SET_AWUSER(mp0_syshub_soc_tlb2_38_reg, awuser) \
      mp0_syshub_soc_tlb2_38_reg = (mp0_syshub_soc_tlb2_38_reg & ~MP0_SYSHUB_SOC_TLB2_38_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_38_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_38_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_38_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_38_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_38_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_38_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_38_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_38_t f;
} mp0_syshub_soc_tlb2_38_u;


/*
 * MP0_SYSHUB_SOC_TLB3_38 struct
 */

#define MP0_SYSHUB_SOC_TLB3_38_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_38_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_38_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_38_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_38_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_38_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_38_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_38_MASK \
      (MP0_SYSHUB_SOC_TLB3_38_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_38_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_38_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_38_GET_ARUSER(mp0_syshub_soc_tlb3_38) \
      ((mp0_syshub_soc_tlb3_38 & MP0_SYSHUB_SOC_TLB3_38_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_38_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_38_GET_WUSER(mp0_syshub_soc_tlb3_38) \
      ((mp0_syshub_soc_tlb3_38 & MP0_SYSHUB_SOC_TLB3_38_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_38_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_38_SET_ARUSER(mp0_syshub_soc_tlb3_38_reg, aruser) \
      mp0_syshub_soc_tlb3_38_reg = (mp0_syshub_soc_tlb3_38_reg & ~MP0_SYSHUB_SOC_TLB3_38_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_38_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_38_SET_WUSER(mp0_syshub_soc_tlb3_38_reg, wuser) \
      mp0_syshub_soc_tlb3_38_reg = (mp0_syshub_soc_tlb3_38_reg & ~MP0_SYSHUB_SOC_TLB3_38_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_38_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_38_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_38_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_38_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_38_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_38_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_38_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_38_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_38_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_38_t f;
} mp0_syshub_soc_tlb3_38_u;


/*
 * MP0_SYSHUB_SOC_TLB0_39 struct
 */

#define MP0_SYSHUB_SOC_TLB0_39_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_39_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_39_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_39_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_39_MASK \
      (MP0_SYSHUB_SOC_TLB0_39_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_39_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_39_GET_SOC_ADDR(mp0_syshub_soc_tlb0_39) \
      ((mp0_syshub_soc_tlb0_39 & MP0_SYSHUB_SOC_TLB0_39_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_39_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_39_SET_SOC_ADDR(mp0_syshub_soc_tlb0_39_reg, soc_addr) \
      mp0_syshub_soc_tlb0_39_reg = (mp0_syshub_soc_tlb0_39_reg & ~MP0_SYSHUB_SOC_TLB0_39_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_39_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_39_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_39_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_39_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_39_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_39_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_39_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_39_t f;
} mp0_syshub_soc_tlb0_39_u;


/*
 * MP0_SYSHUB_SOC_TLB1_39 struct
 */

#define MP0_SYSHUB_SOC_TLB1_39_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_39_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_39_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_39_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_39_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_39_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_39_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_39_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_39_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_39_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_39_MASK \
      (MP0_SYSHUB_SOC_TLB1_39_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_39_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_39_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_39_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_39_GET_COHERENCE(mp0_syshub_soc_tlb1_39) \
      ((mp0_syshub_soc_tlb1_39 & MP0_SYSHUB_SOC_TLB1_39_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_39_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_39_GET_SEG_SIZE(mp0_syshub_soc_tlb1_39) \
      ((mp0_syshub_soc_tlb1_39 & MP0_SYSHUB_SOC_TLB1_39_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_39_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_39_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_39) \
      ((mp0_syshub_soc_tlb1_39 & MP0_SYSHUB_SOC_TLB1_39_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_39_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_39_SET_COHERENCE(mp0_syshub_soc_tlb1_39_reg, coherence) \
      mp0_syshub_soc_tlb1_39_reg = (mp0_syshub_soc_tlb1_39_reg & ~MP0_SYSHUB_SOC_TLB1_39_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_39_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_39_SET_SEG_SIZE(mp0_syshub_soc_tlb1_39_reg, seg_size) \
      mp0_syshub_soc_tlb1_39_reg = (mp0_syshub_soc_tlb1_39_reg & ~MP0_SYSHUB_SOC_TLB1_39_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_39_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_39_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_39_reg, seg_offset) \
      mp0_syshub_soc_tlb1_39_reg = (mp0_syshub_soc_tlb1_39_reg & ~MP0_SYSHUB_SOC_TLB1_39_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_39_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_39_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_39_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_39_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_39_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_39_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_39_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_39_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_39_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_39_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_39_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_39_t f;
} mp0_syshub_soc_tlb1_39_u;


/*
 * MP0_SYSHUB_SOC_TLB2_39 struct
 */

#define MP0_SYSHUB_SOC_TLB2_39_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_39_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_39_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_39_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_39_MASK \
      (MP0_SYSHUB_SOC_TLB2_39_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_39_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_39_GET_AWUSER(mp0_syshub_soc_tlb2_39) \
      ((mp0_syshub_soc_tlb2_39 & MP0_SYSHUB_SOC_TLB2_39_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_39_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_39_SET_AWUSER(mp0_syshub_soc_tlb2_39_reg, awuser) \
      mp0_syshub_soc_tlb2_39_reg = (mp0_syshub_soc_tlb2_39_reg & ~MP0_SYSHUB_SOC_TLB2_39_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_39_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_39_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_39_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_39_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_39_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_39_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_39_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_39_t f;
} mp0_syshub_soc_tlb2_39_u;


/*
 * MP0_SYSHUB_SOC_TLB3_39 struct
 */

#define MP0_SYSHUB_SOC_TLB3_39_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_39_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_39_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_39_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_39_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_39_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_39_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_39_MASK \
      (MP0_SYSHUB_SOC_TLB3_39_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_39_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_39_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_39_GET_ARUSER(mp0_syshub_soc_tlb3_39) \
      ((mp0_syshub_soc_tlb3_39 & MP0_SYSHUB_SOC_TLB3_39_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_39_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_39_GET_WUSER(mp0_syshub_soc_tlb3_39) \
      ((mp0_syshub_soc_tlb3_39 & MP0_SYSHUB_SOC_TLB3_39_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_39_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_39_SET_ARUSER(mp0_syshub_soc_tlb3_39_reg, aruser) \
      mp0_syshub_soc_tlb3_39_reg = (mp0_syshub_soc_tlb3_39_reg & ~MP0_SYSHUB_SOC_TLB3_39_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_39_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_39_SET_WUSER(mp0_syshub_soc_tlb3_39_reg, wuser) \
      mp0_syshub_soc_tlb3_39_reg = (mp0_syshub_soc_tlb3_39_reg & ~MP0_SYSHUB_SOC_TLB3_39_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_39_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_39_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_39_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_39_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_39_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_39_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_39_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_39_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_39_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_39_t f;
} mp0_syshub_soc_tlb3_39_u;


/*
 * MP0_SYSHUB_SOC_TLB0_40 struct
 */

#define MP0_SYSHUB_SOC_TLB0_40_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_40_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_40_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_40_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_40_MASK \
      (MP0_SYSHUB_SOC_TLB0_40_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_40_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_40_GET_SOC_ADDR(mp0_syshub_soc_tlb0_40) \
      ((mp0_syshub_soc_tlb0_40 & MP0_SYSHUB_SOC_TLB0_40_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_40_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_40_SET_SOC_ADDR(mp0_syshub_soc_tlb0_40_reg, soc_addr) \
      mp0_syshub_soc_tlb0_40_reg = (mp0_syshub_soc_tlb0_40_reg & ~MP0_SYSHUB_SOC_TLB0_40_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_40_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_40_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_40_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_40_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_40_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_40_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_40_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_40_t f;
} mp0_syshub_soc_tlb0_40_u;


/*
 * MP0_SYSHUB_SOC_TLB1_40 struct
 */

#define MP0_SYSHUB_SOC_TLB1_40_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_40_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_40_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_40_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_40_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_40_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_40_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_40_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_40_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_40_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_40_MASK \
      (MP0_SYSHUB_SOC_TLB1_40_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_40_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_40_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_40_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_40_GET_COHERENCE(mp0_syshub_soc_tlb1_40) \
      ((mp0_syshub_soc_tlb1_40 & MP0_SYSHUB_SOC_TLB1_40_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_40_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_40_GET_SEG_SIZE(mp0_syshub_soc_tlb1_40) \
      ((mp0_syshub_soc_tlb1_40 & MP0_SYSHUB_SOC_TLB1_40_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_40_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_40_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_40) \
      ((mp0_syshub_soc_tlb1_40 & MP0_SYSHUB_SOC_TLB1_40_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_40_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_40_SET_COHERENCE(mp0_syshub_soc_tlb1_40_reg, coherence) \
      mp0_syshub_soc_tlb1_40_reg = (mp0_syshub_soc_tlb1_40_reg & ~MP0_SYSHUB_SOC_TLB1_40_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_40_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_40_SET_SEG_SIZE(mp0_syshub_soc_tlb1_40_reg, seg_size) \
      mp0_syshub_soc_tlb1_40_reg = (mp0_syshub_soc_tlb1_40_reg & ~MP0_SYSHUB_SOC_TLB1_40_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_40_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_40_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_40_reg, seg_offset) \
      mp0_syshub_soc_tlb1_40_reg = (mp0_syshub_soc_tlb1_40_reg & ~MP0_SYSHUB_SOC_TLB1_40_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_40_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_40_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_40_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_40_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_40_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_40_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_40_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_40_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_40_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_40_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_40_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_40_t f;
} mp0_syshub_soc_tlb1_40_u;


/*
 * MP0_SYSHUB_SOC_TLB2_40 struct
 */

#define MP0_SYSHUB_SOC_TLB2_40_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_40_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_40_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_40_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_40_MASK \
      (MP0_SYSHUB_SOC_TLB2_40_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_40_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_40_GET_AWUSER(mp0_syshub_soc_tlb2_40) \
      ((mp0_syshub_soc_tlb2_40 & MP0_SYSHUB_SOC_TLB2_40_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_40_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_40_SET_AWUSER(mp0_syshub_soc_tlb2_40_reg, awuser) \
      mp0_syshub_soc_tlb2_40_reg = (mp0_syshub_soc_tlb2_40_reg & ~MP0_SYSHUB_SOC_TLB2_40_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_40_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_40_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_40_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_40_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_40_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_40_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_40_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_40_t f;
} mp0_syshub_soc_tlb2_40_u;


/*
 * MP0_SYSHUB_SOC_TLB3_40 struct
 */

#define MP0_SYSHUB_SOC_TLB3_40_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_40_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_40_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_40_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_40_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_40_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_40_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_40_MASK \
      (MP0_SYSHUB_SOC_TLB3_40_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_40_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_40_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_40_GET_ARUSER(mp0_syshub_soc_tlb3_40) \
      ((mp0_syshub_soc_tlb3_40 & MP0_SYSHUB_SOC_TLB3_40_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_40_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_40_GET_WUSER(mp0_syshub_soc_tlb3_40) \
      ((mp0_syshub_soc_tlb3_40 & MP0_SYSHUB_SOC_TLB3_40_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_40_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_40_SET_ARUSER(mp0_syshub_soc_tlb3_40_reg, aruser) \
      mp0_syshub_soc_tlb3_40_reg = (mp0_syshub_soc_tlb3_40_reg & ~MP0_SYSHUB_SOC_TLB3_40_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_40_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_40_SET_WUSER(mp0_syshub_soc_tlb3_40_reg, wuser) \
      mp0_syshub_soc_tlb3_40_reg = (mp0_syshub_soc_tlb3_40_reg & ~MP0_SYSHUB_SOC_TLB3_40_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_40_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_40_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_40_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_40_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_40_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_40_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_40_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_40_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_40_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_40_t f;
} mp0_syshub_soc_tlb3_40_u;


/*
 * MP0_SYSHUB_SOC_TLB0_41 struct
 */

#define MP0_SYSHUB_SOC_TLB0_41_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_41_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_41_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_41_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_41_MASK \
      (MP0_SYSHUB_SOC_TLB0_41_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_41_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_41_GET_SOC_ADDR(mp0_syshub_soc_tlb0_41) \
      ((mp0_syshub_soc_tlb0_41 & MP0_SYSHUB_SOC_TLB0_41_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_41_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_41_SET_SOC_ADDR(mp0_syshub_soc_tlb0_41_reg, soc_addr) \
      mp0_syshub_soc_tlb0_41_reg = (mp0_syshub_soc_tlb0_41_reg & ~MP0_SYSHUB_SOC_TLB0_41_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_41_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_41_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_41_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_41_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_41_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_41_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_41_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_41_t f;
} mp0_syshub_soc_tlb0_41_u;


/*
 * MP0_SYSHUB_SOC_TLB1_41 struct
 */

#define MP0_SYSHUB_SOC_TLB1_41_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_41_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_41_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_41_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_41_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_41_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_41_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_41_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_41_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_41_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_41_MASK \
      (MP0_SYSHUB_SOC_TLB1_41_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_41_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_41_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_41_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_41_GET_COHERENCE(mp0_syshub_soc_tlb1_41) \
      ((mp0_syshub_soc_tlb1_41 & MP0_SYSHUB_SOC_TLB1_41_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_41_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_41_GET_SEG_SIZE(mp0_syshub_soc_tlb1_41) \
      ((mp0_syshub_soc_tlb1_41 & MP0_SYSHUB_SOC_TLB1_41_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_41_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_41_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_41) \
      ((mp0_syshub_soc_tlb1_41 & MP0_SYSHUB_SOC_TLB1_41_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_41_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_41_SET_COHERENCE(mp0_syshub_soc_tlb1_41_reg, coherence) \
      mp0_syshub_soc_tlb1_41_reg = (mp0_syshub_soc_tlb1_41_reg & ~MP0_SYSHUB_SOC_TLB1_41_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_41_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_41_SET_SEG_SIZE(mp0_syshub_soc_tlb1_41_reg, seg_size) \
      mp0_syshub_soc_tlb1_41_reg = (mp0_syshub_soc_tlb1_41_reg & ~MP0_SYSHUB_SOC_TLB1_41_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_41_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_41_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_41_reg, seg_offset) \
      mp0_syshub_soc_tlb1_41_reg = (mp0_syshub_soc_tlb1_41_reg & ~MP0_SYSHUB_SOC_TLB1_41_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_41_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_41_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_41_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_41_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_41_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_41_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_41_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_41_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_41_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_41_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_41_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_41_t f;
} mp0_syshub_soc_tlb1_41_u;


/*
 * MP0_SYSHUB_SOC_TLB2_41 struct
 */

#define MP0_SYSHUB_SOC_TLB2_41_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_41_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_41_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_41_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_41_MASK \
      (MP0_SYSHUB_SOC_TLB2_41_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_41_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_41_GET_AWUSER(mp0_syshub_soc_tlb2_41) \
      ((mp0_syshub_soc_tlb2_41 & MP0_SYSHUB_SOC_TLB2_41_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_41_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_41_SET_AWUSER(mp0_syshub_soc_tlb2_41_reg, awuser) \
      mp0_syshub_soc_tlb2_41_reg = (mp0_syshub_soc_tlb2_41_reg & ~MP0_SYSHUB_SOC_TLB2_41_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_41_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_41_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_41_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_41_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_41_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_41_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_41_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_41_t f;
} mp0_syshub_soc_tlb2_41_u;


/*
 * MP0_SYSHUB_SOC_TLB3_41 struct
 */

#define MP0_SYSHUB_SOC_TLB3_41_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_41_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_41_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_41_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_41_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_41_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_41_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_41_MASK \
      (MP0_SYSHUB_SOC_TLB3_41_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_41_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_41_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_41_GET_ARUSER(mp0_syshub_soc_tlb3_41) \
      ((mp0_syshub_soc_tlb3_41 & MP0_SYSHUB_SOC_TLB3_41_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_41_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_41_GET_WUSER(mp0_syshub_soc_tlb3_41) \
      ((mp0_syshub_soc_tlb3_41 & MP0_SYSHUB_SOC_TLB3_41_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_41_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_41_SET_ARUSER(mp0_syshub_soc_tlb3_41_reg, aruser) \
      mp0_syshub_soc_tlb3_41_reg = (mp0_syshub_soc_tlb3_41_reg & ~MP0_SYSHUB_SOC_TLB3_41_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_41_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_41_SET_WUSER(mp0_syshub_soc_tlb3_41_reg, wuser) \
      mp0_syshub_soc_tlb3_41_reg = (mp0_syshub_soc_tlb3_41_reg & ~MP0_SYSHUB_SOC_TLB3_41_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_41_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_41_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_41_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_41_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_41_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_41_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_41_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_41_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_41_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_41_t f;
} mp0_syshub_soc_tlb3_41_u;


/*
 * MP0_SYSHUB_SOC_TLB0_42 struct
 */

#define MP0_SYSHUB_SOC_TLB0_42_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_42_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_42_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_42_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_42_MASK \
      (MP0_SYSHUB_SOC_TLB0_42_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_42_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_42_GET_SOC_ADDR(mp0_syshub_soc_tlb0_42) \
      ((mp0_syshub_soc_tlb0_42 & MP0_SYSHUB_SOC_TLB0_42_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_42_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_42_SET_SOC_ADDR(mp0_syshub_soc_tlb0_42_reg, soc_addr) \
      mp0_syshub_soc_tlb0_42_reg = (mp0_syshub_soc_tlb0_42_reg & ~MP0_SYSHUB_SOC_TLB0_42_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_42_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_42_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_42_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_42_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_42_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_42_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_42_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_42_t f;
} mp0_syshub_soc_tlb0_42_u;


/*
 * MP0_SYSHUB_SOC_TLB1_42 struct
 */

#define MP0_SYSHUB_SOC_TLB1_42_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_42_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_42_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_42_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_42_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_42_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_42_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_42_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_42_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_42_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_42_MASK \
      (MP0_SYSHUB_SOC_TLB1_42_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_42_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_42_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_42_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_42_GET_COHERENCE(mp0_syshub_soc_tlb1_42) \
      ((mp0_syshub_soc_tlb1_42 & MP0_SYSHUB_SOC_TLB1_42_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_42_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_42_GET_SEG_SIZE(mp0_syshub_soc_tlb1_42) \
      ((mp0_syshub_soc_tlb1_42 & MP0_SYSHUB_SOC_TLB1_42_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_42_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_42_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_42) \
      ((mp0_syshub_soc_tlb1_42 & MP0_SYSHUB_SOC_TLB1_42_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_42_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_42_SET_COHERENCE(mp0_syshub_soc_tlb1_42_reg, coherence) \
      mp0_syshub_soc_tlb1_42_reg = (mp0_syshub_soc_tlb1_42_reg & ~MP0_SYSHUB_SOC_TLB1_42_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_42_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_42_SET_SEG_SIZE(mp0_syshub_soc_tlb1_42_reg, seg_size) \
      mp0_syshub_soc_tlb1_42_reg = (mp0_syshub_soc_tlb1_42_reg & ~MP0_SYSHUB_SOC_TLB1_42_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_42_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_42_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_42_reg, seg_offset) \
      mp0_syshub_soc_tlb1_42_reg = (mp0_syshub_soc_tlb1_42_reg & ~MP0_SYSHUB_SOC_TLB1_42_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_42_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_42_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_42_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_42_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_42_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_42_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_42_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_42_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_42_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_42_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_42_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_42_t f;
} mp0_syshub_soc_tlb1_42_u;


/*
 * MP0_SYSHUB_SOC_TLB2_42 struct
 */

#define MP0_SYSHUB_SOC_TLB2_42_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_42_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_42_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_42_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_42_MASK \
      (MP0_SYSHUB_SOC_TLB2_42_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_42_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_42_GET_AWUSER(mp0_syshub_soc_tlb2_42) \
      ((mp0_syshub_soc_tlb2_42 & MP0_SYSHUB_SOC_TLB2_42_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_42_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_42_SET_AWUSER(mp0_syshub_soc_tlb2_42_reg, awuser) \
      mp0_syshub_soc_tlb2_42_reg = (mp0_syshub_soc_tlb2_42_reg & ~MP0_SYSHUB_SOC_TLB2_42_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_42_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_42_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_42_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_42_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_42_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_42_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_42_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_42_t f;
} mp0_syshub_soc_tlb2_42_u;


/*
 * MP0_SYSHUB_SOC_TLB3_42 struct
 */

#define MP0_SYSHUB_SOC_TLB3_42_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_42_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_42_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_42_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_42_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_42_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_42_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_42_MASK \
      (MP0_SYSHUB_SOC_TLB3_42_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_42_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_42_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_42_GET_ARUSER(mp0_syshub_soc_tlb3_42) \
      ((mp0_syshub_soc_tlb3_42 & MP0_SYSHUB_SOC_TLB3_42_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_42_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_42_GET_WUSER(mp0_syshub_soc_tlb3_42) \
      ((mp0_syshub_soc_tlb3_42 & MP0_SYSHUB_SOC_TLB3_42_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_42_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_42_SET_ARUSER(mp0_syshub_soc_tlb3_42_reg, aruser) \
      mp0_syshub_soc_tlb3_42_reg = (mp0_syshub_soc_tlb3_42_reg & ~MP0_SYSHUB_SOC_TLB3_42_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_42_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_42_SET_WUSER(mp0_syshub_soc_tlb3_42_reg, wuser) \
      mp0_syshub_soc_tlb3_42_reg = (mp0_syshub_soc_tlb3_42_reg & ~MP0_SYSHUB_SOC_TLB3_42_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_42_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_42_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_42_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_42_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_42_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_42_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_42_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_42_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_42_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_42_t f;
} mp0_syshub_soc_tlb3_42_u;


/*
 * MP0_SYSHUB_SOC_TLB0_43 struct
 */

#define MP0_SYSHUB_SOC_TLB0_43_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_43_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_43_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_43_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_43_MASK \
      (MP0_SYSHUB_SOC_TLB0_43_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_43_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_43_GET_SOC_ADDR(mp0_syshub_soc_tlb0_43) \
      ((mp0_syshub_soc_tlb0_43 & MP0_SYSHUB_SOC_TLB0_43_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_43_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_43_SET_SOC_ADDR(mp0_syshub_soc_tlb0_43_reg, soc_addr) \
      mp0_syshub_soc_tlb0_43_reg = (mp0_syshub_soc_tlb0_43_reg & ~MP0_SYSHUB_SOC_TLB0_43_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_43_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_43_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_43_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_43_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_43_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_43_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_43_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_43_t f;
} mp0_syshub_soc_tlb0_43_u;


/*
 * MP0_SYSHUB_SOC_TLB1_43 struct
 */

#define MP0_SYSHUB_SOC_TLB1_43_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_43_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_43_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_43_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_43_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_43_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_43_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_43_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_43_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_43_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_43_MASK \
      (MP0_SYSHUB_SOC_TLB1_43_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_43_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_43_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_43_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_43_GET_COHERENCE(mp0_syshub_soc_tlb1_43) \
      ((mp0_syshub_soc_tlb1_43 & MP0_SYSHUB_SOC_TLB1_43_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_43_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_43_GET_SEG_SIZE(mp0_syshub_soc_tlb1_43) \
      ((mp0_syshub_soc_tlb1_43 & MP0_SYSHUB_SOC_TLB1_43_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_43_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_43_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_43) \
      ((mp0_syshub_soc_tlb1_43 & MP0_SYSHUB_SOC_TLB1_43_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_43_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_43_SET_COHERENCE(mp0_syshub_soc_tlb1_43_reg, coherence) \
      mp0_syshub_soc_tlb1_43_reg = (mp0_syshub_soc_tlb1_43_reg & ~MP0_SYSHUB_SOC_TLB1_43_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_43_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_43_SET_SEG_SIZE(mp0_syshub_soc_tlb1_43_reg, seg_size) \
      mp0_syshub_soc_tlb1_43_reg = (mp0_syshub_soc_tlb1_43_reg & ~MP0_SYSHUB_SOC_TLB1_43_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_43_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_43_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_43_reg, seg_offset) \
      mp0_syshub_soc_tlb1_43_reg = (mp0_syshub_soc_tlb1_43_reg & ~MP0_SYSHUB_SOC_TLB1_43_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_43_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_43_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_43_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_43_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_43_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_43_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_43_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_43_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_43_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_43_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_43_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_43_t f;
} mp0_syshub_soc_tlb1_43_u;


/*
 * MP0_SYSHUB_SOC_TLB2_43 struct
 */

#define MP0_SYSHUB_SOC_TLB2_43_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_43_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_43_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_43_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_43_MASK \
      (MP0_SYSHUB_SOC_TLB2_43_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_43_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_43_GET_AWUSER(mp0_syshub_soc_tlb2_43) \
      ((mp0_syshub_soc_tlb2_43 & MP0_SYSHUB_SOC_TLB2_43_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_43_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_43_SET_AWUSER(mp0_syshub_soc_tlb2_43_reg, awuser) \
      mp0_syshub_soc_tlb2_43_reg = (mp0_syshub_soc_tlb2_43_reg & ~MP0_SYSHUB_SOC_TLB2_43_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_43_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_43_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_43_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_43_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_43_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_43_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_43_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_43_t f;
} mp0_syshub_soc_tlb2_43_u;


/*
 * MP0_SYSHUB_SOC_TLB3_43 struct
 */

#define MP0_SYSHUB_SOC_TLB3_43_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_43_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_43_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_43_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_43_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_43_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_43_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_43_MASK \
      (MP0_SYSHUB_SOC_TLB3_43_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_43_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_43_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_43_GET_ARUSER(mp0_syshub_soc_tlb3_43) \
      ((mp0_syshub_soc_tlb3_43 & MP0_SYSHUB_SOC_TLB3_43_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_43_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_43_GET_WUSER(mp0_syshub_soc_tlb3_43) \
      ((mp0_syshub_soc_tlb3_43 & MP0_SYSHUB_SOC_TLB3_43_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_43_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_43_SET_ARUSER(mp0_syshub_soc_tlb3_43_reg, aruser) \
      mp0_syshub_soc_tlb3_43_reg = (mp0_syshub_soc_tlb3_43_reg & ~MP0_SYSHUB_SOC_TLB3_43_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_43_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_43_SET_WUSER(mp0_syshub_soc_tlb3_43_reg, wuser) \
      mp0_syshub_soc_tlb3_43_reg = (mp0_syshub_soc_tlb3_43_reg & ~MP0_SYSHUB_SOC_TLB3_43_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_43_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_43_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_43_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_43_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_43_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_43_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_43_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_43_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_43_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_43_t f;
} mp0_syshub_soc_tlb3_43_u;


/*
 * MP0_SYSHUB_SOC_TLB0_44 struct
 */

#define MP0_SYSHUB_SOC_TLB0_44_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_44_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_44_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_44_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_44_MASK \
      (MP0_SYSHUB_SOC_TLB0_44_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_44_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_44_GET_SOC_ADDR(mp0_syshub_soc_tlb0_44) \
      ((mp0_syshub_soc_tlb0_44 & MP0_SYSHUB_SOC_TLB0_44_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_44_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_44_SET_SOC_ADDR(mp0_syshub_soc_tlb0_44_reg, soc_addr) \
      mp0_syshub_soc_tlb0_44_reg = (mp0_syshub_soc_tlb0_44_reg & ~MP0_SYSHUB_SOC_TLB0_44_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_44_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_44_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_44_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_44_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_44_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_44_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_44_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_44_t f;
} mp0_syshub_soc_tlb0_44_u;


/*
 * MP0_SYSHUB_SOC_TLB1_44 struct
 */

#define MP0_SYSHUB_SOC_TLB1_44_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_44_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_44_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_44_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_44_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_44_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_44_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_44_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_44_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_44_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_44_MASK \
      (MP0_SYSHUB_SOC_TLB1_44_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_44_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_44_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_44_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_44_GET_COHERENCE(mp0_syshub_soc_tlb1_44) \
      ((mp0_syshub_soc_tlb1_44 & MP0_SYSHUB_SOC_TLB1_44_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_44_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_44_GET_SEG_SIZE(mp0_syshub_soc_tlb1_44) \
      ((mp0_syshub_soc_tlb1_44 & MP0_SYSHUB_SOC_TLB1_44_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_44_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_44_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_44) \
      ((mp0_syshub_soc_tlb1_44 & MP0_SYSHUB_SOC_TLB1_44_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_44_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_44_SET_COHERENCE(mp0_syshub_soc_tlb1_44_reg, coherence) \
      mp0_syshub_soc_tlb1_44_reg = (mp0_syshub_soc_tlb1_44_reg & ~MP0_SYSHUB_SOC_TLB1_44_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_44_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_44_SET_SEG_SIZE(mp0_syshub_soc_tlb1_44_reg, seg_size) \
      mp0_syshub_soc_tlb1_44_reg = (mp0_syshub_soc_tlb1_44_reg & ~MP0_SYSHUB_SOC_TLB1_44_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_44_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_44_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_44_reg, seg_offset) \
      mp0_syshub_soc_tlb1_44_reg = (mp0_syshub_soc_tlb1_44_reg & ~MP0_SYSHUB_SOC_TLB1_44_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_44_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_44_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_44_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_44_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_44_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_44_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_44_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_44_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_44_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_44_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_44_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_44_t f;
} mp0_syshub_soc_tlb1_44_u;


/*
 * MP0_SYSHUB_SOC_TLB2_44 struct
 */

#define MP0_SYSHUB_SOC_TLB2_44_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_44_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_44_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_44_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_44_MASK \
      (MP0_SYSHUB_SOC_TLB2_44_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_44_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_44_GET_AWUSER(mp0_syshub_soc_tlb2_44) \
      ((mp0_syshub_soc_tlb2_44 & MP0_SYSHUB_SOC_TLB2_44_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_44_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_44_SET_AWUSER(mp0_syshub_soc_tlb2_44_reg, awuser) \
      mp0_syshub_soc_tlb2_44_reg = (mp0_syshub_soc_tlb2_44_reg & ~MP0_SYSHUB_SOC_TLB2_44_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_44_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_44_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_44_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_44_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_44_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_44_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_44_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_44_t f;
} mp0_syshub_soc_tlb2_44_u;


/*
 * MP0_SYSHUB_SOC_TLB3_44 struct
 */

#define MP0_SYSHUB_SOC_TLB3_44_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_44_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_44_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_44_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_44_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_44_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_44_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_44_MASK \
      (MP0_SYSHUB_SOC_TLB3_44_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_44_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_44_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_44_GET_ARUSER(mp0_syshub_soc_tlb3_44) \
      ((mp0_syshub_soc_tlb3_44 & MP0_SYSHUB_SOC_TLB3_44_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_44_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_44_GET_WUSER(mp0_syshub_soc_tlb3_44) \
      ((mp0_syshub_soc_tlb3_44 & MP0_SYSHUB_SOC_TLB3_44_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_44_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_44_SET_ARUSER(mp0_syshub_soc_tlb3_44_reg, aruser) \
      mp0_syshub_soc_tlb3_44_reg = (mp0_syshub_soc_tlb3_44_reg & ~MP0_SYSHUB_SOC_TLB3_44_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_44_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_44_SET_WUSER(mp0_syshub_soc_tlb3_44_reg, wuser) \
      mp0_syshub_soc_tlb3_44_reg = (mp0_syshub_soc_tlb3_44_reg & ~MP0_SYSHUB_SOC_TLB3_44_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_44_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_44_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_44_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_44_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_44_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_44_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_44_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_44_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_44_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_44_t f;
} mp0_syshub_soc_tlb3_44_u;


/*
 * MP0_SYSHUB_SOC_TLB0_45 struct
 */

#define MP0_SYSHUB_SOC_TLB0_45_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_45_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_45_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_45_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_45_MASK \
      (MP0_SYSHUB_SOC_TLB0_45_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_45_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_45_GET_SOC_ADDR(mp0_syshub_soc_tlb0_45) \
      ((mp0_syshub_soc_tlb0_45 & MP0_SYSHUB_SOC_TLB0_45_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_45_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_45_SET_SOC_ADDR(mp0_syshub_soc_tlb0_45_reg, soc_addr) \
      mp0_syshub_soc_tlb0_45_reg = (mp0_syshub_soc_tlb0_45_reg & ~MP0_SYSHUB_SOC_TLB0_45_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_45_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_45_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_45_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_45_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_45_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_45_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_45_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_45_t f;
} mp0_syshub_soc_tlb0_45_u;


/*
 * MP0_SYSHUB_SOC_TLB1_45 struct
 */

#define MP0_SYSHUB_SOC_TLB1_45_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_45_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_45_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_45_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_45_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_45_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_45_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_45_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_45_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_45_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_45_MASK \
      (MP0_SYSHUB_SOC_TLB1_45_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_45_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_45_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_45_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_45_GET_COHERENCE(mp0_syshub_soc_tlb1_45) \
      ((mp0_syshub_soc_tlb1_45 & MP0_SYSHUB_SOC_TLB1_45_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_45_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_45_GET_SEG_SIZE(mp0_syshub_soc_tlb1_45) \
      ((mp0_syshub_soc_tlb1_45 & MP0_SYSHUB_SOC_TLB1_45_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_45_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_45_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_45) \
      ((mp0_syshub_soc_tlb1_45 & MP0_SYSHUB_SOC_TLB1_45_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_45_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_45_SET_COHERENCE(mp0_syshub_soc_tlb1_45_reg, coherence) \
      mp0_syshub_soc_tlb1_45_reg = (mp0_syshub_soc_tlb1_45_reg & ~MP0_SYSHUB_SOC_TLB1_45_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_45_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_45_SET_SEG_SIZE(mp0_syshub_soc_tlb1_45_reg, seg_size) \
      mp0_syshub_soc_tlb1_45_reg = (mp0_syshub_soc_tlb1_45_reg & ~MP0_SYSHUB_SOC_TLB1_45_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_45_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_45_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_45_reg, seg_offset) \
      mp0_syshub_soc_tlb1_45_reg = (mp0_syshub_soc_tlb1_45_reg & ~MP0_SYSHUB_SOC_TLB1_45_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_45_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_45_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_45_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_45_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_45_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_45_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_45_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_45_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_45_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_45_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_45_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_45_t f;
} mp0_syshub_soc_tlb1_45_u;


/*
 * MP0_SYSHUB_SOC_TLB2_45 struct
 */

#define MP0_SYSHUB_SOC_TLB2_45_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_45_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_45_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_45_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_45_MASK \
      (MP0_SYSHUB_SOC_TLB2_45_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_45_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_45_GET_AWUSER(mp0_syshub_soc_tlb2_45) \
      ((mp0_syshub_soc_tlb2_45 & MP0_SYSHUB_SOC_TLB2_45_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_45_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_45_SET_AWUSER(mp0_syshub_soc_tlb2_45_reg, awuser) \
      mp0_syshub_soc_tlb2_45_reg = (mp0_syshub_soc_tlb2_45_reg & ~MP0_SYSHUB_SOC_TLB2_45_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_45_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_45_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_45_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_45_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_45_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_45_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_45_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_45_t f;
} mp0_syshub_soc_tlb2_45_u;


/*
 * MP0_SYSHUB_SOC_TLB3_45 struct
 */

#define MP0_SYSHUB_SOC_TLB3_45_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_45_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_45_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_45_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_45_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_45_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_45_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_45_MASK \
      (MP0_SYSHUB_SOC_TLB3_45_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_45_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_45_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_45_GET_ARUSER(mp0_syshub_soc_tlb3_45) \
      ((mp0_syshub_soc_tlb3_45 & MP0_SYSHUB_SOC_TLB3_45_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_45_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_45_GET_WUSER(mp0_syshub_soc_tlb3_45) \
      ((mp0_syshub_soc_tlb3_45 & MP0_SYSHUB_SOC_TLB3_45_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_45_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_45_SET_ARUSER(mp0_syshub_soc_tlb3_45_reg, aruser) \
      mp0_syshub_soc_tlb3_45_reg = (mp0_syshub_soc_tlb3_45_reg & ~MP0_SYSHUB_SOC_TLB3_45_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_45_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_45_SET_WUSER(mp0_syshub_soc_tlb3_45_reg, wuser) \
      mp0_syshub_soc_tlb3_45_reg = (mp0_syshub_soc_tlb3_45_reg & ~MP0_SYSHUB_SOC_TLB3_45_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_45_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_45_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_45_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_45_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_45_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_45_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_45_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_45_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_45_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_45_t f;
} mp0_syshub_soc_tlb3_45_u;


/*
 * MP0_SYSHUB_SOC_TLB0_46 struct
 */

#define MP0_SYSHUB_SOC_TLB0_46_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_46_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_46_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_46_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_46_MASK \
      (MP0_SYSHUB_SOC_TLB0_46_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_46_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_46_GET_SOC_ADDR(mp0_syshub_soc_tlb0_46) \
      ((mp0_syshub_soc_tlb0_46 & MP0_SYSHUB_SOC_TLB0_46_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_46_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_46_SET_SOC_ADDR(mp0_syshub_soc_tlb0_46_reg, soc_addr) \
      mp0_syshub_soc_tlb0_46_reg = (mp0_syshub_soc_tlb0_46_reg & ~MP0_SYSHUB_SOC_TLB0_46_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_46_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_46_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_46_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_46_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_46_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_46_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_46_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_46_t f;
} mp0_syshub_soc_tlb0_46_u;


/*
 * MP0_SYSHUB_SOC_TLB1_46 struct
 */

#define MP0_SYSHUB_SOC_TLB1_46_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_46_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_46_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_46_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_46_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_46_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_46_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_46_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_46_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_46_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_46_MASK \
      (MP0_SYSHUB_SOC_TLB1_46_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_46_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_46_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_46_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_46_GET_COHERENCE(mp0_syshub_soc_tlb1_46) \
      ((mp0_syshub_soc_tlb1_46 & MP0_SYSHUB_SOC_TLB1_46_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_46_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_46_GET_SEG_SIZE(mp0_syshub_soc_tlb1_46) \
      ((mp0_syshub_soc_tlb1_46 & MP0_SYSHUB_SOC_TLB1_46_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_46_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_46_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_46) \
      ((mp0_syshub_soc_tlb1_46 & MP0_SYSHUB_SOC_TLB1_46_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_46_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_46_SET_COHERENCE(mp0_syshub_soc_tlb1_46_reg, coherence) \
      mp0_syshub_soc_tlb1_46_reg = (mp0_syshub_soc_tlb1_46_reg & ~MP0_SYSHUB_SOC_TLB1_46_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_46_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_46_SET_SEG_SIZE(mp0_syshub_soc_tlb1_46_reg, seg_size) \
      mp0_syshub_soc_tlb1_46_reg = (mp0_syshub_soc_tlb1_46_reg & ~MP0_SYSHUB_SOC_TLB1_46_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_46_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_46_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_46_reg, seg_offset) \
      mp0_syshub_soc_tlb1_46_reg = (mp0_syshub_soc_tlb1_46_reg & ~MP0_SYSHUB_SOC_TLB1_46_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_46_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_46_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_46_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_46_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_46_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_46_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_46_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_46_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_46_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_46_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_46_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_46_t f;
} mp0_syshub_soc_tlb1_46_u;


/*
 * MP0_SYSHUB_SOC_TLB2_46 struct
 */

#define MP0_SYSHUB_SOC_TLB2_46_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_46_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_46_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_46_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_46_MASK \
      (MP0_SYSHUB_SOC_TLB2_46_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_46_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_46_GET_AWUSER(mp0_syshub_soc_tlb2_46) \
      ((mp0_syshub_soc_tlb2_46 & MP0_SYSHUB_SOC_TLB2_46_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_46_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_46_SET_AWUSER(mp0_syshub_soc_tlb2_46_reg, awuser) \
      mp0_syshub_soc_tlb2_46_reg = (mp0_syshub_soc_tlb2_46_reg & ~MP0_SYSHUB_SOC_TLB2_46_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_46_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_46_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_46_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_46_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_46_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_46_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_46_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_46_t f;
} mp0_syshub_soc_tlb2_46_u;


/*
 * MP0_SYSHUB_SOC_TLB3_46 struct
 */

#define MP0_SYSHUB_SOC_TLB3_46_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_46_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_46_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_46_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_46_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_46_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_46_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_46_MASK \
      (MP0_SYSHUB_SOC_TLB3_46_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_46_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_46_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_46_GET_ARUSER(mp0_syshub_soc_tlb3_46) \
      ((mp0_syshub_soc_tlb3_46 & MP0_SYSHUB_SOC_TLB3_46_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_46_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_46_GET_WUSER(mp0_syshub_soc_tlb3_46) \
      ((mp0_syshub_soc_tlb3_46 & MP0_SYSHUB_SOC_TLB3_46_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_46_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_46_SET_ARUSER(mp0_syshub_soc_tlb3_46_reg, aruser) \
      mp0_syshub_soc_tlb3_46_reg = (mp0_syshub_soc_tlb3_46_reg & ~MP0_SYSHUB_SOC_TLB3_46_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_46_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_46_SET_WUSER(mp0_syshub_soc_tlb3_46_reg, wuser) \
      mp0_syshub_soc_tlb3_46_reg = (mp0_syshub_soc_tlb3_46_reg & ~MP0_SYSHUB_SOC_TLB3_46_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_46_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_46_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_46_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_46_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_46_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_46_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_46_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_46_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_46_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_46_t f;
} mp0_syshub_soc_tlb3_46_u;


/*
 * MP0_SYSHUB_SOC_TLB0_47 struct
 */

#define MP0_SYSHUB_SOC_TLB0_47_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_47_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_47_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_47_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_47_MASK \
      (MP0_SYSHUB_SOC_TLB0_47_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_47_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_47_GET_SOC_ADDR(mp0_syshub_soc_tlb0_47) \
      ((mp0_syshub_soc_tlb0_47 & MP0_SYSHUB_SOC_TLB0_47_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_47_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_47_SET_SOC_ADDR(mp0_syshub_soc_tlb0_47_reg, soc_addr) \
      mp0_syshub_soc_tlb0_47_reg = (mp0_syshub_soc_tlb0_47_reg & ~MP0_SYSHUB_SOC_TLB0_47_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_47_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_47_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_47_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_47_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_47_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_47_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_47_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_47_t f;
} mp0_syshub_soc_tlb0_47_u;


/*
 * MP0_SYSHUB_SOC_TLB1_47 struct
 */

#define MP0_SYSHUB_SOC_TLB1_47_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_47_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_47_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_47_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_47_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_47_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_47_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_47_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_47_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_47_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_47_MASK \
      (MP0_SYSHUB_SOC_TLB1_47_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_47_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_47_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_47_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_47_GET_COHERENCE(mp0_syshub_soc_tlb1_47) \
      ((mp0_syshub_soc_tlb1_47 & MP0_SYSHUB_SOC_TLB1_47_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_47_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_47_GET_SEG_SIZE(mp0_syshub_soc_tlb1_47) \
      ((mp0_syshub_soc_tlb1_47 & MP0_SYSHUB_SOC_TLB1_47_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_47_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_47_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_47) \
      ((mp0_syshub_soc_tlb1_47 & MP0_SYSHUB_SOC_TLB1_47_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_47_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_47_SET_COHERENCE(mp0_syshub_soc_tlb1_47_reg, coherence) \
      mp0_syshub_soc_tlb1_47_reg = (mp0_syshub_soc_tlb1_47_reg & ~MP0_SYSHUB_SOC_TLB1_47_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_47_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_47_SET_SEG_SIZE(mp0_syshub_soc_tlb1_47_reg, seg_size) \
      mp0_syshub_soc_tlb1_47_reg = (mp0_syshub_soc_tlb1_47_reg & ~MP0_SYSHUB_SOC_TLB1_47_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_47_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_47_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_47_reg, seg_offset) \
      mp0_syshub_soc_tlb1_47_reg = (mp0_syshub_soc_tlb1_47_reg & ~MP0_SYSHUB_SOC_TLB1_47_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_47_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_47_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_47_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_47_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_47_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_47_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_47_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_47_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_47_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_47_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_47_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_47_t f;
} mp0_syshub_soc_tlb1_47_u;


/*
 * MP0_SYSHUB_SOC_TLB2_47 struct
 */

#define MP0_SYSHUB_SOC_TLB2_47_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_47_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_47_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_47_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_47_MASK \
      (MP0_SYSHUB_SOC_TLB2_47_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_47_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_47_GET_AWUSER(mp0_syshub_soc_tlb2_47) \
      ((mp0_syshub_soc_tlb2_47 & MP0_SYSHUB_SOC_TLB2_47_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_47_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_47_SET_AWUSER(mp0_syshub_soc_tlb2_47_reg, awuser) \
      mp0_syshub_soc_tlb2_47_reg = (mp0_syshub_soc_tlb2_47_reg & ~MP0_SYSHUB_SOC_TLB2_47_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_47_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_47_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_47_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_47_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_47_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_47_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_47_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_47_t f;
} mp0_syshub_soc_tlb2_47_u;


/*
 * MP0_SYSHUB_SOC_TLB3_47 struct
 */

#define MP0_SYSHUB_SOC_TLB3_47_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_47_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_47_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_47_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_47_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_47_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_47_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_47_MASK \
      (MP0_SYSHUB_SOC_TLB3_47_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_47_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_47_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_47_GET_ARUSER(mp0_syshub_soc_tlb3_47) \
      ((mp0_syshub_soc_tlb3_47 & MP0_SYSHUB_SOC_TLB3_47_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_47_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_47_GET_WUSER(mp0_syshub_soc_tlb3_47) \
      ((mp0_syshub_soc_tlb3_47 & MP0_SYSHUB_SOC_TLB3_47_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_47_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_47_SET_ARUSER(mp0_syshub_soc_tlb3_47_reg, aruser) \
      mp0_syshub_soc_tlb3_47_reg = (mp0_syshub_soc_tlb3_47_reg & ~MP0_SYSHUB_SOC_TLB3_47_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_47_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_47_SET_WUSER(mp0_syshub_soc_tlb3_47_reg, wuser) \
      mp0_syshub_soc_tlb3_47_reg = (mp0_syshub_soc_tlb3_47_reg & ~MP0_SYSHUB_SOC_TLB3_47_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_47_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_47_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_47_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_47_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_47_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_47_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_47_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_47_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_47_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_47_t f;
} mp0_syshub_soc_tlb3_47_u;


/*
 * MP0_SYSHUB_SOC_TLB0_48 struct
 */

#define MP0_SYSHUB_SOC_TLB0_48_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB0_48_SOC_ADDR_SIZE  22

#define MP0_SYSHUB_SOC_TLB0_48_SOC_ADDR_SHIFT  0

#define MP0_SYSHUB_SOC_TLB0_48_SOC_ADDR_MASK  0x003fffff

#define MP0_SYSHUB_SOC_TLB0_48_MASK \
      (MP0_SYSHUB_SOC_TLB0_48_SOC_ADDR_MASK)

#define MP0_SYSHUB_SOC_TLB0_48_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB0_48_GET_SOC_ADDR(mp0_syshub_soc_tlb0_48) \
      ((mp0_syshub_soc_tlb0_48 & MP0_SYSHUB_SOC_TLB0_48_SOC_ADDR_MASK) >> MP0_SYSHUB_SOC_TLB0_48_SOC_ADDR_SHIFT)

#define MP0_SYSHUB_SOC_TLB0_48_SET_SOC_ADDR(mp0_syshub_soc_tlb0_48_reg, soc_addr) \
      mp0_syshub_soc_tlb0_48_reg = (mp0_syshub_soc_tlb0_48_reg & ~MP0_SYSHUB_SOC_TLB0_48_SOC_ADDR_MASK) | (soc_addr << MP0_SYSHUB_SOC_TLB0_48_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_48_t {
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_48_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp0_syshub_soc_tlb0_48_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb0_48_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP0_SYSHUB_SOC_TLB0_48_SOC_ADDR_SIZE;
      } mp0_syshub_soc_tlb0_48_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb0_48_t f;
} mp0_syshub_soc_tlb0_48_u;


/*
 * MP0_SYSHUB_SOC_TLB1_48 struct
 */

#define MP0_SYSHUB_SOC_TLB1_48_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB1_48_COHERENCE_SIZE  1
#define MP0_SYSHUB_SOC_TLB1_48_SEG_SIZE_SIZE  4
#define MP0_SYSHUB_SOC_TLB1_48_SEG_OFFSET_SIZE  9

#define MP0_SYSHUB_SOC_TLB1_48_COHERENCE_SHIFT  0
#define MP0_SYSHUB_SOC_TLB1_48_SEG_SIZE_SHIFT  1
#define MP0_SYSHUB_SOC_TLB1_48_SEG_OFFSET_SHIFT  5

#define MP0_SYSHUB_SOC_TLB1_48_COHERENCE_MASK  0x00000001
#define MP0_SYSHUB_SOC_TLB1_48_SEG_SIZE_MASK  0x0000001e
#define MP0_SYSHUB_SOC_TLB1_48_SEG_OFFSET_MASK  0x00003fe0

#define MP0_SYSHUB_SOC_TLB1_48_MASK \
      (MP0_SYSHUB_SOC_TLB1_48_COHERENCE_MASK | \
      MP0_SYSHUB_SOC_TLB1_48_SEG_SIZE_MASK | \
      MP0_SYSHUB_SOC_TLB1_48_SEG_OFFSET_MASK)

#define MP0_SYSHUB_SOC_TLB1_48_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB1_48_GET_COHERENCE(mp0_syshub_soc_tlb1_48) \
      ((mp0_syshub_soc_tlb1_48 & MP0_SYSHUB_SOC_TLB1_48_COHERENCE_MASK) >> MP0_SYSHUB_SOC_TLB1_48_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_48_GET_SEG_SIZE(mp0_syshub_soc_tlb1_48) \
      ((mp0_syshub_soc_tlb1_48 & MP0_SYSHUB_SOC_TLB1_48_SEG_SIZE_MASK) >> MP0_SYSHUB_SOC_TLB1_48_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_48_GET_SEG_OFFSET(mp0_syshub_soc_tlb1_48) \
      ((mp0_syshub_soc_tlb1_48 & MP0_SYSHUB_SOC_TLB1_48_SEG_OFFSET_MASK) >> MP0_SYSHUB_SOC_TLB1_48_SEG_OFFSET_SHIFT)

#define MP0_SYSHUB_SOC_TLB1_48_SET_COHERENCE(mp0_syshub_soc_tlb1_48_reg, coherence) \
      mp0_syshub_soc_tlb1_48_reg = (mp0_syshub_soc_tlb1_48_reg & ~MP0_SYSHUB_SOC_TLB1_48_COHERENCE_MASK) | (coherence << MP0_SYSHUB_SOC_TLB1_48_COHERENCE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_48_SET_SEG_SIZE(mp0_syshub_soc_tlb1_48_reg, seg_size) \
      mp0_syshub_soc_tlb1_48_reg = (mp0_syshub_soc_tlb1_48_reg & ~MP0_SYSHUB_SOC_TLB1_48_SEG_SIZE_MASK) | (seg_size << MP0_SYSHUB_SOC_TLB1_48_SEG_SIZE_SHIFT)
#define MP0_SYSHUB_SOC_TLB1_48_SET_SEG_OFFSET(mp0_syshub_soc_tlb1_48_reg, seg_offset) \
      mp0_syshub_soc_tlb1_48_reg = (mp0_syshub_soc_tlb1_48_reg & ~MP0_SYSHUB_SOC_TLB1_48_SEG_OFFSET_MASK) | (seg_offset << MP0_SYSHUB_SOC_TLB1_48_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_48_t {
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_48_COHERENCE_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_48_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_48_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp0_syshub_soc_tlb1_48_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb1_48_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP0_SYSHUB_SOC_TLB1_48_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP0_SYSHUB_SOC_TLB1_48_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP0_SYSHUB_SOC_TLB1_48_COHERENCE_SIZE;
      } mp0_syshub_soc_tlb1_48_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb1_48_t f;
} mp0_syshub_soc_tlb1_48_u;


/*
 * MP0_SYSHUB_SOC_TLB2_48 struct
 */

#define MP0_SYSHUB_SOC_TLB2_48_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB2_48_AWUSER_SIZE  32

#define MP0_SYSHUB_SOC_TLB2_48_AWUSER_SHIFT  0

#define MP0_SYSHUB_SOC_TLB2_48_AWUSER_MASK  0xffffffff

#define MP0_SYSHUB_SOC_TLB2_48_MASK \
      (MP0_SYSHUB_SOC_TLB2_48_AWUSER_MASK)

#define MP0_SYSHUB_SOC_TLB2_48_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB2_48_GET_AWUSER(mp0_syshub_soc_tlb2_48) \
      ((mp0_syshub_soc_tlb2_48 & MP0_SYSHUB_SOC_TLB2_48_AWUSER_MASK) >> MP0_SYSHUB_SOC_TLB2_48_AWUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB2_48_SET_AWUSER(mp0_syshub_soc_tlb2_48_reg, awuser) \
      mp0_syshub_soc_tlb2_48_reg = (mp0_syshub_soc_tlb2_48_reg & ~MP0_SYSHUB_SOC_TLB2_48_AWUSER_MASK) | (awuser << MP0_SYSHUB_SOC_TLB2_48_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_48_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_48_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_48_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb2_48_t {
            unsigned int awuser                         : MP0_SYSHUB_SOC_TLB2_48_AWUSER_SIZE;
      } mp0_syshub_soc_tlb2_48_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb2_48_t f;
} mp0_syshub_soc_tlb2_48_u;


/*
 * MP0_SYSHUB_SOC_TLB3_48 struct
 */

#define MP0_SYSHUB_SOC_TLB3_48_REG_SIZE         32
#define MP0_SYSHUB_SOC_TLB3_48_ARUSER_SIZE  6
#define MP0_SYSHUB_SOC_TLB3_48_WUSER_SIZE  4

#define MP0_SYSHUB_SOC_TLB3_48_ARUSER_SHIFT  0
#define MP0_SYSHUB_SOC_TLB3_48_WUSER_SHIFT  6

#define MP0_SYSHUB_SOC_TLB3_48_ARUSER_MASK  0x0000003f
#define MP0_SYSHUB_SOC_TLB3_48_WUSER_MASK  0x000003c0

#define MP0_SYSHUB_SOC_TLB3_48_MASK \
      (MP0_SYSHUB_SOC_TLB3_48_ARUSER_MASK | \
      MP0_SYSHUB_SOC_TLB3_48_WUSER_MASK)

#define MP0_SYSHUB_SOC_TLB3_48_DEFAULT 0x00000000

#define MP0_SYSHUB_SOC_TLB3_48_GET_ARUSER(mp0_syshub_soc_tlb3_48) \
      ((mp0_syshub_soc_tlb3_48 & MP0_SYSHUB_SOC_TLB3_48_ARUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_48_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_48_GET_WUSER(mp0_syshub_soc_tlb3_48) \
      ((mp0_syshub_soc_tlb3_48 & MP0_SYSHUB_SOC_TLB3_48_WUSER_MASK) >> MP0_SYSHUB_SOC_TLB3_48_WUSER_SHIFT)

#define MP0_SYSHUB_SOC_TLB3_48_SET_ARUSER(mp0_syshub_soc_tlb3_48_reg, aruser) \
      mp0_syshub_soc_tlb3_48_reg = (mp0_syshub_soc_tlb3_48_reg & ~MP0_SYSHUB_SOC_TLB3_48_ARUSER_MASK) | (aruser << MP0_SYSHUB_SOC_TLB3_48_ARUSER_SHIFT)
#define MP0_SYSHUB_SOC_TLB3_48_SET_WUSER(mp0_syshub_soc_tlb3_48_reg, wuser) \
      mp0_syshub_soc_tlb3_48_reg = (mp0_syshub_soc_tlb3_48_reg & ~MP0_SYSHUB_SOC_TLB3_48_WUSER_MASK) | (wuser << MP0_SYSHUB_SOC_TLB3_48_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_48_t {
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_48_ARUSER_SIZE;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_48_WUSER_SIZE;
            unsigned int                                : 22;
      } mp0_syshub_soc_tlb3_48_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_soc_tlb3_48_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MP0_SYSHUB_SOC_TLB3_48_WUSER_SIZE;
            unsigned int aruser                         : MP0_SYSHUB_SOC_TLB3_48_ARUSER_SIZE;
      } mp0_syshub_soc_tlb3_48_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_soc_tlb3_48_t f;
} mp0_syshub_soc_tlb3_48_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_1) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_1 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_1_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_1_reg = (mp0_syshub_tlb_sub_page_attribute_rw_1_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_1_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_1_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_1_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_1_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_2) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_2 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_2_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_2_reg = (mp0_syshub_tlb_sub_page_attribute_rw_2_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_2_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_2_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_2_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_2_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_3) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_3 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_3_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_3_reg = (mp0_syshub_tlb_sub_page_attribute_rw_3_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_3_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_3_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_3_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_3_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_4) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_4 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_4_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_4_reg = (mp0_syshub_tlb_sub_page_attribute_rw_4_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_4_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_4_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_4_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_4_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_5) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_5 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_5_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_5_reg = (mp0_syshub_tlb_sub_page_attribute_rw_5_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_5_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_5_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_5_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_5_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_6) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_6 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_6_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_6_reg = (mp0_syshub_tlb_sub_page_attribute_rw_6_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_6_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_6_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_6_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_6_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_7) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_7 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_7_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_7_reg = (mp0_syshub_tlb_sub_page_attribute_rw_7_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_7_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_7_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_7_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_7_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_8) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_8 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_8_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_8_reg = (mp0_syshub_tlb_sub_page_attribute_rw_8_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_8_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_8_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_8_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_8_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_9) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_9 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_9_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_9_reg = (mp0_syshub_tlb_sub_page_attribute_rw_9_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_9_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_9_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_9_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_9_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_10) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_10 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_10_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_10_reg = (mp0_syshub_tlb_sub_page_attribute_rw_10_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_10_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_10_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_10_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_10_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_11) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_11 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_11_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_11_reg = (mp0_syshub_tlb_sub_page_attribute_rw_11_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_11_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_11_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_11_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_11_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_12) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_12 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_12_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_12_reg = (mp0_syshub_tlb_sub_page_attribute_rw_12_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_12_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_12_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_12_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_12_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_13) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_13 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_13_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_13_reg = (mp0_syshub_tlb_sub_page_attribute_rw_13_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_13_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_13_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_13_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_13_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_14) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_14 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_14_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_14_reg = (mp0_syshub_tlb_sub_page_attribute_rw_14_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_14_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_14_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_14_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_14_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_14_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_15) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_15 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_15_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_15_reg = (mp0_syshub_tlb_sub_page_attribute_rw_15_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_15_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_15_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_15_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_15_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_15_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_16) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_16 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_16_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_16_reg = (mp0_syshub_tlb_sub_page_attribute_rw_16_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_16_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_16_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_16_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_16_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_16_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_16_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_17) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_17 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_17_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_17_reg = (mp0_syshub_tlb_sub_page_attribute_rw_17_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_17_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_17_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_17_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_17_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_17_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_17_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_18) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_18 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_18_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_18_reg = (mp0_syshub_tlb_sub_page_attribute_rw_18_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_18_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_18_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_18_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_18_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_18_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_18_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_19) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_19 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_19_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_19_reg = (mp0_syshub_tlb_sub_page_attribute_rw_19_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_19_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_19_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_19_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_19_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_19_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_19_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_20) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_20 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_20_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_20_reg = (mp0_syshub_tlb_sub_page_attribute_rw_20_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_20_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_20_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_20_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_20_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_20_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_20_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_21) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_21 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_21_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_21_reg = (mp0_syshub_tlb_sub_page_attribute_rw_21_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_21_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_21_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_21_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_21_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_21_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_21_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_22) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_22 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_22_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_22_reg = (mp0_syshub_tlb_sub_page_attribute_rw_22_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_22_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_22_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_22_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_22_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_22_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_22_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_23) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_23 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_23_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_23_reg = (mp0_syshub_tlb_sub_page_attribute_rw_23_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_23_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_23_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_23_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_23_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_23_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_23_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_24) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_24 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_24_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_24_reg = (mp0_syshub_tlb_sub_page_attribute_rw_24_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_24_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_24_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_24_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_24_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_24_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_24_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_25) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_25 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_25_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_25_reg = (mp0_syshub_tlb_sub_page_attribute_rw_25_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_25_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_25_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_25_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_25_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_25_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_25_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_26) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_26 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_26_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_26_reg = (mp0_syshub_tlb_sub_page_attribute_rw_26_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_26_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_26_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_26_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_26_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_26_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_26_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_27) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_27 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_27_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_27_reg = (mp0_syshub_tlb_sub_page_attribute_rw_27_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_27_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_27_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_27_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_27_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_27_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_27_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_28) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_28 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_28_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_28_reg = (mp0_syshub_tlb_sub_page_attribute_rw_28_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_28_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_28_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_28_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_28_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_28_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_28_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_29) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_29 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_29_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_29_reg = (mp0_syshub_tlb_sub_page_attribute_rw_29_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_29_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_29_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_29_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_29_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_29_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_29_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_30) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_30 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_30_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_30_reg = (mp0_syshub_tlb_sub_page_attribute_rw_30_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_30_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_30_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_30_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_30_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_30_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_30_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_31) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_31 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_31_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_31_reg = (mp0_syshub_tlb_sub_page_attribute_rw_31_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_31_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_31_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_31_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_31_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_31_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_31_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_32 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_32_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_32_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_32_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_32_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_32_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_32_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_32_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_32_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_32) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_32 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_32_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_32_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_32_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_32_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_32_reg = (mp0_syshub_tlb_sub_page_attribute_rw_32_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_32_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_32_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_32_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_32_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_32_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_32_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_32_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_32_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_32_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_32_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_33 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_33_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_33_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_33_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_33_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_33_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_33_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_33_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_33_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_33) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_33 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_33_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_33_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_33_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_33_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_33_reg = (mp0_syshub_tlb_sub_page_attribute_rw_33_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_33_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_33_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_33_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_33_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_33_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_33_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_33_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_33_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_33_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_33_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_34 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_34_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_34_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_34_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_34_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_34_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_34_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_34_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_34_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_34) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_34 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_34_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_34_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_34_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_34_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_34_reg = (mp0_syshub_tlb_sub_page_attribute_rw_34_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_34_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_34_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_34_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_34_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_34_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_34_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_34_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_34_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_34_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_34_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_35 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_35_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_35_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_35_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_35_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_35_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_35_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_35_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_35_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_35) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_35 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_35_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_35_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_35_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_35_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_35_reg = (mp0_syshub_tlb_sub_page_attribute_rw_35_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_35_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_35_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_35_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_35_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_35_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_35_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_35_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_35_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_35_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_35_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_36 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_36_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_36_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_36_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_36_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_36_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_36_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_36_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_36_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_36) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_36 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_36_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_36_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_36_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_36_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_36_reg = (mp0_syshub_tlb_sub_page_attribute_rw_36_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_36_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_36_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_36_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_36_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_36_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_36_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_36_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_36_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_36_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_36_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_37 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_37_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_37_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_37_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_37_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_37_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_37_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_37_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_37_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_37) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_37 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_37_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_37_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_37_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_37_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_37_reg = (mp0_syshub_tlb_sub_page_attribute_rw_37_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_37_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_37_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_37_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_37_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_37_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_37_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_37_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_37_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_37_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_37_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_38 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_38_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_38_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_38_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_38_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_38_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_38_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_38_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_38_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_38) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_38 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_38_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_38_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_38_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_38_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_38_reg = (mp0_syshub_tlb_sub_page_attribute_rw_38_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_38_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_38_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_38_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_38_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_38_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_38_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_38_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_38_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_38_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_38_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_39 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_39_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_39_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_39_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_39_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_39_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_39_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_39_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_39_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_39) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_39 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_39_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_39_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_39_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_39_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_39_reg = (mp0_syshub_tlb_sub_page_attribute_rw_39_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_39_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_39_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_39_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_39_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_39_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_39_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_39_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_39_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_39_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_39_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_40 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_40_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_40_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_40_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_40_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_40_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_40_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_40_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_40_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_40) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_40 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_40_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_40_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_40_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_40_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_40_reg = (mp0_syshub_tlb_sub_page_attribute_rw_40_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_40_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_40_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_40_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_40_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_40_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_40_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_40_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_40_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_40_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_40_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_41 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_41_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_41_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_41_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_41_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_41_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_41_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_41_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_41_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_41) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_41 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_41_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_41_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_41_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_41_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_41_reg = (mp0_syshub_tlb_sub_page_attribute_rw_41_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_41_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_41_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_41_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_41_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_41_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_41_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_41_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_41_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_41_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_41_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_42 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_42_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_42_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_42_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_42_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_42_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_42_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_42_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_42_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_42) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_42 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_42_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_42_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_42_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_42_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_42_reg = (mp0_syshub_tlb_sub_page_attribute_rw_42_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_42_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_42_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_42_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_42_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_42_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_42_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_42_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_42_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_42_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_42_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_43 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_43_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_43_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_43_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_43_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_43_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_43_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_43_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_43_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_43) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_43 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_43_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_43_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_43_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_43_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_43_reg = (mp0_syshub_tlb_sub_page_attribute_rw_43_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_43_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_43_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_43_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_43_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_43_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_43_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_43_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_43_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_43_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_43_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_44 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_44_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_44_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_44_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_44_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_44_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_44_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_44_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_44_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_44) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_44 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_44_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_44_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_44_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_44_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_44_reg = (mp0_syshub_tlb_sub_page_attribute_rw_44_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_44_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_44_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_44_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_44_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_44_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_44_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_44_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_44_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_44_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_44_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_45 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_45_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_45_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_45_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_45_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_45_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_45_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_45_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_45_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_45) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_45 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_45_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_45_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_45_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_45_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_45_reg = (mp0_syshub_tlb_sub_page_attribute_rw_45_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_45_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_45_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_45_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_45_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_45_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_45_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_45_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_45_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_45_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_45_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_46 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_46_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_46_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_46_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_46_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_46_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_46_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_46_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_46_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_46) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_46 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_46_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_46_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_46_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_46_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_46_reg = (mp0_syshub_tlb_sub_page_attribute_rw_46_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_46_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_46_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_46_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_46_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_46_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_46_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_46_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_46_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_46_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_46_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_47 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_47_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_47_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_47_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_47_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_47_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_47_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_47_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_47_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_47) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_47 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_47_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_47_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_47_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_47_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_47_reg = (mp0_syshub_tlb_sub_page_attribute_rw_47_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_47_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_47_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_47_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_47_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_47_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_47_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_47_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_47_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_47_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_47_u;


/*
 * MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_48 struct
 */

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_48_REG_SIZE         32
#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_48_RW_ATTRIB_SIZE  32

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_48_RW_ATTRIB_SHIFT  0

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_48_RW_ATTRIB_MASK  0xffffffff

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_48_MASK \
      (MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_48_RW_ATTRIB_MASK)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_48_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_48_GET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_48) \
      ((mp0_syshub_tlb_sub_page_attribute_rw_48 & MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_48_RW_ATTRIB_MASK) >> MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_48_RW_ATTRIB_SHIFT)

#define MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_48_SET_RW_ATTRIB(mp0_syshub_tlb_sub_page_attribute_rw_48_reg, rw_attrib) \
      mp0_syshub_tlb_sub_page_attribute_rw_48_reg = (mp0_syshub_tlb_sub_page_attribute_rw_48_reg & ~MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_48_RW_ATTRIB_MASK) | (rw_attrib << MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_48_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_48_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_48_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_48_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_sub_page_attribute_rw_48_t {
            unsigned int rw_attrib                      : MP0_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_48_RW_ATTRIB_SIZE;
      } mp0_syshub_tlb_sub_page_attribute_rw_48_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_sub_page_attribute_rw_48_t f;
} mp0_syshub_tlb_sub_page_attribute_rw_48_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_1 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_1_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_1_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_1_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_1_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_1) \
      ((mp0_syshub_tlb_attribute_1 & MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_1) \
      ((mp0_syshub_tlb_attribute_1 & MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_1) \
      ((mp0_syshub_tlb_attribute_1 & MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_1) \
      ((mp0_syshub_tlb_attribute_1 & MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_1) \
      ((mp0_syshub_tlb_attribute_1 & MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_1) \
      ((mp0_syshub_tlb_attribute_1 & MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_1) \
      ((mp0_syshub_tlb_attribute_1 & MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_1_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_1_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_1_reg = (mp0_syshub_tlb_attribute_1_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_1_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_1_reg = (mp0_syshub_tlb_attribute_1_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_1_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_1_reg = (mp0_syshub_tlb_attribute_1_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_1_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_1_reg = (mp0_syshub_tlb_attribute_1_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_1_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_1_reg = (mp0_syshub_tlb_attribute_1_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_1_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_1_reg = (mp0_syshub_tlb_attribute_1_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_1_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_1_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_1_reg = (mp0_syshub_tlb_attribute_1_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_1_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_1_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_1_t f;
} mp0_syshub_tlb_attribute_1_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_2 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_2_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_2_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_2_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_2_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_2) \
      ((mp0_syshub_tlb_attribute_2 & MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_2) \
      ((mp0_syshub_tlb_attribute_2 & MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_2) \
      ((mp0_syshub_tlb_attribute_2 & MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_2) \
      ((mp0_syshub_tlb_attribute_2 & MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_2) \
      ((mp0_syshub_tlb_attribute_2 & MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_2) \
      ((mp0_syshub_tlb_attribute_2 & MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_2) \
      ((mp0_syshub_tlb_attribute_2 & MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_2_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_2_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_2_reg = (mp0_syshub_tlb_attribute_2_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_2_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_2_reg = (mp0_syshub_tlb_attribute_2_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_2_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_2_reg = (mp0_syshub_tlb_attribute_2_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_2_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_2_reg = (mp0_syshub_tlb_attribute_2_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_2_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_2_reg = (mp0_syshub_tlb_attribute_2_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_2_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_2_reg = (mp0_syshub_tlb_attribute_2_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_2_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_2_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_2_reg = (mp0_syshub_tlb_attribute_2_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_2_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_2_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_2_t f;
} mp0_syshub_tlb_attribute_2_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_3 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_3_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_3_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_3_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_3_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_3) \
      ((mp0_syshub_tlb_attribute_3 & MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_3) \
      ((mp0_syshub_tlb_attribute_3 & MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_3) \
      ((mp0_syshub_tlb_attribute_3 & MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_3) \
      ((mp0_syshub_tlb_attribute_3 & MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_3) \
      ((mp0_syshub_tlb_attribute_3 & MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_3) \
      ((mp0_syshub_tlb_attribute_3 & MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_3) \
      ((mp0_syshub_tlb_attribute_3 & MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_3_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_3_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_3_reg = (mp0_syshub_tlb_attribute_3_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_3_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_3_reg = (mp0_syshub_tlb_attribute_3_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_3_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_3_reg = (mp0_syshub_tlb_attribute_3_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_3_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_3_reg = (mp0_syshub_tlb_attribute_3_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_3_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_3_reg = (mp0_syshub_tlb_attribute_3_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_3_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_3_reg = (mp0_syshub_tlb_attribute_3_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_3_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_3_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_3_reg = (mp0_syshub_tlb_attribute_3_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_3_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_3_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_3_t f;
} mp0_syshub_tlb_attribute_3_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_4 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_4_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_4_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_4_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_4_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_4) \
      ((mp0_syshub_tlb_attribute_4 & MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_4) \
      ((mp0_syshub_tlb_attribute_4 & MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_4) \
      ((mp0_syshub_tlb_attribute_4 & MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_4) \
      ((mp0_syshub_tlb_attribute_4 & MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_4) \
      ((mp0_syshub_tlb_attribute_4 & MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_4) \
      ((mp0_syshub_tlb_attribute_4 & MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_4) \
      ((mp0_syshub_tlb_attribute_4 & MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_4_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_4_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_4_reg = (mp0_syshub_tlb_attribute_4_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_4_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_4_reg = (mp0_syshub_tlb_attribute_4_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_4_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_4_reg = (mp0_syshub_tlb_attribute_4_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_4_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_4_reg = (mp0_syshub_tlb_attribute_4_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_4_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_4_reg = (mp0_syshub_tlb_attribute_4_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_4_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_4_reg = (mp0_syshub_tlb_attribute_4_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_4_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_4_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_4_reg = (mp0_syshub_tlb_attribute_4_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_4_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_4_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_4_t f;
} mp0_syshub_tlb_attribute_4_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_5 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_5_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_5_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_5_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_5_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_5) \
      ((mp0_syshub_tlb_attribute_5 & MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_5) \
      ((mp0_syshub_tlb_attribute_5 & MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_5) \
      ((mp0_syshub_tlb_attribute_5 & MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_5) \
      ((mp0_syshub_tlb_attribute_5 & MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_5) \
      ((mp0_syshub_tlb_attribute_5 & MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_5) \
      ((mp0_syshub_tlb_attribute_5 & MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_5) \
      ((mp0_syshub_tlb_attribute_5 & MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_5_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_5_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_5_reg = (mp0_syshub_tlb_attribute_5_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_5_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_5_reg = (mp0_syshub_tlb_attribute_5_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_5_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_5_reg = (mp0_syshub_tlb_attribute_5_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_5_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_5_reg = (mp0_syshub_tlb_attribute_5_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_5_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_5_reg = (mp0_syshub_tlb_attribute_5_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_5_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_5_reg = (mp0_syshub_tlb_attribute_5_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_5_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_5_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_5_reg = (mp0_syshub_tlb_attribute_5_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_5_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_5_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_5_t f;
} mp0_syshub_tlb_attribute_5_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_6 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_6_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_6_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_6_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_6_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_6) \
      ((mp0_syshub_tlb_attribute_6 & MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_6) \
      ((mp0_syshub_tlb_attribute_6 & MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_6) \
      ((mp0_syshub_tlb_attribute_6 & MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_6) \
      ((mp0_syshub_tlb_attribute_6 & MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_6) \
      ((mp0_syshub_tlb_attribute_6 & MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_6) \
      ((mp0_syshub_tlb_attribute_6 & MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_6) \
      ((mp0_syshub_tlb_attribute_6 & MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_6_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_6_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_6_reg = (mp0_syshub_tlb_attribute_6_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_6_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_6_reg = (mp0_syshub_tlb_attribute_6_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_6_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_6_reg = (mp0_syshub_tlb_attribute_6_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_6_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_6_reg = (mp0_syshub_tlb_attribute_6_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_6_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_6_reg = (mp0_syshub_tlb_attribute_6_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_6_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_6_reg = (mp0_syshub_tlb_attribute_6_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_6_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_6_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_6_reg = (mp0_syshub_tlb_attribute_6_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_6_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_6_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_6_t f;
} mp0_syshub_tlb_attribute_6_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_7 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_7_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_7_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_7_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_7_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_7) \
      ((mp0_syshub_tlb_attribute_7 & MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_7) \
      ((mp0_syshub_tlb_attribute_7 & MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_7) \
      ((mp0_syshub_tlb_attribute_7 & MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_7) \
      ((mp0_syshub_tlb_attribute_7 & MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_7) \
      ((mp0_syshub_tlb_attribute_7 & MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_7) \
      ((mp0_syshub_tlb_attribute_7 & MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_7) \
      ((mp0_syshub_tlb_attribute_7 & MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_7_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_7_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_7_reg = (mp0_syshub_tlb_attribute_7_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_7_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_7_reg = (mp0_syshub_tlb_attribute_7_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_7_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_7_reg = (mp0_syshub_tlb_attribute_7_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_7_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_7_reg = (mp0_syshub_tlb_attribute_7_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_7_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_7_reg = (mp0_syshub_tlb_attribute_7_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_7_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_7_reg = (mp0_syshub_tlb_attribute_7_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_7_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_7_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_7_reg = (mp0_syshub_tlb_attribute_7_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_7_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_7_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_7_t f;
} mp0_syshub_tlb_attribute_7_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_8 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_8_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_8_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_8_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_8_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_8) \
      ((mp0_syshub_tlb_attribute_8 & MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_8) \
      ((mp0_syshub_tlb_attribute_8 & MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_8) \
      ((mp0_syshub_tlb_attribute_8 & MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_8) \
      ((mp0_syshub_tlb_attribute_8 & MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_8) \
      ((mp0_syshub_tlb_attribute_8 & MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_8) \
      ((mp0_syshub_tlb_attribute_8 & MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_8) \
      ((mp0_syshub_tlb_attribute_8 & MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_8_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_8_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_8_reg = (mp0_syshub_tlb_attribute_8_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_8_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_8_reg = (mp0_syshub_tlb_attribute_8_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_8_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_8_reg = (mp0_syshub_tlb_attribute_8_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_8_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_8_reg = (mp0_syshub_tlb_attribute_8_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_8_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_8_reg = (mp0_syshub_tlb_attribute_8_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_8_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_8_reg = (mp0_syshub_tlb_attribute_8_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_8_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_8_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_8_reg = (mp0_syshub_tlb_attribute_8_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_8_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_8_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_8_t f;
} mp0_syshub_tlb_attribute_8_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_9 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_9_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_9_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_9_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_9_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_9) \
      ((mp0_syshub_tlb_attribute_9 & MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_9) \
      ((mp0_syshub_tlb_attribute_9 & MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_9) \
      ((mp0_syshub_tlb_attribute_9 & MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_9) \
      ((mp0_syshub_tlb_attribute_9 & MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_9) \
      ((mp0_syshub_tlb_attribute_9 & MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_9) \
      ((mp0_syshub_tlb_attribute_9 & MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_9) \
      ((mp0_syshub_tlb_attribute_9 & MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_9_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_9_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_9_reg = (mp0_syshub_tlb_attribute_9_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_9_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_9_reg = (mp0_syshub_tlb_attribute_9_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_9_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_9_reg = (mp0_syshub_tlb_attribute_9_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_9_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_9_reg = (mp0_syshub_tlb_attribute_9_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_9_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_9_reg = (mp0_syshub_tlb_attribute_9_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_9_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_9_reg = (mp0_syshub_tlb_attribute_9_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_9_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_9_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_9_reg = (mp0_syshub_tlb_attribute_9_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_9_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_9_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_9_t f;
} mp0_syshub_tlb_attribute_9_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_10 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_10_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_10_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_10_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_10_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_10) \
      ((mp0_syshub_tlb_attribute_10 & MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_10) \
      ((mp0_syshub_tlb_attribute_10 & MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_10) \
      ((mp0_syshub_tlb_attribute_10 & MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_10) \
      ((mp0_syshub_tlb_attribute_10 & MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_10) \
      ((mp0_syshub_tlb_attribute_10 & MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_10) \
      ((mp0_syshub_tlb_attribute_10 & MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_10) \
      ((mp0_syshub_tlb_attribute_10 & MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_10_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_10_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_10_reg = (mp0_syshub_tlb_attribute_10_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_10_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_10_reg = (mp0_syshub_tlb_attribute_10_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_10_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_10_reg = (mp0_syshub_tlb_attribute_10_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_10_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_10_reg = (mp0_syshub_tlb_attribute_10_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_10_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_10_reg = (mp0_syshub_tlb_attribute_10_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_10_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_10_reg = (mp0_syshub_tlb_attribute_10_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_10_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_10_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_10_reg = (mp0_syshub_tlb_attribute_10_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_10_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_10_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_10_t f;
} mp0_syshub_tlb_attribute_10_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_11 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_11_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_11_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_11_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_11_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_11) \
      ((mp0_syshub_tlb_attribute_11 & MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_11) \
      ((mp0_syshub_tlb_attribute_11 & MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_11) \
      ((mp0_syshub_tlb_attribute_11 & MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_11) \
      ((mp0_syshub_tlb_attribute_11 & MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_11) \
      ((mp0_syshub_tlb_attribute_11 & MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_11) \
      ((mp0_syshub_tlb_attribute_11 & MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_11) \
      ((mp0_syshub_tlb_attribute_11 & MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_11_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_11_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_11_reg = (mp0_syshub_tlb_attribute_11_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_11_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_11_reg = (mp0_syshub_tlb_attribute_11_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_11_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_11_reg = (mp0_syshub_tlb_attribute_11_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_11_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_11_reg = (mp0_syshub_tlb_attribute_11_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_11_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_11_reg = (mp0_syshub_tlb_attribute_11_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_11_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_11_reg = (mp0_syshub_tlb_attribute_11_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_11_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_11_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_11_reg = (mp0_syshub_tlb_attribute_11_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_11_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_11_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_11_t f;
} mp0_syshub_tlb_attribute_11_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_12 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_12_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_12_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_12_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_12_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_12) \
      ((mp0_syshub_tlb_attribute_12 & MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_12) \
      ((mp0_syshub_tlb_attribute_12 & MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_12) \
      ((mp0_syshub_tlb_attribute_12 & MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_12) \
      ((mp0_syshub_tlb_attribute_12 & MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_12) \
      ((mp0_syshub_tlb_attribute_12 & MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_12) \
      ((mp0_syshub_tlb_attribute_12 & MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_12) \
      ((mp0_syshub_tlb_attribute_12 & MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_12_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_12_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_12_reg = (mp0_syshub_tlb_attribute_12_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_12_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_12_reg = (mp0_syshub_tlb_attribute_12_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_12_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_12_reg = (mp0_syshub_tlb_attribute_12_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_12_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_12_reg = (mp0_syshub_tlb_attribute_12_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_12_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_12_reg = (mp0_syshub_tlb_attribute_12_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_12_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_12_reg = (mp0_syshub_tlb_attribute_12_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_12_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_12_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_12_reg = (mp0_syshub_tlb_attribute_12_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_12_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_12_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_12_t f;
} mp0_syshub_tlb_attribute_12_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_13 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_13_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_13_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_13_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_13_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_13) \
      ((mp0_syshub_tlb_attribute_13 & MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_13) \
      ((mp0_syshub_tlb_attribute_13 & MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_13) \
      ((mp0_syshub_tlb_attribute_13 & MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_13) \
      ((mp0_syshub_tlb_attribute_13 & MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_13) \
      ((mp0_syshub_tlb_attribute_13 & MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_13) \
      ((mp0_syshub_tlb_attribute_13 & MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_13) \
      ((mp0_syshub_tlb_attribute_13 & MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_13_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_13_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_13_reg = (mp0_syshub_tlb_attribute_13_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_13_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_13_reg = (mp0_syshub_tlb_attribute_13_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_13_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_13_reg = (mp0_syshub_tlb_attribute_13_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_13_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_13_reg = (mp0_syshub_tlb_attribute_13_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_13_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_13_reg = (mp0_syshub_tlb_attribute_13_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_13_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_13_reg = (mp0_syshub_tlb_attribute_13_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_13_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_13_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_13_reg = (mp0_syshub_tlb_attribute_13_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_13_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_13_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_13_t f;
} mp0_syshub_tlb_attribute_13_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_14 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_14_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_14_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_14_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_14_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_14) \
      ((mp0_syshub_tlb_attribute_14 & MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_14) \
      ((mp0_syshub_tlb_attribute_14 & MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_14) \
      ((mp0_syshub_tlb_attribute_14 & MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_14) \
      ((mp0_syshub_tlb_attribute_14 & MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_14) \
      ((mp0_syshub_tlb_attribute_14 & MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_14) \
      ((mp0_syshub_tlb_attribute_14 & MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_14) \
      ((mp0_syshub_tlb_attribute_14 & MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_14_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_14_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_14_reg = (mp0_syshub_tlb_attribute_14_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_14_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_14_reg = (mp0_syshub_tlb_attribute_14_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_14_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_14_reg = (mp0_syshub_tlb_attribute_14_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_14_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_14_reg = (mp0_syshub_tlb_attribute_14_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_14_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_14_reg = (mp0_syshub_tlb_attribute_14_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_14_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_14_reg = (mp0_syshub_tlb_attribute_14_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_14_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_14_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_14_reg = (mp0_syshub_tlb_attribute_14_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_14_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_14_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_14_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_14_t f;
} mp0_syshub_tlb_attribute_14_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_15 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_15_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_15_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_15_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_15_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_15) \
      ((mp0_syshub_tlb_attribute_15 & MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_15) \
      ((mp0_syshub_tlb_attribute_15 & MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_15) \
      ((mp0_syshub_tlb_attribute_15 & MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_15) \
      ((mp0_syshub_tlb_attribute_15 & MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_15) \
      ((mp0_syshub_tlb_attribute_15 & MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_15) \
      ((mp0_syshub_tlb_attribute_15 & MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_15) \
      ((mp0_syshub_tlb_attribute_15 & MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_15_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_15_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_15_reg = (mp0_syshub_tlb_attribute_15_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_15_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_15_reg = (mp0_syshub_tlb_attribute_15_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_15_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_15_reg = (mp0_syshub_tlb_attribute_15_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_15_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_15_reg = (mp0_syshub_tlb_attribute_15_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_15_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_15_reg = (mp0_syshub_tlb_attribute_15_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_15_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_15_reg = (mp0_syshub_tlb_attribute_15_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_15_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_15_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_15_reg = (mp0_syshub_tlb_attribute_15_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_15_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_15_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_15_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_15_t f;
} mp0_syshub_tlb_attribute_15_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_16 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_16_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_16_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_16_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_16_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_16) \
      ((mp0_syshub_tlb_attribute_16 & MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_16) \
      ((mp0_syshub_tlb_attribute_16 & MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_16) \
      ((mp0_syshub_tlb_attribute_16 & MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_16) \
      ((mp0_syshub_tlb_attribute_16 & MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_16) \
      ((mp0_syshub_tlb_attribute_16 & MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_16) \
      ((mp0_syshub_tlb_attribute_16 & MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_16) \
      ((mp0_syshub_tlb_attribute_16 & MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_16_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_16_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_16_reg = (mp0_syshub_tlb_attribute_16_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_16_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_16_reg = (mp0_syshub_tlb_attribute_16_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_16_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_16_reg = (mp0_syshub_tlb_attribute_16_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_16_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_16_reg = (mp0_syshub_tlb_attribute_16_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_16_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_16_reg = (mp0_syshub_tlb_attribute_16_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_16_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_16_reg = (mp0_syshub_tlb_attribute_16_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_16_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_16_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_16_reg = (mp0_syshub_tlb_attribute_16_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_16_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_16_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_16_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_16_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_16_t f;
} mp0_syshub_tlb_attribute_16_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_17 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_17_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_17_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_17_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_17_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_17) \
      ((mp0_syshub_tlb_attribute_17 & MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_17) \
      ((mp0_syshub_tlb_attribute_17 & MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_17) \
      ((mp0_syshub_tlb_attribute_17 & MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_17) \
      ((mp0_syshub_tlb_attribute_17 & MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_17) \
      ((mp0_syshub_tlb_attribute_17 & MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_17) \
      ((mp0_syshub_tlb_attribute_17 & MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_17) \
      ((mp0_syshub_tlb_attribute_17 & MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_17_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_17_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_17_reg = (mp0_syshub_tlb_attribute_17_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_17_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_17_reg = (mp0_syshub_tlb_attribute_17_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_17_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_17_reg = (mp0_syshub_tlb_attribute_17_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_17_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_17_reg = (mp0_syshub_tlb_attribute_17_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_17_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_17_reg = (mp0_syshub_tlb_attribute_17_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_17_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_17_reg = (mp0_syshub_tlb_attribute_17_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_17_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_17_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_17_reg = (mp0_syshub_tlb_attribute_17_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_17_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_17_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_17_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_17_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_17_t f;
} mp0_syshub_tlb_attribute_17_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_18 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_18_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_18_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_18_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_18_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_18) \
      ((mp0_syshub_tlb_attribute_18 & MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_18) \
      ((mp0_syshub_tlb_attribute_18 & MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_18) \
      ((mp0_syshub_tlb_attribute_18 & MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_18) \
      ((mp0_syshub_tlb_attribute_18 & MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_18) \
      ((mp0_syshub_tlb_attribute_18 & MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_18) \
      ((mp0_syshub_tlb_attribute_18 & MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_18) \
      ((mp0_syshub_tlb_attribute_18 & MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_18_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_18_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_18_reg = (mp0_syshub_tlb_attribute_18_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_18_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_18_reg = (mp0_syshub_tlb_attribute_18_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_18_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_18_reg = (mp0_syshub_tlb_attribute_18_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_18_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_18_reg = (mp0_syshub_tlb_attribute_18_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_18_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_18_reg = (mp0_syshub_tlb_attribute_18_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_18_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_18_reg = (mp0_syshub_tlb_attribute_18_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_18_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_18_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_18_reg = (mp0_syshub_tlb_attribute_18_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_18_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_18_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_18_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_18_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_18_t f;
} mp0_syshub_tlb_attribute_18_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_19 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_19_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_19_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_19_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_19_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_19) \
      ((mp0_syshub_tlb_attribute_19 & MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_19) \
      ((mp0_syshub_tlb_attribute_19 & MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_19) \
      ((mp0_syshub_tlb_attribute_19 & MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_19) \
      ((mp0_syshub_tlb_attribute_19 & MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_19) \
      ((mp0_syshub_tlb_attribute_19 & MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_19) \
      ((mp0_syshub_tlb_attribute_19 & MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_19) \
      ((mp0_syshub_tlb_attribute_19 & MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_19_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_19_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_19_reg = (mp0_syshub_tlb_attribute_19_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_19_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_19_reg = (mp0_syshub_tlb_attribute_19_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_19_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_19_reg = (mp0_syshub_tlb_attribute_19_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_19_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_19_reg = (mp0_syshub_tlb_attribute_19_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_19_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_19_reg = (mp0_syshub_tlb_attribute_19_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_19_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_19_reg = (mp0_syshub_tlb_attribute_19_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_19_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_19_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_19_reg = (mp0_syshub_tlb_attribute_19_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_19_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_19_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_19_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_19_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_19_t f;
} mp0_syshub_tlb_attribute_19_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_20 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_20_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_20_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_20_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_20_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_20) \
      ((mp0_syshub_tlb_attribute_20 & MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_20) \
      ((mp0_syshub_tlb_attribute_20 & MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_20) \
      ((mp0_syshub_tlb_attribute_20 & MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_20) \
      ((mp0_syshub_tlb_attribute_20 & MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_20) \
      ((mp0_syshub_tlb_attribute_20 & MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_20) \
      ((mp0_syshub_tlb_attribute_20 & MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_20) \
      ((mp0_syshub_tlb_attribute_20 & MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_20_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_20_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_20_reg = (mp0_syshub_tlb_attribute_20_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_20_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_20_reg = (mp0_syshub_tlb_attribute_20_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_20_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_20_reg = (mp0_syshub_tlb_attribute_20_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_20_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_20_reg = (mp0_syshub_tlb_attribute_20_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_20_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_20_reg = (mp0_syshub_tlb_attribute_20_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_20_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_20_reg = (mp0_syshub_tlb_attribute_20_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_20_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_20_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_20_reg = (mp0_syshub_tlb_attribute_20_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_20_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_20_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_20_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_20_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_20_t f;
} mp0_syshub_tlb_attribute_20_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_21 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_21_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_21_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_21_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_21_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_21) \
      ((mp0_syshub_tlb_attribute_21 & MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_21) \
      ((mp0_syshub_tlb_attribute_21 & MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_21) \
      ((mp0_syshub_tlb_attribute_21 & MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_21) \
      ((mp0_syshub_tlb_attribute_21 & MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_21) \
      ((mp0_syshub_tlb_attribute_21 & MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_21) \
      ((mp0_syshub_tlb_attribute_21 & MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_21) \
      ((mp0_syshub_tlb_attribute_21 & MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_21_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_21_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_21_reg = (mp0_syshub_tlb_attribute_21_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_21_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_21_reg = (mp0_syshub_tlb_attribute_21_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_21_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_21_reg = (mp0_syshub_tlb_attribute_21_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_21_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_21_reg = (mp0_syshub_tlb_attribute_21_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_21_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_21_reg = (mp0_syshub_tlb_attribute_21_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_21_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_21_reg = (mp0_syshub_tlb_attribute_21_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_21_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_21_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_21_reg = (mp0_syshub_tlb_attribute_21_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_21_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_21_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_21_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_21_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_21_t f;
} mp0_syshub_tlb_attribute_21_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_22 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_22_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_22_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_22_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_22_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_22) \
      ((mp0_syshub_tlb_attribute_22 & MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_22) \
      ((mp0_syshub_tlb_attribute_22 & MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_22) \
      ((mp0_syshub_tlb_attribute_22 & MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_22) \
      ((mp0_syshub_tlb_attribute_22 & MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_22) \
      ((mp0_syshub_tlb_attribute_22 & MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_22) \
      ((mp0_syshub_tlb_attribute_22 & MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_22) \
      ((mp0_syshub_tlb_attribute_22 & MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_22_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_22_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_22_reg = (mp0_syshub_tlb_attribute_22_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_22_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_22_reg = (mp0_syshub_tlb_attribute_22_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_22_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_22_reg = (mp0_syshub_tlb_attribute_22_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_22_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_22_reg = (mp0_syshub_tlb_attribute_22_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_22_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_22_reg = (mp0_syshub_tlb_attribute_22_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_22_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_22_reg = (mp0_syshub_tlb_attribute_22_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_22_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_22_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_22_reg = (mp0_syshub_tlb_attribute_22_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_22_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_22_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_22_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_22_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_22_t f;
} mp0_syshub_tlb_attribute_22_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_23 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_23_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_23_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_23_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_23_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_23) \
      ((mp0_syshub_tlb_attribute_23 & MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_23) \
      ((mp0_syshub_tlb_attribute_23 & MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_23) \
      ((mp0_syshub_tlb_attribute_23 & MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_23) \
      ((mp0_syshub_tlb_attribute_23 & MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_23) \
      ((mp0_syshub_tlb_attribute_23 & MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_23) \
      ((mp0_syshub_tlb_attribute_23 & MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_23) \
      ((mp0_syshub_tlb_attribute_23 & MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_23_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_23_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_23_reg = (mp0_syshub_tlb_attribute_23_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_23_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_23_reg = (mp0_syshub_tlb_attribute_23_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_23_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_23_reg = (mp0_syshub_tlb_attribute_23_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_23_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_23_reg = (mp0_syshub_tlb_attribute_23_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_23_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_23_reg = (mp0_syshub_tlb_attribute_23_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_23_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_23_reg = (mp0_syshub_tlb_attribute_23_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_23_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_23_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_23_reg = (mp0_syshub_tlb_attribute_23_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_23_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_23_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_23_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_23_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_23_t f;
} mp0_syshub_tlb_attribute_23_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_24 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_24_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_24_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_24_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_24_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_24) \
      ((mp0_syshub_tlb_attribute_24 & MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_24) \
      ((mp0_syshub_tlb_attribute_24 & MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_24) \
      ((mp0_syshub_tlb_attribute_24 & MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_24) \
      ((mp0_syshub_tlb_attribute_24 & MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_24) \
      ((mp0_syshub_tlb_attribute_24 & MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_24) \
      ((mp0_syshub_tlb_attribute_24 & MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_24) \
      ((mp0_syshub_tlb_attribute_24 & MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_24_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_24_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_24_reg = (mp0_syshub_tlb_attribute_24_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_24_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_24_reg = (mp0_syshub_tlb_attribute_24_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_24_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_24_reg = (mp0_syshub_tlb_attribute_24_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_24_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_24_reg = (mp0_syshub_tlb_attribute_24_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_24_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_24_reg = (mp0_syshub_tlb_attribute_24_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_24_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_24_reg = (mp0_syshub_tlb_attribute_24_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_24_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_24_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_24_reg = (mp0_syshub_tlb_attribute_24_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_24_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_24_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_24_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_24_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_24_t f;
} mp0_syshub_tlb_attribute_24_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_25 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_25_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_25_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_25_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_25_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_25) \
      ((mp0_syshub_tlb_attribute_25 & MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_25) \
      ((mp0_syshub_tlb_attribute_25 & MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_25) \
      ((mp0_syshub_tlb_attribute_25 & MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_25) \
      ((mp0_syshub_tlb_attribute_25 & MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_25) \
      ((mp0_syshub_tlb_attribute_25 & MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_25) \
      ((mp0_syshub_tlb_attribute_25 & MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_25) \
      ((mp0_syshub_tlb_attribute_25 & MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_25_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_25_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_25_reg = (mp0_syshub_tlb_attribute_25_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_25_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_25_reg = (mp0_syshub_tlb_attribute_25_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_25_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_25_reg = (mp0_syshub_tlb_attribute_25_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_25_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_25_reg = (mp0_syshub_tlb_attribute_25_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_25_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_25_reg = (mp0_syshub_tlb_attribute_25_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_25_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_25_reg = (mp0_syshub_tlb_attribute_25_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_25_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_25_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_25_reg = (mp0_syshub_tlb_attribute_25_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_25_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_25_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_25_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_25_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_25_t f;
} mp0_syshub_tlb_attribute_25_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_26 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_26_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_26_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_26_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_26_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_26) \
      ((mp0_syshub_tlb_attribute_26 & MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_26) \
      ((mp0_syshub_tlb_attribute_26 & MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_26) \
      ((mp0_syshub_tlb_attribute_26 & MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_26) \
      ((mp0_syshub_tlb_attribute_26 & MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_26) \
      ((mp0_syshub_tlb_attribute_26 & MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_26) \
      ((mp0_syshub_tlb_attribute_26 & MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_26) \
      ((mp0_syshub_tlb_attribute_26 & MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_26_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_26_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_26_reg = (mp0_syshub_tlb_attribute_26_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_26_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_26_reg = (mp0_syshub_tlb_attribute_26_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_26_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_26_reg = (mp0_syshub_tlb_attribute_26_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_26_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_26_reg = (mp0_syshub_tlb_attribute_26_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_26_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_26_reg = (mp0_syshub_tlb_attribute_26_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_26_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_26_reg = (mp0_syshub_tlb_attribute_26_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_26_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_26_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_26_reg = (mp0_syshub_tlb_attribute_26_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_26_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_26_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_26_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_26_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_26_t f;
} mp0_syshub_tlb_attribute_26_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_27 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_27_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_27_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_27_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_27_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_27) \
      ((mp0_syshub_tlb_attribute_27 & MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_27) \
      ((mp0_syshub_tlb_attribute_27 & MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_27) \
      ((mp0_syshub_tlb_attribute_27 & MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_27) \
      ((mp0_syshub_tlb_attribute_27 & MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_27) \
      ((mp0_syshub_tlb_attribute_27 & MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_27) \
      ((mp0_syshub_tlb_attribute_27 & MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_27) \
      ((mp0_syshub_tlb_attribute_27 & MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_27_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_27_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_27_reg = (mp0_syshub_tlb_attribute_27_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_27_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_27_reg = (mp0_syshub_tlb_attribute_27_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_27_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_27_reg = (mp0_syshub_tlb_attribute_27_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_27_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_27_reg = (mp0_syshub_tlb_attribute_27_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_27_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_27_reg = (mp0_syshub_tlb_attribute_27_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_27_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_27_reg = (mp0_syshub_tlb_attribute_27_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_27_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_27_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_27_reg = (mp0_syshub_tlb_attribute_27_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_27_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_27_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_27_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_27_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_27_t f;
} mp0_syshub_tlb_attribute_27_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_28 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_28_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_28_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_28_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_28_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_28) \
      ((mp0_syshub_tlb_attribute_28 & MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_28) \
      ((mp0_syshub_tlb_attribute_28 & MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_28) \
      ((mp0_syshub_tlb_attribute_28 & MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_28) \
      ((mp0_syshub_tlb_attribute_28 & MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_28) \
      ((mp0_syshub_tlb_attribute_28 & MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_28) \
      ((mp0_syshub_tlb_attribute_28 & MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_28) \
      ((mp0_syshub_tlb_attribute_28 & MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_28_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_28_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_28_reg = (mp0_syshub_tlb_attribute_28_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_28_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_28_reg = (mp0_syshub_tlb_attribute_28_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_28_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_28_reg = (mp0_syshub_tlb_attribute_28_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_28_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_28_reg = (mp0_syshub_tlb_attribute_28_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_28_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_28_reg = (mp0_syshub_tlb_attribute_28_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_28_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_28_reg = (mp0_syshub_tlb_attribute_28_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_28_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_28_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_28_reg = (mp0_syshub_tlb_attribute_28_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_28_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_28_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_28_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_28_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_28_t f;
} mp0_syshub_tlb_attribute_28_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_29 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_29_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_29_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_29_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_29_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_29) \
      ((mp0_syshub_tlb_attribute_29 & MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_29) \
      ((mp0_syshub_tlb_attribute_29 & MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_29) \
      ((mp0_syshub_tlb_attribute_29 & MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_29) \
      ((mp0_syshub_tlb_attribute_29 & MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_29) \
      ((mp0_syshub_tlb_attribute_29 & MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_29) \
      ((mp0_syshub_tlb_attribute_29 & MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_29) \
      ((mp0_syshub_tlb_attribute_29 & MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_29_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_29_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_29_reg = (mp0_syshub_tlb_attribute_29_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_29_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_29_reg = (mp0_syshub_tlb_attribute_29_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_29_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_29_reg = (mp0_syshub_tlb_attribute_29_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_29_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_29_reg = (mp0_syshub_tlb_attribute_29_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_29_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_29_reg = (mp0_syshub_tlb_attribute_29_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_29_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_29_reg = (mp0_syshub_tlb_attribute_29_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_29_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_29_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_29_reg = (mp0_syshub_tlb_attribute_29_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_29_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_29_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_29_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_29_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_29_t f;
} mp0_syshub_tlb_attribute_29_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_30 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_30_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_30_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_30_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_30_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_30) \
      ((mp0_syshub_tlb_attribute_30 & MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_30) \
      ((mp0_syshub_tlb_attribute_30 & MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_30) \
      ((mp0_syshub_tlb_attribute_30 & MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_30) \
      ((mp0_syshub_tlb_attribute_30 & MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_30) \
      ((mp0_syshub_tlb_attribute_30 & MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_30) \
      ((mp0_syshub_tlb_attribute_30 & MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_30) \
      ((mp0_syshub_tlb_attribute_30 & MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_30_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_30_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_30_reg = (mp0_syshub_tlb_attribute_30_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_30_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_30_reg = (mp0_syshub_tlb_attribute_30_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_30_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_30_reg = (mp0_syshub_tlb_attribute_30_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_30_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_30_reg = (mp0_syshub_tlb_attribute_30_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_30_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_30_reg = (mp0_syshub_tlb_attribute_30_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_30_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_30_reg = (mp0_syshub_tlb_attribute_30_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_30_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_30_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_30_reg = (mp0_syshub_tlb_attribute_30_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_30_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_30_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_30_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_30_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_30_t f;
} mp0_syshub_tlb_attribute_30_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_31 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_31_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_31_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_31_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_31_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_31) \
      ((mp0_syshub_tlb_attribute_31 & MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_31) \
      ((mp0_syshub_tlb_attribute_31 & MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_31) \
      ((mp0_syshub_tlb_attribute_31 & MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_31) \
      ((mp0_syshub_tlb_attribute_31 & MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_31) \
      ((mp0_syshub_tlb_attribute_31 & MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_31) \
      ((mp0_syshub_tlb_attribute_31 & MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_31) \
      ((mp0_syshub_tlb_attribute_31 & MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_31_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_31_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_31_reg = (mp0_syshub_tlb_attribute_31_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_31_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_31_reg = (mp0_syshub_tlb_attribute_31_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_31_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_31_reg = (mp0_syshub_tlb_attribute_31_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_31_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_31_reg = (mp0_syshub_tlb_attribute_31_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_31_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_31_reg = (mp0_syshub_tlb_attribute_31_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_31_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_31_reg = (mp0_syshub_tlb_attribute_31_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_31_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_31_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_31_reg = (mp0_syshub_tlb_attribute_31_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_31_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_31_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_31_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_31_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_31_t f;
} mp0_syshub_tlb_attribute_31_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_32 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_32_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_32_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_32_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_32_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_32) \
      ((mp0_syshub_tlb_attribute_32 & MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_32) \
      ((mp0_syshub_tlb_attribute_32 & MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_32) \
      ((mp0_syshub_tlb_attribute_32 & MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_32) \
      ((mp0_syshub_tlb_attribute_32 & MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_32) \
      ((mp0_syshub_tlb_attribute_32 & MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_32) \
      ((mp0_syshub_tlb_attribute_32 & MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_32) \
      ((mp0_syshub_tlb_attribute_32 & MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_32_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_32_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_32_reg = (mp0_syshub_tlb_attribute_32_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_32_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_32_reg = (mp0_syshub_tlb_attribute_32_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_32_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_32_reg = (mp0_syshub_tlb_attribute_32_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_32_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_32_reg = (mp0_syshub_tlb_attribute_32_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_32_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_32_reg = (mp0_syshub_tlb_attribute_32_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_32_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_32_reg = (mp0_syshub_tlb_attribute_32_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_32_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_32_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_32_reg = (mp0_syshub_tlb_attribute_32_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_32_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_32_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_32_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_32_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_32_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_32_t f;
} mp0_syshub_tlb_attribute_32_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_33 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_33_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_33_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_33_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_33_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_33) \
      ((mp0_syshub_tlb_attribute_33 & MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_33) \
      ((mp0_syshub_tlb_attribute_33 & MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_33) \
      ((mp0_syshub_tlb_attribute_33 & MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_33) \
      ((mp0_syshub_tlb_attribute_33 & MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_33) \
      ((mp0_syshub_tlb_attribute_33 & MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_33) \
      ((mp0_syshub_tlb_attribute_33 & MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_33) \
      ((mp0_syshub_tlb_attribute_33 & MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_33_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_33_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_33_reg = (mp0_syshub_tlb_attribute_33_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_33_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_33_reg = (mp0_syshub_tlb_attribute_33_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_33_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_33_reg = (mp0_syshub_tlb_attribute_33_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_33_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_33_reg = (mp0_syshub_tlb_attribute_33_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_33_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_33_reg = (mp0_syshub_tlb_attribute_33_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_33_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_33_reg = (mp0_syshub_tlb_attribute_33_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_33_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_33_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_33_reg = (mp0_syshub_tlb_attribute_33_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_33_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_33_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_33_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_33_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_33_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_33_t f;
} mp0_syshub_tlb_attribute_33_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_34 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_34_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_34_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_34_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_34_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_34) \
      ((mp0_syshub_tlb_attribute_34 & MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_34) \
      ((mp0_syshub_tlb_attribute_34 & MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_34) \
      ((mp0_syshub_tlb_attribute_34 & MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_34) \
      ((mp0_syshub_tlb_attribute_34 & MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_34) \
      ((mp0_syshub_tlb_attribute_34 & MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_34) \
      ((mp0_syshub_tlb_attribute_34 & MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_34) \
      ((mp0_syshub_tlb_attribute_34 & MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_34_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_34_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_34_reg = (mp0_syshub_tlb_attribute_34_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_34_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_34_reg = (mp0_syshub_tlb_attribute_34_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_34_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_34_reg = (mp0_syshub_tlb_attribute_34_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_34_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_34_reg = (mp0_syshub_tlb_attribute_34_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_34_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_34_reg = (mp0_syshub_tlb_attribute_34_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_34_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_34_reg = (mp0_syshub_tlb_attribute_34_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_34_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_34_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_34_reg = (mp0_syshub_tlb_attribute_34_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_34_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_34_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_34_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_34_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_34_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_34_t f;
} mp0_syshub_tlb_attribute_34_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_35 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_35_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_35_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_35_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_35_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_35) \
      ((mp0_syshub_tlb_attribute_35 & MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_35) \
      ((mp0_syshub_tlb_attribute_35 & MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_35) \
      ((mp0_syshub_tlb_attribute_35 & MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_35) \
      ((mp0_syshub_tlb_attribute_35 & MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_35) \
      ((mp0_syshub_tlb_attribute_35 & MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_35) \
      ((mp0_syshub_tlb_attribute_35 & MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_35) \
      ((mp0_syshub_tlb_attribute_35 & MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_35_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_35_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_35_reg = (mp0_syshub_tlb_attribute_35_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_35_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_35_reg = (mp0_syshub_tlb_attribute_35_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_35_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_35_reg = (mp0_syshub_tlb_attribute_35_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_35_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_35_reg = (mp0_syshub_tlb_attribute_35_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_35_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_35_reg = (mp0_syshub_tlb_attribute_35_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_35_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_35_reg = (mp0_syshub_tlb_attribute_35_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_35_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_35_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_35_reg = (mp0_syshub_tlb_attribute_35_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_35_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_35_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_35_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_35_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_35_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_35_t f;
} mp0_syshub_tlb_attribute_35_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_36 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_36_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_36_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_36_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_36_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_36) \
      ((mp0_syshub_tlb_attribute_36 & MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_36) \
      ((mp0_syshub_tlb_attribute_36 & MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_36) \
      ((mp0_syshub_tlb_attribute_36 & MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_36) \
      ((mp0_syshub_tlb_attribute_36 & MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_36) \
      ((mp0_syshub_tlb_attribute_36 & MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_36) \
      ((mp0_syshub_tlb_attribute_36 & MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_36) \
      ((mp0_syshub_tlb_attribute_36 & MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_36_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_36_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_36_reg = (mp0_syshub_tlb_attribute_36_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_36_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_36_reg = (mp0_syshub_tlb_attribute_36_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_36_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_36_reg = (mp0_syshub_tlb_attribute_36_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_36_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_36_reg = (mp0_syshub_tlb_attribute_36_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_36_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_36_reg = (mp0_syshub_tlb_attribute_36_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_36_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_36_reg = (mp0_syshub_tlb_attribute_36_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_36_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_36_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_36_reg = (mp0_syshub_tlb_attribute_36_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_36_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_36_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_36_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_36_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_36_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_36_t f;
} mp0_syshub_tlb_attribute_36_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_37 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_37_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_37_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_37_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_37_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_37) \
      ((mp0_syshub_tlb_attribute_37 & MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_37) \
      ((mp0_syshub_tlb_attribute_37 & MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_37) \
      ((mp0_syshub_tlb_attribute_37 & MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_37) \
      ((mp0_syshub_tlb_attribute_37 & MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_37) \
      ((mp0_syshub_tlb_attribute_37 & MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_37) \
      ((mp0_syshub_tlb_attribute_37 & MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_37) \
      ((mp0_syshub_tlb_attribute_37 & MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_37_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_37_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_37_reg = (mp0_syshub_tlb_attribute_37_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_37_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_37_reg = (mp0_syshub_tlb_attribute_37_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_37_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_37_reg = (mp0_syshub_tlb_attribute_37_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_37_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_37_reg = (mp0_syshub_tlb_attribute_37_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_37_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_37_reg = (mp0_syshub_tlb_attribute_37_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_37_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_37_reg = (mp0_syshub_tlb_attribute_37_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_37_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_37_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_37_reg = (mp0_syshub_tlb_attribute_37_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_37_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_37_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_37_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_37_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_37_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_37_t f;
} mp0_syshub_tlb_attribute_37_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_38 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_38_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_38_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_38_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_38_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_38) \
      ((mp0_syshub_tlb_attribute_38 & MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_38) \
      ((mp0_syshub_tlb_attribute_38 & MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_38) \
      ((mp0_syshub_tlb_attribute_38 & MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_38) \
      ((mp0_syshub_tlb_attribute_38 & MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_38) \
      ((mp0_syshub_tlb_attribute_38 & MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_38) \
      ((mp0_syshub_tlb_attribute_38 & MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_38) \
      ((mp0_syshub_tlb_attribute_38 & MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_38_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_38_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_38_reg = (mp0_syshub_tlb_attribute_38_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_38_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_38_reg = (mp0_syshub_tlb_attribute_38_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_38_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_38_reg = (mp0_syshub_tlb_attribute_38_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_38_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_38_reg = (mp0_syshub_tlb_attribute_38_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_38_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_38_reg = (mp0_syshub_tlb_attribute_38_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_38_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_38_reg = (mp0_syshub_tlb_attribute_38_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_38_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_38_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_38_reg = (mp0_syshub_tlb_attribute_38_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_38_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_38_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_38_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_38_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_38_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_38_t f;
} mp0_syshub_tlb_attribute_38_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_39 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_39_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_39_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_39_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_39_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_39) \
      ((mp0_syshub_tlb_attribute_39 & MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_39) \
      ((mp0_syshub_tlb_attribute_39 & MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_39) \
      ((mp0_syshub_tlb_attribute_39 & MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_39) \
      ((mp0_syshub_tlb_attribute_39 & MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_39) \
      ((mp0_syshub_tlb_attribute_39 & MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_39) \
      ((mp0_syshub_tlb_attribute_39 & MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_39) \
      ((mp0_syshub_tlb_attribute_39 & MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_39_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_39_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_39_reg = (mp0_syshub_tlb_attribute_39_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_39_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_39_reg = (mp0_syshub_tlb_attribute_39_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_39_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_39_reg = (mp0_syshub_tlb_attribute_39_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_39_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_39_reg = (mp0_syshub_tlb_attribute_39_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_39_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_39_reg = (mp0_syshub_tlb_attribute_39_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_39_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_39_reg = (mp0_syshub_tlb_attribute_39_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_39_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_39_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_39_reg = (mp0_syshub_tlb_attribute_39_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_39_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_39_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_39_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_39_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_39_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_39_t f;
} mp0_syshub_tlb_attribute_39_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_40 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_40_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_40_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_40_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_40_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_40) \
      ((mp0_syshub_tlb_attribute_40 & MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_40) \
      ((mp0_syshub_tlb_attribute_40 & MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_40) \
      ((mp0_syshub_tlb_attribute_40 & MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_40) \
      ((mp0_syshub_tlb_attribute_40 & MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_40) \
      ((mp0_syshub_tlb_attribute_40 & MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_40) \
      ((mp0_syshub_tlb_attribute_40 & MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_40) \
      ((mp0_syshub_tlb_attribute_40 & MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_40_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_40_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_40_reg = (mp0_syshub_tlb_attribute_40_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_40_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_40_reg = (mp0_syshub_tlb_attribute_40_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_40_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_40_reg = (mp0_syshub_tlb_attribute_40_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_40_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_40_reg = (mp0_syshub_tlb_attribute_40_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_40_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_40_reg = (mp0_syshub_tlb_attribute_40_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_40_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_40_reg = (mp0_syshub_tlb_attribute_40_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_40_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_40_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_40_reg = (mp0_syshub_tlb_attribute_40_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_40_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_40_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_40_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_40_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_40_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_40_t f;
} mp0_syshub_tlb_attribute_40_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_41 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_41_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_41_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_41_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_41_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_41) \
      ((mp0_syshub_tlb_attribute_41 & MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_41) \
      ((mp0_syshub_tlb_attribute_41 & MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_41) \
      ((mp0_syshub_tlb_attribute_41 & MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_41) \
      ((mp0_syshub_tlb_attribute_41 & MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_41) \
      ((mp0_syshub_tlb_attribute_41 & MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_41) \
      ((mp0_syshub_tlb_attribute_41 & MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_41) \
      ((mp0_syshub_tlb_attribute_41 & MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_41_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_41_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_41_reg = (mp0_syshub_tlb_attribute_41_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_41_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_41_reg = (mp0_syshub_tlb_attribute_41_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_41_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_41_reg = (mp0_syshub_tlb_attribute_41_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_41_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_41_reg = (mp0_syshub_tlb_attribute_41_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_41_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_41_reg = (mp0_syshub_tlb_attribute_41_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_41_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_41_reg = (mp0_syshub_tlb_attribute_41_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_41_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_41_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_41_reg = (mp0_syshub_tlb_attribute_41_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_41_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_41_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_41_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_41_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_41_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_41_t f;
} mp0_syshub_tlb_attribute_41_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_42 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_42_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_42_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_42_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_42_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_42) \
      ((mp0_syshub_tlb_attribute_42 & MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_42) \
      ((mp0_syshub_tlb_attribute_42 & MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_42) \
      ((mp0_syshub_tlb_attribute_42 & MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_42) \
      ((mp0_syshub_tlb_attribute_42 & MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_42) \
      ((mp0_syshub_tlb_attribute_42 & MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_42) \
      ((mp0_syshub_tlb_attribute_42 & MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_42) \
      ((mp0_syshub_tlb_attribute_42 & MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_42_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_42_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_42_reg = (mp0_syshub_tlb_attribute_42_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_42_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_42_reg = (mp0_syshub_tlb_attribute_42_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_42_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_42_reg = (mp0_syshub_tlb_attribute_42_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_42_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_42_reg = (mp0_syshub_tlb_attribute_42_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_42_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_42_reg = (mp0_syshub_tlb_attribute_42_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_42_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_42_reg = (mp0_syshub_tlb_attribute_42_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_42_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_42_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_42_reg = (mp0_syshub_tlb_attribute_42_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_42_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_42_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_42_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_42_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_42_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_42_t f;
} mp0_syshub_tlb_attribute_42_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_43 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_43_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_43_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_43_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_43_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_43) \
      ((mp0_syshub_tlb_attribute_43 & MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_43) \
      ((mp0_syshub_tlb_attribute_43 & MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_43) \
      ((mp0_syshub_tlb_attribute_43 & MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_43) \
      ((mp0_syshub_tlb_attribute_43 & MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_43) \
      ((mp0_syshub_tlb_attribute_43 & MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_43) \
      ((mp0_syshub_tlb_attribute_43 & MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_43) \
      ((mp0_syshub_tlb_attribute_43 & MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_43_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_43_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_43_reg = (mp0_syshub_tlb_attribute_43_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_43_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_43_reg = (mp0_syshub_tlb_attribute_43_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_43_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_43_reg = (mp0_syshub_tlb_attribute_43_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_43_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_43_reg = (mp0_syshub_tlb_attribute_43_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_43_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_43_reg = (mp0_syshub_tlb_attribute_43_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_43_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_43_reg = (mp0_syshub_tlb_attribute_43_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_43_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_43_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_43_reg = (mp0_syshub_tlb_attribute_43_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_43_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_43_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_43_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_43_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_43_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_43_t f;
} mp0_syshub_tlb_attribute_43_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_44 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_44_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_44_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_44_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_44_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_44) \
      ((mp0_syshub_tlb_attribute_44 & MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_44) \
      ((mp0_syshub_tlb_attribute_44 & MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_44) \
      ((mp0_syshub_tlb_attribute_44 & MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_44) \
      ((mp0_syshub_tlb_attribute_44 & MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_44) \
      ((mp0_syshub_tlb_attribute_44 & MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_44) \
      ((mp0_syshub_tlb_attribute_44 & MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_44) \
      ((mp0_syshub_tlb_attribute_44 & MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_44_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_44_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_44_reg = (mp0_syshub_tlb_attribute_44_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_44_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_44_reg = (mp0_syshub_tlb_attribute_44_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_44_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_44_reg = (mp0_syshub_tlb_attribute_44_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_44_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_44_reg = (mp0_syshub_tlb_attribute_44_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_44_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_44_reg = (mp0_syshub_tlb_attribute_44_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_44_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_44_reg = (mp0_syshub_tlb_attribute_44_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_44_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_44_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_44_reg = (mp0_syshub_tlb_attribute_44_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_44_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_44_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_44_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_44_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_44_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_44_t f;
} mp0_syshub_tlb_attribute_44_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_45 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_45_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_45_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_45_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_45_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_45) \
      ((mp0_syshub_tlb_attribute_45 & MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_45) \
      ((mp0_syshub_tlb_attribute_45 & MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_45) \
      ((mp0_syshub_tlb_attribute_45 & MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_45) \
      ((mp0_syshub_tlb_attribute_45 & MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_45) \
      ((mp0_syshub_tlb_attribute_45 & MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_45) \
      ((mp0_syshub_tlb_attribute_45 & MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_45) \
      ((mp0_syshub_tlb_attribute_45 & MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_45_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_45_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_45_reg = (mp0_syshub_tlb_attribute_45_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_45_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_45_reg = (mp0_syshub_tlb_attribute_45_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_45_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_45_reg = (mp0_syshub_tlb_attribute_45_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_45_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_45_reg = (mp0_syshub_tlb_attribute_45_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_45_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_45_reg = (mp0_syshub_tlb_attribute_45_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_45_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_45_reg = (mp0_syshub_tlb_attribute_45_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_45_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_45_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_45_reg = (mp0_syshub_tlb_attribute_45_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_45_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_45_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_45_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_45_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_45_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_45_t f;
} mp0_syshub_tlb_attribute_45_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_46 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_46_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_46_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_46_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_46_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_46) \
      ((mp0_syshub_tlb_attribute_46 & MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_46) \
      ((mp0_syshub_tlb_attribute_46 & MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_46) \
      ((mp0_syshub_tlb_attribute_46 & MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_46) \
      ((mp0_syshub_tlb_attribute_46 & MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_46) \
      ((mp0_syshub_tlb_attribute_46 & MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_46) \
      ((mp0_syshub_tlb_attribute_46 & MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_46) \
      ((mp0_syshub_tlb_attribute_46 & MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_46_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_46_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_46_reg = (mp0_syshub_tlb_attribute_46_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_46_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_46_reg = (mp0_syshub_tlb_attribute_46_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_46_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_46_reg = (mp0_syshub_tlb_attribute_46_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_46_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_46_reg = (mp0_syshub_tlb_attribute_46_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_46_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_46_reg = (mp0_syshub_tlb_attribute_46_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_46_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_46_reg = (mp0_syshub_tlb_attribute_46_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_46_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_46_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_46_reg = (mp0_syshub_tlb_attribute_46_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_46_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_46_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_46_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_46_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_46_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_46_t f;
} mp0_syshub_tlb_attribute_46_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_47 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_47_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_47_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_47_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_47_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_47) \
      ((mp0_syshub_tlb_attribute_47 & MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_47) \
      ((mp0_syshub_tlb_attribute_47 & MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_47) \
      ((mp0_syshub_tlb_attribute_47 & MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_47) \
      ((mp0_syshub_tlb_attribute_47 & MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_47) \
      ((mp0_syshub_tlb_attribute_47 & MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_47) \
      ((mp0_syshub_tlb_attribute_47 & MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_47) \
      ((mp0_syshub_tlb_attribute_47 & MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_47_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_47_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_47_reg = (mp0_syshub_tlb_attribute_47_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_47_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_47_reg = (mp0_syshub_tlb_attribute_47_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_47_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_47_reg = (mp0_syshub_tlb_attribute_47_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_47_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_47_reg = (mp0_syshub_tlb_attribute_47_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_47_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_47_reg = (mp0_syshub_tlb_attribute_47_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_47_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_47_reg = (mp0_syshub_tlb_attribute_47_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_47_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_47_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_47_reg = (mp0_syshub_tlb_attribute_47_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_47_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_47_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_47_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_47_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_47_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_47_t f;
} mp0_syshub_tlb_attribute_47_u;


/*
 * MP0_SYSHUB_TLB_ATTRIBUTE_48 struct
 */

#define MP0_SYSHUB_TLB_ATTRIBUTE_48_REG_SIZE         32
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_ARPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AWPROT_1_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AES_KEY_SEL_SIZE  2
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AES_EN_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_CCP_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_PUB_SIZE  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_PRIV_SIZE  1

#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_ARPROT_1_SHIFT  0
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AWPROT_1_SHIFT  1
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AES_KEY_SEL_SHIFT  13
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AES_EN_SHIFT  15
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_CCP_SHIFT  23
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_PUB_SHIFT  30
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_PRIV_SHIFT  31

#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AES_KEY_SEL_MASK  0x00006000
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AES_EN_MASK  0x00008000
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_CCP_MASK  0x00800000
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_PUB_MASK  0x40000000
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_PRIV_MASK  0x80000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_48_MASK \
      (MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_ARPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AWPROT_1_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AES_KEY_SEL_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AES_EN_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_CCP_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_PUB_MASK | \
      MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_PRIV_MASK)

#define MP0_SYSHUB_TLB_ATTRIBUTE_48_DEFAULT 0x00000000

#define MP0_SYSHUB_TLB_ATTRIBUTE_48_GET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_48) \
      ((mp0_syshub_tlb_attribute_48 & MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_ARPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_GET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_48) \
      ((mp0_syshub_tlb_attribute_48 & MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AWPROT_1_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_GET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_48) \
      ((mp0_syshub_tlb_attribute_48 & MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AES_KEY_SEL_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_GET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_48) \
      ((mp0_syshub_tlb_attribute_48 & MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AES_EN_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_GET_MA_PSP_CCP(mp0_syshub_tlb_attribute_48) \
      ((mp0_syshub_tlb_attribute_48 & MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_CCP_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_GET_MA_PSP_PUB(mp0_syshub_tlb_attribute_48) \
      ((mp0_syshub_tlb_attribute_48 & MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_PUB_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_GET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_48) \
      ((mp0_syshub_tlb_attribute_48 & MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_PRIV_MASK) >> MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_PRIV_SHIFT)

#define MP0_SYSHUB_TLB_ATTRIBUTE_48_SET_MA_PSP_ARPROT_1(mp0_syshub_tlb_attribute_48_reg, ma_psp_arprot_1) \
      mp0_syshub_tlb_attribute_48_reg = (mp0_syshub_tlb_attribute_48_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_ARPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_SET_MA_PSP_AWPROT_1(mp0_syshub_tlb_attribute_48_reg, ma_psp_awprot_1) \
      mp0_syshub_tlb_attribute_48_reg = (mp0_syshub_tlb_attribute_48_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AWPROT_1_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_SET_MA_PSP_AES_KEY_SEL(mp0_syshub_tlb_attribute_48_reg, ma_psp_aes_key_sel) \
      mp0_syshub_tlb_attribute_48_reg = (mp0_syshub_tlb_attribute_48_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AES_KEY_SEL_MASK) | (ma_psp_aes_key_sel << MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AES_KEY_SEL_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_SET_MA_PSP_AES_EN(mp0_syshub_tlb_attribute_48_reg, ma_psp_aes_en) \
      mp0_syshub_tlb_attribute_48_reg = (mp0_syshub_tlb_attribute_48_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AES_EN_MASK) | (ma_psp_aes_en << MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AES_EN_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_SET_MA_PSP_CCP(mp0_syshub_tlb_attribute_48_reg, ma_psp_ccp) \
      mp0_syshub_tlb_attribute_48_reg = (mp0_syshub_tlb_attribute_48_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_CCP_MASK) | (ma_psp_ccp << MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_CCP_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_SET_MA_PSP_PUB(mp0_syshub_tlb_attribute_48_reg, ma_psp_pub) \
      mp0_syshub_tlb_attribute_48_reg = (mp0_syshub_tlb_attribute_48_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_PUB_MASK) | (ma_psp_pub << MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_PUB_SHIFT)
#define MP0_SYSHUB_TLB_ATTRIBUTE_48_SET_MA_PSP_PRIV(mp0_syshub_tlb_attribute_48_reg, ma_psp_priv) \
      mp0_syshub_tlb_attribute_48_reg = (mp0_syshub_tlb_attribute_48_reg & ~MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_48_t {
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AES_EN_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_CCP_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_PRIV_SIZE;
      } mp0_syshub_tlb_attribute_48_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_tlb_attribute_48_t {
            unsigned int ma_psp_priv                    : MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_PUB_SIZE;
            unsigned int                                : 6;
            unsigned int ma_psp_ccp                     : MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_CCP_SIZE;
            unsigned int                                : 7;
            unsigned int ma_psp_aes_en                  : MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AES_EN_SIZE;
            unsigned int ma_psp_aes_key_sel             : MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AES_KEY_SEL_SIZE;
            unsigned int                                : 11;
            unsigned int ma_psp_awprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP0_SYSHUB_TLB_ATTRIBUTE_48_MA_PSP_ARPROT_1_SIZE;
      } mp0_syshub_tlb_attribute_48_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_tlb_attribute_48_t f;
} mp0_syshub_tlb_attribute_48_u;


/*
 * MP0_SYSHUB_INT_STATUS struct
 */

#define MP0_SYSHUB_INT_STATUS_REG_SIZE         32
#define MP0_SYSHUB_INT_STATUS_RD_ERROR_SIZE  1
#define MP0_SYSHUB_INT_STATUS_WR_ERROR_SIZE  1
#define MP0_SYSHUB_INT_STATUS_REG_ERROR_SIZE  1

#define MP0_SYSHUB_INT_STATUS_RD_ERROR_SHIFT  0
#define MP0_SYSHUB_INT_STATUS_WR_ERROR_SHIFT  1
#define MP0_SYSHUB_INT_STATUS_REG_ERROR_SHIFT  2

#define MP0_SYSHUB_INT_STATUS_RD_ERROR_MASK  0x00000001
#define MP0_SYSHUB_INT_STATUS_WR_ERROR_MASK  0x00000002
#define MP0_SYSHUB_INT_STATUS_REG_ERROR_MASK  0x00000004

#define MP0_SYSHUB_INT_STATUS_MASK \
      (MP0_SYSHUB_INT_STATUS_RD_ERROR_MASK | \
      MP0_SYSHUB_INT_STATUS_WR_ERROR_MASK | \
      MP0_SYSHUB_INT_STATUS_REG_ERROR_MASK)

#define MP0_SYSHUB_INT_STATUS_DEFAULT  0x00000000

#define MP0_SYSHUB_INT_STATUS_GET_RD_ERROR(mp0_syshub_int_status) \
      ((mp0_syshub_int_status & MP0_SYSHUB_INT_STATUS_RD_ERROR_MASK) >> MP0_SYSHUB_INT_STATUS_RD_ERROR_SHIFT)
#define MP0_SYSHUB_INT_STATUS_GET_WR_ERROR(mp0_syshub_int_status) \
      ((mp0_syshub_int_status & MP0_SYSHUB_INT_STATUS_WR_ERROR_MASK) >> MP0_SYSHUB_INT_STATUS_WR_ERROR_SHIFT)
#define MP0_SYSHUB_INT_STATUS_GET_REG_ERROR(mp0_syshub_int_status) \
      ((mp0_syshub_int_status & MP0_SYSHUB_INT_STATUS_REG_ERROR_MASK) >> MP0_SYSHUB_INT_STATUS_REG_ERROR_SHIFT)

#define MP0_SYSHUB_INT_STATUS_SET_RD_ERROR(mp0_syshub_int_status_reg, rd_error) \
      mp0_syshub_int_status_reg = (mp0_syshub_int_status_reg & ~MP0_SYSHUB_INT_STATUS_RD_ERROR_MASK) | (rd_error << MP0_SYSHUB_INT_STATUS_RD_ERROR_SHIFT)
#define MP0_SYSHUB_INT_STATUS_SET_WR_ERROR(mp0_syshub_int_status_reg, wr_error) \
      mp0_syshub_int_status_reg = (mp0_syshub_int_status_reg & ~MP0_SYSHUB_INT_STATUS_WR_ERROR_MASK) | (wr_error << MP0_SYSHUB_INT_STATUS_WR_ERROR_SHIFT)
#define MP0_SYSHUB_INT_STATUS_SET_REG_ERROR(mp0_syshub_int_status_reg, reg_error) \
      mp0_syshub_int_status_reg = (mp0_syshub_int_status_reg & ~MP0_SYSHUB_INT_STATUS_REG_ERROR_MASK) | (reg_error << MP0_SYSHUB_INT_STATUS_REG_ERROR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_int_status_t {
            unsigned int rd_error                       : MP0_SYSHUB_INT_STATUS_RD_ERROR_SIZE;
            unsigned int wr_error                       : MP0_SYSHUB_INT_STATUS_WR_ERROR_SIZE;
            unsigned int reg_error                      : MP0_SYSHUB_INT_STATUS_REG_ERROR_SIZE;
            unsigned int                                : 29;
      } mp0_syshub_int_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_int_status_t {
            unsigned int                                : 29;
            unsigned int reg_error                      : MP0_SYSHUB_INT_STATUS_REG_ERROR_SIZE;
            unsigned int wr_error                       : MP0_SYSHUB_INT_STATUS_WR_ERROR_SIZE;
            unsigned int rd_error                       : MP0_SYSHUB_INT_STATUS_RD_ERROR_SIZE;
      } mp0_syshub_int_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_int_status_t f;
} mp0_syshub_int_status_u;


/*
 * MP0_SYSHUB_WR_INT_ADDR struct
 */

#define MP0_SYSHUB_WR_INT_ADDR_REG_SIZE         32
#define MP0_SYSHUB_WR_INT_ADDR_ADDR_SIZE  32

#define MP0_SYSHUB_WR_INT_ADDR_ADDR_SHIFT  0

#define MP0_SYSHUB_WR_INT_ADDR_ADDR_MASK  0xffffffff

#define MP0_SYSHUB_WR_INT_ADDR_MASK \
      (MP0_SYSHUB_WR_INT_ADDR_ADDR_MASK)

#define MP0_SYSHUB_WR_INT_ADDR_DEFAULT 0x00000000

#define MP0_SYSHUB_WR_INT_ADDR_GET_ADDR(mp0_syshub_wr_int_addr) \
      ((mp0_syshub_wr_int_addr & MP0_SYSHUB_WR_INT_ADDR_ADDR_MASK) >> MP0_SYSHUB_WR_INT_ADDR_ADDR_SHIFT)

#define MP0_SYSHUB_WR_INT_ADDR_SET_ADDR(mp0_syshub_wr_int_addr_reg, addr) \
      mp0_syshub_wr_int_addr_reg = (mp0_syshub_wr_int_addr_reg & ~MP0_SYSHUB_WR_INT_ADDR_ADDR_MASK) | (addr << MP0_SYSHUB_WR_INT_ADDR_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_wr_int_addr_t {
            unsigned int addr                           : MP0_SYSHUB_WR_INT_ADDR_ADDR_SIZE;
      } mp0_syshub_wr_int_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_wr_int_addr_t {
            unsigned int addr                           : MP0_SYSHUB_WR_INT_ADDR_ADDR_SIZE;
      } mp0_syshub_wr_int_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_wr_int_addr_t f;
} mp0_syshub_wr_int_addr_u;


/*
 * MP0_SYSHUB_WR_INT_ID struct
 */

#define MP0_SYSHUB_WR_INT_ID_REG_SIZE         32
#define MP0_SYSHUB_WR_INT_ID_AXI_ID_SIZE  21

#define MP0_SYSHUB_WR_INT_ID_AXI_ID_SHIFT  0

#define MP0_SYSHUB_WR_INT_ID_AXI_ID_MASK  0x001fffff

#define MP0_SYSHUB_WR_INT_ID_MASK \
      (MP0_SYSHUB_WR_INT_ID_AXI_ID_MASK)

#define MP0_SYSHUB_WR_INT_ID_DEFAULT   0x00000000

#define MP0_SYSHUB_WR_INT_ID_GET_AXI_ID(mp0_syshub_wr_int_id) \
      ((mp0_syshub_wr_int_id & MP0_SYSHUB_WR_INT_ID_AXI_ID_MASK) >> MP0_SYSHUB_WR_INT_ID_AXI_ID_SHIFT)

#define MP0_SYSHUB_WR_INT_ID_SET_AXI_ID(mp0_syshub_wr_int_id_reg, axi_id) \
      mp0_syshub_wr_int_id_reg = (mp0_syshub_wr_int_id_reg & ~MP0_SYSHUB_WR_INT_ID_AXI_ID_MASK) | (axi_id << MP0_SYSHUB_WR_INT_ID_AXI_ID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_wr_int_id_t {
            unsigned int axi_id                         : MP0_SYSHUB_WR_INT_ID_AXI_ID_SIZE;
            unsigned int                                : 11;
      } mp0_syshub_wr_int_id_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_wr_int_id_t {
            unsigned int                                : 11;
            unsigned int axi_id                         : MP0_SYSHUB_WR_INT_ID_AXI_ID_SIZE;
      } mp0_syshub_wr_int_id_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_wr_int_id_t f;
} mp0_syshub_wr_int_id_u;


/*
 * MP0_SYSHUB_MISC_CTRL struct
 */

#define MP0_SYSHUB_MISC_CTRL_REG_SIZE         32
#define MP0_SYSHUB_MISC_CTRL_CLK_GATE_EN_SIZE  1
#define MP0_SYSHUB_MISC_CTRL_REG_CLK_STS_SIZE  1

#define MP0_SYSHUB_MISC_CTRL_CLK_GATE_EN_SHIFT  0
#define MP0_SYSHUB_MISC_CTRL_REG_CLK_STS_SHIFT  8

#define MP0_SYSHUB_MISC_CTRL_CLK_GATE_EN_MASK  0x00000001
#define MP0_SYSHUB_MISC_CTRL_REG_CLK_STS_MASK  0x00000100

#define MP0_SYSHUB_MISC_CTRL_MASK \
      (MP0_SYSHUB_MISC_CTRL_CLK_GATE_EN_MASK | \
      MP0_SYSHUB_MISC_CTRL_REG_CLK_STS_MASK)

#define MP0_SYSHUB_MISC_CTRL_DEFAULT   0x00000101

#define MP0_SYSHUB_MISC_CTRL_GET_CLK_GATE_EN(mp0_syshub_misc_ctrl) \
      ((mp0_syshub_misc_ctrl & MP0_SYSHUB_MISC_CTRL_CLK_GATE_EN_MASK) >> MP0_SYSHUB_MISC_CTRL_CLK_GATE_EN_SHIFT)
#define MP0_SYSHUB_MISC_CTRL_GET_REG_CLK_STS(mp0_syshub_misc_ctrl) \
      ((mp0_syshub_misc_ctrl & MP0_SYSHUB_MISC_CTRL_REG_CLK_STS_MASK) >> MP0_SYSHUB_MISC_CTRL_REG_CLK_STS_SHIFT)

#define MP0_SYSHUB_MISC_CTRL_SET_CLK_GATE_EN(mp0_syshub_misc_ctrl_reg, clk_gate_en) \
      mp0_syshub_misc_ctrl_reg = (mp0_syshub_misc_ctrl_reg & ~MP0_SYSHUB_MISC_CTRL_CLK_GATE_EN_MASK) | (clk_gate_en << MP0_SYSHUB_MISC_CTRL_CLK_GATE_EN_SHIFT)
#define MP0_SYSHUB_MISC_CTRL_SET_REG_CLK_STS(mp0_syshub_misc_ctrl_reg, reg_clk_sts) \
      mp0_syshub_misc_ctrl_reg = (mp0_syshub_misc_ctrl_reg & ~MP0_SYSHUB_MISC_CTRL_REG_CLK_STS_MASK) | (reg_clk_sts << MP0_SYSHUB_MISC_CTRL_REG_CLK_STS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_misc_ctrl_t {
            unsigned int clk_gate_en                    : MP0_SYSHUB_MISC_CTRL_CLK_GATE_EN_SIZE;
            unsigned int                                : 7;
            unsigned int reg_clk_sts                    : MP0_SYSHUB_MISC_CTRL_REG_CLK_STS_SIZE;
            unsigned int                                : 23;
      } mp0_syshub_misc_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_misc_ctrl_t {
            unsigned int                                : 23;
            unsigned int reg_clk_sts                    : MP0_SYSHUB_MISC_CTRL_REG_CLK_STS_SIZE;
            unsigned int                                : 7;
            unsigned int clk_gate_en                    : MP0_SYSHUB_MISC_CTRL_CLK_GATE_EN_SIZE;
      } mp0_syshub_misc_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_misc_ctrl_t f;
} mp0_syshub_misc_ctrl_u;


/*
 * MP0_SYSHUB_WR_INT_OTHER struct
 */

#define MP0_SYSHUB_WR_INT_OTHER_REG_SIZE         32
#define MP0_SYSHUB_WR_INT_OTHER_ERROR_TLB_SIZE  1
#define MP0_SYSHUB_WR_INT_OTHER_ERROR_PAGE_SIZE  1
#define MP0_SYSHUB_WR_INT_OTHER_ERROR_ATTRIB_SIZE  1
#define MP0_SYSHUB_WR_INT_OTHER_ERROR_PROT_SIZE  1
#define MP0_SYSHUB_WR_INT_OTHER_ERROR_MST_SIZE  1
#define MP0_SYSHUB_WR_INT_OTHER_ERROR_AES_SIZE  1
#define MP0_SYSHUB_WR_INT_OTHER_ERROR_AES_RMW_SIZE  1
#define MP0_SYSHUB_WR_INT_OTHER_INT_CLEAR_SIZE  1

#define MP0_SYSHUB_WR_INT_OTHER_ERROR_TLB_SHIFT  0
#define MP0_SYSHUB_WR_INT_OTHER_ERROR_PAGE_SHIFT  1
#define MP0_SYSHUB_WR_INT_OTHER_ERROR_ATTRIB_SHIFT  2
#define MP0_SYSHUB_WR_INT_OTHER_ERROR_PROT_SHIFT  3
#define MP0_SYSHUB_WR_INT_OTHER_ERROR_MST_SHIFT  4
#define MP0_SYSHUB_WR_INT_OTHER_ERROR_AES_SHIFT  5
#define MP0_SYSHUB_WR_INT_OTHER_ERROR_AES_RMW_SHIFT  8
#define MP0_SYSHUB_WR_INT_OTHER_INT_CLEAR_SHIFT  31

#define MP0_SYSHUB_WR_INT_OTHER_ERROR_TLB_MASK  0x00000001
#define MP0_SYSHUB_WR_INT_OTHER_ERROR_PAGE_MASK  0x00000002
#define MP0_SYSHUB_WR_INT_OTHER_ERROR_ATTRIB_MASK  0x00000004
#define MP0_SYSHUB_WR_INT_OTHER_ERROR_PROT_MASK  0x00000008
#define MP0_SYSHUB_WR_INT_OTHER_ERROR_MST_MASK  0x00000010
#define MP0_SYSHUB_WR_INT_OTHER_ERROR_AES_MASK  0x00000020
#define MP0_SYSHUB_WR_INT_OTHER_ERROR_AES_RMW_MASK  0x00000100
#define MP0_SYSHUB_WR_INT_OTHER_INT_CLEAR_MASK  0x80000000

#define MP0_SYSHUB_WR_INT_OTHER_MASK \
      (MP0_SYSHUB_WR_INT_OTHER_ERROR_TLB_MASK | \
      MP0_SYSHUB_WR_INT_OTHER_ERROR_PAGE_MASK | \
      MP0_SYSHUB_WR_INT_OTHER_ERROR_ATTRIB_MASK | \
      MP0_SYSHUB_WR_INT_OTHER_ERROR_PROT_MASK | \
      MP0_SYSHUB_WR_INT_OTHER_ERROR_MST_MASK | \
      MP0_SYSHUB_WR_INT_OTHER_ERROR_AES_MASK | \
      MP0_SYSHUB_WR_INT_OTHER_ERROR_AES_RMW_MASK | \
      MP0_SYSHUB_WR_INT_OTHER_INT_CLEAR_MASK)

#define MP0_SYSHUB_WR_INT_OTHER_DEFAULT 0x00000000

#define MP0_SYSHUB_WR_INT_OTHER_GET_ERROR_TLB(mp0_syshub_wr_int_other) \
      ((mp0_syshub_wr_int_other & MP0_SYSHUB_WR_INT_OTHER_ERROR_TLB_MASK) >> MP0_SYSHUB_WR_INT_OTHER_ERROR_TLB_SHIFT)
#define MP0_SYSHUB_WR_INT_OTHER_GET_ERROR_PAGE(mp0_syshub_wr_int_other) \
      ((mp0_syshub_wr_int_other & MP0_SYSHUB_WR_INT_OTHER_ERROR_PAGE_MASK) >> MP0_SYSHUB_WR_INT_OTHER_ERROR_PAGE_SHIFT)
#define MP0_SYSHUB_WR_INT_OTHER_GET_ERROR_ATTRIB(mp0_syshub_wr_int_other) \
      ((mp0_syshub_wr_int_other & MP0_SYSHUB_WR_INT_OTHER_ERROR_ATTRIB_MASK) >> MP0_SYSHUB_WR_INT_OTHER_ERROR_ATTRIB_SHIFT)
#define MP0_SYSHUB_WR_INT_OTHER_GET_ERROR_PROT(mp0_syshub_wr_int_other) \
      ((mp0_syshub_wr_int_other & MP0_SYSHUB_WR_INT_OTHER_ERROR_PROT_MASK) >> MP0_SYSHUB_WR_INT_OTHER_ERROR_PROT_SHIFT)
#define MP0_SYSHUB_WR_INT_OTHER_GET_ERROR_MST(mp0_syshub_wr_int_other) \
      ((mp0_syshub_wr_int_other & MP0_SYSHUB_WR_INT_OTHER_ERROR_MST_MASK) >> MP0_SYSHUB_WR_INT_OTHER_ERROR_MST_SHIFT)
#define MP0_SYSHUB_WR_INT_OTHER_GET_ERROR_AES(mp0_syshub_wr_int_other) \
      ((mp0_syshub_wr_int_other & MP0_SYSHUB_WR_INT_OTHER_ERROR_AES_MASK) >> MP0_SYSHUB_WR_INT_OTHER_ERROR_AES_SHIFT)
#define MP0_SYSHUB_WR_INT_OTHER_GET_ERROR_AES_RMW(mp0_syshub_wr_int_other) \
      ((mp0_syshub_wr_int_other & MP0_SYSHUB_WR_INT_OTHER_ERROR_AES_RMW_MASK) >> MP0_SYSHUB_WR_INT_OTHER_ERROR_AES_RMW_SHIFT)
#define MP0_SYSHUB_WR_INT_OTHER_GET_INT_CLEAR(mp0_syshub_wr_int_other) \
      ((mp0_syshub_wr_int_other & MP0_SYSHUB_WR_INT_OTHER_INT_CLEAR_MASK) >> MP0_SYSHUB_WR_INT_OTHER_INT_CLEAR_SHIFT)

#define MP0_SYSHUB_WR_INT_OTHER_SET_ERROR_TLB(mp0_syshub_wr_int_other_reg, error_tlb) \
      mp0_syshub_wr_int_other_reg = (mp0_syshub_wr_int_other_reg & ~MP0_SYSHUB_WR_INT_OTHER_ERROR_TLB_MASK) | (error_tlb << MP0_SYSHUB_WR_INT_OTHER_ERROR_TLB_SHIFT)
#define MP0_SYSHUB_WR_INT_OTHER_SET_ERROR_PAGE(mp0_syshub_wr_int_other_reg, error_page) \
      mp0_syshub_wr_int_other_reg = (mp0_syshub_wr_int_other_reg & ~MP0_SYSHUB_WR_INT_OTHER_ERROR_PAGE_MASK) | (error_page << MP0_SYSHUB_WR_INT_OTHER_ERROR_PAGE_SHIFT)
#define MP0_SYSHUB_WR_INT_OTHER_SET_ERROR_ATTRIB(mp0_syshub_wr_int_other_reg, error_attrib) \
      mp0_syshub_wr_int_other_reg = (mp0_syshub_wr_int_other_reg & ~MP0_SYSHUB_WR_INT_OTHER_ERROR_ATTRIB_MASK) | (error_attrib << MP0_SYSHUB_WR_INT_OTHER_ERROR_ATTRIB_SHIFT)
#define MP0_SYSHUB_WR_INT_OTHER_SET_ERROR_PROT(mp0_syshub_wr_int_other_reg, error_prot) \
      mp0_syshub_wr_int_other_reg = (mp0_syshub_wr_int_other_reg & ~MP0_SYSHUB_WR_INT_OTHER_ERROR_PROT_MASK) | (error_prot << MP0_SYSHUB_WR_INT_OTHER_ERROR_PROT_SHIFT)
#define MP0_SYSHUB_WR_INT_OTHER_SET_ERROR_MST(mp0_syshub_wr_int_other_reg, error_mst) \
      mp0_syshub_wr_int_other_reg = (mp0_syshub_wr_int_other_reg & ~MP0_SYSHUB_WR_INT_OTHER_ERROR_MST_MASK) | (error_mst << MP0_SYSHUB_WR_INT_OTHER_ERROR_MST_SHIFT)
#define MP0_SYSHUB_WR_INT_OTHER_SET_ERROR_AES(mp0_syshub_wr_int_other_reg, error_aes) \
      mp0_syshub_wr_int_other_reg = (mp0_syshub_wr_int_other_reg & ~MP0_SYSHUB_WR_INT_OTHER_ERROR_AES_MASK) | (error_aes << MP0_SYSHUB_WR_INT_OTHER_ERROR_AES_SHIFT)
#define MP0_SYSHUB_WR_INT_OTHER_SET_ERROR_AES_RMW(mp0_syshub_wr_int_other_reg, error_aes_rmw) \
      mp0_syshub_wr_int_other_reg = (mp0_syshub_wr_int_other_reg & ~MP0_SYSHUB_WR_INT_OTHER_ERROR_AES_RMW_MASK) | (error_aes_rmw << MP0_SYSHUB_WR_INT_OTHER_ERROR_AES_RMW_SHIFT)
#define MP0_SYSHUB_WR_INT_OTHER_SET_INT_CLEAR(mp0_syshub_wr_int_other_reg, int_clear) \
      mp0_syshub_wr_int_other_reg = (mp0_syshub_wr_int_other_reg & ~MP0_SYSHUB_WR_INT_OTHER_INT_CLEAR_MASK) | (int_clear << MP0_SYSHUB_WR_INT_OTHER_INT_CLEAR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_wr_int_other_t {
            unsigned int error_tlb                      : MP0_SYSHUB_WR_INT_OTHER_ERROR_TLB_SIZE;
            unsigned int error_page                     : MP0_SYSHUB_WR_INT_OTHER_ERROR_PAGE_SIZE;
            unsigned int error_attrib                   : MP0_SYSHUB_WR_INT_OTHER_ERROR_ATTRIB_SIZE;
            unsigned int error_prot                     : MP0_SYSHUB_WR_INT_OTHER_ERROR_PROT_SIZE;
            unsigned int error_mst                      : MP0_SYSHUB_WR_INT_OTHER_ERROR_MST_SIZE;
            unsigned int error_aes                      : MP0_SYSHUB_WR_INT_OTHER_ERROR_AES_SIZE;
            unsigned int                                : 2;
            unsigned int error_aes_rmw                  : MP0_SYSHUB_WR_INT_OTHER_ERROR_AES_RMW_SIZE;
            unsigned int                                : 22;
            unsigned int int_clear                      : MP0_SYSHUB_WR_INT_OTHER_INT_CLEAR_SIZE;
      } mp0_syshub_wr_int_other_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_wr_int_other_t {
            unsigned int int_clear                      : MP0_SYSHUB_WR_INT_OTHER_INT_CLEAR_SIZE;
            unsigned int                                : 22;
            unsigned int error_aes_rmw                  : MP0_SYSHUB_WR_INT_OTHER_ERROR_AES_RMW_SIZE;
            unsigned int                                : 2;
            unsigned int error_aes                      : MP0_SYSHUB_WR_INT_OTHER_ERROR_AES_SIZE;
            unsigned int error_mst                      : MP0_SYSHUB_WR_INT_OTHER_ERROR_MST_SIZE;
            unsigned int error_prot                     : MP0_SYSHUB_WR_INT_OTHER_ERROR_PROT_SIZE;
            unsigned int error_attrib                   : MP0_SYSHUB_WR_INT_OTHER_ERROR_ATTRIB_SIZE;
            unsigned int error_page                     : MP0_SYSHUB_WR_INT_OTHER_ERROR_PAGE_SIZE;
            unsigned int error_tlb                      : MP0_SYSHUB_WR_INT_OTHER_ERROR_TLB_SIZE;
      } mp0_syshub_wr_int_other_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_wr_int_other_t f;
} mp0_syshub_wr_int_other_u;


/*
 * MP0_SYSHUB_RD_INT_ADDR struct
 */

#define MP0_SYSHUB_RD_INT_ADDR_REG_SIZE         32
#define MP0_SYSHUB_RD_INT_ADDR_ADDR_SIZE  32

#define MP0_SYSHUB_RD_INT_ADDR_ADDR_SHIFT  0

#define MP0_SYSHUB_RD_INT_ADDR_ADDR_MASK  0xffffffff

#define MP0_SYSHUB_RD_INT_ADDR_MASK \
      (MP0_SYSHUB_RD_INT_ADDR_ADDR_MASK)

#define MP0_SYSHUB_RD_INT_ADDR_DEFAULT 0x00000000

#define MP0_SYSHUB_RD_INT_ADDR_GET_ADDR(mp0_syshub_rd_int_addr) \
      ((mp0_syshub_rd_int_addr & MP0_SYSHUB_RD_INT_ADDR_ADDR_MASK) >> MP0_SYSHUB_RD_INT_ADDR_ADDR_SHIFT)

#define MP0_SYSHUB_RD_INT_ADDR_SET_ADDR(mp0_syshub_rd_int_addr_reg, addr) \
      mp0_syshub_rd_int_addr_reg = (mp0_syshub_rd_int_addr_reg & ~MP0_SYSHUB_RD_INT_ADDR_ADDR_MASK) | (addr << MP0_SYSHUB_RD_INT_ADDR_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_rd_int_addr_t {
            unsigned int addr                           : MP0_SYSHUB_RD_INT_ADDR_ADDR_SIZE;
      } mp0_syshub_rd_int_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_rd_int_addr_t {
            unsigned int addr                           : MP0_SYSHUB_RD_INT_ADDR_ADDR_SIZE;
      } mp0_syshub_rd_int_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_rd_int_addr_t f;
} mp0_syshub_rd_int_addr_u;


/*
 * MP0_SYSHUB_RD_INT_ID struct
 */

#define MP0_SYSHUB_RD_INT_ID_REG_SIZE         32
#define MP0_SYSHUB_RD_INT_ID_AXI_ID_SIZE  21

#define MP0_SYSHUB_RD_INT_ID_AXI_ID_SHIFT  0

#define MP0_SYSHUB_RD_INT_ID_AXI_ID_MASK  0x001fffff

#define MP0_SYSHUB_RD_INT_ID_MASK \
      (MP0_SYSHUB_RD_INT_ID_AXI_ID_MASK)

#define MP0_SYSHUB_RD_INT_ID_DEFAULT   0x00000000

#define MP0_SYSHUB_RD_INT_ID_GET_AXI_ID(mp0_syshub_rd_int_id) \
      ((mp0_syshub_rd_int_id & MP0_SYSHUB_RD_INT_ID_AXI_ID_MASK) >> MP0_SYSHUB_RD_INT_ID_AXI_ID_SHIFT)

#define MP0_SYSHUB_RD_INT_ID_SET_AXI_ID(mp0_syshub_rd_int_id_reg, axi_id) \
      mp0_syshub_rd_int_id_reg = (mp0_syshub_rd_int_id_reg & ~MP0_SYSHUB_RD_INT_ID_AXI_ID_MASK) | (axi_id << MP0_SYSHUB_RD_INT_ID_AXI_ID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_rd_int_id_t {
            unsigned int axi_id                         : MP0_SYSHUB_RD_INT_ID_AXI_ID_SIZE;
            unsigned int                                : 11;
      } mp0_syshub_rd_int_id_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_rd_int_id_t {
            unsigned int                                : 11;
            unsigned int axi_id                         : MP0_SYSHUB_RD_INT_ID_AXI_ID_SIZE;
      } mp0_syshub_rd_int_id_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_rd_int_id_t f;
} mp0_syshub_rd_int_id_u;


/*
 * MP0_SYSHUB_RD_INT_OTHER struct
 */

#define MP0_SYSHUB_RD_INT_OTHER_REG_SIZE         32
#define MP0_SYSHUB_RD_INT_OTHER_ERROR_TLB_SIZE  1
#define MP0_SYSHUB_RD_INT_OTHER_ERROR_PAGE_SIZE  1
#define MP0_SYSHUB_RD_INT_OTHER_ERROR_ATTRIB_SIZE  1
#define MP0_SYSHUB_RD_INT_OTHER_ERROR_PROT_SIZE  1
#define MP0_SYSHUB_RD_INT_OTHER_ERROR_MST_SIZE  1
#define MP0_SYSHUB_RD_INT_OTHER_ERROR_AES_SIZE  1
#define MP0_SYSHUB_RD_INT_OTHER_ERROR_LENGTH_SIZE  1
#define MP0_SYSHUB_RD_INT_OTHER_INT_CLEAR_SIZE  1

#define MP0_SYSHUB_RD_INT_OTHER_ERROR_TLB_SHIFT  0
#define MP0_SYSHUB_RD_INT_OTHER_ERROR_PAGE_SHIFT  1
#define MP0_SYSHUB_RD_INT_OTHER_ERROR_ATTRIB_SHIFT  2
#define MP0_SYSHUB_RD_INT_OTHER_ERROR_PROT_SHIFT  3
#define MP0_SYSHUB_RD_INT_OTHER_ERROR_MST_SHIFT  4
#define MP0_SYSHUB_RD_INT_OTHER_ERROR_AES_SHIFT  5
#define MP0_SYSHUB_RD_INT_OTHER_ERROR_LENGTH_SHIFT  6
#define MP0_SYSHUB_RD_INT_OTHER_INT_CLEAR_SHIFT  31

#define MP0_SYSHUB_RD_INT_OTHER_ERROR_TLB_MASK  0x00000001
#define MP0_SYSHUB_RD_INT_OTHER_ERROR_PAGE_MASK  0x00000002
#define MP0_SYSHUB_RD_INT_OTHER_ERROR_ATTRIB_MASK  0x00000004
#define MP0_SYSHUB_RD_INT_OTHER_ERROR_PROT_MASK  0x00000008
#define MP0_SYSHUB_RD_INT_OTHER_ERROR_MST_MASK  0x00000010
#define MP0_SYSHUB_RD_INT_OTHER_ERROR_AES_MASK  0x00000020
#define MP0_SYSHUB_RD_INT_OTHER_ERROR_LENGTH_MASK  0x00000040
#define MP0_SYSHUB_RD_INT_OTHER_INT_CLEAR_MASK  0x80000000

#define MP0_SYSHUB_RD_INT_OTHER_MASK \
      (MP0_SYSHUB_RD_INT_OTHER_ERROR_TLB_MASK | \
      MP0_SYSHUB_RD_INT_OTHER_ERROR_PAGE_MASK | \
      MP0_SYSHUB_RD_INT_OTHER_ERROR_ATTRIB_MASK | \
      MP0_SYSHUB_RD_INT_OTHER_ERROR_PROT_MASK | \
      MP0_SYSHUB_RD_INT_OTHER_ERROR_MST_MASK | \
      MP0_SYSHUB_RD_INT_OTHER_ERROR_AES_MASK | \
      MP0_SYSHUB_RD_INT_OTHER_ERROR_LENGTH_MASK | \
      MP0_SYSHUB_RD_INT_OTHER_INT_CLEAR_MASK)

#define MP0_SYSHUB_RD_INT_OTHER_DEFAULT 0x00000000

#define MP0_SYSHUB_RD_INT_OTHER_GET_ERROR_TLB(mp0_syshub_rd_int_other) \
      ((mp0_syshub_rd_int_other & MP0_SYSHUB_RD_INT_OTHER_ERROR_TLB_MASK) >> MP0_SYSHUB_RD_INT_OTHER_ERROR_TLB_SHIFT)
#define MP0_SYSHUB_RD_INT_OTHER_GET_ERROR_PAGE(mp0_syshub_rd_int_other) \
      ((mp0_syshub_rd_int_other & MP0_SYSHUB_RD_INT_OTHER_ERROR_PAGE_MASK) >> MP0_SYSHUB_RD_INT_OTHER_ERROR_PAGE_SHIFT)
#define MP0_SYSHUB_RD_INT_OTHER_GET_ERROR_ATTRIB(mp0_syshub_rd_int_other) \
      ((mp0_syshub_rd_int_other & MP0_SYSHUB_RD_INT_OTHER_ERROR_ATTRIB_MASK) >> MP0_SYSHUB_RD_INT_OTHER_ERROR_ATTRIB_SHIFT)
#define MP0_SYSHUB_RD_INT_OTHER_GET_ERROR_PROT(mp0_syshub_rd_int_other) \
      ((mp0_syshub_rd_int_other & MP0_SYSHUB_RD_INT_OTHER_ERROR_PROT_MASK) >> MP0_SYSHUB_RD_INT_OTHER_ERROR_PROT_SHIFT)
#define MP0_SYSHUB_RD_INT_OTHER_GET_ERROR_MST(mp0_syshub_rd_int_other) \
      ((mp0_syshub_rd_int_other & MP0_SYSHUB_RD_INT_OTHER_ERROR_MST_MASK) >> MP0_SYSHUB_RD_INT_OTHER_ERROR_MST_SHIFT)
#define MP0_SYSHUB_RD_INT_OTHER_GET_ERROR_AES(mp0_syshub_rd_int_other) \
      ((mp0_syshub_rd_int_other & MP0_SYSHUB_RD_INT_OTHER_ERROR_AES_MASK) >> MP0_SYSHUB_RD_INT_OTHER_ERROR_AES_SHIFT)
#define MP0_SYSHUB_RD_INT_OTHER_GET_ERROR_LENGTH(mp0_syshub_rd_int_other) \
      ((mp0_syshub_rd_int_other & MP0_SYSHUB_RD_INT_OTHER_ERROR_LENGTH_MASK) >> MP0_SYSHUB_RD_INT_OTHER_ERROR_LENGTH_SHIFT)
#define MP0_SYSHUB_RD_INT_OTHER_GET_INT_CLEAR(mp0_syshub_rd_int_other) \
      ((mp0_syshub_rd_int_other & MP0_SYSHUB_RD_INT_OTHER_INT_CLEAR_MASK) >> MP0_SYSHUB_RD_INT_OTHER_INT_CLEAR_SHIFT)

#define MP0_SYSHUB_RD_INT_OTHER_SET_ERROR_TLB(mp0_syshub_rd_int_other_reg, error_tlb) \
      mp0_syshub_rd_int_other_reg = (mp0_syshub_rd_int_other_reg & ~MP0_SYSHUB_RD_INT_OTHER_ERROR_TLB_MASK) | (error_tlb << MP0_SYSHUB_RD_INT_OTHER_ERROR_TLB_SHIFT)
#define MP0_SYSHUB_RD_INT_OTHER_SET_ERROR_PAGE(mp0_syshub_rd_int_other_reg, error_page) \
      mp0_syshub_rd_int_other_reg = (mp0_syshub_rd_int_other_reg & ~MP0_SYSHUB_RD_INT_OTHER_ERROR_PAGE_MASK) | (error_page << MP0_SYSHUB_RD_INT_OTHER_ERROR_PAGE_SHIFT)
#define MP0_SYSHUB_RD_INT_OTHER_SET_ERROR_ATTRIB(mp0_syshub_rd_int_other_reg, error_attrib) \
      mp0_syshub_rd_int_other_reg = (mp0_syshub_rd_int_other_reg & ~MP0_SYSHUB_RD_INT_OTHER_ERROR_ATTRIB_MASK) | (error_attrib << MP0_SYSHUB_RD_INT_OTHER_ERROR_ATTRIB_SHIFT)
#define MP0_SYSHUB_RD_INT_OTHER_SET_ERROR_PROT(mp0_syshub_rd_int_other_reg, error_prot) \
      mp0_syshub_rd_int_other_reg = (mp0_syshub_rd_int_other_reg & ~MP0_SYSHUB_RD_INT_OTHER_ERROR_PROT_MASK) | (error_prot << MP0_SYSHUB_RD_INT_OTHER_ERROR_PROT_SHIFT)
#define MP0_SYSHUB_RD_INT_OTHER_SET_ERROR_MST(mp0_syshub_rd_int_other_reg, error_mst) \
      mp0_syshub_rd_int_other_reg = (mp0_syshub_rd_int_other_reg & ~MP0_SYSHUB_RD_INT_OTHER_ERROR_MST_MASK) | (error_mst << MP0_SYSHUB_RD_INT_OTHER_ERROR_MST_SHIFT)
#define MP0_SYSHUB_RD_INT_OTHER_SET_ERROR_AES(mp0_syshub_rd_int_other_reg, error_aes) \
      mp0_syshub_rd_int_other_reg = (mp0_syshub_rd_int_other_reg & ~MP0_SYSHUB_RD_INT_OTHER_ERROR_AES_MASK) | (error_aes << MP0_SYSHUB_RD_INT_OTHER_ERROR_AES_SHIFT)
#define MP0_SYSHUB_RD_INT_OTHER_SET_ERROR_LENGTH(mp0_syshub_rd_int_other_reg, error_length) \
      mp0_syshub_rd_int_other_reg = (mp0_syshub_rd_int_other_reg & ~MP0_SYSHUB_RD_INT_OTHER_ERROR_LENGTH_MASK) | (error_length << MP0_SYSHUB_RD_INT_OTHER_ERROR_LENGTH_SHIFT)
#define MP0_SYSHUB_RD_INT_OTHER_SET_INT_CLEAR(mp0_syshub_rd_int_other_reg, int_clear) \
      mp0_syshub_rd_int_other_reg = (mp0_syshub_rd_int_other_reg & ~MP0_SYSHUB_RD_INT_OTHER_INT_CLEAR_MASK) | (int_clear << MP0_SYSHUB_RD_INT_OTHER_INT_CLEAR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_rd_int_other_t {
            unsigned int error_tlb                      : MP0_SYSHUB_RD_INT_OTHER_ERROR_TLB_SIZE;
            unsigned int error_page                     : MP0_SYSHUB_RD_INT_OTHER_ERROR_PAGE_SIZE;
            unsigned int error_attrib                   : MP0_SYSHUB_RD_INT_OTHER_ERROR_ATTRIB_SIZE;
            unsigned int error_prot                     : MP0_SYSHUB_RD_INT_OTHER_ERROR_PROT_SIZE;
            unsigned int error_mst                      : MP0_SYSHUB_RD_INT_OTHER_ERROR_MST_SIZE;
            unsigned int error_aes                      : MP0_SYSHUB_RD_INT_OTHER_ERROR_AES_SIZE;
            unsigned int error_length                   : MP0_SYSHUB_RD_INT_OTHER_ERROR_LENGTH_SIZE;
            unsigned int                                : 24;
            unsigned int int_clear                      : MP0_SYSHUB_RD_INT_OTHER_INT_CLEAR_SIZE;
      } mp0_syshub_rd_int_other_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_rd_int_other_t {
            unsigned int int_clear                      : MP0_SYSHUB_RD_INT_OTHER_INT_CLEAR_SIZE;
            unsigned int                                : 24;
            unsigned int error_length                   : MP0_SYSHUB_RD_INT_OTHER_ERROR_LENGTH_SIZE;
            unsigned int error_aes                      : MP0_SYSHUB_RD_INT_OTHER_ERROR_AES_SIZE;
            unsigned int error_mst                      : MP0_SYSHUB_RD_INT_OTHER_ERROR_MST_SIZE;
            unsigned int error_prot                     : MP0_SYSHUB_RD_INT_OTHER_ERROR_PROT_SIZE;
            unsigned int error_attrib                   : MP0_SYSHUB_RD_INT_OTHER_ERROR_ATTRIB_SIZE;
            unsigned int error_page                     : MP0_SYSHUB_RD_INT_OTHER_ERROR_PAGE_SIZE;
            unsigned int error_tlb                      : MP0_SYSHUB_RD_INT_OTHER_ERROR_TLB_SIZE;
      } mp0_syshub_rd_int_other_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_rd_int_other_t f;
} mp0_syshub_rd_int_other_u;


/*
 * MP0_SYSHUB_REG_INT_ADDR struct
 */

#define MP0_SYSHUB_REG_INT_ADDR_REG_SIZE         32
#define MP0_SYSHUB_REG_INT_ADDR_ADDR_SIZE  16

#define MP0_SYSHUB_REG_INT_ADDR_ADDR_SHIFT  0

#define MP0_SYSHUB_REG_INT_ADDR_ADDR_MASK  0x0000ffff

#define MP0_SYSHUB_REG_INT_ADDR_MASK \
      (MP0_SYSHUB_REG_INT_ADDR_ADDR_MASK)

#define MP0_SYSHUB_REG_INT_ADDR_DEFAULT 0x00000000

#define MP0_SYSHUB_REG_INT_ADDR_GET_ADDR(mp0_syshub_reg_int_addr) \
      ((mp0_syshub_reg_int_addr & MP0_SYSHUB_REG_INT_ADDR_ADDR_MASK) >> MP0_SYSHUB_REG_INT_ADDR_ADDR_SHIFT)

#define MP0_SYSHUB_REG_INT_ADDR_SET_ADDR(mp0_syshub_reg_int_addr_reg, addr) \
      mp0_syshub_reg_int_addr_reg = (mp0_syshub_reg_int_addr_reg & ~MP0_SYSHUB_REG_INT_ADDR_ADDR_MASK) | (addr << MP0_SYSHUB_REG_INT_ADDR_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_reg_int_addr_t {
            unsigned int addr                           : MP0_SYSHUB_REG_INT_ADDR_ADDR_SIZE;
            unsigned int                                : 16;
      } mp0_syshub_reg_int_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_reg_int_addr_t {
            unsigned int                                : 16;
            unsigned int addr                           : MP0_SYSHUB_REG_INT_ADDR_ADDR_SIZE;
      } mp0_syshub_reg_int_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_reg_int_addr_t f;
} mp0_syshub_reg_int_addr_u;


/*
 * MP0_SYSHUB_REG_INT_ID struct
 */

#define MP0_SYSHUB_REG_INT_ID_REG_SIZE         32
#define MP0_SYSHUB_REG_INT_ID_AXI_ID_SIZE  21

#define MP0_SYSHUB_REG_INT_ID_AXI_ID_SHIFT  0

#define MP0_SYSHUB_REG_INT_ID_AXI_ID_MASK  0x001fffff

#define MP0_SYSHUB_REG_INT_ID_MASK \
      (MP0_SYSHUB_REG_INT_ID_AXI_ID_MASK)

#define MP0_SYSHUB_REG_INT_ID_DEFAULT  0x00000000

#define MP0_SYSHUB_REG_INT_ID_GET_AXI_ID(mp0_syshub_reg_int_id) \
      ((mp0_syshub_reg_int_id & MP0_SYSHUB_REG_INT_ID_AXI_ID_MASK) >> MP0_SYSHUB_REG_INT_ID_AXI_ID_SHIFT)

#define MP0_SYSHUB_REG_INT_ID_SET_AXI_ID(mp0_syshub_reg_int_id_reg, axi_id) \
      mp0_syshub_reg_int_id_reg = (mp0_syshub_reg_int_id_reg & ~MP0_SYSHUB_REG_INT_ID_AXI_ID_MASK) | (axi_id << MP0_SYSHUB_REG_INT_ID_AXI_ID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_reg_int_id_t {
            unsigned int axi_id                         : MP0_SYSHUB_REG_INT_ID_AXI_ID_SIZE;
            unsigned int                                : 11;
      } mp0_syshub_reg_int_id_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_reg_int_id_t {
            unsigned int                                : 11;
            unsigned int axi_id                         : MP0_SYSHUB_REG_INT_ID_AXI_ID_SIZE;
      } mp0_syshub_reg_int_id_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_reg_int_id_t f;
} mp0_syshub_reg_int_id_u;


/*
 * MP0_SYSHUB_REG_INT_OTHER struct
 */

#define MP0_SYSHUB_REG_INT_OTHER_REG_SIZE         32
#define MP0_SYSHUB_REG_INT_OTHER_ERROR_AES_SIZE  1
#define MP0_SYSHUB_REG_INT_OTHER_ERROR_MST_SIZE  1
#define MP0_SYSHUB_REG_INT_OTHER_ERROR_ADDR_SIZE  1
#define MP0_SYSHUB_REG_INT_OTHER_ERROR_PROT_SIZE  1
#define MP0_SYSHUB_REG_INT_OTHER_ERROR_GPU_VA_SIZE  1
#define MP0_SYSHUB_REG_INT_OTHER_ERROR_BYPASS_SIZE  1
#define MP0_SYSHUB_REG_INT_OTHER_ERROR_REQIO_SIZE  1
#define MP0_SYSHUB_REG_INT_OTHER_INT_CLEAR_SIZE  1

#define MP0_SYSHUB_REG_INT_OTHER_ERROR_AES_SHIFT  0
#define MP0_SYSHUB_REG_INT_OTHER_ERROR_MST_SHIFT  1
#define MP0_SYSHUB_REG_INT_OTHER_ERROR_ADDR_SHIFT  2
#define MP0_SYSHUB_REG_INT_OTHER_ERROR_PROT_SHIFT  3
#define MP0_SYSHUB_REG_INT_OTHER_ERROR_GPU_VA_SHIFT  5
#define MP0_SYSHUB_REG_INT_OTHER_ERROR_BYPASS_SHIFT  6
#define MP0_SYSHUB_REG_INT_OTHER_ERROR_REQIO_SHIFT  7
#define MP0_SYSHUB_REG_INT_OTHER_INT_CLEAR_SHIFT  31

#define MP0_SYSHUB_REG_INT_OTHER_ERROR_AES_MASK  0x00000001
#define MP0_SYSHUB_REG_INT_OTHER_ERROR_MST_MASK  0x00000002
#define MP0_SYSHUB_REG_INT_OTHER_ERROR_ADDR_MASK  0x00000004
#define MP0_SYSHUB_REG_INT_OTHER_ERROR_PROT_MASK  0x00000008
#define MP0_SYSHUB_REG_INT_OTHER_ERROR_GPU_VA_MASK  0x00000020
#define MP0_SYSHUB_REG_INT_OTHER_ERROR_BYPASS_MASK  0x00000040
#define MP0_SYSHUB_REG_INT_OTHER_ERROR_REQIO_MASK  0x00000080
#define MP0_SYSHUB_REG_INT_OTHER_INT_CLEAR_MASK  0x80000000

#define MP0_SYSHUB_REG_INT_OTHER_MASK \
      (MP0_SYSHUB_REG_INT_OTHER_ERROR_AES_MASK | \
      MP0_SYSHUB_REG_INT_OTHER_ERROR_MST_MASK | \
      MP0_SYSHUB_REG_INT_OTHER_ERROR_ADDR_MASK | \
      MP0_SYSHUB_REG_INT_OTHER_ERROR_PROT_MASK | \
      MP0_SYSHUB_REG_INT_OTHER_ERROR_GPU_VA_MASK | \
      MP0_SYSHUB_REG_INT_OTHER_ERROR_BYPASS_MASK | \
      MP0_SYSHUB_REG_INT_OTHER_ERROR_REQIO_MASK | \
      MP0_SYSHUB_REG_INT_OTHER_INT_CLEAR_MASK)

#define MP0_SYSHUB_REG_INT_OTHER_DEFAULT 0x00000000

#define MP0_SYSHUB_REG_INT_OTHER_GET_ERROR_AES(mp0_syshub_reg_int_other) \
      ((mp0_syshub_reg_int_other & MP0_SYSHUB_REG_INT_OTHER_ERROR_AES_MASK) >> MP0_SYSHUB_REG_INT_OTHER_ERROR_AES_SHIFT)
#define MP0_SYSHUB_REG_INT_OTHER_GET_ERROR_MST(mp0_syshub_reg_int_other) \
      ((mp0_syshub_reg_int_other & MP0_SYSHUB_REG_INT_OTHER_ERROR_MST_MASK) >> MP0_SYSHUB_REG_INT_OTHER_ERROR_MST_SHIFT)
#define MP0_SYSHUB_REG_INT_OTHER_GET_ERROR_ADDR(mp0_syshub_reg_int_other) \
      ((mp0_syshub_reg_int_other & MP0_SYSHUB_REG_INT_OTHER_ERROR_ADDR_MASK) >> MP0_SYSHUB_REG_INT_OTHER_ERROR_ADDR_SHIFT)
#define MP0_SYSHUB_REG_INT_OTHER_GET_ERROR_PROT(mp0_syshub_reg_int_other) \
      ((mp0_syshub_reg_int_other & MP0_SYSHUB_REG_INT_OTHER_ERROR_PROT_MASK) >> MP0_SYSHUB_REG_INT_OTHER_ERROR_PROT_SHIFT)
#define MP0_SYSHUB_REG_INT_OTHER_GET_ERROR_GPU_VA(mp0_syshub_reg_int_other) \
      ((mp0_syshub_reg_int_other & MP0_SYSHUB_REG_INT_OTHER_ERROR_GPU_VA_MASK) >> MP0_SYSHUB_REG_INT_OTHER_ERROR_GPU_VA_SHIFT)
#define MP0_SYSHUB_REG_INT_OTHER_GET_ERROR_BYPASS(mp0_syshub_reg_int_other) \
      ((mp0_syshub_reg_int_other & MP0_SYSHUB_REG_INT_OTHER_ERROR_BYPASS_MASK) >> MP0_SYSHUB_REG_INT_OTHER_ERROR_BYPASS_SHIFT)
#define MP0_SYSHUB_REG_INT_OTHER_GET_ERROR_REQIO(mp0_syshub_reg_int_other) \
      ((mp0_syshub_reg_int_other & MP0_SYSHUB_REG_INT_OTHER_ERROR_REQIO_MASK) >> MP0_SYSHUB_REG_INT_OTHER_ERROR_REQIO_SHIFT)
#define MP0_SYSHUB_REG_INT_OTHER_GET_INT_CLEAR(mp0_syshub_reg_int_other) \
      ((mp0_syshub_reg_int_other & MP0_SYSHUB_REG_INT_OTHER_INT_CLEAR_MASK) >> MP0_SYSHUB_REG_INT_OTHER_INT_CLEAR_SHIFT)

#define MP0_SYSHUB_REG_INT_OTHER_SET_ERROR_AES(mp0_syshub_reg_int_other_reg, error_aes) \
      mp0_syshub_reg_int_other_reg = (mp0_syshub_reg_int_other_reg & ~MP0_SYSHUB_REG_INT_OTHER_ERROR_AES_MASK) | (error_aes << MP0_SYSHUB_REG_INT_OTHER_ERROR_AES_SHIFT)
#define MP0_SYSHUB_REG_INT_OTHER_SET_ERROR_MST(mp0_syshub_reg_int_other_reg, error_mst) \
      mp0_syshub_reg_int_other_reg = (mp0_syshub_reg_int_other_reg & ~MP0_SYSHUB_REG_INT_OTHER_ERROR_MST_MASK) | (error_mst << MP0_SYSHUB_REG_INT_OTHER_ERROR_MST_SHIFT)
#define MP0_SYSHUB_REG_INT_OTHER_SET_ERROR_ADDR(mp0_syshub_reg_int_other_reg, error_addr) \
      mp0_syshub_reg_int_other_reg = (mp0_syshub_reg_int_other_reg & ~MP0_SYSHUB_REG_INT_OTHER_ERROR_ADDR_MASK) | (error_addr << MP0_SYSHUB_REG_INT_OTHER_ERROR_ADDR_SHIFT)
#define MP0_SYSHUB_REG_INT_OTHER_SET_ERROR_PROT(mp0_syshub_reg_int_other_reg, error_prot) \
      mp0_syshub_reg_int_other_reg = (mp0_syshub_reg_int_other_reg & ~MP0_SYSHUB_REG_INT_OTHER_ERROR_PROT_MASK) | (error_prot << MP0_SYSHUB_REG_INT_OTHER_ERROR_PROT_SHIFT)
#define MP0_SYSHUB_REG_INT_OTHER_SET_ERROR_GPU_VA(mp0_syshub_reg_int_other_reg, error_gpu_va) \
      mp0_syshub_reg_int_other_reg = (mp0_syshub_reg_int_other_reg & ~MP0_SYSHUB_REG_INT_OTHER_ERROR_GPU_VA_MASK) | (error_gpu_va << MP0_SYSHUB_REG_INT_OTHER_ERROR_GPU_VA_SHIFT)
#define MP0_SYSHUB_REG_INT_OTHER_SET_ERROR_BYPASS(mp0_syshub_reg_int_other_reg, error_bypass) \
      mp0_syshub_reg_int_other_reg = (mp0_syshub_reg_int_other_reg & ~MP0_SYSHUB_REG_INT_OTHER_ERROR_BYPASS_MASK) | (error_bypass << MP0_SYSHUB_REG_INT_OTHER_ERROR_BYPASS_SHIFT)
#define MP0_SYSHUB_REG_INT_OTHER_SET_ERROR_REQIO(mp0_syshub_reg_int_other_reg, error_reqio) \
      mp0_syshub_reg_int_other_reg = (mp0_syshub_reg_int_other_reg & ~MP0_SYSHUB_REG_INT_OTHER_ERROR_REQIO_MASK) | (error_reqio << MP0_SYSHUB_REG_INT_OTHER_ERROR_REQIO_SHIFT)
#define MP0_SYSHUB_REG_INT_OTHER_SET_INT_CLEAR(mp0_syshub_reg_int_other_reg, int_clear) \
      mp0_syshub_reg_int_other_reg = (mp0_syshub_reg_int_other_reg & ~MP0_SYSHUB_REG_INT_OTHER_INT_CLEAR_MASK) | (int_clear << MP0_SYSHUB_REG_INT_OTHER_INT_CLEAR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_reg_int_other_t {
            unsigned int error_aes                      : MP0_SYSHUB_REG_INT_OTHER_ERROR_AES_SIZE;
            unsigned int error_mst                      : MP0_SYSHUB_REG_INT_OTHER_ERROR_MST_SIZE;
            unsigned int error_addr                     : MP0_SYSHUB_REG_INT_OTHER_ERROR_ADDR_SIZE;
            unsigned int error_prot                     : MP0_SYSHUB_REG_INT_OTHER_ERROR_PROT_SIZE;
            unsigned int                                : 1;
            unsigned int error_gpu_va                   : MP0_SYSHUB_REG_INT_OTHER_ERROR_GPU_VA_SIZE;
            unsigned int error_bypass                   : MP0_SYSHUB_REG_INT_OTHER_ERROR_BYPASS_SIZE;
            unsigned int error_reqio                    : MP0_SYSHUB_REG_INT_OTHER_ERROR_REQIO_SIZE;
            unsigned int                                : 23;
            unsigned int int_clear                      : MP0_SYSHUB_REG_INT_OTHER_INT_CLEAR_SIZE;
      } mp0_syshub_reg_int_other_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_reg_int_other_t {
            unsigned int int_clear                      : MP0_SYSHUB_REG_INT_OTHER_INT_CLEAR_SIZE;
            unsigned int                                : 23;
            unsigned int error_reqio                    : MP0_SYSHUB_REG_INT_OTHER_ERROR_REQIO_SIZE;
            unsigned int error_bypass                   : MP0_SYSHUB_REG_INT_OTHER_ERROR_BYPASS_SIZE;
            unsigned int error_gpu_va                   : MP0_SYSHUB_REG_INT_OTHER_ERROR_GPU_VA_SIZE;
            unsigned int                                : 1;
            unsigned int error_prot                     : MP0_SYSHUB_REG_INT_OTHER_ERROR_PROT_SIZE;
            unsigned int error_addr                     : MP0_SYSHUB_REG_INT_OTHER_ERROR_ADDR_SIZE;
            unsigned int error_mst                      : MP0_SYSHUB_REG_INT_OTHER_ERROR_MST_SIZE;
            unsigned int error_aes                      : MP0_SYSHUB_REG_INT_OTHER_ERROR_AES_SIZE;
      } mp0_syshub_reg_int_other_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_reg_int_other_t f;
} mp0_syshub_reg_int_other_u;


/*
 * MP0_SYSHUB_AXCACHE_CFG struct
 */

#define MP0_SYSHUB_AXCACHE_CFG_REG_SIZE         32
#define MP0_SYSHUB_AXCACHE_CFG_ARCACHE_NONCOH_SIZE  4
#define MP0_SYSHUB_AXCACHE_CFG_ARCACHE_COH_SIZE  4
#define MP0_SYSHUB_AXCACHE_CFG_AWCACHE_NONCOH_SIZE  4
#define MP0_SYSHUB_AXCACHE_CFG_AWCACHE_COH_SIZE  4
#define MP0_SYSHUB_AXCACHE_CFG_QOSW_SIZE  4
#define MP0_SYSHUB_AXCACHE_CFG_QOSR_SIZE  4

#define MP0_SYSHUB_AXCACHE_CFG_ARCACHE_NONCOH_SHIFT  0
#define MP0_SYSHUB_AXCACHE_CFG_ARCACHE_COH_SHIFT  4
#define MP0_SYSHUB_AXCACHE_CFG_AWCACHE_NONCOH_SHIFT  8
#define MP0_SYSHUB_AXCACHE_CFG_AWCACHE_COH_SHIFT  12
#define MP0_SYSHUB_AXCACHE_CFG_QOSW_SHIFT  16
#define MP0_SYSHUB_AXCACHE_CFG_QOSR_SHIFT  20

#define MP0_SYSHUB_AXCACHE_CFG_ARCACHE_NONCOH_MASK  0x0000000f
#define MP0_SYSHUB_AXCACHE_CFG_ARCACHE_COH_MASK  0x000000f0
#define MP0_SYSHUB_AXCACHE_CFG_AWCACHE_NONCOH_MASK  0x00000f00
#define MP0_SYSHUB_AXCACHE_CFG_AWCACHE_COH_MASK  0x0000f000
#define MP0_SYSHUB_AXCACHE_CFG_QOSW_MASK  0x000f0000
#define MP0_SYSHUB_AXCACHE_CFG_QOSR_MASK  0x00f00000

#define MP0_SYSHUB_AXCACHE_CFG_MASK \
      (MP0_SYSHUB_AXCACHE_CFG_ARCACHE_NONCOH_MASK | \
      MP0_SYSHUB_AXCACHE_CFG_ARCACHE_COH_MASK | \
      MP0_SYSHUB_AXCACHE_CFG_AWCACHE_NONCOH_MASK | \
      MP0_SYSHUB_AXCACHE_CFG_AWCACHE_COH_MASK | \
      MP0_SYSHUB_AXCACHE_CFG_QOSW_MASK | \
      MP0_SYSHUB_AXCACHE_CFG_QOSR_MASK)

#define MP0_SYSHUB_AXCACHE_CFG_DEFAULT 0x000073b3

#define MP0_SYSHUB_AXCACHE_CFG_GET_ARCACHE_NONCOH(mp0_syshub_axcache_cfg) \
      ((mp0_syshub_axcache_cfg & MP0_SYSHUB_AXCACHE_CFG_ARCACHE_NONCOH_MASK) >> MP0_SYSHUB_AXCACHE_CFG_ARCACHE_NONCOH_SHIFT)
#define MP0_SYSHUB_AXCACHE_CFG_GET_ARCACHE_COH(mp0_syshub_axcache_cfg) \
      ((mp0_syshub_axcache_cfg & MP0_SYSHUB_AXCACHE_CFG_ARCACHE_COH_MASK) >> MP0_SYSHUB_AXCACHE_CFG_ARCACHE_COH_SHIFT)
#define MP0_SYSHUB_AXCACHE_CFG_GET_AWCACHE_NONCOH(mp0_syshub_axcache_cfg) \
      ((mp0_syshub_axcache_cfg & MP0_SYSHUB_AXCACHE_CFG_AWCACHE_NONCOH_MASK) >> MP0_SYSHUB_AXCACHE_CFG_AWCACHE_NONCOH_SHIFT)
#define MP0_SYSHUB_AXCACHE_CFG_GET_AWCACHE_COH(mp0_syshub_axcache_cfg) \
      ((mp0_syshub_axcache_cfg & MP0_SYSHUB_AXCACHE_CFG_AWCACHE_COH_MASK) >> MP0_SYSHUB_AXCACHE_CFG_AWCACHE_COH_SHIFT)
#define MP0_SYSHUB_AXCACHE_CFG_GET_QOSW(mp0_syshub_axcache_cfg) \
      ((mp0_syshub_axcache_cfg & MP0_SYSHUB_AXCACHE_CFG_QOSW_MASK) >> MP0_SYSHUB_AXCACHE_CFG_QOSW_SHIFT)
#define MP0_SYSHUB_AXCACHE_CFG_GET_QOSR(mp0_syshub_axcache_cfg) \
      ((mp0_syshub_axcache_cfg & MP0_SYSHUB_AXCACHE_CFG_QOSR_MASK) >> MP0_SYSHUB_AXCACHE_CFG_QOSR_SHIFT)

#define MP0_SYSHUB_AXCACHE_CFG_SET_ARCACHE_NONCOH(mp0_syshub_axcache_cfg_reg, arcache_noncoh) \
      mp0_syshub_axcache_cfg_reg = (mp0_syshub_axcache_cfg_reg & ~MP0_SYSHUB_AXCACHE_CFG_ARCACHE_NONCOH_MASK) | (arcache_noncoh << MP0_SYSHUB_AXCACHE_CFG_ARCACHE_NONCOH_SHIFT)
#define MP0_SYSHUB_AXCACHE_CFG_SET_ARCACHE_COH(mp0_syshub_axcache_cfg_reg, arcache_coh) \
      mp0_syshub_axcache_cfg_reg = (mp0_syshub_axcache_cfg_reg & ~MP0_SYSHUB_AXCACHE_CFG_ARCACHE_COH_MASK) | (arcache_coh << MP0_SYSHUB_AXCACHE_CFG_ARCACHE_COH_SHIFT)
#define MP0_SYSHUB_AXCACHE_CFG_SET_AWCACHE_NONCOH(mp0_syshub_axcache_cfg_reg, awcache_noncoh) \
      mp0_syshub_axcache_cfg_reg = (mp0_syshub_axcache_cfg_reg & ~MP0_SYSHUB_AXCACHE_CFG_AWCACHE_NONCOH_MASK) | (awcache_noncoh << MP0_SYSHUB_AXCACHE_CFG_AWCACHE_NONCOH_SHIFT)
#define MP0_SYSHUB_AXCACHE_CFG_SET_AWCACHE_COH(mp0_syshub_axcache_cfg_reg, awcache_coh) \
      mp0_syshub_axcache_cfg_reg = (mp0_syshub_axcache_cfg_reg & ~MP0_SYSHUB_AXCACHE_CFG_AWCACHE_COH_MASK) | (awcache_coh << MP0_SYSHUB_AXCACHE_CFG_AWCACHE_COH_SHIFT)
#define MP0_SYSHUB_AXCACHE_CFG_SET_QOSW(mp0_syshub_axcache_cfg_reg, qosw) \
      mp0_syshub_axcache_cfg_reg = (mp0_syshub_axcache_cfg_reg & ~MP0_SYSHUB_AXCACHE_CFG_QOSW_MASK) | (qosw << MP0_SYSHUB_AXCACHE_CFG_QOSW_SHIFT)
#define MP0_SYSHUB_AXCACHE_CFG_SET_QOSR(mp0_syshub_axcache_cfg_reg, qosr) \
      mp0_syshub_axcache_cfg_reg = (mp0_syshub_axcache_cfg_reg & ~MP0_SYSHUB_AXCACHE_CFG_QOSR_MASK) | (qosr << MP0_SYSHUB_AXCACHE_CFG_QOSR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_axcache_cfg_t {
            unsigned int arcache_noncoh                 : MP0_SYSHUB_AXCACHE_CFG_ARCACHE_NONCOH_SIZE;
            unsigned int arcache_coh                    : MP0_SYSHUB_AXCACHE_CFG_ARCACHE_COH_SIZE;
            unsigned int awcache_noncoh                 : MP0_SYSHUB_AXCACHE_CFG_AWCACHE_NONCOH_SIZE;
            unsigned int awcache_coh                    : MP0_SYSHUB_AXCACHE_CFG_AWCACHE_COH_SIZE;
            unsigned int qosw                           : MP0_SYSHUB_AXCACHE_CFG_QOSW_SIZE;
            unsigned int qosr                           : MP0_SYSHUB_AXCACHE_CFG_QOSR_SIZE;
            unsigned int                                : 8;
      } mp0_syshub_axcache_cfg_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_axcache_cfg_t {
            unsigned int                                : 8;
            unsigned int qosr                           : MP0_SYSHUB_AXCACHE_CFG_QOSR_SIZE;
            unsigned int qosw                           : MP0_SYSHUB_AXCACHE_CFG_QOSW_SIZE;
            unsigned int awcache_coh                    : MP0_SYSHUB_AXCACHE_CFG_AWCACHE_COH_SIZE;
            unsigned int awcache_noncoh                 : MP0_SYSHUB_AXCACHE_CFG_AWCACHE_NONCOH_SIZE;
            unsigned int arcache_coh                    : MP0_SYSHUB_AXCACHE_CFG_ARCACHE_COH_SIZE;
            unsigned int arcache_noncoh                 : MP0_SYSHUB_AXCACHE_CFG_ARCACHE_NONCOH_SIZE;
      } mp0_syshub_axcache_cfg_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_axcache_cfg_t f;
} mp0_syshub_axcache_cfg_u;


/*
 * MP0_SYSHUB_OUTSTANDING_WR struct
 */

#define MP0_SYSHUB_OUTSTANDING_WR_REG_SIZE         32
#define MP0_SYSHUB_OUTSTANDING_WR_PENDING_WR_SIZE  32

#define MP0_SYSHUB_OUTSTANDING_WR_PENDING_WR_SHIFT  0

#define MP0_SYSHUB_OUTSTANDING_WR_PENDING_WR_MASK  0xffffffff

#define MP0_SYSHUB_OUTSTANDING_WR_MASK \
      (MP0_SYSHUB_OUTSTANDING_WR_PENDING_WR_MASK)

#define MP0_SYSHUB_OUTSTANDING_WR_DEFAULT 0x00000000

#define MP0_SYSHUB_OUTSTANDING_WR_GET_PENDING_WR(mp0_syshub_outstanding_wr) \
      ((mp0_syshub_outstanding_wr & MP0_SYSHUB_OUTSTANDING_WR_PENDING_WR_MASK) >> MP0_SYSHUB_OUTSTANDING_WR_PENDING_WR_SHIFT)

#define MP0_SYSHUB_OUTSTANDING_WR_SET_PENDING_WR(mp0_syshub_outstanding_wr_reg, pending_wr) \
      mp0_syshub_outstanding_wr_reg = (mp0_syshub_outstanding_wr_reg & ~MP0_SYSHUB_OUTSTANDING_WR_PENDING_WR_MASK) | (pending_wr << MP0_SYSHUB_OUTSTANDING_WR_PENDING_WR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_outstanding_wr_t {
            unsigned int pending_wr                     : MP0_SYSHUB_OUTSTANDING_WR_PENDING_WR_SIZE;
      } mp0_syshub_outstanding_wr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_outstanding_wr_t {
            unsigned int pending_wr                     : MP0_SYSHUB_OUTSTANDING_WR_PENDING_WR_SIZE;
      } mp0_syshub_outstanding_wr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_outstanding_wr_t f;
} mp0_syshub_outstanding_wr_u;


/*
 * MP0_SYSHUB_OUTSTANDING_RD struct
 */

#define MP0_SYSHUB_OUTSTANDING_RD_REG_SIZE         32
#define MP0_SYSHUB_OUTSTANDING_RD_PENDING_RD_SIZE  32

#define MP0_SYSHUB_OUTSTANDING_RD_PENDING_RD_SHIFT  0

#define MP0_SYSHUB_OUTSTANDING_RD_PENDING_RD_MASK  0xffffffff

#define MP0_SYSHUB_OUTSTANDING_RD_MASK \
      (MP0_SYSHUB_OUTSTANDING_RD_PENDING_RD_MASK)

#define MP0_SYSHUB_OUTSTANDING_RD_DEFAULT 0x00000000

#define MP0_SYSHUB_OUTSTANDING_RD_GET_PENDING_RD(mp0_syshub_outstanding_rd) \
      ((mp0_syshub_outstanding_rd & MP0_SYSHUB_OUTSTANDING_RD_PENDING_RD_MASK) >> MP0_SYSHUB_OUTSTANDING_RD_PENDING_RD_SHIFT)

#define MP0_SYSHUB_OUTSTANDING_RD_SET_PENDING_RD(mp0_syshub_outstanding_rd_reg, pending_rd) \
      mp0_syshub_outstanding_rd_reg = (mp0_syshub_outstanding_rd_reg & ~MP0_SYSHUB_OUTSTANDING_RD_PENDING_RD_MASK) | (pending_rd << MP0_SYSHUB_OUTSTANDING_RD_PENDING_RD_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_outstanding_rd_t {
            unsigned int pending_rd                     : MP0_SYSHUB_OUTSTANDING_RD_PENDING_RD_SIZE;
      } mp0_syshub_outstanding_rd_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_outstanding_rd_t {
            unsigned int pending_rd                     : MP0_SYSHUB_OUTSTANDING_RD_PENDING_RD_SIZE;
      } mp0_syshub_outstanding_rd_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_outstanding_rd_t f;
} mp0_syshub_outstanding_rd_u;


/*
 * MP0_SYSHUB_AWUSER_MASK struct
 */

#define MP0_SYSHUB_AWUSER_MASK_REG_SIZE         32
#define MP0_SYSHUB_AWUSER_MASK_AWUSER_MASK_SIZE  32

#define MP0_SYSHUB_AWUSER_MASK_AWUSER_MASK_SHIFT  0

#define MP0_SYSHUB_AWUSER_MASK_AWUSER_MASK_MASK  0xffffffff

#define MP0_SYSHUB_AWUSER_MASK_MASK \
      (MP0_SYSHUB_AWUSER_MASK_AWUSER_MASK_MASK)

#define MP0_SYSHUB_AWUSER_MASK_DEFAULT 0x00000000

#define MP0_SYSHUB_AWUSER_MASK_GET_AWUSER_MASK(mp0_syshub_awuser_mask) \
      ((mp0_syshub_awuser_mask & MP0_SYSHUB_AWUSER_MASK_AWUSER_MASK_MASK) >> MP0_SYSHUB_AWUSER_MASK_AWUSER_MASK_SHIFT)

#define MP0_SYSHUB_AWUSER_MASK_SET_AWUSER_MASK(mp0_syshub_awuser_mask_reg, awuser_mask) \
      mp0_syshub_awuser_mask_reg = (mp0_syshub_awuser_mask_reg & ~MP0_SYSHUB_AWUSER_MASK_AWUSER_MASK_MASK) | (awuser_mask << MP0_SYSHUB_AWUSER_MASK_AWUSER_MASK_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_awuser_mask_t {
            unsigned int awuser_mask                    : MP0_SYSHUB_AWUSER_MASK_AWUSER_MASK_SIZE;
      } mp0_syshub_awuser_mask_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_awuser_mask_t {
            unsigned int awuser_mask                    : MP0_SYSHUB_AWUSER_MASK_AWUSER_MASK_SIZE;
      } mp0_syshub_awuser_mask_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_awuser_mask_t f;
} mp0_syshub_awuser_mask_u;


/*
 * MP0_SYSHUB_AWUSER_VALUE struct
 */

#define MP0_SYSHUB_AWUSER_VALUE_REG_SIZE         32
#define MP0_SYSHUB_AWUSER_VALUE_AWUSER_VALUE_SIZE  32

#define MP0_SYSHUB_AWUSER_VALUE_AWUSER_VALUE_SHIFT  0

#define MP0_SYSHUB_AWUSER_VALUE_AWUSER_VALUE_MASK  0xffffffff

#define MP0_SYSHUB_AWUSER_VALUE_MASK \
      (MP0_SYSHUB_AWUSER_VALUE_AWUSER_VALUE_MASK)

#define MP0_SYSHUB_AWUSER_VALUE_DEFAULT 0x00000000

#define MP0_SYSHUB_AWUSER_VALUE_GET_AWUSER_VALUE(mp0_syshub_awuser_value) \
      ((mp0_syshub_awuser_value & MP0_SYSHUB_AWUSER_VALUE_AWUSER_VALUE_MASK) >> MP0_SYSHUB_AWUSER_VALUE_AWUSER_VALUE_SHIFT)

#define MP0_SYSHUB_AWUSER_VALUE_SET_AWUSER_VALUE(mp0_syshub_awuser_value_reg, awuser_value) \
      mp0_syshub_awuser_value_reg = (mp0_syshub_awuser_value_reg & ~MP0_SYSHUB_AWUSER_VALUE_AWUSER_VALUE_MASK) | (awuser_value << MP0_SYSHUB_AWUSER_VALUE_AWUSER_VALUE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_awuser_value_t {
            unsigned int awuser_value                   : MP0_SYSHUB_AWUSER_VALUE_AWUSER_VALUE_SIZE;
      } mp0_syshub_awuser_value_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_awuser_value_t {
            unsigned int awuser_value                   : MP0_SYSHUB_AWUSER_VALUE_AWUSER_VALUE_SIZE;
      } mp0_syshub_awuser_value_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_awuser_value_t f;
} mp0_syshub_awuser_value_u;


/*
 * MP0_SYSHUB_ARUSER_MASK struct
 */

#define MP0_SYSHUB_ARUSER_MASK_REG_SIZE         32
#define MP0_SYSHUB_ARUSER_MASK_ARUSER_MASK_SIZE  32

#define MP0_SYSHUB_ARUSER_MASK_ARUSER_MASK_SHIFT  0

#define MP0_SYSHUB_ARUSER_MASK_ARUSER_MASK_MASK  0xffffffff

#define MP0_SYSHUB_ARUSER_MASK_MASK \
      (MP0_SYSHUB_ARUSER_MASK_ARUSER_MASK_MASK)

#define MP0_SYSHUB_ARUSER_MASK_DEFAULT 0x00000000

#define MP0_SYSHUB_ARUSER_MASK_GET_ARUSER_MASK(mp0_syshub_aruser_mask) \
      ((mp0_syshub_aruser_mask & MP0_SYSHUB_ARUSER_MASK_ARUSER_MASK_MASK) >> MP0_SYSHUB_ARUSER_MASK_ARUSER_MASK_SHIFT)

#define MP0_SYSHUB_ARUSER_MASK_SET_ARUSER_MASK(mp0_syshub_aruser_mask_reg, aruser_mask) \
      mp0_syshub_aruser_mask_reg = (mp0_syshub_aruser_mask_reg & ~MP0_SYSHUB_ARUSER_MASK_ARUSER_MASK_MASK) | (aruser_mask << MP0_SYSHUB_ARUSER_MASK_ARUSER_MASK_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_aruser_mask_t {
            unsigned int aruser_mask                    : MP0_SYSHUB_ARUSER_MASK_ARUSER_MASK_SIZE;
      } mp0_syshub_aruser_mask_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_aruser_mask_t {
            unsigned int aruser_mask                    : MP0_SYSHUB_ARUSER_MASK_ARUSER_MASK_SIZE;
      } mp0_syshub_aruser_mask_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_aruser_mask_t f;
} mp0_syshub_aruser_mask_u;


/*
 * MP0_SYSHUB_ARUSER_VALUE struct
 */

#define MP0_SYSHUB_ARUSER_VALUE_REG_SIZE         32
#define MP0_SYSHUB_ARUSER_VALUE_ARUSER_VALUE_SIZE  32

#define MP0_SYSHUB_ARUSER_VALUE_ARUSER_VALUE_SHIFT  0

#define MP0_SYSHUB_ARUSER_VALUE_ARUSER_VALUE_MASK  0xffffffff

#define MP0_SYSHUB_ARUSER_VALUE_MASK \
      (MP0_SYSHUB_ARUSER_VALUE_ARUSER_VALUE_MASK)

#define MP0_SYSHUB_ARUSER_VALUE_DEFAULT 0x00000000

#define MP0_SYSHUB_ARUSER_VALUE_GET_ARUSER_VALUE(mp0_syshub_aruser_value) \
      ((mp0_syshub_aruser_value & MP0_SYSHUB_ARUSER_VALUE_ARUSER_VALUE_MASK) >> MP0_SYSHUB_ARUSER_VALUE_ARUSER_VALUE_SHIFT)

#define MP0_SYSHUB_ARUSER_VALUE_SET_ARUSER_VALUE(mp0_syshub_aruser_value_reg, aruser_value) \
      mp0_syshub_aruser_value_reg = (mp0_syshub_aruser_value_reg & ~MP0_SYSHUB_ARUSER_VALUE_ARUSER_VALUE_MASK) | (aruser_value << MP0_SYSHUB_ARUSER_VALUE_ARUSER_VALUE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_aruser_value_t {
            unsigned int aruser_value                   : MP0_SYSHUB_ARUSER_VALUE_ARUSER_VALUE_SIZE;
      } mp0_syshub_aruser_value_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_aruser_value_t {
            unsigned int aruser_value                   : MP0_SYSHUB_ARUSER_VALUE_ARUSER_VALUE_SIZE;
      } mp0_syshub_aruser_value_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_aruser_value_t f;
} mp0_syshub_aruser_value_u;


/*
 * MP0_SYSHUB_BRESP_MASK_CTRL struct
 */

#define MP0_SYSHUB_BRESP_MASK_CTRL_REG_SIZE         32
#define MP0_SYSHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_SIZE  2
#define MP0_SYSHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_SIZE  1
#define MP0_SYSHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_SIZE  1

#define MP0_SYSHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_SHIFT  0
#define MP0_SYSHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_SHIFT  2
#define MP0_SYSHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_SHIFT  3

#define MP0_SYSHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_MASK  0x00000003
#define MP0_SYSHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_MASK  0x00000004
#define MP0_SYSHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_MASK  0x00000008

#define MP0_SYSHUB_BRESP_MASK_CTRL_MASK \
      (MP0_SYSHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_MASK | \
      MP0_SYSHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_MASK | \
      MP0_SYSHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_MASK)

#define MP0_SYSHUB_BRESP_MASK_CTRL_DEFAULT 0x00000000

#define MP0_SYSHUB_BRESP_MASK_CTRL_GET_MASK_BRESP_ERROR(mp0_syshub_bresp_mask_ctrl) \
      ((mp0_syshub_bresp_mask_ctrl & MP0_SYSHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_MASK) >> MP0_SYSHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_SHIFT)
#define MP0_SYSHUB_BRESP_MASK_CTRL_GET_WR_RESP_INT_TRIG_EN(mp0_syshub_bresp_mask_ctrl) \
      ((mp0_syshub_bresp_mask_ctrl & MP0_SYSHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_MASK) >> MP0_SYSHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_SHIFT)
#define MP0_SYSHUB_BRESP_MASK_CTRL_GET_CLR_AXI_WR_ERR_CNT(mp0_syshub_bresp_mask_ctrl) \
      ((mp0_syshub_bresp_mask_ctrl & MP0_SYSHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_MASK) >> MP0_SYSHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_SHIFT)

#define MP0_SYSHUB_BRESP_MASK_CTRL_SET_MASK_BRESP_ERROR(mp0_syshub_bresp_mask_ctrl_reg, mask_bresp_error) \
      mp0_syshub_bresp_mask_ctrl_reg = (mp0_syshub_bresp_mask_ctrl_reg & ~MP0_SYSHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_MASK) | (mask_bresp_error << MP0_SYSHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_SHIFT)
#define MP0_SYSHUB_BRESP_MASK_CTRL_SET_WR_RESP_INT_TRIG_EN(mp0_syshub_bresp_mask_ctrl_reg, wr_resp_int_trig_en) \
      mp0_syshub_bresp_mask_ctrl_reg = (mp0_syshub_bresp_mask_ctrl_reg & ~MP0_SYSHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_MASK) | (wr_resp_int_trig_en << MP0_SYSHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_SHIFT)
#define MP0_SYSHUB_BRESP_MASK_CTRL_SET_CLR_AXI_WR_ERR_CNT(mp0_syshub_bresp_mask_ctrl_reg, clr_axi_wr_err_cnt) \
      mp0_syshub_bresp_mask_ctrl_reg = (mp0_syshub_bresp_mask_ctrl_reg & ~MP0_SYSHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_MASK) | (clr_axi_wr_err_cnt << MP0_SYSHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_bresp_mask_ctrl_t {
            unsigned int mask_bresp_error               : MP0_SYSHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_SIZE;
            unsigned int wr_resp_int_trig_en            : MP0_SYSHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_SIZE;
            unsigned int clr_axi_wr_err_cnt             : MP0_SYSHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_SIZE;
            unsigned int                                : 28;
      } mp0_syshub_bresp_mask_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_bresp_mask_ctrl_t {
            unsigned int                                : 28;
            unsigned int clr_axi_wr_err_cnt             : MP0_SYSHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_SIZE;
            unsigned int wr_resp_int_trig_en            : MP0_SYSHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_SIZE;
            unsigned int mask_bresp_error               : MP0_SYSHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_SIZE;
      } mp0_syshub_bresp_mask_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_bresp_mask_ctrl_t f;
} mp0_syshub_bresp_mask_ctrl_u;


/*
 * MP0_SYSHUB_AXI_WR_ERR_CNT struct
 */

#define MP0_SYSHUB_AXI_WR_ERR_CNT_REG_SIZE         32
#define MP0_SYSHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_SIZE  32

#define MP0_SYSHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_SHIFT  0

#define MP0_SYSHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_MASK  0xffffffff

#define MP0_SYSHUB_AXI_WR_ERR_CNT_MASK \
      (MP0_SYSHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_MASK)

#define MP0_SYSHUB_AXI_WR_ERR_CNT_DEFAULT 0x00000000

#define MP0_SYSHUB_AXI_WR_ERR_CNT_GET_AXI_WR_ERR_CNT(mp0_syshub_axi_wr_err_cnt) \
      ((mp0_syshub_axi_wr_err_cnt & MP0_SYSHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_MASK) >> MP0_SYSHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_SHIFT)

#define MP0_SYSHUB_AXI_WR_ERR_CNT_SET_AXI_WR_ERR_CNT(mp0_syshub_axi_wr_err_cnt_reg, axi_wr_err_cnt) \
      mp0_syshub_axi_wr_err_cnt_reg = (mp0_syshub_axi_wr_err_cnt_reg & ~MP0_SYSHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_MASK) | (axi_wr_err_cnt << MP0_SYSHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_axi_wr_err_cnt_t {
            unsigned int axi_wr_err_cnt                 : MP0_SYSHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_SIZE;
      } mp0_syshub_axi_wr_err_cnt_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_axi_wr_err_cnt_t {
            unsigned int axi_wr_err_cnt                 : MP0_SYSHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_SIZE;
      } mp0_syshub_axi_wr_err_cnt_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_axi_wr_err_cnt_t f;
} mp0_syshub_axi_wr_err_cnt_u;


/*
 * MP0_SYSHUB_RRESP_MASK_CTRL struct
 */

#define MP0_SYSHUB_RRESP_MASK_CTRL_REG_SIZE         32
#define MP0_SYSHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_SIZE  2
#define MP0_SYSHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_SIZE  1
#define MP0_SYSHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_SIZE  1

#define MP0_SYSHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_SHIFT  0
#define MP0_SYSHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_SHIFT  2
#define MP0_SYSHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_SHIFT  3

#define MP0_SYSHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_MASK  0x00000003
#define MP0_SYSHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_MASK  0x00000004
#define MP0_SYSHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_MASK  0x00000008

#define MP0_SYSHUB_RRESP_MASK_CTRL_MASK \
      (MP0_SYSHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_MASK | \
      MP0_SYSHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_MASK | \
      MP0_SYSHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_MASK)

#define MP0_SYSHUB_RRESP_MASK_CTRL_DEFAULT 0x00000000

#define MP0_SYSHUB_RRESP_MASK_CTRL_GET_MASK_RRESP_ERROR(mp0_syshub_rresp_mask_ctrl) \
      ((mp0_syshub_rresp_mask_ctrl & MP0_SYSHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_MASK) >> MP0_SYSHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_SHIFT)
#define MP0_SYSHUB_RRESP_MASK_CTRL_GET_RD_RESP_INT_TRIG_EN(mp0_syshub_rresp_mask_ctrl) \
      ((mp0_syshub_rresp_mask_ctrl & MP0_SYSHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_MASK) >> MP0_SYSHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_SHIFT)
#define MP0_SYSHUB_RRESP_MASK_CTRL_GET_CLR_AXI_RD_ERR_CNT(mp0_syshub_rresp_mask_ctrl) \
      ((mp0_syshub_rresp_mask_ctrl & MP0_SYSHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_MASK) >> MP0_SYSHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_SHIFT)

#define MP0_SYSHUB_RRESP_MASK_CTRL_SET_MASK_RRESP_ERROR(mp0_syshub_rresp_mask_ctrl_reg, mask_rresp_error) \
      mp0_syshub_rresp_mask_ctrl_reg = (mp0_syshub_rresp_mask_ctrl_reg & ~MP0_SYSHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_MASK) | (mask_rresp_error << MP0_SYSHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_SHIFT)
#define MP0_SYSHUB_RRESP_MASK_CTRL_SET_RD_RESP_INT_TRIG_EN(mp0_syshub_rresp_mask_ctrl_reg, rd_resp_int_trig_en) \
      mp0_syshub_rresp_mask_ctrl_reg = (mp0_syshub_rresp_mask_ctrl_reg & ~MP0_SYSHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_MASK) | (rd_resp_int_trig_en << MP0_SYSHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_SHIFT)
#define MP0_SYSHUB_RRESP_MASK_CTRL_SET_CLR_AXI_RD_ERR_CNT(mp0_syshub_rresp_mask_ctrl_reg, clr_axi_rd_err_cnt) \
      mp0_syshub_rresp_mask_ctrl_reg = (mp0_syshub_rresp_mask_ctrl_reg & ~MP0_SYSHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_MASK) | (clr_axi_rd_err_cnt << MP0_SYSHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_rresp_mask_ctrl_t {
            unsigned int mask_rresp_error               : MP0_SYSHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_SIZE;
            unsigned int rd_resp_int_trig_en            : MP0_SYSHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_SIZE;
            unsigned int clr_axi_rd_err_cnt             : MP0_SYSHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_SIZE;
            unsigned int                                : 28;
      } mp0_syshub_rresp_mask_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_rresp_mask_ctrl_t {
            unsigned int                                : 28;
            unsigned int clr_axi_rd_err_cnt             : MP0_SYSHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_SIZE;
            unsigned int rd_resp_int_trig_en            : MP0_SYSHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_SIZE;
            unsigned int mask_rresp_error               : MP0_SYSHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_SIZE;
      } mp0_syshub_rresp_mask_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_rresp_mask_ctrl_t f;
} mp0_syshub_rresp_mask_ctrl_u;


/*
 * MP0_SYSHUB_AXI_RD_ERR_CNT struct
 */

#define MP0_SYSHUB_AXI_RD_ERR_CNT_REG_SIZE         32
#define MP0_SYSHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_SIZE  32

#define MP0_SYSHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_SHIFT  0

#define MP0_SYSHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_MASK  0xffffffff

#define MP0_SYSHUB_AXI_RD_ERR_CNT_MASK \
      (MP0_SYSHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_MASK)

#define MP0_SYSHUB_AXI_RD_ERR_CNT_DEFAULT 0x00000000

#define MP0_SYSHUB_AXI_RD_ERR_CNT_GET_AXI_RD_ERR_CNT(mp0_syshub_axi_rd_err_cnt) \
      ((mp0_syshub_axi_rd_err_cnt & MP0_SYSHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_MASK) >> MP0_SYSHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_SHIFT)

#define MP0_SYSHUB_AXI_RD_ERR_CNT_SET_AXI_RD_ERR_CNT(mp0_syshub_axi_rd_err_cnt_reg, axi_rd_err_cnt) \
      mp0_syshub_axi_rd_err_cnt_reg = (mp0_syshub_axi_rd_err_cnt_reg & ~MP0_SYSHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_MASK) | (axi_rd_err_cnt << MP0_SYSHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_axi_rd_err_cnt_t {
            unsigned int axi_rd_err_cnt                 : MP0_SYSHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_SIZE;
      } mp0_syshub_axi_rd_err_cnt_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_axi_rd_err_cnt_t {
            unsigned int axi_rd_err_cnt                 : MP0_SYSHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_SIZE;
      } mp0_syshub_axi_rd_err_cnt_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_axi_rd_err_cnt_t f;
} mp0_syshub_axi_rd_err_cnt_u;


/*
 * MP0_SYSHUB_OBFF_EMUL struct
 */

#define MP0_SYSHUB_OBFF_EMUL_REG_SIZE         32
#define MP0_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_INTR_SIZE  1
#define MP0_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SIZE  1

#define MP0_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_INTR_SHIFT  0
#define MP0_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SHIFT  1

#define MP0_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_INTR_MASK  0x00000001
#define MP0_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_MASK  0x00000002

#define MP0_SYSHUB_OBFF_EMUL_MASK \
      (MP0_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_INTR_MASK | \
      MP0_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_MASK)

#define MP0_SYSHUB_OBFF_EMUL_DEFAULT   0x00000000

#define MP0_SYSHUB_OBFF_EMUL_GET_IP_SYSHUB_URGENT_INTR(mp0_syshub_obff_emul) \
      ((mp0_syshub_obff_emul & MP0_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_INTR_MASK) >> MP0_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_INTR_SHIFT)
#define MP0_SYSHUB_OBFF_EMUL_GET_IP_SYSHUB_URGENT_DMA(mp0_syshub_obff_emul) \
      ((mp0_syshub_obff_emul & MP0_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_MASK) >> MP0_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SHIFT)

#define MP0_SYSHUB_OBFF_EMUL_SET_IP_SYSHUB_URGENT_INTR(mp0_syshub_obff_emul_reg, ip_syshub_urgent_intr) \
      mp0_syshub_obff_emul_reg = (mp0_syshub_obff_emul_reg & ~MP0_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_INTR_MASK) | (ip_syshub_urgent_intr << MP0_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_INTR_SHIFT)
#define MP0_SYSHUB_OBFF_EMUL_SET_IP_SYSHUB_URGENT_DMA(mp0_syshub_obff_emul_reg, ip_syshub_urgent_dma) \
      mp0_syshub_obff_emul_reg = (mp0_syshub_obff_emul_reg & ~MP0_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_MASK) | (ip_syshub_urgent_dma << MP0_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_obff_emul_t {
            unsigned int ip_syshub_urgent_intr          : MP0_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_INTR_SIZE;
            unsigned int ip_syshub_urgent_dma           : MP0_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SIZE;
            unsigned int                                : 30;
      } mp0_syshub_obff_emul_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_obff_emul_t {
            unsigned int                                : 30;
            unsigned int ip_syshub_urgent_dma           : MP0_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SIZE;
            unsigned int ip_syshub_urgent_intr          : MP0_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_INTR_SIZE;
      } mp0_syshub_obff_emul_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_obff_emul_t f;
} mp0_syshub_obff_emul_u;


/*
 * MP0_SYSHUB_RMW_CONTROL struct
 */

#define MP0_SYSHUB_RMW_CONTROL_REG_SIZE         32
#define MP0_SYSHUB_RMW_CONTROL_AES_RMW_ENABLE_SIZE  1

#define MP0_SYSHUB_RMW_CONTROL_AES_RMW_ENABLE_SHIFT  0

#define MP0_SYSHUB_RMW_CONTROL_AES_RMW_ENABLE_MASK  0x00000001

#define MP0_SYSHUB_RMW_CONTROL_MASK \
      (MP0_SYSHUB_RMW_CONTROL_AES_RMW_ENABLE_MASK)

#define MP0_SYSHUB_RMW_CONTROL_DEFAULT 0x00000000

#define MP0_SYSHUB_RMW_CONTROL_GET_AES_RMW_ENABLE(mp0_syshub_rmw_control) \
      ((mp0_syshub_rmw_control & MP0_SYSHUB_RMW_CONTROL_AES_RMW_ENABLE_MASK) >> MP0_SYSHUB_RMW_CONTROL_AES_RMW_ENABLE_SHIFT)

#define MP0_SYSHUB_RMW_CONTROL_SET_AES_RMW_ENABLE(mp0_syshub_rmw_control_reg, aes_rmw_enable) \
      mp0_syshub_rmw_control_reg = (mp0_syshub_rmw_control_reg & ~MP0_SYSHUB_RMW_CONTROL_AES_RMW_ENABLE_MASK) | (aes_rmw_enable << MP0_SYSHUB_RMW_CONTROL_AES_RMW_ENABLE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_rmw_control_t {
            unsigned int aes_rmw_enable                 : MP0_SYSHUB_RMW_CONTROL_AES_RMW_ENABLE_SIZE;
            unsigned int                                : 31;
      } mp0_syshub_rmw_control_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_rmw_control_t {
            unsigned int                                : 31;
            unsigned int aes_rmw_enable                 : MP0_SYSHUB_RMW_CONTROL_AES_RMW_ENABLE_SIZE;
      } mp0_syshub_rmw_control_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_rmw_control_t f;
} mp0_syshub_rmw_control_u;


#endif

