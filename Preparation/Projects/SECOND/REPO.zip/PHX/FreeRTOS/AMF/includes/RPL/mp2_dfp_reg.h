// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MP2_DFP_FIDDLE_H)
#define _MP2_DFP_FIDDLE_H

/*****************************************************************************************************************
 *
 *	mp2_dfp_reg.h
 *
 *	Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif


/*******************************************************
 * Values
 *******************************************************/


/*******************************************************
 * Structures
 *******************************************************/

/*
 * MP2_PSP_ACCESS_ONLY struct
 */

#define MP2_PSP_ACCESS_ONLY_REG_SIZE   32
#define MP2_PSP_ACCESS_ONLY_PSP_FORCE_PG_SIZE 1

#define MP2_PSP_ACCESS_ONLY_PSP_FORCE_PG_SHIFT 0

#define MP2_PSP_ACCESS_ONLY_PSP_FORCE_PG_MASK 0x1

#define MP2_PSP_ACCESS_ONLY_MASK \
     (MP2_PSP_ACCESS_ONLY_PSP_FORCE_PG_MASK)

#define MP2_PSP_ACCESS_ONLY_DEFAULT    0x00000000

#define MP2_PSP_ACCESS_ONLY_GET_PSP_FORCE_PG(mp2_psp_access_only) \
     ((mp2_psp_access_only & MP2_PSP_ACCESS_ONLY_PSP_FORCE_PG_MASK) >> MP2_PSP_ACCESS_ONLY_PSP_FORCE_PG_SHIFT)

#define MP2_PSP_ACCESS_ONLY_SET_PSP_FORCE_PG(mp2_psp_access_only_reg, psp_force_pg) \
     mp2_psp_access_only_reg = (mp2_psp_access_only_reg & ~MP2_PSP_ACCESS_ONLY_PSP_FORCE_PG_MASK) | (psp_force_pg << MP2_PSP_ACCESS_ONLY_PSP_FORCE_PG_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_psp_access_only_t {
          unsigned int psp_force_pg                   : MP2_PSP_ACCESS_ONLY_PSP_FORCE_PG_SIZE;
          unsigned int                                : 31;
     } mp2_psp_access_only_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_psp_access_only_t {
          unsigned int                                : 31;
          unsigned int psp_force_pg                   : MP2_PSP_ACCESS_ONLY_PSP_FORCE_PG_SIZE;
     } mp2_psp_access_only_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_psp_access_only_t f;
} mp2_psp_access_only_u;


/*
 * MP2_MPCLK_XBAR_CG_CTRL struct
 */

#define MP2_MPCLK_XBAR_CG_CTRL_REG_SIZE 32
#define MP2_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SIZE 1

#define MP2_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SHIFT 0

#define MP2_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_MASK 0x1

#define MP2_MPCLK_XBAR_CG_CTRL_MASK \
     (MP2_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_MASK)

#define MP2_MPCLK_XBAR_CG_CTRL_DEFAULT 0x00000000

#define MP2_MPCLK_XBAR_CG_CTRL_GET_MPCLK_XBAR_CACTIVE_EN(mp2_mpclk_xbar_cg_ctrl) \
     ((mp2_mpclk_xbar_cg_ctrl & MP2_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_MASK) >> MP2_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SHIFT)

#define MP2_MPCLK_XBAR_CG_CTRL_SET_MPCLK_XBAR_CACTIVE_EN(mp2_mpclk_xbar_cg_ctrl_reg, mpclk_xbar_cactive_en) \
     mp2_mpclk_xbar_cg_ctrl_reg = (mp2_mpclk_xbar_cg_ctrl_reg & ~MP2_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_MASK) | (mpclk_xbar_cactive_en << MP2_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mpclk_xbar_cg_ctrl_t {
          unsigned int mpclk_xbar_cactive_en          : MP2_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SIZE;
          unsigned int                                : 31;
     } mp2_mpclk_xbar_cg_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mpclk_xbar_cg_ctrl_t {
          unsigned int                                : 31;
          unsigned int mpclk_xbar_cactive_en          : MP2_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SIZE;
     } mp2_mpclk_xbar_cg_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mpclk_xbar_cg_ctrl_t f;
} mp2_mpclk_xbar_cg_ctrl_u;


/*
 * MP2_MPCLK_XBAR_CG_EN struct
 */

#define MP2_MPCLK_XBAR_CG_EN_REG_SIZE  32
#define MP2_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SIZE 1
#define MP2_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SIZE 1

#define MP2_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SHIFT 1
#define MP2_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SHIFT 2

#define MP2_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_MASK 0x2
#define MP2_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_MASK 0x4

#define MP2_MPCLK_XBAR_CG_EN_MASK \
     (MP2_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_MASK | \
      MP2_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_MASK)

#define MP2_MPCLK_XBAR_CG_EN_DEFAULT   0x00000000

#define MP2_MPCLK_XBAR_CG_EN_GET_MPCLK_XBAR_CG_EN_0(mp2_mpclk_xbar_cg_en) \
     ((mp2_mpclk_xbar_cg_en & MP2_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_MASK) >> MP2_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SHIFT)
#define MP2_MPCLK_XBAR_CG_EN_GET_MPCLK_XBAR_CG_OVERRIDE_0(mp2_mpclk_xbar_cg_en) \
     ((mp2_mpclk_xbar_cg_en & MP2_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_MASK) >> MP2_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SHIFT)

#define MP2_MPCLK_XBAR_CG_EN_SET_MPCLK_XBAR_CG_EN_0(mp2_mpclk_xbar_cg_en_reg, mpclk_xbar_cg_en_0) \
     mp2_mpclk_xbar_cg_en_reg = (mp2_mpclk_xbar_cg_en_reg & ~MP2_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_MASK) | (mpclk_xbar_cg_en_0 << MP2_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SHIFT)
#define MP2_MPCLK_XBAR_CG_EN_SET_MPCLK_XBAR_CG_OVERRIDE_0(mp2_mpclk_xbar_cg_en_reg, mpclk_xbar_cg_override_0) \
     mp2_mpclk_xbar_cg_en_reg = (mp2_mpclk_xbar_cg_en_reg & ~MP2_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_MASK) | (mpclk_xbar_cg_override_0 << MP2_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mpclk_xbar_cg_en_t {
          unsigned int                                : 1;
          unsigned int mpclk_xbar_cg_en_0             : MP2_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SIZE;
          unsigned int mpclk_xbar_cg_override_0       : MP2_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SIZE;
          unsigned int                                : 29;
     } mp2_mpclk_xbar_cg_en_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mpclk_xbar_cg_en_t {
          unsigned int                                : 29;
          unsigned int mpclk_xbar_cg_override_0       : MP2_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SIZE;
          unsigned int mpclk_xbar_cg_en_0             : MP2_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SIZE;
          unsigned int                                : 1;
     } mp2_mpclk_xbar_cg_en_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mpclk_xbar_cg_en_t f;
} mp2_mpclk_xbar_cg_en_u;


/*
 * MP2_MPCLK_XBAR_CG_MISC struct
 */

#define MP2_MPCLK_XBAR_CG_MISC_REG_SIZE 32
#define MP2_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SIZE 8
#define MP2_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SIZE 8

#define MP2_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SHIFT 0
#define MP2_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SHIFT 8

#define MP2_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_MASK 0xff
#define MP2_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_MASK 0xff00

#define MP2_MPCLK_XBAR_CG_MISC_MASK \
     (MP2_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_MASK | \
      MP2_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_MASK)

#define MP2_MPCLK_XBAR_CG_MISC_DEFAULT 0x00000606

#define MP2_MPCLK_XBAR_CG_MISC_GET_MPCLK_XBAR_CG_TIMEOUT(mp2_mpclk_xbar_cg_misc) \
     ((mp2_mpclk_xbar_cg_misc & MP2_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_MASK) >> MP2_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MP2_MPCLK_XBAR_CG_MISC_GET_MPCLK_XBAR_CSYS_DELAY(mp2_mpclk_xbar_cg_misc) \
     ((mp2_mpclk_xbar_cg_misc & MP2_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_MASK) >> MP2_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SHIFT)

#define MP2_MPCLK_XBAR_CG_MISC_SET_MPCLK_XBAR_CG_TIMEOUT(mp2_mpclk_xbar_cg_misc_reg, mpclk_xbar_cg_timeout) \
     mp2_mpclk_xbar_cg_misc_reg = (mp2_mpclk_xbar_cg_misc_reg & ~MP2_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_MASK) | (mpclk_xbar_cg_timeout << MP2_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MP2_MPCLK_XBAR_CG_MISC_SET_MPCLK_XBAR_CSYS_DELAY(mp2_mpclk_xbar_cg_misc_reg, mpclk_xbar_csys_delay) \
     mp2_mpclk_xbar_cg_misc_reg = (mp2_mpclk_xbar_cg_misc_reg & ~MP2_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_MASK) | (mpclk_xbar_csys_delay << MP2_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mpclk_xbar_cg_misc_t {
          unsigned int mpclk_xbar_cg_timeout          : MP2_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SIZE;
          unsigned int mpclk_xbar_csys_delay          : MP2_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SIZE;
          unsigned int                                : 16;
     } mp2_mpclk_xbar_cg_misc_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mpclk_xbar_cg_misc_t {
          unsigned int                                : 16;
          unsigned int mpclk_xbar_csys_delay          : MP2_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SIZE;
          unsigned int mpclk_xbar_cg_timeout          : MP2_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SIZE;
     } mp2_mpclk_xbar_cg_misc_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mpclk_xbar_cg_misc_t f;
} mp2_mpclk_xbar_cg_misc_u;


/*
 * MP2_DFP_ZSCIF_CTRL struct
 */

#define MP2_DFP_ZSCIF_CTRL_REG_SIZE    32
#define MP2_DFP_ZSCIF_CTRL_ZSC_IF_ENABLE_SIZE 1
#define MP2_DFP_ZSCIF_CTRL_ZSC_IF_IDLE_SIZE 1
#define MP2_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_REQ_SIZE 1
#define MP2_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_ACK_SIZE 1
#define MP2_DFP_ZSCIF_CTRL_ZSC_IF_WAKE_SIZE 1

#define MP2_DFP_ZSCIF_CTRL_ZSC_IF_ENABLE_SHIFT 0
#define MP2_DFP_ZSCIF_CTRL_ZSC_IF_IDLE_SHIFT 1
#define MP2_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_REQ_SHIFT 2
#define MP2_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_ACK_SHIFT 3
#define MP2_DFP_ZSCIF_CTRL_ZSC_IF_WAKE_SHIFT 4

#define MP2_DFP_ZSCIF_CTRL_ZSC_IF_ENABLE_MASK 0x1
#define MP2_DFP_ZSCIF_CTRL_ZSC_IF_IDLE_MASK 0x2
#define MP2_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_REQ_MASK 0x4
#define MP2_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_ACK_MASK 0x8
#define MP2_DFP_ZSCIF_CTRL_ZSC_IF_WAKE_MASK 0x10

#define MP2_DFP_ZSCIF_CTRL_MASK \
     (MP2_DFP_ZSCIF_CTRL_ZSC_IF_ENABLE_MASK | \
      MP2_DFP_ZSCIF_CTRL_ZSC_IF_IDLE_MASK | \
      MP2_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_REQ_MASK | \
      MP2_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_ACK_MASK | \
      MP2_DFP_ZSCIF_CTRL_ZSC_IF_WAKE_MASK)

#define MP2_DFP_ZSCIF_CTRL_DEFAULT     0x00000000

#define MP2_DFP_ZSCIF_CTRL_GET_ZSC_IF_ENABLE(mp2_dfp_zscif_ctrl) \
     ((mp2_dfp_zscif_ctrl & MP2_DFP_ZSCIF_CTRL_ZSC_IF_ENABLE_MASK) >> MP2_DFP_ZSCIF_CTRL_ZSC_IF_ENABLE_SHIFT)
#define MP2_DFP_ZSCIF_CTRL_GET_ZSC_IF_IDLE(mp2_dfp_zscif_ctrl) \
     ((mp2_dfp_zscif_ctrl & MP2_DFP_ZSCIF_CTRL_ZSC_IF_IDLE_MASK) >> MP2_DFP_ZSCIF_CTRL_ZSC_IF_IDLE_SHIFT)
#define MP2_DFP_ZSCIF_CTRL_GET_ZSC_IF_FENCE_REQ(mp2_dfp_zscif_ctrl) \
     ((mp2_dfp_zscif_ctrl & MP2_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_REQ_MASK) >> MP2_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_REQ_SHIFT)
#define MP2_DFP_ZSCIF_CTRL_GET_ZSC_IF_FENCE_ACK(mp2_dfp_zscif_ctrl) \
     ((mp2_dfp_zscif_ctrl & MP2_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_ACK_MASK) >> MP2_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_ACK_SHIFT)
#define MP2_DFP_ZSCIF_CTRL_GET_ZSC_IF_WAKE(mp2_dfp_zscif_ctrl) \
     ((mp2_dfp_zscif_ctrl & MP2_DFP_ZSCIF_CTRL_ZSC_IF_WAKE_MASK) >> MP2_DFP_ZSCIF_CTRL_ZSC_IF_WAKE_SHIFT)

#define MP2_DFP_ZSCIF_CTRL_SET_ZSC_IF_ENABLE(mp2_dfp_zscif_ctrl_reg, zsc_if_enable) \
     mp2_dfp_zscif_ctrl_reg = (mp2_dfp_zscif_ctrl_reg & ~MP2_DFP_ZSCIF_CTRL_ZSC_IF_ENABLE_MASK) | (zsc_if_enable << MP2_DFP_ZSCIF_CTRL_ZSC_IF_ENABLE_SHIFT)
#define MP2_DFP_ZSCIF_CTRL_SET_ZSC_IF_IDLE(mp2_dfp_zscif_ctrl_reg, zsc_if_idle) \
     mp2_dfp_zscif_ctrl_reg = (mp2_dfp_zscif_ctrl_reg & ~MP2_DFP_ZSCIF_CTRL_ZSC_IF_IDLE_MASK) | (zsc_if_idle << MP2_DFP_ZSCIF_CTRL_ZSC_IF_IDLE_SHIFT)
#define MP2_DFP_ZSCIF_CTRL_SET_ZSC_IF_FENCE_REQ(mp2_dfp_zscif_ctrl_reg, zsc_if_fence_req) \
     mp2_dfp_zscif_ctrl_reg = (mp2_dfp_zscif_ctrl_reg & ~MP2_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_REQ_MASK) | (zsc_if_fence_req << MP2_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_REQ_SHIFT)
#define MP2_DFP_ZSCIF_CTRL_SET_ZSC_IF_FENCE_ACK(mp2_dfp_zscif_ctrl_reg, zsc_if_fence_ack) \
     mp2_dfp_zscif_ctrl_reg = (mp2_dfp_zscif_ctrl_reg & ~MP2_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_ACK_MASK) | (zsc_if_fence_ack << MP2_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_ACK_SHIFT)
#define MP2_DFP_ZSCIF_CTRL_SET_ZSC_IF_WAKE(mp2_dfp_zscif_ctrl_reg, zsc_if_wake) \
     mp2_dfp_zscif_ctrl_reg = (mp2_dfp_zscif_ctrl_reg & ~MP2_DFP_ZSCIF_CTRL_ZSC_IF_WAKE_MASK) | (zsc_if_wake << MP2_DFP_ZSCIF_CTRL_ZSC_IF_WAKE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfp_zscif_ctrl_t {
          unsigned int zsc_if_enable                  : MP2_DFP_ZSCIF_CTRL_ZSC_IF_ENABLE_SIZE;
          unsigned int zsc_if_idle                    : MP2_DFP_ZSCIF_CTRL_ZSC_IF_IDLE_SIZE;
          unsigned int zsc_if_fence_req               : MP2_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_REQ_SIZE;
          unsigned int zsc_if_fence_ack               : MP2_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_ACK_SIZE;
          unsigned int zsc_if_wake                    : MP2_DFP_ZSCIF_CTRL_ZSC_IF_WAKE_SIZE;
          unsigned int                                : 27;
     } mp2_dfp_zscif_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfp_zscif_ctrl_t {
          unsigned int                                : 27;
          unsigned int zsc_if_wake                    : MP2_DFP_ZSCIF_CTRL_ZSC_IF_WAKE_SIZE;
          unsigned int zsc_if_fence_ack               : MP2_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_ACK_SIZE;
          unsigned int zsc_if_fence_req               : MP2_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_REQ_SIZE;
          unsigned int zsc_if_idle                    : MP2_DFP_ZSCIF_CTRL_ZSC_IF_IDLE_SIZE;
          unsigned int zsc_if_enable                  : MP2_DFP_ZSCIF_CTRL_ZSC_IF_ENABLE_SIZE;
     } mp2_dfp_zscif_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfp_zscif_ctrl_t f;
} mp2_dfp_zscif_ctrl_u;


/*
 * MP2_DFP_PGFSM_CTRL struct
 */

#define MP2_DFP_PGFSM_CTRL_REG_SIZE    32
#define MP2_DFP_PGFSM_CTRL_PGFSM_ENTER_SIZE 1
#define MP2_DFP_PGFSM_CTRL_PGFSM_SAFE_IDLE_SIZE 1
#define MP2_DFP_PGFSM_CTRL_PGFSM_NO_WAKE_ON_SMNIF_SIZE 1
#define MP2_DFP_PGFSM_CTRL_PGFSM_DS_ALLOW_EN_SIZE 1
#define MP2_DFP_PGFSM_CTRL_PGFSM_NO_CLK_CG_ON_PWROFF_SIZE 1
#define MP2_DFP_PGFSM_CTRL_PGFSM_SUCCESS_SIZE 1

#define MP2_DFP_PGFSM_CTRL_PGFSM_ENTER_SHIFT 0
#define MP2_DFP_PGFSM_CTRL_PGFSM_SAFE_IDLE_SHIFT 1
#define MP2_DFP_PGFSM_CTRL_PGFSM_NO_WAKE_ON_SMNIF_SHIFT 4
#define MP2_DFP_PGFSM_CTRL_PGFSM_DS_ALLOW_EN_SHIFT 5
#define MP2_DFP_PGFSM_CTRL_PGFSM_NO_CLK_CG_ON_PWROFF_SHIFT 7
#define MP2_DFP_PGFSM_CTRL_PGFSM_SUCCESS_SHIFT 31

#define MP2_DFP_PGFSM_CTRL_PGFSM_ENTER_MASK 0x1
#define MP2_DFP_PGFSM_CTRL_PGFSM_SAFE_IDLE_MASK 0x2
#define MP2_DFP_PGFSM_CTRL_PGFSM_NO_WAKE_ON_SMNIF_MASK 0x10
#define MP2_DFP_PGFSM_CTRL_PGFSM_DS_ALLOW_EN_MASK 0x20
#define MP2_DFP_PGFSM_CTRL_PGFSM_NO_CLK_CG_ON_PWROFF_MASK 0x80
#define MP2_DFP_PGFSM_CTRL_PGFSM_SUCCESS_MASK 0x80000000

#define MP2_DFP_PGFSM_CTRL_MASK \
     (MP2_DFP_PGFSM_CTRL_PGFSM_ENTER_MASK | \
      MP2_DFP_PGFSM_CTRL_PGFSM_SAFE_IDLE_MASK | \
      MP2_DFP_PGFSM_CTRL_PGFSM_NO_WAKE_ON_SMNIF_MASK | \
      MP2_DFP_PGFSM_CTRL_PGFSM_DS_ALLOW_EN_MASK | \
      MP2_DFP_PGFSM_CTRL_PGFSM_NO_CLK_CG_ON_PWROFF_MASK | \
      MP2_DFP_PGFSM_CTRL_PGFSM_SUCCESS_MASK)

#define MP2_DFP_PGFSM_CTRL_DEFAULT     0x00000000

#define MP2_DFP_PGFSM_CTRL_GET_PGFSM_ENTER(mp2_dfp_pgfsm_ctrl) \
     ((mp2_dfp_pgfsm_ctrl & MP2_DFP_PGFSM_CTRL_PGFSM_ENTER_MASK) >> MP2_DFP_PGFSM_CTRL_PGFSM_ENTER_SHIFT)
#define MP2_DFP_PGFSM_CTRL_GET_PGFSM_SAFE_IDLE(mp2_dfp_pgfsm_ctrl) \
     ((mp2_dfp_pgfsm_ctrl & MP2_DFP_PGFSM_CTRL_PGFSM_SAFE_IDLE_MASK) >> MP2_DFP_PGFSM_CTRL_PGFSM_SAFE_IDLE_SHIFT)
#define MP2_DFP_PGFSM_CTRL_GET_PGFSM_NO_WAKE_ON_SMNIF(mp2_dfp_pgfsm_ctrl) \
     ((mp2_dfp_pgfsm_ctrl & MP2_DFP_PGFSM_CTRL_PGFSM_NO_WAKE_ON_SMNIF_MASK) >> MP2_DFP_PGFSM_CTRL_PGFSM_NO_WAKE_ON_SMNIF_SHIFT)
#define MP2_DFP_PGFSM_CTRL_GET_PGFSM_DS_ALLOW_EN(mp2_dfp_pgfsm_ctrl) \
     ((mp2_dfp_pgfsm_ctrl & MP2_DFP_PGFSM_CTRL_PGFSM_DS_ALLOW_EN_MASK) >> MP2_DFP_PGFSM_CTRL_PGFSM_DS_ALLOW_EN_SHIFT)
#define MP2_DFP_PGFSM_CTRL_GET_PGFSM_NO_CLK_CG_ON_PWROFF(mp2_dfp_pgfsm_ctrl) \
     ((mp2_dfp_pgfsm_ctrl & MP2_DFP_PGFSM_CTRL_PGFSM_NO_CLK_CG_ON_PWROFF_MASK) >> MP2_DFP_PGFSM_CTRL_PGFSM_NO_CLK_CG_ON_PWROFF_SHIFT)
#define MP2_DFP_PGFSM_CTRL_GET_PGFSM_SUCCESS(mp2_dfp_pgfsm_ctrl) \
     ((mp2_dfp_pgfsm_ctrl & MP2_DFP_PGFSM_CTRL_PGFSM_SUCCESS_MASK) >> MP2_DFP_PGFSM_CTRL_PGFSM_SUCCESS_SHIFT)

#define MP2_DFP_PGFSM_CTRL_SET_PGFSM_ENTER(mp2_dfp_pgfsm_ctrl_reg, pgfsm_enter) \
     mp2_dfp_pgfsm_ctrl_reg = (mp2_dfp_pgfsm_ctrl_reg & ~MP2_DFP_PGFSM_CTRL_PGFSM_ENTER_MASK) | (pgfsm_enter << MP2_DFP_PGFSM_CTRL_PGFSM_ENTER_SHIFT)
#define MP2_DFP_PGFSM_CTRL_SET_PGFSM_SAFE_IDLE(mp2_dfp_pgfsm_ctrl_reg, pgfsm_safe_idle) \
     mp2_dfp_pgfsm_ctrl_reg = (mp2_dfp_pgfsm_ctrl_reg & ~MP2_DFP_PGFSM_CTRL_PGFSM_SAFE_IDLE_MASK) | (pgfsm_safe_idle << MP2_DFP_PGFSM_CTRL_PGFSM_SAFE_IDLE_SHIFT)
#define MP2_DFP_PGFSM_CTRL_SET_PGFSM_NO_WAKE_ON_SMNIF(mp2_dfp_pgfsm_ctrl_reg, pgfsm_no_wake_on_smnif) \
     mp2_dfp_pgfsm_ctrl_reg = (mp2_dfp_pgfsm_ctrl_reg & ~MP2_DFP_PGFSM_CTRL_PGFSM_NO_WAKE_ON_SMNIF_MASK) | (pgfsm_no_wake_on_smnif << MP2_DFP_PGFSM_CTRL_PGFSM_NO_WAKE_ON_SMNIF_SHIFT)
#define MP2_DFP_PGFSM_CTRL_SET_PGFSM_DS_ALLOW_EN(mp2_dfp_pgfsm_ctrl_reg, pgfsm_ds_allow_en) \
     mp2_dfp_pgfsm_ctrl_reg = (mp2_dfp_pgfsm_ctrl_reg & ~MP2_DFP_PGFSM_CTRL_PGFSM_DS_ALLOW_EN_MASK) | (pgfsm_ds_allow_en << MP2_DFP_PGFSM_CTRL_PGFSM_DS_ALLOW_EN_SHIFT)
#define MP2_DFP_PGFSM_CTRL_SET_PGFSM_NO_CLK_CG_ON_PWROFF(mp2_dfp_pgfsm_ctrl_reg, pgfsm_no_clk_cg_on_pwroff) \
     mp2_dfp_pgfsm_ctrl_reg = (mp2_dfp_pgfsm_ctrl_reg & ~MP2_DFP_PGFSM_CTRL_PGFSM_NO_CLK_CG_ON_PWROFF_MASK) | (pgfsm_no_clk_cg_on_pwroff << MP2_DFP_PGFSM_CTRL_PGFSM_NO_CLK_CG_ON_PWROFF_SHIFT)
#define MP2_DFP_PGFSM_CTRL_SET_PGFSM_SUCCESS(mp2_dfp_pgfsm_ctrl_reg, pgfsm_success) \
     mp2_dfp_pgfsm_ctrl_reg = (mp2_dfp_pgfsm_ctrl_reg & ~MP2_DFP_PGFSM_CTRL_PGFSM_SUCCESS_MASK) | (pgfsm_success << MP2_DFP_PGFSM_CTRL_PGFSM_SUCCESS_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfp_pgfsm_ctrl_t {
          unsigned int pgfsm_enter                    : MP2_DFP_PGFSM_CTRL_PGFSM_ENTER_SIZE;
          unsigned int pgfsm_safe_idle                : MP2_DFP_PGFSM_CTRL_PGFSM_SAFE_IDLE_SIZE;
          unsigned int                                : 2;
          unsigned int pgfsm_no_wake_on_smnif         : MP2_DFP_PGFSM_CTRL_PGFSM_NO_WAKE_ON_SMNIF_SIZE;
          unsigned int pgfsm_ds_allow_en              : MP2_DFP_PGFSM_CTRL_PGFSM_DS_ALLOW_EN_SIZE;
          unsigned int                                : 1;
          unsigned int pgfsm_no_clk_cg_on_pwroff      : MP2_DFP_PGFSM_CTRL_PGFSM_NO_CLK_CG_ON_PWROFF_SIZE;
          unsigned int                                : 23;
          unsigned int pgfsm_success                  : MP2_DFP_PGFSM_CTRL_PGFSM_SUCCESS_SIZE;
     } mp2_dfp_pgfsm_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfp_pgfsm_ctrl_t {
          unsigned int pgfsm_success                  : MP2_DFP_PGFSM_CTRL_PGFSM_SUCCESS_SIZE;
          unsigned int                                : 23;
          unsigned int pgfsm_no_clk_cg_on_pwroff      : MP2_DFP_PGFSM_CTRL_PGFSM_NO_CLK_CG_ON_PWROFF_SIZE;
          unsigned int                                : 1;
          unsigned int pgfsm_ds_allow_en              : MP2_DFP_PGFSM_CTRL_PGFSM_DS_ALLOW_EN_SIZE;
          unsigned int pgfsm_no_wake_on_smnif         : MP2_DFP_PGFSM_CTRL_PGFSM_NO_WAKE_ON_SMNIF_SIZE;
          unsigned int                                : 2;
          unsigned int pgfsm_safe_idle                : MP2_DFP_PGFSM_CTRL_PGFSM_SAFE_IDLE_SIZE;
          unsigned int pgfsm_enter                    : MP2_DFP_PGFSM_CTRL_PGFSM_ENTER_SIZE;
     } mp2_dfp_pgfsm_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfp_pgfsm_ctrl_t f;
} mp2_dfp_pgfsm_ctrl_u;


/*
 * MP2_DFP_CLK_DIV struct
 */

#define MP2_DFP_CLK_DIV_REG_SIZE       32
#define MP2_DFP_CLK_DIV_CLK_DIV_SIZE   2
#define MP2_DFP_CLK_DIV_CLK_DIV_IN_PG_SIZE 2
#define MP2_DFP_CLK_DIV_CLK_DIV_PG_EN_SIZE 1

#define MP2_DFP_CLK_DIV_CLK_DIV_SHIFT  0
#define MP2_DFP_CLK_DIV_CLK_DIV_IN_PG_SHIFT 2
#define MP2_DFP_CLK_DIV_CLK_DIV_PG_EN_SHIFT 4

#define MP2_DFP_CLK_DIV_CLK_DIV_MASK   0x3
#define MP2_DFP_CLK_DIV_CLK_DIV_IN_PG_MASK 0xc
#define MP2_DFP_CLK_DIV_CLK_DIV_PG_EN_MASK 0x10

#define MP2_DFP_CLK_DIV_MASK \
     (MP2_DFP_CLK_DIV_CLK_DIV_MASK | \
      MP2_DFP_CLK_DIV_CLK_DIV_IN_PG_MASK | \
      MP2_DFP_CLK_DIV_CLK_DIV_PG_EN_MASK)

#define MP2_DFP_CLK_DIV_DEFAULT        0x00000000

#define MP2_DFP_CLK_DIV_GET_CLK_DIV(mp2_dfp_clk_div) \
     ((mp2_dfp_clk_div & MP2_DFP_CLK_DIV_CLK_DIV_MASK) >> MP2_DFP_CLK_DIV_CLK_DIV_SHIFT)
#define MP2_DFP_CLK_DIV_GET_CLK_DIV_IN_PG(mp2_dfp_clk_div) \
     ((mp2_dfp_clk_div & MP2_DFP_CLK_DIV_CLK_DIV_IN_PG_MASK) >> MP2_DFP_CLK_DIV_CLK_DIV_IN_PG_SHIFT)
#define MP2_DFP_CLK_DIV_GET_CLK_DIV_PG_EN(mp2_dfp_clk_div) \
     ((mp2_dfp_clk_div & MP2_DFP_CLK_DIV_CLK_DIV_PG_EN_MASK) >> MP2_DFP_CLK_DIV_CLK_DIV_PG_EN_SHIFT)

#define MP2_DFP_CLK_DIV_SET_CLK_DIV(mp2_dfp_clk_div_reg, clk_div) \
     mp2_dfp_clk_div_reg = (mp2_dfp_clk_div_reg & ~MP2_DFP_CLK_DIV_CLK_DIV_MASK) | (clk_div << MP2_DFP_CLK_DIV_CLK_DIV_SHIFT)
#define MP2_DFP_CLK_DIV_SET_CLK_DIV_IN_PG(mp2_dfp_clk_div_reg, clk_div_in_pg) \
     mp2_dfp_clk_div_reg = (mp2_dfp_clk_div_reg & ~MP2_DFP_CLK_DIV_CLK_DIV_IN_PG_MASK) | (clk_div_in_pg << MP2_DFP_CLK_DIV_CLK_DIV_IN_PG_SHIFT)
#define MP2_DFP_CLK_DIV_SET_CLK_DIV_PG_EN(mp2_dfp_clk_div_reg, clk_div_pg_en) \
     mp2_dfp_clk_div_reg = (mp2_dfp_clk_div_reg & ~MP2_DFP_CLK_DIV_CLK_DIV_PG_EN_MASK) | (clk_div_pg_en << MP2_DFP_CLK_DIV_CLK_DIV_PG_EN_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfp_clk_div_t {
          unsigned int clk_div                        : MP2_DFP_CLK_DIV_CLK_DIV_SIZE;
          unsigned int clk_div_in_pg                  : MP2_DFP_CLK_DIV_CLK_DIV_IN_PG_SIZE;
          unsigned int clk_div_pg_en                  : MP2_DFP_CLK_DIV_CLK_DIV_PG_EN_SIZE;
          unsigned int                                : 27;
     } mp2_dfp_clk_div_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfp_clk_div_t {
          unsigned int                                : 27;
          unsigned int clk_div_pg_en                  : MP2_DFP_CLK_DIV_CLK_DIV_PG_EN_SIZE;
          unsigned int clk_div_in_pg                  : MP2_DFP_CLK_DIV_CLK_DIV_IN_PG_SIZE;
          unsigned int clk_div                        : MP2_DFP_CLK_DIV_CLK_DIV_SIZE;
     } mp2_dfp_clk_div_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfp_clk_div_t f;
} mp2_dfp_clk_div_u;


/*
 * MP2_DFP_PGFSM_TRAN_CTRL struct
 */

#define MP2_DFP_PGFSM_TRAN_CTRL_REG_SIZE 32
#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_ADDR_SIZE 4
#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_CMD_SIZE 3
#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_OVRD_IP_CTRL_SIZE 1
#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_DONE_SIZE 1
#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_DONE_SIZE 1
#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_STATUS_SIZE 2
#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_START_SIZE 1

#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_ADDR_SHIFT 0
#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_CMD_SHIFT 4
#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_OVRD_IP_CTRL_SHIFT 7
#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_DONE_SHIFT 8
#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_DONE_SHIFT 9
#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_STATUS_SHIFT 10
#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_START_SHIFT 31

#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_ADDR_MASK 0xf
#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_CMD_MASK 0x70
#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_OVRD_IP_CTRL_MASK 0x80
#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_DONE_MASK 0x100
#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_DONE_MASK 0x200
#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_STATUS_MASK 0xc00
#define MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_START_MASK 0x80000000

#define MP2_DFP_PGFSM_TRAN_CTRL_MASK \
     (MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_ADDR_MASK | \
      MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_CMD_MASK | \
      MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_OVRD_IP_CTRL_MASK | \
      MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_DONE_MASK | \
      MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_DONE_MASK | \
      MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_STATUS_MASK | \
      MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_START_MASK)

#define MP2_DFP_PGFSM_TRAN_CTRL_DEFAULT 0x00000000

#define MP2_DFP_PGFSM_TRAN_CTRL_GET_PGFSM_TRAN_ADDR(mp2_dfp_pgfsm_tran_ctrl) \
     ((mp2_dfp_pgfsm_tran_ctrl & MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_ADDR_MASK) >> MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_ADDR_SHIFT)
#define MP2_DFP_PGFSM_TRAN_CTRL_GET_PGFSM_TRAN_CMD(mp2_dfp_pgfsm_tran_ctrl) \
     ((mp2_dfp_pgfsm_tran_ctrl & MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_CMD_MASK) >> MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_CMD_SHIFT)
#define MP2_DFP_PGFSM_TRAN_CTRL_GET_PGFSM_OVRD_IP_CTRL(mp2_dfp_pgfsm_tran_ctrl) \
     ((mp2_dfp_pgfsm_tran_ctrl & MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_OVRD_IP_CTRL_MASK) >> MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_OVRD_IP_CTRL_SHIFT)
#define MP2_DFP_PGFSM_TRAN_CTRL_GET_PGFSM_TRAN_DONE(mp2_dfp_pgfsm_tran_ctrl) \
     ((mp2_dfp_pgfsm_tran_ctrl & MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_DONE_MASK) >> MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_DONE_SHIFT)
#define MP2_DFP_PGFSM_TRAN_CTRL_GET_PGFSM_IP_CMD_DONE(mp2_dfp_pgfsm_tran_ctrl) \
     ((mp2_dfp_pgfsm_tran_ctrl & MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_DONE_MASK) >> MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_DONE_SHIFT)
#define MP2_DFP_PGFSM_TRAN_CTRL_GET_PGFSM_IP_CMD_STATUS(mp2_dfp_pgfsm_tran_ctrl) \
     ((mp2_dfp_pgfsm_tran_ctrl & MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_STATUS_MASK) >> MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_STATUS_SHIFT)
#define MP2_DFP_PGFSM_TRAN_CTRL_GET_PGFSM_TRAN_START(mp2_dfp_pgfsm_tran_ctrl) \
     ((mp2_dfp_pgfsm_tran_ctrl & MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_START_MASK) >> MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_START_SHIFT)

#define MP2_DFP_PGFSM_TRAN_CTRL_SET_PGFSM_TRAN_ADDR(mp2_dfp_pgfsm_tran_ctrl_reg, pgfsm_tran_addr) \
     mp2_dfp_pgfsm_tran_ctrl_reg = (mp2_dfp_pgfsm_tran_ctrl_reg & ~MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_ADDR_MASK) | (pgfsm_tran_addr << MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_ADDR_SHIFT)
#define MP2_DFP_PGFSM_TRAN_CTRL_SET_PGFSM_TRAN_CMD(mp2_dfp_pgfsm_tran_ctrl_reg, pgfsm_tran_cmd) \
     mp2_dfp_pgfsm_tran_ctrl_reg = (mp2_dfp_pgfsm_tran_ctrl_reg & ~MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_CMD_MASK) | (pgfsm_tran_cmd << MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_CMD_SHIFT)
#define MP2_DFP_PGFSM_TRAN_CTRL_SET_PGFSM_OVRD_IP_CTRL(mp2_dfp_pgfsm_tran_ctrl_reg, pgfsm_ovrd_ip_ctrl) \
     mp2_dfp_pgfsm_tran_ctrl_reg = (mp2_dfp_pgfsm_tran_ctrl_reg & ~MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_OVRD_IP_CTRL_MASK) | (pgfsm_ovrd_ip_ctrl << MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_OVRD_IP_CTRL_SHIFT)
#define MP2_DFP_PGFSM_TRAN_CTRL_SET_PGFSM_TRAN_DONE(mp2_dfp_pgfsm_tran_ctrl_reg, pgfsm_tran_done) \
     mp2_dfp_pgfsm_tran_ctrl_reg = (mp2_dfp_pgfsm_tran_ctrl_reg & ~MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_DONE_MASK) | (pgfsm_tran_done << MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_DONE_SHIFT)
#define MP2_DFP_PGFSM_TRAN_CTRL_SET_PGFSM_IP_CMD_DONE(mp2_dfp_pgfsm_tran_ctrl_reg, pgfsm_ip_cmd_done) \
     mp2_dfp_pgfsm_tran_ctrl_reg = (mp2_dfp_pgfsm_tran_ctrl_reg & ~MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_DONE_MASK) | (pgfsm_ip_cmd_done << MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_DONE_SHIFT)
#define MP2_DFP_PGFSM_TRAN_CTRL_SET_PGFSM_IP_CMD_STATUS(mp2_dfp_pgfsm_tran_ctrl_reg, pgfsm_ip_cmd_status) \
     mp2_dfp_pgfsm_tran_ctrl_reg = (mp2_dfp_pgfsm_tran_ctrl_reg & ~MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_STATUS_MASK) | (pgfsm_ip_cmd_status << MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_STATUS_SHIFT)
#define MP2_DFP_PGFSM_TRAN_CTRL_SET_PGFSM_TRAN_START(mp2_dfp_pgfsm_tran_ctrl_reg, pgfsm_tran_start) \
     mp2_dfp_pgfsm_tran_ctrl_reg = (mp2_dfp_pgfsm_tran_ctrl_reg & ~MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_START_MASK) | (pgfsm_tran_start << MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_START_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfp_pgfsm_tran_ctrl_t {
          unsigned int pgfsm_tran_addr                : MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_ADDR_SIZE;
          unsigned int pgfsm_tran_cmd                 : MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_CMD_SIZE;
          unsigned int pgfsm_ovrd_ip_ctrl             : MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_OVRD_IP_CTRL_SIZE;
          unsigned int pgfsm_tran_done                : MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_DONE_SIZE;
          unsigned int pgfsm_ip_cmd_done              : MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_DONE_SIZE;
          unsigned int pgfsm_ip_cmd_status            : MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_STATUS_SIZE;
          unsigned int                                : 19;
          unsigned int pgfsm_tran_start               : MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_START_SIZE;
     } mp2_dfp_pgfsm_tran_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfp_pgfsm_tran_ctrl_t {
          unsigned int pgfsm_tran_start               : MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_START_SIZE;
          unsigned int                                : 19;
          unsigned int pgfsm_ip_cmd_status            : MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_STATUS_SIZE;
          unsigned int pgfsm_ip_cmd_done              : MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_DONE_SIZE;
          unsigned int pgfsm_tran_done                : MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_DONE_SIZE;
          unsigned int pgfsm_ovrd_ip_ctrl             : MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_OVRD_IP_CTRL_SIZE;
          unsigned int pgfsm_tran_cmd                 : MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_CMD_SIZE;
          unsigned int pgfsm_tran_addr                : MP2_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_ADDR_SIZE;
     } mp2_dfp_pgfsm_tran_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfp_pgfsm_tran_ctrl_t f;
} mp2_dfp_pgfsm_tran_ctrl_u;


/*
 * MP2_DFP_PGFSM_TRAN_WRITE_DATA struct
 */

#define MP2_DFP_PGFSM_TRAN_WRITE_DATA_REG_SIZE 32
#define MP2_DFP_PGFSM_TRAN_WRITE_DATA_PGFSM_TRAN_WRITE_DATA_SIZE 32

#define MP2_DFP_PGFSM_TRAN_WRITE_DATA_PGFSM_TRAN_WRITE_DATA_SHIFT 0

#define MP2_DFP_PGFSM_TRAN_WRITE_DATA_PGFSM_TRAN_WRITE_DATA_MASK 0xffffffff

#define MP2_DFP_PGFSM_TRAN_WRITE_DATA_MASK \
     (MP2_DFP_PGFSM_TRAN_WRITE_DATA_PGFSM_TRAN_WRITE_DATA_MASK)

#define MP2_DFP_PGFSM_TRAN_WRITE_DATA_DEFAULT 0x00000000

#define MP2_DFP_PGFSM_TRAN_WRITE_DATA_GET_PGFSM_TRAN_WRITE_DATA(mp2_dfp_pgfsm_tran_write_data) \
     ((mp2_dfp_pgfsm_tran_write_data & MP2_DFP_PGFSM_TRAN_WRITE_DATA_PGFSM_TRAN_WRITE_DATA_MASK) >> MP2_DFP_PGFSM_TRAN_WRITE_DATA_PGFSM_TRAN_WRITE_DATA_SHIFT)

#define MP2_DFP_PGFSM_TRAN_WRITE_DATA_SET_PGFSM_TRAN_WRITE_DATA(mp2_dfp_pgfsm_tran_write_data_reg, pgfsm_tran_write_data) \
     mp2_dfp_pgfsm_tran_write_data_reg = (mp2_dfp_pgfsm_tran_write_data_reg & ~MP2_DFP_PGFSM_TRAN_WRITE_DATA_PGFSM_TRAN_WRITE_DATA_MASK) | (pgfsm_tran_write_data << MP2_DFP_PGFSM_TRAN_WRITE_DATA_PGFSM_TRAN_WRITE_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfp_pgfsm_tran_write_data_t {
          unsigned int pgfsm_tran_write_data          : MP2_DFP_PGFSM_TRAN_WRITE_DATA_PGFSM_TRAN_WRITE_DATA_SIZE;
     } mp2_dfp_pgfsm_tran_write_data_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfp_pgfsm_tran_write_data_t {
          unsigned int pgfsm_tran_write_data          : MP2_DFP_PGFSM_TRAN_WRITE_DATA_PGFSM_TRAN_WRITE_DATA_SIZE;
     } mp2_dfp_pgfsm_tran_write_data_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfp_pgfsm_tran_write_data_t f;
} mp2_dfp_pgfsm_tran_write_data_u;


/*
 * MP2_DFP_PGFSM_TRAN_READ_DATA struct
 */

#define MP2_DFP_PGFSM_TRAN_READ_DATA_REG_SIZE 32
#define MP2_DFP_PGFSM_TRAN_READ_DATA_PGFSM_TRAN_READ_DATA_SIZE 32

#define MP2_DFP_PGFSM_TRAN_READ_DATA_PGFSM_TRAN_READ_DATA_SHIFT 0

#define MP2_DFP_PGFSM_TRAN_READ_DATA_PGFSM_TRAN_READ_DATA_MASK 0xffffffff

#define MP2_DFP_PGFSM_TRAN_READ_DATA_MASK \
     (MP2_DFP_PGFSM_TRAN_READ_DATA_PGFSM_TRAN_READ_DATA_MASK)

#define MP2_DFP_PGFSM_TRAN_READ_DATA_DEFAULT 0x00000000

#define MP2_DFP_PGFSM_TRAN_READ_DATA_GET_PGFSM_TRAN_READ_DATA(mp2_dfp_pgfsm_tran_read_data) \
     ((mp2_dfp_pgfsm_tran_read_data & MP2_DFP_PGFSM_TRAN_READ_DATA_PGFSM_TRAN_READ_DATA_MASK) >> MP2_DFP_PGFSM_TRAN_READ_DATA_PGFSM_TRAN_READ_DATA_SHIFT)

#define MP2_DFP_PGFSM_TRAN_READ_DATA_SET_PGFSM_TRAN_READ_DATA(mp2_dfp_pgfsm_tran_read_data_reg, pgfsm_tran_read_data) \
     mp2_dfp_pgfsm_tran_read_data_reg = (mp2_dfp_pgfsm_tran_read_data_reg & ~MP2_DFP_PGFSM_TRAN_READ_DATA_PGFSM_TRAN_READ_DATA_MASK) | (pgfsm_tran_read_data << MP2_DFP_PGFSM_TRAN_READ_DATA_PGFSM_TRAN_READ_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfp_pgfsm_tran_read_data_t {
          unsigned int pgfsm_tran_read_data           : MP2_DFP_PGFSM_TRAN_READ_DATA_PGFSM_TRAN_READ_DATA_SIZE;
     } mp2_dfp_pgfsm_tran_read_data_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfp_pgfsm_tran_read_data_t {
          unsigned int pgfsm_tran_read_data           : MP2_DFP_PGFSM_TRAN_READ_DATA_PGFSM_TRAN_READ_DATA_SIZE;
     } mp2_dfp_pgfsm_tran_read_data_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfp_pgfsm_tran_read_data_t f;
} mp2_dfp_pgfsm_tran_read_data_u;


/*
 * MP2_DFP_PGFSM_OVRD_REG struct
 */

#define MP2_DFP_PGFSM_OVRD_REG_REG_SIZE 32
#define MP2_DFP_PGFSM_OVRD_REG_PGFSM_MGCG_OVRD_SIZE 1
#define MP2_DFP_PGFSM_OVRD_REG_PGFSM_CSYS_DELAY_SIZE 8

#define MP2_DFP_PGFSM_OVRD_REG_PGFSM_MGCG_OVRD_SHIFT 0
#define MP2_DFP_PGFSM_OVRD_REG_PGFSM_CSYS_DELAY_SHIFT 8

#define MP2_DFP_PGFSM_OVRD_REG_PGFSM_MGCG_OVRD_MASK 0x1
#define MP2_DFP_PGFSM_OVRD_REG_PGFSM_CSYS_DELAY_MASK 0xff00

#define MP2_DFP_PGFSM_OVRD_REG_MASK \
     (MP2_DFP_PGFSM_OVRD_REG_PGFSM_MGCG_OVRD_MASK | \
      MP2_DFP_PGFSM_OVRD_REG_PGFSM_CSYS_DELAY_MASK)

#define MP2_DFP_PGFSM_OVRD_REG_DEFAULT 0x00000b00

#define MP2_DFP_PGFSM_OVRD_REG_GET_PGFSM_MGCG_OVRD(mp2_dfp_pgfsm_ovrd_reg) \
     ((mp2_dfp_pgfsm_ovrd_reg & MP2_DFP_PGFSM_OVRD_REG_PGFSM_MGCG_OVRD_MASK) >> MP2_DFP_PGFSM_OVRD_REG_PGFSM_MGCG_OVRD_SHIFT)
#define MP2_DFP_PGFSM_OVRD_REG_GET_PGFSM_CSYS_DELAY(mp2_dfp_pgfsm_ovrd_reg) \
     ((mp2_dfp_pgfsm_ovrd_reg & MP2_DFP_PGFSM_OVRD_REG_PGFSM_CSYS_DELAY_MASK) >> MP2_DFP_PGFSM_OVRD_REG_PGFSM_CSYS_DELAY_SHIFT)

#define MP2_DFP_PGFSM_OVRD_REG_SET_PGFSM_MGCG_OVRD(mp2_dfp_pgfsm_ovrd_reg_reg, pgfsm_mgcg_ovrd) \
     mp2_dfp_pgfsm_ovrd_reg_reg = (mp2_dfp_pgfsm_ovrd_reg_reg & ~MP2_DFP_PGFSM_OVRD_REG_PGFSM_MGCG_OVRD_MASK) | (pgfsm_mgcg_ovrd << MP2_DFP_PGFSM_OVRD_REG_PGFSM_MGCG_OVRD_SHIFT)
#define MP2_DFP_PGFSM_OVRD_REG_SET_PGFSM_CSYS_DELAY(mp2_dfp_pgfsm_ovrd_reg_reg, pgfsm_csys_delay) \
     mp2_dfp_pgfsm_ovrd_reg_reg = (mp2_dfp_pgfsm_ovrd_reg_reg & ~MP2_DFP_PGFSM_OVRD_REG_PGFSM_CSYS_DELAY_MASK) | (pgfsm_csys_delay << MP2_DFP_PGFSM_OVRD_REG_PGFSM_CSYS_DELAY_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfp_pgfsm_ovrd_reg_t {
          unsigned int pgfsm_mgcg_ovrd                : MP2_DFP_PGFSM_OVRD_REG_PGFSM_MGCG_OVRD_SIZE;
          unsigned int                                : 7;
          unsigned int pgfsm_csys_delay               : MP2_DFP_PGFSM_OVRD_REG_PGFSM_CSYS_DELAY_SIZE;
          unsigned int                                : 16;
     } mp2_dfp_pgfsm_ovrd_reg_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfp_pgfsm_ovrd_reg_t {
          unsigned int                                : 16;
          unsigned int pgfsm_csys_delay               : MP2_DFP_PGFSM_OVRD_REG_PGFSM_CSYS_DELAY_SIZE;
          unsigned int                                : 7;
          unsigned int pgfsm_mgcg_ovrd                : MP2_DFP_PGFSM_OVRD_REG_PGFSM_MGCG_OVRD_SIZE;
     } mp2_dfp_pgfsm_ovrd_reg_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfp_pgfsm_ovrd_reg_t f;
} mp2_dfp_pgfsm_ovrd_reg_u;


/*
 * MP2_DFP_PGRAM_MMU0_CNTL struct
 */

#define MP2_DFP_PGRAM_MMU0_CNTL_REG_SIZE 32
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_SD_MMU0_SIZE 1
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_ROP_MMU0_SIZE 1
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_DEEP_SLEEP_EN_MMU0_SIZE 1
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_DEEP_SLEEP_STATUS_MMU0_SIZE 1
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_LIGHT_SLEEP_EN_MMU0_SIZE 1
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU0_SIZE 1
#define MP2_DFP_PGRAM_MMU0_CNTL_PGFSM_MEM_SDDS_EN_MMU0_SIZE 1
#define MP2_DFP_PGRAM_MMU0_CNTL_PGFSM_MEM_SDDS_MODE_MMU0_SIZE 1
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_SLEEP_TIMEOUT_MMU0_SIZE 8
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_PG_DLY_MMU0_SIZE 8

#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_SD_MMU0_SHIFT 0
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_ROP_MMU0_SHIFT 1
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_DEEP_SLEEP_EN_MMU0_SHIFT 2
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_DEEP_SLEEP_STATUS_MMU0_SHIFT 3
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_LIGHT_SLEEP_EN_MMU0_SHIFT 4
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU0_SHIFT 5
#define MP2_DFP_PGRAM_MMU0_CNTL_PGFSM_MEM_SDDS_EN_MMU0_SHIFT 6
#define MP2_DFP_PGRAM_MMU0_CNTL_PGFSM_MEM_SDDS_MODE_MMU0_SHIFT 7
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_SLEEP_TIMEOUT_MMU0_SHIFT 8
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_PG_DLY_MMU0_SHIFT 16

#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_SD_MMU0_MASK 0x1
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_ROP_MMU0_MASK 0x2
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_DEEP_SLEEP_EN_MMU0_MASK 0x4
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_DEEP_SLEEP_STATUS_MMU0_MASK 0x8
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_LIGHT_SLEEP_EN_MMU0_MASK 0x10
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU0_MASK 0x20
#define MP2_DFP_PGRAM_MMU0_CNTL_PGFSM_MEM_SDDS_EN_MMU0_MASK 0x40
#define MP2_DFP_PGRAM_MMU0_CNTL_PGFSM_MEM_SDDS_MODE_MMU0_MASK 0x80
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_SLEEP_TIMEOUT_MMU0_MASK 0xff00
#define MP2_DFP_PGRAM_MMU0_CNTL_MEM_PG_DLY_MMU0_MASK 0xff0000

#define MP2_DFP_PGRAM_MMU0_CNTL_MASK \
     (MP2_DFP_PGRAM_MMU0_CNTL_MEM_SD_MMU0_MASK | \
      MP2_DFP_PGRAM_MMU0_CNTL_MEM_ROP_MMU0_MASK | \
      MP2_DFP_PGRAM_MMU0_CNTL_MEM_DEEP_SLEEP_EN_MMU0_MASK | \
      MP2_DFP_PGRAM_MMU0_CNTL_MEM_DEEP_SLEEP_STATUS_MMU0_MASK | \
      MP2_DFP_PGRAM_MMU0_CNTL_MEM_LIGHT_SLEEP_EN_MMU0_MASK | \
      MP2_DFP_PGRAM_MMU0_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU0_MASK | \
      MP2_DFP_PGRAM_MMU0_CNTL_PGFSM_MEM_SDDS_EN_MMU0_MASK | \
      MP2_DFP_PGRAM_MMU0_CNTL_PGFSM_MEM_SDDS_MODE_MMU0_MASK | \
      MP2_DFP_PGRAM_MMU0_CNTL_MEM_SLEEP_TIMEOUT_MMU0_MASK | \
      MP2_DFP_PGRAM_MMU0_CNTL_MEM_PG_DLY_MMU0_MASK)

#define MP2_DFP_PGRAM_MMU0_CNTL_DEFAULT 0x0010102a

#define MP2_DFP_PGRAM_MMU0_CNTL_GET_MEM_SD_MMU0(mp2_dfp_pgram_mmu0_cntl) \
     ((mp2_dfp_pgram_mmu0_cntl & MP2_DFP_PGRAM_MMU0_CNTL_MEM_SD_MMU0_MASK) >> MP2_DFP_PGRAM_MMU0_CNTL_MEM_SD_MMU0_SHIFT)
#define MP2_DFP_PGRAM_MMU0_CNTL_GET_MEM_ROP_MMU0(mp2_dfp_pgram_mmu0_cntl) \
     ((mp2_dfp_pgram_mmu0_cntl & MP2_DFP_PGRAM_MMU0_CNTL_MEM_ROP_MMU0_MASK) >> MP2_DFP_PGRAM_MMU0_CNTL_MEM_ROP_MMU0_SHIFT)
#define MP2_DFP_PGRAM_MMU0_CNTL_GET_MEM_DEEP_SLEEP_EN_MMU0(mp2_dfp_pgram_mmu0_cntl) \
     ((mp2_dfp_pgram_mmu0_cntl & MP2_DFP_PGRAM_MMU0_CNTL_MEM_DEEP_SLEEP_EN_MMU0_MASK) >> MP2_DFP_PGRAM_MMU0_CNTL_MEM_DEEP_SLEEP_EN_MMU0_SHIFT)
#define MP2_DFP_PGRAM_MMU0_CNTL_GET_MEM_DEEP_SLEEP_STATUS_MMU0(mp2_dfp_pgram_mmu0_cntl) \
     ((mp2_dfp_pgram_mmu0_cntl & MP2_DFP_PGRAM_MMU0_CNTL_MEM_DEEP_SLEEP_STATUS_MMU0_MASK) >> MP2_DFP_PGRAM_MMU0_CNTL_MEM_DEEP_SLEEP_STATUS_MMU0_SHIFT)
#define MP2_DFP_PGRAM_MMU0_CNTL_GET_MEM_LIGHT_SLEEP_EN_MMU0(mp2_dfp_pgram_mmu0_cntl) \
     ((mp2_dfp_pgram_mmu0_cntl & MP2_DFP_PGRAM_MMU0_CNTL_MEM_LIGHT_SLEEP_EN_MMU0_MASK) >> MP2_DFP_PGRAM_MMU0_CNTL_MEM_LIGHT_SLEEP_EN_MMU0_SHIFT)
#define MP2_DFP_PGRAM_MMU0_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_MMU0(mp2_dfp_pgram_mmu0_cntl) \
     ((mp2_dfp_pgram_mmu0_cntl & MP2_DFP_PGRAM_MMU0_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU0_MASK) >> MP2_DFP_PGRAM_MMU0_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU0_SHIFT)
#define MP2_DFP_PGRAM_MMU0_CNTL_GET_PGFSM_MEM_SDDS_EN_MMU0(mp2_dfp_pgram_mmu0_cntl) \
     ((mp2_dfp_pgram_mmu0_cntl & MP2_DFP_PGRAM_MMU0_CNTL_PGFSM_MEM_SDDS_EN_MMU0_MASK) >> MP2_DFP_PGRAM_MMU0_CNTL_PGFSM_MEM_SDDS_EN_MMU0_SHIFT)
#define MP2_DFP_PGRAM_MMU0_CNTL_GET_PGFSM_MEM_SDDS_MODE_MMU0(mp2_dfp_pgram_mmu0_cntl) \
     ((mp2_dfp_pgram_mmu0_cntl & MP2_DFP_PGRAM_MMU0_CNTL_PGFSM_MEM_SDDS_MODE_MMU0_MASK) >> MP2_DFP_PGRAM_MMU0_CNTL_PGFSM_MEM_SDDS_MODE_MMU0_SHIFT)
#define MP2_DFP_PGRAM_MMU0_CNTL_GET_MEM_SLEEP_TIMEOUT_MMU0(mp2_dfp_pgram_mmu0_cntl) \
     ((mp2_dfp_pgram_mmu0_cntl & MP2_DFP_PGRAM_MMU0_CNTL_MEM_SLEEP_TIMEOUT_MMU0_MASK) >> MP2_DFP_PGRAM_MMU0_CNTL_MEM_SLEEP_TIMEOUT_MMU0_SHIFT)
#define MP2_DFP_PGRAM_MMU0_CNTL_GET_MEM_PG_DLY_MMU0(mp2_dfp_pgram_mmu0_cntl) \
     ((mp2_dfp_pgram_mmu0_cntl & MP2_DFP_PGRAM_MMU0_CNTL_MEM_PG_DLY_MMU0_MASK) >> MP2_DFP_PGRAM_MMU0_CNTL_MEM_PG_DLY_MMU0_SHIFT)

#define MP2_DFP_PGRAM_MMU0_CNTL_SET_MEM_SD_MMU0(mp2_dfp_pgram_mmu0_cntl_reg, mem_sd_mmu0) \
     mp2_dfp_pgram_mmu0_cntl_reg = (mp2_dfp_pgram_mmu0_cntl_reg & ~MP2_DFP_PGRAM_MMU0_CNTL_MEM_SD_MMU0_MASK) | (mem_sd_mmu0 << MP2_DFP_PGRAM_MMU0_CNTL_MEM_SD_MMU0_SHIFT)
#define MP2_DFP_PGRAM_MMU0_CNTL_SET_MEM_ROP_MMU0(mp2_dfp_pgram_mmu0_cntl_reg, mem_rop_mmu0) \
     mp2_dfp_pgram_mmu0_cntl_reg = (mp2_dfp_pgram_mmu0_cntl_reg & ~MP2_DFP_PGRAM_MMU0_CNTL_MEM_ROP_MMU0_MASK) | (mem_rop_mmu0 << MP2_DFP_PGRAM_MMU0_CNTL_MEM_ROP_MMU0_SHIFT)
#define MP2_DFP_PGRAM_MMU0_CNTL_SET_MEM_DEEP_SLEEP_EN_MMU0(mp2_dfp_pgram_mmu0_cntl_reg, mem_deep_sleep_en_mmu0) \
     mp2_dfp_pgram_mmu0_cntl_reg = (mp2_dfp_pgram_mmu0_cntl_reg & ~MP2_DFP_PGRAM_MMU0_CNTL_MEM_DEEP_SLEEP_EN_MMU0_MASK) | (mem_deep_sleep_en_mmu0 << MP2_DFP_PGRAM_MMU0_CNTL_MEM_DEEP_SLEEP_EN_MMU0_SHIFT)
#define MP2_DFP_PGRAM_MMU0_CNTL_SET_MEM_DEEP_SLEEP_STATUS_MMU0(mp2_dfp_pgram_mmu0_cntl_reg, mem_deep_sleep_status_mmu0) \
     mp2_dfp_pgram_mmu0_cntl_reg = (mp2_dfp_pgram_mmu0_cntl_reg & ~MP2_DFP_PGRAM_MMU0_CNTL_MEM_DEEP_SLEEP_STATUS_MMU0_MASK) | (mem_deep_sleep_status_mmu0 << MP2_DFP_PGRAM_MMU0_CNTL_MEM_DEEP_SLEEP_STATUS_MMU0_SHIFT)
#define MP2_DFP_PGRAM_MMU0_CNTL_SET_MEM_LIGHT_SLEEP_EN_MMU0(mp2_dfp_pgram_mmu0_cntl_reg, mem_light_sleep_en_mmu0) \
     mp2_dfp_pgram_mmu0_cntl_reg = (mp2_dfp_pgram_mmu0_cntl_reg & ~MP2_DFP_PGRAM_MMU0_CNTL_MEM_LIGHT_SLEEP_EN_MMU0_MASK) | (mem_light_sleep_en_mmu0 << MP2_DFP_PGRAM_MMU0_CNTL_MEM_LIGHT_SLEEP_EN_MMU0_SHIFT)
#define MP2_DFP_PGRAM_MMU0_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_MMU0(mp2_dfp_pgram_mmu0_cntl_reg, mem_light_sleep_status_mmu0) \
     mp2_dfp_pgram_mmu0_cntl_reg = (mp2_dfp_pgram_mmu0_cntl_reg & ~MP2_DFP_PGRAM_MMU0_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU0_MASK) | (mem_light_sleep_status_mmu0 << MP2_DFP_PGRAM_MMU0_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU0_SHIFT)
#define MP2_DFP_PGRAM_MMU0_CNTL_SET_PGFSM_MEM_SDDS_EN_MMU0(mp2_dfp_pgram_mmu0_cntl_reg, pgfsm_mem_sdds_en_mmu0) \
     mp2_dfp_pgram_mmu0_cntl_reg = (mp2_dfp_pgram_mmu0_cntl_reg & ~MP2_DFP_PGRAM_MMU0_CNTL_PGFSM_MEM_SDDS_EN_MMU0_MASK) | (pgfsm_mem_sdds_en_mmu0 << MP2_DFP_PGRAM_MMU0_CNTL_PGFSM_MEM_SDDS_EN_MMU0_SHIFT)
#define MP2_DFP_PGRAM_MMU0_CNTL_SET_PGFSM_MEM_SDDS_MODE_MMU0(mp2_dfp_pgram_mmu0_cntl_reg, pgfsm_mem_sdds_mode_mmu0) \
     mp2_dfp_pgram_mmu0_cntl_reg = (mp2_dfp_pgram_mmu0_cntl_reg & ~MP2_DFP_PGRAM_MMU0_CNTL_PGFSM_MEM_SDDS_MODE_MMU0_MASK) | (pgfsm_mem_sdds_mode_mmu0 << MP2_DFP_PGRAM_MMU0_CNTL_PGFSM_MEM_SDDS_MODE_MMU0_SHIFT)
#define MP2_DFP_PGRAM_MMU0_CNTL_SET_MEM_SLEEP_TIMEOUT_MMU0(mp2_dfp_pgram_mmu0_cntl_reg, mem_sleep_timeout_mmu0) \
     mp2_dfp_pgram_mmu0_cntl_reg = (mp2_dfp_pgram_mmu0_cntl_reg & ~MP2_DFP_PGRAM_MMU0_CNTL_MEM_SLEEP_TIMEOUT_MMU0_MASK) | (mem_sleep_timeout_mmu0 << MP2_DFP_PGRAM_MMU0_CNTL_MEM_SLEEP_TIMEOUT_MMU0_SHIFT)
#define MP2_DFP_PGRAM_MMU0_CNTL_SET_MEM_PG_DLY_MMU0(mp2_dfp_pgram_mmu0_cntl_reg, mem_pg_dly_mmu0) \
     mp2_dfp_pgram_mmu0_cntl_reg = (mp2_dfp_pgram_mmu0_cntl_reg & ~MP2_DFP_PGRAM_MMU0_CNTL_MEM_PG_DLY_MMU0_MASK) | (mem_pg_dly_mmu0 << MP2_DFP_PGRAM_MMU0_CNTL_MEM_PG_DLY_MMU0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfp_pgram_mmu0_cntl_t {
          unsigned int mem_sd_mmu0                    : MP2_DFP_PGRAM_MMU0_CNTL_MEM_SD_MMU0_SIZE;
          unsigned int mem_rop_mmu0                   : MP2_DFP_PGRAM_MMU0_CNTL_MEM_ROP_MMU0_SIZE;
          unsigned int mem_deep_sleep_en_mmu0         : MP2_DFP_PGRAM_MMU0_CNTL_MEM_DEEP_SLEEP_EN_MMU0_SIZE;
          unsigned int mem_deep_sleep_status_mmu0     : MP2_DFP_PGRAM_MMU0_CNTL_MEM_DEEP_SLEEP_STATUS_MMU0_SIZE;
          unsigned int mem_light_sleep_en_mmu0        : MP2_DFP_PGRAM_MMU0_CNTL_MEM_LIGHT_SLEEP_EN_MMU0_SIZE;
          unsigned int mem_light_sleep_status_mmu0    : MP2_DFP_PGRAM_MMU0_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU0_SIZE;
          unsigned int pgfsm_mem_sdds_en_mmu0         : MP2_DFP_PGRAM_MMU0_CNTL_PGFSM_MEM_SDDS_EN_MMU0_SIZE;
          unsigned int pgfsm_mem_sdds_mode_mmu0       : MP2_DFP_PGRAM_MMU0_CNTL_PGFSM_MEM_SDDS_MODE_MMU0_SIZE;
          unsigned int mem_sleep_timeout_mmu0         : MP2_DFP_PGRAM_MMU0_CNTL_MEM_SLEEP_TIMEOUT_MMU0_SIZE;
          unsigned int mem_pg_dly_mmu0                : MP2_DFP_PGRAM_MMU0_CNTL_MEM_PG_DLY_MMU0_SIZE;
          unsigned int                                : 8;
     } mp2_dfp_pgram_mmu0_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfp_pgram_mmu0_cntl_t {
          unsigned int                                : 8;
          unsigned int mem_pg_dly_mmu0                : MP2_DFP_PGRAM_MMU0_CNTL_MEM_PG_DLY_MMU0_SIZE;
          unsigned int mem_sleep_timeout_mmu0         : MP2_DFP_PGRAM_MMU0_CNTL_MEM_SLEEP_TIMEOUT_MMU0_SIZE;
          unsigned int pgfsm_mem_sdds_mode_mmu0       : MP2_DFP_PGRAM_MMU0_CNTL_PGFSM_MEM_SDDS_MODE_MMU0_SIZE;
          unsigned int pgfsm_mem_sdds_en_mmu0         : MP2_DFP_PGRAM_MMU0_CNTL_PGFSM_MEM_SDDS_EN_MMU0_SIZE;
          unsigned int mem_light_sleep_status_mmu0    : MP2_DFP_PGRAM_MMU0_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU0_SIZE;
          unsigned int mem_light_sleep_en_mmu0        : MP2_DFP_PGRAM_MMU0_CNTL_MEM_LIGHT_SLEEP_EN_MMU0_SIZE;
          unsigned int mem_deep_sleep_status_mmu0     : MP2_DFP_PGRAM_MMU0_CNTL_MEM_DEEP_SLEEP_STATUS_MMU0_SIZE;
          unsigned int mem_deep_sleep_en_mmu0         : MP2_DFP_PGRAM_MMU0_CNTL_MEM_DEEP_SLEEP_EN_MMU0_SIZE;
          unsigned int mem_rop_mmu0                   : MP2_DFP_PGRAM_MMU0_CNTL_MEM_ROP_MMU0_SIZE;
          unsigned int mem_sd_mmu0                    : MP2_DFP_PGRAM_MMU0_CNTL_MEM_SD_MMU0_SIZE;
     } mp2_dfp_pgram_mmu0_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfp_pgram_mmu0_cntl_t f;
} mp2_dfp_pgram_mmu0_cntl_u;


/*
 * MP2_DFP_PGRAM_MMU1_CNTL struct
 */

#define MP2_DFP_PGRAM_MMU1_CNTL_REG_SIZE 32
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_SD_MMU1_SIZE 1
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_ROP_MMU1_SIZE 1
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_DEEP_SLEEP_EN_MMU1_SIZE 1
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_DEEP_SLEEP_STATUS_MMU1_SIZE 1
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_LIGHT_SLEEP_EN_MMU1_SIZE 1
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU1_SIZE 1
#define MP2_DFP_PGRAM_MMU1_CNTL_PGFSM_MEM_SDDS_EN_MMU1_SIZE 1
#define MP2_DFP_PGRAM_MMU1_CNTL_PGFSM_MEM_SDDS_MODE_MMU1_SIZE 1
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_SLEEP_TIMEOUT_MMU1_SIZE 8
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_PG_DLY_MMU1_SIZE 8

#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_SD_MMU1_SHIFT 0
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_ROP_MMU1_SHIFT 1
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_DEEP_SLEEP_EN_MMU1_SHIFT 2
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_DEEP_SLEEP_STATUS_MMU1_SHIFT 3
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_LIGHT_SLEEP_EN_MMU1_SHIFT 4
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU1_SHIFT 5
#define MP2_DFP_PGRAM_MMU1_CNTL_PGFSM_MEM_SDDS_EN_MMU1_SHIFT 6
#define MP2_DFP_PGRAM_MMU1_CNTL_PGFSM_MEM_SDDS_MODE_MMU1_SHIFT 7
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_SLEEP_TIMEOUT_MMU1_SHIFT 8
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_PG_DLY_MMU1_SHIFT 16

#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_SD_MMU1_MASK 0x1
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_ROP_MMU1_MASK 0x2
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_DEEP_SLEEP_EN_MMU1_MASK 0x4
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_DEEP_SLEEP_STATUS_MMU1_MASK 0x8
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_LIGHT_SLEEP_EN_MMU1_MASK 0x10
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU1_MASK 0x20
#define MP2_DFP_PGRAM_MMU1_CNTL_PGFSM_MEM_SDDS_EN_MMU1_MASK 0x40
#define MP2_DFP_PGRAM_MMU1_CNTL_PGFSM_MEM_SDDS_MODE_MMU1_MASK 0x80
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_SLEEP_TIMEOUT_MMU1_MASK 0xff00
#define MP2_DFP_PGRAM_MMU1_CNTL_MEM_PG_DLY_MMU1_MASK 0xff0000

#define MP2_DFP_PGRAM_MMU1_CNTL_MASK \
     (MP2_DFP_PGRAM_MMU1_CNTL_MEM_SD_MMU1_MASK | \
      MP2_DFP_PGRAM_MMU1_CNTL_MEM_ROP_MMU1_MASK | \
      MP2_DFP_PGRAM_MMU1_CNTL_MEM_DEEP_SLEEP_EN_MMU1_MASK | \
      MP2_DFP_PGRAM_MMU1_CNTL_MEM_DEEP_SLEEP_STATUS_MMU1_MASK | \
      MP2_DFP_PGRAM_MMU1_CNTL_MEM_LIGHT_SLEEP_EN_MMU1_MASK | \
      MP2_DFP_PGRAM_MMU1_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU1_MASK | \
      MP2_DFP_PGRAM_MMU1_CNTL_PGFSM_MEM_SDDS_EN_MMU1_MASK | \
      MP2_DFP_PGRAM_MMU1_CNTL_PGFSM_MEM_SDDS_MODE_MMU1_MASK | \
      MP2_DFP_PGRAM_MMU1_CNTL_MEM_SLEEP_TIMEOUT_MMU1_MASK | \
      MP2_DFP_PGRAM_MMU1_CNTL_MEM_PG_DLY_MMU1_MASK)

#define MP2_DFP_PGRAM_MMU1_CNTL_DEFAULT 0x0010102a

#define MP2_DFP_PGRAM_MMU1_CNTL_GET_MEM_SD_MMU1(mp2_dfp_pgram_mmu1_cntl) \
     ((mp2_dfp_pgram_mmu1_cntl & MP2_DFP_PGRAM_MMU1_CNTL_MEM_SD_MMU1_MASK) >> MP2_DFP_PGRAM_MMU1_CNTL_MEM_SD_MMU1_SHIFT)
#define MP2_DFP_PGRAM_MMU1_CNTL_GET_MEM_ROP_MMU1(mp2_dfp_pgram_mmu1_cntl) \
     ((mp2_dfp_pgram_mmu1_cntl & MP2_DFP_PGRAM_MMU1_CNTL_MEM_ROP_MMU1_MASK) >> MP2_DFP_PGRAM_MMU1_CNTL_MEM_ROP_MMU1_SHIFT)
#define MP2_DFP_PGRAM_MMU1_CNTL_GET_MEM_DEEP_SLEEP_EN_MMU1(mp2_dfp_pgram_mmu1_cntl) \
     ((mp2_dfp_pgram_mmu1_cntl & MP2_DFP_PGRAM_MMU1_CNTL_MEM_DEEP_SLEEP_EN_MMU1_MASK) >> MP2_DFP_PGRAM_MMU1_CNTL_MEM_DEEP_SLEEP_EN_MMU1_SHIFT)
#define MP2_DFP_PGRAM_MMU1_CNTL_GET_MEM_DEEP_SLEEP_STATUS_MMU1(mp2_dfp_pgram_mmu1_cntl) \
     ((mp2_dfp_pgram_mmu1_cntl & MP2_DFP_PGRAM_MMU1_CNTL_MEM_DEEP_SLEEP_STATUS_MMU1_MASK) >> MP2_DFP_PGRAM_MMU1_CNTL_MEM_DEEP_SLEEP_STATUS_MMU1_SHIFT)
#define MP2_DFP_PGRAM_MMU1_CNTL_GET_MEM_LIGHT_SLEEP_EN_MMU1(mp2_dfp_pgram_mmu1_cntl) \
     ((mp2_dfp_pgram_mmu1_cntl & MP2_DFP_PGRAM_MMU1_CNTL_MEM_LIGHT_SLEEP_EN_MMU1_MASK) >> MP2_DFP_PGRAM_MMU1_CNTL_MEM_LIGHT_SLEEP_EN_MMU1_SHIFT)
#define MP2_DFP_PGRAM_MMU1_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_MMU1(mp2_dfp_pgram_mmu1_cntl) \
     ((mp2_dfp_pgram_mmu1_cntl & MP2_DFP_PGRAM_MMU1_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU1_MASK) >> MP2_DFP_PGRAM_MMU1_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU1_SHIFT)
#define MP2_DFP_PGRAM_MMU1_CNTL_GET_PGFSM_MEM_SDDS_EN_MMU1(mp2_dfp_pgram_mmu1_cntl) \
     ((mp2_dfp_pgram_mmu1_cntl & MP2_DFP_PGRAM_MMU1_CNTL_PGFSM_MEM_SDDS_EN_MMU1_MASK) >> MP2_DFP_PGRAM_MMU1_CNTL_PGFSM_MEM_SDDS_EN_MMU1_SHIFT)
#define MP2_DFP_PGRAM_MMU1_CNTL_GET_PGFSM_MEM_SDDS_MODE_MMU1(mp2_dfp_pgram_mmu1_cntl) \
     ((mp2_dfp_pgram_mmu1_cntl & MP2_DFP_PGRAM_MMU1_CNTL_PGFSM_MEM_SDDS_MODE_MMU1_MASK) >> MP2_DFP_PGRAM_MMU1_CNTL_PGFSM_MEM_SDDS_MODE_MMU1_SHIFT)
#define MP2_DFP_PGRAM_MMU1_CNTL_GET_MEM_SLEEP_TIMEOUT_MMU1(mp2_dfp_pgram_mmu1_cntl) \
     ((mp2_dfp_pgram_mmu1_cntl & MP2_DFP_PGRAM_MMU1_CNTL_MEM_SLEEP_TIMEOUT_MMU1_MASK) >> MP2_DFP_PGRAM_MMU1_CNTL_MEM_SLEEP_TIMEOUT_MMU1_SHIFT)
#define MP2_DFP_PGRAM_MMU1_CNTL_GET_MEM_PG_DLY_MMU1(mp2_dfp_pgram_mmu1_cntl) \
     ((mp2_dfp_pgram_mmu1_cntl & MP2_DFP_PGRAM_MMU1_CNTL_MEM_PG_DLY_MMU1_MASK) >> MP2_DFP_PGRAM_MMU1_CNTL_MEM_PG_DLY_MMU1_SHIFT)

#define MP2_DFP_PGRAM_MMU1_CNTL_SET_MEM_SD_MMU1(mp2_dfp_pgram_mmu1_cntl_reg, mem_sd_mmu1) \
     mp2_dfp_pgram_mmu1_cntl_reg = (mp2_dfp_pgram_mmu1_cntl_reg & ~MP2_DFP_PGRAM_MMU1_CNTL_MEM_SD_MMU1_MASK) | (mem_sd_mmu1 << MP2_DFP_PGRAM_MMU1_CNTL_MEM_SD_MMU1_SHIFT)
#define MP2_DFP_PGRAM_MMU1_CNTL_SET_MEM_ROP_MMU1(mp2_dfp_pgram_mmu1_cntl_reg, mem_rop_mmu1) \
     mp2_dfp_pgram_mmu1_cntl_reg = (mp2_dfp_pgram_mmu1_cntl_reg & ~MP2_DFP_PGRAM_MMU1_CNTL_MEM_ROP_MMU1_MASK) | (mem_rop_mmu1 << MP2_DFP_PGRAM_MMU1_CNTL_MEM_ROP_MMU1_SHIFT)
#define MP2_DFP_PGRAM_MMU1_CNTL_SET_MEM_DEEP_SLEEP_EN_MMU1(mp2_dfp_pgram_mmu1_cntl_reg, mem_deep_sleep_en_mmu1) \
     mp2_dfp_pgram_mmu1_cntl_reg = (mp2_dfp_pgram_mmu1_cntl_reg & ~MP2_DFP_PGRAM_MMU1_CNTL_MEM_DEEP_SLEEP_EN_MMU1_MASK) | (mem_deep_sleep_en_mmu1 << MP2_DFP_PGRAM_MMU1_CNTL_MEM_DEEP_SLEEP_EN_MMU1_SHIFT)
#define MP2_DFP_PGRAM_MMU1_CNTL_SET_MEM_DEEP_SLEEP_STATUS_MMU1(mp2_dfp_pgram_mmu1_cntl_reg, mem_deep_sleep_status_mmu1) \
     mp2_dfp_pgram_mmu1_cntl_reg = (mp2_dfp_pgram_mmu1_cntl_reg & ~MP2_DFP_PGRAM_MMU1_CNTL_MEM_DEEP_SLEEP_STATUS_MMU1_MASK) | (mem_deep_sleep_status_mmu1 << MP2_DFP_PGRAM_MMU1_CNTL_MEM_DEEP_SLEEP_STATUS_MMU1_SHIFT)
#define MP2_DFP_PGRAM_MMU1_CNTL_SET_MEM_LIGHT_SLEEP_EN_MMU1(mp2_dfp_pgram_mmu1_cntl_reg, mem_light_sleep_en_mmu1) \
     mp2_dfp_pgram_mmu1_cntl_reg = (mp2_dfp_pgram_mmu1_cntl_reg & ~MP2_DFP_PGRAM_MMU1_CNTL_MEM_LIGHT_SLEEP_EN_MMU1_MASK) | (mem_light_sleep_en_mmu1 << MP2_DFP_PGRAM_MMU1_CNTL_MEM_LIGHT_SLEEP_EN_MMU1_SHIFT)
#define MP2_DFP_PGRAM_MMU1_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_MMU1(mp2_dfp_pgram_mmu1_cntl_reg, mem_light_sleep_status_mmu1) \
     mp2_dfp_pgram_mmu1_cntl_reg = (mp2_dfp_pgram_mmu1_cntl_reg & ~MP2_DFP_PGRAM_MMU1_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU1_MASK) | (mem_light_sleep_status_mmu1 << MP2_DFP_PGRAM_MMU1_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU1_SHIFT)
#define MP2_DFP_PGRAM_MMU1_CNTL_SET_PGFSM_MEM_SDDS_EN_MMU1(mp2_dfp_pgram_mmu1_cntl_reg, pgfsm_mem_sdds_en_mmu1) \
     mp2_dfp_pgram_mmu1_cntl_reg = (mp2_dfp_pgram_mmu1_cntl_reg & ~MP2_DFP_PGRAM_MMU1_CNTL_PGFSM_MEM_SDDS_EN_MMU1_MASK) | (pgfsm_mem_sdds_en_mmu1 << MP2_DFP_PGRAM_MMU1_CNTL_PGFSM_MEM_SDDS_EN_MMU1_SHIFT)
#define MP2_DFP_PGRAM_MMU1_CNTL_SET_PGFSM_MEM_SDDS_MODE_MMU1(mp2_dfp_pgram_mmu1_cntl_reg, pgfsm_mem_sdds_mode_mmu1) \
     mp2_dfp_pgram_mmu1_cntl_reg = (mp2_dfp_pgram_mmu1_cntl_reg & ~MP2_DFP_PGRAM_MMU1_CNTL_PGFSM_MEM_SDDS_MODE_MMU1_MASK) | (pgfsm_mem_sdds_mode_mmu1 << MP2_DFP_PGRAM_MMU1_CNTL_PGFSM_MEM_SDDS_MODE_MMU1_SHIFT)
#define MP2_DFP_PGRAM_MMU1_CNTL_SET_MEM_SLEEP_TIMEOUT_MMU1(mp2_dfp_pgram_mmu1_cntl_reg, mem_sleep_timeout_mmu1) \
     mp2_dfp_pgram_mmu1_cntl_reg = (mp2_dfp_pgram_mmu1_cntl_reg & ~MP2_DFP_PGRAM_MMU1_CNTL_MEM_SLEEP_TIMEOUT_MMU1_MASK) | (mem_sleep_timeout_mmu1 << MP2_DFP_PGRAM_MMU1_CNTL_MEM_SLEEP_TIMEOUT_MMU1_SHIFT)
#define MP2_DFP_PGRAM_MMU1_CNTL_SET_MEM_PG_DLY_MMU1(mp2_dfp_pgram_mmu1_cntl_reg, mem_pg_dly_mmu1) \
     mp2_dfp_pgram_mmu1_cntl_reg = (mp2_dfp_pgram_mmu1_cntl_reg & ~MP2_DFP_PGRAM_MMU1_CNTL_MEM_PG_DLY_MMU1_MASK) | (mem_pg_dly_mmu1 << MP2_DFP_PGRAM_MMU1_CNTL_MEM_PG_DLY_MMU1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfp_pgram_mmu1_cntl_t {
          unsigned int mem_sd_mmu1                    : MP2_DFP_PGRAM_MMU1_CNTL_MEM_SD_MMU1_SIZE;
          unsigned int mem_rop_mmu1                   : MP2_DFP_PGRAM_MMU1_CNTL_MEM_ROP_MMU1_SIZE;
          unsigned int mem_deep_sleep_en_mmu1         : MP2_DFP_PGRAM_MMU1_CNTL_MEM_DEEP_SLEEP_EN_MMU1_SIZE;
          unsigned int mem_deep_sleep_status_mmu1     : MP2_DFP_PGRAM_MMU1_CNTL_MEM_DEEP_SLEEP_STATUS_MMU1_SIZE;
          unsigned int mem_light_sleep_en_mmu1        : MP2_DFP_PGRAM_MMU1_CNTL_MEM_LIGHT_SLEEP_EN_MMU1_SIZE;
          unsigned int mem_light_sleep_status_mmu1    : MP2_DFP_PGRAM_MMU1_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU1_SIZE;
          unsigned int pgfsm_mem_sdds_en_mmu1         : MP2_DFP_PGRAM_MMU1_CNTL_PGFSM_MEM_SDDS_EN_MMU1_SIZE;
          unsigned int pgfsm_mem_sdds_mode_mmu1       : MP2_DFP_PGRAM_MMU1_CNTL_PGFSM_MEM_SDDS_MODE_MMU1_SIZE;
          unsigned int mem_sleep_timeout_mmu1         : MP2_DFP_PGRAM_MMU1_CNTL_MEM_SLEEP_TIMEOUT_MMU1_SIZE;
          unsigned int mem_pg_dly_mmu1                : MP2_DFP_PGRAM_MMU1_CNTL_MEM_PG_DLY_MMU1_SIZE;
          unsigned int                                : 8;
     } mp2_dfp_pgram_mmu1_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfp_pgram_mmu1_cntl_t {
          unsigned int                                : 8;
          unsigned int mem_pg_dly_mmu1                : MP2_DFP_PGRAM_MMU1_CNTL_MEM_PG_DLY_MMU1_SIZE;
          unsigned int mem_sleep_timeout_mmu1         : MP2_DFP_PGRAM_MMU1_CNTL_MEM_SLEEP_TIMEOUT_MMU1_SIZE;
          unsigned int pgfsm_mem_sdds_mode_mmu1       : MP2_DFP_PGRAM_MMU1_CNTL_PGFSM_MEM_SDDS_MODE_MMU1_SIZE;
          unsigned int pgfsm_mem_sdds_en_mmu1         : MP2_DFP_PGRAM_MMU1_CNTL_PGFSM_MEM_SDDS_EN_MMU1_SIZE;
          unsigned int mem_light_sleep_status_mmu1    : MP2_DFP_PGRAM_MMU1_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU1_SIZE;
          unsigned int mem_light_sleep_en_mmu1        : MP2_DFP_PGRAM_MMU1_CNTL_MEM_LIGHT_SLEEP_EN_MMU1_SIZE;
          unsigned int mem_deep_sleep_status_mmu1     : MP2_DFP_PGRAM_MMU1_CNTL_MEM_DEEP_SLEEP_STATUS_MMU1_SIZE;
          unsigned int mem_deep_sleep_en_mmu1         : MP2_DFP_PGRAM_MMU1_CNTL_MEM_DEEP_SLEEP_EN_MMU1_SIZE;
          unsigned int mem_rop_mmu1                   : MP2_DFP_PGRAM_MMU1_CNTL_MEM_ROP_MMU1_SIZE;
          unsigned int mem_sd_mmu1                    : MP2_DFP_PGRAM_MMU1_CNTL_MEM_SD_MMU1_SIZE;
     } mp2_dfp_pgram_mmu1_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfp_pgram_mmu1_cntl_t f;
} mp2_dfp_pgram_mmu1_cntl_u;


/*
 * MP2_DFP_PGRAM_MMU2_CNTL struct
 */

#define MP2_DFP_PGRAM_MMU2_CNTL_REG_SIZE 32
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_SD_MMU2_SIZE 1
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_ROP_MMU2_SIZE 1
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_DEEP_SLEEP_EN_MMU2_SIZE 1
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_DEEP_SLEEP_STATUS_MMU2_SIZE 1
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_LIGHT_SLEEP_EN_MMU2_SIZE 1
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU2_SIZE 1
#define MP2_DFP_PGRAM_MMU2_CNTL_PGFSM_MEM_SDDS_EN_MMU2_SIZE 1
#define MP2_DFP_PGRAM_MMU2_CNTL_PGFSM_MEM_SDDS_MODE_MMU2_SIZE 1
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_SLEEP_TIMEOUT_MMU2_SIZE 8
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_PG_DLY_MMU2_SIZE 8

#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_SD_MMU2_SHIFT 0
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_ROP_MMU2_SHIFT 1
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_DEEP_SLEEP_EN_MMU2_SHIFT 2
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_DEEP_SLEEP_STATUS_MMU2_SHIFT 3
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_LIGHT_SLEEP_EN_MMU2_SHIFT 4
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU2_SHIFT 5
#define MP2_DFP_PGRAM_MMU2_CNTL_PGFSM_MEM_SDDS_EN_MMU2_SHIFT 6
#define MP2_DFP_PGRAM_MMU2_CNTL_PGFSM_MEM_SDDS_MODE_MMU2_SHIFT 7
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_SLEEP_TIMEOUT_MMU2_SHIFT 8
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_PG_DLY_MMU2_SHIFT 16

#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_SD_MMU2_MASK 0x1
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_ROP_MMU2_MASK 0x2
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_DEEP_SLEEP_EN_MMU2_MASK 0x4
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_DEEP_SLEEP_STATUS_MMU2_MASK 0x8
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_LIGHT_SLEEP_EN_MMU2_MASK 0x10
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU2_MASK 0x20
#define MP2_DFP_PGRAM_MMU2_CNTL_PGFSM_MEM_SDDS_EN_MMU2_MASK 0x40
#define MP2_DFP_PGRAM_MMU2_CNTL_PGFSM_MEM_SDDS_MODE_MMU2_MASK 0x80
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_SLEEP_TIMEOUT_MMU2_MASK 0xff00
#define MP2_DFP_PGRAM_MMU2_CNTL_MEM_PG_DLY_MMU2_MASK 0xff0000

#define MP2_DFP_PGRAM_MMU2_CNTL_MASK \
     (MP2_DFP_PGRAM_MMU2_CNTL_MEM_SD_MMU2_MASK | \
      MP2_DFP_PGRAM_MMU2_CNTL_MEM_ROP_MMU2_MASK | \
      MP2_DFP_PGRAM_MMU2_CNTL_MEM_DEEP_SLEEP_EN_MMU2_MASK | \
      MP2_DFP_PGRAM_MMU2_CNTL_MEM_DEEP_SLEEP_STATUS_MMU2_MASK | \
      MP2_DFP_PGRAM_MMU2_CNTL_MEM_LIGHT_SLEEP_EN_MMU2_MASK | \
      MP2_DFP_PGRAM_MMU2_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU2_MASK | \
      MP2_DFP_PGRAM_MMU2_CNTL_PGFSM_MEM_SDDS_EN_MMU2_MASK | \
      MP2_DFP_PGRAM_MMU2_CNTL_PGFSM_MEM_SDDS_MODE_MMU2_MASK | \
      MP2_DFP_PGRAM_MMU2_CNTL_MEM_SLEEP_TIMEOUT_MMU2_MASK | \
      MP2_DFP_PGRAM_MMU2_CNTL_MEM_PG_DLY_MMU2_MASK)

#define MP2_DFP_PGRAM_MMU2_CNTL_DEFAULT 0x0010102a

#define MP2_DFP_PGRAM_MMU2_CNTL_GET_MEM_SD_MMU2(mp2_dfp_pgram_mmu2_cntl) \
     ((mp2_dfp_pgram_mmu2_cntl & MP2_DFP_PGRAM_MMU2_CNTL_MEM_SD_MMU2_MASK) >> MP2_DFP_PGRAM_MMU2_CNTL_MEM_SD_MMU2_SHIFT)
#define MP2_DFP_PGRAM_MMU2_CNTL_GET_MEM_ROP_MMU2(mp2_dfp_pgram_mmu2_cntl) \
     ((mp2_dfp_pgram_mmu2_cntl & MP2_DFP_PGRAM_MMU2_CNTL_MEM_ROP_MMU2_MASK) >> MP2_DFP_PGRAM_MMU2_CNTL_MEM_ROP_MMU2_SHIFT)
#define MP2_DFP_PGRAM_MMU2_CNTL_GET_MEM_DEEP_SLEEP_EN_MMU2(mp2_dfp_pgram_mmu2_cntl) \
     ((mp2_dfp_pgram_mmu2_cntl & MP2_DFP_PGRAM_MMU2_CNTL_MEM_DEEP_SLEEP_EN_MMU2_MASK) >> MP2_DFP_PGRAM_MMU2_CNTL_MEM_DEEP_SLEEP_EN_MMU2_SHIFT)
#define MP2_DFP_PGRAM_MMU2_CNTL_GET_MEM_DEEP_SLEEP_STATUS_MMU2(mp2_dfp_pgram_mmu2_cntl) \
     ((mp2_dfp_pgram_mmu2_cntl & MP2_DFP_PGRAM_MMU2_CNTL_MEM_DEEP_SLEEP_STATUS_MMU2_MASK) >> MP2_DFP_PGRAM_MMU2_CNTL_MEM_DEEP_SLEEP_STATUS_MMU2_SHIFT)
#define MP2_DFP_PGRAM_MMU2_CNTL_GET_MEM_LIGHT_SLEEP_EN_MMU2(mp2_dfp_pgram_mmu2_cntl) \
     ((mp2_dfp_pgram_mmu2_cntl & MP2_DFP_PGRAM_MMU2_CNTL_MEM_LIGHT_SLEEP_EN_MMU2_MASK) >> MP2_DFP_PGRAM_MMU2_CNTL_MEM_LIGHT_SLEEP_EN_MMU2_SHIFT)
#define MP2_DFP_PGRAM_MMU2_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_MMU2(mp2_dfp_pgram_mmu2_cntl) \
     ((mp2_dfp_pgram_mmu2_cntl & MP2_DFP_PGRAM_MMU2_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU2_MASK) >> MP2_DFP_PGRAM_MMU2_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU2_SHIFT)
#define MP2_DFP_PGRAM_MMU2_CNTL_GET_PGFSM_MEM_SDDS_EN_MMU2(mp2_dfp_pgram_mmu2_cntl) \
     ((mp2_dfp_pgram_mmu2_cntl & MP2_DFP_PGRAM_MMU2_CNTL_PGFSM_MEM_SDDS_EN_MMU2_MASK) >> MP2_DFP_PGRAM_MMU2_CNTL_PGFSM_MEM_SDDS_EN_MMU2_SHIFT)
#define MP2_DFP_PGRAM_MMU2_CNTL_GET_PGFSM_MEM_SDDS_MODE_MMU2(mp2_dfp_pgram_mmu2_cntl) \
     ((mp2_dfp_pgram_mmu2_cntl & MP2_DFP_PGRAM_MMU2_CNTL_PGFSM_MEM_SDDS_MODE_MMU2_MASK) >> MP2_DFP_PGRAM_MMU2_CNTL_PGFSM_MEM_SDDS_MODE_MMU2_SHIFT)
#define MP2_DFP_PGRAM_MMU2_CNTL_GET_MEM_SLEEP_TIMEOUT_MMU2(mp2_dfp_pgram_mmu2_cntl) \
     ((mp2_dfp_pgram_mmu2_cntl & MP2_DFP_PGRAM_MMU2_CNTL_MEM_SLEEP_TIMEOUT_MMU2_MASK) >> MP2_DFP_PGRAM_MMU2_CNTL_MEM_SLEEP_TIMEOUT_MMU2_SHIFT)
#define MP2_DFP_PGRAM_MMU2_CNTL_GET_MEM_PG_DLY_MMU2(mp2_dfp_pgram_mmu2_cntl) \
     ((mp2_dfp_pgram_mmu2_cntl & MP2_DFP_PGRAM_MMU2_CNTL_MEM_PG_DLY_MMU2_MASK) >> MP2_DFP_PGRAM_MMU2_CNTL_MEM_PG_DLY_MMU2_SHIFT)

#define MP2_DFP_PGRAM_MMU2_CNTL_SET_MEM_SD_MMU2(mp2_dfp_pgram_mmu2_cntl_reg, mem_sd_mmu2) \
     mp2_dfp_pgram_mmu2_cntl_reg = (mp2_dfp_pgram_mmu2_cntl_reg & ~MP2_DFP_PGRAM_MMU2_CNTL_MEM_SD_MMU2_MASK) | (mem_sd_mmu2 << MP2_DFP_PGRAM_MMU2_CNTL_MEM_SD_MMU2_SHIFT)
#define MP2_DFP_PGRAM_MMU2_CNTL_SET_MEM_ROP_MMU2(mp2_dfp_pgram_mmu2_cntl_reg, mem_rop_mmu2) \
     mp2_dfp_pgram_mmu2_cntl_reg = (mp2_dfp_pgram_mmu2_cntl_reg & ~MP2_DFP_PGRAM_MMU2_CNTL_MEM_ROP_MMU2_MASK) | (mem_rop_mmu2 << MP2_DFP_PGRAM_MMU2_CNTL_MEM_ROP_MMU2_SHIFT)
#define MP2_DFP_PGRAM_MMU2_CNTL_SET_MEM_DEEP_SLEEP_EN_MMU2(mp2_dfp_pgram_mmu2_cntl_reg, mem_deep_sleep_en_mmu2) \
     mp2_dfp_pgram_mmu2_cntl_reg = (mp2_dfp_pgram_mmu2_cntl_reg & ~MP2_DFP_PGRAM_MMU2_CNTL_MEM_DEEP_SLEEP_EN_MMU2_MASK) | (mem_deep_sleep_en_mmu2 << MP2_DFP_PGRAM_MMU2_CNTL_MEM_DEEP_SLEEP_EN_MMU2_SHIFT)
#define MP2_DFP_PGRAM_MMU2_CNTL_SET_MEM_DEEP_SLEEP_STATUS_MMU2(mp2_dfp_pgram_mmu2_cntl_reg, mem_deep_sleep_status_mmu2) \
     mp2_dfp_pgram_mmu2_cntl_reg = (mp2_dfp_pgram_mmu2_cntl_reg & ~MP2_DFP_PGRAM_MMU2_CNTL_MEM_DEEP_SLEEP_STATUS_MMU2_MASK) | (mem_deep_sleep_status_mmu2 << MP2_DFP_PGRAM_MMU2_CNTL_MEM_DEEP_SLEEP_STATUS_MMU2_SHIFT)
#define MP2_DFP_PGRAM_MMU2_CNTL_SET_MEM_LIGHT_SLEEP_EN_MMU2(mp2_dfp_pgram_mmu2_cntl_reg, mem_light_sleep_en_mmu2) \
     mp2_dfp_pgram_mmu2_cntl_reg = (mp2_dfp_pgram_mmu2_cntl_reg & ~MP2_DFP_PGRAM_MMU2_CNTL_MEM_LIGHT_SLEEP_EN_MMU2_MASK) | (mem_light_sleep_en_mmu2 << MP2_DFP_PGRAM_MMU2_CNTL_MEM_LIGHT_SLEEP_EN_MMU2_SHIFT)
#define MP2_DFP_PGRAM_MMU2_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_MMU2(mp2_dfp_pgram_mmu2_cntl_reg, mem_light_sleep_status_mmu2) \
     mp2_dfp_pgram_mmu2_cntl_reg = (mp2_dfp_pgram_mmu2_cntl_reg & ~MP2_DFP_PGRAM_MMU2_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU2_MASK) | (mem_light_sleep_status_mmu2 << MP2_DFP_PGRAM_MMU2_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU2_SHIFT)
#define MP2_DFP_PGRAM_MMU2_CNTL_SET_PGFSM_MEM_SDDS_EN_MMU2(mp2_dfp_pgram_mmu2_cntl_reg, pgfsm_mem_sdds_en_mmu2) \
     mp2_dfp_pgram_mmu2_cntl_reg = (mp2_dfp_pgram_mmu2_cntl_reg & ~MP2_DFP_PGRAM_MMU2_CNTL_PGFSM_MEM_SDDS_EN_MMU2_MASK) | (pgfsm_mem_sdds_en_mmu2 << MP2_DFP_PGRAM_MMU2_CNTL_PGFSM_MEM_SDDS_EN_MMU2_SHIFT)
#define MP2_DFP_PGRAM_MMU2_CNTL_SET_PGFSM_MEM_SDDS_MODE_MMU2(mp2_dfp_pgram_mmu2_cntl_reg, pgfsm_mem_sdds_mode_mmu2) \
     mp2_dfp_pgram_mmu2_cntl_reg = (mp2_dfp_pgram_mmu2_cntl_reg & ~MP2_DFP_PGRAM_MMU2_CNTL_PGFSM_MEM_SDDS_MODE_MMU2_MASK) | (pgfsm_mem_sdds_mode_mmu2 << MP2_DFP_PGRAM_MMU2_CNTL_PGFSM_MEM_SDDS_MODE_MMU2_SHIFT)
#define MP2_DFP_PGRAM_MMU2_CNTL_SET_MEM_SLEEP_TIMEOUT_MMU2(mp2_dfp_pgram_mmu2_cntl_reg, mem_sleep_timeout_mmu2) \
     mp2_dfp_pgram_mmu2_cntl_reg = (mp2_dfp_pgram_mmu2_cntl_reg & ~MP2_DFP_PGRAM_MMU2_CNTL_MEM_SLEEP_TIMEOUT_MMU2_MASK) | (mem_sleep_timeout_mmu2 << MP2_DFP_PGRAM_MMU2_CNTL_MEM_SLEEP_TIMEOUT_MMU2_SHIFT)
#define MP2_DFP_PGRAM_MMU2_CNTL_SET_MEM_PG_DLY_MMU2(mp2_dfp_pgram_mmu2_cntl_reg, mem_pg_dly_mmu2) \
     mp2_dfp_pgram_mmu2_cntl_reg = (mp2_dfp_pgram_mmu2_cntl_reg & ~MP2_DFP_PGRAM_MMU2_CNTL_MEM_PG_DLY_MMU2_MASK) | (mem_pg_dly_mmu2 << MP2_DFP_PGRAM_MMU2_CNTL_MEM_PG_DLY_MMU2_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfp_pgram_mmu2_cntl_t {
          unsigned int mem_sd_mmu2                    : MP2_DFP_PGRAM_MMU2_CNTL_MEM_SD_MMU2_SIZE;
          unsigned int mem_rop_mmu2                   : MP2_DFP_PGRAM_MMU2_CNTL_MEM_ROP_MMU2_SIZE;
          unsigned int mem_deep_sleep_en_mmu2         : MP2_DFP_PGRAM_MMU2_CNTL_MEM_DEEP_SLEEP_EN_MMU2_SIZE;
          unsigned int mem_deep_sleep_status_mmu2     : MP2_DFP_PGRAM_MMU2_CNTL_MEM_DEEP_SLEEP_STATUS_MMU2_SIZE;
          unsigned int mem_light_sleep_en_mmu2        : MP2_DFP_PGRAM_MMU2_CNTL_MEM_LIGHT_SLEEP_EN_MMU2_SIZE;
          unsigned int mem_light_sleep_status_mmu2    : MP2_DFP_PGRAM_MMU2_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU2_SIZE;
          unsigned int pgfsm_mem_sdds_en_mmu2         : MP2_DFP_PGRAM_MMU2_CNTL_PGFSM_MEM_SDDS_EN_MMU2_SIZE;
          unsigned int pgfsm_mem_sdds_mode_mmu2       : MP2_DFP_PGRAM_MMU2_CNTL_PGFSM_MEM_SDDS_MODE_MMU2_SIZE;
          unsigned int mem_sleep_timeout_mmu2         : MP2_DFP_PGRAM_MMU2_CNTL_MEM_SLEEP_TIMEOUT_MMU2_SIZE;
          unsigned int mem_pg_dly_mmu2                : MP2_DFP_PGRAM_MMU2_CNTL_MEM_PG_DLY_MMU2_SIZE;
          unsigned int                                : 8;
     } mp2_dfp_pgram_mmu2_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfp_pgram_mmu2_cntl_t {
          unsigned int                                : 8;
          unsigned int mem_pg_dly_mmu2                : MP2_DFP_PGRAM_MMU2_CNTL_MEM_PG_DLY_MMU2_SIZE;
          unsigned int mem_sleep_timeout_mmu2         : MP2_DFP_PGRAM_MMU2_CNTL_MEM_SLEEP_TIMEOUT_MMU2_SIZE;
          unsigned int pgfsm_mem_sdds_mode_mmu2       : MP2_DFP_PGRAM_MMU2_CNTL_PGFSM_MEM_SDDS_MODE_MMU2_SIZE;
          unsigned int pgfsm_mem_sdds_en_mmu2         : MP2_DFP_PGRAM_MMU2_CNTL_PGFSM_MEM_SDDS_EN_MMU2_SIZE;
          unsigned int mem_light_sleep_status_mmu2    : MP2_DFP_PGRAM_MMU2_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU2_SIZE;
          unsigned int mem_light_sleep_en_mmu2        : MP2_DFP_PGRAM_MMU2_CNTL_MEM_LIGHT_SLEEP_EN_MMU2_SIZE;
          unsigned int mem_deep_sleep_status_mmu2     : MP2_DFP_PGRAM_MMU2_CNTL_MEM_DEEP_SLEEP_STATUS_MMU2_SIZE;
          unsigned int mem_deep_sleep_en_mmu2         : MP2_DFP_PGRAM_MMU2_CNTL_MEM_DEEP_SLEEP_EN_MMU2_SIZE;
          unsigned int mem_rop_mmu2                   : MP2_DFP_PGRAM_MMU2_CNTL_MEM_ROP_MMU2_SIZE;
          unsigned int mem_sd_mmu2                    : MP2_DFP_PGRAM_MMU2_CNTL_MEM_SD_MMU2_SIZE;
     } mp2_dfp_pgram_mmu2_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfp_pgram_mmu2_cntl_t f;
} mp2_dfp_pgram_mmu2_cntl_u;


/*
 * MP2_DFP_PGRAM_MMU3_CNTL struct
 */

#define MP2_DFP_PGRAM_MMU3_CNTL_REG_SIZE 32
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_SD_MMU3_SIZE 1
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_ROP_MMU3_SIZE 1
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_DEEP_SLEEP_EN_MMU3_SIZE 1
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_DEEP_SLEEP_STATUS_MMU3_SIZE 1
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_LIGHT_SLEEP_EN_MMU3_SIZE 1
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU3_SIZE 1
#define MP2_DFP_PGRAM_MMU3_CNTL_PGFSM_MEM_SDDS_EN_MMU3_SIZE 1
#define MP2_DFP_PGRAM_MMU3_CNTL_PGFSM_MEM_SDDS_MODE_MMU3_SIZE 1
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_SLEEP_TIMEOUT_MMU3_SIZE 8
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_PG_DLY_MMU3_SIZE 8

#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_SD_MMU3_SHIFT 0
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_ROP_MMU3_SHIFT 1
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_DEEP_SLEEP_EN_MMU3_SHIFT 2
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_DEEP_SLEEP_STATUS_MMU3_SHIFT 3
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_LIGHT_SLEEP_EN_MMU3_SHIFT 4
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU3_SHIFT 5
#define MP2_DFP_PGRAM_MMU3_CNTL_PGFSM_MEM_SDDS_EN_MMU3_SHIFT 6
#define MP2_DFP_PGRAM_MMU3_CNTL_PGFSM_MEM_SDDS_MODE_MMU3_SHIFT 7
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_SLEEP_TIMEOUT_MMU3_SHIFT 8
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_PG_DLY_MMU3_SHIFT 16

#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_SD_MMU3_MASK 0x1
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_ROP_MMU3_MASK 0x2
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_DEEP_SLEEP_EN_MMU3_MASK 0x4
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_DEEP_SLEEP_STATUS_MMU3_MASK 0x8
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_LIGHT_SLEEP_EN_MMU3_MASK 0x10
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU3_MASK 0x20
#define MP2_DFP_PGRAM_MMU3_CNTL_PGFSM_MEM_SDDS_EN_MMU3_MASK 0x40
#define MP2_DFP_PGRAM_MMU3_CNTL_PGFSM_MEM_SDDS_MODE_MMU3_MASK 0x80
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_SLEEP_TIMEOUT_MMU3_MASK 0xff00
#define MP2_DFP_PGRAM_MMU3_CNTL_MEM_PG_DLY_MMU3_MASK 0xff0000

#define MP2_DFP_PGRAM_MMU3_CNTL_MASK \
     (MP2_DFP_PGRAM_MMU3_CNTL_MEM_SD_MMU3_MASK | \
      MP2_DFP_PGRAM_MMU3_CNTL_MEM_ROP_MMU3_MASK | \
      MP2_DFP_PGRAM_MMU3_CNTL_MEM_DEEP_SLEEP_EN_MMU3_MASK | \
      MP2_DFP_PGRAM_MMU3_CNTL_MEM_DEEP_SLEEP_STATUS_MMU3_MASK | \
      MP2_DFP_PGRAM_MMU3_CNTL_MEM_LIGHT_SLEEP_EN_MMU3_MASK | \
      MP2_DFP_PGRAM_MMU3_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU3_MASK | \
      MP2_DFP_PGRAM_MMU3_CNTL_PGFSM_MEM_SDDS_EN_MMU3_MASK | \
      MP2_DFP_PGRAM_MMU3_CNTL_PGFSM_MEM_SDDS_MODE_MMU3_MASK | \
      MP2_DFP_PGRAM_MMU3_CNTL_MEM_SLEEP_TIMEOUT_MMU3_MASK | \
      MP2_DFP_PGRAM_MMU3_CNTL_MEM_PG_DLY_MMU3_MASK)

#define MP2_DFP_PGRAM_MMU3_CNTL_DEFAULT 0x0010102a

#define MP2_DFP_PGRAM_MMU3_CNTL_GET_MEM_SD_MMU3(mp2_dfp_pgram_mmu3_cntl) \
     ((mp2_dfp_pgram_mmu3_cntl & MP2_DFP_PGRAM_MMU3_CNTL_MEM_SD_MMU3_MASK) >> MP2_DFP_PGRAM_MMU3_CNTL_MEM_SD_MMU3_SHIFT)
#define MP2_DFP_PGRAM_MMU3_CNTL_GET_MEM_ROP_MMU3(mp2_dfp_pgram_mmu3_cntl) \
     ((mp2_dfp_pgram_mmu3_cntl & MP2_DFP_PGRAM_MMU3_CNTL_MEM_ROP_MMU3_MASK) >> MP2_DFP_PGRAM_MMU3_CNTL_MEM_ROP_MMU3_SHIFT)
#define MP2_DFP_PGRAM_MMU3_CNTL_GET_MEM_DEEP_SLEEP_EN_MMU3(mp2_dfp_pgram_mmu3_cntl) \
     ((mp2_dfp_pgram_mmu3_cntl & MP2_DFP_PGRAM_MMU3_CNTL_MEM_DEEP_SLEEP_EN_MMU3_MASK) >> MP2_DFP_PGRAM_MMU3_CNTL_MEM_DEEP_SLEEP_EN_MMU3_SHIFT)
#define MP2_DFP_PGRAM_MMU3_CNTL_GET_MEM_DEEP_SLEEP_STATUS_MMU3(mp2_dfp_pgram_mmu3_cntl) \
     ((mp2_dfp_pgram_mmu3_cntl & MP2_DFP_PGRAM_MMU3_CNTL_MEM_DEEP_SLEEP_STATUS_MMU3_MASK) >> MP2_DFP_PGRAM_MMU3_CNTL_MEM_DEEP_SLEEP_STATUS_MMU3_SHIFT)
#define MP2_DFP_PGRAM_MMU3_CNTL_GET_MEM_LIGHT_SLEEP_EN_MMU3(mp2_dfp_pgram_mmu3_cntl) \
     ((mp2_dfp_pgram_mmu3_cntl & MP2_DFP_PGRAM_MMU3_CNTL_MEM_LIGHT_SLEEP_EN_MMU3_MASK) >> MP2_DFP_PGRAM_MMU3_CNTL_MEM_LIGHT_SLEEP_EN_MMU3_SHIFT)
#define MP2_DFP_PGRAM_MMU3_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_MMU3(mp2_dfp_pgram_mmu3_cntl) \
     ((mp2_dfp_pgram_mmu3_cntl & MP2_DFP_PGRAM_MMU3_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU3_MASK) >> MP2_DFP_PGRAM_MMU3_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU3_SHIFT)
#define MP2_DFP_PGRAM_MMU3_CNTL_GET_PGFSM_MEM_SDDS_EN_MMU3(mp2_dfp_pgram_mmu3_cntl) \
     ((mp2_dfp_pgram_mmu3_cntl & MP2_DFP_PGRAM_MMU3_CNTL_PGFSM_MEM_SDDS_EN_MMU3_MASK) >> MP2_DFP_PGRAM_MMU3_CNTL_PGFSM_MEM_SDDS_EN_MMU3_SHIFT)
#define MP2_DFP_PGRAM_MMU3_CNTL_GET_PGFSM_MEM_SDDS_MODE_MMU3(mp2_dfp_pgram_mmu3_cntl) \
     ((mp2_dfp_pgram_mmu3_cntl & MP2_DFP_PGRAM_MMU3_CNTL_PGFSM_MEM_SDDS_MODE_MMU3_MASK) >> MP2_DFP_PGRAM_MMU3_CNTL_PGFSM_MEM_SDDS_MODE_MMU3_SHIFT)
#define MP2_DFP_PGRAM_MMU3_CNTL_GET_MEM_SLEEP_TIMEOUT_MMU3(mp2_dfp_pgram_mmu3_cntl) \
     ((mp2_dfp_pgram_mmu3_cntl & MP2_DFP_PGRAM_MMU3_CNTL_MEM_SLEEP_TIMEOUT_MMU3_MASK) >> MP2_DFP_PGRAM_MMU3_CNTL_MEM_SLEEP_TIMEOUT_MMU3_SHIFT)
#define MP2_DFP_PGRAM_MMU3_CNTL_GET_MEM_PG_DLY_MMU3(mp2_dfp_pgram_mmu3_cntl) \
     ((mp2_dfp_pgram_mmu3_cntl & MP2_DFP_PGRAM_MMU3_CNTL_MEM_PG_DLY_MMU3_MASK) >> MP2_DFP_PGRAM_MMU3_CNTL_MEM_PG_DLY_MMU3_SHIFT)

#define MP2_DFP_PGRAM_MMU3_CNTL_SET_MEM_SD_MMU3(mp2_dfp_pgram_mmu3_cntl_reg, mem_sd_mmu3) \
     mp2_dfp_pgram_mmu3_cntl_reg = (mp2_dfp_pgram_mmu3_cntl_reg & ~MP2_DFP_PGRAM_MMU3_CNTL_MEM_SD_MMU3_MASK) | (mem_sd_mmu3 << MP2_DFP_PGRAM_MMU3_CNTL_MEM_SD_MMU3_SHIFT)
#define MP2_DFP_PGRAM_MMU3_CNTL_SET_MEM_ROP_MMU3(mp2_dfp_pgram_mmu3_cntl_reg, mem_rop_mmu3) \
     mp2_dfp_pgram_mmu3_cntl_reg = (mp2_dfp_pgram_mmu3_cntl_reg & ~MP2_DFP_PGRAM_MMU3_CNTL_MEM_ROP_MMU3_MASK) | (mem_rop_mmu3 << MP2_DFP_PGRAM_MMU3_CNTL_MEM_ROP_MMU3_SHIFT)
#define MP2_DFP_PGRAM_MMU3_CNTL_SET_MEM_DEEP_SLEEP_EN_MMU3(mp2_dfp_pgram_mmu3_cntl_reg, mem_deep_sleep_en_mmu3) \
     mp2_dfp_pgram_mmu3_cntl_reg = (mp2_dfp_pgram_mmu3_cntl_reg & ~MP2_DFP_PGRAM_MMU3_CNTL_MEM_DEEP_SLEEP_EN_MMU3_MASK) | (mem_deep_sleep_en_mmu3 << MP2_DFP_PGRAM_MMU3_CNTL_MEM_DEEP_SLEEP_EN_MMU3_SHIFT)
#define MP2_DFP_PGRAM_MMU3_CNTL_SET_MEM_DEEP_SLEEP_STATUS_MMU3(mp2_dfp_pgram_mmu3_cntl_reg, mem_deep_sleep_status_mmu3) \
     mp2_dfp_pgram_mmu3_cntl_reg = (mp2_dfp_pgram_mmu3_cntl_reg & ~MP2_DFP_PGRAM_MMU3_CNTL_MEM_DEEP_SLEEP_STATUS_MMU3_MASK) | (mem_deep_sleep_status_mmu3 << MP2_DFP_PGRAM_MMU3_CNTL_MEM_DEEP_SLEEP_STATUS_MMU3_SHIFT)
#define MP2_DFP_PGRAM_MMU3_CNTL_SET_MEM_LIGHT_SLEEP_EN_MMU3(mp2_dfp_pgram_mmu3_cntl_reg, mem_light_sleep_en_mmu3) \
     mp2_dfp_pgram_mmu3_cntl_reg = (mp2_dfp_pgram_mmu3_cntl_reg & ~MP2_DFP_PGRAM_MMU3_CNTL_MEM_LIGHT_SLEEP_EN_MMU3_MASK) | (mem_light_sleep_en_mmu3 << MP2_DFP_PGRAM_MMU3_CNTL_MEM_LIGHT_SLEEP_EN_MMU3_SHIFT)
#define MP2_DFP_PGRAM_MMU3_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_MMU3(mp2_dfp_pgram_mmu3_cntl_reg, mem_light_sleep_status_mmu3) \
     mp2_dfp_pgram_mmu3_cntl_reg = (mp2_dfp_pgram_mmu3_cntl_reg & ~MP2_DFP_PGRAM_MMU3_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU3_MASK) | (mem_light_sleep_status_mmu3 << MP2_DFP_PGRAM_MMU3_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU3_SHIFT)
#define MP2_DFP_PGRAM_MMU3_CNTL_SET_PGFSM_MEM_SDDS_EN_MMU3(mp2_dfp_pgram_mmu3_cntl_reg, pgfsm_mem_sdds_en_mmu3) \
     mp2_dfp_pgram_mmu3_cntl_reg = (mp2_dfp_pgram_mmu3_cntl_reg & ~MP2_DFP_PGRAM_MMU3_CNTL_PGFSM_MEM_SDDS_EN_MMU3_MASK) | (pgfsm_mem_sdds_en_mmu3 << MP2_DFP_PGRAM_MMU3_CNTL_PGFSM_MEM_SDDS_EN_MMU3_SHIFT)
#define MP2_DFP_PGRAM_MMU3_CNTL_SET_PGFSM_MEM_SDDS_MODE_MMU3(mp2_dfp_pgram_mmu3_cntl_reg, pgfsm_mem_sdds_mode_mmu3) \
     mp2_dfp_pgram_mmu3_cntl_reg = (mp2_dfp_pgram_mmu3_cntl_reg & ~MP2_DFP_PGRAM_MMU3_CNTL_PGFSM_MEM_SDDS_MODE_MMU3_MASK) | (pgfsm_mem_sdds_mode_mmu3 << MP2_DFP_PGRAM_MMU3_CNTL_PGFSM_MEM_SDDS_MODE_MMU3_SHIFT)
#define MP2_DFP_PGRAM_MMU3_CNTL_SET_MEM_SLEEP_TIMEOUT_MMU3(mp2_dfp_pgram_mmu3_cntl_reg, mem_sleep_timeout_mmu3) \
     mp2_dfp_pgram_mmu3_cntl_reg = (mp2_dfp_pgram_mmu3_cntl_reg & ~MP2_DFP_PGRAM_MMU3_CNTL_MEM_SLEEP_TIMEOUT_MMU3_MASK) | (mem_sleep_timeout_mmu3 << MP2_DFP_PGRAM_MMU3_CNTL_MEM_SLEEP_TIMEOUT_MMU3_SHIFT)
#define MP2_DFP_PGRAM_MMU3_CNTL_SET_MEM_PG_DLY_MMU3(mp2_dfp_pgram_mmu3_cntl_reg, mem_pg_dly_mmu3) \
     mp2_dfp_pgram_mmu3_cntl_reg = (mp2_dfp_pgram_mmu3_cntl_reg & ~MP2_DFP_PGRAM_MMU3_CNTL_MEM_PG_DLY_MMU3_MASK) | (mem_pg_dly_mmu3 << MP2_DFP_PGRAM_MMU3_CNTL_MEM_PG_DLY_MMU3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfp_pgram_mmu3_cntl_t {
          unsigned int mem_sd_mmu3                    : MP2_DFP_PGRAM_MMU3_CNTL_MEM_SD_MMU3_SIZE;
          unsigned int mem_rop_mmu3                   : MP2_DFP_PGRAM_MMU3_CNTL_MEM_ROP_MMU3_SIZE;
          unsigned int mem_deep_sleep_en_mmu3         : MP2_DFP_PGRAM_MMU3_CNTL_MEM_DEEP_SLEEP_EN_MMU3_SIZE;
          unsigned int mem_deep_sleep_status_mmu3     : MP2_DFP_PGRAM_MMU3_CNTL_MEM_DEEP_SLEEP_STATUS_MMU3_SIZE;
          unsigned int mem_light_sleep_en_mmu3        : MP2_DFP_PGRAM_MMU3_CNTL_MEM_LIGHT_SLEEP_EN_MMU3_SIZE;
          unsigned int mem_light_sleep_status_mmu3    : MP2_DFP_PGRAM_MMU3_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU3_SIZE;
          unsigned int pgfsm_mem_sdds_en_mmu3         : MP2_DFP_PGRAM_MMU3_CNTL_PGFSM_MEM_SDDS_EN_MMU3_SIZE;
          unsigned int pgfsm_mem_sdds_mode_mmu3       : MP2_DFP_PGRAM_MMU3_CNTL_PGFSM_MEM_SDDS_MODE_MMU3_SIZE;
          unsigned int mem_sleep_timeout_mmu3         : MP2_DFP_PGRAM_MMU3_CNTL_MEM_SLEEP_TIMEOUT_MMU3_SIZE;
          unsigned int mem_pg_dly_mmu3                : MP2_DFP_PGRAM_MMU3_CNTL_MEM_PG_DLY_MMU3_SIZE;
          unsigned int                                : 8;
     } mp2_dfp_pgram_mmu3_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfp_pgram_mmu3_cntl_t {
          unsigned int                                : 8;
          unsigned int mem_pg_dly_mmu3                : MP2_DFP_PGRAM_MMU3_CNTL_MEM_PG_DLY_MMU3_SIZE;
          unsigned int mem_sleep_timeout_mmu3         : MP2_DFP_PGRAM_MMU3_CNTL_MEM_SLEEP_TIMEOUT_MMU3_SIZE;
          unsigned int pgfsm_mem_sdds_mode_mmu3       : MP2_DFP_PGRAM_MMU3_CNTL_PGFSM_MEM_SDDS_MODE_MMU3_SIZE;
          unsigned int pgfsm_mem_sdds_en_mmu3         : MP2_DFP_PGRAM_MMU3_CNTL_PGFSM_MEM_SDDS_EN_MMU3_SIZE;
          unsigned int mem_light_sleep_status_mmu3    : MP2_DFP_PGRAM_MMU3_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU3_SIZE;
          unsigned int mem_light_sleep_en_mmu3        : MP2_DFP_PGRAM_MMU3_CNTL_MEM_LIGHT_SLEEP_EN_MMU3_SIZE;
          unsigned int mem_deep_sleep_status_mmu3     : MP2_DFP_PGRAM_MMU3_CNTL_MEM_DEEP_SLEEP_STATUS_MMU3_SIZE;
          unsigned int mem_deep_sleep_en_mmu3         : MP2_DFP_PGRAM_MMU3_CNTL_MEM_DEEP_SLEEP_EN_MMU3_SIZE;
          unsigned int mem_rop_mmu3                   : MP2_DFP_PGRAM_MMU3_CNTL_MEM_ROP_MMU3_SIZE;
          unsigned int mem_sd_mmu3                    : MP2_DFP_PGRAM_MMU3_CNTL_MEM_SD_MMU3_SIZE;
     } mp2_dfp_pgram_mmu3_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfp_pgram_mmu3_cntl_t f;
} mp2_dfp_pgram_mmu3_cntl_u;


/*
 * MP2_DFP_PGRAM_I3C_CNTL struct
 */

#define MP2_DFP_PGRAM_I3C_CNTL_REG_SIZE 32
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_SD_I3C_SIZE 1
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_ROP_I3C_SIZE 1
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_DEEP_SLEEP_EN_I3C_SIZE 1
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_DEEP_SLEEP_STATUS_I3C_SIZE 1
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_LIGHT_SLEEP_EN_I3C_SIZE 1
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_LIGHT_SLEEP_STATUS_I3C_SIZE 1
#define MP2_DFP_PGRAM_I3C_CNTL_PGFSM_MEM_SDDS_EN_I3C_SIZE 1
#define MP2_DFP_PGRAM_I3C_CNTL_PGFSM_MEM_SDDS_MODE_I3C_SIZE 1
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_SLEEP_TIMEOUT_I3C_SIZE 8
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_PG_DLY_I3C_SIZE 8

#define MP2_DFP_PGRAM_I3C_CNTL_MEM_SD_I3C_SHIFT 0
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_ROP_I3C_SHIFT 1
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_DEEP_SLEEP_EN_I3C_SHIFT 2
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_DEEP_SLEEP_STATUS_I3C_SHIFT 3
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_LIGHT_SLEEP_EN_I3C_SHIFT 4
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_LIGHT_SLEEP_STATUS_I3C_SHIFT 5
#define MP2_DFP_PGRAM_I3C_CNTL_PGFSM_MEM_SDDS_EN_I3C_SHIFT 6
#define MP2_DFP_PGRAM_I3C_CNTL_PGFSM_MEM_SDDS_MODE_I3C_SHIFT 7
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_SLEEP_TIMEOUT_I3C_SHIFT 8
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_PG_DLY_I3C_SHIFT 16

#define MP2_DFP_PGRAM_I3C_CNTL_MEM_SD_I3C_MASK 0x1
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_ROP_I3C_MASK 0x2
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_DEEP_SLEEP_EN_I3C_MASK 0x4
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_DEEP_SLEEP_STATUS_I3C_MASK 0x8
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_LIGHT_SLEEP_EN_I3C_MASK 0x10
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_LIGHT_SLEEP_STATUS_I3C_MASK 0x20
#define MP2_DFP_PGRAM_I3C_CNTL_PGFSM_MEM_SDDS_EN_I3C_MASK 0x40
#define MP2_DFP_PGRAM_I3C_CNTL_PGFSM_MEM_SDDS_MODE_I3C_MASK 0x80
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_SLEEP_TIMEOUT_I3C_MASK 0xff00
#define MP2_DFP_PGRAM_I3C_CNTL_MEM_PG_DLY_I3C_MASK 0xff0000

#define MP2_DFP_PGRAM_I3C_CNTL_MASK \
     (MP2_DFP_PGRAM_I3C_CNTL_MEM_SD_I3C_MASK | \
      MP2_DFP_PGRAM_I3C_CNTL_MEM_ROP_I3C_MASK | \
      MP2_DFP_PGRAM_I3C_CNTL_MEM_DEEP_SLEEP_EN_I3C_MASK | \
      MP2_DFP_PGRAM_I3C_CNTL_MEM_DEEP_SLEEP_STATUS_I3C_MASK | \
      MP2_DFP_PGRAM_I3C_CNTL_MEM_LIGHT_SLEEP_EN_I3C_MASK | \
      MP2_DFP_PGRAM_I3C_CNTL_MEM_LIGHT_SLEEP_STATUS_I3C_MASK | \
      MP2_DFP_PGRAM_I3C_CNTL_PGFSM_MEM_SDDS_EN_I3C_MASK | \
      MP2_DFP_PGRAM_I3C_CNTL_PGFSM_MEM_SDDS_MODE_I3C_MASK | \
      MP2_DFP_PGRAM_I3C_CNTL_MEM_SLEEP_TIMEOUT_I3C_MASK | \
      MP2_DFP_PGRAM_I3C_CNTL_MEM_PG_DLY_I3C_MASK)

#define MP2_DFP_PGRAM_I3C_CNTL_DEFAULT 0x0010102a

#define MP2_DFP_PGRAM_I3C_CNTL_GET_MEM_SD_I3C(mp2_dfp_pgram_i3c_cntl) \
     ((mp2_dfp_pgram_i3c_cntl & MP2_DFP_PGRAM_I3C_CNTL_MEM_SD_I3C_MASK) >> MP2_DFP_PGRAM_I3C_CNTL_MEM_SD_I3C_SHIFT)
#define MP2_DFP_PGRAM_I3C_CNTL_GET_MEM_ROP_I3C(mp2_dfp_pgram_i3c_cntl) \
     ((mp2_dfp_pgram_i3c_cntl & MP2_DFP_PGRAM_I3C_CNTL_MEM_ROP_I3C_MASK) >> MP2_DFP_PGRAM_I3C_CNTL_MEM_ROP_I3C_SHIFT)
#define MP2_DFP_PGRAM_I3C_CNTL_GET_MEM_DEEP_SLEEP_EN_I3C(mp2_dfp_pgram_i3c_cntl) \
     ((mp2_dfp_pgram_i3c_cntl & MP2_DFP_PGRAM_I3C_CNTL_MEM_DEEP_SLEEP_EN_I3C_MASK) >> MP2_DFP_PGRAM_I3C_CNTL_MEM_DEEP_SLEEP_EN_I3C_SHIFT)
#define MP2_DFP_PGRAM_I3C_CNTL_GET_MEM_DEEP_SLEEP_STATUS_I3C(mp2_dfp_pgram_i3c_cntl) \
     ((mp2_dfp_pgram_i3c_cntl & MP2_DFP_PGRAM_I3C_CNTL_MEM_DEEP_SLEEP_STATUS_I3C_MASK) >> MP2_DFP_PGRAM_I3C_CNTL_MEM_DEEP_SLEEP_STATUS_I3C_SHIFT)
#define MP2_DFP_PGRAM_I3C_CNTL_GET_MEM_LIGHT_SLEEP_EN_I3C(mp2_dfp_pgram_i3c_cntl) \
     ((mp2_dfp_pgram_i3c_cntl & MP2_DFP_PGRAM_I3C_CNTL_MEM_LIGHT_SLEEP_EN_I3C_MASK) >> MP2_DFP_PGRAM_I3C_CNTL_MEM_LIGHT_SLEEP_EN_I3C_SHIFT)
#define MP2_DFP_PGRAM_I3C_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_I3C(mp2_dfp_pgram_i3c_cntl) \
     ((mp2_dfp_pgram_i3c_cntl & MP2_DFP_PGRAM_I3C_CNTL_MEM_LIGHT_SLEEP_STATUS_I3C_MASK) >> MP2_DFP_PGRAM_I3C_CNTL_MEM_LIGHT_SLEEP_STATUS_I3C_SHIFT)
#define MP2_DFP_PGRAM_I3C_CNTL_GET_PGFSM_MEM_SDDS_EN_I3C(mp2_dfp_pgram_i3c_cntl) \
     ((mp2_dfp_pgram_i3c_cntl & MP2_DFP_PGRAM_I3C_CNTL_PGFSM_MEM_SDDS_EN_I3C_MASK) >> MP2_DFP_PGRAM_I3C_CNTL_PGFSM_MEM_SDDS_EN_I3C_SHIFT)
#define MP2_DFP_PGRAM_I3C_CNTL_GET_PGFSM_MEM_SDDS_MODE_I3C(mp2_dfp_pgram_i3c_cntl) \
     ((mp2_dfp_pgram_i3c_cntl & MP2_DFP_PGRAM_I3C_CNTL_PGFSM_MEM_SDDS_MODE_I3C_MASK) >> MP2_DFP_PGRAM_I3C_CNTL_PGFSM_MEM_SDDS_MODE_I3C_SHIFT)
#define MP2_DFP_PGRAM_I3C_CNTL_GET_MEM_SLEEP_TIMEOUT_I3C(mp2_dfp_pgram_i3c_cntl) \
     ((mp2_dfp_pgram_i3c_cntl & MP2_DFP_PGRAM_I3C_CNTL_MEM_SLEEP_TIMEOUT_I3C_MASK) >> MP2_DFP_PGRAM_I3C_CNTL_MEM_SLEEP_TIMEOUT_I3C_SHIFT)
#define MP2_DFP_PGRAM_I3C_CNTL_GET_MEM_PG_DLY_I3C(mp2_dfp_pgram_i3c_cntl) \
     ((mp2_dfp_pgram_i3c_cntl & MP2_DFP_PGRAM_I3C_CNTL_MEM_PG_DLY_I3C_MASK) >> MP2_DFP_PGRAM_I3C_CNTL_MEM_PG_DLY_I3C_SHIFT)

#define MP2_DFP_PGRAM_I3C_CNTL_SET_MEM_SD_I3C(mp2_dfp_pgram_i3c_cntl_reg, mem_sd_i3c) \
     mp2_dfp_pgram_i3c_cntl_reg = (mp2_dfp_pgram_i3c_cntl_reg & ~MP2_DFP_PGRAM_I3C_CNTL_MEM_SD_I3C_MASK) | (mem_sd_i3c << MP2_DFP_PGRAM_I3C_CNTL_MEM_SD_I3C_SHIFT)
#define MP2_DFP_PGRAM_I3C_CNTL_SET_MEM_ROP_I3C(mp2_dfp_pgram_i3c_cntl_reg, mem_rop_i3c) \
     mp2_dfp_pgram_i3c_cntl_reg = (mp2_dfp_pgram_i3c_cntl_reg & ~MP2_DFP_PGRAM_I3C_CNTL_MEM_ROP_I3C_MASK) | (mem_rop_i3c << MP2_DFP_PGRAM_I3C_CNTL_MEM_ROP_I3C_SHIFT)
#define MP2_DFP_PGRAM_I3C_CNTL_SET_MEM_DEEP_SLEEP_EN_I3C(mp2_dfp_pgram_i3c_cntl_reg, mem_deep_sleep_en_i3c) \
     mp2_dfp_pgram_i3c_cntl_reg = (mp2_dfp_pgram_i3c_cntl_reg & ~MP2_DFP_PGRAM_I3C_CNTL_MEM_DEEP_SLEEP_EN_I3C_MASK) | (mem_deep_sleep_en_i3c << MP2_DFP_PGRAM_I3C_CNTL_MEM_DEEP_SLEEP_EN_I3C_SHIFT)
#define MP2_DFP_PGRAM_I3C_CNTL_SET_MEM_DEEP_SLEEP_STATUS_I3C(mp2_dfp_pgram_i3c_cntl_reg, mem_deep_sleep_status_i3c) \
     mp2_dfp_pgram_i3c_cntl_reg = (mp2_dfp_pgram_i3c_cntl_reg & ~MP2_DFP_PGRAM_I3C_CNTL_MEM_DEEP_SLEEP_STATUS_I3C_MASK) | (mem_deep_sleep_status_i3c << MP2_DFP_PGRAM_I3C_CNTL_MEM_DEEP_SLEEP_STATUS_I3C_SHIFT)
#define MP2_DFP_PGRAM_I3C_CNTL_SET_MEM_LIGHT_SLEEP_EN_I3C(mp2_dfp_pgram_i3c_cntl_reg, mem_light_sleep_en_i3c) \
     mp2_dfp_pgram_i3c_cntl_reg = (mp2_dfp_pgram_i3c_cntl_reg & ~MP2_DFP_PGRAM_I3C_CNTL_MEM_LIGHT_SLEEP_EN_I3C_MASK) | (mem_light_sleep_en_i3c << MP2_DFP_PGRAM_I3C_CNTL_MEM_LIGHT_SLEEP_EN_I3C_SHIFT)
#define MP2_DFP_PGRAM_I3C_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_I3C(mp2_dfp_pgram_i3c_cntl_reg, mem_light_sleep_status_i3c) \
     mp2_dfp_pgram_i3c_cntl_reg = (mp2_dfp_pgram_i3c_cntl_reg & ~MP2_DFP_PGRAM_I3C_CNTL_MEM_LIGHT_SLEEP_STATUS_I3C_MASK) | (mem_light_sleep_status_i3c << MP2_DFP_PGRAM_I3C_CNTL_MEM_LIGHT_SLEEP_STATUS_I3C_SHIFT)
#define MP2_DFP_PGRAM_I3C_CNTL_SET_PGFSM_MEM_SDDS_EN_I3C(mp2_dfp_pgram_i3c_cntl_reg, pgfsm_mem_sdds_en_i3c) \
     mp2_dfp_pgram_i3c_cntl_reg = (mp2_dfp_pgram_i3c_cntl_reg & ~MP2_DFP_PGRAM_I3C_CNTL_PGFSM_MEM_SDDS_EN_I3C_MASK) | (pgfsm_mem_sdds_en_i3c << MP2_DFP_PGRAM_I3C_CNTL_PGFSM_MEM_SDDS_EN_I3C_SHIFT)
#define MP2_DFP_PGRAM_I3C_CNTL_SET_PGFSM_MEM_SDDS_MODE_I3C(mp2_dfp_pgram_i3c_cntl_reg, pgfsm_mem_sdds_mode_i3c) \
     mp2_dfp_pgram_i3c_cntl_reg = (mp2_dfp_pgram_i3c_cntl_reg & ~MP2_DFP_PGRAM_I3C_CNTL_PGFSM_MEM_SDDS_MODE_I3C_MASK) | (pgfsm_mem_sdds_mode_i3c << MP2_DFP_PGRAM_I3C_CNTL_PGFSM_MEM_SDDS_MODE_I3C_SHIFT)
#define MP2_DFP_PGRAM_I3C_CNTL_SET_MEM_SLEEP_TIMEOUT_I3C(mp2_dfp_pgram_i3c_cntl_reg, mem_sleep_timeout_i3c) \
     mp2_dfp_pgram_i3c_cntl_reg = (mp2_dfp_pgram_i3c_cntl_reg & ~MP2_DFP_PGRAM_I3C_CNTL_MEM_SLEEP_TIMEOUT_I3C_MASK) | (mem_sleep_timeout_i3c << MP2_DFP_PGRAM_I3C_CNTL_MEM_SLEEP_TIMEOUT_I3C_SHIFT)
#define MP2_DFP_PGRAM_I3C_CNTL_SET_MEM_PG_DLY_I3C(mp2_dfp_pgram_i3c_cntl_reg, mem_pg_dly_i3c) \
     mp2_dfp_pgram_i3c_cntl_reg = (mp2_dfp_pgram_i3c_cntl_reg & ~MP2_DFP_PGRAM_I3C_CNTL_MEM_PG_DLY_I3C_MASK) | (mem_pg_dly_i3c << MP2_DFP_PGRAM_I3C_CNTL_MEM_PG_DLY_I3C_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfp_pgram_i3c_cntl_t {
          unsigned int mem_sd_i3c                     : MP2_DFP_PGRAM_I3C_CNTL_MEM_SD_I3C_SIZE;
          unsigned int mem_rop_i3c                    : MP2_DFP_PGRAM_I3C_CNTL_MEM_ROP_I3C_SIZE;
          unsigned int mem_deep_sleep_en_i3c          : MP2_DFP_PGRAM_I3C_CNTL_MEM_DEEP_SLEEP_EN_I3C_SIZE;
          unsigned int mem_deep_sleep_status_i3c      : MP2_DFP_PGRAM_I3C_CNTL_MEM_DEEP_SLEEP_STATUS_I3C_SIZE;
          unsigned int mem_light_sleep_en_i3c         : MP2_DFP_PGRAM_I3C_CNTL_MEM_LIGHT_SLEEP_EN_I3C_SIZE;
          unsigned int mem_light_sleep_status_i3c     : MP2_DFP_PGRAM_I3C_CNTL_MEM_LIGHT_SLEEP_STATUS_I3C_SIZE;
          unsigned int pgfsm_mem_sdds_en_i3c          : MP2_DFP_PGRAM_I3C_CNTL_PGFSM_MEM_SDDS_EN_I3C_SIZE;
          unsigned int pgfsm_mem_sdds_mode_i3c        : MP2_DFP_PGRAM_I3C_CNTL_PGFSM_MEM_SDDS_MODE_I3C_SIZE;
          unsigned int mem_sleep_timeout_i3c          : MP2_DFP_PGRAM_I3C_CNTL_MEM_SLEEP_TIMEOUT_I3C_SIZE;
          unsigned int mem_pg_dly_i3c                 : MP2_DFP_PGRAM_I3C_CNTL_MEM_PG_DLY_I3C_SIZE;
          unsigned int                                : 8;
     } mp2_dfp_pgram_i3c_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfp_pgram_i3c_cntl_t {
          unsigned int                                : 8;
          unsigned int mem_pg_dly_i3c                 : MP2_DFP_PGRAM_I3C_CNTL_MEM_PG_DLY_I3C_SIZE;
          unsigned int mem_sleep_timeout_i3c          : MP2_DFP_PGRAM_I3C_CNTL_MEM_SLEEP_TIMEOUT_I3C_SIZE;
          unsigned int pgfsm_mem_sdds_mode_i3c        : MP2_DFP_PGRAM_I3C_CNTL_PGFSM_MEM_SDDS_MODE_I3C_SIZE;
          unsigned int pgfsm_mem_sdds_en_i3c          : MP2_DFP_PGRAM_I3C_CNTL_PGFSM_MEM_SDDS_EN_I3C_SIZE;
          unsigned int mem_light_sleep_status_i3c     : MP2_DFP_PGRAM_I3C_CNTL_MEM_LIGHT_SLEEP_STATUS_I3C_SIZE;
          unsigned int mem_light_sleep_en_i3c         : MP2_DFP_PGRAM_I3C_CNTL_MEM_LIGHT_SLEEP_EN_I3C_SIZE;
          unsigned int mem_deep_sleep_status_i3c      : MP2_DFP_PGRAM_I3C_CNTL_MEM_DEEP_SLEEP_STATUS_I3C_SIZE;
          unsigned int mem_deep_sleep_en_i3c          : MP2_DFP_PGRAM_I3C_CNTL_MEM_DEEP_SLEEP_EN_I3C_SIZE;
          unsigned int mem_rop_i3c                    : MP2_DFP_PGRAM_I3C_CNTL_MEM_ROP_I3C_SIZE;
          unsigned int mem_sd_i3c                     : MP2_DFP_PGRAM_I3C_CNTL_MEM_SD_I3C_SIZE;
     } mp2_dfp_pgram_i3c_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfp_pgram_i3c_cntl_t f;
} mp2_dfp_pgram_i3c_cntl_u;


/*
 * MP2_DFP_MPCLKDS_CTRL struct
 */

#define MP2_DFP_MPCLKDS_CTRL_REG_SIZE  32
#define MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SIZE 1
#define MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SIZE 1
#define MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SIZE 8
#define MP2_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SIZE 1
#define MP2_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SIZE 1
#define MP2_DFP_MPCLKDS_CTRL_MPCLK_PGFSM_WAKE_MASK_SIZE 1

#define MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SHIFT 0
#define MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SHIFT 1
#define MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SHIFT 2
#define MP2_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SHIFT 10
#define MP2_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SHIFT 11
#define MP2_DFP_MPCLKDS_CTRL_MPCLK_PGFSM_WAKE_MASK_SHIFT 12

#define MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_MASK 0x1
#define MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_MASK 0x2
#define MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_MASK 0x3fc
#define MP2_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_MASK 0x400
#define MP2_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_MASK 0x800
#define MP2_DFP_MPCLKDS_CTRL_MPCLK_PGFSM_WAKE_MASK_MASK 0x1000

#define MP2_DFP_MPCLKDS_CTRL_MASK \
     (MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_MASK | \
      MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_MASK | \
      MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_MASK | \
      MP2_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_MASK | \
      MP2_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_MASK | \
      MP2_DFP_MPCLKDS_CTRL_MPCLK_PGFSM_WAKE_MASK_MASK)

#define MP2_DFP_MPCLKDS_CTRL_DEFAULT   0x00001ffc

#define MP2_DFP_MPCLKDS_CTRL_GET_MPCLK_DS_ENB(mp2_dfp_mpclkds_ctrl) \
     ((mp2_dfp_mpclkds_ctrl & MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_MASK) >> MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SHIFT)
#define MP2_DFP_MPCLKDS_CTRL_GET_MPCLK_DS_STATUS(mp2_dfp_mpclkds_ctrl) \
     ((mp2_dfp_mpclkds_ctrl & MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_MASK) >> MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SHIFT)
#define MP2_DFP_MPCLKDS_CTRL_GET_MPCLK_DS_TIMEOUT(mp2_dfp_mpclkds_ctrl) \
     ((mp2_dfp_mpclkds_ctrl & MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_MASK) >> MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SHIFT)
#define MP2_DFP_MPCLKDS_CTRL_GET_MPCLK_CPUINTR_WAKE_MASK(mp2_dfp_mpclkds_ctrl) \
     ((mp2_dfp_mpclkds_ctrl & MP2_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_MASK) >> MP2_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SHIFT)
#define MP2_DFP_MPCLKDS_CTRL_GET_MPCLK_SMN_WAKE_MASK(mp2_dfp_mpclkds_ctrl) \
     ((mp2_dfp_mpclkds_ctrl & MP2_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_MASK) >> MP2_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SHIFT)
#define MP2_DFP_MPCLKDS_CTRL_GET_MPCLK_PGFSM_WAKE_MASK(mp2_dfp_mpclkds_ctrl) \
     ((mp2_dfp_mpclkds_ctrl & MP2_DFP_MPCLKDS_CTRL_MPCLK_PGFSM_WAKE_MASK_MASK) >> MP2_DFP_MPCLKDS_CTRL_MPCLK_PGFSM_WAKE_MASK_SHIFT)

#define MP2_DFP_MPCLKDS_CTRL_SET_MPCLK_DS_ENB(mp2_dfp_mpclkds_ctrl_reg, mpclk_ds_enb) \
     mp2_dfp_mpclkds_ctrl_reg = (mp2_dfp_mpclkds_ctrl_reg & ~MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_MASK) | (mpclk_ds_enb << MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SHIFT)
#define MP2_DFP_MPCLKDS_CTRL_SET_MPCLK_DS_STATUS(mp2_dfp_mpclkds_ctrl_reg, mpclk_ds_status) \
     mp2_dfp_mpclkds_ctrl_reg = (mp2_dfp_mpclkds_ctrl_reg & ~MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_MASK) | (mpclk_ds_status << MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SHIFT)
#define MP2_DFP_MPCLKDS_CTRL_SET_MPCLK_DS_TIMEOUT(mp2_dfp_mpclkds_ctrl_reg, mpclk_ds_timeout) \
     mp2_dfp_mpclkds_ctrl_reg = (mp2_dfp_mpclkds_ctrl_reg & ~MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_MASK) | (mpclk_ds_timeout << MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SHIFT)
#define MP2_DFP_MPCLKDS_CTRL_SET_MPCLK_CPUINTR_WAKE_MASK(mp2_dfp_mpclkds_ctrl_reg, mpclk_cpuintr_wake_mask) \
     mp2_dfp_mpclkds_ctrl_reg = (mp2_dfp_mpclkds_ctrl_reg & ~MP2_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_MASK) | (mpclk_cpuintr_wake_mask << MP2_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SHIFT)
#define MP2_DFP_MPCLKDS_CTRL_SET_MPCLK_SMN_WAKE_MASK(mp2_dfp_mpclkds_ctrl_reg, mpclk_smn_wake_mask) \
     mp2_dfp_mpclkds_ctrl_reg = (mp2_dfp_mpclkds_ctrl_reg & ~MP2_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_MASK) | (mpclk_smn_wake_mask << MP2_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SHIFT)
#define MP2_DFP_MPCLKDS_CTRL_SET_MPCLK_PGFSM_WAKE_MASK(mp2_dfp_mpclkds_ctrl_reg, mpclk_pgfsm_wake_mask) \
     mp2_dfp_mpclkds_ctrl_reg = (mp2_dfp_mpclkds_ctrl_reg & ~MP2_DFP_MPCLKDS_CTRL_MPCLK_PGFSM_WAKE_MASK_MASK) | (mpclk_pgfsm_wake_mask << MP2_DFP_MPCLKDS_CTRL_MPCLK_PGFSM_WAKE_MASK_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfp_mpclkds_ctrl_t {
          unsigned int mpclk_ds_enb                   : MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SIZE;
          unsigned int mpclk_ds_status                : MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SIZE;
          unsigned int mpclk_ds_timeout               : MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SIZE;
          unsigned int mpclk_cpuintr_wake_mask        : MP2_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SIZE;
          unsigned int mpclk_smn_wake_mask            : MP2_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SIZE;
          unsigned int mpclk_pgfsm_wake_mask          : MP2_DFP_MPCLKDS_CTRL_MPCLK_PGFSM_WAKE_MASK_SIZE;
          unsigned int                                : 19;
     } mp2_dfp_mpclkds_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfp_mpclkds_ctrl_t {
          unsigned int                                : 19;
          unsigned int mpclk_pgfsm_wake_mask          : MP2_DFP_MPCLKDS_CTRL_MPCLK_PGFSM_WAKE_MASK_SIZE;
          unsigned int mpclk_smn_wake_mask            : MP2_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SIZE;
          unsigned int mpclk_cpuintr_wake_mask        : MP2_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SIZE;
          unsigned int mpclk_ds_timeout               : MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SIZE;
          unsigned int mpclk_ds_status                : MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SIZE;
          unsigned int mpclk_ds_enb                   : MP2_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SIZE;
     } mp2_dfp_mpclkds_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfp_mpclkds_ctrl_t f;
} mp2_dfp_mpclkds_ctrl_u;


/*
 * MP2_CM4_WIC_CTRL struct
 */

#define MP2_CM4_WIC_CTRL_REG_SIZE      32
#define MP2_CM4_WIC_CTRL_M4_CG_EN_SIZE 1
#define MP2_CM4_WIC_CTRL_M4_CG_BYPASS_SIZE 1
#define MP2_CM4_WIC_CTRL_M4_WIC_EN_SIZE 1
#define MP2_CM4_WIC_CTRL_M4_SLEEPING_OVRD_SIZE 1
#define MP2_CM4_WIC_CTRL_M4_SLEEPDEEP_OVRD_SIZE 1
#define MP2_CM4_WIC_CTRL_M4_HOLD_EN_SIZE 1
#define MP2_CM4_WIC_CTRL_M4_WIC_STATUS_SIZE 2
#define MP2_CM4_WIC_CTRL_M4_INTISR_MASK_SIZE 1
#define MP2_CM4_WIC_CTRL_M4_INTNMI_MASK_SIZE 1
#define MP2_CM4_WIC_CTRL_M4_WIC_RESETn_SIZE 1

#define MP2_CM4_WIC_CTRL_M4_CG_EN_SHIFT 0
#define MP2_CM4_WIC_CTRL_M4_CG_BYPASS_SHIFT 1
#define MP2_CM4_WIC_CTRL_M4_WIC_EN_SHIFT 2
#define MP2_CM4_WIC_CTRL_M4_SLEEPING_OVRD_SHIFT 3
#define MP2_CM4_WIC_CTRL_M4_SLEEPDEEP_OVRD_SHIFT 4
#define MP2_CM4_WIC_CTRL_M4_HOLD_EN_SHIFT 5
#define MP2_CM4_WIC_CTRL_M4_WIC_STATUS_SHIFT 6
#define MP2_CM4_WIC_CTRL_M4_INTISR_MASK_SHIFT 8
#define MP2_CM4_WIC_CTRL_M4_INTNMI_MASK_SHIFT 9
#define MP2_CM4_WIC_CTRL_M4_WIC_RESETn_SHIFT 10

#define MP2_CM4_WIC_CTRL_M4_CG_EN_MASK 0x1
#define MP2_CM4_WIC_CTRL_M4_CG_BYPASS_MASK 0x2
#define MP2_CM4_WIC_CTRL_M4_WIC_EN_MASK 0x4
#define MP2_CM4_WIC_CTRL_M4_SLEEPING_OVRD_MASK 0x8
#define MP2_CM4_WIC_CTRL_M4_SLEEPDEEP_OVRD_MASK 0x10
#define MP2_CM4_WIC_CTRL_M4_HOLD_EN_MASK 0x20
#define MP2_CM4_WIC_CTRL_M4_WIC_STATUS_MASK 0xc0
#define MP2_CM4_WIC_CTRL_M4_INTISR_MASK_MASK 0x100
#define MP2_CM4_WIC_CTRL_M4_INTNMI_MASK_MASK 0x200
#define MP2_CM4_WIC_CTRL_M4_WIC_RESETn_MASK 0x400

#define MP2_CM4_WIC_CTRL_MASK \
     (MP2_CM4_WIC_CTRL_M4_CG_EN_MASK | \
      MP2_CM4_WIC_CTRL_M4_CG_BYPASS_MASK | \
      MP2_CM4_WIC_CTRL_M4_WIC_EN_MASK | \
      MP2_CM4_WIC_CTRL_M4_SLEEPING_OVRD_MASK | \
      MP2_CM4_WIC_CTRL_M4_SLEEPDEEP_OVRD_MASK | \
      MP2_CM4_WIC_CTRL_M4_HOLD_EN_MASK | \
      MP2_CM4_WIC_CTRL_M4_WIC_STATUS_MASK | \
      MP2_CM4_WIC_CTRL_M4_INTISR_MASK_MASK | \
      MP2_CM4_WIC_CTRL_M4_INTNMI_MASK_MASK | \
      MP2_CM4_WIC_CTRL_M4_WIC_RESETn_MASK)

#define MP2_CM4_WIC_CTRL_DEFAULT       0x00000020

#define MP2_CM4_WIC_CTRL_GET_M4_CG_EN(mp2_cm4_wic_ctrl) \
     ((mp2_cm4_wic_ctrl & MP2_CM4_WIC_CTRL_M4_CG_EN_MASK) >> MP2_CM4_WIC_CTRL_M4_CG_EN_SHIFT)
#define MP2_CM4_WIC_CTRL_GET_M4_CG_BYPASS(mp2_cm4_wic_ctrl) \
     ((mp2_cm4_wic_ctrl & MP2_CM4_WIC_CTRL_M4_CG_BYPASS_MASK) >> MP2_CM4_WIC_CTRL_M4_CG_BYPASS_SHIFT)
#define MP2_CM4_WIC_CTRL_GET_M4_WIC_EN(mp2_cm4_wic_ctrl) \
     ((mp2_cm4_wic_ctrl & MP2_CM4_WIC_CTRL_M4_WIC_EN_MASK) >> MP2_CM4_WIC_CTRL_M4_WIC_EN_SHIFT)
#define MP2_CM4_WIC_CTRL_GET_M4_SLEEPING_OVRD(mp2_cm4_wic_ctrl) \
     ((mp2_cm4_wic_ctrl & MP2_CM4_WIC_CTRL_M4_SLEEPING_OVRD_MASK) >> MP2_CM4_WIC_CTRL_M4_SLEEPING_OVRD_SHIFT)
#define MP2_CM4_WIC_CTRL_GET_M4_SLEEPDEEP_OVRD(mp2_cm4_wic_ctrl) \
     ((mp2_cm4_wic_ctrl & MP2_CM4_WIC_CTRL_M4_SLEEPDEEP_OVRD_MASK) >> MP2_CM4_WIC_CTRL_M4_SLEEPDEEP_OVRD_SHIFT)
#define MP2_CM4_WIC_CTRL_GET_M4_HOLD_EN(mp2_cm4_wic_ctrl) \
     ((mp2_cm4_wic_ctrl & MP2_CM4_WIC_CTRL_M4_HOLD_EN_MASK) >> MP2_CM4_WIC_CTRL_M4_HOLD_EN_SHIFT)
#define MP2_CM4_WIC_CTRL_GET_M4_WIC_STATUS(mp2_cm4_wic_ctrl) \
     ((mp2_cm4_wic_ctrl & MP2_CM4_WIC_CTRL_M4_WIC_STATUS_MASK) >> MP2_CM4_WIC_CTRL_M4_WIC_STATUS_SHIFT)
#define MP2_CM4_WIC_CTRL_GET_M4_INTISR_MASK(mp2_cm4_wic_ctrl) \
     ((mp2_cm4_wic_ctrl & MP2_CM4_WIC_CTRL_M4_INTISR_MASK_MASK) >> MP2_CM4_WIC_CTRL_M4_INTISR_MASK_SHIFT)
#define MP2_CM4_WIC_CTRL_GET_M4_INTNMI_MASK(mp2_cm4_wic_ctrl) \
     ((mp2_cm4_wic_ctrl & MP2_CM4_WIC_CTRL_M4_INTNMI_MASK_MASK) >> MP2_CM4_WIC_CTRL_M4_INTNMI_MASK_SHIFT)
#define MP2_CM4_WIC_CTRL_GET_M4_WIC_RESETn(mp2_cm4_wic_ctrl) \
     ((mp2_cm4_wic_ctrl & MP2_CM4_WIC_CTRL_M4_WIC_RESETn_MASK) >> MP2_CM4_WIC_CTRL_M4_WIC_RESETn_SHIFT)

#define MP2_CM4_WIC_CTRL_SET_M4_CG_EN(mp2_cm4_wic_ctrl_reg, m4_cg_en) \
     mp2_cm4_wic_ctrl_reg = (mp2_cm4_wic_ctrl_reg & ~MP2_CM4_WIC_CTRL_M4_CG_EN_MASK) | (m4_cg_en << MP2_CM4_WIC_CTRL_M4_CG_EN_SHIFT)
#define MP2_CM4_WIC_CTRL_SET_M4_CG_BYPASS(mp2_cm4_wic_ctrl_reg, m4_cg_bypass) \
     mp2_cm4_wic_ctrl_reg = (mp2_cm4_wic_ctrl_reg & ~MP2_CM4_WIC_CTRL_M4_CG_BYPASS_MASK) | (m4_cg_bypass << MP2_CM4_WIC_CTRL_M4_CG_BYPASS_SHIFT)
#define MP2_CM4_WIC_CTRL_SET_M4_WIC_EN(mp2_cm4_wic_ctrl_reg, m4_wic_en) \
     mp2_cm4_wic_ctrl_reg = (mp2_cm4_wic_ctrl_reg & ~MP2_CM4_WIC_CTRL_M4_WIC_EN_MASK) | (m4_wic_en << MP2_CM4_WIC_CTRL_M4_WIC_EN_SHIFT)
#define MP2_CM4_WIC_CTRL_SET_M4_SLEEPING_OVRD(mp2_cm4_wic_ctrl_reg, m4_sleeping_ovrd) \
     mp2_cm4_wic_ctrl_reg = (mp2_cm4_wic_ctrl_reg & ~MP2_CM4_WIC_CTRL_M4_SLEEPING_OVRD_MASK) | (m4_sleeping_ovrd << MP2_CM4_WIC_CTRL_M4_SLEEPING_OVRD_SHIFT)
#define MP2_CM4_WIC_CTRL_SET_M4_SLEEPDEEP_OVRD(mp2_cm4_wic_ctrl_reg, m4_sleepdeep_ovrd) \
     mp2_cm4_wic_ctrl_reg = (mp2_cm4_wic_ctrl_reg & ~MP2_CM4_WIC_CTRL_M4_SLEEPDEEP_OVRD_MASK) | (m4_sleepdeep_ovrd << MP2_CM4_WIC_CTRL_M4_SLEEPDEEP_OVRD_SHIFT)
#define MP2_CM4_WIC_CTRL_SET_M4_HOLD_EN(mp2_cm4_wic_ctrl_reg, m4_hold_en) \
     mp2_cm4_wic_ctrl_reg = (mp2_cm4_wic_ctrl_reg & ~MP2_CM4_WIC_CTRL_M4_HOLD_EN_MASK) | (m4_hold_en << MP2_CM4_WIC_CTRL_M4_HOLD_EN_SHIFT)
#define MP2_CM4_WIC_CTRL_SET_M4_WIC_STATUS(mp2_cm4_wic_ctrl_reg, m4_wic_status) \
     mp2_cm4_wic_ctrl_reg = (mp2_cm4_wic_ctrl_reg & ~MP2_CM4_WIC_CTRL_M4_WIC_STATUS_MASK) | (m4_wic_status << MP2_CM4_WIC_CTRL_M4_WIC_STATUS_SHIFT)
#define MP2_CM4_WIC_CTRL_SET_M4_INTISR_MASK(mp2_cm4_wic_ctrl_reg, m4_intisr_mask) \
     mp2_cm4_wic_ctrl_reg = (mp2_cm4_wic_ctrl_reg & ~MP2_CM4_WIC_CTRL_M4_INTISR_MASK_MASK) | (m4_intisr_mask << MP2_CM4_WIC_CTRL_M4_INTISR_MASK_SHIFT)
#define MP2_CM4_WIC_CTRL_SET_M4_INTNMI_MASK(mp2_cm4_wic_ctrl_reg, m4_intnmi_mask) \
     mp2_cm4_wic_ctrl_reg = (mp2_cm4_wic_ctrl_reg & ~MP2_CM4_WIC_CTRL_M4_INTNMI_MASK_MASK) | (m4_intnmi_mask << MP2_CM4_WIC_CTRL_M4_INTNMI_MASK_SHIFT)
#define MP2_CM4_WIC_CTRL_SET_M4_WIC_RESETn(mp2_cm4_wic_ctrl_reg, m4_wic_resetn) \
     mp2_cm4_wic_ctrl_reg = (mp2_cm4_wic_ctrl_reg & ~MP2_CM4_WIC_CTRL_M4_WIC_RESETn_MASK) | (m4_wic_resetn << MP2_CM4_WIC_CTRL_M4_WIC_RESETn_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_cm4_wic_ctrl_t {
          unsigned int m4_cg_en                       : MP2_CM4_WIC_CTRL_M4_CG_EN_SIZE;
          unsigned int m4_cg_bypass                   : MP2_CM4_WIC_CTRL_M4_CG_BYPASS_SIZE;
          unsigned int m4_wic_en                      : MP2_CM4_WIC_CTRL_M4_WIC_EN_SIZE;
          unsigned int m4_sleeping_ovrd               : MP2_CM4_WIC_CTRL_M4_SLEEPING_OVRD_SIZE;
          unsigned int m4_sleepdeep_ovrd              : MP2_CM4_WIC_CTRL_M4_SLEEPDEEP_OVRD_SIZE;
          unsigned int m4_hold_en                     : MP2_CM4_WIC_CTRL_M4_HOLD_EN_SIZE;
          unsigned int m4_wic_status                  : MP2_CM4_WIC_CTRL_M4_WIC_STATUS_SIZE;
          unsigned int m4_intisr_mask                 : MP2_CM4_WIC_CTRL_M4_INTISR_MASK_SIZE;
          unsigned int m4_intnmi_mask                 : MP2_CM4_WIC_CTRL_M4_INTNMI_MASK_SIZE;
          unsigned int m4_wic_resetn                  : MP2_CM4_WIC_CTRL_M4_WIC_RESETn_SIZE;
          unsigned int                                : 21;
     } mp2_cm4_wic_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_cm4_wic_ctrl_t {
          unsigned int                                : 21;
          unsigned int m4_wic_resetn                  : MP2_CM4_WIC_CTRL_M4_WIC_RESETn_SIZE;
          unsigned int m4_intnmi_mask                 : MP2_CM4_WIC_CTRL_M4_INTNMI_MASK_SIZE;
          unsigned int m4_intisr_mask                 : MP2_CM4_WIC_CTRL_M4_INTISR_MASK_SIZE;
          unsigned int m4_wic_status                  : MP2_CM4_WIC_CTRL_M4_WIC_STATUS_SIZE;
          unsigned int m4_hold_en                     : MP2_CM4_WIC_CTRL_M4_HOLD_EN_SIZE;
          unsigned int m4_sleepdeep_ovrd              : MP2_CM4_WIC_CTRL_M4_SLEEPDEEP_OVRD_SIZE;
          unsigned int m4_sleeping_ovrd               : MP2_CM4_WIC_CTRL_M4_SLEEPING_OVRD_SIZE;
          unsigned int m4_wic_en                      : MP2_CM4_WIC_CTRL_M4_WIC_EN_SIZE;
          unsigned int m4_cg_bypass                   : MP2_CM4_WIC_CTRL_M4_CG_BYPASS_SIZE;
          unsigned int m4_cg_en                       : MP2_CM4_WIC_CTRL_M4_CG_EN_SIZE;
     } mp2_cm4_wic_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_cm4_wic_ctrl_t f;
} mp2_cm4_wic_ctrl_u;


/*
 * MP2_WAKE_EVENT_CTRL struct
 */

#define MP2_WAKE_EVENT_CTRL_REG_SIZE   32
#define MP2_WAKE_EVENT_CTRL_PSP_WAKE_INTR_EN_SIZE 1
#define MP2_WAKE_EVENT_CTRL_PSP_WAKE_INTR_CLEAR_SIZE 1

#define MP2_WAKE_EVENT_CTRL_PSP_WAKE_INTR_EN_SHIFT 0
#define MP2_WAKE_EVENT_CTRL_PSP_WAKE_INTR_CLEAR_SHIFT 1

#define MP2_WAKE_EVENT_CTRL_PSP_WAKE_INTR_EN_MASK 0x1
#define MP2_WAKE_EVENT_CTRL_PSP_WAKE_INTR_CLEAR_MASK 0x2

#define MP2_WAKE_EVENT_CTRL_MASK \
     (MP2_WAKE_EVENT_CTRL_PSP_WAKE_INTR_EN_MASK | \
      MP2_WAKE_EVENT_CTRL_PSP_WAKE_INTR_CLEAR_MASK)

#define MP2_WAKE_EVENT_CTRL_DEFAULT    0x00000000

#define MP2_WAKE_EVENT_CTRL_GET_PSP_WAKE_INTR_EN(mp2_wake_event_ctrl) \
     ((mp2_wake_event_ctrl & MP2_WAKE_EVENT_CTRL_PSP_WAKE_INTR_EN_MASK) >> MP2_WAKE_EVENT_CTRL_PSP_WAKE_INTR_EN_SHIFT)
#define MP2_WAKE_EVENT_CTRL_GET_PSP_WAKE_INTR_CLEAR(mp2_wake_event_ctrl) \
     ((mp2_wake_event_ctrl & MP2_WAKE_EVENT_CTRL_PSP_WAKE_INTR_CLEAR_MASK) >> MP2_WAKE_EVENT_CTRL_PSP_WAKE_INTR_CLEAR_SHIFT)

#define MP2_WAKE_EVENT_CTRL_SET_PSP_WAKE_INTR_EN(mp2_wake_event_ctrl_reg, psp_wake_intr_en) \
     mp2_wake_event_ctrl_reg = (mp2_wake_event_ctrl_reg & ~MP2_WAKE_EVENT_CTRL_PSP_WAKE_INTR_EN_MASK) | (psp_wake_intr_en << MP2_WAKE_EVENT_CTRL_PSP_WAKE_INTR_EN_SHIFT)
#define MP2_WAKE_EVENT_CTRL_SET_PSP_WAKE_INTR_CLEAR(mp2_wake_event_ctrl_reg, psp_wake_intr_clear) \
     mp2_wake_event_ctrl_reg = (mp2_wake_event_ctrl_reg & ~MP2_WAKE_EVENT_CTRL_PSP_WAKE_INTR_CLEAR_MASK) | (psp_wake_intr_clear << MP2_WAKE_EVENT_CTRL_PSP_WAKE_INTR_CLEAR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_wake_event_ctrl_t {
          unsigned int psp_wake_intr_en               : MP2_WAKE_EVENT_CTRL_PSP_WAKE_INTR_EN_SIZE;
          unsigned int psp_wake_intr_clear            : MP2_WAKE_EVENT_CTRL_PSP_WAKE_INTR_CLEAR_SIZE;
          unsigned int                                : 30;
     } mp2_wake_event_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_wake_event_ctrl_t {
          unsigned int                                : 30;
          unsigned int psp_wake_intr_clear            : MP2_WAKE_EVENT_CTRL_PSP_WAKE_INTR_CLEAR_SIZE;
          unsigned int psp_wake_intr_en               : MP2_WAKE_EVENT_CTRL_PSP_WAKE_INTR_EN_SIZE;
     } mp2_wake_event_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_wake_event_ctrl_t f;
} mp2_wake_event_ctrl_u;


/*
 * MP2_MPAONCLK_XBAR_CG_CTRL struct
 */

#define MP2_MPAONCLK_XBAR_CG_CTRL_REG_SIZE 32
#define MP2_MPAONCLK_XBAR_CG_CTRL_MPAONCLK_XBAR_CACTIVE_EN_SIZE 1

#define MP2_MPAONCLK_XBAR_CG_CTRL_MPAONCLK_XBAR_CACTIVE_EN_SHIFT 0

#define MP2_MPAONCLK_XBAR_CG_CTRL_MPAONCLK_XBAR_CACTIVE_EN_MASK 0x1

#define MP2_MPAONCLK_XBAR_CG_CTRL_MASK \
     (MP2_MPAONCLK_XBAR_CG_CTRL_MPAONCLK_XBAR_CACTIVE_EN_MASK)

#define MP2_MPAONCLK_XBAR_CG_CTRL_DEFAULT 0x00000000

#define MP2_MPAONCLK_XBAR_CG_CTRL_GET_MPAONCLK_XBAR_CACTIVE_EN(mp2_mpaonclk_xbar_cg_ctrl) \
     ((mp2_mpaonclk_xbar_cg_ctrl & MP2_MPAONCLK_XBAR_CG_CTRL_MPAONCLK_XBAR_CACTIVE_EN_MASK) >> MP2_MPAONCLK_XBAR_CG_CTRL_MPAONCLK_XBAR_CACTIVE_EN_SHIFT)

#define MP2_MPAONCLK_XBAR_CG_CTRL_SET_MPAONCLK_XBAR_CACTIVE_EN(mp2_mpaonclk_xbar_cg_ctrl_reg, mpaonclk_xbar_cactive_en) \
     mp2_mpaonclk_xbar_cg_ctrl_reg = (mp2_mpaonclk_xbar_cg_ctrl_reg & ~MP2_MPAONCLK_XBAR_CG_CTRL_MPAONCLK_XBAR_CACTIVE_EN_MASK) | (mpaonclk_xbar_cactive_en << MP2_MPAONCLK_XBAR_CG_CTRL_MPAONCLK_XBAR_CACTIVE_EN_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mpaonclk_xbar_cg_ctrl_t {
          unsigned int mpaonclk_xbar_cactive_en       : MP2_MPAONCLK_XBAR_CG_CTRL_MPAONCLK_XBAR_CACTIVE_EN_SIZE;
          unsigned int                                : 31;
     } mp2_mpaonclk_xbar_cg_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mpaonclk_xbar_cg_ctrl_t {
          unsigned int                                : 31;
          unsigned int mpaonclk_xbar_cactive_en       : MP2_MPAONCLK_XBAR_CG_CTRL_MPAONCLK_XBAR_CACTIVE_EN_SIZE;
     } mp2_mpaonclk_xbar_cg_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mpaonclk_xbar_cg_ctrl_t f;
} mp2_mpaonclk_xbar_cg_ctrl_u;


/*
 * MP2_MPAONCLK_XBAR_CG_EN struct
 */

#define MP2_MPAONCLK_XBAR_CG_EN_REG_SIZE 32
#define MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_0_SIZE 1
#define MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_1_SIZE 1
#define MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_0_SIZE 1
#define MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_1_SIZE 1

#define MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_0_SHIFT 1
#define MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_1_SHIFT 2
#define MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_0_SHIFT 3
#define MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_1_SHIFT 4

#define MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_0_MASK 0x2
#define MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_1_MASK 0x4
#define MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_0_MASK 0x8
#define MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_1_MASK 0x10

#define MP2_MPAONCLK_XBAR_CG_EN_MASK \
     (MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_0_MASK | \
      MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_1_MASK | \
      MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_0_MASK | \
      MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_1_MASK)

#define MP2_MPAONCLK_XBAR_CG_EN_DEFAULT 0x00000000

#define MP2_MPAONCLK_XBAR_CG_EN_GET_MPAONCLK_XBAR_CG_EN_0(mp2_mpaonclk_xbar_cg_en) \
     ((mp2_mpaonclk_xbar_cg_en & MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_0_MASK) >> MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_0_SHIFT)
#define MP2_MPAONCLK_XBAR_CG_EN_GET_MPAONCLK_XBAR_CG_EN_1(mp2_mpaonclk_xbar_cg_en) \
     ((mp2_mpaonclk_xbar_cg_en & MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_1_MASK) >> MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_1_SHIFT)
#define MP2_MPAONCLK_XBAR_CG_EN_GET_MPAONCLK_XBAR_CG_OVERRIDE_0(mp2_mpaonclk_xbar_cg_en) \
     ((mp2_mpaonclk_xbar_cg_en & MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_0_MASK) >> MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_0_SHIFT)
#define MP2_MPAONCLK_XBAR_CG_EN_GET_MPAONCLK_XBAR_CG_OVERRIDE_1(mp2_mpaonclk_xbar_cg_en) \
     ((mp2_mpaonclk_xbar_cg_en & MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_1_MASK) >> MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_1_SHIFT)

#define MP2_MPAONCLK_XBAR_CG_EN_SET_MPAONCLK_XBAR_CG_EN_0(mp2_mpaonclk_xbar_cg_en_reg, mpaonclk_xbar_cg_en_0) \
     mp2_mpaonclk_xbar_cg_en_reg = (mp2_mpaonclk_xbar_cg_en_reg & ~MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_0_MASK) | (mpaonclk_xbar_cg_en_0 << MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_0_SHIFT)
#define MP2_MPAONCLK_XBAR_CG_EN_SET_MPAONCLK_XBAR_CG_EN_1(mp2_mpaonclk_xbar_cg_en_reg, mpaonclk_xbar_cg_en_1) \
     mp2_mpaonclk_xbar_cg_en_reg = (mp2_mpaonclk_xbar_cg_en_reg & ~MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_1_MASK) | (mpaonclk_xbar_cg_en_1 << MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_1_SHIFT)
#define MP2_MPAONCLK_XBAR_CG_EN_SET_MPAONCLK_XBAR_CG_OVERRIDE_0(mp2_mpaonclk_xbar_cg_en_reg, mpaonclk_xbar_cg_override_0) \
     mp2_mpaonclk_xbar_cg_en_reg = (mp2_mpaonclk_xbar_cg_en_reg & ~MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_0_MASK) | (mpaonclk_xbar_cg_override_0 << MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_0_SHIFT)
#define MP2_MPAONCLK_XBAR_CG_EN_SET_MPAONCLK_XBAR_CG_OVERRIDE_1(mp2_mpaonclk_xbar_cg_en_reg, mpaonclk_xbar_cg_override_1) \
     mp2_mpaonclk_xbar_cg_en_reg = (mp2_mpaonclk_xbar_cg_en_reg & ~MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_1_MASK) | (mpaonclk_xbar_cg_override_1 << MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mpaonclk_xbar_cg_en_t {
          unsigned int                                : 1;
          unsigned int mpaonclk_xbar_cg_en_0          : MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_0_SIZE;
          unsigned int mpaonclk_xbar_cg_en_1          : MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_1_SIZE;
          unsigned int mpaonclk_xbar_cg_override_0    : MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_0_SIZE;
          unsigned int mpaonclk_xbar_cg_override_1    : MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_1_SIZE;
          unsigned int                                : 27;
     } mp2_mpaonclk_xbar_cg_en_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mpaonclk_xbar_cg_en_t {
          unsigned int                                : 27;
          unsigned int mpaonclk_xbar_cg_override_1    : MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_1_SIZE;
          unsigned int mpaonclk_xbar_cg_override_0    : MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_0_SIZE;
          unsigned int mpaonclk_xbar_cg_en_1          : MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_1_SIZE;
          unsigned int mpaonclk_xbar_cg_en_0          : MP2_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_0_SIZE;
          unsigned int                                : 1;
     } mp2_mpaonclk_xbar_cg_en_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mpaonclk_xbar_cg_en_t f;
} mp2_mpaonclk_xbar_cg_en_u;


/*
 * MP2_MPAONCLK_XBAR_CG_MISC struct
 */

#define MP2_MPAONCLK_XBAR_CG_MISC_REG_SIZE 32
#define MP2_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CG_TIMEOUT_SIZE 8
#define MP2_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CSYS_DELAY_SIZE 8

#define MP2_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CG_TIMEOUT_SHIFT 0
#define MP2_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CSYS_DELAY_SHIFT 8

#define MP2_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CG_TIMEOUT_MASK 0xff
#define MP2_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CSYS_DELAY_MASK 0xff00

#define MP2_MPAONCLK_XBAR_CG_MISC_MASK \
     (MP2_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CG_TIMEOUT_MASK | \
      MP2_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CSYS_DELAY_MASK)

#define MP2_MPAONCLK_XBAR_CG_MISC_DEFAULT 0x00000606

#define MP2_MPAONCLK_XBAR_CG_MISC_GET_MPAONCLK_XBAR_CG_TIMEOUT(mp2_mpaonclk_xbar_cg_misc) \
     ((mp2_mpaonclk_xbar_cg_misc & MP2_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CG_TIMEOUT_MASK) >> MP2_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MP2_MPAONCLK_XBAR_CG_MISC_GET_MPAONCLK_XBAR_CSYS_DELAY(mp2_mpaonclk_xbar_cg_misc) \
     ((mp2_mpaonclk_xbar_cg_misc & MP2_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CSYS_DELAY_MASK) >> MP2_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CSYS_DELAY_SHIFT)

#define MP2_MPAONCLK_XBAR_CG_MISC_SET_MPAONCLK_XBAR_CG_TIMEOUT(mp2_mpaonclk_xbar_cg_misc_reg, mpaonclk_xbar_cg_timeout) \
     mp2_mpaonclk_xbar_cg_misc_reg = (mp2_mpaonclk_xbar_cg_misc_reg & ~MP2_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CG_TIMEOUT_MASK) | (mpaonclk_xbar_cg_timeout << MP2_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MP2_MPAONCLK_XBAR_CG_MISC_SET_MPAONCLK_XBAR_CSYS_DELAY(mp2_mpaonclk_xbar_cg_misc_reg, mpaonclk_xbar_csys_delay) \
     mp2_mpaonclk_xbar_cg_misc_reg = (mp2_mpaonclk_xbar_cg_misc_reg & ~MP2_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CSYS_DELAY_MASK) | (mpaonclk_xbar_csys_delay << MP2_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CSYS_DELAY_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mpaonclk_xbar_cg_misc_t {
          unsigned int mpaonclk_xbar_cg_timeout       : MP2_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CG_TIMEOUT_SIZE;
          unsigned int mpaonclk_xbar_csys_delay       : MP2_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CSYS_DELAY_SIZE;
          unsigned int                                : 16;
     } mp2_mpaonclk_xbar_cg_misc_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mpaonclk_xbar_cg_misc_t {
          unsigned int                                : 16;
          unsigned int mpaonclk_xbar_csys_delay       : MP2_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CSYS_DELAY_SIZE;
          unsigned int mpaonclk_xbar_cg_timeout       : MP2_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CG_TIMEOUT_SIZE;
     } mp2_mpaonclk_xbar_cg_misc_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mpaonclk_xbar_cg_misc_t f;
} mp2_mpaonclk_xbar_cg_misc_u;


/*
 * MP2_DFP_PGRAM_RAM0_CNTL struct
 */

#define MP2_DFP_PGRAM_RAM0_CNTL_REG_SIZE 32
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_SD_RAM0_SIZE 1
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_ROP_RAM0_SIZE 1
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_DEEP_SLEEP_EN_RAM0_SIZE 1
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_DEEP_SLEEP_STATUS_RAM0_SIZE 1
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_LIGHT_SLEEP_EN_RAM0_SIZE 1
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM0_SIZE 1
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_SLEEP_TIMEOUT_RAM0_SIZE 8
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_PG_DLY_RAM0_SIZE 8

#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_SD_RAM0_SHIFT 0
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_ROP_RAM0_SHIFT 1
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_DEEP_SLEEP_EN_RAM0_SHIFT 2
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_DEEP_SLEEP_STATUS_RAM0_SHIFT 3
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_LIGHT_SLEEP_EN_RAM0_SHIFT 4
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM0_SHIFT 5
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_SLEEP_TIMEOUT_RAM0_SHIFT 8
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_PG_DLY_RAM0_SHIFT 16

#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_SD_RAM0_MASK 0x1
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_ROP_RAM0_MASK 0x2
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_DEEP_SLEEP_EN_RAM0_MASK 0x4
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_DEEP_SLEEP_STATUS_RAM0_MASK 0x8
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_LIGHT_SLEEP_EN_RAM0_MASK 0x10
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM0_MASK 0x20
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_SLEEP_TIMEOUT_RAM0_MASK 0xff00
#define MP2_DFP_PGRAM_RAM0_CNTL_MEM_PG_DLY_RAM0_MASK 0xff0000

#define MP2_DFP_PGRAM_RAM0_CNTL_MASK \
     (MP2_DFP_PGRAM_RAM0_CNTL_MEM_SD_RAM0_MASK | \
      MP2_DFP_PGRAM_RAM0_CNTL_MEM_ROP_RAM0_MASK | \
      MP2_DFP_PGRAM_RAM0_CNTL_MEM_DEEP_SLEEP_EN_RAM0_MASK | \
      MP2_DFP_PGRAM_RAM0_CNTL_MEM_DEEP_SLEEP_STATUS_RAM0_MASK | \
      MP2_DFP_PGRAM_RAM0_CNTL_MEM_LIGHT_SLEEP_EN_RAM0_MASK | \
      MP2_DFP_PGRAM_RAM0_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM0_MASK | \
      MP2_DFP_PGRAM_RAM0_CNTL_MEM_SLEEP_TIMEOUT_RAM0_MASK | \
      MP2_DFP_PGRAM_RAM0_CNTL_MEM_PG_DLY_RAM0_MASK)

#define MP2_DFP_PGRAM_RAM0_CNTL_DEFAULT 0x0010102a

#define MP2_DFP_PGRAM_RAM0_CNTL_GET_MEM_SD_RAM0(mp2_dfp_pgram_ram0_cntl) \
     ((mp2_dfp_pgram_ram0_cntl & MP2_DFP_PGRAM_RAM0_CNTL_MEM_SD_RAM0_MASK) >> MP2_DFP_PGRAM_RAM0_CNTL_MEM_SD_RAM0_SHIFT)
#define MP2_DFP_PGRAM_RAM0_CNTL_GET_MEM_ROP_RAM0(mp2_dfp_pgram_ram0_cntl) \
     ((mp2_dfp_pgram_ram0_cntl & MP2_DFP_PGRAM_RAM0_CNTL_MEM_ROP_RAM0_MASK) >> MP2_DFP_PGRAM_RAM0_CNTL_MEM_ROP_RAM0_SHIFT)
#define MP2_DFP_PGRAM_RAM0_CNTL_GET_MEM_DEEP_SLEEP_EN_RAM0(mp2_dfp_pgram_ram0_cntl) \
     ((mp2_dfp_pgram_ram0_cntl & MP2_DFP_PGRAM_RAM0_CNTL_MEM_DEEP_SLEEP_EN_RAM0_MASK) >> MP2_DFP_PGRAM_RAM0_CNTL_MEM_DEEP_SLEEP_EN_RAM0_SHIFT)
#define MP2_DFP_PGRAM_RAM0_CNTL_GET_MEM_DEEP_SLEEP_STATUS_RAM0(mp2_dfp_pgram_ram0_cntl) \
     ((mp2_dfp_pgram_ram0_cntl & MP2_DFP_PGRAM_RAM0_CNTL_MEM_DEEP_SLEEP_STATUS_RAM0_MASK) >> MP2_DFP_PGRAM_RAM0_CNTL_MEM_DEEP_SLEEP_STATUS_RAM0_SHIFT)
#define MP2_DFP_PGRAM_RAM0_CNTL_GET_MEM_LIGHT_SLEEP_EN_RAM0(mp2_dfp_pgram_ram0_cntl) \
     ((mp2_dfp_pgram_ram0_cntl & MP2_DFP_PGRAM_RAM0_CNTL_MEM_LIGHT_SLEEP_EN_RAM0_MASK) >> MP2_DFP_PGRAM_RAM0_CNTL_MEM_LIGHT_SLEEP_EN_RAM0_SHIFT)
#define MP2_DFP_PGRAM_RAM0_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_RAM0(mp2_dfp_pgram_ram0_cntl) \
     ((mp2_dfp_pgram_ram0_cntl & MP2_DFP_PGRAM_RAM0_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM0_MASK) >> MP2_DFP_PGRAM_RAM0_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM0_SHIFT)
#define MP2_DFP_PGRAM_RAM0_CNTL_GET_MEM_SLEEP_TIMEOUT_RAM0(mp2_dfp_pgram_ram0_cntl) \
     ((mp2_dfp_pgram_ram0_cntl & MP2_DFP_PGRAM_RAM0_CNTL_MEM_SLEEP_TIMEOUT_RAM0_MASK) >> MP2_DFP_PGRAM_RAM0_CNTL_MEM_SLEEP_TIMEOUT_RAM0_SHIFT)
#define MP2_DFP_PGRAM_RAM0_CNTL_GET_MEM_PG_DLY_RAM0(mp2_dfp_pgram_ram0_cntl) \
     ((mp2_dfp_pgram_ram0_cntl & MP2_DFP_PGRAM_RAM0_CNTL_MEM_PG_DLY_RAM0_MASK) >> MP2_DFP_PGRAM_RAM0_CNTL_MEM_PG_DLY_RAM0_SHIFT)

#define MP2_DFP_PGRAM_RAM0_CNTL_SET_MEM_SD_RAM0(mp2_dfp_pgram_ram0_cntl_reg, mem_sd_ram0) \
     mp2_dfp_pgram_ram0_cntl_reg = (mp2_dfp_pgram_ram0_cntl_reg & ~MP2_DFP_PGRAM_RAM0_CNTL_MEM_SD_RAM0_MASK) | (mem_sd_ram0 << MP2_DFP_PGRAM_RAM0_CNTL_MEM_SD_RAM0_SHIFT)
#define MP2_DFP_PGRAM_RAM0_CNTL_SET_MEM_ROP_RAM0(mp2_dfp_pgram_ram0_cntl_reg, mem_rop_ram0) \
     mp2_dfp_pgram_ram0_cntl_reg = (mp2_dfp_pgram_ram0_cntl_reg & ~MP2_DFP_PGRAM_RAM0_CNTL_MEM_ROP_RAM0_MASK) | (mem_rop_ram0 << MP2_DFP_PGRAM_RAM0_CNTL_MEM_ROP_RAM0_SHIFT)
#define MP2_DFP_PGRAM_RAM0_CNTL_SET_MEM_DEEP_SLEEP_EN_RAM0(mp2_dfp_pgram_ram0_cntl_reg, mem_deep_sleep_en_ram0) \
     mp2_dfp_pgram_ram0_cntl_reg = (mp2_dfp_pgram_ram0_cntl_reg & ~MP2_DFP_PGRAM_RAM0_CNTL_MEM_DEEP_SLEEP_EN_RAM0_MASK) | (mem_deep_sleep_en_ram0 << MP2_DFP_PGRAM_RAM0_CNTL_MEM_DEEP_SLEEP_EN_RAM0_SHIFT)
#define MP2_DFP_PGRAM_RAM0_CNTL_SET_MEM_DEEP_SLEEP_STATUS_RAM0(mp2_dfp_pgram_ram0_cntl_reg, mem_deep_sleep_status_ram0) \
     mp2_dfp_pgram_ram0_cntl_reg = (mp2_dfp_pgram_ram0_cntl_reg & ~MP2_DFP_PGRAM_RAM0_CNTL_MEM_DEEP_SLEEP_STATUS_RAM0_MASK) | (mem_deep_sleep_status_ram0 << MP2_DFP_PGRAM_RAM0_CNTL_MEM_DEEP_SLEEP_STATUS_RAM0_SHIFT)
#define MP2_DFP_PGRAM_RAM0_CNTL_SET_MEM_LIGHT_SLEEP_EN_RAM0(mp2_dfp_pgram_ram0_cntl_reg, mem_light_sleep_en_ram0) \
     mp2_dfp_pgram_ram0_cntl_reg = (mp2_dfp_pgram_ram0_cntl_reg & ~MP2_DFP_PGRAM_RAM0_CNTL_MEM_LIGHT_SLEEP_EN_RAM0_MASK) | (mem_light_sleep_en_ram0 << MP2_DFP_PGRAM_RAM0_CNTL_MEM_LIGHT_SLEEP_EN_RAM0_SHIFT)
#define MP2_DFP_PGRAM_RAM0_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_RAM0(mp2_dfp_pgram_ram0_cntl_reg, mem_light_sleep_status_ram0) \
     mp2_dfp_pgram_ram0_cntl_reg = (mp2_dfp_pgram_ram0_cntl_reg & ~MP2_DFP_PGRAM_RAM0_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM0_MASK) | (mem_light_sleep_status_ram0 << MP2_DFP_PGRAM_RAM0_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM0_SHIFT)
#define MP2_DFP_PGRAM_RAM0_CNTL_SET_MEM_SLEEP_TIMEOUT_RAM0(mp2_dfp_pgram_ram0_cntl_reg, mem_sleep_timeout_ram0) \
     mp2_dfp_pgram_ram0_cntl_reg = (mp2_dfp_pgram_ram0_cntl_reg & ~MP2_DFP_PGRAM_RAM0_CNTL_MEM_SLEEP_TIMEOUT_RAM0_MASK) | (mem_sleep_timeout_ram0 << MP2_DFP_PGRAM_RAM0_CNTL_MEM_SLEEP_TIMEOUT_RAM0_SHIFT)
#define MP2_DFP_PGRAM_RAM0_CNTL_SET_MEM_PG_DLY_RAM0(mp2_dfp_pgram_ram0_cntl_reg, mem_pg_dly_ram0) \
     mp2_dfp_pgram_ram0_cntl_reg = (mp2_dfp_pgram_ram0_cntl_reg & ~MP2_DFP_PGRAM_RAM0_CNTL_MEM_PG_DLY_RAM0_MASK) | (mem_pg_dly_ram0 << MP2_DFP_PGRAM_RAM0_CNTL_MEM_PG_DLY_RAM0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfp_pgram_ram0_cntl_t {
          unsigned int mem_sd_ram0                    : MP2_DFP_PGRAM_RAM0_CNTL_MEM_SD_RAM0_SIZE;
          unsigned int mem_rop_ram0                   : MP2_DFP_PGRAM_RAM0_CNTL_MEM_ROP_RAM0_SIZE;
          unsigned int mem_deep_sleep_en_ram0         : MP2_DFP_PGRAM_RAM0_CNTL_MEM_DEEP_SLEEP_EN_RAM0_SIZE;
          unsigned int mem_deep_sleep_status_ram0     : MP2_DFP_PGRAM_RAM0_CNTL_MEM_DEEP_SLEEP_STATUS_RAM0_SIZE;
          unsigned int mem_light_sleep_en_ram0        : MP2_DFP_PGRAM_RAM0_CNTL_MEM_LIGHT_SLEEP_EN_RAM0_SIZE;
          unsigned int mem_light_sleep_status_ram0    : MP2_DFP_PGRAM_RAM0_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM0_SIZE;
          unsigned int                                : 2;
          unsigned int mem_sleep_timeout_ram0         : MP2_DFP_PGRAM_RAM0_CNTL_MEM_SLEEP_TIMEOUT_RAM0_SIZE;
          unsigned int mem_pg_dly_ram0                : MP2_DFP_PGRAM_RAM0_CNTL_MEM_PG_DLY_RAM0_SIZE;
          unsigned int                                : 8;
     } mp2_dfp_pgram_ram0_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfp_pgram_ram0_cntl_t {
          unsigned int                                : 8;
          unsigned int mem_pg_dly_ram0                : MP2_DFP_PGRAM_RAM0_CNTL_MEM_PG_DLY_RAM0_SIZE;
          unsigned int mem_sleep_timeout_ram0         : MP2_DFP_PGRAM_RAM0_CNTL_MEM_SLEEP_TIMEOUT_RAM0_SIZE;
          unsigned int                                : 2;
          unsigned int mem_light_sleep_status_ram0    : MP2_DFP_PGRAM_RAM0_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM0_SIZE;
          unsigned int mem_light_sleep_en_ram0        : MP2_DFP_PGRAM_RAM0_CNTL_MEM_LIGHT_SLEEP_EN_RAM0_SIZE;
          unsigned int mem_deep_sleep_status_ram0     : MP2_DFP_PGRAM_RAM0_CNTL_MEM_DEEP_SLEEP_STATUS_RAM0_SIZE;
          unsigned int mem_deep_sleep_en_ram0         : MP2_DFP_PGRAM_RAM0_CNTL_MEM_DEEP_SLEEP_EN_RAM0_SIZE;
          unsigned int mem_rop_ram0                   : MP2_DFP_PGRAM_RAM0_CNTL_MEM_ROP_RAM0_SIZE;
          unsigned int mem_sd_ram0                    : MP2_DFP_PGRAM_RAM0_CNTL_MEM_SD_RAM0_SIZE;
     } mp2_dfp_pgram_ram0_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfp_pgram_ram0_cntl_t f;
} mp2_dfp_pgram_ram0_cntl_u;


/*
 * MP2_DFP_PGRAM_RAM1_CNTL struct
 */

#define MP2_DFP_PGRAM_RAM1_CNTL_REG_SIZE 32
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_SD_RAM1_SIZE 1
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_ROP_RAM1_SIZE 1
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_DEEP_SLEEP_EN_RAM1_SIZE 1
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_DEEP_SLEEP_STATUS_RAM1_SIZE 1
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_LIGHT_SLEEP_EN_RAM1_SIZE 1
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM1_SIZE 1
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_SLEEP_TIMEOUT_RAM1_SIZE 8
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_PG_DLY_RAM1_SIZE 8

#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_SD_RAM1_SHIFT 0
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_ROP_RAM1_SHIFT 1
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_DEEP_SLEEP_EN_RAM1_SHIFT 2
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_DEEP_SLEEP_STATUS_RAM1_SHIFT 3
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_LIGHT_SLEEP_EN_RAM1_SHIFT 4
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM1_SHIFT 5
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_SLEEP_TIMEOUT_RAM1_SHIFT 8
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_PG_DLY_RAM1_SHIFT 16

#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_SD_RAM1_MASK 0x1
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_ROP_RAM1_MASK 0x2
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_DEEP_SLEEP_EN_RAM1_MASK 0x4
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_DEEP_SLEEP_STATUS_RAM1_MASK 0x8
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_LIGHT_SLEEP_EN_RAM1_MASK 0x10
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM1_MASK 0x20
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_SLEEP_TIMEOUT_RAM1_MASK 0xff00
#define MP2_DFP_PGRAM_RAM1_CNTL_MEM_PG_DLY_RAM1_MASK 0xff0000

#define MP2_DFP_PGRAM_RAM1_CNTL_MASK \
     (MP2_DFP_PGRAM_RAM1_CNTL_MEM_SD_RAM1_MASK | \
      MP2_DFP_PGRAM_RAM1_CNTL_MEM_ROP_RAM1_MASK | \
      MP2_DFP_PGRAM_RAM1_CNTL_MEM_DEEP_SLEEP_EN_RAM1_MASK | \
      MP2_DFP_PGRAM_RAM1_CNTL_MEM_DEEP_SLEEP_STATUS_RAM1_MASK | \
      MP2_DFP_PGRAM_RAM1_CNTL_MEM_LIGHT_SLEEP_EN_RAM1_MASK | \
      MP2_DFP_PGRAM_RAM1_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM1_MASK | \
      MP2_DFP_PGRAM_RAM1_CNTL_MEM_SLEEP_TIMEOUT_RAM1_MASK | \
      MP2_DFP_PGRAM_RAM1_CNTL_MEM_PG_DLY_RAM1_MASK)

#define MP2_DFP_PGRAM_RAM1_CNTL_DEFAULT 0x0010102a

#define MP2_DFP_PGRAM_RAM1_CNTL_GET_MEM_SD_RAM1(mp2_dfp_pgram_ram1_cntl) \
     ((mp2_dfp_pgram_ram1_cntl & MP2_DFP_PGRAM_RAM1_CNTL_MEM_SD_RAM1_MASK) >> MP2_DFP_PGRAM_RAM1_CNTL_MEM_SD_RAM1_SHIFT)
#define MP2_DFP_PGRAM_RAM1_CNTL_GET_MEM_ROP_RAM1(mp2_dfp_pgram_ram1_cntl) \
     ((mp2_dfp_pgram_ram1_cntl & MP2_DFP_PGRAM_RAM1_CNTL_MEM_ROP_RAM1_MASK) >> MP2_DFP_PGRAM_RAM1_CNTL_MEM_ROP_RAM1_SHIFT)
#define MP2_DFP_PGRAM_RAM1_CNTL_GET_MEM_DEEP_SLEEP_EN_RAM1(mp2_dfp_pgram_ram1_cntl) \
     ((mp2_dfp_pgram_ram1_cntl & MP2_DFP_PGRAM_RAM1_CNTL_MEM_DEEP_SLEEP_EN_RAM1_MASK) >> MP2_DFP_PGRAM_RAM1_CNTL_MEM_DEEP_SLEEP_EN_RAM1_SHIFT)
#define MP2_DFP_PGRAM_RAM1_CNTL_GET_MEM_DEEP_SLEEP_STATUS_RAM1(mp2_dfp_pgram_ram1_cntl) \
     ((mp2_dfp_pgram_ram1_cntl & MP2_DFP_PGRAM_RAM1_CNTL_MEM_DEEP_SLEEP_STATUS_RAM1_MASK) >> MP2_DFP_PGRAM_RAM1_CNTL_MEM_DEEP_SLEEP_STATUS_RAM1_SHIFT)
#define MP2_DFP_PGRAM_RAM1_CNTL_GET_MEM_LIGHT_SLEEP_EN_RAM1(mp2_dfp_pgram_ram1_cntl) \
     ((mp2_dfp_pgram_ram1_cntl & MP2_DFP_PGRAM_RAM1_CNTL_MEM_LIGHT_SLEEP_EN_RAM1_MASK) >> MP2_DFP_PGRAM_RAM1_CNTL_MEM_LIGHT_SLEEP_EN_RAM1_SHIFT)
#define MP2_DFP_PGRAM_RAM1_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_RAM1(mp2_dfp_pgram_ram1_cntl) \
     ((mp2_dfp_pgram_ram1_cntl & MP2_DFP_PGRAM_RAM1_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM1_MASK) >> MP2_DFP_PGRAM_RAM1_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM1_SHIFT)
#define MP2_DFP_PGRAM_RAM1_CNTL_GET_MEM_SLEEP_TIMEOUT_RAM1(mp2_dfp_pgram_ram1_cntl) \
     ((mp2_dfp_pgram_ram1_cntl & MP2_DFP_PGRAM_RAM1_CNTL_MEM_SLEEP_TIMEOUT_RAM1_MASK) >> MP2_DFP_PGRAM_RAM1_CNTL_MEM_SLEEP_TIMEOUT_RAM1_SHIFT)
#define MP2_DFP_PGRAM_RAM1_CNTL_GET_MEM_PG_DLY_RAM1(mp2_dfp_pgram_ram1_cntl) \
     ((mp2_dfp_pgram_ram1_cntl & MP2_DFP_PGRAM_RAM1_CNTL_MEM_PG_DLY_RAM1_MASK) >> MP2_DFP_PGRAM_RAM1_CNTL_MEM_PG_DLY_RAM1_SHIFT)

#define MP2_DFP_PGRAM_RAM1_CNTL_SET_MEM_SD_RAM1(mp2_dfp_pgram_ram1_cntl_reg, mem_sd_ram1) \
     mp2_dfp_pgram_ram1_cntl_reg = (mp2_dfp_pgram_ram1_cntl_reg & ~MP2_DFP_PGRAM_RAM1_CNTL_MEM_SD_RAM1_MASK) | (mem_sd_ram1 << MP2_DFP_PGRAM_RAM1_CNTL_MEM_SD_RAM1_SHIFT)
#define MP2_DFP_PGRAM_RAM1_CNTL_SET_MEM_ROP_RAM1(mp2_dfp_pgram_ram1_cntl_reg, mem_rop_ram1) \
     mp2_dfp_pgram_ram1_cntl_reg = (mp2_dfp_pgram_ram1_cntl_reg & ~MP2_DFP_PGRAM_RAM1_CNTL_MEM_ROP_RAM1_MASK) | (mem_rop_ram1 << MP2_DFP_PGRAM_RAM1_CNTL_MEM_ROP_RAM1_SHIFT)
#define MP2_DFP_PGRAM_RAM1_CNTL_SET_MEM_DEEP_SLEEP_EN_RAM1(mp2_dfp_pgram_ram1_cntl_reg, mem_deep_sleep_en_ram1) \
     mp2_dfp_pgram_ram1_cntl_reg = (mp2_dfp_pgram_ram1_cntl_reg & ~MP2_DFP_PGRAM_RAM1_CNTL_MEM_DEEP_SLEEP_EN_RAM1_MASK) | (mem_deep_sleep_en_ram1 << MP2_DFP_PGRAM_RAM1_CNTL_MEM_DEEP_SLEEP_EN_RAM1_SHIFT)
#define MP2_DFP_PGRAM_RAM1_CNTL_SET_MEM_DEEP_SLEEP_STATUS_RAM1(mp2_dfp_pgram_ram1_cntl_reg, mem_deep_sleep_status_ram1) \
     mp2_dfp_pgram_ram1_cntl_reg = (mp2_dfp_pgram_ram1_cntl_reg & ~MP2_DFP_PGRAM_RAM1_CNTL_MEM_DEEP_SLEEP_STATUS_RAM1_MASK) | (mem_deep_sleep_status_ram1 << MP2_DFP_PGRAM_RAM1_CNTL_MEM_DEEP_SLEEP_STATUS_RAM1_SHIFT)
#define MP2_DFP_PGRAM_RAM1_CNTL_SET_MEM_LIGHT_SLEEP_EN_RAM1(mp2_dfp_pgram_ram1_cntl_reg, mem_light_sleep_en_ram1) \
     mp2_dfp_pgram_ram1_cntl_reg = (mp2_dfp_pgram_ram1_cntl_reg & ~MP2_DFP_PGRAM_RAM1_CNTL_MEM_LIGHT_SLEEP_EN_RAM1_MASK) | (mem_light_sleep_en_ram1 << MP2_DFP_PGRAM_RAM1_CNTL_MEM_LIGHT_SLEEP_EN_RAM1_SHIFT)
#define MP2_DFP_PGRAM_RAM1_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_RAM1(mp2_dfp_pgram_ram1_cntl_reg, mem_light_sleep_status_ram1) \
     mp2_dfp_pgram_ram1_cntl_reg = (mp2_dfp_pgram_ram1_cntl_reg & ~MP2_DFP_PGRAM_RAM1_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM1_MASK) | (mem_light_sleep_status_ram1 << MP2_DFP_PGRAM_RAM1_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM1_SHIFT)
#define MP2_DFP_PGRAM_RAM1_CNTL_SET_MEM_SLEEP_TIMEOUT_RAM1(mp2_dfp_pgram_ram1_cntl_reg, mem_sleep_timeout_ram1) \
     mp2_dfp_pgram_ram1_cntl_reg = (mp2_dfp_pgram_ram1_cntl_reg & ~MP2_DFP_PGRAM_RAM1_CNTL_MEM_SLEEP_TIMEOUT_RAM1_MASK) | (mem_sleep_timeout_ram1 << MP2_DFP_PGRAM_RAM1_CNTL_MEM_SLEEP_TIMEOUT_RAM1_SHIFT)
#define MP2_DFP_PGRAM_RAM1_CNTL_SET_MEM_PG_DLY_RAM1(mp2_dfp_pgram_ram1_cntl_reg, mem_pg_dly_ram1) \
     mp2_dfp_pgram_ram1_cntl_reg = (mp2_dfp_pgram_ram1_cntl_reg & ~MP2_DFP_PGRAM_RAM1_CNTL_MEM_PG_DLY_RAM1_MASK) | (mem_pg_dly_ram1 << MP2_DFP_PGRAM_RAM1_CNTL_MEM_PG_DLY_RAM1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfp_pgram_ram1_cntl_t {
          unsigned int mem_sd_ram1                    : MP2_DFP_PGRAM_RAM1_CNTL_MEM_SD_RAM1_SIZE;
          unsigned int mem_rop_ram1                   : MP2_DFP_PGRAM_RAM1_CNTL_MEM_ROP_RAM1_SIZE;
          unsigned int mem_deep_sleep_en_ram1         : MP2_DFP_PGRAM_RAM1_CNTL_MEM_DEEP_SLEEP_EN_RAM1_SIZE;
          unsigned int mem_deep_sleep_status_ram1     : MP2_DFP_PGRAM_RAM1_CNTL_MEM_DEEP_SLEEP_STATUS_RAM1_SIZE;
          unsigned int mem_light_sleep_en_ram1        : MP2_DFP_PGRAM_RAM1_CNTL_MEM_LIGHT_SLEEP_EN_RAM1_SIZE;
          unsigned int mem_light_sleep_status_ram1    : MP2_DFP_PGRAM_RAM1_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM1_SIZE;
          unsigned int                                : 2;
          unsigned int mem_sleep_timeout_ram1         : MP2_DFP_PGRAM_RAM1_CNTL_MEM_SLEEP_TIMEOUT_RAM1_SIZE;
          unsigned int mem_pg_dly_ram1                : MP2_DFP_PGRAM_RAM1_CNTL_MEM_PG_DLY_RAM1_SIZE;
          unsigned int                                : 8;
     } mp2_dfp_pgram_ram1_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfp_pgram_ram1_cntl_t {
          unsigned int                                : 8;
          unsigned int mem_pg_dly_ram1                : MP2_DFP_PGRAM_RAM1_CNTL_MEM_PG_DLY_RAM1_SIZE;
          unsigned int mem_sleep_timeout_ram1         : MP2_DFP_PGRAM_RAM1_CNTL_MEM_SLEEP_TIMEOUT_RAM1_SIZE;
          unsigned int                                : 2;
          unsigned int mem_light_sleep_status_ram1    : MP2_DFP_PGRAM_RAM1_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM1_SIZE;
          unsigned int mem_light_sleep_en_ram1        : MP2_DFP_PGRAM_RAM1_CNTL_MEM_LIGHT_SLEEP_EN_RAM1_SIZE;
          unsigned int mem_deep_sleep_status_ram1     : MP2_DFP_PGRAM_RAM1_CNTL_MEM_DEEP_SLEEP_STATUS_RAM1_SIZE;
          unsigned int mem_deep_sleep_en_ram1         : MP2_DFP_PGRAM_RAM1_CNTL_MEM_DEEP_SLEEP_EN_RAM1_SIZE;
          unsigned int mem_rop_ram1                   : MP2_DFP_PGRAM_RAM1_CNTL_MEM_ROP_RAM1_SIZE;
          unsigned int mem_sd_ram1                    : MP2_DFP_PGRAM_RAM1_CNTL_MEM_SD_RAM1_SIZE;
     } mp2_dfp_pgram_ram1_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfp_pgram_ram1_cntl_t f;
} mp2_dfp_pgram_ram1_cntl_u;


/*
 * MP2_DFP_PGRAM_RAM2_CNTL struct
 */

#define MP2_DFP_PGRAM_RAM2_CNTL_REG_SIZE 32
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_SD_RAM2_SIZE 1
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_ROP_RAM2_SIZE 1
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_DEEP_SLEEP_EN_RAM2_SIZE 1
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_DEEP_SLEEP_STATUS_RAM2_SIZE 1
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_LIGHT_SLEEP_EN_RAM2_SIZE 1
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM2_SIZE 1
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_SLEEP_TIMEOUT_RAM2_SIZE 8
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_PG_DLY_RAM2_SIZE 8

#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_SD_RAM2_SHIFT 0
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_ROP_RAM2_SHIFT 1
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_DEEP_SLEEP_EN_RAM2_SHIFT 2
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_DEEP_SLEEP_STATUS_RAM2_SHIFT 3
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_LIGHT_SLEEP_EN_RAM2_SHIFT 4
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM2_SHIFT 5
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_SLEEP_TIMEOUT_RAM2_SHIFT 8
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_PG_DLY_RAM2_SHIFT 16

#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_SD_RAM2_MASK 0x1
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_ROP_RAM2_MASK 0x2
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_DEEP_SLEEP_EN_RAM2_MASK 0x4
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_DEEP_SLEEP_STATUS_RAM2_MASK 0x8
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_LIGHT_SLEEP_EN_RAM2_MASK 0x10
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM2_MASK 0x20
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_SLEEP_TIMEOUT_RAM2_MASK 0xff00
#define MP2_DFP_PGRAM_RAM2_CNTL_MEM_PG_DLY_RAM2_MASK 0xff0000

#define MP2_DFP_PGRAM_RAM2_CNTL_MASK \
     (MP2_DFP_PGRAM_RAM2_CNTL_MEM_SD_RAM2_MASK | \
      MP2_DFP_PGRAM_RAM2_CNTL_MEM_ROP_RAM2_MASK | \
      MP2_DFP_PGRAM_RAM2_CNTL_MEM_DEEP_SLEEP_EN_RAM2_MASK | \
      MP2_DFP_PGRAM_RAM2_CNTL_MEM_DEEP_SLEEP_STATUS_RAM2_MASK | \
      MP2_DFP_PGRAM_RAM2_CNTL_MEM_LIGHT_SLEEP_EN_RAM2_MASK | \
      MP2_DFP_PGRAM_RAM2_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM2_MASK | \
      MP2_DFP_PGRAM_RAM2_CNTL_MEM_SLEEP_TIMEOUT_RAM2_MASK | \
      MP2_DFP_PGRAM_RAM2_CNTL_MEM_PG_DLY_RAM2_MASK)

#define MP2_DFP_PGRAM_RAM2_CNTL_DEFAULT 0x0010102a

#define MP2_DFP_PGRAM_RAM2_CNTL_GET_MEM_SD_RAM2(mp2_dfp_pgram_ram2_cntl) \
     ((mp2_dfp_pgram_ram2_cntl & MP2_DFP_PGRAM_RAM2_CNTL_MEM_SD_RAM2_MASK) >> MP2_DFP_PGRAM_RAM2_CNTL_MEM_SD_RAM2_SHIFT)
#define MP2_DFP_PGRAM_RAM2_CNTL_GET_MEM_ROP_RAM2(mp2_dfp_pgram_ram2_cntl) \
     ((mp2_dfp_pgram_ram2_cntl & MP2_DFP_PGRAM_RAM2_CNTL_MEM_ROP_RAM2_MASK) >> MP2_DFP_PGRAM_RAM2_CNTL_MEM_ROP_RAM2_SHIFT)
#define MP2_DFP_PGRAM_RAM2_CNTL_GET_MEM_DEEP_SLEEP_EN_RAM2(mp2_dfp_pgram_ram2_cntl) \
     ((mp2_dfp_pgram_ram2_cntl & MP2_DFP_PGRAM_RAM2_CNTL_MEM_DEEP_SLEEP_EN_RAM2_MASK) >> MP2_DFP_PGRAM_RAM2_CNTL_MEM_DEEP_SLEEP_EN_RAM2_SHIFT)
#define MP2_DFP_PGRAM_RAM2_CNTL_GET_MEM_DEEP_SLEEP_STATUS_RAM2(mp2_dfp_pgram_ram2_cntl) \
     ((mp2_dfp_pgram_ram2_cntl & MP2_DFP_PGRAM_RAM2_CNTL_MEM_DEEP_SLEEP_STATUS_RAM2_MASK) >> MP2_DFP_PGRAM_RAM2_CNTL_MEM_DEEP_SLEEP_STATUS_RAM2_SHIFT)
#define MP2_DFP_PGRAM_RAM2_CNTL_GET_MEM_LIGHT_SLEEP_EN_RAM2(mp2_dfp_pgram_ram2_cntl) \
     ((mp2_dfp_pgram_ram2_cntl & MP2_DFP_PGRAM_RAM2_CNTL_MEM_LIGHT_SLEEP_EN_RAM2_MASK) >> MP2_DFP_PGRAM_RAM2_CNTL_MEM_LIGHT_SLEEP_EN_RAM2_SHIFT)
#define MP2_DFP_PGRAM_RAM2_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_RAM2(mp2_dfp_pgram_ram2_cntl) \
     ((mp2_dfp_pgram_ram2_cntl & MP2_DFP_PGRAM_RAM2_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM2_MASK) >> MP2_DFP_PGRAM_RAM2_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM2_SHIFT)
#define MP2_DFP_PGRAM_RAM2_CNTL_GET_MEM_SLEEP_TIMEOUT_RAM2(mp2_dfp_pgram_ram2_cntl) \
     ((mp2_dfp_pgram_ram2_cntl & MP2_DFP_PGRAM_RAM2_CNTL_MEM_SLEEP_TIMEOUT_RAM2_MASK) >> MP2_DFP_PGRAM_RAM2_CNTL_MEM_SLEEP_TIMEOUT_RAM2_SHIFT)
#define MP2_DFP_PGRAM_RAM2_CNTL_GET_MEM_PG_DLY_RAM2(mp2_dfp_pgram_ram2_cntl) \
     ((mp2_dfp_pgram_ram2_cntl & MP2_DFP_PGRAM_RAM2_CNTL_MEM_PG_DLY_RAM2_MASK) >> MP2_DFP_PGRAM_RAM2_CNTL_MEM_PG_DLY_RAM2_SHIFT)

#define MP2_DFP_PGRAM_RAM2_CNTL_SET_MEM_SD_RAM2(mp2_dfp_pgram_ram2_cntl_reg, mem_sd_ram2) \
     mp2_dfp_pgram_ram2_cntl_reg = (mp2_dfp_pgram_ram2_cntl_reg & ~MP2_DFP_PGRAM_RAM2_CNTL_MEM_SD_RAM2_MASK) | (mem_sd_ram2 << MP2_DFP_PGRAM_RAM2_CNTL_MEM_SD_RAM2_SHIFT)
#define MP2_DFP_PGRAM_RAM2_CNTL_SET_MEM_ROP_RAM2(mp2_dfp_pgram_ram2_cntl_reg, mem_rop_ram2) \
     mp2_dfp_pgram_ram2_cntl_reg = (mp2_dfp_pgram_ram2_cntl_reg & ~MP2_DFP_PGRAM_RAM2_CNTL_MEM_ROP_RAM2_MASK) | (mem_rop_ram2 << MP2_DFP_PGRAM_RAM2_CNTL_MEM_ROP_RAM2_SHIFT)
#define MP2_DFP_PGRAM_RAM2_CNTL_SET_MEM_DEEP_SLEEP_EN_RAM2(mp2_dfp_pgram_ram2_cntl_reg, mem_deep_sleep_en_ram2) \
     mp2_dfp_pgram_ram2_cntl_reg = (mp2_dfp_pgram_ram2_cntl_reg & ~MP2_DFP_PGRAM_RAM2_CNTL_MEM_DEEP_SLEEP_EN_RAM2_MASK) | (mem_deep_sleep_en_ram2 << MP2_DFP_PGRAM_RAM2_CNTL_MEM_DEEP_SLEEP_EN_RAM2_SHIFT)
#define MP2_DFP_PGRAM_RAM2_CNTL_SET_MEM_DEEP_SLEEP_STATUS_RAM2(mp2_dfp_pgram_ram2_cntl_reg, mem_deep_sleep_status_ram2) \
     mp2_dfp_pgram_ram2_cntl_reg = (mp2_dfp_pgram_ram2_cntl_reg & ~MP2_DFP_PGRAM_RAM2_CNTL_MEM_DEEP_SLEEP_STATUS_RAM2_MASK) | (mem_deep_sleep_status_ram2 << MP2_DFP_PGRAM_RAM2_CNTL_MEM_DEEP_SLEEP_STATUS_RAM2_SHIFT)
#define MP2_DFP_PGRAM_RAM2_CNTL_SET_MEM_LIGHT_SLEEP_EN_RAM2(mp2_dfp_pgram_ram2_cntl_reg, mem_light_sleep_en_ram2) \
     mp2_dfp_pgram_ram2_cntl_reg = (mp2_dfp_pgram_ram2_cntl_reg & ~MP2_DFP_PGRAM_RAM2_CNTL_MEM_LIGHT_SLEEP_EN_RAM2_MASK) | (mem_light_sleep_en_ram2 << MP2_DFP_PGRAM_RAM2_CNTL_MEM_LIGHT_SLEEP_EN_RAM2_SHIFT)
#define MP2_DFP_PGRAM_RAM2_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_RAM2(mp2_dfp_pgram_ram2_cntl_reg, mem_light_sleep_status_ram2) \
     mp2_dfp_pgram_ram2_cntl_reg = (mp2_dfp_pgram_ram2_cntl_reg & ~MP2_DFP_PGRAM_RAM2_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM2_MASK) | (mem_light_sleep_status_ram2 << MP2_DFP_PGRAM_RAM2_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM2_SHIFT)
#define MP2_DFP_PGRAM_RAM2_CNTL_SET_MEM_SLEEP_TIMEOUT_RAM2(mp2_dfp_pgram_ram2_cntl_reg, mem_sleep_timeout_ram2) \
     mp2_dfp_pgram_ram2_cntl_reg = (mp2_dfp_pgram_ram2_cntl_reg & ~MP2_DFP_PGRAM_RAM2_CNTL_MEM_SLEEP_TIMEOUT_RAM2_MASK) | (mem_sleep_timeout_ram2 << MP2_DFP_PGRAM_RAM2_CNTL_MEM_SLEEP_TIMEOUT_RAM2_SHIFT)
#define MP2_DFP_PGRAM_RAM2_CNTL_SET_MEM_PG_DLY_RAM2(mp2_dfp_pgram_ram2_cntl_reg, mem_pg_dly_ram2) \
     mp2_dfp_pgram_ram2_cntl_reg = (mp2_dfp_pgram_ram2_cntl_reg & ~MP2_DFP_PGRAM_RAM2_CNTL_MEM_PG_DLY_RAM2_MASK) | (mem_pg_dly_ram2 << MP2_DFP_PGRAM_RAM2_CNTL_MEM_PG_DLY_RAM2_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfp_pgram_ram2_cntl_t {
          unsigned int mem_sd_ram2                    : MP2_DFP_PGRAM_RAM2_CNTL_MEM_SD_RAM2_SIZE;
          unsigned int mem_rop_ram2                   : MP2_DFP_PGRAM_RAM2_CNTL_MEM_ROP_RAM2_SIZE;
          unsigned int mem_deep_sleep_en_ram2         : MP2_DFP_PGRAM_RAM2_CNTL_MEM_DEEP_SLEEP_EN_RAM2_SIZE;
          unsigned int mem_deep_sleep_status_ram2     : MP2_DFP_PGRAM_RAM2_CNTL_MEM_DEEP_SLEEP_STATUS_RAM2_SIZE;
          unsigned int mem_light_sleep_en_ram2        : MP2_DFP_PGRAM_RAM2_CNTL_MEM_LIGHT_SLEEP_EN_RAM2_SIZE;
          unsigned int mem_light_sleep_status_ram2    : MP2_DFP_PGRAM_RAM2_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM2_SIZE;
          unsigned int                                : 2;
          unsigned int mem_sleep_timeout_ram2         : MP2_DFP_PGRAM_RAM2_CNTL_MEM_SLEEP_TIMEOUT_RAM2_SIZE;
          unsigned int mem_pg_dly_ram2                : MP2_DFP_PGRAM_RAM2_CNTL_MEM_PG_DLY_RAM2_SIZE;
          unsigned int                                : 8;
     } mp2_dfp_pgram_ram2_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfp_pgram_ram2_cntl_t {
          unsigned int                                : 8;
          unsigned int mem_pg_dly_ram2                : MP2_DFP_PGRAM_RAM2_CNTL_MEM_PG_DLY_RAM2_SIZE;
          unsigned int mem_sleep_timeout_ram2         : MP2_DFP_PGRAM_RAM2_CNTL_MEM_SLEEP_TIMEOUT_RAM2_SIZE;
          unsigned int                                : 2;
          unsigned int mem_light_sleep_status_ram2    : MP2_DFP_PGRAM_RAM2_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM2_SIZE;
          unsigned int mem_light_sleep_en_ram2        : MP2_DFP_PGRAM_RAM2_CNTL_MEM_LIGHT_SLEEP_EN_RAM2_SIZE;
          unsigned int mem_deep_sleep_status_ram2     : MP2_DFP_PGRAM_RAM2_CNTL_MEM_DEEP_SLEEP_STATUS_RAM2_SIZE;
          unsigned int mem_deep_sleep_en_ram2         : MP2_DFP_PGRAM_RAM2_CNTL_MEM_DEEP_SLEEP_EN_RAM2_SIZE;
          unsigned int mem_rop_ram2                   : MP2_DFP_PGRAM_RAM2_CNTL_MEM_ROP_RAM2_SIZE;
          unsigned int mem_sd_ram2                    : MP2_DFP_PGRAM_RAM2_CNTL_MEM_SD_RAM2_SIZE;
     } mp2_dfp_pgram_ram2_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfp_pgram_ram2_cntl_t f;
} mp2_dfp_pgram_ram2_cntl_u;


/*
 * MP2_DFP_PGRAM_RAM3_CNTL struct
 */

#define MP2_DFP_PGRAM_RAM3_CNTL_REG_SIZE 32
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_SD_RAM3_SIZE 1
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_ROP_RAM3_SIZE 1
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_DEEP_SLEEP_EN_RAM3_SIZE 1
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_DEEP_SLEEP_STATUS_RAM3_SIZE 1
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_LIGHT_SLEEP_EN_RAM3_SIZE 1
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM3_SIZE 1
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_SLEEP_TIMEOUT_RAM3_SIZE 8
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_PG_DLY_RAM3_SIZE 8

#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_SD_RAM3_SHIFT 0
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_ROP_RAM3_SHIFT 1
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_DEEP_SLEEP_EN_RAM3_SHIFT 2
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_DEEP_SLEEP_STATUS_RAM3_SHIFT 3
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_LIGHT_SLEEP_EN_RAM3_SHIFT 4
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM3_SHIFT 5
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_SLEEP_TIMEOUT_RAM3_SHIFT 8
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_PG_DLY_RAM3_SHIFT 16

#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_SD_RAM3_MASK 0x1
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_ROP_RAM3_MASK 0x2
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_DEEP_SLEEP_EN_RAM3_MASK 0x4
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_DEEP_SLEEP_STATUS_RAM3_MASK 0x8
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_LIGHT_SLEEP_EN_RAM3_MASK 0x10
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM3_MASK 0x20
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_SLEEP_TIMEOUT_RAM3_MASK 0xff00
#define MP2_DFP_PGRAM_RAM3_CNTL_MEM_PG_DLY_RAM3_MASK 0xff0000

#define MP2_DFP_PGRAM_RAM3_CNTL_MASK \
     (MP2_DFP_PGRAM_RAM3_CNTL_MEM_SD_RAM3_MASK | \
      MP2_DFP_PGRAM_RAM3_CNTL_MEM_ROP_RAM3_MASK | \
      MP2_DFP_PGRAM_RAM3_CNTL_MEM_DEEP_SLEEP_EN_RAM3_MASK | \
      MP2_DFP_PGRAM_RAM3_CNTL_MEM_DEEP_SLEEP_STATUS_RAM3_MASK | \
      MP2_DFP_PGRAM_RAM3_CNTL_MEM_LIGHT_SLEEP_EN_RAM3_MASK | \
      MP2_DFP_PGRAM_RAM3_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM3_MASK | \
      MP2_DFP_PGRAM_RAM3_CNTL_MEM_SLEEP_TIMEOUT_RAM3_MASK | \
      MP2_DFP_PGRAM_RAM3_CNTL_MEM_PG_DLY_RAM3_MASK)

#define MP2_DFP_PGRAM_RAM3_CNTL_DEFAULT 0x0010102a

#define MP2_DFP_PGRAM_RAM3_CNTL_GET_MEM_SD_RAM3(mp2_dfp_pgram_ram3_cntl) \
     ((mp2_dfp_pgram_ram3_cntl & MP2_DFP_PGRAM_RAM3_CNTL_MEM_SD_RAM3_MASK) >> MP2_DFP_PGRAM_RAM3_CNTL_MEM_SD_RAM3_SHIFT)
#define MP2_DFP_PGRAM_RAM3_CNTL_GET_MEM_ROP_RAM3(mp2_dfp_pgram_ram3_cntl) \
     ((mp2_dfp_pgram_ram3_cntl & MP2_DFP_PGRAM_RAM3_CNTL_MEM_ROP_RAM3_MASK) >> MP2_DFP_PGRAM_RAM3_CNTL_MEM_ROP_RAM3_SHIFT)
#define MP2_DFP_PGRAM_RAM3_CNTL_GET_MEM_DEEP_SLEEP_EN_RAM3(mp2_dfp_pgram_ram3_cntl) \
     ((mp2_dfp_pgram_ram3_cntl & MP2_DFP_PGRAM_RAM3_CNTL_MEM_DEEP_SLEEP_EN_RAM3_MASK) >> MP2_DFP_PGRAM_RAM3_CNTL_MEM_DEEP_SLEEP_EN_RAM3_SHIFT)
#define MP2_DFP_PGRAM_RAM3_CNTL_GET_MEM_DEEP_SLEEP_STATUS_RAM3(mp2_dfp_pgram_ram3_cntl) \
     ((mp2_dfp_pgram_ram3_cntl & MP2_DFP_PGRAM_RAM3_CNTL_MEM_DEEP_SLEEP_STATUS_RAM3_MASK) >> MP2_DFP_PGRAM_RAM3_CNTL_MEM_DEEP_SLEEP_STATUS_RAM3_SHIFT)
#define MP2_DFP_PGRAM_RAM3_CNTL_GET_MEM_LIGHT_SLEEP_EN_RAM3(mp2_dfp_pgram_ram3_cntl) \
     ((mp2_dfp_pgram_ram3_cntl & MP2_DFP_PGRAM_RAM3_CNTL_MEM_LIGHT_SLEEP_EN_RAM3_MASK) >> MP2_DFP_PGRAM_RAM3_CNTL_MEM_LIGHT_SLEEP_EN_RAM3_SHIFT)
#define MP2_DFP_PGRAM_RAM3_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_RAM3(mp2_dfp_pgram_ram3_cntl) \
     ((mp2_dfp_pgram_ram3_cntl & MP2_DFP_PGRAM_RAM3_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM3_MASK) >> MP2_DFP_PGRAM_RAM3_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM3_SHIFT)
#define MP2_DFP_PGRAM_RAM3_CNTL_GET_MEM_SLEEP_TIMEOUT_RAM3(mp2_dfp_pgram_ram3_cntl) \
     ((mp2_dfp_pgram_ram3_cntl & MP2_DFP_PGRAM_RAM3_CNTL_MEM_SLEEP_TIMEOUT_RAM3_MASK) >> MP2_DFP_PGRAM_RAM3_CNTL_MEM_SLEEP_TIMEOUT_RAM3_SHIFT)
#define MP2_DFP_PGRAM_RAM3_CNTL_GET_MEM_PG_DLY_RAM3(mp2_dfp_pgram_ram3_cntl) \
     ((mp2_dfp_pgram_ram3_cntl & MP2_DFP_PGRAM_RAM3_CNTL_MEM_PG_DLY_RAM3_MASK) >> MP2_DFP_PGRAM_RAM3_CNTL_MEM_PG_DLY_RAM3_SHIFT)

#define MP2_DFP_PGRAM_RAM3_CNTL_SET_MEM_SD_RAM3(mp2_dfp_pgram_ram3_cntl_reg, mem_sd_ram3) \
     mp2_dfp_pgram_ram3_cntl_reg = (mp2_dfp_pgram_ram3_cntl_reg & ~MP2_DFP_PGRAM_RAM3_CNTL_MEM_SD_RAM3_MASK) | (mem_sd_ram3 << MP2_DFP_PGRAM_RAM3_CNTL_MEM_SD_RAM3_SHIFT)
#define MP2_DFP_PGRAM_RAM3_CNTL_SET_MEM_ROP_RAM3(mp2_dfp_pgram_ram3_cntl_reg, mem_rop_ram3) \
     mp2_dfp_pgram_ram3_cntl_reg = (mp2_dfp_pgram_ram3_cntl_reg & ~MP2_DFP_PGRAM_RAM3_CNTL_MEM_ROP_RAM3_MASK) | (mem_rop_ram3 << MP2_DFP_PGRAM_RAM3_CNTL_MEM_ROP_RAM3_SHIFT)
#define MP2_DFP_PGRAM_RAM3_CNTL_SET_MEM_DEEP_SLEEP_EN_RAM3(mp2_dfp_pgram_ram3_cntl_reg, mem_deep_sleep_en_ram3) \
     mp2_dfp_pgram_ram3_cntl_reg = (mp2_dfp_pgram_ram3_cntl_reg & ~MP2_DFP_PGRAM_RAM3_CNTL_MEM_DEEP_SLEEP_EN_RAM3_MASK) | (mem_deep_sleep_en_ram3 << MP2_DFP_PGRAM_RAM3_CNTL_MEM_DEEP_SLEEP_EN_RAM3_SHIFT)
#define MP2_DFP_PGRAM_RAM3_CNTL_SET_MEM_DEEP_SLEEP_STATUS_RAM3(mp2_dfp_pgram_ram3_cntl_reg, mem_deep_sleep_status_ram3) \
     mp2_dfp_pgram_ram3_cntl_reg = (mp2_dfp_pgram_ram3_cntl_reg & ~MP2_DFP_PGRAM_RAM3_CNTL_MEM_DEEP_SLEEP_STATUS_RAM3_MASK) | (mem_deep_sleep_status_ram3 << MP2_DFP_PGRAM_RAM3_CNTL_MEM_DEEP_SLEEP_STATUS_RAM3_SHIFT)
#define MP2_DFP_PGRAM_RAM3_CNTL_SET_MEM_LIGHT_SLEEP_EN_RAM3(mp2_dfp_pgram_ram3_cntl_reg, mem_light_sleep_en_ram3) \
     mp2_dfp_pgram_ram3_cntl_reg = (mp2_dfp_pgram_ram3_cntl_reg & ~MP2_DFP_PGRAM_RAM3_CNTL_MEM_LIGHT_SLEEP_EN_RAM3_MASK) | (mem_light_sleep_en_ram3 << MP2_DFP_PGRAM_RAM3_CNTL_MEM_LIGHT_SLEEP_EN_RAM3_SHIFT)
#define MP2_DFP_PGRAM_RAM3_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_RAM3(mp2_dfp_pgram_ram3_cntl_reg, mem_light_sleep_status_ram3) \
     mp2_dfp_pgram_ram3_cntl_reg = (mp2_dfp_pgram_ram3_cntl_reg & ~MP2_DFP_PGRAM_RAM3_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM3_MASK) | (mem_light_sleep_status_ram3 << MP2_DFP_PGRAM_RAM3_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM3_SHIFT)
#define MP2_DFP_PGRAM_RAM3_CNTL_SET_MEM_SLEEP_TIMEOUT_RAM3(mp2_dfp_pgram_ram3_cntl_reg, mem_sleep_timeout_ram3) \
     mp2_dfp_pgram_ram3_cntl_reg = (mp2_dfp_pgram_ram3_cntl_reg & ~MP2_DFP_PGRAM_RAM3_CNTL_MEM_SLEEP_TIMEOUT_RAM3_MASK) | (mem_sleep_timeout_ram3 << MP2_DFP_PGRAM_RAM3_CNTL_MEM_SLEEP_TIMEOUT_RAM3_SHIFT)
#define MP2_DFP_PGRAM_RAM3_CNTL_SET_MEM_PG_DLY_RAM3(mp2_dfp_pgram_ram3_cntl_reg, mem_pg_dly_ram3) \
     mp2_dfp_pgram_ram3_cntl_reg = (mp2_dfp_pgram_ram3_cntl_reg & ~MP2_DFP_PGRAM_RAM3_CNTL_MEM_PG_DLY_RAM3_MASK) | (mem_pg_dly_ram3 << MP2_DFP_PGRAM_RAM3_CNTL_MEM_PG_DLY_RAM3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfp_pgram_ram3_cntl_t {
          unsigned int mem_sd_ram3                    : MP2_DFP_PGRAM_RAM3_CNTL_MEM_SD_RAM3_SIZE;
          unsigned int mem_rop_ram3                   : MP2_DFP_PGRAM_RAM3_CNTL_MEM_ROP_RAM3_SIZE;
          unsigned int mem_deep_sleep_en_ram3         : MP2_DFP_PGRAM_RAM3_CNTL_MEM_DEEP_SLEEP_EN_RAM3_SIZE;
          unsigned int mem_deep_sleep_status_ram3     : MP2_DFP_PGRAM_RAM3_CNTL_MEM_DEEP_SLEEP_STATUS_RAM3_SIZE;
          unsigned int mem_light_sleep_en_ram3        : MP2_DFP_PGRAM_RAM3_CNTL_MEM_LIGHT_SLEEP_EN_RAM3_SIZE;
          unsigned int mem_light_sleep_status_ram3    : MP2_DFP_PGRAM_RAM3_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM3_SIZE;
          unsigned int                                : 2;
          unsigned int mem_sleep_timeout_ram3         : MP2_DFP_PGRAM_RAM3_CNTL_MEM_SLEEP_TIMEOUT_RAM3_SIZE;
          unsigned int mem_pg_dly_ram3                : MP2_DFP_PGRAM_RAM3_CNTL_MEM_PG_DLY_RAM3_SIZE;
          unsigned int                                : 8;
     } mp2_dfp_pgram_ram3_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfp_pgram_ram3_cntl_t {
          unsigned int                                : 8;
          unsigned int mem_pg_dly_ram3                : MP2_DFP_PGRAM_RAM3_CNTL_MEM_PG_DLY_RAM3_SIZE;
          unsigned int mem_sleep_timeout_ram3         : MP2_DFP_PGRAM_RAM3_CNTL_MEM_SLEEP_TIMEOUT_RAM3_SIZE;
          unsigned int                                : 2;
          unsigned int mem_light_sleep_status_ram3    : MP2_DFP_PGRAM_RAM3_CNTL_MEM_LIGHT_SLEEP_STATUS_RAM3_SIZE;
          unsigned int mem_light_sleep_en_ram3        : MP2_DFP_PGRAM_RAM3_CNTL_MEM_LIGHT_SLEEP_EN_RAM3_SIZE;
          unsigned int mem_deep_sleep_status_ram3     : MP2_DFP_PGRAM_RAM3_CNTL_MEM_DEEP_SLEEP_STATUS_RAM3_SIZE;
          unsigned int mem_deep_sleep_en_ram3         : MP2_DFP_PGRAM_RAM3_CNTL_MEM_DEEP_SLEEP_EN_RAM3_SIZE;
          unsigned int mem_rop_ram3                   : MP2_DFP_PGRAM_RAM3_CNTL_MEM_ROP_RAM3_SIZE;
          unsigned int mem_sd_ram3                    : MP2_DFP_PGRAM_RAM3_CNTL_MEM_SD_RAM3_SIZE;
     } mp2_dfp_pgram_ram3_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfp_pgram_ram3_cntl_t f;
} mp2_dfp_pgram_ram3_cntl_u;


/*
 * MP2_PG_PUB_STATUS struct
 */

#define MP2_PG_PUB_STATUS_REG_SIZE     32
#define MP2_PG_PUB_STATUS_PG_IDLE_SIZE 1
#define MP2_PG_PUB_STATUS_SAFE_IDLE_SIZE 1
#define MP2_PG_PUB_STATUS_ACTIVE_SIZE  1

#define MP2_PG_PUB_STATUS_PG_IDLE_SHIFT 0
#define MP2_PG_PUB_STATUS_SAFE_IDLE_SHIFT 1
#define MP2_PG_PUB_STATUS_ACTIVE_SHIFT 3

#define MP2_PG_PUB_STATUS_PG_IDLE_MASK 0x1
#define MP2_PG_PUB_STATUS_SAFE_IDLE_MASK 0x2
#define MP2_PG_PUB_STATUS_ACTIVE_MASK  0x8

#define MP2_PG_PUB_STATUS_MASK \
     (MP2_PG_PUB_STATUS_PG_IDLE_MASK | \
      MP2_PG_PUB_STATUS_SAFE_IDLE_MASK | \
      MP2_PG_PUB_STATUS_ACTIVE_MASK)

#define MP2_PG_PUB_STATUS_DEFAULT      0x00000000

#define MP2_PG_PUB_STATUS_GET_PG_IDLE(mp2_pg_pub_status) \
     ((mp2_pg_pub_status & MP2_PG_PUB_STATUS_PG_IDLE_MASK) >> MP2_PG_PUB_STATUS_PG_IDLE_SHIFT)
#define MP2_PG_PUB_STATUS_GET_SAFE_IDLE(mp2_pg_pub_status) \
     ((mp2_pg_pub_status & MP2_PG_PUB_STATUS_SAFE_IDLE_MASK) >> MP2_PG_PUB_STATUS_SAFE_IDLE_SHIFT)
#define MP2_PG_PUB_STATUS_GET_ACTIVE(mp2_pg_pub_status) \
     ((mp2_pg_pub_status & MP2_PG_PUB_STATUS_ACTIVE_MASK) >> MP2_PG_PUB_STATUS_ACTIVE_SHIFT)

#define MP2_PG_PUB_STATUS_SET_PG_IDLE(mp2_pg_pub_status_reg, pg_idle) \
     mp2_pg_pub_status_reg = (mp2_pg_pub_status_reg & ~MP2_PG_PUB_STATUS_PG_IDLE_MASK) | (pg_idle << MP2_PG_PUB_STATUS_PG_IDLE_SHIFT)
#define MP2_PG_PUB_STATUS_SET_SAFE_IDLE(mp2_pg_pub_status_reg, safe_idle) \
     mp2_pg_pub_status_reg = (mp2_pg_pub_status_reg & ~MP2_PG_PUB_STATUS_SAFE_IDLE_MASK) | (safe_idle << MP2_PG_PUB_STATUS_SAFE_IDLE_SHIFT)
#define MP2_PG_PUB_STATUS_SET_ACTIVE(mp2_pg_pub_status_reg, active) \
     mp2_pg_pub_status_reg = (mp2_pg_pub_status_reg & ~MP2_PG_PUB_STATUS_ACTIVE_MASK) | (active << MP2_PG_PUB_STATUS_ACTIVE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pg_pub_status_t {
          unsigned int pg_idle                        : MP2_PG_PUB_STATUS_PG_IDLE_SIZE;
          unsigned int safe_idle                      : MP2_PG_PUB_STATUS_SAFE_IDLE_SIZE;
          unsigned int                                : 1;
          unsigned int active                         : MP2_PG_PUB_STATUS_ACTIVE_SIZE;
          unsigned int                                : 28;
     } mp2_pg_pub_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pg_pub_status_t {
          unsigned int                                : 28;
          unsigned int active                         : MP2_PG_PUB_STATUS_ACTIVE_SIZE;
          unsigned int                                : 1;
          unsigned int safe_idle                      : MP2_PG_PUB_STATUS_SAFE_IDLE_SIZE;
          unsigned int pg_idle                        : MP2_PG_PUB_STATUS_PG_IDLE_SIZE;
     } mp2_pg_pub_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pg_pub_status_t f;
} mp2_pg_pub_status_u;


#endif


