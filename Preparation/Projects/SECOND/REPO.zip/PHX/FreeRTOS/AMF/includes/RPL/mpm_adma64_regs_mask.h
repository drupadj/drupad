// Copyright (c) 1994 - 2021 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MPM_ADMA64_REGS_MASK_H)
#define _MPM_ADMA64_REGS_MASK_H

/*
 *    mpm_adma64_regs_mask.h   
 *
 *    Register Spec Release:  <unknown>
 *
 *
 *      (c) 2000 ATI Technologies Inc.  (unpublished)
 *
 *       All rights reserved.  This notice is intended as a precaution against
 *     inadvertent publication and does not imply publication or any waiver
 *      of confidentiality.  The year included in the foregoing notice is the
 *     year of creation of the work.
 *
 */

/*******************************************************
 * Read and Write Masks
 *******************************************************/

#define mpM_Adma64Cmd_Queue_Priority0_READ_MASK 0x000001ff
#define mpM_Adma64Cmd_Queue_Priority0_WRITE_MASK 0x000001ff

#define mpM_Adma64ReqID_Config0_READ_MASK 0x000001ff
#define mpM_Adma64ReqID_Config0_WRITE_MASK 0x000001ff

#define mpM_Adma64Module_Reset_READ_MASK 0x00000000
#define mpM_Adma64Module_Reset_WRITE_MASK 0x0000fc08

#define mpM_Adma64Cmd_Timeout_READ_MASK 0xffffffff
#define mpM_Adma64Cmd_Timeout_WRITE_MASK 0xffffffff

#define mpM_Adma64Cmd_Timeout_Granularity_READ_MASK 0xffffffff
#define mpM_Adma64Cmd_Timeout_Granularity_WRITE_MASK 0xffffffff

#define mpM_Adma64Memory_Deep_Sleep_Enable_READ_MASK 0x00007fff
#define mpM_Adma64Memory_Deep_Sleep_Enable_WRITE_MASK 0x00007fff

#define mpM_Adma64Memory_Deep_Sleep_Status_READ_MASK 0x000000ff
#define mpM_Adma64Memory_Deep_Sleep_Status_WRITE_MASK 0x00000000

#define mpM_Adma64Clock_Gating_Control_READ_MASK 0x000007ff
#define mpM_Adma64Clock_Gating_Control_WRITE_MASK 0x000007ff

#define mpM_Adma64Version_READ_MASK    0x000f803f
#define mpM_Adma64Version_WRITE_MASK   0x00000000

#define mpM_Adma64Vqd0_Control_READ_MASK 0xffff00ff
#define mpM_Adma64Vqd0_Control_WRITE_MASK 0xffff00fd

#define mpM_Adma64Vqd0_Tail_Lo_READ_MASK 0xffffffff
#define mpM_Adma64Vqd0_Tail_Lo_WRITE_MASK 0xffffffff

#define mpM_Adma64Vqd0_Head_Lo_READ_MASK 0xffffffff
#define mpM_Adma64Vqd0_Head_Lo_WRITE_MASK 0xffffffff

#define mpM_Adma64Cmd_Interrupt_Enable_Q0_READ_MASK 0x0000000f
#define mpM_Adma64Cmd_Interrupt_Enable_Q0_WRITE_MASK 0x0000000f

#define mpM_Adma64Cmd_Interrupt_Status_Q0_READ_MASK 0x0000000f
#define mpM_Adma64Cmd_Interrupt_Status_Q0_WRITE_MASK 0x0000000f

#define mpM_Adma64Cmd_Status_Q0_READ_MASK 0x00001fff
#define mpM_Adma64Cmd_Status_Q0_WRITE_MASK 0x00000000

#define mpM_Adma64Cmd_Int_Status_Q0_READ_MASK 0x0000007f
#define mpM_Adma64Cmd_Int_Status_Q0_WRITE_MASK 0x00000000

#define mpM_Adma64Cmd_DMA_Status_Q0_READ_MASK 0x0007ffff
#define mpM_Adma64Cmd_DMA_Status_Q0_WRITE_MASK 0x00000000

#define mpM_Adma64Cmd_DMA_Read_Status_Q0_READ_MASK 0xffffffff
#define mpM_Adma64Cmd_DMA_Read_Status_Q0_WRITE_MASK 0x00000000

#define mpM_Adma64Cmd_DMA_Write_Status_Q0_READ_MASK 0xffffffff
#define mpM_Adma64Cmd_DMA_Write_Status_Q0_WRITE_MASK 0x00000000

#define mpM_Adma64Cmd_Abort_Q0_READ_MASK 0x00000000
#define mpM_Adma64Cmd_Abort_Q0_WRITE_MASK 0x8003ffff

#define mpM_Adma64Cmd_AxCACHE_Q0_READ_MASK 0x00000fff
#define mpM_Adma64Cmd_AxCACHE_Q0_WRITE_MASK 0x00000fff

#define mpM_Adma64Vqd1_Control_READ_MASK 0xffff00ff
#define mpM_Adma64Vqd1_Control_WRITE_MASK 0xffff00fd

#define mpM_Adma64Vqd1_Tail_Lo_READ_MASK 0xffffffff
#define mpM_Adma64Vqd1_Tail_Lo_WRITE_MASK 0xffffffff

#define mpM_Adma64Vqd1_Head_Lo_READ_MASK 0xffffffff
#define mpM_Adma64Vqd1_Head_Lo_WRITE_MASK 0xffffffff

#define mpM_Adma64Cmd_Interrupt_Enable_Q1_READ_MASK 0x0000000f
#define mpM_Adma64Cmd_Interrupt_Enable_Q1_WRITE_MASK 0x0000000f

#define mpM_Adma64Cmd_Interrupt_Status_Q1_READ_MASK 0x0000000f
#define mpM_Adma64Cmd_Interrupt_Status_Q1_WRITE_MASK 0x0000000f

#define mpM_Adma64Cmd_Status_Q1_READ_MASK 0x00001fff
#define mpM_Adma64Cmd_Status_Q1_WRITE_MASK 0x00000000

#define mpM_Adma64Cmd_Int_Status_Q1_READ_MASK 0x0000007f
#define mpM_Adma64Cmd_Int_Status_Q1_WRITE_MASK 0x00000000

#define mpM_Adma64Cmd_DMA_Status_Q1_READ_MASK 0x0007ffff
#define mpM_Adma64Cmd_DMA_Status_Q1_WRITE_MASK 0x00000000

#define mpM_Adma64Cmd_DMA_Read_Status_Q1_READ_MASK 0xffffffff
#define mpM_Adma64Cmd_DMA_Read_Status_Q1_WRITE_MASK 0x00000000

#define mpM_Adma64Cmd_DMA_Write_Status_Q1_READ_MASK 0xffffffff
#define mpM_Adma64Cmd_DMA_Write_Status_Q1_WRITE_MASK 0x00000000

#define mpM_Adma64Cmd_Abort_Q1_READ_MASK 0x00000000
#define mpM_Adma64Cmd_Abort_Q1_WRITE_MASK 0x8003ffff

#define mpM_Adma64Cmd_AxCACHE_Q1_READ_MASK 0x00000fff
#define mpM_Adma64Cmd_AxCACHE_Q1_WRITE_MASK 0x00000fff

#define mpM_Adma64Vqd2_Control_READ_MASK 0xffff00ff
#define mpM_Adma64Vqd2_Control_WRITE_MASK 0xffff00fd

#define mpM_Adma64Vqd2_Tail_Lo_READ_MASK 0xffffffff
#define mpM_Adma64Vqd2_Tail_Lo_WRITE_MASK 0xffffffff

#define mpM_Adma64Vqd2_Head_Lo_READ_MASK 0xffffffff
#define mpM_Adma64Vqd2_Head_Lo_WRITE_MASK 0xffffffff

#define mpM_Adma64Cmd_Interrupt_Enable_Q2_READ_MASK 0x0000000f
#define mpM_Adma64Cmd_Interrupt_Enable_Q2_WRITE_MASK 0x0000000f

#define mpM_Adma64Cmd_Interrupt_Status_Q2_READ_MASK 0x0000000f
#define mpM_Adma64Cmd_Interrupt_Status_Q2_WRITE_MASK 0x0000000f

#define mpM_Adma64Cmd_Status_Q2_READ_MASK 0x00001fff
#define mpM_Adma64Cmd_Status_Q2_WRITE_MASK 0x00000000

#define mpM_Adma64Cmd_Int_Status_Q2_READ_MASK 0x0000007f
#define mpM_Adma64Cmd_Int_Status_Q2_WRITE_MASK 0x00000000

#define mpM_Adma64Cmd_DMA_Status_Q2_READ_MASK 0x0007ffff
#define mpM_Adma64Cmd_DMA_Status_Q2_WRITE_MASK 0x00000000

#define mpM_Adma64Cmd_DMA_Read_Status_Q2_READ_MASK 0xffffffff
#define mpM_Adma64Cmd_DMA_Read_Status_Q2_WRITE_MASK 0x00000000

#define mpM_Adma64Cmd_DMA_Write_Status_Q2_READ_MASK 0xffffffff
#define mpM_Adma64Cmd_DMA_Write_Status_Q2_WRITE_MASK 0x00000000

#define mpM_Adma64Cmd_Abort_Q2_READ_MASK 0x00000000
#define mpM_Adma64Cmd_Abort_Q2_WRITE_MASK 0x8003ffff

#define mpM_Adma64Cmd_AxCACHE_Q2_READ_MASK 0x00000fff
#define mpM_Adma64Cmd_AxCACHE_Q2_WRITE_MASK 0x00000fff

#endif


