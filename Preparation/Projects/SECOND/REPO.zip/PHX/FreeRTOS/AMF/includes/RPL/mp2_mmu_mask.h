// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MP2_MMU_MASK_H)
#define _MP2_MMU_MASK_H

/*****************************************************************************************************************
 *
 *	mp2_mmu_mask.h
 *
 *	Register Spec Release:  <unknown>
*
*	 (c) 2000 ATI Technologies Inc.  (unpublished)
*
*	 All rights reserved.  This notice is intended as a precaution against
*	 inadvertent publication and does not imply publication or any waiver
*	 of confidentiality.  The year included in the foregoing notice is the
*	 year of creation of the work.
*
 *****************************************************************************************************************/

/*******************************************************
 * Read and Write Masks
 *******************************************************/

#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_READ_MASK 0xffffffff
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_WRITE_MASK 0x0

#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_READ_MASK 0xc1ffffff
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_WRITE_MASK 0xc0000000

#define MP2_MMU_MISC_CNTL_READ_MASK    0xff000d
#define MP2_MMU_MISC_CNTL_WRITE_MASK   0x3f000d

#define MP2_MMU_ACCESS_ERR_LOG_READ_MASK 0xfffff1f
#define MP2_MMU_ACCESS_ERR_LOG_WRITE_MASK 0x18

#define MP2_MMU_SRAM_UNSECURE_BAR_READ_MASK 0xffffffff
#define MP2_MMU_SRAM_UNSECURE_BAR_WRITE_MASK 0xffffffff

#define MP2_MMU_SCRATCH_0_READ_MASK    0xffffffff
#define MP2_MMU_SCRATCH_0_WRITE_MASK   0xffffffff

#define MP2_MMU_SCRATCH_1_READ_MASK    0xffffffff
#define MP2_MMU_SCRATCH_1_WRITE_MASK   0xffffffff

#define MP2_MMU_SCRATCH_2_READ_MASK    0xffffffff
#define MP2_MMU_SCRATCH_2_WRITE_MASK   0xffffffff

#define MP2_MMU_SCRATCH_3_READ_MASK    0xffffffff
#define MP2_MMU_SCRATCH_3_WRITE_MASK   0xffffffff

#define MP2_MMU_SCRATCH_4_READ_MASK    0xffffffff
#define MP2_MMU_SCRATCH_4_WRITE_MASK   0xffffffff

#define MP2_MMU_SCRATCH_5_READ_MASK    0xffffffff
#define MP2_MMU_SCRATCH_5_WRITE_MASK   0xffffffff

#define MP2_MMU_SCRATCH_6_READ_MASK    0xffffffff
#define MP2_MMU_SCRATCH_6_WRITE_MASK   0xffffffff

#define MP2_MMU_SCRATCH_7_READ_MASK    0xffffffff
#define MP2_MMU_SCRATCH_7_WRITE_MASK   0xffffffff

#define MP2_PMI_INITID_CONFIG_READ_MASK 0x3
#define MP2_PMI_INITID_CONFIG_WRITE_MASK 0x3

#define MP2_PMI_INITID_0_READ_MASK     0x103ff
#define MP2_PMI_INITID_0_WRITE_MASK    0x103ff

#define MP2_PMI_INITID_1_READ_MASK     0x103ff
#define MP2_PMI_INITID_1_WRITE_MASK    0x103ff

#define MP2_PMI_INITID_2_READ_MASK     0x103ff
#define MP2_PMI_INITID_2_WRITE_MASK    0x103ff

#define MP2_PMI_INITID_3_READ_MASK     0x103ff
#define MP2_PMI_INITID_3_WRITE_MASK    0x103ff

#define MP2_PMI_INITID_4_READ_MASK     0x103ff
#define MP2_PMI_INITID_4_WRITE_MASK    0x103ff

#define MP2_PMI_INITID_5_READ_MASK     0x103ff
#define MP2_PMI_INITID_5_WRITE_MASK    0x103ff

#define MP2_PMI_INITID_6_READ_MASK     0x103ff
#define MP2_PMI_INITID_6_WRITE_MASK    0x103ff

#define MP2_PMI_INITID_7_READ_MASK     0x103ff
#define MP2_PMI_INITID_7_WRITE_MASK    0x103ff

#define MP2_PMI_INITID_8_READ_MASK     0x103ff
#define MP2_PMI_INITID_8_WRITE_MASK    0x103ff

#define MP2_PMI_INITID_9_READ_MASK     0x103ff
#define MP2_PMI_INITID_9_WRITE_MASK    0x103ff

#define MP2_PMI_INITID_10_READ_MASK    0x103ff
#define MP2_PMI_INITID_10_WRITE_MASK   0x103ff

#define MP2_PMI_INITID_11_READ_MASK    0x103ff
#define MP2_PMI_INITID_11_WRITE_MASK   0x103ff

#define MP2_PMI_INITID_12_READ_MASK    0x103ff
#define MP2_PMI_INITID_12_WRITE_MASK   0x103ff

#define MP2_PMI_INITID_13_READ_MASK    0x103ff
#define MP2_PMI_INITID_13_WRITE_MASK   0x103ff

#define MP2_PMI_INITID_14_READ_MASK    0x103ff
#define MP2_PMI_INITID_14_WRITE_MASK   0x103ff

#define MP2_PMI_INITID_15_READ_MASK    0x103ff
#define MP2_PMI_INITID_15_WRITE_MASK   0x103ff

#define MP2_PMI_0_RELOAD_READ_MASK     0x0
#define MP2_PMI_0_RELOAD_WRITE_MASK    0x1

#define MP2_PMI_0_START_READ_MASK      0x8003ffff
#define MP2_PMI_0_START_WRITE_MASK     0x8003ffff

#define MP2_PMI_0_FIFO_READ_MASK       0xf0fff
#define MP2_PMI_0_FIFO_WRITE_MASK      0x30f0fff

#define MP2_POSTCODE_CONFIG_READ_MASK  0x3
#define MP2_POSTCODE_CONFIG_WRITE_MASK 0x3

#define MP2_POSTCODE_IP_0_READ_MASK    0x1ff
#define MP2_POSTCODE_IP_0_WRITE_MASK   0x1ff

#define MP2_POSTCODE_FEATURE_0_READ_MASK 0x1ff
#define MP2_POSTCODE_FEATURE_0_WRITE_MASK 0x1ff

#define MP2_POSTCODE_IP_1_READ_MASK    0x1ff
#define MP2_POSTCODE_IP_1_WRITE_MASK   0x1ff

#define MP2_POSTCODE_FEATURE_1_READ_MASK 0x1ff
#define MP2_POSTCODE_FEATURE_1_WRITE_MASK 0x1ff

#define MP2_POSTCODE_IP_2_READ_MASK    0x1ff
#define MP2_POSTCODE_IP_2_WRITE_MASK   0x1ff

#define MP2_POSTCODE_FEATURE_2_READ_MASK 0x1ff
#define MP2_POSTCODE_FEATURE_2_WRITE_MASK 0x1ff

#define MP2_POSTCODE_IP_3_READ_MASK    0x1ff
#define MP2_POSTCODE_IP_3_WRITE_MASK   0x1ff

#define MP2_POSTCODE_FEATURE_3_READ_MASK 0x1ff
#define MP2_POSTCODE_FEATURE_3_WRITE_MASK 0x1ff

#define MP2_POSTCODE_IP_4_READ_MASK    0x1ff
#define MP2_POSTCODE_IP_4_WRITE_MASK   0x1ff

#define MP2_POSTCODE_FEATURE_4_READ_MASK 0x1ff
#define MP2_POSTCODE_FEATURE_4_WRITE_MASK 0x1ff

#define MP2_POSTCODE_IP_5_READ_MASK    0x1ff
#define MP2_POSTCODE_IP_5_WRITE_MASK   0x1ff

#define MP2_POSTCODE_FEATURE_5_READ_MASK 0x1ff
#define MP2_POSTCODE_FEATURE_5_WRITE_MASK 0x1ff

#define MP2_POSTCODE_IP_6_READ_MASK    0x1ff
#define MP2_POSTCODE_IP_6_WRITE_MASK   0x1ff

#define MP2_POSTCODE_FEATURE_6_READ_MASK 0x1ff
#define MP2_POSTCODE_FEATURE_6_WRITE_MASK 0x1ff

#define MP2_POSTCODE_IP_7_READ_MASK    0x1ff
#define MP2_POSTCODE_IP_7_WRITE_MASK   0x1ff

#define MP2_POSTCODE_FEATURE_7_READ_MASK 0x1ff
#define MP2_POSTCODE_FEATURE_7_WRITE_MASK 0x1ff

#define MP2_POSTCODE_IP_8_READ_MASK    0x1ff
#define MP2_POSTCODE_IP_8_WRITE_MASK   0x1ff

#define MP2_POSTCODE_FEATURE_8_READ_MASK 0x1ff
#define MP2_POSTCODE_FEATURE_8_WRITE_MASK 0x1ff

#define MP2_POSTCODE_IP_9_READ_MASK    0x1ff
#define MP2_POSTCODE_IP_9_WRITE_MASK   0x1ff

#define MP2_POSTCODE_FEATURE_9_READ_MASK 0x1ff
#define MP2_POSTCODE_FEATURE_9_WRITE_MASK 0x1ff

#define MP2_POSTCODE_IP_10_READ_MASK   0x1ff
#define MP2_POSTCODE_IP_10_WRITE_MASK  0x1ff

#define MP2_POSTCODE_FEATURE_10_READ_MASK 0x1ff
#define MP2_POSTCODE_FEATURE_10_WRITE_MASK 0x1ff

#define MP2_POSTCODE_IP_11_READ_MASK   0x1ff
#define MP2_POSTCODE_IP_11_WRITE_MASK  0x1ff

#define MP2_POSTCODE_FEATURE_11_READ_MASK 0x1ff
#define MP2_POSTCODE_FEATURE_11_WRITE_MASK 0x1ff

#define MP2_POSTCODE_IP_12_READ_MASK   0x1ff
#define MP2_POSTCODE_IP_12_WRITE_MASK  0x1ff

#define MP2_POSTCODE_FEATURE_12_READ_MASK 0x1ff
#define MP2_POSTCODE_FEATURE_12_WRITE_MASK 0x1ff

#define MP2_POSTCODE_IP_13_READ_MASK   0x1ff
#define MP2_POSTCODE_IP_13_WRITE_MASK  0x1ff

#define MP2_POSTCODE_FEATURE_13_READ_MASK 0x1ff
#define MP2_POSTCODE_FEATURE_13_WRITE_MASK 0x1ff

#define MP2_POSTCODE_IP_14_READ_MASK   0x1ff
#define MP2_POSTCODE_IP_14_WRITE_MASK  0x1ff

#define MP2_POSTCODE_FEATURE_14_READ_MASK 0x1ff
#define MP2_POSTCODE_FEATURE_14_WRITE_MASK 0x1ff

#define MP2_POSTCODE_IP_15_READ_MASK   0x1ff
#define MP2_POSTCODE_IP_15_WRITE_MASK  0x1ff

#define MP2_POSTCODE_FEATURE_15_READ_MASK 0x1ff
#define MP2_POSTCODE_FEATURE_15_WRITE_MASK 0x1ff

#define MP2_PMI_0_READ_MASK            0xffffffff
#define MP2_PMI_0_WRITE_MASK           0xffffffff

#define MP2_PMI_0_STATUS_READ_MASK     0x3
#define MP2_PMI_0_STATUS_WRITE_MASK    0x0

#define MP2_PMI_0_READ_POINTER_READ_MASK 0x3ffff
#define MP2_PMI_0_READ_POINTER_WRITE_MASK 0x0

#define MP2_PMI_0_WRITE_POINTER_READ_MASK 0x3ffff
#define MP2_PMI_0_WRITE_POINTER_WRITE_MASK 0x0

#endif


