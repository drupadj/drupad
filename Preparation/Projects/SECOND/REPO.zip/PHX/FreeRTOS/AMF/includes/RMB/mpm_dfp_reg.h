// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MPM_DFP_FIDDLE_H)
#define _MPM_DFP_FIDDLE_H

/*****************************************************************************************************************
 *
 *	mpm_dfp_reg.h
 *
 *	Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif


/*******************************************************
 * Values
 *******************************************************/


/*******************************************************
 * Structures
 *******************************************************/

/*
 * MPM_MPCLK_XBAR_CG_CTRL struct
 */

#define MPM_MPCLK_XBAR_CG_CTRL_REG_SIZE 32
#define MPM_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SIZE 1

#define MPM_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SHIFT 0

#define MPM_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_MASK 0x1

#define MPM_MPCLK_XBAR_CG_CTRL_MASK \
     (MPM_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_MASK)

#define MPM_MPCLK_XBAR_CG_CTRL_DEFAULT 0x00000000

#define MPM_MPCLK_XBAR_CG_CTRL_GET_MPCLK_XBAR_CACTIVE_EN(mpm_mpclk_xbar_cg_ctrl) \
     ((mpm_mpclk_xbar_cg_ctrl & MPM_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_MASK) >> MPM_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SHIFT)

#define MPM_MPCLK_XBAR_CG_CTRL_SET_MPCLK_XBAR_CACTIVE_EN(mpm_mpclk_xbar_cg_ctrl_reg, mpclk_xbar_cactive_en) \
     mpm_mpclk_xbar_cg_ctrl_reg = (mpm_mpclk_xbar_cg_ctrl_reg & ~MPM_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_MASK) | (mpclk_xbar_cactive_en << MPM_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_mpclk_xbar_cg_ctrl_t {
          unsigned int mpclk_xbar_cactive_en          : MPM_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SIZE;
          unsigned int                                : 31;
     } mpm_mpclk_xbar_cg_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_mpclk_xbar_cg_ctrl_t {
          unsigned int                                : 31;
          unsigned int mpclk_xbar_cactive_en          : MPM_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SIZE;
     } mpm_mpclk_xbar_cg_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_mpclk_xbar_cg_ctrl_t f;
} mpm_mpclk_xbar_cg_ctrl_u;


/*
 * MPM_MPCLK_XBAR_CG_EN struct
 */

#define MPM_MPCLK_XBAR_CG_EN_REG_SIZE  32
#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SIZE 1
#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_SIZE 1
#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SIZE 1
#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_SIZE 1

#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SHIFT 1
#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_SHIFT 2
#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SHIFT 3
#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_SHIFT 4

#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_MASK 0x2
#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_MASK 0x4
#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_MASK 0x8
#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_MASK 0x10

#define MPM_MPCLK_XBAR_CG_EN_MASK \
     (MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_MASK | \
      MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_MASK | \
      MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_MASK | \
      MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_MASK)

#define MPM_MPCLK_XBAR_CG_EN_DEFAULT   0x00000000

#define MPM_MPCLK_XBAR_CG_EN_GET_MPCLK_XBAR_CG_EN_0(mpm_mpclk_xbar_cg_en) \
     ((mpm_mpclk_xbar_cg_en & MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_MASK) >> MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SHIFT)
#define MPM_MPCLK_XBAR_CG_EN_GET_MPCLK_XBAR_CG_EN_1(mpm_mpclk_xbar_cg_en) \
     ((mpm_mpclk_xbar_cg_en & MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_MASK) >> MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_SHIFT)
#define MPM_MPCLK_XBAR_CG_EN_GET_MPCLK_XBAR_CG_OVERRIDE_0(mpm_mpclk_xbar_cg_en) \
     ((mpm_mpclk_xbar_cg_en & MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_MASK) >> MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SHIFT)
#define MPM_MPCLK_XBAR_CG_EN_GET_MPCLK_XBAR_CG_OVERRIDE_1(mpm_mpclk_xbar_cg_en) \
     ((mpm_mpclk_xbar_cg_en & MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_MASK) >> MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_SHIFT)

#define MPM_MPCLK_XBAR_CG_EN_SET_MPCLK_XBAR_CG_EN_0(mpm_mpclk_xbar_cg_en_reg, mpclk_xbar_cg_en_0) \
     mpm_mpclk_xbar_cg_en_reg = (mpm_mpclk_xbar_cg_en_reg & ~MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_MASK) | (mpclk_xbar_cg_en_0 << MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SHIFT)
#define MPM_MPCLK_XBAR_CG_EN_SET_MPCLK_XBAR_CG_EN_1(mpm_mpclk_xbar_cg_en_reg, mpclk_xbar_cg_en_1) \
     mpm_mpclk_xbar_cg_en_reg = (mpm_mpclk_xbar_cg_en_reg & ~MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_MASK) | (mpclk_xbar_cg_en_1 << MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_SHIFT)
#define MPM_MPCLK_XBAR_CG_EN_SET_MPCLK_XBAR_CG_OVERRIDE_0(mpm_mpclk_xbar_cg_en_reg, mpclk_xbar_cg_override_0) \
     mpm_mpclk_xbar_cg_en_reg = (mpm_mpclk_xbar_cg_en_reg & ~MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_MASK) | (mpclk_xbar_cg_override_0 << MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SHIFT)
#define MPM_MPCLK_XBAR_CG_EN_SET_MPCLK_XBAR_CG_OVERRIDE_1(mpm_mpclk_xbar_cg_en_reg, mpclk_xbar_cg_override_1) \
     mpm_mpclk_xbar_cg_en_reg = (mpm_mpclk_xbar_cg_en_reg & ~MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_MASK) | (mpclk_xbar_cg_override_1 << MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_mpclk_xbar_cg_en_t {
          unsigned int                                : 1;
          unsigned int mpclk_xbar_cg_en_0             : MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SIZE;
          unsigned int mpclk_xbar_cg_en_1             : MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_SIZE;
          unsigned int mpclk_xbar_cg_override_0       : MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SIZE;
          unsigned int mpclk_xbar_cg_override_1       : MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_SIZE;
          unsigned int                                : 27;
     } mpm_mpclk_xbar_cg_en_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_mpclk_xbar_cg_en_t {
          unsigned int                                : 27;
          unsigned int mpclk_xbar_cg_override_1       : MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_SIZE;
          unsigned int mpclk_xbar_cg_override_0       : MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SIZE;
          unsigned int mpclk_xbar_cg_en_1             : MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_SIZE;
          unsigned int mpclk_xbar_cg_en_0             : MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SIZE;
          unsigned int                                : 1;
     } mpm_mpclk_xbar_cg_en_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_mpclk_xbar_cg_en_t f;
} mpm_mpclk_xbar_cg_en_u;


/*
 * MPM_MPCLK_XBAR_CG_MISC struct
 */

#define MPM_MPCLK_XBAR_CG_MISC_REG_SIZE 32
#define MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SIZE 8
#define MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SIZE 8

#define MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SHIFT 0
#define MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SHIFT 8

#define MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_MASK 0xff
#define MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_MASK 0xff00

#define MPM_MPCLK_XBAR_CG_MISC_MASK \
     (MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_MASK | \
      MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_MASK)

#define MPM_MPCLK_XBAR_CG_MISC_DEFAULT 0x00000606

#define MPM_MPCLK_XBAR_CG_MISC_GET_MPCLK_XBAR_CG_TIMEOUT(mpm_mpclk_xbar_cg_misc) \
     ((mpm_mpclk_xbar_cg_misc & MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_MASK) >> MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MPM_MPCLK_XBAR_CG_MISC_GET_MPCLK_XBAR_CSYS_DELAY(mpm_mpclk_xbar_cg_misc) \
     ((mpm_mpclk_xbar_cg_misc & MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_MASK) >> MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SHIFT)

#define MPM_MPCLK_XBAR_CG_MISC_SET_MPCLK_XBAR_CG_TIMEOUT(mpm_mpclk_xbar_cg_misc_reg, mpclk_xbar_cg_timeout) \
     mpm_mpclk_xbar_cg_misc_reg = (mpm_mpclk_xbar_cg_misc_reg & ~MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_MASK) | (mpclk_xbar_cg_timeout << MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MPM_MPCLK_XBAR_CG_MISC_SET_MPCLK_XBAR_CSYS_DELAY(mpm_mpclk_xbar_cg_misc_reg, mpclk_xbar_csys_delay) \
     mpm_mpclk_xbar_cg_misc_reg = (mpm_mpclk_xbar_cg_misc_reg & ~MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_MASK) | (mpclk_xbar_csys_delay << MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_mpclk_xbar_cg_misc_t {
          unsigned int mpclk_xbar_cg_timeout          : MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SIZE;
          unsigned int mpclk_xbar_csys_delay          : MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SIZE;
          unsigned int                                : 16;
     } mpm_mpclk_xbar_cg_misc_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_mpclk_xbar_cg_misc_t {
          unsigned int                                : 16;
          unsigned int mpclk_xbar_csys_delay          : MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SIZE;
          unsigned int mpclk_xbar_cg_timeout          : MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SIZE;
     } mpm_mpclk_xbar_cg_misc_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_mpclk_xbar_cg_misc_t f;
} mpm_mpclk_xbar_cg_misc_u;


/*
 * MPM_DFP_PGFSM_CTRL struct
 */

#define MPM_DFP_PGFSM_CTRL_REG_SIZE    32
#define MPM_DFP_PGFSM_CTRL_PGFSM_ENTER_SIZE 1
#define MPM_DFP_PGFSM_CTRL_PGFSM_SAFE_IDLE_SIZE 1
#define MPM_DFP_PGFSM_CTRL_PGFSM_S0I2X_SIZE 1
#define MPM_DFP_PGFSM_CTRL_PGFSM_SMNIF_LIVMIN_EN_SIZE 1
#define MPM_DFP_PGFSM_CTRL_PGFSM_NO_WAKE_ON_SMNIF_SIZE 1
#define MPM_DFP_PGFSM_CTRL_PGFSM_DS_ALLOW_EN_SIZE 1
#define MPM_DFP_PGFSM_CTRL_PGFSM_NO_CLK_CG_ON_PWROFF_SIZE 1
#define MPM_DFP_PGFSM_CTRL_PGFSM_SUCCESS_SIZE 1

#define MPM_DFP_PGFSM_CTRL_PGFSM_ENTER_SHIFT 0
#define MPM_DFP_PGFSM_CTRL_PGFSM_SAFE_IDLE_SHIFT 1
#define MPM_DFP_PGFSM_CTRL_PGFSM_S0I2X_SHIFT 2
#define MPM_DFP_PGFSM_CTRL_PGFSM_SMNIF_LIVMIN_EN_SHIFT 3
#define MPM_DFP_PGFSM_CTRL_PGFSM_NO_WAKE_ON_SMNIF_SHIFT 4
#define MPM_DFP_PGFSM_CTRL_PGFSM_DS_ALLOW_EN_SHIFT 5
#define MPM_DFP_PGFSM_CTRL_PGFSM_NO_CLK_CG_ON_PWROFF_SHIFT 7
#define MPM_DFP_PGFSM_CTRL_PGFSM_SUCCESS_SHIFT 31

#define MPM_DFP_PGFSM_CTRL_PGFSM_ENTER_MASK 0x1
#define MPM_DFP_PGFSM_CTRL_PGFSM_SAFE_IDLE_MASK 0x2
#define MPM_DFP_PGFSM_CTRL_PGFSM_S0I2X_MASK 0x4
#define MPM_DFP_PGFSM_CTRL_PGFSM_SMNIF_LIVMIN_EN_MASK 0x8
#define MPM_DFP_PGFSM_CTRL_PGFSM_NO_WAKE_ON_SMNIF_MASK 0x10
#define MPM_DFP_PGFSM_CTRL_PGFSM_DS_ALLOW_EN_MASK 0x20
#define MPM_DFP_PGFSM_CTRL_PGFSM_NO_CLK_CG_ON_PWROFF_MASK 0x80
#define MPM_DFP_PGFSM_CTRL_PGFSM_SUCCESS_MASK 0x80000000

#define MPM_DFP_PGFSM_CTRL_MASK \
     (MPM_DFP_PGFSM_CTRL_PGFSM_ENTER_MASK | \
      MPM_DFP_PGFSM_CTRL_PGFSM_SAFE_IDLE_MASK | \
      MPM_DFP_PGFSM_CTRL_PGFSM_S0I2X_MASK | \
      MPM_DFP_PGFSM_CTRL_PGFSM_SMNIF_LIVMIN_EN_MASK | \
      MPM_DFP_PGFSM_CTRL_PGFSM_NO_WAKE_ON_SMNIF_MASK | \
      MPM_DFP_PGFSM_CTRL_PGFSM_DS_ALLOW_EN_MASK | \
      MPM_DFP_PGFSM_CTRL_PGFSM_NO_CLK_CG_ON_PWROFF_MASK | \
      MPM_DFP_PGFSM_CTRL_PGFSM_SUCCESS_MASK)

#define MPM_DFP_PGFSM_CTRL_DEFAULT     0x00000000

#define MPM_DFP_PGFSM_CTRL_GET_PGFSM_ENTER(mpm_dfp_pgfsm_ctrl) \
     ((mpm_dfp_pgfsm_ctrl & MPM_DFP_PGFSM_CTRL_PGFSM_ENTER_MASK) >> MPM_DFP_PGFSM_CTRL_PGFSM_ENTER_SHIFT)
#define MPM_DFP_PGFSM_CTRL_GET_PGFSM_SAFE_IDLE(mpm_dfp_pgfsm_ctrl) \
     ((mpm_dfp_pgfsm_ctrl & MPM_DFP_PGFSM_CTRL_PGFSM_SAFE_IDLE_MASK) >> MPM_DFP_PGFSM_CTRL_PGFSM_SAFE_IDLE_SHIFT)
#define MPM_DFP_PGFSM_CTRL_GET_PGFSM_S0I2X(mpm_dfp_pgfsm_ctrl) \
     ((mpm_dfp_pgfsm_ctrl & MPM_DFP_PGFSM_CTRL_PGFSM_S0I2X_MASK) >> MPM_DFP_PGFSM_CTRL_PGFSM_S0I2X_SHIFT)
#define MPM_DFP_PGFSM_CTRL_GET_PGFSM_SMNIF_LIVMIN_EN(mpm_dfp_pgfsm_ctrl) \
     ((mpm_dfp_pgfsm_ctrl & MPM_DFP_PGFSM_CTRL_PGFSM_SMNIF_LIVMIN_EN_MASK) >> MPM_DFP_PGFSM_CTRL_PGFSM_SMNIF_LIVMIN_EN_SHIFT)
#define MPM_DFP_PGFSM_CTRL_GET_PGFSM_NO_WAKE_ON_SMNIF(mpm_dfp_pgfsm_ctrl) \
     ((mpm_dfp_pgfsm_ctrl & MPM_DFP_PGFSM_CTRL_PGFSM_NO_WAKE_ON_SMNIF_MASK) >> MPM_DFP_PGFSM_CTRL_PGFSM_NO_WAKE_ON_SMNIF_SHIFT)
#define MPM_DFP_PGFSM_CTRL_GET_PGFSM_DS_ALLOW_EN(mpm_dfp_pgfsm_ctrl) \
     ((mpm_dfp_pgfsm_ctrl & MPM_DFP_PGFSM_CTRL_PGFSM_DS_ALLOW_EN_MASK) >> MPM_DFP_PGFSM_CTRL_PGFSM_DS_ALLOW_EN_SHIFT)
#define MPM_DFP_PGFSM_CTRL_GET_PGFSM_NO_CLK_CG_ON_PWROFF(mpm_dfp_pgfsm_ctrl) \
     ((mpm_dfp_pgfsm_ctrl & MPM_DFP_PGFSM_CTRL_PGFSM_NO_CLK_CG_ON_PWROFF_MASK) >> MPM_DFP_PGFSM_CTRL_PGFSM_NO_CLK_CG_ON_PWROFF_SHIFT)
#define MPM_DFP_PGFSM_CTRL_GET_PGFSM_SUCCESS(mpm_dfp_pgfsm_ctrl) \
     ((mpm_dfp_pgfsm_ctrl & MPM_DFP_PGFSM_CTRL_PGFSM_SUCCESS_MASK) >> MPM_DFP_PGFSM_CTRL_PGFSM_SUCCESS_SHIFT)

#define MPM_DFP_PGFSM_CTRL_SET_PGFSM_ENTER(mpm_dfp_pgfsm_ctrl_reg, pgfsm_enter) \
     mpm_dfp_pgfsm_ctrl_reg = (mpm_dfp_pgfsm_ctrl_reg & ~MPM_DFP_PGFSM_CTRL_PGFSM_ENTER_MASK) | (pgfsm_enter << MPM_DFP_PGFSM_CTRL_PGFSM_ENTER_SHIFT)
#define MPM_DFP_PGFSM_CTRL_SET_PGFSM_SAFE_IDLE(mpm_dfp_pgfsm_ctrl_reg, pgfsm_safe_idle) \
     mpm_dfp_pgfsm_ctrl_reg = (mpm_dfp_pgfsm_ctrl_reg & ~MPM_DFP_PGFSM_CTRL_PGFSM_SAFE_IDLE_MASK) | (pgfsm_safe_idle << MPM_DFP_PGFSM_CTRL_PGFSM_SAFE_IDLE_SHIFT)
#define MPM_DFP_PGFSM_CTRL_SET_PGFSM_S0I2X(mpm_dfp_pgfsm_ctrl_reg, pgfsm_s0i2x) \
     mpm_dfp_pgfsm_ctrl_reg = (mpm_dfp_pgfsm_ctrl_reg & ~MPM_DFP_PGFSM_CTRL_PGFSM_S0I2X_MASK) | (pgfsm_s0i2x << MPM_DFP_PGFSM_CTRL_PGFSM_S0I2X_SHIFT)
#define MPM_DFP_PGFSM_CTRL_SET_PGFSM_SMNIF_LIVMIN_EN(mpm_dfp_pgfsm_ctrl_reg, pgfsm_smnif_livmin_en) \
     mpm_dfp_pgfsm_ctrl_reg = (mpm_dfp_pgfsm_ctrl_reg & ~MPM_DFP_PGFSM_CTRL_PGFSM_SMNIF_LIVMIN_EN_MASK) | (pgfsm_smnif_livmin_en << MPM_DFP_PGFSM_CTRL_PGFSM_SMNIF_LIVMIN_EN_SHIFT)
#define MPM_DFP_PGFSM_CTRL_SET_PGFSM_NO_WAKE_ON_SMNIF(mpm_dfp_pgfsm_ctrl_reg, pgfsm_no_wake_on_smnif) \
     mpm_dfp_pgfsm_ctrl_reg = (mpm_dfp_pgfsm_ctrl_reg & ~MPM_DFP_PGFSM_CTRL_PGFSM_NO_WAKE_ON_SMNIF_MASK) | (pgfsm_no_wake_on_smnif << MPM_DFP_PGFSM_CTRL_PGFSM_NO_WAKE_ON_SMNIF_SHIFT)
#define MPM_DFP_PGFSM_CTRL_SET_PGFSM_DS_ALLOW_EN(mpm_dfp_pgfsm_ctrl_reg, pgfsm_ds_allow_en) \
     mpm_dfp_pgfsm_ctrl_reg = (mpm_dfp_pgfsm_ctrl_reg & ~MPM_DFP_PGFSM_CTRL_PGFSM_DS_ALLOW_EN_MASK) | (pgfsm_ds_allow_en << MPM_DFP_PGFSM_CTRL_PGFSM_DS_ALLOW_EN_SHIFT)
#define MPM_DFP_PGFSM_CTRL_SET_PGFSM_NO_CLK_CG_ON_PWROFF(mpm_dfp_pgfsm_ctrl_reg, pgfsm_no_clk_cg_on_pwroff) \
     mpm_dfp_pgfsm_ctrl_reg = (mpm_dfp_pgfsm_ctrl_reg & ~MPM_DFP_PGFSM_CTRL_PGFSM_NO_CLK_CG_ON_PWROFF_MASK) | (pgfsm_no_clk_cg_on_pwroff << MPM_DFP_PGFSM_CTRL_PGFSM_NO_CLK_CG_ON_PWROFF_SHIFT)
#define MPM_DFP_PGFSM_CTRL_SET_PGFSM_SUCCESS(mpm_dfp_pgfsm_ctrl_reg, pgfsm_success) \
     mpm_dfp_pgfsm_ctrl_reg = (mpm_dfp_pgfsm_ctrl_reg & ~MPM_DFP_PGFSM_CTRL_PGFSM_SUCCESS_MASK) | (pgfsm_success << MPM_DFP_PGFSM_CTRL_PGFSM_SUCCESS_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_dfp_pgfsm_ctrl_t {
          unsigned int pgfsm_enter                    : MPM_DFP_PGFSM_CTRL_PGFSM_ENTER_SIZE;
          unsigned int pgfsm_safe_idle                : MPM_DFP_PGFSM_CTRL_PGFSM_SAFE_IDLE_SIZE;
          unsigned int pgfsm_s0i2x                    : MPM_DFP_PGFSM_CTRL_PGFSM_S0I2X_SIZE;
          unsigned int pgfsm_smnif_livmin_en          : MPM_DFP_PGFSM_CTRL_PGFSM_SMNIF_LIVMIN_EN_SIZE;
          unsigned int pgfsm_no_wake_on_smnif         : MPM_DFP_PGFSM_CTRL_PGFSM_NO_WAKE_ON_SMNIF_SIZE;
          unsigned int pgfsm_ds_allow_en              : MPM_DFP_PGFSM_CTRL_PGFSM_DS_ALLOW_EN_SIZE;
          unsigned int                                : 1;
          unsigned int pgfsm_no_clk_cg_on_pwroff      : MPM_DFP_PGFSM_CTRL_PGFSM_NO_CLK_CG_ON_PWROFF_SIZE;
          unsigned int                                : 23;
          unsigned int pgfsm_success                  : MPM_DFP_PGFSM_CTRL_PGFSM_SUCCESS_SIZE;
     } mpm_dfp_pgfsm_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_dfp_pgfsm_ctrl_t {
          unsigned int pgfsm_success                  : MPM_DFP_PGFSM_CTRL_PGFSM_SUCCESS_SIZE;
          unsigned int                                : 23;
          unsigned int pgfsm_no_clk_cg_on_pwroff      : MPM_DFP_PGFSM_CTRL_PGFSM_NO_CLK_CG_ON_PWROFF_SIZE;
          unsigned int                                : 1;
          unsigned int pgfsm_ds_allow_en              : MPM_DFP_PGFSM_CTRL_PGFSM_DS_ALLOW_EN_SIZE;
          unsigned int pgfsm_no_wake_on_smnif         : MPM_DFP_PGFSM_CTRL_PGFSM_NO_WAKE_ON_SMNIF_SIZE;
          unsigned int pgfsm_smnif_livmin_en          : MPM_DFP_PGFSM_CTRL_PGFSM_SMNIF_LIVMIN_EN_SIZE;
          unsigned int pgfsm_s0i2x                    : MPM_DFP_PGFSM_CTRL_PGFSM_S0I2X_SIZE;
          unsigned int pgfsm_safe_idle                : MPM_DFP_PGFSM_CTRL_PGFSM_SAFE_IDLE_SIZE;
          unsigned int pgfsm_enter                    : MPM_DFP_PGFSM_CTRL_PGFSM_ENTER_SIZE;
     } mpm_dfp_pgfsm_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_dfp_pgfsm_ctrl_t f;
} mpm_dfp_pgfsm_ctrl_u;


/*
 * MPM_DFP_PGFSM_TRAN_CTRL struct
 */

#define MPM_DFP_PGFSM_TRAN_CTRL_REG_SIZE 32
#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_ADDR_SIZE 4
#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_CMD_SIZE 3
#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_OVRD_IP_CTRL_SIZE 1
#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_DONE_SIZE 1
#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_DONE_SIZE 1
#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_STATUS_SIZE 2
#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_START_SIZE 1

#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_ADDR_SHIFT 0
#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_CMD_SHIFT 4
#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_OVRD_IP_CTRL_SHIFT 7
#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_DONE_SHIFT 8
#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_DONE_SHIFT 9
#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_STATUS_SHIFT 10
#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_START_SHIFT 31

#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_ADDR_MASK 0xf
#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_CMD_MASK 0x70
#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_OVRD_IP_CTRL_MASK 0x80
#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_DONE_MASK 0x100
#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_DONE_MASK 0x200
#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_STATUS_MASK 0xc00
#define MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_START_MASK 0x80000000

#define MPM_DFP_PGFSM_TRAN_CTRL_MASK \
     (MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_ADDR_MASK | \
      MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_CMD_MASK | \
      MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_OVRD_IP_CTRL_MASK | \
      MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_DONE_MASK | \
      MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_DONE_MASK | \
      MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_STATUS_MASK | \
      MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_START_MASK)

#define MPM_DFP_PGFSM_TRAN_CTRL_DEFAULT 0x00000000

#define MPM_DFP_PGFSM_TRAN_CTRL_GET_PGFSM_TRAN_ADDR(mpm_dfp_pgfsm_tran_ctrl) \
     ((mpm_dfp_pgfsm_tran_ctrl & MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_ADDR_MASK) >> MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_ADDR_SHIFT)
#define MPM_DFP_PGFSM_TRAN_CTRL_GET_PGFSM_TRAN_CMD(mpm_dfp_pgfsm_tran_ctrl) \
     ((mpm_dfp_pgfsm_tran_ctrl & MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_CMD_MASK) >> MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_CMD_SHIFT)
#define MPM_DFP_PGFSM_TRAN_CTRL_GET_PGFSM_OVRD_IP_CTRL(mpm_dfp_pgfsm_tran_ctrl) \
     ((mpm_dfp_pgfsm_tran_ctrl & MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_OVRD_IP_CTRL_MASK) >> MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_OVRD_IP_CTRL_SHIFT)
#define MPM_DFP_PGFSM_TRAN_CTRL_GET_PGFSM_TRAN_DONE(mpm_dfp_pgfsm_tran_ctrl) \
     ((mpm_dfp_pgfsm_tran_ctrl & MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_DONE_MASK) >> MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_DONE_SHIFT)
#define MPM_DFP_PGFSM_TRAN_CTRL_GET_PGFSM_IP_CMD_DONE(mpm_dfp_pgfsm_tran_ctrl) \
     ((mpm_dfp_pgfsm_tran_ctrl & MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_DONE_MASK) >> MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_DONE_SHIFT)
#define MPM_DFP_PGFSM_TRAN_CTRL_GET_PGFSM_IP_CMD_STATUS(mpm_dfp_pgfsm_tran_ctrl) \
     ((mpm_dfp_pgfsm_tran_ctrl & MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_STATUS_MASK) >> MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_STATUS_SHIFT)
#define MPM_DFP_PGFSM_TRAN_CTRL_GET_PGFSM_TRAN_START(mpm_dfp_pgfsm_tran_ctrl) \
     ((mpm_dfp_pgfsm_tran_ctrl & MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_START_MASK) >> MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_START_SHIFT)

#define MPM_DFP_PGFSM_TRAN_CTRL_SET_PGFSM_TRAN_ADDR(mpm_dfp_pgfsm_tran_ctrl_reg, pgfsm_tran_addr) \
     mpm_dfp_pgfsm_tran_ctrl_reg = (mpm_dfp_pgfsm_tran_ctrl_reg & ~MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_ADDR_MASK) | (pgfsm_tran_addr << MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_ADDR_SHIFT)
#define MPM_DFP_PGFSM_TRAN_CTRL_SET_PGFSM_TRAN_CMD(mpm_dfp_pgfsm_tran_ctrl_reg, pgfsm_tran_cmd) \
     mpm_dfp_pgfsm_tran_ctrl_reg = (mpm_dfp_pgfsm_tran_ctrl_reg & ~MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_CMD_MASK) | (pgfsm_tran_cmd << MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_CMD_SHIFT)
#define MPM_DFP_PGFSM_TRAN_CTRL_SET_PGFSM_OVRD_IP_CTRL(mpm_dfp_pgfsm_tran_ctrl_reg, pgfsm_ovrd_ip_ctrl) \
     mpm_dfp_pgfsm_tran_ctrl_reg = (mpm_dfp_pgfsm_tran_ctrl_reg & ~MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_OVRD_IP_CTRL_MASK) | (pgfsm_ovrd_ip_ctrl << MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_OVRD_IP_CTRL_SHIFT)
#define MPM_DFP_PGFSM_TRAN_CTRL_SET_PGFSM_TRAN_DONE(mpm_dfp_pgfsm_tran_ctrl_reg, pgfsm_tran_done) \
     mpm_dfp_pgfsm_tran_ctrl_reg = (mpm_dfp_pgfsm_tran_ctrl_reg & ~MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_DONE_MASK) | (pgfsm_tran_done << MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_DONE_SHIFT)
#define MPM_DFP_PGFSM_TRAN_CTRL_SET_PGFSM_IP_CMD_DONE(mpm_dfp_pgfsm_tran_ctrl_reg, pgfsm_ip_cmd_done) \
     mpm_dfp_pgfsm_tran_ctrl_reg = (mpm_dfp_pgfsm_tran_ctrl_reg & ~MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_DONE_MASK) | (pgfsm_ip_cmd_done << MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_DONE_SHIFT)
#define MPM_DFP_PGFSM_TRAN_CTRL_SET_PGFSM_IP_CMD_STATUS(mpm_dfp_pgfsm_tran_ctrl_reg, pgfsm_ip_cmd_status) \
     mpm_dfp_pgfsm_tran_ctrl_reg = (mpm_dfp_pgfsm_tran_ctrl_reg & ~MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_STATUS_MASK) | (pgfsm_ip_cmd_status << MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_STATUS_SHIFT)
#define MPM_DFP_PGFSM_TRAN_CTRL_SET_PGFSM_TRAN_START(mpm_dfp_pgfsm_tran_ctrl_reg, pgfsm_tran_start) \
     mpm_dfp_pgfsm_tran_ctrl_reg = (mpm_dfp_pgfsm_tran_ctrl_reg & ~MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_START_MASK) | (pgfsm_tran_start << MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_START_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_dfp_pgfsm_tran_ctrl_t {
          unsigned int pgfsm_tran_addr                : MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_ADDR_SIZE;
          unsigned int pgfsm_tran_cmd                 : MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_CMD_SIZE;
          unsigned int pgfsm_ovrd_ip_ctrl             : MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_OVRD_IP_CTRL_SIZE;
          unsigned int pgfsm_tran_done                : MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_DONE_SIZE;
          unsigned int pgfsm_ip_cmd_done              : MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_DONE_SIZE;
          unsigned int pgfsm_ip_cmd_status            : MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_STATUS_SIZE;
          unsigned int                                : 19;
          unsigned int pgfsm_tran_start               : MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_START_SIZE;
     } mpm_dfp_pgfsm_tran_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_dfp_pgfsm_tran_ctrl_t {
          unsigned int pgfsm_tran_start               : MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_START_SIZE;
          unsigned int                                : 19;
          unsigned int pgfsm_ip_cmd_status            : MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_STATUS_SIZE;
          unsigned int pgfsm_ip_cmd_done              : MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_IP_CMD_DONE_SIZE;
          unsigned int pgfsm_tran_done                : MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_DONE_SIZE;
          unsigned int pgfsm_ovrd_ip_ctrl             : MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_OVRD_IP_CTRL_SIZE;
          unsigned int pgfsm_tran_cmd                 : MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_CMD_SIZE;
          unsigned int pgfsm_tran_addr                : MPM_DFP_PGFSM_TRAN_CTRL_PGFSM_TRAN_ADDR_SIZE;
     } mpm_dfp_pgfsm_tran_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_dfp_pgfsm_tran_ctrl_t f;
} mpm_dfp_pgfsm_tran_ctrl_u;


/*
 * MPM_DFP_PGFSM_TRAN_WRITE_DATA struct
 */

#define MPM_DFP_PGFSM_TRAN_WRITE_DATA_REG_SIZE 32
#define MPM_DFP_PGFSM_TRAN_WRITE_DATA_PGFSM_TRAN_WRITE_DATA_SIZE 32

#define MPM_DFP_PGFSM_TRAN_WRITE_DATA_PGFSM_TRAN_WRITE_DATA_SHIFT 0

#define MPM_DFP_PGFSM_TRAN_WRITE_DATA_PGFSM_TRAN_WRITE_DATA_MASK 0xffffffff

#define MPM_DFP_PGFSM_TRAN_WRITE_DATA_MASK \
     (MPM_DFP_PGFSM_TRAN_WRITE_DATA_PGFSM_TRAN_WRITE_DATA_MASK)

#define MPM_DFP_PGFSM_TRAN_WRITE_DATA_DEFAULT 0x00000000

#define MPM_DFP_PGFSM_TRAN_WRITE_DATA_GET_PGFSM_TRAN_WRITE_DATA(mpm_dfp_pgfsm_tran_write_data) \
     ((mpm_dfp_pgfsm_tran_write_data & MPM_DFP_PGFSM_TRAN_WRITE_DATA_PGFSM_TRAN_WRITE_DATA_MASK) >> MPM_DFP_PGFSM_TRAN_WRITE_DATA_PGFSM_TRAN_WRITE_DATA_SHIFT)

#define MPM_DFP_PGFSM_TRAN_WRITE_DATA_SET_PGFSM_TRAN_WRITE_DATA(mpm_dfp_pgfsm_tran_write_data_reg, pgfsm_tran_write_data) \
     mpm_dfp_pgfsm_tran_write_data_reg = (mpm_dfp_pgfsm_tran_write_data_reg & ~MPM_DFP_PGFSM_TRAN_WRITE_DATA_PGFSM_TRAN_WRITE_DATA_MASK) | (pgfsm_tran_write_data << MPM_DFP_PGFSM_TRAN_WRITE_DATA_PGFSM_TRAN_WRITE_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_dfp_pgfsm_tran_write_data_t {
          unsigned int pgfsm_tran_write_data          : MPM_DFP_PGFSM_TRAN_WRITE_DATA_PGFSM_TRAN_WRITE_DATA_SIZE;
     } mpm_dfp_pgfsm_tran_write_data_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_dfp_pgfsm_tran_write_data_t {
          unsigned int pgfsm_tran_write_data          : MPM_DFP_PGFSM_TRAN_WRITE_DATA_PGFSM_TRAN_WRITE_DATA_SIZE;
     } mpm_dfp_pgfsm_tran_write_data_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_dfp_pgfsm_tran_write_data_t f;
} mpm_dfp_pgfsm_tran_write_data_u;


/*
 * MPM_DFP_PGFSM_TRAN_READ_DATA struct
 */

#define MPM_DFP_PGFSM_TRAN_READ_DATA_REG_SIZE 32
#define MPM_DFP_PGFSM_TRAN_READ_DATA_PGFSM_TRAN_READ_DATA_SIZE 32

#define MPM_DFP_PGFSM_TRAN_READ_DATA_PGFSM_TRAN_READ_DATA_SHIFT 0

#define MPM_DFP_PGFSM_TRAN_READ_DATA_PGFSM_TRAN_READ_DATA_MASK 0xffffffff

#define MPM_DFP_PGFSM_TRAN_READ_DATA_MASK \
     (MPM_DFP_PGFSM_TRAN_READ_DATA_PGFSM_TRAN_READ_DATA_MASK)

#define MPM_DFP_PGFSM_TRAN_READ_DATA_DEFAULT 0x00000000

#define MPM_DFP_PGFSM_TRAN_READ_DATA_GET_PGFSM_TRAN_READ_DATA(mpm_dfp_pgfsm_tran_read_data) \
     ((mpm_dfp_pgfsm_tran_read_data & MPM_DFP_PGFSM_TRAN_READ_DATA_PGFSM_TRAN_READ_DATA_MASK) >> MPM_DFP_PGFSM_TRAN_READ_DATA_PGFSM_TRAN_READ_DATA_SHIFT)

#define MPM_DFP_PGFSM_TRAN_READ_DATA_SET_PGFSM_TRAN_READ_DATA(mpm_dfp_pgfsm_tran_read_data_reg, pgfsm_tran_read_data) \
     mpm_dfp_pgfsm_tran_read_data_reg = (mpm_dfp_pgfsm_tran_read_data_reg & ~MPM_DFP_PGFSM_TRAN_READ_DATA_PGFSM_TRAN_READ_DATA_MASK) | (pgfsm_tran_read_data << MPM_DFP_PGFSM_TRAN_READ_DATA_PGFSM_TRAN_READ_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_dfp_pgfsm_tran_read_data_t {
          unsigned int pgfsm_tran_read_data           : MPM_DFP_PGFSM_TRAN_READ_DATA_PGFSM_TRAN_READ_DATA_SIZE;
     } mpm_dfp_pgfsm_tran_read_data_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_dfp_pgfsm_tran_read_data_t {
          unsigned int pgfsm_tran_read_data           : MPM_DFP_PGFSM_TRAN_READ_DATA_PGFSM_TRAN_READ_DATA_SIZE;
     } mpm_dfp_pgfsm_tran_read_data_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_dfp_pgfsm_tran_read_data_t f;
} mpm_dfp_pgfsm_tran_read_data_u;


/*
 * MPM_DFP_PGFSM_OVRD_REG struct
 */

#define MPM_DFP_PGFSM_OVRD_REG_REG_SIZE 32
#define MPM_DFP_PGFSM_OVRD_REG_PGFSM_MGCG_OVRD_SIZE 1
#define MPM_DFP_PGFSM_OVRD_REG_PGFSM_CSYS_DELAY_SIZE 8

#define MPM_DFP_PGFSM_OVRD_REG_PGFSM_MGCG_OVRD_SHIFT 0
#define MPM_DFP_PGFSM_OVRD_REG_PGFSM_CSYS_DELAY_SHIFT 8

#define MPM_DFP_PGFSM_OVRD_REG_PGFSM_MGCG_OVRD_MASK 0x1
#define MPM_DFP_PGFSM_OVRD_REG_PGFSM_CSYS_DELAY_MASK 0xff00

#define MPM_DFP_PGFSM_OVRD_REG_MASK \
     (MPM_DFP_PGFSM_OVRD_REG_PGFSM_MGCG_OVRD_MASK | \
      MPM_DFP_PGFSM_OVRD_REG_PGFSM_CSYS_DELAY_MASK)

#define MPM_DFP_PGFSM_OVRD_REG_DEFAULT 0x00000600

#define MPM_DFP_PGFSM_OVRD_REG_GET_PGFSM_MGCG_OVRD(mpm_dfp_pgfsm_ovrd_reg) \
     ((mpm_dfp_pgfsm_ovrd_reg & MPM_DFP_PGFSM_OVRD_REG_PGFSM_MGCG_OVRD_MASK) >> MPM_DFP_PGFSM_OVRD_REG_PGFSM_MGCG_OVRD_SHIFT)
#define MPM_DFP_PGFSM_OVRD_REG_GET_PGFSM_CSYS_DELAY(mpm_dfp_pgfsm_ovrd_reg) \
     ((mpm_dfp_pgfsm_ovrd_reg & MPM_DFP_PGFSM_OVRD_REG_PGFSM_CSYS_DELAY_MASK) >> MPM_DFP_PGFSM_OVRD_REG_PGFSM_CSYS_DELAY_SHIFT)

#define MPM_DFP_PGFSM_OVRD_REG_SET_PGFSM_MGCG_OVRD(mpm_dfp_pgfsm_ovrd_reg_reg, pgfsm_mgcg_ovrd) \
     mpm_dfp_pgfsm_ovrd_reg_reg = (mpm_dfp_pgfsm_ovrd_reg_reg & ~MPM_DFP_PGFSM_OVRD_REG_PGFSM_MGCG_OVRD_MASK) | (pgfsm_mgcg_ovrd << MPM_DFP_PGFSM_OVRD_REG_PGFSM_MGCG_OVRD_SHIFT)
#define MPM_DFP_PGFSM_OVRD_REG_SET_PGFSM_CSYS_DELAY(mpm_dfp_pgfsm_ovrd_reg_reg, pgfsm_csys_delay) \
     mpm_dfp_pgfsm_ovrd_reg_reg = (mpm_dfp_pgfsm_ovrd_reg_reg & ~MPM_DFP_PGFSM_OVRD_REG_PGFSM_CSYS_DELAY_MASK) | (pgfsm_csys_delay << MPM_DFP_PGFSM_OVRD_REG_PGFSM_CSYS_DELAY_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_dfp_pgfsm_ovrd_reg_t {
          unsigned int pgfsm_mgcg_ovrd                : MPM_DFP_PGFSM_OVRD_REG_PGFSM_MGCG_OVRD_SIZE;
          unsigned int                                : 7;
          unsigned int pgfsm_csys_delay               : MPM_DFP_PGFSM_OVRD_REG_PGFSM_CSYS_DELAY_SIZE;
          unsigned int                                : 16;
     } mpm_dfp_pgfsm_ovrd_reg_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_dfp_pgfsm_ovrd_reg_t {
          unsigned int                                : 16;
          unsigned int pgfsm_csys_delay               : MPM_DFP_PGFSM_OVRD_REG_PGFSM_CSYS_DELAY_SIZE;
          unsigned int                                : 7;
          unsigned int pgfsm_mgcg_ovrd                : MPM_DFP_PGFSM_OVRD_REG_PGFSM_MGCG_OVRD_SIZE;
     } mpm_dfp_pgfsm_ovrd_reg_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_dfp_pgfsm_ovrd_reg_t f;
} mpm_dfp_pgfsm_ovrd_reg_u;


/*
 * MPM_DFP_PGRAM_MMU_CNTL struct
 */

#define MPM_DFP_PGRAM_MMU_CNTL_REG_SIZE 32
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_SIZE 1
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_ROP_MMU_SIZE 1
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_SIZE 1
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_SIZE 1
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_SIZE 1
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_SIZE 1
#define MPM_DFP_PGRAM_MMU_CNTL_PGFSM_MEM_SDDS_EN_MMU_SIZE 1
#define MPM_DFP_PGRAM_MMU_CNTL_PGFSM_MEM_SDDS_MODE_MMU_SIZE 1
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_SIZE 8
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_SIZE 8

#define MPM_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_SHIFT 0
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_ROP_MMU_SHIFT 1
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_SHIFT 2
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_SHIFT 3
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_SHIFT 4
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_SHIFT 5
#define MPM_DFP_PGRAM_MMU_CNTL_PGFSM_MEM_SDDS_EN_MMU_SHIFT 6
#define MPM_DFP_PGRAM_MMU_CNTL_PGFSM_MEM_SDDS_MODE_MMU_SHIFT 7
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_SHIFT 8
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_SHIFT 16

#define MPM_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_MASK 0x1
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_ROP_MMU_MASK 0x2
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_MASK 0x4
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_MASK 0x8
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_MASK 0x10
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_MASK 0x20
#define MPM_DFP_PGRAM_MMU_CNTL_PGFSM_MEM_SDDS_EN_MMU_MASK 0x40
#define MPM_DFP_PGRAM_MMU_CNTL_PGFSM_MEM_SDDS_MODE_MMU_MASK 0x80
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_MASK 0xff00
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_MASK 0xff0000

#define MPM_DFP_PGRAM_MMU_CNTL_MASK \
     (MPM_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_MASK | \
      MPM_DFP_PGRAM_MMU_CNTL_MEM_ROP_MMU_MASK | \
      MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_MASK | \
      MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_MASK | \
      MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_MASK | \
      MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_MASK | \
      MPM_DFP_PGRAM_MMU_CNTL_PGFSM_MEM_SDDS_EN_MMU_MASK | \
      MPM_DFP_PGRAM_MMU_CNTL_PGFSM_MEM_SDDS_MODE_MMU_MASK | \
      MPM_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_MASK | \
      MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_MASK)

#define MPM_DFP_PGRAM_MMU_CNTL_DEFAULT 0x0010102a

#define MPM_DFP_PGRAM_MMU_CNTL_GET_MEM_SD_MMU(mpm_dfp_pgram_mmu_cntl) \
     ((mpm_dfp_pgram_mmu_cntl & MPM_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_MASK) >> MPM_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_GET_MEM_ROP_MMU(mpm_dfp_pgram_mmu_cntl) \
     ((mpm_dfp_pgram_mmu_cntl & MPM_DFP_PGRAM_MMU_CNTL_MEM_ROP_MMU_MASK) >> MPM_DFP_PGRAM_MMU_CNTL_MEM_ROP_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_GET_MEM_DEEP_SLEEP_EN_MMU(mpm_dfp_pgram_mmu_cntl) \
     ((mpm_dfp_pgram_mmu_cntl & MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_MASK) >> MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_GET_MEM_DEEP_SLEEP_STATUS_MMU(mpm_dfp_pgram_mmu_cntl) \
     ((mpm_dfp_pgram_mmu_cntl & MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_MASK) >> MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_GET_MEM_LIGHT_SLEEP_EN_MMU(mpm_dfp_pgram_mmu_cntl) \
     ((mpm_dfp_pgram_mmu_cntl & MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_MASK) >> MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_MMU(mpm_dfp_pgram_mmu_cntl) \
     ((mpm_dfp_pgram_mmu_cntl & MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_MASK) >> MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_GET_PGFSM_MEM_SDDS_EN_MMU(mpm_dfp_pgram_mmu_cntl) \
     ((mpm_dfp_pgram_mmu_cntl & MPM_DFP_PGRAM_MMU_CNTL_PGFSM_MEM_SDDS_EN_MMU_MASK) >> MPM_DFP_PGRAM_MMU_CNTL_PGFSM_MEM_SDDS_EN_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_GET_PGFSM_MEM_SDDS_MODE_MMU(mpm_dfp_pgram_mmu_cntl) \
     ((mpm_dfp_pgram_mmu_cntl & MPM_DFP_PGRAM_MMU_CNTL_PGFSM_MEM_SDDS_MODE_MMU_MASK) >> MPM_DFP_PGRAM_MMU_CNTL_PGFSM_MEM_SDDS_MODE_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_GET_MEM_SLEEP_TIMEOUT_MMU(mpm_dfp_pgram_mmu_cntl) \
     ((mpm_dfp_pgram_mmu_cntl & MPM_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_MASK) >> MPM_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_GET_MEM_PG_DLY_MMU(mpm_dfp_pgram_mmu_cntl) \
     ((mpm_dfp_pgram_mmu_cntl & MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_MASK) >> MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_SHIFT)

#define MPM_DFP_PGRAM_MMU_CNTL_SET_MEM_SD_MMU(mpm_dfp_pgram_mmu_cntl_reg, mem_sd_mmu) \
     mpm_dfp_pgram_mmu_cntl_reg = (mpm_dfp_pgram_mmu_cntl_reg & ~MPM_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_MASK) | (mem_sd_mmu << MPM_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_SET_MEM_ROP_MMU(mpm_dfp_pgram_mmu_cntl_reg, mem_rop_mmu) \
     mpm_dfp_pgram_mmu_cntl_reg = (mpm_dfp_pgram_mmu_cntl_reg & ~MPM_DFP_PGRAM_MMU_CNTL_MEM_ROP_MMU_MASK) | (mem_rop_mmu << MPM_DFP_PGRAM_MMU_CNTL_MEM_ROP_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_SET_MEM_DEEP_SLEEP_EN_MMU(mpm_dfp_pgram_mmu_cntl_reg, mem_deep_sleep_en_mmu) \
     mpm_dfp_pgram_mmu_cntl_reg = (mpm_dfp_pgram_mmu_cntl_reg & ~MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_MASK) | (mem_deep_sleep_en_mmu << MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_SET_MEM_DEEP_SLEEP_STATUS_MMU(mpm_dfp_pgram_mmu_cntl_reg, mem_deep_sleep_status_mmu) \
     mpm_dfp_pgram_mmu_cntl_reg = (mpm_dfp_pgram_mmu_cntl_reg & ~MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_MASK) | (mem_deep_sleep_status_mmu << MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_SET_MEM_LIGHT_SLEEP_EN_MMU(mpm_dfp_pgram_mmu_cntl_reg, mem_light_sleep_en_mmu) \
     mpm_dfp_pgram_mmu_cntl_reg = (mpm_dfp_pgram_mmu_cntl_reg & ~MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_MASK) | (mem_light_sleep_en_mmu << MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_MMU(mpm_dfp_pgram_mmu_cntl_reg, mem_light_sleep_status_mmu) \
     mpm_dfp_pgram_mmu_cntl_reg = (mpm_dfp_pgram_mmu_cntl_reg & ~MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_MASK) | (mem_light_sleep_status_mmu << MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_SET_PGFSM_MEM_SDDS_EN_MMU(mpm_dfp_pgram_mmu_cntl_reg, pgfsm_mem_sdds_en_mmu) \
     mpm_dfp_pgram_mmu_cntl_reg = (mpm_dfp_pgram_mmu_cntl_reg & ~MPM_DFP_PGRAM_MMU_CNTL_PGFSM_MEM_SDDS_EN_MMU_MASK) | (pgfsm_mem_sdds_en_mmu << MPM_DFP_PGRAM_MMU_CNTL_PGFSM_MEM_SDDS_EN_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_SET_PGFSM_MEM_SDDS_MODE_MMU(mpm_dfp_pgram_mmu_cntl_reg, pgfsm_mem_sdds_mode_mmu) \
     mpm_dfp_pgram_mmu_cntl_reg = (mpm_dfp_pgram_mmu_cntl_reg & ~MPM_DFP_PGRAM_MMU_CNTL_PGFSM_MEM_SDDS_MODE_MMU_MASK) | (pgfsm_mem_sdds_mode_mmu << MPM_DFP_PGRAM_MMU_CNTL_PGFSM_MEM_SDDS_MODE_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_SET_MEM_SLEEP_TIMEOUT_MMU(mpm_dfp_pgram_mmu_cntl_reg, mem_sleep_timeout_mmu) \
     mpm_dfp_pgram_mmu_cntl_reg = (mpm_dfp_pgram_mmu_cntl_reg & ~MPM_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_MASK) | (mem_sleep_timeout_mmu << MPM_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_SET_MEM_PG_DLY_MMU(mpm_dfp_pgram_mmu_cntl_reg, mem_pg_dly_mmu) \
     mpm_dfp_pgram_mmu_cntl_reg = (mpm_dfp_pgram_mmu_cntl_reg & ~MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_MASK) | (mem_pg_dly_mmu << MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_dfp_pgram_mmu_cntl_t {
          unsigned int mem_sd_mmu                     : MPM_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_SIZE;
          unsigned int mem_rop_mmu                    : MPM_DFP_PGRAM_MMU_CNTL_MEM_ROP_MMU_SIZE;
          unsigned int mem_deep_sleep_en_mmu          : MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_SIZE;
          unsigned int mem_deep_sleep_status_mmu      : MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_SIZE;
          unsigned int mem_light_sleep_en_mmu         : MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_SIZE;
          unsigned int mem_light_sleep_status_mmu     : MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_SIZE;
          unsigned int pgfsm_mem_sdds_en_mmu          : MPM_DFP_PGRAM_MMU_CNTL_PGFSM_MEM_SDDS_EN_MMU_SIZE;
          unsigned int pgfsm_mem_sdds_mode_mmu        : MPM_DFP_PGRAM_MMU_CNTL_PGFSM_MEM_SDDS_MODE_MMU_SIZE;
          unsigned int mem_sleep_timeout_mmu          : MPM_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_SIZE;
          unsigned int mem_pg_dly_mmu                 : MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_SIZE;
          unsigned int                                : 8;
     } mpm_dfp_pgram_mmu_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_dfp_pgram_mmu_cntl_t {
          unsigned int                                : 8;
          unsigned int mem_pg_dly_mmu                 : MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_SIZE;
          unsigned int mem_sleep_timeout_mmu          : MPM_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_SIZE;
          unsigned int pgfsm_mem_sdds_mode_mmu        : MPM_DFP_PGRAM_MMU_CNTL_PGFSM_MEM_SDDS_MODE_MMU_SIZE;
          unsigned int pgfsm_mem_sdds_en_mmu          : MPM_DFP_PGRAM_MMU_CNTL_PGFSM_MEM_SDDS_EN_MMU_SIZE;
          unsigned int mem_light_sleep_status_mmu     : MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_SIZE;
          unsigned int mem_light_sleep_en_mmu         : MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_SIZE;
          unsigned int mem_deep_sleep_status_mmu      : MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_SIZE;
          unsigned int mem_deep_sleep_en_mmu          : MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_SIZE;
          unsigned int mem_rop_mmu                    : MPM_DFP_PGRAM_MMU_CNTL_MEM_ROP_MMU_SIZE;
          unsigned int mem_sd_mmu                     : MPM_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_SIZE;
     } mpm_dfp_pgram_mmu_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_dfp_pgram_mmu_cntl_t f;
} mpm_dfp_pgram_mmu_cntl_u;


/*
 * MPM_DFP_PGRAM_CPU_CNTL struct
 */

#define MPM_DFP_PGRAM_CPU_CNTL_REG_SIZE 32
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_SIZE 1
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_ROP_CPU_SIZE 1
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_SIZE 1
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_SIZE 1
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_SIZE 1
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_SIZE 1
#define MPM_DFP_PGRAM_CPU_CNTL_PGFSM_MEM_SDDS_EN_CPU_SIZE 1
#define MPM_DFP_PGRAM_CPU_CNTL_PGFSM_MEM_SDDS_MODE_CPU_SIZE 1
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_SIZE 8
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_SIZE 8

#define MPM_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_SHIFT 0
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_ROP_CPU_SHIFT 1
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_SHIFT 2
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_SHIFT 3
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_SHIFT 4
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_SHIFT 5
#define MPM_DFP_PGRAM_CPU_CNTL_PGFSM_MEM_SDDS_EN_CPU_SHIFT 6
#define MPM_DFP_PGRAM_CPU_CNTL_PGFSM_MEM_SDDS_MODE_CPU_SHIFT 7
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_SHIFT 8
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_SHIFT 16

#define MPM_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_MASK 0x1
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_ROP_CPU_MASK 0x2
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_MASK 0x4
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_MASK 0x8
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_MASK 0x10
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_MASK 0x20
#define MPM_DFP_PGRAM_CPU_CNTL_PGFSM_MEM_SDDS_EN_CPU_MASK 0x40
#define MPM_DFP_PGRAM_CPU_CNTL_PGFSM_MEM_SDDS_MODE_CPU_MASK 0x80
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_MASK 0xff00
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_MASK 0xff0000

#define MPM_DFP_PGRAM_CPU_CNTL_MASK \
     (MPM_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_MASK | \
      MPM_DFP_PGRAM_CPU_CNTL_MEM_ROP_CPU_MASK | \
      MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_MASK | \
      MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_MASK | \
      MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_MASK | \
      MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_MASK | \
      MPM_DFP_PGRAM_CPU_CNTL_PGFSM_MEM_SDDS_EN_CPU_MASK | \
      MPM_DFP_PGRAM_CPU_CNTL_PGFSM_MEM_SDDS_MODE_CPU_MASK | \
      MPM_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_MASK | \
      MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_MASK)

#define MPM_DFP_PGRAM_CPU_CNTL_DEFAULT 0x0010102a

#define MPM_DFP_PGRAM_CPU_CNTL_GET_MEM_SD_CPU(mpm_dfp_pgram_cpu_cntl) \
     ((mpm_dfp_pgram_cpu_cntl & MPM_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_MASK) >> MPM_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_GET_MEM_ROP_CPU(mpm_dfp_pgram_cpu_cntl) \
     ((mpm_dfp_pgram_cpu_cntl & MPM_DFP_PGRAM_CPU_CNTL_MEM_ROP_CPU_MASK) >> MPM_DFP_PGRAM_CPU_CNTL_MEM_ROP_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_GET_MEM_DEEP_SLEEP_EN_CPU(mpm_dfp_pgram_cpu_cntl) \
     ((mpm_dfp_pgram_cpu_cntl & MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_MASK) >> MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_GET_MEM_DEEP_SLEEP_STATUS_CPU(mpm_dfp_pgram_cpu_cntl) \
     ((mpm_dfp_pgram_cpu_cntl & MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_MASK) >> MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_GET_MEM_LIGHT_SLEEP_EN_CPU(mpm_dfp_pgram_cpu_cntl) \
     ((mpm_dfp_pgram_cpu_cntl & MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_MASK) >> MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_CPU(mpm_dfp_pgram_cpu_cntl) \
     ((mpm_dfp_pgram_cpu_cntl & MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_MASK) >> MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_GET_PGFSM_MEM_SDDS_EN_CPU(mpm_dfp_pgram_cpu_cntl) \
     ((mpm_dfp_pgram_cpu_cntl & MPM_DFP_PGRAM_CPU_CNTL_PGFSM_MEM_SDDS_EN_CPU_MASK) >> MPM_DFP_PGRAM_CPU_CNTL_PGFSM_MEM_SDDS_EN_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_GET_PGFSM_MEM_SDDS_MODE_CPU(mpm_dfp_pgram_cpu_cntl) \
     ((mpm_dfp_pgram_cpu_cntl & MPM_DFP_PGRAM_CPU_CNTL_PGFSM_MEM_SDDS_MODE_CPU_MASK) >> MPM_DFP_PGRAM_CPU_CNTL_PGFSM_MEM_SDDS_MODE_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_GET_MEM_SLEEP_TIMEOUT_CPU(mpm_dfp_pgram_cpu_cntl) \
     ((mpm_dfp_pgram_cpu_cntl & MPM_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_MASK) >> MPM_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_GET_MEM_PG_DLY_CPU(mpm_dfp_pgram_cpu_cntl) \
     ((mpm_dfp_pgram_cpu_cntl & MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_MASK) >> MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_SHIFT)

#define MPM_DFP_PGRAM_CPU_CNTL_SET_MEM_SD_CPU(mpm_dfp_pgram_cpu_cntl_reg, mem_sd_cpu) \
     mpm_dfp_pgram_cpu_cntl_reg = (mpm_dfp_pgram_cpu_cntl_reg & ~MPM_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_MASK) | (mem_sd_cpu << MPM_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_SET_MEM_ROP_CPU(mpm_dfp_pgram_cpu_cntl_reg, mem_rop_cpu) \
     mpm_dfp_pgram_cpu_cntl_reg = (mpm_dfp_pgram_cpu_cntl_reg & ~MPM_DFP_PGRAM_CPU_CNTL_MEM_ROP_CPU_MASK) | (mem_rop_cpu << MPM_DFP_PGRAM_CPU_CNTL_MEM_ROP_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_SET_MEM_DEEP_SLEEP_EN_CPU(mpm_dfp_pgram_cpu_cntl_reg, mem_deep_sleep_en_cpu) \
     mpm_dfp_pgram_cpu_cntl_reg = (mpm_dfp_pgram_cpu_cntl_reg & ~MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_MASK) | (mem_deep_sleep_en_cpu << MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_SET_MEM_DEEP_SLEEP_STATUS_CPU(mpm_dfp_pgram_cpu_cntl_reg, mem_deep_sleep_status_cpu) \
     mpm_dfp_pgram_cpu_cntl_reg = (mpm_dfp_pgram_cpu_cntl_reg & ~MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_MASK) | (mem_deep_sleep_status_cpu << MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_SET_MEM_LIGHT_SLEEP_EN_CPU(mpm_dfp_pgram_cpu_cntl_reg, mem_light_sleep_en_cpu) \
     mpm_dfp_pgram_cpu_cntl_reg = (mpm_dfp_pgram_cpu_cntl_reg & ~MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_MASK) | (mem_light_sleep_en_cpu << MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_CPU(mpm_dfp_pgram_cpu_cntl_reg, mem_light_sleep_status_cpu) \
     mpm_dfp_pgram_cpu_cntl_reg = (mpm_dfp_pgram_cpu_cntl_reg & ~MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_MASK) | (mem_light_sleep_status_cpu << MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_SET_PGFSM_MEM_SDDS_EN_CPU(mpm_dfp_pgram_cpu_cntl_reg, pgfsm_mem_sdds_en_cpu) \
     mpm_dfp_pgram_cpu_cntl_reg = (mpm_dfp_pgram_cpu_cntl_reg & ~MPM_DFP_PGRAM_CPU_CNTL_PGFSM_MEM_SDDS_EN_CPU_MASK) | (pgfsm_mem_sdds_en_cpu << MPM_DFP_PGRAM_CPU_CNTL_PGFSM_MEM_SDDS_EN_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_SET_PGFSM_MEM_SDDS_MODE_CPU(mpm_dfp_pgram_cpu_cntl_reg, pgfsm_mem_sdds_mode_cpu) \
     mpm_dfp_pgram_cpu_cntl_reg = (mpm_dfp_pgram_cpu_cntl_reg & ~MPM_DFP_PGRAM_CPU_CNTL_PGFSM_MEM_SDDS_MODE_CPU_MASK) | (pgfsm_mem_sdds_mode_cpu << MPM_DFP_PGRAM_CPU_CNTL_PGFSM_MEM_SDDS_MODE_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_SET_MEM_SLEEP_TIMEOUT_CPU(mpm_dfp_pgram_cpu_cntl_reg, mem_sleep_timeout_cpu) \
     mpm_dfp_pgram_cpu_cntl_reg = (mpm_dfp_pgram_cpu_cntl_reg & ~MPM_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_MASK) | (mem_sleep_timeout_cpu << MPM_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_SET_MEM_PG_DLY_CPU(mpm_dfp_pgram_cpu_cntl_reg, mem_pg_dly_cpu) \
     mpm_dfp_pgram_cpu_cntl_reg = (mpm_dfp_pgram_cpu_cntl_reg & ~MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_MASK) | (mem_pg_dly_cpu << MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_dfp_pgram_cpu_cntl_t {
          unsigned int mem_sd_cpu                     : MPM_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_SIZE;
          unsigned int mem_rop_cpu                    : MPM_DFP_PGRAM_CPU_CNTL_MEM_ROP_CPU_SIZE;
          unsigned int mem_deep_sleep_en_cpu          : MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_SIZE;
          unsigned int mem_deep_sleep_status_cpu      : MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_SIZE;
          unsigned int mem_light_sleep_en_cpu         : MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_SIZE;
          unsigned int mem_light_sleep_status_cpu     : MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_SIZE;
          unsigned int pgfsm_mem_sdds_en_cpu          : MPM_DFP_PGRAM_CPU_CNTL_PGFSM_MEM_SDDS_EN_CPU_SIZE;
          unsigned int pgfsm_mem_sdds_mode_cpu        : MPM_DFP_PGRAM_CPU_CNTL_PGFSM_MEM_SDDS_MODE_CPU_SIZE;
          unsigned int mem_sleep_timeout_cpu          : MPM_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_SIZE;
          unsigned int mem_pg_dly_cpu                 : MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_SIZE;
          unsigned int                                : 8;
     } mpm_dfp_pgram_cpu_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_dfp_pgram_cpu_cntl_t {
          unsigned int                                : 8;
          unsigned int mem_pg_dly_cpu                 : MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_SIZE;
          unsigned int mem_sleep_timeout_cpu          : MPM_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_SIZE;
          unsigned int pgfsm_mem_sdds_mode_cpu        : MPM_DFP_PGRAM_CPU_CNTL_PGFSM_MEM_SDDS_MODE_CPU_SIZE;
          unsigned int pgfsm_mem_sdds_en_cpu          : MPM_DFP_PGRAM_CPU_CNTL_PGFSM_MEM_SDDS_EN_CPU_SIZE;
          unsigned int mem_light_sleep_status_cpu     : MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_SIZE;
          unsigned int mem_light_sleep_en_cpu         : MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_SIZE;
          unsigned int mem_deep_sleep_status_cpu      : MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_SIZE;
          unsigned int mem_deep_sleep_en_cpu          : MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_SIZE;
          unsigned int mem_rop_cpu                    : MPM_DFP_PGRAM_CPU_CNTL_MEM_ROP_CPU_SIZE;
          unsigned int mem_sd_cpu                     : MPM_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_SIZE;
     } mpm_dfp_pgram_cpu_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_dfp_pgram_cpu_cntl_t f;
} mpm_dfp_pgram_cpu_cntl_u;


/*
 * MPM_DFP_MPCLKDS_CTRL struct
 */

#define MPM_DFP_MPCLKDS_CTRL_REG_SIZE  32
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SIZE 1
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SIZE 1
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SIZE 8
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SIZE 1
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SIZE 1
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_PGFSM_WAKE_MASK_SIZE 1

#define MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SHIFT 0
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SHIFT 1
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SHIFT 2
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SHIFT 10
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SHIFT 11
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_PGFSM_WAKE_MASK_SHIFT 12

#define MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_MASK 0x1
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_MASK 0x2
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_MASK 0x3fc
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_MASK 0x400
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_MASK 0x800
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_PGFSM_WAKE_MASK_MASK 0x1000

#define MPM_DFP_MPCLKDS_CTRL_MASK \
     (MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_MASK | \
      MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_MASK | \
      MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_MASK | \
      MPM_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_MASK | \
      MPM_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_MASK | \
      MPM_DFP_MPCLKDS_CTRL_MPCLK_PGFSM_WAKE_MASK_MASK)

#define MPM_DFP_MPCLKDS_CTRL_DEFAULT   0x00001ffc

#define MPM_DFP_MPCLKDS_CTRL_GET_MPCLK_DS_ENB(mpm_dfp_mpclkds_ctrl) \
     ((mpm_dfp_mpclkds_ctrl & MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_MASK) >> MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SHIFT)
#define MPM_DFP_MPCLKDS_CTRL_GET_MPCLK_DS_STATUS(mpm_dfp_mpclkds_ctrl) \
     ((mpm_dfp_mpclkds_ctrl & MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_MASK) >> MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SHIFT)
#define MPM_DFP_MPCLKDS_CTRL_GET_MPCLK_DS_TIMEOUT(mpm_dfp_mpclkds_ctrl) \
     ((mpm_dfp_mpclkds_ctrl & MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_MASK) >> MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SHIFT)
#define MPM_DFP_MPCLKDS_CTRL_GET_MPCLK_CPUINTR_WAKE_MASK(mpm_dfp_mpclkds_ctrl) \
     ((mpm_dfp_mpclkds_ctrl & MPM_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_MASK) >> MPM_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SHIFT)
#define MPM_DFP_MPCLKDS_CTRL_GET_MPCLK_SMN_WAKE_MASK(mpm_dfp_mpclkds_ctrl) \
     ((mpm_dfp_mpclkds_ctrl & MPM_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_MASK) >> MPM_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SHIFT)
#define MPM_DFP_MPCLKDS_CTRL_GET_MPCLK_PGFSM_WAKE_MASK(mpm_dfp_mpclkds_ctrl) \
     ((mpm_dfp_mpclkds_ctrl & MPM_DFP_MPCLKDS_CTRL_MPCLK_PGFSM_WAKE_MASK_MASK) >> MPM_DFP_MPCLKDS_CTRL_MPCLK_PGFSM_WAKE_MASK_SHIFT)

#define MPM_DFP_MPCLKDS_CTRL_SET_MPCLK_DS_ENB(mpm_dfp_mpclkds_ctrl_reg, mpclk_ds_enb) \
     mpm_dfp_mpclkds_ctrl_reg = (mpm_dfp_mpclkds_ctrl_reg & ~MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_MASK) | (mpclk_ds_enb << MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SHIFT)
#define MPM_DFP_MPCLKDS_CTRL_SET_MPCLK_DS_STATUS(mpm_dfp_mpclkds_ctrl_reg, mpclk_ds_status) \
     mpm_dfp_mpclkds_ctrl_reg = (mpm_dfp_mpclkds_ctrl_reg & ~MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_MASK) | (mpclk_ds_status << MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SHIFT)
#define MPM_DFP_MPCLKDS_CTRL_SET_MPCLK_DS_TIMEOUT(mpm_dfp_mpclkds_ctrl_reg, mpclk_ds_timeout) \
     mpm_dfp_mpclkds_ctrl_reg = (mpm_dfp_mpclkds_ctrl_reg & ~MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_MASK) | (mpclk_ds_timeout << MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SHIFT)
#define MPM_DFP_MPCLKDS_CTRL_SET_MPCLK_CPUINTR_WAKE_MASK(mpm_dfp_mpclkds_ctrl_reg, mpclk_cpuintr_wake_mask) \
     mpm_dfp_mpclkds_ctrl_reg = (mpm_dfp_mpclkds_ctrl_reg & ~MPM_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_MASK) | (mpclk_cpuintr_wake_mask << MPM_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SHIFT)
#define MPM_DFP_MPCLKDS_CTRL_SET_MPCLK_SMN_WAKE_MASK(mpm_dfp_mpclkds_ctrl_reg, mpclk_smn_wake_mask) \
     mpm_dfp_mpclkds_ctrl_reg = (mpm_dfp_mpclkds_ctrl_reg & ~MPM_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_MASK) | (mpclk_smn_wake_mask << MPM_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SHIFT)
#define MPM_DFP_MPCLKDS_CTRL_SET_MPCLK_PGFSM_WAKE_MASK(mpm_dfp_mpclkds_ctrl_reg, mpclk_pgfsm_wake_mask) \
     mpm_dfp_mpclkds_ctrl_reg = (mpm_dfp_mpclkds_ctrl_reg & ~MPM_DFP_MPCLKDS_CTRL_MPCLK_PGFSM_WAKE_MASK_MASK) | (mpclk_pgfsm_wake_mask << MPM_DFP_MPCLKDS_CTRL_MPCLK_PGFSM_WAKE_MASK_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_dfp_mpclkds_ctrl_t {
          unsigned int mpclk_ds_enb                   : MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SIZE;
          unsigned int mpclk_ds_status                : MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SIZE;
          unsigned int mpclk_ds_timeout               : MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SIZE;
          unsigned int mpclk_cpuintr_wake_mask        : MPM_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SIZE;
          unsigned int mpclk_smn_wake_mask            : MPM_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SIZE;
          unsigned int mpclk_pgfsm_wake_mask          : MPM_DFP_MPCLKDS_CTRL_MPCLK_PGFSM_WAKE_MASK_SIZE;
          unsigned int                                : 19;
     } mpm_dfp_mpclkds_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_dfp_mpclkds_ctrl_t {
          unsigned int                                : 19;
          unsigned int mpclk_pgfsm_wake_mask          : MPM_DFP_MPCLKDS_CTRL_MPCLK_PGFSM_WAKE_MASK_SIZE;
          unsigned int mpclk_smn_wake_mask            : MPM_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SIZE;
          unsigned int mpclk_cpuintr_wake_mask        : MPM_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SIZE;
          unsigned int mpclk_ds_timeout               : MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SIZE;
          unsigned int mpclk_ds_status                : MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SIZE;
          unsigned int mpclk_ds_enb                   : MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SIZE;
     } mpm_dfp_mpclkds_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_dfp_mpclkds_ctrl_t f;
} mpm_dfp_mpclkds_ctrl_u;


/*
 * MPM_MPAONCLK_XBAR_CG_CTRL struct
 */

#define MPM_MPAONCLK_XBAR_CG_CTRL_REG_SIZE 32
#define MPM_MPAONCLK_XBAR_CG_CTRL_MPAONCLK_XBAR_CACTIVE_EN_SIZE 1

#define MPM_MPAONCLK_XBAR_CG_CTRL_MPAONCLK_XBAR_CACTIVE_EN_SHIFT 0

#define MPM_MPAONCLK_XBAR_CG_CTRL_MPAONCLK_XBAR_CACTIVE_EN_MASK 0x1

#define MPM_MPAONCLK_XBAR_CG_CTRL_MASK \
     (MPM_MPAONCLK_XBAR_CG_CTRL_MPAONCLK_XBAR_CACTIVE_EN_MASK)

#define MPM_MPAONCLK_XBAR_CG_CTRL_DEFAULT 0x00000000

#define MPM_MPAONCLK_XBAR_CG_CTRL_GET_MPAONCLK_XBAR_CACTIVE_EN(mpm_mpaonclk_xbar_cg_ctrl) \
     ((mpm_mpaonclk_xbar_cg_ctrl & MPM_MPAONCLK_XBAR_CG_CTRL_MPAONCLK_XBAR_CACTIVE_EN_MASK) >> MPM_MPAONCLK_XBAR_CG_CTRL_MPAONCLK_XBAR_CACTIVE_EN_SHIFT)

#define MPM_MPAONCLK_XBAR_CG_CTRL_SET_MPAONCLK_XBAR_CACTIVE_EN(mpm_mpaonclk_xbar_cg_ctrl_reg, mpaonclk_xbar_cactive_en) \
     mpm_mpaonclk_xbar_cg_ctrl_reg = (mpm_mpaonclk_xbar_cg_ctrl_reg & ~MPM_MPAONCLK_XBAR_CG_CTRL_MPAONCLK_XBAR_CACTIVE_EN_MASK) | (mpaonclk_xbar_cactive_en << MPM_MPAONCLK_XBAR_CG_CTRL_MPAONCLK_XBAR_CACTIVE_EN_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_mpaonclk_xbar_cg_ctrl_t {
          unsigned int mpaonclk_xbar_cactive_en       : MPM_MPAONCLK_XBAR_CG_CTRL_MPAONCLK_XBAR_CACTIVE_EN_SIZE;
          unsigned int                                : 31;
     } mpm_mpaonclk_xbar_cg_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_mpaonclk_xbar_cg_ctrl_t {
          unsigned int                                : 31;
          unsigned int mpaonclk_xbar_cactive_en       : MPM_MPAONCLK_XBAR_CG_CTRL_MPAONCLK_XBAR_CACTIVE_EN_SIZE;
     } mpm_mpaonclk_xbar_cg_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_mpaonclk_xbar_cg_ctrl_t f;
} mpm_mpaonclk_xbar_cg_ctrl_u;


/*
 * MPM_MPAONCLK_XBAR_CG_EN struct
 */

#define MPM_MPAONCLK_XBAR_CG_EN_REG_SIZE 32
#define MPM_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_0_SIZE 1
#define MPM_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_0_SIZE 1

#define MPM_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_0_SHIFT 1
#define MPM_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_0_SHIFT 2

#define MPM_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_0_MASK 0x2
#define MPM_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_0_MASK 0x4

#define MPM_MPAONCLK_XBAR_CG_EN_MASK \
     (MPM_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_0_MASK | \
      MPM_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_0_MASK)

#define MPM_MPAONCLK_XBAR_CG_EN_DEFAULT 0x00000000

#define MPM_MPAONCLK_XBAR_CG_EN_GET_MPAONCLK_XBAR_CG_EN_0(mpm_mpaonclk_xbar_cg_en) \
     ((mpm_mpaonclk_xbar_cg_en & MPM_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_0_MASK) >> MPM_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_0_SHIFT)
#define MPM_MPAONCLK_XBAR_CG_EN_GET_MPAONCLK_XBAR_CG_OVERRIDE_0(mpm_mpaonclk_xbar_cg_en) \
     ((mpm_mpaonclk_xbar_cg_en & MPM_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_0_MASK) >> MPM_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_0_SHIFT)

#define MPM_MPAONCLK_XBAR_CG_EN_SET_MPAONCLK_XBAR_CG_EN_0(mpm_mpaonclk_xbar_cg_en_reg, mpaonclk_xbar_cg_en_0) \
     mpm_mpaonclk_xbar_cg_en_reg = (mpm_mpaonclk_xbar_cg_en_reg & ~MPM_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_0_MASK) | (mpaonclk_xbar_cg_en_0 << MPM_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_0_SHIFT)
#define MPM_MPAONCLK_XBAR_CG_EN_SET_MPAONCLK_XBAR_CG_OVERRIDE_0(mpm_mpaonclk_xbar_cg_en_reg, mpaonclk_xbar_cg_override_0) \
     mpm_mpaonclk_xbar_cg_en_reg = (mpm_mpaonclk_xbar_cg_en_reg & ~MPM_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_0_MASK) | (mpaonclk_xbar_cg_override_0 << MPM_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_mpaonclk_xbar_cg_en_t {
          unsigned int                                : 1;
          unsigned int mpaonclk_xbar_cg_en_0          : MPM_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_0_SIZE;
          unsigned int mpaonclk_xbar_cg_override_0    : MPM_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_0_SIZE;
          unsigned int                                : 29;
     } mpm_mpaonclk_xbar_cg_en_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_mpaonclk_xbar_cg_en_t {
          unsigned int                                : 29;
          unsigned int mpaonclk_xbar_cg_override_0    : MPM_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_OVERRIDE_0_SIZE;
          unsigned int mpaonclk_xbar_cg_en_0          : MPM_MPAONCLK_XBAR_CG_EN_MPAONCLK_XBAR_CG_EN_0_SIZE;
          unsigned int                                : 1;
     } mpm_mpaonclk_xbar_cg_en_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_mpaonclk_xbar_cg_en_t f;
} mpm_mpaonclk_xbar_cg_en_u;


/*
 * MPM_MPAONCLK_XBAR_CG_MISC struct
 */

#define MPM_MPAONCLK_XBAR_CG_MISC_REG_SIZE 32
#define MPM_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CG_TIMEOUT_SIZE 8
#define MPM_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CSYS_DELAY_SIZE 8

#define MPM_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CG_TIMEOUT_SHIFT 0
#define MPM_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CSYS_DELAY_SHIFT 8

#define MPM_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CG_TIMEOUT_MASK 0xff
#define MPM_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CSYS_DELAY_MASK 0xff00

#define MPM_MPAONCLK_XBAR_CG_MISC_MASK \
     (MPM_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CG_TIMEOUT_MASK | \
      MPM_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CSYS_DELAY_MASK)

#define MPM_MPAONCLK_XBAR_CG_MISC_DEFAULT 0x00000606

#define MPM_MPAONCLK_XBAR_CG_MISC_GET_MPAONCLK_XBAR_CG_TIMEOUT(mpm_mpaonclk_xbar_cg_misc) \
     ((mpm_mpaonclk_xbar_cg_misc & MPM_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CG_TIMEOUT_MASK) >> MPM_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MPM_MPAONCLK_XBAR_CG_MISC_GET_MPAONCLK_XBAR_CSYS_DELAY(mpm_mpaonclk_xbar_cg_misc) \
     ((mpm_mpaonclk_xbar_cg_misc & MPM_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CSYS_DELAY_MASK) >> MPM_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CSYS_DELAY_SHIFT)

#define MPM_MPAONCLK_XBAR_CG_MISC_SET_MPAONCLK_XBAR_CG_TIMEOUT(mpm_mpaonclk_xbar_cg_misc_reg, mpaonclk_xbar_cg_timeout) \
     mpm_mpaonclk_xbar_cg_misc_reg = (mpm_mpaonclk_xbar_cg_misc_reg & ~MPM_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CG_TIMEOUT_MASK) | (mpaonclk_xbar_cg_timeout << MPM_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MPM_MPAONCLK_XBAR_CG_MISC_SET_MPAONCLK_XBAR_CSYS_DELAY(mpm_mpaonclk_xbar_cg_misc_reg, mpaonclk_xbar_csys_delay) \
     mpm_mpaonclk_xbar_cg_misc_reg = (mpm_mpaonclk_xbar_cg_misc_reg & ~MPM_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CSYS_DELAY_MASK) | (mpaonclk_xbar_csys_delay << MPM_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CSYS_DELAY_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_mpaonclk_xbar_cg_misc_t {
          unsigned int mpaonclk_xbar_cg_timeout       : MPM_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CG_TIMEOUT_SIZE;
          unsigned int mpaonclk_xbar_csys_delay       : MPM_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CSYS_DELAY_SIZE;
          unsigned int                                : 16;
     } mpm_mpaonclk_xbar_cg_misc_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_mpaonclk_xbar_cg_misc_t {
          unsigned int                                : 16;
          unsigned int mpaonclk_xbar_csys_delay       : MPM_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CSYS_DELAY_SIZE;
          unsigned int mpaonclk_xbar_cg_timeout       : MPM_MPAONCLK_XBAR_CG_MISC_MPAONCLK_XBAR_CG_TIMEOUT_SIZE;
     } mpm_mpaonclk_xbar_cg_misc_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_mpaonclk_xbar_cg_misc_t f;
} mpm_mpaonclk_xbar_cg_misc_u;


/*
 * MPM_DFP_PGRAM_CRU_CNTL struct
 */

#define MPM_DFP_PGRAM_CRU_CNTL_REG_SIZE 32
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_SIZE 1
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_ROP_CRU_SIZE 1
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_SIZE 1
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_SIZE 1
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_SIZE 1
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_SIZE 1
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_SIZE 8
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_SIZE 8

#define MPM_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_SHIFT 0
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_ROP_CRU_SHIFT 1
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_SHIFT 2
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_SHIFT 3
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_SHIFT 4
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_SHIFT 5
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_SHIFT 8
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_SHIFT 16

#define MPM_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_MASK 0x1
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_ROP_CRU_MASK 0x2
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_MASK 0x4
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_MASK 0x8
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_MASK 0x10
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_MASK 0x20
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_MASK 0xff00
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_MASK 0xff0000

#define MPM_DFP_PGRAM_CRU_CNTL_MASK \
     (MPM_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_MASK | \
      MPM_DFP_PGRAM_CRU_CNTL_MEM_ROP_CRU_MASK | \
      MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_MASK | \
      MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_MASK | \
      MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_MASK | \
      MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_MASK | \
      MPM_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_MASK | \
      MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_MASK)

#define MPM_DFP_PGRAM_CRU_CNTL_DEFAULT 0x0010102a

#define MPM_DFP_PGRAM_CRU_CNTL_GET_MEM_SD_CRU(mpm_dfp_pgram_cru_cntl) \
     ((mpm_dfp_pgram_cru_cntl & MPM_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_MASK) >> MPM_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_GET_MEM_ROP_CRU(mpm_dfp_pgram_cru_cntl) \
     ((mpm_dfp_pgram_cru_cntl & MPM_DFP_PGRAM_CRU_CNTL_MEM_ROP_CRU_MASK) >> MPM_DFP_PGRAM_CRU_CNTL_MEM_ROP_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_GET_MEM_DEEP_SLEEP_EN_CRU(mpm_dfp_pgram_cru_cntl) \
     ((mpm_dfp_pgram_cru_cntl & MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_MASK) >> MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_GET_MEM_DEEP_SLEEP_STATUS_CRU(mpm_dfp_pgram_cru_cntl) \
     ((mpm_dfp_pgram_cru_cntl & MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_MASK) >> MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_GET_MEM_LIGHT_SLEEP_EN_CRU(mpm_dfp_pgram_cru_cntl) \
     ((mpm_dfp_pgram_cru_cntl & MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_MASK) >> MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_CRU(mpm_dfp_pgram_cru_cntl) \
     ((mpm_dfp_pgram_cru_cntl & MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_MASK) >> MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_GET_MEM_SLEEP_TIMEOUT_CRU(mpm_dfp_pgram_cru_cntl) \
     ((mpm_dfp_pgram_cru_cntl & MPM_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_MASK) >> MPM_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_GET_MEM_PG_DLY_CRU(mpm_dfp_pgram_cru_cntl) \
     ((mpm_dfp_pgram_cru_cntl & MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_MASK) >> MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_SHIFT)

#define MPM_DFP_PGRAM_CRU_CNTL_SET_MEM_SD_CRU(mpm_dfp_pgram_cru_cntl_reg, mem_sd_cru) \
     mpm_dfp_pgram_cru_cntl_reg = (mpm_dfp_pgram_cru_cntl_reg & ~MPM_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_MASK) | (mem_sd_cru << MPM_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_SET_MEM_ROP_CRU(mpm_dfp_pgram_cru_cntl_reg, mem_rop_cru) \
     mpm_dfp_pgram_cru_cntl_reg = (mpm_dfp_pgram_cru_cntl_reg & ~MPM_DFP_PGRAM_CRU_CNTL_MEM_ROP_CRU_MASK) | (mem_rop_cru << MPM_DFP_PGRAM_CRU_CNTL_MEM_ROP_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_SET_MEM_DEEP_SLEEP_EN_CRU(mpm_dfp_pgram_cru_cntl_reg, mem_deep_sleep_en_cru) \
     mpm_dfp_pgram_cru_cntl_reg = (mpm_dfp_pgram_cru_cntl_reg & ~MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_MASK) | (mem_deep_sleep_en_cru << MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_SET_MEM_DEEP_SLEEP_STATUS_CRU(mpm_dfp_pgram_cru_cntl_reg, mem_deep_sleep_status_cru) \
     mpm_dfp_pgram_cru_cntl_reg = (mpm_dfp_pgram_cru_cntl_reg & ~MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_MASK) | (mem_deep_sleep_status_cru << MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_SET_MEM_LIGHT_SLEEP_EN_CRU(mpm_dfp_pgram_cru_cntl_reg, mem_light_sleep_en_cru) \
     mpm_dfp_pgram_cru_cntl_reg = (mpm_dfp_pgram_cru_cntl_reg & ~MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_MASK) | (mem_light_sleep_en_cru << MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_CRU(mpm_dfp_pgram_cru_cntl_reg, mem_light_sleep_status_cru) \
     mpm_dfp_pgram_cru_cntl_reg = (mpm_dfp_pgram_cru_cntl_reg & ~MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_MASK) | (mem_light_sleep_status_cru << MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_SET_MEM_SLEEP_TIMEOUT_CRU(mpm_dfp_pgram_cru_cntl_reg, mem_sleep_timeout_cru) \
     mpm_dfp_pgram_cru_cntl_reg = (mpm_dfp_pgram_cru_cntl_reg & ~MPM_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_MASK) | (mem_sleep_timeout_cru << MPM_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_SET_MEM_PG_DLY_CRU(mpm_dfp_pgram_cru_cntl_reg, mem_pg_dly_cru) \
     mpm_dfp_pgram_cru_cntl_reg = (mpm_dfp_pgram_cru_cntl_reg & ~MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_MASK) | (mem_pg_dly_cru << MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_dfp_pgram_cru_cntl_t {
          unsigned int mem_sd_cru                     : MPM_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_SIZE;
          unsigned int mem_rop_cru                    : MPM_DFP_PGRAM_CRU_CNTL_MEM_ROP_CRU_SIZE;
          unsigned int mem_deep_sleep_en_cru          : MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_SIZE;
          unsigned int mem_deep_sleep_status_cru      : MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_SIZE;
          unsigned int mem_light_sleep_en_cru         : MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_SIZE;
          unsigned int mem_light_sleep_status_cru     : MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_SIZE;
          unsigned int                                : 2;
          unsigned int mem_sleep_timeout_cru          : MPM_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_SIZE;
          unsigned int mem_pg_dly_cru                 : MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_SIZE;
          unsigned int                                : 8;
     } mpm_dfp_pgram_cru_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_dfp_pgram_cru_cntl_t {
          unsigned int                                : 8;
          unsigned int mem_pg_dly_cru                 : MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_SIZE;
          unsigned int mem_sleep_timeout_cru          : MPM_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_SIZE;
          unsigned int                                : 2;
          unsigned int mem_light_sleep_status_cru     : MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_SIZE;
          unsigned int mem_light_sleep_en_cru         : MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_SIZE;
          unsigned int mem_deep_sleep_status_cru      : MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_SIZE;
          unsigned int mem_deep_sleep_en_cru          : MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_SIZE;
          unsigned int mem_rop_cru                    : MPM_DFP_PGRAM_CRU_CNTL_MEM_ROP_CRU_SIZE;
          unsigned int mem_sd_cru                     : MPM_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_SIZE;
     } mpm_dfp_pgram_cru_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_dfp_pgram_cru_cntl_t f;
} mpm_dfp_pgram_cru_cntl_u;


/*
 * MPM_SOCCLK_XBAR_CG_CTRL struct
 */

#define MPM_SOCCLK_XBAR_CG_CTRL_REG_SIZE 32
#define MPM_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_SIZE 1

#define MPM_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_SHIFT 0

#define MPM_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_MASK 0x1

#define MPM_SOCCLK_XBAR_CG_CTRL_MASK \
     (MPM_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_MASK)

#define MPM_SOCCLK_XBAR_CG_CTRL_DEFAULT 0x00000000

#define MPM_SOCCLK_XBAR_CG_CTRL_GET_SOCCLK_XBAR_CACTIVE_EN(mpm_socclk_xbar_cg_ctrl) \
     ((mpm_socclk_xbar_cg_ctrl & MPM_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_MASK) >> MPM_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_SHIFT)

#define MPM_SOCCLK_XBAR_CG_CTRL_SET_SOCCLK_XBAR_CACTIVE_EN(mpm_socclk_xbar_cg_ctrl_reg, socclk_xbar_cactive_en) \
     mpm_socclk_xbar_cg_ctrl_reg = (mpm_socclk_xbar_cg_ctrl_reg & ~MPM_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_MASK) | (socclk_xbar_cactive_en << MPM_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_socclk_xbar_cg_ctrl_t {
          unsigned int socclk_xbar_cactive_en         : MPM_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_SIZE;
          unsigned int                                : 31;
     } mpm_socclk_xbar_cg_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_socclk_xbar_cg_ctrl_t {
          unsigned int                                : 31;
          unsigned int socclk_xbar_cactive_en         : MPM_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_SIZE;
     } mpm_socclk_xbar_cg_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_socclk_xbar_cg_ctrl_t f;
} mpm_socclk_xbar_cg_ctrl_u;


/*
 * MPM_SOCCLK_XBAR_CG_EN struct
 */

#define MPM_SOCCLK_XBAR_CG_EN_REG_SIZE 32
#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_SIZE 1
#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_SIZE 1
#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_SIZE 1
#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_SIZE 1

#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_SHIFT 1
#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_SHIFT 2
#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_SHIFT 3
#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_SHIFT 4

#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_MASK 0x2
#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_MASK 0x4
#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_MASK 0x8
#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_MASK 0x10

#define MPM_SOCCLK_XBAR_CG_EN_MASK \
     (MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_MASK | \
      MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_MASK | \
      MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_MASK | \
      MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_MASK)

#define MPM_SOCCLK_XBAR_CG_EN_DEFAULT  0x00000000

#define MPM_SOCCLK_XBAR_CG_EN_GET_SOCCLK_XBAR_CG_EN_0(mpm_socclk_xbar_cg_en) \
     ((mpm_socclk_xbar_cg_en & MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_MASK) >> MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_SHIFT)
#define MPM_SOCCLK_XBAR_CG_EN_GET_SOCCLK_XBAR_CG_EN_1(mpm_socclk_xbar_cg_en) \
     ((mpm_socclk_xbar_cg_en & MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_MASK) >> MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_SHIFT)
#define MPM_SOCCLK_XBAR_CG_EN_GET_SOCCLK_XBAR_CG_OVERRIDE_0(mpm_socclk_xbar_cg_en) \
     ((mpm_socclk_xbar_cg_en & MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_MASK) >> MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_SHIFT)
#define MPM_SOCCLK_XBAR_CG_EN_GET_SOCCLK_XBAR_CG_OVERRIDE_1(mpm_socclk_xbar_cg_en) \
     ((mpm_socclk_xbar_cg_en & MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_MASK) >> MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_SHIFT)

#define MPM_SOCCLK_XBAR_CG_EN_SET_SOCCLK_XBAR_CG_EN_0(mpm_socclk_xbar_cg_en_reg, socclk_xbar_cg_en_0) \
     mpm_socclk_xbar_cg_en_reg = (mpm_socclk_xbar_cg_en_reg & ~MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_MASK) | (socclk_xbar_cg_en_0 << MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_SHIFT)
#define MPM_SOCCLK_XBAR_CG_EN_SET_SOCCLK_XBAR_CG_EN_1(mpm_socclk_xbar_cg_en_reg, socclk_xbar_cg_en_1) \
     mpm_socclk_xbar_cg_en_reg = (mpm_socclk_xbar_cg_en_reg & ~MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_MASK) | (socclk_xbar_cg_en_1 << MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_SHIFT)
#define MPM_SOCCLK_XBAR_CG_EN_SET_SOCCLK_XBAR_CG_OVERRIDE_0(mpm_socclk_xbar_cg_en_reg, socclk_xbar_cg_override_0) \
     mpm_socclk_xbar_cg_en_reg = (mpm_socclk_xbar_cg_en_reg & ~MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_MASK) | (socclk_xbar_cg_override_0 << MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_SHIFT)
#define MPM_SOCCLK_XBAR_CG_EN_SET_SOCCLK_XBAR_CG_OVERRIDE_1(mpm_socclk_xbar_cg_en_reg, socclk_xbar_cg_override_1) \
     mpm_socclk_xbar_cg_en_reg = (mpm_socclk_xbar_cg_en_reg & ~MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_MASK) | (socclk_xbar_cg_override_1 << MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_socclk_xbar_cg_en_t {
          unsigned int                                : 1;
          unsigned int socclk_xbar_cg_en_0            : MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_SIZE;
          unsigned int socclk_xbar_cg_en_1            : MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_SIZE;
          unsigned int socclk_xbar_cg_override_0      : MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_SIZE;
          unsigned int socclk_xbar_cg_override_1      : MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_SIZE;
          unsigned int                                : 27;
     } mpm_socclk_xbar_cg_en_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_socclk_xbar_cg_en_t {
          unsigned int                                : 27;
          unsigned int socclk_xbar_cg_override_1      : MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_SIZE;
          unsigned int socclk_xbar_cg_override_0      : MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_SIZE;
          unsigned int socclk_xbar_cg_en_1            : MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_SIZE;
          unsigned int socclk_xbar_cg_en_0            : MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_SIZE;
          unsigned int                                : 1;
     } mpm_socclk_xbar_cg_en_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_socclk_xbar_cg_en_t f;
} mpm_socclk_xbar_cg_en_u;


/*
 * MPM_SOCCLK_XBAR_CG_MISC struct
 */

#define MPM_SOCCLK_XBAR_CG_MISC_REG_SIZE 32
#define MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_SIZE 8
#define MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_SIZE 8

#define MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_SHIFT 0
#define MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_SHIFT 8

#define MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_MASK 0xff
#define MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_MASK 0xff00

#define MPM_SOCCLK_XBAR_CG_MISC_MASK \
     (MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_MASK | \
      MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_MASK)

#define MPM_SOCCLK_XBAR_CG_MISC_DEFAULT 0x00000606

#define MPM_SOCCLK_XBAR_CG_MISC_GET_SOCCLK_XBAR_CG_TIMEOUT(mpm_socclk_xbar_cg_misc) \
     ((mpm_socclk_xbar_cg_misc & MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_MASK) >> MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MPM_SOCCLK_XBAR_CG_MISC_GET_SOCCLK_XBAR_CSYS_DELAY(mpm_socclk_xbar_cg_misc) \
     ((mpm_socclk_xbar_cg_misc & MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_MASK) >> MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_SHIFT)

#define MPM_SOCCLK_XBAR_CG_MISC_SET_SOCCLK_XBAR_CG_TIMEOUT(mpm_socclk_xbar_cg_misc_reg, socclk_xbar_cg_timeout) \
     mpm_socclk_xbar_cg_misc_reg = (mpm_socclk_xbar_cg_misc_reg & ~MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_MASK) | (socclk_xbar_cg_timeout << MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MPM_SOCCLK_XBAR_CG_MISC_SET_SOCCLK_XBAR_CSYS_DELAY(mpm_socclk_xbar_cg_misc_reg, socclk_xbar_csys_delay) \
     mpm_socclk_xbar_cg_misc_reg = (mpm_socclk_xbar_cg_misc_reg & ~MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_MASK) | (socclk_xbar_csys_delay << MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_socclk_xbar_cg_misc_t {
          unsigned int socclk_xbar_cg_timeout         : MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_SIZE;
          unsigned int socclk_xbar_csys_delay         : MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_SIZE;
          unsigned int                                : 16;
     } mpm_socclk_xbar_cg_misc_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_socclk_xbar_cg_misc_t {
          unsigned int                                : 16;
          unsigned int socclk_xbar_csys_delay         : MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_SIZE;
          unsigned int socclk_xbar_cg_timeout         : MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_SIZE;
     } mpm_socclk_xbar_cg_misc_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_socclk_xbar_cg_misc_t f;
} mpm_socclk_xbar_cg_misc_u;


/*
 * MPM_DFP_PGRAM_MHUB_CNTL struct
 */

#define MPM_DFP_PGRAM_MHUB_CNTL_REG_SIZE 32
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_SIZE 1
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_ROP_MHUB_SIZE 1
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_SIZE 1
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_SIZE 1
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_SIZE 1
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_SIZE 1
#define MPM_DFP_PGRAM_MHUB_CNTL_PGFSM_MEM_SDDS_EN_MHUB_SIZE 1
#define MPM_DFP_PGRAM_MHUB_CNTL_PGFSM_MEM_SDDS_MODE_MHUB_SIZE 1
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_SIZE 8
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_SIZE 8

#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_SHIFT 0
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_ROP_MHUB_SHIFT 1
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_SHIFT 2
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_SHIFT 3
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_SHIFT 4
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_SHIFT 5
#define MPM_DFP_PGRAM_MHUB_CNTL_PGFSM_MEM_SDDS_EN_MHUB_SHIFT 6
#define MPM_DFP_PGRAM_MHUB_CNTL_PGFSM_MEM_SDDS_MODE_MHUB_SHIFT 7
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_SHIFT 8
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_SHIFT 16

#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_MASK 0x1
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_ROP_MHUB_MASK 0x2
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_MASK 0x4
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_MASK 0x8
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_MASK 0x10
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_MASK 0x20
#define MPM_DFP_PGRAM_MHUB_CNTL_PGFSM_MEM_SDDS_EN_MHUB_MASK 0x40
#define MPM_DFP_PGRAM_MHUB_CNTL_PGFSM_MEM_SDDS_MODE_MHUB_MASK 0x80
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_MASK 0xff00
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_MASK 0xff0000

#define MPM_DFP_PGRAM_MHUB_CNTL_MASK \
     (MPM_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_MASK | \
      MPM_DFP_PGRAM_MHUB_CNTL_MEM_ROP_MHUB_MASK | \
      MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_MASK | \
      MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_MASK | \
      MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_MASK | \
      MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_MASK | \
      MPM_DFP_PGRAM_MHUB_CNTL_PGFSM_MEM_SDDS_EN_MHUB_MASK | \
      MPM_DFP_PGRAM_MHUB_CNTL_PGFSM_MEM_SDDS_MODE_MHUB_MASK | \
      MPM_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_MASK | \
      MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_MASK)

#define MPM_DFP_PGRAM_MHUB_CNTL_DEFAULT 0x0010102a

#define MPM_DFP_PGRAM_MHUB_CNTL_GET_MEM_SD_MHUB(mpm_dfp_pgram_mhub_cntl) \
     ((mpm_dfp_pgram_mhub_cntl & MPM_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_MASK) >> MPM_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_GET_MEM_ROP_MHUB(mpm_dfp_pgram_mhub_cntl) \
     ((mpm_dfp_pgram_mhub_cntl & MPM_DFP_PGRAM_MHUB_CNTL_MEM_ROP_MHUB_MASK) >> MPM_DFP_PGRAM_MHUB_CNTL_MEM_ROP_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_GET_MEM_DEEP_SLEEP_EN_MHUB(mpm_dfp_pgram_mhub_cntl) \
     ((mpm_dfp_pgram_mhub_cntl & MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_MASK) >> MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_GET_MEM_DEEP_SLEEP_STATUS_MHUB(mpm_dfp_pgram_mhub_cntl) \
     ((mpm_dfp_pgram_mhub_cntl & MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_MASK) >> MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_GET_MEM_LIGHT_SLEEP_EN_MHUB(mpm_dfp_pgram_mhub_cntl) \
     ((mpm_dfp_pgram_mhub_cntl & MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_MASK) >> MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_MHUB(mpm_dfp_pgram_mhub_cntl) \
     ((mpm_dfp_pgram_mhub_cntl & MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_MASK) >> MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_GET_PGFSM_MEM_SDDS_EN_MHUB(mpm_dfp_pgram_mhub_cntl) \
     ((mpm_dfp_pgram_mhub_cntl & MPM_DFP_PGRAM_MHUB_CNTL_PGFSM_MEM_SDDS_EN_MHUB_MASK) >> MPM_DFP_PGRAM_MHUB_CNTL_PGFSM_MEM_SDDS_EN_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_GET_PGFSM_MEM_SDDS_MODE_MHUB(mpm_dfp_pgram_mhub_cntl) \
     ((mpm_dfp_pgram_mhub_cntl & MPM_DFP_PGRAM_MHUB_CNTL_PGFSM_MEM_SDDS_MODE_MHUB_MASK) >> MPM_DFP_PGRAM_MHUB_CNTL_PGFSM_MEM_SDDS_MODE_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_GET_MEM_SLEEP_TIMEOUT_MHUB(mpm_dfp_pgram_mhub_cntl) \
     ((mpm_dfp_pgram_mhub_cntl & MPM_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_MASK) >> MPM_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_GET_MEM_PG_DLY_MHUB(mpm_dfp_pgram_mhub_cntl) \
     ((mpm_dfp_pgram_mhub_cntl & MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_MASK) >> MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_SHIFT)

#define MPM_DFP_PGRAM_MHUB_CNTL_SET_MEM_SD_MHUB(mpm_dfp_pgram_mhub_cntl_reg, mem_sd_mhub) \
     mpm_dfp_pgram_mhub_cntl_reg = (mpm_dfp_pgram_mhub_cntl_reg & ~MPM_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_MASK) | (mem_sd_mhub << MPM_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_SET_MEM_ROP_MHUB(mpm_dfp_pgram_mhub_cntl_reg, mem_rop_mhub) \
     mpm_dfp_pgram_mhub_cntl_reg = (mpm_dfp_pgram_mhub_cntl_reg & ~MPM_DFP_PGRAM_MHUB_CNTL_MEM_ROP_MHUB_MASK) | (mem_rop_mhub << MPM_DFP_PGRAM_MHUB_CNTL_MEM_ROP_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_SET_MEM_DEEP_SLEEP_EN_MHUB(mpm_dfp_pgram_mhub_cntl_reg, mem_deep_sleep_en_mhub) \
     mpm_dfp_pgram_mhub_cntl_reg = (mpm_dfp_pgram_mhub_cntl_reg & ~MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_MASK) | (mem_deep_sleep_en_mhub << MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_SET_MEM_DEEP_SLEEP_STATUS_MHUB(mpm_dfp_pgram_mhub_cntl_reg, mem_deep_sleep_status_mhub) \
     mpm_dfp_pgram_mhub_cntl_reg = (mpm_dfp_pgram_mhub_cntl_reg & ~MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_MASK) | (mem_deep_sleep_status_mhub << MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_SET_MEM_LIGHT_SLEEP_EN_MHUB(mpm_dfp_pgram_mhub_cntl_reg, mem_light_sleep_en_mhub) \
     mpm_dfp_pgram_mhub_cntl_reg = (mpm_dfp_pgram_mhub_cntl_reg & ~MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_MASK) | (mem_light_sleep_en_mhub << MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_MHUB(mpm_dfp_pgram_mhub_cntl_reg, mem_light_sleep_status_mhub) \
     mpm_dfp_pgram_mhub_cntl_reg = (mpm_dfp_pgram_mhub_cntl_reg & ~MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_MASK) | (mem_light_sleep_status_mhub << MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_SET_PGFSM_MEM_SDDS_EN_MHUB(mpm_dfp_pgram_mhub_cntl_reg, pgfsm_mem_sdds_en_mhub) \
     mpm_dfp_pgram_mhub_cntl_reg = (mpm_dfp_pgram_mhub_cntl_reg & ~MPM_DFP_PGRAM_MHUB_CNTL_PGFSM_MEM_SDDS_EN_MHUB_MASK) | (pgfsm_mem_sdds_en_mhub << MPM_DFP_PGRAM_MHUB_CNTL_PGFSM_MEM_SDDS_EN_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_SET_PGFSM_MEM_SDDS_MODE_MHUB(mpm_dfp_pgram_mhub_cntl_reg, pgfsm_mem_sdds_mode_mhub) \
     mpm_dfp_pgram_mhub_cntl_reg = (mpm_dfp_pgram_mhub_cntl_reg & ~MPM_DFP_PGRAM_MHUB_CNTL_PGFSM_MEM_SDDS_MODE_MHUB_MASK) | (pgfsm_mem_sdds_mode_mhub << MPM_DFP_PGRAM_MHUB_CNTL_PGFSM_MEM_SDDS_MODE_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_SET_MEM_SLEEP_TIMEOUT_MHUB(mpm_dfp_pgram_mhub_cntl_reg, mem_sleep_timeout_mhub) \
     mpm_dfp_pgram_mhub_cntl_reg = (mpm_dfp_pgram_mhub_cntl_reg & ~MPM_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_MASK) | (mem_sleep_timeout_mhub << MPM_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_SET_MEM_PG_DLY_MHUB(mpm_dfp_pgram_mhub_cntl_reg, mem_pg_dly_mhub) \
     mpm_dfp_pgram_mhub_cntl_reg = (mpm_dfp_pgram_mhub_cntl_reg & ~MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_MASK) | (mem_pg_dly_mhub << MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_dfp_pgram_mhub_cntl_t {
          unsigned int mem_sd_mhub                    : MPM_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_SIZE;
          unsigned int mem_rop_mhub                   : MPM_DFP_PGRAM_MHUB_CNTL_MEM_ROP_MHUB_SIZE;
          unsigned int mem_deep_sleep_en_mhub         : MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_SIZE;
          unsigned int mem_deep_sleep_status_mhub     : MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_SIZE;
          unsigned int mem_light_sleep_en_mhub        : MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_SIZE;
          unsigned int mem_light_sleep_status_mhub    : MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_SIZE;
          unsigned int pgfsm_mem_sdds_en_mhub         : MPM_DFP_PGRAM_MHUB_CNTL_PGFSM_MEM_SDDS_EN_MHUB_SIZE;
          unsigned int pgfsm_mem_sdds_mode_mhub       : MPM_DFP_PGRAM_MHUB_CNTL_PGFSM_MEM_SDDS_MODE_MHUB_SIZE;
          unsigned int mem_sleep_timeout_mhub         : MPM_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_SIZE;
          unsigned int mem_pg_dly_mhub                : MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_SIZE;
          unsigned int                                : 8;
     } mpm_dfp_pgram_mhub_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_dfp_pgram_mhub_cntl_t {
          unsigned int                                : 8;
          unsigned int mem_pg_dly_mhub                : MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_SIZE;
          unsigned int mem_sleep_timeout_mhub         : MPM_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_SIZE;
          unsigned int pgfsm_mem_sdds_mode_mhub       : MPM_DFP_PGRAM_MHUB_CNTL_PGFSM_MEM_SDDS_MODE_MHUB_SIZE;
          unsigned int pgfsm_mem_sdds_en_mhub         : MPM_DFP_PGRAM_MHUB_CNTL_PGFSM_MEM_SDDS_EN_MHUB_SIZE;
          unsigned int mem_light_sleep_status_mhub    : MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_SIZE;
          unsigned int mem_light_sleep_en_mhub        : MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_SIZE;
          unsigned int mem_deep_sleep_status_mhub     : MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_SIZE;
          unsigned int mem_deep_sleep_en_mhub         : MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_SIZE;
          unsigned int mem_rop_mhub                   : MPM_DFP_PGRAM_MHUB_CNTL_MEM_ROP_MHUB_SIZE;
          unsigned int mem_sd_mhub                    : MPM_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_SIZE;
     } mpm_dfp_pgram_mhub_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_dfp_pgram_mhub_cntl_t f;
} mpm_dfp_pgram_mhub_cntl_u;


/*
 * MPM_DFP_SOCCLKDS_CTRL struct
 */

#define MPM_DFP_SOCCLKDS_CTRL_REG_SIZE 32
#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_SIZE 1
#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_SIZE 1
#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_SIZE 8
#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_SIZE 1

#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_SHIFT 0
#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_SHIFT 1
#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_SHIFT 2
#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_SHIFT 10

#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_MASK 0x1
#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_MASK 0x2
#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_MASK 0x3fc
#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_MASK 0x400

#define MPM_DFP_SOCCLKDS_CTRL_MASK \
     (MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_MASK | \
      MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_MASK | \
      MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_MASK | \
      MPM_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_MASK)

#define MPM_DFP_SOCCLKDS_CTRL_DEFAULT  0x000007fc

#define MPM_DFP_SOCCLKDS_CTRL_GET_SOCCLK_DS_ENB(mpm_dfp_socclkds_ctrl) \
     ((mpm_dfp_socclkds_ctrl & MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_MASK) >> MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_SHIFT)
#define MPM_DFP_SOCCLKDS_CTRL_GET_SOCCLK_DS_STATUS(mpm_dfp_socclkds_ctrl) \
     ((mpm_dfp_socclkds_ctrl & MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_MASK) >> MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_SHIFT)
#define MPM_DFP_SOCCLKDS_CTRL_GET_SOCCLK_DS_TIMEOUT(mpm_dfp_socclkds_ctrl) \
     ((mpm_dfp_socclkds_ctrl & MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_MASK) >> MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_SHIFT)
#define MPM_DFP_SOCCLKDS_CTRL_GET_SOCCLK_MHUBIF_WAKE_MASK(mpm_dfp_socclkds_ctrl) \
     ((mpm_dfp_socclkds_ctrl & MPM_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_MASK) >> MPM_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_SHIFT)

#define MPM_DFP_SOCCLKDS_CTRL_SET_SOCCLK_DS_ENB(mpm_dfp_socclkds_ctrl_reg, socclk_ds_enb) \
     mpm_dfp_socclkds_ctrl_reg = (mpm_dfp_socclkds_ctrl_reg & ~MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_MASK) | (socclk_ds_enb << MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_SHIFT)
#define MPM_DFP_SOCCLKDS_CTRL_SET_SOCCLK_DS_STATUS(mpm_dfp_socclkds_ctrl_reg, socclk_ds_status) \
     mpm_dfp_socclkds_ctrl_reg = (mpm_dfp_socclkds_ctrl_reg & ~MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_MASK) | (socclk_ds_status << MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_SHIFT)
#define MPM_DFP_SOCCLKDS_CTRL_SET_SOCCLK_DS_TIMEOUT(mpm_dfp_socclkds_ctrl_reg, socclk_ds_timeout) \
     mpm_dfp_socclkds_ctrl_reg = (mpm_dfp_socclkds_ctrl_reg & ~MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_MASK) | (socclk_ds_timeout << MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_SHIFT)
#define MPM_DFP_SOCCLKDS_CTRL_SET_SOCCLK_MHUBIF_WAKE_MASK(mpm_dfp_socclkds_ctrl_reg, socclk_mhubif_wake_mask) \
     mpm_dfp_socclkds_ctrl_reg = (mpm_dfp_socclkds_ctrl_reg & ~MPM_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_MASK) | (socclk_mhubif_wake_mask << MPM_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_dfp_socclkds_ctrl_t {
          unsigned int socclk_ds_enb                  : MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_SIZE;
          unsigned int socclk_ds_status               : MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_SIZE;
          unsigned int socclk_ds_timeout              : MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_SIZE;
          unsigned int socclk_mhubif_wake_mask        : MPM_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_SIZE;
          unsigned int                                : 21;
     } mpm_dfp_socclkds_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_dfp_socclkds_ctrl_t {
          unsigned int                                : 21;
          unsigned int socclk_mhubif_wake_mask        : MPM_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_SIZE;
          unsigned int socclk_ds_timeout              : MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_SIZE;
          unsigned int socclk_ds_status               : MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_SIZE;
          unsigned int socclk_ds_enb                  : MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_SIZE;
     } mpm_dfp_socclkds_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_dfp_socclkds_ctrl_t f;
} mpm_dfp_socclkds_ctrl_u;


/*
 * MPM_SHUBCLK_XBAR_CG_CTRL struct
 */

#define MPM_SHUBCLK_XBAR_CG_CTRL_REG_SIZE 32
#define MPM_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_SIZE 1

#define MPM_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_SHIFT 0

#define MPM_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_MASK 0x1

#define MPM_SHUBCLK_XBAR_CG_CTRL_MASK \
     (MPM_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_MASK)

#define MPM_SHUBCLK_XBAR_CG_CTRL_DEFAULT 0x00000000

#define MPM_SHUBCLK_XBAR_CG_CTRL_GET_SHUBCLK_XBAR_CACTIVE_EN(mpm_shubclk_xbar_cg_ctrl) \
     ((mpm_shubclk_xbar_cg_ctrl & MPM_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_MASK) >> MPM_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_SHIFT)

#define MPM_SHUBCLK_XBAR_CG_CTRL_SET_SHUBCLK_XBAR_CACTIVE_EN(mpm_shubclk_xbar_cg_ctrl_reg, shubclk_xbar_cactive_en) \
     mpm_shubclk_xbar_cg_ctrl_reg = (mpm_shubclk_xbar_cg_ctrl_reg & ~MPM_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_MASK) | (shubclk_xbar_cactive_en << MPM_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_shubclk_xbar_cg_ctrl_t {
          unsigned int shubclk_xbar_cactive_en        : MPM_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_SIZE;
          unsigned int                                : 31;
     } mpm_shubclk_xbar_cg_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_shubclk_xbar_cg_ctrl_t {
          unsigned int                                : 31;
          unsigned int shubclk_xbar_cactive_en        : MPM_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_SIZE;
     } mpm_shubclk_xbar_cg_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_shubclk_xbar_cg_ctrl_t f;
} mpm_shubclk_xbar_cg_ctrl_u;


/*
 * MPM_SHUBCLK_XBAR_CG_EN struct
 */

#define MPM_SHUBCLK_XBAR_CG_EN_REG_SIZE 32
#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_SIZE 1
#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_SIZE 1
#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_SIZE 1
#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_SIZE 1

#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_SHIFT 1
#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_SHIFT 2
#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_SHIFT 3
#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_SHIFT 4

#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_MASK 0x2
#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_MASK 0x4
#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_MASK 0x8
#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_MASK 0x10

#define MPM_SHUBCLK_XBAR_CG_EN_MASK \
     (MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_MASK | \
      MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_MASK | \
      MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_MASK | \
      MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_MASK)

#define MPM_SHUBCLK_XBAR_CG_EN_DEFAULT 0x00000000

#define MPM_SHUBCLK_XBAR_CG_EN_GET_SHUBCLK_XBAR_CG_EN_0(mpm_shubclk_xbar_cg_en) \
     ((mpm_shubclk_xbar_cg_en & MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_MASK) >> MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_SHIFT)
#define MPM_SHUBCLK_XBAR_CG_EN_GET_SHUBCLK_XBAR_CG_EN_1(mpm_shubclk_xbar_cg_en) \
     ((mpm_shubclk_xbar_cg_en & MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_MASK) >> MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_SHIFT)
#define MPM_SHUBCLK_XBAR_CG_EN_GET_SHUBCLK_XBAR_CG_OVERRIDE_0(mpm_shubclk_xbar_cg_en) \
     ((mpm_shubclk_xbar_cg_en & MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_MASK) >> MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_SHIFT)
#define MPM_SHUBCLK_XBAR_CG_EN_GET_SHUBCLK_XBAR_CG_OVERRIDE_1(mpm_shubclk_xbar_cg_en) \
     ((mpm_shubclk_xbar_cg_en & MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_MASK) >> MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_SHIFT)

#define MPM_SHUBCLK_XBAR_CG_EN_SET_SHUBCLK_XBAR_CG_EN_0(mpm_shubclk_xbar_cg_en_reg, shubclk_xbar_cg_en_0) \
     mpm_shubclk_xbar_cg_en_reg = (mpm_shubclk_xbar_cg_en_reg & ~MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_MASK) | (shubclk_xbar_cg_en_0 << MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_SHIFT)
#define MPM_SHUBCLK_XBAR_CG_EN_SET_SHUBCLK_XBAR_CG_EN_1(mpm_shubclk_xbar_cg_en_reg, shubclk_xbar_cg_en_1) \
     mpm_shubclk_xbar_cg_en_reg = (mpm_shubclk_xbar_cg_en_reg & ~MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_MASK) | (shubclk_xbar_cg_en_1 << MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_SHIFT)
#define MPM_SHUBCLK_XBAR_CG_EN_SET_SHUBCLK_XBAR_CG_OVERRIDE_0(mpm_shubclk_xbar_cg_en_reg, shubclk_xbar_cg_override_0) \
     mpm_shubclk_xbar_cg_en_reg = (mpm_shubclk_xbar_cg_en_reg & ~MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_MASK) | (shubclk_xbar_cg_override_0 << MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_SHIFT)
#define MPM_SHUBCLK_XBAR_CG_EN_SET_SHUBCLK_XBAR_CG_OVERRIDE_1(mpm_shubclk_xbar_cg_en_reg, shubclk_xbar_cg_override_1) \
     mpm_shubclk_xbar_cg_en_reg = (mpm_shubclk_xbar_cg_en_reg & ~MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_MASK) | (shubclk_xbar_cg_override_1 << MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_shubclk_xbar_cg_en_t {
          unsigned int                                : 1;
          unsigned int shubclk_xbar_cg_en_0           : MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_SIZE;
          unsigned int shubclk_xbar_cg_en_1           : MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_SIZE;
          unsigned int shubclk_xbar_cg_override_0     : MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_SIZE;
          unsigned int shubclk_xbar_cg_override_1     : MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_SIZE;
          unsigned int                                : 27;
     } mpm_shubclk_xbar_cg_en_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_shubclk_xbar_cg_en_t {
          unsigned int                                : 27;
          unsigned int shubclk_xbar_cg_override_1     : MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_SIZE;
          unsigned int shubclk_xbar_cg_override_0     : MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_SIZE;
          unsigned int shubclk_xbar_cg_en_1           : MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_SIZE;
          unsigned int shubclk_xbar_cg_en_0           : MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_SIZE;
          unsigned int                                : 1;
     } mpm_shubclk_xbar_cg_en_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_shubclk_xbar_cg_en_t f;
} mpm_shubclk_xbar_cg_en_u;


/*
 * MPM_SHUBCLK_XBAR_CG_MISC struct
 */

#define MPM_SHUBCLK_XBAR_CG_MISC_REG_SIZE 32
#define MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_SIZE 8
#define MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_SIZE 8

#define MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_SHIFT 0
#define MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_SHIFT 8

#define MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_MASK 0xff
#define MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_MASK 0xff00

#define MPM_SHUBCLK_XBAR_CG_MISC_MASK \
     (MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_MASK | \
      MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_MASK)

#define MPM_SHUBCLK_XBAR_CG_MISC_DEFAULT 0x00000606

#define MPM_SHUBCLK_XBAR_CG_MISC_GET_SHUBCLK_XBAR_CG_TIMEOUT(mpm_shubclk_xbar_cg_misc) \
     ((mpm_shubclk_xbar_cg_misc & MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_MASK) >> MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MPM_SHUBCLK_XBAR_CG_MISC_GET_SHUBCLK_XBAR_CSYS_DELAY(mpm_shubclk_xbar_cg_misc) \
     ((mpm_shubclk_xbar_cg_misc & MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_MASK) >> MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_SHIFT)

#define MPM_SHUBCLK_XBAR_CG_MISC_SET_SHUBCLK_XBAR_CG_TIMEOUT(mpm_shubclk_xbar_cg_misc_reg, shubclk_xbar_cg_timeout) \
     mpm_shubclk_xbar_cg_misc_reg = (mpm_shubclk_xbar_cg_misc_reg & ~MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_MASK) | (shubclk_xbar_cg_timeout << MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MPM_SHUBCLK_XBAR_CG_MISC_SET_SHUBCLK_XBAR_CSYS_DELAY(mpm_shubclk_xbar_cg_misc_reg, shubclk_xbar_csys_delay) \
     mpm_shubclk_xbar_cg_misc_reg = (mpm_shubclk_xbar_cg_misc_reg & ~MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_MASK) | (shubclk_xbar_csys_delay << MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_shubclk_xbar_cg_misc_t {
          unsigned int shubclk_xbar_cg_timeout        : MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_SIZE;
          unsigned int shubclk_xbar_csys_delay        : MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_SIZE;
          unsigned int                                : 16;
     } mpm_shubclk_xbar_cg_misc_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_shubclk_xbar_cg_misc_t {
          unsigned int                                : 16;
          unsigned int shubclk_xbar_csys_delay        : MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_SIZE;
          unsigned int shubclk_xbar_cg_timeout        : MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_SIZE;
     } mpm_shubclk_xbar_cg_misc_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_shubclk_xbar_cg_misc_t f;
} mpm_shubclk_xbar_cg_misc_u;


/*
 * MPM_DFP_PGRAM_SHUB_CNTL struct
 */

#define MPM_DFP_PGRAM_SHUB_CNTL_REG_SIZE 32
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_SIZE 1
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_ROP_SHUB_SIZE 1
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_SIZE 1
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_SIZE 1
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_SIZE 1
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_SIZE 1
#define MPM_DFP_PGRAM_SHUB_CNTL_PGFSM_MEM_SDDS_EN_SHUB_SIZE 1
#define MPM_DFP_PGRAM_SHUB_CNTL_PGFSM_MEM_SDDS_MODE_SHUB_SIZE 1
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_SIZE 8
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_SIZE 8

#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_SHIFT 0
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_ROP_SHUB_SHIFT 1
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_SHIFT 2
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_SHIFT 3
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_SHIFT 4
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_SHIFT 5
#define MPM_DFP_PGRAM_SHUB_CNTL_PGFSM_MEM_SDDS_EN_SHUB_SHIFT 6
#define MPM_DFP_PGRAM_SHUB_CNTL_PGFSM_MEM_SDDS_MODE_SHUB_SHIFT 7
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_SHIFT 8
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_SHIFT 16

#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_MASK 0x1
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_ROP_SHUB_MASK 0x2
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_MASK 0x4
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_MASK 0x8
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_MASK 0x10
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_MASK 0x20
#define MPM_DFP_PGRAM_SHUB_CNTL_PGFSM_MEM_SDDS_EN_SHUB_MASK 0x40
#define MPM_DFP_PGRAM_SHUB_CNTL_PGFSM_MEM_SDDS_MODE_SHUB_MASK 0x80
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_MASK 0xff00
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_MASK 0xff0000

#define MPM_DFP_PGRAM_SHUB_CNTL_MASK \
     (MPM_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_MASK | \
      MPM_DFP_PGRAM_SHUB_CNTL_MEM_ROP_SHUB_MASK | \
      MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_MASK | \
      MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_MASK | \
      MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_MASK | \
      MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_MASK | \
      MPM_DFP_PGRAM_SHUB_CNTL_PGFSM_MEM_SDDS_EN_SHUB_MASK | \
      MPM_DFP_PGRAM_SHUB_CNTL_PGFSM_MEM_SDDS_MODE_SHUB_MASK | \
      MPM_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_MASK | \
      MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_MASK)

#define MPM_DFP_PGRAM_SHUB_CNTL_DEFAULT 0x0010102a

#define MPM_DFP_PGRAM_SHUB_CNTL_GET_MEM_SD_SHUB(mpm_dfp_pgram_shub_cntl) \
     ((mpm_dfp_pgram_shub_cntl & MPM_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_MASK) >> MPM_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_GET_MEM_ROP_SHUB(mpm_dfp_pgram_shub_cntl) \
     ((mpm_dfp_pgram_shub_cntl & MPM_DFP_PGRAM_SHUB_CNTL_MEM_ROP_SHUB_MASK) >> MPM_DFP_PGRAM_SHUB_CNTL_MEM_ROP_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_GET_MEM_DEEP_SLEEP_EN_SHUB(mpm_dfp_pgram_shub_cntl) \
     ((mpm_dfp_pgram_shub_cntl & MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_MASK) >> MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_GET_MEM_DEEP_SLEEP_STATUS_SHUB(mpm_dfp_pgram_shub_cntl) \
     ((mpm_dfp_pgram_shub_cntl & MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_MASK) >> MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_GET_MEM_LIGHT_SLEEP_EN_SHUB(mpm_dfp_pgram_shub_cntl) \
     ((mpm_dfp_pgram_shub_cntl & MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_MASK) >> MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_SHUB(mpm_dfp_pgram_shub_cntl) \
     ((mpm_dfp_pgram_shub_cntl & MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_MASK) >> MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_GET_PGFSM_MEM_SDDS_EN_SHUB(mpm_dfp_pgram_shub_cntl) \
     ((mpm_dfp_pgram_shub_cntl & MPM_DFP_PGRAM_SHUB_CNTL_PGFSM_MEM_SDDS_EN_SHUB_MASK) >> MPM_DFP_PGRAM_SHUB_CNTL_PGFSM_MEM_SDDS_EN_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_GET_PGFSM_MEM_SDDS_MODE_SHUB(mpm_dfp_pgram_shub_cntl) \
     ((mpm_dfp_pgram_shub_cntl & MPM_DFP_PGRAM_SHUB_CNTL_PGFSM_MEM_SDDS_MODE_SHUB_MASK) >> MPM_DFP_PGRAM_SHUB_CNTL_PGFSM_MEM_SDDS_MODE_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_GET_MEM_SLEEP_TIMEOUT_SHUB(mpm_dfp_pgram_shub_cntl) \
     ((mpm_dfp_pgram_shub_cntl & MPM_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_MASK) >> MPM_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_GET_MEM_PG_DLY_SHUB(mpm_dfp_pgram_shub_cntl) \
     ((mpm_dfp_pgram_shub_cntl & MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_MASK) >> MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_SHIFT)

#define MPM_DFP_PGRAM_SHUB_CNTL_SET_MEM_SD_SHUB(mpm_dfp_pgram_shub_cntl_reg, mem_sd_shub) \
     mpm_dfp_pgram_shub_cntl_reg = (mpm_dfp_pgram_shub_cntl_reg & ~MPM_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_MASK) | (mem_sd_shub << MPM_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_SET_MEM_ROP_SHUB(mpm_dfp_pgram_shub_cntl_reg, mem_rop_shub) \
     mpm_dfp_pgram_shub_cntl_reg = (mpm_dfp_pgram_shub_cntl_reg & ~MPM_DFP_PGRAM_SHUB_CNTL_MEM_ROP_SHUB_MASK) | (mem_rop_shub << MPM_DFP_PGRAM_SHUB_CNTL_MEM_ROP_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_SET_MEM_DEEP_SLEEP_EN_SHUB(mpm_dfp_pgram_shub_cntl_reg, mem_deep_sleep_en_shub) \
     mpm_dfp_pgram_shub_cntl_reg = (mpm_dfp_pgram_shub_cntl_reg & ~MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_MASK) | (mem_deep_sleep_en_shub << MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_SET_MEM_DEEP_SLEEP_STATUS_SHUB(mpm_dfp_pgram_shub_cntl_reg, mem_deep_sleep_status_shub) \
     mpm_dfp_pgram_shub_cntl_reg = (mpm_dfp_pgram_shub_cntl_reg & ~MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_MASK) | (mem_deep_sleep_status_shub << MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_SET_MEM_LIGHT_SLEEP_EN_SHUB(mpm_dfp_pgram_shub_cntl_reg, mem_light_sleep_en_shub) \
     mpm_dfp_pgram_shub_cntl_reg = (mpm_dfp_pgram_shub_cntl_reg & ~MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_MASK) | (mem_light_sleep_en_shub << MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_SHUB(mpm_dfp_pgram_shub_cntl_reg, mem_light_sleep_status_shub) \
     mpm_dfp_pgram_shub_cntl_reg = (mpm_dfp_pgram_shub_cntl_reg & ~MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_MASK) | (mem_light_sleep_status_shub << MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_SET_PGFSM_MEM_SDDS_EN_SHUB(mpm_dfp_pgram_shub_cntl_reg, pgfsm_mem_sdds_en_shub) \
     mpm_dfp_pgram_shub_cntl_reg = (mpm_dfp_pgram_shub_cntl_reg & ~MPM_DFP_PGRAM_SHUB_CNTL_PGFSM_MEM_SDDS_EN_SHUB_MASK) | (pgfsm_mem_sdds_en_shub << MPM_DFP_PGRAM_SHUB_CNTL_PGFSM_MEM_SDDS_EN_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_SET_PGFSM_MEM_SDDS_MODE_SHUB(mpm_dfp_pgram_shub_cntl_reg, pgfsm_mem_sdds_mode_shub) \
     mpm_dfp_pgram_shub_cntl_reg = (mpm_dfp_pgram_shub_cntl_reg & ~MPM_DFP_PGRAM_SHUB_CNTL_PGFSM_MEM_SDDS_MODE_SHUB_MASK) | (pgfsm_mem_sdds_mode_shub << MPM_DFP_PGRAM_SHUB_CNTL_PGFSM_MEM_SDDS_MODE_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_SET_MEM_SLEEP_TIMEOUT_SHUB(mpm_dfp_pgram_shub_cntl_reg, mem_sleep_timeout_shub) \
     mpm_dfp_pgram_shub_cntl_reg = (mpm_dfp_pgram_shub_cntl_reg & ~MPM_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_MASK) | (mem_sleep_timeout_shub << MPM_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_SET_MEM_PG_DLY_SHUB(mpm_dfp_pgram_shub_cntl_reg, mem_pg_dly_shub) \
     mpm_dfp_pgram_shub_cntl_reg = (mpm_dfp_pgram_shub_cntl_reg & ~MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_MASK) | (mem_pg_dly_shub << MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_dfp_pgram_shub_cntl_t {
          unsigned int mem_sd_shub                    : MPM_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_SIZE;
          unsigned int mem_rop_shub                   : MPM_DFP_PGRAM_SHUB_CNTL_MEM_ROP_SHUB_SIZE;
          unsigned int mem_deep_sleep_en_shub         : MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_SIZE;
          unsigned int mem_deep_sleep_status_shub     : MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_SIZE;
          unsigned int mem_light_sleep_en_shub        : MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_SIZE;
          unsigned int mem_light_sleep_status_shub    : MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_SIZE;
          unsigned int pgfsm_mem_sdds_en_shub         : MPM_DFP_PGRAM_SHUB_CNTL_PGFSM_MEM_SDDS_EN_SHUB_SIZE;
          unsigned int pgfsm_mem_sdds_mode_shub       : MPM_DFP_PGRAM_SHUB_CNTL_PGFSM_MEM_SDDS_MODE_SHUB_SIZE;
          unsigned int mem_sleep_timeout_shub         : MPM_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_SIZE;
          unsigned int mem_pg_dly_shub                : MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_SIZE;
          unsigned int                                : 8;
     } mpm_dfp_pgram_shub_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_dfp_pgram_shub_cntl_t {
          unsigned int                                : 8;
          unsigned int mem_pg_dly_shub                : MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_SIZE;
          unsigned int mem_sleep_timeout_shub         : MPM_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_SIZE;
          unsigned int pgfsm_mem_sdds_mode_shub       : MPM_DFP_PGRAM_SHUB_CNTL_PGFSM_MEM_SDDS_MODE_SHUB_SIZE;
          unsigned int pgfsm_mem_sdds_en_shub         : MPM_DFP_PGRAM_SHUB_CNTL_PGFSM_MEM_SDDS_EN_SHUB_SIZE;
          unsigned int mem_light_sleep_status_shub    : MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_SIZE;
          unsigned int mem_light_sleep_en_shub        : MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_SIZE;
          unsigned int mem_deep_sleep_status_shub     : MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_SIZE;
          unsigned int mem_deep_sleep_en_shub         : MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_SIZE;
          unsigned int mem_rop_shub                   : MPM_DFP_PGRAM_SHUB_CNTL_MEM_ROP_SHUB_SIZE;
          unsigned int mem_sd_shub                    : MPM_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_SIZE;
     } mpm_dfp_pgram_shub_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_dfp_pgram_shub_cntl_t f;
} mpm_dfp_pgram_shub_cntl_u;


/*
 * MPM_DFP_SHUBCLKDS_CTRL struct
 */

#define MPM_DFP_SHUBCLKDS_CTRL_REG_SIZE 32
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_SIZE 1
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_SIZE 1
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_SIZE 8
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_SIZE 1
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_HUBIFNB_WAKE_MASK_SIZE 1

#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_SHIFT 0
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_SHIFT 1
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_SHIFT 2
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_SHIFT 10
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_HUBIFNB_WAKE_MASK_SHIFT 11

#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_MASK 0x1
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_MASK 0x2
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_MASK 0x3fc
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_MASK 0x400
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_HUBIFNB_WAKE_MASK_MASK 0x800

#define MPM_DFP_SHUBCLKDS_CTRL_MASK \
     (MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_MASK | \
      MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_MASK | \
      MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_MASK | \
      MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_MASK | \
      MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_HUBIFNB_WAKE_MASK_MASK)

#define MPM_DFP_SHUBCLKDS_CTRL_DEFAULT 0x00000ffc

#define MPM_DFP_SHUBCLKDS_CTRL_GET_SHUBCLK_DS_ENB(mpm_dfp_shubclkds_ctrl) \
     ((mpm_dfp_shubclkds_ctrl & MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_MASK) >> MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_SHIFT)
#define MPM_DFP_SHUBCLKDS_CTRL_GET_SHUBCLK_DS_STATUS(mpm_dfp_shubclkds_ctrl) \
     ((mpm_dfp_shubclkds_ctrl & MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_MASK) >> MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_SHIFT)
#define MPM_DFP_SHUBCLKDS_CTRL_GET_SHUBCLK_DS_TIMEOUT(mpm_dfp_shubclkds_ctrl) \
     ((mpm_dfp_shubclkds_ctrl & MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_MASK) >> MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_SHIFT)
#define MPM_DFP_SHUBCLKDS_CTRL_GET_SHUBCLK_SHUBIF_WAKE_MASK(mpm_dfp_shubclkds_ctrl) \
     ((mpm_dfp_shubclkds_ctrl & MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_MASK) >> MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_SHIFT)
#define MPM_DFP_SHUBCLKDS_CTRL_GET_SHUBCLK_HUBIFNB_WAKE_MASK(mpm_dfp_shubclkds_ctrl) \
     ((mpm_dfp_shubclkds_ctrl & MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_HUBIFNB_WAKE_MASK_MASK) >> MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_HUBIFNB_WAKE_MASK_SHIFT)

#define MPM_DFP_SHUBCLKDS_CTRL_SET_SHUBCLK_DS_ENB(mpm_dfp_shubclkds_ctrl_reg, shubclk_ds_enb) \
     mpm_dfp_shubclkds_ctrl_reg = (mpm_dfp_shubclkds_ctrl_reg & ~MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_MASK) | (shubclk_ds_enb << MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_SHIFT)
#define MPM_DFP_SHUBCLKDS_CTRL_SET_SHUBCLK_DS_STATUS(mpm_dfp_shubclkds_ctrl_reg, shubclk_ds_status) \
     mpm_dfp_shubclkds_ctrl_reg = (mpm_dfp_shubclkds_ctrl_reg & ~MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_MASK) | (shubclk_ds_status << MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_SHIFT)
#define MPM_DFP_SHUBCLKDS_CTRL_SET_SHUBCLK_DS_TIMEOUT(mpm_dfp_shubclkds_ctrl_reg, shubclk_ds_timeout) \
     mpm_dfp_shubclkds_ctrl_reg = (mpm_dfp_shubclkds_ctrl_reg & ~MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_MASK) | (shubclk_ds_timeout << MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_SHIFT)
#define MPM_DFP_SHUBCLKDS_CTRL_SET_SHUBCLK_SHUBIF_WAKE_MASK(mpm_dfp_shubclkds_ctrl_reg, shubclk_shubif_wake_mask) \
     mpm_dfp_shubclkds_ctrl_reg = (mpm_dfp_shubclkds_ctrl_reg & ~MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_MASK) | (shubclk_shubif_wake_mask << MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_SHIFT)
#define MPM_DFP_SHUBCLKDS_CTRL_SET_SHUBCLK_HUBIFNB_WAKE_MASK(mpm_dfp_shubclkds_ctrl_reg, shubclk_hubifnb_wake_mask) \
     mpm_dfp_shubclkds_ctrl_reg = (mpm_dfp_shubclkds_ctrl_reg & ~MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_HUBIFNB_WAKE_MASK_MASK) | (shubclk_hubifnb_wake_mask << MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_HUBIFNB_WAKE_MASK_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_dfp_shubclkds_ctrl_t {
          unsigned int shubclk_ds_enb                 : MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_SIZE;
          unsigned int shubclk_ds_status              : MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_SIZE;
          unsigned int shubclk_ds_timeout             : MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_SIZE;
          unsigned int shubclk_shubif_wake_mask       : MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_SIZE;
          unsigned int shubclk_hubifnb_wake_mask      : MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_HUBIFNB_WAKE_MASK_SIZE;
          unsigned int                                : 20;
     } mpm_dfp_shubclkds_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_dfp_shubclkds_ctrl_t {
          unsigned int                                : 20;
          unsigned int shubclk_hubifnb_wake_mask      : MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_HUBIFNB_WAKE_MASK_SIZE;
          unsigned int shubclk_shubif_wake_mask       : MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_SIZE;
          unsigned int shubclk_ds_timeout             : MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_SIZE;
          unsigned int shubclk_ds_status              : MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_SIZE;
          unsigned int shubclk_ds_enb                 : MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_SIZE;
     } mpm_dfp_shubclkds_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_dfp_shubclkds_ctrl_t f;
} mpm_dfp_shubclkds_ctrl_u;


/*
 * MPM_PG_PUB_STATUS struct
 */

#define MPM_PG_PUB_STATUS_REG_SIZE     32
#define MPM_PG_PUB_STATUS_PG_IDLE_SIZE 1
#define MPM_PG_PUB_STATUS_SAFE_IDLE_SIZE 1
#define MPM_PG_PUB_STATUS_S0I2X_IDLE_SIZE 1
#define MPM_PG_PUB_STATUS_ACTIVE_SIZE  1

#define MPM_PG_PUB_STATUS_PG_IDLE_SHIFT 0
#define MPM_PG_PUB_STATUS_SAFE_IDLE_SHIFT 1
#define MPM_PG_PUB_STATUS_S0I2X_IDLE_SHIFT 2
#define MPM_PG_PUB_STATUS_ACTIVE_SHIFT 3

#define MPM_PG_PUB_STATUS_PG_IDLE_MASK 0x1
#define MPM_PG_PUB_STATUS_SAFE_IDLE_MASK 0x2
#define MPM_PG_PUB_STATUS_S0I2X_IDLE_MASK 0x4
#define MPM_PG_PUB_STATUS_ACTIVE_MASK  0x8

#define MPM_PG_PUB_STATUS_MASK \
     (MPM_PG_PUB_STATUS_PG_IDLE_MASK | \
      MPM_PG_PUB_STATUS_SAFE_IDLE_MASK | \
      MPM_PG_PUB_STATUS_S0I2X_IDLE_MASK | \
      MPM_PG_PUB_STATUS_ACTIVE_MASK)

#define MPM_PG_PUB_STATUS_DEFAULT      0x00000000

#define MPM_PG_PUB_STATUS_GET_PG_IDLE(mpm_pg_pub_status) \
     ((mpm_pg_pub_status & MPM_PG_PUB_STATUS_PG_IDLE_MASK) >> MPM_PG_PUB_STATUS_PG_IDLE_SHIFT)
#define MPM_PG_PUB_STATUS_GET_SAFE_IDLE(mpm_pg_pub_status) \
     ((mpm_pg_pub_status & MPM_PG_PUB_STATUS_SAFE_IDLE_MASK) >> MPM_PG_PUB_STATUS_SAFE_IDLE_SHIFT)
#define MPM_PG_PUB_STATUS_GET_S0I2X_IDLE(mpm_pg_pub_status) \
     ((mpm_pg_pub_status & MPM_PG_PUB_STATUS_S0I2X_IDLE_MASK) >> MPM_PG_PUB_STATUS_S0I2X_IDLE_SHIFT)
#define MPM_PG_PUB_STATUS_GET_ACTIVE(mpm_pg_pub_status) \
     ((mpm_pg_pub_status & MPM_PG_PUB_STATUS_ACTIVE_MASK) >> MPM_PG_PUB_STATUS_ACTIVE_SHIFT)

#define MPM_PG_PUB_STATUS_SET_PG_IDLE(mpm_pg_pub_status_reg, pg_idle) \
     mpm_pg_pub_status_reg = (mpm_pg_pub_status_reg & ~MPM_PG_PUB_STATUS_PG_IDLE_MASK) | (pg_idle << MPM_PG_PUB_STATUS_PG_IDLE_SHIFT)
#define MPM_PG_PUB_STATUS_SET_SAFE_IDLE(mpm_pg_pub_status_reg, safe_idle) \
     mpm_pg_pub_status_reg = (mpm_pg_pub_status_reg & ~MPM_PG_PUB_STATUS_SAFE_IDLE_MASK) | (safe_idle << MPM_PG_PUB_STATUS_SAFE_IDLE_SHIFT)
#define MPM_PG_PUB_STATUS_SET_S0I2X_IDLE(mpm_pg_pub_status_reg, s0i2x_idle) \
     mpm_pg_pub_status_reg = (mpm_pg_pub_status_reg & ~MPM_PG_PUB_STATUS_S0I2X_IDLE_MASK) | (s0i2x_idle << MPM_PG_PUB_STATUS_S0I2X_IDLE_SHIFT)
#define MPM_PG_PUB_STATUS_SET_ACTIVE(mpm_pg_pub_status_reg, active) \
     mpm_pg_pub_status_reg = (mpm_pg_pub_status_reg & ~MPM_PG_PUB_STATUS_ACTIVE_MASK) | (active << MPM_PG_PUB_STATUS_ACTIVE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mpm_pg_pub_status_t {
          unsigned int pg_idle                        : MPM_PG_PUB_STATUS_PG_IDLE_SIZE;
          unsigned int safe_idle                      : MPM_PG_PUB_STATUS_SAFE_IDLE_SIZE;
          unsigned int s0i2x_idle                     : MPM_PG_PUB_STATUS_S0I2X_IDLE_SIZE;
          unsigned int active                         : MPM_PG_PUB_STATUS_ACTIVE_SIZE;
          unsigned int                                : 28;
     } mpm_pg_pub_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mpm_pg_pub_status_t {
          unsigned int                                : 28;
          unsigned int active                         : MPM_PG_PUB_STATUS_ACTIVE_SIZE;
          unsigned int s0i2x_idle                     : MPM_PG_PUB_STATUS_S0I2X_IDLE_SIZE;
          unsigned int safe_idle                      : MPM_PG_PUB_STATUS_SAFE_IDLE_SIZE;
          unsigned int pg_idle                        : MPM_PG_PUB_STATUS_PG_IDLE_SIZE;
     } mpm_pg_pub_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mpm_pg_pub_status_t f;
} mpm_pg_pub_status_u;


#endif


