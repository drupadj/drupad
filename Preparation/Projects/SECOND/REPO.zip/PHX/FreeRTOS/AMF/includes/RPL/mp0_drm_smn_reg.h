// Copyright (c) 1994 - 2021 Advanced Micro Devices, Inc. All rights reserved. 
 #if !defined (_MP0_DRM_SMN_FIDDLE_H)
#define _MP0_DRM_SMN_FIDDLE_H
 /*****************************************************************************************************************
 *
 *  mp0_drm_smn_reg.h
 *
 *  Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif

 /*******************************************************
 * Values
 *******************************************************/

 /*******************************************************
 * Structures
 *******************************************************/

/*
 * MP0_SMN_DRM_KEYGEN_START struct
 */

#define MP0_SMN_DRM_KEYGEN_START_REG_SIZE         32
#define MP0_SMN_DRM_KEYGEN_START_RESERVED_SIZE  32

#define MP0_SMN_DRM_KEYGEN_START_RESERVED_SHIFT  0

#define MP0_SMN_DRM_KEYGEN_START_RESERVED_MASK  0xffffffff

#define MP0_SMN_DRM_KEYGEN_START_MASK \
      (MP0_SMN_DRM_KEYGEN_START_RESERVED_MASK)

#define MP0_SMN_DRM_KEYGEN_START_DEFAULT 0x00000000

#define MP0_SMN_DRM_KEYGEN_START_GET_RESERVED(mp0_smn_drm_keygen_start) \
      ((mp0_smn_drm_keygen_start & MP0_SMN_DRM_KEYGEN_START_RESERVED_MASK) >> MP0_SMN_DRM_KEYGEN_START_RESERVED_SHIFT)

#define MP0_SMN_DRM_KEYGEN_START_SET_RESERVED(mp0_smn_drm_keygen_start_reg, reserved) \
      mp0_smn_drm_keygen_start_reg = (mp0_smn_drm_keygen_start_reg & ~MP0_SMN_DRM_KEYGEN_START_RESERVED_MASK) | (reserved << MP0_SMN_DRM_KEYGEN_START_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_keygen_start_t {
            unsigned int reserved                       : MP0_SMN_DRM_KEYGEN_START_RESERVED_SIZE;
      } mp0_smn_drm_keygen_start_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_keygen_start_t {
            unsigned int reserved                       : MP0_SMN_DRM_KEYGEN_START_RESERVED_SIZE;
      } mp0_smn_drm_keygen_start_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_keygen_start_t f;
} mp0_smn_drm_keygen_start_u;


/*
 * MP0_SMN_DRM_KEYGEN_CONT struct
 */

#define MP0_SMN_DRM_KEYGEN_CONT_REG_SIZE         32
#define MP0_SMN_DRM_KEYGEN_CONT_RESERVED_SIZE  32

#define MP0_SMN_DRM_KEYGEN_CONT_RESERVED_SHIFT  0

#define MP0_SMN_DRM_KEYGEN_CONT_RESERVED_MASK  0xffffffff

#define MP0_SMN_DRM_KEYGEN_CONT_MASK \
      (MP0_SMN_DRM_KEYGEN_CONT_RESERVED_MASK)

#define MP0_SMN_DRM_KEYGEN_CONT_DEFAULT 0x00000000

#define MP0_SMN_DRM_KEYGEN_CONT_GET_RESERVED(mp0_smn_drm_keygen_cont) \
      ((mp0_smn_drm_keygen_cont & MP0_SMN_DRM_KEYGEN_CONT_RESERVED_MASK) >> MP0_SMN_DRM_KEYGEN_CONT_RESERVED_SHIFT)

#define MP0_SMN_DRM_KEYGEN_CONT_SET_RESERVED(mp0_smn_drm_keygen_cont_reg, reserved) \
      mp0_smn_drm_keygen_cont_reg = (mp0_smn_drm_keygen_cont_reg & ~MP0_SMN_DRM_KEYGEN_CONT_RESERVED_MASK) | (reserved << MP0_SMN_DRM_KEYGEN_CONT_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_keygen_cont_t {
            unsigned int reserved                       : MP0_SMN_DRM_KEYGEN_CONT_RESERVED_SIZE;
      } mp0_smn_drm_keygen_cont_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_keygen_cont_t {
            unsigned int reserved                       : MP0_SMN_DRM_KEYGEN_CONT_RESERVED_SIZE;
      } mp0_smn_drm_keygen_cont_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_keygen_cont_t f;
} mp0_smn_drm_keygen_cont_u;


/*
 * MP0_SMN_DRM_KEYGEN_RADDR struct
 */

#define MP0_SMN_DRM_KEYGEN_RADDR_REG_SIZE         32
#define MP0_SMN_DRM_KEYGEN_RADDR_RADDR_SIZE  6

#define MP0_SMN_DRM_KEYGEN_RADDR_RADDR_SHIFT  0

#define MP0_SMN_DRM_KEYGEN_RADDR_RADDR_MASK  0x0000003f

#define MP0_SMN_DRM_KEYGEN_RADDR_MASK \
      (MP0_SMN_DRM_KEYGEN_RADDR_RADDR_MASK)

#define MP0_SMN_DRM_KEYGEN_RADDR_DEFAULT 0x00000000

#define MP0_SMN_DRM_KEYGEN_RADDR_GET_RADDR(mp0_smn_drm_keygen_raddr) \
      ((mp0_smn_drm_keygen_raddr & MP0_SMN_DRM_KEYGEN_RADDR_RADDR_MASK) >> MP0_SMN_DRM_KEYGEN_RADDR_RADDR_SHIFT)

#define MP0_SMN_DRM_KEYGEN_RADDR_SET_RADDR(mp0_smn_drm_keygen_raddr_reg, raddr) \
      mp0_smn_drm_keygen_raddr_reg = (mp0_smn_drm_keygen_raddr_reg & ~MP0_SMN_DRM_KEYGEN_RADDR_RADDR_MASK) | (raddr << MP0_SMN_DRM_KEYGEN_RADDR_RADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_keygen_raddr_t {
            unsigned int raddr                          : MP0_SMN_DRM_KEYGEN_RADDR_RADDR_SIZE;
            unsigned int                                : 26;
      } mp0_smn_drm_keygen_raddr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_keygen_raddr_t {
            unsigned int                                : 26;
            unsigned int raddr                          : MP0_SMN_DRM_KEYGEN_RADDR_RADDR_SIZE;
      } mp0_smn_drm_keygen_raddr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_keygen_raddr_t f;
} mp0_smn_drm_keygen_raddr_u;


/*
 * MP0_SMN_DRM_KEYGEN_RDATA struct
 */

#define MP0_SMN_DRM_KEYGEN_RDATA_REG_SIZE         32
#define MP0_SMN_DRM_KEYGEN_RDATA_RDATA_SIZE  32

#define MP0_SMN_DRM_KEYGEN_RDATA_RDATA_SHIFT  0

#define MP0_SMN_DRM_KEYGEN_RDATA_RDATA_MASK  0xffffffff

#define MP0_SMN_DRM_KEYGEN_RDATA_MASK \
      (MP0_SMN_DRM_KEYGEN_RDATA_RDATA_MASK)

#define MP0_SMN_DRM_KEYGEN_RDATA_DEFAULT 0x00000000

#define MP0_SMN_DRM_KEYGEN_RDATA_GET_RDATA(mp0_smn_drm_keygen_rdata) \
      ((mp0_smn_drm_keygen_rdata & MP0_SMN_DRM_KEYGEN_RDATA_RDATA_MASK) >> MP0_SMN_DRM_KEYGEN_RDATA_RDATA_SHIFT)

#define MP0_SMN_DRM_KEYGEN_RDATA_SET_RDATA(mp0_smn_drm_keygen_rdata_reg, rdata) \
      mp0_smn_drm_keygen_rdata_reg = (mp0_smn_drm_keygen_rdata_reg & ~MP0_SMN_DRM_KEYGEN_RDATA_RDATA_MASK) | (rdata << MP0_SMN_DRM_KEYGEN_RDATA_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_keygen_rdata_t {
            unsigned int rdata                          : MP0_SMN_DRM_KEYGEN_RDATA_RDATA_SIZE;
      } mp0_smn_drm_keygen_rdata_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_keygen_rdata_t {
            unsigned int rdata                          : MP0_SMN_DRM_KEYGEN_RDATA_RDATA_SIZE;
      } mp0_smn_drm_keygen_rdata_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_keygen_rdata_t f;
} mp0_smn_drm_keygen_rdata_u;


/*
 * MP0_SMN_DRM_KEYGEN_WADDR struct
 */

#define MP0_SMN_DRM_KEYGEN_WADDR_REG_SIZE         32
#define MP0_SMN_DRM_KEYGEN_WADDR_WADDR_SIZE  6

#define MP0_SMN_DRM_KEYGEN_WADDR_WADDR_SHIFT  0

#define MP0_SMN_DRM_KEYGEN_WADDR_WADDR_MASK  0x0000003f

#define MP0_SMN_DRM_KEYGEN_WADDR_MASK \
      (MP0_SMN_DRM_KEYGEN_WADDR_WADDR_MASK)

#define MP0_SMN_DRM_KEYGEN_WADDR_DEFAULT 0x00000000

#define MP0_SMN_DRM_KEYGEN_WADDR_GET_WADDR(mp0_smn_drm_keygen_waddr) \
      ((mp0_smn_drm_keygen_waddr & MP0_SMN_DRM_KEYGEN_WADDR_WADDR_MASK) >> MP0_SMN_DRM_KEYGEN_WADDR_WADDR_SHIFT)

#define MP0_SMN_DRM_KEYGEN_WADDR_SET_WADDR(mp0_smn_drm_keygen_waddr_reg, waddr) \
      mp0_smn_drm_keygen_waddr_reg = (mp0_smn_drm_keygen_waddr_reg & ~MP0_SMN_DRM_KEYGEN_WADDR_WADDR_MASK) | (waddr << MP0_SMN_DRM_KEYGEN_WADDR_WADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_keygen_waddr_t {
            unsigned int waddr                          : MP0_SMN_DRM_KEYGEN_WADDR_WADDR_SIZE;
            unsigned int                                : 26;
      } mp0_smn_drm_keygen_waddr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_keygen_waddr_t {
            unsigned int                                : 26;
            unsigned int waddr                          : MP0_SMN_DRM_KEYGEN_WADDR_WADDR_SIZE;
      } mp0_smn_drm_keygen_waddr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_keygen_waddr_t f;
} mp0_smn_drm_keygen_waddr_u;


/*
 * MP0_SMN_DRM_KEYGEN_WDATA struct
 */

#define MP0_SMN_DRM_KEYGEN_WDATA_REG_SIZE         32
#define MP0_SMN_DRM_KEYGEN_WDATA_WDATA_SIZE  32

#define MP0_SMN_DRM_KEYGEN_WDATA_WDATA_SHIFT  0

#define MP0_SMN_DRM_KEYGEN_WDATA_WDATA_MASK  0xffffffff

#define MP0_SMN_DRM_KEYGEN_WDATA_MASK \
      (MP0_SMN_DRM_KEYGEN_WDATA_WDATA_MASK)

#define MP0_SMN_DRM_KEYGEN_WDATA_DEFAULT 0x00000000

#define MP0_SMN_DRM_KEYGEN_WDATA_GET_WDATA(mp0_smn_drm_keygen_wdata) \
      ((mp0_smn_drm_keygen_wdata & MP0_SMN_DRM_KEYGEN_WDATA_WDATA_MASK) >> MP0_SMN_DRM_KEYGEN_WDATA_WDATA_SHIFT)

#define MP0_SMN_DRM_KEYGEN_WDATA_SET_WDATA(mp0_smn_drm_keygen_wdata_reg, wdata) \
      mp0_smn_drm_keygen_wdata_reg = (mp0_smn_drm_keygen_wdata_reg & ~MP0_SMN_DRM_KEYGEN_WDATA_WDATA_MASK) | (wdata << MP0_SMN_DRM_KEYGEN_WDATA_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_keygen_wdata_t {
            unsigned int wdata                          : MP0_SMN_DRM_KEYGEN_WDATA_WDATA_SIZE;
      } mp0_smn_drm_keygen_wdata_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_keygen_wdata_t {
            unsigned int wdata                          : MP0_SMN_DRM_KEYGEN_WDATA_WDATA_SIZE;
      } mp0_smn_drm_keygen_wdata_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_keygen_wdata_t f;
} mp0_smn_drm_keygen_wdata_u;


/*
 * MP0_SMN_DRM_HFS_START struct
 */

#define MP0_SMN_DRM_HFS_START_REG_SIZE         32
#define MP0_SMN_DRM_HFS_START_HFS_TYPE_SIZE  4

#define MP0_SMN_DRM_HFS_START_HFS_TYPE_SHIFT  0

#define MP0_SMN_DRM_HFS_START_HFS_TYPE_MASK  0x0000000f

#define MP0_SMN_DRM_HFS_START_MASK \
      (MP0_SMN_DRM_HFS_START_HFS_TYPE_MASK)

#define MP0_SMN_DRM_HFS_START_DEFAULT  0x00000000

#define MP0_SMN_DRM_HFS_START_GET_HFS_TYPE(mp0_smn_drm_hfs_start) \
      ((mp0_smn_drm_hfs_start & MP0_SMN_DRM_HFS_START_HFS_TYPE_MASK) >> MP0_SMN_DRM_HFS_START_HFS_TYPE_SHIFT)

#define MP0_SMN_DRM_HFS_START_SET_HFS_TYPE(mp0_smn_drm_hfs_start_reg, hfs_type) \
      mp0_smn_drm_hfs_start_reg = (mp0_smn_drm_hfs_start_reg & ~MP0_SMN_DRM_HFS_START_HFS_TYPE_MASK) | (hfs_type << MP0_SMN_DRM_HFS_START_HFS_TYPE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_hfs_start_t {
            unsigned int hfs_type                       : MP0_SMN_DRM_HFS_START_HFS_TYPE_SIZE;
            unsigned int                                : 28;
      } mp0_smn_drm_hfs_start_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_hfs_start_t {
            unsigned int                                : 28;
            unsigned int hfs_type                       : MP0_SMN_DRM_HFS_START_HFS_TYPE_SIZE;
      } mp0_smn_drm_hfs_start_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_hfs_start_t f;
} mp0_smn_drm_hfs_start_u;


/*
 * MP0_SMN_DRM_HFS_SW_NONCE0 struct
 */

#define MP0_SMN_DRM_HFS_SW_NONCE0_REG_SIZE         32
#define MP0_SMN_DRM_HFS_SW_NONCE0_SW_NONCE_SIZE  32

#define MP0_SMN_DRM_HFS_SW_NONCE0_SW_NONCE_SHIFT  0

#define MP0_SMN_DRM_HFS_SW_NONCE0_SW_NONCE_MASK  0xffffffff

#define MP0_SMN_DRM_HFS_SW_NONCE0_MASK \
      (MP0_SMN_DRM_HFS_SW_NONCE0_SW_NONCE_MASK)

#define MP0_SMN_DRM_HFS_SW_NONCE0_DEFAULT 0x00000000

#define MP0_SMN_DRM_HFS_SW_NONCE0_GET_SW_NONCE(mp0_smn_drm_hfs_sw_nonce0) \
      ((mp0_smn_drm_hfs_sw_nonce0 & MP0_SMN_DRM_HFS_SW_NONCE0_SW_NONCE_MASK) >> MP0_SMN_DRM_HFS_SW_NONCE0_SW_NONCE_SHIFT)

#define MP0_SMN_DRM_HFS_SW_NONCE0_SET_SW_NONCE(mp0_smn_drm_hfs_sw_nonce0_reg, sw_nonce) \
      mp0_smn_drm_hfs_sw_nonce0_reg = (mp0_smn_drm_hfs_sw_nonce0_reg & ~MP0_SMN_DRM_HFS_SW_NONCE0_SW_NONCE_MASK) | (sw_nonce << MP0_SMN_DRM_HFS_SW_NONCE0_SW_NONCE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_hfs_sw_nonce0_t {
            unsigned int sw_nonce                       : MP0_SMN_DRM_HFS_SW_NONCE0_SW_NONCE_SIZE;
      } mp0_smn_drm_hfs_sw_nonce0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_hfs_sw_nonce0_t {
            unsigned int sw_nonce                       : MP0_SMN_DRM_HFS_SW_NONCE0_SW_NONCE_SIZE;
      } mp0_smn_drm_hfs_sw_nonce0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_hfs_sw_nonce0_t f;
} mp0_smn_drm_hfs_sw_nonce0_u;


/*
 * MP0_SMN_DRM_HFS_SW_NONCE1 struct
 */

#define MP0_SMN_DRM_HFS_SW_NONCE1_REG_SIZE         32
#define MP0_SMN_DRM_HFS_SW_NONCE1_SW_NONCE_SIZE  32

#define MP0_SMN_DRM_HFS_SW_NONCE1_SW_NONCE_SHIFT  0

#define MP0_SMN_DRM_HFS_SW_NONCE1_SW_NONCE_MASK  0xffffffff

#define MP0_SMN_DRM_HFS_SW_NONCE1_MASK \
      (MP0_SMN_DRM_HFS_SW_NONCE1_SW_NONCE_MASK)

#define MP0_SMN_DRM_HFS_SW_NONCE1_DEFAULT 0x00000000

#define MP0_SMN_DRM_HFS_SW_NONCE1_GET_SW_NONCE(mp0_smn_drm_hfs_sw_nonce1) \
      ((mp0_smn_drm_hfs_sw_nonce1 & MP0_SMN_DRM_HFS_SW_NONCE1_SW_NONCE_MASK) >> MP0_SMN_DRM_HFS_SW_NONCE1_SW_NONCE_SHIFT)

#define MP0_SMN_DRM_HFS_SW_NONCE1_SET_SW_NONCE(mp0_smn_drm_hfs_sw_nonce1_reg, sw_nonce) \
      mp0_smn_drm_hfs_sw_nonce1_reg = (mp0_smn_drm_hfs_sw_nonce1_reg & ~MP0_SMN_DRM_HFS_SW_NONCE1_SW_NONCE_MASK) | (sw_nonce << MP0_SMN_DRM_HFS_SW_NONCE1_SW_NONCE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_hfs_sw_nonce1_t {
            unsigned int sw_nonce                       : MP0_SMN_DRM_HFS_SW_NONCE1_SW_NONCE_SIZE;
      } mp0_smn_drm_hfs_sw_nonce1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_hfs_sw_nonce1_t {
            unsigned int sw_nonce                       : MP0_SMN_DRM_HFS_SW_NONCE1_SW_NONCE_SIZE;
      } mp0_smn_drm_hfs_sw_nonce1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_hfs_sw_nonce1_t f;
} mp0_smn_drm_hfs_sw_nonce1_u;


/*
 * MP0_SMN_DRM_HFS_SW_NONCE2 struct
 */

#define MP0_SMN_DRM_HFS_SW_NONCE2_REG_SIZE         32
#define MP0_SMN_DRM_HFS_SW_NONCE2_SW_NONCE_SIZE  32

#define MP0_SMN_DRM_HFS_SW_NONCE2_SW_NONCE_SHIFT  0

#define MP0_SMN_DRM_HFS_SW_NONCE2_SW_NONCE_MASK  0xffffffff

#define MP0_SMN_DRM_HFS_SW_NONCE2_MASK \
      (MP0_SMN_DRM_HFS_SW_NONCE2_SW_NONCE_MASK)

#define MP0_SMN_DRM_HFS_SW_NONCE2_DEFAULT 0x00000000

#define MP0_SMN_DRM_HFS_SW_NONCE2_GET_SW_NONCE(mp0_smn_drm_hfs_sw_nonce2) \
      ((mp0_smn_drm_hfs_sw_nonce2 & MP0_SMN_DRM_HFS_SW_NONCE2_SW_NONCE_MASK) >> MP0_SMN_DRM_HFS_SW_NONCE2_SW_NONCE_SHIFT)

#define MP0_SMN_DRM_HFS_SW_NONCE2_SET_SW_NONCE(mp0_smn_drm_hfs_sw_nonce2_reg, sw_nonce) \
      mp0_smn_drm_hfs_sw_nonce2_reg = (mp0_smn_drm_hfs_sw_nonce2_reg & ~MP0_SMN_DRM_HFS_SW_NONCE2_SW_NONCE_MASK) | (sw_nonce << MP0_SMN_DRM_HFS_SW_NONCE2_SW_NONCE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_hfs_sw_nonce2_t {
            unsigned int sw_nonce                       : MP0_SMN_DRM_HFS_SW_NONCE2_SW_NONCE_SIZE;
      } mp0_smn_drm_hfs_sw_nonce2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_hfs_sw_nonce2_t {
            unsigned int sw_nonce                       : MP0_SMN_DRM_HFS_SW_NONCE2_SW_NONCE_SIZE;
      } mp0_smn_drm_hfs_sw_nonce2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_hfs_sw_nonce2_t f;
} mp0_smn_drm_hfs_sw_nonce2_u;


/*
 * MP0_SMN_DRM_HFS_SW_NONCE3 struct
 */

#define MP0_SMN_DRM_HFS_SW_NONCE3_REG_SIZE         32
#define MP0_SMN_DRM_HFS_SW_NONCE3_SW_NONCE_SIZE  32

#define MP0_SMN_DRM_HFS_SW_NONCE3_SW_NONCE_SHIFT  0

#define MP0_SMN_DRM_HFS_SW_NONCE3_SW_NONCE_MASK  0xffffffff

#define MP0_SMN_DRM_HFS_SW_NONCE3_MASK \
      (MP0_SMN_DRM_HFS_SW_NONCE3_SW_NONCE_MASK)

#define MP0_SMN_DRM_HFS_SW_NONCE3_DEFAULT 0x00000000

#define MP0_SMN_DRM_HFS_SW_NONCE3_GET_SW_NONCE(mp0_smn_drm_hfs_sw_nonce3) \
      ((mp0_smn_drm_hfs_sw_nonce3 & MP0_SMN_DRM_HFS_SW_NONCE3_SW_NONCE_MASK) >> MP0_SMN_DRM_HFS_SW_NONCE3_SW_NONCE_SHIFT)

#define MP0_SMN_DRM_HFS_SW_NONCE3_SET_SW_NONCE(mp0_smn_drm_hfs_sw_nonce3_reg, sw_nonce) \
      mp0_smn_drm_hfs_sw_nonce3_reg = (mp0_smn_drm_hfs_sw_nonce3_reg & ~MP0_SMN_DRM_HFS_SW_NONCE3_SW_NONCE_MASK) | (sw_nonce << MP0_SMN_DRM_HFS_SW_NONCE3_SW_NONCE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_hfs_sw_nonce3_t {
            unsigned int sw_nonce                       : MP0_SMN_DRM_HFS_SW_NONCE3_SW_NONCE_SIZE;
      } mp0_smn_drm_hfs_sw_nonce3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_hfs_sw_nonce3_t {
            unsigned int sw_nonce                       : MP0_SMN_DRM_HFS_SW_NONCE3_SW_NONCE_SIZE;
      } mp0_smn_drm_hfs_sw_nonce3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_hfs_sw_nonce3_t f;
} mp0_smn_drm_hfs_sw_nonce3_u;


/*
 * MP0_SMN_DRM_HFS_HW_NONCE0 struct
 */

#define MP0_SMN_DRM_HFS_HW_NONCE0_REG_SIZE         32
#define MP0_SMN_DRM_HFS_HW_NONCE0_HW_NONCE_SIZE  32

#define MP0_SMN_DRM_HFS_HW_NONCE0_HW_NONCE_SHIFT  0

#define MP0_SMN_DRM_HFS_HW_NONCE0_HW_NONCE_MASK  0xffffffff

#define MP0_SMN_DRM_HFS_HW_NONCE0_MASK \
      (MP0_SMN_DRM_HFS_HW_NONCE0_HW_NONCE_MASK)

#define MP0_SMN_DRM_HFS_HW_NONCE0_DEFAULT 0x00000000

#define MP0_SMN_DRM_HFS_HW_NONCE0_GET_HW_NONCE(mp0_smn_drm_hfs_hw_nonce0) \
      ((mp0_smn_drm_hfs_hw_nonce0 & MP0_SMN_DRM_HFS_HW_NONCE0_HW_NONCE_MASK) >> MP0_SMN_DRM_HFS_HW_NONCE0_HW_NONCE_SHIFT)

#define MP0_SMN_DRM_HFS_HW_NONCE0_SET_HW_NONCE(mp0_smn_drm_hfs_hw_nonce0_reg, hw_nonce) \
      mp0_smn_drm_hfs_hw_nonce0_reg = (mp0_smn_drm_hfs_hw_nonce0_reg & ~MP0_SMN_DRM_HFS_HW_NONCE0_HW_NONCE_MASK) | (hw_nonce << MP0_SMN_DRM_HFS_HW_NONCE0_HW_NONCE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_hfs_hw_nonce0_t {
            unsigned int hw_nonce                       : MP0_SMN_DRM_HFS_HW_NONCE0_HW_NONCE_SIZE;
      } mp0_smn_drm_hfs_hw_nonce0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_hfs_hw_nonce0_t {
            unsigned int hw_nonce                       : MP0_SMN_DRM_HFS_HW_NONCE0_HW_NONCE_SIZE;
      } mp0_smn_drm_hfs_hw_nonce0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_hfs_hw_nonce0_t f;
} mp0_smn_drm_hfs_hw_nonce0_u;


/*
 * MP0_SMN_DRM_HFS_HW_NONCE1 struct
 */

#define MP0_SMN_DRM_HFS_HW_NONCE1_REG_SIZE         32
#define MP0_SMN_DRM_HFS_HW_NONCE1_HW_NONCE_SIZE  32

#define MP0_SMN_DRM_HFS_HW_NONCE1_HW_NONCE_SHIFT  0

#define MP0_SMN_DRM_HFS_HW_NONCE1_HW_NONCE_MASK  0xffffffff

#define MP0_SMN_DRM_HFS_HW_NONCE1_MASK \
      (MP0_SMN_DRM_HFS_HW_NONCE1_HW_NONCE_MASK)

#define MP0_SMN_DRM_HFS_HW_NONCE1_DEFAULT 0x00000000

#define MP0_SMN_DRM_HFS_HW_NONCE1_GET_HW_NONCE(mp0_smn_drm_hfs_hw_nonce1) \
      ((mp0_smn_drm_hfs_hw_nonce1 & MP0_SMN_DRM_HFS_HW_NONCE1_HW_NONCE_MASK) >> MP0_SMN_DRM_HFS_HW_NONCE1_HW_NONCE_SHIFT)

#define MP0_SMN_DRM_HFS_HW_NONCE1_SET_HW_NONCE(mp0_smn_drm_hfs_hw_nonce1_reg, hw_nonce) \
      mp0_smn_drm_hfs_hw_nonce1_reg = (mp0_smn_drm_hfs_hw_nonce1_reg & ~MP0_SMN_DRM_HFS_HW_NONCE1_HW_NONCE_MASK) | (hw_nonce << MP0_SMN_DRM_HFS_HW_NONCE1_HW_NONCE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_hfs_hw_nonce1_t {
            unsigned int hw_nonce                       : MP0_SMN_DRM_HFS_HW_NONCE1_HW_NONCE_SIZE;
      } mp0_smn_drm_hfs_hw_nonce1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_hfs_hw_nonce1_t {
            unsigned int hw_nonce                       : MP0_SMN_DRM_HFS_HW_NONCE1_HW_NONCE_SIZE;
      } mp0_smn_drm_hfs_hw_nonce1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_hfs_hw_nonce1_t f;
} mp0_smn_drm_hfs_hw_nonce1_u;


/*
 * MP0_SMN_DRM_HFS_HW_NONCE2 struct
 */

#define MP0_SMN_DRM_HFS_HW_NONCE2_REG_SIZE         32
#define MP0_SMN_DRM_HFS_HW_NONCE2_HW_NONCE_SIZE  32

#define MP0_SMN_DRM_HFS_HW_NONCE2_HW_NONCE_SHIFT  0

#define MP0_SMN_DRM_HFS_HW_NONCE2_HW_NONCE_MASK  0xffffffff

#define MP0_SMN_DRM_HFS_HW_NONCE2_MASK \
      (MP0_SMN_DRM_HFS_HW_NONCE2_HW_NONCE_MASK)

#define MP0_SMN_DRM_HFS_HW_NONCE2_DEFAULT 0x00000000

#define MP0_SMN_DRM_HFS_HW_NONCE2_GET_HW_NONCE(mp0_smn_drm_hfs_hw_nonce2) \
      ((mp0_smn_drm_hfs_hw_nonce2 & MP0_SMN_DRM_HFS_HW_NONCE2_HW_NONCE_MASK) >> MP0_SMN_DRM_HFS_HW_NONCE2_HW_NONCE_SHIFT)

#define MP0_SMN_DRM_HFS_HW_NONCE2_SET_HW_NONCE(mp0_smn_drm_hfs_hw_nonce2_reg, hw_nonce) \
      mp0_smn_drm_hfs_hw_nonce2_reg = (mp0_smn_drm_hfs_hw_nonce2_reg & ~MP0_SMN_DRM_HFS_HW_NONCE2_HW_NONCE_MASK) | (hw_nonce << MP0_SMN_DRM_HFS_HW_NONCE2_HW_NONCE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_hfs_hw_nonce2_t {
            unsigned int hw_nonce                       : MP0_SMN_DRM_HFS_HW_NONCE2_HW_NONCE_SIZE;
      } mp0_smn_drm_hfs_hw_nonce2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_hfs_hw_nonce2_t {
            unsigned int hw_nonce                       : MP0_SMN_DRM_HFS_HW_NONCE2_HW_NONCE_SIZE;
      } mp0_smn_drm_hfs_hw_nonce2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_hfs_hw_nonce2_t f;
} mp0_smn_drm_hfs_hw_nonce2_u;


/*
 * MP0_SMN_DRM_HFS_HW_NONCE3 struct
 */

#define MP0_SMN_DRM_HFS_HW_NONCE3_REG_SIZE         32
#define MP0_SMN_DRM_HFS_HW_NONCE3_HW_NONCE_SIZE  32

#define MP0_SMN_DRM_HFS_HW_NONCE3_HW_NONCE_SHIFT  0

#define MP0_SMN_DRM_HFS_HW_NONCE3_HW_NONCE_MASK  0xffffffff

#define MP0_SMN_DRM_HFS_HW_NONCE3_MASK \
      (MP0_SMN_DRM_HFS_HW_NONCE3_HW_NONCE_MASK)

#define MP0_SMN_DRM_HFS_HW_NONCE3_DEFAULT 0x00000000

#define MP0_SMN_DRM_HFS_HW_NONCE3_GET_HW_NONCE(mp0_smn_drm_hfs_hw_nonce3) \
      ((mp0_smn_drm_hfs_hw_nonce3 & MP0_SMN_DRM_HFS_HW_NONCE3_HW_NONCE_MASK) >> MP0_SMN_DRM_HFS_HW_NONCE3_HW_NONCE_SHIFT)

#define MP0_SMN_DRM_HFS_HW_NONCE3_SET_HW_NONCE(mp0_smn_drm_hfs_hw_nonce3_reg, hw_nonce) \
      mp0_smn_drm_hfs_hw_nonce3_reg = (mp0_smn_drm_hfs_hw_nonce3_reg & ~MP0_SMN_DRM_HFS_HW_NONCE3_HW_NONCE_MASK) | (hw_nonce << MP0_SMN_DRM_HFS_HW_NONCE3_HW_NONCE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_hfs_hw_nonce3_t {
            unsigned int hw_nonce                       : MP0_SMN_DRM_HFS_HW_NONCE3_HW_NONCE_SIZE;
      } mp0_smn_drm_hfs_hw_nonce3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_hfs_hw_nonce3_t {
            unsigned int hw_nonce                       : MP0_SMN_DRM_HFS_HW_NONCE3_HW_NONCE_SIZE;
      } mp0_smn_drm_hfs_hw_nonce3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_hfs_hw_nonce3_t f;
} mp0_smn_drm_hfs_hw_nonce3_u;


/*
 * MP0_SMN_DRM_SHARED_CLIENT struct
 */

#define MP0_SMN_DRM_SHARED_CLIENT_REG_SIZE         32
#define MP0_SMN_DRM_SHARED_CLIENT_VP8_SELECT_SIZE  1

#define MP0_SMN_DRM_SHARED_CLIENT_VP8_SELECT_SHIFT  0

#define MP0_SMN_DRM_SHARED_CLIENT_VP8_SELECT_MASK  0x00000001

#define MP0_SMN_DRM_SHARED_CLIENT_MASK \
      (MP0_SMN_DRM_SHARED_CLIENT_VP8_SELECT_MASK)

#define MP0_SMN_DRM_SHARED_CLIENT_DEFAULT 0x00000000

#define MP0_SMN_DRM_SHARED_CLIENT_GET_VP8_SELECT(mp0_smn_drm_shared_client) \
      ((mp0_smn_drm_shared_client & MP0_SMN_DRM_SHARED_CLIENT_VP8_SELECT_MASK) >> MP0_SMN_DRM_SHARED_CLIENT_VP8_SELECT_SHIFT)

#define MP0_SMN_DRM_SHARED_CLIENT_SET_VP8_SELECT(mp0_smn_drm_shared_client_reg, vp8_select) \
      mp0_smn_drm_shared_client_reg = (mp0_smn_drm_shared_client_reg & ~MP0_SMN_DRM_SHARED_CLIENT_VP8_SELECT_MASK) | (vp8_select << MP0_SMN_DRM_SHARED_CLIENT_VP8_SELECT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_shared_client_t {
            unsigned int vp8_select                     : MP0_SMN_DRM_SHARED_CLIENT_VP8_SELECT_SIZE;
            unsigned int                                : 31;
      } mp0_smn_drm_shared_client_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_shared_client_t {
            unsigned int                                : 31;
            unsigned int vp8_select                     : MP0_SMN_DRM_SHARED_CLIENT_VP8_SELECT_SIZE;
      } mp0_smn_drm_shared_client_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_shared_client_t f;
} mp0_smn_drm_shared_client_u;


/*
 * MP0_SMN_DRM_TIMEOUT struct
 */

#define MP0_SMN_DRM_TIMEOUT_REG_SIZE         32
#define MP0_SMN_DRM_TIMEOUT_CLIENT2_TIMEOUT_SIZE  8
#define MP0_SMN_DRM_TIMEOUT_CLIENT0_TIMEOUT_SIZE  8
#define MP0_SMN_DRM_TIMEOUT_CLIENT1_TIMEOUT_SIZE  8
#define MP0_SMN_DRM_TIMEOUT_CLIENT3_TIMEOUT_SIZE  8

#define MP0_SMN_DRM_TIMEOUT_CLIENT2_TIMEOUT_SHIFT  0
#define MP0_SMN_DRM_TIMEOUT_CLIENT0_TIMEOUT_SHIFT  8
#define MP0_SMN_DRM_TIMEOUT_CLIENT1_TIMEOUT_SHIFT  16
#define MP0_SMN_DRM_TIMEOUT_CLIENT3_TIMEOUT_SHIFT  24

#define MP0_SMN_DRM_TIMEOUT_CLIENT2_TIMEOUT_MASK  0x000000ff
#define MP0_SMN_DRM_TIMEOUT_CLIENT0_TIMEOUT_MASK  0x0000ff00
#define MP0_SMN_DRM_TIMEOUT_CLIENT1_TIMEOUT_MASK  0x00ff0000
#define MP0_SMN_DRM_TIMEOUT_CLIENT3_TIMEOUT_MASK  0xff000000

#define MP0_SMN_DRM_TIMEOUT_MASK \
      (MP0_SMN_DRM_TIMEOUT_CLIENT2_TIMEOUT_MASK | \
      MP0_SMN_DRM_TIMEOUT_CLIENT0_TIMEOUT_MASK | \
      MP0_SMN_DRM_TIMEOUT_CLIENT1_TIMEOUT_MASK | \
      MP0_SMN_DRM_TIMEOUT_CLIENT3_TIMEOUT_MASK)

#define MP0_SMN_DRM_TIMEOUT_DEFAULT    0xffffffff

#define MP0_SMN_DRM_TIMEOUT_GET_CLIENT2_TIMEOUT(mp0_smn_drm_timeout) \
      ((mp0_smn_drm_timeout & MP0_SMN_DRM_TIMEOUT_CLIENT2_TIMEOUT_MASK) >> MP0_SMN_DRM_TIMEOUT_CLIENT2_TIMEOUT_SHIFT)
#define MP0_SMN_DRM_TIMEOUT_GET_CLIENT0_TIMEOUT(mp0_smn_drm_timeout) \
      ((mp0_smn_drm_timeout & MP0_SMN_DRM_TIMEOUT_CLIENT0_TIMEOUT_MASK) >> MP0_SMN_DRM_TIMEOUT_CLIENT0_TIMEOUT_SHIFT)
#define MP0_SMN_DRM_TIMEOUT_GET_CLIENT1_TIMEOUT(mp0_smn_drm_timeout) \
      ((mp0_smn_drm_timeout & MP0_SMN_DRM_TIMEOUT_CLIENT1_TIMEOUT_MASK) >> MP0_SMN_DRM_TIMEOUT_CLIENT1_TIMEOUT_SHIFT)
#define MP0_SMN_DRM_TIMEOUT_GET_CLIENT3_TIMEOUT(mp0_smn_drm_timeout) \
      ((mp0_smn_drm_timeout & MP0_SMN_DRM_TIMEOUT_CLIENT3_TIMEOUT_MASK) >> MP0_SMN_DRM_TIMEOUT_CLIENT3_TIMEOUT_SHIFT)

#define MP0_SMN_DRM_TIMEOUT_SET_CLIENT2_TIMEOUT(mp0_smn_drm_timeout_reg, client2_timeout) \
      mp0_smn_drm_timeout_reg = (mp0_smn_drm_timeout_reg & ~MP0_SMN_DRM_TIMEOUT_CLIENT2_TIMEOUT_MASK) | (client2_timeout << MP0_SMN_DRM_TIMEOUT_CLIENT2_TIMEOUT_SHIFT)
#define MP0_SMN_DRM_TIMEOUT_SET_CLIENT0_TIMEOUT(mp0_smn_drm_timeout_reg, client0_timeout) \
      mp0_smn_drm_timeout_reg = (mp0_smn_drm_timeout_reg & ~MP0_SMN_DRM_TIMEOUT_CLIENT0_TIMEOUT_MASK) | (client0_timeout << MP0_SMN_DRM_TIMEOUT_CLIENT0_TIMEOUT_SHIFT)
#define MP0_SMN_DRM_TIMEOUT_SET_CLIENT1_TIMEOUT(mp0_smn_drm_timeout_reg, client1_timeout) \
      mp0_smn_drm_timeout_reg = (mp0_smn_drm_timeout_reg & ~MP0_SMN_DRM_TIMEOUT_CLIENT1_TIMEOUT_MASK) | (client1_timeout << MP0_SMN_DRM_TIMEOUT_CLIENT1_TIMEOUT_SHIFT)
#define MP0_SMN_DRM_TIMEOUT_SET_CLIENT3_TIMEOUT(mp0_smn_drm_timeout_reg, client3_timeout) \
      mp0_smn_drm_timeout_reg = (mp0_smn_drm_timeout_reg & ~MP0_SMN_DRM_TIMEOUT_CLIENT3_TIMEOUT_MASK) | (client3_timeout << MP0_SMN_DRM_TIMEOUT_CLIENT3_TIMEOUT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_timeout_t {
            unsigned int client2_timeout                : MP0_SMN_DRM_TIMEOUT_CLIENT2_TIMEOUT_SIZE;
            unsigned int client0_timeout                : MP0_SMN_DRM_TIMEOUT_CLIENT0_TIMEOUT_SIZE;
            unsigned int client1_timeout                : MP0_SMN_DRM_TIMEOUT_CLIENT1_TIMEOUT_SIZE;
            unsigned int client3_timeout                : MP0_SMN_DRM_TIMEOUT_CLIENT3_TIMEOUT_SIZE;
      } mp0_smn_drm_timeout_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_timeout_t {
            unsigned int client3_timeout                : MP0_SMN_DRM_TIMEOUT_CLIENT3_TIMEOUT_SIZE;
            unsigned int client1_timeout                : MP0_SMN_DRM_TIMEOUT_CLIENT1_TIMEOUT_SIZE;
            unsigned int client0_timeout                : MP0_SMN_DRM_TIMEOUT_CLIENT0_TIMEOUT_SIZE;
            unsigned int client2_timeout                : MP0_SMN_DRM_TIMEOUT_CLIENT2_TIMEOUT_SIZE;
      } mp0_smn_drm_timeout_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_timeout_t f;
} mp0_smn_drm_timeout_u;


/*
 * MP0_SMN_DRM_BYTESWAP struct
 */

#define MP0_SMN_DRM_BYTESWAP_REG_SIZE         32
#define MP0_SMN_DRM_BYTESWAP_CLIENT2_BYTESWAP_SIZE  1
#define MP0_SMN_DRM_BYTESWAP_CLIENT0_BYTESWAP_SIZE  1
#define MP0_SMN_DRM_BYTESWAP_CLIENT1_BYTESWAP_SIZE  1
#define MP0_SMN_DRM_BYTESWAP_CLIENT3_BYTESWAP_SIZE  1
#define MP0_SMN_DRM_BYTESWAP_CLIENT4_BYTESWAP_SIZE  1

#define MP0_SMN_DRM_BYTESWAP_CLIENT2_BYTESWAP_SHIFT  0
#define MP0_SMN_DRM_BYTESWAP_CLIENT0_BYTESWAP_SHIFT  8
#define MP0_SMN_DRM_BYTESWAP_CLIENT1_BYTESWAP_SHIFT  16
#define MP0_SMN_DRM_BYTESWAP_CLIENT3_BYTESWAP_SHIFT  24
#define MP0_SMN_DRM_BYTESWAP_CLIENT4_BYTESWAP_SHIFT  25

#define MP0_SMN_DRM_BYTESWAP_CLIENT2_BYTESWAP_MASK  0x00000001
#define MP0_SMN_DRM_BYTESWAP_CLIENT0_BYTESWAP_MASK  0x00000100
#define MP0_SMN_DRM_BYTESWAP_CLIENT1_BYTESWAP_MASK  0x00010000
#define MP0_SMN_DRM_BYTESWAP_CLIENT3_BYTESWAP_MASK  0x01000000
#define MP0_SMN_DRM_BYTESWAP_CLIENT4_BYTESWAP_MASK  0x02000000

#define MP0_SMN_DRM_BYTESWAP_MASK \
      (MP0_SMN_DRM_BYTESWAP_CLIENT2_BYTESWAP_MASK | \
      MP0_SMN_DRM_BYTESWAP_CLIENT0_BYTESWAP_MASK | \
      MP0_SMN_DRM_BYTESWAP_CLIENT1_BYTESWAP_MASK | \
      MP0_SMN_DRM_BYTESWAP_CLIENT3_BYTESWAP_MASK | \
      MP0_SMN_DRM_BYTESWAP_CLIENT4_BYTESWAP_MASK)

#define MP0_SMN_DRM_BYTESWAP_DEFAULT   0x00000000

#define MP0_SMN_DRM_BYTESWAP_GET_CLIENT2_BYTESWAP(mp0_smn_drm_byteswap) \
      ((mp0_smn_drm_byteswap & MP0_SMN_DRM_BYTESWAP_CLIENT2_BYTESWAP_MASK) >> MP0_SMN_DRM_BYTESWAP_CLIENT2_BYTESWAP_SHIFT)
#define MP0_SMN_DRM_BYTESWAP_GET_CLIENT0_BYTESWAP(mp0_smn_drm_byteswap) \
      ((mp0_smn_drm_byteswap & MP0_SMN_DRM_BYTESWAP_CLIENT0_BYTESWAP_MASK) >> MP0_SMN_DRM_BYTESWAP_CLIENT0_BYTESWAP_SHIFT)
#define MP0_SMN_DRM_BYTESWAP_GET_CLIENT1_BYTESWAP(mp0_smn_drm_byteswap) \
      ((mp0_smn_drm_byteswap & MP0_SMN_DRM_BYTESWAP_CLIENT1_BYTESWAP_MASK) >> MP0_SMN_DRM_BYTESWAP_CLIENT1_BYTESWAP_SHIFT)
#define MP0_SMN_DRM_BYTESWAP_GET_CLIENT3_BYTESWAP(mp0_smn_drm_byteswap) \
      ((mp0_smn_drm_byteswap & MP0_SMN_DRM_BYTESWAP_CLIENT3_BYTESWAP_MASK) >> MP0_SMN_DRM_BYTESWAP_CLIENT3_BYTESWAP_SHIFT)
#define MP0_SMN_DRM_BYTESWAP_GET_CLIENT4_BYTESWAP(mp0_smn_drm_byteswap) \
      ((mp0_smn_drm_byteswap & MP0_SMN_DRM_BYTESWAP_CLIENT4_BYTESWAP_MASK) >> MP0_SMN_DRM_BYTESWAP_CLIENT4_BYTESWAP_SHIFT)

#define MP0_SMN_DRM_BYTESWAP_SET_CLIENT2_BYTESWAP(mp0_smn_drm_byteswap_reg, client2_byteswap) \
      mp0_smn_drm_byteswap_reg = (mp0_smn_drm_byteswap_reg & ~MP0_SMN_DRM_BYTESWAP_CLIENT2_BYTESWAP_MASK) | (client2_byteswap << MP0_SMN_DRM_BYTESWAP_CLIENT2_BYTESWAP_SHIFT)
#define MP0_SMN_DRM_BYTESWAP_SET_CLIENT0_BYTESWAP(mp0_smn_drm_byteswap_reg, client0_byteswap) \
      mp0_smn_drm_byteswap_reg = (mp0_smn_drm_byteswap_reg & ~MP0_SMN_DRM_BYTESWAP_CLIENT0_BYTESWAP_MASK) | (client0_byteswap << MP0_SMN_DRM_BYTESWAP_CLIENT0_BYTESWAP_SHIFT)
#define MP0_SMN_DRM_BYTESWAP_SET_CLIENT1_BYTESWAP(mp0_smn_drm_byteswap_reg, client1_byteswap) \
      mp0_smn_drm_byteswap_reg = (mp0_smn_drm_byteswap_reg & ~MP0_SMN_DRM_BYTESWAP_CLIENT1_BYTESWAP_MASK) | (client1_byteswap << MP0_SMN_DRM_BYTESWAP_CLIENT1_BYTESWAP_SHIFT)
#define MP0_SMN_DRM_BYTESWAP_SET_CLIENT3_BYTESWAP(mp0_smn_drm_byteswap_reg, client3_byteswap) \
      mp0_smn_drm_byteswap_reg = (mp0_smn_drm_byteswap_reg & ~MP0_SMN_DRM_BYTESWAP_CLIENT3_BYTESWAP_MASK) | (client3_byteswap << MP0_SMN_DRM_BYTESWAP_CLIENT3_BYTESWAP_SHIFT)
#define MP0_SMN_DRM_BYTESWAP_SET_CLIENT4_BYTESWAP(mp0_smn_drm_byteswap_reg, client4_byteswap) \
      mp0_smn_drm_byteswap_reg = (mp0_smn_drm_byteswap_reg & ~MP0_SMN_DRM_BYTESWAP_CLIENT4_BYTESWAP_MASK) | (client4_byteswap << MP0_SMN_DRM_BYTESWAP_CLIENT4_BYTESWAP_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_byteswap_t {
            unsigned int client2_byteswap               : MP0_SMN_DRM_BYTESWAP_CLIENT2_BYTESWAP_SIZE;
            unsigned int                                : 7;
            unsigned int client0_byteswap               : MP0_SMN_DRM_BYTESWAP_CLIENT0_BYTESWAP_SIZE;
            unsigned int                                : 7;
            unsigned int client1_byteswap               : MP0_SMN_DRM_BYTESWAP_CLIENT1_BYTESWAP_SIZE;
            unsigned int                                : 7;
            unsigned int client3_byteswap               : MP0_SMN_DRM_BYTESWAP_CLIENT3_BYTESWAP_SIZE;
            unsigned int client4_byteswap               : MP0_SMN_DRM_BYTESWAP_CLIENT4_BYTESWAP_SIZE;
            unsigned int                                : 6;
      } mp0_smn_drm_byteswap_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_byteswap_t {
            unsigned int                                : 6;
            unsigned int client4_byteswap               : MP0_SMN_DRM_BYTESWAP_CLIENT4_BYTESWAP_SIZE;
            unsigned int client3_byteswap               : MP0_SMN_DRM_BYTESWAP_CLIENT3_BYTESWAP_SIZE;
            unsigned int                                : 7;
            unsigned int client1_byteswap               : MP0_SMN_DRM_BYTESWAP_CLIENT1_BYTESWAP_SIZE;
            unsigned int                                : 7;
            unsigned int client0_byteswap               : MP0_SMN_DRM_BYTESWAP_CLIENT0_BYTESWAP_SIZE;
            unsigned int                                : 7;
            unsigned int client2_byteswap               : MP0_SMN_DRM_BYTESWAP_CLIENT2_BYTESWAP_SIZE;
      } mp0_smn_drm_byteswap_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_byteswap_t f;
} mp0_smn_drm_byteswap_u;


/*
 * MP0_SMN_DRM_RESET struct
 */

#define MP0_SMN_DRM_RESET_REG_SIZE         32
#define MP0_SMN_DRM_RESET_CLIENT2_RESET_SIZE  1
#define MP0_SMN_DRM_RESET_CLIENT0_RESET_SIZE  1
#define MP0_SMN_DRM_RESET_CLIENT1_RESET_SIZE  1
#define MP0_SMN_DRM_RESET_CLIENT0_INVALID_CMD_SIZE  1
#define MP0_SMN_DRM_RESET_SPU_IF_RESET_SIZE  1
#define MP0_SMN_DRM_RESET_CLIENT3_RESET_SIZE  1
#define MP0_SMN_DRM_RESET_CLIENT4_RESET_SIZE  1
#define MP0_SMN_DRM_RESET_CLIENT1_INVALID_CMD_SIZE  1
#define MP0_SMN_DRM_RESET_CLIENT2_INVALID_CMD_SIZE  1
#define MP0_SMN_DRM_RESET_CLIENT3_INVALID_CMD_SIZE  1
#define MP0_SMN_DRM_RESET_CLIENT4_INVALID_CMD_SIZE  1
#define MP0_SMN_DRM_RESET_SPU_INVALID_CMD_SIZE  1

#define MP0_SMN_DRM_RESET_CLIENT2_RESET_SHIFT  0
#define MP0_SMN_DRM_RESET_CLIENT0_RESET_SHIFT  8
#define MP0_SMN_DRM_RESET_CLIENT1_RESET_SHIFT  16
#define MP0_SMN_DRM_RESET_CLIENT0_INVALID_CMD_SHIFT  23
#define MP0_SMN_DRM_RESET_SPU_IF_RESET_SHIFT  24
#define MP0_SMN_DRM_RESET_CLIENT3_RESET_SHIFT  25
#define MP0_SMN_DRM_RESET_CLIENT4_RESET_SHIFT  26
#define MP0_SMN_DRM_RESET_CLIENT1_INVALID_CMD_SHIFT  27
#define MP0_SMN_DRM_RESET_CLIENT2_INVALID_CMD_SHIFT  28
#define MP0_SMN_DRM_RESET_CLIENT3_INVALID_CMD_SHIFT  29
#define MP0_SMN_DRM_RESET_CLIENT4_INVALID_CMD_SHIFT  30
#define MP0_SMN_DRM_RESET_SPU_INVALID_CMD_SHIFT  31

#define MP0_SMN_DRM_RESET_CLIENT2_RESET_MASK  0x00000001
#define MP0_SMN_DRM_RESET_CLIENT0_RESET_MASK  0x00000100
#define MP0_SMN_DRM_RESET_CLIENT1_RESET_MASK  0x00010000
#define MP0_SMN_DRM_RESET_CLIENT0_INVALID_CMD_MASK  0x00800000
#define MP0_SMN_DRM_RESET_SPU_IF_RESET_MASK  0x01000000
#define MP0_SMN_DRM_RESET_CLIENT3_RESET_MASK  0x02000000
#define MP0_SMN_DRM_RESET_CLIENT4_RESET_MASK  0x04000000
#define MP0_SMN_DRM_RESET_CLIENT1_INVALID_CMD_MASK  0x08000000
#define MP0_SMN_DRM_RESET_CLIENT2_INVALID_CMD_MASK  0x10000000
#define MP0_SMN_DRM_RESET_CLIENT3_INVALID_CMD_MASK  0x20000000
#define MP0_SMN_DRM_RESET_CLIENT4_INVALID_CMD_MASK  0x40000000
#define MP0_SMN_DRM_RESET_SPU_INVALID_CMD_MASK  0x80000000

#define MP0_SMN_DRM_RESET_MASK \
      (MP0_SMN_DRM_RESET_CLIENT2_RESET_MASK | \
      MP0_SMN_DRM_RESET_CLIENT0_RESET_MASK | \
      MP0_SMN_DRM_RESET_CLIENT1_RESET_MASK | \
      MP0_SMN_DRM_RESET_CLIENT0_INVALID_CMD_MASK | \
      MP0_SMN_DRM_RESET_SPU_IF_RESET_MASK | \
      MP0_SMN_DRM_RESET_CLIENT3_RESET_MASK | \
      MP0_SMN_DRM_RESET_CLIENT4_RESET_MASK | \
      MP0_SMN_DRM_RESET_CLIENT1_INVALID_CMD_MASK | \
      MP0_SMN_DRM_RESET_CLIENT2_INVALID_CMD_MASK | \
      MP0_SMN_DRM_RESET_CLIENT3_INVALID_CMD_MASK | \
      MP0_SMN_DRM_RESET_CLIENT4_INVALID_CMD_MASK | \
      MP0_SMN_DRM_RESET_SPU_INVALID_CMD_MASK)

#define MP0_SMN_DRM_RESET_DEFAULT      0x00000000

#define MP0_SMN_DRM_RESET_GET_CLIENT2_RESET(mp0_smn_drm_reset) \
      ((mp0_smn_drm_reset & MP0_SMN_DRM_RESET_CLIENT2_RESET_MASK) >> MP0_SMN_DRM_RESET_CLIENT2_RESET_SHIFT)
#define MP0_SMN_DRM_RESET_GET_CLIENT0_RESET(mp0_smn_drm_reset) \
      ((mp0_smn_drm_reset & MP0_SMN_DRM_RESET_CLIENT0_RESET_MASK) >> MP0_SMN_DRM_RESET_CLIENT0_RESET_SHIFT)
#define MP0_SMN_DRM_RESET_GET_CLIENT1_RESET(mp0_smn_drm_reset) \
      ((mp0_smn_drm_reset & MP0_SMN_DRM_RESET_CLIENT1_RESET_MASK) >> MP0_SMN_DRM_RESET_CLIENT1_RESET_SHIFT)
#define MP0_SMN_DRM_RESET_GET_CLIENT0_INVALID_CMD(mp0_smn_drm_reset) \
      ((mp0_smn_drm_reset & MP0_SMN_DRM_RESET_CLIENT0_INVALID_CMD_MASK) >> MP0_SMN_DRM_RESET_CLIENT0_INVALID_CMD_SHIFT)
#define MP0_SMN_DRM_RESET_GET_SPU_IF_RESET(mp0_smn_drm_reset) \
      ((mp0_smn_drm_reset & MP0_SMN_DRM_RESET_SPU_IF_RESET_MASK) >> MP0_SMN_DRM_RESET_SPU_IF_RESET_SHIFT)
#define MP0_SMN_DRM_RESET_GET_CLIENT3_RESET(mp0_smn_drm_reset) \
      ((mp0_smn_drm_reset & MP0_SMN_DRM_RESET_CLIENT3_RESET_MASK) >> MP0_SMN_DRM_RESET_CLIENT3_RESET_SHIFT)
#define MP0_SMN_DRM_RESET_GET_CLIENT4_RESET(mp0_smn_drm_reset) \
      ((mp0_smn_drm_reset & MP0_SMN_DRM_RESET_CLIENT4_RESET_MASK) >> MP0_SMN_DRM_RESET_CLIENT4_RESET_SHIFT)
#define MP0_SMN_DRM_RESET_GET_CLIENT1_INVALID_CMD(mp0_smn_drm_reset) \
      ((mp0_smn_drm_reset & MP0_SMN_DRM_RESET_CLIENT1_INVALID_CMD_MASK) >> MP0_SMN_DRM_RESET_CLIENT1_INVALID_CMD_SHIFT)
#define MP0_SMN_DRM_RESET_GET_CLIENT2_INVALID_CMD(mp0_smn_drm_reset) \
      ((mp0_smn_drm_reset & MP0_SMN_DRM_RESET_CLIENT2_INVALID_CMD_MASK) >> MP0_SMN_DRM_RESET_CLIENT2_INVALID_CMD_SHIFT)
#define MP0_SMN_DRM_RESET_GET_CLIENT3_INVALID_CMD(mp0_smn_drm_reset) \
      ((mp0_smn_drm_reset & MP0_SMN_DRM_RESET_CLIENT3_INVALID_CMD_MASK) >> MP0_SMN_DRM_RESET_CLIENT3_INVALID_CMD_SHIFT)
#define MP0_SMN_DRM_RESET_GET_CLIENT4_INVALID_CMD(mp0_smn_drm_reset) \
      ((mp0_smn_drm_reset & MP0_SMN_DRM_RESET_CLIENT4_INVALID_CMD_MASK) >> MP0_SMN_DRM_RESET_CLIENT4_INVALID_CMD_SHIFT)
#define MP0_SMN_DRM_RESET_GET_SPU_INVALID_CMD(mp0_smn_drm_reset) \
      ((mp0_smn_drm_reset & MP0_SMN_DRM_RESET_SPU_INVALID_CMD_MASK) >> MP0_SMN_DRM_RESET_SPU_INVALID_CMD_SHIFT)

#define MP0_SMN_DRM_RESET_SET_CLIENT2_RESET(mp0_smn_drm_reset_reg, client2_reset) \
      mp0_smn_drm_reset_reg = (mp0_smn_drm_reset_reg & ~MP0_SMN_DRM_RESET_CLIENT2_RESET_MASK) | (client2_reset << MP0_SMN_DRM_RESET_CLIENT2_RESET_SHIFT)
#define MP0_SMN_DRM_RESET_SET_CLIENT0_RESET(mp0_smn_drm_reset_reg, client0_reset) \
      mp0_smn_drm_reset_reg = (mp0_smn_drm_reset_reg & ~MP0_SMN_DRM_RESET_CLIENT0_RESET_MASK) | (client0_reset << MP0_SMN_DRM_RESET_CLIENT0_RESET_SHIFT)
#define MP0_SMN_DRM_RESET_SET_CLIENT1_RESET(mp0_smn_drm_reset_reg, client1_reset) \
      mp0_smn_drm_reset_reg = (mp0_smn_drm_reset_reg & ~MP0_SMN_DRM_RESET_CLIENT1_RESET_MASK) | (client1_reset << MP0_SMN_DRM_RESET_CLIENT1_RESET_SHIFT)
#define MP0_SMN_DRM_RESET_SET_CLIENT0_INVALID_CMD(mp0_smn_drm_reset_reg, client0_invalid_cmd) \
      mp0_smn_drm_reset_reg = (mp0_smn_drm_reset_reg & ~MP0_SMN_DRM_RESET_CLIENT0_INVALID_CMD_MASK) | (client0_invalid_cmd << MP0_SMN_DRM_RESET_CLIENT0_INVALID_CMD_SHIFT)
#define MP0_SMN_DRM_RESET_SET_SPU_IF_RESET(mp0_smn_drm_reset_reg, spu_if_reset) \
      mp0_smn_drm_reset_reg = (mp0_smn_drm_reset_reg & ~MP0_SMN_DRM_RESET_SPU_IF_RESET_MASK) | (spu_if_reset << MP0_SMN_DRM_RESET_SPU_IF_RESET_SHIFT)
#define MP0_SMN_DRM_RESET_SET_CLIENT3_RESET(mp0_smn_drm_reset_reg, client3_reset) \
      mp0_smn_drm_reset_reg = (mp0_smn_drm_reset_reg & ~MP0_SMN_DRM_RESET_CLIENT3_RESET_MASK) | (client3_reset << MP0_SMN_DRM_RESET_CLIENT3_RESET_SHIFT)
#define MP0_SMN_DRM_RESET_SET_CLIENT4_RESET(mp0_smn_drm_reset_reg, client4_reset) \
      mp0_smn_drm_reset_reg = (mp0_smn_drm_reset_reg & ~MP0_SMN_DRM_RESET_CLIENT4_RESET_MASK) | (client4_reset << MP0_SMN_DRM_RESET_CLIENT4_RESET_SHIFT)
#define MP0_SMN_DRM_RESET_SET_CLIENT1_INVALID_CMD(mp0_smn_drm_reset_reg, client1_invalid_cmd) \
      mp0_smn_drm_reset_reg = (mp0_smn_drm_reset_reg & ~MP0_SMN_DRM_RESET_CLIENT1_INVALID_CMD_MASK) | (client1_invalid_cmd << MP0_SMN_DRM_RESET_CLIENT1_INVALID_CMD_SHIFT)
#define MP0_SMN_DRM_RESET_SET_CLIENT2_INVALID_CMD(mp0_smn_drm_reset_reg, client2_invalid_cmd) \
      mp0_smn_drm_reset_reg = (mp0_smn_drm_reset_reg & ~MP0_SMN_DRM_RESET_CLIENT2_INVALID_CMD_MASK) | (client2_invalid_cmd << MP0_SMN_DRM_RESET_CLIENT2_INVALID_CMD_SHIFT)
#define MP0_SMN_DRM_RESET_SET_CLIENT3_INVALID_CMD(mp0_smn_drm_reset_reg, client3_invalid_cmd) \
      mp0_smn_drm_reset_reg = (mp0_smn_drm_reset_reg & ~MP0_SMN_DRM_RESET_CLIENT3_INVALID_CMD_MASK) | (client3_invalid_cmd << MP0_SMN_DRM_RESET_CLIENT3_INVALID_CMD_SHIFT)
#define MP0_SMN_DRM_RESET_SET_CLIENT4_INVALID_CMD(mp0_smn_drm_reset_reg, client4_invalid_cmd) \
      mp0_smn_drm_reset_reg = (mp0_smn_drm_reset_reg & ~MP0_SMN_DRM_RESET_CLIENT4_INVALID_CMD_MASK) | (client4_invalid_cmd << MP0_SMN_DRM_RESET_CLIENT4_INVALID_CMD_SHIFT)
#define MP0_SMN_DRM_RESET_SET_SPU_INVALID_CMD(mp0_smn_drm_reset_reg, spu_invalid_cmd) \
      mp0_smn_drm_reset_reg = (mp0_smn_drm_reset_reg & ~MP0_SMN_DRM_RESET_SPU_INVALID_CMD_MASK) | (spu_invalid_cmd << MP0_SMN_DRM_RESET_SPU_INVALID_CMD_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_reset_t {
            unsigned int client2_reset                  : MP0_SMN_DRM_RESET_CLIENT2_RESET_SIZE;
            unsigned int                                : 7;
            unsigned int client0_reset                  : MP0_SMN_DRM_RESET_CLIENT0_RESET_SIZE;
            unsigned int                                : 7;
            unsigned int client1_reset                  : MP0_SMN_DRM_RESET_CLIENT1_RESET_SIZE;
            unsigned int                                : 6;
            unsigned int client0_invalid_cmd            : MP0_SMN_DRM_RESET_CLIENT0_INVALID_CMD_SIZE;
            unsigned int spu_if_reset                   : MP0_SMN_DRM_RESET_SPU_IF_RESET_SIZE;
            unsigned int client3_reset                  : MP0_SMN_DRM_RESET_CLIENT3_RESET_SIZE;
            unsigned int client4_reset                  : MP0_SMN_DRM_RESET_CLIENT4_RESET_SIZE;
            unsigned int client1_invalid_cmd            : MP0_SMN_DRM_RESET_CLIENT1_INVALID_CMD_SIZE;
            unsigned int client2_invalid_cmd            : MP0_SMN_DRM_RESET_CLIENT2_INVALID_CMD_SIZE;
            unsigned int client3_invalid_cmd            : MP0_SMN_DRM_RESET_CLIENT3_INVALID_CMD_SIZE;
            unsigned int client4_invalid_cmd            : MP0_SMN_DRM_RESET_CLIENT4_INVALID_CMD_SIZE;
            unsigned int spu_invalid_cmd                : MP0_SMN_DRM_RESET_SPU_INVALID_CMD_SIZE;
      } mp0_smn_drm_reset_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_reset_t {
            unsigned int spu_invalid_cmd                : MP0_SMN_DRM_RESET_SPU_INVALID_CMD_SIZE;
            unsigned int client4_invalid_cmd            : MP0_SMN_DRM_RESET_CLIENT4_INVALID_CMD_SIZE;
            unsigned int client3_invalid_cmd            : MP0_SMN_DRM_RESET_CLIENT3_INVALID_CMD_SIZE;
            unsigned int client2_invalid_cmd            : MP0_SMN_DRM_RESET_CLIENT2_INVALID_CMD_SIZE;
            unsigned int client1_invalid_cmd            : MP0_SMN_DRM_RESET_CLIENT1_INVALID_CMD_SIZE;
            unsigned int client4_reset                  : MP0_SMN_DRM_RESET_CLIENT4_RESET_SIZE;
            unsigned int client3_reset                  : MP0_SMN_DRM_RESET_CLIENT3_RESET_SIZE;
            unsigned int spu_if_reset                   : MP0_SMN_DRM_RESET_SPU_IF_RESET_SIZE;
            unsigned int client0_invalid_cmd            : MP0_SMN_DRM_RESET_CLIENT0_INVALID_CMD_SIZE;
            unsigned int                                : 6;
            unsigned int client1_reset                  : MP0_SMN_DRM_RESET_CLIENT1_RESET_SIZE;
            unsigned int                                : 7;
            unsigned int client0_reset                  : MP0_SMN_DRM_RESET_CLIENT0_RESET_SIZE;
            unsigned int                                : 7;
            unsigned int client2_reset                  : MP0_SMN_DRM_RESET_CLIENT2_RESET_SIZE;
      } mp0_smn_drm_reset_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_reset_t f;
} mp0_smn_drm_reset_u;


/*
 * MP0_SMN_DRM_ARB_PRIORITY struct
 */

#define MP0_SMN_DRM_ARB_PRIORITY_REG_SIZE         32
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT0_SIZE  4
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT1_SIZE  4
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT2_SIZE  4
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT3_SIZE  4
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT4_SIZE  4
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT5_SIZE  4
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT6_SIZE  4
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT7_SIZE  4

#define MP0_SMN_DRM_ARB_PRIORITY_SLOT0_SHIFT  0
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT1_SHIFT  4
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT2_SHIFT  8
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT3_SHIFT  12
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT4_SHIFT  16
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT5_SHIFT  20
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT6_SHIFT  24
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT7_SHIFT  28

#define MP0_SMN_DRM_ARB_PRIORITY_SLOT0_MASK  0x0000000f
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT1_MASK  0x000000f0
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT2_MASK  0x00000f00
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT3_MASK  0x0000f000
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT4_MASK  0x000f0000
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT5_MASK  0x00f00000
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT6_MASK  0x0f000000
#define MP0_SMN_DRM_ARB_PRIORITY_SLOT7_MASK  0xf0000000

#define MP0_SMN_DRM_ARB_PRIORITY_MASK \
      (MP0_SMN_DRM_ARB_PRIORITY_SLOT0_MASK | \
      MP0_SMN_DRM_ARB_PRIORITY_SLOT1_MASK | \
      MP0_SMN_DRM_ARB_PRIORITY_SLOT2_MASK | \
      MP0_SMN_DRM_ARB_PRIORITY_SLOT3_MASK | \
      MP0_SMN_DRM_ARB_PRIORITY_SLOT4_MASK | \
      MP0_SMN_DRM_ARB_PRIORITY_SLOT5_MASK | \
      MP0_SMN_DRM_ARB_PRIORITY_SLOT6_MASK | \
      MP0_SMN_DRM_ARB_PRIORITY_SLOT7_MASK)

#define MP0_SMN_DRM_ARB_PRIORITY_DEFAULT 0xfff01234

#define MP0_SMN_DRM_ARB_PRIORITY_GET_SLOT0(mp0_smn_drm_arb_priority) \
      ((mp0_smn_drm_arb_priority & MP0_SMN_DRM_ARB_PRIORITY_SLOT0_MASK) >> MP0_SMN_DRM_ARB_PRIORITY_SLOT0_SHIFT)
#define MP0_SMN_DRM_ARB_PRIORITY_GET_SLOT1(mp0_smn_drm_arb_priority) \
      ((mp0_smn_drm_arb_priority & MP0_SMN_DRM_ARB_PRIORITY_SLOT1_MASK) >> MP0_SMN_DRM_ARB_PRIORITY_SLOT1_SHIFT)
#define MP0_SMN_DRM_ARB_PRIORITY_GET_SLOT2(mp0_smn_drm_arb_priority) \
      ((mp0_smn_drm_arb_priority & MP0_SMN_DRM_ARB_PRIORITY_SLOT2_MASK) >> MP0_SMN_DRM_ARB_PRIORITY_SLOT2_SHIFT)
#define MP0_SMN_DRM_ARB_PRIORITY_GET_SLOT3(mp0_smn_drm_arb_priority) \
      ((mp0_smn_drm_arb_priority & MP0_SMN_DRM_ARB_PRIORITY_SLOT3_MASK) >> MP0_SMN_DRM_ARB_PRIORITY_SLOT3_SHIFT)
#define MP0_SMN_DRM_ARB_PRIORITY_GET_SLOT4(mp0_smn_drm_arb_priority) \
      ((mp0_smn_drm_arb_priority & MP0_SMN_DRM_ARB_PRIORITY_SLOT4_MASK) >> MP0_SMN_DRM_ARB_PRIORITY_SLOT4_SHIFT)
#define MP0_SMN_DRM_ARB_PRIORITY_GET_SLOT5(mp0_smn_drm_arb_priority) \
      ((mp0_smn_drm_arb_priority & MP0_SMN_DRM_ARB_PRIORITY_SLOT5_MASK) >> MP0_SMN_DRM_ARB_PRIORITY_SLOT5_SHIFT)
#define MP0_SMN_DRM_ARB_PRIORITY_GET_SLOT6(mp0_smn_drm_arb_priority) \
      ((mp0_smn_drm_arb_priority & MP0_SMN_DRM_ARB_PRIORITY_SLOT6_MASK) >> MP0_SMN_DRM_ARB_PRIORITY_SLOT6_SHIFT)
#define MP0_SMN_DRM_ARB_PRIORITY_GET_SLOT7(mp0_smn_drm_arb_priority) \
      ((mp0_smn_drm_arb_priority & MP0_SMN_DRM_ARB_PRIORITY_SLOT7_MASK) >> MP0_SMN_DRM_ARB_PRIORITY_SLOT7_SHIFT)

#define MP0_SMN_DRM_ARB_PRIORITY_SET_SLOT0(mp0_smn_drm_arb_priority_reg, slot0) \
      mp0_smn_drm_arb_priority_reg = (mp0_smn_drm_arb_priority_reg & ~MP0_SMN_DRM_ARB_PRIORITY_SLOT0_MASK) | (slot0 << MP0_SMN_DRM_ARB_PRIORITY_SLOT0_SHIFT)
#define MP0_SMN_DRM_ARB_PRIORITY_SET_SLOT1(mp0_smn_drm_arb_priority_reg, slot1) \
      mp0_smn_drm_arb_priority_reg = (mp0_smn_drm_arb_priority_reg & ~MP0_SMN_DRM_ARB_PRIORITY_SLOT1_MASK) | (slot1 << MP0_SMN_DRM_ARB_PRIORITY_SLOT1_SHIFT)
#define MP0_SMN_DRM_ARB_PRIORITY_SET_SLOT2(mp0_smn_drm_arb_priority_reg, slot2) \
      mp0_smn_drm_arb_priority_reg = (mp0_smn_drm_arb_priority_reg & ~MP0_SMN_DRM_ARB_PRIORITY_SLOT2_MASK) | (slot2 << MP0_SMN_DRM_ARB_PRIORITY_SLOT2_SHIFT)
#define MP0_SMN_DRM_ARB_PRIORITY_SET_SLOT3(mp0_smn_drm_arb_priority_reg, slot3) \
      mp0_smn_drm_arb_priority_reg = (mp0_smn_drm_arb_priority_reg & ~MP0_SMN_DRM_ARB_PRIORITY_SLOT3_MASK) | (slot3 << MP0_SMN_DRM_ARB_PRIORITY_SLOT3_SHIFT)
#define MP0_SMN_DRM_ARB_PRIORITY_SET_SLOT4(mp0_smn_drm_arb_priority_reg, slot4) \
      mp0_smn_drm_arb_priority_reg = (mp0_smn_drm_arb_priority_reg & ~MP0_SMN_DRM_ARB_PRIORITY_SLOT4_MASK) | (slot4 << MP0_SMN_DRM_ARB_PRIORITY_SLOT4_SHIFT)
#define MP0_SMN_DRM_ARB_PRIORITY_SET_SLOT5(mp0_smn_drm_arb_priority_reg, slot5) \
      mp0_smn_drm_arb_priority_reg = (mp0_smn_drm_arb_priority_reg & ~MP0_SMN_DRM_ARB_PRIORITY_SLOT5_MASK) | (slot5 << MP0_SMN_DRM_ARB_PRIORITY_SLOT5_SHIFT)
#define MP0_SMN_DRM_ARB_PRIORITY_SET_SLOT6(mp0_smn_drm_arb_priority_reg, slot6) \
      mp0_smn_drm_arb_priority_reg = (mp0_smn_drm_arb_priority_reg & ~MP0_SMN_DRM_ARB_PRIORITY_SLOT6_MASK) | (slot6 << MP0_SMN_DRM_ARB_PRIORITY_SLOT6_SHIFT)
#define MP0_SMN_DRM_ARB_PRIORITY_SET_SLOT7(mp0_smn_drm_arb_priority_reg, slot7) \
      mp0_smn_drm_arb_priority_reg = (mp0_smn_drm_arb_priority_reg & ~MP0_SMN_DRM_ARB_PRIORITY_SLOT7_MASK) | (slot7 << MP0_SMN_DRM_ARB_PRIORITY_SLOT7_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_arb_priority_t {
            unsigned int slot0                          : MP0_SMN_DRM_ARB_PRIORITY_SLOT0_SIZE;
            unsigned int slot1                          : MP0_SMN_DRM_ARB_PRIORITY_SLOT1_SIZE;
            unsigned int slot2                          : MP0_SMN_DRM_ARB_PRIORITY_SLOT2_SIZE;
            unsigned int slot3                          : MP0_SMN_DRM_ARB_PRIORITY_SLOT3_SIZE;
            unsigned int slot4                          : MP0_SMN_DRM_ARB_PRIORITY_SLOT4_SIZE;
            unsigned int slot5                          : MP0_SMN_DRM_ARB_PRIORITY_SLOT5_SIZE;
            unsigned int slot6                          : MP0_SMN_DRM_ARB_PRIORITY_SLOT6_SIZE;
            unsigned int slot7                          : MP0_SMN_DRM_ARB_PRIORITY_SLOT7_SIZE;
      } mp0_smn_drm_arb_priority_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_arb_priority_t {
            unsigned int slot7                          : MP0_SMN_DRM_ARB_PRIORITY_SLOT7_SIZE;
            unsigned int slot6                          : MP0_SMN_DRM_ARB_PRIORITY_SLOT6_SIZE;
            unsigned int slot5                          : MP0_SMN_DRM_ARB_PRIORITY_SLOT5_SIZE;
            unsigned int slot4                          : MP0_SMN_DRM_ARB_PRIORITY_SLOT4_SIZE;
            unsigned int slot3                          : MP0_SMN_DRM_ARB_PRIORITY_SLOT3_SIZE;
            unsigned int slot2                          : MP0_SMN_DRM_ARB_PRIORITY_SLOT2_SIZE;
            unsigned int slot1                          : MP0_SMN_DRM_ARB_PRIORITY_SLOT1_SIZE;
            unsigned int slot0                          : MP0_SMN_DRM_ARB_PRIORITY_SLOT0_SIZE;
      } mp0_smn_drm_arb_priority_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_arb_priority_t f;
} mp0_smn_drm_arb_priority_u;


/*
 * MP0_SMN_DRM_TRNG_CNTL struct
 */

#define MP0_SMN_DRM_TRNG_CNTL_REG_SIZE         32
#define MP0_SMN_DRM_TRNG_CNTL_EN_OSC_SIZE  1
#define MP0_SMN_DRM_TRNG_CNTL_EN_LFSR_SIZE  1
#define MP0_SMN_DRM_TRNG_CNTL_EN_OUT_SIZE  1

#define MP0_SMN_DRM_TRNG_CNTL_EN_OSC_SHIFT  0
#define MP0_SMN_DRM_TRNG_CNTL_EN_LFSR_SHIFT  1
#define MP0_SMN_DRM_TRNG_CNTL_EN_OUT_SHIFT  8

#define MP0_SMN_DRM_TRNG_CNTL_EN_OSC_MASK  0x00000001
#define MP0_SMN_DRM_TRNG_CNTL_EN_LFSR_MASK  0x00000002
#define MP0_SMN_DRM_TRNG_CNTL_EN_OUT_MASK  0x00000100

#define MP0_SMN_DRM_TRNG_CNTL_MASK \
      (MP0_SMN_DRM_TRNG_CNTL_EN_OSC_MASK | \
      MP0_SMN_DRM_TRNG_CNTL_EN_LFSR_MASK | \
      MP0_SMN_DRM_TRNG_CNTL_EN_OUT_MASK)

#define MP0_SMN_DRM_TRNG_CNTL_DEFAULT  0x00000000

#define MP0_SMN_DRM_TRNG_CNTL_GET_EN_OSC(mp0_smn_drm_trng_cntl) \
      ((mp0_smn_drm_trng_cntl & MP0_SMN_DRM_TRNG_CNTL_EN_OSC_MASK) >> MP0_SMN_DRM_TRNG_CNTL_EN_OSC_SHIFT)
#define MP0_SMN_DRM_TRNG_CNTL_GET_EN_LFSR(mp0_smn_drm_trng_cntl) \
      ((mp0_smn_drm_trng_cntl & MP0_SMN_DRM_TRNG_CNTL_EN_LFSR_MASK) >> MP0_SMN_DRM_TRNG_CNTL_EN_LFSR_SHIFT)
#define MP0_SMN_DRM_TRNG_CNTL_GET_EN_OUT(mp0_smn_drm_trng_cntl) \
      ((mp0_smn_drm_trng_cntl & MP0_SMN_DRM_TRNG_CNTL_EN_OUT_MASK) >> MP0_SMN_DRM_TRNG_CNTL_EN_OUT_SHIFT)

#define MP0_SMN_DRM_TRNG_CNTL_SET_EN_OSC(mp0_smn_drm_trng_cntl_reg, en_osc) \
      mp0_smn_drm_trng_cntl_reg = (mp0_smn_drm_trng_cntl_reg & ~MP0_SMN_DRM_TRNG_CNTL_EN_OSC_MASK) | (en_osc << MP0_SMN_DRM_TRNG_CNTL_EN_OSC_SHIFT)
#define MP0_SMN_DRM_TRNG_CNTL_SET_EN_LFSR(mp0_smn_drm_trng_cntl_reg, en_lfsr) \
      mp0_smn_drm_trng_cntl_reg = (mp0_smn_drm_trng_cntl_reg & ~MP0_SMN_DRM_TRNG_CNTL_EN_LFSR_MASK) | (en_lfsr << MP0_SMN_DRM_TRNG_CNTL_EN_LFSR_SHIFT)
#define MP0_SMN_DRM_TRNG_CNTL_SET_EN_OUT(mp0_smn_drm_trng_cntl_reg, en_out) \
      mp0_smn_drm_trng_cntl_reg = (mp0_smn_drm_trng_cntl_reg & ~MP0_SMN_DRM_TRNG_CNTL_EN_OUT_MASK) | (en_out << MP0_SMN_DRM_TRNG_CNTL_EN_OUT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_trng_cntl_t {
            unsigned int en_osc                         : MP0_SMN_DRM_TRNG_CNTL_EN_OSC_SIZE;
            unsigned int en_lfsr                        : MP0_SMN_DRM_TRNG_CNTL_EN_LFSR_SIZE;
            unsigned int                                : 6;
            unsigned int en_out                         : MP0_SMN_DRM_TRNG_CNTL_EN_OUT_SIZE;
            unsigned int                                : 23;
      } mp0_smn_drm_trng_cntl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_trng_cntl_t {
            unsigned int                                : 23;
            unsigned int en_out                         : MP0_SMN_DRM_TRNG_CNTL_EN_OUT_SIZE;
            unsigned int                                : 6;
            unsigned int en_lfsr                        : MP0_SMN_DRM_TRNG_CNTL_EN_LFSR_SIZE;
            unsigned int en_osc                         : MP0_SMN_DRM_TRNG_CNTL_EN_OSC_SIZE;
      } mp0_smn_drm_trng_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_trng_cntl_t f;
} mp0_smn_drm_trng_cntl_u;


/*
 * MP0_SMN_DRM_TRNG_DATA struct
 */

#define MP0_SMN_DRM_TRNG_DATA_REG_SIZE         32
#define MP0_SMN_DRM_TRNG_DATA_RNG_VAL_SIZE  32

#define MP0_SMN_DRM_TRNG_DATA_RNG_VAL_SHIFT  0

#define MP0_SMN_DRM_TRNG_DATA_RNG_VAL_MASK  0xffffffff

#define MP0_SMN_DRM_TRNG_DATA_MASK \
      (MP0_SMN_DRM_TRNG_DATA_RNG_VAL_MASK)

#define MP0_SMN_DRM_TRNG_DATA_DEFAULT  0xffffffff

#define MP0_SMN_DRM_TRNG_DATA_GET_RNG_VAL(mp0_smn_drm_trng_data) \
      ((mp0_smn_drm_trng_data & MP0_SMN_DRM_TRNG_DATA_RNG_VAL_MASK) >> MP0_SMN_DRM_TRNG_DATA_RNG_VAL_SHIFT)

#define MP0_SMN_DRM_TRNG_DATA_SET_RNG_VAL(mp0_smn_drm_trng_data_reg, rng_val) \
      mp0_smn_drm_trng_data_reg = (mp0_smn_drm_trng_data_reg & ~MP0_SMN_DRM_TRNG_DATA_RNG_VAL_MASK) | (rng_val << MP0_SMN_DRM_TRNG_DATA_RNG_VAL_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_trng_data_t {
            unsigned int rng_val                        : MP0_SMN_DRM_TRNG_DATA_RNG_VAL_SIZE;
      } mp0_smn_drm_trng_data_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_trng_data_t {
            unsigned int rng_val                        : MP0_SMN_DRM_TRNG_DATA_RNG_VAL_SIZE;
      } mp0_smn_drm_trng_data_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_trng_data_t f;
} mp0_smn_drm_trng_data_u;


/*
 * MP0_SMN_DRM_PERFMON_CNTL struct
 */

#define MP0_SMN_DRM_PERFMON_CNTL_REG_SIZE         32
#define MP0_SMN_DRM_PERFMON_CNTL_PERFMON_STATE_SIZE  4

#define MP0_SMN_DRM_PERFMON_CNTL_PERFMON_STATE_SHIFT  0

#define MP0_SMN_DRM_PERFMON_CNTL_PERFMON_STATE_MASK  0x0000000f

#define MP0_SMN_DRM_PERFMON_CNTL_MASK \
      (MP0_SMN_DRM_PERFMON_CNTL_PERFMON_STATE_MASK)

#define MP0_SMN_DRM_PERFMON_CNTL_DEFAULT 0x00000002

#define MP0_SMN_DRM_PERFMON_CNTL_GET_PERFMON_STATE(mp0_smn_drm_perfmon_cntl) \
      ((mp0_smn_drm_perfmon_cntl & MP0_SMN_DRM_PERFMON_CNTL_PERFMON_STATE_MASK) >> MP0_SMN_DRM_PERFMON_CNTL_PERFMON_STATE_SHIFT)

#define MP0_SMN_DRM_PERFMON_CNTL_SET_PERFMON_STATE(mp0_smn_drm_perfmon_cntl_reg, perfmon_state) \
      mp0_smn_drm_perfmon_cntl_reg = (mp0_smn_drm_perfmon_cntl_reg & ~MP0_SMN_DRM_PERFMON_CNTL_PERFMON_STATE_MASK) | (perfmon_state << MP0_SMN_DRM_PERFMON_CNTL_PERFMON_STATE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_perfmon_cntl_t {
            unsigned int perfmon_state                  : MP0_SMN_DRM_PERFMON_CNTL_PERFMON_STATE_SIZE;
            unsigned int                                : 28;
      } mp0_smn_drm_perfmon_cntl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_perfmon_cntl_t {
            unsigned int                                : 28;
            unsigned int perfmon_state                  : MP0_SMN_DRM_PERFMON_CNTL_PERFMON_STATE_SIZE;
      } mp0_smn_drm_perfmon_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_perfmon_cntl_t f;
} mp0_smn_drm_perfmon_cntl_u;


/*
 * MP0_SMN_DRM_PERFCOUNTER1_SELECT struct
 */

#define MP0_SMN_DRM_PERFCOUNTER1_SELECT_REG_SIZE         32
#define MP0_SMN_DRM_PERFCOUNTER1_SELECT_PERFCOUNTER1_SELECT_SIZE  6

#define MP0_SMN_DRM_PERFCOUNTER1_SELECT_PERFCOUNTER1_SELECT_SHIFT  0

#define MP0_SMN_DRM_PERFCOUNTER1_SELECT_PERFCOUNTER1_SELECT_MASK  0x0000003f

#define MP0_SMN_DRM_PERFCOUNTER1_SELECT_MASK \
      (MP0_SMN_DRM_PERFCOUNTER1_SELECT_PERFCOUNTER1_SELECT_MASK)

#define MP0_SMN_DRM_PERFCOUNTER1_SELECT_DEFAULT 0x00000000

#define MP0_SMN_DRM_PERFCOUNTER1_SELECT_GET_PERFCOUNTER1_SELECT(mp0_smn_drm_perfcounter1_select) \
      ((mp0_smn_drm_perfcounter1_select & MP0_SMN_DRM_PERFCOUNTER1_SELECT_PERFCOUNTER1_SELECT_MASK) >> MP0_SMN_DRM_PERFCOUNTER1_SELECT_PERFCOUNTER1_SELECT_SHIFT)

#define MP0_SMN_DRM_PERFCOUNTER1_SELECT_SET_PERFCOUNTER1_SELECT(mp0_smn_drm_perfcounter1_select_reg, perfcounter1_select) \
      mp0_smn_drm_perfcounter1_select_reg = (mp0_smn_drm_perfcounter1_select_reg & ~MP0_SMN_DRM_PERFCOUNTER1_SELECT_PERFCOUNTER1_SELECT_MASK) | (perfcounter1_select << MP0_SMN_DRM_PERFCOUNTER1_SELECT_PERFCOUNTER1_SELECT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_perfcounter1_select_t {
            unsigned int perfcounter1_select            : MP0_SMN_DRM_PERFCOUNTER1_SELECT_PERFCOUNTER1_SELECT_SIZE;
            unsigned int                                : 26;
      } mp0_smn_drm_perfcounter1_select_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_perfcounter1_select_t {
            unsigned int                                : 26;
            unsigned int perfcounter1_select            : MP0_SMN_DRM_PERFCOUNTER1_SELECT_PERFCOUNTER1_SELECT_SIZE;
      } mp0_smn_drm_perfcounter1_select_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_perfcounter1_select_t f;
} mp0_smn_drm_perfcounter1_select_u;


/*
 * MP0_SMN_DRM_PERFCOUNTER2_SELECT struct
 */

#define MP0_SMN_DRM_PERFCOUNTER2_SELECT_REG_SIZE         32
#define MP0_SMN_DRM_PERFCOUNTER2_SELECT_PERFCOUNTER2_SELECT_SIZE  6

#define MP0_SMN_DRM_PERFCOUNTER2_SELECT_PERFCOUNTER2_SELECT_SHIFT  0

#define MP0_SMN_DRM_PERFCOUNTER2_SELECT_PERFCOUNTER2_SELECT_MASK  0x0000003f

#define MP0_SMN_DRM_PERFCOUNTER2_SELECT_MASK \
      (MP0_SMN_DRM_PERFCOUNTER2_SELECT_PERFCOUNTER2_SELECT_MASK)

#define MP0_SMN_DRM_PERFCOUNTER2_SELECT_DEFAULT 0x00000000

#define MP0_SMN_DRM_PERFCOUNTER2_SELECT_GET_PERFCOUNTER2_SELECT(mp0_smn_drm_perfcounter2_select) \
      ((mp0_smn_drm_perfcounter2_select & MP0_SMN_DRM_PERFCOUNTER2_SELECT_PERFCOUNTER2_SELECT_MASK) >> MP0_SMN_DRM_PERFCOUNTER2_SELECT_PERFCOUNTER2_SELECT_SHIFT)

#define MP0_SMN_DRM_PERFCOUNTER2_SELECT_SET_PERFCOUNTER2_SELECT(mp0_smn_drm_perfcounter2_select_reg, perfcounter2_select) \
      mp0_smn_drm_perfcounter2_select_reg = (mp0_smn_drm_perfcounter2_select_reg & ~MP0_SMN_DRM_PERFCOUNTER2_SELECT_PERFCOUNTER2_SELECT_MASK) | (perfcounter2_select << MP0_SMN_DRM_PERFCOUNTER2_SELECT_PERFCOUNTER2_SELECT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_perfcounter2_select_t {
            unsigned int perfcounter2_select            : MP0_SMN_DRM_PERFCOUNTER2_SELECT_PERFCOUNTER2_SELECT_SIZE;
            unsigned int                                : 26;
      } mp0_smn_drm_perfcounter2_select_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_perfcounter2_select_t {
            unsigned int                                : 26;
            unsigned int perfcounter2_select            : MP0_SMN_DRM_PERFCOUNTER2_SELECT_PERFCOUNTER2_SELECT_SIZE;
      } mp0_smn_drm_perfcounter2_select_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_perfcounter2_select_t f;
} mp0_smn_drm_perfcounter2_select_u;


/*
 * MP0_SMN_DRM_PERFCOUNTER1_LO struct
 */

#define MP0_SMN_DRM_PERFCOUNTER1_LO_REG_SIZE         32
#define MP0_SMN_DRM_PERFCOUNTER1_LO_LO_SIZE  32

#define MP0_SMN_DRM_PERFCOUNTER1_LO_LO_SHIFT  0

#define MP0_SMN_DRM_PERFCOUNTER1_LO_LO_MASK  0xffffffff

#define MP0_SMN_DRM_PERFCOUNTER1_LO_MASK \
      (MP0_SMN_DRM_PERFCOUNTER1_LO_LO_MASK)

#define MP0_SMN_DRM_PERFCOUNTER1_LO_DEFAULT 0x00000000

#define MP0_SMN_DRM_PERFCOUNTER1_LO_GET_LO(mp0_smn_drm_perfcounter1_lo) \
      ((mp0_smn_drm_perfcounter1_lo & MP0_SMN_DRM_PERFCOUNTER1_LO_LO_MASK) >> MP0_SMN_DRM_PERFCOUNTER1_LO_LO_SHIFT)

#define MP0_SMN_DRM_PERFCOUNTER1_LO_SET_LO(mp0_smn_drm_perfcounter1_lo_reg, lo) \
      mp0_smn_drm_perfcounter1_lo_reg = (mp0_smn_drm_perfcounter1_lo_reg & ~MP0_SMN_DRM_PERFCOUNTER1_LO_LO_MASK) | (lo << MP0_SMN_DRM_PERFCOUNTER1_LO_LO_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_perfcounter1_lo_t {
            unsigned int lo                             : MP0_SMN_DRM_PERFCOUNTER1_LO_LO_SIZE;
      } mp0_smn_drm_perfcounter1_lo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_perfcounter1_lo_t {
            unsigned int lo                             : MP0_SMN_DRM_PERFCOUNTER1_LO_LO_SIZE;
      } mp0_smn_drm_perfcounter1_lo_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_perfcounter1_lo_t f;
} mp0_smn_drm_perfcounter1_lo_u;


/*
 * MP0_SMN_DRM_PERFCOUNTER1_HI struct
 */

#define MP0_SMN_DRM_PERFCOUNTER1_HI_REG_SIZE         32
#define MP0_SMN_DRM_PERFCOUNTER1_HI_HI_SIZE  16

#define MP0_SMN_DRM_PERFCOUNTER1_HI_HI_SHIFT  0

#define MP0_SMN_DRM_PERFCOUNTER1_HI_HI_MASK  0x0000ffff

#define MP0_SMN_DRM_PERFCOUNTER1_HI_MASK \
      (MP0_SMN_DRM_PERFCOUNTER1_HI_HI_MASK)

#define MP0_SMN_DRM_PERFCOUNTER1_HI_DEFAULT 0x00000000

#define MP0_SMN_DRM_PERFCOUNTER1_HI_GET_HI(mp0_smn_drm_perfcounter1_hi) \
      ((mp0_smn_drm_perfcounter1_hi & MP0_SMN_DRM_PERFCOUNTER1_HI_HI_MASK) >> MP0_SMN_DRM_PERFCOUNTER1_HI_HI_SHIFT)

#define MP0_SMN_DRM_PERFCOUNTER1_HI_SET_HI(mp0_smn_drm_perfcounter1_hi_reg, hi) \
      mp0_smn_drm_perfcounter1_hi_reg = (mp0_smn_drm_perfcounter1_hi_reg & ~MP0_SMN_DRM_PERFCOUNTER1_HI_HI_MASK) | (hi << MP0_SMN_DRM_PERFCOUNTER1_HI_HI_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_perfcounter1_hi_t {
            unsigned int hi                             : MP0_SMN_DRM_PERFCOUNTER1_HI_HI_SIZE;
            unsigned int                                : 16;
      } mp0_smn_drm_perfcounter1_hi_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_perfcounter1_hi_t {
            unsigned int                                : 16;
            unsigned int hi                             : MP0_SMN_DRM_PERFCOUNTER1_HI_HI_SIZE;
      } mp0_smn_drm_perfcounter1_hi_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_perfcounter1_hi_t f;
} mp0_smn_drm_perfcounter1_hi_u;


/*
 * MP0_SMN_DRM_PERFCOUNTER2_LO struct
 */

#define MP0_SMN_DRM_PERFCOUNTER2_LO_REG_SIZE         32
#define MP0_SMN_DRM_PERFCOUNTER2_LO_LO_SIZE  32

#define MP0_SMN_DRM_PERFCOUNTER2_LO_LO_SHIFT  0

#define MP0_SMN_DRM_PERFCOUNTER2_LO_LO_MASK  0xffffffff

#define MP0_SMN_DRM_PERFCOUNTER2_LO_MASK \
      (MP0_SMN_DRM_PERFCOUNTER2_LO_LO_MASK)

#define MP0_SMN_DRM_PERFCOUNTER2_LO_DEFAULT 0x00000000

#define MP0_SMN_DRM_PERFCOUNTER2_LO_GET_LO(mp0_smn_drm_perfcounter2_lo) \
      ((mp0_smn_drm_perfcounter2_lo & MP0_SMN_DRM_PERFCOUNTER2_LO_LO_MASK) >> MP0_SMN_DRM_PERFCOUNTER2_LO_LO_SHIFT)

#define MP0_SMN_DRM_PERFCOUNTER2_LO_SET_LO(mp0_smn_drm_perfcounter2_lo_reg, lo) \
      mp0_smn_drm_perfcounter2_lo_reg = (mp0_smn_drm_perfcounter2_lo_reg & ~MP0_SMN_DRM_PERFCOUNTER2_LO_LO_MASK) | (lo << MP0_SMN_DRM_PERFCOUNTER2_LO_LO_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_perfcounter2_lo_t {
            unsigned int lo                             : MP0_SMN_DRM_PERFCOUNTER2_LO_LO_SIZE;
      } mp0_smn_drm_perfcounter2_lo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_perfcounter2_lo_t {
            unsigned int lo                             : MP0_SMN_DRM_PERFCOUNTER2_LO_LO_SIZE;
      } mp0_smn_drm_perfcounter2_lo_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_perfcounter2_lo_t f;
} mp0_smn_drm_perfcounter2_lo_u;


/*
 * MP0_SMN_DRM_PERFCOUNTER2_HI struct
 */

#define MP0_SMN_DRM_PERFCOUNTER2_HI_REG_SIZE         32
#define MP0_SMN_DRM_PERFCOUNTER2_HI_HI_SIZE  16

#define MP0_SMN_DRM_PERFCOUNTER2_HI_HI_SHIFT  0

#define MP0_SMN_DRM_PERFCOUNTER2_HI_HI_MASK  0x0000ffff

#define MP0_SMN_DRM_PERFCOUNTER2_HI_MASK \
      (MP0_SMN_DRM_PERFCOUNTER2_HI_HI_MASK)

#define MP0_SMN_DRM_PERFCOUNTER2_HI_DEFAULT 0x00000000

#define MP0_SMN_DRM_PERFCOUNTER2_HI_GET_HI(mp0_smn_drm_perfcounter2_hi) \
      ((mp0_smn_drm_perfcounter2_hi & MP0_SMN_DRM_PERFCOUNTER2_HI_HI_MASK) >> MP0_SMN_DRM_PERFCOUNTER2_HI_HI_SHIFT)

#define MP0_SMN_DRM_PERFCOUNTER2_HI_SET_HI(mp0_smn_drm_perfcounter2_hi_reg, hi) \
      mp0_smn_drm_perfcounter2_hi_reg = (mp0_smn_drm_perfcounter2_hi_reg & ~MP0_SMN_DRM_PERFCOUNTER2_HI_HI_MASK) | (hi << MP0_SMN_DRM_PERFCOUNTER2_HI_HI_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_perfcounter2_hi_t {
            unsigned int hi                             : MP0_SMN_DRM_PERFCOUNTER2_HI_HI_SIZE;
            unsigned int                                : 16;
      } mp0_smn_drm_perfcounter2_hi_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_perfcounter2_hi_t {
            unsigned int                                : 16;
            unsigned int hi                             : MP0_SMN_DRM_PERFCOUNTER2_HI_HI_SIZE;
      } mp0_smn_drm_perfcounter2_hi_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_perfcounter2_hi_t f;
} mp0_smn_drm_perfcounter2_hi_u;


/*
 * MP0_SMN_DRM_DEBUG struct
 */

#define MP0_SMN_DRM_DEBUG_REG_SIZE         32
#define MP0_SMN_DRM_DEBUG_DEBUG_UNUSED_0_SIZE  24
#define MP0_SMN_DRM_DEBUG_DEBUG_BUS_SELECT_SIZE  6
#define MP0_SMN_DRM_DEBUG_DEBUG_UNUSED_1_SIZE  2

#define MP0_SMN_DRM_DEBUG_DEBUG_UNUSED_0_SHIFT  0
#define MP0_SMN_DRM_DEBUG_DEBUG_BUS_SELECT_SHIFT  24
#define MP0_SMN_DRM_DEBUG_DEBUG_UNUSED_1_SHIFT  30

#define MP0_SMN_DRM_DEBUG_DEBUG_UNUSED_0_MASK  0x00ffffff
#define MP0_SMN_DRM_DEBUG_DEBUG_BUS_SELECT_MASK  0x3f000000
#define MP0_SMN_DRM_DEBUG_DEBUG_UNUSED_1_MASK  0xc0000000

#define MP0_SMN_DRM_DEBUG_MASK \
      (MP0_SMN_DRM_DEBUG_DEBUG_UNUSED_0_MASK | \
      MP0_SMN_DRM_DEBUG_DEBUG_BUS_SELECT_MASK | \
      MP0_SMN_DRM_DEBUG_DEBUG_UNUSED_1_MASK)

#define MP0_SMN_DRM_DEBUG_DEFAULT      0x00000000

#define MP0_SMN_DRM_DEBUG_GET_DEBUG_UNUSED_0(mp0_smn_drm_debug) \
      ((mp0_smn_drm_debug & MP0_SMN_DRM_DEBUG_DEBUG_UNUSED_0_MASK) >> MP0_SMN_DRM_DEBUG_DEBUG_UNUSED_0_SHIFT)
#define MP0_SMN_DRM_DEBUG_GET_DEBUG_BUS_SELECT(mp0_smn_drm_debug) \
      ((mp0_smn_drm_debug & MP0_SMN_DRM_DEBUG_DEBUG_BUS_SELECT_MASK) >> MP0_SMN_DRM_DEBUG_DEBUG_BUS_SELECT_SHIFT)
#define MP0_SMN_DRM_DEBUG_GET_DEBUG_UNUSED_1(mp0_smn_drm_debug) \
      ((mp0_smn_drm_debug & MP0_SMN_DRM_DEBUG_DEBUG_UNUSED_1_MASK) >> MP0_SMN_DRM_DEBUG_DEBUG_UNUSED_1_SHIFT)

#define MP0_SMN_DRM_DEBUG_SET_DEBUG_UNUSED_0(mp0_smn_drm_debug_reg, debug_unused_0) \
      mp0_smn_drm_debug_reg = (mp0_smn_drm_debug_reg & ~MP0_SMN_DRM_DEBUG_DEBUG_UNUSED_0_MASK) | (debug_unused_0 << MP0_SMN_DRM_DEBUG_DEBUG_UNUSED_0_SHIFT)
#define MP0_SMN_DRM_DEBUG_SET_DEBUG_BUS_SELECT(mp0_smn_drm_debug_reg, debug_bus_select) \
      mp0_smn_drm_debug_reg = (mp0_smn_drm_debug_reg & ~MP0_SMN_DRM_DEBUG_DEBUG_BUS_SELECT_MASK) | (debug_bus_select << MP0_SMN_DRM_DEBUG_DEBUG_BUS_SELECT_SHIFT)
#define MP0_SMN_DRM_DEBUG_SET_DEBUG_UNUSED_1(mp0_smn_drm_debug_reg, debug_unused_1) \
      mp0_smn_drm_debug_reg = (mp0_smn_drm_debug_reg & ~MP0_SMN_DRM_DEBUG_DEBUG_UNUSED_1_MASK) | (debug_unused_1 << MP0_SMN_DRM_DEBUG_DEBUG_UNUSED_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_debug_t {
            unsigned int debug_unused_0                 : MP0_SMN_DRM_DEBUG_DEBUG_UNUSED_0_SIZE;
            unsigned int debug_bus_select               : MP0_SMN_DRM_DEBUG_DEBUG_BUS_SELECT_SIZE;
            unsigned int debug_unused_1                 : MP0_SMN_DRM_DEBUG_DEBUG_UNUSED_1_SIZE;
      } mp0_smn_drm_debug_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_debug_t {
            unsigned int debug_unused_1                 : MP0_SMN_DRM_DEBUG_DEBUG_UNUSED_1_SIZE;
            unsigned int debug_bus_select               : MP0_SMN_DRM_DEBUG_DEBUG_BUS_SELECT_SIZE;
            unsigned int debug_unused_0                 : MP0_SMN_DRM_DEBUG_DEBUG_UNUSED_0_SIZE;
      } mp0_smn_drm_debug_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_debug_t f;
} mp0_smn_drm_debug_u;


/*
 * MP0_SMN_DRM_IH_CREDITS struct
 */

#define MP0_SMN_DRM_IH_CREDITS_REG_SIZE         32
#define MP0_SMN_DRM_IH_CREDITS_IH_CREDITS_SIZE  5

#define MP0_SMN_DRM_IH_CREDITS_IH_CREDITS_SHIFT  0

#define MP0_SMN_DRM_IH_CREDITS_IH_CREDITS_MASK  0x0000001f

#define MP0_SMN_DRM_IH_CREDITS_MASK \
      (MP0_SMN_DRM_IH_CREDITS_IH_CREDITS_MASK)

#define MP0_SMN_DRM_IH_CREDITS_DEFAULT 0x00000010

#define MP0_SMN_DRM_IH_CREDITS_GET_IH_CREDITS(mp0_smn_drm_ih_credits) \
      ((mp0_smn_drm_ih_credits & MP0_SMN_DRM_IH_CREDITS_IH_CREDITS_MASK) >> MP0_SMN_DRM_IH_CREDITS_IH_CREDITS_SHIFT)

#define MP0_SMN_DRM_IH_CREDITS_SET_IH_CREDITS(mp0_smn_drm_ih_credits_reg, ih_credits) \
      mp0_smn_drm_ih_credits_reg = (mp0_smn_drm_ih_credits_reg & ~MP0_SMN_DRM_IH_CREDITS_IH_CREDITS_MASK) | (ih_credits << MP0_SMN_DRM_IH_CREDITS_IH_CREDITS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_ih_credits_t {
            unsigned int ih_credits                     : MP0_SMN_DRM_IH_CREDITS_IH_CREDITS_SIZE;
            unsigned int                                : 27;
      } mp0_smn_drm_ih_credits_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_ih_credits_t {
            unsigned int                                : 27;
            unsigned int ih_credits                     : MP0_SMN_DRM_IH_CREDITS_IH_CREDITS_SIZE;
      } mp0_smn_drm_ih_credits_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_ih_credits_t f;
} mp0_smn_drm_ih_credits_u;


/*
 * MP0_SMN_DRM_INT_STATUS struct
 */

#define MP0_SMN_DRM_INT_STATUS_REG_SIZE         32
#define MP0_SMN_DRM_INT_STATUS_DH1_DONE_SIZE  1
#define MP0_SMN_DRM_INT_STATUS_DH2_DONE_SIZE  1
#define MP0_SMN_DRM_INT_STATUS_HFS_DONE_SIZE  1
#define MP0_SMN_DRM_INT_STATUS_SIG_DONE_SIZE  1
#define MP0_SMN_DRM_INT_STATUS_SIG_VALID_SIZE  1
#define MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT2_SIZE  1
#define MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT0_SIZE  1
#define MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT1_SIZE  1
#define MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT2_SIZE  1
#define MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT0_SIZE  1
#define MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT1_SIZE  1
#define MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT3_SIZE  1
#define MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT3_SIZE  1
#define MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT4_SIZE  1
#define MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT4_SIZE  1

#define MP0_SMN_DRM_INT_STATUS_DH1_DONE_SHIFT  0
#define MP0_SMN_DRM_INT_STATUS_DH2_DONE_SHIFT  1
#define MP0_SMN_DRM_INT_STATUS_HFS_DONE_SHIFT  2
#define MP0_SMN_DRM_INT_STATUS_SIG_DONE_SHIFT  3
#define MP0_SMN_DRM_INT_STATUS_SIG_VALID_SHIFT  4
#define MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT2_SHIFT  5
#define MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT0_SHIFT  6
#define MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT1_SHIFT  7
#define MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT2_SHIFT  8
#define MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT0_SHIFT  9
#define MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT1_SHIFT  10
#define MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT3_SHIFT  11
#define MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT3_SHIFT  12
#define MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT4_SHIFT  13
#define MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT4_SHIFT  14

#define MP0_SMN_DRM_INT_STATUS_DH1_DONE_MASK  0x00000001
#define MP0_SMN_DRM_INT_STATUS_DH2_DONE_MASK  0x00000002
#define MP0_SMN_DRM_INT_STATUS_HFS_DONE_MASK  0x00000004
#define MP0_SMN_DRM_INT_STATUS_SIG_DONE_MASK  0x00000008
#define MP0_SMN_DRM_INT_STATUS_SIG_VALID_MASK  0x00000010
#define MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT2_MASK  0x00000020
#define MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT0_MASK  0x00000040
#define MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT1_MASK  0x00000080
#define MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT2_MASK  0x00000100
#define MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT0_MASK  0x00000200
#define MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT1_MASK  0x00000400
#define MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT3_MASK  0x00000800
#define MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT3_MASK  0x00001000
#define MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT4_MASK  0x00002000
#define MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT4_MASK  0x00004000

#define MP0_SMN_DRM_INT_STATUS_MASK \
      (MP0_SMN_DRM_INT_STATUS_DH1_DONE_MASK | \
      MP0_SMN_DRM_INT_STATUS_DH2_DONE_MASK | \
      MP0_SMN_DRM_INT_STATUS_HFS_DONE_MASK | \
      MP0_SMN_DRM_INT_STATUS_SIG_DONE_MASK | \
      MP0_SMN_DRM_INT_STATUS_SIG_VALID_MASK | \
      MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT2_MASK | \
      MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT0_MASK | \
      MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT1_MASK | \
      MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT2_MASK | \
      MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT0_MASK | \
      MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT1_MASK | \
      MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT3_MASK | \
      MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT3_MASK | \
      MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT4_MASK | \
      MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT4_MASK)

#define MP0_SMN_DRM_INT_STATUS_DEFAULT 0x00000000

#define MP0_SMN_DRM_INT_STATUS_GET_DH1_DONE(mp0_smn_drm_int_status) \
      ((mp0_smn_drm_int_status & MP0_SMN_DRM_INT_STATUS_DH1_DONE_MASK) >> MP0_SMN_DRM_INT_STATUS_DH1_DONE_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_GET_DH2_DONE(mp0_smn_drm_int_status) \
      ((mp0_smn_drm_int_status & MP0_SMN_DRM_INT_STATUS_DH2_DONE_MASK) >> MP0_SMN_DRM_INT_STATUS_DH2_DONE_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_GET_HFS_DONE(mp0_smn_drm_int_status) \
      ((mp0_smn_drm_int_status & MP0_SMN_DRM_INT_STATUS_HFS_DONE_MASK) >> MP0_SMN_DRM_INT_STATUS_HFS_DONE_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_GET_SIG_DONE(mp0_smn_drm_int_status) \
      ((mp0_smn_drm_int_status & MP0_SMN_DRM_INT_STATUS_SIG_DONE_MASK) >> MP0_SMN_DRM_INT_STATUS_SIG_DONE_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_GET_SIG_VALID(mp0_smn_drm_int_status) \
      ((mp0_smn_drm_int_status & MP0_SMN_DRM_INT_STATUS_SIG_VALID_MASK) >> MP0_SMN_DRM_INT_STATUS_SIG_VALID_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_GET_TIMEOUT_CLIENT2(mp0_smn_drm_int_status) \
      ((mp0_smn_drm_int_status & MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT2_MASK) >> MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT2_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_GET_TIMEOUT_CLIENT0(mp0_smn_drm_int_status) \
      ((mp0_smn_drm_int_status & MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT0_MASK) >> MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT0_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_GET_TIMEOUT_CLIENT1(mp0_smn_drm_int_status) \
      ((mp0_smn_drm_int_status & MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT1_MASK) >> MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT1_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_GET_INVALID_CLIENT2(mp0_smn_drm_int_status) \
      ((mp0_smn_drm_int_status & MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT2_MASK) >> MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT2_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_GET_INVALID_CLIENT0(mp0_smn_drm_int_status) \
      ((mp0_smn_drm_int_status & MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT0_MASK) >> MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT0_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_GET_INVALID_CLIENT1(mp0_smn_drm_int_status) \
      ((mp0_smn_drm_int_status & MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT1_MASK) >> MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT1_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_GET_TIMEOUT_CLIENT3(mp0_smn_drm_int_status) \
      ((mp0_smn_drm_int_status & MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT3_MASK) >> MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT3_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_GET_INVALID_CLIENT3(mp0_smn_drm_int_status) \
      ((mp0_smn_drm_int_status & MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT3_MASK) >> MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT3_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_GET_TIMEOUT_CLIENT4(mp0_smn_drm_int_status) \
      ((mp0_smn_drm_int_status & MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT4_MASK) >> MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT4_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_GET_INVALID_CLIENT4(mp0_smn_drm_int_status) \
      ((mp0_smn_drm_int_status & MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT4_MASK) >> MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT4_SHIFT)

#define MP0_SMN_DRM_INT_STATUS_SET_DH1_DONE(mp0_smn_drm_int_status_reg, dh1_done) \
      mp0_smn_drm_int_status_reg = (mp0_smn_drm_int_status_reg & ~MP0_SMN_DRM_INT_STATUS_DH1_DONE_MASK) | (dh1_done << MP0_SMN_DRM_INT_STATUS_DH1_DONE_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_SET_DH2_DONE(mp0_smn_drm_int_status_reg, dh2_done) \
      mp0_smn_drm_int_status_reg = (mp0_smn_drm_int_status_reg & ~MP0_SMN_DRM_INT_STATUS_DH2_DONE_MASK) | (dh2_done << MP0_SMN_DRM_INT_STATUS_DH2_DONE_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_SET_HFS_DONE(mp0_smn_drm_int_status_reg, hfs_done) \
      mp0_smn_drm_int_status_reg = (mp0_smn_drm_int_status_reg & ~MP0_SMN_DRM_INT_STATUS_HFS_DONE_MASK) | (hfs_done << MP0_SMN_DRM_INT_STATUS_HFS_DONE_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_SET_SIG_DONE(mp0_smn_drm_int_status_reg, sig_done) \
      mp0_smn_drm_int_status_reg = (mp0_smn_drm_int_status_reg & ~MP0_SMN_DRM_INT_STATUS_SIG_DONE_MASK) | (sig_done << MP0_SMN_DRM_INT_STATUS_SIG_DONE_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_SET_SIG_VALID(mp0_smn_drm_int_status_reg, sig_valid) \
      mp0_smn_drm_int_status_reg = (mp0_smn_drm_int_status_reg & ~MP0_SMN_DRM_INT_STATUS_SIG_VALID_MASK) | (sig_valid << MP0_SMN_DRM_INT_STATUS_SIG_VALID_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_SET_TIMEOUT_CLIENT2(mp0_smn_drm_int_status_reg, timeout_client2) \
      mp0_smn_drm_int_status_reg = (mp0_smn_drm_int_status_reg & ~MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT2_MASK) | (timeout_client2 << MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT2_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_SET_TIMEOUT_CLIENT0(mp0_smn_drm_int_status_reg, timeout_client0) \
      mp0_smn_drm_int_status_reg = (mp0_smn_drm_int_status_reg & ~MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT0_MASK) | (timeout_client0 << MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT0_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_SET_TIMEOUT_CLIENT1(mp0_smn_drm_int_status_reg, timeout_client1) \
      mp0_smn_drm_int_status_reg = (mp0_smn_drm_int_status_reg & ~MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT1_MASK) | (timeout_client1 << MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT1_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_SET_INVALID_CLIENT2(mp0_smn_drm_int_status_reg, invalid_client2) \
      mp0_smn_drm_int_status_reg = (mp0_smn_drm_int_status_reg & ~MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT2_MASK) | (invalid_client2 << MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT2_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_SET_INVALID_CLIENT0(mp0_smn_drm_int_status_reg, invalid_client0) \
      mp0_smn_drm_int_status_reg = (mp0_smn_drm_int_status_reg & ~MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT0_MASK) | (invalid_client0 << MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT0_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_SET_INVALID_CLIENT1(mp0_smn_drm_int_status_reg, invalid_client1) \
      mp0_smn_drm_int_status_reg = (mp0_smn_drm_int_status_reg & ~MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT1_MASK) | (invalid_client1 << MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT1_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_SET_TIMEOUT_CLIENT3(mp0_smn_drm_int_status_reg, timeout_client3) \
      mp0_smn_drm_int_status_reg = (mp0_smn_drm_int_status_reg & ~MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT3_MASK) | (timeout_client3 << MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT3_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_SET_INVALID_CLIENT3(mp0_smn_drm_int_status_reg, invalid_client3) \
      mp0_smn_drm_int_status_reg = (mp0_smn_drm_int_status_reg & ~MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT3_MASK) | (invalid_client3 << MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT3_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_SET_TIMEOUT_CLIENT4(mp0_smn_drm_int_status_reg, timeout_client4) \
      mp0_smn_drm_int_status_reg = (mp0_smn_drm_int_status_reg & ~MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT4_MASK) | (timeout_client4 << MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT4_SHIFT)
#define MP0_SMN_DRM_INT_STATUS_SET_INVALID_CLIENT4(mp0_smn_drm_int_status_reg, invalid_client4) \
      mp0_smn_drm_int_status_reg = (mp0_smn_drm_int_status_reg & ~MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT4_MASK) | (invalid_client4 << MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT4_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_int_status_t {
            unsigned int dh1_done                       : MP0_SMN_DRM_INT_STATUS_DH1_DONE_SIZE;
            unsigned int dh2_done                       : MP0_SMN_DRM_INT_STATUS_DH2_DONE_SIZE;
            unsigned int hfs_done                       : MP0_SMN_DRM_INT_STATUS_HFS_DONE_SIZE;
            unsigned int sig_done                       : MP0_SMN_DRM_INT_STATUS_SIG_DONE_SIZE;
            unsigned int sig_valid                      : MP0_SMN_DRM_INT_STATUS_SIG_VALID_SIZE;
            unsigned int timeout_client2                : MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT2_SIZE;
            unsigned int timeout_client0                : MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT0_SIZE;
            unsigned int timeout_client1                : MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT1_SIZE;
            unsigned int invalid_client2                : MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT2_SIZE;
            unsigned int invalid_client0                : MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT0_SIZE;
            unsigned int invalid_client1                : MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT1_SIZE;
            unsigned int timeout_client3                : MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT3_SIZE;
            unsigned int invalid_client3                : MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT3_SIZE;
            unsigned int timeout_client4                : MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT4_SIZE;
            unsigned int invalid_client4                : MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT4_SIZE;
            unsigned int                                : 17;
      } mp0_smn_drm_int_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_int_status_t {
            unsigned int                                : 17;
            unsigned int invalid_client4                : MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT4_SIZE;
            unsigned int timeout_client4                : MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT4_SIZE;
            unsigned int invalid_client3                : MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT3_SIZE;
            unsigned int timeout_client3                : MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT3_SIZE;
            unsigned int invalid_client1                : MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT1_SIZE;
            unsigned int invalid_client0                : MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT0_SIZE;
            unsigned int invalid_client2                : MP0_SMN_DRM_INT_STATUS_INVALID_CLIENT2_SIZE;
            unsigned int timeout_client1                : MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT1_SIZE;
            unsigned int timeout_client0                : MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT0_SIZE;
            unsigned int timeout_client2                : MP0_SMN_DRM_INT_STATUS_TIMEOUT_CLIENT2_SIZE;
            unsigned int sig_valid                      : MP0_SMN_DRM_INT_STATUS_SIG_VALID_SIZE;
            unsigned int sig_done                       : MP0_SMN_DRM_INT_STATUS_SIG_DONE_SIZE;
            unsigned int hfs_done                       : MP0_SMN_DRM_INT_STATUS_HFS_DONE_SIZE;
            unsigned int dh2_done                       : MP0_SMN_DRM_INT_STATUS_DH2_DONE_SIZE;
            unsigned int dh1_done                       : MP0_SMN_DRM_INT_STATUS_DH1_DONE_SIZE;
      } mp0_smn_drm_int_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_int_status_t f;
} mp0_smn_drm_int_status_u;


/*
 * MP0_SMN_DRM_INT_MASK struct
 */

#define MP0_SMN_DRM_INT_MASK_REG_SIZE         32
#define MP0_SMN_DRM_INT_MASK_DH1_DONE_SIZE  1
#define MP0_SMN_DRM_INT_MASK_DH2_DONE_SIZE  1
#define MP0_SMN_DRM_INT_MASK_HFS_DONE_SIZE  1
#define MP0_SMN_DRM_INT_MASK_SIG_DONE_SIZE  1
#define MP0_SMN_DRM_INT_MASK_SIG_VALID_SIZE  1
#define MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT2_SIZE  1
#define MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT0_SIZE  1
#define MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT1_SIZE  1
#define MP0_SMN_DRM_INT_MASK_INVALID_CLIENT2_SIZE  1
#define MP0_SMN_DRM_INT_MASK_INVALID_CLIENT0_SIZE  1
#define MP0_SMN_DRM_INT_MASK_INVALID_CLIENT1_SIZE  1
#define MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT3_SIZE  1
#define MP0_SMN_DRM_INT_MASK_INVALID_CLIENT3_SIZE  1
#define MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT4_SIZE  1
#define MP0_SMN_DRM_INT_MASK_INVALID_CLIENT4_SIZE  1

#define MP0_SMN_DRM_INT_MASK_DH1_DONE_SHIFT  0
#define MP0_SMN_DRM_INT_MASK_DH2_DONE_SHIFT  1
#define MP0_SMN_DRM_INT_MASK_HFS_DONE_SHIFT  2
#define MP0_SMN_DRM_INT_MASK_SIG_DONE_SHIFT  3
#define MP0_SMN_DRM_INT_MASK_SIG_VALID_SHIFT  4
#define MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT2_SHIFT  5
#define MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT0_SHIFT  6
#define MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT1_SHIFT  7
#define MP0_SMN_DRM_INT_MASK_INVALID_CLIENT2_SHIFT  8
#define MP0_SMN_DRM_INT_MASK_INVALID_CLIENT0_SHIFT  9
#define MP0_SMN_DRM_INT_MASK_INVALID_CLIENT1_SHIFT  10
#define MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT3_SHIFT  11
#define MP0_SMN_DRM_INT_MASK_INVALID_CLIENT3_SHIFT  12
#define MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT4_SHIFT  13
#define MP0_SMN_DRM_INT_MASK_INVALID_CLIENT4_SHIFT  14

#define MP0_SMN_DRM_INT_MASK_DH1_DONE_MASK  0x00000001
#define MP0_SMN_DRM_INT_MASK_DH2_DONE_MASK  0x00000002
#define MP0_SMN_DRM_INT_MASK_HFS_DONE_MASK  0x00000004
#define MP0_SMN_DRM_INT_MASK_SIG_DONE_MASK  0x00000008
#define MP0_SMN_DRM_INT_MASK_SIG_VALID_MASK  0x00000010
#define MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT2_MASK  0x00000020
#define MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT0_MASK  0x00000040
#define MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT1_MASK  0x00000080
#define MP0_SMN_DRM_INT_MASK_INVALID_CLIENT2_MASK  0x00000100
#define MP0_SMN_DRM_INT_MASK_INVALID_CLIENT0_MASK  0x00000200
#define MP0_SMN_DRM_INT_MASK_INVALID_CLIENT1_MASK  0x00000400
#define MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT3_MASK  0x00000800
#define MP0_SMN_DRM_INT_MASK_INVALID_CLIENT3_MASK  0x00001000
#define MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT4_MASK  0x00002000
#define MP0_SMN_DRM_INT_MASK_INVALID_CLIENT4_MASK  0x00004000

#define MP0_SMN_DRM_INT_MASK_MASK \
      (MP0_SMN_DRM_INT_MASK_DH1_DONE_MASK | \
      MP0_SMN_DRM_INT_MASK_DH2_DONE_MASK | \
      MP0_SMN_DRM_INT_MASK_HFS_DONE_MASK | \
      MP0_SMN_DRM_INT_MASK_SIG_DONE_MASK | \
      MP0_SMN_DRM_INT_MASK_SIG_VALID_MASK | \
      MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT2_MASK | \
      MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT0_MASK | \
      MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT1_MASK | \
      MP0_SMN_DRM_INT_MASK_INVALID_CLIENT2_MASK | \
      MP0_SMN_DRM_INT_MASK_INVALID_CLIENT0_MASK | \
      MP0_SMN_DRM_INT_MASK_INVALID_CLIENT1_MASK | \
      MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT3_MASK | \
      MP0_SMN_DRM_INT_MASK_INVALID_CLIENT3_MASK | \
      MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT4_MASK | \
      MP0_SMN_DRM_INT_MASK_INVALID_CLIENT4_MASK)

#define MP0_SMN_DRM_INT_MASK_DEFAULT   0x00000000

#define MP0_SMN_DRM_INT_MASK_GET_DH1_DONE(mp0_smn_drm_int_mask) \
      ((mp0_smn_drm_int_mask & MP0_SMN_DRM_INT_MASK_DH1_DONE_MASK) >> MP0_SMN_DRM_INT_MASK_DH1_DONE_SHIFT)
#define MP0_SMN_DRM_INT_MASK_GET_DH2_DONE(mp0_smn_drm_int_mask) \
      ((mp0_smn_drm_int_mask & MP0_SMN_DRM_INT_MASK_DH2_DONE_MASK) >> MP0_SMN_DRM_INT_MASK_DH2_DONE_SHIFT)
#define MP0_SMN_DRM_INT_MASK_GET_HFS_DONE(mp0_smn_drm_int_mask) \
      ((mp0_smn_drm_int_mask & MP0_SMN_DRM_INT_MASK_HFS_DONE_MASK) >> MP0_SMN_DRM_INT_MASK_HFS_DONE_SHIFT)
#define MP0_SMN_DRM_INT_MASK_GET_SIG_DONE(mp0_smn_drm_int_mask) \
      ((mp0_smn_drm_int_mask & MP0_SMN_DRM_INT_MASK_SIG_DONE_MASK) >> MP0_SMN_DRM_INT_MASK_SIG_DONE_SHIFT)
#define MP0_SMN_DRM_INT_MASK_GET_SIG_VALID(mp0_smn_drm_int_mask) \
      ((mp0_smn_drm_int_mask & MP0_SMN_DRM_INT_MASK_SIG_VALID_MASK) >> MP0_SMN_DRM_INT_MASK_SIG_VALID_SHIFT)
#define MP0_SMN_DRM_INT_MASK_GET_TIMEOUT_CLIENT2(mp0_smn_drm_int_mask) \
      ((mp0_smn_drm_int_mask & MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT2_MASK) >> MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT2_SHIFT)
#define MP0_SMN_DRM_INT_MASK_GET_TIMEOUT_CLIENT0(mp0_smn_drm_int_mask) \
      ((mp0_smn_drm_int_mask & MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT0_MASK) >> MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT0_SHIFT)
#define MP0_SMN_DRM_INT_MASK_GET_TIMEOUT_CLIENT1(mp0_smn_drm_int_mask) \
      ((mp0_smn_drm_int_mask & MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT1_MASK) >> MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT1_SHIFT)
#define MP0_SMN_DRM_INT_MASK_GET_INVALID_CLIENT2(mp0_smn_drm_int_mask) \
      ((mp0_smn_drm_int_mask & MP0_SMN_DRM_INT_MASK_INVALID_CLIENT2_MASK) >> MP0_SMN_DRM_INT_MASK_INVALID_CLIENT2_SHIFT)
#define MP0_SMN_DRM_INT_MASK_GET_INVALID_CLIENT0(mp0_smn_drm_int_mask) \
      ((mp0_smn_drm_int_mask & MP0_SMN_DRM_INT_MASK_INVALID_CLIENT0_MASK) >> MP0_SMN_DRM_INT_MASK_INVALID_CLIENT0_SHIFT)
#define MP0_SMN_DRM_INT_MASK_GET_INVALID_CLIENT1(mp0_smn_drm_int_mask) \
      ((mp0_smn_drm_int_mask & MP0_SMN_DRM_INT_MASK_INVALID_CLIENT1_MASK) >> MP0_SMN_DRM_INT_MASK_INVALID_CLIENT1_SHIFT)
#define MP0_SMN_DRM_INT_MASK_GET_TIMEOUT_CLIENT3(mp0_smn_drm_int_mask) \
      ((mp0_smn_drm_int_mask & MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT3_MASK) >> MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT3_SHIFT)
#define MP0_SMN_DRM_INT_MASK_GET_INVALID_CLIENT3(mp0_smn_drm_int_mask) \
      ((mp0_smn_drm_int_mask & MP0_SMN_DRM_INT_MASK_INVALID_CLIENT3_MASK) >> MP0_SMN_DRM_INT_MASK_INVALID_CLIENT3_SHIFT)
#define MP0_SMN_DRM_INT_MASK_GET_TIMEOUT_CLIENT4(mp0_smn_drm_int_mask) \
      ((mp0_smn_drm_int_mask & MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT4_MASK) >> MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT4_SHIFT)
#define MP0_SMN_DRM_INT_MASK_GET_INVALID_CLIENT4(mp0_smn_drm_int_mask) \
      ((mp0_smn_drm_int_mask & MP0_SMN_DRM_INT_MASK_INVALID_CLIENT4_MASK) >> MP0_SMN_DRM_INT_MASK_INVALID_CLIENT4_SHIFT)

#define MP0_SMN_DRM_INT_MASK_SET_DH1_DONE(mp0_smn_drm_int_mask_reg, dh1_done) \
      mp0_smn_drm_int_mask_reg = (mp0_smn_drm_int_mask_reg & ~MP0_SMN_DRM_INT_MASK_DH1_DONE_MASK) | (dh1_done << MP0_SMN_DRM_INT_MASK_DH1_DONE_SHIFT)
#define MP0_SMN_DRM_INT_MASK_SET_DH2_DONE(mp0_smn_drm_int_mask_reg, dh2_done) \
      mp0_smn_drm_int_mask_reg = (mp0_smn_drm_int_mask_reg & ~MP0_SMN_DRM_INT_MASK_DH2_DONE_MASK) | (dh2_done << MP0_SMN_DRM_INT_MASK_DH2_DONE_SHIFT)
#define MP0_SMN_DRM_INT_MASK_SET_HFS_DONE(mp0_smn_drm_int_mask_reg, hfs_done) \
      mp0_smn_drm_int_mask_reg = (mp0_smn_drm_int_mask_reg & ~MP0_SMN_DRM_INT_MASK_HFS_DONE_MASK) | (hfs_done << MP0_SMN_DRM_INT_MASK_HFS_DONE_SHIFT)
#define MP0_SMN_DRM_INT_MASK_SET_SIG_DONE(mp0_smn_drm_int_mask_reg, sig_done) \
      mp0_smn_drm_int_mask_reg = (mp0_smn_drm_int_mask_reg & ~MP0_SMN_DRM_INT_MASK_SIG_DONE_MASK) | (sig_done << MP0_SMN_DRM_INT_MASK_SIG_DONE_SHIFT)
#define MP0_SMN_DRM_INT_MASK_SET_SIG_VALID(mp0_smn_drm_int_mask_reg, sig_valid) \
      mp0_smn_drm_int_mask_reg = (mp0_smn_drm_int_mask_reg & ~MP0_SMN_DRM_INT_MASK_SIG_VALID_MASK) | (sig_valid << MP0_SMN_DRM_INT_MASK_SIG_VALID_SHIFT)
#define MP0_SMN_DRM_INT_MASK_SET_TIMEOUT_CLIENT2(mp0_smn_drm_int_mask_reg, timeout_client2) \
      mp0_smn_drm_int_mask_reg = (mp0_smn_drm_int_mask_reg & ~MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT2_MASK) | (timeout_client2 << MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT2_SHIFT)
#define MP0_SMN_DRM_INT_MASK_SET_TIMEOUT_CLIENT0(mp0_smn_drm_int_mask_reg, timeout_client0) \
      mp0_smn_drm_int_mask_reg = (mp0_smn_drm_int_mask_reg & ~MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT0_MASK) | (timeout_client0 << MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT0_SHIFT)
#define MP0_SMN_DRM_INT_MASK_SET_TIMEOUT_CLIENT1(mp0_smn_drm_int_mask_reg, timeout_client1) \
      mp0_smn_drm_int_mask_reg = (mp0_smn_drm_int_mask_reg & ~MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT1_MASK) | (timeout_client1 << MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT1_SHIFT)
#define MP0_SMN_DRM_INT_MASK_SET_INVALID_CLIENT2(mp0_smn_drm_int_mask_reg, invalid_client2) \
      mp0_smn_drm_int_mask_reg = (mp0_smn_drm_int_mask_reg & ~MP0_SMN_DRM_INT_MASK_INVALID_CLIENT2_MASK) | (invalid_client2 << MP0_SMN_DRM_INT_MASK_INVALID_CLIENT2_SHIFT)
#define MP0_SMN_DRM_INT_MASK_SET_INVALID_CLIENT0(mp0_smn_drm_int_mask_reg, invalid_client0) \
      mp0_smn_drm_int_mask_reg = (mp0_smn_drm_int_mask_reg & ~MP0_SMN_DRM_INT_MASK_INVALID_CLIENT0_MASK) | (invalid_client0 << MP0_SMN_DRM_INT_MASK_INVALID_CLIENT0_SHIFT)
#define MP0_SMN_DRM_INT_MASK_SET_INVALID_CLIENT1(mp0_smn_drm_int_mask_reg, invalid_client1) \
      mp0_smn_drm_int_mask_reg = (mp0_smn_drm_int_mask_reg & ~MP0_SMN_DRM_INT_MASK_INVALID_CLIENT1_MASK) | (invalid_client1 << MP0_SMN_DRM_INT_MASK_INVALID_CLIENT1_SHIFT)
#define MP0_SMN_DRM_INT_MASK_SET_TIMEOUT_CLIENT3(mp0_smn_drm_int_mask_reg, timeout_client3) \
      mp0_smn_drm_int_mask_reg = (mp0_smn_drm_int_mask_reg & ~MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT3_MASK) | (timeout_client3 << MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT3_SHIFT)
#define MP0_SMN_DRM_INT_MASK_SET_INVALID_CLIENT3(mp0_smn_drm_int_mask_reg, invalid_client3) \
      mp0_smn_drm_int_mask_reg = (mp0_smn_drm_int_mask_reg & ~MP0_SMN_DRM_INT_MASK_INVALID_CLIENT3_MASK) | (invalid_client3 << MP0_SMN_DRM_INT_MASK_INVALID_CLIENT3_SHIFT)
#define MP0_SMN_DRM_INT_MASK_SET_TIMEOUT_CLIENT4(mp0_smn_drm_int_mask_reg, timeout_client4) \
      mp0_smn_drm_int_mask_reg = (mp0_smn_drm_int_mask_reg & ~MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT4_MASK) | (timeout_client4 << MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT4_SHIFT)
#define MP0_SMN_DRM_INT_MASK_SET_INVALID_CLIENT4(mp0_smn_drm_int_mask_reg, invalid_client4) \
      mp0_smn_drm_int_mask_reg = (mp0_smn_drm_int_mask_reg & ~MP0_SMN_DRM_INT_MASK_INVALID_CLIENT4_MASK) | (invalid_client4 << MP0_SMN_DRM_INT_MASK_INVALID_CLIENT4_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_int_mask_t {
            unsigned int dh1_done                       : MP0_SMN_DRM_INT_MASK_DH1_DONE_SIZE;
            unsigned int dh2_done                       : MP0_SMN_DRM_INT_MASK_DH2_DONE_SIZE;
            unsigned int hfs_done                       : MP0_SMN_DRM_INT_MASK_HFS_DONE_SIZE;
            unsigned int sig_done                       : MP0_SMN_DRM_INT_MASK_SIG_DONE_SIZE;
            unsigned int sig_valid                      : MP0_SMN_DRM_INT_MASK_SIG_VALID_SIZE;
            unsigned int timeout_client2                : MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT2_SIZE;
            unsigned int timeout_client0                : MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT0_SIZE;
            unsigned int timeout_client1                : MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT1_SIZE;
            unsigned int invalid_client2                : MP0_SMN_DRM_INT_MASK_INVALID_CLIENT2_SIZE;
            unsigned int invalid_client0                : MP0_SMN_DRM_INT_MASK_INVALID_CLIENT0_SIZE;
            unsigned int invalid_client1                : MP0_SMN_DRM_INT_MASK_INVALID_CLIENT1_SIZE;
            unsigned int timeout_client3                : MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT3_SIZE;
            unsigned int invalid_client3                : MP0_SMN_DRM_INT_MASK_INVALID_CLIENT3_SIZE;
            unsigned int timeout_client4                : MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT4_SIZE;
            unsigned int invalid_client4                : MP0_SMN_DRM_INT_MASK_INVALID_CLIENT4_SIZE;
            unsigned int                                : 17;
      } mp0_smn_drm_int_mask_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_int_mask_t {
            unsigned int                                : 17;
            unsigned int invalid_client4                : MP0_SMN_DRM_INT_MASK_INVALID_CLIENT4_SIZE;
            unsigned int timeout_client4                : MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT4_SIZE;
            unsigned int invalid_client3                : MP0_SMN_DRM_INT_MASK_INVALID_CLIENT3_SIZE;
            unsigned int timeout_client3                : MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT3_SIZE;
            unsigned int invalid_client1                : MP0_SMN_DRM_INT_MASK_INVALID_CLIENT1_SIZE;
            unsigned int invalid_client0                : MP0_SMN_DRM_INT_MASK_INVALID_CLIENT0_SIZE;
            unsigned int invalid_client2                : MP0_SMN_DRM_INT_MASK_INVALID_CLIENT2_SIZE;
            unsigned int timeout_client1                : MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT1_SIZE;
            unsigned int timeout_client0                : MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT0_SIZE;
            unsigned int timeout_client2                : MP0_SMN_DRM_INT_MASK_TIMEOUT_CLIENT2_SIZE;
            unsigned int sig_valid                      : MP0_SMN_DRM_INT_MASK_SIG_VALID_SIZE;
            unsigned int sig_done                       : MP0_SMN_DRM_INT_MASK_SIG_DONE_SIZE;
            unsigned int hfs_done                       : MP0_SMN_DRM_INT_MASK_HFS_DONE_SIZE;
            unsigned int dh2_done                       : MP0_SMN_DRM_INT_MASK_DH2_DONE_SIZE;
            unsigned int dh1_done                       : MP0_SMN_DRM_INT_MASK_DH1_DONE_SIZE;
      } mp0_smn_drm_int_mask_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_int_mask_t f;
} mp0_smn_drm_int_mask_u;


/*
 * MP0_SMN_DRM_INT_ACK struct
 */

#define MP0_SMN_DRM_INT_ACK_REG_SIZE         32
#define MP0_SMN_DRM_INT_ACK_DH1_DONE_SIZE  1
#define MP0_SMN_DRM_INT_ACK_DH2_DONE_SIZE  1
#define MP0_SMN_DRM_INT_ACK_HFS_DONE_SIZE  1
#define MP0_SMN_DRM_INT_ACK_SIG_DONE_SIZE  1
#define MP0_SMN_DRM_INT_ACK_SIG_VALID_SIZE  1
#define MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT2_SIZE  1
#define MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT0_SIZE  1
#define MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT1_SIZE  1
#define MP0_SMN_DRM_INT_ACK_INVALID_CLIENT2_SIZE  1
#define MP0_SMN_DRM_INT_ACK_INVALID_CLIENT0_SIZE  1
#define MP0_SMN_DRM_INT_ACK_INVALID_CLIENT1_SIZE  1
#define MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT3_SIZE  1
#define MP0_SMN_DRM_INT_ACK_INVALID_CLIENT3_SIZE  1
#define MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT4_SIZE  1
#define MP0_SMN_DRM_INT_ACK_INVALID_CLIENT4_SIZE  1

#define MP0_SMN_DRM_INT_ACK_DH1_DONE_SHIFT  0
#define MP0_SMN_DRM_INT_ACK_DH2_DONE_SHIFT  1
#define MP0_SMN_DRM_INT_ACK_HFS_DONE_SHIFT  2
#define MP0_SMN_DRM_INT_ACK_SIG_DONE_SHIFT  3
#define MP0_SMN_DRM_INT_ACK_SIG_VALID_SHIFT  4
#define MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT2_SHIFT  5
#define MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT0_SHIFT  6
#define MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT1_SHIFT  7
#define MP0_SMN_DRM_INT_ACK_INVALID_CLIENT2_SHIFT  8
#define MP0_SMN_DRM_INT_ACK_INVALID_CLIENT0_SHIFT  9
#define MP0_SMN_DRM_INT_ACK_INVALID_CLIENT1_SHIFT  10
#define MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT3_SHIFT  11
#define MP0_SMN_DRM_INT_ACK_INVALID_CLIENT3_SHIFT  12
#define MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT4_SHIFT  13
#define MP0_SMN_DRM_INT_ACK_INVALID_CLIENT4_SHIFT  14

#define MP0_SMN_DRM_INT_ACK_DH1_DONE_MASK  0x00000001
#define MP0_SMN_DRM_INT_ACK_DH2_DONE_MASK  0x00000002
#define MP0_SMN_DRM_INT_ACK_HFS_DONE_MASK  0x00000004
#define MP0_SMN_DRM_INT_ACK_SIG_DONE_MASK  0x00000008
#define MP0_SMN_DRM_INT_ACK_SIG_VALID_MASK  0x00000010
#define MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT2_MASK  0x00000020
#define MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT0_MASK  0x00000040
#define MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT1_MASK  0x00000080
#define MP0_SMN_DRM_INT_ACK_INVALID_CLIENT2_MASK  0x00000100
#define MP0_SMN_DRM_INT_ACK_INVALID_CLIENT0_MASK  0x00000200
#define MP0_SMN_DRM_INT_ACK_INVALID_CLIENT1_MASK  0x00000400
#define MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT3_MASK  0x00000800
#define MP0_SMN_DRM_INT_ACK_INVALID_CLIENT3_MASK  0x00001000
#define MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT4_MASK  0x00002000
#define MP0_SMN_DRM_INT_ACK_INVALID_CLIENT4_MASK  0x00004000

#define MP0_SMN_DRM_INT_ACK_MASK \
      (MP0_SMN_DRM_INT_ACK_DH1_DONE_MASK | \
      MP0_SMN_DRM_INT_ACK_DH2_DONE_MASK | \
      MP0_SMN_DRM_INT_ACK_HFS_DONE_MASK | \
      MP0_SMN_DRM_INT_ACK_SIG_DONE_MASK | \
      MP0_SMN_DRM_INT_ACK_SIG_VALID_MASK | \
      MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT2_MASK | \
      MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT0_MASK | \
      MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT1_MASK | \
      MP0_SMN_DRM_INT_ACK_INVALID_CLIENT2_MASK | \
      MP0_SMN_DRM_INT_ACK_INVALID_CLIENT0_MASK | \
      MP0_SMN_DRM_INT_ACK_INVALID_CLIENT1_MASK | \
      MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT3_MASK | \
      MP0_SMN_DRM_INT_ACK_INVALID_CLIENT3_MASK | \
      MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT4_MASK | \
      MP0_SMN_DRM_INT_ACK_INVALID_CLIENT4_MASK)

#define MP0_SMN_DRM_INT_ACK_DEFAULT    0x00000000

#define MP0_SMN_DRM_INT_ACK_GET_DH1_DONE(mp0_smn_drm_int_ack) \
      ((mp0_smn_drm_int_ack & MP0_SMN_DRM_INT_ACK_DH1_DONE_MASK) >> MP0_SMN_DRM_INT_ACK_DH1_DONE_SHIFT)
#define MP0_SMN_DRM_INT_ACK_GET_DH2_DONE(mp0_smn_drm_int_ack) \
      ((mp0_smn_drm_int_ack & MP0_SMN_DRM_INT_ACK_DH2_DONE_MASK) >> MP0_SMN_DRM_INT_ACK_DH2_DONE_SHIFT)
#define MP0_SMN_DRM_INT_ACK_GET_HFS_DONE(mp0_smn_drm_int_ack) \
      ((mp0_smn_drm_int_ack & MP0_SMN_DRM_INT_ACK_HFS_DONE_MASK) >> MP0_SMN_DRM_INT_ACK_HFS_DONE_SHIFT)
#define MP0_SMN_DRM_INT_ACK_GET_SIG_DONE(mp0_smn_drm_int_ack) \
      ((mp0_smn_drm_int_ack & MP0_SMN_DRM_INT_ACK_SIG_DONE_MASK) >> MP0_SMN_DRM_INT_ACK_SIG_DONE_SHIFT)
#define MP0_SMN_DRM_INT_ACK_GET_SIG_VALID(mp0_smn_drm_int_ack) \
      ((mp0_smn_drm_int_ack & MP0_SMN_DRM_INT_ACK_SIG_VALID_MASK) >> MP0_SMN_DRM_INT_ACK_SIG_VALID_SHIFT)
#define MP0_SMN_DRM_INT_ACK_GET_TIMEOUT_CLIENT2(mp0_smn_drm_int_ack) \
      ((mp0_smn_drm_int_ack & MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT2_MASK) >> MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT2_SHIFT)
#define MP0_SMN_DRM_INT_ACK_GET_TIMEOUT_CLIENT0(mp0_smn_drm_int_ack) \
      ((mp0_smn_drm_int_ack & MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT0_MASK) >> MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT0_SHIFT)
#define MP0_SMN_DRM_INT_ACK_GET_TIMEOUT_CLIENT1(mp0_smn_drm_int_ack) \
      ((mp0_smn_drm_int_ack & MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT1_MASK) >> MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT1_SHIFT)
#define MP0_SMN_DRM_INT_ACK_GET_INVALID_CLIENT2(mp0_smn_drm_int_ack) \
      ((mp0_smn_drm_int_ack & MP0_SMN_DRM_INT_ACK_INVALID_CLIENT2_MASK) >> MP0_SMN_DRM_INT_ACK_INVALID_CLIENT2_SHIFT)
#define MP0_SMN_DRM_INT_ACK_GET_INVALID_CLIENT0(mp0_smn_drm_int_ack) \
      ((mp0_smn_drm_int_ack & MP0_SMN_DRM_INT_ACK_INVALID_CLIENT0_MASK) >> MP0_SMN_DRM_INT_ACK_INVALID_CLIENT0_SHIFT)
#define MP0_SMN_DRM_INT_ACK_GET_INVALID_CLIENT1(mp0_smn_drm_int_ack) \
      ((mp0_smn_drm_int_ack & MP0_SMN_DRM_INT_ACK_INVALID_CLIENT1_MASK) >> MP0_SMN_DRM_INT_ACK_INVALID_CLIENT1_SHIFT)
#define MP0_SMN_DRM_INT_ACK_GET_TIMEOUT_CLIENT3(mp0_smn_drm_int_ack) \
      ((mp0_smn_drm_int_ack & MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT3_MASK) >> MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT3_SHIFT)
#define MP0_SMN_DRM_INT_ACK_GET_INVALID_CLIENT3(mp0_smn_drm_int_ack) \
      ((mp0_smn_drm_int_ack & MP0_SMN_DRM_INT_ACK_INVALID_CLIENT3_MASK) >> MP0_SMN_DRM_INT_ACK_INVALID_CLIENT3_SHIFT)
#define MP0_SMN_DRM_INT_ACK_GET_TIMEOUT_CLIENT4(mp0_smn_drm_int_ack) \
      ((mp0_smn_drm_int_ack & MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT4_MASK) >> MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT4_SHIFT)
#define MP0_SMN_DRM_INT_ACK_GET_INVALID_CLIENT4(mp0_smn_drm_int_ack) \
      ((mp0_smn_drm_int_ack & MP0_SMN_DRM_INT_ACK_INVALID_CLIENT4_MASK) >> MP0_SMN_DRM_INT_ACK_INVALID_CLIENT4_SHIFT)

#define MP0_SMN_DRM_INT_ACK_SET_DH1_DONE(mp0_smn_drm_int_ack_reg, dh1_done) \
      mp0_smn_drm_int_ack_reg = (mp0_smn_drm_int_ack_reg & ~MP0_SMN_DRM_INT_ACK_DH1_DONE_MASK) | (dh1_done << MP0_SMN_DRM_INT_ACK_DH1_DONE_SHIFT)
#define MP0_SMN_DRM_INT_ACK_SET_DH2_DONE(mp0_smn_drm_int_ack_reg, dh2_done) \
      mp0_smn_drm_int_ack_reg = (mp0_smn_drm_int_ack_reg & ~MP0_SMN_DRM_INT_ACK_DH2_DONE_MASK) | (dh2_done << MP0_SMN_DRM_INT_ACK_DH2_DONE_SHIFT)
#define MP0_SMN_DRM_INT_ACK_SET_HFS_DONE(mp0_smn_drm_int_ack_reg, hfs_done) \
      mp0_smn_drm_int_ack_reg = (mp0_smn_drm_int_ack_reg & ~MP0_SMN_DRM_INT_ACK_HFS_DONE_MASK) | (hfs_done << MP0_SMN_DRM_INT_ACK_HFS_DONE_SHIFT)
#define MP0_SMN_DRM_INT_ACK_SET_SIG_DONE(mp0_smn_drm_int_ack_reg, sig_done) \
      mp0_smn_drm_int_ack_reg = (mp0_smn_drm_int_ack_reg & ~MP0_SMN_DRM_INT_ACK_SIG_DONE_MASK) | (sig_done << MP0_SMN_DRM_INT_ACK_SIG_DONE_SHIFT)
#define MP0_SMN_DRM_INT_ACK_SET_SIG_VALID(mp0_smn_drm_int_ack_reg, sig_valid) \
      mp0_smn_drm_int_ack_reg = (mp0_smn_drm_int_ack_reg & ~MP0_SMN_DRM_INT_ACK_SIG_VALID_MASK) | (sig_valid << MP0_SMN_DRM_INT_ACK_SIG_VALID_SHIFT)
#define MP0_SMN_DRM_INT_ACK_SET_TIMEOUT_CLIENT2(mp0_smn_drm_int_ack_reg, timeout_client2) \
      mp0_smn_drm_int_ack_reg = (mp0_smn_drm_int_ack_reg & ~MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT2_MASK) | (timeout_client2 << MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT2_SHIFT)
#define MP0_SMN_DRM_INT_ACK_SET_TIMEOUT_CLIENT0(mp0_smn_drm_int_ack_reg, timeout_client0) \
      mp0_smn_drm_int_ack_reg = (mp0_smn_drm_int_ack_reg & ~MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT0_MASK) | (timeout_client0 << MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT0_SHIFT)
#define MP0_SMN_DRM_INT_ACK_SET_TIMEOUT_CLIENT1(mp0_smn_drm_int_ack_reg, timeout_client1) \
      mp0_smn_drm_int_ack_reg = (mp0_smn_drm_int_ack_reg & ~MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT1_MASK) | (timeout_client1 << MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT1_SHIFT)
#define MP0_SMN_DRM_INT_ACK_SET_INVALID_CLIENT2(mp0_smn_drm_int_ack_reg, invalid_client2) \
      mp0_smn_drm_int_ack_reg = (mp0_smn_drm_int_ack_reg & ~MP0_SMN_DRM_INT_ACK_INVALID_CLIENT2_MASK) | (invalid_client2 << MP0_SMN_DRM_INT_ACK_INVALID_CLIENT2_SHIFT)
#define MP0_SMN_DRM_INT_ACK_SET_INVALID_CLIENT0(mp0_smn_drm_int_ack_reg, invalid_client0) \
      mp0_smn_drm_int_ack_reg = (mp0_smn_drm_int_ack_reg & ~MP0_SMN_DRM_INT_ACK_INVALID_CLIENT0_MASK) | (invalid_client0 << MP0_SMN_DRM_INT_ACK_INVALID_CLIENT0_SHIFT)
#define MP0_SMN_DRM_INT_ACK_SET_INVALID_CLIENT1(mp0_smn_drm_int_ack_reg, invalid_client1) \
      mp0_smn_drm_int_ack_reg = (mp0_smn_drm_int_ack_reg & ~MP0_SMN_DRM_INT_ACK_INVALID_CLIENT1_MASK) | (invalid_client1 << MP0_SMN_DRM_INT_ACK_INVALID_CLIENT1_SHIFT)
#define MP0_SMN_DRM_INT_ACK_SET_TIMEOUT_CLIENT3(mp0_smn_drm_int_ack_reg, timeout_client3) \
      mp0_smn_drm_int_ack_reg = (mp0_smn_drm_int_ack_reg & ~MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT3_MASK) | (timeout_client3 << MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT3_SHIFT)
#define MP0_SMN_DRM_INT_ACK_SET_INVALID_CLIENT3(mp0_smn_drm_int_ack_reg, invalid_client3) \
      mp0_smn_drm_int_ack_reg = (mp0_smn_drm_int_ack_reg & ~MP0_SMN_DRM_INT_ACK_INVALID_CLIENT3_MASK) | (invalid_client3 << MP0_SMN_DRM_INT_ACK_INVALID_CLIENT3_SHIFT)
#define MP0_SMN_DRM_INT_ACK_SET_TIMEOUT_CLIENT4(mp0_smn_drm_int_ack_reg, timeout_client4) \
      mp0_smn_drm_int_ack_reg = (mp0_smn_drm_int_ack_reg & ~MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT4_MASK) | (timeout_client4 << MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT4_SHIFT)
#define MP0_SMN_DRM_INT_ACK_SET_INVALID_CLIENT4(mp0_smn_drm_int_ack_reg, invalid_client4) \
      mp0_smn_drm_int_ack_reg = (mp0_smn_drm_int_ack_reg & ~MP0_SMN_DRM_INT_ACK_INVALID_CLIENT4_MASK) | (invalid_client4 << MP0_SMN_DRM_INT_ACK_INVALID_CLIENT4_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_int_ack_t {
            unsigned int dh1_done                       : MP0_SMN_DRM_INT_ACK_DH1_DONE_SIZE;
            unsigned int dh2_done                       : MP0_SMN_DRM_INT_ACK_DH2_DONE_SIZE;
            unsigned int hfs_done                       : MP0_SMN_DRM_INT_ACK_HFS_DONE_SIZE;
            unsigned int sig_done                       : MP0_SMN_DRM_INT_ACK_SIG_DONE_SIZE;
            unsigned int sig_valid                      : MP0_SMN_DRM_INT_ACK_SIG_VALID_SIZE;
            unsigned int timeout_client2                : MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT2_SIZE;
            unsigned int timeout_client0                : MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT0_SIZE;
            unsigned int timeout_client1                : MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT1_SIZE;
            unsigned int invalid_client2                : MP0_SMN_DRM_INT_ACK_INVALID_CLIENT2_SIZE;
            unsigned int invalid_client0                : MP0_SMN_DRM_INT_ACK_INVALID_CLIENT0_SIZE;
            unsigned int invalid_client1                : MP0_SMN_DRM_INT_ACK_INVALID_CLIENT1_SIZE;
            unsigned int timeout_client3                : MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT3_SIZE;
            unsigned int invalid_client3                : MP0_SMN_DRM_INT_ACK_INVALID_CLIENT3_SIZE;
            unsigned int timeout_client4                : MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT4_SIZE;
            unsigned int invalid_client4                : MP0_SMN_DRM_INT_ACK_INVALID_CLIENT4_SIZE;
            unsigned int                                : 17;
      } mp0_smn_drm_int_ack_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_int_ack_t {
            unsigned int                                : 17;
            unsigned int invalid_client4                : MP0_SMN_DRM_INT_ACK_INVALID_CLIENT4_SIZE;
            unsigned int timeout_client4                : MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT4_SIZE;
            unsigned int invalid_client3                : MP0_SMN_DRM_INT_ACK_INVALID_CLIENT3_SIZE;
            unsigned int timeout_client3                : MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT3_SIZE;
            unsigned int invalid_client1                : MP0_SMN_DRM_INT_ACK_INVALID_CLIENT1_SIZE;
            unsigned int invalid_client0                : MP0_SMN_DRM_INT_ACK_INVALID_CLIENT0_SIZE;
            unsigned int invalid_client2                : MP0_SMN_DRM_INT_ACK_INVALID_CLIENT2_SIZE;
            unsigned int timeout_client1                : MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT1_SIZE;
            unsigned int timeout_client0                : MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT0_SIZE;
            unsigned int timeout_client2                : MP0_SMN_DRM_INT_ACK_TIMEOUT_CLIENT2_SIZE;
            unsigned int sig_valid                      : MP0_SMN_DRM_INT_ACK_SIG_VALID_SIZE;
            unsigned int sig_done                       : MP0_SMN_DRM_INT_ACK_SIG_DONE_SIZE;
            unsigned int hfs_done                       : MP0_SMN_DRM_INT_ACK_HFS_DONE_SIZE;
            unsigned int dh2_done                       : MP0_SMN_DRM_INT_ACK_DH2_DONE_SIZE;
            unsigned int dh1_done                       : MP0_SMN_DRM_INT_ACK_DH1_DONE_SIZE;
      } mp0_smn_drm_int_ack_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_int_ack_t f;
} mp0_smn_drm_int_ack_u;


/*
 * MP0_SMN_DRM_STATUS struct
 */

#define MP0_SMN_DRM_STATUS_REG_SIZE         32
#define MP0_SMN_DRM_STATUS_DRM_BUSY_SIZE  1
#define MP0_SMN_DRM_STATUS_TRNG_BUSY_SIZE  1
#define MP0_SMN_DRM_STATUS_CLIENT1_BUSY_SIZE  1
#define MP0_SMN_DRM_STATUS_CLIENT2_BUSY_SIZE  1
#define MP0_SMN_DRM_STATUS_CLIENT0_BUSY_SIZE  1
#define MP0_SMN_DRM_STATUS_SIG_BUSY_SIZE  1
#define MP0_SMN_DRM_STATUS_HFS_BUSY_SIZE  1
#define MP0_SMN_DRM_STATUS_DH_BUSY2_SIZE  1
#define MP0_SMN_DRM_STATUS_DH_BUSY1_SIZE  1
#define MP0_SMN_DRM_STATUS_CLIENT1_PARSE_BUSY_SIZE  1
#define MP0_SMN_DRM_STATUS_CLIENT2_PARSE_BUSY_SIZE  1
#define MP0_SMN_DRM_STATUS_CLIENT0_PARSE_BUSY_SIZE  1
#define MP0_SMN_DRM_STATUS_SIG_RD_BUSY_SIZE  1
#define MP0_SMN_DRM_STATUS_HFS_DONE_SIZE  1
#define MP0_SMN_DRM_STATUS_DH_DONE_SIZE  1
#define MP0_SMN_DRM_STATUS_DRM_INIT_SIZE  1
#define MP0_SMN_DRM_STATUS_DH_ACTIVE_SIZE  1
#define MP0_SMN_DRM_STATUS_HFS_ACTIVE_SIZE  1
#define MP0_SMN_DRM_STATUS_SIG_ACTIVE_SIZE  1
#define MP0_SMN_DRM_STATUS_HFS_PASS_SIZE  1
#define MP0_SMN_DRM_STATUS_AUTH_STATE_SIZE  3
#define MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_1_SIZE  1
#define MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_2_SIZE  1
#define MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_3_SIZE  1
#define MP0_SMN_DRM_STATUS_CLIENT3_BUSY_SIZE  1

#define MP0_SMN_DRM_STATUS_DRM_BUSY_SHIFT  0
#define MP0_SMN_DRM_STATUS_TRNG_BUSY_SHIFT  1
#define MP0_SMN_DRM_STATUS_CLIENT1_BUSY_SHIFT  2
#define MP0_SMN_DRM_STATUS_CLIENT2_BUSY_SHIFT  3
#define MP0_SMN_DRM_STATUS_CLIENT0_BUSY_SHIFT  4
#define MP0_SMN_DRM_STATUS_SIG_BUSY_SHIFT  5
#define MP0_SMN_DRM_STATUS_HFS_BUSY_SHIFT  6
#define MP0_SMN_DRM_STATUS_DH_BUSY2_SHIFT  7
#define MP0_SMN_DRM_STATUS_DH_BUSY1_SHIFT  8
#define MP0_SMN_DRM_STATUS_CLIENT1_PARSE_BUSY_SHIFT  9
#define MP0_SMN_DRM_STATUS_CLIENT2_PARSE_BUSY_SHIFT  10
#define MP0_SMN_DRM_STATUS_CLIENT0_PARSE_BUSY_SHIFT  11
#define MP0_SMN_DRM_STATUS_SIG_RD_BUSY_SHIFT  12
#define MP0_SMN_DRM_STATUS_HFS_DONE_SHIFT  16
#define MP0_SMN_DRM_STATUS_DH_DONE_SHIFT  17
#define MP0_SMN_DRM_STATUS_DRM_INIT_SHIFT  18
#define MP0_SMN_DRM_STATUS_DH_ACTIVE_SHIFT  20
#define MP0_SMN_DRM_STATUS_HFS_ACTIVE_SHIFT  21
#define MP0_SMN_DRM_STATUS_SIG_ACTIVE_SHIFT  22
#define MP0_SMN_DRM_STATUS_HFS_PASS_SHIFT  24
#define MP0_SMN_DRM_STATUS_AUTH_STATE_SHIFT  25
#define MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_1_SHIFT  28
#define MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_2_SHIFT  29
#define MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_3_SHIFT  30
#define MP0_SMN_DRM_STATUS_CLIENT3_BUSY_SHIFT  31

#define MP0_SMN_DRM_STATUS_DRM_BUSY_MASK  0x00000001
#define MP0_SMN_DRM_STATUS_TRNG_BUSY_MASK  0x00000002
#define MP0_SMN_DRM_STATUS_CLIENT1_BUSY_MASK  0x00000004
#define MP0_SMN_DRM_STATUS_CLIENT2_BUSY_MASK  0x00000008
#define MP0_SMN_DRM_STATUS_CLIENT0_BUSY_MASK  0x00000010
#define MP0_SMN_DRM_STATUS_SIG_BUSY_MASK  0x00000020
#define MP0_SMN_DRM_STATUS_HFS_BUSY_MASK  0x00000040
#define MP0_SMN_DRM_STATUS_DH_BUSY2_MASK  0x00000080
#define MP0_SMN_DRM_STATUS_DH_BUSY1_MASK  0x00000100
#define MP0_SMN_DRM_STATUS_CLIENT1_PARSE_BUSY_MASK  0x00000200
#define MP0_SMN_DRM_STATUS_CLIENT2_PARSE_BUSY_MASK  0x00000400
#define MP0_SMN_DRM_STATUS_CLIENT0_PARSE_BUSY_MASK  0x00000800
#define MP0_SMN_DRM_STATUS_SIG_RD_BUSY_MASK  0x00001000
#define MP0_SMN_DRM_STATUS_HFS_DONE_MASK  0x00010000
#define MP0_SMN_DRM_STATUS_DH_DONE_MASK  0x00020000
#define MP0_SMN_DRM_STATUS_DRM_INIT_MASK  0x00040000
#define MP0_SMN_DRM_STATUS_DH_ACTIVE_MASK  0x00100000
#define MP0_SMN_DRM_STATUS_HFS_ACTIVE_MASK  0x00200000
#define MP0_SMN_DRM_STATUS_SIG_ACTIVE_MASK  0x00400000
#define MP0_SMN_DRM_STATUS_HFS_PASS_MASK  0x01000000
#define MP0_SMN_DRM_STATUS_AUTH_STATE_MASK  0x0e000000
#define MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_1_MASK  0x10000000
#define MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_2_MASK  0x20000000
#define MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_3_MASK  0x40000000
#define MP0_SMN_DRM_STATUS_CLIENT3_BUSY_MASK  0x80000000

#define MP0_SMN_DRM_STATUS_MASK \
      (MP0_SMN_DRM_STATUS_DRM_BUSY_MASK | \
      MP0_SMN_DRM_STATUS_TRNG_BUSY_MASK | \
      MP0_SMN_DRM_STATUS_CLIENT1_BUSY_MASK | \
      MP0_SMN_DRM_STATUS_CLIENT2_BUSY_MASK | \
      MP0_SMN_DRM_STATUS_CLIENT0_BUSY_MASK | \
      MP0_SMN_DRM_STATUS_SIG_BUSY_MASK | \
      MP0_SMN_DRM_STATUS_HFS_BUSY_MASK | \
      MP0_SMN_DRM_STATUS_DH_BUSY2_MASK | \
      MP0_SMN_DRM_STATUS_DH_BUSY1_MASK | \
      MP0_SMN_DRM_STATUS_CLIENT1_PARSE_BUSY_MASK | \
      MP0_SMN_DRM_STATUS_CLIENT2_PARSE_BUSY_MASK | \
      MP0_SMN_DRM_STATUS_CLIENT0_PARSE_BUSY_MASK | \
      MP0_SMN_DRM_STATUS_SIG_RD_BUSY_MASK | \
      MP0_SMN_DRM_STATUS_HFS_DONE_MASK | \
      MP0_SMN_DRM_STATUS_DH_DONE_MASK | \
      MP0_SMN_DRM_STATUS_DRM_INIT_MASK | \
      MP0_SMN_DRM_STATUS_DH_ACTIVE_MASK | \
      MP0_SMN_DRM_STATUS_HFS_ACTIVE_MASK | \
      MP0_SMN_DRM_STATUS_SIG_ACTIVE_MASK | \
      MP0_SMN_DRM_STATUS_HFS_PASS_MASK | \
      MP0_SMN_DRM_STATUS_AUTH_STATE_MASK | \
      MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_1_MASK | \
      MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_2_MASK | \
      MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_3_MASK | \
      MP0_SMN_DRM_STATUS_CLIENT3_BUSY_MASK)

#define MP0_SMN_DRM_STATUS_DEFAULT     0x00000000

#define MP0_SMN_DRM_STATUS_GET_DRM_BUSY(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_DRM_BUSY_MASK) >> MP0_SMN_DRM_STATUS_DRM_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_TRNG_BUSY(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_TRNG_BUSY_MASK) >> MP0_SMN_DRM_STATUS_TRNG_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_CLIENT1_BUSY(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_CLIENT1_BUSY_MASK) >> MP0_SMN_DRM_STATUS_CLIENT1_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_CLIENT2_BUSY(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_CLIENT2_BUSY_MASK) >> MP0_SMN_DRM_STATUS_CLIENT2_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_CLIENT0_BUSY(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_CLIENT0_BUSY_MASK) >> MP0_SMN_DRM_STATUS_CLIENT0_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_SIG_BUSY(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_SIG_BUSY_MASK) >> MP0_SMN_DRM_STATUS_SIG_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_HFS_BUSY(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_HFS_BUSY_MASK) >> MP0_SMN_DRM_STATUS_HFS_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_DH_BUSY2(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_DH_BUSY2_MASK) >> MP0_SMN_DRM_STATUS_DH_BUSY2_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_DH_BUSY1(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_DH_BUSY1_MASK) >> MP0_SMN_DRM_STATUS_DH_BUSY1_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_CLIENT1_PARSE_BUSY(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_CLIENT1_PARSE_BUSY_MASK) >> MP0_SMN_DRM_STATUS_CLIENT1_PARSE_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_CLIENT2_PARSE_BUSY(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_CLIENT2_PARSE_BUSY_MASK) >> MP0_SMN_DRM_STATUS_CLIENT2_PARSE_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_CLIENT0_PARSE_BUSY(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_CLIENT0_PARSE_BUSY_MASK) >> MP0_SMN_DRM_STATUS_CLIENT0_PARSE_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_SIG_RD_BUSY(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_SIG_RD_BUSY_MASK) >> MP0_SMN_DRM_STATUS_SIG_RD_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_HFS_DONE(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_HFS_DONE_MASK) >> MP0_SMN_DRM_STATUS_HFS_DONE_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_DH_DONE(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_DH_DONE_MASK) >> MP0_SMN_DRM_STATUS_DH_DONE_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_DRM_INIT(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_DRM_INIT_MASK) >> MP0_SMN_DRM_STATUS_DRM_INIT_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_DH_ACTIVE(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_DH_ACTIVE_MASK) >> MP0_SMN_DRM_STATUS_DH_ACTIVE_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_HFS_ACTIVE(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_HFS_ACTIVE_MASK) >> MP0_SMN_DRM_STATUS_HFS_ACTIVE_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_SIG_ACTIVE(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_SIG_ACTIVE_MASK) >> MP0_SMN_DRM_STATUS_SIG_ACTIVE_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_HFS_PASS(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_HFS_PASS_MASK) >> MP0_SMN_DRM_STATUS_HFS_PASS_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_AUTH_STATE(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_AUTH_STATE_MASK) >> MP0_SMN_DRM_STATUS_AUTH_STATE_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_DRM_INIT_SESSION_1(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_1_MASK) >> MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_1_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_DRM_INIT_SESSION_2(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_2_MASK) >> MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_2_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_DRM_INIT_SESSION_3(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_3_MASK) >> MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_3_SHIFT)
#define MP0_SMN_DRM_STATUS_GET_CLIENT3_BUSY(mp0_smn_drm_status) \
      ((mp0_smn_drm_status & MP0_SMN_DRM_STATUS_CLIENT3_BUSY_MASK) >> MP0_SMN_DRM_STATUS_CLIENT3_BUSY_SHIFT)

#define MP0_SMN_DRM_STATUS_SET_DRM_BUSY(mp0_smn_drm_status_reg, drm_busy) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_DRM_BUSY_MASK) | (drm_busy << MP0_SMN_DRM_STATUS_DRM_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_TRNG_BUSY(mp0_smn_drm_status_reg, trng_busy) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_TRNG_BUSY_MASK) | (trng_busy << MP0_SMN_DRM_STATUS_TRNG_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_CLIENT1_BUSY(mp0_smn_drm_status_reg, client1_busy) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_CLIENT1_BUSY_MASK) | (client1_busy << MP0_SMN_DRM_STATUS_CLIENT1_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_CLIENT2_BUSY(mp0_smn_drm_status_reg, client2_busy) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_CLIENT2_BUSY_MASK) | (client2_busy << MP0_SMN_DRM_STATUS_CLIENT2_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_CLIENT0_BUSY(mp0_smn_drm_status_reg, client0_busy) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_CLIENT0_BUSY_MASK) | (client0_busy << MP0_SMN_DRM_STATUS_CLIENT0_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_SIG_BUSY(mp0_smn_drm_status_reg, sig_busy) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_SIG_BUSY_MASK) | (sig_busy << MP0_SMN_DRM_STATUS_SIG_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_HFS_BUSY(mp0_smn_drm_status_reg, hfs_busy) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_HFS_BUSY_MASK) | (hfs_busy << MP0_SMN_DRM_STATUS_HFS_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_DH_BUSY2(mp0_smn_drm_status_reg, dh_busy2) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_DH_BUSY2_MASK) | (dh_busy2 << MP0_SMN_DRM_STATUS_DH_BUSY2_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_DH_BUSY1(mp0_smn_drm_status_reg, dh_busy1) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_DH_BUSY1_MASK) | (dh_busy1 << MP0_SMN_DRM_STATUS_DH_BUSY1_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_CLIENT1_PARSE_BUSY(mp0_smn_drm_status_reg, client1_parse_busy) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_CLIENT1_PARSE_BUSY_MASK) | (client1_parse_busy << MP0_SMN_DRM_STATUS_CLIENT1_PARSE_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_CLIENT2_PARSE_BUSY(mp0_smn_drm_status_reg, client2_parse_busy) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_CLIENT2_PARSE_BUSY_MASK) | (client2_parse_busy << MP0_SMN_DRM_STATUS_CLIENT2_PARSE_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_CLIENT0_PARSE_BUSY(mp0_smn_drm_status_reg, client0_parse_busy) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_CLIENT0_PARSE_BUSY_MASK) | (client0_parse_busy << MP0_SMN_DRM_STATUS_CLIENT0_PARSE_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_SIG_RD_BUSY(mp0_smn_drm_status_reg, sig_rd_busy) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_SIG_RD_BUSY_MASK) | (sig_rd_busy << MP0_SMN_DRM_STATUS_SIG_RD_BUSY_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_HFS_DONE(mp0_smn_drm_status_reg, hfs_done) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_HFS_DONE_MASK) | (hfs_done << MP0_SMN_DRM_STATUS_HFS_DONE_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_DH_DONE(mp0_smn_drm_status_reg, dh_done) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_DH_DONE_MASK) | (dh_done << MP0_SMN_DRM_STATUS_DH_DONE_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_DRM_INIT(mp0_smn_drm_status_reg, drm_init) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_DRM_INIT_MASK) | (drm_init << MP0_SMN_DRM_STATUS_DRM_INIT_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_DH_ACTIVE(mp0_smn_drm_status_reg, dh_active) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_DH_ACTIVE_MASK) | (dh_active << MP0_SMN_DRM_STATUS_DH_ACTIVE_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_HFS_ACTIVE(mp0_smn_drm_status_reg, hfs_active) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_HFS_ACTIVE_MASK) | (hfs_active << MP0_SMN_DRM_STATUS_HFS_ACTIVE_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_SIG_ACTIVE(mp0_smn_drm_status_reg, sig_active) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_SIG_ACTIVE_MASK) | (sig_active << MP0_SMN_DRM_STATUS_SIG_ACTIVE_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_HFS_PASS(mp0_smn_drm_status_reg, hfs_pass) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_HFS_PASS_MASK) | (hfs_pass << MP0_SMN_DRM_STATUS_HFS_PASS_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_AUTH_STATE(mp0_smn_drm_status_reg, auth_state) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_AUTH_STATE_MASK) | (auth_state << MP0_SMN_DRM_STATUS_AUTH_STATE_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_DRM_INIT_SESSION_1(mp0_smn_drm_status_reg, drm_init_session_1) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_1_MASK) | (drm_init_session_1 << MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_1_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_DRM_INIT_SESSION_2(mp0_smn_drm_status_reg, drm_init_session_2) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_2_MASK) | (drm_init_session_2 << MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_2_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_DRM_INIT_SESSION_3(mp0_smn_drm_status_reg, drm_init_session_3) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_3_MASK) | (drm_init_session_3 << MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_3_SHIFT)
#define MP0_SMN_DRM_STATUS_SET_CLIENT3_BUSY(mp0_smn_drm_status_reg, client3_busy) \
      mp0_smn_drm_status_reg = (mp0_smn_drm_status_reg & ~MP0_SMN_DRM_STATUS_CLIENT3_BUSY_MASK) | (client3_busy << MP0_SMN_DRM_STATUS_CLIENT3_BUSY_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_status_t {
            unsigned int drm_busy                       : MP0_SMN_DRM_STATUS_DRM_BUSY_SIZE;
            unsigned int trng_busy                      : MP0_SMN_DRM_STATUS_TRNG_BUSY_SIZE;
            unsigned int client1_busy                   : MP0_SMN_DRM_STATUS_CLIENT1_BUSY_SIZE;
            unsigned int client2_busy                   : MP0_SMN_DRM_STATUS_CLIENT2_BUSY_SIZE;
            unsigned int client0_busy                   : MP0_SMN_DRM_STATUS_CLIENT0_BUSY_SIZE;
            unsigned int sig_busy                       : MP0_SMN_DRM_STATUS_SIG_BUSY_SIZE;
            unsigned int hfs_busy                       : MP0_SMN_DRM_STATUS_HFS_BUSY_SIZE;
            unsigned int dh_busy2                       : MP0_SMN_DRM_STATUS_DH_BUSY2_SIZE;
            unsigned int dh_busy1                       : MP0_SMN_DRM_STATUS_DH_BUSY1_SIZE;
            unsigned int client1_parse_busy             : MP0_SMN_DRM_STATUS_CLIENT1_PARSE_BUSY_SIZE;
            unsigned int client2_parse_busy             : MP0_SMN_DRM_STATUS_CLIENT2_PARSE_BUSY_SIZE;
            unsigned int client0_parse_busy             : MP0_SMN_DRM_STATUS_CLIENT0_PARSE_BUSY_SIZE;
            unsigned int sig_rd_busy                    : MP0_SMN_DRM_STATUS_SIG_RD_BUSY_SIZE;
            unsigned int                                : 3;
            unsigned int hfs_done                       : MP0_SMN_DRM_STATUS_HFS_DONE_SIZE;
            unsigned int dh_done                        : MP0_SMN_DRM_STATUS_DH_DONE_SIZE;
            unsigned int drm_init                       : MP0_SMN_DRM_STATUS_DRM_INIT_SIZE;
            unsigned int                                : 1;
            unsigned int dh_active                      : MP0_SMN_DRM_STATUS_DH_ACTIVE_SIZE;
            unsigned int hfs_active                     : MP0_SMN_DRM_STATUS_HFS_ACTIVE_SIZE;
            unsigned int sig_active                     : MP0_SMN_DRM_STATUS_SIG_ACTIVE_SIZE;
            unsigned int                                : 1;
            unsigned int hfs_pass                       : MP0_SMN_DRM_STATUS_HFS_PASS_SIZE;
            unsigned int auth_state                     : MP0_SMN_DRM_STATUS_AUTH_STATE_SIZE;
            unsigned int drm_init_session_1             : MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_1_SIZE;
            unsigned int drm_init_session_2             : MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_2_SIZE;
            unsigned int drm_init_session_3             : MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_3_SIZE;
            unsigned int client3_busy                   : MP0_SMN_DRM_STATUS_CLIENT3_BUSY_SIZE;
      } mp0_smn_drm_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_status_t {
            unsigned int client3_busy                   : MP0_SMN_DRM_STATUS_CLIENT3_BUSY_SIZE;
            unsigned int drm_init_session_3             : MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_3_SIZE;
            unsigned int drm_init_session_2             : MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_2_SIZE;
            unsigned int drm_init_session_1             : MP0_SMN_DRM_STATUS_DRM_INIT_SESSION_1_SIZE;
            unsigned int auth_state                     : MP0_SMN_DRM_STATUS_AUTH_STATE_SIZE;
            unsigned int hfs_pass                       : MP0_SMN_DRM_STATUS_HFS_PASS_SIZE;
            unsigned int                                : 1;
            unsigned int sig_active                     : MP0_SMN_DRM_STATUS_SIG_ACTIVE_SIZE;
            unsigned int hfs_active                     : MP0_SMN_DRM_STATUS_HFS_ACTIVE_SIZE;
            unsigned int dh_active                      : MP0_SMN_DRM_STATUS_DH_ACTIVE_SIZE;
            unsigned int                                : 1;
            unsigned int drm_init                       : MP0_SMN_DRM_STATUS_DRM_INIT_SIZE;
            unsigned int dh_done                        : MP0_SMN_DRM_STATUS_DH_DONE_SIZE;
            unsigned int hfs_done                       : MP0_SMN_DRM_STATUS_HFS_DONE_SIZE;
            unsigned int                                : 3;
            unsigned int sig_rd_busy                    : MP0_SMN_DRM_STATUS_SIG_RD_BUSY_SIZE;
            unsigned int client0_parse_busy             : MP0_SMN_DRM_STATUS_CLIENT0_PARSE_BUSY_SIZE;
            unsigned int client2_parse_busy             : MP0_SMN_DRM_STATUS_CLIENT2_PARSE_BUSY_SIZE;
            unsigned int client1_parse_busy             : MP0_SMN_DRM_STATUS_CLIENT1_PARSE_BUSY_SIZE;
            unsigned int dh_busy1                       : MP0_SMN_DRM_STATUS_DH_BUSY1_SIZE;
            unsigned int dh_busy2                       : MP0_SMN_DRM_STATUS_DH_BUSY2_SIZE;
            unsigned int hfs_busy                       : MP0_SMN_DRM_STATUS_HFS_BUSY_SIZE;
            unsigned int sig_busy                       : MP0_SMN_DRM_STATUS_SIG_BUSY_SIZE;
            unsigned int client0_busy                   : MP0_SMN_DRM_STATUS_CLIENT0_BUSY_SIZE;
            unsigned int client2_busy                   : MP0_SMN_DRM_STATUS_CLIENT2_BUSY_SIZE;
            unsigned int client1_busy                   : MP0_SMN_DRM_STATUS_CLIENT1_BUSY_SIZE;
            unsigned int trng_busy                      : MP0_SMN_DRM_STATUS_TRNG_BUSY_SIZE;
            unsigned int drm_busy                       : MP0_SMN_DRM_STATUS_DRM_BUSY_SIZE;
      } mp0_smn_drm_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_status_t f;
} mp0_smn_drm_status_u;


/*
 * MP0_SMN_DRM_PROTO_ADDR struct
 */

#define MP0_SMN_DRM_PROTO_ADDR_REG_SIZE         32
#define MP0_SMN_DRM_PROTO_ADDR_ADDR_SIZE  12

#define MP0_SMN_DRM_PROTO_ADDR_ADDR_SHIFT  0

#define MP0_SMN_DRM_PROTO_ADDR_ADDR_MASK  0x00000fff

#define MP0_SMN_DRM_PROTO_ADDR_MASK \
      (MP0_SMN_DRM_PROTO_ADDR_ADDR_MASK)

#define MP0_SMN_DRM_PROTO_ADDR_DEFAULT 0x00000000

#define MP0_SMN_DRM_PROTO_ADDR_GET_ADDR(mp0_smn_drm_proto_addr) \
      ((mp0_smn_drm_proto_addr & MP0_SMN_DRM_PROTO_ADDR_ADDR_MASK) >> MP0_SMN_DRM_PROTO_ADDR_ADDR_SHIFT)

#define MP0_SMN_DRM_PROTO_ADDR_SET_ADDR(mp0_smn_drm_proto_addr_reg, addr) \
      mp0_smn_drm_proto_addr_reg = (mp0_smn_drm_proto_addr_reg & ~MP0_SMN_DRM_PROTO_ADDR_ADDR_MASK) | (addr << MP0_SMN_DRM_PROTO_ADDR_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_proto_addr_t {
            unsigned int addr                           : MP0_SMN_DRM_PROTO_ADDR_ADDR_SIZE;
            unsigned int                                : 20;
      } mp0_smn_drm_proto_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_proto_addr_t {
            unsigned int                                : 20;
            unsigned int addr                           : MP0_SMN_DRM_PROTO_ADDR_ADDR_SIZE;
      } mp0_smn_drm_proto_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_proto_addr_t f;
} mp0_smn_drm_proto_addr_u;


/*
 * MP0_SMN_DRM_PROTO_DATA struct
 */

#define MP0_SMN_DRM_PROTO_DATA_REG_SIZE         32
#define MP0_SMN_DRM_PROTO_DATA_DATA_SIZE  32

#define MP0_SMN_DRM_PROTO_DATA_DATA_SHIFT  0

#define MP0_SMN_DRM_PROTO_DATA_DATA_MASK  0xffffffff

#define MP0_SMN_DRM_PROTO_DATA_MASK \
      (MP0_SMN_DRM_PROTO_DATA_DATA_MASK)

#define MP0_SMN_DRM_PROTO_DATA_DEFAULT 0x00000000

#define MP0_SMN_DRM_PROTO_DATA_GET_DATA(mp0_smn_drm_proto_data) \
      ((mp0_smn_drm_proto_data & MP0_SMN_DRM_PROTO_DATA_DATA_MASK) >> MP0_SMN_DRM_PROTO_DATA_DATA_SHIFT)

#define MP0_SMN_DRM_PROTO_DATA_SET_DATA(mp0_smn_drm_proto_data_reg, data) \
      mp0_smn_drm_proto_data_reg = (mp0_smn_drm_proto_data_reg & ~MP0_SMN_DRM_PROTO_DATA_DATA_MASK) | (data << MP0_SMN_DRM_PROTO_DATA_DATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_proto_data_t {
            unsigned int data                           : MP0_SMN_DRM_PROTO_DATA_DATA_SIZE;
      } mp0_smn_drm_proto_data_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_proto_data_t {
            unsigned int data                           : MP0_SMN_DRM_PROTO_DATA_DATA_SIZE;
      } mp0_smn_drm_proto_data_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_proto_data_t f;
} mp0_smn_drm_proto_data_u;


/*
 * MP0_SMN_CGTT_DRM_CLK_CTRL0 struct
 */

#define MP0_SMN_CGTT_DRM_CLK_CTRL0_REG_SIZE         32
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_ON_DELAY_SIZE  4
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_OFF_HYSTERESIS_SIZE  8
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_DIV_ID_SIZE  3
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_0_SIZE  1
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_REG_SIZE  1
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE7_SIZE  1
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE6_SIZE  1
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE5_SIZE  1
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE4_SIZE  1
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE3_SIZE  1
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE2_SIZE  1
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE1_SIZE  1
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE0_SIZE  1

#define MP0_SMN_CGTT_DRM_CLK_CTRL0_ON_DELAY_SHIFT  0
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_OFF_HYSTERESIS_SHIFT  4
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_DIV_ID_SHIFT  12
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_0_SHIFT  21
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_REG_SHIFT  22
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE7_SHIFT  24
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE6_SHIFT  25
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE5_SHIFT  26
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE4_SHIFT  27
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE3_SHIFT  28
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE2_SHIFT  29
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE1_SHIFT  30
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE0_SHIFT  31

#define MP0_SMN_CGTT_DRM_CLK_CTRL0_ON_DELAY_MASK  0x0000000f
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_OFF_HYSTERESIS_MASK  0x00000ff0
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_DIV_ID_MASK  0x00007000
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_0_MASK  0x00200000
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_REG_MASK  0x00400000
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE7_MASK  0x01000000
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE6_MASK  0x02000000
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE5_MASK  0x04000000
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE4_MASK  0x08000000
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE3_MASK  0x10000000
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE2_MASK  0x20000000
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE1_MASK  0x40000000
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE0_MASK  0x80000000

#define MP0_SMN_CGTT_DRM_CLK_CTRL0_MASK \
      (MP0_SMN_CGTT_DRM_CLK_CTRL0_ON_DELAY_MASK | \
      MP0_SMN_CGTT_DRM_CLK_CTRL0_OFF_HYSTERESIS_MASK | \
      MP0_SMN_CGTT_DRM_CLK_CTRL0_DIV_ID_MASK | \
      MP0_SMN_CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_0_MASK | \
      MP0_SMN_CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_REG_MASK | \
      MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE7_MASK | \
      MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE6_MASK | \
      MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE5_MASK | \
      MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE4_MASK | \
      MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE3_MASK | \
      MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE2_MASK | \
      MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE1_MASK | \
      MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE0_MASK)

#define MP0_SMN_CGTT_DRM_CLK_CTRL0_DEFAULT 0x00600100

#define MP0_SMN_CGTT_DRM_CLK_CTRL0_GET_ON_DELAY(mp0_smn_cgtt_drm_clk_ctrl0) \
      ((mp0_smn_cgtt_drm_clk_ctrl0 & MP0_SMN_CGTT_DRM_CLK_CTRL0_ON_DELAY_MASK) >> MP0_SMN_CGTT_DRM_CLK_CTRL0_ON_DELAY_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_GET_OFF_HYSTERESIS(mp0_smn_cgtt_drm_clk_ctrl0) \
      ((mp0_smn_cgtt_drm_clk_ctrl0 & MP0_SMN_CGTT_DRM_CLK_CTRL0_OFF_HYSTERESIS_MASK) >> MP0_SMN_CGTT_DRM_CLK_CTRL0_OFF_HYSTERESIS_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_GET_DIV_ID(mp0_smn_cgtt_drm_clk_ctrl0) \
      ((mp0_smn_cgtt_drm_clk_ctrl0 & MP0_SMN_CGTT_DRM_CLK_CTRL0_DIV_ID_MASK) >> MP0_SMN_CGTT_DRM_CLK_CTRL0_DIV_ID_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_GET_RAMP_DIS_CLK_0(mp0_smn_cgtt_drm_clk_ctrl0) \
      ((mp0_smn_cgtt_drm_clk_ctrl0 & MP0_SMN_CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_0_MASK) >> MP0_SMN_CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_0_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_GET_RAMP_DIS_CLK_REG(mp0_smn_cgtt_drm_clk_ctrl0) \
      ((mp0_smn_cgtt_drm_clk_ctrl0 & MP0_SMN_CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_REG_MASK) >> MP0_SMN_CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_REG_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_GET_SOFT_OVERRIDE7(mp0_smn_cgtt_drm_clk_ctrl0) \
      ((mp0_smn_cgtt_drm_clk_ctrl0 & MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE7_MASK) >> MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE7_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_GET_SOFT_OVERRIDE6(mp0_smn_cgtt_drm_clk_ctrl0) \
      ((mp0_smn_cgtt_drm_clk_ctrl0 & MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE6_MASK) >> MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE6_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_GET_SOFT_OVERRIDE5(mp0_smn_cgtt_drm_clk_ctrl0) \
      ((mp0_smn_cgtt_drm_clk_ctrl0 & MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE5_MASK) >> MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE5_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_GET_SOFT_OVERRIDE4(mp0_smn_cgtt_drm_clk_ctrl0) \
      ((mp0_smn_cgtt_drm_clk_ctrl0 & MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE4_MASK) >> MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE4_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_GET_SOFT_OVERRIDE3(mp0_smn_cgtt_drm_clk_ctrl0) \
      ((mp0_smn_cgtt_drm_clk_ctrl0 & MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE3_MASK) >> MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE3_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_GET_SOFT_OVERRIDE2(mp0_smn_cgtt_drm_clk_ctrl0) \
      ((mp0_smn_cgtt_drm_clk_ctrl0 & MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE2_MASK) >> MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE2_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_GET_SOFT_OVERRIDE1(mp0_smn_cgtt_drm_clk_ctrl0) \
      ((mp0_smn_cgtt_drm_clk_ctrl0 & MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE1_MASK) >> MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE1_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_GET_SOFT_OVERRIDE0(mp0_smn_cgtt_drm_clk_ctrl0) \
      ((mp0_smn_cgtt_drm_clk_ctrl0 & MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE0_MASK) >> MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE0_SHIFT)

#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SET_ON_DELAY(mp0_smn_cgtt_drm_clk_ctrl0_reg, on_delay) \
      mp0_smn_cgtt_drm_clk_ctrl0_reg = (mp0_smn_cgtt_drm_clk_ctrl0_reg & ~MP0_SMN_CGTT_DRM_CLK_CTRL0_ON_DELAY_MASK) | (on_delay << MP0_SMN_CGTT_DRM_CLK_CTRL0_ON_DELAY_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SET_OFF_HYSTERESIS(mp0_smn_cgtt_drm_clk_ctrl0_reg, off_hysteresis) \
      mp0_smn_cgtt_drm_clk_ctrl0_reg = (mp0_smn_cgtt_drm_clk_ctrl0_reg & ~MP0_SMN_CGTT_DRM_CLK_CTRL0_OFF_HYSTERESIS_MASK) | (off_hysteresis << MP0_SMN_CGTT_DRM_CLK_CTRL0_OFF_HYSTERESIS_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SET_DIV_ID(mp0_smn_cgtt_drm_clk_ctrl0_reg, div_id) \
      mp0_smn_cgtt_drm_clk_ctrl0_reg = (mp0_smn_cgtt_drm_clk_ctrl0_reg & ~MP0_SMN_CGTT_DRM_CLK_CTRL0_DIV_ID_MASK) | (div_id << MP0_SMN_CGTT_DRM_CLK_CTRL0_DIV_ID_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SET_RAMP_DIS_CLK_0(mp0_smn_cgtt_drm_clk_ctrl0_reg, ramp_dis_clk_0) \
      mp0_smn_cgtt_drm_clk_ctrl0_reg = (mp0_smn_cgtt_drm_clk_ctrl0_reg & ~MP0_SMN_CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_0_MASK) | (ramp_dis_clk_0 << MP0_SMN_CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_0_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SET_RAMP_DIS_CLK_REG(mp0_smn_cgtt_drm_clk_ctrl0_reg, ramp_dis_clk_reg) \
      mp0_smn_cgtt_drm_clk_ctrl0_reg = (mp0_smn_cgtt_drm_clk_ctrl0_reg & ~MP0_SMN_CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_REG_MASK) | (ramp_dis_clk_reg << MP0_SMN_CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_REG_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SET_SOFT_OVERRIDE7(mp0_smn_cgtt_drm_clk_ctrl0_reg, soft_override7) \
      mp0_smn_cgtt_drm_clk_ctrl0_reg = (mp0_smn_cgtt_drm_clk_ctrl0_reg & ~MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE7_MASK) | (soft_override7 << MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE7_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SET_SOFT_OVERRIDE6(mp0_smn_cgtt_drm_clk_ctrl0_reg, soft_override6) \
      mp0_smn_cgtt_drm_clk_ctrl0_reg = (mp0_smn_cgtt_drm_clk_ctrl0_reg & ~MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE6_MASK) | (soft_override6 << MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE6_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SET_SOFT_OVERRIDE5(mp0_smn_cgtt_drm_clk_ctrl0_reg, soft_override5) \
      mp0_smn_cgtt_drm_clk_ctrl0_reg = (mp0_smn_cgtt_drm_clk_ctrl0_reg & ~MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE5_MASK) | (soft_override5 << MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE5_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SET_SOFT_OVERRIDE4(mp0_smn_cgtt_drm_clk_ctrl0_reg, soft_override4) \
      mp0_smn_cgtt_drm_clk_ctrl0_reg = (mp0_smn_cgtt_drm_clk_ctrl0_reg & ~MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE4_MASK) | (soft_override4 << MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE4_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SET_SOFT_OVERRIDE3(mp0_smn_cgtt_drm_clk_ctrl0_reg, soft_override3) \
      mp0_smn_cgtt_drm_clk_ctrl0_reg = (mp0_smn_cgtt_drm_clk_ctrl0_reg & ~MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE3_MASK) | (soft_override3 << MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE3_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SET_SOFT_OVERRIDE2(mp0_smn_cgtt_drm_clk_ctrl0_reg, soft_override2) \
      mp0_smn_cgtt_drm_clk_ctrl0_reg = (mp0_smn_cgtt_drm_clk_ctrl0_reg & ~MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE2_MASK) | (soft_override2 << MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE2_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SET_SOFT_OVERRIDE1(mp0_smn_cgtt_drm_clk_ctrl0_reg, soft_override1) \
      mp0_smn_cgtt_drm_clk_ctrl0_reg = (mp0_smn_cgtt_drm_clk_ctrl0_reg & ~MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE1_MASK) | (soft_override1 << MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE1_SHIFT)
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_SET_SOFT_OVERRIDE0(mp0_smn_cgtt_drm_clk_ctrl0_reg, soft_override0) \
      mp0_smn_cgtt_drm_clk_ctrl0_reg = (mp0_smn_cgtt_drm_clk_ctrl0_reg & ~MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE0_MASK) | (soft_override0 << MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_cgtt_drm_clk_ctrl0_t {
            unsigned int on_delay                       : MP0_SMN_CGTT_DRM_CLK_CTRL0_ON_DELAY_SIZE;
            unsigned int off_hysteresis                 : MP0_SMN_CGTT_DRM_CLK_CTRL0_OFF_HYSTERESIS_SIZE;
            unsigned int div_id                         : MP0_SMN_CGTT_DRM_CLK_CTRL0_DIV_ID_SIZE;
            unsigned int                                : 6;
            unsigned int ramp_dis_clk_0                 : MP0_SMN_CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_0_SIZE;
            unsigned int ramp_dis_clk_reg               : MP0_SMN_CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_REG_SIZE;
            unsigned int                                : 1;
            unsigned int soft_override7                 : MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE7_SIZE;
            unsigned int soft_override6                 : MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE6_SIZE;
            unsigned int soft_override5                 : MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE5_SIZE;
            unsigned int soft_override4                 : MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE4_SIZE;
            unsigned int soft_override3                 : MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE3_SIZE;
            unsigned int soft_override2                 : MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE2_SIZE;
            unsigned int soft_override1                 : MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE1_SIZE;
            unsigned int soft_override0                 : MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE0_SIZE;
      } mp0_smn_cgtt_drm_clk_ctrl0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_cgtt_drm_clk_ctrl0_t {
            unsigned int soft_override0                 : MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE0_SIZE;
            unsigned int soft_override1                 : MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE1_SIZE;
            unsigned int soft_override2                 : MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE2_SIZE;
            unsigned int soft_override3                 : MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE3_SIZE;
            unsigned int soft_override4                 : MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE4_SIZE;
            unsigned int soft_override5                 : MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE5_SIZE;
            unsigned int soft_override6                 : MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE6_SIZE;
            unsigned int soft_override7                 : MP0_SMN_CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE7_SIZE;
            unsigned int                                : 1;
            unsigned int ramp_dis_clk_reg               : MP0_SMN_CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_REG_SIZE;
            unsigned int ramp_dis_clk_0                 : MP0_SMN_CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_0_SIZE;
            unsigned int                                : 6;
            unsigned int div_id                         : MP0_SMN_CGTT_DRM_CLK_CTRL0_DIV_ID_SIZE;
            unsigned int off_hysteresis                 : MP0_SMN_CGTT_DRM_CLK_CTRL0_OFF_HYSTERESIS_SIZE;
            unsigned int on_delay                       : MP0_SMN_CGTT_DRM_CLK_CTRL0_ON_DELAY_SIZE;
      } mp0_smn_cgtt_drm_clk_ctrl0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_cgtt_drm_clk_ctrl0_t f;
} mp0_smn_cgtt_drm_clk_ctrl0_u;


/*
 * MP0_SMN_DRM_MASTER_CTRL struct
 */

#define MP0_SMN_DRM_MASTER_CTRL_REG_SIZE         32
#define MP0_SMN_DRM_MASTER_CTRL_MEM_LIGHT_SLEEP_EN_SIZE  1
#define MP0_SMN_DRM_MASTER_CTRL_LEGACY_SIG_CHECK_EN_SIZE  1
#define MP0_SMN_DRM_MASTER_CTRL_MULTI_SESSION_EN_SIZE  1
#define MP0_SMN_DRM_MASTER_CTRL_MEM_SHUT_DOWN_EN_SIZE  1

#define MP0_SMN_DRM_MASTER_CTRL_MEM_LIGHT_SLEEP_EN_SHIFT  0
#define MP0_SMN_DRM_MASTER_CTRL_LEGACY_SIG_CHECK_EN_SHIFT  1
#define MP0_SMN_DRM_MASTER_CTRL_MULTI_SESSION_EN_SHIFT  2
#define MP0_SMN_DRM_MASTER_CTRL_MEM_SHUT_DOWN_EN_SHIFT  3

#define MP0_SMN_DRM_MASTER_CTRL_MEM_LIGHT_SLEEP_EN_MASK  0x00000001
#define MP0_SMN_DRM_MASTER_CTRL_LEGACY_SIG_CHECK_EN_MASK  0x00000002
#define MP0_SMN_DRM_MASTER_CTRL_MULTI_SESSION_EN_MASK  0x00000004
#define MP0_SMN_DRM_MASTER_CTRL_MEM_SHUT_DOWN_EN_MASK  0x00000008

#define MP0_SMN_DRM_MASTER_CTRL_MASK \
      (MP0_SMN_DRM_MASTER_CTRL_MEM_LIGHT_SLEEP_EN_MASK | \
      MP0_SMN_DRM_MASTER_CTRL_LEGACY_SIG_CHECK_EN_MASK | \
      MP0_SMN_DRM_MASTER_CTRL_MULTI_SESSION_EN_MASK | \
      MP0_SMN_DRM_MASTER_CTRL_MEM_SHUT_DOWN_EN_MASK)

#define MP0_SMN_DRM_MASTER_CTRL_DEFAULT 0x00000000

#define MP0_SMN_DRM_MASTER_CTRL_GET_MEM_LIGHT_SLEEP_EN(mp0_smn_drm_master_ctrl) \
      ((mp0_smn_drm_master_ctrl & MP0_SMN_DRM_MASTER_CTRL_MEM_LIGHT_SLEEP_EN_MASK) >> MP0_SMN_DRM_MASTER_CTRL_MEM_LIGHT_SLEEP_EN_SHIFT)
#define MP0_SMN_DRM_MASTER_CTRL_GET_LEGACY_SIG_CHECK_EN(mp0_smn_drm_master_ctrl) \
      ((mp0_smn_drm_master_ctrl & MP0_SMN_DRM_MASTER_CTRL_LEGACY_SIG_CHECK_EN_MASK) >> MP0_SMN_DRM_MASTER_CTRL_LEGACY_SIG_CHECK_EN_SHIFT)
#define MP0_SMN_DRM_MASTER_CTRL_GET_MULTI_SESSION_EN(mp0_smn_drm_master_ctrl) \
      ((mp0_smn_drm_master_ctrl & MP0_SMN_DRM_MASTER_CTRL_MULTI_SESSION_EN_MASK) >> MP0_SMN_DRM_MASTER_CTRL_MULTI_SESSION_EN_SHIFT)
#define MP0_SMN_DRM_MASTER_CTRL_GET_MEM_SHUT_DOWN_EN(mp0_smn_drm_master_ctrl) \
      ((mp0_smn_drm_master_ctrl & MP0_SMN_DRM_MASTER_CTRL_MEM_SHUT_DOWN_EN_MASK) >> MP0_SMN_DRM_MASTER_CTRL_MEM_SHUT_DOWN_EN_SHIFT)

#define MP0_SMN_DRM_MASTER_CTRL_SET_MEM_LIGHT_SLEEP_EN(mp0_smn_drm_master_ctrl_reg, mem_light_sleep_en) \
      mp0_smn_drm_master_ctrl_reg = (mp0_smn_drm_master_ctrl_reg & ~MP0_SMN_DRM_MASTER_CTRL_MEM_LIGHT_SLEEP_EN_MASK) | (mem_light_sleep_en << MP0_SMN_DRM_MASTER_CTRL_MEM_LIGHT_SLEEP_EN_SHIFT)
#define MP0_SMN_DRM_MASTER_CTRL_SET_LEGACY_SIG_CHECK_EN(mp0_smn_drm_master_ctrl_reg, legacy_sig_check_en) \
      mp0_smn_drm_master_ctrl_reg = (mp0_smn_drm_master_ctrl_reg & ~MP0_SMN_DRM_MASTER_CTRL_LEGACY_SIG_CHECK_EN_MASK) | (legacy_sig_check_en << MP0_SMN_DRM_MASTER_CTRL_LEGACY_SIG_CHECK_EN_SHIFT)
#define MP0_SMN_DRM_MASTER_CTRL_SET_MULTI_SESSION_EN(mp0_smn_drm_master_ctrl_reg, multi_session_en) \
      mp0_smn_drm_master_ctrl_reg = (mp0_smn_drm_master_ctrl_reg & ~MP0_SMN_DRM_MASTER_CTRL_MULTI_SESSION_EN_MASK) | (multi_session_en << MP0_SMN_DRM_MASTER_CTRL_MULTI_SESSION_EN_SHIFT)
#define MP0_SMN_DRM_MASTER_CTRL_SET_MEM_SHUT_DOWN_EN(mp0_smn_drm_master_ctrl_reg, mem_shut_down_en) \
      mp0_smn_drm_master_ctrl_reg = (mp0_smn_drm_master_ctrl_reg & ~MP0_SMN_DRM_MASTER_CTRL_MEM_SHUT_DOWN_EN_MASK) | (mem_shut_down_en << MP0_SMN_DRM_MASTER_CTRL_MEM_SHUT_DOWN_EN_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_master_ctrl_t {
            unsigned int mem_light_sleep_en             : MP0_SMN_DRM_MASTER_CTRL_MEM_LIGHT_SLEEP_EN_SIZE;
            unsigned int legacy_sig_check_en            : MP0_SMN_DRM_MASTER_CTRL_LEGACY_SIG_CHECK_EN_SIZE;
            unsigned int multi_session_en               : MP0_SMN_DRM_MASTER_CTRL_MULTI_SESSION_EN_SIZE;
            unsigned int mem_shut_down_en               : MP0_SMN_DRM_MASTER_CTRL_MEM_SHUT_DOWN_EN_SIZE;
            unsigned int                                : 28;
      } mp0_smn_drm_master_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_master_ctrl_t {
            unsigned int                                : 28;
            unsigned int mem_shut_down_en               : MP0_SMN_DRM_MASTER_CTRL_MEM_SHUT_DOWN_EN_SIZE;
            unsigned int multi_session_en               : MP0_SMN_DRM_MASTER_CTRL_MULTI_SESSION_EN_SIZE;
            unsigned int legacy_sig_check_en            : MP0_SMN_DRM_MASTER_CTRL_LEGACY_SIG_CHECK_EN_SIZE;
            unsigned int mem_light_sleep_en             : MP0_SMN_DRM_MASTER_CTRL_MEM_LIGHT_SLEEP_EN_SIZE;
      } mp0_smn_drm_master_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_master_ctrl_t f;
} mp0_smn_drm_master_ctrl_u;


/*
 * MP0_SMN_DRM_AUTH_SESSION struct
 */

#define MP0_SMN_DRM_AUTH_SESSION_REG_SIZE         32
#define MP0_SMN_DRM_AUTH_SESSION_SELECT_SIZE  4

#define MP0_SMN_DRM_AUTH_SESSION_SELECT_SHIFT  0

#define MP0_SMN_DRM_AUTH_SESSION_SELECT_MASK  0x0000000f

#define MP0_SMN_DRM_AUTH_SESSION_MASK \
      (MP0_SMN_DRM_AUTH_SESSION_SELECT_MASK)

#define MP0_SMN_DRM_AUTH_SESSION_DEFAULT 0x00000000

#define MP0_SMN_DRM_AUTH_SESSION_GET_SELECT(mp0_smn_drm_auth_session) \
      ((mp0_smn_drm_auth_session & MP0_SMN_DRM_AUTH_SESSION_SELECT_MASK) >> MP0_SMN_DRM_AUTH_SESSION_SELECT_SHIFT)

#define MP0_SMN_DRM_AUTH_SESSION_SET_SELECT(mp0_smn_drm_auth_session_reg, select) \
      mp0_smn_drm_auth_session_reg = (mp0_smn_drm_auth_session_reg & ~MP0_SMN_DRM_AUTH_SESSION_SELECT_MASK) | (select << MP0_SMN_DRM_AUTH_SESSION_SELECT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_auth_session_t {
            unsigned int select                         : MP0_SMN_DRM_AUTH_SESSION_SELECT_SIZE;
            unsigned int                                : 28;
      } mp0_smn_drm_auth_session_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_auth_session_t {
            unsigned int                                : 28;
            unsigned int select                         : MP0_SMN_DRM_AUTH_SESSION_SELECT_SIZE;
      } mp0_smn_drm_auth_session_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_auth_session_t f;
} mp0_smn_drm_auth_session_u;


/*
 * MP0_SMN_DH_TEST struct
 */

#define MP0_SMN_DH_TEST_REG_SIZE         32
#define MP0_SMN_DH_TEST_DH_TEST_SIZE  1

#define MP0_SMN_DH_TEST_DH_TEST_SHIFT  0

#define MP0_SMN_DH_TEST_DH_TEST_MASK    0x00000001

#define MP0_SMN_DH_TEST_MASK \
      (MP0_SMN_DH_TEST_DH_TEST_MASK)

#define MP0_SMN_DH_TEST_DEFAULT        0x00000000

#define MP0_SMN_DH_TEST_GET_DH_TEST(mp0_smn_dh_test) \
      ((mp0_smn_dh_test & MP0_SMN_DH_TEST_DH_TEST_MASK) >> MP0_SMN_DH_TEST_DH_TEST_SHIFT)

#define MP0_SMN_DH_TEST_SET_DH_TEST(mp0_smn_dh_test_reg, dh_test) \
      mp0_smn_dh_test_reg = (mp0_smn_dh_test_reg & ~MP0_SMN_DH_TEST_DH_TEST_MASK) | (dh_test << MP0_SMN_DH_TEST_DH_TEST_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_dh_test_t {
            unsigned int dh_test                        : MP0_SMN_DH_TEST_DH_TEST_SIZE;
            unsigned int                                : 31;
      } mp0_smn_dh_test_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_dh_test_t {
            unsigned int                                : 31;
            unsigned int dh_test                        : MP0_SMN_DH_TEST_DH_TEST_SIZE;
      } mp0_smn_dh_test_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_dh_test_t f;
} mp0_smn_dh_test_u;


/*
 * MP0_SMN_DC_TEST_DEBUG_INDEX struct
 */

#define MP0_SMN_DC_TEST_DEBUG_INDEX_REG_SIZE         32
#define MP0_SMN_DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_INDEX_SIZE  8
#define MP0_SMN_DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_WRITE_EN_SIZE  1

#define MP0_SMN_DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_INDEX_SHIFT  0
#define MP0_SMN_DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_WRITE_EN_SHIFT  8

#define MP0_SMN_DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_INDEX_MASK  0x000000ff
#define MP0_SMN_DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_WRITE_EN_MASK  0x00000100

#define MP0_SMN_DC_TEST_DEBUG_INDEX_MASK \
      (MP0_SMN_DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_INDEX_MASK | \
      MP0_SMN_DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_WRITE_EN_MASK)

#define MP0_SMN_DC_TEST_DEBUG_INDEX_DEFAULT 0x00000000

#define MP0_SMN_DC_TEST_DEBUG_INDEX_GET_DC_TEST_DEBUG_INDEX(mp0_smn_dc_test_debug_index) \
      ((mp0_smn_dc_test_debug_index & MP0_SMN_DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_INDEX_MASK) >> MP0_SMN_DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_INDEX_SHIFT)
#define MP0_SMN_DC_TEST_DEBUG_INDEX_GET_DC_TEST_DEBUG_WRITE_EN(mp0_smn_dc_test_debug_index) \
      ((mp0_smn_dc_test_debug_index & MP0_SMN_DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_WRITE_EN_MASK) >> MP0_SMN_DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_WRITE_EN_SHIFT)

#define MP0_SMN_DC_TEST_DEBUG_INDEX_SET_DC_TEST_DEBUG_INDEX(mp0_smn_dc_test_debug_index_reg, dc_test_debug_index) \
      mp0_smn_dc_test_debug_index_reg = (mp0_smn_dc_test_debug_index_reg & ~MP0_SMN_DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_INDEX_MASK) | (dc_test_debug_index << MP0_SMN_DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_INDEX_SHIFT)
#define MP0_SMN_DC_TEST_DEBUG_INDEX_SET_DC_TEST_DEBUG_WRITE_EN(mp0_smn_dc_test_debug_index_reg, dc_test_debug_write_en) \
      mp0_smn_dc_test_debug_index_reg = (mp0_smn_dc_test_debug_index_reg & ~MP0_SMN_DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_WRITE_EN_MASK) | (dc_test_debug_write_en << MP0_SMN_DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_WRITE_EN_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_dc_test_debug_index_t {
            unsigned int dc_test_debug_index            : MP0_SMN_DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_INDEX_SIZE;
            unsigned int dc_test_debug_write_en         : MP0_SMN_DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_WRITE_EN_SIZE;
            unsigned int                                : 23;
      } mp0_smn_dc_test_debug_index_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_dc_test_debug_index_t {
            unsigned int                                : 23;
            unsigned int dc_test_debug_write_en         : MP0_SMN_DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_WRITE_EN_SIZE;
            unsigned int dc_test_debug_index            : MP0_SMN_DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_INDEX_SIZE;
      } mp0_smn_dc_test_debug_index_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_dc_test_debug_index_t f;
} mp0_smn_dc_test_debug_index_u;


/*
 * MP0_SMN_DC_TEST_DEBUG_DATA struct
 */

#define MP0_SMN_DC_TEST_DEBUG_DATA_REG_SIZE         32
#define MP0_SMN_DC_TEST_DEBUG_DATA_DC_TEST_DEBUG_DATA_SIZE  32

#define MP0_SMN_DC_TEST_DEBUG_DATA_DC_TEST_DEBUG_DATA_SHIFT  0

#define MP0_SMN_DC_TEST_DEBUG_DATA_DC_TEST_DEBUG_DATA_MASK  0xffffffff

#define MP0_SMN_DC_TEST_DEBUG_DATA_MASK \
      (MP0_SMN_DC_TEST_DEBUG_DATA_DC_TEST_DEBUG_DATA_MASK)

#define MP0_SMN_DC_TEST_DEBUG_DATA_DEFAULT 0x00000000

#define MP0_SMN_DC_TEST_DEBUG_DATA_GET_DC_TEST_DEBUG_DATA(mp0_smn_dc_test_debug_data) \
      ((mp0_smn_dc_test_debug_data & MP0_SMN_DC_TEST_DEBUG_DATA_DC_TEST_DEBUG_DATA_MASK) >> MP0_SMN_DC_TEST_DEBUG_DATA_DC_TEST_DEBUG_DATA_SHIFT)

#define MP0_SMN_DC_TEST_DEBUG_DATA_SET_DC_TEST_DEBUG_DATA(mp0_smn_dc_test_debug_data_reg, dc_test_debug_data) \
      mp0_smn_dc_test_debug_data_reg = (mp0_smn_dc_test_debug_data_reg & ~MP0_SMN_DC_TEST_DEBUG_DATA_DC_TEST_DEBUG_DATA_MASK) | (dc_test_debug_data << MP0_SMN_DC_TEST_DEBUG_DATA_DC_TEST_DEBUG_DATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_dc_test_debug_data_t {
            unsigned int dc_test_debug_data             : MP0_SMN_DC_TEST_DEBUG_DATA_DC_TEST_DEBUG_DATA_SIZE;
      } mp0_smn_dc_test_debug_data_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_dc_test_debug_data_t {
            unsigned int dc_test_debug_data             : MP0_SMN_DC_TEST_DEBUG_DATA_DC_TEST_DEBUG_DATA_SIZE;
      } mp0_smn_dc_test_debug_data_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_dc_test_debug_data_t f;
} mp0_smn_dc_test_debug_data_u;


/*
 * MP0_SMN_DRM_CNT_KEY_STATUS struct
 */

#define MP0_SMN_DRM_CNT_KEY_STATUS_REG_SIZE         32
#define MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT0_SIZE  1
#define MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT1_SIZE  1
#define MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT2_SIZE  1
#define MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT3_SIZE  1
#define MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT4_SIZE  1

#define MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT0_SHIFT  0
#define MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT1_SHIFT  1
#define MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT2_SHIFT  2
#define MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT3_SHIFT  3
#define MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT4_SHIFT  4

#define MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT0_MASK  0x00000001
#define MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT1_MASK  0x00000002
#define MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT2_MASK  0x00000004
#define MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT3_MASK  0x00000008
#define MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT4_MASK  0x00000010

#define MP0_SMN_DRM_CNT_KEY_STATUS_MASK \
      (MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT0_MASK | \
      MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT1_MASK | \
      MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT2_MASK | \
      MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT3_MASK | \
      MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT4_MASK)

#define MP0_SMN_DRM_CNT_KEY_STATUS_DEFAULT 0x0000001f

#define MP0_SMN_DRM_CNT_KEY_STATUS_GET_CLIENT0(mp0_smn_drm_cnt_key_status) \
      ((mp0_smn_drm_cnt_key_status & MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT0_MASK) >> MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT0_SHIFT)
#define MP0_SMN_DRM_CNT_KEY_STATUS_GET_CLIENT1(mp0_smn_drm_cnt_key_status) \
      ((mp0_smn_drm_cnt_key_status & MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT1_MASK) >> MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT1_SHIFT)
#define MP0_SMN_DRM_CNT_KEY_STATUS_GET_CLIENT2(mp0_smn_drm_cnt_key_status) \
      ((mp0_smn_drm_cnt_key_status & MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT2_MASK) >> MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT2_SHIFT)
#define MP0_SMN_DRM_CNT_KEY_STATUS_GET_CLIENT3(mp0_smn_drm_cnt_key_status) \
      ((mp0_smn_drm_cnt_key_status & MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT3_MASK) >> MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT3_SHIFT)
#define MP0_SMN_DRM_CNT_KEY_STATUS_GET_CLIENT4(mp0_smn_drm_cnt_key_status) \
      ((mp0_smn_drm_cnt_key_status & MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT4_MASK) >> MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT4_SHIFT)

#define MP0_SMN_DRM_CNT_KEY_STATUS_SET_CLIENT0(mp0_smn_drm_cnt_key_status_reg, client0) \
      mp0_smn_drm_cnt_key_status_reg = (mp0_smn_drm_cnt_key_status_reg & ~MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT0_MASK) | (client0 << MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT0_SHIFT)
#define MP0_SMN_DRM_CNT_KEY_STATUS_SET_CLIENT1(mp0_smn_drm_cnt_key_status_reg, client1) \
      mp0_smn_drm_cnt_key_status_reg = (mp0_smn_drm_cnt_key_status_reg & ~MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT1_MASK) | (client1 << MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT1_SHIFT)
#define MP0_SMN_DRM_CNT_KEY_STATUS_SET_CLIENT2(mp0_smn_drm_cnt_key_status_reg, client2) \
      mp0_smn_drm_cnt_key_status_reg = (mp0_smn_drm_cnt_key_status_reg & ~MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT2_MASK) | (client2 << MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT2_SHIFT)
#define MP0_SMN_DRM_CNT_KEY_STATUS_SET_CLIENT3(mp0_smn_drm_cnt_key_status_reg, client3) \
      mp0_smn_drm_cnt_key_status_reg = (mp0_smn_drm_cnt_key_status_reg & ~MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT3_MASK) | (client3 << MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT3_SHIFT)
#define MP0_SMN_DRM_CNT_KEY_STATUS_SET_CLIENT4(mp0_smn_drm_cnt_key_status_reg, client4) \
      mp0_smn_drm_cnt_key_status_reg = (mp0_smn_drm_cnt_key_status_reg & ~MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT4_MASK) | (client4 << MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT4_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_cnt_key_status_t {
            unsigned int client0                        : MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT0_SIZE;
            unsigned int client1                        : MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT1_SIZE;
            unsigned int client2                        : MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT2_SIZE;
            unsigned int client3                        : MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT3_SIZE;
            unsigned int client4                        : MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT4_SIZE;
            unsigned int                                : 27;
      } mp0_smn_drm_cnt_key_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_cnt_key_status_t {
            unsigned int                                : 27;
            unsigned int client4                        : MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT4_SIZE;
            unsigned int client3                        : MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT3_SIZE;
            unsigned int client2                        : MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT2_SIZE;
            unsigned int client1                        : MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT1_SIZE;
            unsigned int client0                        : MP0_SMN_DRM_CNT_KEY_STATUS_CLIENT0_SIZE;
      } mp0_smn_drm_cnt_key_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_cnt_key_status_t f;
} mp0_smn_drm_cnt_key_status_u;


/*
 * MP0_SMN_DRM_CLIENT4_EXT struct
 */

#define MP0_SMN_DRM_CLIENT4_EXT_REG_SIZE         32
#define MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_TIMEOUT_SIZE  8
#define MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_BUSY_SIZE  1
#define MP0_SMN_DRM_CLIENT4_EXT_DRM_INIT_SESSION_4_SIZE  1
#define MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_PARSE_BUSY_SIZE  1

#define MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_TIMEOUT_SHIFT  0
#define MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_BUSY_SHIFT  8
#define MP0_SMN_DRM_CLIENT4_EXT_DRM_INIT_SESSION_4_SHIFT  9
#define MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_PARSE_BUSY_SHIFT  10

#define MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_TIMEOUT_MASK  0x000000ff
#define MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_BUSY_MASK  0x00000100
#define MP0_SMN_DRM_CLIENT4_EXT_DRM_INIT_SESSION_4_MASK  0x00000200
#define MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_PARSE_BUSY_MASK  0x00000400

#define MP0_SMN_DRM_CLIENT4_EXT_MASK \
      (MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_TIMEOUT_MASK | \
      MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_BUSY_MASK | \
      MP0_SMN_DRM_CLIENT4_EXT_DRM_INIT_SESSION_4_MASK | \
      MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_PARSE_BUSY_MASK)

#define MP0_SMN_DRM_CLIENT4_EXT_DEFAULT 0x000000ff

#define MP0_SMN_DRM_CLIENT4_EXT_GET_CLIENT4_TIMEOUT(mp0_smn_drm_client4_ext) \
      ((mp0_smn_drm_client4_ext & MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_TIMEOUT_MASK) >> MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_TIMEOUT_SHIFT)
#define MP0_SMN_DRM_CLIENT4_EXT_GET_CLIENT4_BUSY(mp0_smn_drm_client4_ext) \
      ((mp0_smn_drm_client4_ext & MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_BUSY_MASK) >> MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_BUSY_SHIFT)
#define MP0_SMN_DRM_CLIENT4_EXT_GET_DRM_INIT_SESSION_4(mp0_smn_drm_client4_ext) \
      ((mp0_smn_drm_client4_ext & MP0_SMN_DRM_CLIENT4_EXT_DRM_INIT_SESSION_4_MASK) >> MP0_SMN_DRM_CLIENT4_EXT_DRM_INIT_SESSION_4_SHIFT)
#define MP0_SMN_DRM_CLIENT4_EXT_GET_CLIENT4_PARSE_BUSY(mp0_smn_drm_client4_ext) \
      ((mp0_smn_drm_client4_ext & MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_PARSE_BUSY_MASK) >> MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_PARSE_BUSY_SHIFT)

#define MP0_SMN_DRM_CLIENT4_EXT_SET_CLIENT4_TIMEOUT(mp0_smn_drm_client4_ext_reg, client4_timeout) \
      mp0_smn_drm_client4_ext_reg = (mp0_smn_drm_client4_ext_reg & ~MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_TIMEOUT_MASK) | (client4_timeout << MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_TIMEOUT_SHIFT)
#define MP0_SMN_DRM_CLIENT4_EXT_SET_CLIENT4_BUSY(mp0_smn_drm_client4_ext_reg, client4_busy) \
      mp0_smn_drm_client4_ext_reg = (mp0_smn_drm_client4_ext_reg & ~MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_BUSY_MASK) | (client4_busy << MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_BUSY_SHIFT)
#define MP0_SMN_DRM_CLIENT4_EXT_SET_DRM_INIT_SESSION_4(mp0_smn_drm_client4_ext_reg, drm_init_session_4) \
      mp0_smn_drm_client4_ext_reg = (mp0_smn_drm_client4_ext_reg & ~MP0_SMN_DRM_CLIENT4_EXT_DRM_INIT_SESSION_4_MASK) | (drm_init_session_4 << MP0_SMN_DRM_CLIENT4_EXT_DRM_INIT_SESSION_4_SHIFT)
#define MP0_SMN_DRM_CLIENT4_EXT_SET_CLIENT4_PARSE_BUSY(mp0_smn_drm_client4_ext_reg, client4_parse_busy) \
      mp0_smn_drm_client4_ext_reg = (mp0_smn_drm_client4_ext_reg & ~MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_PARSE_BUSY_MASK) | (client4_parse_busy << MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_PARSE_BUSY_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_client4_ext_t {
            unsigned int client4_timeout                : MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_TIMEOUT_SIZE;
            unsigned int client4_busy                   : MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_BUSY_SIZE;
            unsigned int drm_init_session_4             : MP0_SMN_DRM_CLIENT4_EXT_DRM_INIT_SESSION_4_SIZE;
            unsigned int client4_parse_busy             : MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_PARSE_BUSY_SIZE;
            unsigned int                                : 21;
      } mp0_smn_drm_client4_ext_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_client4_ext_t {
            unsigned int                                : 21;
            unsigned int client4_parse_busy             : MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_PARSE_BUSY_SIZE;
            unsigned int drm_init_session_4             : MP0_SMN_DRM_CLIENT4_EXT_DRM_INIT_SESSION_4_SIZE;
            unsigned int client4_busy                   : MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_BUSY_SIZE;
            unsigned int client4_timeout                : MP0_SMN_DRM_CLIENT4_EXT_CLIENT4_TIMEOUT_SIZE;
      } mp0_smn_drm_client4_ext_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_client4_ext_t f;
} mp0_smn_drm_client4_ext_u;


/*
 * MP0_SMN_DRM_DEBUG_ID struct
 */

#define MP0_SMN_DRM_DEBUG_ID_REG_SIZE         32
#define MP0_SMN_DRM_DEBUG_ID_DRM_DEBUG_ID_SIZE  32

#define MP0_SMN_DRM_DEBUG_ID_DRM_DEBUG_ID_SHIFT  0

#define MP0_SMN_DRM_DEBUG_ID_DRM_DEBUG_ID_MASK  0xffffffff

#define MP0_SMN_DRM_DEBUG_ID_MASK \
      (MP0_SMN_DRM_DEBUG_ID_DRM_DEBUG_ID_MASK)

#define MP0_SMN_DRM_DEBUG_ID_DEFAULT   0xbbbbbbbb

#define MP0_SMN_DRM_DEBUG_ID_GET_DRM_DEBUG_ID(mp0_smn_drm_debug_id) \
      ((mp0_smn_drm_debug_id & MP0_SMN_DRM_DEBUG_ID_DRM_DEBUG_ID_MASK) >> MP0_SMN_DRM_DEBUG_ID_DRM_DEBUG_ID_SHIFT)

#define MP0_SMN_DRM_DEBUG_ID_SET_DRM_DEBUG_ID(mp0_smn_drm_debug_id_reg, drm_debug_id) \
      mp0_smn_drm_debug_id_reg = (mp0_smn_drm_debug_id_reg & ~MP0_SMN_DRM_DEBUG_ID_DRM_DEBUG_ID_MASK) | (drm_debug_id << MP0_SMN_DRM_DEBUG_ID_DRM_DEBUG_ID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_smn_drm_debug_id_t {
            unsigned int drm_debug_id                   : MP0_SMN_DRM_DEBUG_ID_DRM_DEBUG_ID_SIZE;
      } mp0_smn_drm_debug_id_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_smn_drm_debug_id_t {
            unsigned int drm_debug_id                   : MP0_SMN_DRM_DEBUG_ID_DRM_DEBUG_ID_SIZE;
      } mp0_smn_drm_debug_id_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_smn_drm_debug_id_t f;
} mp0_smn_drm_debug_id_u;


#endif

