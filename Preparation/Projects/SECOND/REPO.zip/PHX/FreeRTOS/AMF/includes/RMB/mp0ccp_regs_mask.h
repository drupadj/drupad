// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MP0CCP_REGS_MASK_H)
#define _MP0CCP_REGS_MASK_H

/*****************************************************************************************************************
 *
 *	mp0ccp_regs_mask.h
 *
 *	Register Spec Release:  <unknown>
*
*	 (c) 2000 ATI Technologies Inc.  (unpublished)
*
*	 All rights reserved.  This notice is intended as a precaution against
*	 inadvertent publication and does not imply publication or any waiver
*	 of confidentiality.  The year included in the foregoing notice is the
*	 year of creation of the work.
*
 *****************************************************************************************************************/

/*******************************************************
 * Read and Write Masks
 *******************************************************/

#endif


