// Copyright (c) 1994 - 2022 Advanced Micro Devices, Inc. All rights reserved.

#if !defined (_MP1_CRU_MASK_H)
#define _MP1_CRU_MASK_H

/*
 *    mp1_cru_mask.h   
 *
 *    Register Spec Release:  <unknown>
 *
 *
 *      (c) 2021 Advanced Micro Devices, Inc.  (unpublished)
 *
 *        All rights reserved.  This notice is intended as a precaution against
 *     inadvertent publication and does not imply publication or any waiver
 *      of confidentiality.  The year included in the foregoing notice is the
 *     year of creation of the work.
 *
 */

/*******************************************************
 * Read and Write Masks
 *******************************************************/

#define MP1_SMNIF_ERROR_READ_MASK      0xffffffff
#define MP1_SMNIF_ERROR_WRITE_MASK     0xffffffff

#define MP1_CRU_MISC_STATUS_READ_MASK  0xffffffff
#define MP1_CRU_MISC_STATUS_WRITE_MASK 0x00000000

#define MP1_FW_DEBUG_CNT0_READ_MASK    0xffffffff
#define MP1_FW_DEBUG_CNT0_WRITE_MASK   0xffffffff

#define MP1_FW_DEBUG_CNT1_READ_MASK    0xffffffff
#define MP1_FW_DEBUG_CNT1_WRITE_MASK   0xffffffff

#define MP1_FW_DEBUG_CNT2_READ_MASK    0xffffffff
#define MP1_FW_DEBUG_CNT2_WRITE_MASK   0xffffffff

#define MP1_FW_DEBUG_CNT3_READ_MASK    0xffffffff
#define MP1_FW_DEBUG_CNT3_WRITE_MASK   0xffffffff

#define MP1_FW_DEBUG_SIGNAL0_READ_MASK 0xffffffff
#define MP1_FW_DEBUG_SIGNAL0_WRITE_MASK 0xffffffff

#define MP1_FW_DEBUG_SIGNAL1_READ_MASK 0xffffffff
#define MP1_FW_DEBUG_SIGNAL1_WRITE_MASK 0xffffffff

#define MP1_DSM_ENABLE_READ_MASK       0x0000000f
#define MP1_DSM_ENABLE_WRITE_MASK      0x0000000f

#define MP1_FIRMWARE_FLAGS_READ_MASK   0xffffffff
#define MP1_FIRMWARE_FLAGS_WRITE_MASK  0xffffffff

#define MP1_LX3_PDEBUGPC_READ_MASK     0xffffffff
#define MP1_LX3_PDEBUGPC_WRITE_MASK    0x00000000

#define MP1_LX3_PWAITMODE_READ_MASK    0x00000001
#define MP1_LX3_PWAITMODE_WRITE_MASK   0x00000000

#define MP1_MUTEX_0_READ_MASK          0x000000ff
#define MP1_MUTEX_0_WRITE_MASK         0x000000ff

#define MP1_MUTEX_1_READ_MASK          0x000000ff
#define MP1_MUTEX_1_WRITE_MASK         0x000000ff

#define MP1_MUTEX_2_READ_MASK          0x000000ff
#define MP1_MUTEX_2_WRITE_MASK         0x000000ff

#define MP1_MUTEX_3_READ_MASK          0x000000ff
#define MP1_MUTEX_3_WRITE_MASK         0x000000ff

#define MP1_PUB_ECO0_READ_MASK         0xffffffff
#define MP1_PUB_ECO0_WRITE_MASK        0xffffffff

#define MP1_PUB_ECO1_READ_MASK         0xffffffff
#define MP1_PUB_ECO1_WRITE_MASK        0xffffffff

#define MP1_PUB_ECO2_READ_MASK         0xffffffff
#define MP1_PUB_ECO2_WRITE_MASK        0xffffffff

#define MP1_PUB_ECO3_READ_MASK         0xffffffff
#define MP1_PUB_ECO3_WRITE_MASK        0xffffffff

#define MP1_PUB_SCRATCH0_READ_MASK     0xffffffff
#define MP1_PUB_SCRATCH0_WRITE_MASK    0xffffffff

#define MP1_PUB_SCRATCH1_READ_MASK     0xffffffff
#define MP1_PUB_SCRATCH1_WRITE_MASK    0xffffffff

#define MP1_PUB_SCRATCH2_READ_MASK     0xffffffff
#define MP1_PUB_SCRATCH2_WRITE_MASK    0xffffffff

#define MP1_PUB_SCRATCH3_READ_MASK     0xffffffff
#define MP1_PUB_SCRATCH3_WRITE_MASK    0xffffffff

#define MP1_PUB_SCRATCH4_READ_MASK     0xffffffff
#define MP1_PUB_SCRATCH4_WRITE_MASK    0xffffffff

#define MP1_PUB_SCRATCH5_READ_MASK     0xffffffff
#define MP1_PUB_SCRATCH5_WRITE_MASK    0xffffffff

#define MP1_PUB_SCRATCH6_READ_MASK     0xffffffff
#define MP1_PUB_SCRATCH6_WRITE_MASK    0xffffffff

#define MP1_PUB_SCRATCH7_READ_MASK     0xffffffff
#define MP1_PUB_SCRATCH7_WRITE_MASK    0xffffffff

#define MP1_PUB_SCRATCH8_READ_MASK     0xffffffff
#define MP1_PUB_SCRATCH8_WRITE_MASK    0xffffffff

#define MP1_PUB_SCRATCH9_READ_MASK     0xffffffff
#define MP1_PUB_SCRATCH9_WRITE_MASK    0xffffffff

#define MP1_PUB_SCRATCH10_READ_MASK    0xffffffff
#define MP1_PUB_SCRATCH10_WRITE_MASK   0xffffffff

#define MP1_PUB_SCRATCH11_READ_MASK    0xffffffff
#define MP1_PUB_SCRATCH11_WRITE_MASK   0xffffffff

#define MP1_PUB_SCRATCH12_READ_MASK    0xffffffff
#define MP1_PUB_SCRATCH12_WRITE_MASK   0xffffffff

#define MP1_PUB_SCRATCH13_READ_MASK    0xffffffff
#define MP1_PUB_SCRATCH13_WRITE_MASK   0xffffffff

#define MP1_PUB_SCRATCH14_READ_MASK    0xffffffff
#define MP1_PUB_SCRATCH14_WRITE_MASK   0xffffffff

#define MP1_PUB_SCRATCH15_READ_MASK    0xffffffff
#define MP1_PUB_SCRATCH15_WRITE_MASK   0xffffffff

#define MP1_C2PMSG_32_READ_MASK        0xffffffff
#define MP1_C2PMSG_32_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_33_READ_MASK        0xffffffff
#define MP1_C2PMSG_33_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_34_READ_MASK        0xffffffff
#define MP1_C2PMSG_34_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_35_READ_MASK        0xffffffff
#define MP1_C2PMSG_35_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_36_READ_MASK        0xffffffff
#define MP1_C2PMSG_36_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_37_READ_MASK        0xffffffff
#define MP1_C2PMSG_37_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_38_READ_MASK        0xffffffff
#define MP1_C2PMSG_38_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_39_READ_MASK        0xffffffff
#define MP1_C2PMSG_39_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_40_READ_MASK        0xffffffff
#define MP1_C2PMSG_40_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_41_READ_MASK        0xffffffff
#define MP1_C2PMSG_41_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_42_READ_MASK        0xffffffff
#define MP1_C2PMSG_42_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_43_READ_MASK        0xffffffff
#define MP1_C2PMSG_43_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_44_READ_MASK        0xffffffff
#define MP1_C2PMSG_44_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_45_READ_MASK        0xffffffff
#define MP1_C2PMSG_45_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_46_READ_MASK        0xffffffff
#define MP1_C2PMSG_46_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_47_READ_MASK        0xffffffff
#define MP1_C2PMSG_47_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_48_READ_MASK        0xffffffff
#define MP1_C2PMSG_48_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_49_READ_MASK        0xffffffff
#define MP1_C2PMSG_49_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_50_READ_MASK        0xffffffff
#define MP1_C2PMSG_50_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_51_READ_MASK        0xffffffff
#define MP1_C2PMSG_51_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_52_READ_MASK        0xffffffff
#define MP1_C2PMSG_52_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_53_READ_MASK        0xffffffff
#define MP1_C2PMSG_53_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_54_READ_MASK        0xffffffff
#define MP1_C2PMSG_54_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_55_READ_MASK        0xffffffff
#define MP1_C2PMSG_55_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_56_READ_MASK        0xffffffff
#define MP1_C2PMSG_56_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_57_READ_MASK        0xffffffff
#define MP1_C2PMSG_57_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_58_READ_MASK        0xffffffff
#define MP1_C2PMSG_58_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_59_READ_MASK        0xffffffff
#define MP1_C2PMSG_59_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_60_READ_MASK        0xffffffff
#define MP1_C2PMSG_60_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_61_READ_MASK        0xffffffff
#define MP1_C2PMSG_61_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_62_READ_MASK        0xffffffff
#define MP1_C2PMSG_62_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_63_READ_MASK        0xffffffff
#define MP1_C2PMSG_63_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_64_READ_MASK        0xffffffff
#define MP1_C2PMSG_64_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_65_READ_MASK        0xffffffff
#define MP1_C2PMSG_65_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_66_READ_MASK        0xffffffff
#define MP1_C2PMSG_66_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_67_READ_MASK        0xffffffff
#define MP1_C2PMSG_67_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_68_READ_MASK        0xffffffff
#define MP1_C2PMSG_68_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_69_READ_MASK        0xffffffff
#define MP1_C2PMSG_69_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_70_READ_MASK        0xffffffff
#define MP1_C2PMSG_70_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_71_READ_MASK        0xffffffff
#define MP1_C2PMSG_71_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_72_READ_MASK        0xffffffff
#define MP1_C2PMSG_72_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_73_READ_MASK        0xffffffff
#define MP1_C2PMSG_73_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_74_READ_MASK        0xffffffff
#define MP1_C2PMSG_74_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_75_READ_MASK        0xffffffff
#define MP1_C2PMSG_75_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_76_READ_MASK        0xffffffff
#define MP1_C2PMSG_76_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_77_READ_MASK        0xffffffff
#define MP1_C2PMSG_77_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_78_READ_MASK        0xffffffff
#define MP1_C2PMSG_78_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_79_READ_MASK        0xffffffff
#define MP1_C2PMSG_79_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_80_READ_MASK        0xffffffff
#define MP1_C2PMSG_80_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_81_READ_MASK        0xffffffff
#define MP1_C2PMSG_81_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_82_READ_MASK        0xffffffff
#define MP1_C2PMSG_82_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_83_READ_MASK        0xffffffff
#define MP1_C2PMSG_83_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_84_READ_MASK        0xffffffff
#define MP1_C2PMSG_84_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_85_READ_MASK        0xffffffff
#define MP1_C2PMSG_85_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_86_READ_MASK        0xffffffff
#define MP1_C2PMSG_86_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_87_READ_MASK        0xffffffff
#define MP1_C2PMSG_87_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_88_READ_MASK        0xffffffff
#define MP1_C2PMSG_88_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_89_READ_MASK        0xffffffff
#define MP1_C2PMSG_89_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_90_READ_MASK        0xffffffff
#define MP1_C2PMSG_90_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_91_READ_MASK        0xffffffff
#define MP1_C2PMSG_91_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_92_READ_MASK        0xffffffff
#define MP1_C2PMSG_92_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_93_READ_MASK        0xffffffff
#define MP1_C2PMSG_93_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_94_READ_MASK        0xffffffff
#define MP1_C2PMSG_94_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_95_READ_MASK        0xffffffff
#define MP1_C2PMSG_95_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_96_READ_MASK        0xffffffff
#define MP1_C2PMSG_96_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_97_READ_MASK        0xffffffff
#define MP1_C2PMSG_97_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_98_READ_MASK        0xffffffff
#define MP1_C2PMSG_98_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_99_READ_MASK        0xffffffff
#define MP1_C2PMSG_99_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_100_READ_MASK       0xffffffff
#define MP1_C2PMSG_100_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_101_READ_MASK       0xffffffff
#define MP1_C2PMSG_101_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_102_READ_MASK       0xffffffff
#define MP1_C2PMSG_102_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_103_READ_MASK       0xffffffff
#define MP1_C2PMSG_103_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_104_READ_MASK       0xffffffff
#define MP1_C2PMSG_104_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_105_READ_MASK       0xffffffff
#define MP1_C2PMSG_105_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_106_READ_MASK       0xffffffff
#define MP1_C2PMSG_106_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_107_READ_MASK       0xffffffff
#define MP1_C2PMSG_107_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_108_READ_MASK       0xffffffff
#define MP1_C2PMSG_108_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_109_READ_MASK       0xffffffff
#define MP1_C2PMSG_109_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_110_READ_MASK       0xffffffff
#define MP1_C2PMSG_110_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_111_READ_MASK       0xffffffff
#define MP1_C2PMSG_111_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_112_READ_MASK       0xffffffff
#define MP1_C2PMSG_112_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_113_READ_MASK       0xffffffff
#define MP1_C2PMSG_113_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_114_READ_MASK       0xffffffff
#define MP1_C2PMSG_114_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_115_READ_MASK       0xffffffff
#define MP1_C2PMSG_115_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_116_READ_MASK       0xffffffff
#define MP1_C2PMSG_116_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_117_READ_MASK       0xffffffff
#define MP1_C2PMSG_117_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_118_READ_MASK       0xffffffff
#define MP1_C2PMSG_118_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_119_READ_MASK       0xffffffff
#define MP1_C2PMSG_119_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_120_READ_MASK       0xffffffff
#define MP1_C2PMSG_120_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_121_READ_MASK       0xffffffff
#define MP1_C2PMSG_121_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_122_READ_MASK       0xffffffff
#define MP1_C2PMSG_122_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_123_READ_MASK       0xffffffff
#define MP1_C2PMSG_123_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_124_READ_MASK       0xffffffff
#define MP1_C2PMSG_124_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_125_READ_MASK       0xffffffff
#define MP1_C2PMSG_125_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_126_READ_MASK       0xffffffff
#define MP1_C2PMSG_126_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_127_READ_MASK       0xffffffff
#define MP1_C2PMSG_127_WRITE_MASK      0xffffffff

#define MP1_C2PMSG_0_READ_MASK         0xffffffff
#define MP1_C2PMSG_0_WRITE_MASK        0xffffffff

#define MP1_C2PMSG_1_READ_MASK         0xffffffff
#define MP1_C2PMSG_1_WRITE_MASK        0xffffffff

#define MP1_C2PMSG_2_READ_MASK         0xffffffff
#define MP1_C2PMSG_2_WRITE_MASK        0xffffffff

#define MP1_C2PMSG_3_READ_MASK         0xffffffff
#define MP1_C2PMSG_3_WRITE_MASK        0xffffffff

#define MP1_C2PMSG_4_READ_MASK         0xffffffff
#define MP1_C2PMSG_4_WRITE_MASK        0xffffffff

#define MP1_C2PMSG_5_READ_MASK         0xffffffff
#define MP1_C2PMSG_5_WRITE_MASK        0xffffffff

#define MP1_C2PMSG_6_READ_MASK         0xffffffff
#define MP1_C2PMSG_6_WRITE_MASK        0xffffffff

#define MP1_C2PMSG_7_READ_MASK         0xffffffff
#define MP1_C2PMSG_7_WRITE_MASK        0xffffffff

#define MP1_C2PMSG_8_READ_MASK         0xffffffff
#define MP1_C2PMSG_8_WRITE_MASK        0xffffffff

#define MP1_C2PMSG_9_READ_MASK         0xffffffff
#define MP1_C2PMSG_9_WRITE_MASK        0xffffffff

#define MP1_C2PMSG_10_READ_MASK        0xffffffff
#define MP1_C2PMSG_10_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_11_READ_MASK        0xffffffff
#define MP1_C2PMSG_11_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_12_READ_MASK        0xffffffff
#define MP1_C2PMSG_12_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_13_READ_MASK        0xffffffff
#define MP1_C2PMSG_13_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_14_READ_MASK        0xffffffff
#define MP1_C2PMSG_14_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_15_READ_MASK        0xffffffff
#define MP1_C2PMSG_15_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_16_READ_MASK        0xffffffff
#define MP1_C2PMSG_16_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_17_READ_MASK        0xffffffff
#define MP1_C2PMSG_17_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_18_READ_MASK        0xffffffff
#define MP1_C2PMSG_18_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_19_READ_MASK        0xffffffff
#define MP1_C2PMSG_19_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_20_READ_MASK        0xffffffff
#define MP1_C2PMSG_20_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_21_READ_MASK        0xffffffff
#define MP1_C2PMSG_21_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_22_READ_MASK        0xffffffff
#define MP1_C2PMSG_22_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_23_READ_MASK        0xffffffff
#define MP1_C2PMSG_23_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_24_READ_MASK        0xffffffff
#define MP1_C2PMSG_24_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_25_READ_MASK        0xffffffff
#define MP1_C2PMSG_25_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_26_READ_MASK        0xffffffff
#define MP1_C2PMSG_26_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_27_READ_MASK        0xffffffff
#define MP1_C2PMSG_27_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_28_READ_MASK        0xffffffff
#define MP1_C2PMSG_28_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_29_READ_MASK        0xffffffff
#define MP1_C2PMSG_29_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_30_READ_MASK        0xffffffff
#define MP1_C2PMSG_30_WRITE_MASK       0xffffffff

#define MP1_C2PMSG_31_READ_MASK        0xffffffff
#define MP1_C2PMSG_31_WRITE_MASK       0xffffffff

#define MP1_P2CMSG_0_READ_MASK         0xffffffff
#define MP1_P2CMSG_0_WRITE_MASK        0xffffffff

#define MP1_P2CMSG_1_READ_MASK         0xffffffff
#define MP1_P2CMSG_1_WRITE_MASK        0xffffffff

#define MP1_P2CMSG_2_READ_MASK         0xffffffff
#define MP1_P2CMSG_2_WRITE_MASK        0xffffffff

#define MP1_P2CMSG_3_READ_MASK         0xffffffff
#define MP1_P2CMSG_3_WRITE_MASK        0xffffffff

#define MP1_P2CMSG_INTEN_READ_MASK     0x0000000f
#define MP1_P2CMSG_INTEN_WRITE_MASK    0x0000000f

#define MP1_P2CMSG_INTSTS_READ_MASK    0x0000000f
#define MP1_P2CMSG_INTSTS_WRITE_MASK   0x0000000f

#define MP1_P2SMSG_0_READ_MASK         0xffffffff
#define MP1_P2SMSG_0_WRITE_MASK        0xffffffff

#define MP1_P2SMSG_1_READ_MASK         0xffffffff
#define MP1_P2SMSG_1_WRITE_MASK        0xffffffff

#define MP1_P2SMSG_2_READ_MASK         0xffffffff
#define MP1_P2SMSG_2_WRITE_MASK        0xffffffff

#define MP1_P2SMSG_3_READ_MASK         0xffffffff
#define MP1_P2SMSG_3_WRITE_MASK        0xffffffff

#define MP1_P2SMSG_INTSTS_READ_MASK    0x0000000f
#define MP1_P2SMSG_INTSTS_WRITE_MASK   0x0000000f

#define MP1_S2PMSG_0_READ_MASK         0xffffffff
#define MP1_S2PMSG_0_WRITE_MASK        0xffffffff

#define MP1_IH_CREDIT_READ_MASK        0x00000000
#define MP1_IH_CREDIT_WRITE_MASK       0x00ff0003

#define MP1_IH_SW_INT_READ_MASK        0x000001ff
#define MP1_IH_SW_INT_WRITE_MASK       0x000001ff

#define MP1_IH_SW_INT_CTRL_READ_MASK   0x00000001
#define MP1_IH_SW_INT_CTRL_WRITE_MASK  0x00000101

#define MP1_FPS_CNT_READ_MASK          0xffffffff
#define MP1_FPS_CNT_WRITE_MASK         0xffffffff

#define MP1_EXT_SCRATCH0_READ_MASK     0xffffffff
#define MP1_EXT_SCRATCH0_WRITE_MASK    0xffffffff

#define MP1_EXT_SCRATCH1_READ_MASK     0xffffffff
#define MP1_EXT_SCRATCH1_WRITE_MASK    0xffffffff

#define MP1_EXT_SCRATCH2_READ_MASK     0xffffffff
#define MP1_EXT_SCRATCH2_WRITE_MASK    0xffffffff

#define MP1_EXT_SCRATCH3_READ_MASK     0xffffffff
#define MP1_EXT_SCRATCH3_WRITE_MASK    0xffffffff

#define MP1_EXT_SCRATCH4_READ_MASK     0xffffffff
#define MP1_EXT_SCRATCH4_WRITE_MASK    0xffffffff

#define MP1_EXT_SCRATCH5_READ_MASK     0xffffffff
#define MP1_EXT_SCRATCH5_WRITE_MASK    0xffffffff

#define MP1_EXT_SCRATCH6_READ_MASK     0xffffffff
#define MP1_EXT_SCRATCH6_WRITE_MASK    0xffffffff

#define MP1_EXT_SCRATCH7_READ_MASK     0xffffffff
#define MP1_EXT_SCRATCH7_WRITE_MASK    0xffffffff

#define MP1_EXT_SCRATCH8_READ_MASK     0xffffffff
#define MP1_EXT_SCRATCH8_WRITE_MASK    0xffffffff

#define MP1_EXT_SCRATCH9_READ_MASK     0xffffffff
#define MP1_EXT_SCRATCH9_WRITE_MASK    0xffffffff

#define MP1_EXT_SCRATCH10_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH10_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH11_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH11_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH12_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH12_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH13_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH13_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH14_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH14_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH15_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH15_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH16_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH16_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH17_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH17_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH18_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH18_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH19_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH19_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH20_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH20_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH21_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH21_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH22_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH22_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH23_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH23_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH24_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH24_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH25_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH25_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH26_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH26_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH27_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH27_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH28_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH28_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH29_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH29_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH30_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH30_WRITE_MASK   0xffffffff

#define MP1_EXT_SCRATCH31_READ_MASK    0xffffffff
#define MP1_EXT_SCRATCH31_WRITE_MASK   0xffffffff

#define MP1_REVID_READ_MASK            0xffffffff
#define MP1_REVID_WRITE_MASK           0xffffffff

#define MP1_CPU_HARVEST_ENB_READ_MASK  0x00000001
#define MP1_CPU_HARVEST_ENB_WRITE_MASK 0x00000000

#define MP1_RAM_REPAIR_DONE_READ_MASK  0xffffffff
#define MP1_RAM_REPAIR_DONE_WRITE_MASK 0xffffffff

#define MP1_RAM_REPAIR_RESULT_READ_MASK 0xffffffff
#define MP1_RAM_REPAIR_RESULT_WRITE_MASK 0xffffffff

#define MP1_FUSE_HARVESTING_READ_MASK  0xffffffff
#define MP1_FUSE_HARVESTING_WRITE_MASK 0xffffffff

#define MP1_ACC_VIO_INTSTS_READ_MASK   0xffffffff
#define MP1_ACC_VIO_INTSTS_WRITE_MASK  0xffffffff

#define MP1_TDR_MISC0_STATUS_READ_MASK 0xffffffff
#define MP1_TDR_MISC0_STATUS_WRITE_MASK 0x00000000

#define MP1_FW_OVERRIDE_READ_MASK      0xffffffff
#define MP1_FW_OVERRIDE_WRITE_MASK     0xffffffff

#define MP1_J2P_MBOX0_READ_MASK        0xffffffff
#define MP1_J2P_MBOX0_WRITE_MASK       0xffffffff

#define MP1_J2P_MBOX1_READ_MASK        0xffffffff
#define MP1_J2P_MBOX1_WRITE_MASK       0xffffffff

#define MP1_J2P_ATTR_READ_MASK         0x00000003
#define MP1_J2P_ATTR_WRITE_MASK        0x00000003

#define MP1_CRU_ACC_VIO_INTSTS_READ_MASK 0xffffffff
#define MP1_CRU_ACC_VIO_INTSTS_WRITE_MASK 0xffffffff

#define MP1_ACC_VIOL_LOG0_READ_MASK    0x7fffffff
#define MP1_ACC_VIOL_LOG0_WRITE_MASK   0x80000000

#define MP1_ACC_VIOL_LOG1_READ_MASK    0xffffffff
#define MP1_ACC_VIOL_LOG1_WRITE_MASK   0x00000000

#define MP1_STICKY_READ_MASK           0xffffffff
#define MP1_STICKY_WRITE_MASK          0xffffffff

#define MP1_CRU_MISC_CTRL_READ_MASK    0x9501c107
#define MP1_CRU_MISC_CTRL_WRITE_MASK   0x95010107

#define MP1_SOFT_RESET_CTRL_READ_MASK  0x00080f07
#define MP1_SOFT_RESET_CTRL_WRITE_MASK 0x00080f07

#define MP1_NS_PROT_FAULT_STATUS_0_READ_MASK 0x00000013
#define MP1_NS_PROT_FAULT_STATUS_0_WRITE_MASK 0x00000013

#define MP1_LX3_CTRL_READ_MASK         0x00000003
#define MP1_LX3_CTRL_WRITE_MASK        0x00000003

#define MP1_SEC_SCRATCH0_READ_MASK     0xffffffff
#define MP1_SEC_SCRATCH0_WRITE_MASK    0xffffffff

#define MP1_SEC_SCRATCH1_READ_MASK     0xffffffff
#define MP1_SEC_SCRATCH1_WRITE_MASK    0xffffffff

#define MP1_SEC_SCRATCH2_READ_MASK     0xffffffff
#define MP1_SEC_SCRATCH2_WRITE_MASK    0xffffffff

#define MP1_SEC_SCRATCH3_READ_MASK     0xffffffff
#define MP1_SEC_SCRATCH3_WRITE_MASK    0xffffffff

#define MP1_SEC_ECO0_READ_MASK         0xffffffff
#define MP1_SEC_ECO0_WRITE_MASK        0xffffffff

#define MP1_SEC_ECO1_READ_MASK         0xffffffff
#define MP1_SEC_ECO1_WRITE_MASK        0xffffffff

#define MP1_SEC_ECO2_READ_MASK         0xffffffff
#define MP1_SEC_ECO2_WRITE_MASK        0xffffffff

#define MP1_SEC_ECO3_READ_MASK         0xffffffff
#define MP1_SEC_ECO3_WRITE_MASK        0xffffffff

#define MP1_VIRT_INITID0_GRP0_READ_MASK 0x03ff03ff
#define MP1_VIRT_INITID0_GRP0_WRITE_MASK 0x03ff03ff

#define MP1_VIRT_INITID1_GRP0_READ_MASK 0x03ff03ff
#define MP1_VIRT_INITID1_GRP0_WRITE_MASK 0x03ff03ff

#define MP1_VIRT_INITID0_GRP1_READ_MASK 0x03ff03ff
#define MP1_VIRT_INITID0_GRP1_WRITE_MASK 0x03ff03ff

#define MP1_VIRT_INITID1_GRP1_READ_MASK 0x03ff03ff
#define MP1_VIRT_INITID1_GRP1_WRITE_MASK 0x03ff03ff

#define MP1_VIRT_INITID0_GRP2_READ_MASK 0x03ff03ff
#define MP1_VIRT_INITID0_GRP2_WRITE_MASK 0x03ff03ff

#define MP1_VIRT_INITID1_GRP2_READ_MASK 0x03ff03ff
#define MP1_VIRT_INITID1_GRP2_WRITE_MASK 0x03ff03ff

#define MP1_VIRT_INITID0_GRP3_READ_MASK 0x03ff03ff
#define MP1_VIRT_INITID0_GRP3_WRITE_MASK 0x03ff03ff

#define MP1_VIRT_INITID1_GRP3_READ_MASK 0x03ff03ff
#define MP1_VIRT_INITID1_GRP3_WRITE_MASK 0x03ff03ff

#define MP1_VIRT_INITID_GRP0_CTRL_READ_MASK 0x0000010f
#define MP1_VIRT_INITID_GRP0_CTRL_WRITE_MASK 0x0000010f

#define MP1_VIRT_INITID_GRP1_CTRL_READ_MASK 0x0000010f
#define MP1_VIRT_INITID_GRP1_CTRL_WRITE_MASK 0x0000010f

#define MP1_VIRT_INITID_GRP2_CTRL_READ_MASK 0x0000010f
#define MP1_VIRT_INITID_GRP2_CTRL_WRITE_MASK 0x0000010f

#define MP1_VIRT_INITID_GRP3_CTRL_READ_MASK 0x0000010f
#define MP1_VIRT_INITID_GRP3_CTRL_WRITE_MASK 0x0000010f

#define MP1_IH_CLIENT_ID_READ_MASK     0x000000ff
#define MP1_IH_CLIENT_ID_WRITE_MASK    0x000000ff

#define MP1_IH_CREDIT_CNT_READ_MASK    0x00000003
#define MP1_IH_CREDIT_CNT_WRITE_MASK   0x00010100

#define MP1_FW_MISC_CTRL_READ_MASK     0xffffffff
#define MP1_FW_MISC_CTRL_WRITE_MASK    0xffffffff

#define MP1_AEB_STATUS_0_READ_MASK     0x0000000f
#define MP1_AEB_STATUS_0_WRITE_MASK    0x00000000

#define MP1_FW_CHRONO_LO_READ_MASK     0xffffffff
#define MP1_FW_CHRONO_LO_WRITE_MASK    0x00000000

#define MP1_FW_CHRONO_HI_READ_MASK     0xffffffff
#define MP1_FW_CHRONO_HI_WRITE_MASK    0x00000000

#define MP1_PIC0_MASK_0_READ_MASK      0x000000ff
#define MP1_PIC0_MASK_0_WRITE_MASK     0x000000ff

#define MP1_PIC0_LEVEL_0_READ_MASK     0x000000ff
#define MP1_PIC0_LEVEL_0_WRITE_MASK    0x000000ff

#define MP1_PIC0_EDGE_0_READ_MASK      0x000000ff
#define MP1_PIC0_EDGE_0_WRITE_MASK     0x000000ff

#define MP1_PIC0_PRIORITY_0_READ_MASK  0xffffffff
#define MP1_PIC0_PRIORITY_0_WRITE_MASK 0xffffffff

#define MP1_PIC0_PRIORITY_1_READ_MASK  0xffffffff
#define MP1_PIC0_PRIORITY_1_WRITE_MASK 0xffffffff

#define MP1_PIC0_STATUS_0_READ_MASK    0x000000ff
#define MP1_PIC0_STATUS_0_WRITE_MASK   0x000000ff

#define MP1_PIC0_INTR_READ_MASK        0xffffffff
#define MP1_PIC0_INTR_WRITE_MASK       0x00000000

#define MP1_PIC0_ID_READ_MASK          0xffffffff
#define MP1_PIC0_ID_WRITE_MASK         0x00000000

#define MP1_PIC1_MASK_0_READ_MASK      0xffffffff
#define MP1_PIC1_MASK_0_WRITE_MASK     0xffffffff

#define MP1_PIC1_MASK_1_READ_MASK      0xffffffff
#define MP1_PIC1_MASK_1_WRITE_MASK     0xffffffff

#define MP1_PIC1_MASK_2_READ_MASK      0xffffffff
#define MP1_PIC1_MASK_2_WRITE_MASK     0xffffffff

#define MP1_PIC1_MASK_3_READ_MASK      0xffffffff
#define MP1_PIC1_MASK_3_WRITE_MASK     0xffffffff

#define MP1_PIC1_LEVEL_0_READ_MASK     0xffffffff
#define MP1_PIC1_LEVEL_0_WRITE_MASK    0xffffffff

#define MP1_PIC1_LEVEL_1_READ_MASK     0xffffffff
#define MP1_PIC1_LEVEL_1_WRITE_MASK    0xffffffff

#define MP1_PIC1_LEVEL_2_READ_MASK     0xffffffff
#define MP1_PIC1_LEVEL_2_WRITE_MASK    0xffffffff

#define MP1_PIC1_LEVEL_3_READ_MASK     0xffffffff
#define MP1_PIC1_LEVEL_3_WRITE_MASK    0xffffffff

#define MP1_PIC1_EDGE_0_READ_MASK      0xffffffff
#define MP1_PIC1_EDGE_0_WRITE_MASK     0xffffffff

#define MP1_PIC1_EDGE_1_READ_MASK      0xffffffff
#define MP1_PIC1_EDGE_1_WRITE_MASK     0xffffffff

#define MP1_PIC1_EDGE_2_READ_MASK      0xffffffff
#define MP1_PIC1_EDGE_2_WRITE_MASK     0xffffffff

#define MP1_PIC1_EDGE_3_READ_MASK      0xffffffff
#define MP1_PIC1_EDGE_3_WRITE_MASK     0xffffffff

#define MP1_PIC1_PRIORITY_0_READ_MASK  0xffffffff
#define MP1_PIC1_PRIORITY_0_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_1_READ_MASK  0xffffffff
#define MP1_PIC1_PRIORITY_1_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_2_READ_MASK  0xffffffff
#define MP1_PIC1_PRIORITY_2_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_3_READ_MASK  0xffffffff
#define MP1_PIC1_PRIORITY_3_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_4_READ_MASK  0xffffffff
#define MP1_PIC1_PRIORITY_4_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_5_READ_MASK  0xffffffff
#define MP1_PIC1_PRIORITY_5_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_6_READ_MASK  0xffffffff
#define MP1_PIC1_PRIORITY_6_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_7_READ_MASK  0xffffffff
#define MP1_PIC1_PRIORITY_7_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_8_READ_MASK  0xffffffff
#define MP1_PIC1_PRIORITY_8_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_9_READ_MASK  0xffffffff
#define MP1_PIC1_PRIORITY_9_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_10_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_10_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_11_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_11_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_12_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_12_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_13_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_13_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_14_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_14_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_15_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_15_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_16_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_16_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_17_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_17_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_18_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_18_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_19_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_19_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_20_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_20_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_21_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_21_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_22_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_22_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_23_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_23_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_24_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_24_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_25_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_25_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_26_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_26_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_27_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_27_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_28_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_28_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_29_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_29_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_30_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_30_WRITE_MASK 0xffffffff

#define MP1_PIC1_PRIORITY_31_READ_MASK 0xffffffff
#define MP1_PIC1_PRIORITY_31_WRITE_MASK 0xffffffff

#define MP1_PIC1_STATUS_0_READ_MASK    0xffffffff
#define MP1_PIC1_STATUS_0_WRITE_MASK   0xffffffff

#define MP1_PIC1_STATUS_1_READ_MASK    0xffffffff
#define MP1_PIC1_STATUS_1_WRITE_MASK   0xffffffff

#define MP1_PIC1_STATUS_2_READ_MASK    0xffffffff
#define MP1_PIC1_STATUS_2_WRITE_MASK   0xffffffff

#define MP1_PIC1_STATUS_3_READ_MASK    0xffffffff
#define MP1_PIC1_STATUS_3_WRITE_MASK   0xffffffff

#define MP1_PIC1_INTR_READ_MASK        0xffffffff
#define MP1_PIC1_INTR_WRITE_MASK       0x00000000

#define MP1_PIC1_ID_READ_MASK          0xffffffff
#define MP1_PIC1_ID_WRITE_MASK         0x00000000

#define MP1_TIMER_0_CTRL0_READ_MASK    0x01010101
#define MP1_TIMER_0_CTRL0_WRITE_MASK   0x01010101

#define MP1_TIMER_0_CTRL1_READ_MASK    0xff010101
#define MP1_TIMER_0_CTRL1_WRITE_MASK   0x00010101

#define MP1_TIMER_0_CMP_AUTOINC_READ_MASK 0xffffffff
#define MP1_TIMER_0_CMP_AUTOINC_WRITE_MASK 0x0000000f

#define MP1_TIMER_0_INTEN_READ_MASK    0xffffffff
#define MP1_TIMER_0_INTEN_WRITE_MASK   0x0000000f

#define MP1_TIMER_OCMP_0_0_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_0_0_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_0_1_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_0_1_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_0_2_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_0_2_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_0_3_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_0_3_WRITE_MASK  0xffffffff

#define MP1_TIMER_0_CNT_READ_MASK      0xffffffff
#define MP1_TIMER_0_CNT_WRITE_MASK     0x00000000

#define MP1_TIMER_1_CTRL0_READ_MASK    0x01010101
#define MP1_TIMER_1_CTRL0_WRITE_MASK   0x01010101

#define MP1_TIMER_1_CTRL1_READ_MASK    0xff010101
#define MP1_TIMER_1_CTRL1_WRITE_MASK   0x00010101

#define MP1_TIMER_1_CMP_AUTOINC_READ_MASK 0xffffffff
#define MP1_TIMER_1_CMP_AUTOINC_WRITE_MASK 0x0000000f

#define MP1_TIMER_1_INTEN_READ_MASK    0xffffffff
#define MP1_TIMER_1_INTEN_WRITE_MASK   0x0000000f

#define MP1_TIMER_OCMP_1_0_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_1_0_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_1_1_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_1_1_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_1_2_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_1_2_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_1_3_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_1_3_WRITE_MASK  0xffffffff

#define MP1_TIMER_1_CNT_READ_MASK      0xffffffff
#define MP1_TIMER_1_CNT_WRITE_MASK     0x00000000

#define MP1_TIMER_2_CTRL0_READ_MASK    0x01010101
#define MP1_TIMER_2_CTRL0_WRITE_MASK   0x01010101

#define MP1_TIMER_2_CTRL1_READ_MASK    0xff010101
#define MP1_TIMER_2_CTRL1_WRITE_MASK   0x00010101

#define MP1_TIMER_2_CMP_AUTOINC_READ_MASK 0xffffffff
#define MP1_TIMER_2_CMP_AUTOINC_WRITE_MASK 0x0000000f

#define MP1_TIMER_2_INTEN_READ_MASK    0xffffffff
#define MP1_TIMER_2_INTEN_WRITE_MASK   0x0000000f

#define MP1_TIMER_OCMP_2_0_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_2_0_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_2_1_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_2_1_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_2_2_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_2_2_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_2_3_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_2_3_WRITE_MASK  0xffffffff

#define MP1_TIMER_2_CNT_READ_MASK      0xffffffff
#define MP1_TIMER_2_CNT_WRITE_MASK     0x00000000

#define MP1_TIMER_3_CTRL0_READ_MASK    0x01010101
#define MP1_TIMER_3_CTRL0_WRITE_MASK   0x01010101

#define MP1_TIMER_3_CTRL1_READ_MASK    0xff010101
#define MP1_TIMER_3_CTRL1_WRITE_MASK   0x00010101

#define MP1_TIMER_3_CMP_AUTOINC_READ_MASK 0xffffffff
#define MP1_TIMER_3_CMP_AUTOINC_WRITE_MASK 0x0000000f

#define MP1_TIMER_3_INTEN_READ_MASK    0xffffffff
#define MP1_TIMER_3_INTEN_WRITE_MASK   0x0000000f

#define MP1_TIMER_OCMP_3_0_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_3_0_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_3_1_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_3_1_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_3_2_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_3_2_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_3_3_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_3_3_WRITE_MASK  0xffffffff

#define MP1_TIMER_3_CNT_READ_MASK      0xffffffff
#define MP1_TIMER_3_CNT_WRITE_MASK     0x00000000

#define MP1_TIMER_4_CTRL0_READ_MASK    0x01010101
#define MP1_TIMER_4_CTRL0_WRITE_MASK   0x01010101

#define MP1_TIMER_4_CTRL1_READ_MASK    0xff010101
#define MP1_TIMER_4_CTRL1_WRITE_MASK   0x00010101

#define MP1_TIMER_4_CMP_AUTOINC_READ_MASK 0xffffffff
#define MP1_TIMER_4_CMP_AUTOINC_WRITE_MASK 0x0000000f

#define MP1_TIMER_4_INTEN_READ_MASK    0xffffffff
#define MP1_TIMER_4_INTEN_WRITE_MASK   0x0000000f

#define MP1_TIMER_OCMP_4_0_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_4_0_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_4_1_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_4_1_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_4_2_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_4_2_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_4_3_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_4_3_WRITE_MASK  0xffffffff

#define MP1_TIMER_4_CNT_READ_MASK      0xffffffff
#define MP1_TIMER_4_CNT_WRITE_MASK     0x00000000

#define MP1_TIMER_5_CTRL0_READ_MASK    0x01010101
#define MP1_TIMER_5_CTRL0_WRITE_MASK   0x01010101

#define MP1_TIMER_5_CTRL1_READ_MASK    0xff010101
#define MP1_TIMER_5_CTRL1_WRITE_MASK   0x00010101

#define MP1_TIMER_5_CMP_AUTOINC_READ_MASK 0xffffffff
#define MP1_TIMER_5_CMP_AUTOINC_WRITE_MASK 0x0000000f

#define MP1_TIMER_5_INTEN_READ_MASK    0xffffffff
#define MP1_TIMER_5_INTEN_WRITE_MASK   0x0000000f

#define MP1_TIMER_OCMP_5_0_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_5_0_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_5_1_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_5_1_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_5_2_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_5_2_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_5_3_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_5_3_WRITE_MASK  0xffffffff

#define MP1_TIMER_5_CNT_READ_MASK      0xffffffff
#define MP1_TIMER_5_CNT_WRITE_MASK     0x00000000

#define MP1_TIMER_6_CTRL0_READ_MASK    0x01010101
#define MP1_TIMER_6_CTRL0_WRITE_MASK   0x01010101

#define MP1_TIMER_6_CTRL1_READ_MASK    0xff010101
#define MP1_TIMER_6_CTRL1_WRITE_MASK   0x00010101

#define MP1_TIMER_6_CMP_AUTOINC_READ_MASK 0xffffffff
#define MP1_TIMER_6_CMP_AUTOINC_WRITE_MASK 0x0000000f

#define MP1_TIMER_6_INTEN_READ_MASK    0xffffffff
#define MP1_TIMER_6_INTEN_WRITE_MASK   0x0000000f

#define MP1_TIMER_OCMP_6_0_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_6_0_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_6_1_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_6_1_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_6_2_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_6_2_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_6_3_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_6_3_WRITE_MASK  0xffffffff

#define MP1_TIMER_6_CNT_READ_MASK      0xffffffff
#define MP1_TIMER_6_CNT_WRITE_MASK     0x00000000

#define MP1_TIMER_7_CTRL0_READ_MASK    0x01010101
#define MP1_TIMER_7_CTRL0_WRITE_MASK   0x01010101

#define MP1_TIMER_7_CTRL1_READ_MASK    0xff010101
#define MP1_TIMER_7_CTRL1_WRITE_MASK   0x00010101

#define MP1_TIMER_7_CMP_AUTOINC_READ_MASK 0xffffffff
#define MP1_TIMER_7_CMP_AUTOINC_WRITE_MASK 0x0000000f

#define MP1_TIMER_7_INTEN_READ_MASK    0xffffffff
#define MP1_TIMER_7_INTEN_WRITE_MASK   0x0000000f

#define MP1_TIMER_OCMP_7_0_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_7_0_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_7_1_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_7_1_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_7_2_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_7_2_WRITE_MASK  0xffffffff

#define MP1_TIMER_OCMP_7_3_READ_MASK   0xffffffff
#define MP1_TIMER_OCMP_7_3_WRITE_MASK  0xffffffff

#define MP1_TIMER_7_CNT_READ_MASK      0xffffffff
#define MP1_TIMER_7_CNT_WRITE_MASK     0x00000000

#define MP1_P2CMSG_ATTR_READ_MASK      0x000000ff
#define MP1_P2CMSG_ATTR_WRITE_MASK     0x000000ff

#define MP1_C2PMSG_ATTR_0_READ_MASK    0xffffffff
#define MP1_C2PMSG_ATTR_0_WRITE_MASK   0xffffffff

#define MP1_C2PMSG_ATTR_1_READ_MASK    0xffffffff
#define MP1_C2PMSG_ATTR_1_WRITE_MASK   0xffffffff

#define MP1_C2PMSG_ATTR_2_READ_MASK    0xffffffff
#define MP1_C2PMSG_ATTR_2_WRITE_MASK   0xffffffff

#define MP1_C2PMSG_ATTR_3_READ_MASK    0xffffffff
#define MP1_C2PMSG_ATTR_3_WRITE_MASK   0xffffffff

#define MP1_C2PMSG_ATTR_4_READ_MASK    0xffffffff
#define MP1_C2PMSG_ATTR_4_WRITE_MASK   0xffffffff

#define MP1_C2PMSG_ATTR_5_READ_MASK    0xffffffff
#define MP1_C2PMSG_ATTR_5_WRITE_MASK   0xffffffff

#define MP1_C2PMSG_ATTR_6_READ_MASK    0xffffffff
#define MP1_C2PMSG_ATTR_6_WRITE_MASK   0xffffffff

#define MP1_C2PMSG_ATTR_7_READ_MASK    0xffffffff
#define MP1_C2PMSG_ATTR_7_WRITE_MASK   0xffffffff

#define MP1_S2PMSG_ATTR_READ_MASK      0x00000003
#define MP1_S2PMSG_ATTR_WRITE_MASK     0x00000003

#define MP1_P2SMSG_ATTR_READ_MASK      0x000000ff
#define MP1_P2SMSG_ATTR_WRITE_MASK     0x000000ff

#endif


