// Copyright (c) 1994 - 2021 Advanced Micro Devices, Inc. All rights reserved. 
 #if !defined (_MP_DRM_FIDDLE_H)
#define _MP_DRM_FIDDLE_H
 /*****************************************************************************************************************
 *
 *  mp_drm_reg.h
 *
 *  Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif

 /*******************************************************
 * Values
 *******************************************************/

 /*******************************************************
 * Structures
 *******************************************************/

/*
 * DRM_KEYGEN_START struct
 */

#define DRM_KEYGEN_START_REG_SIZE         32
#define DRM_KEYGEN_START_RESERVED_SIZE  32

#define DRM_KEYGEN_START_RESERVED_SHIFT  0

#define DRM_KEYGEN_START_RESERVED_MASK  0xffffffff

#define DRM_KEYGEN_START_MASK \
      (DRM_KEYGEN_START_RESERVED_MASK)

#define DRM_KEYGEN_START_DEFAULT       0x00000000

#define DRM_KEYGEN_START_GET_RESERVED(drm_keygen_start) \
      ((drm_keygen_start & DRM_KEYGEN_START_RESERVED_MASK) >> DRM_KEYGEN_START_RESERVED_SHIFT)

#define DRM_KEYGEN_START_SET_RESERVED(drm_keygen_start_reg, reserved) \
      drm_keygen_start_reg = (drm_keygen_start_reg & ~DRM_KEYGEN_START_RESERVED_MASK) | (reserved << DRM_KEYGEN_START_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_keygen_start_t {
            unsigned int reserved                       : DRM_KEYGEN_START_RESERVED_SIZE;
      } drm_keygen_start_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_keygen_start_t {
            unsigned int reserved                       : DRM_KEYGEN_START_RESERVED_SIZE;
      } drm_keygen_start_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_keygen_start_t f;
} drm_keygen_start_u;


/*
 * DRM_KEYGEN_CONT struct
 */

#define DRM_KEYGEN_CONT_REG_SIZE         32
#define DRM_KEYGEN_CONT_RESERVED_SIZE  32

#define DRM_KEYGEN_CONT_RESERVED_SHIFT  0

#define DRM_KEYGEN_CONT_RESERVED_MASK   0xffffffff

#define DRM_KEYGEN_CONT_MASK \
      (DRM_KEYGEN_CONT_RESERVED_MASK)

#define DRM_KEYGEN_CONT_DEFAULT        0x00000000

#define DRM_KEYGEN_CONT_GET_RESERVED(drm_keygen_cont) \
      ((drm_keygen_cont & DRM_KEYGEN_CONT_RESERVED_MASK) >> DRM_KEYGEN_CONT_RESERVED_SHIFT)

#define DRM_KEYGEN_CONT_SET_RESERVED(drm_keygen_cont_reg, reserved) \
      drm_keygen_cont_reg = (drm_keygen_cont_reg & ~DRM_KEYGEN_CONT_RESERVED_MASK) | (reserved << DRM_KEYGEN_CONT_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_keygen_cont_t {
            unsigned int reserved                       : DRM_KEYGEN_CONT_RESERVED_SIZE;
      } drm_keygen_cont_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_keygen_cont_t {
            unsigned int reserved                       : DRM_KEYGEN_CONT_RESERVED_SIZE;
      } drm_keygen_cont_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_keygen_cont_t f;
} drm_keygen_cont_u;


/*
 * DRM_KEYGEN_RADDR struct
 */

#define DRM_KEYGEN_RADDR_REG_SIZE         32
#define DRM_KEYGEN_RADDR_RADDR_SIZE  6

#define DRM_KEYGEN_RADDR_RADDR_SHIFT  0

#define DRM_KEYGEN_RADDR_RADDR_MASK     0x0000003f

#define DRM_KEYGEN_RADDR_MASK \
      (DRM_KEYGEN_RADDR_RADDR_MASK)

#define DRM_KEYGEN_RADDR_DEFAULT       0x00000000

#define DRM_KEYGEN_RADDR_GET_RADDR(drm_keygen_raddr) \
      ((drm_keygen_raddr & DRM_KEYGEN_RADDR_RADDR_MASK) >> DRM_KEYGEN_RADDR_RADDR_SHIFT)

#define DRM_KEYGEN_RADDR_SET_RADDR(drm_keygen_raddr_reg, raddr) \
      drm_keygen_raddr_reg = (drm_keygen_raddr_reg & ~DRM_KEYGEN_RADDR_RADDR_MASK) | (raddr << DRM_KEYGEN_RADDR_RADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_keygen_raddr_t {
            unsigned int raddr                          : DRM_KEYGEN_RADDR_RADDR_SIZE;
            unsigned int                                : 26;
      } drm_keygen_raddr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_keygen_raddr_t {
            unsigned int                                : 26;
            unsigned int raddr                          : DRM_KEYGEN_RADDR_RADDR_SIZE;
      } drm_keygen_raddr_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_keygen_raddr_t f;
} drm_keygen_raddr_u;


/*
 * DRM_KEYGEN_RDATA struct
 */

#define DRM_KEYGEN_RDATA_REG_SIZE         32
#define DRM_KEYGEN_RDATA_RDATA_SIZE  32

#define DRM_KEYGEN_RDATA_RDATA_SHIFT  0

#define DRM_KEYGEN_RDATA_RDATA_MASK     0xffffffff

#define DRM_KEYGEN_RDATA_MASK \
      (DRM_KEYGEN_RDATA_RDATA_MASK)

#define DRM_KEYGEN_RDATA_DEFAULT       0x00000000

#define DRM_KEYGEN_RDATA_GET_RDATA(drm_keygen_rdata) \
      ((drm_keygen_rdata & DRM_KEYGEN_RDATA_RDATA_MASK) >> DRM_KEYGEN_RDATA_RDATA_SHIFT)

#define DRM_KEYGEN_RDATA_SET_RDATA(drm_keygen_rdata_reg, rdata) \
      drm_keygen_rdata_reg = (drm_keygen_rdata_reg & ~DRM_KEYGEN_RDATA_RDATA_MASK) | (rdata << DRM_KEYGEN_RDATA_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_keygen_rdata_t {
            unsigned int rdata                          : DRM_KEYGEN_RDATA_RDATA_SIZE;
      } drm_keygen_rdata_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_keygen_rdata_t {
            unsigned int rdata                          : DRM_KEYGEN_RDATA_RDATA_SIZE;
      } drm_keygen_rdata_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_keygen_rdata_t f;
} drm_keygen_rdata_u;


/*
 * DRM_KEYGEN_WADDR struct
 */

#define DRM_KEYGEN_WADDR_REG_SIZE         32
#define DRM_KEYGEN_WADDR_WADDR_SIZE  6

#define DRM_KEYGEN_WADDR_WADDR_SHIFT  0

#define DRM_KEYGEN_WADDR_WADDR_MASK     0x0000003f

#define DRM_KEYGEN_WADDR_MASK \
      (DRM_KEYGEN_WADDR_WADDR_MASK)

#define DRM_KEYGEN_WADDR_DEFAULT       0x00000000

#define DRM_KEYGEN_WADDR_GET_WADDR(drm_keygen_waddr) \
      ((drm_keygen_waddr & DRM_KEYGEN_WADDR_WADDR_MASK) >> DRM_KEYGEN_WADDR_WADDR_SHIFT)

#define DRM_KEYGEN_WADDR_SET_WADDR(drm_keygen_waddr_reg, waddr) \
      drm_keygen_waddr_reg = (drm_keygen_waddr_reg & ~DRM_KEYGEN_WADDR_WADDR_MASK) | (waddr << DRM_KEYGEN_WADDR_WADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_keygen_waddr_t {
            unsigned int waddr                          : DRM_KEYGEN_WADDR_WADDR_SIZE;
            unsigned int                                : 26;
      } drm_keygen_waddr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_keygen_waddr_t {
            unsigned int                                : 26;
            unsigned int waddr                          : DRM_KEYGEN_WADDR_WADDR_SIZE;
      } drm_keygen_waddr_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_keygen_waddr_t f;
} drm_keygen_waddr_u;


/*
 * DRM_KEYGEN_WDATA struct
 */

#define DRM_KEYGEN_WDATA_REG_SIZE         32
#define DRM_KEYGEN_WDATA_WDATA_SIZE  32

#define DRM_KEYGEN_WDATA_WDATA_SHIFT  0

#define DRM_KEYGEN_WDATA_WDATA_MASK     0xffffffff

#define DRM_KEYGEN_WDATA_MASK \
      (DRM_KEYGEN_WDATA_WDATA_MASK)

#define DRM_KEYGEN_WDATA_DEFAULT       0x00000000

#define DRM_KEYGEN_WDATA_GET_WDATA(drm_keygen_wdata) \
      ((drm_keygen_wdata & DRM_KEYGEN_WDATA_WDATA_MASK) >> DRM_KEYGEN_WDATA_WDATA_SHIFT)

#define DRM_KEYGEN_WDATA_SET_WDATA(drm_keygen_wdata_reg, wdata) \
      drm_keygen_wdata_reg = (drm_keygen_wdata_reg & ~DRM_KEYGEN_WDATA_WDATA_MASK) | (wdata << DRM_KEYGEN_WDATA_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_keygen_wdata_t {
            unsigned int wdata                          : DRM_KEYGEN_WDATA_WDATA_SIZE;
      } drm_keygen_wdata_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_keygen_wdata_t {
            unsigned int wdata                          : DRM_KEYGEN_WDATA_WDATA_SIZE;
      } drm_keygen_wdata_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_keygen_wdata_t f;
} drm_keygen_wdata_u;


/*
 * DRM_HFS_START struct
 */

#define DRM_HFS_START_REG_SIZE         32
#define DRM_HFS_START_HFS_TYPE_SIZE  4

#define DRM_HFS_START_HFS_TYPE_SHIFT  0

#define DRM_HFS_START_HFS_TYPE_MASK     0x0000000f

#define DRM_HFS_START_MASK \
      (DRM_HFS_START_HFS_TYPE_MASK)

#define DRM_HFS_START_DEFAULT          0x00000000

#define DRM_HFS_START_GET_HFS_TYPE(drm_hfs_start) \
      ((drm_hfs_start & DRM_HFS_START_HFS_TYPE_MASK) >> DRM_HFS_START_HFS_TYPE_SHIFT)

#define DRM_HFS_START_SET_HFS_TYPE(drm_hfs_start_reg, hfs_type) \
      drm_hfs_start_reg = (drm_hfs_start_reg & ~DRM_HFS_START_HFS_TYPE_MASK) | (hfs_type << DRM_HFS_START_HFS_TYPE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_hfs_start_t {
            unsigned int hfs_type                       : DRM_HFS_START_HFS_TYPE_SIZE;
            unsigned int                                : 28;
      } drm_hfs_start_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_hfs_start_t {
            unsigned int                                : 28;
            unsigned int hfs_type                       : DRM_HFS_START_HFS_TYPE_SIZE;
      } drm_hfs_start_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_hfs_start_t f;
} drm_hfs_start_u;


/*
 * DRM_HFS_SW_NONCE0 struct
 */

#define DRM_HFS_SW_NONCE0_REG_SIZE         32
#define DRM_HFS_SW_NONCE0_SW_NONCE_SIZE  32

#define DRM_HFS_SW_NONCE0_SW_NONCE_SHIFT  0

#define DRM_HFS_SW_NONCE0_SW_NONCE_MASK  0xffffffff

#define DRM_HFS_SW_NONCE0_MASK \
      (DRM_HFS_SW_NONCE0_SW_NONCE_MASK)

#define DRM_HFS_SW_NONCE0_DEFAULT      0x00000000

#define DRM_HFS_SW_NONCE0_GET_SW_NONCE(drm_hfs_sw_nonce0) \
      ((drm_hfs_sw_nonce0 & DRM_HFS_SW_NONCE0_SW_NONCE_MASK) >> DRM_HFS_SW_NONCE0_SW_NONCE_SHIFT)

#define DRM_HFS_SW_NONCE0_SET_SW_NONCE(drm_hfs_sw_nonce0_reg, sw_nonce) \
      drm_hfs_sw_nonce0_reg = (drm_hfs_sw_nonce0_reg & ~DRM_HFS_SW_NONCE0_SW_NONCE_MASK) | (sw_nonce << DRM_HFS_SW_NONCE0_SW_NONCE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_hfs_sw_nonce0_t {
            unsigned int sw_nonce                       : DRM_HFS_SW_NONCE0_SW_NONCE_SIZE;
      } drm_hfs_sw_nonce0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_hfs_sw_nonce0_t {
            unsigned int sw_nonce                       : DRM_HFS_SW_NONCE0_SW_NONCE_SIZE;
      } drm_hfs_sw_nonce0_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_hfs_sw_nonce0_t f;
} drm_hfs_sw_nonce0_u;


/*
 * DRM_HFS_SW_NONCE1 struct
 */

#define DRM_HFS_SW_NONCE1_REG_SIZE         32
#define DRM_HFS_SW_NONCE1_SW_NONCE_SIZE  32

#define DRM_HFS_SW_NONCE1_SW_NONCE_SHIFT  0

#define DRM_HFS_SW_NONCE1_SW_NONCE_MASK  0xffffffff

#define DRM_HFS_SW_NONCE1_MASK \
      (DRM_HFS_SW_NONCE1_SW_NONCE_MASK)

#define DRM_HFS_SW_NONCE1_DEFAULT      0x00000000

#define DRM_HFS_SW_NONCE1_GET_SW_NONCE(drm_hfs_sw_nonce1) \
      ((drm_hfs_sw_nonce1 & DRM_HFS_SW_NONCE1_SW_NONCE_MASK) >> DRM_HFS_SW_NONCE1_SW_NONCE_SHIFT)

#define DRM_HFS_SW_NONCE1_SET_SW_NONCE(drm_hfs_sw_nonce1_reg, sw_nonce) \
      drm_hfs_sw_nonce1_reg = (drm_hfs_sw_nonce1_reg & ~DRM_HFS_SW_NONCE1_SW_NONCE_MASK) | (sw_nonce << DRM_HFS_SW_NONCE1_SW_NONCE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_hfs_sw_nonce1_t {
            unsigned int sw_nonce                       : DRM_HFS_SW_NONCE1_SW_NONCE_SIZE;
      } drm_hfs_sw_nonce1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_hfs_sw_nonce1_t {
            unsigned int sw_nonce                       : DRM_HFS_SW_NONCE1_SW_NONCE_SIZE;
      } drm_hfs_sw_nonce1_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_hfs_sw_nonce1_t f;
} drm_hfs_sw_nonce1_u;


/*
 * DRM_HFS_SW_NONCE2 struct
 */

#define DRM_HFS_SW_NONCE2_REG_SIZE         32
#define DRM_HFS_SW_NONCE2_SW_NONCE_SIZE  32

#define DRM_HFS_SW_NONCE2_SW_NONCE_SHIFT  0

#define DRM_HFS_SW_NONCE2_SW_NONCE_MASK  0xffffffff

#define DRM_HFS_SW_NONCE2_MASK \
      (DRM_HFS_SW_NONCE2_SW_NONCE_MASK)

#define DRM_HFS_SW_NONCE2_DEFAULT      0x00000000

#define DRM_HFS_SW_NONCE2_GET_SW_NONCE(drm_hfs_sw_nonce2) \
      ((drm_hfs_sw_nonce2 & DRM_HFS_SW_NONCE2_SW_NONCE_MASK) >> DRM_HFS_SW_NONCE2_SW_NONCE_SHIFT)

#define DRM_HFS_SW_NONCE2_SET_SW_NONCE(drm_hfs_sw_nonce2_reg, sw_nonce) \
      drm_hfs_sw_nonce2_reg = (drm_hfs_sw_nonce2_reg & ~DRM_HFS_SW_NONCE2_SW_NONCE_MASK) | (sw_nonce << DRM_HFS_SW_NONCE2_SW_NONCE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_hfs_sw_nonce2_t {
            unsigned int sw_nonce                       : DRM_HFS_SW_NONCE2_SW_NONCE_SIZE;
      } drm_hfs_sw_nonce2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_hfs_sw_nonce2_t {
            unsigned int sw_nonce                       : DRM_HFS_SW_NONCE2_SW_NONCE_SIZE;
      } drm_hfs_sw_nonce2_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_hfs_sw_nonce2_t f;
} drm_hfs_sw_nonce2_u;


/*
 * DRM_HFS_SW_NONCE3 struct
 */

#define DRM_HFS_SW_NONCE3_REG_SIZE         32
#define DRM_HFS_SW_NONCE3_SW_NONCE_SIZE  32

#define DRM_HFS_SW_NONCE3_SW_NONCE_SHIFT  0

#define DRM_HFS_SW_NONCE3_SW_NONCE_MASK  0xffffffff

#define DRM_HFS_SW_NONCE3_MASK \
      (DRM_HFS_SW_NONCE3_SW_NONCE_MASK)

#define DRM_HFS_SW_NONCE3_DEFAULT      0x00000000

#define DRM_HFS_SW_NONCE3_GET_SW_NONCE(drm_hfs_sw_nonce3) \
      ((drm_hfs_sw_nonce3 & DRM_HFS_SW_NONCE3_SW_NONCE_MASK) >> DRM_HFS_SW_NONCE3_SW_NONCE_SHIFT)

#define DRM_HFS_SW_NONCE3_SET_SW_NONCE(drm_hfs_sw_nonce3_reg, sw_nonce) \
      drm_hfs_sw_nonce3_reg = (drm_hfs_sw_nonce3_reg & ~DRM_HFS_SW_NONCE3_SW_NONCE_MASK) | (sw_nonce << DRM_HFS_SW_NONCE3_SW_NONCE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_hfs_sw_nonce3_t {
            unsigned int sw_nonce                       : DRM_HFS_SW_NONCE3_SW_NONCE_SIZE;
      } drm_hfs_sw_nonce3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_hfs_sw_nonce3_t {
            unsigned int sw_nonce                       : DRM_HFS_SW_NONCE3_SW_NONCE_SIZE;
      } drm_hfs_sw_nonce3_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_hfs_sw_nonce3_t f;
} drm_hfs_sw_nonce3_u;


/*
 * DRM_HFS_HW_NONCE0 struct
 */

#define DRM_HFS_HW_NONCE0_REG_SIZE         32
#define DRM_HFS_HW_NONCE0_HW_NONCE_SIZE  32

#define DRM_HFS_HW_NONCE0_HW_NONCE_SHIFT  0

#define DRM_HFS_HW_NONCE0_HW_NONCE_MASK  0xffffffff

#define DRM_HFS_HW_NONCE0_MASK \
      (DRM_HFS_HW_NONCE0_HW_NONCE_MASK)

#define DRM_HFS_HW_NONCE0_DEFAULT      0x00000000

#define DRM_HFS_HW_NONCE0_GET_HW_NONCE(drm_hfs_hw_nonce0) \
      ((drm_hfs_hw_nonce0 & DRM_HFS_HW_NONCE0_HW_NONCE_MASK) >> DRM_HFS_HW_NONCE0_HW_NONCE_SHIFT)

#define DRM_HFS_HW_NONCE0_SET_HW_NONCE(drm_hfs_hw_nonce0_reg, hw_nonce) \
      drm_hfs_hw_nonce0_reg = (drm_hfs_hw_nonce0_reg & ~DRM_HFS_HW_NONCE0_HW_NONCE_MASK) | (hw_nonce << DRM_HFS_HW_NONCE0_HW_NONCE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_hfs_hw_nonce0_t {
            unsigned int hw_nonce                       : DRM_HFS_HW_NONCE0_HW_NONCE_SIZE;
      } drm_hfs_hw_nonce0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_hfs_hw_nonce0_t {
            unsigned int hw_nonce                       : DRM_HFS_HW_NONCE0_HW_NONCE_SIZE;
      } drm_hfs_hw_nonce0_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_hfs_hw_nonce0_t f;
} drm_hfs_hw_nonce0_u;


/*
 * DRM_HFS_HW_NONCE1 struct
 */

#define DRM_HFS_HW_NONCE1_REG_SIZE         32
#define DRM_HFS_HW_NONCE1_HW_NONCE_SIZE  32

#define DRM_HFS_HW_NONCE1_HW_NONCE_SHIFT  0

#define DRM_HFS_HW_NONCE1_HW_NONCE_MASK  0xffffffff

#define DRM_HFS_HW_NONCE1_MASK \
      (DRM_HFS_HW_NONCE1_HW_NONCE_MASK)

#define DRM_HFS_HW_NONCE1_DEFAULT      0x00000000

#define DRM_HFS_HW_NONCE1_GET_HW_NONCE(drm_hfs_hw_nonce1) \
      ((drm_hfs_hw_nonce1 & DRM_HFS_HW_NONCE1_HW_NONCE_MASK) >> DRM_HFS_HW_NONCE1_HW_NONCE_SHIFT)

#define DRM_HFS_HW_NONCE1_SET_HW_NONCE(drm_hfs_hw_nonce1_reg, hw_nonce) \
      drm_hfs_hw_nonce1_reg = (drm_hfs_hw_nonce1_reg & ~DRM_HFS_HW_NONCE1_HW_NONCE_MASK) | (hw_nonce << DRM_HFS_HW_NONCE1_HW_NONCE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_hfs_hw_nonce1_t {
            unsigned int hw_nonce                       : DRM_HFS_HW_NONCE1_HW_NONCE_SIZE;
      } drm_hfs_hw_nonce1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_hfs_hw_nonce1_t {
            unsigned int hw_nonce                       : DRM_HFS_HW_NONCE1_HW_NONCE_SIZE;
      } drm_hfs_hw_nonce1_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_hfs_hw_nonce1_t f;
} drm_hfs_hw_nonce1_u;


/*
 * DRM_HFS_HW_NONCE2 struct
 */

#define DRM_HFS_HW_NONCE2_REG_SIZE         32
#define DRM_HFS_HW_NONCE2_HW_NONCE_SIZE  32

#define DRM_HFS_HW_NONCE2_HW_NONCE_SHIFT  0

#define DRM_HFS_HW_NONCE2_HW_NONCE_MASK  0xffffffff

#define DRM_HFS_HW_NONCE2_MASK \
      (DRM_HFS_HW_NONCE2_HW_NONCE_MASK)

#define DRM_HFS_HW_NONCE2_DEFAULT      0x00000000

#define DRM_HFS_HW_NONCE2_GET_HW_NONCE(drm_hfs_hw_nonce2) \
      ((drm_hfs_hw_nonce2 & DRM_HFS_HW_NONCE2_HW_NONCE_MASK) >> DRM_HFS_HW_NONCE2_HW_NONCE_SHIFT)

#define DRM_HFS_HW_NONCE2_SET_HW_NONCE(drm_hfs_hw_nonce2_reg, hw_nonce) \
      drm_hfs_hw_nonce2_reg = (drm_hfs_hw_nonce2_reg & ~DRM_HFS_HW_NONCE2_HW_NONCE_MASK) | (hw_nonce << DRM_HFS_HW_NONCE2_HW_NONCE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_hfs_hw_nonce2_t {
            unsigned int hw_nonce                       : DRM_HFS_HW_NONCE2_HW_NONCE_SIZE;
      } drm_hfs_hw_nonce2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_hfs_hw_nonce2_t {
            unsigned int hw_nonce                       : DRM_HFS_HW_NONCE2_HW_NONCE_SIZE;
      } drm_hfs_hw_nonce2_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_hfs_hw_nonce2_t f;
} drm_hfs_hw_nonce2_u;


/*
 * DRM_HFS_HW_NONCE3 struct
 */

#define DRM_HFS_HW_NONCE3_REG_SIZE         32
#define DRM_HFS_HW_NONCE3_HW_NONCE_SIZE  32

#define DRM_HFS_HW_NONCE3_HW_NONCE_SHIFT  0

#define DRM_HFS_HW_NONCE3_HW_NONCE_MASK  0xffffffff

#define DRM_HFS_HW_NONCE3_MASK \
      (DRM_HFS_HW_NONCE3_HW_NONCE_MASK)

#define DRM_HFS_HW_NONCE3_DEFAULT      0x00000000

#define DRM_HFS_HW_NONCE3_GET_HW_NONCE(drm_hfs_hw_nonce3) \
      ((drm_hfs_hw_nonce3 & DRM_HFS_HW_NONCE3_HW_NONCE_MASK) >> DRM_HFS_HW_NONCE3_HW_NONCE_SHIFT)

#define DRM_HFS_HW_NONCE3_SET_HW_NONCE(drm_hfs_hw_nonce3_reg, hw_nonce) \
      drm_hfs_hw_nonce3_reg = (drm_hfs_hw_nonce3_reg & ~DRM_HFS_HW_NONCE3_HW_NONCE_MASK) | (hw_nonce << DRM_HFS_HW_NONCE3_HW_NONCE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_hfs_hw_nonce3_t {
            unsigned int hw_nonce                       : DRM_HFS_HW_NONCE3_HW_NONCE_SIZE;
      } drm_hfs_hw_nonce3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_hfs_hw_nonce3_t {
            unsigned int hw_nonce                       : DRM_HFS_HW_NONCE3_HW_NONCE_SIZE;
      } drm_hfs_hw_nonce3_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_hfs_hw_nonce3_t f;
} drm_hfs_hw_nonce3_u;


/*
 * DRM_SHARED_CLIENT struct
 */

#define DRM_SHARED_CLIENT_REG_SIZE         32
#define DRM_SHARED_CLIENT_VP8_SELECT_SIZE  1

#define DRM_SHARED_CLIENT_VP8_SELECT_SHIFT  0

#define DRM_SHARED_CLIENT_VP8_SELECT_MASK  0x00000001

#define DRM_SHARED_CLIENT_MASK \
      (DRM_SHARED_CLIENT_VP8_SELECT_MASK)

#define DRM_SHARED_CLIENT_DEFAULT      0x00000000

#define DRM_SHARED_CLIENT_GET_VP8_SELECT(drm_shared_client) \
      ((drm_shared_client & DRM_SHARED_CLIENT_VP8_SELECT_MASK) >> DRM_SHARED_CLIENT_VP8_SELECT_SHIFT)

#define DRM_SHARED_CLIENT_SET_VP8_SELECT(drm_shared_client_reg, vp8_select) \
      drm_shared_client_reg = (drm_shared_client_reg & ~DRM_SHARED_CLIENT_VP8_SELECT_MASK) | (vp8_select << DRM_SHARED_CLIENT_VP8_SELECT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_shared_client_t {
            unsigned int vp8_select                     : DRM_SHARED_CLIENT_VP8_SELECT_SIZE;
            unsigned int                                : 31;
      } drm_shared_client_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_shared_client_t {
            unsigned int                                : 31;
            unsigned int vp8_select                     : DRM_SHARED_CLIENT_VP8_SELECT_SIZE;
      } drm_shared_client_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_shared_client_t f;
} drm_shared_client_u;


/*
 * DRM_TIMEOUT struct
 */

#define DRM_TIMEOUT_REG_SIZE         32
#define DRM_TIMEOUT_CLIENT2_TIMEOUT_SIZE  8
#define DRM_TIMEOUT_CLIENT0_TIMEOUT_SIZE  8
#define DRM_TIMEOUT_CLIENT1_TIMEOUT_SIZE  8
#define DRM_TIMEOUT_CLIENT3_TIMEOUT_SIZE  8

#define DRM_TIMEOUT_CLIENT2_TIMEOUT_SHIFT  0
#define DRM_TIMEOUT_CLIENT0_TIMEOUT_SHIFT  8
#define DRM_TIMEOUT_CLIENT1_TIMEOUT_SHIFT  16
#define DRM_TIMEOUT_CLIENT3_TIMEOUT_SHIFT  24

#define DRM_TIMEOUT_CLIENT2_TIMEOUT_MASK  0x000000ff
#define DRM_TIMEOUT_CLIENT0_TIMEOUT_MASK  0x0000ff00
#define DRM_TIMEOUT_CLIENT1_TIMEOUT_MASK  0x00ff0000
#define DRM_TIMEOUT_CLIENT3_TIMEOUT_MASK  0xff000000

#define DRM_TIMEOUT_MASK \
      (DRM_TIMEOUT_CLIENT2_TIMEOUT_MASK | \
      DRM_TIMEOUT_CLIENT0_TIMEOUT_MASK | \
      DRM_TIMEOUT_CLIENT1_TIMEOUT_MASK | \
      DRM_TIMEOUT_CLIENT3_TIMEOUT_MASK)

#define DRM_TIMEOUT_DEFAULT            0xffffffff

#define DRM_TIMEOUT_GET_CLIENT2_TIMEOUT(drm_timeout) \
      ((drm_timeout & DRM_TIMEOUT_CLIENT2_TIMEOUT_MASK) >> DRM_TIMEOUT_CLIENT2_TIMEOUT_SHIFT)
#define DRM_TIMEOUT_GET_CLIENT0_TIMEOUT(drm_timeout) \
      ((drm_timeout & DRM_TIMEOUT_CLIENT0_TIMEOUT_MASK) >> DRM_TIMEOUT_CLIENT0_TIMEOUT_SHIFT)
#define DRM_TIMEOUT_GET_CLIENT1_TIMEOUT(drm_timeout) \
      ((drm_timeout & DRM_TIMEOUT_CLIENT1_TIMEOUT_MASK) >> DRM_TIMEOUT_CLIENT1_TIMEOUT_SHIFT)
#define DRM_TIMEOUT_GET_CLIENT3_TIMEOUT(drm_timeout) \
      ((drm_timeout & DRM_TIMEOUT_CLIENT3_TIMEOUT_MASK) >> DRM_TIMEOUT_CLIENT3_TIMEOUT_SHIFT)

#define DRM_TIMEOUT_SET_CLIENT2_TIMEOUT(drm_timeout_reg, client2_timeout) \
      drm_timeout_reg = (drm_timeout_reg & ~DRM_TIMEOUT_CLIENT2_TIMEOUT_MASK) | (client2_timeout << DRM_TIMEOUT_CLIENT2_TIMEOUT_SHIFT)
#define DRM_TIMEOUT_SET_CLIENT0_TIMEOUT(drm_timeout_reg, client0_timeout) \
      drm_timeout_reg = (drm_timeout_reg & ~DRM_TIMEOUT_CLIENT0_TIMEOUT_MASK) | (client0_timeout << DRM_TIMEOUT_CLIENT0_TIMEOUT_SHIFT)
#define DRM_TIMEOUT_SET_CLIENT1_TIMEOUT(drm_timeout_reg, client1_timeout) \
      drm_timeout_reg = (drm_timeout_reg & ~DRM_TIMEOUT_CLIENT1_TIMEOUT_MASK) | (client1_timeout << DRM_TIMEOUT_CLIENT1_TIMEOUT_SHIFT)
#define DRM_TIMEOUT_SET_CLIENT3_TIMEOUT(drm_timeout_reg, client3_timeout) \
      drm_timeout_reg = (drm_timeout_reg & ~DRM_TIMEOUT_CLIENT3_TIMEOUT_MASK) | (client3_timeout << DRM_TIMEOUT_CLIENT3_TIMEOUT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_timeout_t {
            unsigned int client2_timeout                : DRM_TIMEOUT_CLIENT2_TIMEOUT_SIZE;
            unsigned int client0_timeout                : DRM_TIMEOUT_CLIENT0_TIMEOUT_SIZE;
            unsigned int client1_timeout                : DRM_TIMEOUT_CLIENT1_TIMEOUT_SIZE;
            unsigned int client3_timeout                : DRM_TIMEOUT_CLIENT3_TIMEOUT_SIZE;
      } drm_timeout_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_timeout_t {
            unsigned int client3_timeout                : DRM_TIMEOUT_CLIENT3_TIMEOUT_SIZE;
            unsigned int client1_timeout                : DRM_TIMEOUT_CLIENT1_TIMEOUT_SIZE;
            unsigned int client0_timeout                : DRM_TIMEOUT_CLIENT0_TIMEOUT_SIZE;
            unsigned int client2_timeout                : DRM_TIMEOUT_CLIENT2_TIMEOUT_SIZE;
      } drm_timeout_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_timeout_t f;
} drm_timeout_u;


/*
 * DRM_BYTESWAP struct
 */

#define DRM_BYTESWAP_REG_SIZE         32
#define DRM_BYTESWAP_CLIENT2_BYTESWAP_SIZE  1
#define DRM_BYTESWAP_CLIENT0_BYTESWAP_SIZE  1
#define DRM_BYTESWAP_CLIENT1_BYTESWAP_SIZE  1
#define DRM_BYTESWAP_CLIENT3_BYTESWAP_SIZE  1
#define DRM_BYTESWAP_CLIENT4_BYTESWAP_SIZE  1

#define DRM_BYTESWAP_CLIENT2_BYTESWAP_SHIFT  0
#define DRM_BYTESWAP_CLIENT0_BYTESWAP_SHIFT  8
#define DRM_BYTESWAP_CLIENT1_BYTESWAP_SHIFT  16
#define DRM_BYTESWAP_CLIENT3_BYTESWAP_SHIFT  24
#define DRM_BYTESWAP_CLIENT4_BYTESWAP_SHIFT  25

#define DRM_BYTESWAP_CLIENT2_BYTESWAP_MASK  0x00000001
#define DRM_BYTESWAP_CLIENT0_BYTESWAP_MASK  0x00000100
#define DRM_BYTESWAP_CLIENT1_BYTESWAP_MASK  0x00010000
#define DRM_BYTESWAP_CLIENT3_BYTESWAP_MASK  0x01000000
#define DRM_BYTESWAP_CLIENT4_BYTESWAP_MASK  0x02000000

#define DRM_BYTESWAP_MASK \
      (DRM_BYTESWAP_CLIENT2_BYTESWAP_MASK | \
      DRM_BYTESWAP_CLIENT0_BYTESWAP_MASK | \
      DRM_BYTESWAP_CLIENT1_BYTESWAP_MASK | \
      DRM_BYTESWAP_CLIENT3_BYTESWAP_MASK | \
      DRM_BYTESWAP_CLIENT4_BYTESWAP_MASK)

#define DRM_BYTESWAP_DEFAULT           0x00000000

#define DRM_BYTESWAP_GET_CLIENT2_BYTESWAP(drm_byteswap) \
      ((drm_byteswap & DRM_BYTESWAP_CLIENT2_BYTESWAP_MASK) >> DRM_BYTESWAP_CLIENT2_BYTESWAP_SHIFT)
#define DRM_BYTESWAP_GET_CLIENT0_BYTESWAP(drm_byteswap) \
      ((drm_byteswap & DRM_BYTESWAP_CLIENT0_BYTESWAP_MASK) >> DRM_BYTESWAP_CLIENT0_BYTESWAP_SHIFT)
#define DRM_BYTESWAP_GET_CLIENT1_BYTESWAP(drm_byteswap) \
      ((drm_byteswap & DRM_BYTESWAP_CLIENT1_BYTESWAP_MASK) >> DRM_BYTESWAP_CLIENT1_BYTESWAP_SHIFT)
#define DRM_BYTESWAP_GET_CLIENT3_BYTESWAP(drm_byteswap) \
      ((drm_byteswap & DRM_BYTESWAP_CLIENT3_BYTESWAP_MASK) >> DRM_BYTESWAP_CLIENT3_BYTESWAP_SHIFT)
#define DRM_BYTESWAP_GET_CLIENT4_BYTESWAP(drm_byteswap) \
      ((drm_byteswap & DRM_BYTESWAP_CLIENT4_BYTESWAP_MASK) >> DRM_BYTESWAP_CLIENT4_BYTESWAP_SHIFT)

#define DRM_BYTESWAP_SET_CLIENT2_BYTESWAP(drm_byteswap_reg, client2_byteswap) \
      drm_byteswap_reg = (drm_byteswap_reg & ~DRM_BYTESWAP_CLIENT2_BYTESWAP_MASK) | (client2_byteswap << DRM_BYTESWAP_CLIENT2_BYTESWAP_SHIFT)
#define DRM_BYTESWAP_SET_CLIENT0_BYTESWAP(drm_byteswap_reg, client0_byteswap) \
      drm_byteswap_reg = (drm_byteswap_reg & ~DRM_BYTESWAP_CLIENT0_BYTESWAP_MASK) | (client0_byteswap << DRM_BYTESWAP_CLIENT0_BYTESWAP_SHIFT)
#define DRM_BYTESWAP_SET_CLIENT1_BYTESWAP(drm_byteswap_reg, client1_byteswap) \
      drm_byteswap_reg = (drm_byteswap_reg & ~DRM_BYTESWAP_CLIENT1_BYTESWAP_MASK) | (client1_byteswap << DRM_BYTESWAP_CLIENT1_BYTESWAP_SHIFT)
#define DRM_BYTESWAP_SET_CLIENT3_BYTESWAP(drm_byteswap_reg, client3_byteswap) \
      drm_byteswap_reg = (drm_byteswap_reg & ~DRM_BYTESWAP_CLIENT3_BYTESWAP_MASK) | (client3_byteswap << DRM_BYTESWAP_CLIENT3_BYTESWAP_SHIFT)
#define DRM_BYTESWAP_SET_CLIENT4_BYTESWAP(drm_byteswap_reg, client4_byteswap) \
      drm_byteswap_reg = (drm_byteswap_reg & ~DRM_BYTESWAP_CLIENT4_BYTESWAP_MASK) | (client4_byteswap << DRM_BYTESWAP_CLIENT4_BYTESWAP_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_byteswap_t {
            unsigned int client2_byteswap               : DRM_BYTESWAP_CLIENT2_BYTESWAP_SIZE;
            unsigned int                                : 7;
            unsigned int client0_byteswap               : DRM_BYTESWAP_CLIENT0_BYTESWAP_SIZE;
            unsigned int                                : 7;
            unsigned int client1_byteswap               : DRM_BYTESWAP_CLIENT1_BYTESWAP_SIZE;
            unsigned int                                : 7;
            unsigned int client3_byteswap               : DRM_BYTESWAP_CLIENT3_BYTESWAP_SIZE;
            unsigned int client4_byteswap               : DRM_BYTESWAP_CLIENT4_BYTESWAP_SIZE;
            unsigned int                                : 6;
      } drm_byteswap_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_byteswap_t {
            unsigned int                                : 6;
            unsigned int client4_byteswap               : DRM_BYTESWAP_CLIENT4_BYTESWAP_SIZE;
            unsigned int client3_byteswap               : DRM_BYTESWAP_CLIENT3_BYTESWAP_SIZE;
            unsigned int                                : 7;
            unsigned int client1_byteswap               : DRM_BYTESWAP_CLIENT1_BYTESWAP_SIZE;
            unsigned int                                : 7;
            unsigned int client0_byteswap               : DRM_BYTESWAP_CLIENT0_BYTESWAP_SIZE;
            unsigned int                                : 7;
            unsigned int client2_byteswap               : DRM_BYTESWAP_CLIENT2_BYTESWAP_SIZE;
      } drm_byteswap_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_byteswap_t f;
} drm_byteswap_u;


/*
 * DRM_RESET struct
 */

#define DRM_RESET_REG_SIZE         32
#define DRM_RESET_CLIENT2_RESET_SIZE  1
#define DRM_RESET_CLIENT0_RESET_SIZE  1
#define DRM_RESET_CLIENT1_RESET_SIZE  1
#define DRM_RESET_CLIENT0_INVALID_CMD_SIZE  1
#define DRM_RESET_SPU_IF_RESET_SIZE  1
#define DRM_RESET_CLIENT3_RESET_SIZE  1
#define DRM_RESET_CLIENT4_RESET_SIZE  1
#define DRM_RESET_CLIENT1_INVALID_CMD_SIZE  1
#define DRM_RESET_CLIENT2_INVALID_CMD_SIZE  1
#define DRM_RESET_CLIENT3_INVALID_CMD_SIZE  1
#define DRM_RESET_CLIENT4_INVALID_CMD_SIZE  1
#define DRM_RESET_SPU_INVALID_CMD_SIZE  1

#define DRM_RESET_CLIENT2_RESET_SHIFT  0
#define DRM_RESET_CLIENT0_RESET_SHIFT  8
#define DRM_RESET_CLIENT1_RESET_SHIFT  16
#define DRM_RESET_CLIENT0_INVALID_CMD_SHIFT  23
#define DRM_RESET_SPU_IF_RESET_SHIFT  24
#define DRM_RESET_CLIENT3_RESET_SHIFT  25
#define DRM_RESET_CLIENT4_RESET_SHIFT  26
#define DRM_RESET_CLIENT1_INVALID_CMD_SHIFT  27
#define DRM_RESET_CLIENT2_INVALID_CMD_SHIFT  28
#define DRM_RESET_CLIENT3_INVALID_CMD_SHIFT  29
#define DRM_RESET_CLIENT4_INVALID_CMD_SHIFT  30
#define DRM_RESET_SPU_INVALID_CMD_SHIFT  31

#define DRM_RESET_CLIENT2_RESET_MASK    0x00000001
#define DRM_RESET_CLIENT0_RESET_MASK    0x00000100
#define DRM_RESET_CLIENT1_RESET_MASK    0x00010000
#define DRM_RESET_CLIENT0_INVALID_CMD_MASK  0x00800000
#define DRM_RESET_SPU_IF_RESET_MASK     0x01000000
#define DRM_RESET_CLIENT3_RESET_MASK    0x02000000
#define DRM_RESET_CLIENT4_RESET_MASK    0x04000000
#define DRM_RESET_CLIENT1_INVALID_CMD_MASK  0x08000000
#define DRM_RESET_CLIENT2_INVALID_CMD_MASK  0x10000000
#define DRM_RESET_CLIENT3_INVALID_CMD_MASK  0x20000000
#define DRM_RESET_CLIENT4_INVALID_CMD_MASK  0x40000000
#define DRM_RESET_SPU_INVALID_CMD_MASK  0x80000000

#define DRM_RESET_MASK \
      (DRM_RESET_CLIENT2_RESET_MASK | \
      DRM_RESET_CLIENT0_RESET_MASK | \
      DRM_RESET_CLIENT1_RESET_MASK | \
      DRM_RESET_CLIENT0_INVALID_CMD_MASK | \
      DRM_RESET_SPU_IF_RESET_MASK | \
      DRM_RESET_CLIENT3_RESET_MASK | \
      DRM_RESET_CLIENT4_RESET_MASK | \
      DRM_RESET_CLIENT1_INVALID_CMD_MASK | \
      DRM_RESET_CLIENT2_INVALID_CMD_MASK | \
      DRM_RESET_CLIENT3_INVALID_CMD_MASK | \
      DRM_RESET_CLIENT4_INVALID_CMD_MASK | \
      DRM_RESET_SPU_INVALID_CMD_MASK)

#define DRM_RESET_DEFAULT              0x00000000

#define DRM_RESET_GET_CLIENT2_RESET(drm_reset) \
      ((drm_reset & DRM_RESET_CLIENT2_RESET_MASK) >> DRM_RESET_CLIENT2_RESET_SHIFT)
#define DRM_RESET_GET_CLIENT0_RESET(drm_reset) \
      ((drm_reset & DRM_RESET_CLIENT0_RESET_MASK) >> DRM_RESET_CLIENT0_RESET_SHIFT)
#define DRM_RESET_GET_CLIENT1_RESET(drm_reset) \
      ((drm_reset & DRM_RESET_CLIENT1_RESET_MASK) >> DRM_RESET_CLIENT1_RESET_SHIFT)
#define DRM_RESET_GET_CLIENT0_INVALID_CMD(drm_reset) \
      ((drm_reset & DRM_RESET_CLIENT0_INVALID_CMD_MASK) >> DRM_RESET_CLIENT0_INVALID_CMD_SHIFT)
#define DRM_RESET_GET_SPU_IF_RESET(drm_reset) \
      ((drm_reset & DRM_RESET_SPU_IF_RESET_MASK) >> DRM_RESET_SPU_IF_RESET_SHIFT)
#define DRM_RESET_GET_CLIENT3_RESET(drm_reset) \
      ((drm_reset & DRM_RESET_CLIENT3_RESET_MASK) >> DRM_RESET_CLIENT3_RESET_SHIFT)
#define DRM_RESET_GET_CLIENT4_RESET(drm_reset) \
      ((drm_reset & DRM_RESET_CLIENT4_RESET_MASK) >> DRM_RESET_CLIENT4_RESET_SHIFT)
#define DRM_RESET_GET_CLIENT1_INVALID_CMD(drm_reset) \
      ((drm_reset & DRM_RESET_CLIENT1_INVALID_CMD_MASK) >> DRM_RESET_CLIENT1_INVALID_CMD_SHIFT)
#define DRM_RESET_GET_CLIENT2_INVALID_CMD(drm_reset) \
      ((drm_reset & DRM_RESET_CLIENT2_INVALID_CMD_MASK) >> DRM_RESET_CLIENT2_INVALID_CMD_SHIFT)
#define DRM_RESET_GET_CLIENT3_INVALID_CMD(drm_reset) \
      ((drm_reset & DRM_RESET_CLIENT3_INVALID_CMD_MASK) >> DRM_RESET_CLIENT3_INVALID_CMD_SHIFT)
#define DRM_RESET_GET_CLIENT4_INVALID_CMD(drm_reset) \
      ((drm_reset & DRM_RESET_CLIENT4_INVALID_CMD_MASK) >> DRM_RESET_CLIENT4_INVALID_CMD_SHIFT)
#define DRM_RESET_GET_SPU_INVALID_CMD(drm_reset) \
      ((drm_reset & DRM_RESET_SPU_INVALID_CMD_MASK) >> DRM_RESET_SPU_INVALID_CMD_SHIFT)

#define DRM_RESET_SET_CLIENT2_RESET(drm_reset_reg, client2_reset) \
      drm_reset_reg = (drm_reset_reg & ~DRM_RESET_CLIENT2_RESET_MASK) | (client2_reset << DRM_RESET_CLIENT2_RESET_SHIFT)
#define DRM_RESET_SET_CLIENT0_RESET(drm_reset_reg, client0_reset) \
      drm_reset_reg = (drm_reset_reg & ~DRM_RESET_CLIENT0_RESET_MASK) | (client0_reset << DRM_RESET_CLIENT0_RESET_SHIFT)
#define DRM_RESET_SET_CLIENT1_RESET(drm_reset_reg, client1_reset) \
      drm_reset_reg = (drm_reset_reg & ~DRM_RESET_CLIENT1_RESET_MASK) | (client1_reset << DRM_RESET_CLIENT1_RESET_SHIFT)
#define DRM_RESET_SET_CLIENT0_INVALID_CMD(drm_reset_reg, client0_invalid_cmd) \
      drm_reset_reg = (drm_reset_reg & ~DRM_RESET_CLIENT0_INVALID_CMD_MASK) | (client0_invalid_cmd << DRM_RESET_CLIENT0_INVALID_CMD_SHIFT)
#define DRM_RESET_SET_SPU_IF_RESET(drm_reset_reg, spu_if_reset) \
      drm_reset_reg = (drm_reset_reg & ~DRM_RESET_SPU_IF_RESET_MASK) | (spu_if_reset << DRM_RESET_SPU_IF_RESET_SHIFT)
#define DRM_RESET_SET_CLIENT3_RESET(drm_reset_reg, client3_reset) \
      drm_reset_reg = (drm_reset_reg & ~DRM_RESET_CLIENT3_RESET_MASK) | (client3_reset << DRM_RESET_CLIENT3_RESET_SHIFT)
#define DRM_RESET_SET_CLIENT4_RESET(drm_reset_reg, client4_reset) \
      drm_reset_reg = (drm_reset_reg & ~DRM_RESET_CLIENT4_RESET_MASK) | (client4_reset << DRM_RESET_CLIENT4_RESET_SHIFT)
#define DRM_RESET_SET_CLIENT1_INVALID_CMD(drm_reset_reg, client1_invalid_cmd) \
      drm_reset_reg = (drm_reset_reg & ~DRM_RESET_CLIENT1_INVALID_CMD_MASK) | (client1_invalid_cmd << DRM_RESET_CLIENT1_INVALID_CMD_SHIFT)
#define DRM_RESET_SET_CLIENT2_INVALID_CMD(drm_reset_reg, client2_invalid_cmd) \
      drm_reset_reg = (drm_reset_reg & ~DRM_RESET_CLIENT2_INVALID_CMD_MASK) | (client2_invalid_cmd << DRM_RESET_CLIENT2_INVALID_CMD_SHIFT)
#define DRM_RESET_SET_CLIENT3_INVALID_CMD(drm_reset_reg, client3_invalid_cmd) \
      drm_reset_reg = (drm_reset_reg & ~DRM_RESET_CLIENT3_INVALID_CMD_MASK) | (client3_invalid_cmd << DRM_RESET_CLIENT3_INVALID_CMD_SHIFT)
#define DRM_RESET_SET_CLIENT4_INVALID_CMD(drm_reset_reg, client4_invalid_cmd) \
      drm_reset_reg = (drm_reset_reg & ~DRM_RESET_CLIENT4_INVALID_CMD_MASK) | (client4_invalid_cmd << DRM_RESET_CLIENT4_INVALID_CMD_SHIFT)
#define DRM_RESET_SET_SPU_INVALID_CMD(drm_reset_reg, spu_invalid_cmd) \
      drm_reset_reg = (drm_reset_reg & ~DRM_RESET_SPU_INVALID_CMD_MASK) | (spu_invalid_cmd << DRM_RESET_SPU_INVALID_CMD_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_reset_t {
            unsigned int client2_reset                  : DRM_RESET_CLIENT2_RESET_SIZE;
            unsigned int                                : 7;
            unsigned int client0_reset                  : DRM_RESET_CLIENT0_RESET_SIZE;
            unsigned int                                : 7;
            unsigned int client1_reset                  : DRM_RESET_CLIENT1_RESET_SIZE;
            unsigned int                                : 6;
            unsigned int client0_invalid_cmd            : DRM_RESET_CLIENT0_INVALID_CMD_SIZE;
            unsigned int spu_if_reset                   : DRM_RESET_SPU_IF_RESET_SIZE;
            unsigned int client3_reset                  : DRM_RESET_CLIENT3_RESET_SIZE;
            unsigned int client4_reset                  : DRM_RESET_CLIENT4_RESET_SIZE;
            unsigned int client1_invalid_cmd            : DRM_RESET_CLIENT1_INVALID_CMD_SIZE;
            unsigned int client2_invalid_cmd            : DRM_RESET_CLIENT2_INVALID_CMD_SIZE;
            unsigned int client3_invalid_cmd            : DRM_RESET_CLIENT3_INVALID_CMD_SIZE;
            unsigned int client4_invalid_cmd            : DRM_RESET_CLIENT4_INVALID_CMD_SIZE;
            unsigned int spu_invalid_cmd                : DRM_RESET_SPU_INVALID_CMD_SIZE;
      } drm_reset_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_reset_t {
            unsigned int spu_invalid_cmd                : DRM_RESET_SPU_INVALID_CMD_SIZE;
            unsigned int client4_invalid_cmd            : DRM_RESET_CLIENT4_INVALID_CMD_SIZE;
            unsigned int client3_invalid_cmd            : DRM_RESET_CLIENT3_INVALID_CMD_SIZE;
            unsigned int client2_invalid_cmd            : DRM_RESET_CLIENT2_INVALID_CMD_SIZE;
            unsigned int client1_invalid_cmd            : DRM_RESET_CLIENT1_INVALID_CMD_SIZE;
            unsigned int client4_reset                  : DRM_RESET_CLIENT4_RESET_SIZE;
            unsigned int client3_reset                  : DRM_RESET_CLIENT3_RESET_SIZE;
            unsigned int spu_if_reset                   : DRM_RESET_SPU_IF_RESET_SIZE;
            unsigned int client0_invalid_cmd            : DRM_RESET_CLIENT0_INVALID_CMD_SIZE;
            unsigned int                                : 6;
            unsigned int client1_reset                  : DRM_RESET_CLIENT1_RESET_SIZE;
            unsigned int                                : 7;
            unsigned int client0_reset                  : DRM_RESET_CLIENT0_RESET_SIZE;
            unsigned int                                : 7;
            unsigned int client2_reset                  : DRM_RESET_CLIENT2_RESET_SIZE;
      } drm_reset_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_reset_t f;
} drm_reset_u;


/*
 * DRM_ARB_PRIORITY struct
 */

#define DRM_ARB_PRIORITY_REG_SIZE         32
#define DRM_ARB_PRIORITY_SLOT0_SIZE  4
#define DRM_ARB_PRIORITY_SLOT1_SIZE  4
#define DRM_ARB_PRIORITY_SLOT2_SIZE  4
#define DRM_ARB_PRIORITY_SLOT3_SIZE  4
#define DRM_ARB_PRIORITY_SLOT4_SIZE  4
#define DRM_ARB_PRIORITY_SLOT5_SIZE  4
#define DRM_ARB_PRIORITY_SLOT6_SIZE  4
#define DRM_ARB_PRIORITY_SLOT7_SIZE  4

#define DRM_ARB_PRIORITY_SLOT0_SHIFT  0
#define DRM_ARB_PRIORITY_SLOT1_SHIFT  4
#define DRM_ARB_PRIORITY_SLOT2_SHIFT  8
#define DRM_ARB_PRIORITY_SLOT3_SHIFT  12
#define DRM_ARB_PRIORITY_SLOT4_SHIFT  16
#define DRM_ARB_PRIORITY_SLOT5_SHIFT  20
#define DRM_ARB_PRIORITY_SLOT6_SHIFT  24
#define DRM_ARB_PRIORITY_SLOT7_SHIFT  28

#define DRM_ARB_PRIORITY_SLOT0_MASK     0x0000000f
#define DRM_ARB_PRIORITY_SLOT1_MASK     0x000000f0
#define DRM_ARB_PRIORITY_SLOT2_MASK     0x00000f00
#define DRM_ARB_PRIORITY_SLOT3_MASK     0x0000f000
#define DRM_ARB_PRIORITY_SLOT4_MASK     0x000f0000
#define DRM_ARB_PRIORITY_SLOT5_MASK     0x00f00000
#define DRM_ARB_PRIORITY_SLOT6_MASK     0x0f000000
#define DRM_ARB_PRIORITY_SLOT7_MASK     0xf0000000

#define DRM_ARB_PRIORITY_MASK \
      (DRM_ARB_PRIORITY_SLOT0_MASK | \
      DRM_ARB_PRIORITY_SLOT1_MASK | \
      DRM_ARB_PRIORITY_SLOT2_MASK | \
      DRM_ARB_PRIORITY_SLOT3_MASK | \
      DRM_ARB_PRIORITY_SLOT4_MASK | \
      DRM_ARB_PRIORITY_SLOT5_MASK | \
      DRM_ARB_PRIORITY_SLOT6_MASK | \
      DRM_ARB_PRIORITY_SLOT7_MASK)

#define DRM_ARB_PRIORITY_DEFAULT       0xfff01234

#define DRM_ARB_PRIORITY_GET_SLOT0(drm_arb_priority) \
      ((drm_arb_priority & DRM_ARB_PRIORITY_SLOT0_MASK) >> DRM_ARB_PRIORITY_SLOT0_SHIFT)
#define DRM_ARB_PRIORITY_GET_SLOT1(drm_arb_priority) \
      ((drm_arb_priority & DRM_ARB_PRIORITY_SLOT1_MASK) >> DRM_ARB_PRIORITY_SLOT1_SHIFT)
#define DRM_ARB_PRIORITY_GET_SLOT2(drm_arb_priority) \
      ((drm_arb_priority & DRM_ARB_PRIORITY_SLOT2_MASK) >> DRM_ARB_PRIORITY_SLOT2_SHIFT)
#define DRM_ARB_PRIORITY_GET_SLOT3(drm_arb_priority) \
      ((drm_arb_priority & DRM_ARB_PRIORITY_SLOT3_MASK) >> DRM_ARB_PRIORITY_SLOT3_SHIFT)
#define DRM_ARB_PRIORITY_GET_SLOT4(drm_arb_priority) \
      ((drm_arb_priority & DRM_ARB_PRIORITY_SLOT4_MASK) >> DRM_ARB_PRIORITY_SLOT4_SHIFT)
#define DRM_ARB_PRIORITY_GET_SLOT5(drm_arb_priority) \
      ((drm_arb_priority & DRM_ARB_PRIORITY_SLOT5_MASK) >> DRM_ARB_PRIORITY_SLOT5_SHIFT)
#define DRM_ARB_PRIORITY_GET_SLOT6(drm_arb_priority) \
      ((drm_arb_priority & DRM_ARB_PRIORITY_SLOT6_MASK) >> DRM_ARB_PRIORITY_SLOT6_SHIFT)
#define DRM_ARB_PRIORITY_GET_SLOT7(drm_arb_priority) \
      ((drm_arb_priority & DRM_ARB_PRIORITY_SLOT7_MASK) >> DRM_ARB_PRIORITY_SLOT7_SHIFT)

#define DRM_ARB_PRIORITY_SET_SLOT0(drm_arb_priority_reg, slot0) \
      drm_arb_priority_reg = (drm_arb_priority_reg & ~DRM_ARB_PRIORITY_SLOT0_MASK) | (slot0 << DRM_ARB_PRIORITY_SLOT0_SHIFT)
#define DRM_ARB_PRIORITY_SET_SLOT1(drm_arb_priority_reg, slot1) \
      drm_arb_priority_reg = (drm_arb_priority_reg & ~DRM_ARB_PRIORITY_SLOT1_MASK) | (slot1 << DRM_ARB_PRIORITY_SLOT1_SHIFT)
#define DRM_ARB_PRIORITY_SET_SLOT2(drm_arb_priority_reg, slot2) \
      drm_arb_priority_reg = (drm_arb_priority_reg & ~DRM_ARB_PRIORITY_SLOT2_MASK) | (slot2 << DRM_ARB_PRIORITY_SLOT2_SHIFT)
#define DRM_ARB_PRIORITY_SET_SLOT3(drm_arb_priority_reg, slot3) \
      drm_arb_priority_reg = (drm_arb_priority_reg & ~DRM_ARB_PRIORITY_SLOT3_MASK) | (slot3 << DRM_ARB_PRIORITY_SLOT3_SHIFT)
#define DRM_ARB_PRIORITY_SET_SLOT4(drm_arb_priority_reg, slot4) \
      drm_arb_priority_reg = (drm_arb_priority_reg & ~DRM_ARB_PRIORITY_SLOT4_MASK) | (slot4 << DRM_ARB_PRIORITY_SLOT4_SHIFT)
#define DRM_ARB_PRIORITY_SET_SLOT5(drm_arb_priority_reg, slot5) \
      drm_arb_priority_reg = (drm_arb_priority_reg & ~DRM_ARB_PRIORITY_SLOT5_MASK) | (slot5 << DRM_ARB_PRIORITY_SLOT5_SHIFT)
#define DRM_ARB_PRIORITY_SET_SLOT6(drm_arb_priority_reg, slot6) \
      drm_arb_priority_reg = (drm_arb_priority_reg & ~DRM_ARB_PRIORITY_SLOT6_MASK) | (slot6 << DRM_ARB_PRIORITY_SLOT6_SHIFT)
#define DRM_ARB_PRIORITY_SET_SLOT7(drm_arb_priority_reg, slot7) \
      drm_arb_priority_reg = (drm_arb_priority_reg & ~DRM_ARB_PRIORITY_SLOT7_MASK) | (slot7 << DRM_ARB_PRIORITY_SLOT7_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_arb_priority_t {
            unsigned int slot0                          : DRM_ARB_PRIORITY_SLOT0_SIZE;
            unsigned int slot1                          : DRM_ARB_PRIORITY_SLOT1_SIZE;
            unsigned int slot2                          : DRM_ARB_PRIORITY_SLOT2_SIZE;
            unsigned int slot3                          : DRM_ARB_PRIORITY_SLOT3_SIZE;
            unsigned int slot4                          : DRM_ARB_PRIORITY_SLOT4_SIZE;
            unsigned int slot5                          : DRM_ARB_PRIORITY_SLOT5_SIZE;
            unsigned int slot6                          : DRM_ARB_PRIORITY_SLOT6_SIZE;
            unsigned int slot7                          : DRM_ARB_PRIORITY_SLOT7_SIZE;
      } drm_arb_priority_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_arb_priority_t {
            unsigned int slot7                          : DRM_ARB_PRIORITY_SLOT7_SIZE;
            unsigned int slot6                          : DRM_ARB_PRIORITY_SLOT6_SIZE;
            unsigned int slot5                          : DRM_ARB_PRIORITY_SLOT5_SIZE;
            unsigned int slot4                          : DRM_ARB_PRIORITY_SLOT4_SIZE;
            unsigned int slot3                          : DRM_ARB_PRIORITY_SLOT3_SIZE;
            unsigned int slot2                          : DRM_ARB_PRIORITY_SLOT2_SIZE;
            unsigned int slot1                          : DRM_ARB_PRIORITY_SLOT1_SIZE;
            unsigned int slot0                          : DRM_ARB_PRIORITY_SLOT0_SIZE;
      } drm_arb_priority_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_arb_priority_t f;
} drm_arb_priority_u;


/*
 * DRM_TRNG_CNTL struct
 */

#define DRM_TRNG_CNTL_REG_SIZE         32
#define DRM_TRNG_CNTL_EN_OSC_SIZE  1
#define DRM_TRNG_CNTL_EN_LFSR_SIZE  1
#define DRM_TRNG_CNTL_EN_OUT_SIZE  1

#define DRM_TRNG_CNTL_EN_OSC_SHIFT  0
#define DRM_TRNG_CNTL_EN_LFSR_SHIFT  1
#define DRM_TRNG_CNTL_EN_OUT_SHIFT  8

#define DRM_TRNG_CNTL_EN_OSC_MASK       0x00000001
#define DRM_TRNG_CNTL_EN_LFSR_MASK      0x00000002
#define DRM_TRNG_CNTL_EN_OUT_MASK       0x00000100

#define DRM_TRNG_CNTL_MASK \
      (DRM_TRNG_CNTL_EN_OSC_MASK | \
      DRM_TRNG_CNTL_EN_LFSR_MASK | \
      DRM_TRNG_CNTL_EN_OUT_MASK)

#define DRM_TRNG_CNTL_DEFAULT          0x00000000

#define DRM_TRNG_CNTL_GET_EN_OSC(drm_trng_cntl) \
      ((drm_trng_cntl & DRM_TRNG_CNTL_EN_OSC_MASK) >> DRM_TRNG_CNTL_EN_OSC_SHIFT)
#define DRM_TRNG_CNTL_GET_EN_LFSR(drm_trng_cntl) \
      ((drm_trng_cntl & DRM_TRNG_CNTL_EN_LFSR_MASK) >> DRM_TRNG_CNTL_EN_LFSR_SHIFT)
#define DRM_TRNG_CNTL_GET_EN_OUT(drm_trng_cntl) \
      ((drm_trng_cntl & DRM_TRNG_CNTL_EN_OUT_MASK) >> DRM_TRNG_CNTL_EN_OUT_SHIFT)

#define DRM_TRNG_CNTL_SET_EN_OSC(drm_trng_cntl_reg, en_osc) \
      drm_trng_cntl_reg = (drm_trng_cntl_reg & ~DRM_TRNG_CNTL_EN_OSC_MASK) | (en_osc << DRM_TRNG_CNTL_EN_OSC_SHIFT)
#define DRM_TRNG_CNTL_SET_EN_LFSR(drm_trng_cntl_reg, en_lfsr) \
      drm_trng_cntl_reg = (drm_trng_cntl_reg & ~DRM_TRNG_CNTL_EN_LFSR_MASK) | (en_lfsr << DRM_TRNG_CNTL_EN_LFSR_SHIFT)
#define DRM_TRNG_CNTL_SET_EN_OUT(drm_trng_cntl_reg, en_out) \
      drm_trng_cntl_reg = (drm_trng_cntl_reg & ~DRM_TRNG_CNTL_EN_OUT_MASK) | (en_out << DRM_TRNG_CNTL_EN_OUT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_trng_cntl_t {
            unsigned int en_osc                         : DRM_TRNG_CNTL_EN_OSC_SIZE;
            unsigned int en_lfsr                        : DRM_TRNG_CNTL_EN_LFSR_SIZE;
            unsigned int                                : 6;
            unsigned int en_out                         : DRM_TRNG_CNTL_EN_OUT_SIZE;
            unsigned int                                : 23;
      } drm_trng_cntl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_trng_cntl_t {
            unsigned int                                : 23;
            unsigned int en_out                         : DRM_TRNG_CNTL_EN_OUT_SIZE;
            unsigned int                                : 6;
            unsigned int en_lfsr                        : DRM_TRNG_CNTL_EN_LFSR_SIZE;
            unsigned int en_osc                         : DRM_TRNG_CNTL_EN_OSC_SIZE;
      } drm_trng_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_trng_cntl_t f;
} drm_trng_cntl_u;


/*
 * DRM_TRNG_DATA struct
 */

#define DRM_TRNG_DATA_REG_SIZE         32
#define DRM_TRNG_DATA_RNG_VAL_SIZE  32

#define DRM_TRNG_DATA_RNG_VAL_SHIFT  0

#define DRM_TRNG_DATA_RNG_VAL_MASK      0xffffffff

#define DRM_TRNG_DATA_MASK \
      (DRM_TRNG_DATA_RNG_VAL_MASK)

#define DRM_TRNG_DATA_DEFAULT          0xffffffff

#define DRM_TRNG_DATA_GET_RNG_VAL(drm_trng_data) \
      ((drm_trng_data & DRM_TRNG_DATA_RNG_VAL_MASK) >> DRM_TRNG_DATA_RNG_VAL_SHIFT)

#define DRM_TRNG_DATA_SET_RNG_VAL(drm_trng_data_reg, rng_val) \
      drm_trng_data_reg = (drm_trng_data_reg & ~DRM_TRNG_DATA_RNG_VAL_MASK) | (rng_val << DRM_TRNG_DATA_RNG_VAL_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_trng_data_t {
            unsigned int rng_val                        : DRM_TRNG_DATA_RNG_VAL_SIZE;
      } drm_trng_data_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_trng_data_t {
            unsigned int rng_val                        : DRM_TRNG_DATA_RNG_VAL_SIZE;
      } drm_trng_data_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_trng_data_t f;
} drm_trng_data_u;


/*
 * DRM_PERFMON_CNTL struct
 */

#define DRM_PERFMON_CNTL_REG_SIZE         32
#define DRM_PERFMON_CNTL_PERFMON_STATE_SIZE  4

#define DRM_PERFMON_CNTL_PERFMON_STATE_SHIFT  0

#define DRM_PERFMON_CNTL_PERFMON_STATE_MASK  0x0000000f

#define DRM_PERFMON_CNTL_MASK \
      (DRM_PERFMON_CNTL_PERFMON_STATE_MASK)

#define DRM_PERFMON_CNTL_DEFAULT       0x00000002

#define DRM_PERFMON_CNTL_GET_PERFMON_STATE(drm_perfmon_cntl) \
      ((drm_perfmon_cntl & DRM_PERFMON_CNTL_PERFMON_STATE_MASK) >> DRM_PERFMON_CNTL_PERFMON_STATE_SHIFT)

#define DRM_PERFMON_CNTL_SET_PERFMON_STATE(drm_perfmon_cntl_reg, perfmon_state) \
      drm_perfmon_cntl_reg = (drm_perfmon_cntl_reg & ~DRM_PERFMON_CNTL_PERFMON_STATE_MASK) | (perfmon_state << DRM_PERFMON_CNTL_PERFMON_STATE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_perfmon_cntl_t {
            unsigned int perfmon_state                  : DRM_PERFMON_CNTL_PERFMON_STATE_SIZE;
            unsigned int                                : 28;
      } drm_perfmon_cntl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_perfmon_cntl_t {
            unsigned int                                : 28;
            unsigned int perfmon_state                  : DRM_PERFMON_CNTL_PERFMON_STATE_SIZE;
      } drm_perfmon_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_perfmon_cntl_t f;
} drm_perfmon_cntl_u;


/*
 * DRM_PERFCOUNTER1_SELECT struct
 */

#define DRM_PERFCOUNTER1_SELECT_REG_SIZE         32
#define DRM_PERFCOUNTER1_SELECT_PERFCOUNTER1_SELECT_SIZE  6

#define DRM_PERFCOUNTER1_SELECT_PERFCOUNTER1_SELECT_SHIFT  0

#define DRM_PERFCOUNTER1_SELECT_PERFCOUNTER1_SELECT_MASK  0x0000003f

#define DRM_PERFCOUNTER1_SELECT_MASK \
      (DRM_PERFCOUNTER1_SELECT_PERFCOUNTER1_SELECT_MASK)

#define DRM_PERFCOUNTER1_SELECT_DEFAULT 0x00000000

#define DRM_PERFCOUNTER1_SELECT_GET_PERFCOUNTER1_SELECT(drm_perfcounter1_select) \
      ((drm_perfcounter1_select & DRM_PERFCOUNTER1_SELECT_PERFCOUNTER1_SELECT_MASK) >> DRM_PERFCOUNTER1_SELECT_PERFCOUNTER1_SELECT_SHIFT)

#define DRM_PERFCOUNTER1_SELECT_SET_PERFCOUNTER1_SELECT(drm_perfcounter1_select_reg, perfcounter1_select) \
      drm_perfcounter1_select_reg = (drm_perfcounter1_select_reg & ~DRM_PERFCOUNTER1_SELECT_PERFCOUNTER1_SELECT_MASK) | (perfcounter1_select << DRM_PERFCOUNTER1_SELECT_PERFCOUNTER1_SELECT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_perfcounter1_select_t {
            unsigned int perfcounter1_select            : DRM_PERFCOUNTER1_SELECT_PERFCOUNTER1_SELECT_SIZE;
            unsigned int                                : 26;
      } drm_perfcounter1_select_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_perfcounter1_select_t {
            unsigned int                                : 26;
            unsigned int perfcounter1_select            : DRM_PERFCOUNTER1_SELECT_PERFCOUNTER1_SELECT_SIZE;
      } drm_perfcounter1_select_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_perfcounter1_select_t f;
} drm_perfcounter1_select_u;


/*
 * DRM_PERFCOUNTER2_SELECT struct
 */

#define DRM_PERFCOUNTER2_SELECT_REG_SIZE         32
#define DRM_PERFCOUNTER2_SELECT_PERFCOUNTER2_SELECT_SIZE  6

#define DRM_PERFCOUNTER2_SELECT_PERFCOUNTER2_SELECT_SHIFT  0

#define DRM_PERFCOUNTER2_SELECT_PERFCOUNTER2_SELECT_MASK  0x0000003f

#define DRM_PERFCOUNTER2_SELECT_MASK \
      (DRM_PERFCOUNTER2_SELECT_PERFCOUNTER2_SELECT_MASK)

#define DRM_PERFCOUNTER2_SELECT_DEFAULT 0x00000000

#define DRM_PERFCOUNTER2_SELECT_GET_PERFCOUNTER2_SELECT(drm_perfcounter2_select) \
      ((drm_perfcounter2_select & DRM_PERFCOUNTER2_SELECT_PERFCOUNTER2_SELECT_MASK) >> DRM_PERFCOUNTER2_SELECT_PERFCOUNTER2_SELECT_SHIFT)

#define DRM_PERFCOUNTER2_SELECT_SET_PERFCOUNTER2_SELECT(drm_perfcounter2_select_reg, perfcounter2_select) \
      drm_perfcounter2_select_reg = (drm_perfcounter2_select_reg & ~DRM_PERFCOUNTER2_SELECT_PERFCOUNTER2_SELECT_MASK) | (perfcounter2_select << DRM_PERFCOUNTER2_SELECT_PERFCOUNTER2_SELECT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_perfcounter2_select_t {
            unsigned int perfcounter2_select            : DRM_PERFCOUNTER2_SELECT_PERFCOUNTER2_SELECT_SIZE;
            unsigned int                                : 26;
      } drm_perfcounter2_select_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_perfcounter2_select_t {
            unsigned int                                : 26;
            unsigned int perfcounter2_select            : DRM_PERFCOUNTER2_SELECT_PERFCOUNTER2_SELECT_SIZE;
      } drm_perfcounter2_select_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_perfcounter2_select_t f;
} drm_perfcounter2_select_u;


/*
 * DRM_PERFCOUNTER1_LO struct
 */

#define DRM_PERFCOUNTER1_LO_REG_SIZE         32
#define DRM_PERFCOUNTER1_LO_LO_SIZE  32

#define DRM_PERFCOUNTER1_LO_LO_SHIFT  0

#define DRM_PERFCOUNTER1_LO_LO_MASK     0xffffffff

#define DRM_PERFCOUNTER1_LO_MASK \
      (DRM_PERFCOUNTER1_LO_LO_MASK)

#define DRM_PERFCOUNTER1_LO_DEFAULT    0x00000000

#define DRM_PERFCOUNTER1_LO_GET_LO(drm_perfcounter1_lo) \
      ((drm_perfcounter1_lo & DRM_PERFCOUNTER1_LO_LO_MASK) >> DRM_PERFCOUNTER1_LO_LO_SHIFT)

#define DRM_PERFCOUNTER1_LO_SET_LO(drm_perfcounter1_lo_reg, lo) \
      drm_perfcounter1_lo_reg = (drm_perfcounter1_lo_reg & ~DRM_PERFCOUNTER1_LO_LO_MASK) | (lo << DRM_PERFCOUNTER1_LO_LO_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_perfcounter1_lo_t {
            unsigned int lo                             : DRM_PERFCOUNTER1_LO_LO_SIZE;
      } drm_perfcounter1_lo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_perfcounter1_lo_t {
            unsigned int lo                             : DRM_PERFCOUNTER1_LO_LO_SIZE;
      } drm_perfcounter1_lo_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_perfcounter1_lo_t f;
} drm_perfcounter1_lo_u;


/*
 * DRM_PERFCOUNTER1_HI struct
 */

#define DRM_PERFCOUNTER1_HI_REG_SIZE         32
#define DRM_PERFCOUNTER1_HI_HI_SIZE  16

#define DRM_PERFCOUNTER1_HI_HI_SHIFT  0

#define DRM_PERFCOUNTER1_HI_HI_MASK     0x0000ffff

#define DRM_PERFCOUNTER1_HI_MASK \
      (DRM_PERFCOUNTER1_HI_HI_MASK)

#define DRM_PERFCOUNTER1_HI_DEFAULT    0x00000000

#define DRM_PERFCOUNTER1_HI_GET_HI(drm_perfcounter1_hi) \
      ((drm_perfcounter1_hi & DRM_PERFCOUNTER1_HI_HI_MASK) >> DRM_PERFCOUNTER1_HI_HI_SHIFT)

#define DRM_PERFCOUNTER1_HI_SET_HI(drm_perfcounter1_hi_reg, hi) \
      drm_perfcounter1_hi_reg = (drm_perfcounter1_hi_reg & ~DRM_PERFCOUNTER1_HI_HI_MASK) | (hi << DRM_PERFCOUNTER1_HI_HI_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_perfcounter1_hi_t {
            unsigned int hi                             : DRM_PERFCOUNTER1_HI_HI_SIZE;
            unsigned int                                : 16;
      } drm_perfcounter1_hi_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_perfcounter1_hi_t {
            unsigned int                                : 16;
            unsigned int hi                             : DRM_PERFCOUNTER1_HI_HI_SIZE;
      } drm_perfcounter1_hi_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_perfcounter1_hi_t f;
} drm_perfcounter1_hi_u;


/*
 * DRM_PERFCOUNTER2_LO struct
 */

#define DRM_PERFCOUNTER2_LO_REG_SIZE         32
#define DRM_PERFCOUNTER2_LO_LO_SIZE  32

#define DRM_PERFCOUNTER2_LO_LO_SHIFT  0

#define DRM_PERFCOUNTER2_LO_LO_MASK     0xffffffff

#define DRM_PERFCOUNTER2_LO_MASK \
      (DRM_PERFCOUNTER2_LO_LO_MASK)

#define DRM_PERFCOUNTER2_LO_DEFAULT    0x00000000

#define DRM_PERFCOUNTER2_LO_GET_LO(drm_perfcounter2_lo) \
      ((drm_perfcounter2_lo & DRM_PERFCOUNTER2_LO_LO_MASK) >> DRM_PERFCOUNTER2_LO_LO_SHIFT)

#define DRM_PERFCOUNTER2_LO_SET_LO(drm_perfcounter2_lo_reg, lo) \
      drm_perfcounter2_lo_reg = (drm_perfcounter2_lo_reg & ~DRM_PERFCOUNTER2_LO_LO_MASK) | (lo << DRM_PERFCOUNTER2_LO_LO_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_perfcounter2_lo_t {
            unsigned int lo                             : DRM_PERFCOUNTER2_LO_LO_SIZE;
      } drm_perfcounter2_lo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_perfcounter2_lo_t {
            unsigned int lo                             : DRM_PERFCOUNTER2_LO_LO_SIZE;
      } drm_perfcounter2_lo_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_perfcounter2_lo_t f;
} drm_perfcounter2_lo_u;


/*
 * DRM_PERFCOUNTER2_HI struct
 */

#define DRM_PERFCOUNTER2_HI_REG_SIZE         32
#define DRM_PERFCOUNTER2_HI_HI_SIZE  16

#define DRM_PERFCOUNTER2_HI_HI_SHIFT  0

#define DRM_PERFCOUNTER2_HI_HI_MASK     0x0000ffff

#define DRM_PERFCOUNTER2_HI_MASK \
      (DRM_PERFCOUNTER2_HI_HI_MASK)

#define DRM_PERFCOUNTER2_HI_DEFAULT    0x00000000

#define DRM_PERFCOUNTER2_HI_GET_HI(drm_perfcounter2_hi) \
      ((drm_perfcounter2_hi & DRM_PERFCOUNTER2_HI_HI_MASK) >> DRM_PERFCOUNTER2_HI_HI_SHIFT)

#define DRM_PERFCOUNTER2_HI_SET_HI(drm_perfcounter2_hi_reg, hi) \
      drm_perfcounter2_hi_reg = (drm_perfcounter2_hi_reg & ~DRM_PERFCOUNTER2_HI_HI_MASK) | (hi << DRM_PERFCOUNTER2_HI_HI_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_perfcounter2_hi_t {
            unsigned int hi                             : DRM_PERFCOUNTER2_HI_HI_SIZE;
            unsigned int                                : 16;
      } drm_perfcounter2_hi_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_perfcounter2_hi_t {
            unsigned int                                : 16;
            unsigned int hi                             : DRM_PERFCOUNTER2_HI_HI_SIZE;
      } drm_perfcounter2_hi_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_perfcounter2_hi_t f;
} drm_perfcounter2_hi_u;


/*
 * DRM_DEBUG struct
 */

#define DRM_DEBUG_REG_SIZE         32
#define DRM_DEBUG_DEBUG_UNUSED_0_SIZE  24
#define DRM_DEBUG_DEBUG_BUS_SELECT_SIZE  6
#define DRM_DEBUG_DEBUG_UNUSED_1_SIZE  2

#define DRM_DEBUG_DEBUG_UNUSED_0_SHIFT  0
#define DRM_DEBUG_DEBUG_BUS_SELECT_SHIFT  24
#define DRM_DEBUG_DEBUG_UNUSED_1_SHIFT  30

#define DRM_DEBUG_DEBUG_UNUSED_0_MASK   0x00ffffff
#define DRM_DEBUG_DEBUG_BUS_SELECT_MASK  0x3f000000
#define DRM_DEBUG_DEBUG_UNUSED_1_MASK   0xc0000000

#define DRM_DEBUG_MASK \
      (DRM_DEBUG_DEBUG_UNUSED_0_MASK | \
      DRM_DEBUG_DEBUG_BUS_SELECT_MASK | \
      DRM_DEBUG_DEBUG_UNUSED_1_MASK)

#define DRM_DEBUG_DEFAULT              0x00000000

#define DRM_DEBUG_GET_DEBUG_UNUSED_0(drm_debug) \
      ((drm_debug & DRM_DEBUG_DEBUG_UNUSED_0_MASK) >> DRM_DEBUG_DEBUG_UNUSED_0_SHIFT)
#define DRM_DEBUG_GET_DEBUG_BUS_SELECT(drm_debug) \
      ((drm_debug & DRM_DEBUG_DEBUG_BUS_SELECT_MASK) >> DRM_DEBUG_DEBUG_BUS_SELECT_SHIFT)
#define DRM_DEBUG_GET_DEBUG_UNUSED_1(drm_debug) \
      ((drm_debug & DRM_DEBUG_DEBUG_UNUSED_1_MASK) >> DRM_DEBUG_DEBUG_UNUSED_1_SHIFT)

#define DRM_DEBUG_SET_DEBUG_UNUSED_0(drm_debug_reg, debug_unused_0) \
      drm_debug_reg = (drm_debug_reg & ~DRM_DEBUG_DEBUG_UNUSED_0_MASK) | (debug_unused_0 << DRM_DEBUG_DEBUG_UNUSED_0_SHIFT)
#define DRM_DEBUG_SET_DEBUG_BUS_SELECT(drm_debug_reg, debug_bus_select) \
      drm_debug_reg = (drm_debug_reg & ~DRM_DEBUG_DEBUG_BUS_SELECT_MASK) | (debug_bus_select << DRM_DEBUG_DEBUG_BUS_SELECT_SHIFT)
#define DRM_DEBUG_SET_DEBUG_UNUSED_1(drm_debug_reg, debug_unused_1) \
      drm_debug_reg = (drm_debug_reg & ~DRM_DEBUG_DEBUG_UNUSED_1_MASK) | (debug_unused_1 << DRM_DEBUG_DEBUG_UNUSED_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_debug_t {
            unsigned int debug_unused_0                 : DRM_DEBUG_DEBUG_UNUSED_0_SIZE;
            unsigned int debug_bus_select               : DRM_DEBUG_DEBUG_BUS_SELECT_SIZE;
            unsigned int debug_unused_1                 : DRM_DEBUG_DEBUG_UNUSED_1_SIZE;
      } drm_debug_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_debug_t {
            unsigned int debug_unused_1                 : DRM_DEBUG_DEBUG_UNUSED_1_SIZE;
            unsigned int debug_bus_select               : DRM_DEBUG_DEBUG_BUS_SELECT_SIZE;
            unsigned int debug_unused_0                 : DRM_DEBUG_DEBUG_UNUSED_0_SIZE;
      } drm_debug_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_debug_t f;
} drm_debug_u;


/*
 * DRM_IH_CREDITS struct
 */

#define DRM_IH_CREDITS_REG_SIZE         32
#define DRM_IH_CREDITS_IH_CREDITS_SIZE  5

#define DRM_IH_CREDITS_IH_CREDITS_SHIFT  0

#define DRM_IH_CREDITS_IH_CREDITS_MASK  0x0000001f

#define DRM_IH_CREDITS_MASK \
      (DRM_IH_CREDITS_IH_CREDITS_MASK)

#define DRM_IH_CREDITS_DEFAULT         0x00000010

#define DRM_IH_CREDITS_GET_IH_CREDITS(drm_ih_credits) \
      ((drm_ih_credits & DRM_IH_CREDITS_IH_CREDITS_MASK) >> DRM_IH_CREDITS_IH_CREDITS_SHIFT)

#define DRM_IH_CREDITS_SET_IH_CREDITS(drm_ih_credits_reg, ih_credits) \
      drm_ih_credits_reg = (drm_ih_credits_reg & ~DRM_IH_CREDITS_IH_CREDITS_MASK) | (ih_credits << DRM_IH_CREDITS_IH_CREDITS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_ih_credits_t {
            unsigned int ih_credits                     : DRM_IH_CREDITS_IH_CREDITS_SIZE;
            unsigned int                                : 27;
      } drm_ih_credits_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_ih_credits_t {
            unsigned int                                : 27;
            unsigned int ih_credits                     : DRM_IH_CREDITS_IH_CREDITS_SIZE;
      } drm_ih_credits_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_ih_credits_t f;
} drm_ih_credits_u;


/*
 * DRM_INT_STATUS struct
 */

#define DRM_INT_STATUS_REG_SIZE         32
#define DRM_INT_STATUS_DH1_DONE_SIZE  1
#define DRM_INT_STATUS_DH2_DONE_SIZE  1
#define DRM_INT_STATUS_HFS_DONE_SIZE  1
#define DRM_INT_STATUS_SIG_DONE_SIZE  1
#define DRM_INT_STATUS_SIG_VALID_SIZE  1
#define DRM_INT_STATUS_TIMEOUT_CLIENT2_SIZE  1
#define DRM_INT_STATUS_TIMEOUT_CLIENT0_SIZE  1
#define DRM_INT_STATUS_TIMEOUT_CLIENT1_SIZE  1
#define DRM_INT_STATUS_INVALID_CLIENT2_SIZE  1
#define DRM_INT_STATUS_INVALID_CLIENT0_SIZE  1
#define DRM_INT_STATUS_INVALID_CLIENT1_SIZE  1
#define DRM_INT_STATUS_TIMEOUT_CLIENT3_SIZE  1
#define DRM_INT_STATUS_INVALID_CLIENT3_SIZE  1
#define DRM_INT_STATUS_TIMEOUT_CLIENT4_SIZE  1
#define DRM_INT_STATUS_INVALID_CLIENT4_SIZE  1

#define DRM_INT_STATUS_DH1_DONE_SHIFT  0
#define DRM_INT_STATUS_DH2_DONE_SHIFT  1
#define DRM_INT_STATUS_HFS_DONE_SHIFT  2
#define DRM_INT_STATUS_SIG_DONE_SHIFT  3
#define DRM_INT_STATUS_SIG_VALID_SHIFT  4
#define DRM_INT_STATUS_TIMEOUT_CLIENT2_SHIFT  5
#define DRM_INT_STATUS_TIMEOUT_CLIENT0_SHIFT  6
#define DRM_INT_STATUS_TIMEOUT_CLIENT1_SHIFT  7
#define DRM_INT_STATUS_INVALID_CLIENT2_SHIFT  8
#define DRM_INT_STATUS_INVALID_CLIENT0_SHIFT  9
#define DRM_INT_STATUS_INVALID_CLIENT1_SHIFT  10
#define DRM_INT_STATUS_TIMEOUT_CLIENT3_SHIFT  11
#define DRM_INT_STATUS_INVALID_CLIENT3_SHIFT  12
#define DRM_INT_STATUS_TIMEOUT_CLIENT4_SHIFT  13
#define DRM_INT_STATUS_INVALID_CLIENT4_SHIFT  14

#define DRM_INT_STATUS_DH1_DONE_MASK    0x00000001
#define DRM_INT_STATUS_DH2_DONE_MASK    0x00000002
#define DRM_INT_STATUS_HFS_DONE_MASK    0x00000004
#define DRM_INT_STATUS_SIG_DONE_MASK    0x00000008
#define DRM_INT_STATUS_SIG_VALID_MASK   0x00000010
#define DRM_INT_STATUS_TIMEOUT_CLIENT2_MASK  0x00000020
#define DRM_INT_STATUS_TIMEOUT_CLIENT0_MASK  0x00000040
#define DRM_INT_STATUS_TIMEOUT_CLIENT1_MASK  0x00000080
#define DRM_INT_STATUS_INVALID_CLIENT2_MASK  0x00000100
#define DRM_INT_STATUS_INVALID_CLIENT0_MASK  0x00000200
#define DRM_INT_STATUS_INVALID_CLIENT1_MASK  0x00000400
#define DRM_INT_STATUS_TIMEOUT_CLIENT3_MASK  0x00000800
#define DRM_INT_STATUS_INVALID_CLIENT3_MASK  0x00001000
#define DRM_INT_STATUS_TIMEOUT_CLIENT4_MASK  0x00002000
#define DRM_INT_STATUS_INVALID_CLIENT4_MASK  0x00004000

#define DRM_INT_STATUS_MASK \
      (DRM_INT_STATUS_DH1_DONE_MASK | \
      DRM_INT_STATUS_DH2_DONE_MASK | \
      DRM_INT_STATUS_HFS_DONE_MASK | \
      DRM_INT_STATUS_SIG_DONE_MASK | \
      DRM_INT_STATUS_SIG_VALID_MASK | \
      DRM_INT_STATUS_TIMEOUT_CLIENT2_MASK | \
      DRM_INT_STATUS_TIMEOUT_CLIENT0_MASK | \
      DRM_INT_STATUS_TIMEOUT_CLIENT1_MASK | \
      DRM_INT_STATUS_INVALID_CLIENT2_MASK | \
      DRM_INT_STATUS_INVALID_CLIENT0_MASK | \
      DRM_INT_STATUS_INVALID_CLIENT1_MASK | \
      DRM_INT_STATUS_TIMEOUT_CLIENT3_MASK | \
      DRM_INT_STATUS_INVALID_CLIENT3_MASK | \
      DRM_INT_STATUS_TIMEOUT_CLIENT4_MASK | \
      DRM_INT_STATUS_INVALID_CLIENT4_MASK)

#define DRM_INT_STATUS_DEFAULT         0x00000000

#define DRM_INT_STATUS_GET_DH1_DONE(drm_int_status) \
      ((drm_int_status & DRM_INT_STATUS_DH1_DONE_MASK) >> DRM_INT_STATUS_DH1_DONE_SHIFT)
#define DRM_INT_STATUS_GET_DH2_DONE(drm_int_status) \
      ((drm_int_status & DRM_INT_STATUS_DH2_DONE_MASK) >> DRM_INT_STATUS_DH2_DONE_SHIFT)
#define DRM_INT_STATUS_GET_HFS_DONE(drm_int_status) \
      ((drm_int_status & DRM_INT_STATUS_HFS_DONE_MASK) >> DRM_INT_STATUS_HFS_DONE_SHIFT)
#define DRM_INT_STATUS_GET_SIG_DONE(drm_int_status) \
      ((drm_int_status & DRM_INT_STATUS_SIG_DONE_MASK) >> DRM_INT_STATUS_SIG_DONE_SHIFT)
#define DRM_INT_STATUS_GET_SIG_VALID(drm_int_status) \
      ((drm_int_status & DRM_INT_STATUS_SIG_VALID_MASK) >> DRM_INT_STATUS_SIG_VALID_SHIFT)
#define DRM_INT_STATUS_GET_TIMEOUT_CLIENT2(drm_int_status) \
      ((drm_int_status & DRM_INT_STATUS_TIMEOUT_CLIENT2_MASK) >> DRM_INT_STATUS_TIMEOUT_CLIENT2_SHIFT)
#define DRM_INT_STATUS_GET_TIMEOUT_CLIENT0(drm_int_status) \
      ((drm_int_status & DRM_INT_STATUS_TIMEOUT_CLIENT0_MASK) >> DRM_INT_STATUS_TIMEOUT_CLIENT0_SHIFT)
#define DRM_INT_STATUS_GET_TIMEOUT_CLIENT1(drm_int_status) \
      ((drm_int_status & DRM_INT_STATUS_TIMEOUT_CLIENT1_MASK) >> DRM_INT_STATUS_TIMEOUT_CLIENT1_SHIFT)
#define DRM_INT_STATUS_GET_INVALID_CLIENT2(drm_int_status) \
      ((drm_int_status & DRM_INT_STATUS_INVALID_CLIENT2_MASK) >> DRM_INT_STATUS_INVALID_CLIENT2_SHIFT)
#define DRM_INT_STATUS_GET_INVALID_CLIENT0(drm_int_status) \
      ((drm_int_status & DRM_INT_STATUS_INVALID_CLIENT0_MASK) >> DRM_INT_STATUS_INVALID_CLIENT0_SHIFT)
#define DRM_INT_STATUS_GET_INVALID_CLIENT1(drm_int_status) \
      ((drm_int_status & DRM_INT_STATUS_INVALID_CLIENT1_MASK) >> DRM_INT_STATUS_INVALID_CLIENT1_SHIFT)
#define DRM_INT_STATUS_GET_TIMEOUT_CLIENT3(drm_int_status) \
      ((drm_int_status & DRM_INT_STATUS_TIMEOUT_CLIENT3_MASK) >> DRM_INT_STATUS_TIMEOUT_CLIENT3_SHIFT)
#define DRM_INT_STATUS_GET_INVALID_CLIENT3(drm_int_status) \
      ((drm_int_status & DRM_INT_STATUS_INVALID_CLIENT3_MASK) >> DRM_INT_STATUS_INVALID_CLIENT3_SHIFT)
#define DRM_INT_STATUS_GET_TIMEOUT_CLIENT4(drm_int_status) \
      ((drm_int_status & DRM_INT_STATUS_TIMEOUT_CLIENT4_MASK) >> DRM_INT_STATUS_TIMEOUT_CLIENT4_SHIFT)
#define DRM_INT_STATUS_GET_INVALID_CLIENT4(drm_int_status) \
      ((drm_int_status & DRM_INT_STATUS_INVALID_CLIENT4_MASK) >> DRM_INT_STATUS_INVALID_CLIENT4_SHIFT)

#define DRM_INT_STATUS_SET_DH1_DONE(drm_int_status_reg, dh1_done) \
      drm_int_status_reg = (drm_int_status_reg & ~DRM_INT_STATUS_DH1_DONE_MASK) | (dh1_done << DRM_INT_STATUS_DH1_DONE_SHIFT)
#define DRM_INT_STATUS_SET_DH2_DONE(drm_int_status_reg, dh2_done) \
      drm_int_status_reg = (drm_int_status_reg & ~DRM_INT_STATUS_DH2_DONE_MASK) | (dh2_done << DRM_INT_STATUS_DH2_DONE_SHIFT)
#define DRM_INT_STATUS_SET_HFS_DONE(drm_int_status_reg, hfs_done) \
      drm_int_status_reg = (drm_int_status_reg & ~DRM_INT_STATUS_HFS_DONE_MASK) | (hfs_done << DRM_INT_STATUS_HFS_DONE_SHIFT)
#define DRM_INT_STATUS_SET_SIG_DONE(drm_int_status_reg, sig_done) \
      drm_int_status_reg = (drm_int_status_reg & ~DRM_INT_STATUS_SIG_DONE_MASK) | (sig_done << DRM_INT_STATUS_SIG_DONE_SHIFT)
#define DRM_INT_STATUS_SET_SIG_VALID(drm_int_status_reg, sig_valid) \
      drm_int_status_reg = (drm_int_status_reg & ~DRM_INT_STATUS_SIG_VALID_MASK) | (sig_valid << DRM_INT_STATUS_SIG_VALID_SHIFT)
#define DRM_INT_STATUS_SET_TIMEOUT_CLIENT2(drm_int_status_reg, timeout_client2) \
      drm_int_status_reg = (drm_int_status_reg & ~DRM_INT_STATUS_TIMEOUT_CLIENT2_MASK) | (timeout_client2 << DRM_INT_STATUS_TIMEOUT_CLIENT2_SHIFT)
#define DRM_INT_STATUS_SET_TIMEOUT_CLIENT0(drm_int_status_reg, timeout_client0) \
      drm_int_status_reg = (drm_int_status_reg & ~DRM_INT_STATUS_TIMEOUT_CLIENT0_MASK) | (timeout_client0 << DRM_INT_STATUS_TIMEOUT_CLIENT0_SHIFT)
#define DRM_INT_STATUS_SET_TIMEOUT_CLIENT1(drm_int_status_reg, timeout_client1) \
      drm_int_status_reg = (drm_int_status_reg & ~DRM_INT_STATUS_TIMEOUT_CLIENT1_MASK) | (timeout_client1 << DRM_INT_STATUS_TIMEOUT_CLIENT1_SHIFT)
#define DRM_INT_STATUS_SET_INVALID_CLIENT2(drm_int_status_reg, invalid_client2) \
      drm_int_status_reg = (drm_int_status_reg & ~DRM_INT_STATUS_INVALID_CLIENT2_MASK) | (invalid_client2 << DRM_INT_STATUS_INVALID_CLIENT2_SHIFT)
#define DRM_INT_STATUS_SET_INVALID_CLIENT0(drm_int_status_reg, invalid_client0) \
      drm_int_status_reg = (drm_int_status_reg & ~DRM_INT_STATUS_INVALID_CLIENT0_MASK) | (invalid_client0 << DRM_INT_STATUS_INVALID_CLIENT0_SHIFT)
#define DRM_INT_STATUS_SET_INVALID_CLIENT1(drm_int_status_reg, invalid_client1) \
      drm_int_status_reg = (drm_int_status_reg & ~DRM_INT_STATUS_INVALID_CLIENT1_MASK) | (invalid_client1 << DRM_INT_STATUS_INVALID_CLIENT1_SHIFT)
#define DRM_INT_STATUS_SET_TIMEOUT_CLIENT3(drm_int_status_reg, timeout_client3) \
      drm_int_status_reg = (drm_int_status_reg & ~DRM_INT_STATUS_TIMEOUT_CLIENT3_MASK) | (timeout_client3 << DRM_INT_STATUS_TIMEOUT_CLIENT3_SHIFT)
#define DRM_INT_STATUS_SET_INVALID_CLIENT3(drm_int_status_reg, invalid_client3) \
      drm_int_status_reg = (drm_int_status_reg & ~DRM_INT_STATUS_INVALID_CLIENT3_MASK) | (invalid_client3 << DRM_INT_STATUS_INVALID_CLIENT3_SHIFT)
#define DRM_INT_STATUS_SET_TIMEOUT_CLIENT4(drm_int_status_reg, timeout_client4) \
      drm_int_status_reg = (drm_int_status_reg & ~DRM_INT_STATUS_TIMEOUT_CLIENT4_MASK) | (timeout_client4 << DRM_INT_STATUS_TIMEOUT_CLIENT4_SHIFT)
#define DRM_INT_STATUS_SET_INVALID_CLIENT4(drm_int_status_reg, invalid_client4) \
      drm_int_status_reg = (drm_int_status_reg & ~DRM_INT_STATUS_INVALID_CLIENT4_MASK) | (invalid_client4 << DRM_INT_STATUS_INVALID_CLIENT4_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_int_status_t {
            unsigned int dh1_done                       : DRM_INT_STATUS_DH1_DONE_SIZE;
            unsigned int dh2_done                       : DRM_INT_STATUS_DH2_DONE_SIZE;
            unsigned int hfs_done                       : DRM_INT_STATUS_HFS_DONE_SIZE;
            unsigned int sig_done                       : DRM_INT_STATUS_SIG_DONE_SIZE;
            unsigned int sig_valid                      : DRM_INT_STATUS_SIG_VALID_SIZE;
            unsigned int timeout_client2                : DRM_INT_STATUS_TIMEOUT_CLIENT2_SIZE;
            unsigned int timeout_client0                : DRM_INT_STATUS_TIMEOUT_CLIENT0_SIZE;
            unsigned int timeout_client1                : DRM_INT_STATUS_TIMEOUT_CLIENT1_SIZE;
            unsigned int invalid_client2                : DRM_INT_STATUS_INVALID_CLIENT2_SIZE;
            unsigned int invalid_client0                : DRM_INT_STATUS_INVALID_CLIENT0_SIZE;
            unsigned int invalid_client1                : DRM_INT_STATUS_INVALID_CLIENT1_SIZE;
            unsigned int timeout_client3                : DRM_INT_STATUS_TIMEOUT_CLIENT3_SIZE;
            unsigned int invalid_client3                : DRM_INT_STATUS_INVALID_CLIENT3_SIZE;
            unsigned int timeout_client4                : DRM_INT_STATUS_TIMEOUT_CLIENT4_SIZE;
            unsigned int invalid_client4                : DRM_INT_STATUS_INVALID_CLIENT4_SIZE;
            unsigned int                                : 17;
      } drm_int_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_int_status_t {
            unsigned int                                : 17;
            unsigned int invalid_client4                : DRM_INT_STATUS_INVALID_CLIENT4_SIZE;
            unsigned int timeout_client4                : DRM_INT_STATUS_TIMEOUT_CLIENT4_SIZE;
            unsigned int invalid_client3                : DRM_INT_STATUS_INVALID_CLIENT3_SIZE;
            unsigned int timeout_client3                : DRM_INT_STATUS_TIMEOUT_CLIENT3_SIZE;
            unsigned int invalid_client1                : DRM_INT_STATUS_INVALID_CLIENT1_SIZE;
            unsigned int invalid_client0                : DRM_INT_STATUS_INVALID_CLIENT0_SIZE;
            unsigned int invalid_client2                : DRM_INT_STATUS_INVALID_CLIENT2_SIZE;
            unsigned int timeout_client1                : DRM_INT_STATUS_TIMEOUT_CLIENT1_SIZE;
            unsigned int timeout_client0                : DRM_INT_STATUS_TIMEOUT_CLIENT0_SIZE;
            unsigned int timeout_client2                : DRM_INT_STATUS_TIMEOUT_CLIENT2_SIZE;
            unsigned int sig_valid                      : DRM_INT_STATUS_SIG_VALID_SIZE;
            unsigned int sig_done                       : DRM_INT_STATUS_SIG_DONE_SIZE;
            unsigned int hfs_done                       : DRM_INT_STATUS_HFS_DONE_SIZE;
            unsigned int dh2_done                       : DRM_INT_STATUS_DH2_DONE_SIZE;
            unsigned int dh1_done                       : DRM_INT_STATUS_DH1_DONE_SIZE;
      } drm_int_status_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_int_status_t f;
} drm_int_status_u;


/*
 * DRM_INT_MASK struct
 */

#define DRM_INT_MASK_REG_SIZE         32
#define DRM_INT_MASK_DH1_DONE_SIZE  1
#define DRM_INT_MASK_DH2_DONE_SIZE  1
#define DRM_INT_MASK_HFS_DONE_SIZE  1
#define DRM_INT_MASK_SIG_DONE_SIZE  1
#define DRM_INT_MASK_SIG_VALID_SIZE  1
#define DRM_INT_MASK_TIMEOUT_CLIENT2_SIZE  1
#define DRM_INT_MASK_TIMEOUT_CLIENT0_SIZE  1
#define DRM_INT_MASK_TIMEOUT_CLIENT1_SIZE  1
#define DRM_INT_MASK_INVALID_CLIENT2_SIZE  1
#define DRM_INT_MASK_INVALID_CLIENT0_SIZE  1
#define DRM_INT_MASK_INVALID_CLIENT1_SIZE  1
#define DRM_INT_MASK_TIMEOUT_CLIENT3_SIZE  1
#define DRM_INT_MASK_INVALID_CLIENT3_SIZE  1
#define DRM_INT_MASK_TIMEOUT_CLIENT4_SIZE  1
#define DRM_INT_MASK_INVALID_CLIENT4_SIZE  1

#define DRM_INT_MASK_DH1_DONE_SHIFT  0
#define DRM_INT_MASK_DH2_DONE_SHIFT  1
#define DRM_INT_MASK_HFS_DONE_SHIFT  2
#define DRM_INT_MASK_SIG_DONE_SHIFT  3
#define DRM_INT_MASK_SIG_VALID_SHIFT  4
#define DRM_INT_MASK_TIMEOUT_CLIENT2_SHIFT  5
#define DRM_INT_MASK_TIMEOUT_CLIENT0_SHIFT  6
#define DRM_INT_MASK_TIMEOUT_CLIENT1_SHIFT  7
#define DRM_INT_MASK_INVALID_CLIENT2_SHIFT  8
#define DRM_INT_MASK_INVALID_CLIENT0_SHIFT  9
#define DRM_INT_MASK_INVALID_CLIENT1_SHIFT  10
#define DRM_INT_MASK_TIMEOUT_CLIENT3_SHIFT  11
#define DRM_INT_MASK_INVALID_CLIENT3_SHIFT  12
#define DRM_INT_MASK_TIMEOUT_CLIENT4_SHIFT  13
#define DRM_INT_MASK_INVALID_CLIENT4_SHIFT  14

#define DRM_INT_MASK_DH1_DONE_MASK      0x00000001
#define DRM_INT_MASK_DH2_DONE_MASK      0x00000002
#define DRM_INT_MASK_HFS_DONE_MASK      0x00000004
#define DRM_INT_MASK_SIG_DONE_MASK      0x00000008
#define DRM_INT_MASK_SIG_VALID_MASK     0x00000010
#define DRM_INT_MASK_TIMEOUT_CLIENT2_MASK  0x00000020
#define DRM_INT_MASK_TIMEOUT_CLIENT0_MASK  0x00000040
#define DRM_INT_MASK_TIMEOUT_CLIENT1_MASK  0x00000080
#define DRM_INT_MASK_INVALID_CLIENT2_MASK  0x00000100
#define DRM_INT_MASK_INVALID_CLIENT0_MASK  0x00000200
#define DRM_INT_MASK_INVALID_CLIENT1_MASK  0x00000400
#define DRM_INT_MASK_TIMEOUT_CLIENT3_MASK  0x00000800
#define DRM_INT_MASK_INVALID_CLIENT3_MASK  0x00001000
#define DRM_INT_MASK_TIMEOUT_CLIENT4_MASK  0x00002000
#define DRM_INT_MASK_INVALID_CLIENT4_MASK  0x00004000

#define DRM_INT_MASK_MASK \
      (DRM_INT_MASK_DH1_DONE_MASK | \
      DRM_INT_MASK_DH2_DONE_MASK | \
      DRM_INT_MASK_HFS_DONE_MASK | \
      DRM_INT_MASK_SIG_DONE_MASK | \
      DRM_INT_MASK_SIG_VALID_MASK | \
      DRM_INT_MASK_TIMEOUT_CLIENT2_MASK | \
      DRM_INT_MASK_TIMEOUT_CLIENT0_MASK | \
      DRM_INT_MASK_TIMEOUT_CLIENT1_MASK | \
      DRM_INT_MASK_INVALID_CLIENT2_MASK | \
      DRM_INT_MASK_INVALID_CLIENT0_MASK | \
      DRM_INT_MASK_INVALID_CLIENT1_MASK | \
      DRM_INT_MASK_TIMEOUT_CLIENT3_MASK | \
      DRM_INT_MASK_INVALID_CLIENT3_MASK | \
      DRM_INT_MASK_TIMEOUT_CLIENT4_MASK | \
      DRM_INT_MASK_INVALID_CLIENT4_MASK)

#define DRM_INT_MASK_DEFAULT           0x00000000

#define DRM_INT_MASK_GET_DH1_DONE(drm_int_mask) \
      ((drm_int_mask & DRM_INT_MASK_DH1_DONE_MASK) >> DRM_INT_MASK_DH1_DONE_SHIFT)
#define DRM_INT_MASK_GET_DH2_DONE(drm_int_mask) \
      ((drm_int_mask & DRM_INT_MASK_DH2_DONE_MASK) >> DRM_INT_MASK_DH2_DONE_SHIFT)
#define DRM_INT_MASK_GET_HFS_DONE(drm_int_mask) \
      ((drm_int_mask & DRM_INT_MASK_HFS_DONE_MASK) >> DRM_INT_MASK_HFS_DONE_SHIFT)
#define DRM_INT_MASK_GET_SIG_DONE(drm_int_mask) \
      ((drm_int_mask & DRM_INT_MASK_SIG_DONE_MASK) >> DRM_INT_MASK_SIG_DONE_SHIFT)
#define DRM_INT_MASK_GET_SIG_VALID(drm_int_mask) \
      ((drm_int_mask & DRM_INT_MASK_SIG_VALID_MASK) >> DRM_INT_MASK_SIG_VALID_SHIFT)
#define DRM_INT_MASK_GET_TIMEOUT_CLIENT2(drm_int_mask) \
      ((drm_int_mask & DRM_INT_MASK_TIMEOUT_CLIENT2_MASK) >> DRM_INT_MASK_TIMEOUT_CLIENT2_SHIFT)
#define DRM_INT_MASK_GET_TIMEOUT_CLIENT0(drm_int_mask) \
      ((drm_int_mask & DRM_INT_MASK_TIMEOUT_CLIENT0_MASK) >> DRM_INT_MASK_TIMEOUT_CLIENT0_SHIFT)
#define DRM_INT_MASK_GET_TIMEOUT_CLIENT1(drm_int_mask) \
      ((drm_int_mask & DRM_INT_MASK_TIMEOUT_CLIENT1_MASK) >> DRM_INT_MASK_TIMEOUT_CLIENT1_SHIFT)
#define DRM_INT_MASK_GET_INVALID_CLIENT2(drm_int_mask) \
      ((drm_int_mask & DRM_INT_MASK_INVALID_CLIENT2_MASK) >> DRM_INT_MASK_INVALID_CLIENT2_SHIFT)
#define DRM_INT_MASK_GET_INVALID_CLIENT0(drm_int_mask) \
      ((drm_int_mask & DRM_INT_MASK_INVALID_CLIENT0_MASK) >> DRM_INT_MASK_INVALID_CLIENT0_SHIFT)
#define DRM_INT_MASK_GET_INVALID_CLIENT1(drm_int_mask) \
      ((drm_int_mask & DRM_INT_MASK_INVALID_CLIENT1_MASK) >> DRM_INT_MASK_INVALID_CLIENT1_SHIFT)
#define DRM_INT_MASK_GET_TIMEOUT_CLIENT3(drm_int_mask) \
      ((drm_int_mask & DRM_INT_MASK_TIMEOUT_CLIENT3_MASK) >> DRM_INT_MASK_TIMEOUT_CLIENT3_SHIFT)
#define DRM_INT_MASK_GET_INVALID_CLIENT3(drm_int_mask) \
      ((drm_int_mask & DRM_INT_MASK_INVALID_CLIENT3_MASK) >> DRM_INT_MASK_INVALID_CLIENT3_SHIFT)
#define DRM_INT_MASK_GET_TIMEOUT_CLIENT4(drm_int_mask) \
      ((drm_int_mask & DRM_INT_MASK_TIMEOUT_CLIENT4_MASK) >> DRM_INT_MASK_TIMEOUT_CLIENT4_SHIFT)
#define DRM_INT_MASK_GET_INVALID_CLIENT4(drm_int_mask) \
      ((drm_int_mask & DRM_INT_MASK_INVALID_CLIENT4_MASK) >> DRM_INT_MASK_INVALID_CLIENT4_SHIFT)

#define DRM_INT_MASK_SET_DH1_DONE(drm_int_mask_reg, dh1_done) \
      drm_int_mask_reg = (drm_int_mask_reg & ~DRM_INT_MASK_DH1_DONE_MASK) | (dh1_done << DRM_INT_MASK_DH1_DONE_SHIFT)
#define DRM_INT_MASK_SET_DH2_DONE(drm_int_mask_reg, dh2_done) \
      drm_int_mask_reg = (drm_int_mask_reg & ~DRM_INT_MASK_DH2_DONE_MASK) | (dh2_done << DRM_INT_MASK_DH2_DONE_SHIFT)
#define DRM_INT_MASK_SET_HFS_DONE(drm_int_mask_reg, hfs_done) \
      drm_int_mask_reg = (drm_int_mask_reg & ~DRM_INT_MASK_HFS_DONE_MASK) | (hfs_done << DRM_INT_MASK_HFS_DONE_SHIFT)
#define DRM_INT_MASK_SET_SIG_DONE(drm_int_mask_reg, sig_done) \
      drm_int_mask_reg = (drm_int_mask_reg & ~DRM_INT_MASK_SIG_DONE_MASK) | (sig_done << DRM_INT_MASK_SIG_DONE_SHIFT)
#define DRM_INT_MASK_SET_SIG_VALID(drm_int_mask_reg, sig_valid) \
      drm_int_mask_reg = (drm_int_mask_reg & ~DRM_INT_MASK_SIG_VALID_MASK) | (sig_valid << DRM_INT_MASK_SIG_VALID_SHIFT)
#define DRM_INT_MASK_SET_TIMEOUT_CLIENT2(drm_int_mask_reg, timeout_client2) \
      drm_int_mask_reg = (drm_int_mask_reg & ~DRM_INT_MASK_TIMEOUT_CLIENT2_MASK) | (timeout_client2 << DRM_INT_MASK_TIMEOUT_CLIENT2_SHIFT)
#define DRM_INT_MASK_SET_TIMEOUT_CLIENT0(drm_int_mask_reg, timeout_client0) \
      drm_int_mask_reg = (drm_int_mask_reg & ~DRM_INT_MASK_TIMEOUT_CLIENT0_MASK) | (timeout_client0 << DRM_INT_MASK_TIMEOUT_CLIENT0_SHIFT)
#define DRM_INT_MASK_SET_TIMEOUT_CLIENT1(drm_int_mask_reg, timeout_client1) \
      drm_int_mask_reg = (drm_int_mask_reg & ~DRM_INT_MASK_TIMEOUT_CLIENT1_MASK) | (timeout_client1 << DRM_INT_MASK_TIMEOUT_CLIENT1_SHIFT)
#define DRM_INT_MASK_SET_INVALID_CLIENT2(drm_int_mask_reg, invalid_client2) \
      drm_int_mask_reg = (drm_int_mask_reg & ~DRM_INT_MASK_INVALID_CLIENT2_MASK) | (invalid_client2 << DRM_INT_MASK_INVALID_CLIENT2_SHIFT)
#define DRM_INT_MASK_SET_INVALID_CLIENT0(drm_int_mask_reg, invalid_client0) \
      drm_int_mask_reg = (drm_int_mask_reg & ~DRM_INT_MASK_INVALID_CLIENT0_MASK) | (invalid_client0 << DRM_INT_MASK_INVALID_CLIENT0_SHIFT)
#define DRM_INT_MASK_SET_INVALID_CLIENT1(drm_int_mask_reg, invalid_client1) \
      drm_int_mask_reg = (drm_int_mask_reg & ~DRM_INT_MASK_INVALID_CLIENT1_MASK) | (invalid_client1 << DRM_INT_MASK_INVALID_CLIENT1_SHIFT)
#define DRM_INT_MASK_SET_TIMEOUT_CLIENT3(drm_int_mask_reg, timeout_client3) \
      drm_int_mask_reg = (drm_int_mask_reg & ~DRM_INT_MASK_TIMEOUT_CLIENT3_MASK) | (timeout_client3 << DRM_INT_MASK_TIMEOUT_CLIENT3_SHIFT)
#define DRM_INT_MASK_SET_INVALID_CLIENT3(drm_int_mask_reg, invalid_client3) \
      drm_int_mask_reg = (drm_int_mask_reg & ~DRM_INT_MASK_INVALID_CLIENT3_MASK) | (invalid_client3 << DRM_INT_MASK_INVALID_CLIENT3_SHIFT)
#define DRM_INT_MASK_SET_TIMEOUT_CLIENT4(drm_int_mask_reg, timeout_client4) \
      drm_int_mask_reg = (drm_int_mask_reg & ~DRM_INT_MASK_TIMEOUT_CLIENT4_MASK) | (timeout_client4 << DRM_INT_MASK_TIMEOUT_CLIENT4_SHIFT)
#define DRM_INT_MASK_SET_INVALID_CLIENT4(drm_int_mask_reg, invalid_client4) \
      drm_int_mask_reg = (drm_int_mask_reg & ~DRM_INT_MASK_INVALID_CLIENT4_MASK) | (invalid_client4 << DRM_INT_MASK_INVALID_CLIENT4_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_int_mask_t {
            unsigned int dh1_done                       : DRM_INT_MASK_DH1_DONE_SIZE;
            unsigned int dh2_done                       : DRM_INT_MASK_DH2_DONE_SIZE;
            unsigned int hfs_done                       : DRM_INT_MASK_HFS_DONE_SIZE;
            unsigned int sig_done                       : DRM_INT_MASK_SIG_DONE_SIZE;
            unsigned int sig_valid                      : DRM_INT_MASK_SIG_VALID_SIZE;
            unsigned int timeout_client2                : DRM_INT_MASK_TIMEOUT_CLIENT2_SIZE;
            unsigned int timeout_client0                : DRM_INT_MASK_TIMEOUT_CLIENT0_SIZE;
            unsigned int timeout_client1                : DRM_INT_MASK_TIMEOUT_CLIENT1_SIZE;
            unsigned int invalid_client2                : DRM_INT_MASK_INVALID_CLIENT2_SIZE;
            unsigned int invalid_client0                : DRM_INT_MASK_INVALID_CLIENT0_SIZE;
            unsigned int invalid_client1                : DRM_INT_MASK_INVALID_CLIENT1_SIZE;
            unsigned int timeout_client3                : DRM_INT_MASK_TIMEOUT_CLIENT3_SIZE;
            unsigned int invalid_client3                : DRM_INT_MASK_INVALID_CLIENT3_SIZE;
            unsigned int timeout_client4                : DRM_INT_MASK_TIMEOUT_CLIENT4_SIZE;
            unsigned int invalid_client4                : DRM_INT_MASK_INVALID_CLIENT4_SIZE;
            unsigned int                                : 17;
      } drm_int_mask_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_int_mask_t {
            unsigned int                                : 17;
            unsigned int invalid_client4                : DRM_INT_MASK_INVALID_CLIENT4_SIZE;
            unsigned int timeout_client4                : DRM_INT_MASK_TIMEOUT_CLIENT4_SIZE;
            unsigned int invalid_client3                : DRM_INT_MASK_INVALID_CLIENT3_SIZE;
            unsigned int timeout_client3                : DRM_INT_MASK_TIMEOUT_CLIENT3_SIZE;
            unsigned int invalid_client1                : DRM_INT_MASK_INVALID_CLIENT1_SIZE;
            unsigned int invalid_client0                : DRM_INT_MASK_INVALID_CLIENT0_SIZE;
            unsigned int invalid_client2                : DRM_INT_MASK_INVALID_CLIENT2_SIZE;
            unsigned int timeout_client1                : DRM_INT_MASK_TIMEOUT_CLIENT1_SIZE;
            unsigned int timeout_client0                : DRM_INT_MASK_TIMEOUT_CLIENT0_SIZE;
            unsigned int timeout_client2                : DRM_INT_MASK_TIMEOUT_CLIENT2_SIZE;
            unsigned int sig_valid                      : DRM_INT_MASK_SIG_VALID_SIZE;
            unsigned int sig_done                       : DRM_INT_MASK_SIG_DONE_SIZE;
            unsigned int hfs_done                       : DRM_INT_MASK_HFS_DONE_SIZE;
            unsigned int dh2_done                       : DRM_INT_MASK_DH2_DONE_SIZE;
            unsigned int dh1_done                       : DRM_INT_MASK_DH1_DONE_SIZE;
      } drm_int_mask_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_int_mask_t f;
} drm_int_mask_u;


/*
 * DRM_INT_ACK struct
 */

#define DRM_INT_ACK_REG_SIZE         32
#define DRM_INT_ACK_DH1_DONE_SIZE  1
#define DRM_INT_ACK_DH2_DONE_SIZE  1
#define DRM_INT_ACK_HFS_DONE_SIZE  1
#define DRM_INT_ACK_SIG_DONE_SIZE  1
#define DRM_INT_ACK_SIG_VALID_SIZE  1
#define DRM_INT_ACK_TIMEOUT_CLIENT2_SIZE  1
#define DRM_INT_ACK_TIMEOUT_CLIENT0_SIZE  1
#define DRM_INT_ACK_TIMEOUT_CLIENT1_SIZE  1
#define DRM_INT_ACK_INVALID_CLIENT2_SIZE  1
#define DRM_INT_ACK_INVALID_CLIENT0_SIZE  1
#define DRM_INT_ACK_INVALID_CLIENT1_SIZE  1
#define DRM_INT_ACK_TIMEOUT_CLIENT3_SIZE  1
#define DRM_INT_ACK_INVALID_CLIENT3_SIZE  1
#define DRM_INT_ACK_TIMEOUT_CLIENT4_SIZE  1
#define DRM_INT_ACK_INVALID_CLIENT4_SIZE  1

#define DRM_INT_ACK_DH1_DONE_SHIFT  0
#define DRM_INT_ACK_DH2_DONE_SHIFT  1
#define DRM_INT_ACK_HFS_DONE_SHIFT  2
#define DRM_INT_ACK_SIG_DONE_SHIFT  3
#define DRM_INT_ACK_SIG_VALID_SHIFT  4
#define DRM_INT_ACK_TIMEOUT_CLIENT2_SHIFT  5
#define DRM_INT_ACK_TIMEOUT_CLIENT0_SHIFT  6
#define DRM_INT_ACK_TIMEOUT_CLIENT1_SHIFT  7
#define DRM_INT_ACK_INVALID_CLIENT2_SHIFT  8
#define DRM_INT_ACK_INVALID_CLIENT0_SHIFT  9
#define DRM_INT_ACK_INVALID_CLIENT1_SHIFT  10
#define DRM_INT_ACK_TIMEOUT_CLIENT3_SHIFT  11
#define DRM_INT_ACK_INVALID_CLIENT3_SHIFT  12
#define DRM_INT_ACK_TIMEOUT_CLIENT4_SHIFT  13
#define DRM_INT_ACK_INVALID_CLIENT4_SHIFT  14

#define DRM_INT_ACK_DH1_DONE_MASK       0x00000001
#define DRM_INT_ACK_DH2_DONE_MASK       0x00000002
#define DRM_INT_ACK_HFS_DONE_MASK       0x00000004
#define DRM_INT_ACK_SIG_DONE_MASK       0x00000008
#define DRM_INT_ACK_SIG_VALID_MASK      0x00000010
#define DRM_INT_ACK_TIMEOUT_CLIENT2_MASK  0x00000020
#define DRM_INT_ACK_TIMEOUT_CLIENT0_MASK  0x00000040
#define DRM_INT_ACK_TIMEOUT_CLIENT1_MASK  0x00000080
#define DRM_INT_ACK_INVALID_CLIENT2_MASK  0x00000100
#define DRM_INT_ACK_INVALID_CLIENT0_MASK  0x00000200
#define DRM_INT_ACK_INVALID_CLIENT1_MASK  0x00000400
#define DRM_INT_ACK_TIMEOUT_CLIENT3_MASK  0x00000800
#define DRM_INT_ACK_INVALID_CLIENT3_MASK  0x00001000
#define DRM_INT_ACK_TIMEOUT_CLIENT4_MASK  0x00002000
#define DRM_INT_ACK_INVALID_CLIENT4_MASK  0x00004000

#define DRM_INT_ACK_MASK \
      (DRM_INT_ACK_DH1_DONE_MASK | \
      DRM_INT_ACK_DH2_DONE_MASK | \
      DRM_INT_ACK_HFS_DONE_MASK | \
      DRM_INT_ACK_SIG_DONE_MASK | \
      DRM_INT_ACK_SIG_VALID_MASK | \
      DRM_INT_ACK_TIMEOUT_CLIENT2_MASK | \
      DRM_INT_ACK_TIMEOUT_CLIENT0_MASK | \
      DRM_INT_ACK_TIMEOUT_CLIENT1_MASK | \
      DRM_INT_ACK_INVALID_CLIENT2_MASK | \
      DRM_INT_ACK_INVALID_CLIENT0_MASK | \
      DRM_INT_ACK_INVALID_CLIENT1_MASK | \
      DRM_INT_ACK_TIMEOUT_CLIENT3_MASK | \
      DRM_INT_ACK_INVALID_CLIENT3_MASK | \
      DRM_INT_ACK_TIMEOUT_CLIENT4_MASK | \
      DRM_INT_ACK_INVALID_CLIENT4_MASK)

#define DRM_INT_ACK_DEFAULT            0x00000000

#define DRM_INT_ACK_GET_DH1_DONE(drm_int_ack) \
      ((drm_int_ack & DRM_INT_ACK_DH1_DONE_MASK) >> DRM_INT_ACK_DH1_DONE_SHIFT)
#define DRM_INT_ACK_GET_DH2_DONE(drm_int_ack) \
      ((drm_int_ack & DRM_INT_ACK_DH2_DONE_MASK) >> DRM_INT_ACK_DH2_DONE_SHIFT)
#define DRM_INT_ACK_GET_HFS_DONE(drm_int_ack) \
      ((drm_int_ack & DRM_INT_ACK_HFS_DONE_MASK) >> DRM_INT_ACK_HFS_DONE_SHIFT)
#define DRM_INT_ACK_GET_SIG_DONE(drm_int_ack) \
      ((drm_int_ack & DRM_INT_ACK_SIG_DONE_MASK) >> DRM_INT_ACK_SIG_DONE_SHIFT)
#define DRM_INT_ACK_GET_SIG_VALID(drm_int_ack) \
      ((drm_int_ack & DRM_INT_ACK_SIG_VALID_MASK) >> DRM_INT_ACK_SIG_VALID_SHIFT)
#define DRM_INT_ACK_GET_TIMEOUT_CLIENT2(drm_int_ack) \
      ((drm_int_ack & DRM_INT_ACK_TIMEOUT_CLIENT2_MASK) >> DRM_INT_ACK_TIMEOUT_CLIENT2_SHIFT)
#define DRM_INT_ACK_GET_TIMEOUT_CLIENT0(drm_int_ack) \
      ((drm_int_ack & DRM_INT_ACK_TIMEOUT_CLIENT0_MASK) >> DRM_INT_ACK_TIMEOUT_CLIENT0_SHIFT)
#define DRM_INT_ACK_GET_TIMEOUT_CLIENT1(drm_int_ack) \
      ((drm_int_ack & DRM_INT_ACK_TIMEOUT_CLIENT1_MASK) >> DRM_INT_ACK_TIMEOUT_CLIENT1_SHIFT)
#define DRM_INT_ACK_GET_INVALID_CLIENT2(drm_int_ack) \
      ((drm_int_ack & DRM_INT_ACK_INVALID_CLIENT2_MASK) >> DRM_INT_ACK_INVALID_CLIENT2_SHIFT)
#define DRM_INT_ACK_GET_INVALID_CLIENT0(drm_int_ack) \
      ((drm_int_ack & DRM_INT_ACK_INVALID_CLIENT0_MASK) >> DRM_INT_ACK_INVALID_CLIENT0_SHIFT)
#define DRM_INT_ACK_GET_INVALID_CLIENT1(drm_int_ack) \
      ((drm_int_ack & DRM_INT_ACK_INVALID_CLIENT1_MASK) >> DRM_INT_ACK_INVALID_CLIENT1_SHIFT)
#define DRM_INT_ACK_GET_TIMEOUT_CLIENT3(drm_int_ack) \
      ((drm_int_ack & DRM_INT_ACK_TIMEOUT_CLIENT3_MASK) >> DRM_INT_ACK_TIMEOUT_CLIENT3_SHIFT)
#define DRM_INT_ACK_GET_INVALID_CLIENT3(drm_int_ack) \
      ((drm_int_ack & DRM_INT_ACK_INVALID_CLIENT3_MASK) >> DRM_INT_ACK_INVALID_CLIENT3_SHIFT)
#define DRM_INT_ACK_GET_TIMEOUT_CLIENT4(drm_int_ack) \
      ((drm_int_ack & DRM_INT_ACK_TIMEOUT_CLIENT4_MASK) >> DRM_INT_ACK_TIMEOUT_CLIENT4_SHIFT)
#define DRM_INT_ACK_GET_INVALID_CLIENT4(drm_int_ack) \
      ((drm_int_ack & DRM_INT_ACK_INVALID_CLIENT4_MASK) >> DRM_INT_ACK_INVALID_CLIENT4_SHIFT)

#define DRM_INT_ACK_SET_DH1_DONE(drm_int_ack_reg, dh1_done) \
      drm_int_ack_reg = (drm_int_ack_reg & ~DRM_INT_ACK_DH1_DONE_MASK) | (dh1_done << DRM_INT_ACK_DH1_DONE_SHIFT)
#define DRM_INT_ACK_SET_DH2_DONE(drm_int_ack_reg, dh2_done) \
      drm_int_ack_reg = (drm_int_ack_reg & ~DRM_INT_ACK_DH2_DONE_MASK) | (dh2_done << DRM_INT_ACK_DH2_DONE_SHIFT)
#define DRM_INT_ACK_SET_HFS_DONE(drm_int_ack_reg, hfs_done) \
      drm_int_ack_reg = (drm_int_ack_reg & ~DRM_INT_ACK_HFS_DONE_MASK) | (hfs_done << DRM_INT_ACK_HFS_DONE_SHIFT)
#define DRM_INT_ACK_SET_SIG_DONE(drm_int_ack_reg, sig_done) \
      drm_int_ack_reg = (drm_int_ack_reg & ~DRM_INT_ACK_SIG_DONE_MASK) | (sig_done << DRM_INT_ACK_SIG_DONE_SHIFT)
#define DRM_INT_ACK_SET_SIG_VALID(drm_int_ack_reg, sig_valid) \
      drm_int_ack_reg = (drm_int_ack_reg & ~DRM_INT_ACK_SIG_VALID_MASK) | (sig_valid << DRM_INT_ACK_SIG_VALID_SHIFT)
#define DRM_INT_ACK_SET_TIMEOUT_CLIENT2(drm_int_ack_reg, timeout_client2) \
      drm_int_ack_reg = (drm_int_ack_reg & ~DRM_INT_ACK_TIMEOUT_CLIENT2_MASK) | (timeout_client2 << DRM_INT_ACK_TIMEOUT_CLIENT2_SHIFT)
#define DRM_INT_ACK_SET_TIMEOUT_CLIENT0(drm_int_ack_reg, timeout_client0) \
      drm_int_ack_reg = (drm_int_ack_reg & ~DRM_INT_ACK_TIMEOUT_CLIENT0_MASK) | (timeout_client0 << DRM_INT_ACK_TIMEOUT_CLIENT0_SHIFT)
#define DRM_INT_ACK_SET_TIMEOUT_CLIENT1(drm_int_ack_reg, timeout_client1) \
      drm_int_ack_reg = (drm_int_ack_reg & ~DRM_INT_ACK_TIMEOUT_CLIENT1_MASK) | (timeout_client1 << DRM_INT_ACK_TIMEOUT_CLIENT1_SHIFT)
#define DRM_INT_ACK_SET_INVALID_CLIENT2(drm_int_ack_reg, invalid_client2) \
      drm_int_ack_reg = (drm_int_ack_reg & ~DRM_INT_ACK_INVALID_CLIENT2_MASK) | (invalid_client2 << DRM_INT_ACK_INVALID_CLIENT2_SHIFT)
#define DRM_INT_ACK_SET_INVALID_CLIENT0(drm_int_ack_reg, invalid_client0) \
      drm_int_ack_reg = (drm_int_ack_reg & ~DRM_INT_ACK_INVALID_CLIENT0_MASK) | (invalid_client0 << DRM_INT_ACK_INVALID_CLIENT0_SHIFT)
#define DRM_INT_ACK_SET_INVALID_CLIENT1(drm_int_ack_reg, invalid_client1) \
      drm_int_ack_reg = (drm_int_ack_reg & ~DRM_INT_ACK_INVALID_CLIENT1_MASK) | (invalid_client1 << DRM_INT_ACK_INVALID_CLIENT1_SHIFT)
#define DRM_INT_ACK_SET_TIMEOUT_CLIENT3(drm_int_ack_reg, timeout_client3) \
      drm_int_ack_reg = (drm_int_ack_reg & ~DRM_INT_ACK_TIMEOUT_CLIENT3_MASK) | (timeout_client3 << DRM_INT_ACK_TIMEOUT_CLIENT3_SHIFT)
#define DRM_INT_ACK_SET_INVALID_CLIENT3(drm_int_ack_reg, invalid_client3) \
      drm_int_ack_reg = (drm_int_ack_reg & ~DRM_INT_ACK_INVALID_CLIENT3_MASK) | (invalid_client3 << DRM_INT_ACK_INVALID_CLIENT3_SHIFT)
#define DRM_INT_ACK_SET_TIMEOUT_CLIENT4(drm_int_ack_reg, timeout_client4) \
      drm_int_ack_reg = (drm_int_ack_reg & ~DRM_INT_ACK_TIMEOUT_CLIENT4_MASK) | (timeout_client4 << DRM_INT_ACK_TIMEOUT_CLIENT4_SHIFT)
#define DRM_INT_ACK_SET_INVALID_CLIENT4(drm_int_ack_reg, invalid_client4) \
      drm_int_ack_reg = (drm_int_ack_reg & ~DRM_INT_ACK_INVALID_CLIENT4_MASK) | (invalid_client4 << DRM_INT_ACK_INVALID_CLIENT4_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_int_ack_t {
            unsigned int dh1_done                       : DRM_INT_ACK_DH1_DONE_SIZE;
            unsigned int dh2_done                       : DRM_INT_ACK_DH2_DONE_SIZE;
            unsigned int hfs_done                       : DRM_INT_ACK_HFS_DONE_SIZE;
            unsigned int sig_done                       : DRM_INT_ACK_SIG_DONE_SIZE;
            unsigned int sig_valid                      : DRM_INT_ACK_SIG_VALID_SIZE;
            unsigned int timeout_client2                : DRM_INT_ACK_TIMEOUT_CLIENT2_SIZE;
            unsigned int timeout_client0                : DRM_INT_ACK_TIMEOUT_CLIENT0_SIZE;
            unsigned int timeout_client1                : DRM_INT_ACK_TIMEOUT_CLIENT1_SIZE;
            unsigned int invalid_client2                : DRM_INT_ACK_INVALID_CLIENT2_SIZE;
            unsigned int invalid_client0                : DRM_INT_ACK_INVALID_CLIENT0_SIZE;
            unsigned int invalid_client1                : DRM_INT_ACK_INVALID_CLIENT1_SIZE;
            unsigned int timeout_client3                : DRM_INT_ACK_TIMEOUT_CLIENT3_SIZE;
            unsigned int invalid_client3                : DRM_INT_ACK_INVALID_CLIENT3_SIZE;
            unsigned int timeout_client4                : DRM_INT_ACK_TIMEOUT_CLIENT4_SIZE;
            unsigned int invalid_client4                : DRM_INT_ACK_INVALID_CLIENT4_SIZE;
            unsigned int                                : 17;
      } drm_int_ack_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_int_ack_t {
            unsigned int                                : 17;
            unsigned int invalid_client4                : DRM_INT_ACK_INVALID_CLIENT4_SIZE;
            unsigned int timeout_client4                : DRM_INT_ACK_TIMEOUT_CLIENT4_SIZE;
            unsigned int invalid_client3                : DRM_INT_ACK_INVALID_CLIENT3_SIZE;
            unsigned int timeout_client3                : DRM_INT_ACK_TIMEOUT_CLIENT3_SIZE;
            unsigned int invalid_client1                : DRM_INT_ACK_INVALID_CLIENT1_SIZE;
            unsigned int invalid_client0                : DRM_INT_ACK_INVALID_CLIENT0_SIZE;
            unsigned int invalid_client2                : DRM_INT_ACK_INVALID_CLIENT2_SIZE;
            unsigned int timeout_client1                : DRM_INT_ACK_TIMEOUT_CLIENT1_SIZE;
            unsigned int timeout_client0                : DRM_INT_ACK_TIMEOUT_CLIENT0_SIZE;
            unsigned int timeout_client2                : DRM_INT_ACK_TIMEOUT_CLIENT2_SIZE;
            unsigned int sig_valid                      : DRM_INT_ACK_SIG_VALID_SIZE;
            unsigned int sig_done                       : DRM_INT_ACK_SIG_DONE_SIZE;
            unsigned int hfs_done                       : DRM_INT_ACK_HFS_DONE_SIZE;
            unsigned int dh2_done                       : DRM_INT_ACK_DH2_DONE_SIZE;
            unsigned int dh1_done                       : DRM_INT_ACK_DH1_DONE_SIZE;
      } drm_int_ack_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_int_ack_t f;
} drm_int_ack_u;


/*
 * DRM_STATUS struct
 */

#define DRM_STATUS_REG_SIZE         32
#define DRM_STATUS_DRM_BUSY_SIZE  1
#define DRM_STATUS_TRNG_BUSY_SIZE  1
#define DRM_STATUS_CLIENT1_BUSY_SIZE  1
#define DRM_STATUS_CLIENT2_BUSY_SIZE  1
#define DRM_STATUS_CLIENT0_BUSY_SIZE  1
#define DRM_STATUS_SIG_BUSY_SIZE  1
#define DRM_STATUS_HFS_BUSY_SIZE  1
#define DRM_STATUS_DH_BUSY2_SIZE  1
#define DRM_STATUS_DH_BUSY1_SIZE  1
#define DRM_STATUS_CLIENT1_PARSE_BUSY_SIZE  1
#define DRM_STATUS_CLIENT2_PARSE_BUSY_SIZE  1
#define DRM_STATUS_CLIENT0_PARSE_BUSY_SIZE  1
#define DRM_STATUS_SIG_RD_BUSY_SIZE  1
#define DRM_STATUS_HFS_DONE_SIZE  1
#define DRM_STATUS_DH_DONE_SIZE  1
#define DRM_STATUS_DRM_INIT_SIZE  1
#define DRM_STATUS_DH_ACTIVE_SIZE  1
#define DRM_STATUS_HFS_ACTIVE_SIZE  1
#define DRM_STATUS_SIG_ACTIVE_SIZE  1
#define DRM_STATUS_HFS_PASS_SIZE  1
#define DRM_STATUS_AUTH_STATE_SIZE  3
#define DRM_STATUS_DRM_INIT_SESSION_1_SIZE  1
#define DRM_STATUS_DRM_INIT_SESSION_2_SIZE  1
#define DRM_STATUS_DRM_INIT_SESSION_3_SIZE  1
#define DRM_STATUS_CLIENT3_BUSY_SIZE  1

#define DRM_STATUS_DRM_BUSY_SHIFT  0
#define DRM_STATUS_TRNG_BUSY_SHIFT  1
#define DRM_STATUS_CLIENT1_BUSY_SHIFT  2
#define DRM_STATUS_CLIENT2_BUSY_SHIFT  3
#define DRM_STATUS_CLIENT0_BUSY_SHIFT  4
#define DRM_STATUS_SIG_BUSY_SHIFT  5
#define DRM_STATUS_HFS_BUSY_SHIFT  6
#define DRM_STATUS_DH_BUSY2_SHIFT  7
#define DRM_STATUS_DH_BUSY1_SHIFT  8
#define DRM_STATUS_CLIENT1_PARSE_BUSY_SHIFT  9
#define DRM_STATUS_CLIENT2_PARSE_BUSY_SHIFT  10
#define DRM_STATUS_CLIENT0_PARSE_BUSY_SHIFT  11
#define DRM_STATUS_SIG_RD_BUSY_SHIFT  12
#define DRM_STATUS_HFS_DONE_SHIFT  16
#define DRM_STATUS_DH_DONE_SHIFT  17
#define DRM_STATUS_DRM_INIT_SHIFT  18
#define DRM_STATUS_DH_ACTIVE_SHIFT  20
#define DRM_STATUS_HFS_ACTIVE_SHIFT  21
#define DRM_STATUS_SIG_ACTIVE_SHIFT  22
#define DRM_STATUS_HFS_PASS_SHIFT  24
#define DRM_STATUS_AUTH_STATE_SHIFT  25
#define DRM_STATUS_DRM_INIT_SESSION_1_SHIFT  28
#define DRM_STATUS_DRM_INIT_SESSION_2_SHIFT  29
#define DRM_STATUS_DRM_INIT_SESSION_3_SHIFT  30
#define DRM_STATUS_CLIENT3_BUSY_SHIFT  31

#define DRM_STATUS_DRM_BUSY_MASK        0x00000001
#define DRM_STATUS_TRNG_BUSY_MASK       0x00000002
#define DRM_STATUS_CLIENT1_BUSY_MASK    0x00000004
#define DRM_STATUS_CLIENT2_BUSY_MASK    0x00000008
#define DRM_STATUS_CLIENT0_BUSY_MASK    0x00000010
#define DRM_STATUS_SIG_BUSY_MASK        0x00000020
#define DRM_STATUS_HFS_BUSY_MASK        0x00000040
#define DRM_STATUS_DH_BUSY2_MASK        0x00000080
#define DRM_STATUS_DH_BUSY1_MASK        0x00000100
#define DRM_STATUS_CLIENT1_PARSE_BUSY_MASK  0x00000200
#define DRM_STATUS_CLIENT2_PARSE_BUSY_MASK  0x00000400
#define DRM_STATUS_CLIENT0_PARSE_BUSY_MASK  0x00000800
#define DRM_STATUS_SIG_RD_BUSY_MASK     0x00001000
#define DRM_STATUS_HFS_DONE_MASK        0x00010000
#define DRM_STATUS_DH_DONE_MASK         0x00020000
#define DRM_STATUS_DRM_INIT_MASK        0x00040000
#define DRM_STATUS_DH_ACTIVE_MASK       0x00100000
#define DRM_STATUS_HFS_ACTIVE_MASK      0x00200000
#define DRM_STATUS_SIG_ACTIVE_MASK      0x00400000
#define DRM_STATUS_HFS_PASS_MASK        0x01000000
#define DRM_STATUS_AUTH_STATE_MASK      0x0e000000
#define DRM_STATUS_DRM_INIT_SESSION_1_MASK  0x10000000
#define DRM_STATUS_DRM_INIT_SESSION_2_MASK  0x20000000
#define DRM_STATUS_DRM_INIT_SESSION_3_MASK  0x40000000
#define DRM_STATUS_CLIENT3_BUSY_MASK    0x80000000

#define DRM_STATUS_MASK \
      (DRM_STATUS_DRM_BUSY_MASK | \
      DRM_STATUS_TRNG_BUSY_MASK | \
      DRM_STATUS_CLIENT1_BUSY_MASK | \
      DRM_STATUS_CLIENT2_BUSY_MASK | \
      DRM_STATUS_CLIENT0_BUSY_MASK | \
      DRM_STATUS_SIG_BUSY_MASK | \
      DRM_STATUS_HFS_BUSY_MASK | \
      DRM_STATUS_DH_BUSY2_MASK | \
      DRM_STATUS_DH_BUSY1_MASK | \
      DRM_STATUS_CLIENT1_PARSE_BUSY_MASK | \
      DRM_STATUS_CLIENT2_PARSE_BUSY_MASK | \
      DRM_STATUS_CLIENT0_PARSE_BUSY_MASK | \
      DRM_STATUS_SIG_RD_BUSY_MASK | \
      DRM_STATUS_HFS_DONE_MASK | \
      DRM_STATUS_DH_DONE_MASK | \
      DRM_STATUS_DRM_INIT_MASK | \
      DRM_STATUS_DH_ACTIVE_MASK | \
      DRM_STATUS_HFS_ACTIVE_MASK | \
      DRM_STATUS_SIG_ACTIVE_MASK | \
      DRM_STATUS_HFS_PASS_MASK | \
      DRM_STATUS_AUTH_STATE_MASK | \
      DRM_STATUS_DRM_INIT_SESSION_1_MASK | \
      DRM_STATUS_DRM_INIT_SESSION_2_MASK | \
      DRM_STATUS_DRM_INIT_SESSION_3_MASK | \
      DRM_STATUS_CLIENT3_BUSY_MASK)

#define DRM_STATUS_DEFAULT             0x00000000

#define DRM_STATUS_GET_DRM_BUSY(drm_status) \
      ((drm_status & DRM_STATUS_DRM_BUSY_MASK) >> DRM_STATUS_DRM_BUSY_SHIFT)
#define DRM_STATUS_GET_TRNG_BUSY(drm_status) \
      ((drm_status & DRM_STATUS_TRNG_BUSY_MASK) >> DRM_STATUS_TRNG_BUSY_SHIFT)
#define DRM_STATUS_GET_CLIENT1_BUSY(drm_status) \
      ((drm_status & DRM_STATUS_CLIENT1_BUSY_MASK) >> DRM_STATUS_CLIENT1_BUSY_SHIFT)
#define DRM_STATUS_GET_CLIENT2_BUSY(drm_status) \
      ((drm_status & DRM_STATUS_CLIENT2_BUSY_MASK) >> DRM_STATUS_CLIENT2_BUSY_SHIFT)
#define DRM_STATUS_GET_CLIENT0_BUSY(drm_status) \
      ((drm_status & DRM_STATUS_CLIENT0_BUSY_MASK) >> DRM_STATUS_CLIENT0_BUSY_SHIFT)
#define DRM_STATUS_GET_SIG_BUSY(drm_status) \
      ((drm_status & DRM_STATUS_SIG_BUSY_MASK) >> DRM_STATUS_SIG_BUSY_SHIFT)
#define DRM_STATUS_GET_HFS_BUSY(drm_status) \
      ((drm_status & DRM_STATUS_HFS_BUSY_MASK) >> DRM_STATUS_HFS_BUSY_SHIFT)
#define DRM_STATUS_GET_DH_BUSY2(drm_status) \
      ((drm_status & DRM_STATUS_DH_BUSY2_MASK) >> DRM_STATUS_DH_BUSY2_SHIFT)
#define DRM_STATUS_GET_DH_BUSY1(drm_status) \
      ((drm_status & DRM_STATUS_DH_BUSY1_MASK) >> DRM_STATUS_DH_BUSY1_SHIFT)
#define DRM_STATUS_GET_CLIENT1_PARSE_BUSY(drm_status) \
      ((drm_status & DRM_STATUS_CLIENT1_PARSE_BUSY_MASK) >> DRM_STATUS_CLIENT1_PARSE_BUSY_SHIFT)
#define DRM_STATUS_GET_CLIENT2_PARSE_BUSY(drm_status) \
      ((drm_status & DRM_STATUS_CLIENT2_PARSE_BUSY_MASK) >> DRM_STATUS_CLIENT2_PARSE_BUSY_SHIFT)
#define DRM_STATUS_GET_CLIENT0_PARSE_BUSY(drm_status) \
      ((drm_status & DRM_STATUS_CLIENT0_PARSE_BUSY_MASK) >> DRM_STATUS_CLIENT0_PARSE_BUSY_SHIFT)
#define DRM_STATUS_GET_SIG_RD_BUSY(drm_status) \
      ((drm_status & DRM_STATUS_SIG_RD_BUSY_MASK) >> DRM_STATUS_SIG_RD_BUSY_SHIFT)
#define DRM_STATUS_GET_HFS_DONE(drm_status) \
      ((drm_status & DRM_STATUS_HFS_DONE_MASK) >> DRM_STATUS_HFS_DONE_SHIFT)
#define DRM_STATUS_GET_DH_DONE(drm_status) \
      ((drm_status & DRM_STATUS_DH_DONE_MASK) >> DRM_STATUS_DH_DONE_SHIFT)
#define DRM_STATUS_GET_DRM_INIT(drm_status) \
      ((drm_status & DRM_STATUS_DRM_INIT_MASK) >> DRM_STATUS_DRM_INIT_SHIFT)
#define DRM_STATUS_GET_DH_ACTIVE(drm_status) \
      ((drm_status & DRM_STATUS_DH_ACTIVE_MASK) >> DRM_STATUS_DH_ACTIVE_SHIFT)
#define DRM_STATUS_GET_HFS_ACTIVE(drm_status) \
      ((drm_status & DRM_STATUS_HFS_ACTIVE_MASK) >> DRM_STATUS_HFS_ACTIVE_SHIFT)
#define DRM_STATUS_GET_SIG_ACTIVE(drm_status) \
      ((drm_status & DRM_STATUS_SIG_ACTIVE_MASK) >> DRM_STATUS_SIG_ACTIVE_SHIFT)
#define DRM_STATUS_GET_HFS_PASS(drm_status) \
      ((drm_status & DRM_STATUS_HFS_PASS_MASK) >> DRM_STATUS_HFS_PASS_SHIFT)
#define DRM_STATUS_GET_AUTH_STATE(drm_status) \
      ((drm_status & DRM_STATUS_AUTH_STATE_MASK) >> DRM_STATUS_AUTH_STATE_SHIFT)
#define DRM_STATUS_GET_DRM_INIT_SESSION_1(drm_status) \
      ((drm_status & DRM_STATUS_DRM_INIT_SESSION_1_MASK) >> DRM_STATUS_DRM_INIT_SESSION_1_SHIFT)
#define DRM_STATUS_GET_DRM_INIT_SESSION_2(drm_status) \
      ((drm_status & DRM_STATUS_DRM_INIT_SESSION_2_MASK) >> DRM_STATUS_DRM_INIT_SESSION_2_SHIFT)
#define DRM_STATUS_GET_DRM_INIT_SESSION_3(drm_status) \
      ((drm_status & DRM_STATUS_DRM_INIT_SESSION_3_MASK) >> DRM_STATUS_DRM_INIT_SESSION_3_SHIFT)
#define DRM_STATUS_GET_CLIENT3_BUSY(drm_status) \
      ((drm_status & DRM_STATUS_CLIENT3_BUSY_MASK) >> DRM_STATUS_CLIENT3_BUSY_SHIFT)

#define DRM_STATUS_SET_DRM_BUSY(drm_status_reg, drm_busy) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_DRM_BUSY_MASK) | (drm_busy << DRM_STATUS_DRM_BUSY_SHIFT)
#define DRM_STATUS_SET_TRNG_BUSY(drm_status_reg, trng_busy) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_TRNG_BUSY_MASK) | (trng_busy << DRM_STATUS_TRNG_BUSY_SHIFT)
#define DRM_STATUS_SET_CLIENT1_BUSY(drm_status_reg, client1_busy) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_CLIENT1_BUSY_MASK) | (client1_busy << DRM_STATUS_CLIENT1_BUSY_SHIFT)
#define DRM_STATUS_SET_CLIENT2_BUSY(drm_status_reg, client2_busy) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_CLIENT2_BUSY_MASK) | (client2_busy << DRM_STATUS_CLIENT2_BUSY_SHIFT)
#define DRM_STATUS_SET_CLIENT0_BUSY(drm_status_reg, client0_busy) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_CLIENT0_BUSY_MASK) | (client0_busy << DRM_STATUS_CLIENT0_BUSY_SHIFT)
#define DRM_STATUS_SET_SIG_BUSY(drm_status_reg, sig_busy) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_SIG_BUSY_MASK) | (sig_busy << DRM_STATUS_SIG_BUSY_SHIFT)
#define DRM_STATUS_SET_HFS_BUSY(drm_status_reg, hfs_busy) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_HFS_BUSY_MASK) | (hfs_busy << DRM_STATUS_HFS_BUSY_SHIFT)
#define DRM_STATUS_SET_DH_BUSY2(drm_status_reg, dh_busy2) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_DH_BUSY2_MASK) | (dh_busy2 << DRM_STATUS_DH_BUSY2_SHIFT)
#define DRM_STATUS_SET_DH_BUSY1(drm_status_reg, dh_busy1) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_DH_BUSY1_MASK) | (dh_busy1 << DRM_STATUS_DH_BUSY1_SHIFT)
#define DRM_STATUS_SET_CLIENT1_PARSE_BUSY(drm_status_reg, client1_parse_busy) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_CLIENT1_PARSE_BUSY_MASK) | (client1_parse_busy << DRM_STATUS_CLIENT1_PARSE_BUSY_SHIFT)
#define DRM_STATUS_SET_CLIENT2_PARSE_BUSY(drm_status_reg, client2_parse_busy) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_CLIENT2_PARSE_BUSY_MASK) | (client2_parse_busy << DRM_STATUS_CLIENT2_PARSE_BUSY_SHIFT)
#define DRM_STATUS_SET_CLIENT0_PARSE_BUSY(drm_status_reg, client0_parse_busy) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_CLIENT0_PARSE_BUSY_MASK) | (client0_parse_busy << DRM_STATUS_CLIENT0_PARSE_BUSY_SHIFT)
#define DRM_STATUS_SET_SIG_RD_BUSY(drm_status_reg, sig_rd_busy) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_SIG_RD_BUSY_MASK) | (sig_rd_busy << DRM_STATUS_SIG_RD_BUSY_SHIFT)
#define DRM_STATUS_SET_HFS_DONE(drm_status_reg, hfs_done) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_HFS_DONE_MASK) | (hfs_done << DRM_STATUS_HFS_DONE_SHIFT)
#define DRM_STATUS_SET_DH_DONE(drm_status_reg, dh_done) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_DH_DONE_MASK) | (dh_done << DRM_STATUS_DH_DONE_SHIFT)
#define DRM_STATUS_SET_DRM_INIT(drm_status_reg, drm_init) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_DRM_INIT_MASK) | (drm_init << DRM_STATUS_DRM_INIT_SHIFT)
#define DRM_STATUS_SET_DH_ACTIVE(drm_status_reg, dh_active) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_DH_ACTIVE_MASK) | (dh_active << DRM_STATUS_DH_ACTIVE_SHIFT)
#define DRM_STATUS_SET_HFS_ACTIVE(drm_status_reg, hfs_active) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_HFS_ACTIVE_MASK) | (hfs_active << DRM_STATUS_HFS_ACTIVE_SHIFT)
#define DRM_STATUS_SET_SIG_ACTIVE(drm_status_reg, sig_active) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_SIG_ACTIVE_MASK) | (sig_active << DRM_STATUS_SIG_ACTIVE_SHIFT)
#define DRM_STATUS_SET_HFS_PASS(drm_status_reg, hfs_pass) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_HFS_PASS_MASK) | (hfs_pass << DRM_STATUS_HFS_PASS_SHIFT)
#define DRM_STATUS_SET_AUTH_STATE(drm_status_reg, auth_state) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_AUTH_STATE_MASK) | (auth_state << DRM_STATUS_AUTH_STATE_SHIFT)
#define DRM_STATUS_SET_DRM_INIT_SESSION_1(drm_status_reg, drm_init_session_1) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_DRM_INIT_SESSION_1_MASK) | (drm_init_session_1 << DRM_STATUS_DRM_INIT_SESSION_1_SHIFT)
#define DRM_STATUS_SET_DRM_INIT_SESSION_2(drm_status_reg, drm_init_session_2) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_DRM_INIT_SESSION_2_MASK) | (drm_init_session_2 << DRM_STATUS_DRM_INIT_SESSION_2_SHIFT)
#define DRM_STATUS_SET_DRM_INIT_SESSION_3(drm_status_reg, drm_init_session_3) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_DRM_INIT_SESSION_3_MASK) | (drm_init_session_3 << DRM_STATUS_DRM_INIT_SESSION_3_SHIFT)
#define DRM_STATUS_SET_CLIENT3_BUSY(drm_status_reg, client3_busy) \
      drm_status_reg = (drm_status_reg & ~DRM_STATUS_CLIENT3_BUSY_MASK) | (client3_busy << DRM_STATUS_CLIENT3_BUSY_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_status_t {
            unsigned int drm_busy                       : DRM_STATUS_DRM_BUSY_SIZE;
            unsigned int trng_busy                      : DRM_STATUS_TRNG_BUSY_SIZE;
            unsigned int client1_busy                   : DRM_STATUS_CLIENT1_BUSY_SIZE;
            unsigned int client2_busy                   : DRM_STATUS_CLIENT2_BUSY_SIZE;
            unsigned int client0_busy                   : DRM_STATUS_CLIENT0_BUSY_SIZE;
            unsigned int sig_busy                       : DRM_STATUS_SIG_BUSY_SIZE;
            unsigned int hfs_busy                       : DRM_STATUS_HFS_BUSY_SIZE;
            unsigned int dh_busy2                       : DRM_STATUS_DH_BUSY2_SIZE;
            unsigned int dh_busy1                       : DRM_STATUS_DH_BUSY1_SIZE;
            unsigned int client1_parse_busy             : DRM_STATUS_CLIENT1_PARSE_BUSY_SIZE;
            unsigned int client2_parse_busy             : DRM_STATUS_CLIENT2_PARSE_BUSY_SIZE;
            unsigned int client0_parse_busy             : DRM_STATUS_CLIENT0_PARSE_BUSY_SIZE;
            unsigned int sig_rd_busy                    : DRM_STATUS_SIG_RD_BUSY_SIZE;
            unsigned int                                : 3;
            unsigned int hfs_done                       : DRM_STATUS_HFS_DONE_SIZE;
            unsigned int dh_done                        : DRM_STATUS_DH_DONE_SIZE;
            unsigned int drm_init                       : DRM_STATUS_DRM_INIT_SIZE;
            unsigned int                                : 1;
            unsigned int dh_active                      : DRM_STATUS_DH_ACTIVE_SIZE;
            unsigned int hfs_active                     : DRM_STATUS_HFS_ACTIVE_SIZE;
            unsigned int sig_active                     : DRM_STATUS_SIG_ACTIVE_SIZE;
            unsigned int                                : 1;
            unsigned int hfs_pass                       : DRM_STATUS_HFS_PASS_SIZE;
            unsigned int auth_state                     : DRM_STATUS_AUTH_STATE_SIZE;
            unsigned int drm_init_session_1             : DRM_STATUS_DRM_INIT_SESSION_1_SIZE;
            unsigned int drm_init_session_2             : DRM_STATUS_DRM_INIT_SESSION_2_SIZE;
            unsigned int drm_init_session_3             : DRM_STATUS_DRM_INIT_SESSION_3_SIZE;
            unsigned int client3_busy                   : DRM_STATUS_CLIENT3_BUSY_SIZE;
      } drm_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_status_t {
            unsigned int client3_busy                   : DRM_STATUS_CLIENT3_BUSY_SIZE;
            unsigned int drm_init_session_3             : DRM_STATUS_DRM_INIT_SESSION_3_SIZE;
            unsigned int drm_init_session_2             : DRM_STATUS_DRM_INIT_SESSION_2_SIZE;
            unsigned int drm_init_session_1             : DRM_STATUS_DRM_INIT_SESSION_1_SIZE;
            unsigned int auth_state                     : DRM_STATUS_AUTH_STATE_SIZE;
            unsigned int hfs_pass                       : DRM_STATUS_HFS_PASS_SIZE;
            unsigned int                                : 1;
            unsigned int sig_active                     : DRM_STATUS_SIG_ACTIVE_SIZE;
            unsigned int hfs_active                     : DRM_STATUS_HFS_ACTIVE_SIZE;
            unsigned int dh_active                      : DRM_STATUS_DH_ACTIVE_SIZE;
            unsigned int                                : 1;
            unsigned int drm_init                       : DRM_STATUS_DRM_INIT_SIZE;
            unsigned int dh_done                        : DRM_STATUS_DH_DONE_SIZE;
            unsigned int hfs_done                       : DRM_STATUS_HFS_DONE_SIZE;
            unsigned int                                : 3;
            unsigned int sig_rd_busy                    : DRM_STATUS_SIG_RD_BUSY_SIZE;
            unsigned int client0_parse_busy             : DRM_STATUS_CLIENT0_PARSE_BUSY_SIZE;
            unsigned int client2_parse_busy             : DRM_STATUS_CLIENT2_PARSE_BUSY_SIZE;
            unsigned int client1_parse_busy             : DRM_STATUS_CLIENT1_PARSE_BUSY_SIZE;
            unsigned int dh_busy1                       : DRM_STATUS_DH_BUSY1_SIZE;
            unsigned int dh_busy2                       : DRM_STATUS_DH_BUSY2_SIZE;
            unsigned int hfs_busy                       : DRM_STATUS_HFS_BUSY_SIZE;
            unsigned int sig_busy                       : DRM_STATUS_SIG_BUSY_SIZE;
            unsigned int client0_busy                   : DRM_STATUS_CLIENT0_BUSY_SIZE;
            unsigned int client2_busy                   : DRM_STATUS_CLIENT2_BUSY_SIZE;
            unsigned int client1_busy                   : DRM_STATUS_CLIENT1_BUSY_SIZE;
            unsigned int trng_busy                      : DRM_STATUS_TRNG_BUSY_SIZE;
            unsigned int drm_busy                       : DRM_STATUS_DRM_BUSY_SIZE;
      } drm_status_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_status_t f;
} drm_status_u;


/*
 * DRM_PROTO_ADDR struct
 */

#define DRM_PROTO_ADDR_REG_SIZE         32
#define DRM_PROTO_ADDR_ADDR_SIZE  12

#define DRM_PROTO_ADDR_ADDR_SHIFT  0

#define DRM_PROTO_ADDR_ADDR_MASK        0x00000fff

#define DRM_PROTO_ADDR_MASK \
      (DRM_PROTO_ADDR_ADDR_MASK)

#define DRM_PROTO_ADDR_DEFAULT         0x00000000

#define DRM_PROTO_ADDR_GET_ADDR(drm_proto_addr) \
      ((drm_proto_addr & DRM_PROTO_ADDR_ADDR_MASK) >> DRM_PROTO_ADDR_ADDR_SHIFT)

#define DRM_PROTO_ADDR_SET_ADDR(drm_proto_addr_reg, addr) \
      drm_proto_addr_reg = (drm_proto_addr_reg & ~DRM_PROTO_ADDR_ADDR_MASK) | (addr << DRM_PROTO_ADDR_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_proto_addr_t {
            unsigned int addr                           : DRM_PROTO_ADDR_ADDR_SIZE;
            unsigned int                                : 20;
      } drm_proto_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_proto_addr_t {
            unsigned int                                : 20;
            unsigned int addr                           : DRM_PROTO_ADDR_ADDR_SIZE;
      } drm_proto_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_proto_addr_t f;
} drm_proto_addr_u;


/*
 * DRM_PROTO_DATA struct
 */

#define DRM_PROTO_DATA_REG_SIZE         32
#define DRM_PROTO_DATA_DATA_SIZE  32

#define DRM_PROTO_DATA_DATA_SHIFT  0

#define DRM_PROTO_DATA_DATA_MASK        0xffffffff

#define DRM_PROTO_DATA_MASK \
      (DRM_PROTO_DATA_DATA_MASK)

#define DRM_PROTO_DATA_DEFAULT         0x00000000

#define DRM_PROTO_DATA_GET_DATA(drm_proto_data) \
      ((drm_proto_data & DRM_PROTO_DATA_DATA_MASK) >> DRM_PROTO_DATA_DATA_SHIFT)

#define DRM_PROTO_DATA_SET_DATA(drm_proto_data_reg, data) \
      drm_proto_data_reg = (drm_proto_data_reg & ~DRM_PROTO_DATA_DATA_MASK) | (data << DRM_PROTO_DATA_DATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_proto_data_t {
            unsigned int data                           : DRM_PROTO_DATA_DATA_SIZE;
      } drm_proto_data_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_proto_data_t {
            unsigned int data                           : DRM_PROTO_DATA_DATA_SIZE;
      } drm_proto_data_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_proto_data_t f;
} drm_proto_data_u;


/*
 * CGTT_DRM_CLK_CTRL0 struct
 */

#define CGTT_DRM_CLK_CTRL0_REG_SIZE         32
#define CGTT_DRM_CLK_CTRL0_ON_DELAY_SIZE  4
#define CGTT_DRM_CLK_CTRL0_OFF_HYSTERESIS_SIZE  8
#define CGTT_DRM_CLK_CTRL0_DIV_ID_SIZE  3
#define CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_0_SIZE  1
#define CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_REG_SIZE  1
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE7_SIZE  1
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE6_SIZE  1
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE5_SIZE  1
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE4_SIZE  1
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE3_SIZE  1
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE2_SIZE  1
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE1_SIZE  1
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE0_SIZE  1

#define CGTT_DRM_CLK_CTRL0_ON_DELAY_SHIFT  0
#define CGTT_DRM_CLK_CTRL0_OFF_HYSTERESIS_SHIFT  4
#define CGTT_DRM_CLK_CTRL0_DIV_ID_SHIFT  12
#define CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_0_SHIFT  21
#define CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_REG_SHIFT  22
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE7_SHIFT  24
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE6_SHIFT  25
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE5_SHIFT  26
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE4_SHIFT  27
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE3_SHIFT  28
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE2_SHIFT  29
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE1_SHIFT  30
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE0_SHIFT  31

#define CGTT_DRM_CLK_CTRL0_ON_DELAY_MASK  0x0000000f
#define CGTT_DRM_CLK_CTRL0_OFF_HYSTERESIS_MASK  0x00000ff0
#define CGTT_DRM_CLK_CTRL0_DIV_ID_MASK  0x00007000
#define CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_0_MASK  0x00200000
#define CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_REG_MASK  0x00400000
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE7_MASK  0x01000000
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE6_MASK  0x02000000
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE5_MASK  0x04000000
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE4_MASK  0x08000000
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE3_MASK  0x10000000
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE2_MASK  0x20000000
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE1_MASK  0x40000000
#define CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE0_MASK  0x80000000

#define CGTT_DRM_CLK_CTRL0_MASK \
      (CGTT_DRM_CLK_CTRL0_ON_DELAY_MASK | \
      CGTT_DRM_CLK_CTRL0_OFF_HYSTERESIS_MASK | \
      CGTT_DRM_CLK_CTRL0_DIV_ID_MASK | \
      CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_0_MASK | \
      CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_REG_MASK | \
      CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE7_MASK | \
      CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE6_MASK | \
      CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE5_MASK | \
      CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE4_MASK | \
      CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE3_MASK | \
      CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE2_MASK | \
      CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE1_MASK | \
      CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE0_MASK)

#define CGTT_DRM_CLK_CTRL0_DEFAULT     0x00600100

#define CGTT_DRM_CLK_CTRL0_GET_ON_DELAY(cgtt_drm_clk_ctrl0) \
      ((cgtt_drm_clk_ctrl0 & CGTT_DRM_CLK_CTRL0_ON_DELAY_MASK) >> CGTT_DRM_CLK_CTRL0_ON_DELAY_SHIFT)
#define CGTT_DRM_CLK_CTRL0_GET_OFF_HYSTERESIS(cgtt_drm_clk_ctrl0) \
      ((cgtt_drm_clk_ctrl0 & CGTT_DRM_CLK_CTRL0_OFF_HYSTERESIS_MASK) >> CGTT_DRM_CLK_CTRL0_OFF_HYSTERESIS_SHIFT)
#define CGTT_DRM_CLK_CTRL0_GET_DIV_ID(cgtt_drm_clk_ctrl0) \
      ((cgtt_drm_clk_ctrl0 & CGTT_DRM_CLK_CTRL0_DIV_ID_MASK) >> CGTT_DRM_CLK_CTRL0_DIV_ID_SHIFT)
#define CGTT_DRM_CLK_CTRL0_GET_RAMP_DIS_CLK_0(cgtt_drm_clk_ctrl0) \
      ((cgtt_drm_clk_ctrl0 & CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_0_MASK) >> CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_0_SHIFT)
#define CGTT_DRM_CLK_CTRL0_GET_RAMP_DIS_CLK_REG(cgtt_drm_clk_ctrl0) \
      ((cgtt_drm_clk_ctrl0 & CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_REG_MASK) >> CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_REG_SHIFT)
#define CGTT_DRM_CLK_CTRL0_GET_SOFT_OVERRIDE7(cgtt_drm_clk_ctrl0) \
      ((cgtt_drm_clk_ctrl0 & CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE7_MASK) >> CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE7_SHIFT)
#define CGTT_DRM_CLK_CTRL0_GET_SOFT_OVERRIDE6(cgtt_drm_clk_ctrl0) \
      ((cgtt_drm_clk_ctrl0 & CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE6_MASK) >> CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE6_SHIFT)
#define CGTT_DRM_CLK_CTRL0_GET_SOFT_OVERRIDE5(cgtt_drm_clk_ctrl0) \
      ((cgtt_drm_clk_ctrl0 & CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE5_MASK) >> CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE5_SHIFT)
#define CGTT_DRM_CLK_CTRL0_GET_SOFT_OVERRIDE4(cgtt_drm_clk_ctrl0) \
      ((cgtt_drm_clk_ctrl0 & CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE4_MASK) >> CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE4_SHIFT)
#define CGTT_DRM_CLK_CTRL0_GET_SOFT_OVERRIDE3(cgtt_drm_clk_ctrl0) \
      ((cgtt_drm_clk_ctrl0 & CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE3_MASK) >> CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE3_SHIFT)
#define CGTT_DRM_CLK_CTRL0_GET_SOFT_OVERRIDE2(cgtt_drm_clk_ctrl0) \
      ((cgtt_drm_clk_ctrl0 & CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE2_MASK) >> CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE2_SHIFT)
#define CGTT_DRM_CLK_CTRL0_GET_SOFT_OVERRIDE1(cgtt_drm_clk_ctrl0) \
      ((cgtt_drm_clk_ctrl0 & CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE1_MASK) >> CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE1_SHIFT)
#define CGTT_DRM_CLK_CTRL0_GET_SOFT_OVERRIDE0(cgtt_drm_clk_ctrl0) \
      ((cgtt_drm_clk_ctrl0 & CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE0_MASK) >> CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE0_SHIFT)

#define CGTT_DRM_CLK_CTRL0_SET_ON_DELAY(cgtt_drm_clk_ctrl0_reg, on_delay) \
      cgtt_drm_clk_ctrl0_reg = (cgtt_drm_clk_ctrl0_reg & ~CGTT_DRM_CLK_CTRL0_ON_DELAY_MASK) | (on_delay << CGTT_DRM_CLK_CTRL0_ON_DELAY_SHIFT)
#define CGTT_DRM_CLK_CTRL0_SET_OFF_HYSTERESIS(cgtt_drm_clk_ctrl0_reg, off_hysteresis) \
      cgtt_drm_clk_ctrl0_reg = (cgtt_drm_clk_ctrl0_reg & ~CGTT_DRM_CLK_CTRL0_OFF_HYSTERESIS_MASK) | (off_hysteresis << CGTT_DRM_CLK_CTRL0_OFF_HYSTERESIS_SHIFT)
#define CGTT_DRM_CLK_CTRL0_SET_DIV_ID(cgtt_drm_clk_ctrl0_reg, div_id) \
      cgtt_drm_clk_ctrl0_reg = (cgtt_drm_clk_ctrl0_reg & ~CGTT_DRM_CLK_CTRL0_DIV_ID_MASK) | (div_id << CGTT_DRM_CLK_CTRL0_DIV_ID_SHIFT)
#define CGTT_DRM_CLK_CTRL0_SET_RAMP_DIS_CLK_0(cgtt_drm_clk_ctrl0_reg, ramp_dis_clk_0) \
      cgtt_drm_clk_ctrl0_reg = (cgtt_drm_clk_ctrl0_reg & ~CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_0_MASK) | (ramp_dis_clk_0 << CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_0_SHIFT)
#define CGTT_DRM_CLK_CTRL0_SET_RAMP_DIS_CLK_REG(cgtt_drm_clk_ctrl0_reg, ramp_dis_clk_reg) \
      cgtt_drm_clk_ctrl0_reg = (cgtt_drm_clk_ctrl0_reg & ~CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_REG_MASK) | (ramp_dis_clk_reg << CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_REG_SHIFT)
#define CGTT_DRM_CLK_CTRL0_SET_SOFT_OVERRIDE7(cgtt_drm_clk_ctrl0_reg, soft_override7) \
      cgtt_drm_clk_ctrl0_reg = (cgtt_drm_clk_ctrl0_reg & ~CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE7_MASK) | (soft_override7 << CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE7_SHIFT)
#define CGTT_DRM_CLK_CTRL0_SET_SOFT_OVERRIDE6(cgtt_drm_clk_ctrl0_reg, soft_override6) \
      cgtt_drm_clk_ctrl0_reg = (cgtt_drm_clk_ctrl0_reg & ~CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE6_MASK) | (soft_override6 << CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE6_SHIFT)
#define CGTT_DRM_CLK_CTRL0_SET_SOFT_OVERRIDE5(cgtt_drm_clk_ctrl0_reg, soft_override5) \
      cgtt_drm_clk_ctrl0_reg = (cgtt_drm_clk_ctrl0_reg & ~CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE5_MASK) | (soft_override5 << CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE5_SHIFT)
#define CGTT_DRM_CLK_CTRL0_SET_SOFT_OVERRIDE4(cgtt_drm_clk_ctrl0_reg, soft_override4) \
      cgtt_drm_clk_ctrl0_reg = (cgtt_drm_clk_ctrl0_reg & ~CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE4_MASK) | (soft_override4 << CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE4_SHIFT)
#define CGTT_DRM_CLK_CTRL0_SET_SOFT_OVERRIDE3(cgtt_drm_clk_ctrl0_reg, soft_override3) \
      cgtt_drm_clk_ctrl0_reg = (cgtt_drm_clk_ctrl0_reg & ~CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE3_MASK) | (soft_override3 << CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE3_SHIFT)
#define CGTT_DRM_CLK_CTRL0_SET_SOFT_OVERRIDE2(cgtt_drm_clk_ctrl0_reg, soft_override2) \
      cgtt_drm_clk_ctrl0_reg = (cgtt_drm_clk_ctrl0_reg & ~CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE2_MASK) | (soft_override2 << CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE2_SHIFT)
#define CGTT_DRM_CLK_CTRL0_SET_SOFT_OVERRIDE1(cgtt_drm_clk_ctrl0_reg, soft_override1) \
      cgtt_drm_clk_ctrl0_reg = (cgtt_drm_clk_ctrl0_reg & ~CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE1_MASK) | (soft_override1 << CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE1_SHIFT)
#define CGTT_DRM_CLK_CTRL0_SET_SOFT_OVERRIDE0(cgtt_drm_clk_ctrl0_reg, soft_override0) \
      cgtt_drm_clk_ctrl0_reg = (cgtt_drm_clk_ctrl0_reg & ~CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE0_MASK) | (soft_override0 << CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct cgtt_drm_clk_ctrl0_t {
            unsigned int on_delay                       : CGTT_DRM_CLK_CTRL0_ON_DELAY_SIZE;
            unsigned int off_hysteresis                 : CGTT_DRM_CLK_CTRL0_OFF_HYSTERESIS_SIZE;
            unsigned int div_id                         : CGTT_DRM_CLK_CTRL0_DIV_ID_SIZE;
            unsigned int                                : 6;
            unsigned int ramp_dis_clk_0                 : CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_0_SIZE;
            unsigned int ramp_dis_clk_reg               : CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_REG_SIZE;
            unsigned int                                : 1;
            unsigned int soft_override7                 : CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE7_SIZE;
            unsigned int soft_override6                 : CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE6_SIZE;
            unsigned int soft_override5                 : CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE5_SIZE;
            unsigned int soft_override4                 : CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE4_SIZE;
            unsigned int soft_override3                 : CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE3_SIZE;
            unsigned int soft_override2                 : CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE2_SIZE;
            unsigned int soft_override1                 : CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE1_SIZE;
            unsigned int soft_override0                 : CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE0_SIZE;
      } cgtt_drm_clk_ctrl0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct cgtt_drm_clk_ctrl0_t {
            unsigned int soft_override0                 : CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE0_SIZE;
            unsigned int soft_override1                 : CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE1_SIZE;
            unsigned int soft_override2                 : CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE2_SIZE;
            unsigned int soft_override3                 : CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE3_SIZE;
            unsigned int soft_override4                 : CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE4_SIZE;
            unsigned int soft_override5                 : CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE5_SIZE;
            unsigned int soft_override6                 : CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE6_SIZE;
            unsigned int soft_override7                 : CGTT_DRM_CLK_CTRL0_SOFT_OVERRIDE7_SIZE;
            unsigned int                                : 1;
            unsigned int ramp_dis_clk_reg               : CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_REG_SIZE;
            unsigned int ramp_dis_clk_0                 : CGTT_DRM_CLK_CTRL0_RAMP_DIS_CLK_0_SIZE;
            unsigned int                                : 6;
            unsigned int div_id                         : CGTT_DRM_CLK_CTRL0_DIV_ID_SIZE;
            unsigned int off_hysteresis                 : CGTT_DRM_CLK_CTRL0_OFF_HYSTERESIS_SIZE;
            unsigned int on_delay                       : CGTT_DRM_CLK_CTRL0_ON_DELAY_SIZE;
      } cgtt_drm_clk_ctrl0_t;

#endif

typedef union {
     unsigned int val : 32;
          cgtt_drm_clk_ctrl0_t f;
} cgtt_drm_clk_ctrl0_u;


/*
 * DRM_MASTER_CTRL struct
 */

#define DRM_MASTER_CTRL_REG_SIZE         32
#define DRM_MASTER_CTRL_MEM_LIGHT_SLEEP_EN_SIZE  1
#define DRM_MASTER_CTRL_LEGACY_SIG_CHECK_EN_SIZE  1
#define DRM_MASTER_CTRL_MULTI_SESSION_EN_SIZE  1
#define DRM_MASTER_CTRL_MEM_SHUT_DOWN_EN_SIZE  1

#define DRM_MASTER_CTRL_MEM_LIGHT_SLEEP_EN_SHIFT  0
#define DRM_MASTER_CTRL_LEGACY_SIG_CHECK_EN_SHIFT  1
#define DRM_MASTER_CTRL_MULTI_SESSION_EN_SHIFT  2
#define DRM_MASTER_CTRL_MEM_SHUT_DOWN_EN_SHIFT  3

#define DRM_MASTER_CTRL_MEM_LIGHT_SLEEP_EN_MASK  0x00000001
#define DRM_MASTER_CTRL_LEGACY_SIG_CHECK_EN_MASK  0x00000002
#define DRM_MASTER_CTRL_MULTI_SESSION_EN_MASK  0x00000004
#define DRM_MASTER_CTRL_MEM_SHUT_DOWN_EN_MASK  0x00000008

#define DRM_MASTER_CTRL_MASK \
      (DRM_MASTER_CTRL_MEM_LIGHT_SLEEP_EN_MASK | \
      DRM_MASTER_CTRL_LEGACY_SIG_CHECK_EN_MASK | \
      DRM_MASTER_CTRL_MULTI_SESSION_EN_MASK | \
      DRM_MASTER_CTRL_MEM_SHUT_DOWN_EN_MASK)

#define DRM_MASTER_CTRL_DEFAULT        0x00000000

#define DRM_MASTER_CTRL_GET_MEM_LIGHT_SLEEP_EN(drm_master_ctrl) \
      ((drm_master_ctrl & DRM_MASTER_CTRL_MEM_LIGHT_SLEEP_EN_MASK) >> DRM_MASTER_CTRL_MEM_LIGHT_SLEEP_EN_SHIFT)
#define DRM_MASTER_CTRL_GET_LEGACY_SIG_CHECK_EN(drm_master_ctrl) \
      ((drm_master_ctrl & DRM_MASTER_CTRL_LEGACY_SIG_CHECK_EN_MASK) >> DRM_MASTER_CTRL_LEGACY_SIG_CHECK_EN_SHIFT)
#define DRM_MASTER_CTRL_GET_MULTI_SESSION_EN(drm_master_ctrl) \
      ((drm_master_ctrl & DRM_MASTER_CTRL_MULTI_SESSION_EN_MASK) >> DRM_MASTER_CTRL_MULTI_SESSION_EN_SHIFT)
#define DRM_MASTER_CTRL_GET_MEM_SHUT_DOWN_EN(drm_master_ctrl) \
      ((drm_master_ctrl & DRM_MASTER_CTRL_MEM_SHUT_DOWN_EN_MASK) >> DRM_MASTER_CTRL_MEM_SHUT_DOWN_EN_SHIFT)

#define DRM_MASTER_CTRL_SET_MEM_LIGHT_SLEEP_EN(drm_master_ctrl_reg, mem_light_sleep_en) \
      drm_master_ctrl_reg = (drm_master_ctrl_reg & ~DRM_MASTER_CTRL_MEM_LIGHT_SLEEP_EN_MASK) | (mem_light_sleep_en << DRM_MASTER_CTRL_MEM_LIGHT_SLEEP_EN_SHIFT)
#define DRM_MASTER_CTRL_SET_LEGACY_SIG_CHECK_EN(drm_master_ctrl_reg, legacy_sig_check_en) \
      drm_master_ctrl_reg = (drm_master_ctrl_reg & ~DRM_MASTER_CTRL_LEGACY_SIG_CHECK_EN_MASK) | (legacy_sig_check_en << DRM_MASTER_CTRL_LEGACY_SIG_CHECK_EN_SHIFT)
#define DRM_MASTER_CTRL_SET_MULTI_SESSION_EN(drm_master_ctrl_reg, multi_session_en) \
      drm_master_ctrl_reg = (drm_master_ctrl_reg & ~DRM_MASTER_CTRL_MULTI_SESSION_EN_MASK) | (multi_session_en << DRM_MASTER_CTRL_MULTI_SESSION_EN_SHIFT)
#define DRM_MASTER_CTRL_SET_MEM_SHUT_DOWN_EN(drm_master_ctrl_reg, mem_shut_down_en) \
      drm_master_ctrl_reg = (drm_master_ctrl_reg & ~DRM_MASTER_CTRL_MEM_SHUT_DOWN_EN_MASK) | (mem_shut_down_en << DRM_MASTER_CTRL_MEM_SHUT_DOWN_EN_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_master_ctrl_t {
            unsigned int mem_light_sleep_en             : DRM_MASTER_CTRL_MEM_LIGHT_SLEEP_EN_SIZE;
            unsigned int legacy_sig_check_en            : DRM_MASTER_CTRL_LEGACY_SIG_CHECK_EN_SIZE;
            unsigned int multi_session_en               : DRM_MASTER_CTRL_MULTI_SESSION_EN_SIZE;
            unsigned int mem_shut_down_en               : DRM_MASTER_CTRL_MEM_SHUT_DOWN_EN_SIZE;
            unsigned int                                : 28;
      } drm_master_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_master_ctrl_t {
            unsigned int                                : 28;
            unsigned int mem_shut_down_en               : DRM_MASTER_CTRL_MEM_SHUT_DOWN_EN_SIZE;
            unsigned int multi_session_en               : DRM_MASTER_CTRL_MULTI_SESSION_EN_SIZE;
            unsigned int legacy_sig_check_en            : DRM_MASTER_CTRL_LEGACY_SIG_CHECK_EN_SIZE;
            unsigned int mem_light_sleep_en             : DRM_MASTER_CTRL_MEM_LIGHT_SLEEP_EN_SIZE;
      } drm_master_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_master_ctrl_t f;
} drm_master_ctrl_u;


/*
 * DRM_AUTH_SESSION struct
 */

#define DRM_AUTH_SESSION_REG_SIZE         32
#define DRM_AUTH_SESSION_SELECT_SIZE  4

#define DRM_AUTH_SESSION_SELECT_SHIFT  0

#define DRM_AUTH_SESSION_SELECT_MASK    0x0000000f

#define DRM_AUTH_SESSION_MASK \
      (DRM_AUTH_SESSION_SELECT_MASK)

#define DRM_AUTH_SESSION_DEFAULT       0x00000000

#define DRM_AUTH_SESSION_GET_SELECT(drm_auth_session) \
      ((drm_auth_session & DRM_AUTH_SESSION_SELECT_MASK) >> DRM_AUTH_SESSION_SELECT_SHIFT)

#define DRM_AUTH_SESSION_SET_SELECT(drm_auth_session_reg, select) \
      drm_auth_session_reg = (drm_auth_session_reg & ~DRM_AUTH_SESSION_SELECT_MASK) | (select << DRM_AUTH_SESSION_SELECT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_auth_session_t {
            unsigned int select                         : DRM_AUTH_SESSION_SELECT_SIZE;
            unsigned int                                : 28;
      } drm_auth_session_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_auth_session_t {
            unsigned int                                : 28;
            unsigned int select                         : DRM_AUTH_SESSION_SELECT_SIZE;
      } drm_auth_session_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_auth_session_t f;
} drm_auth_session_u;


/*
 * DH_TEST struct
 */

#define DH_TEST_REG_SIZE         32
#define DH_TEST_DH_TEST_SIZE  1

#define DH_TEST_DH_TEST_SHIFT  0

#define DH_TEST_DH_TEST_MASK            0x00000001

#define DH_TEST_MASK \
      (DH_TEST_DH_TEST_MASK)

#define DH_TEST_DEFAULT                0x00000000

#define DH_TEST_GET_DH_TEST(dh_test) \
      ((dh_test & DH_TEST_DH_TEST_MASK) >> DH_TEST_DH_TEST_SHIFT)

#define DH_TEST_SET_DH_TEST(dh_test_reg, dh_test) \
      dh_test_reg = (dh_test_reg & ~DH_TEST_DH_TEST_MASK) | (dh_test << DH_TEST_DH_TEST_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct dh_test_t {
            unsigned int dh_test                        : DH_TEST_DH_TEST_SIZE;
            unsigned int                                : 31;
      } dh_test_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct dh_test_t {
            unsigned int                                : 31;
            unsigned int dh_test                        : DH_TEST_DH_TEST_SIZE;
      } dh_test_t;

#endif

typedef union {
     unsigned int val : 32;
          dh_test_t f;
} dh_test_u;


/*
 * KHFS0 struct
 */

#define KHFS0_REG_SIZE         32
#define KHFS0_RESERVED_SIZE  32

#define KHFS0_RESERVED_SHIFT  0

#define KHFS0_RESERVED_MASK             0xffffffff

#define KHFS0_MASK \
      (KHFS0_RESERVED_MASK)

#define KHFS0_DEFAULT                  0x00000000

#define KHFS0_GET_RESERVED(khfs0) \
      ((khfs0 & KHFS0_RESERVED_MASK) >> KHFS0_RESERVED_SHIFT)

#define KHFS0_SET_RESERVED(khfs0_reg, reserved) \
      khfs0_reg = (khfs0_reg & ~KHFS0_RESERVED_MASK) | (reserved << KHFS0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct khfs0_t {
            unsigned int reserved                       : KHFS0_RESERVED_SIZE;
      } khfs0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct khfs0_t {
            unsigned int reserved                       : KHFS0_RESERVED_SIZE;
      } khfs0_t;

#endif

typedef union {
     unsigned int val : 32;
          khfs0_t f;
} khfs0_u;


/*
 * KHFS1 struct
 */

#define KHFS1_REG_SIZE         32
#define KHFS1_RESERVED_SIZE  32

#define KHFS1_RESERVED_SHIFT  0

#define KHFS1_RESERVED_MASK             0xffffffff

#define KHFS1_MASK \
      (KHFS1_RESERVED_MASK)

#define KHFS1_DEFAULT                  0x00000000

#define KHFS1_GET_RESERVED(khfs1) \
      ((khfs1 & KHFS1_RESERVED_MASK) >> KHFS1_RESERVED_SHIFT)

#define KHFS1_SET_RESERVED(khfs1_reg, reserved) \
      khfs1_reg = (khfs1_reg & ~KHFS1_RESERVED_MASK) | (reserved << KHFS1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct khfs1_t {
            unsigned int reserved                       : KHFS1_RESERVED_SIZE;
      } khfs1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct khfs1_t {
            unsigned int reserved                       : KHFS1_RESERVED_SIZE;
      } khfs1_t;

#endif

typedef union {
     unsigned int val : 32;
          khfs1_t f;
} khfs1_u;


/*
 * KHFS2 struct
 */

#define KHFS2_REG_SIZE         32
#define KHFS2_RESERVED_SIZE  32

#define KHFS2_RESERVED_SHIFT  0

#define KHFS2_RESERVED_MASK             0xffffffff

#define KHFS2_MASK \
      (KHFS2_RESERVED_MASK)

#define KHFS2_DEFAULT                  0x00000000

#define KHFS2_GET_RESERVED(khfs2) \
      ((khfs2 & KHFS2_RESERVED_MASK) >> KHFS2_RESERVED_SHIFT)

#define KHFS2_SET_RESERVED(khfs2_reg, reserved) \
      khfs2_reg = (khfs2_reg & ~KHFS2_RESERVED_MASK) | (reserved << KHFS2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct khfs2_t {
            unsigned int reserved                       : KHFS2_RESERVED_SIZE;
      } khfs2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct khfs2_t {
            unsigned int reserved                       : KHFS2_RESERVED_SIZE;
      } khfs2_t;

#endif

typedef union {
     unsigned int val : 32;
          khfs2_t f;
} khfs2_u;


/*
 * KHFS3 struct
 */

#define KHFS3_REG_SIZE         32
#define KHFS3_RESERVED_SIZE  32

#define KHFS3_RESERVED_SHIFT  0

#define KHFS3_RESERVED_MASK             0xffffffff

#define KHFS3_MASK \
      (KHFS3_RESERVED_MASK)

#define KHFS3_DEFAULT                  0x00000000

#define KHFS3_GET_RESERVED(khfs3) \
      ((khfs3 & KHFS3_RESERVED_MASK) >> KHFS3_RESERVED_SHIFT)

#define KHFS3_SET_RESERVED(khfs3_reg, reserved) \
      khfs3_reg = (khfs3_reg & ~KHFS3_RESERVED_MASK) | (reserved << KHFS3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct khfs3_t {
            unsigned int reserved                       : KHFS3_RESERVED_SIZE;
      } khfs3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct khfs3_t {
            unsigned int reserved                       : KHFS3_RESERVED_SIZE;
      } khfs3_t;

#endif

typedef union {
     unsigned int val : 32;
          khfs3_t f;
} khfs3_u;


/*
 * KSESSION0 struct
 */

#define KSESSION0_REG_SIZE         32
#define KSESSION0_RESERVED_SIZE  32

#define KSESSION0_RESERVED_SHIFT  0

#define KSESSION0_RESERVED_MASK         0xffffffff

#define KSESSION0_MASK \
      (KSESSION0_RESERVED_MASK)

#define KSESSION0_DEFAULT              0x00000000

#define KSESSION0_GET_RESERVED(ksession0) \
      ((ksession0 & KSESSION0_RESERVED_MASK) >> KSESSION0_RESERVED_SHIFT)

#define KSESSION0_SET_RESERVED(ksession0_reg, reserved) \
      ksession0_reg = (ksession0_reg & ~KSESSION0_RESERVED_MASK) | (reserved << KSESSION0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ksession0_t {
            unsigned int reserved                       : KSESSION0_RESERVED_SIZE;
      } ksession0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ksession0_t {
            unsigned int reserved                       : KSESSION0_RESERVED_SIZE;
      } ksession0_t;

#endif

typedef union {
     unsigned int val : 32;
          ksession0_t f;
} ksession0_u;


/*
 * KSESSION1 struct
 */

#define KSESSION1_REG_SIZE         32
#define KSESSION1_RESERVED_SIZE  32

#define KSESSION1_RESERVED_SHIFT  0

#define KSESSION1_RESERVED_MASK         0xffffffff

#define KSESSION1_MASK \
      (KSESSION1_RESERVED_MASK)

#define KSESSION1_DEFAULT              0x00000000

#define KSESSION1_GET_RESERVED(ksession1) \
      ((ksession1 & KSESSION1_RESERVED_MASK) >> KSESSION1_RESERVED_SHIFT)

#define KSESSION1_SET_RESERVED(ksession1_reg, reserved) \
      ksession1_reg = (ksession1_reg & ~KSESSION1_RESERVED_MASK) | (reserved << KSESSION1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ksession1_t {
            unsigned int reserved                       : KSESSION1_RESERVED_SIZE;
      } ksession1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ksession1_t {
            unsigned int reserved                       : KSESSION1_RESERVED_SIZE;
      } ksession1_t;

#endif

typedef union {
     unsigned int val : 32;
          ksession1_t f;
} ksession1_u;


/*
 * KSESSION2 struct
 */

#define KSESSION2_REG_SIZE         32
#define KSESSION2_RESERVED_SIZE  32

#define KSESSION2_RESERVED_SHIFT  0

#define KSESSION2_RESERVED_MASK         0xffffffff

#define KSESSION2_MASK \
      (KSESSION2_RESERVED_MASK)

#define KSESSION2_DEFAULT              0x00000000

#define KSESSION2_GET_RESERVED(ksession2) \
      ((ksession2 & KSESSION2_RESERVED_MASK) >> KSESSION2_RESERVED_SHIFT)

#define KSESSION2_SET_RESERVED(ksession2_reg, reserved) \
      ksession2_reg = (ksession2_reg & ~KSESSION2_RESERVED_MASK) | (reserved << KSESSION2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ksession2_t {
            unsigned int reserved                       : KSESSION2_RESERVED_SIZE;
      } ksession2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ksession2_t {
            unsigned int reserved                       : KSESSION2_RESERVED_SIZE;
      } ksession2_t;

#endif

typedef union {
     unsigned int val : 32;
          ksession2_t f;
} ksession2_u;


/*
 * KSESSION3 struct
 */

#define KSESSION3_REG_SIZE         32
#define KSESSION3_RESERVED_SIZE  32

#define KSESSION3_RESERVED_SHIFT  0

#define KSESSION3_RESERVED_MASK         0xffffffff

#define KSESSION3_MASK \
      (KSESSION3_RESERVED_MASK)

#define KSESSION3_DEFAULT              0x00000000

#define KSESSION3_GET_RESERVED(ksession3) \
      ((ksession3 & KSESSION3_RESERVED_MASK) >> KSESSION3_RESERVED_SHIFT)

#define KSESSION3_SET_RESERVED(ksession3_reg, reserved) \
      ksession3_reg = (ksession3_reg & ~KSESSION3_RESERVED_MASK) | (reserved << KSESSION3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ksession3_t {
            unsigned int reserved                       : KSESSION3_RESERVED_SIZE;
      } ksession3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ksession3_t {
            unsigned int reserved                       : KSESSION3_RESERVED_SIZE;
      } ksession3_t;

#endif

typedef union {
     unsigned int val : 32;
          ksession3_t f;
} ksession3_u;


/*
 * KSIG0 struct
 */

#define KSIG0_REG_SIZE         32
#define KSIG0_RESERVED_SIZE  32

#define KSIG0_RESERVED_SHIFT  0

#define KSIG0_RESERVED_MASK             0xffffffff

#define KSIG0_MASK \
      (KSIG0_RESERVED_MASK)

#define KSIG0_DEFAULT                  0x00000000

#define KSIG0_GET_RESERVED(ksig0) \
      ((ksig0 & KSIG0_RESERVED_MASK) >> KSIG0_RESERVED_SHIFT)

#define KSIG0_SET_RESERVED(ksig0_reg, reserved) \
      ksig0_reg = (ksig0_reg & ~KSIG0_RESERVED_MASK) | (reserved << KSIG0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ksig0_t {
            unsigned int reserved                       : KSIG0_RESERVED_SIZE;
      } ksig0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ksig0_t {
            unsigned int reserved                       : KSIG0_RESERVED_SIZE;
      } ksig0_t;

#endif

typedef union {
     unsigned int val : 32;
          ksig0_t f;
} ksig0_u;


/*
 * KSIG1 struct
 */

#define KSIG1_REG_SIZE         32
#define KSIG1_RESERVED_SIZE  32

#define KSIG1_RESERVED_SHIFT  0

#define KSIG1_RESERVED_MASK             0xffffffff

#define KSIG1_MASK \
      (KSIG1_RESERVED_MASK)

#define KSIG1_DEFAULT                  0x00000000

#define KSIG1_GET_RESERVED(ksig1) \
      ((ksig1 & KSIG1_RESERVED_MASK) >> KSIG1_RESERVED_SHIFT)

#define KSIG1_SET_RESERVED(ksig1_reg, reserved) \
      ksig1_reg = (ksig1_reg & ~KSIG1_RESERVED_MASK) | (reserved << KSIG1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ksig1_t {
            unsigned int reserved                       : KSIG1_RESERVED_SIZE;
      } ksig1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ksig1_t {
            unsigned int reserved                       : KSIG1_RESERVED_SIZE;
      } ksig1_t;

#endif

typedef union {
     unsigned int val : 32;
          ksig1_t f;
} ksig1_u;


/*
 * KSIG2 struct
 */

#define KSIG2_REG_SIZE         32
#define KSIG2_RESERVED_SIZE  32

#define KSIG2_RESERVED_SHIFT  0

#define KSIG2_RESERVED_MASK             0xffffffff

#define KSIG2_MASK \
      (KSIG2_RESERVED_MASK)

#define KSIG2_DEFAULT                  0x00000000

#define KSIG2_GET_RESERVED(ksig2) \
      ((ksig2 & KSIG2_RESERVED_MASK) >> KSIG2_RESERVED_SHIFT)

#define KSIG2_SET_RESERVED(ksig2_reg, reserved) \
      ksig2_reg = (ksig2_reg & ~KSIG2_RESERVED_MASK) | (reserved << KSIG2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ksig2_t {
            unsigned int reserved                       : KSIG2_RESERVED_SIZE;
      } ksig2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ksig2_t {
            unsigned int reserved                       : KSIG2_RESERVED_SIZE;
      } ksig2_t;

#endif

typedef union {
     unsigned int val : 32;
          ksig2_t f;
} ksig2_u;


/*
 * KSIG3 struct
 */

#define KSIG3_REG_SIZE         32
#define KSIG3_RESERVED_SIZE  32

#define KSIG3_RESERVED_SHIFT  0

#define KSIG3_RESERVED_MASK             0xffffffff

#define KSIG3_MASK \
      (KSIG3_RESERVED_MASK)

#define KSIG3_DEFAULT                  0x00000000

#define KSIG3_GET_RESERVED(ksig3) \
      ((ksig3 & KSIG3_RESERVED_MASK) >> KSIG3_RESERVED_SHIFT)

#define KSIG3_SET_RESERVED(ksig3_reg, reserved) \
      ksig3_reg = (ksig3_reg & ~KSIG3_RESERVED_MASK) | (reserved << KSIG3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ksig3_t {
            unsigned int reserved                       : KSIG3_RESERVED_SIZE;
      } ksig3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ksig3_t {
            unsigned int reserved                       : KSIG3_RESERVED_SIZE;
      } ksig3_t;

#endif

typedef union {
     unsigned int val : 32;
          ksig3_t f;
} ksig3_u;


/*
 * EXP0 struct
 */

#define EXP0_REG_SIZE         32
#define EXP0_RESERVED_SIZE  32

#define EXP0_RESERVED_SHIFT  0

#define EXP0_RESERVED_MASK              0xffffffff

#define EXP0_MASK \
      (EXP0_RESERVED_MASK)

#define EXP0_DEFAULT                   0x00000000

#define EXP0_GET_RESERVED(exp0) \
      ((exp0 & EXP0_RESERVED_MASK) >> EXP0_RESERVED_SHIFT)

#define EXP0_SET_RESERVED(exp0_reg, reserved) \
      exp0_reg = (exp0_reg & ~EXP0_RESERVED_MASK) | (reserved << EXP0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct exp0_t {
            unsigned int reserved                       : EXP0_RESERVED_SIZE;
      } exp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct exp0_t {
            unsigned int reserved                       : EXP0_RESERVED_SIZE;
      } exp0_t;

#endif

typedef union {
     unsigned int val : 32;
          exp0_t f;
} exp0_u;


/*
 * EXP1 struct
 */

#define EXP1_REG_SIZE         32
#define EXP1_RESERVED_SIZE  32

#define EXP1_RESERVED_SHIFT  0

#define EXP1_RESERVED_MASK              0xffffffff

#define EXP1_MASK \
      (EXP1_RESERVED_MASK)

#define EXP1_DEFAULT                   0x00000000

#define EXP1_GET_RESERVED(exp1) \
      ((exp1 & EXP1_RESERVED_MASK) >> EXP1_RESERVED_SHIFT)

#define EXP1_SET_RESERVED(exp1_reg, reserved) \
      exp1_reg = (exp1_reg & ~EXP1_RESERVED_MASK) | (reserved << EXP1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct exp1_t {
            unsigned int reserved                       : EXP1_RESERVED_SIZE;
      } exp1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct exp1_t {
            unsigned int reserved                       : EXP1_RESERVED_SIZE;
      } exp1_t;

#endif

typedef union {
     unsigned int val : 32;
          exp1_t f;
} exp1_u;


/*
 * EXP2 struct
 */

#define EXP2_REG_SIZE         32
#define EXP2_RESERVED_SIZE  32

#define EXP2_RESERVED_SHIFT  0

#define EXP2_RESERVED_MASK              0xffffffff

#define EXP2_MASK \
      (EXP2_RESERVED_MASK)

#define EXP2_DEFAULT                   0x00000000

#define EXP2_GET_RESERVED(exp2) \
      ((exp2 & EXP2_RESERVED_MASK) >> EXP2_RESERVED_SHIFT)

#define EXP2_SET_RESERVED(exp2_reg, reserved) \
      exp2_reg = (exp2_reg & ~EXP2_RESERVED_MASK) | (reserved << EXP2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct exp2_t {
            unsigned int reserved                       : EXP2_RESERVED_SIZE;
      } exp2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct exp2_t {
            unsigned int reserved                       : EXP2_RESERVED_SIZE;
      } exp2_t;

#endif

typedef union {
     unsigned int val : 32;
          exp2_t f;
} exp2_u;


/*
 * EXP3 struct
 */

#define EXP3_REG_SIZE         32
#define EXP3_RESERVED_SIZE  32

#define EXP3_RESERVED_SHIFT  0

#define EXP3_RESERVED_MASK              0xffffffff

#define EXP3_MASK \
      (EXP3_RESERVED_MASK)

#define EXP3_DEFAULT                   0x00000000

#define EXP3_GET_RESERVED(exp3) \
      ((exp3 & EXP3_RESERVED_MASK) >> EXP3_RESERVED_SHIFT)

#define EXP3_SET_RESERVED(exp3_reg, reserved) \
      exp3_reg = (exp3_reg & ~EXP3_RESERVED_MASK) | (reserved << EXP3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct exp3_t {
            unsigned int reserved                       : EXP3_RESERVED_SIZE;
      } exp3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct exp3_t {
            unsigned int reserved                       : EXP3_RESERVED_SIZE;
      } exp3_t;

#endif

typedef union {
     unsigned int val : 32;
          exp3_t f;
} exp3_u;


/*
 * EXP4 struct
 */

#define EXP4_REG_SIZE         32
#define EXP4_RESERVED_SIZE  32

#define EXP4_RESERVED_SHIFT  0

#define EXP4_RESERVED_MASK              0xffffffff

#define EXP4_MASK \
      (EXP4_RESERVED_MASK)

#define EXP4_DEFAULT                   0x00000000

#define EXP4_GET_RESERVED(exp4) \
      ((exp4 & EXP4_RESERVED_MASK) >> EXP4_RESERVED_SHIFT)

#define EXP4_SET_RESERVED(exp4_reg, reserved) \
      exp4_reg = (exp4_reg & ~EXP4_RESERVED_MASK) | (reserved << EXP4_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct exp4_t {
            unsigned int reserved                       : EXP4_RESERVED_SIZE;
      } exp4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct exp4_t {
            unsigned int reserved                       : EXP4_RESERVED_SIZE;
      } exp4_t;

#endif

typedef union {
     unsigned int val : 32;
          exp4_t f;
} exp4_u;


/*
 * EXP5 struct
 */

#define EXP5_REG_SIZE         32
#define EXP5_RESERVED_SIZE  32

#define EXP5_RESERVED_SHIFT  0

#define EXP5_RESERVED_MASK              0xffffffff

#define EXP5_MASK \
      (EXP5_RESERVED_MASK)

#define EXP5_DEFAULT                   0x00000000

#define EXP5_GET_RESERVED(exp5) \
      ((exp5 & EXP5_RESERVED_MASK) >> EXP5_RESERVED_SHIFT)

#define EXP5_SET_RESERVED(exp5_reg, reserved) \
      exp5_reg = (exp5_reg & ~EXP5_RESERVED_MASK) | (reserved << EXP5_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct exp5_t {
            unsigned int reserved                       : EXP5_RESERVED_SIZE;
      } exp5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct exp5_t {
            unsigned int reserved                       : EXP5_RESERVED_SIZE;
      } exp5_t;

#endif

typedef union {
     unsigned int val : 32;
          exp5_t f;
} exp5_u;


/*
 * EXP6 struct
 */

#define EXP6_REG_SIZE         32
#define EXP6_RESERVED_SIZE  32

#define EXP6_RESERVED_SHIFT  0

#define EXP6_RESERVED_MASK              0xffffffff

#define EXP6_MASK \
      (EXP6_RESERVED_MASK)

#define EXP6_DEFAULT                   0x00000000

#define EXP6_GET_RESERVED(exp6) \
      ((exp6 & EXP6_RESERVED_MASK) >> EXP6_RESERVED_SHIFT)

#define EXP6_SET_RESERVED(exp6_reg, reserved) \
      exp6_reg = (exp6_reg & ~EXP6_RESERVED_MASK) | (reserved << EXP6_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct exp6_t {
            unsigned int reserved                       : EXP6_RESERVED_SIZE;
      } exp6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct exp6_t {
            unsigned int reserved                       : EXP6_RESERVED_SIZE;
      } exp6_t;

#endif

typedef union {
     unsigned int val : 32;
          exp6_t f;
} exp6_u;


/*
 * EXP7 struct
 */

#define EXP7_REG_SIZE         32
#define EXP7_RESERVED_SIZE  32

#define EXP7_RESERVED_SHIFT  0

#define EXP7_RESERVED_MASK              0xffffffff

#define EXP7_MASK \
      (EXP7_RESERVED_MASK)

#define EXP7_DEFAULT                   0x00000000

#define EXP7_GET_RESERVED(exp7) \
      ((exp7 & EXP7_RESERVED_MASK) >> EXP7_RESERVED_SHIFT)

#define EXP7_SET_RESERVED(exp7_reg, reserved) \
      exp7_reg = (exp7_reg & ~EXP7_RESERVED_MASK) | (reserved << EXP7_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct exp7_t {
            unsigned int reserved                       : EXP7_RESERVED_SIZE;
      } exp7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct exp7_t {
            unsigned int reserved                       : EXP7_RESERVED_SIZE;
      } exp7_t;

#endif

typedef union {
     unsigned int val : 32;
          exp7_t f;
} exp7_u;


/*
 * LX0 struct
 */

#define LX0_REG_SIZE         32
#define LX0_RESERVED_SIZE  32

#define LX0_RESERVED_SHIFT  0

#define LX0_RESERVED_MASK               0xffffffff

#define LX0_MASK \
      (LX0_RESERVED_MASK)

#define LX0_DEFAULT                    0x00000000

#define LX0_GET_RESERVED(lx0) \
      ((lx0 & LX0_RESERVED_MASK) >> LX0_RESERVED_SHIFT)

#define LX0_SET_RESERVED(lx0_reg, reserved) \
      lx0_reg = (lx0_reg & ~LX0_RESERVED_MASK) | (reserved << LX0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct lx0_t {
            unsigned int reserved                       : LX0_RESERVED_SIZE;
      } lx0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct lx0_t {
            unsigned int reserved                       : LX0_RESERVED_SIZE;
      } lx0_t;

#endif

typedef union {
     unsigned int val : 32;
          lx0_t f;
} lx0_u;


/*
 * LX1 struct
 */

#define LX1_REG_SIZE         32
#define LX1_RESERVED_SIZE  32

#define LX1_RESERVED_SHIFT  0

#define LX1_RESERVED_MASK               0xffffffff

#define LX1_MASK \
      (LX1_RESERVED_MASK)

#define LX1_DEFAULT                    0x00000000

#define LX1_GET_RESERVED(lx1) \
      ((lx1 & LX1_RESERVED_MASK) >> LX1_RESERVED_SHIFT)

#define LX1_SET_RESERVED(lx1_reg, reserved) \
      lx1_reg = (lx1_reg & ~LX1_RESERVED_MASK) | (reserved << LX1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct lx1_t {
            unsigned int reserved                       : LX1_RESERVED_SIZE;
      } lx1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct lx1_t {
            unsigned int reserved                       : LX1_RESERVED_SIZE;
      } lx1_t;

#endif

typedef union {
     unsigned int val : 32;
          lx1_t f;
} lx1_u;


/*
 * LX2 struct
 */

#define LX2_REG_SIZE         32
#define LX2_RESERVED_SIZE  32

#define LX2_RESERVED_SHIFT  0

#define LX2_RESERVED_MASK               0xffffffff

#define LX2_MASK \
      (LX2_RESERVED_MASK)

#define LX2_DEFAULT                    0x00000000

#define LX2_GET_RESERVED(lx2) \
      ((lx2 & LX2_RESERVED_MASK) >> LX2_RESERVED_SHIFT)

#define LX2_SET_RESERVED(lx2_reg, reserved) \
      lx2_reg = (lx2_reg & ~LX2_RESERVED_MASK) | (reserved << LX2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct lx2_t {
            unsigned int reserved                       : LX2_RESERVED_SIZE;
      } lx2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct lx2_t {
            unsigned int reserved                       : LX2_RESERVED_SIZE;
      } lx2_t;

#endif

typedef union {
     unsigned int val : 32;
          lx2_t f;
} lx2_u;


/*
 * LX3 struct
 */

#define LX3_REG_SIZE         32
#define LX3_RESERVED_SIZE  32

#define LX3_RESERVED_SHIFT  0

#define LX3_RESERVED_MASK               0xffffffff

#define LX3_MASK \
      (LX3_RESERVED_MASK)

#define LX3_DEFAULT                    0x00000000

#define LX3_GET_RESERVED(lx3) \
      ((lx3 & LX3_RESERVED_MASK) >> LX3_RESERVED_SHIFT)

#define LX3_SET_RESERVED(lx3_reg, reserved) \
      lx3_reg = (lx3_reg & ~LX3_RESERVED_MASK) | (reserved << LX3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct lx3_t {
            unsigned int reserved                       : LX3_RESERVED_SIZE;
      } lx3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct lx3_t {
            unsigned int reserved                       : LX3_RESERVED_SIZE;
      } lx3_t;

#endif

typedef union {
     unsigned int val : 32;
          lx3_t f;
} lx3_u;


/*
 * FAST_AES0 struct
 */

#define FAST_AES0_REG_SIZE         32
#define FAST_AES0_RESERVED_SIZE  32

#define FAST_AES0_RESERVED_SHIFT  0

#define FAST_AES0_RESERVED_MASK         0xffffffff

#define FAST_AES0_MASK \
      (FAST_AES0_RESERVED_MASK)

#define FAST_AES0_DEFAULT              0x00000000

#define FAST_AES0_GET_RESERVED(fast_aes0) \
      ((fast_aes0 & FAST_AES0_RESERVED_MASK) >> FAST_AES0_RESERVED_SHIFT)

#define FAST_AES0_SET_RESERVED(fast_aes0_reg, reserved) \
      fast_aes0_reg = (fast_aes0_reg & ~FAST_AES0_RESERVED_MASK) | (reserved << FAST_AES0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct fast_aes0_t {
            unsigned int reserved                       : FAST_AES0_RESERVED_SIZE;
      } fast_aes0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct fast_aes0_t {
            unsigned int reserved                       : FAST_AES0_RESERVED_SIZE;
      } fast_aes0_t;

#endif

typedef union {
     unsigned int val : 32;
          fast_aes0_t f;
} fast_aes0_u;


/*
 * FAST_AES1 struct
 */

#define FAST_AES1_REG_SIZE         32
#define FAST_AES1_RESERVED_SIZE  32

#define FAST_AES1_RESERVED_SHIFT  0

#define FAST_AES1_RESERVED_MASK         0xffffffff

#define FAST_AES1_MASK \
      (FAST_AES1_RESERVED_MASK)

#define FAST_AES1_DEFAULT              0x00000000

#define FAST_AES1_GET_RESERVED(fast_aes1) \
      ((fast_aes1 & FAST_AES1_RESERVED_MASK) >> FAST_AES1_RESERVED_SHIFT)

#define FAST_AES1_SET_RESERVED(fast_aes1_reg, reserved) \
      fast_aes1_reg = (fast_aes1_reg & ~FAST_AES1_RESERVED_MASK) | (reserved << FAST_AES1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct fast_aes1_t {
            unsigned int reserved                       : FAST_AES1_RESERVED_SIZE;
      } fast_aes1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct fast_aes1_t {
            unsigned int reserved                       : FAST_AES1_RESERVED_SIZE;
      } fast_aes1_t;

#endif

typedef union {
     unsigned int val : 32;
          fast_aes1_t f;
} fast_aes1_u;


/*
 * FAST_AES2 struct
 */

#define FAST_AES2_REG_SIZE         32
#define FAST_AES2_RESERVED_SIZE  32

#define FAST_AES2_RESERVED_SHIFT  0

#define FAST_AES2_RESERVED_MASK         0xffffffff

#define FAST_AES2_MASK \
      (FAST_AES2_RESERVED_MASK)

#define FAST_AES2_DEFAULT              0x00000000

#define FAST_AES2_GET_RESERVED(fast_aes2) \
      ((fast_aes2 & FAST_AES2_RESERVED_MASK) >> FAST_AES2_RESERVED_SHIFT)

#define FAST_AES2_SET_RESERVED(fast_aes2_reg, reserved) \
      fast_aes2_reg = (fast_aes2_reg & ~FAST_AES2_RESERVED_MASK) | (reserved << FAST_AES2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct fast_aes2_t {
            unsigned int reserved                       : FAST_AES2_RESERVED_SIZE;
      } fast_aes2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct fast_aes2_t {
            unsigned int reserved                       : FAST_AES2_RESERVED_SIZE;
      } fast_aes2_t;

#endif

typedef union {
     unsigned int val : 32;
          fast_aes2_t f;
} fast_aes2_u;


/*
 * FAST_AES3 struct
 */

#define FAST_AES3_REG_SIZE         32
#define FAST_AES3_RESERVED_SIZE  32

#define FAST_AES3_RESERVED_SHIFT  0

#define FAST_AES3_RESERVED_MASK         0xffffffff

#define FAST_AES3_MASK \
      (FAST_AES3_RESERVED_MASK)

#define FAST_AES3_DEFAULT              0x00000000

#define FAST_AES3_GET_RESERVED(fast_aes3) \
      ((fast_aes3 & FAST_AES3_RESERVED_MASK) >> FAST_AES3_RESERVED_SHIFT)

#define FAST_AES3_SET_RESERVED(fast_aes3_reg, reserved) \
      fast_aes3_reg = (fast_aes3_reg & ~FAST_AES3_RESERVED_MASK) | (reserved << FAST_AES3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct fast_aes3_t {
            unsigned int reserved                       : FAST_AES3_RESERVED_SIZE;
      } fast_aes3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct fast_aes3_t {
            unsigned int reserved                       : FAST_AES3_RESERVED_SIZE;
      } fast_aes3_t;

#endif

typedef union {
     unsigned int val : 32;
          fast_aes3_t f;
} fast_aes3_u;


/*
 * FAST_AES4 struct
 */

#define FAST_AES4_REG_SIZE         32
#define FAST_AES4_RESERVED_SIZE  32

#define FAST_AES4_RESERVED_SHIFT  0

#define FAST_AES4_RESERVED_MASK         0xffffffff

#define FAST_AES4_MASK \
      (FAST_AES4_RESERVED_MASK)

#define FAST_AES4_DEFAULT              0x00000000

#define FAST_AES4_GET_RESERVED(fast_aes4) \
      ((fast_aes4 & FAST_AES4_RESERVED_MASK) >> FAST_AES4_RESERVED_SHIFT)

#define FAST_AES4_SET_RESERVED(fast_aes4_reg, reserved) \
      fast_aes4_reg = (fast_aes4_reg & ~FAST_AES4_RESERVED_MASK) | (reserved << FAST_AES4_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct fast_aes4_t {
            unsigned int reserved                       : FAST_AES4_RESERVED_SIZE;
      } fast_aes4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct fast_aes4_t {
            unsigned int reserved                       : FAST_AES4_RESERVED_SIZE;
      } fast_aes4_t;

#endif

typedef union {
     unsigned int val : 32;
          fast_aes4_t f;
} fast_aes4_u;


/*
 * FAST_AES5 struct
 */

#define FAST_AES5_REG_SIZE         32
#define FAST_AES5_RESERVED_SIZE  32

#define FAST_AES5_RESERVED_SHIFT  0

#define FAST_AES5_RESERVED_MASK         0xffffffff

#define FAST_AES5_MASK \
      (FAST_AES5_RESERVED_MASK)

#define FAST_AES5_DEFAULT              0x00000000

#define FAST_AES5_GET_RESERVED(fast_aes5) \
      ((fast_aes5 & FAST_AES5_RESERVED_MASK) >> FAST_AES5_RESERVED_SHIFT)

#define FAST_AES5_SET_RESERVED(fast_aes5_reg, reserved) \
      fast_aes5_reg = (fast_aes5_reg & ~FAST_AES5_RESERVED_MASK) | (reserved << FAST_AES5_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct fast_aes5_t {
            unsigned int reserved                       : FAST_AES5_RESERVED_SIZE;
      } fast_aes5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct fast_aes5_t {
            unsigned int reserved                       : FAST_AES5_RESERVED_SIZE;
      } fast_aes5_t;

#endif

typedef union {
     unsigned int val : 32;
          fast_aes5_t f;
} fast_aes5_u;


/*
 * FAST_AES6 struct
 */

#define FAST_AES6_REG_SIZE         32
#define FAST_AES6_RESERVED_SIZE  32

#define FAST_AES6_RESERVED_SHIFT  0

#define FAST_AES6_RESERVED_MASK         0xffffffff

#define FAST_AES6_MASK \
      (FAST_AES6_RESERVED_MASK)

#define FAST_AES6_DEFAULT              0x00000000

#define FAST_AES6_GET_RESERVED(fast_aes6) \
      ((fast_aes6 & FAST_AES6_RESERVED_MASK) >> FAST_AES6_RESERVED_SHIFT)

#define FAST_AES6_SET_RESERVED(fast_aes6_reg, reserved) \
      fast_aes6_reg = (fast_aes6_reg & ~FAST_AES6_RESERVED_MASK) | (reserved << FAST_AES6_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct fast_aes6_t {
            unsigned int reserved                       : FAST_AES6_RESERVED_SIZE;
      } fast_aes6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct fast_aes6_t {
            unsigned int reserved                       : FAST_AES6_RESERVED_SIZE;
      } fast_aes6_t;

#endif

typedef union {
     unsigned int val : 32;
          fast_aes6_t f;
} fast_aes6_u;


/*
 * FAST_AES7 struct
 */

#define FAST_AES7_REG_SIZE         32
#define FAST_AES7_RESERVED_SIZE  32

#define FAST_AES7_RESERVED_SHIFT  0

#define FAST_AES7_RESERVED_MASK         0xffffffff

#define FAST_AES7_MASK \
      (FAST_AES7_RESERVED_MASK)

#define FAST_AES7_DEFAULT              0x00000000

#define FAST_AES7_GET_RESERVED(fast_aes7) \
      ((fast_aes7 & FAST_AES7_RESERVED_MASK) >> FAST_AES7_RESERVED_SHIFT)

#define FAST_AES7_SET_RESERVED(fast_aes7_reg, reserved) \
      fast_aes7_reg = (fast_aes7_reg & ~FAST_AES7_RESERVED_MASK) | (reserved << FAST_AES7_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct fast_aes7_t {
            unsigned int reserved                       : FAST_AES7_RESERVED_SIZE;
      } fast_aes7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct fast_aes7_t {
            unsigned int reserved                       : FAST_AES7_RESERVED_SIZE;
      } fast_aes7_t;

#endif

typedef union {
     unsigned int val : 32;
          fast_aes7_t f;
} fast_aes7_u;


/*
 * SLOW_AES0 struct
 */

#define SLOW_AES0_REG_SIZE         32
#define SLOW_AES0_RESERVED_SIZE  32

#define SLOW_AES0_RESERVED_SHIFT  0

#define SLOW_AES0_RESERVED_MASK         0xffffffff

#define SLOW_AES0_MASK \
      (SLOW_AES0_RESERVED_MASK)

#define SLOW_AES0_DEFAULT              0x00000000

#define SLOW_AES0_GET_RESERVED(slow_aes0) \
      ((slow_aes0 & SLOW_AES0_RESERVED_MASK) >> SLOW_AES0_RESERVED_SHIFT)

#define SLOW_AES0_SET_RESERVED(slow_aes0_reg, reserved) \
      slow_aes0_reg = (slow_aes0_reg & ~SLOW_AES0_RESERVED_MASK) | (reserved << SLOW_AES0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct slow_aes0_t {
            unsigned int reserved                       : SLOW_AES0_RESERVED_SIZE;
      } slow_aes0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct slow_aes0_t {
            unsigned int reserved                       : SLOW_AES0_RESERVED_SIZE;
      } slow_aes0_t;

#endif

typedef union {
     unsigned int val : 32;
          slow_aes0_t f;
} slow_aes0_u;


/*
 * SLOW_AES1 struct
 */

#define SLOW_AES1_REG_SIZE         32
#define SLOW_AES1_RESERVED_SIZE  32

#define SLOW_AES1_RESERVED_SHIFT  0

#define SLOW_AES1_RESERVED_MASK         0xffffffff

#define SLOW_AES1_MASK \
      (SLOW_AES1_RESERVED_MASK)

#define SLOW_AES1_DEFAULT              0x00000000

#define SLOW_AES1_GET_RESERVED(slow_aes1) \
      ((slow_aes1 & SLOW_AES1_RESERVED_MASK) >> SLOW_AES1_RESERVED_SHIFT)

#define SLOW_AES1_SET_RESERVED(slow_aes1_reg, reserved) \
      slow_aes1_reg = (slow_aes1_reg & ~SLOW_AES1_RESERVED_MASK) | (reserved << SLOW_AES1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct slow_aes1_t {
            unsigned int reserved                       : SLOW_AES1_RESERVED_SIZE;
      } slow_aes1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct slow_aes1_t {
            unsigned int reserved                       : SLOW_AES1_RESERVED_SIZE;
      } slow_aes1_t;

#endif

typedef union {
     unsigned int val : 32;
          slow_aes1_t f;
} slow_aes1_u;


/*
 * SLOW_AES2 struct
 */

#define SLOW_AES2_REG_SIZE         32
#define SLOW_AES2_RESERVED_SIZE  32

#define SLOW_AES2_RESERVED_SHIFT  0

#define SLOW_AES2_RESERVED_MASK         0xffffffff

#define SLOW_AES2_MASK \
      (SLOW_AES2_RESERVED_MASK)

#define SLOW_AES2_DEFAULT              0x00000000

#define SLOW_AES2_GET_RESERVED(slow_aes2) \
      ((slow_aes2 & SLOW_AES2_RESERVED_MASK) >> SLOW_AES2_RESERVED_SHIFT)

#define SLOW_AES2_SET_RESERVED(slow_aes2_reg, reserved) \
      slow_aes2_reg = (slow_aes2_reg & ~SLOW_AES2_RESERVED_MASK) | (reserved << SLOW_AES2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct slow_aes2_t {
            unsigned int reserved                       : SLOW_AES2_RESERVED_SIZE;
      } slow_aes2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct slow_aes2_t {
            unsigned int reserved                       : SLOW_AES2_RESERVED_SIZE;
      } slow_aes2_t;

#endif

typedef union {
     unsigned int val : 32;
          slow_aes2_t f;
} slow_aes2_u;


/*
 * SLOW_AES3 struct
 */

#define SLOW_AES3_REG_SIZE         32
#define SLOW_AES3_RESERVED_SIZE  32

#define SLOW_AES3_RESERVED_SHIFT  0

#define SLOW_AES3_RESERVED_MASK         0xffffffff

#define SLOW_AES3_MASK \
      (SLOW_AES3_RESERVED_MASK)

#define SLOW_AES3_DEFAULT              0x00000000

#define SLOW_AES3_GET_RESERVED(slow_aes3) \
      ((slow_aes3 & SLOW_AES3_RESERVED_MASK) >> SLOW_AES3_RESERVED_SHIFT)

#define SLOW_AES3_SET_RESERVED(slow_aes3_reg, reserved) \
      slow_aes3_reg = (slow_aes3_reg & ~SLOW_AES3_RESERVED_MASK) | (reserved << SLOW_AES3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct slow_aes3_t {
            unsigned int reserved                       : SLOW_AES3_RESERVED_SIZE;
      } slow_aes3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct slow_aes3_t {
            unsigned int reserved                       : SLOW_AES3_RESERVED_SIZE;
      } slow_aes3_t;

#endif

typedef union {
     unsigned int val : 32;
          slow_aes3_t f;
} slow_aes3_u;


/*
 * CCIPHER_A_IK0 struct
 */

#define CCIPHER_A_IK0_REG_SIZE         32
#define CCIPHER_A_IK0_RESERVED_SIZE  32

#define CCIPHER_A_IK0_RESERVED_SHIFT  0

#define CCIPHER_A_IK0_RESERVED_MASK     0xffffffff

#define CCIPHER_A_IK0_MASK \
      (CCIPHER_A_IK0_RESERVED_MASK)

#define CCIPHER_A_IK0_DEFAULT          0x00000000

#define CCIPHER_A_IK0_GET_RESERVED(ccipher_a_ik0) \
      ((ccipher_a_ik0 & CCIPHER_A_IK0_RESERVED_MASK) >> CCIPHER_A_IK0_RESERVED_SHIFT)

#define CCIPHER_A_IK0_SET_RESERVED(ccipher_a_ik0_reg, reserved) \
      ccipher_a_ik0_reg = (ccipher_a_ik0_reg & ~CCIPHER_A_IK0_RESERVED_MASK) | (reserved << CCIPHER_A_IK0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_ik0_t {
            unsigned int reserved                       : CCIPHER_A_IK0_RESERVED_SIZE;
      } ccipher_a_ik0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_ik0_t {
            unsigned int reserved                       : CCIPHER_A_IK0_RESERVED_SIZE;
      } ccipher_a_ik0_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_ik0_t f;
} ccipher_a_ik0_u;


/*
 * CCIPHER_A_IK1 struct
 */

#define CCIPHER_A_IK1_REG_SIZE         32
#define CCIPHER_A_IK1_RESERVED_SIZE  32

#define CCIPHER_A_IK1_RESERVED_SHIFT  0

#define CCIPHER_A_IK1_RESERVED_MASK     0xffffffff

#define CCIPHER_A_IK1_MASK \
      (CCIPHER_A_IK1_RESERVED_MASK)

#define CCIPHER_A_IK1_DEFAULT          0x00000000

#define CCIPHER_A_IK1_GET_RESERVED(ccipher_a_ik1) \
      ((ccipher_a_ik1 & CCIPHER_A_IK1_RESERVED_MASK) >> CCIPHER_A_IK1_RESERVED_SHIFT)

#define CCIPHER_A_IK1_SET_RESERVED(ccipher_a_ik1_reg, reserved) \
      ccipher_a_ik1_reg = (ccipher_a_ik1_reg & ~CCIPHER_A_IK1_RESERVED_MASK) | (reserved << CCIPHER_A_IK1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_ik1_t {
            unsigned int reserved                       : CCIPHER_A_IK1_RESERVED_SIZE;
      } ccipher_a_ik1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_ik1_t {
            unsigned int reserved                       : CCIPHER_A_IK1_RESERVED_SIZE;
      } ccipher_a_ik1_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_ik1_t f;
} ccipher_a_ik1_u;


/*
 * CCIPHER_A_IK2 struct
 */

#define CCIPHER_A_IK2_REG_SIZE         32
#define CCIPHER_A_IK2_RESERVED_SIZE  32

#define CCIPHER_A_IK2_RESERVED_SHIFT  0

#define CCIPHER_A_IK2_RESERVED_MASK     0xffffffff

#define CCIPHER_A_IK2_MASK \
      (CCIPHER_A_IK2_RESERVED_MASK)

#define CCIPHER_A_IK2_DEFAULT          0x00000000

#define CCIPHER_A_IK2_GET_RESERVED(ccipher_a_ik2) \
      ((ccipher_a_ik2 & CCIPHER_A_IK2_RESERVED_MASK) >> CCIPHER_A_IK2_RESERVED_SHIFT)

#define CCIPHER_A_IK2_SET_RESERVED(ccipher_a_ik2_reg, reserved) \
      ccipher_a_ik2_reg = (ccipher_a_ik2_reg & ~CCIPHER_A_IK2_RESERVED_MASK) | (reserved << CCIPHER_A_IK2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_ik2_t {
            unsigned int reserved                       : CCIPHER_A_IK2_RESERVED_SIZE;
      } ccipher_a_ik2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_ik2_t {
            unsigned int reserved                       : CCIPHER_A_IK2_RESERVED_SIZE;
      } ccipher_a_ik2_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_ik2_t f;
} ccipher_a_ik2_u;


/*
 * CCIPHER_A_IK3 struct
 */

#define CCIPHER_A_IK3_REG_SIZE         32
#define CCIPHER_A_IK3_RESERVED_SIZE  32

#define CCIPHER_A_IK3_RESERVED_SHIFT  0

#define CCIPHER_A_IK3_RESERVED_MASK     0xffffffff

#define CCIPHER_A_IK3_MASK \
      (CCIPHER_A_IK3_RESERVED_MASK)

#define CCIPHER_A_IK3_DEFAULT          0x00000000

#define CCIPHER_A_IK3_GET_RESERVED(ccipher_a_ik3) \
      ((ccipher_a_ik3 & CCIPHER_A_IK3_RESERVED_MASK) >> CCIPHER_A_IK3_RESERVED_SHIFT)

#define CCIPHER_A_IK3_SET_RESERVED(ccipher_a_ik3_reg, reserved) \
      ccipher_a_ik3_reg = (ccipher_a_ik3_reg & ~CCIPHER_A_IK3_RESERVED_MASK) | (reserved << CCIPHER_A_IK3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_ik3_t {
            unsigned int reserved                       : CCIPHER_A_IK3_RESERVED_SIZE;
      } ccipher_a_ik3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_ik3_t {
            unsigned int reserved                       : CCIPHER_A_IK3_RESERVED_SIZE;
      } ccipher_a_ik3_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_ik3_t f;
} ccipher_a_ik3_u;


/*
 * CCIPHER_A_S0 struct
 */

#define CCIPHER_A_S0_REG_SIZE         32
#define CCIPHER_A_S0_RESERVED_SIZE  32

#define CCIPHER_A_S0_RESERVED_SHIFT  0

#define CCIPHER_A_S0_RESERVED_MASK      0xffffffff

#define CCIPHER_A_S0_MASK \
      (CCIPHER_A_S0_RESERVED_MASK)

#define CCIPHER_A_S0_DEFAULT           0x00000000

#define CCIPHER_A_S0_GET_RESERVED(ccipher_a_s0) \
      ((ccipher_a_s0 & CCIPHER_A_S0_RESERVED_MASK) >> CCIPHER_A_S0_RESERVED_SHIFT)

#define CCIPHER_A_S0_SET_RESERVED(ccipher_a_s0_reg, reserved) \
      ccipher_a_s0_reg = (ccipher_a_s0_reg & ~CCIPHER_A_S0_RESERVED_MASK) | (reserved << CCIPHER_A_S0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s0_t {
            unsigned int reserved                       : CCIPHER_A_S0_RESERVED_SIZE;
      } ccipher_a_s0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s0_t {
            unsigned int reserved                       : CCIPHER_A_S0_RESERVED_SIZE;
      } ccipher_a_s0_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s0_t f;
} ccipher_a_s0_u;


/*
 * CCIPHER_A_S1 struct
 */

#define CCIPHER_A_S1_REG_SIZE         32
#define CCIPHER_A_S1_RESERVED_SIZE  32

#define CCIPHER_A_S1_RESERVED_SHIFT  0

#define CCIPHER_A_S1_RESERVED_MASK      0xffffffff

#define CCIPHER_A_S1_MASK \
      (CCIPHER_A_S1_RESERVED_MASK)

#define CCIPHER_A_S1_DEFAULT           0x00000000

#define CCIPHER_A_S1_GET_RESERVED(ccipher_a_s1) \
      ((ccipher_a_s1 & CCIPHER_A_S1_RESERVED_MASK) >> CCIPHER_A_S1_RESERVED_SHIFT)

#define CCIPHER_A_S1_SET_RESERVED(ccipher_a_s1_reg, reserved) \
      ccipher_a_s1_reg = (ccipher_a_s1_reg & ~CCIPHER_A_S1_RESERVED_MASK) | (reserved << CCIPHER_A_S1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s1_t {
            unsigned int reserved                       : CCIPHER_A_S1_RESERVED_SIZE;
      } ccipher_a_s1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s1_t {
            unsigned int reserved                       : CCIPHER_A_S1_RESERVED_SIZE;
      } ccipher_a_s1_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s1_t f;
} ccipher_a_s1_u;


/*
 * CCIPHER_A_S2 struct
 */

#define CCIPHER_A_S2_REG_SIZE         32
#define CCIPHER_A_S2_RESERVED_SIZE  32

#define CCIPHER_A_S2_RESERVED_SHIFT  0

#define CCIPHER_A_S2_RESERVED_MASK      0xffffffff

#define CCIPHER_A_S2_MASK \
      (CCIPHER_A_S2_RESERVED_MASK)

#define CCIPHER_A_S2_DEFAULT           0x00000000

#define CCIPHER_A_S2_GET_RESERVED(ccipher_a_s2) \
      ((ccipher_a_s2 & CCIPHER_A_S2_RESERVED_MASK) >> CCIPHER_A_S2_RESERVED_SHIFT)

#define CCIPHER_A_S2_SET_RESERVED(ccipher_a_s2_reg, reserved) \
      ccipher_a_s2_reg = (ccipher_a_s2_reg & ~CCIPHER_A_S2_RESERVED_MASK) | (reserved << CCIPHER_A_S2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s2_t {
            unsigned int reserved                       : CCIPHER_A_S2_RESERVED_SIZE;
      } ccipher_a_s2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s2_t {
            unsigned int reserved                       : CCIPHER_A_S2_RESERVED_SIZE;
      } ccipher_a_s2_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s2_t f;
} ccipher_a_s2_u;


/*
 * CCIPHER_A_S3 struct
 */

#define CCIPHER_A_S3_REG_SIZE         32
#define CCIPHER_A_S3_RESERVED_SIZE  32

#define CCIPHER_A_S3_RESERVED_SHIFT  0

#define CCIPHER_A_S3_RESERVED_MASK      0xffffffff

#define CCIPHER_A_S3_MASK \
      (CCIPHER_A_S3_RESERVED_MASK)

#define CCIPHER_A_S3_DEFAULT           0x00000000

#define CCIPHER_A_S3_GET_RESERVED(ccipher_a_s3) \
      ((ccipher_a_s3 & CCIPHER_A_S3_RESERVED_MASK) >> CCIPHER_A_S3_RESERVED_SHIFT)

#define CCIPHER_A_S3_SET_RESERVED(ccipher_a_s3_reg, reserved) \
      ccipher_a_s3_reg = (ccipher_a_s3_reg & ~CCIPHER_A_S3_RESERVED_MASK) | (reserved << CCIPHER_A_S3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s3_t {
            unsigned int reserved                       : CCIPHER_A_S3_RESERVED_SIZE;
      } ccipher_a_s3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s3_t {
            unsigned int reserved                       : CCIPHER_A_S3_RESERVED_SIZE;
      } ccipher_a_s3_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s3_t f;
} ccipher_a_s3_u;


/*
 * CCIPHER_A_S4 struct
 */

#define CCIPHER_A_S4_REG_SIZE         32
#define CCIPHER_A_S4_RESERVED_SIZE  32

#define CCIPHER_A_S4_RESERVED_SHIFT  0

#define CCIPHER_A_S4_RESERVED_MASK      0xffffffff

#define CCIPHER_A_S4_MASK \
      (CCIPHER_A_S4_RESERVED_MASK)

#define CCIPHER_A_S4_DEFAULT           0x00000000

#define CCIPHER_A_S4_GET_RESERVED(ccipher_a_s4) \
      ((ccipher_a_s4 & CCIPHER_A_S4_RESERVED_MASK) >> CCIPHER_A_S4_RESERVED_SHIFT)

#define CCIPHER_A_S4_SET_RESERVED(ccipher_a_s4_reg, reserved) \
      ccipher_a_s4_reg = (ccipher_a_s4_reg & ~CCIPHER_A_S4_RESERVED_MASK) | (reserved << CCIPHER_A_S4_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s4_t {
            unsigned int reserved                       : CCIPHER_A_S4_RESERVED_SIZE;
      } ccipher_a_s4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s4_t {
            unsigned int reserved                       : CCIPHER_A_S4_RESERVED_SIZE;
      } ccipher_a_s4_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s4_t f;
} ccipher_a_s4_u;


/*
 * CCIPHER_A_S5 struct
 */

#define CCIPHER_A_S5_REG_SIZE         32
#define CCIPHER_A_S5_RESERVED_SIZE  32

#define CCIPHER_A_S5_RESERVED_SHIFT  0

#define CCIPHER_A_S5_RESERVED_MASK      0xffffffff

#define CCIPHER_A_S5_MASK \
      (CCIPHER_A_S5_RESERVED_MASK)

#define CCIPHER_A_S5_DEFAULT           0x00000000

#define CCIPHER_A_S5_GET_RESERVED(ccipher_a_s5) \
      ((ccipher_a_s5 & CCIPHER_A_S5_RESERVED_MASK) >> CCIPHER_A_S5_RESERVED_SHIFT)

#define CCIPHER_A_S5_SET_RESERVED(ccipher_a_s5_reg, reserved) \
      ccipher_a_s5_reg = (ccipher_a_s5_reg & ~CCIPHER_A_S5_RESERVED_MASK) | (reserved << CCIPHER_A_S5_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s5_t {
            unsigned int reserved                       : CCIPHER_A_S5_RESERVED_SIZE;
      } ccipher_a_s5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s5_t {
            unsigned int reserved                       : CCIPHER_A_S5_RESERVED_SIZE;
      } ccipher_a_s5_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s5_t f;
} ccipher_a_s5_u;


/*
 * CCIPHER_A_S6 struct
 */

#define CCIPHER_A_S6_REG_SIZE         32
#define CCIPHER_A_S6_RESERVED_SIZE  32

#define CCIPHER_A_S6_RESERVED_SHIFT  0

#define CCIPHER_A_S6_RESERVED_MASK      0xffffffff

#define CCIPHER_A_S6_MASK \
      (CCIPHER_A_S6_RESERVED_MASK)

#define CCIPHER_A_S6_DEFAULT           0x00000000

#define CCIPHER_A_S6_GET_RESERVED(ccipher_a_s6) \
      ((ccipher_a_s6 & CCIPHER_A_S6_RESERVED_MASK) >> CCIPHER_A_S6_RESERVED_SHIFT)

#define CCIPHER_A_S6_SET_RESERVED(ccipher_a_s6_reg, reserved) \
      ccipher_a_s6_reg = (ccipher_a_s6_reg & ~CCIPHER_A_S6_RESERVED_MASK) | (reserved << CCIPHER_A_S6_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s6_t {
            unsigned int reserved                       : CCIPHER_A_S6_RESERVED_SIZE;
      } ccipher_a_s6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s6_t {
            unsigned int reserved                       : CCIPHER_A_S6_RESERVED_SIZE;
      } ccipher_a_s6_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s6_t f;
} ccipher_a_s6_u;


/*
 * CCIPHER_A_S7 struct
 */

#define CCIPHER_A_S7_REG_SIZE         32
#define CCIPHER_A_S7_RESERVED_SIZE  32

#define CCIPHER_A_S7_RESERVED_SHIFT  0

#define CCIPHER_A_S7_RESERVED_MASK      0xffffffff

#define CCIPHER_A_S7_MASK \
      (CCIPHER_A_S7_RESERVED_MASK)

#define CCIPHER_A_S7_DEFAULT           0x00000000

#define CCIPHER_A_S7_GET_RESERVED(ccipher_a_s7) \
      ((ccipher_a_s7 & CCIPHER_A_S7_RESERVED_MASK) >> CCIPHER_A_S7_RESERVED_SHIFT)

#define CCIPHER_A_S7_SET_RESERVED(ccipher_a_s7_reg, reserved) \
      ccipher_a_s7_reg = (ccipher_a_s7_reg & ~CCIPHER_A_S7_RESERVED_MASK) | (reserved << CCIPHER_A_S7_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s7_t {
            unsigned int reserved                       : CCIPHER_A_S7_RESERVED_SIZE;
      } ccipher_a_s7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s7_t {
            unsigned int reserved                       : CCIPHER_A_S7_RESERVED_SIZE;
      } ccipher_a_s7_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s7_t f;
} ccipher_a_s7_u;


/*
 * CCIPHER_A_S8 struct
 */

#define CCIPHER_A_S8_REG_SIZE         32
#define CCIPHER_A_S8_RESERVED_SIZE  32

#define CCIPHER_A_S8_RESERVED_SHIFT  0

#define CCIPHER_A_S8_RESERVED_MASK      0xffffffff

#define CCIPHER_A_S8_MASK \
      (CCIPHER_A_S8_RESERVED_MASK)

#define CCIPHER_A_S8_DEFAULT           0x00000000

#define CCIPHER_A_S8_GET_RESERVED(ccipher_a_s8) \
      ((ccipher_a_s8 & CCIPHER_A_S8_RESERVED_MASK) >> CCIPHER_A_S8_RESERVED_SHIFT)

#define CCIPHER_A_S8_SET_RESERVED(ccipher_a_s8_reg, reserved) \
      ccipher_a_s8_reg = (ccipher_a_s8_reg & ~CCIPHER_A_S8_RESERVED_MASK) | (reserved << CCIPHER_A_S8_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s8_t {
            unsigned int reserved                       : CCIPHER_A_S8_RESERVED_SIZE;
      } ccipher_a_s8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s8_t {
            unsigned int reserved                       : CCIPHER_A_S8_RESERVED_SIZE;
      } ccipher_a_s8_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s8_t f;
} ccipher_a_s8_u;


/*
 * CCIPHER_A_S9 struct
 */

#define CCIPHER_A_S9_REG_SIZE         32
#define CCIPHER_A_S9_RESERVED_SIZE  32

#define CCIPHER_A_S9_RESERVED_SHIFT  0

#define CCIPHER_A_S9_RESERVED_MASK      0xffffffff

#define CCIPHER_A_S9_MASK \
      (CCIPHER_A_S9_RESERVED_MASK)

#define CCIPHER_A_S9_DEFAULT           0x00000000

#define CCIPHER_A_S9_GET_RESERVED(ccipher_a_s9) \
      ((ccipher_a_s9 & CCIPHER_A_S9_RESERVED_MASK) >> CCIPHER_A_S9_RESERVED_SHIFT)

#define CCIPHER_A_S9_SET_RESERVED(ccipher_a_s9_reg, reserved) \
      ccipher_a_s9_reg = (ccipher_a_s9_reg & ~CCIPHER_A_S9_RESERVED_MASK) | (reserved << CCIPHER_A_S9_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s9_t {
            unsigned int reserved                       : CCIPHER_A_S9_RESERVED_SIZE;
      } ccipher_a_s9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s9_t {
            unsigned int reserved                       : CCIPHER_A_S9_RESERVED_SIZE;
      } ccipher_a_s9_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s9_t f;
} ccipher_a_s9_u;


/*
 * CCIPHER_A_S10 struct
 */

#define CCIPHER_A_S10_REG_SIZE         32
#define CCIPHER_A_S10_RESERVED_SIZE  32

#define CCIPHER_A_S10_RESERVED_SHIFT  0

#define CCIPHER_A_S10_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S10_MASK \
      (CCIPHER_A_S10_RESERVED_MASK)

#define CCIPHER_A_S10_DEFAULT          0x00000000

#define CCIPHER_A_S10_GET_RESERVED(ccipher_a_s10) \
      ((ccipher_a_s10 & CCIPHER_A_S10_RESERVED_MASK) >> CCIPHER_A_S10_RESERVED_SHIFT)

#define CCIPHER_A_S10_SET_RESERVED(ccipher_a_s10_reg, reserved) \
      ccipher_a_s10_reg = (ccipher_a_s10_reg & ~CCIPHER_A_S10_RESERVED_MASK) | (reserved << CCIPHER_A_S10_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s10_t {
            unsigned int reserved                       : CCIPHER_A_S10_RESERVED_SIZE;
      } ccipher_a_s10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s10_t {
            unsigned int reserved                       : CCIPHER_A_S10_RESERVED_SIZE;
      } ccipher_a_s10_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s10_t f;
} ccipher_a_s10_u;


/*
 * CCIPHER_A_S11 struct
 */

#define CCIPHER_A_S11_REG_SIZE         32
#define CCIPHER_A_S11_RESERVED_SIZE  32

#define CCIPHER_A_S11_RESERVED_SHIFT  0

#define CCIPHER_A_S11_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S11_MASK \
      (CCIPHER_A_S11_RESERVED_MASK)

#define CCIPHER_A_S11_DEFAULT          0x00000000

#define CCIPHER_A_S11_GET_RESERVED(ccipher_a_s11) \
      ((ccipher_a_s11 & CCIPHER_A_S11_RESERVED_MASK) >> CCIPHER_A_S11_RESERVED_SHIFT)

#define CCIPHER_A_S11_SET_RESERVED(ccipher_a_s11_reg, reserved) \
      ccipher_a_s11_reg = (ccipher_a_s11_reg & ~CCIPHER_A_S11_RESERVED_MASK) | (reserved << CCIPHER_A_S11_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s11_t {
            unsigned int reserved                       : CCIPHER_A_S11_RESERVED_SIZE;
      } ccipher_a_s11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s11_t {
            unsigned int reserved                       : CCIPHER_A_S11_RESERVED_SIZE;
      } ccipher_a_s11_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s11_t f;
} ccipher_a_s11_u;


/*
 * CCIPHER_A_S12 struct
 */

#define CCIPHER_A_S12_REG_SIZE         32
#define CCIPHER_A_S12_RESERVED_SIZE  32

#define CCIPHER_A_S12_RESERVED_SHIFT  0

#define CCIPHER_A_S12_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S12_MASK \
      (CCIPHER_A_S12_RESERVED_MASK)

#define CCIPHER_A_S12_DEFAULT          0x00000000

#define CCIPHER_A_S12_GET_RESERVED(ccipher_a_s12) \
      ((ccipher_a_s12 & CCIPHER_A_S12_RESERVED_MASK) >> CCIPHER_A_S12_RESERVED_SHIFT)

#define CCIPHER_A_S12_SET_RESERVED(ccipher_a_s12_reg, reserved) \
      ccipher_a_s12_reg = (ccipher_a_s12_reg & ~CCIPHER_A_S12_RESERVED_MASK) | (reserved << CCIPHER_A_S12_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s12_t {
            unsigned int reserved                       : CCIPHER_A_S12_RESERVED_SIZE;
      } ccipher_a_s12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s12_t {
            unsigned int reserved                       : CCIPHER_A_S12_RESERVED_SIZE;
      } ccipher_a_s12_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s12_t f;
} ccipher_a_s12_u;


/*
 * CCIPHER_A_S13 struct
 */

#define CCIPHER_A_S13_REG_SIZE         32
#define CCIPHER_A_S13_RESERVED_SIZE  32

#define CCIPHER_A_S13_RESERVED_SHIFT  0

#define CCIPHER_A_S13_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S13_MASK \
      (CCIPHER_A_S13_RESERVED_MASK)

#define CCIPHER_A_S13_DEFAULT          0x00000000

#define CCIPHER_A_S13_GET_RESERVED(ccipher_a_s13) \
      ((ccipher_a_s13 & CCIPHER_A_S13_RESERVED_MASK) >> CCIPHER_A_S13_RESERVED_SHIFT)

#define CCIPHER_A_S13_SET_RESERVED(ccipher_a_s13_reg, reserved) \
      ccipher_a_s13_reg = (ccipher_a_s13_reg & ~CCIPHER_A_S13_RESERVED_MASK) | (reserved << CCIPHER_A_S13_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s13_t {
            unsigned int reserved                       : CCIPHER_A_S13_RESERVED_SIZE;
      } ccipher_a_s13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s13_t {
            unsigned int reserved                       : CCIPHER_A_S13_RESERVED_SIZE;
      } ccipher_a_s13_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s13_t f;
} ccipher_a_s13_u;


/*
 * CCIPHER_A_S14 struct
 */

#define CCIPHER_A_S14_REG_SIZE         32
#define CCIPHER_A_S14_RESERVED_SIZE  32

#define CCIPHER_A_S14_RESERVED_SHIFT  0

#define CCIPHER_A_S14_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S14_MASK \
      (CCIPHER_A_S14_RESERVED_MASK)

#define CCIPHER_A_S14_DEFAULT          0x00000000

#define CCIPHER_A_S14_GET_RESERVED(ccipher_a_s14) \
      ((ccipher_a_s14 & CCIPHER_A_S14_RESERVED_MASK) >> CCIPHER_A_S14_RESERVED_SHIFT)

#define CCIPHER_A_S14_SET_RESERVED(ccipher_a_s14_reg, reserved) \
      ccipher_a_s14_reg = (ccipher_a_s14_reg & ~CCIPHER_A_S14_RESERVED_MASK) | (reserved << CCIPHER_A_S14_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s14_t {
            unsigned int reserved                       : CCIPHER_A_S14_RESERVED_SIZE;
      } ccipher_a_s14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s14_t {
            unsigned int reserved                       : CCIPHER_A_S14_RESERVED_SIZE;
      } ccipher_a_s14_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s14_t f;
} ccipher_a_s14_u;


/*
 * CCIPHER_A_S15 struct
 */

#define CCIPHER_A_S15_REG_SIZE         32
#define CCIPHER_A_S15_RESERVED_SIZE  32

#define CCIPHER_A_S15_RESERVED_SHIFT  0

#define CCIPHER_A_S15_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S15_MASK \
      (CCIPHER_A_S15_RESERVED_MASK)

#define CCIPHER_A_S15_DEFAULT          0x00000000

#define CCIPHER_A_S15_GET_RESERVED(ccipher_a_s15) \
      ((ccipher_a_s15 & CCIPHER_A_S15_RESERVED_MASK) >> CCIPHER_A_S15_RESERVED_SHIFT)

#define CCIPHER_A_S15_SET_RESERVED(ccipher_a_s15_reg, reserved) \
      ccipher_a_s15_reg = (ccipher_a_s15_reg & ~CCIPHER_A_S15_RESERVED_MASK) | (reserved << CCIPHER_A_S15_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s15_t {
            unsigned int reserved                       : CCIPHER_A_S15_RESERVED_SIZE;
      } ccipher_a_s15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s15_t {
            unsigned int reserved                       : CCIPHER_A_S15_RESERVED_SIZE;
      } ccipher_a_s15_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s15_t f;
} ccipher_a_s15_u;


/*
 * CCIPHER_A_S16 struct
 */

#define CCIPHER_A_S16_REG_SIZE         32
#define CCIPHER_A_S16_RESERVED_SIZE  32

#define CCIPHER_A_S16_RESERVED_SHIFT  0

#define CCIPHER_A_S16_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S16_MASK \
      (CCIPHER_A_S16_RESERVED_MASK)

#define CCIPHER_A_S16_DEFAULT          0x00000000

#define CCIPHER_A_S16_GET_RESERVED(ccipher_a_s16) \
      ((ccipher_a_s16 & CCIPHER_A_S16_RESERVED_MASK) >> CCIPHER_A_S16_RESERVED_SHIFT)

#define CCIPHER_A_S16_SET_RESERVED(ccipher_a_s16_reg, reserved) \
      ccipher_a_s16_reg = (ccipher_a_s16_reg & ~CCIPHER_A_S16_RESERVED_MASK) | (reserved << CCIPHER_A_S16_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s16_t {
            unsigned int reserved                       : CCIPHER_A_S16_RESERVED_SIZE;
      } ccipher_a_s16_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s16_t {
            unsigned int reserved                       : CCIPHER_A_S16_RESERVED_SIZE;
      } ccipher_a_s16_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s16_t f;
} ccipher_a_s16_u;


/*
 * CCIPHER_A_S17 struct
 */

#define CCIPHER_A_S17_REG_SIZE         32
#define CCIPHER_A_S17_RESERVED_SIZE  32

#define CCIPHER_A_S17_RESERVED_SHIFT  0

#define CCIPHER_A_S17_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S17_MASK \
      (CCIPHER_A_S17_RESERVED_MASK)

#define CCIPHER_A_S17_DEFAULT          0x00000000

#define CCIPHER_A_S17_GET_RESERVED(ccipher_a_s17) \
      ((ccipher_a_s17 & CCIPHER_A_S17_RESERVED_MASK) >> CCIPHER_A_S17_RESERVED_SHIFT)

#define CCIPHER_A_S17_SET_RESERVED(ccipher_a_s17_reg, reserved) \
      ccipher_a_s17_reg = (ccipher_a_s17_reg & ~CCIPHER_A_S17_RESERVED_MASK) | (reserved << CCIPHER_A_S17_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s17_t {
            unsigned int reserved                       : CCIPHER_A_S17_RESERVED_SIZE;
      } ccipher_a_s17_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s17_t {
            unsigned int reserved                       : CCIPHER_A_S17_RESERVED_SIZE;
      } ccipher_a_s17_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s17_t f;
} ccipher_a_s17_u;


/*
 * CCIPHER_A_S18 struct
 */

#define CCIPHER_A_S18_REG_SIZE         32
#define CCIPHER_A_S18_RESERVED_SIZE  32

#define CCIPHER_A_S18_RESERVED_SHIFT  0

#define CCIPHER_A_S18_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S18_MASK \
      (CCIPHER_A_S18_RESERVED_MASK)

#define CCIPHER_A_S18_DEFAULT          0x00000000

#define CCIPHER_A_S18_GET_RESERVED(ccipher_a_s18) \
      ((ccipher_a_s18 & CCIPHER_A_S18_RESERVED_MASK) >> CCIPHER_A_S18_RESERVED_SHIFT)

#define CCIPHER_A_S18_SET_RESERVED(ccipher_a_s18_reg, reserved) \
      ccipher_a_s18_reg = (ccipher_a_s18_reg & ~CCIPHER_A_S18_RESERVED_MASK) | (reserved << CCIPHER_A_S18_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s18_t {
            unsigned int reserved                       : CCIPHER_A_S18_RESERVED_SIZE;
      } ccipher_a_s18_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s18_t {
            unsigned int reserved                       : CCIPHER_A_S18_RESERVED_SIZE;
      } ccipher_a_s18_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s18_t f;
} ccipher_a_s18_u;


/*
 * CCIPHER_A_S19 struct
 */

#define CCIPHER_A_S19_REG_SIZE         32
#define CCIPHER_A_S19_RESERVED_SIZE  32

#define CCIPHER_A_S19_RESERVED_SHIFT  0

#define CCIPHER_A_S19_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S19_MASK \
      (CCIPHER_A_S19_RESERVED_MASK)

#define CCIPHER_A_S19_DEFAULT          0x00000000

#define CCIPHER_A_S19_GET_RESERVED(ccipher_a_s19) \
      ((ccipher_a_s19 & CCIPHER_A_S19_RESERVED_MASK) >> CCIPHER_A_S19_RESERVED_SHIFT)

#define CCIPHER_A_S19_SET_RESERVED(ccipher_a_s19_reg, reserved) \
      ccipher_a_s19_reg = (ccipher_a_s19_reg & ~CCIPHER_A_S19_RESERVED_MASK) | (reserved << CCIPHER_A_S19_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s19_t {
            unsigned int reserved                       : CCIPHER_A_S19_RESERVED_SIZE;
      } ccipher_a_s19_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s19_t {
            unsigned int reserved                       : CCIPHER_A_S19_RESERVED_SIZE;
      } ccipher_a_s19_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s19_t f;
} ccipher_a_s19_u;


/*
 * CCIPHER_A_S20 struct
 */

#define CCIPHER_A_S20_REG_SIZE         32
#define CCIPHER_A_S20_RESERVED_SIZE  32

#define CCIPHER_A_S20_RESERVED_SHIFT  0

#define CCIPHER_A_S20_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S20_MASK \
      (CCIPHER_A_S20_RESERVED_MASK)

#define CCIPHER_A_S20_DEFAULT          0x00000000

#define CCIPHER_A_S20_GET_RESERVED(ccipher_a_s20) \
      ((ccipher_a_s20 & CCIPHER_A_S20_RESERVED_MASK) >> CCIPHER_A_S20_RESERVED_SHIFT)

#define CCIPHER_A_S20_SET_RESERVED(ccipher_a_s20_reg, reserved) \
      ccipher_a_s20_reg = (ccipher_a_s20_reg & ~CCIPHER_A_S20_RESERVED_MASK) | (reserved << CCIPHER_A_S20_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s20_t {
            unsigned int reserved                       : CCIPHER_A_S20_RESERVED_SIZE;
      } ccipher_a_s20_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s20_t {
            unsigned int reserved                       : CCIPHER_A_S20_RESERVED_SIZE;
      } ccipher_a_s20_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s20_t f;
} ccipher_a_s20_u;


/*
 * CCIPHER_A_S21 struct
 */

#define CCIPHER_A_S21_REG_SIZE         32
#define CCIPHER_A_S21_RESERVED_SIZE  32

#define CCIPHER_A_S21_RESERVED_SHIFT  0

#define CCIPHER_A_S21_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S21_MASK \
      (CCIPHER_A_S21_RESERVED_MASK)

#define CCIPHER_A_S21_DEFAULT          0x00000000

#define CCIPHER_A_S21_GET_RESERVED(ccipher_a_s21) \
      ((ccipher_a_s21 & CCIPHER_A_S21_RESERVED_MASK) >> CCIPHER_A_S21_RESERVED_SHIFT)

#define CCIPHER_A_S21_SET_RESERVED(ccipher_a_s21_reg, reserved) \
      ccipher_a_s21_reg = (ccipher_a_s21_reg & ~CCIPHER_A_S21_RESERVED_MASK) | (reserved << CCIPHER_A_S21_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s21_t {
            unsigned int reserved                       : CCIPHER_A_S21_RESERVED_SIZE;
      } ccipher_a_s21_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s21_t {
            unsigned int reserved                       : CCIPHER_A_S21_RESERVED_SIZE;
      } ccipher_a_s21_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s21_t f;
} ccipher_a_s21_u;


/*
 * CCIPHER_A_S22 struct
 */

#define CCIPHER_A_S22_REG_SIZE         32
#define CCIPHER_A_S22_RESERVED_SIZE  32

#define CCIPHER_A_S22_RESERVED_SHIFT  0

#define CCIPHER_A_S22_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S22_MASK \
      (CCIPHER_A_S22_RESERVED_MASK)

#define CCIPHER_A_S22_DEFAULT          0x00000000

#define CCIPHER_A_S22_GET_RESERVED(ccipher_a_s22) \
      ((ccipher_a_s22 & CCIPHER_A_S22_RESERVED_MASK) >> CCIPHER_A_S22_RESERVED_SHIFT)

#define CCIPHER_A_S22_SET_RESERVED(ccipher_a_s22_reg, reserved) \
      ccipher_a_s22_reg = (ccipher_a_s22_reg & ~CCIPHER_A_S22_RESERVED_MASK) | (reserved << CCIPHER_A_S22_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s22_t {
            unsigned int reserved                       : CCIPHER_A_S22_RESERVED_SIZE;
      } ccipher_a_s22_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s22_t {
            unsigned int reserved                       : CCIPHER_A_S22_RESERVED_SIZE;
      } ccipher_a_s22_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s22_t f;
} ccipher_a_s22_u;


/*
 * CCIPHER_A_S23 struct
 */

#define CCIPHER_A_S23_REG_SIZE         32
#define CCIPHER_A_S23_RESERVED_SIZE  32

#define CCIPHER_A_S23_RESERVED_SHIFT  0

#define CCIPHER_A_S23_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S23_MASK \
      (CCIPHER_A_S23_RESERVED_MASK)

#define CCIPHER_A_S23_DEFAULT          0x00000000

#define CCIPHER_A_S23_GET_RESERVED(ccipher_a_s23) \
      ((ccipher_a_s23 & CCIPHER_A_S23_RESERVED_MASK) >> CCIPHER_A_S23_RESERVED_SHIFT)

#define CCIPHER_A_S23_SET_RESERVED(ccipher_a_s23_reg, reserved) \
      ccipher_a_s23_reg = (ccipher_a_s23_reg & ~CCIPHER_A_S23_RESERVED_MASK) | (reserved << CCIPHER_A_S23_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s23_t {
            unsigned int reserved                       : CCIPHER_A_S23_RESERVED_SIZE;
      } ccipher_a_s23_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s23_t {
            unsigned int reserved                       : CCIPHER_A_S23_RESERVED_SIZE;
      } ccipher_a_s23_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s23_t f;
} ccipher_a_s23_u;


/*
 * CCIPHER_A_S24 struct
 */

#define CCIPHER_A_S24_REG_SIZE         32
#define CCIPHER_A_S24_RESERVED_SIZE  32

#define CCIPHER_A_S24_RESERVED_SHIFT  0

#define CCIPHER_A_S24_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S24_MASK \
      (CCIPHER_A_S24_RESERVED_MASK)

#define CCIPHER_A_S24_DEFAULT          0x00000000

#define CCIPHER_A_S24_GET_RESERVED(ccipher_a_s24) \
      ((ccipher_a_s24 & CCIPHER_A_S24_RESERVED_MASK) >> CCIPHER_A_S24_RESERVED_SHIFT)

#define CCIPHER_A_S24_SET_RESERVED(ccipher_a_s24_reg, reserved) \
      ccipher_a_s24_reg = (ccipher_a_s24_reg & ~CCIPHER_A_S24_RESERVED_MASK) | (reserved << CCIPHER_A_S24_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s24_t {
            unsigned int reserved                       : CCIPHER_A_S24_RESERVED_SIZE;
      } ccipher_a_s24_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s24_t {
            unsigned int reserved                       : CCIPHER_A_S24_RESERVED_SIZE;
      } ccipher_a_s24_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s24_t f;
} ccipher_a_s24_u;


/*
 * CCIPHER_A_S25 struct
 */

#define CCIPHER_A_S25_REG_SIZE         32
#define CCIPHER_A_S25_RESERVED_SIZE  32

#define CCIPHER_A_S25_RESERVED_SHIFT  0

#define CCIPHER_A_S25_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S25_MASK \
      (CCIPHER_A_S25_RESERVED_MASK)

#define CCIPHER_A_S25_DEFAULT          0x00000000

#define CCIPHER_A_S25_GET_RESERVED(ccipher_a_s25) \
      ((ccipher_a_s25 & CCIPHER_A_S25_RESERVED_MASK) >> CCIPHER_A_S25_RESERVED_SHIFT)

#define CCIPHER_A_S25_SET_RESERVED(ccipher_a_s25_reg, reserved) \
      ccipher_a_s25_reg = (ccipher_a_s25_reg & ~CCIPHER_A_S25_RESERVED_MASK) | (reserved << CCIPHER_A_S25_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s25_t {
            unsigned int reserved                       : CCIPHER_A_S25_RESERVED_SIZE;
      } ccipher_a_s25_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s25_t {
            unsigned int reserved                       : CCIPHER_A_S25_RESERVED_SIZE;
      } ccipher_a_s25_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s25_t f;
} ccipher_a_s25_u;


/*
 * CCIPHER_A_S26 struct
 */

#define CCIPHER_A_S26_REG_SIZE         32
#define CCIPHER_A_S26_RESERVED_SIZE  32

#define CCIPHER_A_S26_RESERVED_SHIFT  0

#define CCIPHER_A_S26_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S26_MASK \
      (CCIPHER_A_S26_RESERVED_MASK)

#define CCIPHER_A_S26_DEFAULT          0x00000000

#define CCIPHER_A_S26_GET_RESERVED(ccipher_a_s26) \
      ((ccipher_a_s26 & CCIPHER_A_S26_RESERVED_MASK) >> CCIPHER_A_S26_RESERVED_SHIFT)

#define CCIPHER_A_S26_SET_RESERVED(ccipher_a_s26_reg, reserved) \
      ccipher_a_s26_reg = (ccipher_a_s26_reg & ~CCIPHER_A_S26_RESERVED_MASK) | (reserved << CCIPHER_A_S26_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s26_t {
            unsigned int reserved                       : CCIPHER_A_S26_RESERVED_SIZE;
      } ccipher_a_s26_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s26_t {
            unsigned int reserved                       : CCIPHER_A_S26_RESERVED_SIZE;
      } ccipher_a_s26_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s26_t f;
} ccipher_a_s26_u;


/*
 * CCIPHER_A_S27 struct
 */

#define CCIPHER_A_S27_REG_SIZE         32
#define CCIPHER_A_S27_RESERVED_SIZE  32

#define CCIPHER_A_S27_RESERVED_SHIFT  0

#define CCIPHER_A_S27_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S27_MASK \
      (CCIPHER_A_S27_RESERVED_MASK)

#define CCIPHER_A_S27_DEFAULT          0x00000000

#define CCIPHER_A_S27_GET_RESERVED(ccipher_a_s27) \
      ((ccipher_a_s27 & CCIPHER_A_S27_RESERVED_MASK) >> CCIPHER_A_S27_RESERVED_SHIFT)

#define CCIPHER_A_S27_SET_RESERVED(ccipher_a_s27_reg, reserved) \
      ccipher_a_s27_reg = (ccipher_a_s27_reg & ~CCIPHER_A_S27_RESERVED_MASK) | (reserved << CCIPHER_A_S27_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s27_t {
            unsigned int reserved                       : CCIPHER_A_S27_RESERVED_SIZE;
      } ccipher_a_s27_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s27_t {
            unsigned int reserved                       : CCIPHER_A_S27_RESERVED_SIZE;
      } ccipher_a_s27_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s27_t f;
} ccipher_a_s27_u;


/*
 * CCIPHER_A_S28 struct
 */

#define CCIPHER_A_S28_REG_SIZE         32
#define CCIPHER_A_S28_RESERVED_SIZE  32

#define CCIPHER_A_S28_RESERVED_SHIFT  0

#define CCIPHER_A_S28_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S28_MASK \
      (CCIPHER_A_S28_RESERVED_MASK)

#define CCIPHER_A_S28_DEFAULT          0x00000000

#define CCIPHER_A_S28_GET_RESERVED(ccipher_a_s28) \
      ((ccipher_a_s28 & CCIPHER_A_S28_RESERVED_MASK) >> CCIPHER_A_S28_RESERVED_SHIFT)

#define CCIPHER_A_S28_SET_RESERVED(ccipher_a_s28_reg, reserved) \
      ccipher_a_s28_reg = (ccipher_a_s28_reg & ~CCIPHER_A_S28_RESERVED_MASK) | (reserved << CCIPHER_A_S28_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s28_t {
            unsigned int reserved                       : CCIPHER_A_S28_RESERVED_SIZE;
      } ccipher_a_s28_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s28_t {
            unsigned int reserved                       : CCIPHER_A_S28_RESERVED_SIZE;
      } ccipher_a_s28_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s28_t f;
} ccipher_a_s28_u;


/*
 * CCIPHER_A_S29 struct
 */

#define CCIPHER_A_S29_REG_SIZE         32
#define CCIPHER_A_S29_RESERVED_SIZE  32

#define CCIPHER_A_S29_RESERVED_SHIFT  0

#define CCIPHER_A_S29_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S29_MASK \
      (CCIPHER_A_S29_RESERVED_MASK)

#define CCIPHER_A_S29_DEFAULT          0x00000000

#define CCIPHER_A_S29_GET_RESERVED(ccipher_a_s29) \
      ((ccipher_a_s29 & CCIPHER_A_S29_RESERVED_MASK) >> CCIPHER_A_S29_RESERVED_SHIFT)

#define CCIPHER_A_S29_SET_RESERVED(ccipher_a_s29_reg, reserved) \
      ccipher_a_s29_reg = (ccipher_a_s29_reg & ~CCIPHER_A_S29_RESERVED_MASK) | (reserved << CCIPHER_A_S29_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s29_t {
            unsigned int reserved                       : CCIPHER_A_S29_RESERVED_SIZE;
      } ccipher_a_s29_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s29_t {
            unsigned int reserved                       : CCIPHER_A_S29_RESERVED_SIZE;
      } ccipher_a_s29_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s29_t f;
} ccipher_a_s29_u;


/*
 * CCIPHER_A_S30 struct
 */

#define CCIPHER_A_S30_REG_SIZE         32
#define CCIPHER_A_S30_RESERVED_SIZE  32

#define CCIPHER_A_S30_RESERVED_SHIFT  0

#define CCIPHER_A_S30_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S30_MASK \
      (CCIPHER_A_S30_RESERVED_MASK)

#define CCIPHER_A_S30_DEFAULT          0x00000000

#define CCIPHER_A_S30_GET_RESERVED(ccipher_a_s30) \
      ((ccipher_a_s30 & CCIPHER_A_S30_RESERVED_MASK) >> CCIPHER_A_S30_RESERVED_SHIFT)

#define CCIPHER_A_S30_SET_RESERVED(ccipher_a_s30_reg, reserved) \
      ccipher_a_s30_reg = (ccipher_a_s30_reg & ~CCIPHER_A_S30_RESERVED_MASK) | (reserved << CCIPHER_A_S30_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s30_t {
            unsigned int reserved                       : CCIPHER_A_S30_RESERVED_SIZE;
      } ccipher_a_s30_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s30_t {
            unsigned int reserved                       : CCIPHER_A_S30_RESERVED_SIZE;
      } ccipher_a_s30_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s30_t f;
} ccipher_a_s30_u;


/*
 * CCIPHER_A_S31 struct
 */

#define CCIPHER_A_S31_REG_SIZE         32
#define CCIPHER_A_S31_RESERVED_SIZE  32

#define CCIPHER_A_S31_RESERVED_SHIFT  0

#define CCIPHER_A_S31_RESERVED_MASK     0xffffffff

#define CCIPHER_A_S31_MASK \
      (CCIPHER_A_S31_RESERVED_MASK)

#define CCIPHER_A_S31_DEFAULT          0x00000000

#define CCIPHER_A_S31_GET_RESERVED(ccipher_a_s31) \
      ((ccipher_a_s31 & CCIPHER_A_S31_RESERVED_MASK) >> CCIPHER_A_S31_RESERVED_SHIFT)

#define CCIPHER_A_S31_SET_RESERVED(ccipher_a_s31_reg, reserved) \
      ccipher_a_s31_reg = (ccipher_a_s31_reg & ~CCIPHER_A_S31_RESERVED_MASK) | (reserved << CCIPHER_A_S31_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_a_s31_t {
            unsigned int reserved                       : CCIPHER_A_S31_RESERVED_SIZE;
      } ccipher_a_s31_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_a_s31_t {
            unsigned int reserved                       : CCIPHER_A_S31_RESERVED_SIZE;
      } ccipher_a_s31_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_a_s31_t f;
} ccipher_a_s31_u;


/*
 * CCIPHER_B_IK0 struct
 */

#define CCIPHER_B_IK0_REG_SIZE         32
#define CCIPHER_B_IK0_RESERVED_SIZE  32

#define CCIPHER_B_IK0_RESERVED_SHIFT  0

#define CCIPHER_B_IK0_RESERVED_MASK     0xffffffff

#define CCIPHER_B_IK0_MASK \
      (CCIPHER_B_IK0_RESERVED_MASK)

#define CCIPHER_B_IK0_DEFAULT          0x00000000

#define CCIPHER_B_IK0_GET_RESERVED(ccipher_b_ik0) \
      ((ccipher_b_ik0 & CCIPHER_B_IK0_RESERVED_MASK) >> CCIPHER_B_IK0_RESERVED_SHIFT)

#define CCIPHER_B_IK0_SET_RESERVED(ccipher_b_ik0_reg, reserved) \
      ccipher_b_ik0_reg = (ccipher_b_ik0_reg & ~CCIPHER_B_IK0_RESERVED_MASK) | (reserved << CCIPHER_B_IK0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_ik0_t {
            unsigned int reserved                       : CCIPHER_B_IK0_RESERVED_SIZE;
      } ccipher_b_ik0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_ik0_t {
            unsigned int reserved                       : CCIPHER_B_IK0_RESERVED_SIZE;
      } ccipher_b_ik0_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_ik0_t f;
} ccipher_b_ik0_u;


/*
 * CCIPHER_B_IK1 struct
 */

#define CCIPHER_B_IK1_REG_SIZE         32
#define CCIPHER_B_IK1_RESERVED_SIZE  32

#define CCIPHER_B_IK1_RESERVED_SHIFT  0

#define CCIPHER_B_IK1_RESERVED_MASK     0xffffffff

#define CCIPHER_B_IK1_MASK \
      (CCIPHER_B_IK1_RESERVED_MASK)

#define CCIPHER_B_IK1_DEFAULT          0x00000000

#define CCIPHER_B_IK1_GET_RESERVED(ccipher_b_ik1) \
      ((ccipher_b_ik1 & CCIPHER_B_IK1_RESERVED_MASK) >> CCIPHER_B_IK1_RESERVED_SHIFT)

#define CCIPHER_B_IK1_SET_RESERVED(ccipher_b_ik1_reg, reserved) \
      ccipher_b_ik1_reg = (ccipher_b_ik1_reg & ~CCIPHER_B_IK1_RESERVED_MASK) | (reserved << CCIPHER_B_IK1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_ik1_t {
            unsigned int reserved                       : CCIPHER_B_IK1_RESERVED_SIZE;
      } ccipher_b_ik1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_ik1_t {
            unsigned int reserved                       : CCIPHER_B_IK1_RESERVED_SIZE;
      } ccipher_b_ik1_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_ik1_t f;
} ccipher_b_ik1_u;


/*
 * CCIPHER_B_IK2 struct
 */

#define CCIPHER_B_IK2_REG_SIZE         32
#define CCIPHER_B_IK2_RESERVED_SIZE  32

#define CCIPHER_B_IK2_RESERVED_SHIFT  0

#define CCIPHER_B_IK2_RESERVED_MASK     0xffffffff

#define CCIPHER_B_IK2_MASK \
      (CCIPHER_B_IK2_RESERVED_MASK)

#define CCIPHER_B_IK2_DEFAULT          0x00000000

#define CCIPHER_B_IK2_GET_RESERVED(ccipher_b_ik2) \
      ((ccipher_b_ik2 & CCIPHER_B_IK2_RESERVED_MASK) >> CCIPHER_B_IK2_RESERVED_SHIFT)

#define CCIPHER_B_IK2_SET_RESERVED(ccipher_b_ik2_reg, reserved) \
      ccipher_b_ik2_reg = (ccipher_b_ik2_reg & ~CCIPHER_B_IK2_RESERVED_MASK) | (reserved << CCIPHER_B_IK2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_ik2_t {
            unsigned int reserved                       : CCIPHER_B_IK2_RESERVED_SIZE;
      } ccipher_b_ik2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_ik2_t {
            unsigned int reserved                       : CCIPHER_B_IK2_RESERVED_SIZE;
      } ccipher_b_ik2_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_ik2_t f;
} ccipher_b_ik2_u;


/*
 * CCIPHER_B_IK3 struct
 */

#define CCIPHER_B_IK3_REG_SIZE         32
#define CCIPHER_B_IK3_RESERVED_SIZE  32

#define CCIPHER_B_IK3_RESERVED_SHIFT  0

#define CCIPHER_B_IK3_RESERVED_MASK     0xffffffff

#define CCIPHER_B_IK3_MASK \
      (CCIPHER_B_IK3_RESERVED_MASK)

#define CCIPHER_B_IK3_DEFAULT          0x00000000

#define CCIPHER_B_IK3_GET_RESERVED(ccipher_b_ik3) \
      ((ccipher_b_ik3 & CCIPHER_B_IK3_RESERVED_MASK) >> CCIPHER_B_IK3_RESERVED_SHIFT)

#define CCIPHER_B_IK3_SET_RESERVED(ccipher_b_ik3_reg, reserved) \
      ccipher_b_ik3_reg = (ccipher_b_ik3_reg & ~CCIPHER_B_IK3_RESERVED_MASK) | (reserved << CCIPHER_B_IK3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_ik3_t {
            unsigned int reserved                       : CCIPHER_B_IK3_RESERVED_SIZE;
      } ccipher_b_ik3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_ik3_t {
            unsigned int reserved                       : CCIPHER_B_IK3_RESERVED_SIZE;
      } ccipher_b_ik3_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_ik3_t f;
} ccipher_b_ik3_u;


/*
 * CCIPHER_B_S0 struct
 */

#define CCIPHER_B_S0_REG_SIZE         32
#define CCIPHER_B_S0_RESERVED_SIZE  32

#define CCIPHER_B_S0_RESERVED_SHIFT  0

#define CCIPHER_B_S0_RESERVED_MASK      0xffffffff

#define CCIPHER_B_S0_MASK \
      (CCIPHER_B_S0_RESERVED_MASK)

#define CCIPHER_B_S0_DEFAULT           0x00000000

#define CCIPHER_B_S0_GET_RESERVED(ccipher_b_s0) \
      ((ccipher_b_s0 & CCIPHER_B_S0_RESERVED_MASK) >> CCIPHER_B_S0_RESERVED_SHIFT)

#define CCIPHER_B_S0_SET_RESERVED(ccipher_b_s0_reg, reserved) \
      ccipher_b_s0_reg = (ccipher_b_s0_reg & ~CCIPHER_B_S0_RESERVED_MASK) | (reserved << CCIPHER_B_S0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s0_t {
            unsigned int reserved                       : CCIPHER_B_S0_RESERVED_SIZE;
      } ccipher_b_s0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s0_t {
            unsigned int reserved                       : CCIPHER_B_S0_RESERVED_SIZE;
      } ccipher_b_s0_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s0_t f;
} ccipher_b_s0_u;


/*
 * CCIPHER_B_S1 struct
 */

#define CCIPHER_B_S1_REG_SIZE         32
#define CCIPHER_B_S1_RESERVED_SIZE  32

#define CCIPHER_B_S1_RESERVED_SHIFT  0

#define CCIPHER_B_S1_RESERVED_MASK      0xffffffff

#define CCIPHER_B_S1_MASK \
      (CCIPHER_B_S1_RESERVED_MASK)

#define CCIPHER_B_S1_DEFAULT           0x00000000

#define CCIPHER_B_S1_GET_RESERVED(ccipher_b_s1) \
      ((ccipher_b_s1 & CCIPHER_B_S1_RESERVED_MASK) >> CCIPHER_B_S1_RESERVED_SHIFT)

#define CCIPHER_B_S1_SET_RESERVED(ccipher_b_s1_reg, reserved) \
      ccipher_b_s1_reg = (ccipher_b_s1_reg & ~CCIPHER_B_S1_RESERVED_MASK) | (reserved << CCIPHER_B_S1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s1_t {
            unsigned int reserved                       : CCIPHER_B_S1_RESERVED_SIZE;
      } ccipher_b_s1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s1_t {
            unsigned int reserved                       : CCIPHER_B_S1_RESERVED_SIZE;
      } ccipher_b_s1_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s1_t f;
} ccipher_b_s1_u;


/*
 * CCIPHER_B_S2 struct
 */

#define CCIPHER_B_S2_REG_SIZE         32
#define CCIPHER_B_S2_RESERVED_SIZE  32

#define CCIPHER_B_S2_RESERVED_SHIFT  0

#define CCIPHER_B_S2_RESERVED_MASK      0xffffffff

#define CCIPHER_B_S2_MASK \
      (CCIPHER_B_S2_RESERVED_MASK)

#define CCIPHER_B_S2_DEFAULT           0x00000000

#define CCIPHER_B_S2_GET_RESERVED(ccipher_b_s2) \
      ((ccipher_b_s2 & CCIPHER_B_S2_RESERVED_MASK) >> CCIPHER_B_S2_RESERVED_SHIFT)

#define CCIPHER_B_S2_SET_RESERVED(ccipher_b_s2_reg, reserved) \
      ccipher_b_s2_reg = (ccipher_b_s2_reg & ~CCIPHER_B_S2_RESERVED_MASK) | (reserved << CCIPHER_B_S2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s2_t {
            unsigned int reserved                       : CCIPHER_B_S2_RESERVED_SIZE;
      } ccipher_b_s2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s2_t {
            unsigned int reserved                       : CCIPHER_B_S2_RESERVED_SIZE;
      } ccipher_b_s2_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s2_t f;
} ccipher_b_s2_u;


/*
 * CCIPHER_B_S3 struct
 */

#define CCIPHER_B_S3_REG_SIZE         32
#define CCIPHER_B_S3_RESERVED_SIZE  32

#define CCIPHER_B_S3_RESERVED_SHIFT  0

#define CCIPHER_B_S3_RESERVED_MASK      0xffffffff

#define CCIPHER_B_S3_MASK \
      (CCIPHER_B_S3_RESERVED_MASK)

#define CCIPHER_B_S3_DEFAULT           0x00000000

#define CCIPHER_B_S3_GET_RESERVED(ccipher_b_s3) \
      ((ccipher_b_s3 & CCIPHER_B_S3_RESERVED_MASK) >> CCIPHER_B_S3_RESERVED_SHIFT)

#define CCIPHER_B_S3_SET_RESERVED(ccipher_b_s3_reg, reserved) \
      ccipher_b_s3_reg = (ccipher_b_s3_reg & ~CCIPHER_B_S3_RESERVED_MASK) | (reserved << CCIPHER_B_S3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s3_t {
            unsigned int reserved                       : CCIPHER_B_S3_RESERVED_SIZE;
      } ccipher_b_s3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s3_t {
            unsigned int reserved                       : CCIPHER_B_S3_RESERVED_SIZE;
      } ccipher_b_s3_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s3_t f;
} ccipher_b_s3_u;


/*
 * CCIPHER_B_S4 struct
 */

#define CCIPHER_B_S4_REG_SIZE         32
#define CCIPHER_B_S4_RESERVED_SIZE  32

#define CCIPHER_B_S4_RESERVED_SHIFT  0

#define CCIPHER_B_S4_RESERVED_MASK      0xffffffff

#define CCIPHER_B_S4_MASK \
      (CCIPHER_B_S4_RESERVED_MASK)

#define CCIPHER_B_S4_DEFAULT           0x00000000

#define CCIPHER_B_S4_GET_RESERVED(ccipher_b_s4) \
      ((ccipher_b_s4 & CCIPHER_B_S4_RESERVED_MASK) >> CCIPHER_B_S4_RESERVED_SHIFT)

#define CCIPHER_B_S4_SET_RESERVED(ccipher_b_s4_reg, reserved) \
      ccipher_b_s4_reg = (ccipher_b_s4_reg & ~CCIPHER_B_S4_RESERVED_MASK) | (reserved << CCIPHER_B_S4_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s4_t {
            unsigned int reserved                       : CCIPHER_B_S4_RESERVED_SIZE;
      } ccipher_b_s4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s4_t {
            unsigned int reserved                       : CCIPHER_B_S4_RESERVED_SIZE;
      } ccipher_b_s4_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s4_t f;
} ccipher_b_s4_u;


/*
 * CCIPHER_B_S5 struct
 */

#define CCIPHER_B_S5_REG_SIZE         32
#define CCIPHER_B_S5_RESERVED_SIZE  32

#define CCIPHER_B_S5_RESERVED_SHIFT  0

#define CCIPHER_B_S5_RESERVED_MASK      0xffffffff

#define CCIPHER_B_S5_MASK \
      (CCIPHER_B_S5_RESERVED_MASK)

#define CCIPHER_B_S5_DEFAULT           0x00000000

#define CCIPHER_B_S5_GET_RESERVED(ccipher_b_s5) \
      ((ccipher_b_s5 & CCIPHER_B_S5_RESERVED_MASK) >> CCIPHER_B_S5_RESERVED_SHIFT)

#define CCIPHER_B_S5_SET_RESERVED(ccipher_b_s5_reg, reserved) \
      ccipher_b_s5_reg = (ccipher_b_s5_reg & ~CCIPHER_B_S5_RESERVED_MASK) | (reserved << CCIPHER_B_S5_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s5_t {
            unsigned int reserved                       : CCIPHER_B_S5_RESERVED_SIZE;
      } ccipher_b_s5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s5_t {
            unsigned int reserved                       : CCIPHER_B_S5_RESERVED_SIZE;
      } ccipher_b_s5_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s5_t f;
} ccipher_b_s5_u;


/*
 * CCIPHER_B_S6 struct
 */

#define CCIPHER_B_S6_REG_SIZE         32
#define CCIPHER_B_S6_RESERVED_SIZE  32

#define CCIPHER_B_S6_RESERVED_SHIFT  0

#define CCIPHER_B_S6_RESERVED_MASK      0xffffffff

#define CCIPHER_B_S6_MASK \
      (CCIPHER_B_S6_RESERVED_MASK)

#define CCIPHER_B_S6_DEFAULT           0x00000000

#define CCIPHER_B_S6_GET_RESERVED(ccipher_b_s6) \
      ((ccipher_b_s6 & CCIPHER_B_S6_RESERVED_MASK) >> CCIPHER_B_S6_RESERVED_SHIFT)

#define CCIPHER_B_S6_SET_RESERVED(ccipher_b_s6_reg, reserved) \
      ccipher_b_s6_reg = (ccipher_b_s6_reg & ~CCIPHER_B_S6_RESERVED_MASK) | (reserved << CCIPHER_B_S6_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s6_t {
            unsigned int reserved                       : CCIPHER_B_S6_RESERVED_SIZE;
      } ccipher_b_s6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s6_t {
            unsigned int reserved                       : CCIPHER_B_S6_RESERVED_SIZE;
      } ccipher_b_s6_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s6_t f;
} ccipher_b_s6_u;


/*
 * CCIPHER_B_S7 struct
 */

#define CCIPHER_B_S7_REG_SIZE         32
#define CCIPHER_B_S7_RESERVED_SIZE  32

#define CCIPHER_B_S7_RESERVED_SHIFT  0

#define CCIPHER_B_S7_RESERVED_MASK      0xffffffff

#define CCIPHER_B_S7_MASK \
      (CCIPHER_B_S7_RESERVED_MASK)

#define CCIPHER_B_S7_DEFAULT           0x00000000

#define CCIPHER_B_S7_GET_RESERVED(ccipher_b_s7) \
      ((ccipher_b_s7 & CCIPHER_B_S7_RESERVED_MASK) >> CCIPHER_B_S7_RESERVED_SHIFT)

#define CCIPHER_B_S7_SET_RESERVED(ccipher_b_s7_reg, reserved) \
      ccipher_b_s7_reg = (ccipher_b_s7_reg & ~CCIPHER_B_S7_RESERVED_MASK) | (reserved << CCIPHER_B_S7_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s7_t {
            unsigned int reserved                       : CCIPHER_B_S7_RESERVED_SIZE;
      } ccipher_b_s7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s7_t {
            unsigned int reserved                       : CCIPHER_B_S7_RESERVED_SIZE;
      } ccipher_b_s7_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s7_t f;
} ccipher_b_s7_u;


/*
 * CCIPHER_B_S8 struct
 */

#define CCIPHER_B_S8_REG_SIZE         32
#define CCIPHER_B_S8_RESERVED_SIZE  32

#define CCIPHER_B_S8_RESERVED_SHIFT  0

#define CCIPHER_B_S8_RESERVED_MASK      0xffffffff

#define CCIPHER_B_S8_MASK \
      (CCIPHER_B_S8_RESERVED_MASK)

#define CCIPHER_B_S8_DEFAULT           0x00000000

#define CCIPHER_B_S8_GET_RESERVED(ccipher_b_s8) \
      ((ccipher_b_s8 & CCIPHER_B_S8_RESERVED_MASK) >> CCIPHER_B_S8_RESERVED_SHIFT)

#define CCIPHER_B_S8_SET_RESERVED(ccipher_b_s8_reg, reserved) \
      ccipher_b_s8_reg = (ccipher_b_s8_reg & ~CCIPHER_B_S8_RESERVED_MASK) | (reserved << CCIPHER_B_S8_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s8_t {
            unsigned int reserved                       : CCIPHER_B_S8_RESERVED_SIZE;
      } ccipher_b_s8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s8_t {
            unsigned int reserved                       : CCIPHER_B_S8_RESERVED_SIZE;
      } ccipher_b_s8_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s8_t f;
} ccipher_b_s8_u;


/*
 * CCIPHER_B_S9 struct
 */

#define CCIPHER_B_S9_REG_SIZE         32
#define CCIPHER_B_S9_RESERVED_SIZE  32

#define CCIPHER_B_S9_RESERVED_SHIFT  0

#define CCIPHER_B_S9_RESERVED_MASK      0xffffffff

#define CCIPHER_B_S9_MASK \
      (CCIPHER_B_S9_RESERVED_MASK)

#define CCIPHER_B_S9_DEFAULT           0x00000000

#define CCIPHER_B_S9_GET_RESERVED(ccipher_b_s9) \
      ((ccipher_b_s9 & CCIPHER_B_S9_RESERVED_MASK) >> CCIPHER_B_S9_RESERVED_SHIFT)

#define CCIPHER_B_S9_SET_RESERVED(ccipher_b_s9_reg, reserved) \
      ccipher_b_s9_reg = (ccipher_b_s9_reg & ~CCIPHER_B_S9_RESERVED_MASK) | (reserved << CCIPHER_B_S9_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s9_t {
            unsigned int reserved                       : CCIPHER_B_S9_RESERVED_SIZE;
      } ccipher_b_s9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s9_t {
            unsigned int reserved                       : CCIPHER_B_S9_RESERVED_SIZE;
      } ccipher_b_s9_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s9_t f;
} ccipher_b_s9_u;


/*
 * CCIPHER_B_S10 struct
 */

#define CCIPHER_B_S10_REG_SIZE         32
#define CCIPHER_B_S10_RESERVED_SIZE  32

#define CCIPHER_B_S10_RESERVED_SHIFT  0

#define CCIPHER_B_S10_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S10_MASK \
      (CCIPHER_B_S10_RESERVED_MASK)

#define CCIPHER_B_S10_DEFAULT          0x00000000

#define CCIPHER_B_S10_GET_RESERVED(ccipher_b_s10) \
      ((ccipher_b_s10 & CCIPHER_B_S10_RESERVED_MASK) >> CCIPHER_B_S10_RESERVED_SHIFT)

#define CCIPHER_B_S10_SET_RESERVED(ccipher_b_s10_reg, reserved) \
      ccipher_b_s10_reg = (ccipher_b_s10_reg & ~CCIPHER_B_S10_RESERVED_MASK) | (reserved << CCIPHER_B_S10_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s10_t {
            unsigned int reserved                       : CCIPHER_B_S10_RESERVED_SIZE;
      } ccipher_b_s10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s10_t {
            unsigned int reserved                       : CCIPHER_B_S10_RESERVED_SIZE;
      } ccipher_b_s10_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s10_t f;
} ccipher_b_s10_u;


/*
 * CCIPHER_B_S11 struct
 */

#define CCIPHER_B_S11_REG_SIZE         32
#define CCIPHER_B_S11_RESERVED_SIZE  32

#define CCIPHER_B_S11_RESERVED_SHIFT  0

#define CCIPHER_B_S11_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S11_MASK \
      (CCIPHER_B_S11_RESERVED_MASK)

#define CCIPHER_B_S11_DEFAULT          0x00000000

#define CCIPHER_B_S11_GET_RESERVED(ccipher_b_s11) \
      ((ccipher_b_s11 & CCIPHER_B_S11_RESERVED_MASK) >> CCIPHER_B_S11_RESERVED_SHIFT)

#define CCIPHER_B_S11_SET_RESERVED(ccipher_b_s11_reg, reserved) \
      ccipher_b_s11_reg = (ccipher_b_s11_reg & ~CCIPHER_B_S11_RESERVED_MASK) | (reserved << CCIPHER_B_S11_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s11_t {
            unsigned int reserved                       : CCIPHER_B_S11_RESERVED_SIZE;
      } ccipher_b_s11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s11_t {
            unsigned int reserved                       : CCIPHER_B_S11_RESERVED_SIZE;
      } ccipher_b_s11_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s11_t f;
} ccipher_b_s11_u;


/*
 * CCIPHER_B_S12 struct
 */

#define CCIPHER_B_S12_REG_SIZE         32
#define CCIPHER_B_S12_RESERVED_SIZE  32

#define CCIPHER_B_S12_RESERVED_SHIFT  0

#define CCIPHER_B_S12_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S12_MASK \
      (CCIPHER_B_S12_RESERVED_MASK)

#define CCIPHER_B_S12_DEFAULT          0x00000000

#define CCIPHER_B_S12_GET_RESERVED(ccipher_b_s12) \
      ((ccipher_b_s12 & CCIPHER_B_S12_RESERVED_MASK) >> CCIPHER_B_S12_RESERVED_SHIFT)

#define CCIPHER_B_S12_SET_RESERVED(ccipher_b_s12_reg, reserved) \
      ccipher_b_s12_reg = (ccipher_b_s12_reg & ~CCIPHER_B_S12_RESERVED_MASK) | (reserved << CCIPHER_B_S12_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s12_t {
            unsigned int reserved                       : CCIPHER_B_S12_RESERVED_SIZE;
      } ccipher_b_s12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s12_t {
            unsigned int reserved                       : CCIPHER_B_S12_RESERVED_SIZE;
      } ccipher_b_s12_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s12_t f;
} ccipher_b_s12_u;


/*
 * CCIPHER_B_S13 struct
 */

#define CCIPHER_B_S13_REG_SIZE         32
#define CCIPHER_B_S13_RESERVED_SIZE  32

#define CCIPHER_B_S13_RESERVED_SHIFT  0

#define CCIPHER_B_S13_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S13_MASK \
      (CCIPHER_B_S13_RESERVED_MASK)

#define CCIPHER_B_S13_DEFAULT          0x00000000

#define CCIPHER_B_S13_GET_RESERVED(ccipher_b_s13) \
      ((ccipher_b_s13 & CCIPHER_B_S13_RESERVED_MASK) >> CCIPHER_B_S13_RESERVED_SHIFT)

#define CCIPHER_B_S13_SET_RESERVED(ccipher_b_s13_reg, reserved) \
      ccipher_b_s13_reg = (ccipher_b_s13_reg & ~CCIPHER_B_S13_RESERVED_MASK) | (reserved << CCIPHER_B_S13_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s13_t {
            unsigned int reserved                       : CCIPHER_B_S13_RESERVED_SIZE;
      } ccipher_b_s13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s13_t {
            unsigned int reserved                       : CCIPHER_B_S13_RESERVED_SIZE;
      } ccipher_b_s13_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s13_t f;
} ccipher_b_s13_u;


/*
 * CCIPHER_B_S14 struct
 */

#define CCIPHER_B_S14_REG_SIZE         32
#define CCIPHER_B_S14_RESERVED_SIZE  32

#define CCIPHER_B_S14_RESERVED_SHIFT  0

#define CCIPHER_B_S14_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S14_MASK \
      (CCIPHER_B_S14_RESERVED_MASK)

#define CCIPHER_B_S14_DEFAULT          0x00000000

#define CCIPHER_B_S14_GET_RESERVED(ccipher_b_s14) \
      ((ccipher_b_s14 & CCIPHER_B_S14_RESERVED_MASK) >> CCIPHER_B_S14_RESERVED_SHIFT)

#define CCIPHER_B_S14_SET_RESERVED(ccipher_b_s14_reg, reserved) \
      ccipher_b_s14_reg = (ccipher_b_s14_reg & ~CCIPHER_B_S14_RESERVED_MASK) | (reserved << CCIPHER_B_S14_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s14_t {
            unsigned int reserved                       : CCIPHER_B_S14_RESERVED_SIZE;
      } ccipher_b_s14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s14_t {
            unsigned int reserved                       : CCIPHER_B_S14_RESERVED_SIZE;
      } ccipher_b_s14_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s14_t f;
} ccipher_b_s14_u;


/*
 * CCIPHER_B_S15 struct
 */

#define CCIPHER_B_S15_REG_SIZE         32
#define CCIPHER_B_S15_RESERVED_SIZE  32

#define CCIPHER_B_S15_RESERVED_SHIFT  0

#define CCIPHER_B_S15_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S15_MASK \
      (CCIPHER_B_S15_RESERVED_MASK)

#define CCIPHER_B_S15_DEFAULT          0x00000000

#define CCIPHER_B_S15_GET_RESERVED(ccipher_b_s15) \
      ((ccipher_b_s15 & CCIPHER_B_S15_RESERVED_MASK) >> CCIPHER_B_S15_RESERVED_SHIFT)

#define CCIPHER_B_S15_SET_RESERVED(ccipher_b_s15_reg, reserved) \
      ccipher_b_s15_reg = (ccipher_b_s15_reg & ~CCIPHER_B_S15_RESERVED_MASK) | (reserved << CCIPHER_B_S15_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s15_t {
            unsigned int reserved                       : CCIPHER_B_S15_RESERVED_SIZE;
      } ccipher_b_s15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s15_t {
            unsigned int reserved                       : CCIPHER_B_S15_RESERVED_SIZE;
      } ccipher_b_s15_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s15_t f;
} ccipher_b_s15_u;


/*
 * CCIPHER_B_S16 struct
 */

#define CCIPHER_B_S16_REG_SIZE         32
#define CCIPHER_B_S16_RESERVED_SIZE  32

#define CCIPHER_B_S16_RESERVED_SHIFT  0

#define CCIPHER_B_S16_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S16_MASK \
      (CCIPHER_B_S16_RESERVED_MASK)

#define CCIPHER_B_S16_DEFAULT          0x00000000

#define CCIPHER_B_S16_GET_RESERVED(ccipher_b_s16) \
      ((ccipher_b_s16 & CCIPHER_B_S16_RESERVED_MASK) >> CCIPHER_B_S16_RESERVED_SHIFT)

#define CCIPHER_B_S16_SET_RESERVED(ccipher_b_s16_reg, reserved) \
      ccipher_b_s16_reg = (ccipher_b_s16_reg & ~CCIPHER_B_S16_RESERVED_MASK) | (reserved << CCIPHER_B_S16_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s16_t {
            unsigned int reserved                       : CCIPHER_B_S16_RESERVED_SIZE;
      } ccipher_b_s16_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s16_t {
            unsigned int reserved                       : CCIPHER_B_S16_RESERVED_SIZE;
      } ccipher_b_s16_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s16_t f;
} ccipher_b_s16_u;


/*
 * CCIPHER_B_S17 struct
 */

#define CCIPHER_B_S17_REG_SIZE         32
#define CCIPHER_B_S17_RESERVED_SIZE  32

#define CCIPHER_B_S17_RESERVED_SHIFT  0

#define CCIPHER_B_S17_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S17_MASK \
      (CCIPHER_B_S17_RESERVED_MASK)

#define CCIPHER_B_S17_DEFAULT          0x00000000

#define CCIPHER_B_S17_GET_RESERVED(ccipher_b_s17) \
      ((ccipher_b_s17 & CCIPHER_B_S17_RESERVED_MASK) >> CCIPHER_B_S17_RESERVED_SHIFT)

#define CCIPHER_B_S17_SET_RESERVED(ccipher_b_s17_reg, reserved) \
      ccipher_b_s17_reg = (ccipher_b_s17_reg & ~CCIPHER_B_S17_RESERVED_MASK) | (reserved << CCIPHER_B_S17_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s17_t {
            unsigned int reserved                       : CCIPHER_B_S17_RESERVED_SIZE;
      } ccipher_b_s17_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s17_t {
            unsigned int reserved                       : CCIPHER_B_S17_RESERVED_SIZE;
      } ccipher_b_s17_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s17_t f;
} ccipher_b_s17_u;


/*
 * CCIPHER_B_S18 struct
 */

#define CCIPHER_B_S18_REG_SIZE         32
#define CCIPHER_B_S18_RESERVED_SIZE  32

#define CCIPHER_B_S18_RESERVED_SHIFT  0

#define CCIPHER_B_S18_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S18_MASK \
      (CCIPHER_B_S18_RESERVED_MASK)

#define CCIPHER_B_S18_DEFAULT          0x00000000

#define CCIPHER_B_S18_GET_RESERVED(ccipher_b_s18) \
      ((ccipher_b_s18 & CCIPHER_B_S18_RESERVED_MASK) >> CCIPHER_B_S18_RESERVED_SHIFT)

#define CCIPHER_B_S18_SET_RESERVED(ccipher_b_s18_reg, reserved) \
      ccipher_b_s18_reg = (ccipher_b_s18_reg & ~CCIPHER_B_S18_RESERVED_MASK) | (reserved << CCIPHER_B_S18_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s18_t {
            unsigned int reserved                       : CCIPHER_B_S18_RESERVED_SIZE;
      } ccipher_b_s18_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s18_t {
            unsigned int reserved                       : CCIPHER_B_S18_RESERVED_SIZE;
      } ccipher_b_s18_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s18_t f;
} ccipher_b_s18_u;


/*
 * CCIPHER_B_S19 struct
 */

#define CCIPHER_B_S19_REG_SIZE         32
#define CCIPHER_B_S19_RESERVED_SIZE  32

#define CCIPHER_B_S19_RESERVED_SHIFT  0

#define CCIPHER_B_S19_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S19_MASK \
      (CCIPHER_B_S19_RESERVED_MASK)

#define CCIPHER_B_S19_DEFAULT          0x00000000

#define CCIPHER_B_S19_GET_RESERVED(ccipher_b_s19) \
      ((ccipher_b_s19 & CCIPHER_B_S19_RESERVED_MASK) >> CCIPHER_B_S19_RESERVED_SHIFT)

#define CCIPHER_B_S19_SET_RESERVED(ccipher_b_s19_reg, reserved) \
      ccipher_b_s19_reg = (ccipher_b_s19_reg & ~CCIPHER_B_S19_RESERVED_MASK) | (reserved << CCIPHER_B_S19_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s19_t {
            unsigned int reserved                       : CCIPHER_B_S19_RESERVED_SIZE;
      } ccipher_b_s19_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s19_t {
            unsigned int reserved                       : CCIPHER_B_S19_RESERVED_SIZE;
      } ccipher_b_s19_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s19_t f;
} ccipher_b_s19_u;


/*
 * CCIPHER_B_S20 struct
 */

#define CCIPHER_B_S20_REG_SIZE         32
#define CCIPHER_B_S20_RESERVED_SIZE  32

#define CCIPHER_B_S20_RESERVED_SHIFT  0

#define CCIPHER_B_S20_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S20_MASK \
      (CCIPHER_B_S20_RESERVED_MASK)

#define CCIPHER_B_S20_DEFAULT          0x00000000

#define CCIPHER_B_S20_GET_RESERVED(ccipher_b_s20) \
      ((ccipher_b_s20 & CCIPHER_B_S20_RESERVED_MASK) >> CCIPHER_B_S20_RESERVED_SHIFT)

#define CCIPHER_B_S20_SET_RESERVED(ccipher_b_s20_reg, reserved) \
      ccipher_b_s20_reg = (ccipher_b_s20_reg & ~CCIPHER_B_S20_RESERVED_MASK) | (reserved << CCIPHER_B_S20_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s20_t {
            unsigned int reserved                       : CCIPHER_B_S20_RESERVED_SIZE;
      } ccipher_b_s20_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s20_t {
            unsigned int reserved                       : CCIPHER_B_S20_RESERVED_SIZE;
      } ccipher_b_s20_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s20_t f;
} ccipher_b_s20_u;


/*
 * CCIPHER_B_S21 struct
 */

#define CCIPHER_B_S21_REG_SIZE         32
#define CCIPHER_B_S21_RESERVED_SIZE  32

#define CCIPHER_B_S21_RESERVED_SHIFT  0

#define CCIPHER_B_S21_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S21_MASK \
      (CCIPHER_B_S21_RESERVED_MASK)

#define CCIPHER_B_S21_DEFAULT          0x00000000

#define CCIPHER_B_S21_GET_RESERVED(ccipher_b_s21) \
      ((ccipher_b_s21 & CCIPHER_B_S21_RESERVED_MASK) >> CCIPHER_B_S21_RESERVED_SHIFT)

#define CCIPHER_B_S21_SET_RESERVED(ccipher_b_s21_reg, reserved) \
      ccipher_b_s21_reg = (ccipher_b_s21_reg & ~CCIPHER_B_S21_RESERVED_MASK) | (reserved << CCIPHER_B_S21_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s21_t {
            unsigned int reserved                       : CCIPHER_B_S21_RESERVED_SIZE;
      } ccipher_b_s21_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s21_t {
            unsigned int reserved                       : CCIPHER_B_S21_RESERVED_SIZE;
      } ccipher_b_s21_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s21_t f;
} ccipher_b_s21_u;


/*
 * CCIPHER_B_S22 struct
 */

#define CCIPHER_B_S22_REG_SIZE         32
#define CCIPHER_B_S22_RESERVED_SIZE  32

#define CCIPHER_B_S22_RESERVED_SHIFT  0

#define CCIPHER_B_S22_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S22_MASK \
      (CCIPHER_B_S22_RESERVED_MASK)

#define CCIPHER_B_S22_DEFAULT          0x00000000

#define CCIPHER_B_S22_GET_RESERVED(ccipher_b_s22) \
      ((ccipher_b_s22 & CCIPHER_B_S22_RESERVED_MASK) >> CCIPHER_B_S22_RESERVED_SHIFT)

#define CCIPHER_B_S22_SET_RESERVED(ccipher_b_s22_reg, reserved) \
      ccipher_b_s22_reg = (ccipher_b_s22_reg & ~CCIPHER_B_S22_RESERVED_MASK) | (reserved << CCIPHER_B_S22_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s22_t {
            unsigned int reserved                       : CCIPHER_B_S22_RESERVED_SIZE;
      } ccipher_b_s22_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s22_t {
            unsigned int reserved                       : CCIPHER_B_S22_RESERVED_SIZE;
      } ccipher_b_s22_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s22_t f;
} ccipher_b_s22_u;


/*
 * CCIPHER_B_S23 struct
 */

#define CCIPHER_B_S23_REG_SIZE         32
#define CCIPHER_B_S23_RESERVED_SIZE  32

#define CCIPHER_B_S23_RESERVED_SHIFT  0

#define CCIPHER_B_S23_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S23_MASK \
      (CCIPHER_B_S23_RESERVED_MASK)

#define CCIPHER_B_S23_DEFAULT          0x00000000

#define CCIPHER_B_S23_GET_RESERVED(ccipher_b_s23) \
      ((ccipher_b_s23 & CCIPHER_B_S23_RESERVED_MASK) >> CCIPHER_B_S23_RESERVED_SHIFT)

#define CCIPHER_B_S23_SET_RESERVED(ccipher_b_s23_reg, reserved) \
      ccipher_b_s23_reg = (ccipher_b_s23_reg & ~CCIPHER_B_S23_RESERVED_MASK) | (reserved << CCIPHER_B_S23_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s23_t {
            unsigned int reserved                       : CCIPHER_B_S23_RESERVED_SIZE;
      } ccipher_b_s23_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s23_t {
            unsigned int reserved                       : CCIPHER_B_S23_RESERVED_SIZE;
      } ccipher_b_s23_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s23_t f;
} ccipher_b_s23_u;


/*
 * CCIPHER_B_S24 struct
 */

#define CCIPHER_B_S24_REG_SIZE         32
#define CCIPHER_B_S24_RESERVED_SIZE  32

#define CCIPHER_B_S24_RESERVED_SHIFT  0

#define CCIPHER_B_S24_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S24_MASK \
      (CCIPHER_B_S24_RESERVED_MASK)

#define CCIPHER_B_S24_DEFAULT          0x00000000

#define CCIPHER_B_S24_GET_RESERVED(ccipher_b_s24) \
      ((ccipher_b_s24 & CCIPHER_B_S24_RESERVED_MASK) >> CCIPHER_B_S24_RESERVED_SHIFT)

#define CCIPHER_B_S24_SET_RESERVED(ccipher_b_s24_reg, reserved) \
      ccipher_b_s24_reg = (ccipher_b_s24_reg & ~CCIPHER_B_S24_RESERVED_MASK) | (reserved << CCIPHER_B_S24_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s24_t {
            unsigned int reserved                       : CCIPHER_B_S24_RESERVED_SIZE;
      } ccipher_b_s24_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s24_t {
            unsigned int reserved                       : CCIPHER_B_S24_RESERVED_SIZE;
      } ccipher_b_s24_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s24_t f;
} ccipher_b_s24_u;


/*
 * CCIPHER_B_S25 struct
 */

#define CCIPHER_B_S25_REG_SIZE         32
#define CCIPHER_B_S25_RESERVED_SIZE  32

#define CCIPHER_B_S25_RESERVED_SHIFT  0

#define CCIPHER_B_S25_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S25_MASK \
      (CCIPHER_B_S25_RESERVED_MASK)

#define CCIPHER_B_S25_DEFAULT          0x00000000

#define CCIPHER_B_S25_GET_RESERVED(ccipher_b_s25) \
      ((ccipher_b_s25 & CCIPHER_B_S25_RESERVED_MASK) >> CCIPHER_B_S25_RESERVED_SHIFT)

#define CCIPHER_B_S25_SET_RESERVED(ccipher_b_s25_reg, reserved) \
      ccipher_b_s25_reg = (ccipher_b_s25_reg & ~CCIPHER_B_S25_RESERVED_MASK) | (reserved << CCIPHER_B_S25_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s25_t {
            unsigned int reserved                       : CCIPHER_B_S25_RESERVED_SIZE;
      } ccipher_b_s25_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s25_t {
            unsigned int reserved                       : CCIPHER_B_S25_RESERVED_SIZE;
      } ccipher_b_s25_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s25_t f;
} ccipher_b_s25_u;


/*
 * CCIPHER_B_S26 struct
 */

#define CCIPHER_B_S26_REG_SIZE         32
#define CCIPHER_B_S26_RESERVED_SIZE  32

#define CCIPHER_B_S26_RESERVED_SHIFT  0

#define CCIPHER_B_S26_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S26_MASK \
      (CCIPHER_B_S26_RESERVED_MASK)

#define CCIPHER_B_S26_DEFAULT          0x00000000

#define CCIPHER_B_S26_GET_RESERVED(ccipher_b_s26) \
      ((ccipher_b_s26 & CCIPHER_B_S26_RESERVED_MASK) >> CCIPHER_B_S26_RESERVED_SHIFT)

#define CCIPHER_B_S26_SET_RESERVED(ccipher_b_s26_reg, reserved) \
      ccipher_b_s26_reg = (ccipher_b_s26_reg & ~CCIPHER_B_S26_RESERVED_MASK) | (reserved << CCIPHER_B_S26_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s26_t {
            unsigned int reserved                       : CCIPHER_B_S26_RESERVED_SIZE;
      } ccipher_b_s26_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s26_t {
            unsigned int reserved                       : CCIPHER_B_S26_RESERVED_SIZE;
      } ccipher_b_s26_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s26_t f;
} ccipher_b_s26_u;


/*
 * CCIPHER_B_S27 struct
 */

#define CCIPHER_B_S27_REG_SIZE         32
#define CCIPHER_B_S27_RESERVED_SIZE  32

#define CCIPHER_B_S27_RESERVED_SHIFT  0

#define CCIPHER_B_S27_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S27_MASK \
      (CCIPHER_B_S27_RESERVED_MASK)

#define CCIPHER_B_S27_DEFAULT          0x00000000

#define CCIPHER_B_S27_GET_RESERVED(ccipher_b_s27) \
      ((ccipher_b_s27 & CCIPHER_B_S27_RESERVED_MASK) >> CCIPHER_B_S27_RESERVED_SHIFT)

#define CCIPHER_B_S27_SET_RESERVED(ccipher_b_s27_reg, reserved) \
      ccipher_b_s27_reg = (ccipher_b_s27_reg & ~CCIPHER_B_S27_RESERVED_MASK) | (reserved << CCIPHER_B_S27_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s27_t {
            unsigned int reserved                       : CCIPHER_B_S27_RESERVED_SIZE;
      } ccipher_b_s27_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s27_t {
            unsigned int reserved                       : CCIPHER_B_S27_RESERVED_SIZE;
      } ccipher_b_s27_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s27_t f;
} ccipher_b_s27_u;


/*
 * CCIPHER_B_S28 struct
 */

#define CCIPHER_B_S28_REG_SIZE         32
#define CCIPHER_B_S28_RESERVED_SIZE  32

#define CCIPHER_B_S28_RESERVED_SHIFT  0

#define CCIPHER_B_S28_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S28_MASK \
      (CCIPHER_B_S28_RESERVED_MASK)

#define CCIPHER_B_S28_DEFAULT          0x00000000

#define CCIPHER_B_S28_GET_RESERVED(ccipher_b_s28) \
      ((ccipher_b_s28 & CCIPHER_B_S28_RESERVED_MASK) >> CCIPHER_B_S28_RESERVED_SHIFT)

#define CCIPHER_B_S28_SET_RESERVED(ccipher_b_s28_reg, reserved) \
      ccipher_b_s28_reg = (ccipher_b_s28_reg & ~CCIPHER_B_S28_RESERVED_MASK) | (reserved << CCIPHER_B_S28_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s28_t {
            unsigned int reserved                       : CCIPHER_B_S28_RESERVED_SIZE;
      } ccipher_b_s28_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s28_t {
            unsigned int reserved                       : CCIPHER_B_S28_RESERVED_SIZE;
      } ccipher_b_s28_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s28_t f;
} ccipher_b_s28_u;


/*
 * CCIPHER_B_S29 struct
 */

#define CCIPHER_B_S29_REG_SIZE         32
#define CCIPHER_B_S29_RESERVED_SIZE  32

#define CCIPHER_B_S29_RESERVED_SHIFT  0

#define CCIPHER_B_S29_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S29_MASK \
      (CCIPHER_B_S29_RESERVED_MASK)

#define CCIPHER_B_S29_DEFAULT          0x00000000

#define CCIPHER_B_S29_GET_RESERVED(ccipher_b_s29) \
      ((ccipher_b_s29 & CCIPHER_B_S29_RESERVED_MASK) >> CCIPHER_B_S29_RESERVED_SHIFT)

#define CCIPHER_B_S29_SET_RESERVED(ccipher_b_s29_reg, reserved) \
      ccipher_b_s29_reg = (ccipher_b_s29_reg & ~CCIPHER_B_S29_RESERVED_MASK) | (reserved << CCIPHER_B_S29_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s29_t {
            unsigned int reserved                       : CCIPHER_B_S29_RESERVED_SIZE;
      } ccipher_b_s29_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s29_t {
            unsigned int reserved                       : CCIPHER_B_S29_RESERVED_SIZE;
      } ccipher_b_s29_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s29_t f;
} ccipher_b_s29_u;


/*
 * CCIPHER_B_S30 struct
 */

#define CCIPHER_B_S30_REG_SIZE         32
#define CCIPHER_B_S30_RESERVED_SIZE  32

#define CCIPHER_B_S30_RESERVED_SHIFT  0

#define CCIPHER_B_S30_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S30_MASK \
      (CCIPHER_B_S30_RESERVED_MASK)

#define CCIPHER_B_S30_DEFAULT          0x00000000

#define CCIPHER_B_S30_GET_RESERVED(ccipher_b_s30) \
      ((ccipher_b_s30 & CCIPHER_B_S30_RESERVED_MASK) >> CCIPHER_B_S30_RESERVED_SHIFT)

#define CCIPHER_B_S30_SET_RESERVED(ccipher_b_s30_reg, reserved) \
      ccipher_b_s30_reg = (ccipher_b_s30_reg & ~CCIPHER_B_S30_RESERVED_MASK) | (reserved << CCIPHER_B_S30_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s30_t {
            unsigned int reserved                       : CCIPHER_B_S30_RESERVED_SIZE;
      } ccipher_b_s30_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s30_t {
            unsigned int reserved                       : CCIPHER_B_S30_RESERVED_SIZE;
      } ccipher_b_s30_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s30_t f;
} ccipher_b_s30_u;


/*
 * CCIPHER_B_S31 struct
 */

#define CCIPHER_B_S31_REG_SIZE         32
#define CCIPHER_B_S31_RESERVED_SIZE  32

#define CCIPHER_B_S31_RESERVED_SHIFT  0

#define CCIPHER_B_S31_RESERVED_MASK     0xffffffff

#define CCIPHER_B_S31_MASK \
      (CCIPHER_B_S31_RESERVED_MASK)

#define CCIPHER_B_S31_DEFAULT          0x00000000

#define CCIPHER_B_S31_GET_RESERVED(ccipher_b_s31) \
      ((ccipher_b_s31 & CCIPHER_B_S31_RESERVED_MASK) >> CCIPHER_B_S31_RESERVED_SHIFT)

#define CCIPHER_B_S31_SET_RESERVED(ccipher_b_s31_reg, reserved) \
      ccipher_b_s31_reg = (ccipher_b_s31_reg & ~CCIPHER_B_S31_RESERVED_MASK) | (reserved << CCIPHER_B_S31_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ccipher_b_s31_t {
            unsigned int reserved                       : CCIPHER_B_S31_RESERVED_SIZE;
      } ccipher_b_s31_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ccipher_b_s31_t {
            unsigned int reserved                       : CCIPHER_B_S31_RESERVED_SIZE;
      } ccipher_b_s31_t;

#endif

typedef union {
     unsigned int val : 32;
          ccipher_b_s31_t f;
} ccipher_b_s31_u;


/*
 * CLIENT2_K0 struct
 */

#define CLIENT2_K0_REG_SIZE         32
#define CLIENT2_K0_RESERVED_SIZE  32

#define CLIENT2_K0_RESERVED_SHIFT  0

#define CLIENT2_K0_RESERVED_MASK        0xffffffff

#define CLIENT2_K0_MASK \
      (CLIENT2_K0_RESERVED_MASK)

#define CLIENT2_K0_DEFAULT             0x00000000

#define CLIENT2_K0_GET_RESERVED(client2_k0) \
      ((client2_k0 & CLIENT2_K0_RESERVED_MASK) >> CLIENT2_K0_RESERVED_SHIFT)

#define CLIENT2_K0_SET_RESERVED(client2_k0_reg, reserved) \
      client2_k0_reg = (client2_k0_reg & ~CLIENT2_K0_RESERVED_MASK) | (reserved << CLIENT2_K0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client2_k0_t {
            unsigned int reserved                       : CLIENT2_K0_RESERVED_SIZE;
      } client2_k0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client2_k0_t {
            unsigned int reserved                       : CLIENT2_K0_RESERVED_SIZE;
      } client2_k0_t;

#endif

typedef union {
     unsigned int val : 32;
          client2_k0_t f;
} client2_k0_u;


/*
 * CLIENT2_K1 struct
 */

#define CLIENT2_K1_REG_SIZE         32
#define CLIENT2_K1_RESERVED_SIZE  32

#define CLIENT2_K1_RESERVED_SHIFT  0

#define CLIENT2_K1_RESERVED_MASK        0xffffffff

#define CLIENT2_K1_MASK \
      (CLIENT2_K1_RESERVED_MASK)

#define CLIENT2_K1_DEFAULT             0x00000000

#define CLIENT2_K1_GET_RESERVED(client2_k1) \
      ((client2_k1 & CLIENT2_K1_RESERVED_MASK) >> CLIENT2_K1_RESERVED_SHIFT)

#define CLIENT2_K1_SET_RESERVED(client2_k1_reg, reserved) \
      client2_k1_reg = (client2_k1_reg & ~CLIENT2_K1_RESERVED_MASK) | (reserved << CLIENT2_K1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client2_k1_t {
            unsigned int reserved                       : CLIENT2_K1_RESERVED_SIZE;
      } client2_k1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client2_k1_t {
            unsigned int reserved                       : CLIENT2_K1_RESERVED_SIZE;
      } client2_k1_t;

#endif

typedef union {
     unsigned int val : 32;
          client2_k1_t f;
} client2_k1_u;


/*
 * CLIENT2_K2 struct
 */

#define CLIENT2_K2_REG_SIZE         32
#define CLIENT2_K2_RESERVED_SIZE  32

#define CLIENT2_K2_RESERVED_SHIFT  0

#define CLIENT2_K2_RESERVED_MASK        0xffffffff

#define CLIENT2_K2_MASK \
      (CLIENT2_K2_RESERVED_MASK)

#define CLIENT2_K2_DEFAULT             0x00000000

#define CLIENT2_K2_GET_RESERVED(client2_k2) \
      ((client2_k2 & CLIENT2_K2_RESERVED_MASK) >> CLIENT2_K2_RESERVED_SHIFT)

#define CLIENT2_K2_SET_RESERVED(client2_k2_reg, reserved) \
      client2_k2_reg = (client2_k2_reg & ~CLIENT2_K2_RESERVED_MASK) | (reserved << CLIENT2_K2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client2_k2_t {
            unsigned int reserved                       : CLIENT2_K2_RESERVED_SIZE;
      } client2_k2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client2_k2_t {
            unsigned int reserved                       : CLIENT2_K2_RESERVED_SIZE;
      } client2_k2_t;

#endif

typedef union {
     unsigned int val : 32;
          client2_k2_t f;
} client2_k2_u;


/*
 * CLIENT2_K3 struct
 */

#define CLIENT2_K3_REG_SIZE         32
#define CLIENT2_K3_RESERVED_SIZE  32

#define CLIENT2_K3_RESERVED_SHIFT  0

#define CLIENT2_K3_RESERVED_MASK        0xffffffff

#define CLIENT2_K3_MASK \
      (CLIENT2_K3_RESERVED_MASK)

#define CLIENT2_K3_DEFAULT             0x00000000

#define CLIENT2_K3_GET_RESERVED(client2_k3) \
      ((client2_k3 & CLIENT2_K3_RESERVED_MASK) >> CLIENT2_K3_RESERVED_SHIFT)

#define CLIENT2_K3_SET_RESERVED(client2_k3_reg, reserved) \
      client2_k3_reg = (client2_k3_reg & ~CLIENT2_K3_RESERVED_MASK) | (reserved << CLIENT2_K3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client2_k3_t {
            unsigned int reserved                       : CLIENT2_K3_RESERVED_SIZE;
      } client2_k3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client2_k3_t {
            unsigned int reserved                       : CLIENT2_K3_RESERVED_SIZE;
      } client2_k3_t;

#endif

typedef union {
     unsigned int val : 32;
          client2_k3_t f;
} client2_k3_u;


/*
 * CLIENT2_CK0 struct
 */

#define CLIENT2_CK0_REG_SIZE         32
#define CLIENT2_CK0_RESERVED_SIZE  32

#define CLIENT2_CK0_RESERVED_SHIFT  0

#define CLIENT2_CK0_RESERVED_MASK       0xffffffff

#define CLIENT2_CK0_MASK \
      (CLIENT2_CK0_RESERVED_MASK)

#define CLIENT2_CK0_DEFAULT            0x00000000

#define CLIENT2_CK0_GET_RESERVED(client2_ck0) \
      ((client2_ck0 & CLIENT2_CK0_RESERVED_MASK) >> CLIENT2_CK0_RESERVED_SHIFT)

#define CLIENT2_CK0_SET_RESERVED(client2_ck0_reg, reserved) \
      client2_ck0_reg = (client2_ck0_reg & ~CLIENT2_CK0_RESERVED_MASK) | (reserved << CLIENT2_CK0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client2_ck0_t {
            unsigned int reserved                       : CLIENT2_CK0_RESERVED_SIZE;
      } client2_ck0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client2_ck0_t {
            unsigned int reserved                       : CLIENT2_CK0_RESERVED_SIZE;
      } client2_ck0_t;

#endif

typedef union {
     unsigned int val : 32;
          client2_ck0_t f;
} client2_ck0_u;


/*
 * CLIENT2_CK1 struct
 */

#define CLIENT2_CK1_REG_SIZE         32
#define CLIENT2_CK1_RESERVED_SIZE  32

#define CLIENT2_CK1_RESERVED_SHIFT  0

#define CLIENT2_CK1_RESERVED_MASK       0xffffffff

#define CLIENT2_CK1_MASK \
      (CLIENT2_CK1_RESERVED_MASK)

#define CLIENT2_CK1_DEFAULT            0x00000000

#define CLIENT2_CK1_GET_RESERVED(client2_ck1) \
      ((client2_ck1 & CLIENT2_CK1_RESERVED_MASK) >> CLIENT2_CK1_RESERVED_SHIFT)

#define CLIENT2_CK1_SET_RESERVED(client2_ck1_reg, reserved) \
      client2_ck1_reg = (client2_ck1_reg & ~CLIENT2_CK1_RESERVED_MASK) | (reserved << CLIENT2_CK1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client2_ck1_t {
            unsigned int reserved                       : CLIENT2_CK1_RESERVED_SIZE;
      } client2_ck1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client2_ck1_t {
            unsigned int reserved                       : CLIENT2_CK1_RESERVED_SIZE;
      } client2_ck1_t;

#endif

typedef union {
     unsigned int val : 32;
          client2_ck1_t f;
} client2_ck1_u;


/*
 * CLIENT2_CK2 struct
 */

#define CLIENT2_CK2_REG_SIZE         32
#define CLIENT2_CK2_RESERVED_SIZE  32

#define CLIENT2_CK2_RESERVED_SHIFT  0

#define CLIENT2_CK2_RESERVED_MASK       0xffffffff

#define CLIENT2_CK2_MASK \
      (CLIENT2_CK2_RESERVED_MASK)

#define CLIENT2_CK2_DEFAULT            0x00000000

#define CLIENT2_CK2_GET_RESERVED(client2_ck2) \
      ((client2_ck2 & CLIENT2_CK2_RESERVED_MASK) >> CLIENT2_CK2_RESERVED_SHIFT)

#define CLIENT2_CK2_SET_RESERVED(client2_ck2_reg, reserved) \
      client2_ck2_reg = (client2_ck2_reg & ~CLIENT2_CK2_RESERVED_MASK) | (reserved << CLIENT2_CK2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client2_ck2_t {
            unsigned int reserved                       : CLIENT2_CK2_RESERVED_SIZE;
      } client2_ck2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client2_ck2_t {
            unsigned int reserved                       : CLIENT2_CK2_RESERVED_SIZE;
      } client2_ck2_t;

#endif

typedef union {
     unsigned int val : 32;
          client2_ck2_t f;
} client2_ck2_u;


/*
 * CLIENT2_CK3 struct
 */

#define CLIENT2_CK3_REG_SIZE         32
#define CLIENT2_CK3_RESERVED_SIZE  32

#define CLIENT2_CK3_RESERVED_SHIFT  0

#define CLIENT2_CK3_RESERVED_MASK       0xffffffff

#define CLIENT2_CK3_MASK \
      (CLIENT2_CK3_RESERVED_MASK)

#define CLIENT2_CK3_DEFAULT            0x00000000

#define CLIENT2_CK3_GET_RESERVED(client2_ck3) \
      ((client2_ck3 & CLIENT2_CK3_RESERVED_MASK) >> CLIENT2_CK3_RESERVED_SHIFT)

#define CLIENT2_CK3_SET_RESERVED(client2_ck3_reg, reserved) \
      client2_ck3_reg = (client2_ck3_reg & ~CLIENT2_CK3_RESERVED_MASK) | (reserved << CLIENT2_CK3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client2_ck3_t {
            unsigned int reserved                       : CLIENT2_CK3_RESERVED_SIZE;
      } client2_ck3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client2_ck3_t {
            unsigned int reserved                       : CLIENT2_CK3_RESERVED_SIZE;
      } client2_ck3_t;

#endif

typedef union {
     unsigned int val : 32;
          client2_ck3_t f;
} client2_ck3_u;


/*
 * CLIENT2_CD0 struct
 */

#define CLIENT2_CD0_REG_SIZE         32
#define CLIENT2_CD0_RESERVED_SIZE  32

#define CLIENT2_CD0_RESERVED_SHIFT  0

#define CLIENT2_CD0_RESERVED_MASK       0xffffffff

#define CLIENT2_CD0_MASK \
      (CLIENT2_CD0_RESERVED_MASK)

#define CLIENT2_CD0_DEFAULT            0x00000000

#define CLIENT2_CD0_GET_RESERVED(client2_cd0) \
      ((client2_cd0 & CLIENT2_CD0_RESERVED_MASK) >> CLIENT2_CD0_RESERVED_SHIFT)

#define CLIENT2_CD0_SET_RESERVED(client2_cd0_reg, reserved) \
      client2_cd0_reg = (client2_cd0_reg & ~CLIENT2_CD0_RESERVED_MASK) | (reserved << CLIENT2_CD0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client2_cd0_t {
            unsigned int reserved                       : CLIENT2_CD0_RESERVED_SIZE;
      } client2_cd0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client2_cd0_t {
            unsigned int reserved                       : CLIENT2_CD0_RESERVED_SIZE;
      } client2_cd0_t;

#endif

typedef union {
     unsigned int val : 32;
          client2_cd0_t f;
} client2_cd0_u;


/*
 * CLIENT2_CD1 struct
 */

#define CLIENT2_CD1_REG_SIZE         32
#define CLIENT2_CD1_RESERVED_SIZE  32

#define CLIENT2_CD1_RESERVED_SHIFT  0

#define CLIENT2_CD1_RESERVED_MASK       0xffffffff

#define CLIENT2_CD1_MASK \
      (CLIENT2_CD1_RESERVED_MASK)

#define CLIENT2_CD1_DEFAULT            0x00000000

#define CLIENT2_CD1_GET_RESERVED(client2_cd1) \
      ((client2_cd1 & CLIENT2_CD1_RESERVED_MASK) >> CLIENT2_CD1_RESERVED_SHIFT)

#define CLIENT2_CD1_SET_RESERVED(client2_cd1_reg, reserved) \
      client2_cd1_reg = (client2_cd1_reg & ~CLIENT2_CD1_RESERVED_MASK) | (reserved << CLIENT2_CD1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client2_cd1_t {
            unsigned int reserved                       : CLIENT2_CD1_RESERVED_SIZE;
      } client2_cd1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client2_cd1_t {
            unsigned int reserved                       : CLIENT2_CD1_RESERVED_SIZE;
      } client2_cd1_t;

#endif

typedef union {
     unsigned int val : 32;
          client2_cd1_t f;
} client2_cd1_u;


/*
 * CLIENT2_CD2 struct
 */

#define CLIENT2_CD2_REG_SIZE         32
#define CLIENT2_CD2_RESERVED_SIZE  32

#define CLIENT2_CD2_RESERVED_SHIFT  0

#define CLIENT2_CD2_RESERVED_MASK       0xffffffff

#define CLIENT2_CD2_MASK \
      (CLIENT2_CD2_RESERVED_MASK)

#define CLIENT2_CD2_DEFAULT            0x00000000

#define CLIENT2_CD2_GET_RESERVED(client2_cd2) \
      ((client2_cd2 & CLIENT2_CD2_RESERVED_MASK) >> CLIENT2_CD2_RESERVED_SHIFT)

#define CLIENT2_CD2_SET_RESERVED(client2_cd2_reg, reserved) \
      client2_cd2_reg = (client2_cd2_reg & ~CLIENT2_CD2_RESERVED_MASK) | (reserved << CLIENT2_CD2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client2_cd2_t {
            unsigned int reserved                       : CLIENT2_CD2_RESERVED_SIZE;
      } client2_cd2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client2_cd2_t {
            unsigned int reserved                       : CLIENT2_CD2_RESERVED_SIZE;
      } client2_cd2_t;

#endif

typedef union {
     unsigned int val : 32;
          client2_cd2_t f;
} client2_cd2_u;


/*
 * CLIENT2_CD3 struct
 */

#define CLIENT2_CD3_REG_SIZE         32
#define CLIENT2_CD3_RESERVED_SIZE  32

#define CLIENT2_CD3_RESERVED_SHIFT  0

#define CLIENT2_CD3_RESERVED_MASK       0xffffffff

#define CLIENT2_CD3_MASK \
      (CLIENT2_CD3_RESERVED_MASK)

#define CLIENT2_CD3_DEFAULT            0x00000000

#define CLIENT2_CD3_GET_RESERVED(client2_cd3) \
      ((client2_cd3 & CLIENT2_CD3_RESERVED_MASK) >> CLIENT2_CD3_RESERVED_SHIFT)

#define CLIENT2_CD3_SET_RESERVED(client2_cd3_reg, reserved) \
      client2_cd3_reg = (client2_cd3_reg & ~CLIENT2_CD3_RESERVED_MASK) | (reserved << CLIENT2_CD3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client2_cd3_t {
            unsigned int reserved                       : CLIENT2_CD3_RESERVED_SIZE;
      } client2_cd3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client2_cd3_t {
            unsigned int reserved                       : CLIENT2_CD3_RESERVED_SIZE;
      } client2_cd3_t;

#endif

typedef union {
     unsigned int val : 32;
          client2_cd3_t f;
} client2_cd3_u;


/*
 * CLIENT2_BM struct
 */

#define CLIENT2_BM_REG_SIZE         32
#define CLIENT2_BM_RESERVED_SIZE  32

#define CLIENT2_BM_RESERVED_SHIFT  0

#define CLIENT2_BM_RESERVED_MASK        0xffffffff

#define CLIENT2_BM_MASK \
      (CLIENT2_BM_RESERVED_MASK)

#define CLIENT2_BM_DEFAULT             0x00000000

#define CLIENT2_BM_GET_RESERVED(client2_bm) \
      ((client2_bm & CLIENT2_BM_RESERVED_MASK) >> CLIENT2_BM_RESERVED_SHIFT)

#define CLIENT2_BM_SET_RESERVED(client2_bm_reg, reserved) \
      client2_bm_reg = (client2_bm_reg & ~CLIENT2_BM_RESERVED_MASK) | (reserved << CLIENT2_BM_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client2_bm_t {
            unsigned int reserved                       : CLIENT2_BM_RESERVED_SIZE;
      } client2_bm_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client2_bm_t {
            unsigned int reserved                       : CLIENT2_BM_RESERVED_SIZE;
      } client2_bm_t;

#endif

typedef union {
     unsigned int val : 32;
          client2_bm_t f;
} client2_bm_u;


/*
 * CLIENT2_OFFSET struct
 */

#define CLIENT2_OFFSET_REG_SIZE         32
#define CLIENT2_OFFSET_RESERVED_SIZE  32

#define CLIENT2_OFFSET_RESERVED_SHIFT  0

#define CLIENT2_OFFSET_RESERVED_MASK    0xffffffff

#define CLIENT2_OFFSET_MASK \
      (CLIENT2_OFFSET_RESERVED_MASK)

#define CLIENT2_OFFSET_DEFAULT         0x00000000

#define CLIENT2_OFFSET_GET_RESERVED(client2_offset) \
      ((client2_offset & CLIENT2_OFFSET_RESERVED_MASK) >> CLIENT2_OFFSET_RESERVED_SHIFT)

#define CLIENT2_OFFSET_SET_RESERVED(client2_offset_reg, reserved) \
      client2_offset_reg = (client2_offset_reg & ~CLIENT2_OFFSET_RESERVED_MASK) | (reserved << CLIENT2_OFFSET_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client2_offset_t {
            unsigned int reserved                       : CLIENT2_OFFSET_RESERVED_SIZE;
      } client2_offset_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client2_offset_t {
            unsigned int reserved                       : CLIENT2_OFFSET_RESERVED_SIZE;
      } client2_offset_t;

#endif

typedef union {
     unsigned int val : 32;
          client2_offset_t f;
} client2_offset_u;


/*
 * CLIENT2_STATUS struct
 */

#define CLIENT2_STATUS_REG_SIZE         32
#define CLIENT2_STATUS_RESERVED_SIZE  32

#define CLIENT2_STATUS_RESERVED_SHIFT  0

#define CLIENT2_STATUS_RESERVED_MASK    0xffffffff

#define CLIENT2_STATUS_MASK \
      (CLIENT2_STATUS_RESERVED_MASK)

#define CLIENT2_STATUS_DEFAULT         0x00000000

#define CLIENT2_STATUS_GET_RESERVED(client2_status) \
      ((client2_status & CLIENT2_STATUS_RESERVED_MASK) >> CLIENT2_STATUS_RESERVED_SHIFT)

#define CLIENT2_STATUS_SET_RESERVED(client2_status_reg, reserved) \
      client2_status_reg = (client2_status_reg & ~CLIENT2_STATUS_RESERVED_MASK) | (reserved << CLIENT2_STATUS_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client2_status_t {
            unsigned int reserved                       : CLIENT2_STATUS_RESERVED_SIZE;
      } client2_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client2_status_t {
            unsigned int reserved                       : CLIENT2_STATUS_RESERVED_SIZE;
      } client2_status_t;

#endif

typedef union {
     unsigned int val : 32;
          client2_status_t f;
} client2_status_u;


/*
 * CLIENT0_K0 struct
 */

#define CLIENT0_K0_REG_SIZE         32
#define CLIENT0_K0_RESERVED_SIZE  32

#define CLIENT0_K0_RESERVED_SHIFT  0

#define CLIENT0_K0_RESERVED_MASK        0xffffffff

#define CLIENT0_K0_MASK \
      (CLIENT0_K0_RESERVED_MASK)

#define CLIENT0_K0_DEFAULT             0x00000000

#define CLIENT0_K0_GET_RESERVED(client0_k0) \
      ((client0_k0 & CLIENT0_K0_RESERVED_MASK) >> CLIENT0_K0_RESERVED_SHIFT)

#define CLIENT0_K0_SET_RESERVED(client0_k0_reg, reserved) \
      client0_k0_reg = (client0_k0_reg & ~CLIENT0_K0_RESERVED_MASK) | (reserved << CLIENT0_K0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client0_k0_t {
            unsigned int reserved                       : CLIENT0_K0_RESERVED_SIZE;
      } client0_k0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client0_k0_t {
            unsigned int reserved                       : CLIENT0_K0_RESERVED_SIZE;
      } client0_k0_t;

#endif

typedef union {
     unsigned int val : 32;
          client0_k0_t f;
} client0_k0_u;


/*
 * CLIENT0_K1 struct
 */

#define CLIENT0_K1_REG_SIZE         32
#define CLIENT0_K1_RESERVED_SIZE  32

#define CLIENT0_K1_RESERVED_SHIFT  0

#define CLIENT0_K1_RESERVED_MASK        0xffffffff

#define CLIENT0_K1_MASK \
      (CLIENT0_K1_RESERVED_MASK)

#define CLIENT0_K1_DEFAULT             0x00000000

#define CLIENT0_K1_GET_RESERVED(client0_k1) \
      ((client0_k1 & CLIENT0_K1_RESERVED_MASK) >> CLIENT0_K1_RESERVED_SHIFT)

#define CLIENT0_K1_SET_RESERVED(client0_k1_reg, reserved) \
      client0_k1_reg = (client0_k1_reg & ~CLIENT0_K1_RESERVED_MASK) | (reserved << CLIENT0_K1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client0_k1_t {
            unsigned int reserved                       : CLIENT0_K1_RESERVED_SIZE;
      } client0_k1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client0_k1_t {
            unsigned int reserved                       : CLIENT0_K1_RESERVED_SIZE;
      } client0_k1_t;

#endif

typedef union {
     unsigned int val : 32;
          client0_k1_t f;
} client0_k1_u;


/*
 * CLIENT0_K2 struct
 */

#define CLIENT0_K2_REG_SIZE         32
#define CLIENT0_K2_RESERVED_SIZE  32

#define CLIENT0_K2_RESERVED_SHIFT  0

#define CLIENT0_K2_RESERVED_MASK        0xffffffff

#define CLIENT0_K2_MASK \
      (CLIENT0_K2_RESERVED_MASK)

#define CLIENT0_K2_DEFAULT             0x00000000

#define CLIENT0_K2_GET_RESERVED(client0_k2) \
      ((client0_k2 & CLIENT0_K2_RESERVED_MASK) >> CLIENT0_K2_RESERVED_SHIFT)

#define CLIENT0_K2_SET_RESERVED(client0_k2_reg, reserved) \
      client0_k2_reg = (client0_k2_reg & ~CLIENT0_K2_RESERVED_MASK) | (reserved << CLIENT0_K2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client0_k2_t {
            unsigned int reserved                       : CLIENT0_K2_RESERVED_SIZE;
      } client0_k2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client0_k2_t {
            unsigned int reserved                       : CLIENT0_K2_RESERVED_SIZE;
      } client0_k2_t;

#endif

typedef union {
     unsigned int val : 32;
          client0_k2_t f;
} client0_k2_u;


/*
 * CLIENT0_K3 struct
 */

#define CLIENT0_K3_REG_SIZE         32
#define CLIENT0_K3_RESERVED_SIZE  32

#define CLIENT0_K3_RESERVED_SHIFT  0

#define CLIENT0_K3_RESERVED_MASK        0xffffffff

#define CLIENT0_K3_MASK \
      (CLIENT0_K3_RESERVED_MASK)

#define CLIENT0_K3_DEFAULT             0x00000000

#define CLIENT0_K3_GET_RESERVED(client0_k3) \
      ((client0_k3 & CLIENT0_K3_RESERVED_MASK) >> CLIENT0_K3_RESERVED_SHIFT)

#define CLIENT0_K3_SET_RESERVED(client0_k3_reg, reserved) \
      client0_k3_reg = (client0_k3_reg & ~CLIENT0_K3_RESERVED_MASK) | (reserved << CLIENT0_K3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client0_k3_t {
            unsigned int reserved                       : CLIENT0_K3_RESERVED_SIZE;
      } client0_k3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client0_k3_t {
            unsigned int reserved                       : CLIENT0_K3_RESERVED_SIZE;
      } client0_k3_t;

#endif

typedef union {
     unsigned int val : 32;
          client0_k3_t f;
} client0_k3_u;


/*
 * CLIENT0_CK0 struct
 */

#define CLIENT0_CK0_REG_SIZE         32
#define CLIENT0_CK0_RESERVED_SIZE  32

#define CLIENT0_CK0_RESERVED_SHIFT  0

#define CLIENT0_CK0_RESERVED_MASK       0xffffffff

#define CLIENT0_CK0_MASK \
      (CLIENT0_CK0_RESERVED_MASK)

#define CLIENT0_CK0_DEFAULT            0x00000000

#define CLIENT0_CK0_GET_RESERVED(client0_ck0) \
      ((client0_ck0 & CLIENT0_CK0_RESERVED_MASK) >> CLIENT0_CK0_RESERVED_SHIFT)

#define CLIENT0_CK0_SET_RESERVED(client0_ck0_reg, reserved) \
      client0_ck0_reg = (client0_ck0_reg & ~CLIENT0_CK0_RESERVED_MASK) | (reserved << CLIENT0_CK0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client0_ck0_t {
            unsigned int reserved                       : CLIENT0_CK0_RESERVED_SIZE;
      } client0_ck0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client0_ck0_t {
            unsigned int reserved                       : CLIENT0_CK0_RESERVED_SIZE;
      } client0_ck0_t;

#endif

typedef union {
     unsigned int val : 32;
          client0_ck0_t f;
} client0_ck0_u;


/*
 * CLIENT0_CK1 struct
 */

#define CLIENT0_CK1_REG_SIZE         32
#define CLIENT0_CK1_RESERVED_SIZE  32

#define CLIENT0_CK1_RESERVED_SHIFT  0

#define CLIENT0_CK1_RESERVED_MASK       0xffffffff

#define CLIENT0_CK1_MASK \
      (CLIENT0_CK1_RESERVED_MASK)

#define CLIENT0_CK1_DEFAULT            0x00000000

#define CLIENT0_CK1_GET_RESERVED(client0_ck1) \
      ((client0_ck1 & CLIENT0_CK1_RESERVED_MASK) >> CLIENT0_CK1_RESERVED_SHIFT)

#define CLIENT0_CK1_SET_RESERVED(client0_ck1_reg, reserved) \
      client0_ck1_reg = (client0_ck1_reg & ~CLIENT0_CK1_RESERVED_MASK) | (reserved << CLIENT0_CK1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client0_ck1_t {
            unsigned int reserved                       : CLIENT0_CK1_RESERVED_SIZE;
      } client0_ck1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client0_ck1_t {
            unsigned int reserved                       : CLIENT0_CK1_RESERVED_SIZE;
      } client0_ck1_t;

#endif

typedef union {
     unsigned int val : 32;
          client0_ck1_t f;
} client0_ck1_u;


/*
 * CLIENT0_CK2 struct
 */

#define CLIENT0_CK2_REG_SIZE         32
#define CLIENT0_CK2_RESERVED_SIZE  32

#define CLIENT0_CK2_RESERVED_SHIFT  0

#define CLIENT0_CK2_RESERVED_MASK       0xffffffff

#define CLIENT0_CK2_MASK \
      (CLIENT0_CK2_RESERVED_MASK)

#define CLIENT0_CK2_DEFAULT            0x00000000

#define CLIENT0_CK2_GET_RESERVED(client0_ck2) \
      ((client0_ck2 & CLIENT0_CK2_RESERVED_MASK) >> CLIENT0_CK2_RESERVED_SHIFT)

#define CLIENT0_CK2_SET_RESERVED(client0_ck2_reg, reserved) \
      client0_ck2_reg = (client0_ck2_reg & ~CLIENT0_CK2_RESERVED_MASK) | (reserved << CLIENT0_CK2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client0_ck2_t {
            unsigned int reserved                       : CLIENT0_CK2_RESERVED_SIZE;
      } client0_ck2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client0_ck2_t {
            unsigned int reserved                       : CLIENT0_CK2_RESERVED_SIZE;
      } client0_ck2_t;

#endif

typedef union {
     unsigned int val : 32;
          client0_ck2_t f;
} client0_ck2_u;


/*
 * CLIENT0_CK3 struct
 */

#define CLIENT0_CK3_REG_SIZE         32
#define CLIENT0_CK3_RESERVED_SIZE  32

#define CLIENT0_CK3_RESERVED_SHIFT  0

#define CLIENT0_CK3_RESERVED_MASK       0xffffffff

#define CLIENT0_CK3_MASK \
      (CLIENT0_CK3_RESERVED_MASK)

#define CLIENT0_CK3_DEFAULT            0x00000000

#define CLIENT0_CK3_GET_RESERVED(client0_ck3) \
      ((client0_ck3 & CLIENT0_CK3_RESERVED_MASK) >> CLIENT0_CK3_RESERVED_SHIFT)

#define CLIENT0_CK3_SET_RESERVED(client0_ck3_reg, reserved) \
      client0_ck3_reg = (client0_ck3_reg & ~CLIENT0_CK3_RESERVED_MASK) | (reserved << CLIENT0_CK3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client0_ck3_t {
            unsigned int reserved                       : CLIENT0_CK3_RESERVED_SIZE;
      } client0_ck3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client0_ck3_t {
            unsigned int reserved                       : CLIENT0_CK3_RESERVED_SIZE;
      } client0_ck3_t;

#endif

typedef union {
     unsigned int val : 32;
          client0_ck3_t f;
} client0_ck3_u;


/*
 * CLIENT0_CD0 struct
 */

#define CLIENT0_CD0_REG_SIZE         32
#define CLIENT0_CD0_RESERVED_SIZE  32

#define CLIENT0_CD0_RESERVED_SHIFT  0

#define CLIENT0_CD0_RESERVED_MASK       0xffffffff

#define CLIENT0_CD0_MASK \
      (CLIENT0_CD0_RESERVED_MASK)

#define CLIENT0_CD0_DEFAULT            0x00000000

#define CLIENT0_CD0_GET_RESERVED(client0_cd0) \
      ((client0_cd0 & CLIENT0_CD0_RESERVED_MASK) >> CLIENT0_CD0_RESERVED_SHIFT)

#define CLIENT0_CD0_SET_RESERVED(client0_cd0_reg, reserved) \
      client0_cd0_reg = (client0_cd0_reg & ~CLIENT0_CD0_RESERVED_MASK) | (reserved << CLIENT0_CD0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client0_cd0_t {
            unsigned int reserved                       : CLIENT0_CD0_RESERVED_SIZE;
      } client0_cd0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client0_cd0_t {
            unsigned int reserved                       : CLIENT0_CD0_RESERVED_SIZE;
      } client0_cd0_t;

#endif

typedef union {
     unsigned int val : 32;
          client0_cd0_t f;
} client0_cd0_u;


/*
 * CLIENT0_CD1 struct
 */

#define CLIENT0_CD1_REG_SIZE         32
#define CLIENT0_CD1_RESERVED_SIZE  32

#define CLIENT0_CD1_RESERVED_SHIFT  0

#define CLIENT0_CD1_RESERVED_MASK       0xffffffff

#define CLIENT0_CD1_MASK \
      (CLIENT0_CD1_RESERVED_MASK)

#define CLIENT0_CD1_DEFAULT            0x00000000

#define CLIENT0_CD1_GET_RESERVED(client0_cd1) \
      ((client0_cd1 & CLIENT0_CD1_RESERVED_MASK) >> CLIENT0_CD1_RESERVED_SHIFT)

#define CLIENT0_CD1_SET_RESERVED(client0_cd1_reg, reserved) \
      client0_cd1_reg = (client0_cd1_reg & ~CLIENT0_CD1_RESERVED_MASK) | (reserved << CLIENT0_CD1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client0_cd1_t {
            unsigned int reserved                       : CLIENT0_CD1_RESERVED_SIZE;
      } client0_cd1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client0_cd1_t {
            unsigned int reserved                       : CLIENT0_CD1_RESERVED_SIZE;
      } client0_cd1_t;

#endif

typedef union {
     unsigned int val : 32;
          client0_cd1_t f;
} client0_cd1_u;


/*
 * CLIENT0_CD2 struct
 */

#define CLIENT0_CD2_REG_SIZE         32
#define CLIENT0_CD2_RESERVED_SIZE  32

#define CLIENT0_CD2_RESERVED_SHIFT  0

#define CLIENT0_CD2_RESERVED_MASK       0xffffffff

#define CLIENT0_CD2_MASK \
      (CLIENT0_CD2_RESERVED_MASK)

#define CLIENT0_CD2_DEFAULT            0x00000000

#define CLIENT0_CD2_GET_RESERVED(client0_cd2) \
      ((client0_cd2 & CLIENT0_CD2_RESERVED_MASK) >> CLIENT0_CD2_RESERVED_SHIFT)

#define CLIENT0_CD2_SET_RESERVED(client0_cd2_reg, reserved) \
      client0_cd2_reg = (client0_cd2_reg & ~CLIENT0_CD2_RESERVED_MASK) | (reserved << CLIENT0_CD2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client0_cd2_t {
            unsigned int reserved                       : CLIENT0_CD2_RESERVED_SIZE;
      } client0_cd2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client0_cd2_t {
            unsigned int reserved                       : CLIENT0_CD2_RESERVED_SIZE;
      } client0_cd2_t;

#endif

typedef union {
     unsigned int val : 32;
          client0_cd2_t f;
} client0_cd2_u;


/*
 * CLIENT0_CD3 struct
 */

#define CLIENT0_CD3_REG_SIZE         32
#define CLIENT0_CD3_RESERVED_SIZE  32

#define CLIENT0_CD3_RESERVED_SHIFT  0

#define CLIENT0_CD3_RESERVED_MASK       0xffffffff

#define CLIENT0_CD3_MASK \
      (CLIENT0_CD3_RESERVED_MASK)

#define CLIENT0_CD3_DEFAULT            0x00000000

#define CLIENT0_CD3_GET_RESERVED(client0_cd3) \
      ((client0_cd3 & CLIENT0_CD3_RESERVED_MASK) >> CLIENT0_CD3_RESERVED_SHIFT)

#define CLIENT0_CD3_SET_RESERVED(client0_cd3_reg, reserved) \
      client0_cd3_reg = (client0_cd3_reg & ~CLIENT0_CD3_RESERVED_MASK) | (reserved << CLIENT0_CD3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client0_cd3_t {
            unsigned int reserved                       : CLIENT0_CD3_RESERVED_SIZE;
      } client0_cd3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client0_cd3_t {
            unsigned int reserved                       : CLIENT0_CD3_RESERVED_SIZE;
      } client0_cd3_t;

#endif

typedef union {
     unsigned int val : 32;
          client0_cd3_t f;
} client0_cd3_u;


/*
 * CLIENT0_BM struct
 */

#define CLIENT0_BM_REG_SIZE         32
#define CLIENT0_BM_RESERVED_SIZE  32

#define CLIENT0_BM_RESERVED_SHIFT  0

#define CLIENT0_BM_RESERVED_MASK        0xffffffff

#define CLIENT0_BM_MASK \
      (CLIENT0_BM_RESERVED_MASK)

#define CLIENT0_BM_DEFAULT             0x00000000

#define CLIENT0_BM_GET_RESERVED(client0_bm) \
      ((client0_bm & CLIENT0_BM_RESERVED_MASK) >> CLIENT0_BM_RESERVED_SHIFT)

#define CLIENT0_BM_SET_RESERVED(client0_bm_reg, reserved) \
      client0_bm_reg = (client0_bm_reg & ~CLIENT0_BM_RESERVED_MASK) | (reserved << CLIENT0_BM_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client0_bm_t {
            unsigned int reserved                       : CLIENT0_BM_RESERVED_SIZE;
      } client0_bm_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client0_bm_t {
            unsigned int reserved                       : CLIENT0_BM_RESERVED_SIZE;
      } client0_bm_t;

#endif

typedef union {
     unsigned int val : 32;
          client0_bm_t f;
} client0_bm_u;


/*
 * CLIENT0_OFFSET struct
 */

#define CLIENT0_OFFSET_REG_SIZE         32
#define CLIENT0_OFFSET_RESERVED_SIZE  32

#define CLIENT0_OFFSET_RESERVED_SHIFT  0

#define CLIENT0_OFFSET_RESERVED_MASK    0xffffffff

#define CLIENT0_OFFSET_MASK \
      (CLIENT0_OFFSET_RESERVED_MASK)

#define CLIENT0_OFFSET_DEFAULT         0x00000000

#define CLIENT0_OFFSET_GET_RESERVED(client0_offset) \
      ((client0_offset & CLIENT0_OFFSET_RESERVED_MASK) >> CLIENT0_OFFSET_RESERVED_SHIFT)

#define CLIENT0_OFFSET_SET_RESERVED(client0_offset_reg, reserved) \
      client0_offset_reg = (client0_offset_reg & ~CLIENT0_OFFSET_RESERVED_MASK) | (reserved << CLIENT0_OFFSET_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client0_offset_t {
            unsigned int reserved                       : CLIENT0_OFFSET_RESERVED_SIZE;
      } client0_offset_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client0_offset_t {
            unsigned int reserved                       : CLIENT0_OFFSET_RESERVED_SIZE;
      } client0_offset_t;

#endif

typedef union {
     unsigned int val : 32;
          client0_offset_t f;
} client0_offset_u;


/*
 * CLIENT0_STATUS struct
 */

#define CLIENT0_STATUS_REG_SIZE         32
#define CLIENT0_STATUS_RESERVED_SIZE  32

#define CLIENT0_STATUS_RESERVED_SHIFT  0

#define CLIENT0_STATUS_RESERVED_MASK    0xffffffff

#define CLIENT0_STATUS_MASK \
      (CLIENT0_STATUS_RESERVED_MASK)

#define CLIENT0_STATUS_DEFAULT         0x00000000

#define CLIENT0_STATUS_GET_RESERVED(client0_status) \
      ((client0_status & CLIENT0_STATUS_RESERVED_MASK) >> CLIENT0_STATUS_RESERVED_SHIFT)

#define CLIENT0_STATUS_SET_RESERVED(client0_status_reg, reserved) \
      client0_status_reg = (client0_status_reg & ~CLIENT0_STATUS_RESERVED_MASK) | (reserved << CLIENT0_STATUS_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client0_status_t {
            unsigned int reserved                       : CLIENT0_STATUS_RESERVED_SIZE;
      } client0_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client0_status_t {
            unsigned int reserved                       : CLIENT0_STATUS_RESERVED_SIZE;
      } client0_status_t;

#endif

typedef union {
     unsigned int val : 32;
          client0_status_t f;
} client0_status_u;


/*
 * CLIENT1_K0 struct
 */

#define CLIENT1_K0_REG_SIZE         32
#define CLIENT1_K0_RESERVED_SIZE  32

#define CLIENT1_K0_RESERVED_SHIFT  0

#define CLIENT1_K0_RESERVED_MASK        0xffffffff

#define CLIENT1_K0_MASK \
      (CLIENT1_K0_RESERVED_MASK)

#define CLIENT1_K0_DEFAULT             0x00000000

#define CLIENT1_K0_GET_RESERVED(client1_k0) \
      ((client1_k0 & CLIENT1_K0_RESERVED_MASK) >> CLIENT1_K0_RESERVED_SHIFT)

#define CLIENT1_K0_SET_RESERVED(client1_k0_reg, reserved) \
      client1_k0_reg = (client1_k0_reg & ~CLIENT1_K0_RESERVED_MASK) | (reserved << CLIENT1_K0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client1_k0_t {
            unsigned int reserved                       : CLIENT1_K0_RESERVED_SIZE;
      } client1_k0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client1_k0_t {
            unsigned int reserved                       : CLIENT1_K0_RESERVED_SIZE;
      } client1_k0_t;

#endif

typedef union {
     unsigned int val : 32;
          client1_k0_t f;
} client1_k0_u;


/*
 * CLIENT1_K1 struct
 */

#define CLIENT1_K1_REG_SIZE         32
#define CLIENT1_K1_RESERVED_SIZE  32

#define CLIENT1_K1_RESERVED_SHIFT  0

#define CLIENT1_K1_RESERVED_MASK        0xffffffff

#define CLIENT1_K1_MASK \
      (CLIENT1_K1_RESERVED_MASK)

#define CLIENT1_K1_DEFAULT             0x00000000

#define CLIENT1_K1_GET_RESERVED(client1_k1) \
      ((client1_k1 & CLIENT1_K1_RESERVED_MASK) >> CLIENT1_K1_RESERVED_SHIFT)

#define CLIENT1_K1_SET_RESERVED(client1_k1_reg, reserved) \
      client1_k1_reg = (client1_k1_reg & ~CLIENT1_K1_RESERVED_MASK) | (reserved << CLIENT1_K1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client1_k1_t {
            unsigned int reserved                       : CLIENT1_K1_RESERVED_SIZE;
      } client1_k1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client1_k1_t {
            unsigned int reserved                       : CLIENT1_K1_RESERVED_SIZE;
      } client1_k1_t;

#endif

typedef union {
     unsigned int val : 32;
          client1_k1_t f;
} client1_k1_u;


/*
 * CLIENT1_K2 struct
 */

#define CLIENT1_K2_REG_SIZE         32
#define CLIENT1_K2_RESERVED_SIZE  32

#define CLIENT1_K2_RESERVED_SHIFT  0

#define CLIENT1_K2_RESERVED_MASK        0xffffffff

#define CLIENT1_K2_MASK \
      (CLIENT1_K2_RESERVED_MASK)

#define CLIENT1_K2_DEFAULT             0x00000000

#define CLIENT1_K2_GET_RESERVED(client1_k2) \
      ((client1_k2 & CLIENT1_K2_RESERVED_MASK) >> CLIENT1_K2_RESERVED_SHIFT)

#define CLIENT1_K2_SET_RESERVED(client1_k2_reg, reserved) \
      client1_k2_reg = (client1_k2_reg & ~CLIENT1_K2_RESERVED_MASK) | (reserved << CLIENT1_K2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client1_k2_t {
            unsigned int reserved                       : CLIENT1_K2_RESERVED_SIZE;
      } client1_k2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client1_k2_t {
            unsigned int reserved                       : CLIENT1_K2_RESERVED_SIZE;
      } client1_k2_t;

#endif

typedef union {
     unsigned int val : 32;
          client1_k2_t f;
} client1_k2_u;


/*
 * CLIENT1_K3 struct
 */

#define CLIENT1_K3_REG_SIZE         32
#define CLIENT1_K3_RESERVED_SIZE  32

#define CLIENT1_K3_RESERVED_SHIFT  0

#define CLIENT1_K3_RESERVED_MASK        0xffffffff

#define CLIENT1_K3_MASK \
      (CLIENT1_K3_RESERVED_MASK)

#define CLIENT1_K3_DEFAULT             0x00000000

#define CLIENT1_K3_GET_RESERVED(client1_k3) \
      ((client1_k3 & CLIENT1_K3_RESERVED_MASK) >> CLIENT1_K3_RESERVED_SHIFT)

#define CLIENT1_K3_SET_RESERVED(client1_k3_reg, reserved) \
      client1_k3_reg = (client1_k3_reg & ~CLIENT1_K3_RESERVED_MASK) | (reserved << CLIENT1_K3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client1_k3_t {
            unsigned int reserved                       : CLIENT1_K3_RESERVED_SIZE;
      } client1_k3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client1_k3_t {
            unsigned int reserved                       : CLIENT1_K3_RESERVED_SIZE;
      } client1_k3_t;

#endif

typedef union {
     unsigned int val : 32;
          client1_k3_t f;
} client1_k3_u;


/*
 * CLIENT1_CK0 struct
 */

#define CLIENT1_CK0_REG_SIZE         32
#define CLIENT1_CK0_RESERVED_SIZE  32

#define CLIENT1_CK0_RESERVED_SHIFT  0

#define CLIENT1_CK0_RESERVED_MASK       0xffffffff

#define CLIENT1_CK0_MASK \
      (CLIENT1_CK0_RESERVED_MASK)

#define CLIENT1_CK0_DEFAULT            0x00000000

#define CLIENT1_CK0_GET_RESERVED(client1_ck0) \
      ((client1_ck0 & CLIENT1_CK0_RESERVED_MASK) >> CLIENT1_CK0_RESERVED_SHIFT)

#define CLIENT1_CK0_SET_RESERVED(client1_ck0_reg, reserved) \
      client1_ck0_reg = (client1_ck0_reg & ~CLIENT1_CK0_RESERVED_MASK) | (reserved << CLIENT1_CK0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client1_ck0_t {
            unsigned int reserved                       : CLIENT1_CK0_RESERVED_SIZE;
      } client1_ck0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client1_ck0_t {
            unsigned int reserved                       : CLIENT1_CK0_RESERVED_SIZE;
      } client1_ck0_t;

#endif

typedef union {
     unsigned int val : 32;
          client1_ck0_t f;
} client1_ck0_u;


/*
 * CLIENT1_CK1 struct
 */

#define CLIENT1_CK1_REG_SIZE         32
#define CLIENT1_CK1_RESERVED_SIZE  32

#define CLIENT1_CK1_RESERVED_SHIFT  0

#define CLIENT1_CK1_RESERVED_MASK       0xffffffff

#define CLIENT1_CK1_MASK \
      (CLIENT1_CK1_RESERVED_MASK)

#define CLIENT1_CK1_DEFAULT            0x00000000

#define CLIENT1_CK1_GET_RESERVED(client1_ck1) \
      ((client1_ck1 & CLIENT1_CK1_RESERVED_MASK) >> CLIENT1_CK1_RESERVED_SHIFT)

#define CLIENT1_CK1_SET_RESERVED(client1_ck1_reg, reserved) \
      client1_ck1_reg = (client1_ck1_reg & ~CLIENT1_CK1_RESERVED_MASK) | (reserved << CLIENT1_CK1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client1_ck1_t {
            unsigned int reserved                       : CLIENT1_CK1_RESERVED_SIZE;
      } client1_ck1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client1_ck1_t {
            unsigned int reserved                       : CLIENT1_CK1_RESERVED_SIZE;
      } client1_ck1_t;

#endif

typedef union {
     unsigned int val : 32;
          client1_ck1_t f;
} client1_ck1_u;


/*
 * CLIENT1_CK2 struct
 */

#define CLIENT1_CK2_REG_SIZE         32
#define CLIENT1_CK2_RESERVED_SIZE  32

#define CLIENT1_CK2_RESERVED_SHIFT  0

#define CLIENT1_CK2_RESERVED_MASK       0xffffffff

#define CLIENT1_CK2_MASK \
      (CLIENT1_CK2_RESERVED_MASK)

#define CLIENT1_CK2_DEFAULT            0x00000000

#define CLIENT1_CK2_GET_RESERVED(client1_ck2) \
      ((client1_ck2 & CLIENT1_CK2_RESERVED_MASK) >> CLIENT1_CK2_RESERVED_SHIFT)

#define CLIENT1_CK2_SET_RESERVED(client1_ck2_reg, reserved) \
      client1_ck2_reg = (client1_ck2_reg & ~CLIENT1_CK2_RESERVED_MASK) | (reserved << CLIENT1_CK2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client1_ck2_t {
            unsigned int reserved                       : CLIENT1_CK2_RESERVED_SIZE;
      } client1_ck2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client1_ck2_t {
            unsigned int reserved                       : CLIENT1_CK2_RESERVED_SIZE;
      } client1_ck2_t;

#endif

typedef union {
     unsigned int val : 32;
          client1_ck2_t f;
} client1_ck2_u;


/*
 * CLIENT1_CK3 struct
 */

#define CLIENT1_CK3_REG_SIZE         32
#define CLIENT1_CK3_RESERVED_SIZE  32

#define CLIENT1_CK3_RESERVED_SHIFT  0

#define CLIENT1_CK3_RESERVED_MASK       0xffffffff

#define CLIENT1_CK3_MASK \
      (CLIENT1_CK3_RESERVED_MASK)

#define CLIENT1_CK3_DEFAULT            0x00000000

#define CLIENT1_CK3_GET_RESERVED(client1_ck3) \
      ((client1_ck3 & CLIENT1_CK3_RESERVED_MASK) >> CLIENT1_CK3_RESERVED_SHIFT)

#define CLIENT1_CK3_SET_RESERVED(client1_ck3_reg, reserved) \
      client1_ck3_reg = (client1_ck3_reg & ~CLIENT1_CK3_RESERVED_MASK) | (reserved << CLIENT1_CK3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client1_ck3_t {
            unsigned int reserved                       : CLIENT1_CK3_RESERVED_SIZE;
      } client1_ck3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client1_ck3_t {
            unsigned int reserved                       : CLIENT1_CK3_RESERVED_SIZE;
      } client1_ck3_t;

#endif

typedef union {
     unsigned int val : 32;
          client1_ck3_t f;
} client1_ck3_u;


/*
 * CLIENT1_CD0 struct
 */

#define CLIENT1_CD0_REG_SIZE         32
#define CLIENT1_CD0_RESERVED_SIZE  32

#define CLIENT1_CD0_RESERVED_SHIFT  0

#define CLIENT1_CD0_RESERVED_MASK       0xffffffff

#define CLIENT1_CD0_MASK \
      (CLIENT1_CD0_RESERVED_MASK)

#define CLIENT1_CD0_DEFAULT            0x00000000

#define CLIENT1_CD0_GET_RESERVED(client1_cd0) \
      ((client1_cd0 & CLIENT1_CD0_RESERVED_MASK) >> CLIENT1_CD0_RESERVED_SHIFT)

#define CLIENT1_CD0_SET_RESERVED(client1_cd0_reg, reserved) \
      client1_cd0_reg = (client1_cd0_reg & ~CLIENT1_CD0_RESERVED_MASK) | (reserved << CLIENT1_CD0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client1_cd0_t {
            unsigned int reserved                       : CLIENT1_CD0_RESERVED_SIZE;
      } client1_cd0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client1_cd0_t {
            unsigned int reserved                       : CLIENT1_CD0_RESERVED_SIZE;
      } client1_cd0_t;

#endif

typedef union {
     unsigned int val : 32;
          client1_cd0_t f;
} client1_cd0_u;


/*
 * CLIENT1_CD1 struct
 */

#define CLIENT1_CD1_REG_SIZE         32
#define CLIENT1_CD1_RESERVED_SIZE  32

#define CLIENT1_CD1_RESERVED_SHIFT  0

#define CLIENT1_CD1_RESERVED_MASK       0xffffffff

#define CLIENT1_CD1_MASK \
      (CLIENT1_CD1_RESERVED_MASK)

#define CLIENT1_CD1_DEFAULT            0x00000000

#define CLIENT1_CD1_GET_RESERVED(client1_cd1) \
      ((client1_cd1 & CLIENT1_CD1_RESERVED_MASK) >> CLIENT1_CD1_RESERVED_SHIFT)

#define CLIENT1_CD1_SET_RESERVED(client1_cd1_reg, reserved) \
      client1_cd1_reg = (client1_cd1_reg & ~CLIENT1_CD1_RESERVED_MASK) | (reserved << CLIENT1_CD1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client1_cd1_t {
            unsigned int reserved                       : CLIENT1_CD1_RESERVED_SIZE;
      } client1_cd1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client1_cd1_t {
            unsigned int reserved                       : CLIENT1_CD1_RESERVED_SIZE;
      } client1_cd1_t;

#endif

typedef union {
     unsigned int val : 32;
          client1_cd1_t f;
} client1_cd1_u;


/*
 * CLIENT1_CD2 struct
 */

#define CLIENT1_CD2_REG_SIZE         32
#define CLIENT1_CD2_RESERVED_SIZE  32

#define CLIENT1_CD2_RESERVED_SHIFT  0

#define CLIENT1_CD2_RESERVED_MASK       0xffffffff

#define CLIENT1_CD2_MASK \
      (CLIENT1_CD2_RESERVED_MASK)

#define CLIENT1_CD2_DEFAULT            0x00000000

#define CLIENT1_CD2_GET_RESERVED(client1_cd2) \
      ((client1_cd2 & CLIENT1_CD2_RESERVED_MASK) >> CLIENT1_CD2_RESERVED_SHIFT)

#define CLIENT1_CD2_SET_RESERVED(client1_cd2_reg, reserved) \
      client1_cd2_reg = (client1_cd2_reg & ~CLIENT1_CD2_RESERVED_MASK) | (reserved << CLIENT1_CD2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client1_cd2_t {
            unsigned int reserved                       : CLIENT1_CD2_RESERVED_SIZE;
      } client1_cd2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client1_cd2_t {
            unsigned int reserved                       : CLIENT1_CD2_RESERVED_SIZE;
      } client1_cd2_t;

#endif

typedef union {
     unsigned int val : 32;
          client1_cd2_t f;
} client1_cd2_u;


/*
 * CLIENT1_CD3 struct
 */

#define CLIENT1_CD3_REG_SIZE         32
#define CLIENT1_CD3_RESERVED_SIZE  32

#define CLIENT1_CD3_RESERVED_SHIFT  0

#define CLIENT1_CD3_RESERVED_MASK       0xffffffff

#define CLIENT1_CD3_MASK \
      (CLIENT1_CD3_RESERVED_MASK)

#define CLIENT1_CD3_DEFAULT            0x00000000

#define CLIENT1_CD3_GET_RESERVED(client1_cd3) \
      ((client1_cd3 & CLIENT1_CD3_RESERVED_MASK) >> CLIENT1_CD3_RESERVED_SHIFT)

#define CLIENT1_CD3_SET_RESERVED(client1_cd3_reg, reserved) \
      client1_cd3_reg = (client1_cd3_reg & ~CLIENT1_CD3_RESERVED_MASK) | (reserved << CLIENT1_CD3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client1_cd3_t {
            unsigned int reserved                       : CLIENT1_CD3_RESERVED_SIZE;
      } client1_cd3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client1_cd3_t {
            unsigned int reserved                       : CLIENT1_CD3_RESERVED_SIZE;
      } client1_cd3_t;

#endif

typedef union {
     unsigned int val : 32;
          client1_cd3_t f;
} client1_cd3_u;


/*
 * CLIENT1_BM struct
 */

#define CLIENT1_BM_REG_SIZE         32
#define CLIENT1_BM_RESERVED_SIZE  32

#define CLIENT1_BM_RESERVED_SHIFT  0

#define CLIENT1_BM_RESERVED_MASK        0xffffffff

#define CLIENT1_BM_MASK \
      (CLIENT1_BM_RESERVED_MASK)

#define CLIENT1_BM_DEFAULT             0x00000000

#define CLIENT1_BM_GET_RESERVED(client1_bm) \
      ((client1_bm & CLIENT1_BM_RESERVED_MASK) >> CLIENT1_BM_RESERVED_SHIFT)

#define CLIENT1_BM_SET_RESERVED(client1_bm_reg, reserved) \
      client1_bm_reg = (client1_bm_reg & ~CLIENT1_BM_RESERVED_MASK) | (reserved << CLIENT1_BM_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client1_bm_t {
            unsigned int reserved                       : CLIENT1_BM_RESERVED_SIZE;
      } client1_bm_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client1_bm_t {
            unsigned int reserved                       : CLIENT1_BM_RESERVED_SIZE;
      } client1_bm_t;

#endif

typedef union {
     unsigned int val : 32;
          client1_bm_t f;
} client1_bm_u;


/*
 * CLIENT1_OFFSET struct
 */

#define CLIENT1_OFFSET_REG_SIZE         32
#define CLIENT1_OFFSET_RESERVED_SIZE  32

#define CLIENT1_OFFSET_RESERVED_SHIFT  0

#define CLIENT1_OFFSET_RESERVED_MASK    0xffffffff

#define CLIENT1_OFFSET_MASK \
      (CLIENT1_OFFSET_RESERVED_MASK)

#define CLIENT1_OFFSET_DEFAULT         0x00000000

#define CLIENT1_OFFSET_GET_RESERVED(client1_offset) \
      ((client1_offset & CLIENT1_OFFSET_RESERVED_MASK) >> CLIENT1_OFFSET_RESERVED_SHIFT)

#define CLIENT1_OFFSET_SET_RESERVED(client1_offset_reg, reserved) \
      client1_offset_reg = (client1_offset_reg & ~CLIENT1_OFFSET_RESERVED_MASK) | (reserved << CLIENT1_OFFSET_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client1_offset_t {
            unsigned int reserved                       : CLIENT1_OFFSET_RESERVED_SIZE;
      } client1_offset_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client1_offset_t {
            unsigned int reserved                       : CLIENT1_OFFSET_RESERVED_SIZE;
      } client1_offset_t;

#endif

typedef union {
     unsigned int val : 32;
          client1_offset_t f;
} client1_offset_u;


/*
 * CLIENT1_PORT_STATUS struct
 */

#define CLIENT1_PORT_STATUS_REG_SIZE         32
#define CLIENT1_PORT_STATUS_RESERVED_SIZE  32

#define CLIENT1_PORT_STATUS_RESERVED_SHIFT  0

#define CLIENT1_PORT_STATUS_RESERVED_MASK  0xffffffff

#define CLIENT1_PORT_STATUS_MASK \
      (CLIENT1_PORT_STATUS_RESERVED_MASK)

#define CLIENT1_PORT_STATUS_DEFAULT    0x00000000

#define CLIENT1_PORT_STATUS_GET_RESERVED(client1_port_status) \
      ((client1_port_status & CLIENT1_PORT_STATUS_RESERVED_MASK) >> CLIENT1_PORT_STATUS_RESERVED_SHIFT)

#define CLIENT1_PORT_STATUS_SET_RESERVED(client1_port_status_reg, reserved) \
      client1_port_status_reg = (client1_port_status_reg & ~CLIENT1_PORT_STATUS_RESERVED_MASK) | (reserved << CLIENT1_PORT_STATUS_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client1_port_status_t {
            unsigned int reserved                       : CLIENT1_PORT_STATUS_RESERVED_SIZE;
      } client1_port_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client1_port_status_t {
            unsigned int reserved                       : CLIENT1_PORT_STATUS_RESERVED_SIZE;
      } client1_port_status_t;

#endif

typedef union {
     unsigned int val : 32;
          client1_port_status_t f;
} client1_port_status_u;


/*
 * KEFUSE0 struct
 */

#define KEFUSE0_REG_SIZE         32
#define KEFUSE0_RESERVED_SIZE  32

#define KEFUSE0_RESERVED_SHIFT  0

#define KEFUSE0_RESERVED_MASK           0xffffffff

#define KEFUSE0_MASK \
      (KEFUSE0_RESERVED_MASK)

#define KEFUSE0_DEFAULT                0x00000000

#define KEFUSE0_GET_RESERVED(kefuse0) \
      ((kefuse0 & KEFUSE0_RESERVED_MASK) >> KEFUSE0_RESERVED_SHIFT)

#define KEFUSE0_SET_RESERVED(kefuse0_reg, reserved) \
      kefuse0_reg = (kefuse0_reg & ~KEFUSE0_RESERVED_MASK) | (reserved << KEFUSE0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct kefuse0_t {
            unsigned int reserved                       : KEFUSE0_RESERVED_SIZE;
      } kefuse0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct kefuse0_t {
            unsigned int reserved                       : KEFUSE0_RESERVED_SIZE;
      } kefuse0_t;

#endif

typedef union {
     unsigned int val : 32;
          kefuse0_t f;
} kefuse0_u;


/*
 * KEFUSE1 struct
 */

#define KEFUSE1_REG_SIZE         32
#define KEFUSE1_RESERVED_SIZE  32

#define KEFUSE1_RESERVED_SHIFT  0

#define KEFUSE1_RESERVED_MASK           0xffffffff

#define KEFUSE1_MASK \
      (KEFUSE1_RESERVED_MASK)

#define KEFUSE1_DEFAULT                0x00000000

#define KEFUSE1_GET_RESERVED(kefuse1) \
      ((kefuse1 & KEFUSE1_RESERVED_MASK) >> KEFUSE1_RESERVED_SHIFT)

#define KEFUSE1_SET_RESERVED(kefuse1_reg, reserved) \
      kefuse1_reg = (kefuse1_reg & ~KEFUSE1_RESERVED_MASK) | (reserved << KEFUSE1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct kefuse1_t {
            unsigned int reserved                       : KEFUSE1_RESERVED_SIZE;
      } kefuse1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct kefuse1_t {
            unsigned int reserved                       : KEFUSE1_RESERVED_SIZE;
      } kefuse1_t;

#endif

typedef union {
     unsigned int val : 32;
          kefuse1_t f;
} kefuse1_u;


/*
 * KEFUSE2 struct
 */

#define KEFUSE2_REG_SIZE         32
#define KEFUSE2_RESERVED_SIZE  32

#define KEFUSE2_RESERVED_SHIFT  0

#define KEFUSE2_RESERVED_MASK           0xffffffff

#define KEFUSE2_MASK \
      (KEFUSE2_RESERVED_MASK)

#define KEFUSE2_DEFAULT                0x00000000

#define KEFUSE2_GET_RESERVED(kefuse2) \
      ((kefuse2 & KEFUSE2_RESERVED_MASK) >> KEFUSE2_RESERVED_SHIFT)

#define KEFUSE2_SET_RESERVED(kefuse2_reg, reserved) \
      kefuse2_reg = (kefuse2_reg & ~KEFUSE2_RESERVED_MASK) | (reserved << KEFUSE2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct kefuse2_t {
            unsigned int reserved                       : KEFUSE2_RESERVED_SIZE;
      } kefuse2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct kefuse2_t {
            unsigned int reserved                       : KEFUSE2_RESERVED_SIZE;
      } kefuse2_t;

#endif

typedef union {
     unsigned int val : 32;
          kefuse2_t f;
} kefuse2_u;


/*
 * KEFUSE3 struct
 */

#define KEFUSE3_REG_SIZE         32
#define KEFUSE3_RESERVED_SIZE  32

#define KEFUSE3_RESERVED_SHIFT  0

#define KEFUSE3_RESERVED_MASK           0xffffffff

#define KEFUSE3_MASK \
      (KEFUSE3_RESERVED_MASK)

#define KEFUSE3_DEFAULT                0x00000000

#define KEFUSE3_GET_RESERVED(kefuse3) \
      ((kefuse3 & KEFUSE3_RESERVED_MASK) >> KEFUSE3_RESERVED_SHIFT)

#define KEFUSE3_SET_RESERVED(kefuse3_reg, reserved) \
      kefuse3_reg = (kefuse3_reg & ~KEFUSE3_RESERVED_MASK) | (reserved << KEFUSE3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct kefuse3_t {
            unsigned int reserved                       : KEFUSE3_RESERVED_SIZE;
      } kefuse3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct kefuse3_t {
            unsigned int reserved                       : KEFUSE3_RESERVED_SIZE;
      } kefuse3_t;

#endif

typedef union {
     unsigned int val : 32;
          kefuse3_t f;
} kefuse3_u;


/*
 * HFS_SEED0 struct
 */

#define HFS_SEED0_REG_SIZE         32
#define HFS_SEED0_RESERVED_SIZE  32

#define HFS_SEED0_RESERVED_SHIFT  0

#define HFS_SEED0_RESERVED_MASK         0xffffffff

#define HFS_SEED0_MASK \
      (HFS_SEED0_RESERVED_MASK)

#define HFS_SEED0_DEFAULT              0x00000000

#define HFS_SEED0_GET_RESERVED(hfs_seed0) \
      ((hfs_seed0 & HFS_SEED0_RESERVED_MASK) >> HFS_SEED0_RESERVED_SHIFT)

#define HFS_SEED0_SET_RESERVED(hfs_seed0_reg, reserved) \
      hfs_seed0_reg = (hfs_seed0_reg & ~HFS_SEED0_RESERVED_MASK) | (reserved << HFS_SEED0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct hfs_seed0_t {
            unsigned int reserved                       : HFS_SEED0_RESERVED_SIZE;
      } hfs_seed0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct hfs_seed0_t {
            unsigned int reserved                       : HFS_SEED0_RESERVED_SIZE;
      } hfs_seed0_t;

#endif

typedef union {
     unsigned int val : 32;
          hfs_seed0_t f;
} hfs_seed0_u;


/*
 * HFS_SEED1 struct
 */

#define HFS_SEED1_REG_SIZE         32
#define HFS_SEED1_RESERVED_SIZE  32

#define HFS_SEED1_RESERVED_SHIFT  0

#define HFS_SEED1_RESERVED_MASK         0xffffffff

#define HFS_SEED1_MASK \
      (HFS_SEED1_RESERVED_MASK)

#define HFS_SEED1_DEFAULT              0x00000000

#define HFS_SEED1_GET_RESERVED(hfs_seed1) \
      ((hfs_seed1 & HFS_SEED1_RESERVED_MASK) >> HFS_SEED1_RESERVED_SHIFT)

#define HFS_SEED1_SET_RESERVED(hfs_seed1_reg, reserved) \
      hfs_seed1_reg = (hfs_seed1_reg & ~HFS_SEED1_RESERVED_MASK) | (reserved << HFS_SEED1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct hfs_seed1_t {
            unsigned int reserved                       : HFS_SEED1_RESERVED_SIZE;
      } hfs_seed1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct hfs_seed1_t {
            unsigned int reserved                       : HFS_SEED1_RESERVED_SIZE;
      } hfs_seed1_t;

#endif

typedef union {
     unsigned int val : 32;
          hfs_seed1_t f;
} hfs_seed1_u;


/*
 * HFS_SEED2 struct
 */

#define HFS_SEED2_REG_SIZE         32
#define HFS_SEED2_RESERVED_SIZE  32

#define HFS_SEED2_RESERVED_SHIFT  0

#define HFS_SEED2_RESERVED_MASK         0xffffffff

#define HFS_SEED2_MASK \
      (HFS_SEED2_RESERVED_MASK)

#define HFS_SEED2_DEFAULT              0x00000000

#define HFS_SEED2_GET_RESERVED(hfs_seed2) \
      ((hfs_seed2 & HFS_SEED2_RESERVED_MASK) >> HFS_SEED2_RESERVED_SHIFT)

#define HFS_SEED2_SET_RESERVED(hfs_seed2_reg, reserved) \
      hfs_seed2_reg = (hfs_seed2_reg & ~HFS_SEED2_RESERVED_MASK) | (reserved << HFS_SEED2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct hfs_seed2_t {
            unsigned int reserved                       : HFS_SEED2_RESERVED_SIZE;
      } hfs_seed2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct hfs_seed2_t {
            unsigned int reserved                       : HFS_SEED2_RESERVED_SIZE;
      } hfs_seed2_t;

#endif

typedef union {
     unsigned int val : 32;
          hfs_seed2_t f;
} hfs_seed2_u;


/*
 * HFS_SEED3 struct
 */

#define HFS_SEED3_REG_SIZE         32
#define HFS_SEED3_RESERVED_SIZE  32

#define HFS_SEED3_RESERVED_SHIFT  0

#define HFS_SEED3_RESERVED_MASK         0xffffffff

#define HFS_SEED3_MASK \
      (HFS_SEED3_RESERVED_MASK)

#define HFS_SEED3_DEFAULT              0x00000000

#define HFS_SEED3_GET_RESERVED(hfs_seed3) \
      ((hfs_seed3 & HFS_SEED3_RESERVED_MASK) >> HFS_SEED3_RESERVED_SHIFT)

#define HFS_SEED3_SET_RESERVED(hfs_seed3_reg, reserved) \
      hfs_seed3_reg = (hfs_seed3_reg & ~HFS_SEED3_RESERVED_MASK) | (reserved << HFS_SEED3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct hfs_seed3_t {
            unsigned int reserved                       : HFS_SEED3_RESERVED_SIZE;
      } hfs_seed3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct hfs_seed3_t {
            unsigned int reserved                       : HFS_SEED3_RESERVED_SIZE;
      } hfs_seed3_t;

#endif

typedef union {
     unsigned int val : 32;
          hfs_seed3_t f;
} hfs_seed3_u;


/*
 * RINGOSC_MASK struct
 */

#define RINGOSC_MASK_REG_SIZE         32
#define RINGOSC_MASK_MASK_SIZE  16

#define RINGOSC_MASK_MASK_SHIFT  0

#define RINGOSC_MASK_MASK_MASK          0x0000ffff

#define RINGOSC_MASK_MASK \
      (RINGOSC_MASK_MASK_MASK)

#define RINGOSC_MASK_DEFAULT           0x0000ffff

#define RINGOSC_MASK_GET_MASK(ringosc_mask) \
      ((ringosc_mask & RINGOSC_MASK_MASK_MASK) >> RINGOSC_MASK_MASK_SHIFT)

#define RINGOSC_MASK_SET_MASK(ringosc_mask_reg, mask) \
      ringosc_mask_reg = (ringosc_mask_reg & ~RINGOSC_MASK_MASK_MASK) | (mask << RINGOSC_MASK_MASK_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct ringosc_mask_t {
            unsigned int mask                           : RINGOSC_MASK_MASK_SIZE;
            unsigned int                                : 16;
      } ringosc_mask_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct ringosc_mask_t {
            unsigned int                                : 16;
            unsigned int mask                           : RINGOSC_MASK_MASK_SIZE;
      } ringosc_mask_t;

#endif

typedef union {
     unsigned int val : 32;
          ringosc_mask_t f;
} ringosc_mask_u;


/*
 * AUTH_STATE struct
 */

#define AUTH_STATE_REG_SIZE         32
#define AUTH_STATE_STATE_SIZE  3

#define AUTH_STATE_STATE_SHIFT  0

#define AUTH_STATE_STATE_MASK           0x00000007

#define AUTH_STATE_MASK \
      (AUTH_STATE_STATE_MASK)

#define AUTH_STATE_DEFAULT             0x00000000

#define AUTH_STATE_GET_STATE(auth_state) \
      ((auth_state & AUTH_STATE_STATE_MASK) >> AUTH_STATE_STATE_SHIFT)

#define AUTH_STATE_SET_STATE(auth_state_reg, state) \
      auth_state_reg = (auth_state_reg & ~AUTH_STATE_STATE_MASK) | (state << AUTH_STATE_STATE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct auth_state_t {
            unsigned int state                          : AUTH_STATE_STATE_SIZE;
            unsigned int                                : 29;
      } auth_state_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct auth_state_t {
            unsigned int                                : 29;
            unsigned int state                          : AUTH_STATE_STATE_SIZE;
      } auth_state_t;

#endif

typedef union {
     unsigned int val : 32;
          auth_state_t f;
} auth_state_u;


/*
 * CLIENT0_OFFSET_HI struct
 */

#define CLIENT0_OFFSET_HI_REG_SIZE         32
#define CLIENT0_OFFSET_HI_RESERVED_SIZE  32

#define CLIENT0_OFFSET_HI_RESERVED_SHIFT  0

#define CLIENT0_OFFSET_HI_RESERVED_MASK  0xffffffff

#define CLIENT0_OFFSET_HI_MASK \
      (CLIENT0_OFFSET_HI_RESERVED_MASK)

#define CLIENT0_OFFSET_HI_DEFAULT      0x00000000

#define CLIENT0_OFFSET_HI_GET_RESERVED(client0_offset_hi) \
      ((client0_offset_hi & CLIENT0_OFFSET_HI_RESERVED_MASK) >> CLIENT0_OFFSET_HI_RESERVED_SHIFT)

#define CLIENT0_OFFSET_HI_SET_RESERVED(client0_offset_hi_reg, reserved) \
      client0_offset_hi_reg = (client0_offset_hi_reg & ~CLIENT0_OFFSET_HI_RESERVED_MASK) | (reserved << CLIENT0_OFFSET_HI_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client0_offset_hi_t {
            unsigned int reserved                       : CLIENT0_OFFSET_HI_RESERVED_SIZE;
      } client0_offset_hi_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client0_offset_hi_t {
            unsigned int reserved                       : CLIENT0_OFFSET_HI_RESERVED_SIZE;
      } client0_offset_hi_t;

#endif

typedef union {
     unsigned int val : 32;
          client0_offset_hi_t f;
} client0_offset_hi_u;


/*
 * CLIENT1_OFFSET_HI struct
 */

#define CLIENT1_OFFSET_HI_REG_SIZE         32
#define CLIENT1_OFFSET_HI_RESERVED_SIZE  32

#define CLIENT1_OFFSET_HI_RESERVED_SHIFT  0

#define CLIENT1_OFFSET_HI_RESERVED_MASK  0xffffffff

#define CLIENT1_OFFSET_HI_MASK \
      (CLIENT1_OFFSET_HI_RESERVED_MASK)

#define CLIENT1_OFFSET_HI_DEFAULT      0x00000000

#define CLIENT1_OFFSET_HI_GET_RESERVED(client1_offset_hi) \
      ((client1_offset_hi & CLIENT1_OFFSET_HI_RESERVED_MASK) >> CLIENT1_OFFSET_HI_RESERVED_SHIFT)

#define CLIENT1_OFFSET_HI_SET_RESERVED(client1_offset_hi_reg, reserved) \
      client1_offset_hi_reg = (client1_offset_hi_reg & ~CLIENT1_OFFSET_HI_RESERVED_MASK) | (reserved << CLIENT1_OFFSET_HI_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client1_offset_hi_t {
            unsigned int reserved                       : CLIENT1_OFFSET_HI_RESERVED_SIZE;
      } client1_offset_hi_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client1_offset_hi_t {
            unsigned int reserved                       : CLIENT1_OFFSET_HI_RESERVED_SIZE;
      } client1_offset_hi_t;

#endif

typedef union {
     unsigned int val : 32;
          client1_offset_hi_t f;
} client1_offset_hi_u;


/*
 * CLIENT2_OFFSET_HI struct
 */

#define CLIENT2_OFFSET_HI_REG_SIZE         32
#define CLIENT2_OFFSET_HI_RESERVED_SIZE  32

#define CLIENT2_OFFSET_HI_RESERVED_SHIFT  0

#define CLIENT2_OFFSET_HI_RESERVED_MASK  0xffffffff

#define CLIENT2_OFFSET_HI_MASK \
      (CLIENT2_OFFSET_HI_RESERVED_MASK)

#define CLIENT2_OFFSET_HI_DEFAULT      0x00000000

#define CLIENT2_OFFSET_HI_GET_RESERVED(client2_offset_hi) \
      ((client2_offset_hi & CLIENT2_OFFSET_HI_RESERVED_MASK) >> CLIENT2_OFFSET_HI_RESERVED_SHIFT)

#define CLIENT2_OFFSET_HI_SET_RESERVED(client2_offset_hi_reg, reserved) \
      client2_offset_hi_reg = (client2_offset_hi_reg & ~CLIENT2_OFFSET_HI_RESERVED_MASK) | (reserved << CLIENT2_OFFSET_HI_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client2_offset_hi_t {
            unsigned int reserved                       : CLIENT2_OFFSET_HI_RESERVED_SIZE;
      } client2_offset_hi_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client2_offset_hi_t {
            unsigned int reserved                       : CLIENT2_OFFSET_HI_RESERVED_SIZE;
      } client2_offset_hi_t;

#endif

typedef union {
     unsigned int val : 32;
          client2_offset_hi_t f;
} client2_offset_hi_u;


/*
 * SPU_PORT_STATUS struct
 */

#define SPU_PORT_STATUS_REG_SIZE         32
#define SPU_PORT_STATUS_RESERVED_SIZE  32

#define SPU_PORT_STATUS_RESERVED_SHIFT  0

#define SPU_PORT_STATUS_RESERVED_MASK   0xffffffff

#define SPU_PORT_STATUS_MASK \
      (SPU_PORT_STATUS_RESERVED_MASK)

#define SPU_PORT_STATUS_DEFAULT        0x00000000

#define SPU_PORT_STATUS_GET_RESERVED(spu_port_status) \
      ((spu_port_status & SPU_PORT_STATUS_RESERVED_MASK) >> SPU_PORT_STATUS_RESERVED_SHIFT)

#define SPU_PORT_STATUS_SET_RESERVED(spu_port_status_reg, reserved) \
      spu_port_status_reg = (spu_port_status_reg & ~SPU_PORT_STATUS_RESERVED_MASK) | (reserved << SPU_PORT_STATUS_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct spu_port_status_t {
            unsigned int reserved                       : SPU_PORT_STATUS_RESERVED_SIZE;
      } spu_port_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct spu_port_status_t {
            unsigned int reserved                       : SPU_PORT_STATUS_RESERVED_SIZE;
      } spu_port_status_t;

#endif

typedef union {
     unsigned int val : 32;
          spu_port_status_t f;
} spu_port_status_u;


/*
 * CLIENT3_OFFSET_HI struct
 */

#define CLIENT3_OFFSET_HI_REG_SIZE         32
#define CLIENT3_OFFSET_HI_RESERVED_SIZE  32

#define CLIENT3_OFFSET_HI_RESERVED_SHIFT  0

#define CLIENT3_OFFSET_HI_RESERVED_MASK  0xffffffff

#define CLIENT3_OFFSET_HI_MASK \
      (CLIENT3_OFFSET_HI_RESERVED_MASK)

#define CLIENT3_OFFSET_HI_DEFAULT      0x00000000

#define CLIENT3_OFFSET_HI_GET_RESERVED(client3_offset_hi) \
      ((client3_offset_hi & CLIENT3_OFFSET_HI_RESERVED_MASK) >> CLIENT3_OFFSET_HI_RESERVED_SHIFT)

#define CLIENT3_OFFSET_HI_SET_RESERVED(client3_offset_hi_reg, reserved) \
      client3_offset_hi_reg = (client3_offset_hi_reg & ~CLIENT3_OFFSET_HI_RESERVED_MASK) | (reserved << CLIENT3_OFFSET_HI_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client3_offset_hi_t {
            unsigned int reserved                       : CLIENT3_OFFSET_HI_RESERVED_SIZE;
      } client3_offset_hi_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client3_offset_hi_t {
            unsigned int reserved                       : CLIENT3_OFFSET_HI_RESERVED_SIZE;
      } client3_offset_hi_t;

#endif

typedef union {
     unsigned int val : 32;
          client3_offset_hi_t f;
} client3_offset_hi_u;


/*
 * CLIENT3_K0 struct
 */

#define CLIENT3_K0_REG_SIZE         32
#define CLIENT3_K0_RESERVED_SIZE  32

#define CLIENT3_K0_RESERVED_SHIFT  0

#define CLIENT3_K0_RESERVED_MASK        0xffffffff

#define CLIENT3_K0_MASK \
      (CLIENT3_K0_RESERVED_MASK)

#define CLIENT3_K0_DEFAULT             0x00000000

#define CLIENT3_K0_GET_RESERVED(client3_k0) \
      ((client3_k0 & CLIENT3_K0_RESERVED_MASK) >> CLIENT3_K0_RESERVED_SHIFT)

#define CLIENT3_K0_SET_RESERVED(client3_k0_reg, reserved) \
      client3_k0_reg = (client3_k0_reg & ~CLIENT3_K0_RESERVED_MASK) | (reserved << CLIENT3_K0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client3_k0_t {
            unsigned int reserved                       : CLIENT3_K0_RESERVED_SIZE;
      } client3_k0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client3_k0_t {
            unsigned int reserved                       : CLIENT3_K0_RESERVED_SIZE;
      } client3_k0_t;

#endif

typedef union {
     unsigned int val : 32;
          client3_k0_t f;
} client3_k0_u;


/*
 * CLIENT3_K1 struct
 */

#define CLIENT3_K1_REG_SIZE         32
#define CLIENT3_K1_RESERVED_SIZE  32

#define CLIENT3_K1_RESERVED_SHIFT  0

#define CLIENT3_K1_RESERVED_MASK        0xffffffff

#define CLIENT3_K1_MASK \
      (CLIENT3_K1_RESERVED_MASK)

#define CLIENT3_K1_DEFAULT             0x00000000

#define CLIENT3_K1_GET_RESERVED(client3_k1) \
      ((client3_k1 & CLIENT3_K1_RESERVED_MASK) >> CLIENT3_K1_RESERVED_SHIFT)

#define CLIENT3_K1_SET_RESERVED(client3_k1_reg, reserved) \
      client3_k1_reg = (client3_k1_reg & ~CLIENT3_K1_RESERVED_MASK) | (reserved << CLIENT3_K1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client3_k1_t {
            unsigned int reserved                       : CLIENT3_K1_RESERVED_SIZE;
      } client3_k1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client3_k1_t {
            unsigned int reserved                       : CLIENT3_K1_RESERVED_SIZE;
      } client3_k1_t;

#endif

typedef union {
     unsigned int val : 32;
          client3_k1_t f;
} client3_k1_u;


/*
 * CLIENT3_K2 struct
 */

#define CLIENT3_K2_REG_SIZE         32
#define CLIENT3_K2_RESERVED_SIZE  32

#define CLIENT3_K2_RESERVED_SHIFT  0

#define CLIENT3_K2_RESERVED_MASK        0xffffffff

#define CLIENT3_K2_MASK \
      (CLIENT3_K2_RESERVED_MASK)

#define CLIENT3_K2_DEFAULT             0x00000000

#define CLIENT3_K2_GET_RESERVED(client3_k2) \
      ((client3_k2 & CLIENT3_K2_RESERVED_MASK) >> CLIENT3_K2_RESERVED_SHIFT)

#define CLIENT3_K2_SET_RESERVED(client3_k2_reg, reserved) \
      client3_k2_reg = (client3_k2_reg & ~CLIENT3_K2_RESERVED_MASK) | (reserved << CLIENT3_K2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client3_k2_t {
            unsigned int reserved                       : CLIENT3_K2_RESERVED_SIZE;
      } client3_k2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client3_k2_t {
            unsigned int reserved                       : CLIENT3_K2_RESERVED_SIZE;
      } client3_k2_t;

#endif

typedef union {
     unsigned int val : 32;
          client3_k2_t f;
} client3_k2_u;


/*
 * CLIENT3_K3 struct
 */

#define CLIENT3_K3_REG_SIZE         32
#define CLIENT3_K3_RESERVED_SIZE  32

#define CLIENT3_K3_RESERVED_SHIFT  0

#define CLIENT3_K3_RESERVED_MASK        0xffffffff

#define CLIENT3_K3_MASK \
      (CLIENT3_K3_RESERVED_MASK)

#define CLIENT3_K3_DEFAULT             0x00000000

#define CLIENT3_K3_GET_RESERVED(client3_k3) \
      ((client3_k3 & CLIENT3_K3_RESERVED_MASK) >> CLIENT3_K3_RESERVED_SHIFT)

#define CLIENT3_K3_SET_RESERVED(client3_k3_reg, reserved) \
      client3_k3_reg = (client3_k3_reg & ~CLIENT3_K3_RESERVED_MASK) | (reserved << CLIENT3_K3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client3_k3_t {
            unsigned int reserved                       : CLIENT3_K3_RESERVED_SIZE;
      } client3_k3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client3_k3_t {
            unsigned int reserved                       : CLIENT3_K3_RESERVED_SIZE;
      } client3_k3_t;

#endif

typedef union {
     unsigned int val : 32;
          client3_k3_t f;
} client3_k3_u;


/*
 * CLIENT3_CK0 struct
 */

#define CLIENT3_CK0_REG_SIZE         32
#define CLIENT3_CK0_RESERVED_SIZE  32

#define CLIENT3_CK0_RESERVED_SHIFT  0

#define CLIENT3_CK0_RESERVED_MASK       0xffffffff

#define CLIENT3_CK0_MASK \
      (CLIENT3_CK0_RESERVED_MASK)

#define CLIENT3_CK0_DEFAULT            0x00000000

#define CLIENT3_CK0_GET_RESERVED(client3_ck0) \
      ((client3_ck0 & CLIENT3_CK0_RESERVED_MASK) >> CLIENT3_CK0_RESERVED_SHIFT)

#define CLIENT3_CK0_SET_RESERVED(client3_ck0_reg, reserved) \
      client3_ck0_reg = (client3_ck0_reg & ~CLIENT3_CK0_RESERVED_MASK) | (reserved << CLIENT3_CK0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client3_ck0_t {
            unsigned int reserved                       : CLIENT3_CK0_RESERVED_SIZE;
      } client3_ck0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client3_ck0_t {
            unsigned int reserved                       : CLIENT3_CK0_RESERVED_SIZE;
      } client3_ck0_t;

#endif

typedef union {
     unsigned int val : 32;
          client3_ck0_t f;
} client3_ck0_u;


/*
 * CLIENT3_CK1 struct
 */

#define CLIENT3_CK1_REG_SIZE         32
#define CLIENT3_CK1_RESERVED_SIZE  32

#define CLIENT3_CK1_RESERVED_SHIFT  0

#define CLIENT3_CK1_RESERVED_MASK       0xffffffff

#define CLIENT3_CK1_MASK \
      (CLIENT3_CK1_RESERVED_MASK)

#define CLIENT3_CK1_DEFAULT            0x00000000

#define CLIENT3_CK1_GET_RESERVED(client3_ck1) \
      ((client3_ck1 & CLIENT3_CK1_RESERVED_MASK) >> CLIENT3_CK1_RESERVED_SHIFT)

#define CLIENT3_CK1_SET_RESERVED(client3_ck1_reg, reserved) \
      client3_ck1_reg = (client3_ck1_reg & ~CLIENT3_CK1_RESERVED_MASK) | (reserved << CLIENT3_CK1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client3_ck1_t {
            unsigned int reserved                       : CLIENT3_CK1_RESERVED_SIZE;
      } client3_ck1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client3_ck1_t {
            unsigned int reserved                       : CLIENT3_CK1_RESERVED_SIZE;
      } client3_ck1_t;

#endif

typedef union {
     unsigned int val : 32;
          client3_ck1_t f;
} client3_ck1_u;


/*
 * CLIENT3_CK2 struct
 */

#define CLIENT3_CK2_REG_SIZE         32
#define CLIENT3_CK2_RESERVED_SIZE  32

#define CLIENT3_CK2_RESERVED_SHIFT  0

#define CLIENT3_CK2_RESERVED_MASK       0xffffffff

#define CLIENT3_CK2_MASK \
      (CLIENT3_CK2_RESERVED_MASK)

#define CLIENT3_CK2_DEFAULT            0x00000000

#define CLIENT3_CK2_GET_RESERVED(client3_ck2) \
      ((client3_ck2 & CLIENT3_CK2_RESERVED_MASK) >> CLIENT3_CK2_RESERVED_SHIFT)

#define CLIENT3_CK2_SET_RESERVED(client3_ck2_reg, reserved) \
      client3_ck2_reg = (client3_ck2_reg & ~CLIENT3_CK2_RESERVED_MASK) | (reserved << CLIENT3_CK2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client3_ck2_t {
            unsigned int reserved                       : CLIENT3_CK2_RESERVED_SIZE;
      } client3_ck2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client3_ck2_t {
            unsigned int reserved                       : CLIENT3_CK2_RESERVED_SIZE;
      } client3_ck2_t;

#endif

typedef union {
     unsigned int val : 32;
          client3_ck2_t f;
} client3_ck2_u;


/*
 * CLIENT3_CK3 struct
 */

#define CLIENT3_CK3_REG_SIZE         32
#define CLIENT3_CK3_RESERVED_SIZE  32

#define CLIENT3_CK3_RESERVED_SHIFT  0

#define CLIENT3_CK3_RESERVED_MASK       0xffffffff

#define CLIENT3_CK3_MASK \
      (CLIENT3_CK3_RESERVED_MASK)

#define CLIENT3_CK3_DEFAULT            0x00000000

#define CLIENT3_CK3_GET_RESERVED(client3_ck3) \
      ((client3_ck3 & CLIENT3_CK3_RESERVED_MASK) >> CLIENT3_CK3_RESERVED_SHIFT)

#define CLIENT3_CK3_SET_RESERVED(client3_ck3_reg, reserved) \
      client3_ck3_reg = (client3_ck3_reg & ~CLIENT3_CK3_RESERVED_MASK) | (reserved << CLIENT3_CK3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client3_ck3_t {
            unsigned int reserved                       : CLIENT3_CK3_RESERVED_SIZE;
      } client3_ck3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client3_ck3_t {
            unsigned int reserved                       : CLIENT3_CK3_RESERVED_SIZE;
      } client3_ck3_t;

#endif

typedef union {
     unsigned int val : 32;
          client3_ck3_t f;
} client3_ck3_u;


/*
 * CLIENT3_CD0 struct
 */

#define CLIENT3_CD0_REG_SIZE         32
#define CLIENT3_CD0_RESERVED_SIZE  32

#define CLIENT3_CD0_RESERVED_SHIFT  0

#define CLIENT3_CD0_RESERVED_MASK       0xffffffff

#define CLIENT3_CD0_MASK \
      (CLIENT3_CD0_RESERVED_MASK)

#define CLIENT3_CD0_DEFAULT            0x00000000

#define CLIENT3_CD0_GET_RESERVED(client3_cd0) \
      ((client3_cd0 & CLIENT3_CD0_RESERVED_MASK) >> CLIENT3_CD0_RESERVED_SHIFT)

#define CLIENT3_CD0_SET_RESERVED(client3_cd0_reg, reserved) \
      client3_cd0_reg = (client3_cd0_reg & ~CLIENT3_CD0_RESERVED_MASK) | (reserved << CLIENT3_CD0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client3_cd0_t {
            unsigned int reserved                       : CLIENT3_CD0_RESERVED_SIZE;
      } client3_cd0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client3_cd0_t {
            unsigned int reserved                       : CLIENT3_CD0_RESERVED_SIZE;
      } client3_cd0_t;

#endif

typedef union {
     unsigned int val : 32;
          client3_cd0_t f;
} client3_cd0_u;


/*
 * CLIENT3_CD1 struct
 */

#define CLIENT3_CD1_REG_SIZE         32
#define CLIENT3_CD1_RESERVED_SIZE  32

#define CLIENT3_CD1_RESERVED_SHIFT  0

#define CLIENT3_CD1_RESERVED_MASK       0xffffffff

#define CLIENT3_CD1_MASK \
      (CLIENT3_CD1_RESERVED_MASK)

#define CLIENT3_CD1_DEFAULT            0x00000000

#define CLIENT3_CD1_GET_RESERVED(client3_cd1) \
      ((client3_cd1 & CLIENT3_CD1_RESERVED_MASK) >> CLIENT3_CD1_RESERVED_SHIFT)

#define CLIENT3_CD1_SET_RESERVED(client3_cd1_reg, reserved) \
      client3_cd1_reg = (client3_cd1_reg & ~CLIENT3_CD1_RESERVED_MASK) | (reserved << CLIENT3_CD1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client3_cd1_t {
            unsigned int reserved                       : CLIENT3_CD1_RESERVED_SIZE;
      } client3_cd1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client3_cd1_t {
            unsigned int reserved                       : CLIENT3_CD1_RESERVED_SIZE;
      } client3_cd1_t;

#endif

typedef union {
     unsigned int val : 32;
          client3_cd1_t f;
} client3_cd1_u;


/*
 * CLIENT3_CD2 struct
 */

#define CLIENT3_CD2_REG_SIZE         32
#define CLIENT3_CD2_RESERVED_SIZE  32

#define CLIENT3_CD2_RESERVED_SHIFT  0

#define CLIENT3_CD2_RESERVED_MASK       0xffffffff

#define CLIENT3_CD2_MASK \
      (CLIENT3_CD2_RESERVED_MASK)

#define CLIENT3_CD2_DEFAULT            0x00000000

#define CLIENT3_CD2_GET_RESERVED(client3_cd2) \
      ((client3_cd2 & CLIENT3_CD2_RESERVED_MASK) >> CLIENT3_CD2_RESERVED_SHIFT)

#define CLIENT3_CD2_SET_RESERVED(client3_cd2_reg, reserved) \
      client3_cd2_reg = (client3_cd2_reg & ~CLIENT3_CD2_RESERVED_MASK) | (reserved << CLIENT3_CD2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client3_cd2_t {
            unsigned int reserved                       : CLIENT3_CD2_RESERVED_SIZE;
      } client3_cd2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client3_cd2_t {
            unsigned int reserved                       : CLIENT3_CD2_RESERVED_SIZE;
      } client3_cd2_t;

#endif

typedef union {
     unsigned int val : 32;
          client3_cd2_t f;
} client3_cd2_u;


/*
 * CLIENT3_CD3 struct
 */

#define CLIENT3_CD3_REG_SIZE         32
#define CLIENT3_CD3_RESERVED_SIZE  32

#define CLIENT3_CD3_RESERVED_SHIFT  0

#define CLIENT3_CD3_RESERVED_MASK       0xffffffff

#define CLIENT3_CD3_MASK \
      (CLIENT3_CD3_RESERVED_MASK)

#define CLIENT3_CD3_DEFAULT            0x00000000

#define CLIENT3_CD3_GET_RESERVED(client3_cd3) \
      ((client3_cd3 & CLIENT3_CD3_RESERVED_MASK) >> CLIENT3_CD3_RESERVED_SHIFT)

#define CLIENT3_CD3_SET_RESERVED(client3_cd3_reg, reserved) \
      client3_cd3_reg = (client3_cd3_reg & ~CLIENT3_CD3_RESERVED_MASK) | (reserved << CLIENT3_CD3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client3_cd3_t {
            unsigned int reserved                       : CLIENT3_CD3_RESERVED_SIZE;
      } client3_cd3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client3_cd3_t {
            unsigned int reserved                       : CLIENT3_CD3_RESERVED_SIZE;
      } client3_cd3_t;

#endif

typedef union {
     unsigned int val : 32;
          client3_cd3_t f;
} client3_cd3_u;


/*
 * CLIENT3_BM struct
 */

#define CLIENT3_BM_REG_SIZE         32
#define CLIENT3_BM_RESERVED_SIZE  32

#define CLIENT3_BM_RESERVED_SHIFT  0

#define CLIENT3_BM_RESERVED_MASK        0xffffffff

#define CLIENT3_BM_MASK \
      (CLIENT3_BM_RESERVED_MASK)

#define CLIENT3_BM_DEFAULT             0x00000000

#define CLIENT3_BM_GET_RESERVED(client3_bm) \
      ((client3_bm & CLIENT3_BM_RESERVED_MASK) >> CLIENT3_BM_RESERVED_SHIFT)

#define CLIENT3_BM_SET_RESERVED(client3_bm_reg, reserved) \
      client3_bm_reg = (client3_bm_reg & ~CLIENT3_BM_RESERVED_MASK) | (reserved << CLIENT3_BM_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client3_bm_t {
            unsigned int reserved                       : CLIENT3_BM_RESERVED_SIZE;
      } client3_bm_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client3_bm_t {
            unsigned int reserved                       : CLIENT3_BM_RESERVED_SIZE;
      } client3_bm_t;

#endif

typedef union {
     unsigned int val : 32;
          client3_bm_t f;
} client3_bm_u;


/*
 * CLIENT3_OFFSET struct
 */

#define CLIENT3_OFFSET_REG_SIZE         32
#define CLIENT3_OFFSET_RESERVED_SIZE  32

#define CLIENT3_OFFSET_RESERVED_SHIFT  0

#define CLIENT3_OFFSET_RESERVED_MASK    0xffffffff

#define CLIENT3_OFFSET_MASK \
      (CLIENT3_OFFSET_RESERVED_MASK)

#define CLIENT3_OFFSET_DEFAULT         0x00000000

#define CLIENT3_OFFSET_GET_RESERVED(client3_offset) \
      ((client3_offset & CLIENT3_OFFSET_RESERVED_MASK) >> CLIENT3_OFFSET_RESERVED_SHIFT)

#define CLIENT3_OFFSET_SET_RESERVED(client3_offset_reg, reserved) \
      client3_offset_reg = (client3_offset_reg & ~CLIENT3_OFFSET_RESERVED_MASK) | (reserved << CLIENT3_OFFSET_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client3_offset_t {
            unsigned int reserved                       : CLIENT3_OFFSET_RESERVED_SIZE;
      } client3_offset_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client3_offset_t {
            unsigned int reserved                       : CLIENT3_OFFSET_RESERVED_SIZE;
      } client3_offset_t;

#endif

typedef union {
     unsigned int val : 32;
          client3_offset_t f;
} client3_offset_u;


/*
 * CLIENT3_STATUS struct
 */

#define CLIENT3_STATUS_REG_SIZE         32
#define CLIENT3_STATUS_RESERVED_SIZE  32

#define CLIENT3_STATUS_RESERVED_SHIFT  0

#define CLIENT3_STATUS_RESERVED_MASK    0xffffffff

#define CLIENT3_STATUS_MASK \
      (CLIENT3_STATUS_RESERVED_MASK)

#define CLIENT3_STATUS_DEFAULT         0x00000000

#define CLIENT3_STATUS_GET_RESERVED(client3_status) \
      ((client3_status & CLIENT3_STATUS_RESERVED_MASK) >> CLIENT3_STATUS_RESERVED_SHIFT)

#define CLIENT3_STATUS_SET_RESERVED(client3_status_reg, reserved) \
      client3_status_reg = (client3_status_reg & ~CLIENT3_STATUS_RESERVED_MASK) | (reserved << CLIENT3_STATUS_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client3_status_t {
            unsigned int reserved                       : CLIENT3_STATUS_RESERVED_SIZE;
      } client3_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client3_status_t {
            unsigned int reserved                       : CLIENT3_STATUS_RESERVED_SIZE;
      } client3_status_t;

#endif

typedef union {
     unsigned int val : 32;
          client3_status_t f;
} client3_status_u;


/*
 * CLIENT4_OFFSET_HI struct
 */

#define CLIENT4_OFFSET_HI_REG_SIZE         32
#define CLIENT4_OFFSET_HI_RESERVED_SIZE  32

#define CLIENT4_OFFSET_HI_RESERVED_SHIFT  0

#define CLIENT4_OFFSET_HI_RESERVED_MASK  0xffffffff

#define CLIENT4_OFFSET_HI_MASK \
      (CLIENT4_OFFSET_HI_RESERVED_MASK)

#define CLIENT4_OFFSET_HI_DEFAULT      0x00000000

#define CLIENT4_OFFSET_HI_GET_RESERVED(client4_offset_hi) \
      ((client4_offset_hi & CLIENT4_OFFSET_HI_RESERVED_MASK) >> CLIENT4_OFFSET_HI_RESERVED_SHIFT)

#define CLIENT4_OFFSET_HI_SET_RESERVED(client4_offset_hi_reg, reserved) \
      client4_offset_hi_reg = (client4_offset_hi_reg & ~CLIENT4_OFFSET_HI_RESERVED_MASK) | (reserved << CLIENT4_OFFSET_HI_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client4_offset_hi_t {
            unsigned int reserved                       : CLIENT4_OFFSET_HI_RESERVED_SIZE;
      } client4_offset_hi_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client4_offset_hi_t {
            unsigned int reserved                       : CLIENT4_OFFSET_HI_RESERVED_SIZE;
      } client4_offset_hi_t;

#endif

typedef union {
     unsigned int val : 32;
          client4_offset_hi_t f;
} client4_offset_hi_u;


/*
 * CLIENT4_K0 struct
 */

#define CLIENT4_K0_REG_SIZE         32
#define CLIENT4_K0_RESERVED_SIZE  32

#define CLIENT4_K0_RESERVED_SHIFT  0

#define CLIENT4_K0_RESERVED_MASK        0xffffffff

#define CLIENT4_K0_MASK \
      (CLIENT4_K0_RESERVED_MASK)

#define CLIENT4_K0_DEFAULT             0x00000000

#define CLIENT4_K0_GET_RESERVED(client4_k0) \
      ((client4_k0 & CLIENT4_K0_RESERVED_MASK) >> CLIENT4_K0_RESERVED_SHIFT)

#define CLIENT4_K0_SET_RESERVED(client4_k0_reg, reserved) \
      client4_k0_reg = (client4_k0_reg & ~CLIENT4_K0_RESERVED_MASK) | (reserved << CLIENT4_K0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client4_k0_t {
            unsigned int reserved                       : CLIENT4_K0_RESERVED_SIZE;
      } client4_k0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client4_k0_t {
            unsigned int reserved                       : CLIENT4_K0_RESERVED_SIZE;
      } client4_k0_t;

#endif

typedef union {
     unsigned int val : 32;
          client4_k0_t f;
} client4_k0_u;


/*
 * CLIENT4_K1 struct
 */

#define CLIENT4_K1_REG_SIZE         32
#define CLIENT4_K1_RESERVED_SIZE  32

#define CLIENT4_K1_RESERVED_SHIFT  0

#define CLIENT4_K1_RESERVED_MASK        0xffffffff

#define CLIENT4_K1_MASK \
      (CLIENT4_K1_RESERVED_MASK)

#define CLIENT4_K1_DEFAULT             0x00000000

#define CLIENT4_K1_GET_RESERVED(client4_k1) \
      ((client4_k1 & CLIENT4_K1_RESERVED_MASK) >> CLIENT4_K1_RESERVED_SHIFT)

#define CLIENT4_K1_SET_RESERVED(client4_k1_reg, reserved) \
      client4_k1_reg = (client4_k1_reg & ~CLIENT4_K1_RESERVED_MASK) | (reserved << CLIENT4_K1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client4_k1_t {
            unsigned int reserved                       : CLIENT4_K1_RESERVED_SIZE;
      } client4_k1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client4_k1_t {
            unsigned int reserved                       : CLIENT4_K1_RESERVED_SIZE;
      } client4_k1_t;

#endif

typedef union {
     unsigned int val : 32;
          client4_k1_t f;
} client4_k1_u;


/*
 * CLIENT4_K2 struct
 */

#define CLIENT4_K2_REG_SIZE         32
#define CLIENT4_K2_RESERVED_SIZE  32

#define CLIENT4_K2_RESERVED_SHIFT  0

#define CLIENT4_K2_RESERVED_MASK        0xffffffff

#define CLIENT4_K2_MASK \
      (CLIENT4_K2_RESERVED_MASK)

#define CLIENT4_K2_DEFAULT             0x00000000

#define CLIENT4_K2_GET_RESERVED(client4_k2) \
      ((client4_k2 & CLIENT4_K2_RESERVED_MASK) >> CLIENT4_K2_RESERVED_SHIFT)

#define CLIENT4_K2_SET_RESERVED(client4_k2_reg, reserved) \
      client4_k2_reg = (client4_k2_reg & ~CLIENT4_K2_RESERVED_MASK) | (reserved << CLIENT4_K2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client4_k2_t {
            unsigned int reserved                       : CLIENT4_K2_RESERVED_SIZE;
      } client4_k2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client4_k2_t {
            unsigned int reserved                       : CLIENT4_K2_RESERVED_SIZE;
      } client4_k2_t;

#endif

typedef union {
     unsigned int val : 32;
          client4_k2_t f;
} client4_k2_u;


/*
 * CLIENT4_K3 struct
 */

#define CLIENT4_K3_REG_SIZE         32
#define CLIENT4_K3_RESERVED_SIZE  32

#define CLIENT4_K3_RESERVED_SHIFT  0

#define CLIENT4_K3_RESERVED_MASK        0xffffffff

#define CLIENT4_K3_MASK \
      (CLIENT4_K3_RESERVED_MASK)

#define CLIENT4_K3_DEFAULT             0x00000000

#define CLIENT4_K3_GET_RESERVED(client4_k3) \
      ((client4_k3 & CLIENT4_K3_RESERVED_MASK) >> CLIENT4_K3_RESERVED_SHIFT)

#define CLIENT4_K3_SET_RESERVED(client4_k3_reg, reserved) \
      client4_k3_reg = (client4_k3_reg & ~CLIENT4_K3_RESERVED_MASK) | (reserved << CLIENT4_K3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client4_k3_t {
            unsigned int reserved                       : CLIENT4_K3_RESERVED_SIZE;
      } client4_k3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client4_k3_t {
            unsigned int reserved                       : CLIENT4_K3_RESERVED_SIZE;
      } client4_k3_t;

#endif

typedef union {
     unsigned int val : 32;
          client4_k3_t f;
} client4_k3_u;


/*
 * CLIENT4_CK0 struct
 */

#define CLIENT4_CK0_REG_SIZE         32
#define CLIENT4_CK0_RESERVED_SIZE  32

#define CLIENT4_CK0_RESERVED_SHIFT  0

#define CLIENT4_CK0_RESERVED_MASK       0xffffffff

#define CLIENT4_CK0_MASK \
      (CLIENT4_CK0_RESERVED_MASK)

#define CLIENT4_CK0_DEFAULT            0x00000000

#define CLIENT4_CK0_GET_RESERVED(client4_ck0) \
      ((client4_ck0 & CLIENT4_CK0_RESERVED_MASK) >> CLIENT4_CK0_RESERVED_SHIFT)

#define CLIENT4_CK0_SET_RESERVED(client4_ck0_reg, reserved) \
      client4_ck0_reg = (client4_ck0_reg & ~CLIENT4_CK0_RESERVED_MASK) | (reserved << CLIENT4_CK0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client4_ck0_t {
            unsigned int reserved                       : CLIENT4_CK0_RESERVED_SIZE;
      } client4_ck0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client4_ck0_t {
            unsigned int reserved                       : CLIENT4_CK0_RESERVED_SIZE;
      } client4_ck0_t;

#endif

typedef union {
     unsigned int val : 32;
          client4_ck0_t f;
} client4_ck0_u;


/*
 * CLIENT4_CK1 struct
 */

#define CLIENT4_CK1_REG_SIZE         32
#define CLIENT4_CK1_RESERVED_SIZE  32

#define CLIENT4_CK1_RESERVED_SHIFT  0

#define CLIENT4_CK1_RESERVED_MASK       0xffffffff

#define CLIENT4_CK1_MASK \
      (CLIENT4_CK1_RESERVED_MASK)

#define CLIENT4_CK1_DEFAULT            0x00000000

#define CLIENT4_CK1_GET_RESERVED(client4_ck1) \
      ((client4_ck1 & CLIENT4_CK1_RESERVED_MASK) >> CLIENT4_CK1_RESERVED_SHIFT)

#define CLIENT4_CK1_SET_RESERVED(client4_ck1_reg, reserved) \
      client4_ck1_reg = (client4_ck1_reg & ~CLIENT4_CK1_RESERVED_MASK) | (reserved << CLIENT4_CK1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client4_ck1_t {
            unsigned int reserved                       : CLIENT4_CK1_RESERVED_SIZE;
      } client4_ck1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client4_ck1_t {
            unsigned int reserved                       : CLIENT4_CK1_RESERVED_SIZE;
      } client4_ck1_t;

#endif

typedef union {
     unsigned int val : 32;
          client4_ck1_t f;
} client4_ck1_u;


/*
 * CLIENT4_CK2 struct
 */

#define CLIENT4_CK2_REG_SIZE         32
#define CLIENT4_CK2_RESERVED_SIZE  32

#define CLIENT4_CK2_RESERVED_SHIFT  0

#define CLIENT4_CK2_RESERVED_MASK       0xffffffff

#define CLIENT4_CK2_MASK \
      (CLIENT4_CK2_RESERVED_MASK)

#define CLIENT4_CK2_DEFAULT            0x00000000

#define CLIENT4_CK2_GET_RESERVED(client4_ck2) \
      ((client4_ck2 & CLIENT4_CK2_RESERVED_MASK) >> CLIENT4_CK2_RESERVED_SHIFT)

#define CLIENT4_CK2_SET_RESERVED(client4_ck2_reg, reserved) \
      client4_ck2_reg = (client4_ck2_reg & ~CLIENT4_CK2_RESERVED_MASK) | (reserved << CLIENT4_CK2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client4_ck2_t {
            unsigned int reserved                       : CLIENT4_CK2_RESERVED_SIZE;
      } client4_ck2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client4_ck2_t {
            unsigned int reserved                       : CLIENT4_CK2_RESERVED_SIZE;
      } client4_ck2_t;

#endif

typedef union {
     unsigned int val : 32;
          client4_ck2_t f;
} client4_ck2_u;


/*
 * CLIENT4_CK3 struct
 */

#define CLIENT4_CK3_REG_SIZE         32
#define CLIENT4_CK3_RESERVED_SIZE  32

#define CLIENT4_CK3_RESERVED_SHIFT  0

#define CLIENT4_CK3_RESERVED_MASK       0xffffffff

#define CLIENT4_CK3_MASK \
      (CLIENT4_CK3_RESERVED_MASK)

#define CLIENT4_CK3_DEFAULT            0x00000000

#define CLIENT4_CK3_GET_RESERVED(client4_ck3) \
      ((client4_ck3 & CLIENT4_CK3_RESERVED_MASK) >> CLIENT4_CK3_RESERVED_SHIFT)

#define CLIENT4_CK3_SET_RESERVED(client4_ck3_reg, reserved) \
      client4_ck3_reg = (client4_ck3_reg & ~CLIENT4_CK3_RESERVED_MASK) | (reserved << CLIENT4_CK3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client4_ck3_t {
            unsigned int reserved                       : CLIENT4_CK3_RESERVED_SIZE;
      } client4_ck3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client4_ck3_t {
            unsigned int reserved                       : CLIENT4_CK3_RESERVED_SIZE;
      } client4_ck3_t;

#endif

typedef union {
     unsigned int val : 32;
          client4_ck3_t f;
} client4_ck3_u;


/*
 * CLIENT4_CD0 struct
 */

#define CLIENT4_CD0_REG_SIZE         32
#define CLIENT4_CD0_RESERVED_SIZE  32

#define CLIENT4_CD0_RESERVED_SHIFT  0

#define CLIENT4_CD0_RESERVED_MASK       0xffffffff

#define CLIENT4_CD0_MASK \
      (CLIENT4_CD0_RESERVED_MASK)

#define CLIENT4_CD0_DEFAULT            0x00000000

#define CLIENT4_CD0_GET_RESERVED(client4_cd0) \
      ((client4_cd0 & CLIENT4_CD0_RESERVED_MASK) >> CLIENT4_CD0_RESERVED_SHIFT)

#define CLIENT4_CD0_SET_RESERVED(client4_cd0_reg, reserved) \
      client4_cd0_reg = (client4_cd0_reg & ~CLIENT4_CD0_RESERVED_MASK) | (reserved << CLIENT4_CD0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client4_cd0_t {
            unsigned int reserved                       : CLIENT4_CD0_RESERVED_SIZE;
      } client4_cd0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client4_cd0_t {
            unsigned int reserved                       : CLIENT4_CD0_RESERVED_SIZE;
      } client4_cd0_t;

#endif

typedef union {
     unsigned int val : 32;
          client4_cd0_t f;
} client4_cd0_u;


/*
 * CLIENT4_CD1 struct
 */

#define CLIENT4_CD1_REG_SIZE         32
#define CLIENT4_CD1_RESERVED_SIZE  32

#define CLIENT4_CD1_RESERVED_SHIFT  0

#define CLIENT4_CD1_RESERVED_MASK       0xffffffff

#define CLIENT4_CD1_MASK \
      (CLIENT4_CD1_RESERVED_MASK)

#define CLIENT4_CD1_DEFAULT            0x00000000

#define CLIENT4_CD1_GET_RESERVED(client4_cd1) \
      ((client4_cd1 & CLIENT4_CD1_RESERVED_MASK) >> CLIENT4_CD1_RESERVED_SHIFT)

#define CLIENT4_CD1_SET_RESERVED(client4_cd1_reg, reserved) \
      client4_cd1_reg = (client4_cd1_reg & ~CLIENT4_CD1_RESERVED_MASK) | (reserved << CLIENT4_CD1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client4_cd1_t {
            unsigned int reserved                       : CLIENT4_CD1_RESERVED_SIZE;
      } client4_cd1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client4_cd1_t {
            unsigned int reserved                       : CLIENT4_CD1_RESERVED_SIZE;
      } client4_cd1_t;

#endif

typedef union {
     unsigned int val : 32;
          client4_cd1_t f;
} client4_cd1_u;


/*
 * CLIENT4_CD2 struct
 */

#define CLIENT4_CD2_REG_SIZE         32
#define CLIENT4_CD2_RESERVED_SIZE  32

#define CLIENT4_CD2_RESERVED_SHIFT  0

#define CLIENT4_CD2_RESERVED_MASK       0xffffffff

#define CLIENT4_CD2_MASK \
      (CLIENT4_CD2_RESERVED_MASK)

#define CLIENT4_CD2_DEFAULT            0x00000000

#define CLIENT4_CD2_GET_RESERVED(client4_cd2) \
      ((client4_cd2 & CLIENT4_CD2_RESERVED_MASK) >> CLIENT4_CD2_RESERVED_SHIFT)

#define CLIENT4_CD2_SET_RESERVED(client4_cd2_reg, reserved) \
      client4_cd2_reg = (client4_cd2_reg & ~CLIENT4_CD2_RESERVED_MASK) | (reserved << CLIENT4_CD2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client4_cd2_t {
            unsigned int reserved                       : CLIENT4_CD2_RESERVED_SIZE;
      } client4_cd2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client4_cd2_t {
            unsigned int reserved                       : CLIENT4_CD2_RESERVED_SIZE;
      } client4_cd2_t;

#endif

typedef union {
     unsigned int val : 32;
          client4_cd2_t f;
} client4_cd2_u;


/*
 * CLIENT4_CD3 struct
 */

#define CLIENT4_CD3_REG_SIZE         32
#define CLIENT4_CD3_RESERVED_SIZE  32

#define CLIENT4_CD3_RESERVED_SHIFT  0

#define CLIENT4_CD3_RESERVED_MASK       0xffffffff

#define CLIENT4_CD3_MASK \
      (CLIENT4_CD3_RESERVED_MASK)

#define CLIENT4_CD3_DEFAULT            0x00000000

#define CLIENT4_CD3_GET_RESERVED(client4_cd3) \
      ((client4_cd3 & CLIENT4_CD3_RESERVED_MASK) >> CLIENT4_CD3_RESERVED_SHIFT)

#define CLIENT4_CD3_SET_RESERVED(client4_cd3_reg, reserved) \
      client4_cd3_reg = (client4_cd3_reg & ~CLIENT4_CD3_RESERVED_MASK) | (reserved << CLIENT4_CD3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client4_cd3_t {
            unsigned int reserved                       : CLIENT4_CD3_RESERVED_SIZE;
      } client4_cd3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client4_cd3_t {
            unsigned int reserved                       : CLIENT4_CD3_RESERVED_SIZE;
      } client4_cd3_t;

#endif

typedef union {
     unsigned int val : 32;
          client4_cd3_t f;
} client4_cd3_u;


/*
 * CLIENT4_BM struct
 */

#define CLIENT4_BM_REG_SIZE         32
#define CLIENT4_BM_RESERVED_SIZE  32

#define CLIENT4_BM_RESERVED_SHIFT  0

#define CLIENT4_BM_RESERVED_MASK        0xffffffff

#define CLIENT4_BM_MASK \
      (CLIENT4_BM_RESERVED_MASK)

#define CLIENT4_BM_DEFAULT             0x00000000

#define CLIENT4_BM_GET_RESERVED(client4_bm) \
      ((client4_bm & CLIENT4_BM_RESERVED_MASK) >> CLIENT4_BM_RESERVED_SHIFT)

#define CLIENT4_BM_SET_RESERVED(client4_bm_reg, reserved) \
      client4_bm_reg = (client4_bm_reg & ~CLIENT4_BM_RESERVED_MASK) | (reserved << CLIENT4_BM_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client4_bm_t {
            unsigned int reserved                       : CLIENT4_BM_RESERVED_SIZE;
      } client4_bm_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client4_bm_t {
            unsigned int reserved                       : CLIENT4_BM_RESERVED_SIZE;
      } client4_bm_t;

#endif

typedef union {
     unsigned int val : 32;
          client4_bm_t f;
} client4_bm_u;


/*
 * CLIENT4_OFFSET struct
 */

#define CLIENT4_OFFSET_REG_SIZE         32
#define CLIENT4_OFFSET_RESERVED_SIZE  32

#define CLIENT4_OFFSET_RESERVED_SHIFT  0

#define CLIENT4_OFFSET_RESERVED_MASK    0xffffffff

#define CLIENT4_OFFSET_MASK \
      (CLIENT4_OFFSET_RESERVED_MASK)

#define CLIENT4_OFFSET_DEFAULT         0x00000000

#define CLIENT4_OFFSET_GET_RESERVED(client4_offset) \
      ((client4_offset & CLIENT4_OFFSET_RESERVED_MASK) >> CLIENT4_OFFSET_RESERVED_SHIFT)

#define CLIENT4_OFFSET_SET_RESERVED(client4_offset_reg, reserved) \
      client4_offset_reg = (client4_offset_reg & ~CLIENT4_OFFSET_RESERVED_MASK) | (reserved << CLIENT4_OFFSET_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client4_offset_t {
            unsigned int reserved                       : CLIENT4_OFFSET_RESERVED_SIZE;
      } client4_offset_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client4_offset_t {
            unsigned int reserved                       : CLIENT4_OFFSET_RESERVED_SIZE;
      } client4_offset_t;

#endif

typedef union {
     unsigned int val : 32;
          client4_offset_t f;
} client4_offset_u;


/*
 * CLIENT4_STATUS struct
 */

#define CLIENT4_STATUS_REG_SIZE         32
#define CLIENT4_STATUS_RESERVED_SIZE  32

#define CLIENT4_STATUS_RESERVED_SHIFT  0

#define CLIENT4_STATUS_RESERVED_MASK    0xffffffff

#define CLIENT4_STATUS_MASK \
      (CLIENT4_STATUS_RESERVED_MASK)

#define CLIENT4_STATUS_DEFAULT         0x00000000

#define CLIENT4_STATUS_GET_RESERVED(client4_status) \
      ((client4_status & CLIENT4_STATUS_RESERVED_MASK) >> CLIENT4_STATUS_RESERVED_SHIFT)

#define CLIENT4_STATUS_SET_RESERVED(client4_status_reg, reserved) \
      client4_status_reg = (client4_status_reg & ~CLIENT4_STATUS_RESERVED_MASK) | (reserved << CLIENT4_STATUS_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct client4_status_t {
            unsigned int reserved                       : CLIENT4_STATUS_RESERVED_SIZE;
      } client4_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct client4_status_t {
            unsigned int reserved                       : CLIENT4_STATUS_RESERVED_SIZE;
      } client4_status_t;

#endif

typedef union {
     unsigned int val : 32;
          client4_status_t f;
} client4_status_u;


/*
 * DC_TEST_DEBUG_INDEX struct
 */

#define DC_TEST_DEBUG_INDEX_REG_SIZE         32
#define DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_INDEX_SIZE  8
#define DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_WRITE_EN_SIZE  1

#define DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_INDEX_SHIFT  0
#define DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_WRITE_EN_SHIFT  8

#define DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_INDEX_MASK  0x000000ff
#define DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_WRITE_EN_MASK  0x00000100

#define DC_TEST_DEBUG_INDEX_MASK \
      (DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_INDEX_MASK | \
      DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_WRITE_EN_MASK)

#define DC_TEST_DEBUG_INDEX_DEFAULT    0x00000000

#define DC_TEST_DEBUG_INDEX_GET_DC_TEST_DEBUG_INDEX(dc_test_debug_index) \
      ((dc_test_debug_index & DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_INDEX_MASK) >> DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_INDEX_SHIFT)
#define DC_TEST_DEBUG_INDEX_GET_DC_TEST_DEBUG_WRITE_EN(dc_test_debug_index) \
      ((dc_test_debug_index & DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_WRITE_EN_MASK) >> DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_WRITE_EN_SHIFT)

#define DC_TEST_DEBUG_INDEX_SET_DC_TEST_DEBUG_INDEX(dc_test_debug_index_reg, dc_test_debug_index) \
      dc_test_debug_index_reg = (dc_test_debug_index_reg & ~DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_INDEX_MASK) | (dc_test_debug_index << DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_INDEX_SHIFT)
#define DC_TEST_DEBUG_INDEX_SET_DC_TEST_DEBUG_WRITE_EN(dc_test_debug_index_reg, dc_test_debug_write_en) \
      dc_test_debug_index_reg = (dc_test_debug_index_reg & ~DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_WRITE_EN_MASK) | (dc_test_debug_write_en << DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_WRITE_EN_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct dc_test_debug_index_t {
            unsigned int dc_test_debug_index            : DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_INDEX_SIZE;
            unsigned int dc_test_debug_write_en         : DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_WRITE_EN_SIZE;
            unsigned int                                : 23;
      } dc_test_debug_index_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct dc_test_debug_index_t {
            unsigned int                                : 23;
            unsigned int dc_test_debug_write_en         : DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_WRITE_EN_SIZE;
            unsigned int dc_test_debug_index            : DC_TEST_DEBUG_INDEX_DC_TEST_DEBUG_INDEX_SIZE;
      } dc_test_debug_index_t;

#endif

typedef union {
     unsigned int val : 32;
          dc_test_debug_index_t f;
} dc_test_debug_index_u;


/*
 * DC_TEST_DEBUG_DATA struct
 */

#define DC_TEST_DEBUG_DATA_REG_SIZE         32
#define DC_TEST_DEBUG_DATA_DC_TEST_DEBUG_DATA_SIZE  32

#define DC_TEST_DEBUG_DATA_DC_TEST_DEBUG_DATA_SHIFT  0

#define DC_TEST_DEBUG_DATA_DC_TEST_DEBUG_DATA_MASK  0xffffffff

#define DC_TEST_DEBUG_DATA_MASK \
      (DC_TEST_DEBUG_DATA_DC_TEST_DEBUG_DATA_MASK)

#define DC_TEST_DEBUG_DATA_DEFAULT     0x00000000

#define DC_TEST_DEBUG_DATA_GET_DC_TEST_DEBUG_DATA(dc_test_debug_data) \
      ((dc_test_debug_data & DC_TEST_DEBUG_DATA_DC_TEST_DEBUG_DATA_MASK) >> DC_TEST_DEBUG_DATA_DC_TEST_DEBUG_DATA_SHIFT)

#define DC_TEST_DEBUG_DATA_SET_DC_TEST_DEBUG_DATA(dc_test_debug_data_reg, dc_test_debug_data) \
      dc_test_debug_data_reg = (dc_test_debug_data_reg & ~DC_TEST_DEBUG_DATA_DC_TEST_DEBUG_DATA_MASK) | (dc_test_debug_data << DC_TEST_DEBUG_DATA_DC_TEST_DEBUG_DATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct dc_test_debug_data_t {
            unsigned int dc_test_debug_data             : DC_TEST_DEBUG_DATA_DC_TEST_DEBUG_DATA_SIZE;
      } dc_test_debug_data_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct dc_test_debug_data_t {
            unsigned int dc_test_debug_data             : DC_TEST_DEBUG_DATA_DC_TEST_DEBUG_DATA_SIZE;
      } dc_test_debug_data_t;

#endif

typedef union {
     unsigned int val : 32;
          dc_test_debug_data_t f;
} dc_test_debug_data_u;


/*
 * DRM_CNT_KEY_STATUS struct
 */

#define DRM_CNT_KEY_STATUS_REG_SIZE         32
#define DRM_CNT_KEY_STATUS_CLIENT0_SIZE  1
#define DRM_CNT_KEY_STATUS_CLIENT1_SIZE  1
#define DRM_CNT_KEY_STATUS_CLIENT2_SIZE  1
#define DRM_CNT_KEY_STATUS_CLIENT3_SIZE  1
#define DRM_CNT_KEY_STATUS_CLIENT4_SIZE  1

#define DRM_CNT_KEY_STATUS_CLIENT0_SHIFT  0
#define DRM_CNT_KEY_STATUS_CLIENT1_SHIFT  1
#define DRM_CNT_KEY_STATUS_CLIENT2_SHIFT  2
#define DRM_CNT_KEY_STATUS_CLIENT3_SHIFT  3
#define DRM_CNT_KEY_STATUS_CLIENT4_SHIFT  4

#define DRM_CNT_KEY_STATUS_CLIENT0_MASK  0x00000001
#define DRM_CNT_KEY_STATUS_CLIENT1_MASK  0x00000002
#define DRM_CNT_KEY_STATUS_CLIENT2_MASK  0x00000004
#define DRM_CNT_KEY_STATUS_CLIENT3_MASK  0x00000008
#define DRM_CNT_KEY_STATUS_CLIENT4_MASK  0x00000010

#define DRM_CNT_KEY_STATUS_MASK \
      (DRM_CNT_KEY_STATUS_CLIENT0_MASK | \
      DRM_CNT_KEY_STATUS_CLIENT1_MASK | \
      DRM_CNT_KEY_STATUS_CLIENT2_MASK | \
      DRM_CNT_KEY_STATUS_CLIENT3_MASK | \
      DRM_CNT_KEY_STATUS_CLIENT4_MASK)

#define DRM_CNT_KEY_STATUS_DEFAULT     0x0000001f

#define DRM_CNT_KEY_STATUS_GET_CLIENT0(drm_cnt_key_status) \
      ((drm_cnt_key_status & DRM_CNT_KEY_STATUS_CLIENT0_MASK) >> DRM_CNT_KEY_STATUS_CLIENT0_SHIFT)
#define DRM_CNT_KEY_STATUS_GET_CLIENT1(drm_cnt_key_status) \
      ((drm_cnt_key_status & DRM_CNT_KEY_STATUS_CLIENT1_MASK) >> DRM_CNT_KEY_STATUS_CLIENT1_SHIFT)
#define DRM_CNT_KEY_STATUS_GET_CLIENT2(drm_cnt_key_status) \
      ((drm_cnt_key_status & DRM_CNT_KEY_STATUS_CLIENT2_MASK) >> DRM_CNT_KEY_STATUS_CLIENT2_SHIFT)
#define DRM_CNT_KEY_STATUS_GET_CLIENT3(drm_cnt_key_status) \
      ((drm_cnt_key_status & DRM_CNT_KEY_STATUS_CLIENT3_MASK) >> DRM_CNT_KEY_STATUS_CLIENT3_SHIFT)
#define DRM_CNT_KEY_STATUS_GET_CLIENT4(drm_cnt_key_status) \
      ((drm_cnt_key_status & DRM_CNT_KEY_STATUS_CLIENT4_MASK) >> DRM_CNT_KEY_STATUS_CLIENT4_SHIFT)

#define DRM_CNT_KEY_STATUS_SET_CLIENT0(drm_cnt_key_status_reg, client0) \
      drm_cnt_key_status_reg = (drm_cnt_key_status_reg & ~DRM_CNT_KEY_STATUS_CLIENT0_MASK) | (client0 << DRM_CNT_KEY_STATUS_CLIENT0_SHIFT)
#define DRM_CNT_KEY_STATUS_SET_CLIENT1(drm_cnt_key_status_reg, client1) \
      drm_cnt_key_status_reg = (drm_cnt_key_status_reg & ~DRM_CNT_KEY_STATUS_CLIENT1_MASK) | (client1 << DRM_CNT_KEY_STATUS_CLIENT1_SHIFT)
#define DRM_CNT_KEY_STATUS_SET_CLIENT2(drm_cnt_key_status_reg, client2) \
      drm_cnt_key_status_reg = (drm_cnt_key_status_reg & ~DRM_CNT_KEY_STATUS_CLIENT2_MASK) | (client2 << DRM_CNT_KEY_STATUS_CLIENT2_SHIFT)
#define DRM_CNT_KEY_STATUS_SET_CLIENT3(drm_cnt_key_status_reg, client3) \
      drm_cnt_key_status_reg = (drm_cnt_key_status_reg & ~DRM_CNT_KEY_STATUS_CLIENT3_MASK) | (client3 << DRM_CNT_KEY_STATUS_CLIENT3_SHIFT)
#define DRM_CNT_KEY_STATUS_SET_CLIENT4(drm_cnt_key_status_reg, client4) \
      drm_cnt_key_status_reg = (drm_cnt_key_status_reg & ~DRM_CNT_KEY_STATUS_CLIENT4_MASK) | (client4 << DRM_CNT_KEY_STATUS_CLIENT4_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_cnt_key_status_t {
            unsigned int client0                        : DRM_CNT_KEY_STATUS_CLIENT0_SIZE;
            unsigned int client1                        : DRM_CNT_KEY_STATUS_CLIENT1_SIZE;
            unsigned int client2                        : DRM_CNT_KEY_STATUS_CLIENT2_SIZE;
            unsigned int client3                        : DRM_CNT_KEY_STATUS_CLIENT3_SIZE;
            unsigned int client4                        : DRM_CNT_KEY_STATUS_CLIENT4_SIZE;
            unsigned int                                : 27;
      } drm_cnt_key_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_cnt_key_status_t {
            unsigned int                                : 27;
            unsigned int client4                        : DRM_CNT_KEY_STATUS_CLIENT4_SIZE;
            unsigned int client3                        : DRM_CNT_KEY_STATUS_CLIENT3_SIZE;
            unsigned int client2                        : DRM_CNT_KEY_STATUS_CLIENT2_SIZE;
            unsigned int client1                        : DRM_CNT_KEY_STATUS_CLIENT1_SIZE;
            unsigned int client0                        : DRM_CNT_KEY_STATUS_CLIENT0_SIZE;
      } drm_cnt_key_status_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_cnt_key_status_t f;
} drm_cnt_key_status_u;


/*
 * DRM_CLIENT4_EXT struct
 */

#define DRM_CLIENT4_EXT_REG_SIZE         32
#define DRM_CLIENT4_EXT_CLIENT4_TIMEOUT_SIZE  8
#define DRM_CLIENT4_EXT_CLIENT4_BUSY_SIZE  1
#define DRM_CLIENT4_EXT_DRM_INIT_SESSION_4_SIZE  1
#define DRM_CLIENT4_EXT_CLIENT4_PARSE_BUSY_SIZE  1

#define DRM_CLIENT4_EXT_CLIENT4_TIMEOUT_SHIFT  0
#define DRM_CLIENT4_EXT_CLIENT4_BUSY_SHIFT  8
#define DRM_CLIENT4_EXT_DRM_INIT_SESSION_4_SHIFT  9
#define DRM_CLIENT4_EXT_CLIENT4_PARSE_BUSY_SHIFT  10

#define DRM_CLIENT4_EXT_CLIENT4_TIMEOUT_MASK  0x000000ff
#define DRM_CLIENT4_EXT_CLIENT4_BUSY_MASK  0x00000100
#define DRM_CLIENT4_EXT_DRM_INIT_SESSION_4_MASK  0x00000200
#define DRM_CLIENT4_EXT_CLIENT4_PARSE_BUSY_MASK  0x00000400

#define DRM_CLIENT4_EXT_MASK \
      (DRM_CLIENT4_EXT_CLIENT4_TIMEOUT_MASK | \
      DRM_CLIENT4_EXT_CLIENT4_BUSY_MASK | \
      DRM_CLIENT4_EXT_DRM_INIT_SESSION_4_MASK | \
      DRM_CLIENT4_EXT_CLIENT4_PARSE_BUSY_MASK)

#define DRM_CLIENT4_EXT_DEFAULT        0x000000ff

#define DRM_CLIENT4_EXT_GET_CLIENT4_TIMEOUT(drm_client4_ext) \
      ((drm_client4_ext & DRM_CLIENT4_EXT_CLIENT4_TIMEOUT_MASK) >> DRM_CLIENT4_EXT_CLIENT4_TIMEOUT_SHIFT)
#define DRM_CLIENT4_EXT_GET_CLIENT4_BUSY(drm_client4_ext) \
      ((drm_client4_ext & DRM_CLIENT4_EXT_CLIENT4_BUSY_MASK) >> DRM_CLIENT4_EXT_CLIENT4_BUSY_SHIFT)
#define DRM_CLIENT4_EXT_GET_DRM_INIT_SESSION_4(drm_client4_ext) \
      ((drm_client4_ext & DRM_CLIENT4_EXT_DRM_INIT_SESSION_4_MASK) >> DRM_CLIENT4_EXT_DRM_INIT_SESSION_4_SHIFT)
#define DRM_CLIENT4_EXT_GET_CLIENT4_PARSE_BUSY(drm_client4_ext) \
      ((drm_client4_ext & DRM_CLIENT4_EXT_CLIENT4_PARSE_BUSY_MASK) >> DRM_CLIENT4_EXT_CLIENT4_PARSE_BUSY_SHIFT)

#define DRM_CLIENT4_EXT_SET_CLIENT4_TIMEOUT(drm_client4_ext_reg, client4_timeout) \
      drm_client4_ext_reg = (drm_client4_ext_reg & ~DRM_CLIENT4_EXT_CLIENT4_TIMEOUT_MASK) | (client4_timeout << DRM_CLIENT4_EXT_CLIENT4_TIMEOUT_SHIFT)
#define DRM_CLIENT4_EXT_SET_CLIENT4_BUSY(drm_client4_ext_reg, client4_busy) \
      drm_client4_ext_reg = (drm_client4_ext_reg & ~DRM_CLIENT4_EXT_CLIENT4_BUSY_MASK) | (client4_busy << DRM_CLIENT4_EXT_CLIENT4_BUSY_SHIFT)
#define DRM_CLIENT4_EXT_SET_DRM_INIT_SESSION_4(drm_client4_ext_reg, drm_init_session_4) \
      drm_client4_ext_reg = (drm_client4_ext_reg & ~DRM_CLIENT4_EXT_DRM_INIT_SESSION_4_MASK) | (drm_init_session_4 << DRM_CLIENT4_EXT_DRM_INIT_SESSION_4_SHIFT)
#define DRM_CLIENT4_EXT_SET_CLIENT4_PARSE_BUSY(drm_client4_ext_reg, client4_parse_busy) \
      drm_client4_ext_reg = (drm_client4_ext_reg & ~DRM_CLIENT4_EXT_CLIENT4_PARSE_BUSY_MASK) | (client4_parse_busy << DRM_CLIENT4_EXT_CLIENT4_PARSE_BUSY_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_client4_ext_t {
            unsigned int client4_timeout                : DRM_CLIENT4_EXT_CLIENT4_TIMEOUT_SIZE;
            unsigned int client4_busy                   : DRM_CLIENT4_EXT_CLIENT4_BUSY_SIZE;
            unsigned int drm_init_session_4             : DRM_CLIENT4_EXT_DRM_INIT_SESSION_4_SIZE;
            unsigned int client4_parse_busy             : DRM_CLIENT4_EXT_CLIENT4_PARSE_BUSY_SIZE;
            unsigned int                                : 21;
      } drm_client4_ext_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_client4_ext_t {
            unsigned int                                : 21;
            unsigned int client4_parse_busy             : DRM_CLIENT4_EXT_CLIENT4_PARSE_BUSY_SIZE;
            unsigned int drm_init_session_4             : DRM_CLIENT4_EXT_DRM_INIT_SESSION_4_SIZE;
            unsigned int client4_busy                   : DRM_CLIENT4_EXT_CLIENT4_BUSY_SIZE;
            unsigned int client4_timeout                : DRM_CLIENT4_EXT_CLIENT4_TIMEOUT_SIZE;
      } drm_client4_ext_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_client4_ext_t f;
} drm_client4_ext_u;


/*
 * DRM_DEBUG_INDEX0 struct
 */

#define DRM_DEBUG_INDEX0_REG_SIZE         32
#define DRM_DEBUG_INDEX0_DRM_DEBUG_INDEX_SIZE  32

#define DRM_DEBUG_INDEX0_DRM_DEBUG_INDEX_SHIFT  0

#define DRM_DEBUG_INDEX0_DRM_DEBUG_INDEX_MASK  0xffffffff

#define DRM_DEBUG_INDEX0_MASK \
      (DRM_DEBUG_INDEX0_DRM_DEBUG_INDEX_MASK)

#define DRM_DEBUG_INDEX0_DEFAULT       0x00000000

#define DRM_DEBUG_INDEX0_GET_DRM_DEBUG_INDEX(drm_debug_index0) \
      ((drm_debug_index0 & DRM_DEBUG_INDEX0_DRM_DEBUG_INDEX_MASK) >> DRM_DEBUG_INDEX0_DRM_DEBUG_INDEX_SHIFT)

#define DRM_DEBUG_INDEX0_SET_DRM_DEBUG_INDEX(drm_debug_index0_reg, drm_debug_index) \
      drm_debug_index0_reg = (drm_debug_index0_reg & ~DRM_DEBUG_INDEX0_DRM_DEBUG_INDEX_MASK) | (drm_debug_index << DRM_DEBUG_INDEX0_DRM_DEBUG_INDEX_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_debug_index0_t {
            unsigned int drm_debug_index                : DRM_DEBUG_INDEX0_DRM_DEBUG_INDEX_SIZE;
      } drm_debug_index0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_debug_index0_t {
            unsigned int drm_debug_index                : DRM_DEBUG_INDEX0_DRM_DEBUG_INDEX_SIZE;
      } drm_debug_index0_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_debug_index0_t f;
} drm_debug_index0_u;


/*
 * DRM_DEBUG_INDEX1 struct
 */

#define DRM_DEBUG_INDEX1_REG_SIZE         32
#define DRM_DEBUG_INDEX1_DRM_DEBUG_INDEX_SIZE  32

#define DRM_DEBUG_INDEX1_DRM_DEBUG_INDEX_SHIFT  0

#define DRM_DEBUG_INDEX1_DRM_DEBUG_INDEX_MASK  0xffffffff

#define DRM_DEBUG_INDEX1_MASK \
      (DRM_DEBUG_INDEX1_DRM_DEBUG_INDEX_MASK)

#define DRM_DEBUG_INDEX1_DEFAULT       0x00000000

#define DRM_DEBUG_INDEX1_GET_DRM_DEBUG_INDEX(drm_debug_index1) \
      ((drm_debug_index1 & DRM_DEBUG_INDEX1_DRM_DEBUG_INDEX_MASK) >> DRM_DEBUG_INDEX1_DRM_DEBUG_INDEX_SHIFT)

#define DRM_DEBUG_INDEX1_SET_DRM_DEBUG_INDEX(drm_debug_index1_reg, drm_debug_index) \
      drm_debug_index1_reg = (drm_debug_index1_reg & ~DRM_DEBUG_INDEX1_DRM_DEBUG_INDEX_MASK) | (drm_debug_index << DRM_DEBUG_INDEX1_DRM_DEBUG_INDEX_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_debug_index1_t {
            unsigned int drm_debug_index                : DRM_DEBUG_INDEX1_DRM_DEBUG_INDEX_SIZE;
      } drm_debug_index1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_debug_index1_t {
            unsigned int drm_debug_index                : DRM_DEBUG_INDEX1_DRM_DEBUG_INDEX_SIZE;
      } drm_debug_index1_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_debug_index1_t f;
} drm_debug_index1_u;


/*
 * DRM_DEBUG_INDEX2 struct
 */

#define DRM_DEBUG_INDEX2_REG_SIZE         32
#define DRM_DEBUG_INDEX2_DRM_DEBUG_INDEX_SIZE  32

#define DRM_DEBUG_INDEX2_DRM_DEBUG_INDEX_SHIFT  0

#define DRM_DEBUG_INDEX2_DRM_DEBUG_INDEX_MASK  0xffffffff

#define DRM_DEBUG_INDEX2_MASK \
      (DRM_DEBUG_INDEX2_DRM_DEBUG_INDEX_MASK)

#define DRM_DEBUG_INDEX2_DEFAULT       0x00000000

#define DRM_DEBUG_INDEX2_GET_DRM_DEBUG_INDEX(drm_debug_index2) \
      ((drm_debug_index2 & DRM_DEBUG_INDEX2_DRM_DEBUG_INDEX_MASK) >> DRM_DEBUG_INDEX2_DRM_DEBUG_INDEX_SHIFT)

#define DRM_DEBUG_INDEX2_SET_DRM_DEBUG_INDEX(drm_debug_index2_reg, drm_debug_index) \
      drm_debug_index2_reg = (drm_debug_index2_reg & ~DRM_DEBUG_INDEX2_DRM_DEBUG_INDEX_MASK) | (drm_debug_index << DRM_DEBUG_INDEX2_DRM_DEBUG_INDEX_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_debug_index2_t {
            unsigned int drm_debug_index                : DRM_DEBUG_INDEX2_DRM_DEBUG_INDEX_SIZE;
      } drm_debug_index2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_debug_index2_t {
            unsigned int drm_debug_index                : DRM_DEBUG_INDEX2_DRM_DEBUG_INDEX_SIZE;
      } drm_debug_index2_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_debug_index2_t f;
} drm_debug_index2_u;


/*
 * DRM_DEBUG_INDEX3 struct
 */

#define DRM_DEBUG_INDEX3_REG_SIZE         32
#define DRM_DEBUG_INDEX3_DRM_DEBUG_INDEX_SIZE  32

#define DRM_DEBUG_INDEX3_DRM_DEBUG_INDEX_SHIFT  0

#define DRM_DEBUG_INDEX3_DRM_DEBUG_INDEX_MASK  0xffffffff

#define DRM_DEBUG_INDEX3_MASK \
      (DRM_DEBUG_INDEX3_DRM_DEBUG_INDEX_MASK)

#define DRM_DEBUG_INDEX3_DEFAULT       0x00000000

#define DRM_DEBUG_INDEX3_GET_DRM_DEBUG_INDEX(drm_debug_index3) \
      ((drm_debug_index3 & DRM_DEBUG_INDEX3_DRM_DEBUG_INDEX_MASK) >> DRM_DEBUG_INDEX3_DRM_DEBUG_INDEX_SHIFT)

#define DRM_DEBUG_INDEX3_SET_DRM_DEBUG_INDEX(drm_debug_index3_reg, drm_debug_index) \
      drm_debug_index3_reg = (drm_debug_index3_reg & ~DRM_DEBUG_INDEX3_DRM_DEBUG_INDEX_MASK) | (drm_debug_index << DRM_DEBUG_INDEX3_DRM_DEBUG_INDEX_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_debug_index3_t {
            unsigned int drm_debug_index                : DRM_DEBUG_INDEX3_DRM_DEBUG_INDEX_SIZE;
      } drm_debug_index3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_debug_index3_t {
            unsigned int drm_debug_index                : DRM_DEBUG_INDEX3_DRM_DEBUG_INDEX_SIZE;
      } drm_debug_index3_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_debug_index3_t f;
} drm_debug_index3_u;


/*
 * DRM_DEBUG_INDEX4 struct
 */

#define DRM_DEBUG_INDEX4_REG_SIZE         32
#define DRM_DEBUG_INDEX4_DRM_DEBUG_INDEX_SIZE  32

#define DRM_DEBUG_INDEX4_DRM_DEBUG_INDEX_SHIFT  0

#define DRM_DEBUG_INDEX4_DRM_DEBUG_INDEX_MASK  0xffffffff

#define DRM_DEBUG_INDEX4_MASK \
      (DRM_DEBUG_INDEX4_DRM_DEBUG_INDEX_MASK)

#define DRM_DEBUG_INDEX4_DEFAULT       0x00000000

#define DRM_DEBUG_INDEX4_GET_DRM_DEBUG_INDEX(drm_debug_index4) \
      ((drm_debug_index4 & DRM_DEBUG_INDEX4_DRM_DEBUG_INDEX_MASK) >> DRM_DEBUG_INDEX4_DRM_DEBUG_INDEX_SHIFT)

#define DRM_DEBUG_INDEX4_SET_DRM_DEBUG_INDEX(drm_debug_index4_reg, drm_debug_index) \
      drm_debug_index4_reg = (drm_debug_index4_reg & ~DRM_DEBUG_INDEX4_DRM_DEBUG_INDEX_MASK) | (drm_debug_index << DRM_DEBUG_INDEX4_DRM_DEBUG_INDEX_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_debug_index4_t {
            unsigned int drm_debug_index                : DRM_DEBUG_INDEX4_DRM_DEBUG_INDEX_SIZE;
      } drm_debug_index4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_debug_index4_t {
            unsigned int drm_debug_index                : DRM_DEBUG_INDEX4_DRM_DEBUG_INDEX_SIZE;
      } drm_debug_index4_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_debug_index4_t f;
} drm_debug_index4_u;


/*
 * DRM_DEBUG_INDEX5 struct
 */

#define DRM_DEBUG_INDEX5_REG_SIZE         32
#define DRM_DEBUG_INDEX5_DRM_DEBUG_INDEX_SIZE  32

#define DRM_DEBUG_INDEX5_DRM_DEBUG_INDEX_SHIFT  0

#define DRM_DEBUG_INDEX5_DRM_DEBUG_INDEX_MASK  0xffffffff

#define DRM_DEBUG_INDEX5_MASK \
      (DRM_DEBUG_INDEX5_DRM_DEBUG_INDEX_MASK)

#define DRM_DEBUG_INDEX5_DEFAULT       0x00000000

#define DRM_DEBUG_INDEX5_GET_DRM_DEBUG_INDEX(drm_debug_index5) \
      ((drm_debug_index5 & DRM_DEBUG_INDEX5_DRM_DEBUG_INDEX_MASK) >> DRM_DEBUG_INDEX5_DRM_DEBUG_INDEX_SHIFT)

#define DRM_DEBUG_INDEX5_SET_DRM_DEBUG_INDEX(drm_debug_index5_reg, drm_debug_index) \
      drm_debug_index5_reg = (drm_debug_index5_reg & ~DRM_DEBUG_INDEX5_DRM_DEBUG_INDEX_MASK) | (drm_debug_index << DRM_DEBUG_INDEX5_DRM_DEBUG_INDEX_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_debug_index5_t {
            unsigned int drm_debug_index                : DRM_DEBUG_INDEX5_DRM_DEBUG_INDEX_SIZE;
      } drm_debug_index5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_debug_index5_t {
            unsigned int drm_debug_index                : DRM_DEBUG_INDEX5_DRM_DEBUG_INDEX_SIZE;
      } drm_debug_index5_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_debug_index5_t f;
} drm_debug_index5_u;


/*
 * DRM_DEBUG_INDEX6 struct
 */

#define DRM_DEBUG_INDEX6_REG_SIZE         32
#define DRM_DEBUG_INDEX6_DRM_DEBUG_INDEX_SIZE  32

#define DRM_DEBUG_INDEX6_DRM_DEBUG_INDEX_SHIFT  0

#define DRM_DEBUG_INDEX6_DRM_DEBUG_INDEX_MASK  0xffffffff

#define DRM_DEBUG_INDEX6_MASK \
      (DRM_DEBUG_INDEX6_DRM_DEBUG_INDEX_MASK)

#define DRM_DEBUG_INDEX6_DEFAULT       0x00000000

#define DRM_DEBUG_INDEX6_GET_DRM_DEBUG_INDEX(drm_debug_index6) \
      ((drm_debug_index6 & DRM_DEBUG_INDEX6_DRM_DEBUG_INDEX_MASK) >> DRM_DEBUG_INDEX6_DRM_DEBUG_INDEX_SHIFT)

#define DRM_DEBUG_INDEX6_SET_DRM_DEBUG_INDEX(drm_debug_index6_reg, drm_debug_index) \
      drm_debug_index6_reg = (drm_debug_index6_reg & ~DRM_DEBUG_INDEX6_DRM_DEBUG_INDEX_MASK) | (drm_debug_index << DRM_DEBUG_INDEX6_DRM_DEBUG_INDEX_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_debug_index6_t {
            unsigned int drm_debug_index                : DRM_DEBUG_INDEX6_DRM_DEBUG_INDEX_SIZE;
      } drm_debug_index6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_debug_index6_t {
            unsigned int drm_debug_index                : DRM_DEBUG_INDEX6_DRM_DEBUG_INDEX_SIZE;
      } drm_debug_index6_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_debug_index6_t f;
} drm_debug_index6_u;


/*
 * DRM_DEBUG_INDEX7 struct
 */

#define DRM_DEBUG_INDEX7_REG_SIZE         32
#define DRM_DEBUG_INDEX7_DRM_DEBUG_INDEX_SIZE  32

#define DRM_DEBUG_INDEX7_DRM_DEBUG_INDEX_SHIFT  0

#define DRM_DEBUG_INDEX7_DRM_DEBUG_INDEX_MASK  0xffffffff

#define DRM_DEBUG_INDEX7_MASK \
      (DRM_DEBUG_INDEX7_DRM_DEBUG_INDEX_MASK)

#define DRM_DEBUG_INDEX7_DEFAULT       0x00000000

#define DRM_DEBUG_INDEX7_GET_DRM_DEBUG_INDEX(drm_debug_index7) \
      ((drm_debug_index7 & DRM_DEBUG_INDEX7_DRM_DEBUG_INDEX_MASK) >> DRM_DEBUG_INDEX7_DRM_DEBUG_INDEX_SHIFT)

#define DRM_DEBUG_INDEX7_SET_DRM_DEBUG_INDEX(drm_debug_index7_reg, drm_debug_index) \
      drm_debug_index7_reg = (drm_debug_index7_reg & ~DRM_DEBUG_INDEX7_DRM_DEBUG_INDEX_MASK) | (drm_debug_index << DRM_DEBUG_INDEX7_DRM_DEBUG_INDEX_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_debug_index7_t {
            unsigned int drm_debug_index                : DRM_DEBUG_INDEX7_DRM_DEBUG_INDEX_SIZE;
      } drm_debug_index7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_debug_index7_t {
            unsigned int drm_debug_index                : DRM_DEBUG_INDEX7_DRM_DEBUG_INDEX_SIZE;
      } drm_debug_index7_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_debug_index7_t f;
} drm_debug_index7_u;


/*
 * DRM_DEBUG_ID struct
 */

#define DRM_DEBUG_ID_REG_SIZE         32
#define DRM_DEBUG_ID_DRM_DEBUG_ID_SIZE  32

#define DRM_DEBUG_ID_DRM_DEBUG_ID_SHIFT  0

#define DRM_DEBUG_ID_DRM_DEBUG_ID_MASK  0xffffffff

#define DRM_DEBUG_ID_MASK \
      (DRM_DEBUG_ID_DRM_DEBUG_ID_MASK)

#define DRM_DEBUG_ID_DEFAULT           0xbbbbbbbb

#define DRM_DEBUG_ID_GET_DRM_DEBUG_ID(drm_debug_id) \
      ((drm_debug_id & DRM_DEBUG_ID_DRM_DEBUG_ID_MASK) >> DRM_DEBUG_ID_DRM_DEBUG_ID_SHIFT)

#define DRM_DEBUG_ID_SET_DRM_DEBUG_ID(drm_debug_id_reg, drm_debug_id) \
      drm_debug_id_reg = (drm_debug_id_reg & ~DRM_DEBUG_ID_DRM_DEBUG_ID_MASK) | (drm_debug_id << DRM_DEBUG_ID_DRM_DEBUG_ID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_debug_id_t {
            unsigned int drm_debug_id                   : DRM_DEBUG_ID_DRM_DEBUG_ID_SIZE;
      } drm_debug_id_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_debug_id_t {
            unsigned int drm_debug_id                   : DRM_DEBUG_ID_DRM_DEBUG_ID_SIZE;
      } drm_debug_id_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_debug_id_t f;
} drm_debug_id_u;


/*
 * DRM_DSKI_COMMAND struct
 */

#define DRM_DSKI_COMMAND_REG_SIZE         32
#define DRM_DSKI_COMMAND_CMD_SIZE  32

#define DRM_DSKI_COMMAND_CMD_SHIFT  0

#define DRM_DSKI_COMMAND_CMD_MASK       0xffffffff

#define DRM_DSKI_COMMAND_MASK \
      (DRM_DSKI_COMMAND_CMD_MASK)

#define DRM_DSKI_COMMAND_DEFAULT       0x00000000

#define DRM_DSKI_COMMAND_GET_CMD(drm_dski_command) \
      ((drm_dski_command & DRM_DSKI_COMMAND_CMD_MASK) >> DRM_DSKI_COMMAND_CMD_SHIFT)

#define DRM_DSKI_COMMAND_SET_CMD(drm_dski_command_reg, cmd) \
      drm_dski_command_reg = (drm_dski_command_reg & ~DRM_DSKI_COMMAND_CMD_MASK) | (cmd << DRM_DSKI_COMMAND_CMD_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_dski_command_t {
            unsigned int cmd                            : DRM_DSKI_COMMAND_CMD_SIZE;
      } drm_dski_command_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_dski_command_t {
            unsigned int cmd                            : DRM_DSKI_COMMAND_CMD_SIZE;
      } drm_dski_command_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_dski_command_t f;
} drm_dski_command_u;


/*
 * DRM_DSKI_KEY0 struct
 */

#define DRM_DSKI_KEY0_REG_SIZE         32
#define DRM_DSKI_KEY0_KEY_SIZE  32

#define DRM_DSKI_KEY0_KEY_SHIFT  0

#define DRM_DSKI_KEY0_KEY_MASK          0xffffffff

#define DRM_DSKI_KEY0_MASK \
      (DRM_DSKI_KEY0_KEY_MASK)

#define DRM_DSKI_KEY0_DEFAULT          0x00000000

#define DRM_DSKI_KEY0_GET_KEY(drm_dski_key0) \
      ((drm_dski_key0 & DRM_DSKI_KEY0_KEY_MASK) >> DRM_DSKI_KEY0_KEY_SHIFT)

#define DRM_DSKI_KEY0_SET_KEY(drm_dski_key0_reg, key) \
      drm_dski_key0_reg = (drm_dski_key0_reg & ~DRM_DSKI_KEY0_KEY_MASK) | (key << DRM_DSKI_KEY0_KEY_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_dski_key0_t {
            unsigned int key                            : DRM_DSKI_KEY0_KEY_SIZE;
      } drm_dski_key0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_dski_key0_t {
            unsigned int key                            : DRM_DSKI_KEY0_KEY_SIZE;
      } drm_dski_key0_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_dski_key0_t f;
} drm_dski_key0_u;


/*
 * DRM_DSKI_KEY1 struct
 */

#define DRM_DSKI_KEY1_REG_SIZE         32
#define DRM_DSKI_KEY1_KEY_SIZE  32

#define DRM_DSKI_KEY1_KEY_SHIFT  0

#define DRM_DSKI_KEY1_KEY_MASK          0xffffffff

#define DRM_DSKI_KEY1_MASK \
      (DRM_DSKI_KEY1_KEY_MASK)

#define DRM_DSKI_KEY1_DEFAULT          0x00000000

#define DRM_DSKI_KEY1_GET_KEY(drm_dski_key1) \
      ((drm_dski_key1 & DRM_DSKI_KEY1_KEY_MASK) >> DRM_DSKI_KEY1_KEY_SHIFT)

#define DRM_DSKI_KEY1_SET_KEY(drm_dski_key1_reg, key) \
      drm_dski_key1_reg = (drm_dski_key1_reg & ~DRM_DSKI_KEY1_KEY_MASK) | (key << DRM_DSKI_KEY1_KEY_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_dski_key1_t {
            unsigned int key                            : DRM_DSKI_KEY1_KEY_SIZE;
      } drm_dski_key1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_dski_key1_t {
            unsigned int key                            : DRM_DSKI_KEY1_KEY_SIZE;
      } drm_dski_key1_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_dski_key1_t f;
} drm_dski_key1_u;


/*
 * DRM_DSKI_KEY2 struct
 */

#define DRM_DSKI_KEY2_REG_SIZE         32
#define DRM_DSKI_KEY2_KEY_SIZE  32

#define DRM_DSKI_KEY2_KEY_SHIFT  0

#define DRM_DSKI_KEY2_KEY_MASK          0xffffffff

#define DRM_DSKI_KEY2_MASK \
      (DRM_DSKI_KEY2_KEY_MASK)

#define DRM_DSKI_KEY2_DEFAULT          0x00000000

#define DRM_DSKI_KEY2_GET_KEY(drm_dski_key2) \
      ((drm_dski_key2 & DRM_DSKI_KEY2_KEY_MASK) >> DRM_DSKI_KEY2_KEY_SHIFT)

#define DRM_DSKI_KEY2_SET_KEY(drm_dski_key2_reg, key) \
      drm_dski_key2_reg = (drm_dski_key2_reg & ~DRM_DSKI_KEY2_KEY_MASK) | (key << DRM_DSKI_KEY2_KEY_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_dski_key2_t {
            unsigned int key                            : DRM_DSKI_KEY2_KEY_SIZE;
      } drm_dski_key2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_dski_key2_t {
            unsigned int key                            : DRM_DSKI_KEY2_KEY_SIZE;
      } drm_dski_key2_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_dski_key2_t f;
} drm_dski_key2_u;


/*
 * DRM_DSKI_KEY3 struct
 */

#define DRM_DSKI_KEY3_REG_SIZE         32
#define DRM_DSKI_KEY3_KEY_SIZE  32

#define DRM_DSKI_KEY3_KEY_SHIFT  0

#define DRM_DSKI_KEY3_KEY_MASK          0xffffffff

#define DRM_DSKI_KEY3_MASK \
      (DRM_DSKI_KEY3_KEY_MASK)

#define DRM_DSKI_KEY3_DEFAULT          0x00000000

#define DRM_DSKI_KEY3_GET_KEY(drm_dski_key3) \
      ((drm_dski_key3 & DRM_DSKI_KEY3_KEY_MASK) >> DRM_DSKI_KEY3_KEY_SHIFT)

#define DRM_DSKI_KEY3_SET_KEY(drm_dski_key3_reg, key) \
      drm_dski_key3_reg = (drm_dski_key3_reg & ~DRM_DSKI_KEY3_KEY_MASK) | (key << DRM_DSKI_KEY3_KEY_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct drm_dski_key3_t {
            unsigned int key                            : DRM_DSKI_KEY3_KEY_SIZE;
      } drm_dski_key3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct drm_dski_key3_t {
            unsigned int key                            : DRM_DSKI_KEY3_KEY_SIZE;
      } drm_dski_key3_t;

#endif

typedef union {
     unsigned int val : 32;
          drm_dski_key3_t f;
} drm_dski_key3_u;


/*
 * MP_DRM_DEBUG struct
 */

#define MP_DRM_DEBUG_REG_SIZE         32
#define MP_DRM_DEBUG_DBG_MODE_EN_SIZE  1

#define MP_DRM_DEBUG_DBG_MODE_EN_SHIFT  0

#define MP_DRM_DEBUG_DBG_MODE_EN_MASK   0x00000001

#define MP_DRM_DEBUG_MASK \
      (MP_DRM_DEBUG_DBG_MODE_EN_MASK)

#define MP_DRM_DEBUG_DEFAULT           0x00000000

#define MP_DRM_DEBUG_GET_DBG_MODE_EN(mp_drm_debug) \
      ((mp_drm_debug & MP_DRM_DEBUG_DBG_MODE_EN_MASK) >> MP_DRM_DEBUG_DBG_MODE_EN_SHIFT)

#define MP_DRM_DEBUG_SET_DBG_MODE_EN(mp_drm_debug_reg, dbg_mode_en) \
      mp_drm_debug_reg = (mp_drm_debug_reg & ~MP_DRM_DEBUG_DBG_MODE_EN_MASK) | (dbg_mode_en << MP_DRM_DEBUG_DBG_MODE_EN_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp_drm_debug_t {
            unsigned int dbg_mode_en                    : MP_DRM_DEBUG_DBG_MODE_EN_SIZE;
            unsigned int                                : 31;
      } mp_drm_debug_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp_drm_debug_t {
            unsigned int                                : 31;
            unsigned int dbg_mode_en                    : MP_DRM_DEBUG_DBG_MODE_EN_SIZE;
      } mp_drm_debug_t;

#endif

typedef union {
     unsigned int val : 32;
          mp_drm_debug_t f;
} mp_drm_debug_u;


/*
 * MP_DRM_ACC_VIOLATION_LOG_ADDR struct
 */

#define MP_DRM_ACC_VIOLATION_LOG_ADDR_REG_SIZE         32
#define MP_DRM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SIZE  32

#define MP_DRM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SHIFT  0

#define MP_DRM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK  0xffffffff

#define MP_DRM_ACC_VIOLATION_LOG_ADDR_MASK \
      (MP_DRM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK)

#define MP_DRM_ACC_VIOLATION_LOG_ADDR_DEFAULT 0x00000000

#define MP_DRM_ACC_VIOLATION_LOG_ADDR_GET_ADDRESS(mp_drm_acc_violation_log_addr) \
      ((mp_drm_acc_violation_log_addr & MP_DRM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK) >> MP_DRM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SHIFT)

#define MP_DRM_ACC_VIOLATION_LOG_ADDR_SET_ADDRESS(mp_drm_acc_violation_log_addr_reg, address) \
      mp_drm_acc_violation_log_addr_reg = (mp_drm_acc_violation_log_addr_reg & ~MP_DRM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK) | (address << MP_DRM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp_drm_acc_violation_log_addr_t {
            unsigned int address                        : MP_DRM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SIZE;
      } mp_drm_acc_violation_log_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp_drm_acc_violation_log_addr_t {
            unsigned int address                        : MP_DRM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SIZE;
      } mp_drm_acc_violation_log_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp_drm_acc_violation_log_addr_t f;
} mp_drm_acc_violation_log_addr_u;


/*
 * MP_DRM_ACC_VIOLATION_LOG_STATUS struct
 */

#define MP_DRM_ACC_VIOLATION_LOG_STATUS_REG_SIZE         32
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE  1
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SIZE  1
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SIZE  2
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_LO_SIZE  10
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_MID_SIZE  10
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_HI_SIZE  1
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE  1

#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT  0
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SHIFT  3
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SHIFT  6
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_LO_SHIFT  8
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_MID_SHIFT  18
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_HI_SHIFT  28
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT  31

#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK  0x00000001
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_MASK  0x00000008
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_MASK  0x000000c0
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_LO_MASK  0x0003ff00
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_MID_MASK  0x0ffc0000
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_HI_MASK  0x10000000
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK  0x80000000

#define MP_DRM_ACC_VIOLATION_LOG_STATUS_MASK \
      (MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK | \
      MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_MASK | \
      MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_MASK | \
      MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_LO_MASK | \
      MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_MID_MASK | \
      MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_HI_MASK | \
      MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK)

#define MP_DRM_ACC_VIOLATION_LOG_STATUS_DEFAULT 0x00000000

#define MP_DRM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_DETECTED(mp_drm_acc_violation_log_status) \
      ((mp_drm_acc_violation_log_status & MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) >> MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_OP(mp_drm_acc_violation_log_status) \
      ((mp_drm_acc_violation_log_status & MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_MASK) >> MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SHIFT)
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_PERMISSION(mp_drm_acc_violation_log_status) \
      ((mp_drm_acc_violation_log_status & MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_MASK) >> MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SHIFT)
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_AXI_ID_LO(mp_drm_acc_violation_log_status) \
      ((mp_drm_acc_violation_log_status & MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_LO_MASK) >> MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_LO_SHIFT)
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_AXI_ID_MID(mp_drm_acc_violation_log_status) \
      ((mp_drm_acc_violation_log_status & MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_MID_MASK) >> MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_MID_SHIFT)
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_AXI_ID_HI(mp_drm_acc_violation_log_status) \
      ((mp_drm_acc_violation_log_status & MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_HI_MASK) >> MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_HI_SHIFT)
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_LOG_CLEAR(mp_drm_acc_violation_log_status) \
      ((mp_drm_acc_violation_log_status & MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) >> MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)

#define MP_DRM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_DETECTED(mp_drm_acc_violation_log_status_reg, acc_violation_detected) \
      mp_drm_acc_violation_log_status_reg = (mp_drm_acc_violation_log_status_reg & ~MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) | (acc_violation_detected << MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_OP(mp_drm_acc_violation_log_status_reg, acc_violation_op) \
      mp_drm_acc_violation_log_status_reg = (mp_drm_acc_violation_log_status_reg & ~MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_MASK) | (acc_violation_op << MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SHIFT)
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_PERMISSION(mp_drm_acc_violation_log_status_reg, acc_violation_permission) \
      mp_drm_acc_violation_log_status_reg = (mp_drm_acc_violation_log_status_reg & ~MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_MASK) | (acc_violation_permission << MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SHIFT)
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_AXI_ID_LO(mp_drm_acc_violation_log_status_reg, acc_violation_axi_id_lo) \
      mp_drm_acc_violation_log_status_reg = (mp_drm_acc_violation_log_status_reg & ~MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_LO_MASK) | (acc_violation_axi_id_lo << MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_LO_SHIFT)
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_AXI_ID_MID(mp_drm_acc_violation_log_status_reg, acc_violation_axi_id_mid) \
      mp_drm_acc_violation_log_status_reg = (mp_drm_acc_violation_log_status_reg & ~MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_MID_MASK) | (acc_violation_axi_id_mid << MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_MID_SHIFT)
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_AXI_ID_HI(mp_drm_acc_violation_log_status_reg, acc_violation_axi_id_hi) \
      mp_drm_acc_violation_log_status_reg = (mp_drm_acc_violation_log_status_reg & ~MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_HI_MASK) | (acc_violation_axi_id_hi << MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_HI_SHIFT)
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_LOG_CLEAR(mp_drm_acc_violation_log_status_reg, acc_violation_log_clear) \
      mp_drm_acc_violation_log_status_reg = (mp_drm_acc_violation_log_status_reg & ~MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) | (acc_violation_log_clear << MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp_drm_acc_violation_log_status_t {
            unsigned int acc_violation_detected         : MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
            unsigned int                                : 2;
            unsigned int acc_violation_op               : MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SIZE;
            unsigned int                                : 2;
            unsigned int acc_violation_permission       : MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SIZE;
            unsigned int acc_violation_axi_id_lo        : MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_LO_SIZE;
            unsigned int acc_violation_axi_id_mid       : MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_MID_SIZE;
            unsigned int acc_violation_axi_id_hi        : MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_HI_SIZE;
            unsigned int                                : 2;
            unsigned int acc_violation_log_clear        : MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
      } mp_drm_acc_violation_log_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp_drm_acc_violation_log_status_t {
            unsigned int acc_violation_log_clear        : MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
            unsigned int                                : 2;
            unsigned int acc_violation_axi_id_hi        : MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_HI_SIZE;
            unsigned int acc_violation_axi_id_mid       : MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_MID_SIZE;
            unsigned int acc_violation_axi_id_lo        : MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_ID_LO_SIZE;
            unsigned int acc_violation_permission       : MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SIZE;
            unsigned int                                : 2;
            unsigned int acc_violation_op               : MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SIZE;
            unsigned int                                : 2;
            unsigned int acc_violation_detected         : MP_DRM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
      } mp_drm_acc_violation_log_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mp_drm_acc_violation_log_status_t f;
} mp_drm_acc_violation_log_status_u;


#endif

