/*
*  Trade secret of Advanced Micro Devices, Inc.
*  Copyright (c) 2014 Advanced Micro Devices, Inc. (unpublished)
*
*  All rights reserved.  This notice is intended as a precaution against
*  inadvertent publication and does not imply publication or any waiver
*  of confidentiality.  The year included in the foregoing notice is the
*  year of creation of the work.
*
*/

#ifndef __FCH_H
#define __FCH_H

#include <stdint.h>

// Basic Register Access Macros
#define AR_FIELD_SHIFT(reg, field)                      reg##_##field##_SHIFT
#define AR_FIELD_MASK(reg, field)                       reg##_##field##_MASK
#define AR_GET_FIELD(value, reg, field)                 (((value) & AR_FIELD_MASK(reg, field)) >> AR_FIELD_SHIFT(reg, field))
#define AR_SET_FIELD(origval, reg, field, fieldval)     (((origval) & ~AR_FIELD_MASK(reg, field)) | (AR_FIELD_MASK(reg, field) \
                                                        & (((uint32_t)(fieldval)) << AR_FIELD_SHIFT(reg, field))))

#define REG8(addr)                                      *((volatile uint8_t *) (addr))
#define REG16(addr)                                     *((volatile uint16_t *) (addr))
#define REG32(addr)                                     *((volatile uint32_t *) (addr))
#define DREG32(addr)                                    *((uint32_t *) (addr))
#define REG64(addr)                                     *((volatile uint64_t *) (addr))


#define MPM_REG_BYTE(reg)                                    REG8(mm##reg)
#define MPM_REG_SHORT(reg)                                   REG16(mm##reg)
#define MPM_REG_DWORD(reg)                                   REG32(mm##reg)

#define MP1_REG(reg)                                    REG32(mm##reg)
#define MPM_DREG(reg)                                   DREG32(mm##reg)
#define MPM_REG_ADDR(reg)                               REG32(reg)
#define MPM_REG64_ADDR(reg)                             REG64(reg)
#define MPM_REG_READ_FIELD(reg, field)                  AR_GET_FIELD(MPM_REG(reg), reg, field)
#define MPM_REG_WRITE_FIELD(reg, field, fieldval)       MPM_REG(reg) = AR_SET_FIELD(MPM_REG(reg), reg, field, fieldval)


enum POST_CODE_LEVELS {
  POSTCODE_DISABLED,    // No PostCode
  POSTCODE_LEVEL1,      // The higher the level the more PostCodes SMU sends out
  POSTCODE_LEVEL2,
  POSTCODE_LEVEL3,
  POSTCODE_LEVEL_COUNT,
};

/* Defines for FCH */

#define FCH_I2C_ERR_NONE                0x00
#define FCH_I2C_ERR_ABRT_7B_ADDR_NACK   0x01

#define FCH_I2C_REG_ADDR(i2c, addr)                 FCH_REG_ADDR(0x02DC2000 + 0x1000 * i2c + addr)
#define FCH_AOAC_REG_ADDR(addr)                     FCH_REG_ADDR(0x02D02E00 + addr)
#define FCH_SHADOW_SYSTEM_COUNTER_REG_ADDR(addr)    FCH_REG_ADDR(0x02D02100 + addr)

#define FCH_I2C_CONTROLLER_0            0x00
#define FCH_I2C_CONTROLLER_1            0x01

#define FCH_I2C_IC_CON                  0x00
#define FCH_I2C_IC_TAR                  0x04
#define FCH_I2C_IC_SAR                  0x08
#define FCH_I2C_IC_HS_MADDR             0x0C
#define FCH_I2C_IC_DATA_CMD             0x10
#define FCH_I2C_IC_SS_SCL_HCNT          0x14
#define FCH_I2C_IC_SS_SCL_LCNT          0x18
#define FCH_I2C_IC_FS_SCL_HCNT          0x1C
#define FCH_I2C_IC_FS_SCL_LCNT          0x20
#define FCH_I2C_IC_HS_SCL_HCNT          0x24
#define FCH_I2C_IC_HS_SCL_LCNT          0x28
#define FCH_I2C_IC_INTR_STAT            0x2C
#define FCH_I2C_IC_INTR_MASK            0x30
#define FCH_I2C_IC_RAW_INTR_STAT        0x34
#define FCH_I2C_IC_RX_TL                0x38
#define FCH_I2C_IC_TX_TL                0x3C
#define FCH_I2C_IC_CLR_INTR             0x40
#define FCH_I2C_IC_CLR_RX_UNDER         0x44
#define FCH_I2C_IC_CLR_RX_OVER          0x48
#define FCH_I2C_IC_CLR_TX_OVER          0x4C
#define FCH_I2C_IC_CLR_RD_REQ           0x50
#define FCH_I2C_IC_CLR_TX_ABRT          0x54
#define FCH_I2C_IC_CLR_RX_DONE          0x58
#define FCH_I2C_IC_CLR_ACTIVITY         0x5C
#define FCH_I2C_IC_CLR_STOP_DET         0x60
#define FCH_I2C_IC_CLR_START_DET        0x64
#define FCH_I2C_IC_CLR_GEN_CALL         0x68
#define FCH_I2C_IC_ENABLE               0x6C
#define FCH_I2C_IC_STATUS               0x70
#define FCH_I2C_IC_TXFLR                0x74
#define FCH_I2C_IC_RXFLR                0x78
#define FCH_I2C_IC_SDA_HOLD             0x7C
#define FCH_I2C_IC_TX_ABRT_SOURCE       0x80
#define FCH_I2C_IC_SLV_DATA_NACK_ONLY   0x84
#define FCH_I2C_IC_SDA_SETUP            0x94
#define FCH_I2C_IC_ACK_GENERAL_CALL     0x98
#define FCH_I2C_IC_ENABLE_STATUS        0x9C
#define FCH_I2C_IC_FS_SPKLEN            0xA0
#define FCH_I2C_IC_HS_SPKLEN            0xA4
#define FCH_I2C_IC_COMP_PARAM_1         0xF4
#define FCH_I2C_IC_COMP_VERSION         0xF8
#define FCH_I2C_IC_COMP_TYPE            0xFC

#define FCH_SSC_SHDW_SYS_CNT_L          0x00
#define FCH_SSC_SHDW_SYS_CNT_H          0x04
#define FCH_SSC_S0I3_ENTRY_TIME_L		0X30
#define FCH_SSC_S0I3_ENTRY_TIME_H		0x34
#define FCH_SSC_S0I3_EXIT_TIME_L  		0x38
#define FCH_SSC_S0I3_EXIT_TIME_H  		0x3C

#define FCH_SSC_CLK_MHZ					48	// 48 MHz

typedef struct {
  uint32_t master_mode                  : 1;
  uint32_t speed                        : 2;
  uint32_t ic_10bitaddr_slave           : 1;
  uint32_t ic_10bitaddr_master          : 1;
  uint32_t ic_restart_en                : 1;
  uint32_t ic_slave_disable             : 1;
  uint32_t stop_det_ifaddressed         : 1;
  uint32_t tx_empty_ctrl                : 1;
  uint32_t rx_fifo_full_hld_ctrl        : 1;
  uint32_t stop_det_if_master_active    : 1;
  uint32_t reserved                     : 21;
} fch_i2c_ic_con_t;

typedef union {
  uint32_t val;
  fch_i2c_ic_con_t f;
} fch_i2c_ic_con_u;

typedef struct {
  uint32_t dat                          : 8;
  uint32_t cmd                          : 1;
  uint32_t stop                         : 1;
  uint32_t restart                      : 1;
  uint32_t first_data_byte              : 1;
  uint32_t reserved                     : 20;
} fch_i2c_ic_data_cmd_t;

typedef union {
  uint32_t val;
  fch_i2c_ic_data_cmd_t f;
} fch_i2c_ic_data_cmd_u;

/* API functions for FCH.I2C */

void    fch_i2c_init    (uint8_t i2c);
uint8_t FchI2CWriteBytes(uint8_t i2c, uint8_t addr, uint8_t size, uint8_t *data);
uint8_t FchI2CReadBytes (uint8_t i2c, uint8_t addr, uint8_t size, uint8_t *data);


#define AXI_WRITE_STROBE    0xF
#define AXI_MPM_ID          0x1
#define AXI_SIZE_1BYTES     0x0
#define AXI_SIZE_2BYTES     0x1
#define AXI_SIZE_4BYTES     0x2
#define AXI_REQIO_MMIO      0x1
#define AXI_REQIO_IOPORT    0x0
#define AXI_COMPAT          0x2
#define AXI_BYPASS          0x4
#define AXI_USER_MMIO       (AXI_BYPASS | AXI_COMPAT | AXI_REQIO_MMIO)
#define AXI_USER_IOPORT     (AXI_BYPASS | AXI_COMPAT | AXI_REQIO_IOPORT)
#define AXI_USER_PCIE_MMIO  (AXI_BYPASS | AXI_REQIO_IOPORT)
#define AXI_OPCODE_READ     0x0
#define AXI_OPCODE_WRITE    0x1
#define AXI_TRAN_STRT       0x1
#define AXI_TRAN_END        0x0

uint32_t ReadFchPCIeMMIO(uint32_t AddrHigh, uint32_t AddrLow);
void    WriteFchPCIeMMIO(uint32_t AddrHigh, uint32_t AddrLow, uint32_t Data);
uint32_t ReadFchIOPort  (uint32_t AddrHigh, uint32_t AddrLow);
void    WriteFchIOPort  (uint32_t AddrHigh, uint32_t AddrLow, uint32_t Data);
uint32_t ReadFchMMIO    (uint32_t AddrHigh, uint32_t AddrLow);
void    WriteFchMMIO    (uint32_t AddrHigh, uint32_t AddrLow, uint32_t Data);
uint32_t ReadFch        (uint32_t AddrHigh, uint32_t AddrLow, uint8_t AxiUser);
void    WriteFch        (uint32_t AddrHigh, uint32_t AddrLow, uint8_t AxiUser, uint32_t Data);

uint8_t ReadFchByte(uint32_t AddrHigh, uint32_t AddrLow, uint8_t AxiUser);
uint16_t ReadFchShort(uint32_t AddrHigh, uint32_t AddrLow, uint8_t AxiUser);
void WriteFchByte(uint32_t AddrHigh, uint32_t AddrLow, uint8_t AxiUser, uint8_t Data);
void WriteFchShort(uint32_t AddrHigh, uint32_t AddrLow, uint8_t AxiUser, uint16_t Data);

uint8_t ReadFchPCIeMMIOByte(uint32_t AddrHigh, uint32_t AddrLow);
uint16_t ReadFchPCIeMMIOShort(uint32_t AddrHigh, uint32_t AddrLow);

void WriteFchPCIeMMIOByte(uint32_t AddrHigh, uint32_t AddrLow, uint8_t Data);
void WriteFchPCIeMMIOShort(uint32_t AddrHigh, uint32_t AddrLow, uint16_t Data);

#define POSTCODE_ADDR_HIGH  0xFFFD
#define POSTCODE_ADDR_LOW   0xFC000080
#define POSTCODE_SMU_SIGN   0x50000000

void WritePostCode(uint32_t PostCode, uint8_t PostCodeLevel);
void fSMC_MSG_EnablePostCode(uint32_t MsgPort);
uint64_t ReadFchShadowTimer();
void WritePostCodeBypass(uint32_t PostCode);
#endif
