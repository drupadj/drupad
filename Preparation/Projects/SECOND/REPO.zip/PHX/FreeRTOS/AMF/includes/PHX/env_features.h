// Copyright (c) 2010 - 2019 Advanced Micro Devices, Inc. All rights reserved.
#ifndef __ENV_FEATURES_H__
#define __ENV_FEATURES_H__
// reference features

// imported features

// local features
#define ENV__VARIANT rembrandt
#define ENV__VARIANT__REMBRANDT 1
#endif
