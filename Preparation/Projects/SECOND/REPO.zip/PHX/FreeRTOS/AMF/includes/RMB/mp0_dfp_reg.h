// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MP0_DFP_FIDDLE_H)
#define _MP0_DFP_FIDDLE_H

/*****************************************************************************************************************
 *
 *	mp0_dfp_reg.h
 *
 *	Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif


/*******************************************************
 * Values
 *******************************************************/


/*******************************************************
 * Structures
 *******************************************************/

/*
 * MP0_MPCLK_XBAR_CG_CTRL struct
 */

#define MP0_MPCLK_XBAR_CG_CTRL_REG_SIZE 32
#define MP0_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SIZE 1

#define MP0_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SHIFT 0

#define MP0_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_MASK 0x1

#define MP0_MPCLK_XBAR_CG_CTRL_MASK \
     (MP0_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_MASK)

#define MP0_MPCLK_XBAR_CG_CTRL_DEFAULT 0x00000000

#define MP0_MPCLK_XBAR_CG_CTRL_GET_MPCLK_XBAR_CACTIVE_EN(mp0_mpclk_xbar_cg_ctrl) \
     ((mp0_mpclk_xbar_cg_ctrl & MP0_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_MASK) >> MP0_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SHIFT)

#define MP0_MPCLK_XBAR_CG_CTRL_SET_MPCLK_XBAR_CACTIVE_EN(mp0_mpclk_xbar_cg_ctrl_reg, mpclk_xbar_cactive_en) \
     mp0_mpclk_xbar_cg_ctrl_reg = (mp0_mpclk_xbar_cg_ctrl_reg & ~MP0_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_MASK) | (mpclk_xbar_cactive_en << MP0_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_mpclk_xbar_cg_ctrl_t {
          unsigned int mpclk_xbar_cactive_en          : MP0_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SIZE;
          unsigned int                                : 31;
     } mp0_mpclk_xbar_cg_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_mpclk_xbar_cg_ctrl_t {
          unsigned int                                : 31;
          unsigned int mpclk_xbar_cactive_en          : MP0_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SIZE;
     } mp0_mpclk_xbar_cg_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_mpclk_xbar_cg_ctrl_t f;
} mp0_mpclk_xbar_cg_ctrl_u;


/*
 * MP0_MPCLK_XBAR_CG_EN struct
 */

#define MP0_MPCLK_XBAR_CG_EN_REG_SIZE  32
#define MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SIZE 1
#define MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_SIZE 1
#define MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_2_SIZE 1
#define MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SIZE 1
#define MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_SIZE 1
#define MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_2_SIZE 1

#define MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SHIFT 1
#define MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_SHIFT 2
#define MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_2_SHIFT 3
#define MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SHIFT 4
#define MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_SHIFT 5
#define MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_2_SHIFT 6

#define MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_MASK 0x2
#define MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_MASK 0x4
#define MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_2_MASK 0x8
#define MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_MASK 0x10
#define MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_MASK 0x20
#define MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_2_MASK 0x40

#define MP0_MPCLK_XBAR_CG_EN_MASK \
     (MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_MASK | \
      MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_MASK | \
      MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_2_MASK | \
      MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_MASK | \
      MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_MASK | \
      MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_2_MASK)

#define MP0_MPCLK_XBAR_CG_EN_DEFAULT   0x00000000

#define MP0_MPCLK_XBAR_CG_EN_GET_MPCLK_XBAR_CG_EN_0(mp0_mpclk_xbar_cg_en) \
     ((mp0_mpclk_xbar_cg_en & MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_MASK) >> MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SHIFT)
#define MP0_MPCLK_XBAR_CG_EN_GET_MPCLK_XBAR_CG_EN_1(mp0_mpclk_xbar_cg_en) \
     ((mp0_mpclk_xbar_cg_en & MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_MASK) >> MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_SHIFT)
#define MP0_MPCLK_XBAR_CG_EN_GET_MPCLK_XBAR_CG_EN_2(mp0_mpclk_xbar_cg_en) \
     ((mp0_mpclk_xbar_cg_en & MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_2_MASK) >> MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_2_SHIFT)
#define MP0_MPCLK_XBAR_CG_EN_GET_MPCLK_XBAR_CG_OVERRIDE_0(mp0_mpclk_xbar_cg_en) \
     ((mp0_mpclk_xbar_cg_en & MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_MASK) >> MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SHIFT)
#define MP0_MPCLK_XBAR_CG_EN_GET_MPCLK_XBAR_CG_OVERRIDE_1(mp0_mpclk_xbar_cg_en) \
     ((mp0_mpclk_xbar_cg_en & MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_MASK) >> MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_SHIFT)
#define MP0_MPCLK_XBAR_CG_EN_GET_MPCLK_XBAR_CG_OVERRIDE_2(mp0_mpclk_xbar_cg_en) \
     ((mp0_mpclk_xbar_cg_en & MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_2_MASK) >> MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_2_SHIFT)

#define MP0_MPCLK_XBAR_CG_EN_SET_MPCLK_XBAR_CG_EN_0(mp0_mpclk_xbar_cg_en_reg, mpclk_xbar_cg_en_0) \
     mp0_mpclk_xbar_cg_en_reg = (mp0_mpclk_xbar_cg_en_reg & ~MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_MASK) | (mpclk_xbar_cg_en_0 << MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SHIFT)
#define MP0_MPCLK_XBAR_CG_EN_SET_MPCLK_XBAR_CG_EN_1(mp0_mpclk_xbar_cg_en_reg, mpclk_xbar_cg_en_1) \
     mp0_mpclk_xbar_cg_en_reg = (mp0_mpclk_xbar_cg_en_reg & ~MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_MASK) | (mpclk_xbar_cg_en_1 << MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_SHIFT)
#define MP0_MPCLK_XBAR_CG_EN_SET_MPCLK_XBAR_CG_EN_2(mp0_mpclk_xbar_cg_en_reg, mpclk_xbar_cg_en_2) \
     mp0_mpclk_xbar_cg_en_reg = (mp0_mpclk_xbar_cg_en_reg & ~MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_2_MASK) | (mpclk_xbar_cg_en_2 << MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_2_SHIFT)
#define MP0_MPCLK_XBAR_CG_EN_SET_MPCLK_XBAR_CG_OVERRIDE_0(mp0_mpclk_xbar_cg_en_reg, mpclk_xbar_cg_override_0) \
     mp0_mpclk_xbar_cg_en_reg = (mp0_mpclk_xbar_cg_en_reg & ~MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_MASK) | (mpclk_xbar_cg_override_0 << MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SHIFT)
#define MP0_MPCLK_XBAR_CG_EN_SET_MPCLK_XBAR_CG_OVERRIDE_1(mp0_mpclk_xbar_cg_en_reg, mpclk_xbar_cg_override_1) \
     mp0_mpclk_xbar_cg_en_reg = (mp0_mpclk_xbar_cg_en_reg & ~MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_MASK) | (mpclk_xbar_cg_override_1 << MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_SHIFT)
#define MP0_MPCLK_XBAR_CG_EN_SET_MPCLK_XBAR_CG_OVERRIDE_2(mp0_mpclk_xbar_cg_en_reg, mpclk_xbar_cg_override_2) \
     mp0_mpclk_xbar_cg_en_reg = (mp0_mpclk_xbar_cg_en_reg & ~MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_2_MASK) | (mpclk_xbar_cg_override_2 << MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_2_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_mpclk_xbar_cg_en_t {
          unsigned int                                : 1;
          unsigned int mpclk_xbar_cg_en_0             : MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SIZE;
          unsigned int mpclk_xbar_cg_en_1             : MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_SIZE;
          unsigned int mpclk_xbar_cg_en_2             : MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_2_SIZE;
          unsigned int mpclk_xbar_cg_override_0       : MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SIZE;
          unsigned int mpclk_xbar_cg_override_1       : MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_SIZE;
          unsigned int mpclk_xbar_cg_override_2       : MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_2_SIZE;
          unsigned int                                : 25;
     } mp0_mpclk_xbar_cg_en_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_mpclk_xbar_cg_en_t {
          unsigned int                                : 25;
          unsigned int mpclk_xbar_cg_override_2       : MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_2_SIZE;
          unsigned int mpclk_xbar_cg_override_1       : MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_SIZE;
          unsigned int mpclk_xbar_cg_override_0       : MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SIZE;
          unsigned int mpclk_xbar_cg_en_2             : MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_2_SIZE;
          unsigned int mpclk_xbar_cg_en_1             : MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_SIZE;
          unsigned int mpclk_xbar_cg_en_0             : MP0_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SIZE;
          unsigned int                                : 1;
     } mp0_mpclk_xbar_cg_en_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_mpclk_xbar_cg_en_t f;
} mp0_mpclk_xbar_cg_en_u;


/*
 * MP0_MPCLK_XBAR_CG_MISC struct
 */

#define MP0_MPCLK_XBAR_CG_MISC_REG_SIZE 32
#define MP0_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SIZE 8
#define MP0_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SIZE 8

#define MP0_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SHIFT 0
#define MP0_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SHIFT 8

#define MP0_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_MASK 0xff
#define MP0_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_MASK 0xff00

#define MP0_MPCLK_XBAR_CG_MISC_MASK \
     (MP0_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_MASK | \
      MP0_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_MASK)

#define MP0_MPCLK_XBAR_CG_MISC_DEFAULT 0x00000606

#define MP0_MPCLK_XBAR_CG_MISC_GET_MPCLK_XBAR_CG_TIMEOUT(mp0_mpclk_xbar_cg_misc) \
     ((mp0_mpclk_xbar_cg_misc & MP0_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_MASK) >> MP0_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MP0_MPCLK_XBAR_CG_MISC_GET_MPCLK_XBAR_CSYS_DELAY(mp0_mpclk_xbar_cg_misc) \
     ((mp0_mpclk_xbar_cg_misc & MP0_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_MASK) >> MP0_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SHIFT)

#define MP0_MPCLK_XBAR_CG_MISC_SET_MPCLK_XBAR_CG_TIMEOUT(mp0_mpclk_xbar_cg_misc_reg, mpclk_xbar_cg_timeout) \
     mp0_mpclk_xbar_cg_misc_reg = (mp0_mpclk_xbar_cg_misc_reg & ~MP0_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_MASK) | (mpclk_xbar_cg_timeout << MP0_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MP0_MPCLK_XBAR_CG_MISC_SET_MPCLK_XBAR_CSYS_DELAY(mp0_mpclk_xbar_cg_misc_reg, mpclk_xbar_csys_delay) \
     mp0_mpclk_xbar_cg_misc_reg = (mp0_mpclk_xbar_cg_misc_reg & ~MP0_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_MASK) | (mpclk_xbar_csys_delay << MP0_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_mpclk_xbar_cg_misc_t {
          unsigned int mpclk_xbar_cg_timeout          : MP0_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SIZE;
          unsigned int mpclk_xbar_csys_delay          : MP0_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SIZE;
          unsigned int                                : 16;
     } mp0_mpclk_xbar_cg_misc_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_mpclk_xbar_cg_misc_t {
          unsigned int                                : 16;
          unsigned int mpclk_xbar_csys_delay          : MP0_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SIZE;
          unsigned int mpclk_xbar_cg_timeout          : MP0_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SIZE;
     } mp0_mpclk_xbar_cg_misc_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_mpclk_xbar_cg_misc_t f;
} mp0_mpclk_xbar_cg_misc_u;


/*
 * MP0_DFP_ZSCIF_CTRL struct
 */

#define MP0_DFP_ZSCIF_CTRL_REG_SIZE    32
#define MP0_DFP_ZSCIF_CTRL_ZSC_EN_PULSE_SIZE 1
#define MP0_DFP_ZSCIF_CTRL_ZSC_IF_IDLE_SIZE 1
#define MP0_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_REQ_SIZE 1
#define MP0_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_ACK_SIZE 1
#define MP0_DFP_ZSCIF_CTRL_ZSC_AXI_MASK_SIZE 1
#define MP0_DFP_ZSCIF_CTRL_ZSC_INT_MASK_SIZE 1
#define MP0_DFP_ZSCIF_CTRL_ZSC_INT_MASKED_SIZE 1
#define MP0_DFP_ZSCIF_CTRL_ZSC_CLR_PULSE_SIZE 1

#define MP0_DFP_ZSCIF_CTRL_ZSC_EN_PULSE_SHIFT 0
#define MP0_DFP_ZSCIF_CTRL_ZSC_IF_IDLE_SHIFT 1
#define MP0_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_REQ_SHIFT 2
#define MP0_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_ACK_SHIFT 3
#define MP0_DFP_ZSCIF_CTRL_ZSC_AXI_MASK_SHIFT 4
#define MP0_DFP_ZSCIF_CTRL_ZSC_INT_MASK_SHIFT 5
#define MP0_DFP_ZSCIF_CTRL_ZSC_INT_MASKED_SHIFT 7
#define MP0_DFP_ZSCIF_CTRL_ZSC_CLR_PULSE_SHIFT 8

#define MP0_DFP_ZSCIF_CTRL_ZSC_EN_PULSE_MASK 0x1
#define MP0_DFP_ZSCIF_CTRL_ZSC_IF_IDLE_MASK 0x2
#define MP0_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_REQ_MASK 0x4
#define MP0_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_ACK_MASK 0x8
#define MP0_DFP_ZSCIF_CTRL_ZSC_AXI_MASK_MASK 0x10
#define MP0_DFP_ZSCIF_CTRL_ZSC_INT_MASK_MASK 0x20
#define MP0_DFP_ZSCIF_CTRL_ZSC_INT_MASKED_MASK 0x80
#define MP0_DFP_ZSCIF_CTRL_ZSC_CLR_PULSE_MASK 0x100

#define MP0_DFP_ZSCIF_CTRL_MASK \
     (MP0_DFP_ZSCIF_CTRL_ZSC_EN_PULSE_MASK | \
      MP0_DFP_ZSCIF_CTRL_ZSC_IF_IDLE_MASK | \
      MP0_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_REQ_MASK | \
      MP0_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_ACK_MASK | \
      MP0_DFP_ZSCIF_CTRL_ZSC_AXI_MASK_MASK | \
      MP0_DFP_ZSCIF_CTRL_ZSC_INT_MASK_MASK | \
      MP0_DFP_ZSCIF_CTRL_ZSC_INT_MASKED_MASK | \
      MP0_DFP_ZSCIF_CTRL_ZSC_CLR_PULSE_MASK)

#define MP0_DFP_ZSCIF_CTRL_DEFAULT     0x00000000

#define MP0_DFP_ZSCIF_CTRL_GET_ZSC_EN_PULSE(mp0_dfp_zscif_ctrl) \
     ((mp0_dfp_zscif_ctrl & MP0_DFP_ZSCIF_CTRL_ZSC_EN_PULSE_MASK) >> MP0_DFP_ZSCIF_CTRL_ZSC_EN_PULSE_SHIFT)
#define MP0_DFP_ZSCIF_CTRL_GET_ZSC_IF_IDLE(mp0_dfp_zscif_ctrl) \
     ((mp0_dfp_zscif_ctrl & MP0_DFP_ZSCIF_CTRL_ZSC_IF_IDLE_MASK) >> MP0_DFP_ZSCIF_CTRL_ZSC_IF_IDLE_SHIFT)
#define MP0_DFP_ZSCIF_CTRL_GET_ZSC_IF_FENCE_REQ(mp0_dfp_zscif_ctrl) \
     ((mp0_dfp_zscif_ctrl & MP0_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_REQ_MASK) >> MP0_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_REQ_SHIFT)
#define MP0_DFP_ZSCIF_CTRL_GET_ZSC_IF_FENCE_ACK(mp0_dfp_zscif_ctrl) \
     ((mp0_dfp_zscif_ctrl & MP0_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_ACK_MASK) >> MP0_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_ACK_SHIFT)
#define MP0_DFP_ZSCIF_CTRL_GET_ZSC_AXI_MASK(mp0_dfp_zscif_ctrl) \
     ((mp0_dfp_zscif_ctrl & MP0_DFP_ZSCIF_CTRL_ZSC_AXI_MASK_MASK) >> MP0_DFP_ZSCIF_CTRL_ZSC_AXI_MASK_SHIFT)
#define MP0_DFP_ZSCIF_CTRL_GET_ZSC_INT_MASK(mp0_dfp_zscif_ctrl) \
     ((mp0_dfp_zscif_ctrl & MP0_DFP_ZSCIF_CTRL_ZSC_INT_MASK_MASK) >> MP0_DFP_ZSCIF_CTRL_ZSC_INT_MASK_SHIFT)
#define MP0_DFP_ZSCIF_CTRL_GET_ZSC_INT_MASKED(mp0_dfp_zscif_ctrl) \
     ((mp0_dfp_zscif_ctrl & MP0_DFP_ZSCIF_CTRL_ZSC_INT_MASKED_MASK) >> MP0_DFP_ZSCIF_CTRL_ZSC_INT_MASKED_SHIFT)
#define MP0_DFP_ZSCIF_CTRL_GET_ZSC_CLR_PULSE(mp0_dfp_zscif_ctrl) \
     ((mp0_dfp_zscif_ctrl & MP0_DFP_ZSCIF_CTRL_ZSC_CLR_PULSE_MASK) >> MP0_DFP_ZSCIF_CTRL_ZSC_CLR_PULSE_SHIFT)

#define MP0_DFP_ZSCIF_CTRL_SET_ZSC_EN_PULSE(mp0_dfp_zscif_ctrl_reg, zsc_en_pulse) \
     mp0_dfp_zscif_ctrl_reg = (mp0_dfp_zscif_ctrl_reg & ~MP0_DFP_ZSCIF_CTRL_ZSC_EN_PULSE_MASK) | (zsc_en_pulse << MP0_DFP_ZSCIF_CTRL_ZSC_EN_PULSE_SHIFT)
#define MP0_DFP_ZSCIF_CTRL_SET_ZSC_IF_IDLE(mp0_dfp_zscif_ctrl_reg, zsc_if_idle) \
     mp0_dfp_zscif_ctrl_reg = (mp0_dfp_zscif_ctrl_reg & ~MP0_DFP_ZSCIF_CTRL_ZSC_IF_IDLE_MASK) | (zsc_if_idle << MP0_DFP_ZSCIF_CTRL_ZSC_IF_IDLE_SHIFT)
#define MP0_DFP_ZSCIF_CTRL_SET_ZSC_IF_FENCE_REQ(mp0_dfp_zscif_ctrl_reg, zsc_if_fence_req) \
     mp0_dfp_zscif_ctrl_reg = (mp0_dfp_zscif_ctrl_reg & ~MP0_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_REQ_MASK) | (zsc_if_fence_req << MP0_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_REQ_SHIFT)
#define MP0_DFP_ZSCIF_CTRL_SET_ZSC_IF_FENCE_ACK(mp0_dfp_zscif_ctrl_reg, zsc_if_fence_ack) \
     mp0_dfp_zscif_ctrl_reg = (mp0_dfp_zscif_ctrl_reg & ~MP0_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_ACK_MASK) | (zsc_if_fence_ack << MP0_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_ACK_SHIFT)
#define MP0_DFP_ZSCIF_CTRL_SET_ZSC_AXI_MASK(mp0_dfp_zscif_ctrl_reg, zsc_axi_mask) \
     mp0_dfp_zscif_ctrl_reg = (mp0_dfp_zscif_ctrl_reg & ~MP0_DFP_ZSCIF_CTRL_ZSC_AXI_MASK_MASK) | (zsc_axi_mask << MP0_DFP_ZSCIF_CTRL_ZSC_AXI_MASK_SHIFT)
#define MP0_DFP_ZSCIF_CTRL_SET_ZSC_INT_MASK(mp0_dfp_zscif_ctrl_reg, zsc_int_mask) \
     mp0_dfp_zscif_ctrl_reg = (mp0_dfp_zscif_ctrl_reg & ~MP0_DFP_ZSCIF_CTRL_ZSC_INT_MASK_MASK) | (zsc_int_mask << MP0_DFP_ZSCIF_CTRL_ZSC_INT_MASK_SHIFT)
#define MP0_DFP_ZSCIF_CTRL_SET_ZSC_INT_MASKED(mp0_dfp_zscif_ctrl_reg, zsc_int_masked) \
     mp0_dfp_zscif_ctrl_reg = (mp0_dfp_zscif_ctrl_reg & ~MP0_DFP_ZSCIF_CTRL_ZSC_INT_MASKED_MASK) | (zsc_int_masked << MP0_DFP_ZSCIF_CTRL_ZSC_INT_MASKED_SHIFT)
#define MP0_DFP_ZSCIF_CTRL_SET_ZSC_CLR_PULSE(mp0_dfp_zscif_ctrl_reg, zsc_clr_pulse) \
     mp0_dfp_zscif_ctrl_reg = (mp0_dfp_zscif_ctrl_reg & ~MP0_DFP_ZSCIF_CTRL_ZSC_CLR_PULSE_MASK) | (zsc_clr_pulse << MP0_DFP_ZSCIF_CTRL_ZSC_CLR_PULSE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_dfp_zscif_ctrl_t {
          unsigned int zsc_en_pulse                   : MP0_DFP_ZSCIF_CTRL_ZSC_EN_PULSE_SIZE;
          unsigned int zsc_if_idle                    : MP0_DFP_ZSCIF_CTRL_ZSC_IF_IDLE_SIZE;
          unsigned int zsc_if_fence_req               : MP0_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_REQ_SIZE;
          unsigned int zsc_if_fence_ack               : MP0_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_ACK_SIZE;
          unsigned int zsc_axi_mask                   : MP0_DFP_ZSCIF_CTRL_ZSC_AXI_MASK_SIZE;
          unsigned int zsc_int_mask                   : MP0_DFP_ZSCIF_CTRL_ZSC_INT_MASK_SIZE;
          unsigned int                                : 1;
          unsigned int zsc_int_masked                 : MP0_DFP_ZSCIF_CTRL_ZSC_INT_MASKED_SIZE;
          unsigned int zsc_clr_pulse                  : MP0_DFP_ZSCIF_CTRL_ZSC_CLR_PULSE_SIZE;
          unsigned int                                : 23;
     } mp0_dfp_zscif_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_dfp_zscif_ctrl_t {
          unsigned int                                : 23;
          unsigned int zsc_clr_pulse                  : MP0_DFP_ZSCIF_CTRL_ZSC_CLR_PULSE_SIZE;
          unsigned int zsc_int_masked                 : MP0_DFP_ZSCIF_CTRL_ZSC_INT_MASKED_SIZE;
          unsigned int                                : 1;
          unsigned int zsc_int_mask                   : MP0_DFP_ZSCIF_CTRL_ZSC_INT_MASK_SIZE;
          unsigned int zsc_axi_mask                   : MP0_DFP_ZSCIF_CTRL_ZSC_AXI_MASK_SIZE;
          unsigned int zsc_if_fence_ack               : MP0_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_ACK_SIZE;
          unsigned int zsc_if_fence_req               : MP0_DFP_ZSCIF_CTRL_ZSC_IF_FENCE_REQ_SIZE;
          unsigned int zsc_if_idle                    : MP0_DFP_ZSCIF_CTRL_ZSC_IF_IDLE_SIZE;
          unsigned int zsc_en_pulse                   : MP0_DFP_ZSCIF_CTRL_ZSC_EN_PULSE_SIZE;
     } mp0_dfp_zscif_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_dfp_zscif_ctrl_t f;
} mp0_dfp_zscif_ctrl_u;


/*
 * MP0_DFP_PGRAM_CRU_CNTL struct
 */

#define MP0_DFP_PGRAM_CRU_CNTL_REG_SIZE 32
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_SIZE 1
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_ROP_CRU_SIZE 1
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_SIZE 1
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_SIZE 1
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_SIZE 1
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_SIZE 1
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_SIZE 8
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_SIZE 8

#define MP0_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_SHIFT 0
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_ROP_CRU_SHIFT 1
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_SHIFT 2
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_SHIFT 3
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_SHIFT 4
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_SHIFT 5
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_SHIFT 8
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_SHIFT 16

#define MP0_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_MASK 0x1
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_ROP_CRU_MASK 0x2
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_MASK 0x4
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_MASK 0x8
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_MASK 0x10
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_MASK 0x20
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_MASK 0xff00
#define MP0_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_MASK 0xff0000

#define MP0_DFP_PGRAM_CRU_CNTL_MASK \
     (MP0_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_MASK | \
      MP0_DFP_PGRAM_CRU_CNTL_MEM_ROP_CRU_MASK | \
      MP0_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_MASK | \
      MP0_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_MASK | \
      MP0_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_MASK | \
      MP0_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_MASK | \
      MP0_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_MASK | \
      MP0_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_MASK)

#define MP0_DFP_PGRAM_CRU_CNTL_DEFAULT 0x0010102a

#define MP0_DFP_PGRAM_CRU_CNTL_GET_MEM_SD_CRU(mp0_dfp_pgram_cru_cntl) \
     ((mp0_dfp_pgram_cru_cntl & MP0_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_MASK) >> MP0_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_SHIFT)
#define MP0_DFP_PGRAM_CRU_CNTL_GET_MEM_ROP_CRU(mp0_dfp_pgram_cru_cntl) \
     ((mp0_dfp_pgram_cru_cntl & MP0_DFP_PGRAM_CRU_CNTL_MEM_ROP_CRU_MASK) >> MP0_DFP_PGRAM_CRU_CNTL_MEM_ROP_CRU_SHIFT)
#define MP0_DFP_PGRAM_CRU_CNTL_GET_MEM_DEEP_SLEEP_EN_CRU(mp0_dfp_pgram_cru_cntl) \
     ((mp0_dfp_pgram_cru_cntl & MP0_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_MASK) >> MP0_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_SHIFT)
#define MP0_DFP_PGRAM_CRU_CNTL_GET_MEM_DEEP_SLEEP_STATUS_CRU(mp0_dfp_pgram_cru_cntl) \
     ((mp0_dfp_pgram_cru_cntl & MP0_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_MASK) >> MP0_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_SHIFT)
#define MP0_DFP_PGRAM_CRU_CNTL_GET_MEM_LIGHT_SLEEP_EN_CRU(mp0_dfp_pgram_cru_cntl) \
     ((mp0_dfp_pgram_cru_cntl & MP0_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_MASK) >> MP0_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_SHIFT)
#define MP0_DFP_PGRAM_CRU_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_CRU(mp0_dfp_pgram_cru_cntl) \
     ((mp0_dfp_pgram_cru_cntl & MP0_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_MASK) >> MP0_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_SHIFT)
#define MP0_DFP_PGRAM_CRU_CNTL_GET_MEM_SLEEP_TIMEOUT_CRU(mp0_dfp_pgram_cru_cntl) \
     ((mp0_dfp_pgram_cru_cntl & MP0_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_MASK) >> MP0_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_SHIFT)
#define MP0_DFP_PGRAM_CRU_CNTL_GET_MEM_PG_DLY_CRU(mp0_dfp_pgram_cru_cntl) \
     ((mp0_dfp_pgram_cru_cntl & MP0_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_MASK) >> MP0_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_SHIFT)

#define MP0_DFP_PGRAM_CRU_CNTL_SET_MEM_SD_CRU(mp0_dfp_pgram_cru_cntl_reg, mem_sd_cru) \
     mp0_dfp_pgram_cru_cntl_reg = (mp0_dfp_pgram_cru_cntl_reg & ~MP0_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_MASK) | (mem_sd_cru << MP0_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_SHIFT)
#define MP0_DFP_PGRAM_CRU_CNTL_SET_MEM_ROP_CRU(mp0_dfp_pgram_cru_cntl_reg, mem_rop_cru) \
     mp0_dfp_pgram_cru_cntl_reg = (mp0_dfp_pgram_cru_cntl_reg & ~MP0_DFP_PGRAM_CRU_CNTL_MEM_ROP_CRU_MASK) | (mem_rop_cru << MP0_DFP_PGRAM_CRU_CNTL_MEM_ROP_CRU_SHIFT)
#define MP0_DFP_PGRAM_CRU_CNTL_SET_MEM_DEEP_SLEEP_EN_CRU(mp0_dfp_pgram_cru_cntl_reg, mem_deep_sleep_en_cru) \
     mp0_dfp_pgram_cru_cntl_reg = (mp0_dfp_pgram_cru_cntl_reg & ~MP0_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_MASK) | (mem_deep_sleep_en_cru << MP0_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_SHIFT)
#define MP0_DFP_PGRAM_CRU_CNTL_SET_MEM_DEEP_SLEEP_STATUS_CRU(mp0_dfp_pgram_cru_cntl_reg, mem_deep_sleep_status_cru) \
     mp0_dfp_pgram_cru_cntl_reg = (mp0_dfp_pgram_cru_cntl_reg & ~MP0_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_MASK) | (mem_deep_sleep_status_cru << MP0_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_SHIFT)
#define MP0_DFP_PGRAM_CRU_CNTL_SET_MEM_LIGHT_SLEEP_EN_CRU(mp0_dfp_pgram_cru_cntl_reg, mem_light_sleep_en_cru) \
     mp0_dfp_pgram_cru_cntl_reg = (mp0_dfp_pgram_cru_cntl_reg & ~MP0_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_MASK) | (mem_light_sleep_en_cru << MP0_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_SHIFT)
#define MP0_DFP_PGRAM_CRU_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_CRU(mp0_dfp_pgram_cru_cntl_reg, mem_light_sleep_status_cru) \
     mp0_dfp_pgram_cru_cntl_reg = (mp0_dfp_pgram_cru_cntl_reg & ~MP0_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_MASK) | (mem_light_sleep_status_cru << MP0_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_SHIFT)
#define MP0_DFP_PGRAM_CRU_CNTL_SET_MEM_SLEEP_TIMEOUT_CRU(mp0_dfp_pgram_cru_cntl_reg, mem_sleep_timeout_cru) \
     mp0_dfp_pgram_cru_cntl_reg = (mp0_dfp_pgram_cru_cntl_reg & ~MP0_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_MASK) | (mem_sleep_timeout_cru << MP0_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_SHIFT)
#define MP0_DFP_PGRAM_CRU_CNTL_SET_MEM_PG_DLY_CRU(mp0_dfp_pgram_cru_cntl_reg, mem_pg_dly_cru) \
     mp0_dfp_pgram_cru_cntl_reg = (mp0_dfp_pgram_cru_cntl_reg & ~MP0_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_MASK) | (mem_pg_dly_cru << MP0_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_dfp_pgram_cru_cntl_t {
          unsigned int mem_sd_cru                     : MP0_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_SIZE;
          unsigned int mem_rop_cru                    : MP0_DFP_PGRAM_CRU_CNTL_MEM_ROP_CRU_SIZE;
          unsigned int mem_deep_sleep_en_cru          : MP0_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_SIZE;
          unsigned int mem_deep_sleep_status_cru      : MP0_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_SIZE;
          unsigned int mem_light_sleep_en_cru         : MP0_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_SIZE;
          unsigned int mem_light_sleep_status_cru     : MP0_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_SIZE;
          unsigned int                                : 2;
          unsigned int mem_sleep_timeout_cru          : MP0_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_SIZE;
          unsigned int mem_pg_dly_cru                 : MP0_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_SIZE;
          unsigned int                                : 8;
     } mp0_dfp_pgram_cru_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_dfp_pgram_cru_cntl_t {
          unsigned int                                : 8;
          unsigned int mem_pg_dly_cru                 : MP0_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_SIZE;
          unsigned int mem_sleep_timeout_cru          : MP0_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_SIZE;
          unsigned int                                : 2;
          unsigned int mem_light_sleep_status_cru     : MP0_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_SIZE;
          unsigned int mem_light_sleep_en_cru         : MP0_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_SIZE;
          unsigned int mem_deep_sleep_status_cru      : MP0_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_SIZE;
          unsigned int mem_deep_sleep_en_cru          : MP0_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_SIZE;
          unsigned int mem_rop_cru                    : MP0_DFP_PGRAM_CRU_CNTL_MEM_ROP_CRU_SIZE;
          unsigned int mem_sd_cru                     : MP0_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_SIZE;
     } mp0_dfp_pgram_cru_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_dfp_pgram_cru_cntl_t f;
} mp0_dfp_pgram_cru_cntl_u;


/*
 * MP0_DFP_PGRAM_DRM_CNTL struct
 */

#define MP0_DFP_PGRAM_DRM_CNTL_REG_SIZE 32
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_SD_DRM_SIZE 1
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_ROP_DRM_SIZE 1
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_DEEP_SLEEP_EN_DRM_SIZE 1
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_DEEP_SLEEP_STATUS_DRM_SIZE 1
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_LIGHT_SLEEP_EN_DRM_SIZE 1
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_LIGHT_SLEEP_STATUS_DRM_SIZE 1
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_SLEEP_TIMEOUT_DRM_SIZE 8
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_PG_DLY_DRM_SIZE 8

#define MP0_DFP_PGRAM_DRM_CNTL_MEM_SD_DRM_SHIFT 0
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_ROP_DRM_SHIFT 1
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_DEEP_SLEEP_EN_DRM_SHIFT 2
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_DEEP_SLEEP_STATUS_DRM_SHIFT 3
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_LIGHT_SLEEP_EN_DRM_SHIFT 4
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_LIGHT_SLEEP_STATUS_DRM_SHIFT 5
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_SLEEP_TIMEOUT_DRM_SHIFT 8
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_PG_DLY_DRM_SHIFT 16

#define MP0_DFP_PGRAM_DRM_CNTL_MEM_SD_DRM_MASK 0x1
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_ROP_DRM_MASK 0x2
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_DEEP_SLEEP_EN_DRM_MASK 0x4
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_DEEP_SLEEP_STATUS_DRM_MASK 0x8
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_LIGHT_SLEEP_EN_DRM_MASK 0x10
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_LIGHT_SLEEP_STATUS_DRM_MASK 0x20
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_SLEEP_TIMEOUT_DRM_MASK 0xff00
#define MP0_DFP_PGRAM_DRM_CNTL_MEM_PG_DLY_DRM_MASK 0xff0000

#define MP0_DFP_PGRAM_DRM_CNTL_MASK \
     (MP0_DFP_PGRAM_DRM_CNTL_MEM_SD_DRM_MASK | \
      MP0_DFP_PGRAM_DRM_CNTL_MEM_ROP_DRM_MASK | \
      MP0_DFP_PGRAM_DRM_CNTL_MEM_DEEP_SLEEP_EN_DRM_MASK | \
      MP0_DFP_PGRAM_DRM_CNTL_MEM_DEEP_SLEEP_STATUS_DRM_MASK | \
      MP0_DFP_PGRAM_DRM_CNTL_MEM_LIGHT_SLEEP_EN_DRM_MASK | \
      MP0_DFP_PGRAM_DRM_CNTL_MEM_LIGHT_SLEEP_STATUS_DRM_MASK | \
      MP0_DFP_PGRAM_DRM_CNTL_MEM_SLEEP_TIMEOUT_DRM_MASK | \
      MP0_DFP_PGRAM_DRM_CNTL_MEM_PG_DLY_DRM_MASK)

#define MP0_DFP_PGRAM_DRM_CNTL_DEFAULT 0x0010102a

#define MP0_DFP_PGRAM_DRM_CNTL_GET_MEM_SD_DRM(mp0_dfp_pgram_drm_cntl) \
     ((mp0_dfp_pgram_drm_cntl & MP0_DFP_PGRAM_DRM_CNTL_MEM_SD_DRM_MASK) >> MP0_DFP_PGRAM_DRM_CNTL_MEM_SD_DRM_SHIFT)
#define MP0_DFP_PGRAM_DRM_CNTL_GET_MEM_ROP_DRM(mp0_dfp_pgram_drm_cntl) \
     ((mp0_dfp_pgram_drm_cntl & MP0_DFP_PGRAM_DRM_CNTL_MEM_ROP_DRM_MASK) >> MP0_DFP_PGRAM_DRM_CNTL_MEM_ROP_DRM_SHIFT)
#define MP0_DFP_PGRAM_DRM_CNTL_GET_MEM_DEEP_SLEEP_EN_DRM(mp0_dfp_pgram_drm_cntl) \
     ((mp0_dfp_pgram_drm_cntl & MP0_DFP_PGRAM_DRM_CNTL_MEM_DEEP_SLEEP_EN_DRM_MASK) >> MP0_DFP_PGRAM_DRM_CNTL_MEM_DEEP_SLEEP_EN_DRM_SHIFT)
#define MP0_DFP_PGRAM_DRM_CNTL_GET_MEM_DEEP_SLEEP_STATUS_DRM(mp0_dfp_pgram_drm_cntl) \
     ((mp0_dfp_pgram_drm_cntl & MP0_DFP_PGRAM_DRM_CNTL_MEM_DEEP_SLEEP_STATUS_DRM_MASK) >> MP0_DFP_PGRAM_DRM_CNTL_MEM_DEEP_SLEEP_STATUS_DRM_SHIFT)
#define MP0_DFP_PGRAM_DRM_CNTL_GET_MEM_LIGHT_SLEEP_EN_DRM(mp0_dfp_pgram_drm_cntl) \
     ((mp0_dfp_pgram_drm_cntl & MP0_DFP_PGRAM_DRM_CNTL_MEM_LIGHT_SLEEP_EN_DRM_MASK) >> MP0_DFP_PGRAM_DRM_CNTL_MEM_LIGHT_SLEEP_EN_DRM_SHIFT)
#define MP0_DFP_PGRAM_DRM_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_DRM(mp0_dfp_pgram_drm_cntl) \
     ((mp0_dfp_pgram_drm_cntl & MP0_DFP_PGRAM_DRM_CNTL_MEM_LIGHT_SLEEP_STATUS_DRM_MASK) >> MP0_DFP_PGRAM_DRM_CNTL_MEM_LIGHT_SLEEP_STATUS_DRM_SHIFT)
#define MP0_DFP_PGRAM_DRM_CNTL_GET_MEM_SLEEP_TIMEOUT_DRM(mp0_dfp_pgram_drm_cntl) \
     ((mp0_dfp_pgram_drm_cntl & MP0_DFP_PGRAM_DRM_CNTL_MEM_SLEEP_TIMEOUT_DRM_MASK) >> MP0_DFP_PGRAM_DRM_CNTL_MEM_SLEEP_TIMEOUT_DRM_SHIFT)
#define MP0_DFP_PGRAM_DRM_CNTL_GET_MEM_PG_DLY_DRM(mp0_dfp_pgram_drm_cntl) \
     ((mp0_dfp_pgram_drm_cntl & MP0_DFP_PGRAM_DRM_CNTL_MEM_PG_DLY_DRM_MASK) >> MP0_DFP_PGRAM_DRM_CNTL_MEM_PG_DLY_DRM_SHIFT)

#define MP0_DFP_PGRAM_DRM_CNTL_SET_MEM_SD_DRM(mp0_dfp_pgram_drm_cntl_reg, mem_sd_drm) \
     mp0_dfp_pgram_drm_cntl_reg = (mp0_dfp_pgram_drm_cntl_reg & ~MP0_DFP_PGRAM_DRM_CNTL_MEM_SD_DRM_MASK) | (mem_sd_drm << MP0_DFP_PGRAM_DRM_CNTL_MEM_SD_DRM_SHIFT)
#define MP0_DFP_PGRAM_DRM_CNTL_SET_MEM_ROP_DRM(mp0_dfp_pgram_drm_cntl_reg, mem_rop_drm) \
     mp0_dfp_pgram_drm_cntl_reg = (mp0_dfp_pgram_drm_cntl_reg & ~MP0_DFP_PGRAM_DRM_CNTL_MEM_ROP_DRM_MASK) | (mem_rop_drm << MP0_DFP_PGRAM_DRM_CNTL_MEM_ROP_DRM_SHIFT)
#define MP0_DFP_PGRAM_DRM_CNTL_SET_MEM_DEEP_SLEEP_EN_DRM(mp0_dfp_pgram_drm_cntl_reg, mem_deep_sleep_en_drm) \
     mp0_dfp_pgram_drm_cntl_reg = (mp0_dfp_pgram_drm_cntl_reg & ~MP0_DFP_PGRAM_DRM_CNTL_MEM_DEEP_SLEEP_EN_DRM_MASK) | (mem_deep_sleep_en_drm << MP0_DFP_PGRAM_DRM_CNTL_MEM_DEEP_SLEEP_EN_DRM_SHIFT)
#define MP0_DFP_PGRAM_DRM_CNTL_SET_MEM_DEEP_SLEEP_STATUS_DRM(mp0_dfp_pgram_drm_cntl_reg, mem_deep_sleep_status_drm) \
     mp0_dfp_pgram_drm_cntl_reg = (mp0_dfp_pgram_drm_cntl_reg & ~MP0_DFP_PGRAM_DRM_CNTL_MEM_DEEP_SLEEP_STATUS_DRM_MASK) | (mem_deep_sleep_status_drm << MP0_DFP_PGRAM_DRM_CNTL_MEM_DEEP_SLEEP_STATUS_DRM_SHIFT)
#define MP0_DFP_PGRAM_DRM_CNTL_SET_MEM_LIGHT_SLEEP_EN_DRM(mp0_dfp_pgram_drm_cntl_reg, mem_light_sleep_en_drm) \
     mp0_dfp_pgram_drm_cntl_reg = (mp0_dfp_pgram_drm_cntl_reg & ~MP0_DFP_PGRAM_DRM_CNTL_MEM_LIGHT_SLEEP_EN_DRM_MASK) | (mem_light_sleep_en_drm << MP0_DFP_PGRAM_DRM_CNTL_MEM_LIGHT_SLEEP_EN_DRM_SHIFT)
#define MP0_DFP_PGRAM_DRM_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_DRM(mp0_dfp_pgram_drm_cntl_reg, mem_light_sleep_status_drm) \
     mp0_dfp_pgram_drm_cntl_reg = (mp0_dfp_pgram_drm_cntl_reg & ~MP0_DFP_PGRAM_DRM_CNTL_MEM_LIGHT_SLEEP_STATUS_DRM_MASK) | (mem_light_sleep_status_drm << MP0_DFP_PGRAM_DRM_CNTL_MEM_LIGHT_SLEEP_STATUS_DRM_SHIFT)
#define MP0_DFP_PGRAM_DRM_CNTL_SET_MEM_SLEEP_TIMEOUT_DRM(mp0_dfp_pgram_drm_cntl_reg, mem_sleep_timeout_drm) \
     mp0_dfp_pgram_drm_cntl_reg = (mp0_dfp_pgram_drm_cntl_reg & ~MP0_DFP_PGRAM_DRM_CNTL_MEM_SLEEP_TIMEOUT_DRM_MASK) | (mem_sleep_timeout_drm << MP0_DFP_PGRAM_DRM_CNTL_MEM_SLEEP_TIMEOUT_DRM_SHIFT)
#define MP0_DFP_PGRAM_DRM_CNTL_SET_MEM_PG_DLY_DRM(mp0_dfp_pgram_drm_cntl_reg, mem_pg_dly_drm) \
     mp0_dfp_pgram_drm_cntl_reg = (mp0_dfp_pgram_drm_cntl_reg & ~MP0_DFP_PGRAM_DRM_CNTL_MEM_PG_DLY_DRM_MASK) | (mem_pg_dly_drm << MP0_DFP_PGRAM_DRM_CNTL_MEM_PG_DLY_DRM_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_dfp_pgram_drm_cntl_t {
          unsigned int mem_sd_drm                     : MP0_DFP_PGRAM_DRM_CNTL_MEM_SD_DRM_SIZE;
          unsigned int mem_rop_drm                    : MP0_DFP_PGRAM_DRM_CNTL_MEM_ROP_DRM_SIZE;
          unsigned int mem_deep_sleep_en_drm          : MP0_DFP_PGRAM_DRM_CNTL_MEM_DEEP_SLEEP_EN_DRM_SIZE;
          unsigned int mem_deep_sleep_status_drm      : MP0_DFP_PGRAM_DRM_CNTL_MEM_DEEP_SLEEP_STATUS_DRM_SIZE;
          unsigned int mem_light_sleep_en_drm         : MP0_DFP_PGRAM_DRM_CNTL_MEM_LIGHT_SLEEP_EN_DRM_SIZE;
          unsigned int mem_light_sleep_status_drm     : MP0_DFP_PGRAM_DRM_CNTL_MEM_LIGHT_SLEEP_STATUS_DRM_SIZE;
          unsigned int                                : 2;
          unsigned int mem_sleep_timeout_drm          : MP0_DFP_PGRAM_DRM_CNTL_MEM_SLEEP_TIMEOUT_DRM_SIZE;
          unsigned int mem_pg_dly_drm                 : MP0_DFP_PGRAM_DRM_CNTL_MEM_PG_DLY_DRM_SIZE;
          unsigned int                                : 8;
     } mp0_dfp_pgram_drm_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_dfp_pgram_drm_cntl_t {
          unsigned int                                : 8;
          unsigned int mem_pg_dly_drm                 : MP0_DFP_PGRAM_DRM_CNTL_MEM_PG_DLY_DRM_SIZE;
          unsigned int mem_sleep_timeout_drm          : MP0_DFP_PGRAM_DRM_CNTL_MEM_SLEEP_TIMEOUT_DRM_SIZE;
          unsigned int                                : 2;
          unsigned int mem_light_sleep_status_drm     : MP0_DFP_PGRAM_DRM_CNTL_MEM_LIGHT_SLEEP_STATUS_DRM_SIZE;
          unsigned int mem_light_sleep_en_drm         : MP0_DFP_PGRAM_DRM_CNTL_MEM_LIGHT_SLEEP_EN_DRM_SIZE;
          unsigned int mem_deep_sleep_status_drm      : MP0_DFP_PGRAM_DRM_CNTL_MEM_DEEP_SLEEP_STATUS_DRM_SIZE;
          unsigned int mem_deep_sleep_en_drm          : MP0_DFP_PGRAM_DRM_CNTL_MEM_DEEP_SLEEP_EN_DRM_SIZE;
          unsigned int mem_rop_drm                    : MP0_DFP_PGRAM_DRM_CNTL_MEM_ROP_DRM_SIZE;
          unsigned int mem_sd_drm                     : MP0_DFP_PGRAM_DRM_CNTL_MEM_SD_DRM_SIZE;
     } mp0_dfp_pgram_drm_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_dfp_pgram_drm_cntl_t f;
} mp0_dfp_pgram_drm_cntl_u;


/*
 * MP0_DFP_PGRAM_MMU_CNTL struct
 */

#define MP0_DFP_PGRAM_MMU_CNTL_REG_SIZE 32
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_SIZE 1
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_ROP_MMU_SIZE 1
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_SIZE 1
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_SIZE 1
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_SIZE 1
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_SIZE 1
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_SIZE 8
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_SIZE 8

#define MP0_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_SHIFT 0
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_ROP_MMU_SHIFT 1
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_SHIFT 2
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_SHIFT 3
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_SHIFT 4
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_SHIFT 5
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_SHIFT 8
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_SHIFT 16

#define MP0_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_MASK 0x1
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_ROP_MMU_MASK 0x2
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_MASK 0x4
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_MASK 0x8
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_MASK 0x10
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_MASK 0x20
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_MASK 0xff00
#define MP0_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_MASK 0xff0000

#define MP0_DFP_PGRAM_MMU_CNTL_MASK \
     (MP0_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_MASK | \
      MP0_DFP_PGRAM_MMU_CNTL_MEM_ROP_MMU_MASK | \
      MP0_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_MASK | \
      MP0_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_MASK | \
      MP0_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_MASK | \
      MP0_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_MASK | \
      MP0_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_MASK | \
      MP0_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_MASK)

#define MP0_DFP_PGRAM_MMU_CNTL_DEFAULT 0x0010102a

#define MP0_DFP_PGRAM_MMU_CNTL_GET_MEM_SD_MMU(mp0_dfp_pgram_mmu_cntl) \
     ((mp0_dfp_pgram_mmu_cntl & MP0_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_MASK) >> MP0_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_SHIFT)
#define MP0_DFP_PGRAM_MMU_CNTL_GET_MEM_ROP_MMU(mp0_dfp_pgram_mmu_cntl) \
     ((mp0_dfp_pgram_mmu_cntl & MP0_DFP_PGRAM_MMU_CNTL_MEM_ROP_MMU_MASK) >> MP0_DFP_PGRAM_MMU_CNTL_MEM_ROP_MMU_SHIFT)
#define MP0_DFP_PGRAM_MMU_CNTL_GET_MEM_DEEP_SLEEP_EN_MMU(mp0_dfp_pgram_mmu_cntl) \
     ((mp0_dfp_pgram_mmu_cntl & MP0_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_MASK) >> MP0_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_SHIFT)
#define MP0_DFP_PGRAM_MMU_CNTL_GET_MEM_DEEP_SLEEP_STATUS_MMU(mp0_dfp_pgram_mmu_cntl) \
     ((mp0_dfp_pgram_mmu_cntl & MP0_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_MASK) >> MP0_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_SHIFT)
#define MP0_DFP_PGRAM_MMU_CNTL_GET_MEM_LIGHT_SLEEP_EN_MMU(mp0_dfp_pgram_mmu_cntl) \
     ((mp0_dfp_pgram_mmu_cntl & MP0_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_MASK) >> MP0_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_SHIFT)
#define MP0_DFP_PGRAM_MMU_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_MMU(mp0_dfp_pgram_mmu_cntl) \
     ((mp0_dfp_pgram_mmu_cntl & MP0_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_MASK) >> MP0_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_SHIFT)
#define MP0_DFP_PGRAM_MMU_CNTL_GET_MEM_SLEEP_TIMEOUT_MMU(mp0_dfp_pgram_mmu_cntl) \
     ((mp0_dfp_pgram_mmu_cntl & MP0_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_MASK) >> MP0_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_SHIFT)
#define MP0_DFP_PGRAM_MMU_CNTL_GET_MEM_PG_DLY_MMU(mp0_dfp_pgram_mmu_cntl) \
     ((mp0_dfp_pgram_mmu_cntl & MP0_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_MASK) >> MP0_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_SHIFT)

#define MP0_DFP_PGRAM_MMU_CNTL_SET_MEM_SD_MMU(mp0_dfp_pgram_mmu_cntl_reg, mem_sd_mmu) \
     mp0_dfp_pgram_mmu_cntl_reg = (mp0_dfp_pgram_mmu_cntl_reg & ~MP0_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_MASK) | (mem_sd_mmu << MP0_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_SHIFT)
#define MP0_DFP_PGRAM_MMU_CNTL_SET_MEM_ROP_MMU(mp0_dfp_pgram_mmu_cntl_reg, mem_rop_mmu) \
     mp0_dfp_pgram_mmu_cntl_reg = (mp0_dfp_pgram_mmu_cntl_reg & ~MP0_DFP_PGRAM_MMU_CNTL_MEM_ROP_MMU_MASK) | (mem_rop_mmu << MP0_DFP_PGRAM_MMU_CNTL_MEM_ROP_MMU_SHIFT)
#define MP0_DFP_PGRAM_MMU_CNTL_SET_MEM_DEEP_SLEEP_EN_MMU(mp0_dfp_pgram_mmu_cntl_reg, mem_deep_sleep_en_mmu) \
     mp0_dfp_pgram_mmu_cntl_reg = (mp0_dfp_pgram_mmu_cntl_reg & ~MP0_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_MASK) | (mem_deep_sleep_en_mmu << MP0_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_SHIFT)
#define MP0_DFP_PGRAM_MMU_CNTL_SET_MEM_DEEP_SLEEP_STATUS_MMU(mp0_dfp_pgram_mmu_cntl_reg, mem_deep_sleep_status_mmu) \
     mp0_dfp_pgram_mmu_cntl_reg = (mp0_dfp_pgram_mmu_cntl_reg & ~MP0_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_MASK) | (mem_deep_sleep_status_mmu << MP0_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_SHIFT)
#define MP0_DFP_PGRAM_MMU_CNTL_SET_MEM_LIGHT_SLEEP_EN_MMU(mp0_dfp_pgram_mmu_cntl_reg, mem_light_sleep_en_mmu) \
     mp0_dfp_pgram_mmu_cntl_reg = (mp0_dfp_pgram_mmu_cntl_reg & ~MP0_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_MASK) | (mem_light_sleep_en_mmu << MP0_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_SHIFT)
#define MP0_DFP_PGRAM_MMU_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_MMU(mp0_dfp_pgram_mmu_cntl_reg, mem_light_sleep_status_mmu) \
     mp0_dfp_pgram_mmu_cntl_reg = (mp0_dfp_pgram_mmu_cntl_reg & ~MP0_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_MASK) | (mem_light_sleep_status_mmu << MP0_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_SHIFT)
#define MP0_DFP_PGRAM_MMU_CNTL_SET_MEM_SLEEP_TIMEOUT_MMU(mp0_dfp_pgram_mmu_cntl_reg, mem_sleep_timeout_mmu) \
     mp0_dfp_pgram_mmu_cntl_reg = (mp0_dfp_pgram_mmu_cntl_reg & ~MP0_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_MASK) | (mem_sleep_timeout_mmu << MP0_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_SHIFT)
#define MP0_DFP_PGRAM_MMU_CNTL_SET_MEM_PG_DLY_MMU(mp0_dfp_pgram_mmu_cntl_reg, mem_pg_dly_mmu) \
     mp0_dfp_pgram_mmu_cntl_reg = (mp0_dfp_pgram_mmu_cntl_reg & ~MP0_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_MASK) | (mem_pg_dly_mmu << MP0_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_dfp_pgram_mmu_cntl_t {
          unsigned int mem_sd_mmu                     : MP0_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_SIZE;
          unsigned int mem_rop_mmu                    : MP0_DFP_PGRAM_MMU_CNTL_MEM_ROP_MMU_SIZE;
          unsigned int mem_deep_sleep_en_mmu          : MP0_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_SIZE;
          unsigned int mem_deep_sleep_status_mmu      : MP0_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_SIZE;
          unsigned int mem_light_sleep_en_mmu         : MP0_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_SIZE;
          unsigned int mem_light_sleep_status_mmu     : MP0_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_SIZE;
          unsigned int                                : 2;
          unsigned int mem_sleep_timeout_mmu          : MP0_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_SIZE;
          unsigned int mem_pg_dly_mmu                 : MP0_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_SIZE;
          unsigned int                                : 8;
     } mp0_dfp_pgram_mmu_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_dfp_pgram_mmu_cntl_t {
          unsigned int                                : 8;
          unsigned int mem_pg_dly_mmu                 : MP0_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_SIZE;
          unsigned int mem_sleep_timeout_mmu          : MP0_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_SIZE;
          unsigned int                                : 2;
          unsigned int mem_light_sleep_status_mmu     : MP0_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_SIZE;
          unsigned int mem_light_sleep_en_mmu         : MP0_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_SIZE;
          unsigned int mem_deep_sleep_status_mmu      : MP0_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_SIZE;
          unsigned int mem_deep_sleep_en_mmu          : MP0_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_SIZE;
          unsigned int mem_rop_mmu                    : MP0_DFP_PGRAM_MMU_CNTL_MEM_ROP_MMU_SIZE;
          unsigned int mem_sd_mmu                     : MP0_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_SIZE;
     } mp0_dfp_pgram_mmu_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_dfp_pgram_mmu_cntl_t f;
} mp0_dfp_pgram_mmu_cntl_u;


/*
 * MP0_DFP_PGRAM_CPU_CNTL struct
 */

#define MP0_DFP_PGRAM_CPU_CNTL_REG_SIZE 32
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_SIZE 1
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_ROP_CPU_SIZE 1
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_SIZE 1
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_SIZE 1
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_SIZE 1
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_SIZE 1
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_SIZE 8
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_SIZE 8

#define MP0_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_SHIFT 0
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_ROP_CPU_SHIFT 1
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_SHIFT 2
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_SHIFT 3
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_SHIFT 4
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_SHIFT 5
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_SHIFT 8
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_SHIFT 16

#define MP0_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_MASK 0x1
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_ROP_CPU_MASK 0x2
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_MASK 0x4
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_MASK 0x8
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_MASK 0x10
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_MASK 0x20
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_MASK 0xff00
#define MP0_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_MASK 0xff0000

#define MP0_DFP_PGRAM_CPU_CNTL_MASK \
     (MP0_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_MASK | \
      MP0_DFP_PGRAM_CPU_CNTL_MEM_ROP_CPU_MASK | \
      MP0_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_MASK | \
      MP0_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_MASK | \
      MP0_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_MASK | \
      MP0_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_MASK | \
      MP0_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_MASK | \
      MP0_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_MASK)

#define MP0_DFP_PGRAM_CPU_CNTL_DEFAULT 0x0010102a

#define MP0_DFP_PGRAM_CPU_CNTL_GET_MEM_SD_CPU(mp0_dfp_pgram_cpu_cntl) \
     ((mp0_dfp_pgram_cpu_cntl & MP0_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_MASK) >> MP0_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_SHIFT)
#define MP0_DFP_PGRAM_CPU_CNTL_GET_MEM_ROP_CPU(mp0_dfp_pgram_cpu_cntl) \
     ((mp0_dfp_pgram_cpu_cntl & MP0_DFP_PGRAM_CPU_CNTL_MEM_ROP_CPU_MASK) >> MP0_DFP_PGRAM_CPU_CNTL_MEM_ROP_CPU_SHIFT)
#define MP0_DFP_PGRAM_CPU_CNTL_GET_MEM_DEEP_SLEEP_EN_CPU(mp0_dfp_pgram_cpu_cntl) \
     ((mp0_dfp_pgram_cpu_cntl & MP0_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_MASK) >> MP0_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_SHIFT)
#define MP0_DFP_PGRAM_CPU_CNTL_GET_MEM_DEEP_SLEEP_STATUS_CPU(mp0_dfp_pgram_cpu_cntl) \
     ((mp0_dfp_pgram_cpu_cntl & MP0_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_MASK) >> MP0_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_SHIFT)
#define MP0_DFP_PGRAM_CPU_CNTL_GET_MEM_LIGHT_SLEEP_EN_CPU(mp0_dfp_pgram_cpu_cntl) \
     ((mp0_dfp_pgram_cpu_cntl & MP0_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_MASK) >> MP0_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_SHIFT)
#define MP0_DFP_PGRAM_CPU_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_CPU(mp0_dfp_pgram_cpu_cntl) \
     ((mp0_dfp_pgram_cpu_cntl & MP0_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_MASK) >> MP0_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_SHIFT)
#define MP0_DFP_PGRAM_CPU_CNTL_GET_MEM_SLEEP_TIMEOUT_CPU(mp0_dfp_pgram_cpu_cntl) \
     ((mp0_dfp_pgram_cpu_cntl & MP0_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_MASK) >> MP0_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_SHIFT)
#define MP0_DFP_PGRAM_CPU_CNTL_GET_MEM_PG_DLY_CPU(mp0_dfp_pgram_cpu_cntl) \
     ((mp0_dfp_pgram_cpu_cntl & MP0_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_MASK) >> MP0_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_SHIFT)

#define MP0_DFP_PGRAM_CPU_CNTL_SET_MEM_SD_CPU(mp0_dfp_pgram_cpu_cntl_reg, mem_sd_cpu) \
     mp0_dfp_pgram_cpu_cntl_reg = (mp0_dfp_pgram_cpu_cntl_reg & ~MP0_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_MASK) | (mem_sd_cpu << MP0_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_SHIFT)
#define MP0_DFP_PGRAM_CPU_CNTL_SET_MEM_ROP_CPU(mp0_dfp_pgram_cpu_cntl_reg, mem_rop_cpu) \
     mp0_dfp_pgram_cpu_cntl_reg = (mp0_dfp_pgram_cpu_cntl_reg & ~MP0_DFP_PGRAM_CPU_CNTL_MEM_ROP_CPU_MASK) | (mem_rop_cpu << MP0_DFP_PGRAM_CPU_CNTL_MEM_ROP_CPU_SHIFT)
#define MP0_DFP_PGRAM_CPU_CNTL_SET_MEM_DEEP_SLEEP_EN_CPU(mp0_dfp_pgram_cpu_cntl_reg, mem_deep_sleep_en_cpu) \
     mp0_dfp_pgram_cpu_cntl_reg = (mp0_dfp_pgram_cpu_cntl_reg & ~MP0_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_MASK) | (mem_deep_sleep_en_cpu << MP0_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_SHIFT)
#define MP0_DFP_PGRAM_CPU_CNTL_SET_MEM_DEEP_SLEEP_STATUS_CPU(mp0_dfp_pgram_cpu_cntl_reg, mem_deep_sleep_status_cpu) \
     mp0_dfp_pgram_cpu_cntl_reg = (mp0_dfp_pgram_cpu_cntl_reg & ~MP0_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_MASK) | (mem_deep_sleep_status_cpu << MP0_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_SHIFT)
#define MP0_DFP_PGRAM_CPU_CNTL_SET_MEM_LIGHT_SLEEP_EN_CPU(mp0_dfp_pgram_cpu_cntl_reg, mem_light_sleep_en_cpu) \
     mp0_dfp_pgram_cpu_cntl_reg = (mp0_dfp_pgram_cpu_cntl_reg & ~MP0_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_MASK) | (mem_light_sleep_en_cpu << MP0_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_SHIFT)
#define MP0_DFP_PGRAM_CPU_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_CPU(mp0_dfp_pgram_cpu_cntl_reg, mem_light_sleep_status_cpu) \
     mp0_dfp_pgram_cpu_cntl_reg = (mp0_dfp_pgram_cpu_cntl_reg & ~MP0_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_MASK) | (mem_light_sleep_status_cpu << MP0_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_SHIFT)
#define MP0_DFP_PGRAM_CPU_CNTL_SET_MEM_SLEEP_TIMEOUT_CPU(mp0_dfp_pgram_cpu_cntl_reg, mem_sleep_timeout_cpu) \
     mp0_dfp_pgram_cpu_cntl_reg = (mp0_dfp_pgram_cpu_cntl_reg & ~MP0_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_MASK) | (mem_sleep_timeout_cpu << MP0_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_SHIFT)
#define MP0_DFP_PGRAM_CPU_CNTL_SET_MEM_PG_DLY_CPU(mp0_dfp_pgram_cpu_cntl_reg, mem_pg_dly_cpu) \
     mp0_dfp_pgram_cpu_cntl_reg = (mp0_dfp_pgram_cpu_cntl_reg & ~MP0_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_MASK) | (mem_pg_dly_cpu << MP0_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_dfp_pgram_cpu_cntl_t {
          unsigned int mem_sd_cpu                     : MP0_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_SIZE;
          unsigned int mem_rop_cpu                    : MP0_DFP_PGRAM_CPU_CNTL_MEM_ROP_CPU_SIZE;
          unsigned int mem_deep_sleep_en_cpu          : MP0_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_SIZE;
          unsigned int mem_deep_sleep_status_cpu      : MP0_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_SIZE;
          unsigned int mem_light_sleep_en_cpu         : MP0_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_SIZE;
          unsigned int mem_light_sleep_status_cpu     : MP0_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_SIZE;
          unsigned int                                : 2;
          unsigned int mem_sleep_timeout_cpu          : MP0_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_SIZE;
          unsigned int mem_pg_dly_cpu                 : MP0_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_SIZE;
          unsigned int                                : 8;
     } mp0_dfp_pgram_cpu_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_dfp_pgram_cpu_cntl_t {
          unsigned int                                : 8;
          unsigned int mem_pg_dly_cpu                 : MP0_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_SIZE;
          unsigned int mem_sleep_timeout_cpu          : MP0_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_SIZE;
          unsigned int                                : 2;
          unsigned int mem_light_sleep_status_cpu     : MP0_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_SIZE;
          unsigned int mem_light_sleep_en_cpu         : MP0_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_SIZE;
          unsigned int mem_deep_sleep_status_cpu      : MP0_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_SIZE;
          unsigned int mem_deep_sleep_en_cpu          : MP0_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_SIZE;
          unsigned int mem_rop_cpu                    : MP0_DFP_PGRAM_CPU_CNTL_MEM_ROP_CPU_SIZE;
          unsigned int mem_sd_cpu                     : MP0_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_SIZE;
     } mp0_dfp_pgram_cpu_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_dfp_pgram_cpu_cntl_t f;
} mp0_dfp_pgram_cpu_cntl_u;


/*
 * MP0_DFP_MPCLKDS_CTRL struct
 */

#define MP0_DFP_MPCLKDS_CTRL_REG_SIZE  32
#define MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SIZE 1
#define MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SIZE 1
#define MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SIZE 8
#define MP0_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SIZE 1
#define MP0_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SIZE 1
#define MP0_DFP_MPCLKDS_CTRL_MPCLK_CCP1_WAKE_MASK_SIZE 1

#define MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SHIFT 0
#define MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SHIFT 1
#define MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SHIFT 2
#define MP0_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SHIFT 10
#define MP0_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SHIFT 11
#define MP0_DFP_MPCLKDS_CTRL_MPCLK_CCP1_WAKE_MASK_SHIFT 12

#define MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_MASK 0x1
#define MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_MASK 0x2
#define MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_MASK 0x3fc
#define MP0_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_MASK 0x400
#define MP0_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_MASK 0x800
#define MP0_DFP_MPCLKDS_CTRL_MPCLK_CCP1_WAKE_MASK_MASK 0x1000

#define MP0_DFP_MPCLKDS_CTRL_MASK \
     (MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_MASK | \
      MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_MASK | \
      MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_MASK | \
      MP0_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_MASK | \
      MP0_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_MASK | \
      MP0_DFP_MPCLKDS_CTRL_MPCLK_CCP1_WAKE_MASK_MASK)

#define MP0_DFP_MPCLKDS_CTRL_DEFAULT   0x00001ffc

#define MP0_DFP_MPCLKDS_CTRL_GET_MPCLK_DS_ENB(mp0_dfp_mpclkds_ctrl) \
     ((mp0_dfp_mpclkds_ctrl & MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_MASK) >> MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SHIFT)
#define MP0_DFP_MPCLKDS_CTRL_GET_MPCLK_DS_STATUS(mp0_dfp_mpclkds_ctrl) \
     ((mp0_dfp_mpclkds_ctrl & MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_MASK) >> MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SHIFT)
#define MP0_DFP_MPCLKDS_CTRL_GET_MPCLK_DS_TIMEOUT(mp0_dfp_mpclkds_ctrl) \
     ((mp0_dfp_mpclkds_ctrl & MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_MASK) >> MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SHIFT)
#define MP0_DFP_MPCLKDS_CTRL_GET_MPCLK_CPUINTR_WAKE_MASK(mp0_dfp_mpclkds_ctrl) \
     ((mp0_dfp_mpclkds_ctrl & MP0_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_MASK) >> MP0_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SHIFT)
#define MP0_DFP_MPCLKDS_CTRL_GET_MPCLK_SMN_WAKE_MASK(mp0_dfp_mpclkds_ctrl) \
     ((mp0_dfp_mpclkds_ctrl & MP0_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_MASK) >> MP0_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SHIFT)
#define MP0_DFP_MPCLKDS_CTRL_GET_MPCLK_CCP1_WAKE_MASK(mp0_dfp_mpclkds_ctrl) \
     ((mp0_dfp_mpclkds_ctrl & MP0_DFP_MPCLKDS_CTRL_MPCLK_CCP1_WAKE_MASK_MASK) >> MP0_DFP_MPCLKDS_CTRL_MPCLK_CCP1_WAKE_MASK_SHIFT)

#define MP0_DFP_MPCLKDS_CTRL_SET_MPCLK_DS_ENB(mp0_dfp_mpclkds_ctrl_reg, mpclk_ds_enb) \
     mp0_dfp_mpclkds_ctrl_reg = (mp0_dfp_mpclkds_ctrl_reg & ~MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_MASK) | (mpclk_ds_enb << MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SHIFT)
#define MP0_DFP_MPCLKDS_CTRL_SET_MPCLK_DS_STATUS(mp0_dfp_mpclkds_ctrl_reg, mpclk_ds_status) \
     mp0_dfp_mpclkds_ctrl_reg = (mp0_dfp_mpclkds_ctrl_reg & ~MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_MASK) | (mpclk_ds_status << MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SHIFT)
#define MP0_DFP_MPCLKDS_CTRL_SET_MPCLK_DS_TIMEOUT(mp0_dfp_mpclkds_ctrl_reg, mpclk_ds_timeout) \
     mp0_dfp_mpclkds_ctrl_reg = (mp0_dfp_mpclkds_ctrl_reg & ~MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_MASK) | (mpclk_ds_timeout << MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SHIFT)
#define MP0_DFP_MPCLKDS_CTRL_SET_MPCLK_CPUINTR_WAKE_MASK(mp0_dfp_mpclkds_ctrl_reg, mpclk_cpuintr_wake_mask) \
     mp0_dfp_mpclkds_ctrl_reg = (mp0_dfp_mpclkds_ctrl_reg & ~MP0_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_MASK) | (mpclk_cpuintr_wake_mask << MP0_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SHIFT)
#define MP0_DFP_MPCLKDS_CTRL_SET_MPCLK_SMN_WAKE_MASK(mp0_dfp_mpclkds_ctrl_reg, mpclk_smn_wake_mask) \
     mp0_dfp_mpclkds_ctrl_reg = (mp0_dfp_mpclkds_ctrl_reg & ~MP0_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_MASK) | (mpclk_smn_wake_mask << MP0_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SHIFT)
#define MP0_DFP_MPCLKDS_CTRL_SET_MPCLK_CCP1_WAKE_MASK(mp0_dfp_mpclkds_ctrl_reg, mpclk_ccp1_wake_mask) \
     mp0_dfp_mpclkds_ctrl_reg = (mp0_dfp_mpclkds_ctrl_reg & ~MP0_DFP_MPCLKDS_CTRL_MPCLK_CCP1_WAKE_MASK_MASK) | (mpclk_ccp1_wake_mask << MP0_DFP_MPCLKDS_CTRL_MPCLK_CCP1_WAKE_MASK_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_dfp_mpclkds_ctrl_t {
          unsigned int mpclk_ds_enb                   : MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SIZE;
          unsigned int mpclk_ds_status                : MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SIZE;
          unsigned int mpclk_ds_timeout               : MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SIZE;
          unsigned int mpclk_cpuintr_wake_mask        : MP0_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SIZE;
          unsigned int mpclk_smn_wake_mask            : MP0_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SIZE;
          unsigned int mpclk_ccp1_wake_mask           : MP0_DFP_MPCLKDS_CTRL_MPCLK_CCP1_WAKE_MASK_SIZE;
          unsigned int                                : 19;
     } mp0_dfp_mpclkds_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_dfp_mpclkds_ctrl_t {
          unsigned int                                : 19;
          unsigned int mpclk_ccp1_wake_mask           : MP0_DFP_MPCLKDS_CTRL_MPCLK_CCP1_WAKE_MASK_SIZE;
          unsigned int mpclk_smn_wake_mask            : MP0_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SIZE;
          unsigned int mpclk_cpuintr_wake_mask        : MP0_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SIZE;
          unsigned int mpclk_ds_timeout               : MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SIZE;
          unsigned int mpclk_ds_status                : MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SIZE;
          unsigned int mpclk_ds_enb                   : MP0_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SIZE;
     } mp0_dfp_mpclkds_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_dfp_mpclkds_ctrl_t f;
} mp0_dfp_mpclkds_ctrl_u;


/*
 * MP0_SOCCLK_XBAR_CG_CTRL struct
 */

#define MP0_SOCCLK_XBAR_CG_CTRL_REG_SIZE 32
#define MP0_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_SIZE 1

#define MP0_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_SHIFT 0

#define MP0_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_MASK 0x1

#define MP0_SOCCLK_XBAR_CG_CTRL_MASK \
     (MP0_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_MASK)

#define MP0_SOCCLK_XBAR_CG_CTRL_DEFAULT 0x00000000

#define MP0_SOCCLK_XBAR_CG_CTRL_GET_SOCCLK_XBAR_CACTIVE_EN(mp0_socclk_xbar_cg_ctrl) \
     ((mp0_socclk_xbar_cg_ctrl & MP0_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_MASK) >> MP0_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_SHIFT)

#define MP0_SOCCLK_XBAR_CG_CTRL_SET_SOCCLK_XBAR_CACTIVE_EN(mp0_socclk_xbar_cg_ctrl_reg, socclk_xbar_cactive_en) \
     mp0_socclk_xbar_cg_ctrl_reg = (mp0_socclk_xbar_cg_ctrl_reg & ~MP0_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_MASK) | (socclk_xbar_cactive_en << MP0_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_socclk_xbar_cg_ctrl_t {
          unsigned int socclk_xbar_cactive_en         : MP0_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_SIZE;
          unsigned int                                : 31;
     } mp0_socclk_xbar_cg_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_socclk_xbar_cg_ctrl_t {
          unsigned int                                : 31;
          unsigned int socclk_xbar_cactive_en         : MP0_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_SIZE;
     } mp0_socclk_xbar_cg_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_socclk_xbar_cg_ctrl_t f;
} mp0_socclk_xbar_cg_ctrl_u;


/*
 * MP0_SOCCLK_XBAR_CG_EN struct
 */

#define MP0_SOCCLK_XBAR_CG_EN_REG_SIZE 32
#define MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_SIZE 1
#define MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_SIZE 1
#define MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_SIZE 1
#define MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_SIZE 1

#define MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_SHIFT 1
#define MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_SHIFT 2
#define MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_SHIFT 3
#define MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_SHIFT 4

#define MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_MASK 0x2
#define MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_MASK 0x4
#define MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_MASK 0x8
#define MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_MASK 0x10

#define MP0_SOCCLK_XBAR_CG_EN_MASK \
     (MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_MASK | \
      MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_MASK | \
      MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_MASK | \
      MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_MASK)

#define MP0_SOCCLK_XBAR_CG_EN_DEFAULT  0x00000000

#define MP0_SOCCLK_XBAR_CG_EN_GET_SOCCLK_XBAR_CG_EN_0(mp0_socclk_xbar_cg_en) \
     ((mp0_socclk_xbar_cg_en & MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_MASK) >> MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_SHIFT)
#define MP0_SOCCLK_XBAR_CG_EN_GET_SOCCLK_XBAR_CG_EN_1(mp0_socclk_xbar_cg_en) \
     ((mp0_socclk_xbar_cg_en & MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_MASK) >> MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_SHIFT)
#define MP0_SOCCLK_XBAR_CG_EN_GET_SOCCLK_XBAR_CG_OVERRIDE_0(mp0_socclk_xbar_cg_en) \
     ((mp0_socclk_xbar_cg_en & MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_MASK) >> MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_SHIFT)
#define MP0_SOCCLK_XBAR_CG_EN_GET_SOCCLK_XBAR_CG_OVERRIDE_1(mp0_socclk_xbar_cg_en) \
     ((mp0_socclk_xbar_cg_en & MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_MASK) >> MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_SHIFT)

#define MP0_SOCCLK_XBAR_CG_EN_SET_SOCCLK_XBAR_CG_EN_0(mp0_socclk_xbar_cg_en_reg, socclk_xbar_cg_en_0) \
     mp0_socclk_xbar_cg_en_reg = (mp0_socclk_xbar_cg_en_reg & ~MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_MASK) | (socclk_xbar_cg_en_0 << MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_SHIFT)
#define MP0_SOCCLK_XBAR_CG_EN_SET_SOCCLK_XBAR_CG_EN_1(mp0_socclk_xbar_cg_en_reg, socclk_xbar_cg_en_1) \
     mp0_socclk_xbar_cg_en_reg = (mp0_socclk_xbar_cg_en_reg & ~MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_MASK) | (socclk_xbar_cg_en_1 << MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_SHIFT)
#define MP0_SOCCLK_XBAR_CG_EN_SET_SOCCLK_XBAR_CG_OVERRIDE_0(mp0_socclk_xbar_cg_en_reg, socclk_xbar_cg_override_0) \
     mp0_socclk_xbar_cg_en_reg = (mp0_socclk_xbar_cg_en_reg & ~MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_MASK) | (socclk_xbar_cg_override_0 << MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_SHIFT)
#define MP0_SOCCLK_XBAR_CG_EN_SET_SOCCLK_XBAR_CG_OVERRIDE_1(mp0_socclk_xbar_cg_en_reg, socclk_xbar_cg_override_1) \
     mp0_socclk_xbar_cg_en_reg = (mp0_socclk_xbar_cg_en_reg & ~MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_MASK) | (socclk_xbar_cg_override_1 << MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_socclk_xbar_cg_en_t {
          unsigned int                                : 1;
          unsigned int socclk_xbar_cg_en_0            : MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_SIZE;
          unsigned int socclk_xbar_cg_en_1            : MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_SIZE;
          unsigned int socclk_xbar_cg_override_0      : MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_SIZE;
          unsigned int socclk_xbar_cg_override_1      : MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_SIZE;
          unsigned int                                : 27;
     } mp0_socclk_xbar_cg_en_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_socclk_xbar_cg_en_t {
          unsigned int                                : 27;
          unsigned int socclk_xbar_cg_override_1      : MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_SIZE;
          unsigned int socclk_xbar_cg_override_0      : MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_SIZE;
          unsigned int socclk_xbar_cg_en_1            : MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_SIZE;
          unsigned int socclk_xbar_cg_en_0            : MP0_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_SIZE;
          unsigned int                                : 1;
     } mp0_socclk_xbar_cg_en_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_socclk_xbar_cg_en_t f;
} mp0_socclk_xbar_cg_en_u;


/*
 * MP0_SOCCLK_XBAR_CG_MISC struct
 */

#define MP0_SOCCLK_XBAR_CG_MISC_REG_SIZE 32
#define MP0_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_SIZE 8
#define MP0_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_SIZE 8

#define MP0_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_SHIFT 0
#define MP0_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_SHIFT 8

#define MP0_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_MASK 0xff
#define MP0_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_MASK 0xff00

#define MP0_SOCCLK_XBAR_CG_MISC_MASK \
     (MP0_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_MASK | \
      MP0_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_MASK)

#define MP0_SOCCLK_XBAR_CG_MISC_DEFAULT 0x00000606

#define MP0_SOCCLK_XBAR_CG_MISC_GET_SOCCLK_XBAR_CG_TIMEOUT(mp0_socclk_xbar_cg_misc) \
     ((mp0_socclk_xbar_cg_misc & MP0_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_MASK) >> MP0_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MP0_SOCCLK_XBAR_CG_MISC_GET_SOCCLK_XBAR_CSYS_DELAY(mp0_socclk_xbar_cg_misc) \
     ((mp0_socclk_xbar_cg_misc & MP0_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_MASK) >> MP0_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_SHIFT)

#define MP0_SOCCLK_XBAR_CG_MISC_SET_SOCCLK_XBAR_CG_TIMEOUT(mp0_socclk_xbar_cg_misc_reg, socclk_xbar_cg_timeout) \
     mp0_socclk_xbar_cg_misc_reg = (mp0_socclk_xbar_cg_misc_reg & ~MP0_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_MASK) | (socclk_xbar_cg_timeout << MP0_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MP0_SOCCLK_XBAR_CG_MISC_SET_SOCCLK_XBAR_CSYS_DELAY(mp0_socclk_xbar_cg_misc_reg, socclk_xbar_csys_delay) \
     mp0_socclk_xbar_cg_misc_reg = (mp0_socclk_xbar_cg_misc_reg & ~MP0_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_MASK) | (socclk_xbar_csys_delay << MP0_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_socclk_xbar_cg_misc_t {
          unsigned int socclk_xbar_cg_timeout         : MP0_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_SIZE;
          unsigned int socclk_xbar_csys_delay         : MP0_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_SIZE;
          unsigned int                                : 16;
     } mp0_socclk_xbar_cg_misc_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_socclk_xbar_cg_misc_t {
          unsigned int                                : 16;
          unsigned int socclk_xbar_csys_delay         : MP0_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_SIZE;
          unsigned int socclk_xbar_cg_timeout         : MP0_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_SIZE;
     } mp0_socclk_xbar_cg_misc_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_socclk_xbar_cg_misc_t f;
} mp0_socclk_xbar_cg_misc_u;


/*
 * MP0_DFP_PGRAM_MHUB_CNTL struct
 */

#define MP0_DFP_PGRAM_MHUB_CNTL_REG_SIZE 32
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_SIZE 1
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_ROP_MHUB_SIZE 1
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_SIZE 1
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_SIZE 1
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_SIZE 1
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_SIZE 1
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_SIZE 8
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_SIZE 8

#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_SHIFT 0
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_ROP_MHUB_SHIFT 1
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_SHIFT 2
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_SHIFT 3
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_SHIFT 4
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_SHIFT 5
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_SHIFT 8
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_SHIFT 16

#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_MASK 0x1
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_ROP_MHUB_MASK 0x2
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_MASK 0x4
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_MASK 0x8
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_MASK 0x10
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_MASK 0x20
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_MASK 0xff00
#define MP0_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_MASK 0xff0000

#define MP0_DFP_PGRAM_MHUB_CNTL_MASK \
     (MP0_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_MASK | \
      MP0_DFP_PGRAM_MHUB_CNTL_MEM_ROP_MHUB_MASK | \
      MP0_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_MASK | \
      MP0_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_MASK | \
      MP0_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_MASK | \
      MP0_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_MASK | \
      MP0_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_MASK | \
      MP0_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_MASK)

#define MP0_DFP_PGRAM_MHUB_CNTL_DEFAULT 0x0010102a

#define MP0_DFP_PGRAM_MHUB_CNTL_GET_MEM_SD_MHUB(mp0_dfp_pgram_mhub_cntl) \
     ((mp0_dfp_pgram_mhub_cntl & MP0_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_MASK) >> MP0_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_SHIFT)
#define MP0_DFP_PGRAM_MHUB_CNTL_GET_MEM_ROP_MHUB(mp0_dfp_pgram_mhub_cntl) \
     ((mp0_dfp_pgram_mhub_cntl & MP0_DFP_PGRAM_MHUB_CNTL_MEM_ROP_MHUB_MASK) >> MP0_DFP_PGRAM_MHUB_CNTL_MEM_ROP_MHUB_SHIFT)
#define MP0_DFP_PGRAM_MHUB_CNTL_GET_MEM_DEEP_SLEEP_EN_MHUB(mp0_dfp_pgram_mhub_cntl) \
     ((mp0_dfp_pgram_mhub_cntl & MP0_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_MASK) >> MP0_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_SHIFT)
#define MP0_DFP_PGRAM_MHUB_CNTL_GET_MEM_DEEP_SLEEP_STATUS_MHUB(mp0_dfp_pgram_mhub_cntl) \
     ((mp0_dfp_pgram_mhub_cntl & MP0_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_MASK) >> MP0_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_SHIFT)
#define MP0_DFP_PGRAM_MHUB_CNTL_GET_MEM_LIGHT_SLEEP_EN_MHUB(mp0_dfp_pgram_mhub_cntl) \
     ((mp0_dfp_pgram_mhub_cntl & MP0_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_MASK) >> MP0_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_SHIFT)
#define MP0_DFP_PGRAM_MHUB_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_MHUB(mp0_dfp_pgram_mhub_cntl) \
     ((mp0_dfp_pgram_mhub_cntl & MP0_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_MASK) >> MP0_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_SHIFT)
#define MP0_DFP_PGRAM_MHUB_CNTL_GET_MEM_SLEEP_TIMEOUT_MHUB(mp0_dfp_pgram_mhub_cntl) \
     ((mp0_dfp_pgram_mhub_cntl & MP0_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_MASK) >> MP0_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_SHIFT)
#define MP0_DFP_PGRAM_MHUB_CNTL_GET_MEM_PG_DLY_MHUB(mp0_dfp_pgram_mhub_cntl) \
     ((mp0_dfp_pgram_mhub_cntl & MP0_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_MASK) >> MP0_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_SHIFT)

#define MP0_DFP_PGRAM_MHUB_CNTL_SET_MEM_SD_MHUB(mp0_dfp_pgram_mhub_cntl_reg, mem_sd_mhub) \
     mp0_dfp_pgram_mhub_cntl_reg = (mp0_dfp_pgram_mhub_cntl_reg & ~MP0_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_MASK) | (mem_sd_mhub << MP0_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_SHIFT)
#define MP0_DFP_PGRAM_MHUB_CNTL_SET_MEM_ROP_MHUB(mp0_dfp_pgram_mhub_cntl_reg, mem_rop_mhub) \
     mp0_dfp_pgram_mhub_cntl_reg = (mp0_dfp_pgram_mhub_cntl_reg & ~MP0_DFP_PGRAM_MHUB_CNTL_MEM_ROP_MHUB_MASK) | (mem_rop_mhub << MP0_DFP_PGRAM_MHUB_CNTL_MEM_ROP_MHUB_SHIFT)
#define MP0_DFP_PGRAM_MHUB_CNTL_SET_MEM_DEEP_SLEEP_EN_MHUB(mp0_dfp_pgram_mhub_cntl_reg, mem_deep_sleep_en_mhub) \
     mp0_dfp_pgram_mhub_cntl_reg = (mp0_dfp_pgram_mhub_cntl_reg & ~MP0_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_MASK) | (mem_deep_sleep_en_mhub << MP0_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_SHIFT)
#define MP0_DFP_PGRAM_MHUB_CNTL_SET_MEM_DEEP_SLEEP_STATUS_MHUB(mp0_dfp_pgram_mhub_cntl_reg, mem_deep_sleep_status_mhub) \
     mp0_dfp_pgram_mhub_cntl_reg = (mp0_dfp_pgram_mhub_cntl_reg & ~MP0_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_MASK) | (mem_deep_sleep_status_mhub << MP0_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_SHIFT)
#define MP0_DFP_PGRAM_MHUB_CNTL_SET_MEM_LIGHT_SLEEP_EN_MHUB(mp0_dfp_pgram_mhub_cntl_reg, mem_light_sleep_en_mhub) \
     mp0_dfp_pgram_mhub_cntl_reg = (mp0_dfp_pgram_mhub_cntl_reg & ~MP0_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_MASK) | (mem_light_sleep_en_mhub << MP0_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_SHIFT)
#define MP0_DFP_PGRAM_MHUB_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_MHUB(mp0_dfp_pgram_mhub_cntl_reg, mem_light_sleep_status_mhub) \
     mp0_dfp_pgram_mhub_cntl_reg = (mp0_dfp_pgram_mhub_cntl_reg & ~MP0_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_MASK) | (mem_light_sleep_status_mhub << MP0_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_SHIFT)
#define MP0_DFP_PGRAM_MHUB_CNTL_SET_MEM_SLEEP_TIMEOUT_MHUB(mp0_dfp_pgram_mhub_cntl_reg, mem_sleep_timeout_mhub) \
     mp0_dfp_pgram_mhub_cntl_reg = (mp0_dfp_pgram_mhub_cntl_reg & ~MP0_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_MASK) | (mem_sleep_timeout_mhub << MP0_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_SHIFT)
#define MP0_DFP_PGRAM_MHUB_CNTL_SET_MEM_PG_DLY_MHUB(mp0_dfp_pgram_mhub_cntl_reg, mem_pg_dly_mhub) \
     mp0_dfp_pgram_mhub_cntl_reg = (mp0_dfp_pgram_mhub_cntl_reg & ~MP0_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_MASK) | (mem_pg_dly_mhub << MP0_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_dfp_pgram_mhub_cntl_t {
          unsigned int mem_sd_mhub                    : MP0_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_SIZE;
          unsigned int mem_rop_mhub                   : MP0_DFP_PGRAM_MHUB_CNTL_MEM_ROP_MHUB_SIZE;
          unsigned int mem_deep_sleep_en_mhub         : MP0_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_SIZE;
          unsigned int mem_deep_sleep_status_mhub     : MP0_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_SIZE;
          unsigned int mem_light_sleep_en_mhub        : MP0_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_SIZE;
          unsigned int mem_light_sleep_status_mhub    : MP0_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_SIZE;
          unsigned int                                : 2;
          unsigned int mem_sleep_timeout_mhub         : MP0_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_SIZE;
          unsigned int mem_pg_dly_mhub                : MP0_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_SIZE;
          unsigned int                                : 8;
     } mp0_dfp_pgram_mhub_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_dfp_pgram_mhub_cntl_t {
          unsigned int                                : 8;
          unsigned int mem_pg_dly_mhub                : MP0_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_SIZE;
          unsigned int mem_sleep_timeout_mhub         : MP0_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_SIZE;
          unsigned int                                : 2;
          unsigned int mem_light_sleep_status_mhub    : MP0_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_SIZE;
          unsigned int mem_light_sleep_en_mhub        : MP0_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_SIZE;
          unsigned int mem_deep_sleep_status_mhub     : MP0_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_SIZE;
          unsigned int mem_deep_sleep_en_mhub         : MP0_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_SIZE;
          unsigned int mem_rop_mhub                   : MP0_DFP_PGRAM_MHUB_CNTL_MEM_ROP_MHUB_SIZE;
          unsigned int mem_sd_mhub                    : MP0_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_SIZE;
     } mp0_dfp_pgram_mhub_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_dfp_pgram_mhub_cntl_t f;
} mp0_dfp_pgram_mhub_cntl_u;


/*
 * MP0_DFP_SOCCLKDS_CTRL struct
 */

#define MP0_DFP_SOCCLKDS_CTRL_REG_SIZE 32
#define MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_SIZE 1
#define MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_SIZE 1
#define MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_SIZE 8
#define MP0_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_SIZE 1
#define MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DRM_WAKE_MASK_SIZE 1

#define MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_SHIFT 0
#define MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_SHIFT 1
#define MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_SHIFT 2
#define MP0_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_SHIFT 10
#define MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DRM_WAKE_MASK_SHIFT 11

#define MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_MASK 0x1
#define MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_MASK 0x2
#define MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_MASK 0x3fc
#define MP0_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_MASK 0x400
#define MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DRM_WAKE_MASK_MASK 0x800

#define MP0_DFP_SOCCLKDS_CTRL_MASK \
     (MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_MASK | \
      MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_MASK | \
      MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_MASK | \
      MP0_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_MASK | \
      MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DRM_WAKE_MASK_MASK)

#define MP0_DFP_SOCCLKDS_CTRL_DEFAULT  0x00000ffc

#define MP0_DFP_SOCCLKDS_CTRL_GET_SOCCLK_DS_ENB(mp0_dfp_socclkds_ctrl) \
     ((mp0_dfp_socclkds_ctrl & MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_MASK) >> MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_SHIFT)
#define MP0_DFP_SOCCLKDS_CTRL_GET_SOCCLK_DS_STATUS(mp0_dfp_socclkds_ctrl) \
     ((mp0_dfp_socclkds_ctrl & MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_MASK) >> MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_SHIFT)
#define MP0_DFP_SOCCLKDS_CTRL_GET_SOCCLK_DS_TIMEOUT(mp0_dfp_socclkds_ctrl) \
     ((mp0_dfp_socclkds_ctrl & MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_MASK) >> MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_SHIFT)
#define MP0_DFP_SOCCLKDS_CTRL_GET_SOCCLK_MHUBIF_WAKE_MASK(mp0_dfp_socclkds_ctrl) \
     ((mp0_dfp_socclkds_ctrl & MP0_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_MASK) >> MP0_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_SHIFT)
#define MP0_DFP_SOCCLKDS_CTRL_GET_SOCCLK_DRM_WAKE_MASK(mp0_dfp_socclkds_ctrl) \
     ((mp0_dfp_socclkds_ctrl & MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DRM_WAKE_MASK_MASK) >> MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DRM_WAKE_MASK_SHIFT)

#define MP0_DFP_SOCCLKDS_CTRL_SET_SOCCLK_DS_ENB(mp0_dfp_socclkds_ctrl_reg, socclk_ds_enb) \
     mp0_dfp_socclkds_ctrl_reg = (mp0_dfp_socclkds_ctrl_reg & ~MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_MASK) | (socclk_ds_enb << MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_SHIFT)
#define MP0_DFP_SOCCLKDS_CTRL_SET_SOCCLK_DS_STATUS(mp0_dfp_socclkds_ctrl_reg, socclk_ds_status) \
     mp0_dfp_socclkds_ctrl_reg = (mp0_dfp_socclkds_ctrl_reg & ~MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_MASK) | (socclk_ds_status << MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_SHIFT)
#define MP0_DFP_SOCCLKDS_CTRL_SET_SOCCLK_DS_TIMEOUT(mp0_dfp_socclkds_ctrl_reg, socclk_ds_timeout) \
     mp0_dfp_socclkds_ctrl_reg = (mp0_dfp_socclkds_ctrl_reg & ~MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_MASK) | (socclk_ds_timeout << MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_SHIFT)
#define MP0_DFP_SOCCLKDS_CTRL_SET_SOCCLK_MHUBIF_WAKE_MASK(mp0_dfp_socclkds_ctrl_reg, socclk_mhubif_wake_mask) \
     mp0_dfp_socclkds_ctrl_reg = (mp0_dfp_socclkds_ctrl_reg & ~MP0_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_MASK) | (socclk_mhubif_wake_mask << MP0_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_SHIFT)
#define MP0_DFP_SOCCLKDS_CTRL_SET_SOCCLK_DRM_WAKE_MASK(mp0_dfp_socclkds_ctrl_reg, socclk_drm_wake_mask) \
     mp0_dfp_socclkds_ctrl_reg = (mp0_dfp_socclkds_ctrl_reg & ~MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DRM_WAKE_MASK_MASK) | (socclk_drm_wake_mask << MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DRM_WAKE_MASK_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_dfp_socclkds_ctrl_t {
          unsigned int socclk_ds_enb                  : MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_SIZE;
          unsigned int socclk_ds_status               : MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_SIZE;
          unsigned int socclk_ds_timeout              : MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_SIZE;
          unsigned int socclk_mhubif_wake_mask        : MP0_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_SIZE;
          unsigned int socclk_drm_wake_mask           : MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DRM_WAKE_MASK_SIZE;
          unsigned int                                : 20;
     } mp0_dfp_socclkds_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_dfp_socclkds_ctrl_t {
          unsigned int                                : 20;
          unsigned int socclk_drm_wake_mask           : MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DRM_WAKE_MASK_SIZE;
          unsigned int socclk_mhubif_wake_mask        : MP0_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_SIZE;
          unsigned int socclk_ds_timeout              : MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_SIZE;
          unsigned int socclk_ds_status               : MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_SIZE;
          unsigned int socclk_ds_enb                  : MP0_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_SIZE;
     } mp0_dfp_socclkds_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_dfp_socclkds_ctrl_t f;
} mp0_dfp_socclkds_ctrl_u;


/*
 * MP0_SHUBCLK_XBAR_CG_CTRL struct
 */

#define MP0_SHUBCLK_XBAR_CG_CTRL_REG_SIZE 32
#define MP0_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_SIZE 1

#define MP0_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_SHIFT 0

#define MP0_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_MASK 0x1

#define MP0_SHUBCLK_XBAR_CG_CTRL_MASK \
     (MP0_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_MASK)

#define MP0_SHUBCLK_XBAR_CG_CTRL_DEFAULT 0x00000000

#define MP0_SHUBCLK_XBAR_CG_CTRL_GET_SHUBCLK_XBAR_CACTIVE_EN(mp0_shubclk_xbar_cg_ctrl) \
     ((mp0_shubclk_xbar_cg_ctrl & MP0_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_MASK) >> MP0_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_SHIFT)

#define MP0_SHUBCLK_XBAR_CG_CTRL_SET_SHUBCLK_XBAR_CACTIVE_EN(mp0_shubclk_xbar_cg_ctrl_reg, shubclk_xbar_cactive_en) \
     mp0_shubclk_xbar_cg_ctrl_reg = (mp0_shubclk_xbar_cg_ctrl_reg & ~MP0_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_MASK) | (shubclk_xbar_cactive_en << MP0_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_shubclk_xbar_cg_ctrl_t {
          unsigned int shubclk_xbar_cactive_en        : MP0_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_SIZE;
          unsigned int                                : 31;
     } mp0_shubclk_xbar_cg_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_shubclk_xbar_cg_ctrl_t {
          unsigned int                                : 31;
          unsigned int shubclk_xbar_cactive_en        : MP0_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_SIZE;
     } mp0_shubclk_xbar_cg_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_shubclk_xbar_cg_ctrl_t f;
} mp0_shubclk_xbar_cg_ctrl_u;


/*
 * MP0_SHUBCLK_XBAR_CG_EN struct
 */

#define MP0_SHUBCLK_XBAR_CG_EN_REG_SIZE 32
#define MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_SIZE 1
#define MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_SIZE 1
#define MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_SIZE 1
#define MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_SIZE 1

#define MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_SHIFT 1
#define MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_SHIFT 2
#define MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_SHIFT 3
#define MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_SHIFT 4

#define MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_MASK 0x2
#define MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_MASK 0x4
#define MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_MASK 0x8
#define MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_MASK 0x10

#define MP0_SHUBCLK_XBAR_CG_EN_MASK \
     (MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_MASK | \
      MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_MASK | \
      MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_MASK | \
      MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_MASK)

#define MP0_SHUBCLK_XBAR_CG_EN_DEFAULT 0x00000000

#define MP0_SHUBCLK_XBAR_CG_EN_GET_SHUBCLK_XBAR_CG_EN_0(mp0_shubclk_xbar_cg_en) \
     ((mp0_shubclk_xbar_cg_en & MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_MASK) >> MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_SHIFT)
#define MP0_SHUBCLK_XBAR_CG_EN_GET_SHUBCLK_XBAR_CG_EN_1(mp0_shubclk_xbar_cg_en) \
     ((mp0_shubclk_xbar_cg_en & MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_MASK) >> MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_SHIFT)
#define MP0_SHUBCLK_XBAR_CG_EN_GET_SHUBCLK_XBAR_CG_OVERRIDE_0(mp0_shubclk_xbar_cg_en) \
     ((mp0_shubclk_xbar_cg_en & MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_MASK) >> MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_SHIFT)
#define MP0_SHUBCLK_XBAR_CG_EN_GET_SHUBCLK_XBAR_CG_OVERRIDE_1(mp0_shubclk_xbar_cg_en) \
     ((mp0_shubclk_xbar_cg_en & MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_MASK) >> MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_SHIFT)

#define MP0_SHUBCLK_XBAR_CG_EN_SET_SHUBCLK_XBAR_CG_EN_0(mp0_shubclk_xbar_cg_en_reg, shubclk_xbar_cg_en_0) \
     mp0_shubclk_xbar_cg_en_reg = (mp0_shubclk_xbar_cg_en_reg & ~MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_MASK) | (shubclk_xbar_cg_en_0 << MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_SHIFT)
#define MP0_SHUBCLK_XBAR_CG_EN_SET_SHUBCLK_XBAR_CG_EN_1(mp0_shubclk_xbar_cg_en_reg, shubclk_xbar_cg_en_1) \
     mp0_shubclk_xbar_cg_en_reg = (mp0_shubclk_xbar_cg_en_reg & ~MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_MASK) | (shubclk_xbar_cg_en_1 << MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_SHIFT)
#define MP0_SHUBCLK_XBAR_CG_EN_SET_SHUBCLK_XBAR_CG_OVERRIDE_0(mp0_shubclk_xbar_cg_en_reg, shubclk_xbar_cg_override_0) \
     mp0_shubclk_xbar_cg_en_reg = (mp0_shubclk_xbar_cg_en_reg & ~MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_MASK) | (shubclk_xbar_cg_override_0 << MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_SHIFT)
#define MP0_SHUBCLK_XBAR_CG_EN_SET_SHUBCLK_XBAR_CG_OVERRIDE_1(mp0_shubclk_xbar_cg_en_reg, shubclk_xbar_cg_override_1) \
     mp0_shubclk_xbar_cg_en_reg = (mp0_shubclk_xbar_cg_en_reg & ~MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_MASK) | (shubclk_xbar_cg_override_1 << MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_shubclk_xbar_cg_en_t {
          unsigned int                                : 1;
          unsigned int shubclk_xbar_cg_en_0           : MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_SIZE;
          unsigned int shubclk_xbar_cg_en_1           : MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_SIZE;
          unsigned int shubclk_xbar_cg_override_0     : MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_SIZE;
          unsigned int shubclk_xbar_cg_override_1     : MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_SIZE;
          unsigned int                                : 27;
     } mp0_shubclk_xbar_cg_en_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_shubclk_xbar_cg_en_t {
          unsigned int                                : 27;
          unsigned int shubclk_xbar_cg_override_1     : MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_SIZE;
          unsigned int shubclk_xbar_cg_override_0     : MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_SIZE;
          unsigned int shubclk_xbar_cg_en_1           : MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_SIZE;
          unsigned int shubclk_xbar_cg_en_0           : MP0_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_SIZE;
          unsigned int                                : 1;
     } mp0_shubclk_xbar_cg_en_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_shubclk_xbar_cg_en_t f;
} mp0_shubclk_xbar_cg_en_u;


/*
 * MP0_SHUBCLK_XBAR_CG_MISC struct
 */

#define MP0_SHUBCLK_XBAR_CG_MISC_REG_SIZE 32
#define MP0_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_SIZE 8
#define MP0_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_SIZE 8

#define MP0_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_SHIFT 0
#define MP0_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_SHIFT 8

#define MP0_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_MASK 0xff
#define MP0_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_MASK 0xff00

#define MP0_SHUBCLK_XBAR_CG_MISC_MASK \
     (MP0_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_MASK | \
      MP0_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_MASK)

#define MP0_SHUBCLK_XBAR_CG_MISC_DEFAULT 0x00000606

#define MP0_SHUBCLK_XBAR_CG_MISC_GET_SHUBCLK_XBAR_CG_TIMEOUT(mp0_shubclk_xbar_cg_misc) \
     ((mp0_shubclk_xbar_cg_misc & MP0_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_MASK) >> MP0_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MP0_SHUBCLK_XBAR_CG_MISC_GET_SHUBCLK_XBAR_CSYS_DELAY(mp0_shubclk_xbar_cg_misc) \
     ((mp0_shubclk_xbar_cg_misc & MP0_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_MASK) >> MP0_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_SHIFT)

#define MP0_SHUBCLK_XBAR_CG_MISC_SET_SHUBCLK_XBAR_CG_TIMEOUT(mp0_shubclk_xbar_cg_misc_reg, shubclk_xbar_cg_timeout) \
     mp0_shubclk_xbar_cg_misc_reg = (mp0_shubclk_xbar_cg_misc_reg & ~MP0_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_MASK) | (shubclk_xbar_cg_timeout << MP0_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MP0_SHUBCLK_XBAR_CG_MISC_SET_SHUBCLK_XBAR_CSYS_DELAY(mp0_shubclk_xbar_cg_misc_reg, shubclk_xbar_csys_delay) \
     mp0_shubclk_xbar_cg_misc_reg = (mp0_shubclk_xbar_cg_misc_reg & ~MP0_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_MASK) | (shubclk_xbar_csys_delay << MP0_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_shubclk_xbar_cg_misc_t {
          unsigned int shubclk_xbar_cg_timeout        : MP0_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_SIZE;
          unsigned int shubclk_xbar_csys_delay        : MP0_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_SIZE;
          unsigned int                                : 16;
     } mp0_shubclk_xbar_cg_misc_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_shubclk_xbar_cg_misc_t {
          unsigned int                                : 16;
          unsigned int shubclk_xbar_csys_delay        : MP0_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_SIZE;
          unsigned int shubclk_xbar_cg_timeout        : MP0_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_SIZE;
     } mp0_shubclk_xbar_cg_misc_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_shubclk_xbar_cg_misc_t f;
} mp0_shubclk_xbar_cg_misc_u;


/*
 * MP0_DFP_PGRAM_SHUB_CNTL struct
 */

#define MP0_DFP_PGRAM_SHUB_CNTL_REG_SIZE 32
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_SIZE 1
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_ROP_SHUB_SIZE 1
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_SIZE 1
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_SIZE 1
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_SIZE 1
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_SIZE 1
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_SIZE 8
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_SIZE 8

#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_SHIFT 0
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_ROP_SHUB_SHIFT 1
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_SHIFT 2
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_SHIFT 3
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_SHIFT 4
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_SHIFT 5
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_SHIFT 8
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_SHIFT 16

#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_MASK 0x1
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_ROP_SHUB_MASK 0x2
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_MASK 0x4
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_MASK 0x8
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_MASK 0x10
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_MASK 0x20
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_MASK 0xff00
#define MP0_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_MASK 0xff0000

#define MP0_DFP_PGRAM_SHUB_CNTL_MASK \
     (MP0_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_MASK | \
      MP0_DFP_PGRAM_SHUB_CNTL_MEM_ROP_SHUB_MASK | \
      MP0_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_MASK | \
      MP0_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_MASK | \
      MP0_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_MASK | \
      MP0_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_MASK | \
      MP0_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_MASK | \
      MP0_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_MASK)

#define MP0_DFP_PGRAM_SHUB_CNTL_DEFAULT 0x0010102a

#define MP0_DFP_PGRAM_SHUB_CNTL_GET_MEM_SD_SHUB(mp0_dfp_pgram_shub_cntl) \
     ((mp0_dfp_pgram_shub_cntl & MP0_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_MASK) >> MP0_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_SHIFT)
#define MP0_DFP_PGRAM_SHUB_CNTL_GET_MEM_ROP_SHUB(mp0_dfp_pgram_shub_cntl) \
     ((mp0_dfp_pgram_shub_cntl & MP0_DFP_PGRAM_SHUB_CNTL_MEM_ROP_SHUB_MASK) >> MP0_DFP_PGRAM_SHUB_CNTL_MEM_ROP_SHUB_SHIFT)
#define MP0_DFP_PGRAM_SHUB_CNTL_GET_MEM_DEEP_SLEEP_EN_SHUB(mp0_dfp_pgram_shub_cntl) \
     ((mp0_dfp_pgram_shub_cntl & MP0_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_MASK) >> MP0_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_SHIFT)
#define MP0_DFP_PGRAM_SHUB_CNTL_GET_MEM_DEEP_SLEEP_STATUS_SHUB(mp0_dfp_pgram_shub_cntl) \
     ((mp0_dfp_pgram_shub_cntl & MP0_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_MASK) >> MP0_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_SHIFT)
#define MP0_DFP_PGRAM_SHUB_CNTL_GET_MEM_LIGHT_SLEEP_EN_SHUB(mp0_dfp_pgram_shub_cntl) \
     ((mp0_dfp_pgram_shub_cntl & MP0_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_MASK) >> MP0_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_SHIFT)
#define MP0_DFP_PGRAM_SHUB_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_SHUB(mp0_dfp_pgram_shub_cntl) \
     ((mp0_dfp_pgram_shub_cntl & MP0_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_MASK) >> MP0_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_SHIFT)
#define MP0_DFP_PGRAM_SHUB_CNTL_GET_MEM_SLEEP_TIMEOUT_SHUB(mp0_dfp_pgram_shub_cntl) \
     ((mp0_dfp_pgram_shub_cntl & MP0_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_MASK) >> MP0_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_SHIFT)
#define MP0_DFP_PGRAM_SHUB_CNTL_GET_MEM_PG_DLY_SHUB(mp0_dfp_pgram_shub_cntl) \
     ((mp0_dfp_pgram_shub_cntl & MP0_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_MASK) >> MP0_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_SHIFT)

#define MP0_DFP_PGRAM_SHUB_CNTL_SET_MEM_SD_SHUB(mp0_dfp_pgram_shub_cntl_reg, mem_sd_shub) \
     mp0_dfp_pgram_shub_cntl_reg = (mp0_dfp_pgram_shub_cntl_reg & ~MP0_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_MASK) | (mem_sd_shub << MP0_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_SHIFT)
#define MP0_DFP_PGRAM_SHUB_CNTL_SET_MEM_ROP_SHUB(mp0_dfp_pgram_shub_cntl_reg, mem_rop_shub) \
     mp0_dfp_pgram_shub_cntl_reg = (mp0_dfp_pgram_shub_cntl_reg & ~MP0_DFP_PGRAM_SHUB_CNTL_MEM_ROP_SHUB_MASK) | (mem_rop_shub << MP0_DFP_PGRAM_SHUB_CNTL_MEM_ROP_SHUB_SHIFT)
#define MP0_DFP_PGRAM_SHUB_CNTL_SET_MEM_DEEP_SLEEP_EN_SHUB(mp0_dfp_pgram_shub_cntl_reg, mem_deep_sleep_en_shub) \
     mp0_dfp_pgram_shub_cntl_reg = (mp0_dfp_pgram_shub_cntl_reg & ~MP0_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_MASK) | (mem_deep_sleep_en_shub << MP0_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_SHIFT)
#define MP0_DFP_PGRAM_SHUB_CNTL_SET_MEM_DEEP_SLEEP_STATUS_SHUB(mp0_dfp_pgram_shub_cntl_reg, mem_deep_sleep_status_shub) \
     mp0_dfp_pgram_shub_cntl_reg = (mp0_dfp_pgram_shub_cntl_reg & ~MP0_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_MASK) | (mem_deep_sleep_status_shub << MP0_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_SHIFT)
#define MP0_DFP_PGRAM_SHUB_CNTL_SET_MEM_LIGHT_SLEEP_EN_SHUB(mp0_dfp_pgram_shub_cntl_reg, mem_light_sleep_en_shub) \
     mp0_dfp_pgram_shub_cntl_reg = (mp0_dfp_pgram_shub_cntl_reg & ~MP0_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_MASK) | (mem_light_sleep_en_shub << MP0_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_SHIFT)
#define MP0_DFP_PGRAM_SHUB_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_SHUB(mp0_dfp_pgram_shub_cntl_reg, mem_light_sleep_status_shub) \
     mp0_dfp_pgram_shub_cntl_reg = (mp0_dfp_pgram_shub_cntl_reg & ~MP0_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_MASK) | (mem_light_sleep_status_shub << MP0_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_SHIFT)
#define MP0_DFP_PGRAM_SHUB_CNTL_SET_MEM_SLEEP_TIMEOUT_SHUB(mp0_dfp_pgram_shub_cntl_reg, mem_sleep_timeout_shub) \
     mp0_dfp_pgram_shub_cntl_reg = (mp0_dfp_pgram_shub_cntl_reg & ~MP0_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_MASK) | (mem_sleep_timeout_shub << MP0_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_SHIFT)
#define MP0_DFP_PGRAM_SHUB_CNTL_SET_MEM_PG_DLY_SHUB(mp0_dfp_pgram_shub_cntl_reg, mem_pg_dly_shub) \
     mp0_dfp_pgram_shub_cntl_reg = (mp0_dfp_pgram_shub_cntl_reg & ~MP0_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_MASK) | (mem_pg_dly_shub << MP0_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_dfp_pgram_shub_cntl_t {
          unsigned int mem_sd_shub                    : MP0_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_SIZE;
          unsigned int mem_rop_shub                   : MP0_DFP_PGRAM_SHUB_CNTL_MEM_ROP_SHUB_SIZE;
          unsigned int mem_deep_sleep_en_shub         : MP0_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_SIZE;
          unsigned int mem_deep_sleep_status_shub     : MP0_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_SIZE;
          unsigned int mem_light_sleep_en_shub        : MP0_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_SIZE;
          unsigned int mem_light_sleep_status_shub    : MP0_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_SIZE;
          unsigned int                                : 2;
          unsigned int mem_sleep_timeout_shub         : MP0_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_SIZE;
          unsigned int mem_pg_dly_shub                : MP0_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_SIZE;
          unsigned int                                : 8;
     } mp0_dfp_pgram_shub_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_dfp_pgram_shub_cntl_t {
          unsigned int                                : 8;
          unsigned int mem_pg_dly_shub                : MP0_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_SIZE;
          unsigned int mem_sleep_timeout_shub         : MP0_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_SIZE;
          unsigned int                                : 2;
          unsigned int mem_light_sleep_status_shub    : MP0_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_SIZE;
          unsigned int mem_light_sleep_en_shub        : MP0_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_SIZE;
          unsigned int mem_deep_sleep_status_shub     : MP0_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_SIZE;
          unsigned int mem_deep_sleep_en_shub         : MP0_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_SIZE;
          unsigned int mem_rop_shub                   : MP0_DFP_PGRAM_SHUB_CNTL_MEM_ROP_SHUB_SIZE;
          unsigned int mem_sd_shub                    : MP0_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_SIZE;
     } mp0_dfp_pgram_shub_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_dfp_pgram_shub_cntl_t f;
} mp0_dfp_pgram_shub_cntl_u;


/*
 * MP0_DFP_SHUBCLKDS_CTRL struct
 */

#define MP0_DFP_SHUBCLKDS_CTRL_REG_SIZE 32
#define MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_SIZE 1
#define MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_SIZE 1
#define MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_SIZE 8
#define MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_SIZE 1

#define MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_SHIFT 0
#define MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_SHIFT 1
#define MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_SHIFT 2
#define MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_SHIFT 10

#define MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_MASK 0x1
#define MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_MASK 0x2
#define MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_MASK 0x3fc
#define MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_MASK 0x400

#define MP0_DFP_SHUBCLKDS_CTRL_MASK \
     (MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_MASK | \
      MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_MASK | \
      MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_MASK | \
      MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_MASK)

#define MP0_DFP_SHUBCLKDS_CTRL_DEFAULT 0x000007fc

#define MP0_DFP_SHUBCLKDS_CTRL_GET_SHUBCLK_DS_ENB(mp0_dfp_shubclkds_ctrl) \
     ((mp0_dfp_shubclkds_ctrl & MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_MASK) >> MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_SHIFT)
#define MP0_DFP_SHUBCLKDS_CTRL_GET_SHUBCLK_DS_STATUS(mp0_dfp_shubclkds_ctrl) \
     ((mp0_dfp_shubclkds_ctrl & MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_MASK) >> MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_SHIFT)
#define MP0_DFP_SHUBCLKDS_CTRL_GET_SHUBCLK_DS_TIMEOUT(mp0_dfp_shubclkds_ctrl) \
     ((mp0_dfp_shubclkds_ctrl & MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_MASK) >> MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_SHIFT)
#define MP0_DFP_SHUBCLKDS_CTRL_GET_SHUBCLK_SHUBIF_WAKE_MASK(mp0_dfp_shubclkds_ctrl) \
     ((mp0_dfp_shubclkds_ctrl & MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_MASK) >> MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_SHIFT)

#define MP0_DFP_SHUBCLKDS_CTRL_SET_SHUBCLK_DS_ENB(mp0_dfp_shubclkds_ctrl_reg, shubclk_ds_enb) \
     mp0_dfp_shubclkds_ctrl_reg = (mp0_dfp_shubclkds_ctrl_reg & ~MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_MASK) | (shubclk_ds_enb << MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_SHIFT)
#define MP0_DFP_SHUBCLKDS_CTRL_SET_SHUBCLK_DS_STATUS(mp0_dfp_shubclkds_ctrl_reg, shubclk_ds_status) \
     mp0_dfp_shubclkds_ctrl_reg = (mp0_dfp_shubclkds_ctrl_reg & ~MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_MASK) | (shubclk_ds_status << MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_SHIFT)
#define MP0_DFP_SHUBCLKDS_CTRL_SET_SHUBCLK_DS_TIMEOUT(mp0_dfp_shubclkds_ctrl_reg, shubclk_ds_timeout) \
     mp0_dfp_shubclkds_ctrl_reg = (mp0_dfp_shubclkds_ctrl_reg & ~MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_MASK) | (shubclk_ds_timeout << MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_SHIFT)
#define MP0_DFP_SHUBCLKDS_CTRL_SET_SHUBCLK_SHUBIF_WAKE_MASK(mp0_dfp_shubclkds_ctrl_reg, shubclk_shubif_wake_mask) \
     mp0_dfp_shubclkds_ctrl_reg = (mp0_dfp_shubclkds_ctrl_reg & ~MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_MASK) | (shubclk_shubif_wake_mask << MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_dfp_shubclkds_ctrl_t {
          unsigned int shubclk_ds_enb                 : MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_SIZE;
          unsigned int shubclk_ds_status              : MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_SIZE;
          unsigned int shubclk_ds_timeout             : MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_SIZE;
          unsigned int shubclk_shubif_wake_mask       : MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_SIZE;
          unsigned int                                : 21;
     } mp0_dfp_shubclkds_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_dfp_shubclkds_ctrl_t {
          unsigned int                                : 21;
          unsigned int shubclk_shubif_wake_mask       : MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_SIZE;
          unsigned int shubclk_ds_timeout             : MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_SIZE;
          unsigned int shubclk_ds_status              : MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_SIZE;
          unsigned int shubclk_ds_enb                 : MP0_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_SIZE;
     } mp0_dfp_shubclkds_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_dfp_shubclkds_ctrl_t f;
} mp0_dfp_shubclkds_ctrl_u;


#endif


