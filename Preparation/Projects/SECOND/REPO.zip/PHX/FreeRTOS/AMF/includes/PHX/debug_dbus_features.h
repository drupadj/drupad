// Copyright (c) 2010 - 2019 Advanced Micro Devices, Inc. All rights reserved.
#ifndef __DEBUG_DBUS_FEATURES_H__
#define __DEBUG_DBUS_FEATURES_H__
// reference features

// imported features

// local features
#define DEBUG_DBUS__DEBUG_DBUS_WIDTH 32
#define DEBUG_DBUS__DEBUG_DBUS_WIDTH__32 1
#endif
