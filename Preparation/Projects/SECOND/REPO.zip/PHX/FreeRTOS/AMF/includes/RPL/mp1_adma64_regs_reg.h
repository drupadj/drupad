// Copyright (c) 1994 - 2021 Advanced Micro Devices, Inc. All rights reserved. 
 #if !defined (_MP1_ADMA64_REGS_FIDDLE_H)
#define _MP1_ADMA64_REGS_FIDDLE_H
 /*****************************************************************************************************************
 *
 *  mp1_adma64_regs_reg.h
 *
 *  Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif

 /*******************************************************
 * Values
 *******************************************************/

 /*******************************************************
 * Structures
 *******************************************************/

/*
 * mp1_Adma64Cmd_Queue_Priority0 struct
 */

#define mp1_Adma64Cmd_Queue_Priority0_REG_SIZE         32
#define mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue0_SIZE  3
#define mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue1_SIZE  3
#define mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue2_SIZE  3

#define mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue0_SHIFT  0
#define mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue1_SHIFT  3
#define mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue2_SHIFT  6

#define mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue0_MASK  0x00000007
#define mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue1_MASK  0x00000038
#define mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue2_MASK  0x000001c0

#define mp1_Adma64Cmd_Queue_Priority0_MASK \
      (mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue0_MASK | \
      mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue1_MASK | \
      mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue2_MASK)

#define mp1_Adma64Cmd_Queue_Priority0_DEFAULT 0x000001ff

#define mp1_Adma64Cmd_Queue_Priority0_GET_RI_PriorityCmdQueue0(mp1_adma64cmd_queue_priority0) \
      ((mp1_adma64cmd_queue_priority0 & mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue0_MASK) >> mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue0_SHIFT)
#define mp1_Adma64Cmd_Queue_Priority0_GET_RI_PriorityCmdQueue1(mp1_adma64cmd_queue_priority0) \
      ((mp1_adma64cmd_queue_priority0 & mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue1_MASK) >> mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue1_SHIFT)
#define mp1_Adma64Cmd_Queue_Priority0_GET_RI_PriorityCmdQueue2(mp1_adma64cmd_queue_priority0) \
      ((mp1_adma64cmd_queue_priority0 & mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue2_MASK) >> mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue2_SHIFT)

#define mp1_Adma64Cmd_Queue_Priority0_SET_RI_PriorityCmdQueue0(mp1_adma64cmd_queue_priority0_reg, ri_prioritycmdqueue0) \
      mp1_adma64cmd_queue_priority0_reg = (mp1_adma64cmd_queue_priority0_reg & ~mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue0_MASK) | (ri_prioritycmdqueue0 << mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue0_SHIFT)
#define mp1_Adma64Cmd_Queue_Priority0_SET_RI_PriorityCmdQueue1(mp1_adma64cmd_queue_priority0_reg, ri_prioritycmdqueue1) \
      mp1_adma64cmd_queue_priority0_reg = (mp1_adma64cmd_queue_priority0_reg & ~mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue1_MASK) | (ri_prioritycmdqueue1 << mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue1_SHIFT)
#define mp1_Adma64Cmd_Queue_Priority0_SET_RI_PriorityCmdQueue2(mp1_adma64cmd_queue_priority0_reg, ri_prioritycmdqueue2) \
      mp1_adma64cmd_queue_priority0_reg = (mp1_adma64cmd_queue_priority0_reg & ~mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue2_MASK) | (ri_prioritycmdqueue2 << mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue2_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_queue_priority0_t {
            unsigned int ri_prioritycmdqueue0           : mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue0_SIZE;
            unsigned int ri_prioritycmdqueue1           : mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue1_SIZE;
            unsigned int ri_prioritycmdqueue2           : mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue2_SIZE;
            unsigned int                                : 23;
      } mp1_adma64cmd_queue_priority0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_queue_priority0_t {
            unsigned int                                : 23;
            unsigned int ri_prioritycmdqueue2           : mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue2_SIZE;
            unsigned int ri_prioritycmdqueue1           : mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue1_SIZE;
            unsigned int ri_prioritycmdqueue0           : mp1_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue0_SIZE;
      } mp1_adma64cmd_queue_priority0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_queue_priority0_t f;
} mp1_adma64cmd_queue_priority0_u;


/*
 * mp1_Adma64ReqID_Config0 struct
 */

#define mp1_Adma64ReqID_Config0_REG_SIZE         32
#define mp1_Adma64ReqID_Config0_RI_Q0_ReqId_SIZE  3
#define mp1_Adma64ReqID_Config0_RI_Q1_ReqId_SIZE  3
#define mp1_Adma64ReqID_Config0_RI_Q2_ReqId_SIZE  3

#define mp1_Adma64ReqID_Config0_RI_Q0_ReqId_SHIFT  0
#define mp1_Adma64ReqID_Config0_RI_Q1_ReqId_SHIFT  3
#define mp1_Adma64ReqID_Config0_RI_Q2_ReqId_SHIFT  6

#define mp1_Adma64ReqID_Config0_RI_Q0_ReqId_MASK  0x00000007
#define mp1_Adma64ReqID_Config0_RI_Q1_ReqId_MASK  0x00000038
#define mp1_Adma64ReqID_Config0_RI_Q2_ReqId_MASK  0x000001c0

#define mp1_Adma64ReqID_Config0_MASK \
      (mp1_Adma64ReqID_Config0_RI_Q0_ReqId_MASK | \
      mp1_Adma64ReqID_Config0_RI_Q1_ReqId_MASK | \
      mp1_Adma64ReqID_Config0_RI_Q2_ReqId_MASK)

#define mp1_Adma64ReqID_Config0_DEFAULT 0x00000049

#define mp1_Adma64ReqID_Config0_GET_RI_Q0_ReqId(mp1_adma64reqid_config0) \
      ((mp1_adma64reqid_config0 & mp1_Adma64ReqID_Config0_RI_Q0_ReqId_MASK) >> mp1_Adma64ReqID_Config0_RI_Q0_ReqId_SHIFT)
#define mp1_Adma64ReqID_Config0_GET_RI_Q1_ReqId(mp1_adma64reqid_config0) \
      ((mp1_adma64reqid_config0 & mp1_Adma64ReqID_Config0_RI_Q1_ReqId_MASK) >> mp1_Adma64ReqID_Config0_RI_Q1_ReqId_SHIFT)
#define mp1_Adma64ReqID_Config0_GET_RI_Q2_ReqId(mp1_adma64reqid_config0) \
      ((mp1_adma64reqid_config0 & mp1_Adma64ReqID_Config0_RI_Q2_ReqId_MASK) >> mp1_Adma64ReqID_Config0_RI_Q2_ReqId_SHIFT)

#define mp1_Adma64ReqID_Config0_SET_RI_Q0_ReqId(mp1_adma64reqid_config0_reg, ri_q0_reqid) \
      mp1_adma64reqid_config0_reg = (mp1_adma64reqid_config0_reg & ~mp1_Adma64ReqID_Config0_RI_Q0_ReqId_MASK) | (ri_q0_reqid << mp1_Adma64ReqID_Config0_RI_Q0_ReqId_SHIFT)
#define mp1_Adma64ReqID_Config0_SET_RI_Q1_ReqId(mp1_adma64reqid_config0_reg, ri_q1_reqid) \
      mp1_adma64reqid_config0_reg = (mp1_adma64reqid_config0_reg & ~mp1_Adma64ReqID_Config0_RI_Q1_ReqId_MASK) | (ri_q1_reqid << mp1_Adma64ReqID_Config0_RI_Q1_ReqId_SHIFT)
#define mp1_Adma64ReqID_Config0_SET_RI_Q2_ReqId(mp1_adma64reqid_config0_reg, ri_q2_reqid) \
      mp1_adma64reqid_config0_reg = (mp1_adma64reqid_config0_reg & ~mp1_Adma64ReqID_Config0_RI_Q2_ReqId_MASK) | (ri_q2_reqid << mp1_Adma64ReqID_Config0_RI_Q2_ReqId_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64reqid_config0_t {
            unsigned int ri_q0_reqid                    : mp1_Adma64ReqID_Config0_RI_Q0_ReqId_SIZE;
            unsigned int ri_q1_reqid                    : mp1_Adma64ReqID_Config0_RI_Q1_ReqId_SIZE;
            unsigned int ri_q2_reqid                    : mp1_Adma64ReqID_Config0_RI_Q2_ReqId_SIZE;
            unsigned int                                : 23;
      } mp1_adma64reqid_config0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64reqid_config0_t {
            unsigned int                                : 23;
            unsigned int ri_q2_reqid                    : mp1_Adma64ReqID_Config0_RI_Q2_ReqId_SIZE;
            unsigned int ri_q1_reqid                    : mp1_Adma64ReqID_Config0_RI_Q1_ReqId_SIZE;
            unsigned int ri_q0_reqid                    : mp1_Adma64ReqID_Config0_RI_Q0_ReqId_SIZE;
      } mp1_adma64reqid_config0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64reqid_config0_t f;
} mp1_adma64reqid_config0_u;


/*
 * mp1_Adma64Module_Reset struct
 */

#define mp1_Adma64Module_Reset_REG_SIZE         32
#define mp1_Adma64Module_Reset_RI_PT_Reset_SIZE  1
#define mp1_Adma64Module_Reset_RI_IDMA_Reset_SIZE  1
#define mp1_Adma64Module_Reset_RI_JPM_Reset_SIZE  1
#define mp1_Adma64Module_Reset_RI_ODMA_Reset_SIZE  1
#define mp1_Adma64Module_Reset_RI_VQM0_Reset_SIZE  1
#define mp1_Adma64Module_Reset_RI_VQM1_Reset_SIZE  1
#define mp1_Adma64Module_Reset_RI_VQM2_Reset_SIZE  1

#define mp1_Adma64Module_Reset_RI_PT_Reset_SHIFT  3
#define mp1_Adma64Module_Reset_RI_IDMA_Reset_SHIFT  10
#define mp1_Adma64Module_Reset_RI_JPM_Reset_SHIFT  11
#define mp1_Adma64Module_Reset_RI_ODMA_Reset_SHIFT  12
#define mp1_Adma64Module_Reset_RI_VQM0_Reset_SHIFT  13
#define mp1_Adma64Module_Reset_RI_VQM1_Reset_SHIFT  14
#define mp1_Adma64Module_Reset_RI_VQM2_Reset_SHIFT  15

#define mp1_Adma64Module_Reset_RI_PT_Reset_MASK  0x00000008
#define mp1_Adma64Module_Reset_RI_IDMA_Reset_MASK  0x00000400
#define mp1_Adma64Module_Reset_RI_JPM_Reset_MASK  0x00000800
#define mp1_Adma64Module_Reset_RI_ODMA_Reset_MASK  0x00001000
#define mp1_Adma64Module_Reset_RI_VQM0_Reset_MASK  0x00002000
#define mp1_Adma64Module_Reset_RI_VQM1_Reset_MASK  0x00004000
#define mp1_Adma64Module_Reset_RI_VQM2_Reset_MASK  0x00008000

#define mp1_Adma64Module_Reset_MASK \
      (mp1_Adma64Module_Reset_RI_PT_Reset_MASK | \
      mp1_Adma64Module_Reset_RI_IDMA_Reset_MASK | \
      mp1_Adma64Module_Reset_RI_JPM_Reset_MASK | \
      mp1_Adma64Module_Reset_RI_ODMA_Reset_MASK | \
      mp1_Adma64Module_Reset_RI_VQM0_Reset_MASK | \
      mp1_Adma64Module_Reset_RI_VQM1_Reset_MASK | \
      mp1_Adma64Module_Reset_RI_VQM2_Reset_MASK)

#define mp1_Adma64Module_Reset_DEFAULT 0x00000000

#define mp1_Adma64Module_Reset_GET_RI_PT_Reset(mp1_adma64module_reset) \
      ((mp1_adma64module_reset & mp1_Adma64Module_Reset_RI_PT_Reset_MASK) >> mp1_Adma64Module_Reset_RI_PT_Reset_SHIFT)
#define mp1_Adma64Module_Reset_GET_RI_IDMA_Reset(mp1_adma64module_reset) \
      ((mp1_adma64module_reset & mp1_Adma64Module_Reset_RI_IDMA_Reset_MASK) >> mp1_Adma64Module_Reset_RI_IDMA_Reset_SHIFT)
#define mp1_Adma64Module_Reset_GET_RI_JPM_Reset(mp1_adma64module_reset) \
      ((mp1_adma64module_reset & mp1_Adma64Module_Reset_RI_JPM_Reset_MASK) >> mp1_Adma64Module_Reset_RI_JPM_Reset_SHIFT)
#define mp1_Adma64Module_Reset_GET_RI_ODMA_Reset(mp1_adma64module_reset) \
      ((mp1_adma64module_reset & mp1_Adma64Module_Reset_RI_ODMA_Reset_MASK) >> mp1_Adma64Module_Reset_RI_ODMA_Reset_SHIFT)
#define mp1_Adma64Module_Reset_GET_RI_VQM0_Reset(mp1_adma64module_reset) \
      ((mp1_adma64module_reset & mp1_Adma64Module_Reset_RI_VQM0_Reset_MASK) >> mp1_Adma64Module_Reset_RI_VQM0_Reset_SHIFT)
#define mp1_Adma64Module_Reset_GET_RI_VQM1_Reset(mp1_adma64module_reset) \
      ((mp1_adma64module_reset & mp1_Adma64Module_Reset_RI_VQM1_Reset_MASK) >> mp1_Adma64Module_Reset_RI_VQM1_Reset_SHIFT)
#define mp1_Adma64Module_Reset_GET_RI_VQM2_Reset(mp1_adma64module_reset) \
      ((mp1_adma64module_reset & mp1_Adma64Module_Reset_RI_VQM2_Reset_MASK) >> mp1_Adma64Module_Reset_RI_VQM2_Reset_SHIFT)

#define mp1_Adma64Module_Reset_SET_RI_PT_Reset(mp1_adma64module_reset_reg, ri_pt_reset) \
      mp1_adma64module_reset_reg = (mp1_adma64module_reset_reg & ~mp1_Adma64Module_Reset_RI_PT_Reset_MASK) | (ri_pt_reset << mp1_Adma64Module_Reset_RI_PT_Reset_SHIFT)
#define mp1_Adma64Module_Reset_SET_RI_IDMA_Reset(mp1_adma64module_reset_reg, ri_idma_reset) \
      mp1_adma64module_reset_reg = (mp1_adma64module_reset_reg & ~mp1_Adma64Module_Reset_RI_IDMA_Reset_MASK) | (ri_idma_reset << mp1_Adma64Module_Reset_RI_IDMA_Reset_SHIFT)
#define mp1_Adma64Module_Reset_SET_RI_JPM_Reset(mp1_adma64module_reset_reg, ri_jpm_reset) \
      mp1_adma64module_reset_reg = (mp1_adma64module_reset_reg & ~mp1_Adma64Module_Reset_RI_JPM_Reset_MASK) | (ri_jpm_reset << mp1_Adma64Module_Reset_RI_JPM_Reset_SHIFT)
#define mp1_Adma64Module_Reset_SET_RI_ODMA_Reset(mp1_adma64module_reset_reg, ri_odma_reset) \
      mp1_adma64module_reset_reg = (mp1_adma64module_reset_reg & ~mp1_Adma64Module_Reset_RI_ODMA_Reset_MASK) | (ri_odma_reset << mp1_Adma64Module_Reset_RI_ODMA_Reset_SHIFT)
#define mp1_Adma64Module_Reset_SET_RI_VQM0_Reset(mp1_adma64module_reset_reg, ri_vqm0_reset) \
      mp1_adma64module_reset_reg = (mp1_adma64module_reset_reg & ~mp1_Adma64Module_Reset_RI_VQM0_Reset_MASK) | (ri_vqm0_reset << mp1_Adma64Module_Reset_RI_VQM0_Reset_SHIFT)
#define mp1_Adma64Module_Reset_SET_RI_VQM1_Reset(mp1_adma64module_reset_reg, ri_vqm1_reset) \
      mp1_adma64module_reset_reg = (mp1_adma64module_reset_reg & ~mp1_Adma64Module_Reset_RI_VQM1_Reset_MASK) | (ri_vqm1_reset << mp1_Adma64Module_Reset_RI_VQM1_Reset_SHIFT)
#define mp1_Adma64Module_Reset_SET_RI_VQM2_Reset(mp1_adma64module_reset_reg, ri_vqm2_reset) \
      mp1_adma64module_reset_reg = (mp1_adma64module_reset_reg & ~mp1_Adma64Module_Reset_RI_VQM2_Reset_MASK) | (ri_vqm2_reset << mp1_Adma64Module_Reset_RI_VQM2_Reset_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64module_reset_t {
            unsigned int                                : 3;
            unsigned int ri_pt_reset                    : mp1_Adma64Module_Reset_RI_PT_Reset_SIZE;
            unsigned int                                : 6;
            unsigned int ri_idma_reset                  : mp1_Adma64Module_Reset_RI_IDMA_Reset_SIZE;
            unsigned int ri_jpm_reset                   : mp1_Adma64Module_Reset_RI_JPM_Reset_SIZE;
            unsigned int ri_odma_reset                  : mp1_Adma64Module_Reset_RI_ODMA_Reset_SIZE;
            unsigned int ri_vqm0_reset                  : mp1_Adma64Module_Reset_RI_VQM0_Reset_SIZE;
            unsigned int ri_vqm1_reset                  : mp1_Adma64Module_Reset_RI_VQM1_Reset_SIZE;
            unsigned int ri_vqm2_reset                  : mp1_Adma64Module_Reset_RI_VQM2_Reset_SIZE;
            unsigned int                                : 16;
      } mp1_adma64module_reset_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64module_reset_t {
            unsigned int                                : 16;
            unsigned int ri_vqm2_reset                  : mp1_Adma64Module_Reset_RI_VQM2_Reset_SIZE;
            unsigned int ri_vqm1_reset                  : mp1_Adma64Module_Reset_RI_VQM1_Reset_SIZE;
            unsigned int ri_vqm0_reset                  : mp1_Adma64Module_Reset_RI_VQM0_Reset_SIZE;
            unsigned int ri_odma_reset                  : mp1_Adma64Module_Reset_RI_ODMA_Reset_SIZE;
            unsigned int ri_jpm_reset                   : mp1_Adma64Module_Reset_RI_JPM_Reset_SIZE;
            unsigned int ri_idma_reset                  : mp1_Adma64Module_Reset_RI_IDMA_Reset_SIZE;
            unsigned int                                : 6;
            unsigned int ri_pt_reset                    : mp1_Adma64Module_Reset_RI_PT_Reset_SIZE;
            unsigned int                                : 3;
      } mp1_adma64module_reset_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64module_reset_t f;
} mp1_adma64module_reset_u;


/*
 * mp1_Adma64Cmd_Timeout struct
 */

#define mp1_Adma64Cmd_Timeout_REG_SIZE         32
#define mp1_Adma64Cmd_Timeout_RI_CmdTimeout_SIZE  32

#define mp1_Adma64Cmd_Timeout_RI_CmdTimeout_SHIFT  0

#define mp1_Adma64Cmd_Timeout_RI_CmdTimeout_MASK  0xffffffff

#define mp1_Adma64Cmd_Timeout_MASK \
      (mp1_Adma64Cmd_Timeout_RI_CmdTimeout_MASK)

#define mp1_Adma64Cmd_Timeout_DEFAULT  0x00000000

#define mp1_Adma64Cmd_Timeout_GET_RI_CmdTimeout(mp1_adma64cmd_timeout) \
      ((mp1_adma64cmd_timeout & mp1_Adma64Cmd_Timeout_RI_CmdTimeout_MASK) >> mp1_Adma64Cmd_Timeout_RI_CmdTimeout_SHIFT)

#define mp1_Adma64Cmd_Timeout_SET_RI_CmdTimeout(mp1_adma64cmd_timeout_reg, ri_cmdtimeout) \
      mp1_adma64cmd_timeout_reg = (mp1_adma64cmd_timeout_reg & ~mp1_Adma64Cmd_Timeout_RI_CmdTimeout_MASK) | (ri_cmdtimeout << mp1_Adma64Cmd_Timeout_RI_CmdTimeout_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_timeout_t {
            unsigned int ri_cmdtimeout                  : mp1_Adma64Cmd_Timeout_RI_CmdTimeout_SIZE;
      } mp1_adma64cmd_timeout_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_timeout_t {
            unsigned int ri_cmdtimeout                  : mp1_Adma64Cmd_Timeout_RI_CmdTimeout_SIZE;
      } mp1_adma64cmd_timeout_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_timeout_t f;
} mp1_adma64cmd_timeout_u;


/*
 * mp1_Adma64Cmd_Timeout_Granularity struct
 */

#define mp1_Adma64Cmd_Timeout_Granularity_REG_SIZE         32
#define mp1_Adma64Cmd_Timeout_Granularity_RI_Granularity_SIZE  32

#define mp1_Adma64Cmd_Timeout_Granularity_RI_Granularity_SHIFT  0

#define mp1_Adma64Cmd_Timeout_Granularity_RI_Granularity_MASK  0xffffffff

#define mp1_Adma64Cmd_Timeout_Granularity_MASK \
      (mp1_Adma64Cmd_Timeout_Granularity_RI_Granularity_MASK)

#define mp1_Adma64Cmd_Timeout_Granularity_DEFAULT 0x00000001

#define mp1_Adma64Cmd_Timeout_Granularity_GET_RI_Granularity(mp1_adma64cmd_timeout_granularity) \
      ((mp1_adma64cmd_timeout_granularity & mp1_Adma64Cmd_Timeout_Granularity_RI_Granularity_MASK) >> mp1_Adma64Cmd_Timeout_Granularity_RI_Granularity_SHIFT)

#define mp1_Adma64Cmd_Timeout_Granularity_SET_RI_Granularity(mp1_adma64cmd_timeout_granularity_reg, ri_granularity) \
      mp1_adma64cmd_timeout_granularity_reg = (mp1_adma64cmd_timeout_granularity_reg & ~mp1_Adma64Cmd_Timeout_Granularity_RI_Granularity_MASK) | (ri_granularity << mp1_Adma64Cmd_Timeout_Granularity_RI_Granularity_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_timeout_granularity_t {
            unsigned int ri_granularity                 : mp1_Adma64Cmd_Timeout_Granularity_RI_Granularity_SIZE;
      } mp1_adma64cmd_timeout_granularity_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_timeout_granularity_t {
            unsigned int ri_granularity                 : mp1_Adma64Cmd_Timeout_Granularity_RI_Granularity_SIZE;
      } mp1_adma64cmd_timeout_granularity_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_timeout_granularity_t f;
} mp1_adma64cmd_timeout_granularity_u;


/*
 * mp1_Adma64Memory_Deep_Sleep_Enable struct
 */

#define mp1_Adma64Memory_Deep_Sleep_Enable_REG_SIZE         32
#define mp1_Adma64Memory_Deep_Sleep_Enable_RI_DS_COUNTER_SIZE  10
#define mp1_Adma64Memory_Deep_Sleep_Enable_RI_DS_ENG_SEL_SIZE  5

#define mp1_Adma64Memory_Deep_Sleep_Enable_RI_DS_COUNTER_SHIFT  0
#define mp1_Adma64Memory_Deep_Sleep_Enable_RI_DS_ENG_SEL_SHIFT  10

#define mp1_Adma64Memory_Deep_Sleep_Enable_RI_DS_COUNTER_MASK  0x000003ff
#define mp1_Adma64Memory_Deep_Sleep_Enable_RI_DS_ENG_SEL_MASK  0x00007c00

#define mp1_Adma64Memory_Deep_Sleep_Enable_MASK \
      (mp1_Adma64Memory_Deep_Sleep_Enable_RI_DS_COUNTER_MASK | \
      mp1_Adma64Memory_Deep_Sleep_Enable_RI_DS_ENG_SEL_MASK)

#define mp1_Adma64Memory_Deep_Sleep_Enable_DEFAULT 0x00000000

#define mp1_Adma64Memory_Deep_Sleep_Enable_GET_RI_DS_COUNTER(mp1_adma64memory_deep_sleep_enable) \
      ((mp1_adma64memory_deep_sleep_enable & mp1_Adma64Memory_Deep_Sleep_Enable_RI_DS_COUNTER_MASK) >> mp1_Adma64Memory_Deep_Sleep_Enable_RI_DS_COUNTER_SHIFT)
#define mp1_Adma64Memory_Deep_Sleep_Enable_GET_RI_DS_ENG_SEL(mp1_adma64memory_deep_sleep_enable) \
      ((mp1_adma64memory_deep_sleep_enable & mp1_Adma64Memory_Deep_Sleep_Enable_RI_DS_ENG_SEL_MASK) >> mp1_Adma64Memory_Deep_Sleep_Enable_RI_DS_ENG_SEL_SHIFT)

#define mp1_Adma64Memory_Deep_Sleep_Enable_SET_RI_DS_COUNTER(mp1_adma64memory_deep_sleep_enable_reg, ri_ds_counter) \
      mp1_adma64memory_deep_sleep_enable_reg = (mp1_adma64memory_deep_sleep_enable_reg & ~mp1_Adma64Memory_Deep_Sleep_Enable_RI_DS_COUNTER_MASK) | (ri_ds_counter << mp1_Adma64Memory_Deep_Sleep_Enable_RI_DS_COUNTER_SHIFT)
#define mp1_Adma64Memory_Deep_Sleep_Enable_SET_RI_DS_ENG_SEL(mp1_adma64memory_deep_sleep_enable_reg, ri_ds_eng_sel) \
      mp1_adma64memory_deep_sleep_enable_reg = (mp1_adma64memory_deep_sleep_enable_reg & ~mp1_Adma64Memory_Deep_Sleep_Enable_RI_DS_ENG_SEL_MASK) | (ri_ds_eng_sel << mp1_Adma64Memory_Deep_Sleep_Enable_RI_DS_ENG_SEL_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64memory_deep_sleep_enable_t {
            unsigned int ri_ds_counter                  : mp1_Adma64Memory_Deep_Sleep_Enable_RI_DS_COUNTER_SIZE;
            unsigned int ri_ds_eng_sel                  : mp1_Adma64Memory_Deep_Sleep_Enable_RI_DS_ENG_SEL_SIZE;
            unsigned int                                : 17;
      } mp1_adma64memory_deep_sleep_enable_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64memory_deep_sleep_enable_t {
            unsigned int                                : 17;
            unsigned int ri_ds_eng_sel                  : mp1_Adma64Memory_Deep_Sleep_Enable_RI_DS_ENG_SEL_SIZE;
            unsigned int ri_ds_counter                  : mp1_Adma64Memory_Deep_Sleep_Enable_RI_DS_COUNTER_SIZE;
      } mp1_adma64memory_deep_sleep_enable_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64memory_deep_sleep_enable_t f;
} mp1_adma64memory_deep_sleep_enable_u;


/*
 * mp1_Adma64Memory_Deep_Sleep_Status struct
 */

#define mp1_Adma64Memory_Deep_Sleep_Status_REG_SIZE         32
#define mp1_Adma64Memory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_SIZE  8

#define mp1_Adma64Memory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_SHIFT  0

#define mp1_Adma64Memory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_MASK  0x000000ff

#define mp1_Adma64Memory_Deep_Sleep_Status_MASK \
      (mp1_Adma64Memory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_MASK)

#define mp1_Adma64Memory_Deep_Sleep_Status_DEFAULT 0x000000f9

#define mp1_Adma64Memory_Deep_Sleep_Status_GET_RI_DS_ENG_IS_AWAKE(mp1_adma64memory_deep_sleep_status) \
      ((mp1_adma64memory_deep_sleep_status & mp1_Adma64Memory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_MASK) >> mp1_Adma64Memory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_SHIFT)

#define mp1_Adma64Memory_Deep_Sleep_Status_SET_RI_DS_ENG_IS_AWAKE(mp1_adma64memory_deep_sleep_status_reg, ri_ds_eng_is_awake) \
      mp1_adma64memory_deep_sleep_status_reg = (mp1_adma64memory_deep_sleep_status_reg & ~mp1_Adma64Memory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_MASK) | (ri_ds_eng_is_awake << mp1_Adma64Memory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64memory_deep_sleep_status_t {
            unsigned int ri_ds_eng_is_awake             : mp1_Adma64Memory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_SIZE;
            unsigned int                                : 24;
      } mp1_adma64memory_deep_sleep_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64memory_deep_sleep_status_t {
            unsigned int                                : 24;
            unsigned int ri_ds_eng_is_awake             : mp1_Adma64Memory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_SIZE;
      } mp1_adma64memory_deep_sleep_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64memory_deep_sleep_status_t f;
} mp1_adma64memory_deep_sleep_status_u;


/*
 * mp1_Adma64Clock_Gating_Control struct
 */

#define mp1_Adma64Clock_Gating_Control_REG_SIZE         32
#define mp1_Adma64Clock_Gating_Control_DYN_CLOCK_EN_SIZE  1
#define mp1_Adma64Clock_Gating_Control_GATE_MODE_CCP_SIZE  1
#define mp1_Adma64Clock_Gating_Control_CLK_GATE_DLY_TIMER_SIZE  4
#define mp1_Adma64Clock_Gating_Control_SW_GATE_CCP_SIZE  1
#define mp1_Adma64Clock_Gating_Control_CLK_OFF_DLY_TIMER_SIZE  4

#define mp1_Adma64Clock_Gating_Control_DYN_CLOCK_EN_SHIFT  0
#define mp1_Adma64Clock_Gating_Control_GATE_MODE_CCP_SHIFT  1
#define mp1_Adma64Clock_Gating_Control_CLK_GATE_DLY_TIMER_SHIFT  2
#define mp1_Adma64Clock_Gating_Control_SW_GATE_CCP_SHIFT  6
#define mp1_Adma64Clock_Gating_Control_CLK_OFF_DLY_TIMER_SHIFT  7

#define mp1_Adma64Clock_Gating_Control_DYN_CLOCK_EN_MASK  0x00000001
#define mp1_Adma64Clock_Gating_Control_GATE_MODE_CCP_MASK  0x00000002
#define mp1_Adma64Clock_Gating_Control_CLK_GATE_DLY_TIMER_MASK  0x0000003c
#define mp1_Adma64Clock_Gating_Control_SW_GATE_CCP_MASK  0x00000040
#define mp1_Adma64Clock_Gating_Control_CLK_OFF_DLY_TIMER_MASK  0x00000780

#define mp1_Adma64Clock_Gating_Control_MASK \
      (mp1_Adma64Clock_Gating_Control_DYN_CLOCK_EN_MASK | \
      mp1_Adma64Clock_Gating_Control_GATE_MODE_CCP_MASK | \
      mp1_Adma64Clock_Gating_Control_CLK_GATE_DLY_TIMER_MASK | \
      mp1_Adma64Clock_Gating_Control_SW_GATE_CCP_MASK | \
      mp1_Adma64Clock_Gating_Control_CLK_OFF_DLY_TIMER_MASK)

#define mp1_Adma64Clock_Gating_Control_DEFAULT 0x00000000

#define mp1_Adma64Clock_Gating_Control_GET_DYN_CLOCK_EN(mp1_adma64clock_gating_control) \
      ((mp1_adma64clock_gating_control & mp1_Adma64Clock_Gating_Control_DYN_CLOCK_EN_MASK) >> mp1_Adma64Clock_Gating_Control_DYN_CLOCK_EN_SHIFT)
#define mp1_Adma64Clock_Gating_Control_GET_GATE_MODE_CCP(mp1_adma64clock_gating_control) \
      ((mp1_adma64clock_gating_control & mp1_Adma64Clock_Gating_Control_GATE_MODE_CCP_MASK) >> mp1_Adma64Clock_Gating_Control_GATE_MODE_CCP_SHIFT)
#define mp1_Adma64Clock_Gating_Control_GET_CLK_GATE_DLY_TIMER(mp1_adma64clock_gating_control) \
      ((mp1_adma64clock_gating_control & mp1_Adma64Clock_Gating_Control_CLK_GATE_DLY_TIMER_MASK) >> mp1_Adma64Clock_Gating_Control_CLK_GATE_DLY_TIMER_SHIFT)
#define mp1_Adma64Clock_Gating_Control_GET_SW_GATE_CCP(mp1_adma64clock_gating_control) \
      ((mp1_adma64clock_gating_control & mp1_Adma64Clock_Gating_Control_SW_GATE_CCP_MASK) >> mp1_Adma64Clock_Gating_Control_SW_GATE_CCP_SHIFT)
#define mp1_Adma64Clock_Gating_Control_GET_CLK_OFF_DLY_TIMER(mp1_adma64clock_gating_control) \
      ((mp1_adma64clock_gating_control & mp1_Adma64Clock_Gating_Control_CLK_OFF_DLY_TIMER_MASK) >> mp1_Adma64Clock_Gating_Control_CLK_OFF_DLY_TIMER_SHIFT)

#define mp1_Adma64Clock_Gating_Control_SET_DYN_CLOCK_EN(mp1_adma64clock_gating_control_reg, dyn_clock_en) \
      mp1_adma64clock_gating_control_reg = (mp1_adma64clock_gating_control_reg & ~mp1_Adma64Clock_Gating_Control_DYN_CLOCK_EN_MASK) | (dyn_clock_en << mp1_Adma64Clock_Gating_Control_DYN_CLOCK_EN_SHIFT)
#define mp1_Adma64Clock_Gating_Control_SET_GATE_MODE_CCP(mp1_adma64clock_gating_control_reg, gate_mode_ccp) \
      mp1_adma64clock_gating_control_reg = (mp1_adma64clock_gating_control_reg & ~mp1_Adma64Clock_Gating_Control_GATE_MODE_CCP_MASK) | (gate_mode_ccp << mp1_Adma64Clock_Gating_Control_GATE_MODE_CCP_SHIFT)
#define mp1_Adma64Clock_Gating_Control_SET_CLK_GATE_DLY_TIMER(mp1_adma64clock_gating_control_reg, clk_gate_dly_timer) \
      mp1_adma64clock_gating_control_reg = (mp1_adma64clock_gating_control_reg & ~mp1_Adma64Clock_Gating_Control_CLK_GATE_DLY_TIMER_MASK) | (clk_gate_dly_timer << mp1_Adma64Clock_Gating_Control_CLK_GATE_DLY_TIMER_SHIFT)
#define mp1_Adma64Clock_Gating_Control_SET_SW_GATE_CCP(mp1_adma64clock_gating_control_reg, sw_gate_ccp) \
      mp1_adma64clock_gating_control_reg = (mp1_adma64clock_gating_control_reg & ~mp1_Adma64Clock_Gating_Control_SW_GATE_CCP_MASK) | (sw_gate_ccp << mp1_Adma64Clock_Gating_Control_SW_GATE_CCP_SHIFT)
#define mp1_Adma64Clock_Gating_Control_SET_CLK_OFF_DLY_TIMER(mp1_adma64clock_gating_control_reg, clk_off_dly_timer) \
      mp1_adma64clock_gating_control_reg = (mp1_adma64clock_gating_control_reg & ~mp1_Adma64Clock_Gating_Control_CLK_OFF_DLY_TIMER_MASK) | (clk_off_dly_timer << mp1_Adma64Clock_Gating_Control_CLK_OFF_DLY_TIMER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64clock_gating_control_t {
            unsigned int dyn_clock_en                   : mp1_Adma64Clock_Gating_Control_DYN_CLOCK_EN_SIZE;
            unsigned int gate_mode_ccp                  : mp1_Adma64Clock_Gating_Control_GATE_MODE_CCP_SIZE;
            unsigned int clk_gate_dly_timer             : mp1_Adma64Clock_Gating_Control_CLK_GATE_DLY_TIMER_SIZE;
            unsigned int sw_gate_ccp                    : mp1_Adma64Clock_Gating_Control_SW_GATE_CCP_SIZE;
            unsigned int clk_off_dly_timer              : mp1_Adma64Clock_Gating_Control_CLK_OFF_DLY_TIMER_SIZE;
            unsigned int                                : 21;
      } mp1_adma64clock_gating_control_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64clock_gating_control_t {
            unsigned int                                : 21;
            unsigned int clk_off_dly_timer              : mp1_Adma64Clock_Gating_Control_CLK_OFF_DLY_TIMER_SIZE;
            unsigned int sw_gate_ccp                    : mp1_Adma64Clock_Gating_Control_SW_GATE_CCP_SIZE;
            unsigned int clk_gate_dly_timer             : mp1_Adma64Clock_Gating_Control_CLK_GATE_DLY_TIMER_SIZE;
            unsigned int gate_mode_ccp                  : mp1_Adma64Clock_Gating_Control_GATE_MODE_CCP_SIZE;
            unsigned int dyn_clock_en                   : mp1_Adma64Clock_Gating_Control_DYN_CLOCK_EN_SIZE;
      } mp1_adma64clock_gating_control_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64clock_gating_control_t f;
} mp1_adma64clock_gating_control_u;


/*
 * mp1_Adma64Version struct
 */

#define mp1_Adma64Version_REG_SIZE         32
#define mp1_Adma64Version_RI_VersionNum_SIZE  6
#define mp1_Adma64Version_RI_NumVQM_SIZE  5

#define mp1_Adma64Version_RI_VersionNum_SHIFT  0
#define mp1_Adma64Version_RI_NumVQM_SHIFT  15

#define mp1_Adma64Version_RI_VersionNum_MASK  0x0000003f
#define mp1_Adma64Version_RI_NumVQM_MASK  0x000f8000

#define mp1_Adma64Version_MASK \
      (mp1_Adma64Version_RI_VersionNum_MASK | \
      mp1_Adma64Version_RI_NumVQM_MASK)

#define mp1_Adma64Version_DEFAULT      0x00018003

#define mp1_Adma64Version_GET_RI_VersionNum(mp1_adma64version) \
      ((mp1_adma64version & mp1_Adma64Version_RI_VersionNum_MASK) >> mp1_Adma64Version_RI_VersionNum_SHIFT)
#define mp1_Adma64Version_GET_RI_NumVQM(mp1_adma64version) \
      ((mp1_adma64version & mp1_Adma64Version_RI_NumVQM_MASK) >> mp1_Adma64Version_RI_NumVQM_SHIFT)

#define mp1_Adma64Version_SET_RI_VersionNum(mp1_adma64version_reg, ri_versionnum) \
      mp1_adma64version_reg = (mp1_adma64version_reg & ~mp1_Adma64Version_RI_VersionNum_MASK) | (ri_versionnum << mp1_Adma64Version_RI_VersionNum_SHIFT)
#define mp1_Adma64Version_SET_RI_NumVQM(mp1_adma64version_reg, ri_numvqm) \
      mp1_adma64version_reg = (mp1_adma64version_reg & ~mp1_Adma64Version_RI_NumVQM_MASK) | (ri_numvqm << mp1_Adma64Version_RI_NumVQM_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64version_t {
            unsigned int ri_versionnum                  : mp1_Adma64Version_RI_VersionNum_SIZE;
            unsigned int                                : 9;
            unsigned int ri_numvqm                      : mp1_Adma64Version_RI_NumVQM_SIZE;
            unsigned int                                : 12;
      } mp1_adma64version_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64version_t {
            unsigned int                                : 12;
            unsigned int ri_numvqm                      : mp1_Adma64Version_RI_NumVQM_SIZE;
            unsigned int                                : 9;
            unsigned int ri_versionnum                  : mp1_Adma64Version_RI_VersionNum_SIZE;
      } mp1_adma64version_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64version_t f;
} mp1_adma64version_u;


/*
 * mp1_Adma64Vqd0_Control struct
 */

#define mp1_Adma64Vqd0_Control_REG_SIZE         32
#define mp1_Adma64Vqd0_Control_RI_Run_SIZE  1
#define mp1_Adma64Vqd0_Control_VQM_Halted_SIZE  1
#define mp1_Adma64Vqd0_Control_RI_Mem_Location_SIZE  1
#define mp1_Adma64Vqd0_Control_RI_Queue_Size_SIZE  4
#define mp1_Adma64Vqd0_Control_RI_COMP_DESC_SIZE  1
#define mp1_Adma64Vqd0_Control_RI_VQD_Pointer_Hi_SIZE  16

#define mp1_Adma64Vqd0_Control_RI_Run_SHIFT  0
#define mp1_Adma64Vqd0_Control_VQM_Halted_SHIFT  1
#define mp1_Adma64Vqd0_Control_RI_Mem_Location_SHIFT  2
#define mp1_Adma64Vqd0_Control_RI_Queue_Size_SHIFT  3
#define mp1_Adma64Vqd0_Control_RI_COMP_DESC_SHIFT  7
#define mp1_Adma64Vqd0_Control_RI_VQD_Pointer_Hi_SHIFT  16

#define mp1_Adma64Vqd0_Control_RI_Run_MASK  0x00000001
#define mp1_Adma64Vqd0_Control_VQM_Halted_MASK  0x00000002
#define mp1_Adma64Vqd0_Control_RI_Mem_Location_MASK  0x00000004
#define mp1_Adma64Vqd0_Control_RI_Queue_Size_MASK  0x00000078
#define mp1_Adma64Vqd0_Control_RI_COMP_DESC_MASK  0x00000080
#define mp1_Adma64Vqd0_Control_RI_VQD_Pointer_Hi_MASK  0xffff0000

#define mp1_Adma64Vqd0_Control_MASK \
      (mp1_Adma64Vqd0_Control_RI_Run_MASK | \
      mp1_Adma64Vqd0_Control_VQM_Halted_MASK | \
      mp1_Adma64Vqd0_Control_RI_Mem_Location_MASK | \
      mp1_Adma64Vqd0_Control_RI_Queue_Size_MASK | \
      mp1_Adma64Vqd0_Control_RI_COMP_DESC_MASK | \
      mp1_Adma64Vqd0_Control_RI_VQD_Pointer_Hi_MASK)

#define mp1_Adma64Vqd0_Control_DEFAULT 0x00000002

#define mp1_Adma64Vqd0_Control_GET_RI_Run(mp1_adma64vqd0_control) \
      ((mp1_adma64vqd0_control & mp1_Adma64Vqd0_Control_RI_Run_MASK) >> mp1_Adma64Vqd0_Control_RI_Run_SHIFT)
#define mp1_Adma64Vqd0_Control_GET_VQM_Halted(mp1_adma64vqd0_control) \
      ((mp1_adma64vqd0_control & mp1_Adma64Vqd0_Control_VQM_Halted_MASK) >> mp1_Adma64Vqd0_Control_VQM_Halted_SHIFT)
#define mp1_Adma64Vqd0_Control_GET_RI_Mem_Location(mp1_adma64vqd0_control) \
      ((mp1_adma64vqd0_control & mp1_Adma64Vqd0_Control_RI_Mem_Location_MASK) >> mp1_Adma64Vqd0_Control_RI_Mem_Location_SHIFT)
#define mp1_Adma64Vqd0_Control_GET_RI_Queue_Size(mp1_adma64vqd0_control) \
      ((mp1_adma64vqd0_control & mp1_Adma64Vqd0_Control_RI_Queue_Size_MASK) >> mp1_Adma64Vqd0_Control_RI_Queue_Size_SHIFT)
#define mp1_Adma64Vqd0_Control_GET_RI_COMP_DESC(mp1_adma64vqd0_control) \
      ((mp1_adma64vqd0_control & mp1_Adma64Vqd0_Control_RI_COMP_DESC_MASK) >> mp1_Adma64Vqd0_Control_RI_COMP_DESC_SHIFT)
#define mp1_Adma64Vqd0_Control_GET_RI_VQD_Pointer_Hi(mp1_adma64vqd0_control) \
      ((mp1_adma64vqd0_control & mp1_Adma64Vqd0_Control_RI_VQD_Pointer_Hi_MASK) >> mp1_Adma64Vqd0_Control_RI_VQD_Pointer_Hi_SHIFT)

#define mp1_Adma64Vqd0_Control_SET_RI_Run(mp1_adma64vqd0_control_reg, ri_run) \
      mp1_adma64vqd0_control_reg = (mp1_adma64vqd0_control_reg & ~mp1_Adma64Vqd0_Control_RI_Run_MASK) | (ri_run << mp1_Adma64Vqd0_Control_RI_Run_SHIFT)
#define mp1_Adma64Vqd0_Control_SET_VQM_Halted(mp1_adma64vqd0_control_reg, vqm_halted) \
      mp1_adma64vqd0_control_reg = (mp1_adma64vqd0_control_reg & ~mp1_Adma64Vqd0_Control_VQM_Halted_MASK) | (vqm_halted << mp1_Adma64Vqd0_Control_VQM_Halted_SHIFT)
#define mp1_Adma64Vqd0_Control_SET_RI_Mem_Location(mp1_adma64vqd0_control_reg, ri_mem_location) \
      mp1_adma64vqd0_control_reg = (mp1_adma64vqd0_control_reg & ~mp1_Adma64Vqd0_Control_RI_Mem_Location_MASK) | (ri_mem_location << mp1_Adma64Vqd0_Control_RI_Mem_Location_SHIFT)
#define mp1_Adma64Vqd0_Control_SET_RI_Queue_Size(mp1_adma64vqd0_control_reg, ri_queue_size) \
      mp1_adma64vqd0_control_reg = (mp1_adma64vqd0_control_reg & ~mp1_Adma64Vqd0_Control_RI_Queue_Size_MASK) | (ri_queue_size << mp1_Adma64Vqd0_Control_RI_Queue_Size_SHIFT)
#define mp1_Adma64Vqd0_Control_SET_RI_COMP_DESC(mp1_adma64vqd0_control_reg, ri_comp_desc) \
      mp1_adma64vqd0_control_reg = (mp1_adma64vqd0_control_reg & ~mp1_Adma64Vqd0_Control_RI_COMP_DESC_MASK) | (ri_comp_desc << mp1_Adma64Vqd0_Control_RI_COMP_DESC_SHIFT)
#define mp1_Adma64Vqd0_Control_SET_RI_VQD_Pointer_Hi(mp1_adma64vqd0_control_reg, ri_vqd_pointer_hi) \
      mp1_adma64vqd0_control_reg = (mp1_adma64vqd0_control_reg & ~mp1_Adma64Vqd0_Control_RI_VQD_Pointer_Hi_MASK) | (ri_vqd_pointer_hi << mp1_Adma64Vqd0_Control_RI_VQD_Pointer_Hi_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64vqd0_control_t {
            unsigned int ri_run                         : mp1_Adma64Vqd0_Control_RI_Run_SIZE;
            unsigned int vqm_halted                     : mp1_Adma64Vqd0_Control_VQM_Halted_SIZE;
            unsigned int ri_mem_location                : mp1_Adma64Vqd0_Control_RI_Mem_Location_SIZE;
            unsigned int ri_queue_size                  : mp1_Adma64Vqd0_Control_RI_Queue_Size_SIZE;
            unsigned int ri_comp_desc                   : mp1_Adma64Vqd0_Control_RI_COMP_DESC_SIZE;
            unsigned int                                : 8;
            unsigned int ri_vqd_pointer_hi              : mp1_Adma64Vqd0_Control_RI_VQD_Pointer_Hi_SIZE;
      } mp1_adma64vqd0_control_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64vqd0_control_t {
            unsigned int ri_vqd_pointer_hi              : mp1_Adma64Vqd0_Control_RI_VQD_Pointer_Hi_SIZE;
            unsigned int                                : 8;
            unsigned int ri_comp_desc                   : mp1_Adma64Vqd0_Control_RI_COMP_DESC_SIZE;
            unsigned int ri_queue_size                  : mp1_Adma64Vqd0_Control_RI_Queue_Size_SIZE;
            unsigned int ri_mem_location                : mp1_Adma64Vqd0_Control_RI_Mem_Location_SIZE;
            unsigned int vqm_halted                     : mp1_Adma64Vqd0_Control_VQM_Halted_SIZE;
            unsigned int ri_run                         : mp1_Adma64Vqd0_Control_RI_Run_SIZE;
      } mp1_adma64vqd0_control_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64vqd0_control_t f;
} mp1_adma64vqd0_control_u;


/*
 * mp1_Adma64Vqd0_Tail_Lo struct
 */

#define mp1_Adma64Vqd0_Tail_Lo_REG_SIZE         32
#define mp1_Adma64Vqd0_Tail_Lo_RI_Tail_Pointer_Lo_SIZE  32

#define mp1_Adma64Vqd0_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT  0

#define mp1_Adma64Vqd0_Tail_Lo_RI_Tail_Pointer_Lo_MASK  0xffffffff

#define mp1_Adma64Vqd0_Tail_Lo_MASK \
      (mp1_Adma64Vqd0_Tail_Lo_RI_Tail_Pointer_Lo_MASK)

#define mp1_Adma64Vqd0_Tail_Lo_DEFAULT 0x00000000

#define mp1_Adma64Vqd0_Tail_Lo_GET_RI_Tail_Pointer_Lo(mp1_adma64vqd0_tail_lo) \
      ((mp1_adma64vqd0_tail_lo & mp1_Adma64Vqd0_Tail_Lo_RI_Tail_Pointer_Lo_MASK) >> mp1_Adma64Vqd0_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT)

#define mp1_Adma64Vqd0_Tail_Lo_SET_RI_Tail_Pointer_Lo(mp1_adma64vqd0_tail_lo_reg, ri_tail_pointer_lo) \
      mp1_adma64vqd0_tail_lo_reg = (mp1_adma64vqd0_tail_lo_reg & ~mp1_Adma64Vqd0_Tail_Lo_RI_Tail_Pointer_Lo_MASK) | (ri_tail_pointer_lo << mp1_Adma64Vqd0_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64vqd0_tail_lo_t {
            unsigned int ri_tail_pointer_lo             : mp1_Adma64Vqd0_Tail_Lo_RI_Tail_Pointer_Lo_SIZE;
      } mp1_adma64vqd0_tail_lo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64vqd0_tail_lo_t {
            unsigned int ri_tail_pointer_lo             : mp1_Adma64Vqd0_Tail_Lo_RI_Tail_Pointer_Lo_SIZE;
      } mp1_adma64vqd0_tail_lo_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64vqd0_tail_lo_t f;
} mp1_adma64vqd0_tail_lo_u;


/*
 * mp1_Adma64Vqd0_Head_Lo struct
 */

#define mp1_Adma64Vqd0_Head_Lo_REG_SIZE         32
#define mp1_Adma64Vqd0_Head_Lo_RI_Head_Pointer_Lo_SIZE  32

#define mp1_Adma64Vqd0_Head_Lo_RI_Head_Pointer_Lo_SHIFT  0

#define mp1_Adma64Vqd0_Head_Lo_RI_Head_Pointer_Lo_MASK  0xffffffff

#define mp1_Adma64Vqd0_Head_Lo_MASK \
      (mp1_Adma64Vqd0_Head_Lo_RI_Head_Pointer_Lo_MASK)

#define mp1_Adma64Vqd0_Head_Lo_DEFAULT 0x00000000

#define mp1_Adma64Vqd0_Head_Lo_GET_RI_Head_Pointer_Lo(mp1_adma64vqd0_head_lo) \
      ((mp1_adma64vqd0_head_lo & mp1_Adma64Vqd0_Head_Lo_RI_Head_Pointer_Lo_MASK) >> mp1_Adma64Vqd0_Head_Lo_RI_Head_Pointer_Lo_SHIFT)

#define mp1_Adma64Vqd0_Head_Lo_SET_RI_Head_Pointer_Lo(mp1_adma64vqd0_head_lo_reg, ri_head_pointer_lo) \
      mp1_adma64vqd0_head_lo_reg = (mp1_adma64vqd0_head_lo_reg & ~mp1_Adma64Vqd0_Head_Lo_RI_Head_Pointer_Lo_MASK) | (ri_head_pointer_lo << mp1_Adma64Vqd0_Head_Lo_RI_Head_Pointer_Lo_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64vqd0_head_lo_t {
            unsigned int ri_head_pointer_lo             : mp1_Adma64Vqd0_Head_Lo_RI_Head_Pointer_Lo_SIZE;
      } mp1_adma64vqd0_head_lo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64vqd0_head_lo_t {
            unsigned int ri_head_pointer_lo             : mp1_Adma64Vqd0_Head_Lo_RI_Head_Pointer_Lo_SIZE;
      } mp1_adma64vqd0_head_lo_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64vqd0_head_lo_t f;
} mp1_adma64vqd0_head_lo_u;


/*
 * mp1_Adma64Cmd_Interrupt_Enable_Q0 struct
 */

#define mp1_Adma64Cmd_Interrupt_Enable_Q0_REG_SIZE         32
#define mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_CompInt_Enable_SIZE  1
#define mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_SIZE  1
#define mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_QSI_Enable_SIZE  1
#define mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_QEI_Enable_SIZE  1

#define mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_CompInt_Enable_SHIFT  0
#define mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_SHIFT  1
#define mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_QSI_Enable_SHIFT  2
#define mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_QEI_Enable_SHIFT  3

#define mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_CompInt_Enable_MASK  0x00000001
#define mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_MASK  0x00000002
#define mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_QSI_Enable_MASK  0x00000004
#define mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_QEI_Enable_MASK  0x00000008

#define mp1_Adma64Cmd_Interrupt_Enable_Q0_MASK \
      (mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_CompInt_Enable_MASK | \
      mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_MASK | \
      mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_QSI_Enable_MASK | \
      mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_QEI_Enable_MASK)

#define mp1_Adma64Cmd_Interrupt_Enable_Q0_DEFAULT 0x00000000

#define mp1_Adma64Cmd_Interrupt_Enable_Q0_GET_RI_CompInt_Enable(mp1_adma64cmd_interrupt_enable_q0) \
      ((mp1_adma64cmd_interrupt_enable_q0 & mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_CompInt_Enable_MASK) >> mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_CompInt_Enable_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Enable_Q0_GET_RI_ErrInt_Enable(mp1_adma64cmd_interrupt_enable_q0) \
      ((mp1_adma64cmd_interrupt_enable_q0 & mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_MASK) >> mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Enable_Q0_GET_RI_QSI_Enable(mp1_adma64cmd_interrupt_enable_q0) \
      ((mp1_adma64cmd_interrupt_enable_q0 & mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_QSI_Enable_MASK) >> mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_QSI_Enable_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Enable_Q0_GET_RI_QEI_Enable(mp1_adma64cmd_interrupt_enable_q0) \
      ((mp1_adma64cmd_interrupt_enable_q0 & mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_QEI_Enable_MASK) >> mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_QEI_Enable_SHIFT)

#define mp1_Adma64Cmd_Interrupt_Enable_Q0_SET_RI_CompInt_Enable(mp1_adma64cmd_interrupt_enable_q0_reg, ri_compint_enable) \
      mp1_adma64cmd_interrupt_enable_q0_reg = (mp1_adma64cmd_interrupt_enable_q0_reg & ~mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_CompInt_Enable_MASK) | (ri_compint_enable << mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_CompInt_Enable_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Enable_Q0_SET_RI_ErrInt_Enable(mp1_adma64cmd_interrupt_enable_q0_reg, ri_errint_enable) \
      mp1_adma64cmd_interrupt_enable_q0_reg = (mp1_adma64cmd_interrupt_enable_q0_reg & ~mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_MASK) | (ri_errint_enable << mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Enable_Q0_SET_RI_QSI_Enable(mp1_adma64cmd_interrupt_enable_q0_reg, ri_qsi_enable) \
      mp1_adma64cmd_interrupt_enable_q0_reg = (mp1_adma64cmd_interrupt_enable_q0_reg & ~mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_QSI_Enable_MASK) | (ri_qsi_enable << mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_QSI_Enable_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Enable_Q0_SET_RI_QEI_Enable(mp1_adma64cmd_interrupt_enable_q0_reg, ri_qei_enable) \
      mp1_adma64cmd_interrupt_enable_q0_reg = (mp1_adma64cmd_interrupt_enable_q0_reg & ~mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_QEI_Enable_MASK) | (ri_qei_enable << mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_QEI_Enable_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_interrupt_enable_q0_t {
            unsigned int ri_compint_enable              : mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_CompInt_Enable_SIZE;
            unsigned int ri_errint_enable               : mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_SIZE;
            unsigned int ri_qsi_enable                  : mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_QSI_Enable_SIZE;
            unsigned int ri_qei_enable                  : mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_QEI_Enable_SIZE;
            unsigned int                                : 28;
      } mp1_adma64cmd_interrupt_enable_q0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_interrupt_enable_q0_t {
            unsigned int                                : 28;
            unsigned int ri_qei_enable                  : mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_QEI_Enable_SIZE;
            unsigned int ri_qsi_enable                  : mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_QSI_Enable_SIZE;
            unsigned int ri_errint_enable               : mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_SIZE;
            unsigned int ri_compint_enable              : mp1_Adma64Cmd_Interrupt_Enable_Q0_RI_CompInt_Enable_SIZE;
      } mp1_adma64cmd_interrupt_enable_q0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_interrupt_enable_q0_t f;
} mp1_adma64cmd_interrupt_enable_q0_u;


/*
 * mp1_Adma64Cmd_Interrupt_Status_Q0 struct
 */

#define mp1_Adma64Cmd_Interrupt_Status_Q0_REG_SIZE         32
#define mp1_Adma64Cmd_Interrupt_Status_Q0_RI_CompInt_Valid_SIZE  1
#define mp1_Adma64Cmd_Interrupt_Status_Q0_RI_ErrInt_Valid_SIZE  1
#define mp1_Adma64Cmd_Interrupt_Status_Q0_RI_QSI_Valid_SIZE  1
#define mp1_Adma64Cmd_Interrupt_Status_Q0_RI_QEI_Valid_SIZE  1

#define mp1_Adma64Cmd_Interrupt_Status_Q0_RI_CompInt_Valid_SHIFT  0
#define mp1_Adma64Cmd_Interrupt_Status_Q0_RI_ErrInt_Valid_SHIFT  1
#define mp1_Adma64Cmd_Interrupt_Status_Q0_RI_QSI_Valid_SHIFT  2
#define mp1_Adma64Cmd_Interrupt_Status_Q0_RI_QEI_Valid_SHIFT  3

#define mp1_Adma64Cmd_Interrupt_Status_Q0_RI_CompInt_Valid_MASK  0x00000001
#define mp1_Adma64Cmd_Interrupt_Status_Q0_RI_ErrInt_Valid_MASK  0x00000002
#define mp1_Adma64Cmd_Interrupt_Status_Q0_RI_QSI_Valid_MASK  0x00000004
#define mp1_Adma64Cmd_Interrupt_Status_Q0_RI_QEI_Valid_MASK  0x00000008

#define mp1_Adma64Cmd_Interrupt_Status_Q0_MASK \
      (mp1_Adma64Cmd_Interrupt_Status_Q0_RI_CompInt_Valid_MASK | \
      mp1_Adma64Cmd_Interrupt_Status_Q0_RI_ErrInt_Valid_MASK | \
      mp1_Adma64Cmd_Interrupt_Status_Q0_RI_QSI_Valid_MASK | \
      mp1_Adma64Cmd_Interrupt_Status_Q0_RI_QEI_Valid_MASK)

#define mp1_Adma64Cmd_Interrupt_Status_Q0_DEFAULT 0x00000000

#define mp1_Adma64Cmd_Interrupt_Status_Q0_GET_RI_CompInt_Valid(mp1_adma64cmd_interrupt_status_q0) \
      ((mp1_adma64cmd_interrupt_status_q0 & mp1_Adma64Cmd_Interrupt_Status_Q0_RI_CompInt_Valid_MASK) >> mp1_Adma64Cmd_Interrupt_Status_Q0_RI_CompInt_Valid_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Status_Q0_GET_RI_ErrInt_Valid(mp1_adma64cmd_interrupt_status_q0) \
      ((mp1_adma64cmd_interrupt_status_q0 & mp1_Adma64Cmd_Interrupt_Status_Q0_RI_ErrInt_Valid_MASK) >> mp1_Adma64Cmd_Interrupt_Status_Q0_RI_ErrInt_Valid_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Status_Q0_GET_RI_QSI_Valid(mp1_adma64cmd_interrupt_status_q0) \
      ((mp1_adma64cmd_interrupt_status_q0 & mp1_Adma64Cmd_Interrupt_Status_Q0_RI_QSI_Valid_MASK) >> mp1_Adma64Cmd_Interrupt_Status_Q0_RI_QSI_Valid_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Status_Q0_GET_RI_QEI_Valid(mp1_adma64cmd_interrupt_status_q0) \
      ((mp1_adma64cmd_interrupt_status_q0 & mp1_Adma64Cmd_Interrupt_Status_Q0_RI_QEI_Valid_MASK) >> mp1_Adma64Cmd_Interrupt_Status_Q0_RI_QEI_Valid_SHIFT)

#define mp1_Adma64Cmd_Interrupt_Status_Q0_SET_RI_CompInt_Valid(mp1_adma64cmd_interrupt_status_q0_reg, ri_compint_valid) \
      mp1_adma64cmd_interrupt_status_q0_reg = (mp1_adma64cmd_interrupt_status_q0_reg & ~mp1_Adma64Cmd_Interrupt_Status_Q0_RI_CompInt_Valid_MASK) | (ri_compint_valid << mp1_Adma64Cmd_Interrupt_Status_Q0_RI_CompInt_Valid_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Status_Q0_SET_RI_ErrInt_Valid(mp1_adma64cmd_interrupt_status_q0_reg, ri_errint_valid) \
      mp1_adma64cmd_interrupt_status_q0_reg = (mp1_adma64cmd_interrupt_status_q0_reg & ~mp1_Adma64Cmd_Interrupt_Status_Q0_RI_ErrInt_Valid_MASK) | (ri_errint_valid << mp1_Adma64Cmd_Interrupt_Status_Q0_RI_ErrInt_Valid_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Status_Q0_SET_RI_QSI_Valid(mp1_adma64cmd_interrupt_status_q0_reg, ri_qsi_valid) \
      mp1_adma64cmd_interrupt_status_q0_reg = (mp1_adma64cmd_interrupt_status_q0_reg & ~mp1_Adma64Cmd_Interrupt_Status_Q0_RI_QSI_Valid_MASK) | (ri_qsi_valid << mp1_Adma64Cmd_Interrupt_Status_Q0_RI_QSI_Valid_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Status_Q0_SET_RI_QEI_Valid(mp1_adma64cmd_interrupt_status_q0_reg, ri_qei_valid) \
      mp1_adma64cmd_interrupt_status_q0_reg = (mp1_adma64cmd_interrupt_status_q0_reg & ~mp1_Adma64Cmd_Interrupt_Status_Q0_RI_QEI_Valid_MASK) | (ri_qei_valid << mp1_Adma64Cmd_Interrupt_Status_Q0_RI_QEI_Valid_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_interrupt_status_q0_t {
            unsigned int ri_compint_valid               : mp1_Adma64Cmd_Interrupt_Status_Q0_RI_CompInt_Valid_SIZE;
            unsigned int ri_errint_valid                : mp1_Adma64Cmd_Interrupt_Status_Q0_RI_ErrInt_Valid_SIZE;
            unsigned int ri_qsi_valid                   : mp1_Adma64Cmd_Interrupt_Status_Q0_RI_QSI_Valid_SIZE;
            unsigned int ri_qei_valid                   : mp1_Adma64Cmd_Interrupt_Status_Q0_RI_QEI_Valid_SIZE;
            unsigned int                                : 28;
      } mp1_adma64cmd_interrupt_status_q0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_interrupt_status_q0_t {
            unsigned int                                : 28;
            unsigned int ri_qei_valid                   : mp1_Adma64Cmd_Interrupt_Status_Q0_RI_QEI_Valid_SIZE;
            unsigned int ri_qsi_valid                   : mp1_Adma64Cmd_Interrupt_Status_Q0_RI_QSI_Valid_SIZE;
            unsigned int ri_errint_valid                : mp1_Adma64Cmd_Interrupt_Status_Q0_RI_ErrInt_Valid_SIZE;
            unsigned int ri_compint_valid               : mp1_Adma64Cmd_Interrupt_Status_Q0_RI_CompInt_Valid_SIZE;
      } mp1_adma64cmd_interrupt_status_q0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_interrupt_status_q0_t f;
} mp1_adma64cmd_interrupt_status_q0_u;


/*
 * mp1_Adma64Cmd_Status_Q0 struct
 */

#define mp1_Adma64Cmd_Status_Q0_REG_SIZE         32
#define mp1_Adma64Cmd_Status_Q0_VQM_Error_SIZE  6
#define mp1_Adma64Cmd_Status_Q0_VQM_ErrorPrevious_SIZE  1
#define mp1_Adma64Cmd_Status_Q0_VQM_JStatus_SIZE  3
#define mp1_Adma64Cmd_Status_Q0_VQM_ErrorSource_SIZE  3

#define mp1_Adma64Cmd_Status_Q0_VQM_Error_SHIFT  0
#define mp1_Adma64Cmd_Status_Q0_VQM_ErrorPrevious_SHIFT  6
#define mp1_Adma64Cmd_Status_Q0_VQM_JStatus_SHIFT  7
#define mp1_Adma64Cmd_Status_Q0_VQM_ErrorSource_SHIFT  10

#define mp1_Adma64Cmd_Status_Q0_VQM_Error_MASK  0x0000003f
#define mp1_Adma64Cmd_Status_Q0_VQM_ErrorPrevious_MASK  0x00000040
#define mp1_Adma64Cmd_Status_Q0_VQM_JStatus_MASK  0x00000380
#define mp1_Adma64Cmd_Status_Q0_VQM_ErrorSource_MASK  0x00001c00

#define mp1_Adma64Cmd_Status_Q0_MASK \
      (mp1_Adma64Cmd_Status_Q0_VQM_Error_MASK | \
      mp1_Adma64Cmd_Status_Q0_VQM_ErrorPrevious_MASK | \
      mp1_Adma64Cmd_Status_Q0_VQM_JStatus_MASK | \
      mp1_Adma64Cmd_Status_Q0_VQM_ErrorSource_MASK)

#define mp1_Adma64Cmd_Status_Q0_DEFAULT 0x00000000

#define mp1_Adma64Cmd_Status_Q0_GET_VQM_Error(mp1_adma64cmd_status_q0) \
      ((mp1_adma64cmd_status_q0 & mp1_Adma64Cmd_Status_Q0_VQM_Error_MASK) >> mp1_Adma64Cmd_Status_Q0_VQM_Error_SHIFT)
#define mp1_Adma64Cmd_Status_Q0_GET_VQM_ErrorPrevious(mp1_adma64cmd_status_q0) \
      ((mp1_adma64cmd_status_q0 & mp1_Adma64Cmd_Status_Q0_VQM_ErrorPrevious_MASK) >> mp1_Adma64Cmd_Status_Q0_VQM_ErrorPrevious_SHIFT)
#define mp1_Adma64Cmd_Status_Q0_GET_VQM_JStatus(mp1_adma64cmd_status_q0) \
      ((mp1_adma64cmd_status_q0 & mp1_Adma64Cmd_Status_Q0_VQM_JStatus_MASK) >> mp1_Adma64Cmd_Status_Q0_VQM_JStatus_SHIFT)
#define mp1_Adma64Cmd_Status_Q0_GET_VQM_ErrorSource(mp1_adma64cmd_status_q0) \
      ((mp1_adma64cmd_status_q0 & mp1_Adma64Cmd_Status_Q0_VQM_ErrorSource_MASK) >> mp1_Adma64Cmd_Status_Q0_VQM_ErrorSource_SHIFT)

#define mp1_Adma64Cmd_Status_Q0_SET_VQM_Error(mp1_adma64cmd_status_q0_reg, vqm_error) \
      mp1_adma64cmd_status_q0_reg = (mp1_adma64cmd_status_q0_reg & ~mp1_Adma64Cmd_Status_Q0_VQM_Error_MASK) | (vqm_error << mp1_Adma64Cmd_Status_Q0_VQM_Error_SHIFT)
#define mp1_Adma64Cmd_Status_Q0_SET_VQM_ErrorPrevious(mp1_adma64cmd_status_q0_reg, vqm_errorprevious) \
      mp1_adma64cmd_status_q0_reg = (mp1_adma64cmd_status_q0_reg & ~mp1_Adma64Cmd_Status_Q0_VQM_ErrorPrevious_MASK) | (vqm_errorprevious << mp1_Adma64Cmd_Status_Q0_VQM_ErrorPrevious_SHIFT)
#define mp1_Adma64Cmd_Status_Q0_SET_VQM_JStatus(mp1_adma64cmd_status_q0_reg, vqm_jstatus) \
      mp1_adma64cmd_status_q0_reg = (mp1_adma64cmd_status_q0_reg & ~mp1_Adma64Cmd_Status_Q0_VQM_JStatus_MASK) | (vqm_jstatus << mp1_Adma64Cmd_Status_Q0_VQM_JStatus_SHIFT)
#define mp1_Adma64Cmd_Status_Q0_SET_VQM_ErrorSource(mp1_adma64cmd_status_q0_reg, vqm_errorsource) \
      mp1_adma64cmd_status_q0_reg = (mp1_adma64cmd_status_q0_reg & ~mp1_Adma64Cmd_Status_Q0_VQM_ErrorSource_MASK) | (vqm_errorsource << mp1_Adma64Cmd_Status_Q0_VQM_ErrorSource_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_status_q0_t {
            unsigned int vqm_error                      : mp1_Adma64Cmd_Status_Q0_VQM_Error_SIZE;
            unsigned int vqm_errorprevious              : mp1_Adma64Cmd_Status_Q0_VQM_ErrorPrevious_SIZE;
            unsigned int vqm_jstatus                    : mp1_Adma64Cmd_Status_Q0_VQM_JStatus_SIZE;
            unsigned int vqm_errorsource                : mp1_Adma64Cmd_Status_Q0_VQM_ErrorSource_SIZE;
            unsigned int                                : 19;
      } mp1_adma64cmd_status_q0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_status_q0_t {
            unsigned int                                : 19;
            unsigned int vqm_errorsource                : mp1_Adma64Cmd_Status_Q0_VQM_ErrorSource_SIZE;
            unsigned int vqm_jstatus                    : mp1_Adma64Cmd_Status_Q0_VQM_JStatus_SIZE;
            unsigned int vqm_errorprevious              : mp1_Adma64Cmd_Status_Q0_VQM_ErrorPrevious_SIZE;
            unsigned int vqm_error                      : mp1_Adma64Cmd_Status_Q0_VQM_Error_SIZE;
      } mp1_adma64cmd_status_q0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_status_q0_t f;
} mp1_adma64cmd_status_q0_u;


/*
 * mp1_Adma64Cmd_Int_Status_Q0 struct
 */

#define mp1_Adma64Cmd_Int_Status_Q0_REG_SIZE         32
#define mp1_Adma64Cmd_Int_Status_Q0_IC_EventCnt_SIZE  7

#define mp1_Adma64Cmd_Int_Status_Q0_IC_EventCnt_SHIFT  0

#define mp1_Adma64Cmd_Int_Status_Q0_IC_EventCnt_MASK  0x0000007f

#define mp1_Adma64Cmd_Int_Status_Q0_MASK \
      (mp1_Adma64Cmd_Int_Status_Q0_IC_EventCnt_MASK)

#define mp1_Adma64Cmd_Int_Status_Q0_DEFAULT 0x00000000

#define mp1_Adma64Cmd_Int_Status_Q0_GET_IC_EventCnt(mp1_adma64cmd_int_status_q0) \
      ((mp1_adma64cmd_int_status_q0 & mp1_Adma64Cmd_Int_Status_Q0_IC_EventCnt_MASK) >> mp1_Adma64Cmd_Int_Status_Q0_IC_EventCnt_SHIFT)

#define mp1_Adma64Cmd_Int_Status_Q0_SET_IC_EventCnt(mp1_adma64cmd_int_status_q0_reg, ic_eventcnt) \
      mp1_adma64cmd_int_status_q0_reg = (mp1_adma64cmd_int_status_q0_reg & ~mp1_Adma64Cmd_Int_Status_Q0_IC_EventCnt_MASK) | (ic_eventcnt << mp1_Adma64Cmd_Int_Status_Q0_IC_EventCnt_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_int_status_q0_t {
            unsigned int ic_eventcnt                    : mp1_Adma64Cmd_Int_Status_Q0_IC_EventCnt_SIZE;
            unsigned int                                : 25;
      } mp1_adma64cmd_int_status_q0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_int_status_q0_t {
            unsigned int                                : 25;
            unsigned int ic_eventcnt                    : mp1_Adma64Cmd_Int_Status_Q0_IC_EventCnt_SIZE;
      } mp1_adma64cmd_int_status_q0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_int_status_q0_t f;
} mp1_adma64cmd_int_status_q0_u;


/*
 * mp1_Adma64Cmd_DMA_Status_Q0 struct
 */

#define mp1_Adma64Cmd_DMA_Status_Q0_REG_SIZE         32
#define mp1_Adma64Cmd_DMA_Status_Q0_DMA_Pwrites_SIZE  10
#define mp1_Adma64Cmd_DMA_Status_Q0_DMA_Preads_SIZE  6
#define mp1_Adma64Cmd_DMA_Status_Q0_DMA_Dstatus_SIZE  3

#define mp1_Adma64Cmd_DMA_Status_Q0_DMA_Pwrites_SHIFT  0
#define mp1_Adma64Cmd_DMA_Status_Q0_DMA_Preads_SHIFT  10
#define mp1_Adma64Cmd_DMA_Status_Q0_DMA_Dstatus_SHIFT  16

#define mp1_Adma64Cmd_DMA_Status_Q0_DMA_Pwrites_MASK  0x000003ff
#define mp1_Adma64Cmd_DMA_Status_Q0_DMA_Preads_MASK  0x0000fc00
#define mp1_Adma64Cmd_DMA_Status_Q0_DMA_Dstatus_MASK  0x00070000

#define mp1_Adma64Cmd_DMA_Status_Q0_MASK \
      (mp1_Adma64Cmd_DMA_Status_Q0_DMA_Pwrites_MASK | \
      mp1_Adma64Cmd_DMA_Status_Q0_DMA_Preads_MASK | \
      mp1_Adma64Cmd_DMA_Status_Q0_DMA_Dstatus_MASK)

#define mp1_Adma64Cmd_DMA_Status_Q0_DEFAULT 0x00000000

#define mp1_Adma64Cmd_DMA_Status_Q0_GET_DMA_Pwrites(mp1_adma64cmd_dma_status_q0) \
      ((mp1_adma64cmd_dma_status_q0 & mp1_Adma64Cmd_DMA_Status_Q0_DMA_Pwrites_MASK) >> mp1_Adma64Cmd_DMA_Status_Q0_DMA_Pwrites_SHIFT)
#define mp1_Adma64Cmd_DMA_Status_Q0_GET_DMA_Preads(mp1_adma64cmd_dma_status_q0) \
      ((mp1_adma64cmd_dma_status_q0 & mp1_Adma64Cmd_DMA_Status_Q0_DMA_Preads_MASK) >> mp1_Adma64Cmd_DMA_Status_Q0_DMA_Preads_SHIFT)
#define mp1_Adma64Cmd_DMA_Status_Q0_GET_DMA_Dstatus(mp1_adma64cmd_dma_status_q0) \
      ((mp1_adma64cmd_dma_status_q0 & mp1_Adma64Cmd_DMA_Status_Q0_DMA_Dstatus_MASK) >> mp1_Adma64Cmd_DMA_Status_Q0_DMA_Dstatus_SHIFT)

#define mp1_Adma64Cmd_DMA_Status_Q0_SET_DMA_Pwrites(mp1_adma64cmd_dma_status_q0_reg, dma_pwrites) \
      mp1_adma64cmd_dma_status_q0_reg = (mp1_adma64cmd_dma_status_q0_reg & ~mp1_Adma64Cmd_DMA_Status_Q0_DMA_Pwrites_MASK) | (dma_pwrites << mp1_Adma64Cmd_DMA_Status_Q0_DMA_Pwrites_SHIFT)
#define mp1_Adma64Cmd_DMA_Status_Q0_SET_DMA_Preads(mp1_adma64cmd_dma_status_q0_reg, dma_preads) \
      mp1_adma64cmd_dma_status_q0_reg = (mp1_adma64cmd_dma_status_q0_reg & ~mp1_Adma64Cmd_DMA_Status_Q0_DMA_Preads_MASK) | (dma_preads << mp1_Adma64Cmd_DMA_Status_Q0_DMA_Preads_SHIFT)
#define mp1_Adma64Cmd_DMA_Status_Q0_SET_DMA_Dstatus(mp1_adma64cmd_dma_status_q0_reg, dma_dstatus) \
      mp1_adma64cmd_dma_status_q0_reg = (mp1_adma64cmd_dma_status_q0_reg & ~mp1_Adma64Cmd_DMA_Status_Q0_DMA_Dstatus_MASK) | (dma_dstatus << mp1_Adma64Cmd_DMA_Status_Q0_DMA_Dstatus_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_dma_status_q0_t {
            unsigned int dma_pwrites                    : mp1_Adma64Cmd_DMA_Status_Q0_DMA_Pwrites_SIZE;
            unsigned int dma_preads                     : mp1_Adma64Cmd_DMA_Status_Q0_DMA_Preads_SIZE;
            unsigned int dma_dstatus                    : mp1_Adma64Cmd_DMA_Status_Q0_DMA_Dstatus_SIZE;
            unsigned int                                : 13;
      } mp1_adma64cmd_dma_status_q0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_dma_status_q0_t {
            unsigned int                                : 13;
            unsigned int dma_dstatus                    : mp1_Adma64Cmd_DMA_Status_Q0_DMA_Dstatus_SIZE;
            unsigned int dma_preads                     : mp1_Adma64Cmd_DMA_Status_Q0_DMA_Preads_SIZE;
            unsigned int dma_pwrites                    : mp1_Adma64Cmd_DMA_Status_Q0_DMA_Pwrites_SIZE;
      } mp1_adma64cmd_dma_status_q0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_dma_status_q0_t f;
} mp1_adma64cmd_dma_status_q0_u;


/*
 * mp1_Adma64Cmd_DMA_Read_Status_Q0 struct
 */

#define mp1_Adma64Cmd_DMA_Read_Status_Q0_REG_SIZE         32
#define mp1_Adma64Cmd_DMA_Read_Status_Q0_DMA_BytesRead_SIZE  32

#define mp1_Adma64Cmd_DMA_Read_Status_Q0_DMA_BytesRead_SHIFT  0

#define mp1_Adma64Cmd_DMA_Read_Status_Q0_DMA_BytesRead_MASK  0xffffffff

#define mp1_Adma64Cmd_DMA_Read_Status_Q0_MASK \
      (mp1_Adma64Cmd_DMA_Read_Status_Q0_DMA_BytesRead_MASK)

#define mp1_Adma64Cmd_DMA_Read_Status_Q0_DEFAULT 0x00000000

#define mp1_Adma64Cmd_DMA_Read_Status_Q0_GET_DMA_BytesRead(mp1_adma64cmd_dma_read_status_q0) \
      ((mp1_adma64cmd_dma_read_status_q0 & mp1_Adma64Cmd_DMA_Read_Status_Q0_DMA_BytesRead_MASK) >> mp1_Adma64Cmd_DMA_Read_Status_Q0_DMA_BytesRead_SHIFT)

#define mp1_Adma64Cmd_DMA_Read_Status_Q0_SET_DMA_BytesRead(mp1_adma64cmd_dma_read_status_q0_reg, dma_bytesread) \
      mp1_adma64cmd_dma_read_status_q0_reg = (mp1_adma64cmd_dma_read_status_q0_reg & ~mp1_Adma64Cmd_DMA_Read_Status_Q0_DMA_BytesRead_MASK) | (dma_bytesread << mp1_Adma64Cmd_DMA_Read_Status_Q0_DMA_BytesRead_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_dma_read_status_q0_t {
            unsigned int dma_bytesread                  : mp1_Adma64Cmd_DMA_Read_Status_Q0_DMA_BytesRead_SIZE;
      } mp1_adma64cmd_dma_read_status_q0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_dma_read_status_q0_t {
            unsigned int dma_bytesread                  : mp1_Adma64Cmd_DMA_Read_Status_Q0_DMA_BytesRead_SIZE;
      } mp1_adma64cmd_dma_read_status_q0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_dma_read_status_q0_t f;
} mp1_adma64cmd_dma_read_status_q0_u;


/*
 * mp1_Adma64Cmd_DMA_Write_Status_Q0 struct
 */

#define mp1_Adma64Cmd_DMA_Write_Status_Q0_REG_SIZE         32
#define mp1_Adma64Cmd_DMA_Write_Status_Q0_DMA_BytesWritten_SIZE  32

#define mp1_Adma64Cmd_DMA_Write_Status_Q0_DMA_BytesWritten_SHIFT  0

#define mp1_Adma64Cmd_DMA_Write_Status_Q0_DMA_BytesWritten_MASK  0xffffffff

#define mp1_Adma64Cmd_DMA_Write_Status_Q0_MASK \
      (mp1_Adma64Cmd_DMA_Write_Status_Q0_DMA_BytesWritten_MASK)

#define mp1_Adma64Cmd_DMA_Write_Status_Q0_DEFAULT 0x00000000

#define mp1_Adma64Cmd_DMA_Write_Status_Q0_GET_DMA_BytesWritten(mp1_adma64cmd_dma_write_status_q0) \
      ((mp1_adma64cmd_dma_write_status_q0 & mp1_Adma64Cmd_DMA_Write_Status_Q0_DMA_BytesWritten_MASK) >> mp1_Adma64Cmd_DMA_Write_Status_Q0_DMA_BytesWritten_SHIFT)

#define mp1_Adma64Cmd_DMA_Write_Status_Q0_SET_DMA_BytesWritten(mp1_adma64cmd_dma_write_status_q0_reg, dma_byteswritten) \
      mp1_adma64cmd_dma_write_status_q0_reg = (mp1_adma64cmd_dma_write_status_q0_reg & ~mp1_Adma64Cmd_DMA_Write_Status_Q0_DMA_BytesWritten_MASK) | (dma_byteswritten << mp1_Adma64Cmd_DMA_Write_Status_Q0_DMA_BytesWritten_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_dma_write_status_q0_t {
            unsigned int dma_byteswritten               : mp1_Adma64Cmd_DMA_Write_Status_Q0_DMA_BytesWritten_SIZE;
      } mp1_adma64cmd_dma_write_status_q0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_dma_write_status_q0_t {
            unsigned int dma_byteswritten               : mp1_Adma64Cmd_DMA_Write_Status_Q0_DMA_BytesWritten_SIZE;
      } mp1_adma64cmd_dma_write_status_q0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_dma_write_status_q0_t f;
} mp1_adma64cmd_dma_write_status_q0_u;


/*
 * mp1_Adma64Cmd_Abort_Q0 struct
 */

#define mp1_Adma64Cmd_Abort_Q0_REG_SIZE         32
#define mp1_Adma64Cmd_Abort_Q0_RI_Offset_SIZE  18
#define mp1_Adma64Cmd_Abort_Q0_RI_Offset_Valid_SIZE  1

#define mp1_Adma64Cmd_Abort_Q0_RI_Offset_SHIFT  0
#define mp1_Adma64Cmd_Abort_Q0_RI_Offset_Valid_SHIFT  31

#define mp1_Adma64Cmd_Abort_Q0_RI_Offset_MASK  0x0003ffff
#define mp1_Adma64Cmd_Abort_Q0_RI_Offset_Valid_MASK  0x80000000

#define mp1_Adma64Cmd_Abort_Q0_MASK \
      (mp1_Adma64Cmd_Abort_Q0_RI_Offset_MASK | \
      mp1_Adma64Cmd_Abort_Q0_RI_Offset_Valid_MASK)

#define mp1_Adma64Cmd_Abort_Q0_DEFAULT 0x00000000

#define mp1_Adma64Cmd_Abort_Q0_GET_RI_Offset(mp1_adma64cmd_abort_q0) \
      ((mp1_adma64cmd_abort_q0 & mp1_Adma64Cmd_Abort_Q0_RI_Offset_MASK) >> mp1_Adma64Cmd_Abort_Q0_RI_Offset_SHIFT)
#define mp1_Adma64Cmd_Abort_Q0_GET_RI_Offset_Valid(mp1_adma64cmd_abort_q0) \
      ((mp1_adma64cmd_abort_q0 & mp1_Adma64Cmd_Abort_Q0_RI_Offset_Valid_MASK) >> mp1_Adma64Cmd_Abort_Q0_RI_Offset_Valid_SHIFT)

#define mp1_Adma64Cmd_Abort_Q0_SET_RI_Offset(mp1_adma64cmd_abort_q0_reg, ri_offset) \
      mp1_adma64cmd_abort_q0_reg = (mp1_adma64cmd_abort_q0_reg & ~mp1_Adma64Cmd_Abort_Q0_RI_Offset_MASK) | (ri_offset << mp1_Adma64Cmd_Abort_Q0_RI_Offset_SHIFT)
#define mp1_Adma64Cmd_Abort_Q0_SET_RI_Offset_Valid(mp1_adma64cmd_abort_q0_reg, ri_offset_valid) \
      mp1_adma64cmd_abort_q0_reg = (mp1_adma64cmd_abort_q0_reg & ~mp1_Adma64Cmd_Abort_Q0_RI_Offset_Valid_MASK) | (ri_offset_valid << mp1_Adma64Cmd_Abort_Q0_RI_Offset_Valid_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_abort_q0_t {
            unsigned int ri_offset                      : mp1_Adma64Cmd_Abort_Q0_RI_Offset_SIZE;
            unsigned int                                : 13;
            unsigned int ri_offset_valid                : mp1_Adma64Cmd_Abort_Q0_RI_Offset_Valid_SIZE;
      } mp1_adma64cmd_abort_q0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_abort_q0_t {
            unsigned int ri_offset_valid                : mp1_Adma64Cmd_Abort_Q0_RI_Offset_Valid_SIZE;
            unsigned int                                : 13;
            unsigned int ri_offset                      : mp1_Adma64Cmd_Abort_Q0_RI_Offset_SIZE;
      } mp1_adma64cmd_abort_q0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_abort_q0_t f;
} mp1_adma64cmd_abort_q0_u;


/*
 * mp1_Adma64Cmd_AxCACHE_Q0 struct
 */

#define mp1_Adma64Cmd_AxCACHE_Q0_REG_SIZE         32
#define mp1_Adma64Cmd_AxCACHE_Q0_RI_AWCACHE_SIZE  4
#define mp1_Adma64Cmd_AxCACHE_Q0_RI_ARCACHE_SIZE  4
#define mp1_Adma64Cmd_AxCACHE_Q0_RI_VCD_ARCACHE_SIZE  4

#define mp1_Adma64Cmd_AxCACHE_Q0_RI_AWCACHE_SHIFT  0
#define mp1_Adma64Cmd_AxCACHE_Q0_RI_ARCACHE_SHIFT  4
#define mp1_Adma64Cmd_AxCACHE_Q0_RI_VCD_ARCACHE_SHIFT  8

#define mp1_Adma64Cmd_AxCACHE_Q0_RI_AWCACHE_MASK  0x0000000f
#define mp1_Adma64Cmd_AxCACHE_Q0_RI_ARCACHE_MASK  0x000000f0
#define mp1_Adma64Cmd_AxCACHE_Q0_RI_VCD_ARCACHE_MASK  0x00000f00

#define mp1_Adma64Cmd_AxCACHE_Q0_MASK \
      (mp1_Adma64Cmd_AxCACHE_Q0_RI_AWCACHE_MASK | \
      mp1_Adma64Cmd_AxCACHE_Q0_RI_ARCACHE_MASK | \
      mp1_Adma64Cmd_AxCACHE_Q0_RI_VCD_ARCACHE_MASK)

#define mp1_Adma64Cmd_AxCACHE_Q0_DEFAULT 0x00000000

#define mp1_Adma64Cmd_AxCACHE_Q0_GET_RI_AWCACHE(mp1_adma64cmd_axcache_q0) \
      ((mp1_adma64cmd_axcache_q0 & mp1_Adma64Cmd_AxCACHE_Q0_RI_AWCACHE_MASK) >> mp1_Adma64Cmd_AxCACHE_Q0_RI_AWCACHE_SHIFT)
#define mp1_Adma64Cmd_AxCACHE_Q0_GET_RI_ARCACHE(mp1_adma64cmd_axcache_q0) \
      ((mp1_adma64cmd_axcache_q0 & mp1_Adma64Cmd_AxCACHE_Q0_RI_ARCACHE_MASK) >> mp1_Adma64Cmd_AxCACHE_Q0_RI_ARCACHE_SHIFT)
#define mp1_Adma64Cmd_AxCACHE_Q0_GET_RI_VCD_ARCACHE(mp1_adma64cmd_axcache_q0) \
      ((mp1_adma64cmd_axcache_q0 & mp1_Adma64Cmd_AxCACHE_Q0_RI_VCD_ARCACHE_MASK) >> mp1_Adma64Cmd_AxCACHE_Q0_RI_VCD_ARCACHE_SHIFT)

#define mp1_Adma64Cmd_AxCACHE_Q0_SET_RI_AWCACHE(mp1_adma64cmd_axcache_q0_reg, ri_awcache) \
      mp1_adma64cmd_axcache_q0_reg = (mp1_adma64cmd_axcache_q0_reg & ~mp1_Adma64Cmd_AxCACHE_Q0_RI_AWCACHE_MASK) | (ri_awcache << mp1_Adma64Cmd_AxCACHE_Q0_RI_AWCACHE_SHIFT)
#define mp1_Adma64Cmd_AxCACHE_Q0_SET_RI_ARCACHE(mp1_adma64cmd_axcache_q0_reg, ri_arcache) \
      mp1_adma64cmd_axcache_q0_reg = (mp1_adma64cmd_axcache_q0_reg & ~mp1_Adma64Cmd_AxCACHE_Q0_RI_ARCACHE_MASK) | (ri_arcache << mp1_Adma64Cmd_AxCACHE_Q0_RI_ARCACHE_SHIFT)
#define mp1_Adma64Cmd_AxCACHE_Q0_SET_RI_VCD_ARCACHE(mp1_adma64cmd_axcache_q0_reg, ri_vcd_arcache) \
      mp1_adma64cmd_axcache_q0_reg = (mp1_adma64cmd_axcache_q0_reg & ~mp1_Adma64Cmd_AxCACHE_Q0_RI_VCD_ARCACHE_MASK) | (ri_vcd_arcache << mp1_Adma64Cmd_AxCACHE_Q0_RI_VCD_ARCACHE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_axcache_q0_t {
            unsigned int ri_awcache                     : mp1_Adma64Cmd_AxCACHE_Q0_RI_AWCACHE_SIZE;
            unsigned int ri_arcache                     : mp1_Adma64Cmd_AxCACHE_Q0_RI_ARCACHE_SIZE;
            unsigned int ri_vcd_arcache                 : mp1_Adma64Cmd_AxCACHE_Q0_RI_VCD_ARCACHE_SIZE;
            unsigned int                                : 20;
      } mp1_adma64cmd_axcache_q0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_axcache_q0_t {
            unsigned int                                : 20;
            unsigned int ri_vcd_arcache                 : mp1_Adma64Cmd_AxCACHE_Q0_RI_VCD_ARCACHE_SIZE;
            unsigned int ri_arcache                     : mp1_Adma64Cmd_AxCACHE_Q0_RI_ARCACHE_SIZE;
            unsigned int ri_awcache                     : mp1_Adma64Cmd_AxCACHE_Q0_RI_AWCACHE_SIZE;
      } mp1_adma64cmd_axcache_q0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_axcache_q0_t f;
} mp1_adma64cmd_axcache_q0_u;


/*
 * mp1_Adma64Vqd1_Control struct
 */

#define mp1_Adma64Vqd1_Control_REG_SIZE         32
#define mp1_Adma64Vqd1_Control_RI_Run_SIZE  1
#define mp1_Adma64Vqd1_Control_VQM_Halted_SIZE  1
#define mp1_Adma64Vqd1_Control_RI_Mem_Location_SIZE  1
#define mp1_Adma64Vqd1_Control_RI_Queue_Size_SIZE  4
#define mp1_Adma64Vqd1_Control_RI_COMP_DESC_SIZE  1
#define mp1_Adma64Vqd1_Control_RI_VQD_Pointer_Hi_SIZE  16

#define mp1_Adma64Vqd1_Control_RI_Run_SHIFT  0
#define mp1_Adma64Vqd1_Control_VQM_Halted_SHIFT  1
#define mp1_Adma64Vqd1_Control_RI_Mem_Location_SHIFT  2
#define mp1_Adma64Vqd1_Control_RI_Queue_Size_SHIFT  3
#define mp1_Adma64Vqd1_Control_RI_COMP_DESC_SHIFT  7
#define mp1_Adma64Vqd1_Control_RI_VQD_Pointer_Hi_SHIFT  16

#define mp1_Adma64Vqd1_Control_RI_Run_MASK  0x00000001
#define mp1_Adma64Vqd1_Control_VQM_Halted_MASK  0x00000002
#define mp1_Adma64Vqd1_Control_RI_Mem_Location_MASK  0x00000004
#define mp1_Adma64Vqd1_Control_RI_Queue_Size_MASK  0x00000078
#define mp1_Adma64Vqd1_Control_RI_COMP_DESC_MASK  0x00000080
#define mp1_Adma64Vqd1_Control_RI_VQD_Pointer_Hi_MASK  0xffff0000

#define mp1_Adma64Vqd1_Control_MASK \
      (mp1_Adma64Vqd1_Control_RI_Run_MASK | \
      mp1_Adma64Vqd1_Control_VQM_Halted_MASK | \
      mp1_Adma64Vqd1_Control_RI_Mem_Location_MASK | \
      mp1_Adma64Vqd1_Control_RI_Queue_Size_MASK | \
      mp1_Adma64Vqd1_Control_RI_COMP_DESC_MASK | \
      mp1_Adma64Vqd1_Control_RI_VQD_Pointer_Hi_MASK)

#define mp1_Adma64Vqd1_Control_DEFAULT 0x00000002

#define mp1_Adma64Vqd1_Control_GET_RI_Run(mp1_adma64vqd1_control) \
      ((mp1_adma64vqd1_control & mp1_Adma64Vqd1_Control_RI_Run_MASK) >> mp1_Adma64Vqd1_Control_RI_Run_SHIFT)
#define mp1_Adma64Vqd1_Control_GET_VQM_Halted(mp1_adma64vqd1_control) \
      ((mp1_adma64vqd1_control & mp1_Adma64Vqd1_Control_VQM_Halted_MASK) >> mp1_Adma64Vqd1_Control_VQM_Halted_SHIFT)
#define mp1_Adma64Vqd1_Control_GET_RI_Mem_Location(mp1_adma64vqd1_control) \
      ((mp1_adma64vqd1_control & mp1_Adma64Vqd1_Control_RI_Mem_Location_MASK) >> mp1_Adma64Vqd1_Control_RI_Mem_Location_SHIFT)
#define mp1_Adma64Vqd1_Control_GET_RI_Queue_Size(mp1_adma64vqd1_control) \
      ((mp1_adma64vqd1_control & mp1_Adma64Vqd1_Control_RI_Queue_Size_MASK) >> mp1_Adma64Vqd1_Control_RI_Queue_Size_SHIFT)
#define mp1_Adma64Vqd1_Control_GET_RI_COMP_DESC(mp1_adma64vqd1_control) \
      ((mp1_adma64vqd1_control & mp1_Adma64Vqd1_Control_RI_COMP_DESC_MASK) >> mp1_Adma64Vqd1_Control_RI_COMP_DESC_SHIFT)
#define mp1_Adma64Vqd1_Control_GET_RI_VQD_Pointer_Hi(mp1_adma64vqd1_control) \
      ((mp1_adma64vqd1_control & mp1_Adma64Vqd1_Control_RI_VQD_Pointer_Hi_MASK) >> mp1_Adma64Vqd1_Control_RI_VQD_Pointer_Hi_SHIFT)

#define mp1_Adma64Vqd1_Control_SET_RI_Run(mp1_adma64vqd1_control_reg, ri_run) \
      mp1_adma64vqd1_control_reg = (mp1_adma64vqd1_control_reg & ~mp1_Adma64Vqd1_Control_RI_Run_MASK) | (ri_run << mp1_Adma64Vqd1_Control_RI_Run_SHIFT)
#define mp1_Adma64Vqd1_Control_SET_VQM_Halted(mp1_adma64vqd1_control_reg, vqm_halted) \
      mp1_adma64vqd1_control_reg = (mp1_adma64vqd1_control_reg & ~mp1_Adma64Vqd1_Control_VQM_Halted_MASK) | (vqm_halted << mp1_Adma64Vqd1_Control_VQM_Halted_SHIFT)
#define mp1_Adma64Vqd1_Control_SET_RI_Mem_Location(mp1_adma64vqd1_control_reg, ri_mem_location) \
      mp1_adma64vqd1_control_reg = (mp1_adma64vqd1_control_reg & ~mp1_Adma64Vqd1_Control_RI_Mem_Location_MASK) | (ri_mem_location << mp1_Adma64Vqd1_Control_RI_Mem_Location_SHIFT)
#define mp1_Adma64Vqd1_Control_SET_RI_Queue_Size(mp1_adma64vqd1_control_reg, ri_queue_size) \
      mp1_adma64vqd1_control_reg = (mp1_adma64vqd1_control_reg & ~mp1_Adma64Vqd1_Control_RI_Queue_Size_MASK) | (ri_queue_size << mp1_Adma64Vqd1_Control_RI_Queue_Size_SHIFT)
#define mp1_Adma64Vqd1_Control_SET_RI_COMP_DESC(mp1_adma64vqd1_control_reg, ri_comp_desc) \
      mp1_adma64vqd1_control_reg = (mp1_adma64vqd1_control_reg & ~mp1_Adma64Vqd1_Control_RI_COMP_DESC_MASK) | (ri_comp_desc << mp1_Adma64Vqd1_Control_RI_COMP_DESC_SHIFT)
#define mp1_Adma64Vqd1_Control_SET_RI_VQD_Pointer_Hi(mp1_adma64vqd1_control_reg, ri_vqd_pointer_hi) \
      mp1_adma64vqd1_control_reg = (mp1_adma64vqd1_control_reg & ~mp1_Adma64Vqd1_Control_RI_VQD_Pointer_Hi_MASK) | (ri_vqd_pointer_hi << mp1_Adma64Vqd1_Control_RI_VQD_Pointer_Hi_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64vqd1_control_t {
            unsigned int ri_run                         : mp1_Adma64Vqd1_Control_RI_Run_SIZE;
            unsigned int vqm_halted                     : mp1_Adma64Vqd1_Control_VQM_Halted_SIZE;
            unsigned int ri_mem_location                : mp1_Adma64Vqd1_Control_RI_Mem_Location_SIZE;
            unsigned int ri_queue_size                  : mp1_Adma64Vqd1_Control_RI_Queue_Size_SIZE;
            unsigned int ri_comp_desc                   : mp1_Adma64Vqd1_Control_RI_COMP_DESC_SIZE;
            unsigned int                                : 8;
            unsigned int ri_vqd_pointer_hi              : mp1_Adma64Vqd1_Control_RI_VQD_Pointer_Hi_SIZE;
      } mp1_adma64vqd1_control_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64vqd1_control_t {
            unsigned int ri_vqd_pointer_hi              : mp1_Adma64Vqd1_Control_RI_VQD_Pointer_Hi_SIZE;
            unsigned int                                : 8;
            unsigned int ri_comp_desc                   : mp1_Adma64Vqd1_Control_RI_COMP_DESC_SIZE;
            unsigned int ri_queue_size                  : mp1_Adma64Vqd1_Control_RI_Queue_Size_SIZE;
            unsigned int ri_mem_location                : mp1_Adma64Vqd1_Control_RI_Mem_Location_SIZE;
            unsigned int vqm_halted                     : mp1_Adma64Vqd1_Control_VQM_Halted_SIZE;
            unsigned int ri_run                         : mp1_Adma64Vqd1_Control_RI_Run_SIZE;
      } mp1_adma64vqd1_control_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64vqd1_control_t f;
} mp1_adma64vqd1_control_u;


/*
 * mp1_Adma64Vqd1_Tail_Lo struct
 */

#define mp1_Adma64Vqd1_Tail_Lo_REG_SIZE         32
#define mp1_Adma64Vqd1_Tail_Lo_RI_Tail_Pointer_Lo_SIZE  32

#define mp1_Adma64Vqd1_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT  0

#define mp1_Adma64Vqd1_Tail_Lo_RI_Tail_Pointer_Lo_MASK  0xffffffff

#define mp1_Adma64Vqd1_Tail_Lo_MASK \
      (mp1_Adma64Vqd1_Tail_Lo_RI_Tail_Pointer_Lo_MASK)

#define mp1_Adma64Vqd1_Tail_Lo_DEFAULT 0x00000000

#define mp1_Adma64Vqd1_Tail_Lo_GET_RI_Tail_Pointer_Lo(mp1_adma64vqd1_tail_lo) \
      ((mp1_adma64vqd1_tail_lo & mp1_Adma64Vqd1_Tail_Lo_RI_Tail_Pointer_Lo_MASK) >> mp1_Adma64Vqd1_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT)

#define mp1_Adma64Vqd1_Tail_Lo_SET_RI_Tail_Pointer_Lo(mp1_adma64vqd1_tail_lo_reg, ri_tail_pointer_lo) \
      mp1_adma64vqd1_tail_lo_reg = (mp1_adma64vqd1_tail_lo_reg & ~mp1_Adma64Vqd1_Tail_Lo_RI_Tail_Pointer_Lo_MASK) | (ri_tail_pointer_lo << mp1_Adma64Vqd1_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64vqd1_tail_lo_t {
            unsigned int ri_tail_pointer_lo             : mp1_Adma64Vqd1_Tail_Lo_RI_Tail_Pointer_Lo_SIZE;
      } mp1_adma64vqd1_tail_lo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64vqd1_tail_lo_t {
            unsigned int ri_tail_pointer_lo             : mp1_Adma64Vqd1_Tail_Lo_RI_Tail_Pointer_Lo_SIZE;
      } mp1_adma64vqd1_tail_lo_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64vqd1_tail_lo_t f;
} mp1_adma64vqd1_tail_lo_u;


/*
 * mp1_Adma64Vqd1_Head_Lo struct
 */

#define mp1_Adma64Vqd1_Head_Lo_REG_SIZE         32
#define mp1_Adma64Vqd1_Head_Lo_RI_Head_Pointer_Lo_SIZE  32

#define mp1_Adma64Vqd1_Head_Lo_RI_Head_Pointer_Lo_SHIFT  0

#define mp1_Adma64Vqd1_Head_Lo_RI_Head_Pointer_Lo_MASK  0xffffffff

#define mp1_Adma64Vqd1_Head_Lo_MASK \
      (mp1_Adma64Vqd1_Head_Lo_RI_Head_Pointer_Lo_MASK)

#define mp1_Adma64Vqd1_Head_Lo_DEFAULT 0x00000000

#define mp1_Adma64Vqd1_Head_Lo_GET_RI_Head_Pointer_Lo(mp1_adma64vqd1_head_lo) \
      ((mp1_adma64vqd1_head_lo & mp1_Adma64Vqd1_Head_Lo_RI_Head_Pointer_Lo_MASK) >> mp1_Adma64Vqd1_Head_Lo_RI_Head_Pointer_Lo_SHIFT)

#define mp1_Adma64Vqd1_Head_Lo_SET_RI_Head_Pointer_Lo(mp1_adma64vqd1_head_lo_reg, ri_head_pointer_lo) \
      mp1_adma64vqd1_head_lo_reg = (mp1_adma64vqd1_head_lo_reg & ~mp1_Adma64Vqd1_Head_Lo_RI_Head_Pointer_Lo_MASK) | (ri_head_pointer_lo << mp1_Adma64Vqd1_Head_Lo_RI_Head_Pointer_Lo_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64vqd1_head_lo_t {
            unsigned int ri_head_pointer_lo             : mp1_Adma64Vqd1_Head_Lo_RI_Head_Pointer_Lo_SIZE;
      } mp1_adma64vqd1_head_lo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64vqd1_head_lo_t {
            unsigned int ri_head_pointer_lo             : mp1_Adma64Vqd1_Head_Lo_RI_Head_Pointer_Lo_SIZE;
      } mp1_adma64vqd1_head_lo_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64vqd1_head_lo_t f;
} mp1_adma64vqd1_head_lo_u;


/*
 * mp1_Adma64Cmd_Interrupt_Enable_Q1 struct
 */

#define mp1_Adma64Cmd_Interrupt_Enable_Q1_REG_SIZE         32
#define mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_CompInt_Enable_SIZE  1
#define mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_SIZE  1
#define mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_QSI_Enable_SIZE  1
#define mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_QEI_Enable_SIZE  1

#define mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_CompInt_Enable_SHIFT  0
#define mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_SHIFT  1
#define mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_QSI_Enable_SHIFT  2
#define mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_QEI_Enable_SHIFT  3

#define mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_CompInt_Enable_MASK  0x00000001
#define mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_MASK  0x00000002
#define mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_QSI_Enable_MASK  0x00000004
#define mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_QEI_Enable_MASK  0x00000008

#define mp1_Adma64Cmd_Interrupt_Enable_Q1_MASK \
      (mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_CompInt_Enable_MASK | \
      mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_MASK | \
      mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_QSI_Enable_MASK | \
      mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_QEI_Enable_MASK)

#define mp1_Adma64Cmd_Interrupt_Enable_Q1_DEFAULT 0x00000000

#define mp1_Adma64Cmd_Interrupt_Enable_Q1_GET_RI_CompInt_Enable(mp1_adma64cmd_interrupt_enable_q1) \
      ((mp1_adma64cmd_interrupt_enable_q1 & mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_CompInt_Enable_MASK) >> mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_CompInt_Enable_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Enable_Q1_GET_RI_ErrInt_Enable(mp1_adma64cmd_interrupt_enable_q1) \
      ((mp1_adma64cmd_interrupt_enable_q1 & mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_MASK) >> mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Enable_Q1_GET_RI_QSI_Enable(mp1_adma64cmd_interrupt_enable_q1) \
      ((mp1_adma64cmd_interrupt_enable_q1 & mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_QSI_Enable_MASK) >> mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_QSI_Enable_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Enable_Q1_GET_RI_QEI_Enable(mp1_adma64cmd_interrupt_enable_q1) \
      ((mp1_adma64cmd_interrupt_enable_q1 & mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_QEI_Enable_MASK) >> mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_QEI_Enable_SHIFT)

#define mp1_Adma64Cmd_Interrupt_Enable_Q1_SET_RI_CompInt_Enable(mp1_adma64cmd_interrupt_enable_q1_reg, ri_compint_enable) \
      mp1_adma64cmd_interrupt_enable_q1_reg = (mp1_adma64cmd_interrupt_enable_q1_reg & ~mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_CompInt_Enable_MASK) | (ri_compint_enable << mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_CompInt_Enable_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Enable_Q1_SET_RI_ErrInt_Enable(mp1_adma64cmd_interrupt_enable_q1_reg, ri_errint_enable) \
      mp1_adma64cmd_interrupt_enable_q1_reg = (mp1_adma64cmd_interrupt_enable_q1_reg & ~mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_MASK) | (ri_errint_enable << mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Enable_Q1_SET_RI_QSI_Enable(mp1_adma64cmd_interrupt_enable_q1_reg, ri_qsi_enable) \
      mp1_adma64cmd_interrupt_enable_q1_reg = (mp1_adma64cmd_interrupt_enable_q1_reg & ~mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_QSI_Enable_MASK) | (ri_qsi_enable << mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_QSI_Enable_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Enable_Q1_SET_RI_QEI_Enable(mp1_adma64cmd_interrupt_enable_q1_reg, ri_qei_enable) \
      mp1_adma64cmd_interrupt_enable_q1_reg = (mp1_adma64cmd_interrupt_enable_q1_reg & ~mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_QEI_Enable_MASK) | (ri_qei_enable << mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_QEI_Enable_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_interrupt_enable_q1_t {
            unsigned int ri_compint_enable              : mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_CompInt_Enable_SIZE;
            unsigned int ri_errint_enable               : mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_SIZE;
            unsigned int ri_qsi_enable                  : mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_QSI_Enable_SIZE;
            unsigned int ri_qei_enable                  : mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_QEI_Enable_SIZE;
            unsigned int                                : 28;
      } mp1_adma64cmd_interrupt_enable_q1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_interrupt_enable_q1_t {
            unsigned int                                : 28;
            unsigned int ri_qei_enable                  : mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_QEI_Enable_SIZE;
            unsigned int ri_qsi_enable                  : mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_QSI_Enable_SIZE;
            unsigned int ri_errint_enable               : mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_SIZE;
            unsigned int ri_compint_enable              : mp1_Adma64Cmd_Interrupt_Enable_Q1_RI_CompInt_Enable_SIZE;
      } mp1_adma64cmd_interrupt_enable_q1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_interrupt_enable_q1_t f;
} mp1_adma64cmd_interrupt_enable_q1_u;


/*
 * mp1_Adma64Cmd_Interrupt_Status_Q1 struct
 */

#define mp1_Adma64Cmd_Interrupt_Status_Q1_REG_SIZE         32
#define mp1_Adma64Cmd_Interrupt_Status_Q1_RI_CompInt_Valid_SIZE  1
#define mp1_Adma64Cmd_Interrupt_Status_Q1_RI_ErrInt_Valid_SIZE  1
#define mp1_Adma64Cmd_Interrupt_Status_Q1_RI_QSI_Valid_SIZE  1
#define mp1_Adma64Cmd_Interrupt_Status_Q1_RI_QEI_Valid_SIZE  1

#define mp1_Adma64Cmd_Interrupt_Status_Q1_RI_CompInt_Valid_SHIFT  0
#define mp1_Adma64Cmd_Interrupt_Status_Q1_RI_ErrInt_Valid_SHIFT  1
#define mp1_Adma64Cmd_Interrupt_Status_Q1_RI_QSI_Valid_SHIFT  2
#define mp1_Adma64Cmd_Interrupt_Status_Q1_RI_QEI_Valid_SHIFT  3

#define mp1_Adma64Cmd_Interrupt_Status_Q1_RI_CompInt_Valid_MASK  0x00000001
#define mp1_Adma64Cmd_Interrupt_Status_Q1_RI_ErrInt_Valid_MASK  0x00000002
#define mp1_Adma64Cmd_Interrupt_Status_Q1_RI_QSI_Valid_MASK  0x00000004
#define mp1_Adma64Cmd_Interrupt_Status_Q1_RI_QEI_Valid_MASK  0x00000008

#define mp1_Adma64Cmd_Interrupt_Status_Q1_MASK \
      (mp1_Adma64Cmd_Interrupt_Status_Q1_RI_CompInt_Valid_MASK | \
      mp1_Adma64Cmd_Interrupt_Status_Q1_RI_ErrInt_Valid_MASK | \
      mp1_Adma64Cmd_Interrupt_Status_Q1_RI_QSI_Valid_MASK | \
      mp1_Adma64Cmd_Interrupt_Status_Q1_RI_QEI_Valid_MASK)

#define mp1_Adma64Cmd_Interrupt_Status_Q1_DEFAULT 0x00000000

#define mp1_Adma64Cmd_Interrupt_Status_Q1_GET_RI_CompInt_Valid(mp1_adma64cmd_interrupt_status_q1) \
      ((mp1_adma64cmd_interrupt_status_q1 & mp1_Adma64Cmd_Interrupt_Status_Q1_RI_CompInt_Valid_MASK) >> mp1_Adma64Cmd_Interrupt_Status_Q1_RI_CompInt_Valid_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Status_Q1_GET_RI_ErrInt_Valid(mp1_adma64cmd_interrupt_status_q1) \
      ((mp1_adma64cmd_interrupt_status_q1 & mp1_Adma64Cmd_Interrupt_Status_Q1_RI_ErrInt_Valid_MASK) >> mp1_Adma64Cmd_Interrupt_Status_Q1_RI_ErrInt_Valid_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Status_Q1_GET_RI_QSI_Valid(mp1_adma64cmd_interrupt_status_q1) \
      ((mp1_adma64cmd_interrupt_status_q1 & mp1_Adma64Cmd_Interrupt_Status_Q1_RI_QSI_Valid_MASK) >> mp1_Adma64Cmd_Interrupt_Status_Q1_RI_QSI_Valid_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Status_Q1_GET_RI_QEI_Valid(mp1_adma64cmd_interrupt_status_q1) \
      ((mp1_adma64cmd_interrupt_status_q1 & mp1_Adma64Cmd_Interrupt_Status_Q1_RI_QEI_Valid_MASK) >> mp1_Adma64Cmd_Interrupt_Status_Q1_RI_QEI_Valid_SHIFT)

#define mp1_Adma64Cmd_Interrupt_Status_Q1_SET_RI_CompInt_Valid(mp1_adma64cmd_interrupt_status_q1_reg, ri_compint_valid) \
      mp1_adma64cmd_interrupt_status_q1_reg = (mp1_adma64cmd_interrupt_status_q1_reg & ~mp1_Adma64Cmd_Interrupt_Status_Q1_RI_CompInt_Valid_MASK) | (ri_compint_valid << mp1_Adma64Cmd_Interrupt_Status_Q1_RI_CompInt_Valid_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Status_Q1_SET_RI_ErrInt_Valid(mp1_adma64cmd_interrupt_status_q1_reg, ri_errint_valid) \
      mp1_adma64cmd_interrupt_status_q1_reg = (mp1_adma64cmd_interrupt_status_q1_reg & ~mp1_Adma64Cmd_Interrupt_Status_Q1_RI_ErrInt_Valid_MASK) | (ri_errint_valid << mp1_Adma64Cmd_Interrupt_Status_Q1_RI_ErrInt_Valid_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Status_Q1_SET_RI_QSI_Valid(mp1_adma64cmd_interrupt_status_q1_reg, ri_qsi_valid) \
      mp1_adma64cmd_interrupt_status_q1_reg = (mp1_adma64cmd_interrupt_status_q1_reg & ~mp1_Adma64Cmd_Interrupt_Status_Q1_RI_QSI_Valid_MASK) | (ri_qsi_valid << mp1_Adma64Cmd_Interrupt_Status_Q1_RI_QSI_Valid_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Status_Q1_SET_RI_QEI_Valid(mp1_adma64cmd_interrupt_status_q1_reg, ri_qei_valid) \
      mp1_adma64cmd_interrupt_status_q1_reg = (mp1_adma64cmd_interrupt_status_q1_reg & ~mp1_Adma64Cmd_Interrupt_Status_Q1_RI_QEI_Valid_MASK) | (ri_qei_valid << mp1_Adma64Cmd_Interrupt_Status_Q1_RI_QEI_Valid_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_interrupt_status_q1_t {
            unsigned int ri_compint_valid               : mp1_Adma64Cmd_Interrupt_Status_Q1_RI_CompInt_Valid_SIZE;
            unsigned int ri_errint_valid                : mp1_Adma64Cmd_Interrupt_Status_Q1_RI_ErrInt_Valid_SIZE;
            unsigned int ri_qsi_valid                   : mp1_Adma64Cmd_Interrupt_Status_Q1_RI_QSI_Valid_SIZE;
            unsigned int ri_qei_valid                   : mp1_Adma64Cmd_Interrupt_Status_Q1_RI_QEI_Valid_SIZE;
            unsigned int                                : 28;
      } mp1_adma64cmd_interrupt_status_q1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_interrupt_status_q1_t {
            unsigned int                                : 28;
            unsigned int ri_qei_valid                   : mp1_Adma64Cmd_Interrupt_Status_Q1_RI_QEI_Valid_SIZE;
            unsigned int ri_qsi_valid                   : mp1_Adma64Cmd_Interrupt_Status_Q1_RI_QSI_Valid_SIZE;
            unsigned int ri_errint_valid                : mp1_Adma64Cmd_Interrupt_Status_Q1_RI_ErrInt_Valid_SIZE;
            unsigned int ri_compint_valid               : mp1_Adma64Cmd_Interrupt_Status_Q1_RI_CompInt_Valid_SIZE;
      } mp1_adma64cmd_interrupt_status_q1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_interrupt_status_q1_t f;
} mp1_adma64cmd_interrupt_status_q1_u;


/*
 * mp1_Adma64Cmd_Status_Q1 struct
 */

#define mp1_Adma64Cmd_Status_Q1_REG_SIZE         32
#define mp1_Adma64Cmd_Status_Q1_VQM_Error_SIZE  6
#define mp1_Adma64Cmd_Status_Q1_VQM_ErrorPrevious_SIZE  1
#define mp1_Adma64Cmd_Status_Q1_VQM_JStatus_SIZE  3
#define mp1_Adma64Cmd_Status_Q1_VQM_ErrorSource_SIZE  3

#define mp1_Adma64Cmd_Status_Q1_VQM_Error_SHIFT  0
#define mp1_Adma64Cmd_Status_Q1_VQM_ErrorPrevious_SHIFT  6
#define mp1_Adma64Cmd_Status_Q1_VQM_JStatus_SHIFT  7
#define mp1_Adma64Cmd_Status_Q1_VQM_ErrorSource_SHIFT  10

#define mp1_Adma64Cmd_Status_Q1_VQM_Error_MASK  0x0000003f
#define mp1_Adma64Cmd_Status_Q1_VQM_ErrorPrevious_MASK  0x00000040
#define mp1_Adma64Cmd_Status_Q1_VQM_JStatus_MASK  0x00000380
#define mp1_Adma64Cmd_Status_Q1_VQM_ErrorSource_MASK  0x00001c00

#define mp1_Adma64Cmd_Status_Q1_MASK \
      (mp1_Adma64Cmd_Status_Q1_VQM_Error_MASK | \
      mp1_Adma64Cmd_Status_Q1_VQM_ErrorPrevious_MASK | \
      mp1_Adma64Cmd_Status_Q1_VQM_JStatus_MASK | \
      mp1_Adma64Cmd_Status_Q1_VQM_ErrorSource_MASK)

#define mp1_Adma64Cmd_Status_Q1_DEFAULT 0x00000000

#define mp1_Adma64Cmd_Status_Q1_GET_VQM_Error(mp1_adma64cmd_status_q1) \
      ((mp1_adma64cmd_status_q1 & mp1_Adma64Cmd_Status_Q1_VQM_Error_MASK) >> mp1_Adma64Cmd_Status_Q1_VQM_Error_SHIFT)
#define mp1_Adma64Cmd_Status_Q1_GET_VQM_ErrorPrevious(mp1_adma64cmd_status_q1) \
      ((mp1_adma64cmd_status_q1 & mp1_Adma64Cmd_Status_Q1_VQM_ErrorPrevious_MASK) >> mp1_Adma64Cmd_Status_Q1_VQM_ErrorPrevious_SHIFT)
#define mp1_Adma64Cmd_Status_Q1_GET_VQM_JStatus(mp1_adma64cmd_status_q1) \
      ((mp1_adma64cmd_status_q1 & mp1_Adma64Cmd_Status_Q1_VQM_JStatus_MASK) >> mp1_Adma64Cmd_Status_Q1_VQM_JStatus_SHIFT)
#define mp1_Adma64Cmd_Status_Q1_GET_VQM_ErrorSource(mp1_adma64cmd_status_q1) \
      ((mp1_adma64cmd_status_q1 & mp1_Adma64Cmd_Status_Q1_VQM_ErrorSource_MASK) >> mp1_Adma64Cmd_Status_Q1_VQM_ErrorSource_SHIFT)

#define mp1_Adma64Cmd_Status_Q1_SET_VQM_Error(mp1_adma64cmd_status_q1_reg, vqm_error) \
      mp1_adma64cmd_status_q1_reg = (mp1_adma64cmd_status_q1_reg & ~mp1_Adma64Cmd_Status_Q1_VQM_Error_MASK) | (vqm_error << mp1_Adma64Cmd_Status_Q1_VQM_Error_SHIFT)
#define mp1_Adma64Cmd_Status_Q1_SET_VQM_ErrorPrevious(mp1_adma64cmd_status_q1_reg, vqm_errorprevious) \
      mp1_adma64cmd_status_q1_reg = (mp1_adma64cmd_status_q1_reg & ~mp1_Adma64Cmd_Status_Q1_VQM_ErrorPrevious_MASK) | (vqm_errorprevious << mp1_Adma64Cmd_Status_Q1_VQM_ErrorPrevious_SHIFT)
#define mp1_Adma64Cmd_Status_Q1_SET_VQM_JStatus(mp1_adma64cmd_status_q1_reg, vqm_jstatus) \
      mp1_adma64cmd_status_q1_reg = (mp1_adma64cmd_status_q1_reg & ~mp1_Adma64Cmd_Status_Q1_VQM_JStatus_MASK) | (vqm_jstatus << mp1_Adma64Cmd_Status_Q1_VQM_JStatus_SHIFT)
#define mp1_Adma64Cmd_Status_Q1_SET_VQM_ErrorSource(mp1_adma64cmd_status_q1_reg, vqm_errorsource) \
      mp1_adma64cmd_status_q1_reg = (mp1_adma64cmd_status_q1_reg & ~mp1_Adma64Cmd_Status_Q1_VQM_ErrorSource_MASK) | (vqm_errorsource << mp1_Adma64Cmd_Status_Q1_VQM_ErrorSource_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_status_q1_t {
            unsigned int vqm_error                      : mp1_Adma64Cmd_Status_Q1_VQM_Error_SIZE;
            unsigned int vqm_errorprevious              : mp1_Adma64Cmd_Status_Q1_VQM_ErrorPrevious_SIZE;
            unsigned int vqm_jstatus                    : mp1_Adma64Cmd_Status_Q1_VQM_JStatus_SIZE;
            unsigned int vqm_errorsource                : mp1_Adma64Cmd_Status_Q1_VQM_ErrorSource_SIZE;
            unsigned int                                : 19;
      } mp1_adma64cmd_status_q1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_status_q1_t {
            unsigned int                                : 19;
            unsigned int vqm_errorsource                : mp1_Adma64Cmd_Status_Q1_VQM_ErrorSource_SIZE;
            unsigned int vqm_jstatus                    : mp1_Adma64Cmd_Status_Q1_VQM_JStatus_SIZE;
            unsigned int vqm_errorprevious              : mp1_Adma64Cmd_Status_Q1_VQM_ErrorPrevious_SIZE;
            unsigned int vqm_error                      : mp1_Adma64Cmd_Status_Q1_VQM_Error_SIZE;
      } mp1_adma64cmd_status_q1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_status_q1_t f;
} mp1_adma64cmd_status_q1_u;


/*
 * mp1_Adma64Cmd_Int_Status_Q1 struct
 */

#define mp1_Adma64Cmd_Int_Status_Q1_REG_SIZE         32
#define mp1_Adma64Cmd_Int_Status_Q1_IC_EventCnt_SIZE  7

#define mp1_Adma64Cmd_Int_Status_Q1_IC_EventCnt_SHIFT  0

#define mp1_Adma64Cmd_Int_Status_Q1_IC_EventCnt_MASK  0x0000007f

#define mp1_Adma64Cmd_Int_Status_Q1_MASK \
      (mp1_Adma64Cmd_Int_Status_Q1_IC_EventCnt_MASK)

#define mp1_Adma64Cmd_Int_Status_Q1_DEFAULT 0x00000000

#define mp1_Adma64Cmd_Int_Status_Q1_GET_IC_EventCnt(mp1_adma64cmd_int_status_q1) \
      ((mp1_adma64cmd_int_status_q1 & mp1_Adma64Cmd_Int_Status_Q1_IC_EventCnt_MASK) >> mp1_Adma64Cmd_Int_Status_Q1_IC_EventCnt_SHIFT)

#define mp1_Adma64Cmd_Int_Status_Q1_SET_IC_EventCnt(mp1_adma64cmd_int_status_q1_reg, ic_eventcnt) \
      mp1_adma64cmd_int_status_q1_reg = (mp1_adma64cmd_int_status_q1_reg & ~mp1_Adma64Cmd_Int_Status_Q1_IC_EventCnt_MASK) | (ic_eventcnt << mp1_Adma64Cmd_Int_Status_Q1_IC_EventCnt_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_int_status_q1_t {
            unsigned int ic_eventcnt                    : mp1_Adma64Cmd_Int_Status_Q1_IC_EventCnt_SIZE;
            unsigned int                                : 25;
      } mp1_adma64cmd_int_status_q1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_int_status_q1_t {
            unsigned int                                : 25;
            unsigned int ic_eventcnt                    : mp1_Adma64Cmd_Int_Status_Q1_IC_EventCnt_SIZE;
      } mp1_adma64cmd_int_status_q1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_int_status_q1_t f;
} mp1_adma64cmd_int_status_q1_u;


/*
 * mp1_Adma64Cmd_DMA_Status_Q1 struct
 */

#define mp1_Adma64Cmd_DMA_Status_Q1_REG_SIZE         32
#define mp1_Adma64Cmd_DMA_Status_Q1_DMA_Pwrites_SIZE  10
#define mp1_Adma64Cmd_DMA_Status_Q1_DMA_Preads_SIZE  6
#define mp1_Adma64Cmd_DMA_Status_Q1_DMA_Dstatus_SIZE  3

#define mp1_Adma64Cmd_DMA_Status_Q1_DMA_Pwrites_SHIFT  0
#define mp1_Adma64Cmd_DMA_Status_Q1_DMA_Preads_SHIFT  10
#define mp1_Adma64Cmd_DMA_Status_Q1_DMA_Dstatus_SHIFT  16

#define mp1_Adma64Cmd_DMA_Status_Q1_DMA_Pwrites_MASK  0x000003ff
#define mp1_Adma64Cmd_DMA_Status_Q1_DMA_Preads_MASK  0x0000fc00
#define mp1_Adma64Cmd_DMA_Status_Q1_DMA_Dstatus_MASK  0x00070000

#define mp1_Adma64Cmd_DMA_Status_Q1_MASK \
      (mp1_Adma64Cmd_DMA_Status_Q1_DMA_Pwrites_MASK | \
      mp1_Adma64Cmd_DMA_Status_Q1_DMA_Preads_MASK | \
      mp1_Adma64Cmd_DMA_Status_Q1_DMA_Dstatus_MASK)

#define mp1_Adma64Cmd_DMA_Status_Q1_DEFAULT 0x00000000

#define mp1_Adma64Cmd_DMA_Status_Q1_GET_DMA_Pwrites(mp1_adma64cmd_dma_status_q1) \
      ((mp1_adma64cmd_dma_status_q1 & mp1_Adma64Cmd_DMA_Status_Q1_DMA_Pwrites_MASK) >> mp1_Adma64Cmd_DMA_Status_Q1_DMA_Pwrites_SHIFT)
#define mp1_Adma64Cmd_DMA_Status_Q1_GET_DMA_Preads(mp1_adma64cmd_dma_status_q1) \
      ((mp1_adma64cmd_dma_status_q1 & mp1_Adma64Cmd_DMA_Status_Q1_DMA_Preads_MASK) >> mp1_Adma64Cmd_DMA_Status_Q1_DMA_Preads_SHIFT)
#define mp1_Adma64Cmd_DMA_Status_Q1_GET_DMA_Dstatus(mp1_adma64cmd_dma_status_q1) \
      ((mp1_adma64cmd_dma_status_q1 & mp1_Adma64Cmd_DMA_Status_Q1_DMA_Dstatus_MASK) >> mp1_Adma64Cmd_DMA_Status_Q1_DMA_Dstatus_SHIFT)

#define mp1_Adma64Cmd_DMA_Status_Q1_SET_DMA_Pwrites(mp1_adma64cmd_dma_status_q1_reg, dma_pwrites) \
      mp1_adma64cmd_dma_status_q1_reg = (mp1_adma64cmd_dma_status_q1_reg & ~mp1_Adma64Cmd_DMA_Status_Q1_DMA_Pwrites_MASK) | (dma_pwrites << mp1_Adma64Cmd_DMA_Status_Q1_DMA_Pwrites_SHIFT)
#define mp1_Adma64Cmd_DMA_Status_Q1_SET_DMA_Preads(mp1_adma64cmd_dma_status_q1_reg, dma_preads) \
      mp1_adma64cmd_dma_status_q1_reg = (mp1_adma64cmd_dma_status_q1_reg & ~mp1_Adma64Cmd_DMA_Status_Q1_DMA_Preads_MASK) | (dma_preads << mp1_Adma64Cmd_DMA_Status_Q1_DMA_Preads_SHIFT)
#define mp1_Adma64Cmd_DMA_Status_Q1_SET_DMA_Dstatus(mp1_adma64cmd_dma_status_q1_reg, dma_dstatus) \
      mp1_adma64cmd_dma_status_q1_reg = (mp1_adma64cmd_dma_status_q1_reg & ~mp1_Adma64Cmd_DMA_Status_Q1_DMA_Dstatus_MASK) | (dma_dstatus << mp1_Adma64Cmd_DMA_Status_Q1_DMA_Dstatus_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_dma_status_q1_t {
            unsigned int dma_pwrites                    : mp1_Adma64Cmd_DMA_Status_Q1_DMA_Pwrites_SIZE;
            unsigned int dma_preads                     : mp1_Adma64Cmd_DMA_Status_Q1_DMA_Preads_SIZE;
            unsigned int dma_dstatus                    : mp1_Adma64Cmd_DMA_Status_Q1_DMA_Dstatus_SIZE;
            unsigned int                                : 13;
      } mp1_adma64cmd_dma_status_q1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_dma_status_q1_t {
            unsigned int                                : 13;
            unsigned int dma_dstatus                    : mp1_Adma64Cmd_DMA_Status_Q1_DMA_Dstatus_SIZE;
            unsigned int dma_preads                     : mp1_Adma64Cmd_DMA_Status_Q1_DMA_Preads_SIZE;
            unsigned int dma_pwrites                    : mp1_Adma64Cmd_DMA_Status_Q1_DMA_Pwrites_SIZE;
      } mp1_adma64cmd_dma_status_q1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_dma_status_q1_t f;
} mp1_adma64cmd_dma_status_q1_u;


/*
 * mp1_Adma64Cmd_DMA_Read_Status_Q1 struct
 */

#define mp1_Adma64Cmd_DMA_Read_Status_Q1_REG_SIZE         32
#define mp1_Adma64Cmd_DMA_Read_Status_Q1_DMA_BytesRead_SIZE  32

#define mp1_Adma64Cmd_DMA_Read_Status_Q1_DMA_BytesRead_SHIFT  0

#define mp1_Adma64Cmd_DMA_Read_Status_Q1_DMA_BytesRead_MASK  0xffffffff

#define mp1_Adma64Cmd_DMA_Read_Status_Q1_MASK \
      (mp1_Adma64Cmd_DMA_Read_Status_Q1_DMA_BytesRead_MASK)

#define mp1_Adma64Cmd_DMA_Read_Status_Q1_DEFAULT 0x00000000

#define mp1_Adma64Cmd_DMA_Read_Status_Q1_GET_DMA_BytesRead(mp1_adma64cmd_dma_read_status_q1) \
      ((mp1_adma64cmd_dma_read_status_q1 & mp1_Adma64Cmd_DMA_Read_Status_Q1_DMA_BytesRead_MASK) >> mp1_Adma64Cmd_DMA_Read_Status_Q1_DMA_BytesRead_SHIFT)

#define mp1_Adma64Cmd_DMA_Read_Status_Q1_SET_DMA_BytesRead(mp1_adma64cmd_dma_read_status_q1_reg, dma_bytesread) \
      mp1_adma64cmd_dma_read_status_q1_reg = (mp1_adma64cmd_dma_read_status_q1_reg & ~mp1_Adma64Cmd_DMA_Read_Status_Q1_DMA_BytesRead_MASK) | (dma_bytesread << mp1_Adma64Cmd_DMA_Read_Status_Q1_DMA_BytesRead_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_dma_read_status_q1_t {
            unsigned int dma_bytesread                  : mp1_Adma64Cmd_DMA_Read_Status_Q1_DMA_BytesRead_SIZE;
      } mp1_adma64cmd_dma_read_status_q1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_dma_read_status_q1_t {
            unsigned int dma_bytesread                  : mp1_Adma64Cmd_DMA_Read_Status_Q1_DMA_BytesRead_SIZE;
      } mp1_adma64cmd_dma_read_status_q1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_dma_read_status_q1_t f;
} mp1_adma64cmd_dma_read_status_q1_u;


/*
 * mp1_Adma64Cmd_DMA_Write_Status_Q1 struct
 */

#define mp1_Adma64Cmd_DMA_Write_Status_Q1_REG_SIZE         32
#define mp1_Adma64Cmd_DMA_Write_Status_Q1_DMA_BytesWritten_SIZE  32

#define mp1_Adma64Cmd_DMA_Write_Status_Q1_DMA_BytesWritten_SHIFT  0

#define mp1_Adma64Cmd_DMA_Write_Status_Q1_DMA_BytesWritten_MASK  0xffffffff

#define mp1_Adma64Cmd_DMA_Write_Status_Q1_MASK \
      (mp1_Adma64Cmd_DMA_Write_Status_Q1_DMA_BytesWritten_MASK)

#define mp1_Adma64Cmd_DMA_Write_Status_Q1_DEFAULT 0x00000000

#define mp1_Adma64Cmd_DMA_Write_Status_Q1_GET_DMA_BytesWritten(mp1_adma64cmd_dma_write_status_q1) \
      ((mp1_adma64cmd_dma_write_status_q1 & mp1_Adma64Cmd_DMA_Write_Status_Q1_DMA_BytesWritten_MASK) >> mp1_Adma64Cmd_DMA_Write_Status_Q1_DMA_BytesWritten_SHIFT)

#define mp1_Adma64Cmd_DMA_Write_Status_Q1_SET_DMA_BytesWritten(mp1_adma64cmd_dma_write_status_q1_reg, dma_byteswritten) \
      mp1_adma64cmd_dma_write_status_q1_reg = (mp1_adma64cmd_dma_write_status_q1_reg & ~mp1_Adma64Cmd_DMA_Write_Status_Q1_DMA_BytesWritten_MASK) | (dma_byteswritten << mp1_Adma64Cmd_DMA_Write_Status_Q1_DMA_BytesWritten_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_dma_write_status_q1_t {
            unsigned int dma_byteswritten               : mp1_Adma64Cmd_DMA_Write_Status_Q1_DMA_BytesWritten_SIZE;
      } mp1_adma64cmd_dma_write_status_q1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_dma_write_status_q1_t {
            unsigned int dma_byteswritten               : mp1_Adma64Cmd_DMA_Write_Status_Q1_DMA_BytesWritten_SIZE;
      } mp1_adma64cmd_dma_write_status_q1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_dma_write_status_q1_t f;
} mp1_adma64cmd_dma_write_status_q1_u;


/*
 * mp1_Adma64Cmd_Abort_Q1 struct
 */

#define mp1_Adma64Cmd_Abort_Q1_REG_SIZE         32
#define mp1_Adma64Cmd_Abort_Q1_RI_Offset_SIZE  18
#define mp1_Adma64Cmd_Abort_Q1_RI_Offset_Valid_SIZE  1

#define mp1_Adma64Cmd_Abort_Q1_RI_Offset_SHIFT  0
#define mp1_Adma64Cmd_Abort_Q1_RI_Offset_Valid_SHIFT  31

#define mp1_Adma64Cmd_Abort_Q1_RI_Offset_MASK  0x0003ffff
#define mp1_Adma64Cmd_Abort_Q1_RI_Offset_Valid_MASK  0x80000000

#define mp1_Adma64Cmd_Abort_Q1_MASK \
      (mp1_Adma64Cmd_Abort_Q1_RI_Offset_MASK | \
      mp1_Adma64Cmd_Abort_Q1_RI_Offset_Valid_MASK)

#define mp1_Adma64Cmd_Abort_Q1_DEFAULT 0x00000000

#define mp1_Adma64Cmd_Abort_Q1_GET_RI_Offset(mp1_adma64cmd_abort_q1) \
      ((mp1_adma64cmd_abort_q1 & mp1_Adma64Cmd_Abort_Q1_RI_Offset_MASK) >> mp1_Adma64Cmd_Abort_Q1_RI_Offset_SHIFT)
#define mp1_Adma64Cmd_Abort_Q1_GET_RI_Offset_Valid(mp1_adma64cmd_abort_q1) \
      ((mp1_adma64cmd_abort_q1 & mp1_Adma64Cmd_Abort_Q1_RI_Offset_Valid_MASK) >> mp1_Adma64Cmd_Abort_Q1_RI_Offset_Valid_SHIFT)

#define mp1_Adma64Cmd_Abort_Q1_SET_RI_Offset(mp1_adma64cmd_abort_q1_reg, ri_offset) \
      mp1_adma64cmd_abort_q1_reg = (mp1_adma64cmd_abort_q1_reg & ~mp1_Adma64Cmd_Abort_Q1_RI_Offset_MASK) | (ri_offset << mp1_Adma64Cmd_Abort_Q1_RI_Offset_SHIFT)
#define mp1_Adma64Cmd_Abort_Q1_SET_RI_Offset_Valid(mp1_adma64cmd_abort_q1_reg, ri_offset_valid) \
      mp1_adma64cmd_abort_q1_reg = (mp1_adma64cmd_abort_q1_reg & ~mp1_Adma64Cmd_Abort_Q1_RI_Offset_Valid_MASK) | (ri_offset_valid << mp1_Adma64Cmd_Abort_Q1_RI_Offset_Valid_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_abort_q1_t {
            unsigned int ri_offset                      : mp1_Adma64Cmd_Abort_Q1_RI_Offset_SIZE;
            unsigned int                                : 13;
            unsigned int ri_offset_valid                : mp1_Adma64Cmd_Abort_Q1_RI_Offset_Valid_SIZE;
      } mp1_adma64cmd_abort_q1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_abort_q1_t {
            unsigned int ri_offset_valid                : mp1_Adma64Cmd_Abort_Q1_RI_Offset_Valid_SIZE;
            unsigned int                                : 13;
            unsigned int ri_offset                      : mp1_Adma64Cmd_Abort_Q1_RI_Offset_SIZE;
      } mp1_adma64cmd_abort_q1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_abort_q1_t f;
} mp1_adma64cmd_abort_q1_u;


/*
 * mp1_Adma64Cmd_AxCACHE_Q1 struct
 */

#define mp1_Adma64Cmd_AxCACHE_Q1_REG_SIZE         32
#define mp1_Adma64Cmd_AxCACHE_Q1_RI_AWCACHE_SIZE  4
#define mp1_Adma64Cmd_AxCACHE_Q1_RI_ARCACHE_SIZE  4
#define mp1_Adma64Cmd_AxCACHE_Q1_RI_VCD_ARCACHE_SIZE  4

#define mp1_Adma64Cmd_AxCACHE_Q1_RI_AWCACHE_SHIFT  0
#define mp1_Adma64Cmd_AxCACHE_Q1_RI_ARCACHE_SHIFT  4
#define mp1_Adma64Cmd_AxCACHE_Q1_RI_VCD_ARCACHE_SHIFT  8

#define mp1_Adma64Cmd_AxCACHE_Q1_RI_AWCACHE_MASK  0x0000000f
#define mp1_Adma64Cmd_AxCACHE_Q1_RI_ARCACHE_MASK  0x000000f0
#define mp1_Adma64Cmd_AxCACHE_Q1_RI_VCD_ARCACHE_MASK  0x00000f00

#define mp1_Adma64Cmd_AxCACHE_Q1_MASK \
      (mp1_Adma64Cmd_AxCACHE_Q1_RI_AWCACHE_MASK | \
      mp1_Adma64Cmd_AxCACHE_Q1_RI_ARCACHE_MASK | \
      mp1_Adma64Cmd_AxCACHE_Q1_RI_VCD_ARCACHE_MASK)

#define mp1_Adma64Cmd_AxCACHE_Q1_DEFAULT 0x00000000

#define mp1_Adma64Cmd_AxCACHE_Q1_GET_RI_AWCACHE(mp1_adma64cmd_axcache_q1) \
      ((mp1_adma64cmd_axcache_q1 & mp1_Adma64Cmd_AxCACHE_Q1_RI_AWCACHE_MASK) >> mp1_Adma64Cmd_AxCACHE_Q1_RI_AWCACHE_SHIFT)
#define mp1_Adma64Cmd_AxCACHE_Q1_GET_RI_ARCACHE(mp1_adma64cmd_axcache_q1) \
      ((mp1_adma64cmd_axcache_q1 & mp1_Adma64Cmd_AxCACHE_Q1_RI_ARCACHE_MASK) >> mp1_Adma64Cmd_AxCACHE_Q1_RI_ARCACHE_SHIFT)
#define mp1_Adma64Cmd_AxCACHE_Q1_GET_RI_VCD_ARCACHE(mp1_adma64cmd_axcache_q1) \
      ((mp1_adma64cmd_axcache_q1 & mp1_Adma64Cmd_AxCACHE_Q1_RI_VCD_ARCACHE_MASK) >> mp1_Adma64Cmd_AxCACHE_Q1_RI_VCD_ARCACHE_SHIFT)

#define mp1_Adma64Cmd_AxCACHE_Q1_SET_RI_AWCACHE(mp1_adma64cmd_axcache_q1_reg, ri_awcache) \
      mp1_adma64cmd_axcache_q1_reg = (mp1_adma64cmd_axcache_q1_reg & ~mp1_Adma64Cmd_AxCACHE_Q1_RI_AWCACHE_MASK) | (ri_awcache << mp1_Adma64Cmd_AxCACHE_Q1_RI_AWCACHE_SHIFT)
#define mp1_Adma64Cmd_AxCACHE_Q1_SET_RI_ARCACHE(mp1_adma64cmd_axcache_q1_reg, ri_arcache) \
      mp1_adma64cmd_axcache_q1_reg = (mp1_adma64cmd_axcache_q1_reg & ~mp1_Adma64Cmd_AxCACHE_Q1_RI_ARCACHE_MASK) | (ri_arcache << mp1_Adma64Cmd_AxCACHE_Q1_RI_ARCACHE_SHIFT)
#define mp1_Adma64Cmd_AxCACHE_Q1_SET_RI_VCD_ARCACHE(mp1_adma64cmd_axcache_q1_reg, ri_vcd_arcache) \
      mp1_adma64cmd_axcache_q1_reg = (mp1_adma64cmd_axcache_q1_reg & ~mp1_Adma64Cmd_AxCACHE_Q1_RI_VCD_ARCACHE_MASK) | (ri_vcd_arcache << mp1_Adma64Cmd_AxCACHE_Q1_RI_VCD_ARCACHE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_axcache_q1_t {
            unsigned int ri_awcache                     : mp1_Adma64Cmd_AxCACHE_Q1_RI_AWCACHE_SIZE;
            unsigned int ri_arcache                     : mp1_Adma64Cmd_AxCACHE_Q1_RI_ARCACHE_SIZE;
            unsigned int ri_vcd_arcache                 : mp1_Adma64Cmd_AxCACHE_Q1_RI_VCD_ARCACHE_SIZE;
            unsigned int                                : 20;
      } mp1_adma64cmd_axcache_q1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_axcache_q1_t {
            unsigned int                                : 20;
            unsigned int ri_vcd_arcache                 : mp1_Adma64Cmd_AxCACHE_Q1_RI_VCD_ARCACHE_SIZE;
            unsigned int ri_arcache                     : mp1_Adma64Cmd_AxCACHE_Q1_RI_ARCACHE_SIZE;
            unsigned int ri_awcache                     : mp1_Adma64Cmd_AxCACHE_Q1_RI_AWCACHE_SIZE;
      } mp1_adma64cmd_axcache_q1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_axcache_q1_t f;
} mp1_adma64cmd_axcache_q1_u;


/*
 * mp1_Adma64Vqd2_Control struct
 */

#define mp1_Adma64Vqd2_Control_REG_SIZE         32
#define mp1_Adma64Vqd2_Control_RI_Run_SIZE  1
#define mp1_Adma64Vqd2_Control_VQM_Halted_SIZE  1
#define mp1_Adma64Vqd2_Control_RI_Mem_Location_SIZE  1
#define mp1_Adma64Vqd2_Control_RI_Queue_Size_SIZE  4
#define mp1_Adma64Vqd2_Control_RI_COMP_DESC_SIZE  1
#define mp1_Adma64Vqd2_Control_RI_VQD_Pointer_Hi_SIZE  16

#define mp1_Adma64Vqd2_Control_RI_Run_SHIFT  0
#define mp1_Adma64Vqd2_Control_VQM_Halted_SHIFT  1
#define mp1_Adma64Vqd2_Control_RI_Mem_Location_SHIFT  2
#define mp1_Adma64Vqd2_Control_RI_Queue_Size_SHIFT  3
#define mp1_Adma64Vqd2_Control_RI_COMP_DESC_SHIFT  7
#define mp1_Adma64Vqd2_Control_RI_VQD_Pointer_Hi_SHIFT  16

#define mp1_Adma64Vqd2_Control_RI_Run_MASK  0x00000001
#define mp1_Adma64Vqd2_Control_VQM_Halted_MASK  0x00000002
#define mp1_Adma64Vqd2_Control_RI_Mem_Location_MASK  0x00000004
#define mp1_Adma64Vqd2_Control_RI_Queue_Size_MASK  0x00000078
#define mp1_Adma64Vqd2_Control_RI_COMP_DESC_MASK  0x00000080
#define mp1_Adma64Vqd2_Control_RI_VQD_Pointer_Hi_MASK  0xffff0000

#define mp1_Adma64Vqd2_Control_MASK \
      (mp1_Adma64Vqd2_Control_RI_Run_MASK | \
      mp1_Adma64Vqd2_Control_VQM_Halted_MASK | \
      mp1_Adma64Vqd2_Control_RI_Mem_Location_MASK | \
      mp1_Adma64Vqd2_Control_RI_Queue_Size_MASK | \
      mp1_Adma64Vqd2_Control_RI_COMP_DESC_MASK | \
      mp1_Adma64Vqd2_Control_RI_VQD_Pointer_Hi_MASK)

#define mp1_Adma64Vqd2_Control_DEFAULT 0x00000002

#define mp1_Adma64Vqd2_Control_GET_RI_Run(mp1_adma64vqd2_control) \
      ((mp1_adma64vqd2_control & mp1_Adma64Vqd2_Control_RI_Run_MASK) >> mp1_Adma64Vqd2_Control_RI_Run_SHIFT)
#define mp1_Adma64Vqd2_Control_GET_VQM_Halted(mp1_adma64vqd2_control) \
      ((mp1_adma64vqd2_control & mp1_Adma64Vqd2_Control_VQM_Halted_MASK) >> mp1_Adma64Vqd2_Control_VQM_Halted_SHIFT)
#define mp1_Adma64Vqd2_Control_GET_RI_Mem_Location(mp1_adma64vqd2_control) \
      ((mp1_adma64vqd2_control & mp1_Adma64Vqd2_Control_RI_Mem_Location_MASK) >> mp1_Adma64Vqd2_Control_RI_Mem_Location_SHIFT)
#define mp1_Adma64Vqd2_Control_GET_RI_Queue_Size(mp1_adma64vqd2_control) \
      ((mp1_adma64vqd2_control & mp1_Adma64Vqd2_Control_RI_Queue_Size_MASK) >> mp1_Adma64Vqd2_Control_RI_Queue_Size_SHIFT)
#define mp1_Adma64Vqd2_Control_GET_RI_COMP_DESC(mp1_adma64vqd2_control) \
      ((mp1_adma64vqd2_control & mp1_Adma64Vqd2_Control_RI_COMP_DESC_MASK) >> mp1_Adma64Vqd2_Control_RI_COMP_DESC_SHIFT)
#define mp1_Adma64Vqd2_Control_GET_RI_VQD_Pointer_Hi(mp1_adma64vqd2_control) \
      ((mp1_adma64vqd2_control & mp1_Adma64Vqd2_Control_RI_VQD_Pointer_Hi_MASK) >> mp1_Adma64Vqd2_Control_RI_VQD_Pointer_Hi_SHIFT)

#define mp1_Adma64Vqd2_Control_SET_RI_Run(mp1_adma64vqd2_control_reg, ri_run) \
      mp1_adma64vqd2_control_reg = (mp1_adma64vqd2_control_reg & ~mp1_Adma64Vqd2_Control_RI_Run_MASK) | (ri_run << mp1_Adma64Vqd2_Control_RI_Run_SHIFT)
#define mp1_Adma64Vqd2_Control_SET_VQM_Halted(mp1_adma64vqd2_control_reg, vqm_halted) \
      mp1_adma64vqd2_control_reg = (mp1_adma64vqd2_control_reg & ~mp1_Adma64Vqd2_Control_VQM_Halted_MASK) | (vqm_halted << mp1_Adma64Vqd2_Control_VQM_Halted_SHIFT)
#define mp1_Adma64Vqd2_Control_SET_RI_Mem_Location(mp1_adma64vqd2_control_reg, ri_mem_location) \
      mp1_adma64vqd2_control_reg = (mp1_adma64vqd2_control_reg & ~mp1_Adma64Vqd2_Control_RI_Mem_Location_MASK) | (ri_mem_location << mp1_Adma64Vqd2_Control_RI_Mem_Location_SHIFT)
#define mp1_Adma64Vqd2_Control_SET_RI_Queue_Size(mp1_adma64vqd2_control_reg, ri_queue_size) \
      mp1_adma64vqd2_control_reg = (mp1_adma64vqd2_control_reg & ~mp1_Adma64Vqd2_Control_RI_Queue_Size_MASK) | (ri_queue_size << mp1_Adma64Vqd2_Control_RI_Queue_Size_SHIFT)
#define mp1_Adma64Vqd2_Control_SET_RI_COMP_DESC(mp1_adma64vqd2_control_reg, ri_comp_desc) \
      mp1_adma64vqd2_control_reg = (mp1_adma64vqd2_control_reg & ~mp1_Adma64Vqd2_Control_RI_COMP_DESC_MASK) | (ri_comp_desc << mp1_Adma64Vqd2_Control_RI_COMP_DESC_SHIFT)
#define mp1_Adma64Vqd2_Control_SET_RI_VQD_Pointer_Hi(mp1_adma64vqd2_control_reg, ri_vqd_pointer_hi) \
      mp1_adma64vqd2_control_reg = (mp1_adma64vqd2_control_reg & ~mp1_Adma64Vqd2_Control_RI_VQD_Pointer_Hi_MASK) | (ri_vqd_pointer_hi << mp1_Adma64Vqd2_Control_RI_VQD_Pointer_Hi_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64vqd2_control_t {
            unsigned int ri_run                         : mp1_Adma64Vqd2_Control_RI_Run_SIZE;
            unsigned int vqm_halted                     : mp1_Adma64Vqd2_Control_VQM_Halted_SIZE;
            unsigned int ri_mem_location                : mp1_Adma64Vqd2_Control_RI_Mem_Location_SIZE;
            unsigned int ri_queue_size                  : mp1_Adma64Vqd2_Control_RI_Queue_Size_SIZE;
            unsigned int ri_comp_desc                   : mp1_Adma64Vqd2_Control_RI_COMP_DESC_SIZE;
            unsigned int                                : 8;
            unsigned int ri_vqd_pointer_hi              : mp1_Adma64Vqd2_Control_RI_VQD_Pointer_Hi_SIZE;
      } mp1_adma64vqd2_control_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64vqd2_control_t {
            unsigned int ri_vqd_pointer_hi              : mp1_Adma64Vqd2_Control_RI_VQD_Pointer_Hi_SIZE;
            unsigned int                                : 8;
            unsigned int ri_comp_desc                   : mp1_Adma64Vqd2_Control_RI_COMP_DESC_SIZE;
            unsigned int ri_queue_size                  : mp1_Adma64Vqd2_Control_RI_Queue_Size_SIZE;
            unsigned int ri_mem_location                : mp1_Adma64Vqd2_Control_RI_Mem_Location_SIZE;
            unsigned int vqm_halted                     : mp1_Adma64Vqd2_Control_VQM_Halted_SIZE;
            unsigned int ri_run                         : mp1_Adma64Vqd2_Control_RI_Run_SIZE;
      } mp1_adma64vqd2_control_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64vqd2_control_t f;
} mp1_adma64vqd2_control_u;


/*
 * mp1_Adma64Vqd2_Tail_Lo struct
 */

#define mp1_Adma64Vqd2_Tail_Lo_REG_SIZE         32
#define mp1_Adma64Vqd2_Tail_Lo_RI_Tail_Pointer_Lo_SIZE  32

#define mp1_Adma64Vqd2_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT  0

#define mp1_Adma64Vqd2_Tail_Lo_RI_Tail_Pointer_Lo_MASK  0xffffffff

#define mp1_Adma64Vqd2_Tail_Lo_MASK \
      (mp1_Adma64Vqd2_Tail_Lo_RI_Tail_Pointer_Lo_MASK)

#define mp1_Adma64Vqd2_Tail_Lo_DEFAULT 0x00000000

#define mp1_Adma64Vqd2_Tail_Lo_GET_RI_Tail_Pointer_Lo(mp1_adma64vqd2_tail_lo) \
      ((mp1_adma64vqd2_tail_lo & mp1_Adma64Vqd2_Tail_Lo_RI_Tail_Pointer_Lo_MASK) >> mp1_Adma64Vqd2_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT)

#define mp1_Adma64Vqd2_Tail_Lo_SET_RI_Tail_Pointer_Lo(mp1_adma64vqd2_tail_lo_reg, ri_tail_pointer_lo) \
      mp1_adma64vqd2_tail_lo_reg = (mp1_adma64vqd2_tail_lo_reg & ~mp1_Adma64Vqd2_Tail_Lo_RI_Tail_Pointer_Lo_MASK) | (ri_tail_pointer_lo << mp1_Adma64Vqd2_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64vqd2_tail_lo_t {
            unsigned int ri_tail_pointer_lo             : mp1_Adma64Vqd2_Tail_Lo_RI_Tail_Pointer_Lo_SIZE;
      } mp1_adma64vqd2_tail_lo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64vqd2_tail_lo_t {
            unsigned int ri_tail_pointer_lo             : mp1_Adma64Vqd2_Tail_Lo_RI_Tail_Pointer_Lo_SIZE;
      } mp1_adma64vqd2_tail_lo_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64vqd2_tail_lo_t f;
} mp1_adma64vqd2_tail_lo_u;


/*
 * mp1_Adma64Vqd2_Head_Lo struct
 */

#define mp1_Adma64Vqd2_Head_Lo_REG_SIZE         32
#define mp1_Adma64Vqd2_Head_Lo_RI_Head_Pointer_Lo_SIZE  32

#define mp1_Adma64Vqd2_Head_Lo_RI_Head_Pointer_Lo_SHIFT  0

#define mp1_Adma64Vqd2_Head_Lo_RI_Head_Pointer_Lo_MASK  0xffffffff

#define mp1_Adma64Vqd2_Head_Lo_MASK \
      (mp1_Adma64Vqd2_Head_Lo_RI_Head_Pointer_Lo_MASK)

#define mp1_Adma64Vqd2_Head_Lo_DEFAULT 0x00000000

#define mp1_Adma64Vqd2_Head_Lo_GET_RI_Head_Pointer_Lo(mp1_adma64vqd2_head_lo) \
      ((mp1_adma64vqd2_head_lo & mp1_Adma64Vqd2_Head_Lo_RI_Head_Pointer_Lo_MASK) >> mp1_Adma64Vqd2_Head_Lo_RI_Head_Pointer_Lo_SHIFT)

#define mp1_Adma64Vqd2_Head_Lo_SET_RI_Head_Pointer_Lo(mp1_adma64vqd2_head_lo_reg, ri_head_pointer_lo) \
      mp1_adma64vqd2_head_lo_reg = (mp1_adma64vqd2_head_lo_reg & ~mp1_Adma64Vqd2_Head_Lo_RI_Head_Pointer_Lo_MASK) | (ri_head_pointer_lo << mp1_Adma64Vqd2_Head_Lo_RI_Head_Pointer_Lo_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64vqd2_head_lo_t {
            unsigned int ri_head_pointer_lo             : mp1_Adma64Vqd2_Head_Lo_RI_Head_Pointer_Lo_SIZE;
      } mp1_adma64vqd2_head_lo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64vqd2_head_lo_t {
            unsigned int ri_head_pointer_lo             : mp1_Adma64Vqd2_Head_Lo_RI_Head_Pointer_Lo_SIZE;
      } mp1_adma64vqd2_head_lo_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64vqd2_head_lo_t f;
} mp1_adma64vqd2_head_lo_u;


/*
 * mp1_Adma64Cmd_Interrupt_Enable_Q2 struct
 */

#define mp1_Adma64Cmd_Interrupt_Enable_Q2_REG_SIZE         32
#define mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_CompInt_Enable_SIZE  1
#define mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_SIZE  1
#define mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_QSI_Enable_SIZE  1
#define mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_QEI_Enable_SIZE  1

#define mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_CompInt_Enable_SHIFT  0
#define mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_SHIFT  1
#define mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_QSI_Enable_SHIFT  2
#define mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_QEI_Enable_SHIFT  3

#define mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_CompInt_Enable_MASK  0x00000001
#define mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_MASK  0x00000002
#define mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_QSI_Enable_MASK  0x00000004
#define mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_QEI_Enable_MASK  0x00000008

#define mp1_Adma64Cmd_Interrupt_Enable_Q2_MASK \
      (mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_CompInt_Enable_MASK | \
      mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_MASK | \
      mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_QSI_Enable_MASK | \
      mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_QEI_Enable_MASK)

#define mp1_Adma64Cmd_Interrupt_Enable_Q2_DEFAULT 0x00000000

#define mp1_Adma64Cmd_Interrupt_Enable_Q2_GET_RI_CompInt_Enable(mp1_adma64cmd_interrupt_enable_q2) \
      ((mp1_adma64cmd_interrupt_enable_q2 & mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_CompInt_Enable_MASK) >> mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_CompInt_Enable_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Enable_Q2_GET_RI_ErrInt_Enable(mp1_adma64cmd_interrupt_enable_q2) \
      ((mp1_adma64cmd_interrupt_enable_q2 & mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_MASK) >> mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Enable_Q2_GET_RI_QSI_Enable(mp1_adma64cmd_interrupt_enable_q2) \
      ((mp1_adma64cmd_interrupt_enable_q2 & mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_QSI_Enable_MASK) >> mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_QSI_Enable_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Enable_Q2_GET_RI_QEI_Enable(mp1_adma64cmd_interrupt_enable_q2) \
      ((mp1_adma64cmd_interrupt_enable_q2 & mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_QEI_Enable_MASK) >> mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_QEI_Enable_SHIFT)

#define mp1_Adma64Cmd_Interrupt_Enable_Q2_SET_RI_CompInt_Enable(mp1_adma64cmd_interrupt_enable_q2_reg, ri_compint_enable) \
      mp1_adma64cmd_interrupt_enable_q2_reg = (mp1_adma64cmd_interrupt_enable_q2_reg & ~mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_CompInt_Enable_MASK) | (ri_compint_enable << mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_CompInt_Enable_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Enable_Q2_SET_RI_ErrInt_Enable(mp1_adma64cmd_interrupt_enable_q2_reg, ri_errint_enable) \
      mp1_adma64cmd_interrupt_enable_q2_reg = (mp1_adma64cmd_interrupt_enable_q2_reg & ~mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_MASK) | (ri_errint_enable << mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Enable_Q2_SET_RI_QSI_Enable(mp1_adma64cmd_interrupt_enable_q2_reg, ri_qsi_enable) \
      mp1_adma64cmd_interrupt_enable_q2_reg = (mp1_adma64cmd_interrupt_enable_q2_reg & ~mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_QSI_Enable_MASK) | (ri_qsi_enable << mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_QSI_Enable_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Enable_Q2_SET_RI_QEI_Enable(mp1_adma64cmd_interrupt_enable_q2_reg, ri_qei_enable) \
      mp1_adma64cmd_interrupt_enable_q2_reg = (mp1_adma64cmd_interrupt_enable_q2_reg & ~mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_QEI_Enable_MASK) | (ri_qei_enable << mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_QEI_Enable_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_interrupt_enable_q2_t {
            unsigned int ri_compint_enable              : mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_CompInt_Enable_SIZE;
            unsigned int ri_errint_enable               : mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_SIZE;
            unsigned int ri_qsi_enable                  : mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_QSI_Enable_SIZE;
            unsigned int ri_qei_enable                  : mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_QEI_Enable_SIZE;
            unsigned int                                : 28;
      } mp1_adma64cmd_interrupt_enable_q2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_interrupt_enable_q2_t {
            unsigned int                                : 28;
            unsigned int ri_qei_enable                  : mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_QEI_Enable_SIZE;
            unsigned int ri_qsi_enable                  : mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_QSI_Enable_SIZE;
            unsigned int ri_errint_enable               : mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_SIZE;
            unsigned int ri_compint_enable              : mp1_Adma64Cmd_Interrupt_Enable_Q2_RI_CompInt_Enable_SIZE;
      } mp1_adma64cmd_interrupt_enable_q2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_interrupt_enable_q2_t f;
} mp1_adma64cmd_interrupt_enable_q2_u;


/*
 * mp1_Adma64Cmd_Interrupt_Status_Q2 struct
 */

#define mp1_Adma64Cmd_Interrupt_Status_Q2_REG_SIZE         32
#define mp1_Adma64Cmd_Interrupt_Status_Q2_RI_CompInt_Valid_SIZE  1
#define mp1_Adma64Cmd_Interrupt_Status_Q2_RI_ErrInt_Valid_SIZE  1
#define mp1_Adma64Cmd_Interrupt_Status_Q2_RI_QSI_Valid_SIZE  1
#define mp1_Adma64Cmd_Interrupt_Status_Q2_RI_QEI_Valid_SIZE  1

#define mp1_Adma64Cmd_Interrupt_Status_Q2_RI_CompInt_Valid_SHIFT  0
#define mp1_Adma64Cmd_Interrupt_Status_Q2_RI_ErrInt_Valid_SHIFT  1
#define mp1_Adma64Cmd_Interrupt_Status_Q2_RI_QSI_Valid_SHIFT  2
#define mp1_Adma64Cmd_Interrupt_Status_Q2_RI_QEI_Valid_SHIFT  3

#define mp1_Adma64Cmd_Interrupt_Status_Q2_RI_CompInt_Valid_MASK  0x00000001
#define mp1_Adma64Cmd_Interrupt_Status_Q2_RI_ErrInt_Valid_MASK  0x00000002
#define mp1_Adma64Cmd_Interrupt_Status_Q2_RI_QSI_Valid_MASK  0x00000004
#define mp1_Adma64Cmd_Interrupt_Status_Q2_RI_QEI_Valid_MASK  0x00000008

#define mp1_Adma64Cmd_Interrupt_Status_Q2_MASK \
      (mp1_Adma64Cmd_Interrupt_Status_Q2_RI_CompInt_Valid_MASK | \
      mp1_Adma64Cmd_Interrupt_Status_Q2_RI_ErrInt_Valid_MASK | \
      mp1_Adma64Cmd_Interrupt_Status_Q2_RI_QSI_Valid_MASK | \
      mp1_Adma64Cmd_Interrupt_Status_Q2_RI_QEI_Valid_MASK)

#define mp1_Adma64Cmd_Interrupt_Status_Q2_DEFAULT 0x00000000

#define mp1_Adma64Cmd_Interrupt_Status_Q2_GET_RI_CompInt_Valid(mp1_adma64cmd_interrupt_status_q2) \
      ((mp1_adma64cmd_interrupt_status_q2 & mp1_Adma64Cmd_Interrupt_Status_Q2_RI_CompInt_Valid_MASK) >> mp1_Adma64Cmd_Interrupt_Status_Q2_RI_CompInt_Valid_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Status_Q2_GET_RI_ErrInt_Valid(mp1_adma64cmd_interrupt_status_q2) \
      ((mp1_adma64cmd_interrupt_status_q2 & mp1_Adma64Cmd_Interrupt_Status_Q2_RI_ErrInt_Valid_MASK) >> mp1_Adma64Cmd_Interrupt_Status_Q2_RI_ErrInt_Valid_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Status_Q2_GET_RI_QSI_Valid(mp1_adma64cmd_interrupt_status_q2) \
      ((mp1_adma64cmd_interrupt_status_q2 & mp1_Adma64Cmd_Interrupt_Status_Q2_RI_QSI_Valid_MASK) >> mp1_Adma64Cmd_Interrupt_Status_Q2_RI_QSI_Valid_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Status_Q2_GET_RI_QEI_Valid(mp1_adma64cmd_interrupt_status_q2) \
      ((mp1_adma64cmd_interrupt_status_q2 & mp1_Adma64Cmd_Interrupt_Status_Q2_RI_QEI_Valid_MASK) >> mp1_Adma64Cmd_Interrupt_Status_Q2_RI_QEI_Valid_SHIFT)

#define mp1_Adma64Cmd_Interrupt_Status_Q2_SET_RI_CompInt_Valid(mp1_adma64cmd_interrupt_status_q2_reg, ri_compint_valid) \
      mp1_adma64cmd_interrupt_status_q2_reg = (mp1_adma64cmd_interrupt_status_q2_reg & ~mp1_Adma64Cmd_Interrupt_Status_Q2_RI_CompInt_Valid_MASK) | (ri_compint_valid << mp1_Adma64Cmd_Interrupt_Status_Q2_RI_CompInt_Valid_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Status_Q2_SET_RI_ErrInt_Valid(mp1_adma64cmd_interrupt_status_q2_reg, ri_errint_valid) \
      mp1_adma64cmd_interrupt_status_q2_reg = (mp1_adma64cmd_interrupt_status_q2_reg & ~mp1_Adma64Cmd_Interrupt_Status_Q2_RI_ErrInt_Valid_MASK) | (ri_errint_valid << mp1_Adma64Cmd_Interrupt_Status_Q2_RI_ErrInt_Valid_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Status_Q2_SET_RI_QSI_Valid(mp1_adma64cmd_interrupt_status_q2_reg, ri_qsi_valid) \
      mp1_adma64cmd_interrupt_status_q2_reg = (mp1_adma64cmd_interrupt_status_q2_reg & ~mp1_Adma64Cmd_Interrupt_Status_Q2_RI_QSI_Valid_MASK) | (ri_qsi_valid << mp1_Adma64Cmd_Interrupt_Status_Q2_RI_QSI_Valid_SHIFT)
#define mp1_Adma64Cmd_Interrupt_Status_Q2_SET_RI_QEI_Valid(mp1_adma64cmd_interrupt_status_q2_reg, ri_qei_valid) \
      mp1_adma64cmd_interrupt_status_q2_reg = (mp1_adma64cmd_interrupt_status_q2_reg & ~mp1_Adma64Cmd_Interrupt_Status_Q2_RI_QEI_Valid_MASK) | (ri_qei_valid << mp1_Adma64Cmd_Interrupt_Status_Q2_RI_QEI_Valid_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_interrupt_status_q2_t {
            unsigned int ri_compint_valid               : mp1_Adma64Cmd_Interrupt_Status_Q2_RI_CompInt_Valid_SIZE;
            unsigned int ri_errint_valid                : mp1_Adma64Cmd_Interrupt_Status_Q2_RI_ErrInt_Valid_SIZE;
            unsigned int ri_qsi_valid                   : mp1_Adma64Cmd_Interrupt_Status_Q2_RI_QSI_Valid_SIZE;
            unsigned int ri_qei_valid                   : mp1_Adma64Cmd_Interrupt_Status_Q2_RI_QEI_Valid_SIZE;
            unsigned int                                : 28;
      } mp1_adma64cmd_interrupt_status_q2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_interrupt_status_q2_t {
            unsigned int                                : 28;
            unsigned int ri_qei_valid                   : mp1_Adma64Cmd_Interrupt_Status_Q2_RI_QEI_Valid_SIZE;
            unsigned int ri_qsi_valid                   : mp1_Adma64Cmd_Interrupt_Status_Q2_RI_QSI_Valid_SIZE;
            unsigned int ri_errint_valid                : mp1_Adma64Cmd_Interrupt_Status_Q2_RI_ErrInt_Valid_SIZE;
            unsigned int ri_compint_valid               : mp1_Adma64Cmd_Interrupt_Status_Q2_RI_CompInt_Valid_SIZE;
      } mp1_adma64cmd_interrupt_status_q2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_interrupt_status_q2_t f;
} mp1_adma64cmd_interrupt_status_q2_u;


/*
 * mp1_Adma64Cmd_Status_Q2 struct
 */

#define mp1_Adma64Cmd_Status_Q2_REG_SIZE         32
#define mp1_Adma64Cmd_Status_Q2_VQM_Error_SIZE  6
#define mp1_Adma64Cmd_Status_Q2_VQM_ErrorPrevious_SIZE  1
#define mp1_Adma64Cmd_Status_Q2_VQM_JStatus_SIZE  3
#define mp1_Adma64Cmd_Status_Q2_VQM_ErrorSource_SIZE  3

#define mp1_Adma64Cmd_Status_Q2_VQM_Error_SHIFT  0
#define mp1_Adma64Cmd_Status_Q2_VQM_ErrorPrevious_SHIFT  6
#define mp1_Adma64Cmd_Status_Q2_VQM_JStatus_SHIFT  7
#define mp1_Adma64Cmd_Status_Q2_VQM_ErrorSource_SHIFT  10

#define mp1_Adma64Cmd_Status_Q2_VQM_Error_MASK  0x0000003f
#define mp1_Adma64Cmd_Status_Q2_VQM_ErrorPrevious_MASK  0x00000040
#define mp1_Adma64Cmd_Status_Q2_VQM_JStatus_MASK  0x00000380
#define mp1_Adma64Cmd_Status_Q2_VQM_ErrorSource_MASK  0x00001c00

#define mp1_Adma64Cmd_Status_Q2_MASK \
      (mp1_Adma64Cmd_Status_Q2_VQM_Error_MASK | \
      mp1_Adma64Cmd_Status_Q2_VQM_ErrorPrevious_MASK | \
      mp1_Adma64Cmd_Status_Q2_VQM_JStatus_MASK | \
      mp1_Adma64Cmd_Status_Q2_VQM_ErrorSource_MASK)

#define mp1_Adma64Cmd_Status_Q2_DEFAULT 0x00000000

#define mp1_Adma64Cmd_Status_Q2_GET_VQM_Error(mp1_adma64cmd_status_q2) \
      ((mp1_adma64cmd_status_q2 & mp1_Adma64Cmd_Status_Q2_VQM_Error_MASK) >> mp1_Adma64Cmd_Status_Q2_VQM_Error_SHIFT)
#define mp1_Adma64Cmd_Status_Q2_GET_VQM_ErrorPrevious(mp1_adma64cmd_status_q2) \
      ((mp1_adma64cmd_status_q2 & mp1_Adma64Cmd_Status_Q2_VQM_ErrorPrevious_MASK) >> mp1_Adma64Cmd_Status_Q2_VQM_ErrorPrevious_SHIFT)
#define mp1_Adma64Cmd_Status_Q2_GET_VQM_JStatus(mp1_adma64cmd_status_q2) \
      ((mp1_adma64cmd_status_q2 & mp1_Adma64Cmd_Status_Q2_VQM_JStatus_MASK) >> mp1_Adma64Cmd_Status_Q2_VQM_JStatus_SHIFT)
#define mp1_Adma64Cmd_Status_Q2_GET_VQM_ErrorSource(mp1_adma64cmd_status_q2) \
      ((mp1_adma64cmd_status_q2 & mp1_Adma64Cmd_Status_Q2_VQM_ErrorSource_MASK) >> mp1_Adma64Cmd_Status_Q2_VQM_ErrorSource_SHIFT)

#define mp1_Adma64Cmd_Status_Q2_SET_VQM_Error(mp1_adma64cmd_status_q2_reg, vqm_error) \
      mp1_adma64cmd_status_q2_reg = (mp1_adma64cmd_status_q2_reg & ~mp1_Adma64Cmd_Status_Q2_VQM_Error_MASK) | (vqm_error << mp1_Adma64Cmd_Status_Q2_VQM_Error_SHIFT)
#define mp1_Adma64Cmd_Status_Q2_SET_VQM_ErrorPrevious(mp1_adma64cmd_status_q2_reg, vqm_errorprevious) \
      mp1_adma64cmd_status_q2_reg = (mp1_adma64cmd_status_q2_reg & ~mp1_Adma64Cmd_Status_Q2_VQM_ErrorPrevious_MASK) | (vqm_errorprevious << mp1_Adma64Cmd_Status_Q2_VQM_ErrorPrevious_SHIFT)
#define mp1_Adma64Cmd_Status_Q2_SET_VQM_JStatus(mp1_adma64cmd_status_q2_reg, vqm_jstatus) \
      mp1_adma64cmd_status_q2_reg = (mp1_adma64cmd_status_q2_reg & ~mp1_Adma64Cmd_Status_Q2_VQM_JStatus_MASK) | (vqm_jstatus << mp1_Adma64Cmd_Status_Q2_VQM_JStatus_SHIFT)
#define mp1_Adma64Cmd_Status_Q2_SET_VQM_ErrorSource(mp1_adma64cmd_status_q2_reg, vqm_errorsource) \
      mp1_adma64cmd_status_q2_reg = (mp1_adma64cmd_status_q2_reg & ~mp1_Adma64Cmd_Status_Q2_VQM_ErrorSource_MASK) | (vqm_errorsource << mp1_Adma64Cmd_Status_Q2_VQM_ErrorSource_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_status_q2_t {
            unsigned int vqm_error                      : mp1_Adma64Cmd_Status_Q2_VQM_Error_SIZE;
            unsigned int vqm_errorprevious              : mp1_Adma64Cmd_Status_Q2_VQM_ErrorPrevious_SIZE;
            unsigned int vqm_jstatus                    : mp1_Adma64Cmd_Status_Q2_VQM_JStatus_SIZE;
            unsigned int vqm_errorsource                : mp1_Adma64Cmd_Status_Q2_VQM_ErrorSource_SIZE;
            unsigned int                                : 19;
      } mp1_adma64cmd_status_q2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_status_q2_t {
            unsigned int                                : 19;
            unsigned int vqm_errorsource                : mp1_Adma64Cmd_Status_Q2_VQM_ErrorSource_SIZE;
            unsigned int vqm_jstatus                    : mp1_Adma64Cmd_Status_Q2_VQM_JStatus_SIZE;
            unsigned int vqm_errorprevious              : mp1_Adma64Cmd_Status_Q2_VQM_ErrorPrevious_SIZE;
            unsigned int vqm_error                      : mp1_Adma64Cmd_Status_Q2_VQM_Error_SIZE;
      } mp1_adma64cmd_status_q2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_status_q2_t f;
} mp1_adma64cmd_status_q2_u;


/*
 * mp1_Adma64Cmd_Int_Status_Q2 struct
 */

#define mp1_Adma64Cmd_Int_Status_Q2_REG_SIZE         32
#define mp1_Adma64Cmd_Int_Status_Q2_IC_EventCnt_SIZE  7

#define mp1_Adma64Cmd_Int_Status_Q2_IC_EventCnt_SHIFT  0

#define mp1_Adma64Cmd_Int_Status_Q2_IC_EventCnt_MASK  0x0000007f

#define mp1_Adma64Cmd_Int_Status_Q2_MASK \
      (mp1_Adma64Cmd_Int_Status_Q2_IC_EventCnt_MASK)

#define mp1_Adma64Cmd_Int_Status_Q2_DEFAULT 0x00000000

#define mp1_Adma64Cmd_Int_Status_Q2_GET_IC_EventCnt(mp1_adma64cmd_int_status_q2) \
      ((mp1_adma64cmd_int_status_q2 & mp1_Adma64Cmd_Int_Status_Q2_IC_EventCnt_MASK) >> mp1_Adma64Cmd_Int_Status_Q2_IC_EventCnt_SHIFT)

#define mp1_Adma64Cmd_Int_Status_Q2_SET_IC_EventCnt(mp1_adma64cmd_int_status_q2_reg, ic_eventcnt) \
      mp1_adma64cmd_int_status_q2_reg = (mp1_adma64cmd_int_status_q2_reg & ~mp1_Adma64Cmd_Int_Status_Q2_IC_EventCnt_MASK) | (ic_eventcnt << mp1_Adma64Cmd_Int_Status_Q2_IC_EventCnt_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_int_status_q2_t {
            unsigned int ic_eventcnt                    : mp1_Adma64Cmd_Int_Status_Q2_IC_EventCnt_SIZE;
            unsigned int                                : 25;
      } mp1_adma64cmd_int_status_q2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_int_status_q2_t {
            unsigned int                                : 25;
            unsigned int ic_eventcnt                    : mp1_Adma64Cmd_Int_Status_Q2_IC_EventCnt_SIZE;
      } mp1_adma64cmd_int_status_q2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_int_status_q2_t f;
} mp1_adma64cmd_int_status_q2_u;


/*
 * mp1_Adma64Cmd_DMA_Status_Q2 struct
 */

#define mp1_Adma64Cmd_DMA_Status_Q2_REG_SIZE         32
#define mp1_Adma64Cmd_DMA_Status_Q2_DMA_Pwrites_SIZE  10
#define mp1_Adma64Cmd_DMA_Status_Q2_DMA_Preads_SIZE  6
#define mp1_Adma64Cmd_DMA_Status_Q2_DMA_Dstatus_SIZE  3

#define mp1_Adma64Cmd_DMA_Status_Q2_DMA_Pwrites_SHIFT  0
#define mp1_Adma64Cmd_DMA_Status_Q2_DMA_Preads_SHIFT  10
#define mp1_Adma64Cmd_DMA_Status_Q2_DMA_Dstatus_SHIFT  16

#define mp1_Adma64Cmd_DMA_Status_Q2_DMA_Pwrites_MASK  0x000003ff
#define mp1_Adma64Cmd_DMA_Status_Q2_DMA_Preads_MASK  0x0000fc00
#define mp1_Adma64Cmd_DMA_Status_Q2_DMA_Dstatus_MASK  0x00070000

#define mp1_Adma64Cmd_DMA_Status_Q2_MASK \
      (mp1_Adma64Cmd_DMA_Status_Q2_DMA_Pwrites_MASK | \
      mp1_Adma64Cmd_DMA_Status_Q2_DMA_Preads_MASK | \
      mp1_Adma64Cmd_DMA_Status_Q2_DMA_Dstatus_MASK)

#define mp1_Adma64Cmd_DMA_Status_Q2_DEFAULT 0x00000000

#define mp1_Adma64Cmd_DMA_Status_Q2_GET_DMA_Pwrites(mp1_adma64cmd_dma_status_q2) \
      ((mp1_adma64cmd_dma_status_q2 & mp1_Adma64Cmd_DMA_Status_Q2_DMA_Pwrites_MASK) >> mp1_Adma64Cmd_DMA_Status_Q2_DMA_Pwrites_SHIFT)
#define mp1_Adma64Cmd_DMA_Status_Q2_GET_DMA_Preads(mp1_adma64cmd_dma_status_q2) \
      ((mp1_adma64cmd_dma_status_q2 & mp1_Adma64Cmd_DMA_Status_Q2_DMA_Preads_MASK) >> mp1_Adma64Cmd_DMA_Status_Q2_DMA_Preads_SHIFT)
#define mp1_Adma64Cmd_DMA_Status_Q2_GET_DMA_Dstatus(mp1_adma64cmd_dma_status_q2) \
      ((mp1_adma64cmd_dma_status_q2 & mp1_Adma64Cmd_DMA_Status_Q2_DMA_Dstatus_MASK) >> mp1_Adma64Cmd_DMA_Status_Q2_DMA_Dstatus_SHIFT)

#define mp1_Adma64Cmd_DMA_Status_Q2_SET_DMA_Pwrites(mp1_adma64cmd_dma_status_q2_reg, dma_pwrites) \
      mp1_adma64cmd_dma_status_q2_reg = (mp1_adma64cmd_dma_status_q2_reg & ~mp1_Adma64Cmd_DMA_Status_Q2_DMA_Pwrites_MASK) | (dma_pwrites << mp1_Adma64Cmd_DMA_Status_Q2_DMA_Pwrites_SHIFT)
#define mp1_Adma64Cmd_DMA_Status_Q2_SET_DMA_Preads(mp1_adma64cmd_dma_status_q2_reg, dma_preads) \
      mp1_adma64cmd_dma_status_q2_reg = (mp1_adma64cmd_dma_status_q2_reg & ~mp1_Adma64Cmd_DMA_Status_Q2_DMA_Preads_MASK) | (dma_preads << mp1_Adma64Cmd_DMA_Status_Q2_DMA_Preads_SHIFT)
#define mp1_Adma64Cmd_DMA_Status_Q2_SET_DMA_Dstatus(mp1_adma64cmd_dma_status_q2_reg, dma_dstatus) \
      mp1_adma64cmd_dma_status_q2_reg = (mp1_adma64cmd_dma_status_q2_reg & ~mp1_Adma64Cmd_DMA_Status_Q2_DMA_Dstatus_MASK) | (dma_dstatus << mp1_Adma64Cmd_DMA_Status_Q2_DMA_Dstatus_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_dma_status_q2_t {
            unsigned int dma_pwrites                    : mp1_Adma64Cmd_DMA_Status_Q2_DMA_Pwrites_SIZE;
            unsigned int dma_preads                     : mp1_Adma64Cmd_DMA_Status_Q2_DMA_Preads_SIZE;
            unsigned int dma_dstatus                    : mp1_Adma64Cmd_DMA_Status_Q2_DMA_Dstatus_SIZE;
            unsigned int                                : 13;
      } mp1_adma64cmd_dma_status_q2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_dma_status_q2_t {
            unsigned int                                : 13;
            unsigned int dma_dstatus                    : mp1_Adma64Cmd_DMA_Status_Q2_DMA_Dstatus_SIZE;
            unsigned int dma_preads                     : mp1_Adma64Cmd_DMA_Status_Q2_DMA_Preads_SIZE;
            unsigned int dma_pwrites                    : mp1_Adma64Cmd_DMA_Status_Q2_DMA_Pwrites_SIZE;
      } mp1_adma64cmd_dma_status_q2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_dma_status_q2_t f;
} mp1_adma64cmd_dma_status_q2_u;


/*
 * mp1_Adma64Cmd_DMA_Read_Status_Q2 struct
 */

#define mp1_Adma64Cmd_DMA_Read_Status_Q2_REG_SIZE         32
#define mp1_Adma64Cmd_DMA_Read_Status_Q2_DMA_BytesRead_SIZE  32

#define mp1_Adma64Cmd_DMA_Read_Status_Q2_DMA_BytesRead_SHIFT  0

#define mp1_Adma64Cmd_DMA_Read_Status_Q2_DMA_BytesRead_MASK  0xffffffff

#define mp1_Adma64Cmd_DMA_Read_Status_Q2_MASK \
      (mp1_Adma64Cmd_DMA_Read_Status_Q2_DMA_BytesRead_MASK)

#define mp1_Adma64Cmd_DMA_Read_Status_Q2_DEFAULT 0x00000000

#define mp1_Adma64Cmd_DMA_Read_Status_Q2_GET_DMA_BytesRead(mp1_adma64cmd_dma_read_status_q2) \
      ((mp1_adma64cmd_dma_read_status_q2 & mp1_Adma64Cmd_DMA_Read_Status_Q2_DMA_BytesRead_MASK) >> mp1_Adma64Cmd_DMA_Read_Status_Q2_DMA_BytesRead_SHIFT)

#define mp1_Adma64Cmd_DMA_Read_Status_Q2_SET_DMA_BytesRead(mp1_adma64cmd_dma_read_status_q2_reg, dma_bytesread) \
      mp1_adma64cmd_dma_read_status_q2_reg = (mp1_adma64cmd_dma_read_status_q2_reg & ~mp1_Adma64Cmd_DMA_Read_Status_Q2_DMA_BytesRead_MASK) | (dma_bytesread << mp1_Adma64Cmd_DMA_Read_Status_Q2_DMA_BytesRead_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_dma_read_status_q2_t {
            unsigned int dma_bytesread                  : mp1_Adma64Cmd_DMA_Read_Status_Q2_DMA_BytesRead_SIZE;
      } mp1_adma64cmd_dma_read_status_q2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_dma_read_status_q2_t {
            unsigned int dma_bytesread                  : mp1_Adma64Cmd_DMA_Read_Status_Q2_DMA_BytesRead_SIZE;
      } mp1_adma64cmd_dma_read_status_q2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_dma_read_status_q2_t f;
} mp1_adma64cmd_dma_read_status_q2_u;


/*
 * mp1_Adma64Cmd_DMA_Write_Status_Q2 struct
 */

#define mp1_Adma64Cmd_DMA_Write_Status_Q2_REG_SIZE         32
#define mp1_Adma64Cmd_DMA_Write_Status_Q2_DMA_BytesWritten_SIZE  32

#define mp1_Adma64Cmd_DMA_Write_Status_Q2_DMA_BytesWritten_SHIFT  0

#define mp1_Adma64Cmd_DMA_Write_Status_Q2_DMA_BytesWritten_MASK  0xffffffff

#define mp1_Adma64Cmd_DMA_Write_Status_Q2_MASK \
      (mp1_Adma64Cmd_DMA_Write_Status_Q2_DMA_BytesWritten_MASK)

#define mp1_Adma64Cmd_DMA_Write_Status_Q2_DEFAULT 0x00000000

#define mp1_Adma64Cmd_DMA_Write_Status_Q2_GET_DMA_BytesWritten(mp1_adma64cmd_dma_write_status_q2) \
      ((mp1_adma64cmd_dma_write_status_q2 & mp1_Adma64Cmd_DMA_Write_Status_Q2_DMA_BytesWritten_MASK) >> mp1_Adma64Cmd_DMA_Write_Status_Q2_DMA_BytesWritten_SHIFT)

#define mp1_Adma64Cmd_DMA_Write_Status_Q2_SET_DMA_BytesWritten(mp1_adma64cmd_dma_write_status_q2_reg, dma_byteswritten) \
      mp1_adma64cmd_dma_write_status_q2_reg = (mp1_adma64cmd_dma_write_status_q2_reg & ~mp1_Adma64Cmd_DMA_Write_Status_Q2_DMA_BytesWritten_MASK) | (dma_byteswritten << mp1_Adma64Cmd_DMA_Write_Status_Q2_DMA_BytesWritten_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_dma_write_status_q2_t {
            unsigned int dma_byteswritten               : mp1_Adma64Cmd_DMA_Write_Status_Q2_DMA_BytesWritten_SIZE;
      } mp1_adma64cmd_dma_write_status_q2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_dma_write_status_q2_t {
            unsigned int dma_byteswritten               : mp1_Adma64Cmd_DMA_Write_Status_Q2_DMA_BytesWritten_SIZE;
      } mp1_adma64cmd_dma_write_status_q2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_dma_write_status_q2_t f;
} mp1_adma64cmd_dma_write_status_q2_u;


/*
 * mp1_Adma64Cmd_Abort_Q2 struct
 */

#define mp1_Adma64Cmd_Abort_Q2_REG_SIZE         32
#define mp1_Adma64Cmd_Abort_Q2_RI_Offset_SIZE  18
#define mp1_Adma64Cmd_Abort_Q2_RI_Offset_Valid_SIZE  1

#define mp1_Adma64Cmd_Abort_Q2_RI_Offset_SHIFT  0
#define mp1_Adma64Cmd_Abort_Q2_RI_Offset_Valid_SHIFT  31

#define mp1_Adma64Cmd_Abort_Q2_RI_Offset_MASK  0x0003ffff
#define mp1_Adma64Cmd_Abort_Q2_RI_Offset_Valid_MASK  0x80000000

#define mp1_Adma64Cmd_Abort_Q2_MASK \
      (mp1_Adma64Cmd_Abort_Q2_RI_Offset_MASK | \
      mp1_Adma64Cmd_Abort_Q2_RI_Offset_Valid_MASK)

#define mp1_Adma64Cmd_Abort_Q2_DEFAULT 0x00000000

#define mp1_Adma64Cmd_Abort_Q2_GET_RI_Offset(mp1_adma64cmd_abort_q2) \
      ((mp1_adma64cmd_abort_q2 & mp1_Adma64Cmd_Abort_Q2_RI_Offset_MASK) >> mp1_Adma64Cmd_Abort_Q2_RI_Offset_SHIFT)
#define mp1_Adma64Cmd_Abort_Q2_GET_RI_Offset_Valid(mp1_adma64cmd_abort_q2) \
      ((mp1_adma64cmd_abort_q2 & mp1_Adma64Cmd_Abort_Q2_RI_Offset_Valid_MASK) >> mp1_Adma64Cmd_Abort_Q2_RI_Offset_Valid_SHIFT)

#define mp1_Adma64Cmd_Abort_Q2_SET_RI_Offset(mp1_adma64cmd_abort_q2_reg, ri_offset) \
      mp1_adma64cmd_abort_q2_reg = (mp1_adma64cmd_abort_q2_reg & ~mp1_Adma64Cmd_Abort_Q2_RI_Offset_MASK) | (ri_offset << mp1_Adma64Cmd_Abort_Q2_RI_Offset_SHIFT)
#define mp1_Adma64Cmd_Abort_Q2_SET_RI_Offset_Valid(mp1_adma64cmd_abort_q2_reg, ri_offset_valid) \
      mp1_adma64cmd_abort_q2_reg = (mp1_adma64cmd_abort_q2_reg & ~mp1_Adma64Cmd_Abort_Q2_RI_Offset_Valid_MASK) | (ri_offset_valid << mp1_Adma64Cmd_Abort_Q2_RI_Offset_Valid_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_abort_q2_t {
            unsigned int ri_offset                      : mp1_Adma64Cmd_Abort_Q2_RI_Offset_SIZE;
            unsigned int                                : 13;
            unsigned int ri_offset_valid                : mp1_Adma64Cmd_Abort_Q2_RI_Offset_Valid_SIZE;
      } mp1_adma64cmd_abort_q2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_abort_q2_t {
            unsigned int ri_offset_valid                : mp1_Adma64Cmd_Abort_Q2_RI_Offset_Valid_SIZE;
            unsigned int                                : 13;
            unsigned int ri_offset                      : mp1_Adma64Cmd_Abort_Q2_RI_Offset_SIZE;
      } mp1_adma64cmd_abort_q2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_abort_q2_t f;
} mp1_adma64cmd_abort_q2_u;


/*
 * mp1_Adma64Cmd_AxCACHE_Q2 struct
 */

#define mp1_Adma64Cmd_AxCACHE_Q2_REG_SIZE         32
#define mp1_Adma64Cmd_AxCACHE_Q2_RI_AWCACHE_SIZE  4
#define mp1_Adma64Cmd_AxCACHE_Q2_RI_ARCACHE_SIZE  4
#define mp1_Adma64Cmd_AxCACHE_Q2_RI_VCD_ARCACHE_SIZE  4

#define mp1_Adma64Cmd_AxCACHE_Q2_RI_AWCACHE_SHIFT  0
#define mp1_Adma64Cmd_AxCACHE_Q2_RI_ARCACHE_SHIFT  4
#define mp1_Adma64Cmd_AxCACHE_Q2_RI_VCD_ARCACHE_SHIFT  8

#define mp1_Adma64Cmd_AxCACHE_Q2_RI_AWCACHE_MASK  0x0000000f
#define mp1_Adma64Cmd_AxCACHE_Q2_RI_ARCACHE_MASK  0x000000f0
#define mp1_Adma64Cmd_AxCACHE_Q2_RI_VCD_ARCACHE_MASK  0x00000f00

#define mp1_Adma64Cmd_AxCACHE_Q2_MASK \
      (mp1_Adma64Cmd_AxCACHE_Q2_RI_AWCACHE_MASK | \
      mp1_Adma64Cmd_AxCACHE_Q2_RI_ARCACHE_MASK | \
      mp1_Adma64Cmd_AxCACHE_Q2_RI_VCD_ARCACHE_MASK)

#define mp1_Adma64Cmd_AxCACHE_Q2_DEFAULT 0x00000000

#define mp1_Adma64Cmd_AxCACHE_Q2_GET_RI_AWCACHE(mp1_adma64cmd_axcache_q2) \
      ((mp1_adma64cmd_axcache_q2 & mp1_Adma64Cmd_AxCACHE_Q2_RI_AWCACHE_MASK) >> mp1_Adma64Cmd_AxCACHE_Q2_RI_AWCACHE_SHIFT)
#define mp1_Adma64Cmd_AxCACHE_Q2_GET_RI_ARCACHE(mp1_adma64cmd_axcache_q2) \
      ((mp1_adma64cmd_axcache_q2 & mp1_Adma64Cmd_AxCACHE_Q2_RI_ARCACHE_MASK) >> mp1_Adma64Cmd_AxCACHE_Q2_RI_ARCACHE_SHIFT)
#define mp1_Adma64Cmd_AxCACHE_Q2_GET_RI_VCD_ARCACHE(mp1_adma64cmd_axcache_q2) \
      ((mp1_adma64cmd_axcache_q2 & mp1_Adma64Cmd_AxCACHE_Q2_RI_VCD_ARCACHE_MASK) >> mp1_Adma64Cmd_AxCACHE_Q2_RI_VCD_ARCACHE_SHIFT)

#define mp1_Adma64Cmd_AxCACHE_Q2_SET_RI_AWCACHE(mp1_adma64cmd_axcache_q2_reg, ri_awcache) \
      mp1_adma64cmd_axcache_q2_reg = (mp1_adma64cmd_axcache_q2_reg & ~mp1_Adma64Cmd_AxCACHE_Q2_RI_AWCACHE_MASK) | (ri_awcache << mp1_Adma64Cmd_AxCACHE_Q2_RI_AWCACHE_SHIFT)
#define mp1_Adma64Cmd_AxCACHE_Q2_SET_RI_ARCACHE(mp1_adma64cmd_axcache_q2_reg, ri_arcache) \
      mp1_adma64cmd_axcache_q2_reg = (mp1_adma64cmd_axcache_q2_reg & ~mp1_Adma64Cmd_AxCACHE_Q2_RI_ARCACHE_MASK) | (ri_arcache << mp1_Adma64Cmd_AxCACHE_Q2_RI_ARCACHE_SHIFT)
#define mp1_Adma64Cmd_AxCACHE_Q2_SET_RI_VCD_ARCACHE(mp1_adma64cmd_axcache_q2_reg, ri_vcd_arcache) \
      mp1_adma64cmd_axcache_q2_reg = (mp1_adma64cmd_axcache_q2_reg & ~mp1_Adma64Cmd_AxCACHE_Q2_RI_VCD_ARCACHE_MASK) | (ri_vcd_arcache << mp1_Adma64Cmd_AxCACHE_Q2_RI_VCD_ARCACHE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_adma64cmd_axcache_q2_t {
            unsigned int ri_awcache                     : mp1_Adma64Cmd_AxCACHE_Q2_RI_AWCACHE_SIZE;
            unsigned int ri_arcache                     : mp1_Adma64Cmd_AxCACHE_Q2_RI_ARCACHE_SIZE;
            unsigned int ri_vcd_arcache                 : mp1_Adma64Cmd_AxCACHE_Q2_RI_VCD_ARCACHE_SIZE;
            unsigned int                                : 20;
      } mp1_adma64cmd_axcache_q2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_adma64cmd_axcache_q2_t {
            unsigned int                                : 20;
            unsigned int ri_vcd_arcache                 : mp1_Adma64Cmd_AxCACHE_Q2_RI_VCD_ARCACHE_SIZE;
            unsigned int ri_arcache                     : mp1_Adma64Cmd_AxCACHE_Q2_RI_ARCACHE_SIZE;
            unsigned int ri_awcache                     : mp1_Adma64Cmd_AxCACHE_Q2_RI_AWCACHE_SIZE;
      } mp1_adma64cmd_axcache_q2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_adma64cmd_axcache_q2_t f;
} mp1_adma64cmd_axcache_q2_u;


#endif

