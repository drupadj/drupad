// Copyright (c) 1994 - 2022 Advanced Micro Devices, Inc. All rights reserved.

#if !defined (_MP2_CRU_MASK_H)
#define _MP2_CRU_MASK_H

/*
 *    mp2_cru_mask.h   
 *
 *    Register Spec Release:  <unknown>
 *
 *
 *      (c) 2021 Advanced Micro Devices, Inc.  (unpublished)
 *
 *        All rights reserved.  This notice is intended as a precaution against
 *     inadvertent publication and does not imply publication or any waiver
 *      of confidentiality.  The year included in the foregoing notice is the
 *     year of creation of the work.
 *
 */

/*******************************************************
 * Read and Write Masks
 *******************************************************/

#define MP2_SMNIF_ERROR_READ_MASK      0xffffffff
#define MP2_SMNIF_ERROR_WRITE_MASK     0xffffffff

#define MP2_CRU_MISC_STATUS_READ_MASK  0xffffffff
#define MP2_CRU_MISC_STATUS_WRITE_MASK 0x00000000

#define MP2_FW_DEBUG_CNT0_READ_MASK    0xffffffff
#define MP2_FW_DEBUG_CNT0_WRITE_MASK   0xffffffff

#define MP2_FW_DEBUG_CNT1_READ_MASK    0xffffffff
#define MP2_FW_DEBUG_CNT1_WRITE_MASK   0xffffffff

#define MP2_FW_DEBUG_CNT2_READ_MASK    0xffffffff
#define MP2_FW_DEBUG_CNT2_WRITE_MASK   0xffffffff

#define MP2_FW_DEBUG_CNT3_READ_MASK    0xffffffff
#define MP2_FW_DEBUG_CNT3_WRITE_MASK   0xffffffff

#define MP2_FW_DEBUG_SIGNAL0_READ_MASK 0xffffffff
#define MP2_FW_DEBUG_SIGNAL0_WRITE_MASK 0xffffffff

#define MP2_FW_DEBUG_SIGNAL1_READ_MASK 0xffffffff
#define MP2_FW_DEBUG_SIGNAL1_WRITE_MASK 0xffffffff

#define MP2_DSM_ENABLE_READ_MASK       0x0000000f
#define MP2_DSM_ENABLE_WRITE_MASK      0x0000000f

#define MP2_FIRMWARE_FLAGS_READ_MASK   0xffffffff
#define MP2_FIRMWARE_FLAGS_WRITE_MASK  0xffffffff

#define MP2_MUTEX_0_READ_MASK          0x000000ff
#define MP2_MUTEX_0_WRITE_MASK         0x000000ff

#define MP2_MUTEX_1_READ_MASK          0x000000ff
#define MP2_MUTEX_1_WRITE_MASK         0x000000ff

#define MP2_MUTEX_2_READ_MASK          0x000000ff
#define MP2_MUTEX_2_WRITE_MASK         0x000000ff

#define MP2_MUTEX_3_READ_MASK          0x000000ff
#define MP2_MUTEX_3_WRITE_MASK         0x000000ff

#define MP2_MISC_STATUS_READ_MASK      0xffffffff
#define MP2_MISC_STATUS_WRITE_MASK     0x00000000

#define MP2_PUB_ECO0_READ_MASK         0xffffffff
#define MP2_PUB_ECO0_WRITE_MASK        0xffffffff

#define MP2_PUB_ECO1_READ_MASK         0xffffffff
#define MP2_PUB_ECO1_WRITE_MASK        0xffffffff

#define MP2_PUB_ECO2_READ_MASK         0xffffffff
#define MP2_PUB_ECO2_WRITE_MASK        0xffffffff

#define MP2_PUB_ECO3_READ_MASK         0xffffffff
#define MP2_PUB_ECO3_WRITE_MASK        0xffffffff

#define MP2_PUB_SCRATCH0_READ_MASK     0xffffffff
#define MP2_PUB_SCRATCH0_WRITE_MASK    0xffffffff

#define MP2_PUB_SCRATCH1_READ_MASK     0xffffffff
#define MP2_PUB_SCRATCH1_WRITE_MASK    0xffffffff

#define MP2_PUB_SCRATCH2_READ_MASK     0xffffffff
#define MP2_PUB_SCRATCH2_WRITE_MASK    0xffffffff

#define MP2_PUB_SCRATCH3_READ_MASK     0xffffffff
#define MP2_PUB_SCRATCH3_WRITE_MASK    0xffffffff

#define MP2_DFIFO_PUSH_READ_MASK       0x00000000
#define MP2_DFIFO_PUSH_WRITE_MASK      0xffffffff

#define MP2_DFIFO_POP_READ_MASK        0xffffffff
#define MP2_DFIFO_POP_WRITE_MASK       0x00000000

#define MP2_DFIFO_STATUS_READ_MASK     0x0000033f
#define MP2_DFIFO_STATUS_WRITE_MASK    0x00000000

#define MP2_DFIFO_FLUSH_READ_MASK      0x00000000
#define MP2_DFIFO_FLUSH_WRITE_MASK     0xffffffff

#define MP2_C2PMSG_0_READ_MASK         0xffffffff
#define MP2_C2PMSG_0_WRITE_MASK        0xffffffff

#define MP2_C2PMSG_1_READ_MASK         0xffffffff
#define MP2_C2PMSG_1_WRITE_MASK        0xffffffff

#define MP2_C2PMSG_2_READ_MASK         0xffffffff
#define MP2_C2PMSG_2_WRITE_MASK        0xffffffff

#define MP2_C2PMSG_3_READ_MASK         0xffffffff
#define MP2_C2PMSG_3_WRITE_MASK        0xffffffff

#define MP2_C2PMSG_4_READ_MASK         0xffffffff
#define MP2_C2PMSG_4_WRITE_MASK        0xffffffff

#define MP2_C2PMSG_5_READ_MASK         0xffffffff
#define MP2_C2PMSG_5_WRITE_MASK        0xffffffff

#define MP2_C2PMSG_6_READ_MASK         0xffffffff
#define MP2_C2PMSG_6_WRITE_MASK        0xffffffff

#define MP2_C2PMSG_7_READ_MASK         0xffffffff
#define MP2_C2PMSG_7_WRITE_MASK        0xffffffff

#define MP2_C2PMSG_8_READ_MASK         0xffffffff
#define MP2_C2PMSG_8_WRITE_MASK        0xffffffff

#define MP2_C2PMSG_9_READ_MASK         0xffffffff
#define MP2_C2PMSG_9_WRITE_MASK        0xffffffff

#define MP2_C2PMSG_10_READ_MASK        0xffffffff
#define MP2_C2PMSG_10_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_11_READ_MASK        0xffffffff
#define MP2_C2PMSG_11_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_12_READ_MASK        0xffffffff
#define MP2_C2PMSG_12_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_13_READ_MASK        0xffffffff
#define MP2_C2PMSG_13_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_14_READ_MASK        0xffffffff
#define MP2_C2PMSG_14_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_15_READ_MASK        0xffffffff
#define MP2_C2PMSG_15_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_16_READ_MASK        0xffffffff
#define MP2_C2PMSG_16_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_17_READ_MASK        0xffffffff
#define MP2_C2PMSG_17_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_18_READ_MASK        0xffffffff
#define MP2_C2PMSG_18_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_19_READ_MASK        0xffffffff
#define MP2_C2PMSG_19_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_20_READ_MASK        0xffffffff
#define MP2_C2PMSG_20_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_21_READ_MASK        0xffffffff
#define MP2_C2PMSG_21_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_22_READ_MASK        0xffffffff
#define MP2_C2PMSG_22_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_23_READ_MASK        0xffffffff
#define MP2_C2PMSG_23_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_24_READ_MASK        0xffffffff
#define MP2_C2PMSG_24_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_25_READ_MASK        0xffffffff
#define MP2_C2PMSG_25_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_26_READ_MASK        0xffffffff
#define MP2_C2PMSG_26_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_27_READ_MASK        0xffffffff
#define MP2_C2PMSG_27_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_28_READ_MASK        0xffffffff
#define MP2_C2PMSG_28_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_29_READ_MASK        0xffffffff
#define MP2_C2PMSG_29_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_30_READ_MASK        0xffffffff
#define MP2_C2PMSG_30_WRITE_MASK       0xffffffff

#define MP2_C2PMSG_31_READ_MASK        0xffffffff
#define MP2_C2PMSG_31_WRITE_MASK       0xffffffff

#define MP2_P2CMSG_0_READ_MASK         0xffffffff
#define MP2_P2CMSG_0_WRITE_MASK        0xffffffff

#define MP2_P2CMSG_1_READ_MASK         0xffffffff
#define MP2_P2CMSG_1_WRITE_MASK        0xffffffff

#define MP2_P2CMSG_2_READ_MASK         0xffffffff
#define MP2_P2CMSG_2_WRITE_MASK        0xffffffff

#define MP2_P2CMSG_3_READ_MASK         0xffffffff
#define MP2_P2CMSG_3_WRITE_MASK        0xffffffff

#define MP2_P2CMSG_INTEN_READ_MASK     0x0000000f
#define MP2_P2CMSG_INTEN_WRITE_MASK    0x0000000f

#define MP2_P2CMSG_INTSTS_READ_MASK    0x0000000f
#define MP2_P2CMSG_INTSTS_WRITE_MASK   0x0000000f

#define MP2_P2SMSG_0_READ_MASK         0xffffffff
#define MP2_P2SMSG_0_WRITE_MASK        0xffffffff

#define MP2_P2SMSG_1_READ_MASK         0xffffffff
#define MP2_P2SMSG_1_WRITE_MASK        0xffffffff

#define MP2_P2SMSG_2_READ_MASK         0xffffffff
#define MP2_P2SMSG_2_WRITE_MASK        0xffffffff

#define MP2_P2SMSG_3_READ_MASK         0xffffffff
#define MP2_P2SMSG_3_WRITE_MASK        0xffffffff

#define MP2_P2SMSG_INTSTS_READ_MASK    0x0000000f
#define MP2_P2SMSG_INTSTS_WRITE_MASK   0x0000000f

#define MP2_S2PMSG_0_READ_MASK         0xffffffff
#define MP2_S2PMSG_0_WRITE_MASK        0xffffffff

#define MP2_IH_CREDIT_READ_MASK        0x00000000
#define MP2_IH_CREDIT_WRITE_MASK       0x00ff0003

#define MP2_IH_SW_INT_READ_MASK        0x000001ff
#define MP2_IH_SW_INT_WRITE_MASK       0x000001ff

#define MP2_IH_SW_INT_CTRL_READ_MASK   0x00000001
#define MP2_IH_SW_INT_CTRL_WRITE_MASK  0x00000101

#define MP2_REVID_READ_MASK            0xffffffff
#define MP2_REVID_WRITE_MASK           0xffffffff

#define MP2_CPU_HARVEST_ENB_READ_MASK  0x00000001
#define MP2_CPU_HARVEST_ENB_WRITE_MASK 0x00000000

#define MP2_RAM_REPAIR_DONE_READ_MASK  0xffffffff
#define MP2_RAM_REPAIR_DONE_WRITE_MASK 0xffffffff

#define MP2_RAM_REPAIR_RESULT_READ_MASK 0xffffffff
#define MP2_RAM_REPAIR_RESULT_WRITE_MASK 0xffffffff

#define MP2_FUSE_HARVESTING_READ_MASK  0xffffffff
#define MP2_FUSE_HARVESTING_WRITE_MASK 0xffffffff

#define MP2_ACC_VIO_INTSTS_READ_MASK   0xffffffff
#define MP2_ACC_VIO_INTSTS_WRITE_MASK  0xffffffff

#define MP2_TDR_MISC0_STATUS_READ_MASK 0xffffffff
#define MP2_TDR_MISC0_STATUS_WRITE_MASK 0x00000000

#define MP2_FW_OVERRIDE_READ_MASK      0xffffffff
#define MP2_FW_OVERRIDE_WRITE_MASK     0xffffffff

#define MP2_CRU_CPU_CTRL_STS_READ_MASK 0xffffffff
#define MP2_CRU_CPU_CTRL_STS_WRITE_MASK 0xffffffff

#define MP2_J2P_MBOX0_READ_MASK        0xffffffff
#define MP2_J2P_MBOX0_WRITE_MASK       0xffffffff

#define MP2_J2P_MBOX1_READ_MASK        0xffffffff
#define MP2_J2P_MBOX1_WRITE_MASK       0xffffffff

#define MP2_J2P_ATTR_READ_MASK         0x00000003
#define MP2_J2P_ATTR_WRITE_MASK        0x00000003

#define MP2_CRU_ACC_VIO_INTSTS_READ_MASK 0xffffffff
#define MP2_CRU_ACC_VIO_INTSTS_WRITE_MASK 0xffffffff

#define MP2_ACC_VIOL_LOG0_READ_MASK    0x7fffffff
#define MP2_ACC_VIOL_LOG0_WRITE_MASK   0x80000000

#define MP2_ACC_VIOL_LOG1_READ_MASK    0xffffffff
#define MP2_ACC_VIOL_LOG1_WRITE_MASK   0x00000000

#define MP2_STICKY_READ_MASK           0xffffffff
#define MP2_STICKY_WRITE_MASK          0xffffffff

#define MP2_CRU_MISC_CTRL_READ_MASK    0x75010003
#define MP2_CRU_MISC_CTRL_WRITE_MASK   0x75010003

#define MP2_SOFT_RESET_CTRL_READ_MASK  0x0040a017
#define MP2_SOFT_RESET_CTRL_WRITE_MASK 0x0040a017

#define MP2_NS_PROT_FAULT_STATUS_0_READ_MASK 0x00000013
#define MP2_NS_PROT_FAULT_STATUS_0_WRITE_MASK 0x00000013

#define MP2_SEC_SCRATCH0_READ_MASK     0xffffffff
#define MP2_SEC_SCRATCH0_WRITE_MASK    0xffffffff

#define MP2_SEC_SCRATCH1_READ_MASK     0xffffffff
#define MP2_SEC_SCRATCH1_WRITE_MASK    0xffffffff

#define MP2_SEC_SCRATCH2_READ_MASK     0xffffffff
#define MP2_SEC_SCRATCH2_WRITE_MASK    0xffffffff

#define MP2_SEC_SCRATCH3_READ_MASK     0xffffffff
#define MP2_SEC_SCRATCH3_WRITE_MASK    0xffffffff

#define MP2_SEC_ECO0_READ_MASK         0xffffffff
#define MP2_SEC_ECO0_WRITE_MASK        0xffffffff

#define MP2_SEC_ECO1_READ_MASK         0xffffffff
#define MP2_SEC_ECO1_WRITE_MASK        0xffffffff

#define MP2_SEC_ECO2_READ_MASK         0xffffffff
#define MP2_SEC_ECO2_WRITE_MASK        0xffffffff

#define MP2_SEC_ECO3_READ_MASK         0xffffffff
#define MP2_SEC_ECO3_WRITE_MASK        0xffffffff

#define MP2_VIRT_INITID0_GRP0_READ_MASK 0x03ff03ff
#define MP2_VIRT_INITID0_GRP0_WRITE_MASK 0x03ff03ff

#define MP2_VIRT_INITID1_GRP0_READ_MASK 0x03ff03ff
#define MP2_VIRT_INITID1_GRP0_WRITE_MASK 0x03ff03ff

#define MP2_VIRT_INITID0_GRP1_READ_MASK 0x03ff03ff
#define MP2_VIRT_INITID0_GRP1_WRITE_MASK 0x03ff03ff

#define MP2_VIRT_INITID1_GRP1_READ_MASK 0x03ff03ff
#define MP2_VIRT_INITID1_GRP1_WRITE_MASK 0x03ff03ff

#define MP2_VIRT_INITID0_GRP2_READ_MASK 0x03ff03ff
#define MP2_VIRT_INITID0_GRP2_WRITE_MASK 0x03ff03ff

#define MP2_VIRT_INITID1_GRP2_READ_MASK 0x03ff03ff
#define MP2_VIRT_INITID1_GRP2_WRITE_MASK 0x03ff03ff

#define MP2_VIRT_INITID0_GRP3_READ_MASK 0x03ff03ff
#define MP2_VIRT_INITID0_GRP3_WRITE_MASK 0x03ff03ff

#define MP2_VIRT_INITID1_GRP3_READ_MASK 0x03ff03ff
#define MP2_VIRT_INITID1_GRP3_WRITE_MASK 0x03ff03ff

#define MP2_VIRT_INITID_GRP0_CTRL_READ_MASK 0x0000010f
#define MP2_VIRT_INITID_GRP0_CTRL_WRITE_MASK 0x0000010f

#define MP2_VIRT_INITID_GRP1_CTRL_READ_MASK 0x0000010f
#define MP2_VIRT_INITID_GRP1_CTRL_WRITE_MASK 0x0000010f

#define MP2_VIRT_INITID_GRP2_CTRL_READ_MASK 0x0000010f
#define MP2_VIRT_INITID_GRP2_CTRL_WRITE_MASK 0x0000010f

#define MP2_VIRT_INITID_GRP3_CTRL_READ_MASK 0x0000010f
#define MP2_VIRT_INITID_GRP3_CTRL_WRITE_MASK 0x0000010f

#define MP2_IH_CLIENT_ID_READ_MASK     0x000000ff
#define MP2_IH_CLIENT_ID_WRITE_MASK    0x000000ff

#define MP2_IH_CREDIT_CNT_READ_MASK    0x00000003
#define MP2_IH_CREDIT_CNT_WRITE_MASK   0x00010100

#define MP2_I2C_REFCLK_CG_CTRL_READ_MASK 0x00000001
#define MP2_I2C_REFCLK_CG_CTRL_WRITE_MASK 0x00000001

#define S5_MISC_CTRL_READ_MASK         0x000000f3
#define S5_MISC_CTRL_WRITE_MASK        0x000000d3

#define M4_INT_CTRL_READ_MASK          0x00000007
#define M4_INT_CTRL_WRITE_MASK         0x00000007

#define MP2_FW_MISC_CTRL_READ_MASK     0xffffffff
#define MP2_FW_MISC_CTRL_WRITE_MASK    0xffffffff

#define MP2_AEB_STATUS_0_READ_MASK     0x0000000f
#define MP2_AEB_STATUS_0_WRITE_MASK    0x00000000

#define MP2_FW_CHRONO_LO_READ_MASK     0xffffffff
#define MP2_FW_CHRONO_LO_WRITE_MASK    0x00000000

#define MP2_FW_CHRONO_HI_READ_MASK     0xffffffff
#define MP2_FW_CHRONO_HI_WRITE_MASK    0x00000000

#define MP2_PIC0_MASK_0_READ_MASK      0xffffffff
#define MP2_PIC0_MASK_0_WRITE_MASK     0xffffffff

#define MP2_PIC0_MASK_1_READ_MASK      0xffffffff
#define MP2_PIC0_MASK_1_WRITE_MASK     0xffffffff

#define MP2_PIC0_MASK_2_READ_MASK      0xffffffff
#define MP2_PIC0_MASK_2_WRITE_MASK     0xffffffff

#define MP2_PIC0_MASK_3_READ_MASK      0xffffffff
#define MP2_PIC0_MASK_3_WRITE_MASK     0xffffffff

#define MP2_PIC0_LEVEL_0_READ_MASK     0xffffffff
#define MP2_PIC0_LEVEL_0_WRITE_MASK    0xffffffff

#define MP2_PIC0_LEVEL_1_READ_MASK     0xffffffff
#define MP2_PIC0_LEVEL_1_WRITE_MASK    0xffffffff

#define MP2_PIC0_LEVEL_2_READ_MASK     0xffffffff
#define MP2_PIC0_LEVEL_2_WRITE_MASK    0xffffffff

#define MP2_PIC0_LEVEL_3_READ_MASK     0xffffffff
#define MP2_PIC0_LEVEL_3_WRITE_MASK    0xffffffff

#define MP2_PIC0_EDGE_0_READ_MASK      0xffffffff
#define MP2_PIC0_EDGE_0_WRITE_MASK     0xffffffff

#define MP2_PIC0_EDGE_1_READ_MASK      0xffffffff
#define MP2_PIC0_EDGE_1_WRITE_MASK     0xffffffff

#define MP2_PIC0_EDGE_2_READ_MASK      0xffffffff
#define MP2_PIC0_EDGE_2_WRITE_MASK     0xffffffff

#define MP2_PIC0_EDGE_3_READ_MASK      0xffffffff
#define MP2_PIC0_EDGE_3_WRITE_MASK     0xffffffff

#define MP2_PIC0_PRIORITY_0_READ_MASK  0xffffffff
#define MP2_PIC0_PRIORITY_0_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_1_READ_MASK  0xffffffff
#define MP2_PIC0_PRIORITY_1_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_2_READ_MASK  0xffffffff
#define MP2_PIC0_PRIORITY_2_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_3_READ_MASK  0xffffffff
#define MP2_PIC0_PRIORITY_3_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_4_READ_MASK  0xffffffff
#define MP2_PIC0_PRIORITY_4_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_5_READ_MASK  0xffffffff
#define MP2_PIC0_PRIORITY_5_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_6_READ_MASK  0xffffffff
#define MP2_PIC0_PRIORITY_6_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_7_READ_MASK  0xffffffff
#define MP2_PIC0_PRIORITY_7_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_8_READ_MASK  0xffffffff
#define MP2_PIC0_PRIORITY_8_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_9_READ_MASK  0xffffffff
#define MP2_PIC0_PRIORITY_9_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_10_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_10_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_11_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_11_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_12_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_12_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_13_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_13_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_14_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_14_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_15_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_15_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_16_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_16_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_17_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_17_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_18_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_18_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_19_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_19_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_20_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_20_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_21_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_21_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_22_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_22_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_23_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_23_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_24_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_24_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_25_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_25_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_26_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_26_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_27_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_27_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_28_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_28_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_29_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_29_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_30_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_30_WRITE_MASK 0xffffffff

#define MP2_PIC0_PRIORITY_31_READ_MASK 0xffffffff
#define MP2_PIC0_PRIORITY_31_WRITE_MASK 0xffffffff

#define MP2_PIC0_STATUS_0_READ_MASK    0xffffffff
#define MP2_PIC0_STATUS_0_WRITE_MASK   0xffffffff

#define MP2_PIC0_STATUS_1_READ_MASK    0xffffffff
#define MP2_PIC0_STATUS_1_WRITE_MASK   0xffffffff

#define MP2_PIC0_STATUS_2_READ_MASK    0xffffffff
#define MP2_PIC0_STATUS_2_WRITE_MASK   0xffffffff

#define MP2_PIC0_STATUS_3_READ_MASK    0xffffffff
#define MP2_PIC0_STATUS_3_WRITE_MASK   0xffffffff

#define MP2_PIC0_INTR_READ_MASK        0xffffffff
#define MP2_PIC0_INTR_WRITE_MASK       0x00000000

#define MP2_PIC0_ID_READ_MASK          0xffffffff
#define MP2_PIC0_ID_WRITE_MASK         0x00000000

#define MP2_TIMER_0_CTRL0_READ_MASK    0x01010101
#define MP2_TIMER_0_CTRL0_WRITE_MASK   0x01010101

#define MP2_TIMER_0_CTRL1_READ_MASK    0xff010101
#define MP2_TIMER_0_CTRL1_WRITE_MASK   0x00010101

#define MP2_TIMER_0_CMP_AUTOINC_READ_MASK 0xffffffff
#define MP2_TIMER_0_CMP_AUTOINC_WRITE_MASK 0x0000000f

#define MP2_TIMER_0_INTEN_READ_MASK    0xffffffff
#define MP2_TIMER_0_INTEN_WRITE_MASK   0x0000000f

#define MP2_TIMER_OCMP_0_0_READ_MASK   0xffffffff
#define MP2_TIMER_OCMP_0_0_WRITE_MASK  0xffffffff

#define MP2_TIMER_OCMP_0_1_READ_MASK   0xffffffff
#define MP2_TIMER_OCMP_0_1_WRITE_MASK  0xffffffff

#define MP2_TIMER_OCMP_0_2_READ_MASK   0xffffffff
#define MP2_TIMER_OCMP_0_2_WRITE_MASK  0xffffffff

#define MP2_TIMER_OCMP_0_3_READ_MASK   0xffffffff
#define MP2_TIMER_OCMP_0_3_WRITE_MASK  0xffffffff

#define MP2_TIMER_0_CNT_READ_MASK      0xffffffff
#define MP2_TIMER_0_CNT_WRITE_MASK     0x00000000

#define MP2_TIMER_1_CTRL0_READ_MASK    0x01010101
#define MP2_TIMER_1_CTRL0_WRITE_MASK   0x01010101

#define MP2_TIMER_1_CTRL1_READ_MASK    0xff010101
#define MP2_TIMER_1_CTRL1_WRITE_MASK   0x00010101

#define MP2_TIMER_1_CMP_AUTOINC_READ_MASK 0xffffffff
#define MP2_TIMER_1_CMP_AUTOINC_WRITE_MASK 0x0000000f

#define MP2_TIMER_1_INTEN_READ_MASK    0xffffffff
#define MP2_TIMER_1_INTEN_WRITE_MASK   0x0000000f

#define MP2_TIMER_OCMP_1_0_READ_MASK   0xffffffff
#define MP2_TIMER_OCMP_1_0_WRITE_MASK  0xffffffff

#define MP2_TIMER_OCMP_1_1_READ_MASK   0xffffffff
#define MP2_TIMER_OCMP_1_1_WRITE_MASK  0xffffffff

#define MP2_TIMER_OCMP_1_2_READ_MASK   0xffffffff
#define MP2_TIMER_OCMP_1_2_WRITE_MASK  0xffffffff

#define MP2_TIMER_OCMP_1_3_READ_MASK   0xffffffff
#define MP2_TIMER_OCMP_1_3_WRITE_MASK  0xffffffff

#define MP2_TIMER_1_CNT_READ_MASK      0xffffffff
#define MP2_TIMER_1_CNT_WRITE_MASK     0x00000000

#define MP2_TIMER_2_CTRL0_READ_MASK    0x01010101
#define MP2_TIMER_2_CTRL0_WRITE_MASK   0x01010101

#define MP2_TIMER_2_CTRL1_READ_MASK    0xff010101
#define MP2_TIMER_2_CTRL1_WRITE_MASK   0x00010101

#define MP2_TIMER_2_CMP_AUTOINC_READ_MASK 0xffffffff
#define MP2_TIMER_2_CMP_AUTOINC_WRITE_MASK 0x0000000f

#define MP2_TIMER_2_INTEN_READ_MASK    0xffffffff
#define MP2_TIMER_2_INTEN_WRITE_MASK   0x0000000f

#define MP2_TIMER_OCMP_2_0_READ_MASK   0xffffffff
#define MP2_TIMER_OCMP_2_0_WRITE_MASK  0xffffffff

#define MP2_TIMER_OCMP_2_1_READ_MASK   0xffffffff
#define MP2_TIMER_OCMP_2_1_WRITE_MASK  0xffffffff

#define MP2_TIMER_OCMP_2_2_READ_MASK   0xffffffff
#define MP2_TIMER_OCMP_2_2_WRITE_MASK  0xffffffff

#define MP2_TIMER_OCMP_2_3_READ_MASK   0xffffffff
#define MP2_TIMER_OCMP_2_3_WRITE_MASK  0xffffffff

#define MP2_TIMER_2_CNT_READ_MASK      0xffffffff
#define MP2_TIMER_2_CNT_WRITE_MASK     0x00000000

#define MP2_TIMER_3_CTRL0_READ_MASK    0x01010101
#define MP2_TIMER_3_CTRL0_WRITE_MASK   0x01010101

#define MP2_TIMER_3_CTRL1_READ_MASK    0xff010101
#define MP2_TIMER_3_CTRL1_WRITE_MASK   0x00010101

#define MP2_TIMER_3_CMP_AUTOINC_READ_MASK 0xffffffff
#define MP2_TIMER_3_CMP_AUTOINC_WRITE_MASK 0x0000000f

#define MP2_TIMER_3_INTEN_READ_MASK    0xffffffff
#define MP2_TIMER_3_INTEN_WRITE_MASK   0x0000000f

#define MP2_TIMER_OCMP_3_0_READ_MASK   0xffffffff
#define MP2_TIMER_OCMP_3_0_WRITE_MASK  0xffffffff

#define MP2_TIMER_OCMP_3_1_READ_MASK   0xffffffff
#define MP2_TIMER_OCMP_3_1_WRITE_MASK  0xffffffff

#define MP2_TIMER_OCMP_3_2_READ_MASK   0xffffffff
#define MP2_TIMER_OCMP_3_2_WRITE_MASK  0xffffffff

#define MP2_TIMER_OCMP_3_3_READ_MASK   0xffffffff
#define MP2_TIMER_OCMP_3_3_WRITE_MASK  0xffffffff

#define MP2_TIMER_3_CNT_READ_MASK      0xffffffff
#define MP2_TIMER_3_CNT_WRITE_MASK     0x00000000

#define MP2_P2CMSG_ATTR_READ_MASK      0x000000ff
#define MP2_P2CMSG_ATTR_WRITE_MASK     0x000000ff

#define MP2_C2PMSG_ATTR_0_READ_MASK    0xffffffff
#define MP2_C2PMSG_ATTR_0_WRITE_MASK   0xffffffff

#define MP2_C2PMSG_ATTR_1_READ_MASK    0xffffffff
#define MP2_C2PMSG_ATTR_1_WRITE_MASK   0xffffffff

#define MP2_S2PMSG_ATTR_READ_MASK      0x00000003
#define MP2_S2PMSG_ATTR_WRITE_MASK     0x00000003

#define MP2_P2SMSG_ATTR_READ_MASK      0x000000ff
#define MP2_P2SMSG_ATTR_WRITE_MASK     0x000000ff

#endif


