// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_RSMU_MPCCP_FIDDLE_H)
#define _RSMU_MPCCP_FIDDLE_H

/*****************************************************************************************************************
 *
 *	rsmu_mpccp_reg.h
 *
 *	Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif


/*******************************************************
 * Values
 *******************************************************/


/*******************************************************
 * Structures
 *******************************************************/

/*
 * RSMU_HARD_RESETB_MPCCP struct
 */

#define RSMU_HARD_RESETB_MPCCP_REG_SIZE 32
#define RSMU_HARD_RESETB_MPCCP_RSMU_HARD_RESETB_SIZE 2
#define RSMU_HARD_RESETB_MPCCP_RSMU_MASTER_HARD_RESET_FENCE_ENABLE_SIZE 2
#define RSMU_HARD_RESETB_MPCCP_RSMU_SLAVE_HARD_RESET_TIMEOUT_ENABLE_SIZE 2

#define RSMU_HARD_RESETB_MPCCP_RSMU_HARD_RESETB_SHIFT 0
#define RSMU_HARD_RESETB_MPCCP_RSMU_MASTER_HARD_RESET_FENCE_ENABLE_SHIFT 2
#define RSMU_HARD_RESETB_MPCCP_RSMU_SLAVE_HARD_RESET_TIMEOUT_ENABLE_SHIFT 5

#define RSMU_HARD_RESETB_MPCCP_RSMU_HARD_RESETB_MASK 0x3
#define RSMU_HARD_RESETB_MPCCP_RSMU_MASTER_HARD_RESET_FENCE_ENABLE_MASK 0xc
#define RSMU_HARD_RESETB_MPCCP_RSMU_SLAVE_HARD_RESET_TIMEOUT_ENABLE_MASK 0x60

#define RSMU_HARD_RESETB_MPCCP_MASK \
     (RSMU_HARD_RESETB_MPCCP_RSMU_HARD_RESETB_MASK | \
      RSMU_HARD_RESETB_MPCCP_RSMU_MASTER_HARD_RESET_FENCE_ENABLE_MASK | \
      RSMU_HARD_RESETB_MPCCP_RSMU_SLAVE_HARD_RESET_TIMEOUT_ENABLE_MASK)

#define RSMU_HARD_RESETB_MPCCP_DEFAULT 0x00000000

#define RSMU_HARD_RESETB_MPCCP_GET_RSMU_HARD_RESETB(rsmu_hard_resetb_mpccp) \
     ((rsmu_hard_resetb_mpccp & RSMU_HARD_RESETB_MPCCP_RSMU_HARD_RESETB_MASK) >> RSMU_HARD_RESETB_MPCCP_RSMU_HARD_RESETB_SHIFT)
#define RSMU_HARD_RESETB_MPCCP_GET_RSMU_MASTER_HARD_RESET_FENCE_ENABLE(rsmu_hard_resetb_mpccp) \
     ((rsmu_hard_resetb_mpccp & RSMU_HARD_RESETB_MPCCP_RSMU_MASTER_HARD_RESET_FENCE_ENABLE_MASK) >> RSMU_HARD_RESETB_MPCCP_RSMU_MASTER_HARD_RESET_FENCE_ENABLE_SHIFT)
#define RSMU_HARD_RESETB_MPCCP_GET_RSMU_SLAVE_HARD_RESET_TIMEOUT_ENABLE(rsmu_hard_resetb_mpccp) \
     ((rsmu_hard_resetb_mpccp & RSMU_HARD_RESETB_MPCCP_RSMU_SLAVE_HARD_RESET_TIMEOUT_ENABLE_MASK) >> RSMU_HARD_RESETB_MPCCP_RSMU_SLAVE_HARD_RESET_TIMEOUT_ENABLE_SHIFT)

#define RSMU_HARD_RESETB_MPCCP_SET_RSMU_HARD_RESETB(rsmu_hard_resetb_mpccp_reg, rsmu_hard_resetb) \
     rsmu_hard_resetb_mpccp_reg = (rsmu_hard_resetb_mpccp_reg & ~RSMU_HARD_RESETB_MPCCP_RSMU_HARD_RESETB_MASK) | (rsmu_hard_resetb << RSMU_HARD_RESETB_MPCCP_RSMU_HARD_RESETB_SHIFT)
#define RSMU_HARD_RESETB_MPCCP_SET_RSMU_MASTER_HARD_RESET_FENCE_ENABLE(rsmu_hard_resetb_mpccp_reg, rsmu_master_hard_reset_fence_enable) \
     rsmu_hard_resetb_mpccp_reg = (rsmu_hard_resetb_mpccp_reg & ~RSMU_HARD_RESETB_MPCCP_RSMU_MASTER_HARD_RESET_FENCE_ENABLE_MASK) | (rsmu_master_hard_reset_fence_enable << RSMU_HARD_RESETB_MPCCP_RSMU_MASTER_HARD_RESET_FENCE_ENABLE_SHIFT)
#define RSMU_HARD_RESETB_MPCCP_SET_RSMU_SLAVE_HARD_RESET_TIMEOUT_ENABLE(rsmu_hard_resetb_mpccp_reg, rsmu_slave_hard_reset_timeout_enable) \
     rsmu_hard_resetb_mpccp_reg = (rsmu_hard_resetb_mpccp_reg & ~RSMU_HARD_RESETB_MPCCP_RSMU_SLAVE_HARD_RESET_TIMEOUT_ENABLE_MASK) | (rsmu_slave_hard_reset_timeout_enable << RSMU_HARD_RESETB_MPCCP_RSMU_SLAVE_HARD_RESET_TIMEOUT_ENABLE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_hard_resetb_mpccp_t {
          unsigned int rsmu_hard_resetb               : RSMU_HARD_RESETB_MPCCP_RSMU_HARD_RESETB_SIZE;
          unsigned int rsmu_master_hard_reset_fence_enable : RSMU_HARD_RESETB_MPCCP_RSMU_MASTER_HARD_RESET_FENCE_ENABLE_SIZE;
          unsigned int                                : 1;
          unsigned int rsmu_slave_hard_reset_timeout_enable : RSMU_HARD_RESETB_MPCCP_RSMU_SLAVE_HARD_RESET_TIMEOUT_ENABLE_SIZE;
          unsigned int                                : 25;
     } rsmu_hard_resetb_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_hard_resetb_mpccp_t {
          unsigned int                                : 25;
          unsigned int rsmu_slave_hard_reset_timeout_enable : RSMU_HARD_RESETB_MPCCP_RSMU_SLAVE_HARD_RESET_TIMEOUT_ENABLE_SIZE;
          unsigned int                                : 1;
          unsigned int rsmu_master_hard_reset_fence_enable : RSMU_HARD_RESETB_MPCCP_RSMU_MASTER_HARD_RESET_FENCE_ENABLE_SIZE;
          unsigned int rsmu_hard_resetb               : RSMU_HARD_RESETB_MPCCP_RSMU_HARD_RESETB_SIZE;
     } rsmu_hard_resetb_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_hard_resetb_mpccp_t f;
} rsmu_hard_resetb_mpccp_u;


/*
 * RSMU_MEM_POWER_CTRL_MPCCP struct
 */

#define RSMU_MEM_POWER_CTRL_MPCCP_REG_SIZE 32
#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_FUSE_RM_FUSES_SIZE 12
#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_FUSE_CUSTOM_RM_FUSES_SIZE 14
#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_PDP_BC1_SIZE 1
#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_PDP_BC2_SIZE 1
#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_HD_BC1_SIZE 1
#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_HD_BC2_SIZE 1
#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_LIVMIN_DIS_SRAM_SIZE 1

#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_FUSE_RM_FUSES_SHIFT 0
#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_FUSE_CUSTOM_RM_FUSES_SHIFT 12
#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_PDP_BC1_SHIFT 26
#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_PDP_BC2_SHIFT 27
#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_HD_BC1_SHIFT 28
#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_HD_BC2_SHIFT 29
#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_LIVMIN_DIS_SRAM_SHIFT 30

#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_FUSE_RM_FUSES_MASK 0xfff
#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_FUSE_CUSTOM_RM_FUSES_MASK 0x3fff000
#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_PDP_BC1_MASK 0x4000000
#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_PDP_BC2_MASK 0x8000000
#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_HD_BC1_MASK 0x10000000
#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_HD_BC2_MASK 0x20000000
#define RSMU_MEM_POWER_CTRL_MPCCP_RSMU_LIVMIN_DIS_SRAM_MASK 0x40000000

#define RSMU_MEM_POWER_CTRL_MPCCP_MASK \
     (RSMU_MEM_POWER_CTRL_MPCCP_RSMU_FUSE_RM_FUSES_MASK | \
      RSMU_MEM_POWER_CTRL_MPCCP_RSMU_FUSE_CUSTOM_RM_FUSES_MASK | \
      RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_PDP_BC1_MASK | \
      RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_PDP_BC2_MASK | \
      RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_HD_BC1_MASK | \
      RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_HD_BC2_MASK | \
      RSMU_MEM_POWER_CTRL_MPCCP_RSMU_LIVMIN_DIS_SRAM_MASK)

#define RSMU_MEM_POWER_CTRL_MPCCP_DEFAULT 0x14000000

#define RSMU_MEM_POWER_CTRL_MPCCP_GET_RSMU_FUSE_RM_FUSES(rsmu_mem_power_ctrl_mpccp) \
     ((rsmu_mem_power_ctrl_mpccp & RSMU_MEM_POWER_CTRL_MPCCP_RSMU_FUSE_RM_FUSES_MASK) >> RSMU_MEM_POWER_CTRL_MPCCP_RSMU_FUSE_RM_FUSES_SHIFT)
#define RSMU_MEM_POWER_CTRL_MPCCP_GET_RSMU_FUSE_CUSTOM_RM_FUSES(rsmu_mem_power_ctrl_mpccp) \
     ((rsmu_mem_power_ctrl_mpccp & RSMU_MEM_POWER_CTRL_MPCCP_RSMU_FUSE_CUSTOM_RM_FUSES_MASK) >> RSMU_MEM_POWER_CTRL_MPCCP_RSMU_FUSE_CUSTOM_RM_FUSES_SHIFT)
#define RSMU_MEM_POWER_CTRL_MPCCP_GET_RSMU_MEM_POWER_CTRL_PDP_BC1(rsmu_mem_power_ctrl_mpccp) \
     ((rsmu_mem_power_ctrl_mpccp & RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_PDP_BC1_MASK) >> RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_PDP_BC1_SHIFT)
#define RSMU_MEM_POWER_CTRL_MPCCP_GET_RSMU_MEM_POWER_CTRL_PDP_BC2(rsmu_mem_power_ctrl_mpccp) \
     ((rsmu_mem_power_ctrl_mpccp & RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_PDP_BC2_MASK) >> RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_PDP_BC2_SHIFT)
#define RSMU_MEM_POWER_CTRL_MPCCP_GET_RSMU_MEM_POWER_CTRL_HD_BC1(rsmu_mem_power_ctrl_mpccp) \
     ((rsmu_mem_power_ctrl_mpccp & RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_HD_BC1_MASK) >> RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_HD_BC1_SHIFT)
#define RSMU_MEM_POWER_CTRL_MPCCP_GET_RSMU_MEM_POWER_CTRL_HD_BC2(rsmu_mem_power_ctrl_mpccp) \
     ((rsmu_mem_power_ctrl_mpccp & RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_HD_BC2_MASK) >> RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_HD_BC2_SHIFT)
#define RSMU_MEM_POWER_CTRL_MPCCP_GET_RSMU_LIVMIN_DIS_SRAM(rsmu_mem_power_ctrl_mpccp) \
     ((rsmu_mem_power_ctrl_mpccp & RSMU_MEM_POWER_CTRL_MPCCP_RSMU_LIVMIN_DIS_SRAM_MASK) >> RSMU_MEM_POWER_CTRL_MPCCP_RSMU_LIVMIN_DIS_SRAM_SHIFT)

#define RSMU_MEM_POWER_CTRL_MPCCP_SET_RSMU_FUSE_RM_FUSES(rsmu_mem_power_ctrl_mpccp_reg, rsmu_fuse_rm_fuses) \
     rsmu_mem_power_ctrl_mpccp_reg = (rsmu_mem_power_ctrl_mpccp_reg & ~RSMU_MEM_POWER_CTRL_MPCCP_RSMU_FUSE_RM_FUSES_MASK) | (rsmu_fuse_rm_fuses << RSMU_MEM_POWER_CTRL_MPCCP_RSMU_FUSE_RM_FUSES_SHIFT)
#define RSMU_MEM_POWER_CTRL_MPCCP_SET_RSMU_FUSE_CUSTOM_RM_FUSES(rsmu_mem_power_ctrl_mpccp_reg, rsmu_fuse_custom_rm_fuses) \
     rsmu_mem_power_ctrl_mpccp_reg = (rsmu_mem_power_ctrl_mpccp_reg & ~RSMU_MEM_POWER_CTRL_MPCCP_RSMU_FUSE_CUSTOM_RM_FUSES_MASK) | (rsmu_fuse_custom_rm_fuses << RSMU_MEM_POWER_CTRL_MPCCP_RSMU_FUSE_CUSTOM_RM_FUSES_SHIFT)
#define RSMU_MEM_POWER_CTRL_MPCCP_SET_RSMU_MEM_POWER_CTRL_PDP_BC1(rsmu_mem_power_ctrl_mpccp_reg, rsmu_mem_power_ctrl_pdp_bc1) \
     rsmu_mem_power_ctrl_mpccp_reg = (rsmu_mem_power_ctrl_mpccp_reg & ~RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_PDP_BC1_MASK) | (rsmu_mem_power_ctrl_pdp_bc1 << RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_PDP_BC1_SHIFT)
#define RSMU_MEM_POWER_CTRL_MPCCP_SET_RSMU_MEM_POWER_CTRL_PDP_BC2(rsmu_mem_power_ctrl_mpccp_reg, rsmu_mem_power_ctrl_pdp_bc2) \
     rsmu_mem_power_ctrl_mpccp_reg = (rsmu_mem_power_ctrl_mpccp_reg & ~RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_PDP_BC2_MASK) | (rsmu_mem_power_ctrl_pdp_bc2 << RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_PDP_BC2_SHIFT)
#define RSMU_MEM_POWER_CTRL_MPCCP_SET_RSMU_MEM_POWER_CTRL_HD_BC1(rsmu_mem_power_ctrl_mpccp_reg, rsmu_mem_power_ctrl_hd_bc1) \
     rsmu_mem_power_ctrl_mpccp_reg = (rsmu_mem_power_ctrl_mpccp_reg & ~RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_HD_BC1_MASK) | (rsmu_mem_power_ctrl_hd_bc1 << RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_HD_BC1_SHIFT)
#define RSMU_MEM_POWER_CTRL_MPCCP_SET_RSMU_MEM_POWER_CTRL_HD_BC2(rsmu_mem_power_ctrl_mpccp_reg, rsmu_mem_power_ctrl_hd_bc2) \
     rsmu_mem_power_ctrl_mpccp_reg = (rsmu_mem_power_ctrl_mpccp_reg & ~RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_HD_BC2_MASK) | (rsmu_mem_power_ctrl_hd_bc2 << RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_HD_BC2_SHIFT)
#define RSMU_MEM_POWER_CTRL_MPCCP_SET_RSMU_LIVMIN_DIS_SRAM(rsmu_mem_power_ctrl_mpccp_reg, rsmu_livmin_dis_sram) \
     rsmu_mem_power_ctrl_mpccp_reg = (rsmu_mem_power_ctrl_mpccp_reg & ~RSMU_MEM_POWER_CTRL_MPCCP_RSMU_LIVMIN_DIS_SRAM_MASK) | (rsmu_livmin_dis_sram << RSMU_MEM_POWER_CTRL_MPCCP_RSMU_LIVMIN_DIS_SRAM_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_mem_power_ctrl_mpccp_t {
          unsigned int rsmu_fuse_rm_fuses             : RSMU_MEM_POWER_CTRL_MPCCP_RSMU_FUSE_RM_FUSES_SIZE;
          unsigned int rsmu_fuse_custom_rm_fuses      : RSMU_MEM_POWER_CTRL_MPCCP_RSMU_FUSE_CUSTOM_RM_FUSES_SIZE;
          unsigned int rsmu_mem_power_ctrl_pdp_bc1    : RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_PDP_BC1_SIZE;
          unsigned int rsmu_mem_power_ctrl_pdp_bc2    : RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_PDP_BC2_SIZE;
          unsigned int rsmu_mem_power_ctrl_hd_bc1     : RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_HD_BC1_SIZE;
          unsigned int rsmu_mem_power_ctrl_hd_bc2     : RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_HD_BC2_SIZE;
          unsigned int rsmu_livmin_dis_sram           : RSMU_MEM_POWER_CTRL_MPCCP_RSMU_LIVMIN_DIS_SRAM_SIZE;
          unsigned int                                : 1;
     } rsmu_mem_power_ctrl_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_mem_power_ctrl_mpccp_t {
          unsigned int                                : 1;
          unsigned int rsmu_livmin_dis_sram           : RSMU_MEM_POWER_CTRL_MPCCP_RSMU_LIVMIN_DIS_SRAM_SIZE;
          unsigned int rsmu_mem_power_ctrl_hd_bc2     : RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_HD_BC2_SIZE;
          unsigned int rsmu_mem_power_ctrl_hd_bc1     : RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_HD_BC1_SIZE;
          unsigned int rsmu_mem_power_ctrl_pdp_bc2    : RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_PDP_BC2_SIZE;
          unsigned int rsmu_mem_power_ctrl_pdp_bc1    : RSMU_MEM_POWER_CTRL_MPCCP_RSMU_MEM_POWER_CTRL_PDP_BC1_SIZE;
          unsigned int rsmu_fuse_custom_rm_fuses      : RSMU_MEM_POWER_CTRL_MPCCP_RSMU_FUSE_CUSTOM_RM_FUSES_SIZE;
          unsigned int rsmu_fuse_rm_fuses             : RSMU_MEM_POWER_CTRL_MPCCP_RSMU_FUSE_RM_FUSES_SIZE;
     } rsmu_mem_power_ctrl_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_mem_power_ctrl_mpccp_t f;
} rsmu_mem_power_ctrl_mpccp_u;


/*
 * RSMU_SMS_FUSE_CFG_MPCCP struct
 */

#define RSMU_SMS_FUSE_CFG_MPCCP_REG_SIZE 32
#define RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RESETB_SIZE 1
#define RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RUN_BIHR_SIZE 1
#define RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RUN_MBIST_SIZE 1
#define RSMU_SMS_FUSE_CFG_MPCCP_RSMU_FISO_RESET_SIZE 1
#define RSMU_SMS_FUSE_CFG_MPCCP_RSMU_FISO_SET_SIZE 1

#define RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RESETB_SHIFT 0
#define RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RUN_BIHR_SHIFT 1
#define RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RUN_MBIST_SHIFT 2
#define RSMU_SMS_FUSE_CFG_MPCCP_RSMU_FISO_RESET_SHIFT 3
#define RSMU_SMS_FUSE_CFG_MPCCP_RSMU_FISO_SET_SHIFT 4

#define RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RESETB_MASK 0x1
#define RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RUN_BIHR_MASK 0x2
#define RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RUN_MBIST_MASK 0x4
#define RSMU_SMS_FUSE_CFG_MPCCP_RSMU_FISO_RESET_MASK 0x8
#define RSMU_SMS_FUSE_CFG_MPCCP_RSMU_FISO_SET_MASK 0x10

#define RSMU_SMS_FUSE_CFG_MPCCP_MASK \
     (RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RESETB_MASK | \
      RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RUN_BIHR_MASK | \
      RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RUN_MBIST_MASK | \
      RSMU_SMS_FUSE_CFG_MPCCP_RSMU_FISO_RESET_MASK | \
      RSMU_SMS_FUSE_CFG_MPCCP_RSMU_FISO_SET_MASK)

#define RSMU_SMS_FUSE_CFG_MPCCP_DEFAULT 0x00000000

#define RSMU_SMS_FUSE_CFG_MPCCP_GET_RSMU_SMS_FUSE_RESETB(rsmu_sms_fuse_cfg_mpccp) \
     ((rsmu_sms_fuse_cfg_mpccp & RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RESETB_MASK) >> RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RESETB_SHIFT)
#define RSMU_SMS_FUSE_CFG_MPCCP_GET_RSMU_SMS_FUSE_RUN_BIHR(rsmu_sms_fuse_cfg_mpccp) \
     ((rsmu_sms_fuse_cfg_mpccp & RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RUN_BIHR_MASK) >> RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RUN_BIHR_SHIFT)
#define RSMU_SMS_FUSE_CFG_MPCCP_GET_RSMU_SMS_FUSE_RUN_MBIST(rsmu_sms_fuse_cfg_mpccp) \
     ((rsmu_sms_fuse_cfg_mpccp & RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RUN_MBIST_MASK) >> RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RUN_MBIST_SHIFT)
#define RSMU_SMS_FUSE_CFG_MPCCP_GET_RSMU_FISO_RESET(rsmu_sms_fuse_cfg_mpccp) \
     ((rsmu_sms_fuse_cfg_mpccp & RSMU_SMS_FUSE_CFG_MPCCP_RSMU_FISO_RESET_MASK) >> RSMU_SMS_FUSE_CFG_MPCCP_RSMU_FISO_RESET_SHIFT)
#define RSMU_SMS_FUSE_CFG_MPCCP_GET_RSMU_FISO_SET(rsmu_sms_fuse_cfg_mpccp) \
     ((rsmu_sms_fuse_cfg_mpccp & RSMU_SMS_FUSE_CFG_MPCCP_RSMU_FISO_SET_MASK) >> RSMU_SMS_FUSE_CFG_MPCCP_RSMU_FISO_SET_SHIFT)

#define RSMU_SMS_FUSE_CFG_MPCCP_SET_RSMU_SMS_FUSE_RESETB(rsmu_sms_fuse_cfg_mpccp_reg, rsmu_sms_fuse_resetb) \
     rsmu_sms_fuse_cfg_mpccp_reg = (rsmu_sms_fuse_cfg_mpccp_reg & ~RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RESETB_MASK) | (rsmu_sms_fuse_resetb << RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RESETB_SHIFT)
#define RSMU_SMS_FUSE_CFG_MPCCP_SET_RSMU_SMS_FUSE_RUN_BIHR(rsmu_sms_fuse_cfg_mpccp_reg, rsmu_sms_fuse_run_bihr) \
     rsmu_sms_fuse_cfg_mpccp_reg = (rsmu_sms_fuse_cfg_mpccp_reg & ~RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RUN_BIHR_MASK) | (rsmu_sms_fuse_run_bihr << RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RUN_BIHR_SHIFT)
#define RSMU_SMS_FUSE_CFG_MPCCP_SET_RSMU_SMS_FUSE_RUN_MBIST(rsmu_sms_fuse_cfg_mpccp_reg, rsmu_sms_fuse_run_mbist) \
     rsmu_sms_fuse_cfg_mpccp_reg = (rsmu_sms_fuse_cfg_mpccp_reg & ~RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RUN_MBIST_MASK) | (rsmu_sms_fuse_run_mbist << RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RUN_MBIST_SHIFT)
#define RSMU_SMS_FUSE_CFG_MPCCP_SET_RSMU_FISO_RESET(rsmu_sms_fuse_cfg_mpccp_reg, rsmu_fiso_reset) \
     rsmu_sms_fuse_cfg_mpccp_reg = (rsmu_sms_fuse_cfg_mpccp_reg & ~RSMU_SMS_FUSE_CFG_MPCCP_RSMU_FISO_RESET_MASK) | (rsmu_fiso_reset << RSMU_SMS_FUSE_CFG_MPCCP_RSMU_FISO_RESET_SHIFT)
#define RSMU_SMS_FUSE_CFG_MPCCP_SET_RSMU_FISO_SET(rsmu_sms_fuse_cfg_mpccp_reg, rsmu_fiso_set) \
     rsmu_sms_fuse_cfg_mpccp_reg = (rsmu_sms_fuse_cfg_mpccp_reg & ~RSMU_SMS_FUSE_CFG_MPCCP_RSMU_FISO_SET_MASK) | (rsmu_fiso_set << RSMU_SMS_FUSE_CFG_MPCCP_RSMU_FISO_SET_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sms_fuse_cfg_mpccp_t {
          unsigned int rsmu_sms_fuse_resetb           : RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RESETB_SIZE;
          unsigned int rsmu_sms_fuse_run_bihr         : RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RUN_BIHR_SIZE;
          unsigned int rsmu_sms_fuse_run_mbist        : RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RUN_MBIST_SIZE;
          unsigned int rsmu_fiso_reset                : RSMU_SMS_FUSE_CFG_MPCCP_RSMU_FISO_RESET_SIZE;
          unsigned int rsmu_fiso_set                  : RSMU_SMS_FUSE_CFG_MPCCP_RSMU_FISO_SET_SIZE;
          unsigned int                                : 27;
     } rsmu_sms_fuse_cfg_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sms_fuse_cfg_mpccp_t {
          unsigned int                                : 27;
          unsigned int rsmu_fiso_set                  : RSMU_SMS_FUSE_CFG_MPCCP_RSMU_FISO_SET_SIZE;
          unsigned int rsmu_fiso_reset                : RSMU_SMS_FUSE_CFG_MPCCP_RSMU_FISO_RESET_SIZE;
          unsigned int rsmu_sms_fuse_run_mbist        : RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RUN_MBIST_SIZE;
          unsigned int rsmu_sms_fuse_run_bihr         : RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RUN_BIHR_SIZE;
          unsigned int rsmu_sms_fuse_resetb           : RSMU_SMS_FUSE_CFG_MPCCP_RSMU_SMS_FUSE_RESETB_SIZE;
     } rsmu_sms_fuse_cfg_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sms_fuse_cfg_mpccp_t f;
} rsmu_sms_fuse_cfg_mpccp_u;


/*
 * RSMU_SMS_FUSE_ADDR_BASE_MPCCP struct
 */

#define RSMU_SMS_FUSE_ADDR_BASE_MPCCP_REG_SIZE 32
#define RSMU_SMS_FUSE_ADDR_BASE_MPCCP_RSMU_SMS_FUSE_ADDR_BASE_SIZE 20

#define RSMU_SMS_FUSE_ADDR_BASE_MPCCP_RSMU_SMS_FUSE_ADDR_BASE_SHIFT 0

#define RSMU_SMS_FUSE_ADDR_BASE_MPCCP_RSMU_SMS_FUSE_ADDR_BASE_MASK 0xfffff

#define RSMU_SMS_FUSE_ADDR_BASE_MPCCP_MASK \
     (RSMU_SMS_FUSE_ADDR_BASE_MPCCP_RSMU_SMS_FUSE_ADDR_BASE_MASK)

#define RSMU_SMS_FUSE_ADDR_BASE_MPCCP_DEFAULT 0x00000000

#define RSMU_SMS_FUSE_ADDR_BASE_MPCCP_GET_RSMU_SMS_FUSE_ADDR_BASE(rsmu_sms_fuse_addr_base_mpccp) \
     ((rsmu_sms_fuse_addr_base_mpccp & RSMU_SMS_FUSE_ADDR_BASE_MPCCP_RSMU_SMS_FUSE_ADDR_BASE_MASK) >> RSMU_SMS_FUSE_ADDR_BASE_MPCCP_RSMU_SMS_FUSE_ADDR_BASE_SHIFT)

#define RSMU_SMS_FUSE_ADDR_BASE_MPCCP_SET_RSMU_SMS_FUSE_ADDR_BASE(rsmu_sms_fuse_addr_base_mpccp_reg, rsmu_sms_fuse_addr_base) \
     rsmu_sms_fuse_addr_base_mpccp_reg = (rsmu_sms_fuse_addr_base_mpccp_reg & ~RSMU_SMS_FUSE_ADDR_BASE_MPCCP_RSMU_SMS_FUSE_ADDR_BASE_MASK) | (rsmu_sms_fuse_addr_base << RSMU_SMS_FUSE_ADDR_BASE_MPCCP_RSMU_SMS_FUSE_ADDR_BASE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sms_fuse_addr_base_mpccp_t {
          unsigned int rsmu_sms_fuse_addr_base        : RSMU_SMS_FUSE_ADDR_BASE_MPCCP_RSMU_SMS_FUSE_ADDR_BASE_SIZE;
          unsigned int                                : 12;
     } rsmu_sms_fuse_addr_base_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sms_fuse_addr_base_mpccp_t {
          unsigned int                                : 12;
          unsigned int rsmu_sms_fuse_addr_base        : RSMU_SMS_FUSE_ADDR_BASE_MPCCP_RSMU_SMS_FUSE_ADDR_BASE_SIZE;
     } rsmu_sms_fuse_addr_base_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sms_fuse_addr_base_mpccp_t f;
} rsmu_sms_fuse_addr_base_mpccp_u;


/*
 * RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP struct
 */

#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_REG_SIZE 32
#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0_SIZE 8
#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1_SIZE 8
#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2_SIZE 8
#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3_SIZE 8

#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0_SHIFT 0
#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1_SHIFT 8
#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2_SHIFT 16
#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3_SHIFT 24

#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0_MASK 0xff
#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1_MASK 0xff00
#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2_MASK 0xff0000
#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3_MASK 0xff000000

#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_MASK \
     (RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0_MASK | \
      RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1_MASK | \
      RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2_MASK | \
      RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3_MASK)

#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_DEFAULT 0x00000000

#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_GET_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0(rsmu_sms_fuse_addr_offset_mpccp) \
     ((rsmu_sms_fuse_addr_offset_mpccp & RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0_MASK) >> RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0_SHIFT)
#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_GET_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1(rsmu_sms_fuse_addr_offset_mpccp) \
     ((rsmu_sms_fuse_addr_offset_mpccp & RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1_MASK) >> RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1_SHIFT)
#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_GET_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2(rsmu_sms_fuse_addr_offset_mpccp) \
     ((rsmu_sms_fuse_addr_offset_mpccp & RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2_MASK) >> RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2_SHIFT)
#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_GET_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3(rsmu_sms_fuse_addr_offset_mpccp) \
     ((rsmu_sms_fuse_addr_offset_mpccp & RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3_MASK) >> RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3_SHIFT)

#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_SET_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0(rsmu_sms_fuse_addr_offset_mpccp_reg, rsmu_sms_fuse_addr_offset_grp0) \
     rsmu_sms_fuse_addr_offset_mpccp_reg = (rsmu_sms_fuse_addr_offset_mpccp_reg & ~RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0_MASK) | (rsmu_sms_fuse_addr_offset_grp0 << RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0_SHIFT)
#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_SET_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1(rsmu_sms_fuse_addr_offset_mpccp_reg, rsmu_sms_fuse_addr_offset_grp1) \
     rsmu_sms_fuse_addr_offset_mpccp_reg = (rsmu_sms_fuse_addr_offset_mpccp_reg & ~RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1_MASK) | (rsmu_sms_fuse_addr_offset_grp1 << RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1_SHIFT)
#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_SET_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2(rsmu_sms_fuse_addr_offset_mpccp_reg, rsmu_sms_fuse_addr_offset_grp2) \
     rsmu_sms_fuse_addr_offset_mpccp_reg = (rsmu_sms_fuse_addr_offset_mpccp_reg & ~RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2_MASK) | (rsmu_sms_fuse_addr_offset_grp2 << RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2_SHIFT)
#define RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_SET_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3(rsmu_sms_fuse_addr_offset_mpccp_reg, rsmu_sms_fuse_addr_offset_grp3) \
     rsmu_sms_fuse_addr_offset_mpccp_reg = (rsmu_sms_fuse_addr_offset_mpccp_reg & ~RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3_MASK) | (rsmu_sms_fuse_addr_offset_grp3 << RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sms_fuse_addr_offset_mpccp_t {
          unsigned int rsmu_sms_fuse_addr_offset_grp0 : RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0_SIZE;
          unsigned int rsmu_sms_fuse_addr_offset_grp1 : RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1_SIZE;
          unsigned int rsmu_sms_fuse_addr_offset_grp2 : RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2_SIZE;
          unsigned int rsmu_sms_fuse_addr_offset_grp3 : RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3_SIZE;
     } rsmu_sms_fuse_addr_offset_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sms_fuse_addr_offset_mpccp_t {
          unsigned int rsmu_sms_fuse_addr_offset_grp3 : RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3_SIZE;
          unsigned int rsmu_sms_fuse_addr_offset_grp2 : RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2_SIZE;
          unsigned int rsmu_sms_fuse_addr_offset_grp1 : RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1_SIZE;
          unsigned int rsmu_sms_fuse_addr_offset_grp0 : RSMU_SMS_FUSE_ADDR_OFFSET_MPCCP_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0_SIZE;
     } rsmu_sms_fuse_addr_offset_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sms_fuse_addr_offset_mpccp_t f;
} rsmu_sms_fuse_addr_offset_mpccp_u;


/*
 * RSMU_STRAP_CONTROL_MPCCP struct
 */

#define RSMU_STRAP_CONTROL_MPCCP_REG_SIZE 32
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_READY_SIZE 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_VALID_SIZE 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_RELOAD_SIZE 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_READY_SIZE 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_VALID_SIZE 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_RELOAD_SIZE 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_PIN_RELOAD_SIZE 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SEC_FUSE_READY_SIZE 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SEC_FUSE_VALID_SIZE 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP0_SIZE 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP1_SIZE 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP2_SIZE 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP3_SIZE 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP0_SIZE 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP1_SIZE 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP2_SIZE 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP3_SIZE 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP0_SIZE 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP1_SIZE 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP2_SIZE 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP3_SIZE 1

#define RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_READY_SHIFT 0
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_VALID_SHIFT 1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_RELOAD_SHIFT 2
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_READY_SHIFT 3
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_VALID_SHIFT 4
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_RELOAD_SHIFT 5
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_PIN_RELOAD_SHIFT 6
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SEC_FUSE_READY_SHIFT 7
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SEC_FUSE_VALID_SHIFT 8
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP0_SHIFT 9
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP1_SHIFT 10
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP2_SHIFT 11
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP3_SHIFT 12
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP0_SHIFT 13
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP1_SHIFT 14
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP2_SHIFT 15
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP3_SHIFT 16
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP0_SHIFT 17
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP1_SHIFT 18
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP2_SHIFT 19
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP3_SHIFT 20

#define RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_READY_MASK 0x1
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_VALID_MASK 0x2
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_RELOAD_MASK 0x4
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_READY_MASK 0x8
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_VALID_MASK 0x10
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_RELOAD_MASK 0x20
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_PIN_RELOAD_MASK 0x40
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SEC_FUSE_READY_MASK 0x80
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SEC_FUSE_VALID_MASK 0x100
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP0_MASK 0x200
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP1_MASK 0x400
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP2_MASK 0x800
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP3_MASK 0x1000
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP0_MASK 0x2000
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP1_MASK 0x4000
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP2_MASK 0x8000
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP3_MASK 0x10000
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP0_MASK 0x20000
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP1_MASK 0x40000
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP2_MASK 0x80000
#define RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP3_MASK 0x100000

#define RSMU_STRAP_CONTROL_MPCCP_MASK \
     (RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_READY_MASK | \
      RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_VALID_MASK | \
      RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_RELOAD_MASK | \
      RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_READY_MASK | \
      RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_VALID_MASK | \
      RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_RELOAD_MASK | \
      RSMU_STRAP_CONTROL_MPCCP_RSMU_PIN_RELOAD_MASK | \
      RSMU_STRAP_CONTROL_MPCCP_RSMU_SEC_FUSE_READY_MASK | \
      RSMU_STRAP_CONTROL_MPCCP_RSMU_SEC_FUSE_VALID_MASK | \
      RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP0_MASK | \
      RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP1_MASK | \
      RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP2_MASK | \
      RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP3_MASK | \
      RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP0_MASK | \
      RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP1_MASK | \
      RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP2_MASK | \
      RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP3_MASK | \
      RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP0_MASK | \
      RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP1_MASK | \
      RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP2_MASK | \
      RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP3_MASK)

#define RSMU_STRAP_CONTROL_MPCCP_DEFAULT 0x00000000

#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_PUB_FUSE_READY(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_READY_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_READY_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_PUB_FUSE_VALID(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_VALID_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_VALID_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_PUB_FUSE_RELOAD(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_RELOAD_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_RELOAD_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_ROM_READY(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_READY_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_READY_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_ROM_VALID(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_VALID_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_VALID_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_ROM_RELOAD(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_RELOAD_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_RELOAD_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_PIN_RELOAD(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_PIN_RELOAD_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_PIN_RELOAD_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_SEC_FUSE_READY(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_SEC_FUSE_READY_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_SEC_FUSE_READY_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_SEC_FUSE_VALID(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_SEC_FUSE_VALID_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_SEC_FUSE_VALID_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_SMS_FUSE_READY_GRP0(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP0_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP0_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_SMS_FUSE_READY_GRP1(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP1_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP1_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_SMS_FUSE_READY_GRP2(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP2_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP2_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_SMS_FUSE_READY_GRP3(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP3_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP3_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_SMS_FUSE_VALID_GRP0(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP0_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP0_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_SMS_FUSE_VALID_GRP1(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP1_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP1_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_SMS_FUSE_VALID_GRP2(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP2_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP2_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_SMS_FUSE_VALID_GRP3(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP3_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP3_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_SMS_FUSE_BIST_FAIL_GRP0(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP0_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP0_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_SMS_FUSE_BIST_FAIL_GRP1(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP1_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP1_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_SMS_FUSE_BIST_FAIL_GRP2(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP2_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP2_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_GET_RSMU_SMS_FUSE_BIST_FAIL_GRP3(rsmu_strap_control_mpccp) \
     ((rsmu_strap_control_mpccp & RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP3_MASK) >> RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP3_SHIFT)

#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_PUB_FUSE_READY(rsmu_strap_control_mpccp_reg, rsmu_pub_fuse_ready) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_READY_MASK) | (rsmu_pub_fuse_ready << RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_READY_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_PUB_FUSE_VALID(rsmu_strap_control_mpccp_reg, rsmu_pub_fuse_valid) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_VALID_MASK) | (rsmu_pub_fuse_valid << RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_VALID_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_PUB_FUSE_RELOAD(rsmu_strap_control_mpccp_reg, rsmu_pub_fuse_reload) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_RELOAD_MASK) | (rsmu_pub_fuse_reload << RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_RELOAD_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_ROM_READY(rsmu_strap_control_mpccp_reg, rsmu_rom_ready) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_READY_MASK) | (rsmu_rom_ready << RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_READY_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_ROM_VALID(rsmu_strap_control_mpccp_reg, rsmu_rom_valid) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_VALID_MASK) | (rsmu_rom_valid << RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_VALID_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_ROM_RELOAD(rsmu_strap_control_mpccp_reg, rsmu_rom_reload) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_RELOAD_MASK) | (rsmu_rom_reload << RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_RELOAD_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_PIN_RELOAD(rsmu_strap_control_mpccp_reg, rsmu_pin_reload) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_PIN_RELOAD_MASK) | (rsmu_pin_reload << RSMU_STRAP_CONTROL_MPCCP_RSMU_PIN_RELOAD_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_SEC_FUSE_READY(rsmu_strap_control_mpccp_reg, rsmu_sec_fuse_ready) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_SEC_FUSE_READY_MASK) | (rsmu_sec_fuse_ready << RSMU_STRAP_CONTROL_MPCCP_RSMU_SEC_FUSE_READY_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_SEC_FUSE_VALID(rsmu_strap_control_mpccp_reg, rsmu_sec_fuse_valid) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_SEC_FUSE_VALID_MASK) | (rsmu_sec_fuse_valid << RSMU_STRAP_CONTROL_MPCCP_RSMU_SEC_FUSE_VALID_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_SMS_FUSE_READY_GRP0(rsmu_strap_control_mpccp_reg, rsmu_sms_fuse_ready_grp0) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP0_MASK) | (rsmu_sms_fuse_ready_grp0 << RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP0_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_SMS_FUSE_READY_GRP1(rsmu_strap_control_mpccp_reg, rsmu_sms_fuse_ready_grp1) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP1_MASK) | (rsmu_sms_fuse_ready_grp1 << RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP1_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_SMS_FUSE_READY_GRP2(rsmu_strap_control_mpccp_reg, rsmu_sms_fuse_ready_grp2) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP2_MASK) | (rsmu_sms_fuse_ready_grp2 << RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP2_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_SMS_FUSE_READY_GRP3(rsmu_strap_control_mpccp_reg, rsmu_sms_fuse_ready_grp3) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP3_MASK) | (rsmu_sms_fuse_ready_grp3 << RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP3_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_SMS_FUSE_VALID_GRP0(rsmu_strap_control_mpccp_reg, rsmu_sms_fuse_valid_grp0) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP0_MASK) | (rsmu_sms_fuse_valid_grp0 << RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP0_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_SMS_FUSE_VALID_GRP1(rsmu_strap_control_mpccp_reg, rsmu_sms_fuse_valid_grp1) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP1_MASK) | (rsmu_sms_fuse_valid_grp1 << RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP1_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_SMS_FUSE_VALID_GRP2(rsmu_strap_control_mpccp_reg, rsmu_sms_fuse_valid_grp2) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP2_MASK) | (rsmu_sms_fuse_valid_grp2 << RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP2_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_SMS_FUSE_VALID_GRP3(rsmu_strap_control_mpccp_reg, rsmu_sms_fuse_valid_grp3) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP3_MASK) | (rsmu_sms_fuse_valid_grp3 << RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP3_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_SMS_FUSE_BIST_FAIL_GRP0(rsmu_strap_control_mpccp_reg, rsmu_sms_fuse_bist_fail_grp0) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP0_MASK) | (rsmu_sms_fuse_bist_fail_grp0 << RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP0_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_SMS_FUSE_BIST_FAIL_GRP1(rsmu_strap_control_mpccp_reg, rsmu_sms_fuse_bist_fail_grp1) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP1_MASK) | (rsmu_sms_fuse_bist_fail_grp1 << RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP1_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_SMS_FUSE_BIST_FAIL_GRP2(rsmu_strap_control_mpccp_reg, rsmu_sms_fuse_bist_fail_grp2) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP2_MASK) | (rsmu_sms_fuse_bist_fail_grp2 << RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP2_SHIFT)
#define RSMU_STRAP_CONTROL_MPCCP_SET_RSMU_SMS_FUSE_BIST_FAIL_GRP3(rsmu_strap_control_mpccp_reg, rsmu_sms_fuse_bist_fail_grp3) \
     rsmu_strap_control_mpccp_reg = (rsmu_strap_control_mpccp_reg & ~RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP3_MASK) | (rsmu_sms_fuse_bist_fail_grp3 << RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_strap_control_mpccp_t {
          unsigned int rsmu_pub_fuse_ready            : RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_READY_SIZE;
          unsigned int rsmu_pub_fuse_valid            : RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_VALID_SIZE;
          unsigned int rsmu_pub_fuse_reload           : RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_RELOAD_SIZE;
          unsigned int rsmu_rom_ready                 : RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_READY_SIZE;
          unsigned int rsmu_rom_valid                 : RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_VALID_SIZE;
          unsigned int rsmu_rom_reload                : RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_RELOAD_SIZE;
          unsigned int rsmu_pin_reload                : RSMU_STRAP_CONTROL_MPCCP_RSMU_PIN_RELOAD_SIZE;
          unsigned int rsmu_sec_fuse_ready            : RSMU_STRAP_CONTROL_MPCCP_RSMU_SEC_FUSE_READY_SIZE;
          unsigned int rsmu_sec_fuse_valid            : RSMU_STRAP_CONTROL_MPCCP_RSMU_SEC_FUSE_VALID_SIZE;
          unsigned int rsmu_sms_fuse_ready_grp0       : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP0_SIZE;
          unsigned int rsmu_sms_fuse_ready_grp1       : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP1_SIZE;
          unsigned int rsmu_sms_fuse_ready_grp2       : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP2_SIZE;
          unsigned int rsmu_sms_fuse_ready_grp3       : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP3_SIZE;
          unsigned int rsmu_sms_fuse_valid_grp0       : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP0_SIZE;
          unsigned int rsmu_sms_fuse_valid_grp1       : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP1_SIZE;
          unsigned int rsmu_sms_fuse_valid_grp2       : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP2_SIZE;
          unsigned int rsmu_sms_fuse_valid_grp3       : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP3_SIZE;
          unsigned int rsmu_sms_fuse_bist_fail_grp0   : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP0_SIZE;
          unsigned int rsmu_sms_fuse_bist_fail_grp1   : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP1_SIZE;
          unsigned int rsmu_sms_fuse_bist_fail_grp2   : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP2_SIZE;
          unsigned int rsmu_sms_fuse_bist_fail_grp3   : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP3_SIZE;
          unsigned int                                : 11;
     } rsmu_strap_control_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_strap_control_mpccp_t {
          unsigned int                                : 11;
          unsigned int rsmu_sms_fuse_bist_fail_grp3   : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP3_SIZE;
          unsigned int rsmu_sms_fuse_bist_fail_grp2   : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP2_SIZE;
          unsigned int rsmu_sms_fuse_bist_fail_grp1   : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP1_SIZE;
          unsigned int rsmu_sms_fuse_bist_fail_grp0   : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_BIST_FAIL_GRP0_SIZE;
          unsigned int rsmu_sms_fuse_valid_grp3       : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP3_SIZE;
          unsigned int rsmu_sms_fuse_valid_grp2       : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP2_SIZE;
          unsigned int rsmu_sms_fuse_valid_grp1       : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP1_SIZE;
          unsigned int rsmu_sms_fuse_valid_grp0       : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_VALID_GRP0_SIZE;
          unsigned int rsmu_sms_fuse_ready_grp3       : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP3_SIZE;
          unsigned int rsmu_sms_fuse_ready_grp2       : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP2_SIZE;
          unsigned int rsmu_sms_fuse_ready_grp1       : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP1_SIZE;
          unsigned int rsmu_sms_fuse_ready_grp0       : RSMU_STRAP_CONTROL_MPCCP_RSMU_SMS_FUSE_READY_GRP0_SIZE;
          unsigned int rsmu_sec_fuse_valid            : RSMU_STRAP_CONTROL_MPCCP_RSMU_SEC_FUSE_VALID_SIZE;
          unsigned int rsmu_sec_fuse_ready            : RSMU_STRAP_CONTROL_MPCCP_RSMU_SEC_FUSE_READY_SIZE;
          unsigned int rsmu_pin_reload                : RSMU_STRAP_CONTROL_MPCCP_RSMU_PIN_RELOAD_SIZE;
          unsigned int rsmu_rom_reload                : RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_RELOAD_SIZE;
          unsigned int rsmu_rom_valid                 : RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_VALID_SIZE;
          unsigned int rsmu_rom_ready                 : RSMU_STRAP_CONTROL_MPCCP_RSMU_ROM_READY_SIZE;
          unsigned int rsmu_pub_fuse_reload           : RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_RELOAD_SIZE;
          unsigned int rsmu_pub_fuse_valid            : RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_VALID_SIZE;
          unsigned int rsmu_pub_fuse_ready            : RSMU_STRAP_CONTROL_MPCCP_RSMU_PUB_FUSE_READY_SIZE;
     } rsmu_strap_control_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_strap_control_mpccp_t f;
} rsmu_strap_control_mpccp_u;


/*
 * RSMU_HARD_RESETB_COMING_MPCCP struct
 */

#define RSMU_HARD_RESETB_COMING_MPCCP_REG_SIZE 32
#define RSMU_HARD_RESETB_COMING_MPCCP_RSMU_HARD_RESETB_COMING_SIZE 2

#define RSMU_HARD_RESETB_COMING_MPCCP_RSMU_HARD_RESETB_COMING_SHIFT 0

#define RSMU_HARD_RESETB_COMING_MPCCP_RSMU_HARD_RESETB_COMING_MASK 0x3

#define RSMU_HARD_RESETB_COMING_MPCCP_MASK \
     (RSMU_HARD_RESETB_COMING_MPCCP_RSMU_HARD_RESETB_COMING_MASK)

#define RSMU_HARD_RESETB_COMING_MPCCP_DEFAULT 0x00000000

#define RSMU_HARD_RESETB_COMING_MPCCP_GET_RSMU_HARD_RESETB_COMING(rsmu_hard_resetb_coming_mpccp) \
     ((rsmu_hard_resetb_coming_mpccp & RSMU_HARD_RESETB_COMING_MPCCP_RSMU_HARD_RESETB_COMING_MASK) >> RSMU_HARD_RESETB_COMING_MPCCP_RSMU_HARD_RESETB_COMING_SHIFT)

#define RSMU_HARD_RESETB_COMING_MPCCP_SET_RSMU_HARD_RESETB_COMING(rsmu_hard_resetb_coming_mpccp_reg, rsmu_hard_resetb_coming) \
     rsmu_hard_resetb_coming_mpccp_reg = (rsmu_hard_resetb_coming_mpccp_reg & ~RSMU_HARD_RESETB_COMING_MPCCP_RSMU_HARD_RESETB_COMING_MASK) | (rsmu_hard_resetb_coming << RSMU_HARD_RESETB_COMING_MPCCP_RSMU_HARD_RESETB_COMING_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_hard_resetb_coming_mpccp_t {
          unsigned int rsmu_hard_resetb_coming        : RSMU_HARD_RESETB_COMING_MPCCP_RSMU_HARD_RESETB_COMING_SIZE;
          unsigned int                                : 30;
     } rsmu_hard_resetb_coming_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_hard_resetb_coming_mpccp_t {
          unsigned int                                : 30;
          unsigned int rsmu_hard_resetb_coming        : RSMU_HARD_RESETB_COMING_MPCCP_RSMU_HARD_RESETB_COMING_SIZE;
     } rsmu_hard_resetb_coming_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_hard_resetb_coming_mpccp_t f;
} rsmu_hard_resetb_coming_mpccp_u;


/*
 * RSMU_MMIOPUB_SCRATCH_REG_0_MPCCP struct
 */

#define RSMU_MMIOPUB_SCRATCH_REG_0_MPCCP_REG_SIZE 32
#define RSMU_MMIOPUB_SCRATCH_REG_0_MPCCP_RSMU_MMIOPUB_SCRATCH_REG_0_SIZE 32

#define RSMU_MMIOPUB_SCRATCH_REG_0_MPCCP_RSMU_MMIOPUB_SCRATCH_REG_0_SHIFT 0

#define RSMU_MMIOPUB_SCRATCH_REG_0_MPCCP_RSMU_MMIOPUB_SCRATCH_REG_0_MASK 0xffffffff

#define RSMU_MMIOPUB_SCRATCH_REG_0_MPCCP_MASK \
     (RSMU_MMIOPUB_SCRATCH_REG_0_MPCCP_RSMU_MMIOPUB_SCRATCH_REG_0_MASK)

#define RSMU_MMIOPUB_SCRATCH_REG_0_MPCCP_DEFAULT 0x00000000

#define RSMU_MMIOPUB_SCRATCH_REG_0_MPCCP_GET_RSMU_MMIOPUB_SCRATCH_REG_0(rsmu_mmiopub_scratch_reg_0_mpccp) \
     ((rsmu_mmiopub_scratch_reg_0_mpccp & RSMU_MMIOPUB_SCRATCH_REG_0_MPCCP_RSMU_MMIOPUB_SCRATCH_REG_0_MASK) >> RSMU_MMIOPUB_SCRATCH_REG_0_MPCCP_RSMU_MMIOPUB_SCRATCH_REG_0_SHIFT)

#define RSMU_MMIOPUB_SCRATCH_REG_0_MPCCP_SET_RSMU_MMIOPUB_SCRATCH_REG_0(rsmu_mmiopub_scratch_reg_0_mpccp_reg, rsmu_mmiopub_scratch_reg_0) \
     rsmu_mmiopub_scratch_reg_0_mpccp_reg = (rsmu_mmiopub_scratch_reg_0_mpccp_reg & ~RSMU_MMIOPUB_SCRATCH_REG_0_MPCCP_RSMU_MMIOPUB_SCRATCH_REG_0_MASK) | (rsmu_mmiopub_scratch_reg_0 << RSMU_MMIOPUB_SCRATCH_REG_0_MPCCP_RSMU_MMIOPUB_SCRATCH_REG_0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_mmiopub_scratch_reg_0_mpccp_t {
          unsigned int rsmu_mmiopub_scratch_reg_0     : RSMU_MMIOPUB_SCRATCH_REG_0_MPCCP_RSMU_MMIOPUB_SCRATCH_REG_0_SIZE;
     } rsmu_mmiopub_scratch_reg_0_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_mmiopub_scratch_reg_0_mpccp_t {
          unsigned int rsmu_mmiopub_scratch_reg_0     : RSMU_MMIOPUB_SCRATCH_REG_0_MPCCP_RSMU_MMIOPUB_SCRATCH_REG_0_SIZE;
     } rsmu_mmiopub_scratch_reg_0_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_mmiopub_scratch_reg_0_mpccp_t f;
} rsmu_mmiopub_scratch_reg_0_mpccp_u;


/*
 * RSMU_VF_ENABLE_MPCCP struct
 */

#define RSMU_VF_ENABLE_MPCCP_REG_SIZE  32
#define RSMU_VF_ENABLE_MPCCP_RSMU_VF_ENABLE_SIZE 1

#define RSMU_VF_ENABLE_MPCCP_RSMU_VF_ENABLE_SHIFT 0

#define RSMU_VF_ENABLE_MPCCP_RSMU_VF_ENABLE_MASK 0x1

#define RSMU_VF_ENABLE_MPCCP_MASK \
     (RSMU_VF_ENABLE_MPCCP_RSMU_VF_ENABLE_MASK)

#define RSMU_VF_ENABLE_MPCCP_DEFAULT   0x00000000

#define RSMU_VF_ENABLE_MPCCP_GET_RSMU_VF_ENABLE(rsmu_vf_enable_mpccp) \
     ((rsmu_vf_enable_mpccp & RSMU_VF_ENABLE_MPCCP_RSMU_VF_ENABLE_MASK) >> RSMU_VF_ENABLE_MPCCP_RSMU_VF_ENABLE_SHIFT)

#define RSMU_VF_ENABLE_MPCCP_SET_RSMU_VF_ENABLE(rsmu_vf_enable_mpccp_reg, rsmu_vf_enable) \
     rsmu_vf_enable_mpccp_reg = (rsmu_vf_enable_mpccp_reg & ~RSMU_VF_ENABLE_MPCCP_RSMU_VF_ENABLE_MASK) | (rsmu_vf_enable << RSMU_VF_ENABLE_MPCCP_RSMU_VF_ENABLE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_vf_enable_mpccp_t {
          unsigned int rsmu_vf_enable                 : RSMU_VF_ENABLE_MPCCP_RSMU_VF_ENABLE_SIZE;
          unsigned int                                : 31;
     } rsmu_vf_enable_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_vf_enable_mpccp_t {
          unsigned int                                : 31;
          unsigned int rsmu_vf_enable                 : RSMU_VF_ENABLE_MPCCP_RSMU_VF_ENABLE_SIZE;
     } rsmu_vf_enable_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_vf_enable_mpccp_t f;
} rsmu_vf_enable_mpccp_u;


/*
 * RSMU_MGCG_CONTROL_MPCCP struct
 */

#define RSMU_MGCG_CONTROL_MPCCP_REG_SIZE 32
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_AXI_SLAVE_MGCG_OVERRIDE_SIZE 1
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_AXI_MASTER_MGCG_OVERRIDE_SIZE 1
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_SEC_INTR_MGCG_OVERRIDE_SIZE 1
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_PWRMGT_INTR_MGCG_OVERRIDE_SIZE 1
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_REG_WRAPPER_MGCG_OVERRIDE_SIZE 1
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_STRAP_MASTER_MGCG_OVERRIDE_SIZE 1
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_VWIRE_SRC_MGCG_OVERRIDE_SIZE 1
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_REGIF_MASTER_MGCG_OVERRIDE_SIZE 1
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_PGFSM_MGCG_OVERRIDE_SIZE 1
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_IH_MGCG_OVERRIDE_SIZE 1
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_SEM_MGCG_OVERRIDE_SIZE 1
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_DPM_MGCG_OVERRIDE_SIZE 1

#define RSMU_MGCG_CONTROL_MPCCP_RSMU_AXI_SLAVE_MGCG_OVERRIDE_SHIFT 0
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_AXI_MASTER_MGCG_OVERRIDE_SHIFT 1
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_SEC_INTR_MGCG_OVERRIDE_SHIFT 2
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_PWRMGT_INTR_MGCG_OVERRIDE_SHIFT 3
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_REG_WRAPPER_MGCG_OVERRIDE_SHIFT 4
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_STRAP_MASTER_MGCG_OVERRIDE_SHIFT 5
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_VWIRE_SRC_MGCG_OVERRIDE_SHIFT 6
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_REGIF_MASTER_MGCG_OVERRIDE_SHIFT 7
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_PGFSM_MGCG_OVERRIDE_SHIFT 8
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_IH_MGCG_OVERRIDE_SHIFT 9
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_SEM_MGCG_OVERRIDE_SHIFT 10
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_DPM_MGCG_OVERRIDE_SHIFT 11

#define RSMU_MGCG_CONTROL_MPCCP_RSMU_AXI_SLAVE_MGCG_OVERRIDE_MASK 0x1
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_AXI_MASTER_MGCG_OVERRIDE_MASK 0x2
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_SEC_INTR_MGCG_OVERRIDE_MASK 0x4
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_PWRMGT_INTR_MGCG_OVERRIDE_MASK 0x8
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_REG_WRAPPER_MGCG_OVERRIDE_MASK 0x10
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_STRAP_MASTER_MGCG_OVERRIDE_MASK 0x20
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_VWIRE_SRC_MGCG_OVERRIDE_MASK 0x40
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_REGIF_MASTER_MGCG_OVERRIDE_MASK 0x80
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_PGFSM_MGCG_OVERRIDE_MASK 0x100
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_IH_MGCG_OVERRIDE_MASK 0x200
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_SEM_MGCG_OVERRIDE_MASK 0x400
#define RSMU_MGCG_CONTROL_MPCCP_RSMU_DPM_MGCG_OVERRIDE_MASK 0x800

#define RSMU_MGCG_CONTROL_MPCCP_MASK \
     (RSMU_MGCG_CONTROL_MPCCP_RSMU_AXI_SLAVE_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MPCCP_RSMU_AXI_MASTER_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MPCCP_RSMU_SEC_INTR_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MPCCP_RSMU_PWRMGT_INTR_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MPCCP_RSMU_REG_WRAPPER_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MPCCP_RSMU_STRAP_MASTER_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MPCCP_RSMU_VWIRE_SRC_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MPCCP_RSMU_REGIF_MASTER_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MPCCP_RSMU_PGFSM_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MPCCP_RSMU_IH_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MPCCP_RSMU_SEM_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MPCCP_RSMU_DPM_MGCG_OVERRIDE_MASK)

#define RSMU_MGCG_CONTROL_MPCCP_DEFAULT 0x00000000

#define RSMU_MGCG_CONTROL_MPCCP_GET_RSMU_AXI_SLAVE_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp) \
     ((rsmu_mgcg_control_mpccp & RSMU_MGCG_CONTROL_MPCCP_RSMU_AXI_SLAVE_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MPCCP_RSMU_AXI_SLAVE_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_GET_RSMU_AXI_MASTER_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp) \
     ((rsmu_mgcg_control_mpccp & RSMU_MGCG_CONTROL_MPCCP_RSMU_AXI_MASTER_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MPCCP_RSMU_AXI_MASTER_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_GET_RSMU_SEC_INTR_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp) \
     ((rsmu_mgcg_control_mpccp & RSMU_MGCG_CONTROL_MPCCP_RSMU_SEC_INTR_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MPCCP_RSMU_SEC_INTR_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_GET_RSMU_PWRMGT_INTR_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp) \
     ((rsmu_mgcg_control_mpccp & RSMU_MGCG_CONTROL_MPCCP_RSMU_PWRMGT_INTR_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MPCCP_RSMU_PWRMGT_INTR_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_GET_RSMU_REG_WRAPPER_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp) \
     ((rsmu_mgcg_control_mpccp & RSMU_MGCG_CONTROL_MPCCP_RSMU_REG_WRAPPER_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MPCCP_RSMU_REG_WRAPPER_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_GET_RSMU_STRAP_MASTER_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp) \
     ((rsmu_mgcg_control_mpccp & RSMU_MGCG_CONTROL_MPCCP_RSMU_STRAP_MASTER_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MPCCP_RSMU_STRAP_MASTER_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_GET_RSMU_VWIRE_SRC_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp) \
     ((rsmu_mgcg_control_mpccp & RSMU_MGCG_CONTROL_MPCCP_RSMU_VWIRE_SRC_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MPCCP_RSMU_VWIRE_SRC_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_GET_RSMU_REGIF_MASTER_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp) \
     ((rsmu_mgcg_control_mpccp & RSMU_MGCG_CONTROL_MPCCP_RSMU_REGIF_MASTER_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MPCCP_RSMU_REGIF_MASTER_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_GET_RSMU_PGFSM_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp) \
     ((rsmu_mgcg_control_mpccp & RSMU_MGCG_CONTROL_MPCCP_RSMU_PGFSM_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MPCCP_RSMU_PGFSM_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_GET_RSMU_IH_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp) \
     ((rsmu_mgcg_control_mpccp & RSMU_MGCG_CONTROL_MPCCP_RSMU_IH_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MPCCP_RSMU_IH_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_GET_RSMU_SEM_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp) \
     ((rsmu_mgcg_control_mpccp & RSMU_MGCG_CONTROL_MPCCP_RSMU_SEM_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MPCCP_RSMU_SEM_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_GET_RSMU_DPM_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp) \
     ((rsmu_mgcg_control_mpccp & RSMU_MGCG_CONTROL_MPCCP_RSMU_DPM_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MPCCP_RSMU_DPM_MGCG_OVERRIDE_SHIFT)

#define RSMU_MGCG_CONTROL_MPCCP_SET_RSMU_AXI_SLAVE_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp_reg, rsmu_axi_slave_mgcg_override) \
     rsmu_mgcg_control_mpccp_reg = (rsmu_mgcg_control_mpccp_reg & ~RSMU_MGCG_CONTROL_MPCCP_RSMU_AXI_SLAVE_MGCG_OVERRIDE_MASK) | (rsmu_axi_slave_mgcg_override << RSMU_MGCG_CONTROL_MPCCP_RSMU_AXI_SLAVE_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_SET_RSMU_AXI_MASTER_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp_reg, rsmu_axi_master_mgcg_override) \
     rsmu_mgcg_control_mpccp_reg = (rsmu_mgcg_control_mpccp_reg & ~RSMU_MGCG_CONTROL_MPCCP_RSMU_AXI_MASTER_MGCG_OVERRIDE_MASK) | (rsmu_axi_master_mgcg_override << RSMU_MGCG_CONTROL_MPCCP_RSMU_AXI_MASTER_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_SET_RSMU_SEC_INTR_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp_reg, rsmu_sec_intr_mgcg_override) \
     rsmu_mgcg_control_mpccp_reg = (rsmu_mgcg_control_mpccp_reg & ~RSMU_MGCG_CONTROL_MPCCP_RSMU_SEC_INTR_MGCG_OVERRIDE_MASK) | (rsmu_sec_intr_mgcg_override << RSMU_MGCG_CONTROL_MPCCP_RSMU_SEC_INTR_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_SET_RSMU_PWRMGT_INTR_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp_reg, rsmu_pwrmgt_intr_mgcg_override) \
     rsmu_mgcg_control_mpccp_reg = (rsmu_mgcg_control_mpccp_reg & ~RSMU_MGCG_CONTROL_MPCCP_RSMU_PWRMGT_INTR_MGCG_OVERRIDE_MASK) | (rsmu_pwrmgt_intr_mgcg_override << RSMU_MGCG_CONTROL_MPCCP_RSMU_PWRMGT_INTR_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_SET_RSMU_REG_WRAPPER_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp_reg, rsmu_reg_wrapper_mgcg_override) \
     rsmu_mgcg_control_mpccp_reg = (rsmu_mgcg_control_mpccp_reg & ~RSMU_MGCG_CONTROL_MPCCP_RSMU_REG_WRAPPER_MGCG_OVERRIDE_MASK) | (rsmu_reg_wrapper_mgcg_override << RSMU_MGCG_CONTROL_MPCCP_RSMU_REG_WRAPPER_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_SET_RSMU_STRAP_MASTER_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp_reg, rsmu_strap_master_mgcg_override) \
     rsmu_mgcg_control_mpccp_reg = (rsmu_mgcg_control_mpccp_reg & ~RSMU_MGCG_CONTROL_MPCCP_RSMU_STRAP_MASTER_MGCG_OVERRIDE_MASK) | (rsmu_strap_master_mgcg_override << RSMU_MGCG_CONTROL_MPCCP_RSMU_STRAP_MASTER_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_SET_RSMU_VWIRE_SRC_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp_reg, rsmu_vwire_src_mgcg_override) \
     rsmu_mgcg_control_mpccp_reg = (rsmu_mgcg_control_mpccp_reg & ~RSMU_MGCG_CONTROL_MPCCP_RSMU_VWIRE_SRC_MGCG_OVERRIDE_MASK) | (rsmu_vwire_src_mgcg_override << RSMU_MGCG_CONTROL_MPCCP_RSMU_VWIRE_SRC_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_SET_RSMU_REGIF_MASTER_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp_reg, rsmu_regif_master_mgcg_override) \
     rsmu_mgcg_control_mpccp_reg = (rsmu_mgcg_control_mpccp_reg & ~RSMU_MGCG_CONTROL_MPCCP_RSMU_REGIF_MASTER_MGCG_OVERRIDE_MASK) | (rsmu_regif_master_mgcg_override << RSMU_MGCG_CONTROL_MPCCP_RSMU_REGIF_MASTER_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_SET_RSMU_PGFSM_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp_reg, rsmu_pgfsm_mgcg_override) \
     rsmu_mgcg_control_mpccp_reg = (rsmu_mgcg_control_mpccp_reg & ~RSMU_MGCG_CONTROL_MPCCP_RSMU_PGFSM_MGCG_OVERRIDE_MASK) | (rsmu_pgfsm_mgcg_override << RSMU_MGCG_CONTROL_MPCCP_RSMU_PGFSM_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_SET_RSMU_IH_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp_reg, rsmu_ih_mgcg_override) \
     rsmu_mgcg_control_mpccp_reg = (rsmu_mgcg_control_mpccp_reg & ~RSMU_MGCG_CONTROL_MPCCP_RSMU_IH_MGCG_OVERRIDE_MASK) | (rsmu_ih_mgcg_override << RSMU_MGCG_CONTROL_MPCCP_RSMU_IH_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_SET_RSMU_SEM_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp_reg, rsmu_sem_mgcg_override) \
     rsmu_mgcg_control_mpccp_reg = (rsmu_mgcg_control_mpccp_reg & ~RSMU_MGCG_CONTROL_MPCCP_RSMU_SEM_MGCG_OVERRIDE_MASK) | (rsmu_sem_mgcg_override << RSMU_MGCG_CONTROL_MPCCP_RSMU_SEM_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MPCCP_SET_RSMU_DPM_MGCG_OVERRIDE(rsmu_mgcg_control_mpccp_reg, rsmu_dpm_mgcg_override) \
     rsmu_mgcg_control_mpccp_reg = (rsmu_mgcg_control_mpccp_reg & ~RSMU_MGCG_CONTROL_MPCCP_RSMU_DPM_MGCG_OVERRIDE_MASK) | (rsmu_dpm_mgcg_override << RSMU_MGCG_CONTROL_MPCCP_RSMU_DPM_MGCG_OVERRIDE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_mgcg_control_mpccp_t {
          unsigned int rsmu_axi_slave_mgcg_override   : RSMU_MGCG_CONTROL_MPCCP_RSMU_AXI_SLAVE_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_axi_master_mgcg_override  : RSMU_MGCG_CONTROL_MPCCP_RSMU_AXI_MASTER_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_sec_intr_mgcg_override    : RSMU_MGCG_CONTROL_MPCCP_RSMU_SEC_INTR_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_pwrmgt_intr_mgcg_override : RSMU_MGCG_CONTROL_MPCCP_RSMU_PWRMGT_INTR_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_reg_wrapper_mgcg_override : RSMU_MGCG_CONTROL_MPCCP_RSMU_REG_WRAPPER_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_strap_master_mgcg_override : RSMU_MGCG_CONTROL_MPCCP_RSMU_STRAP_MASTER_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_vwire_src_mgcg_override   : RSMU_MGCG_CONTROL_MPCCP_RSMU_VWIRE_SRC_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_regif_master_mgcg_override : RSMU_MGCG_CONTROL_MPCCP_RSMU_REGIF_MASTER_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_pgfsm_mgcg_override       : RSMU_MGCG_CONTROL_MPCCP_RSMU_PGFSM_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_ih_mgcg_override          : RSMU_MGCG_CONTROL_MPCCP_RSMU_IH_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_sem_mgcg_override         : RSMU_MGCG_CONTROL_MPCCP_RSMU_SEM_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_dpm_mgcg_override         : RSMU_MGCG_CONTROL_MPCCP_RSMU_DPM_MGCG_OVERRIDE_SIZE;
          unsigned int                                : 20;
     } rsmu_mgcg_control_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_mgcg_control_mpccp_t {
          unsigned int                                : 20;
          unsigned int rsmu_dpm_mgcg_override         : RSMU_MGCG_CONTROL_MPCCP_RSMU_DPM_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_sem_mgcg_override         : RSMU_MGCG_CONTROL_MPCCP_RSMU_SEM_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_ih_mgcg_override          : RSMU_MGCG_CONTROL_MPCCP_RSMU_IH_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_pgfsm_mgcg_override       : RSMU_MGCG_CONTROL_MPCCP_RSMU_PGFSM_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_regif_master_mgcg_override : RSMU_MGCG_CONTROL_MPCCP_RSMU_REGIF_MASTER_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_vwire_src_mgcg_override   : RSMU_MGCG_CONTROL_MPCCP_RSMU_VWIRE_SRC_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_strap_master_mgcg_override : RSMU_MGCG_CONTROL_MPCCP_RSMU_STRAP_MASTER_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_reg_wrapper_mgcg_override : RSMU_MGCG_CONTROL_MPCCP_RSMU_REG_WRAPPER_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_pwrmgt_intr_mgcg_override : RSMU_MGCG_CONTROL_MPCCP_RSMU_PWRMGT_INTR_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_sec_intr_mgcg_override    : RSMU_MGCG_CONTROL_MPCCP_RSMU_SEC_INTR_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_axi_master_mgcg_override  : RSMU_MGCG_CONTROL_MPCCP_RSMU_AXI_MASTER_MGCG_OVERRIDE_SIZE;
          unsigned int rsmu_axi_slave_mgcg_override   : RSMU_MGCG_CONTROL_MPCCP_RSMU_AXI_SLAVE_MGCG_OVERRIDE_SIZE;
     } rsmu_mgcg_control_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_mgcg_control_mpccp_t f;
} rsmu_mgcg_control_mpccp_u;


/*
 * RSMU_SEC_AXI_MASTER_ENABLE_MPCCP struct
 */

#define RSMU_SEC_AXI_MASTER_ENABLE_MPCCP_REG_SIZE 32
#define RSMU_SEC_AXI_MASTER_ENABLE_MPCCP_RSMU_SEC_AXI_MASTER_ENABLE_SIZE 1

#define RSMU_SEC_AXI_MASTER_ENABLE_MPCCP_RSMU_SEC_AXI_MASTER_ENABLE_SHIFT 0

#define RSMU_SEC_AXI_MASTER_ENABLE_MPCCP_RSMU_SEC_AXI_MASTER_ENABLE_MASK 0x1

#define RSMU_SEC_AXI_MASTER_ENABLE_MPCCP_MASK \
     (RSMU_SEC_AXI_MASTER_ENABLE_MPCCP_RSMU_SEC_AXI_MASTER_ENABLE_MASK)

#define RSMU_SEC_AXI_MASTER_ENABLE_MPCCP_DEFAULT 0x00000001

#define RSMU_SEC_AXI_MASTER_ENABLE_MPCCP_GET_RSMU_SEC_AXI_MASTER_ENABLE(rsmu_sec_axi_master_enable_mpccp) \
     ((rsmu_sec_axi_master_enable_mpccp & RSMU_SEC_AXI_MASTER_ENABLE_MPCCP_RSMU_SEC_AXI_MASTER_ENABLE_MASK) >> RSMU_SEC_AXI_MASTER_ENABLE_MPCCP_RSMU_SEC_AXI_MASTER_ENABLE_SHIFT)

#define RSMU_SEC_AXI_MASTER_ENABLE_MPCCP_SET_RSMU_SEC_AXI_MASTER_ENABLE(rsmu_sec_axi_master_enable_mpccp_reg, rsmu_sec_axi_master_enable) \
     rsmu_sec_axi_master_enable_mpccp_reg = (rsmu_sec_axi_master_enable_mpccp_reg & ~RSMU_SEC_AXI_MASTER_ENABLE_MPCCP_RSMU_SEC_AXI_MASTER_ENABLE_MASK) | (rsmu_sec_axi_master_enable << RSMU_SEC_AXI_MASTER_ENABLE_MPCCP_RSMU_SEC_AXI_MASTER_ENABLE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_axi_master_enable_mpccp_t {
          unsigned int rsmu_sec_axi_master_enable     : RSMU_SEC_AXI_MASTER_ENABLE_MPCCP_RSMU_SEC_AXI_MASTER_ENABLE_SIZE;
          unsigned int                                : 31;
     } rsmu_sec_axi_master_enable_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_axi_master_enable_mpccp_t {
          unsigned int                                : 31;
          unsigned int rsmu_sec_axi_master_enable     : RSMU_SEC_AXI_MASTER_ENABLE_MPCCP_RSMU_SEC_AXI_MASTER_ENABLE_SIZE;
     } rsmu_sec_axi_master_enable_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_axi_master_enable_mpccp_t f;
} rsmu_sec_axi_master_enable_mpccp_u;


/*
 * RSMU_AXI_MASTER_QOS_CNTL_MPCCP struct
 */

#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_REG_SIZE 32
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_MASTER_QOS_OVRD_MODE_SIZE 1
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_MASTER_QOS_OVRD_VALUE_SIZE 4
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_AWQOS_OVRD_MODE_SIZE 1
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_AWQOS_OVRD_VALUE_SIZE 4
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_ARQOS_OVRD_MODE_SIZE 1
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_ARQOS_OVRD_VALUE_SIZE 4

#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_MASTER_QOS_OVRD_MODE_SHIFT 0
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_MASTER_QOS_OVRD_VALUE_SHIFT 1
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_AWQOS_OVRD_MODE_SHIFT 5
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_AWQOS_OVRD_VALUE_SHIFT 6
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_ARQOS_OVRD_MODE_SHIFT 10
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_ARQOS_OVRD_VALUE_SHIFT 11

#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_MASTER_QOS_OVRD_MODE_MASK 0x1
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_MASTER_QOS_OVRD_VALUE_MASK 0x1e
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_AWQOS_OVRD_MODE_MASK 0x20
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_AWQOS_OVRD_VALUE_MASK 0x3c0
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_ARQOS_OVRD_MODE_MASK 0x400
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_ARQOS_OVRD_VALUE_MASK 0x7800

#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_MASK \
     (RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_MASTER_QOS_OVRD_MODE_MASK | \
      RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_MASTER_QOS_OVRD_VALUE_MASK | \
      RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_AWQOS_OVRD_MODE_MASK | \
      RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_AWQOS_OVRD_VALUE_MASK | \
      RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_ARQOS_OVRD_MODE_MASK | \
      RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_ARQOS_OVRD_VALUE_MASK)

#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_DEFAULT 0x00000842

#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_GET_RSMU_MASTER_QOS_OVRD_MODE(rsmu_axi_master_qos_cntl_mpccp) \
     ((rsmu_axi_master_qos_cntl_mpccp & RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_MASTER_QOS_OVRD_MODE_MASK) >> RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_MASTER_QOS_OVRD_MODE_SHIFT)
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_GET_RSMU_MASTER_QOS_OVRD_VALUE(rsmu_axi_master_qos_cntl_mpccp) \
     ((rsmu_axi_master_qos_cntl_mpccp & RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_MASTER_QOS_OVRD_VALUE_MASK) >> RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_MASTER_QOS_OVRD_VALUE_SHIFT)
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_GET_RSMU_IP_MASTER_AWQOS_OVRD_MODE(rsmu_axi_master_qos_cntl_mpccp) \
     ((rsmu_axi_master_qos_cntl_mpccp & RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_AWQOS_OVRD_MODE_MASK) >> RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_AWQOS_OVRD_MODE_SHIFT)
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_GET_RSMU_IP_MASTER_AWQOS_OVRD_VALUE(rsmu_axi_master_qos_cntl_mpccp) \
     ((rsmu_axi_master_qos_cntl_mpccp & RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_AWQOS_OVRD_VALUE_MASK) >> RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_AWQOS_OVRD_VALUE_SHIFT)
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_GET_RSMU_IP_MASTER_ARQOS_OVRD_MODE(rsmu_axi_master_qos_cntl_mpccp) \
     ((rsmu_axi_master_qos_cntl_mpccp & RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_ARQOS_OVRD_MODE_MASK) >> RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_ARQOS_OVRD_MODE_SHIFT)
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_GET_RSMU_IP_MASTER_ARQOS_OVRD_VALUE(rsmu_axi_master_qos_cntl_mpccp) \
     ((rsmu_axi_master_qos_cntl_mpccp & RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_ARQOS_OVRD_VALUE_MASK) >> RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_ARQOS_OVRD_VALUE_SHIFT)

#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_SET_RSMU_MASTER_QOS_OVRD_MODE(rsmu_axi_master_qos_cntl_mpccp_reg, rsmu_master_qos_ovrd_mode) \
     rsmu_axi_master_qos_cntl_mpccp_reg = (rsmu_axi_master_qos_cntl_mpccp_reg & ~RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_MASTER_QOS_OVRD_MODE_MASK) | (rsmu_master_qos_ovrd_mode << RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_MASTER_QOS_OVRD_MODE_SHIFT)
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_SET_RSMU_MASTER_QOS_OVRD_VALUE(rsmu_axi_master_qos_cntl_mpccp_reg, rsmu_master_qos_ovrd_value) \
     rsmu_axi_master_qos_cntl_mpccp_reg = (rsmu_axi_master_qos_cntl_mpccp_reg & ~RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_MASTER_QOS_OVRD_VALUE_MASK) | (rsmu_master_qos_ovrd_value << RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_MASTER_QOS_OVRD_VALUE_SHIFT)
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_SET_RSMU_IP_MASTER_AWQOS_OVRD_MODE(rsmu_axi_master_qos_cntl_mpccp_reg, rsmu_ip_master_awqos_ovrd_mode) \
     rsmu_axi_master_qos_cntl_mpccp_reg = (rsmu_axi_master_qos_cntl_mpccp_reg & ~RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_AWQOS_OVRD_MODE_MASK) | (rsmu_ip_master_awqos_ovrd_mode << RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_AWQOS_OVRD_MODE_SHIFT)
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_SET_RSMU_IP_MASTER_AWQOS_OVRD_VALUE(rsmu_axi_master_qos_cntl_mpccp_reg, rsmu_ip_master_awqos_ovrd_value) \
     rsmu_axi_master_qos_cntl_mpccp_reg = (rsmu_axi_master_qos_cntl_mpccp_reg & ~RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_AWQOS_OVRD_VALUE_MASK) | (rsmu_ip_master_awqos_ovrd_value << RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_AWQOS_OVRD_VALUE_SHIFT)
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_SET_RSMU_IP_MASTER_ARQOS_OVRD_MODE(rsmu_axi_master_qos_cntl_mpccp_reg, rsmu_ip_master_arqos_ovrd_mode) \
     rsmu_axi_master_qos_cntl_mpccp_reg = (rsmu_axi_master_qos_cntl_mpccp_reg & ~RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_ARQOS_OVRD_MODE_MASK) | (rsmu_ip_master_arqos_ovrd_mode << RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_ARQOS_OVRD_MODE_SHIFT)
#define RSMU_AXI_MASTER_QOS_CNTL_MPCCP_SET_RSMU_IP_MASTER_ARQOS_OVRD_VALUE(rsmu_axi_master_qos_cntl_mpccp_reg, rsmu_ip_master_arqos_ovrd_value) \
     rsmu_axi_master_qos_cntl_mpccp_reg = (rsmu_axi_master_qos_cntl_mpccp_reg & ~RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_ARQOS_OVRD_VALUE_MASK) | (rsmu_ip_master_arqos_ovrd_value << RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_ARQOS_OVRD_VALUE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_axi_master_qos_cntl_mpccp_t {
          unsigned int rsmu_master_qos_ovrd_mode      : RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_MASTER_QOS_OVRD_MODE_SIZE;
          unsigned int rsmu_master_qos_ovrd_value     : RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_MASTER_QOS_OVRD_VALUE_SIZE;
          unsigned int rsmu_ip_master_awqos_ovrd_mode : RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_AWQOS_OVRD_MODE_SIZE;
          unsigned int rsmu_ip_master_awqos_ovrd_value : RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_AWQOS_OVRD_VALUE_SIZE;
          unsigned int rsmu_ip_master_arqos_ovrd_mode : RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_ARQOS_OVRD_MODE_SIZE;
          unsigned int rsmu_ip_master_arqos_ovrd_value : RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_ARQOS_OVRD_VALUE_SIZE;
          unsigned int                                : 17;
     } rsmu_axi_master_qos_cntl_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_axi_master_qos_cntl_mpccp_t {
          unsigned int                                : 17;
          unsigned int rsmu_ip_master_arqos_ovrd_value : RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_ARQOS_OVRD_VALUE_SIZE;
          unsigned int rsmu_ip_master_arqos_ovrd_mode : RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_ARQOS_OVRD_MODE_SIZE;
          unsigned int rsmu_ip_master_awqos_ovrd_value : RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_AWQOS_OVRD_VALUE_SIZE;
          unsigned int rsmu_ip_master_awqos_ovrd_mode : RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_IP_MASTER_AWQOS_OVRD_MODE_SIZE;
          unsigned int rsmu_master_qos_ovrd_value     : RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_MASTER_QOS_OVRD_VALUE_SIZE;
          unsigned int rsmu_master_qos_ovrd_mode      : RSMU_AXI_MASTER_QOS_CNTL_MPCCP_RSMU_MASTER_QOS_OVRD_MODE_SIZE;
     } rsmu_axi_master_qos_cntl_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_axi_master_qos_cntl_mpccp_t f;
} rsmu_axi_master_qos_cntl_mpccp_u;


/*
 * RSMU_MASTER_ERROR_COUNTER_MPCCP struct
 */

#define RSMU_MASTER_ERROR_COUNTER_MPCCP_REG_SIZE 32
#define RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_SMN_SLVERR_COUNTER_SIZE 8
#define RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_SMN_DECERR_COUNTER_SIZE 8
#define RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_MASTER_SLVERR_COUNTER_SIZE 8
#define RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_MASTER_DECERR_COUNTER_SIZE 8

#define RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_SMN_SLVERR_COUNTER_SHIFT 0
#define RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_SMN_DECERR_COUNTER_SHIFT 8
#define RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_MASTER_SLVERR_COUNTER_SHIFT 16
#define RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_MASTER_DECERR_COUNTER_SHIFT 24

#define RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_SMN_SLVERR_COUNTER_MASK 0xff
#define RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_SMN_DECERR_COUNTER_MASK 0xff00
#define RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_MASTER_SLVERR_COUNTER_MASK 0xff0000
#define RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_MASTER_DECERR_COUNTER_MASK 0xff000000

#define RSMU_MASTER_ERROR_COUNTER_MPCCP_MASK \
     (RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_SMN_SLVERR_COUNTER_MASK | \
      RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_SMN_DECERR_COUNTER_MASK | \
      RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_MASTER_SLVERR_COUNTER_MASK | \
      RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_MASTER_DECERR_COUNTER_MASK)

#define RSMU_MASTER_ERROR_COUNTER_MPCCP_DEFAULT 0x00000000

#define RSMU_MASTER_ERROR_COUNTER_MPCCP_GET_RSMU_SMN_SLVERR_COUNTER(rsmu_master_error_counter_mpccp) \
     ((rsmu_master_error_counter_mpccp & RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_SMN_SLVERR_COUNTER_MASK) >> RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_SMN_SLVERR_COUNTER_SHIFT)
#define RSMU_MASTER_ERROR_COUNTER_MPCCP_GET_RSMU_SMN_DECERR_COUNTER(rsmu_master_error_counter_mpccp) \
     ((rsmu_master_error_counter_mpccp & RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_SMN_DECERR_COUNTER_MASK) >> RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_SMN_DECERR_COUNTER_SHIFT)
#define RSMU_MASTER_ERROR_COUNTER_MPCCP_GET_RSMU_MASTER_SLVERR_COUNTER(rsmu_master_error_counter_mpccp) \
     ((rsmu_master_error_counter_mpccp & RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_MASTER_SLVERR_COUNTER_MASK) >> RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_MASTER_SLVERR_COUNTER_SHIFT)
#define RSMU_MASTER_ERROR_COUNTER_MPCCP_GET_RSMU_MASTER_DECERR_COUNTER(rsmu_master_error_counter_mpccp) \
     ((rsmu_master_error_counter_mpccp & RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_MASTER_DECERR_COUNTER_MASK) >> RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_MASTER_DECERR_COUNTER_SHIFT)

#define RSMU_MASTER_ERROR_COUNTER_MPCCP_SET_RSMU_SMN_SLVERR_COUNTER(rsmu_master_error_counter_mpccp_reg, rsmu_smn_slverr_counter) \
     rsmu_master_error_counter_mpccp_reg = (rsmu_master_error_counter_mpccp_reg & ~RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_SMN_SLVERR_COUNTER_MASK) | (rsmu_smn_slverr_counter << RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_SMN_SLVERR_COUNTER_SHIFT)
#define RSMU_MASTER_ERROR_COUNTER_MPCCP_SET_RSMU_SMN_DECERR_COUNTER(rsmu_master_error_counter_mpccp_reg, rsmu_smn_decerr_counter) \
     rsmu_master_error_counter_mpccp_reg = (rsmu_master_error_counter_mpccp_reg & ~RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_SMN_DECERR_COUNTER_MASK) | (rsmu_smn_decerr_counter << RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_SMN_DECERR_COUNTER_SHIFT)
#define RSMU_MASTER_ERROR_COUNTER_MPCCP_SET_RSMU_MASTER_SLVERR_COUNTER(rsmu_master_error_counter_mpccp_reg, rsmu_master_slverr_counter) \
     rsmu_master_error_counter_mpccp_reg = (rsmu_master_error_counter_mpccp_reg & ~RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_MASTER_SLVERR_COUNTER_MASK) | (rsmu_master_slverr_counter << RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_MASTER_SLVERR_COUNTER_SHIFT)
#define RSMU_MASTER_ERROR_COUNTER_MPCCP_SET_RSMU_MASTER_DECERR_COUNTER(rsmu_master_error_counter_mpccp_reg, rsmu_master_decerr_counter) \
     rsmu_master_error_counter_mpccp_reg = (rsmu_master_error_counter_mpccp_reg & ~RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_MASTER_DECERR_COUNTER_MASK) | (rsmu_master_decerr_counter << RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_MASTER_DECERR_COUNTER_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_master_error_counter_mpccp_t {
          unsigned int rsmu_smn_slverr_counter        : RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_SMN_SLVERR_COUNTER_SIZE;
          unsigned int rsmu_smn_decerr_counter        : RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_SMN_DECERR_COUNTER_SIZE;
          unsigned int rsmu_master_slverr_counter     : RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_MASTER_SLVERR_COUNTER_SIZE;
          unsigned int rsmu_master_decerr_counter     : RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_MASTER_DECERR_COUNTER_SIZE;
     } rsmu_master_error_counter_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_master_error_counter_mpccp_t {
          unsigned int rsmu_master_decerr_counter     : RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_MASTER_DECERR_COUNTER_SIZE;
          unsigned int rsmu_master_slverr_counter     : RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_MASTER_SLVERR_COUNTER_SIZE;
          unsigned int rsmu_smn_decerr_counter        : RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_SMN_DECERR_COUNTER_SIZE;
          unsigned int rsmu_smn_slverr_counter        : RSMU_MASTER_ERROR_COUNTER_MPCCP_RSMU_SMN_SLVERR_COUNTER_SIZE;
     } rsmu_master_error_counter_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_master_error_counter_mpccp_t f;
} rsmu_master_error_counter_mpccp_u;


/*
 * RSMU_SLAVE_TIMEOUT_VALUE_MPCCP struct
 */

#define RSMU_SLAVE_TIMEOUT_VALUE_MPCCP_REG_SIZE 32
#define RSMU_SLAVE_TIMEOUT_VALUE_MPCCP_RSMU_SLAVE_TIMEOUT_VALUE_SIZE 32

#define RSMU_SLAVE_TIMEOUT_VALUE_MPCCP_RSMU_SLAVE_TIMEOUT_VALUE_SHIFT 0

#define RSMU_SLAVE_TIMEOUT_VALUE_MPCCP_RSMU_SLAVE_TIMEOUT_VALUE_MASK 0xffffffff

#define RSMU_SLAVE_TIMEOUT_VALUE_MPCCP_MASK \
     (RSMU_SLAVE_TIMEOUT_VALUE_MPCCP_RSMU_SLAVE_TIMEOUT_VALUE_MASK)

#define RSMU_SLAVE_TIMEOUT_VALUE_MPCCP_DEFAULT 0x00ffffff

#define RSMU_SLAVE_TIMEOUT_VALUE_MPCCP_GET_RSMU_SLAVE_TIMEOUT_VALUE(rsmu_slave_timeout_value_mpccp) \
     ((rsmu_slave_timeout_value_mpccp & RSMU_SLAVE_TIMEOUT_VALUE_MPCCP_RSMU_SLAVE_TIMEOUT_VALUE_MASK) >> RSMU_SLAVE_TIMEOUT_VALUE_MPCCP_RSMU_SLAVE_TIMEOUT_VALUE_SHIFT)

#define RSMU_SLAVE_TIMEOUT_VALUE_MPCCP_SET_RSMU_SLAVE_TIMEOUT_VALUE(rsmu_slave_timeout_value_mpccp_reg, rsmu_slave_timeout_value) \
     rsmu_slave_timeout_value_mpccp_reg = (rsmu_slave_timeout_value_mpccp_reg & ~RSMU_SLAVE_TIMEOUT_VALUE_MPCCP_RSMU_SLAVE_TIMEOUT_VALUE_MASK) | (rsmu_slave_timeout_value << RSMU_SLAVE_TIMEOUT_VALUE_MPCCP_RSMU_SLAVE_TIMEOUT_VALUE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_slave_timeout_value_mpccp_t {
          unsigned int rsmu_slave_timeout_value       : RSMU_SLAVE_TIMEOUT_VALUE_MPCCP_RSMU_SLAVE_TIMEOUT_VALUE_SIZE;
     } rsmu_slave_timeout_value_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_slave_timeout_value_mpccp_t {
          unsigned int rsmu_slave_timeout_value       : RSMU_SLAVE_TIMEOUT_VALUE_MPCCP_RSMU_SLAVE_TIMEOUT_VALUE_SIZE;
     } rsmu_slave_timeout_value_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_slave_timeout_value_mpccp_t f;
} rsmu_slave_timeout_value_mpccp_u;


/*
 * RSMU_RESET_TIMEOUT_CONTROL_MPCCP struct
 */

#define RSMU_RESET_TIMEOUT_CONTROL_MPCCP_REG_SIZE 32
#define RSMU_RESET_TIMEOUT_CONTROL_MPCCP_RSMU_SLAVE_TIMEOUT_ENABLE_SIZE 1
#define RSMU_RESET_TIMEOUT_CONTROL_MPCCP_RSMU_SLAVE_RESET_TIMEOUT_VALUE_SIZE 8

#define RSMU_RESET_TIMEOUT_CONTROL_MPCCP_RSMU_SLAVE_TIMEOUT_ENABLE_SHIFT 0
#define RSMU_RESET_TIMEOUT_CONTROL_MPCCP_RSMU_SLAVE_RESET_TIMEOUT_VALUE_SHIFT 1

#define RSMU_RESET_TIMEOUT_CONTROL_MPCCP_RSMU_SLAVE_TIMEOUT_ENABLE_MASK 0x1
#define RSMU_RESET_TIMEOUT_CONTROL_MPCCP_RSMU_SLAVE_RESET_TIMEOUT_VALUE_MASK 0x1fe

#define RSMU_RESET_TIMEOUT_CONTROL_MPCCP_MASK \
     (RSMU_RESET_TIMEOUT_CONTROL_MPCCP_RSMU_SLAVE_TIMEOUT_ENABLE_MASK | \
      RSMU_RESET_TIMEOUT_CONTROL_MPCCP_RSMU_SLAVE_RESET_TIMEOUT_VALUE_MASK)

#define RSMU_RESET_TIMEOUT_CONTROL_MPCCP_DEFAULT 0x00000004

#define RSMU_RESET_TIMEOUT_CONTROL_MPCCP_GET_RSMU_SLAVE_TIMEOUT_ENABLE(rsmu_reset_timeout_control_mpccp) \
     ((rsmu_reset_timeout_control_mpccp & RSMU_RESET_TIMEOUT_CONTROL_MPCCP_RSMU_SLAVE_TIMEOUT_ENABLE_MASK) >> RSMU_RESET_TIMEOUT_CONTROL_MPCCP_RSMU_SLAVE_TIMEOUT_ENABLE_SHIFT)
#define RSMU_RESET_TIMEOUT_CONTROL_MPCCP_GET_RSMU_SLAVE_RESET_TIMEOUT_VALUE(rsmu_reset_timeout_control_mpccp) \
     ((rsmu_reset_timeout_control_mpccp & RSMU_RESET_TIMEOUT_CONTROL_MPCCP_RSMU_SLAVE_RESET_TIMEOUT_VALUE_MASK) >> RSMU_RESET_TIMEOUT_CONTROL_MPCCP_RSMU_SLAVE_RESET_TIMEOUT_VALUE_SHIFT)

#define RSMU_RESET_TIMEOUT_CONTROL_MPCCP_SET_RSMU_SLAVE_TIMEOUT_ENABLE(rsmu_reset_timeout_control_mpccp_reg, rsmu_slave_timeout_enable) \
     rsmu_reset_timeout_control_mpccp_reg = (rsmu_reset_timeout_control_mpccp_reg & ~RSMU_RESET_TIMEOUT_CONTROL_MPCCP_RSMU_SLAVE_TIMEOUT_ENABLE_MASK) | (rsmu_slave_timeout_enable << RSMU_RESET_TIMEOUT_CONTROL_MPCCP_RSMU_SLAVE_TIMEOUT_ENABLE_SHIFT)
#define RSMU_RESET_TIMEOUT_CONTROL_MPCCP_SET_RSMU_SLAVE_RESET_TIMEOUT_VALUE(rsmu_reset_timeout_control_mpccp_reg, rsmu_slave_reset_timeout_value) \
     rsmu_reset_timeout_control_mpccp_reg = (rsmu_reset_timeout_control_mpccp_reg & ~RSMU_RESET_TIMEOUT_CONTROL_MPCCP_RSMU_SLAVE_RESET_TIMEOUT_VALUE_MASK) | (rsmu_slave_reset_timeout_value << RSMU_RESET_TIMEOUT_CONTROL_MPCCP_RSMU_SLAVE_RESET_TIMEOUT_VALUE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_reset_timeout_control_mpccp_t {
          unsigned int rsmu_slave_timeout_enable      : RSMU_RESET_TIMEOUT_CONTROL_MPCCP_RSMU_SLAVE_TIMEOUT_ENABLE_SIZE;
          unsigned int rsmu_slave_reset_timeout_value : RSMU_RESET_TIMEOUT_CONTROL_MPCCP_RSMU_SLAVE_RESET_TIMEOUT_VALUE_SIZE;
          unsigned int                                : 23;
     } rsmu_reset_timeout_control_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_reset_timeout_control_mpccp_t {
          unsigned int                                : 23;
          unsigned int rsmu_slave_reset_timeout_value : RSMU_RESET_TIMEOUT_CONTROL_MPCCP_RSMU_SLAVE_RESET_TIMEOUT_VALUE_SIZE;
          unsigned int rsmu_slave_timeout_enable      : RSMU_RESET_TIMEOUT_CONTROL_MPCCP_RSMU_SLAVE_TIMEOUT_ENABLE_SIZE;
     } rsmu_reset_timeout_control_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_reset_timeout_control_mpccp_t f;
} rsmu_reset_timeout_control_mpccp_u;


/*
 * RSMU_SLAVE_ERROR_COUNTER_MPCCP struct
 */

#define RSMU_SLAVE_ERROR_COUNTER_MPCCP_REG_SIZE 32
#define RSMU_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SLAVE_ERROR_COUNTER_SIZE 8

#define RSMU_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SLAVE_ERROR_COUNTER_SHIFT 0

#define RSMU_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SLAVE_ERROR_COUNTER_MASK 0xff

#define RSMU_SLAVE_ERROR_COUNTER_MPCCP_MASK \
     (RSMU_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SLAVE_ERROR_COUNTER_MASK)

#define RSMU_SLAVE_ERROR_COUNTER_MPCCP_DEFAULT 0x00000000

#define RSMU_SLAVE_ERROR_COUNTER_MPCCP_GET_RSMU_SLAVE_ERROR_COUNTER(rsmu_slave_error_counter_mpccp) \
     ((rsmu_slave_error_counter_mpccp & RSMU_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SLAVE_ERROR_COUNTER_MASK) >> RSMU_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SLAVE_ERROR_COUNTER_SHIFT)

#define RSMU_SLAVE_ERROR_COUNTER_MPCCP_SET_RSMU_SLAVE_ERROR_COUNTER(rsmu_slave_error_counter_mpccp_reg, rsmu_slave_error_counter) \
     rsmu_slave_error_counter_mpccp_reg = (rsmu_slave_error_counter_mpccp_reg & ~RSMU_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SLAVE_ERROR_COUNTER_MASK) | (rsmu_slave_error_counter << RSMU_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SLAVE_ERROR_COUNTER_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_slave_error_counter_mpccp_t {
          unsigned int rsmu_slave_error_counter       : RSMU_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SLAVE_ERROR_COUNTER_SIZE;
          unsigned int                                : 24;
     } rsmu_slave_error_counter_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_slave_error_counter_mpccp_t {
          unsigned int                                : 24;
          unsigned int rsmu_slave_error_counter       : RSMU_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SLAVE_ERROR_COUNTER_SIZE;
     } rsmu_slave_error_counter_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_slave_error_counter_mpccp_t f;
} rsmu_slave_error_counter_mpccp_u;


/*
 * RSMU_DBG_MUX_CONTROL_MPCCP struct
 */

#define RSMU_DBG_MUX_CONTROL_MPCCP_REG_SIZE 32
#define RSMU_DBG_MUX_CONTROL_MPCCP_RSMU_DBG_MUX_SELECT_SIZE 8
#define RSMU_DBG_MUX_CONTROL_MPCCP_RSMU_DBG_SIGNATURE_SIZE 8

#define RSMU_DBG_MUX_CONTROL_MPCCP_RSMU_DBG_MUX_SELECT_SHIFT 0
#define RSMU_DBG_MUX_CONTROL_MPCCP_RSMU_DBG_SIGNATURE_SHIFT 24

#define RSMU_DBG_MUX_CONTROL_MPCCP_RSMU_DBG_MUX_SELECT_MASK 0xff
#define RSMU_DBG_MUX_CONTROL_MPCCP_RSMU_DBG_SIGNATURE_MASK 0xff000000

#define RSMU_DBG_MUX_CONTROL_MPCCP_MASK \
     (RSMU_DBG_MUX_CONTROL_MPCCP_RSMU_DBG_MUX_SELECT_MASK | \
      RSMU_DBG_MUX_CONTROL_MPCCP_RSMU_DBG_SIGNATURE_MASK)

#define RSMU_DBG_MUX_CONTROL_MPCCP_DEFAULT 0x5a0000ff

#define RSMU_DBG_MUX_CONTROL_MPCCP_GET_RSMU_DBG_MUX_SELECT(rsmu_dbg_mux_control_mpccp) \
     ((rsmu_dbg_mux_control_mpccp & RSMU_DBG_MUX_CONTROL_MPCCP_RSMU_DBG_MUX_SELECT_MASK) >> RSMU_DBG_MUX_CONTROL_MPCCP_RSMU_DBG_MUX_SELECT_SHIFT)
#define RSMU_DBG_MUX_CONTROL_MPCCP_GET_RSMU_DBG_SIGNATURE(rsmu_dbg_mux_control_mpccp) \
     ((rsmu_dbg_mux_control_mpccp & RSMU_DBG_MUX_CONTROL_MPCCP_RSMU_DBG_SIGNATURE_MASK) >> RSMU_DBG_MUX_CONTROL_MPCCP_RSMU_DBG_SIGNATURE_SHIFT)

#define RSMU_DBG_MUX_CONTROL_MPCCP_SET_RSMU_DBG_MUX_SELECT(rsmu_dbg_mux_control_mpccp_reg, rsmu_dbg_mux_select) \
     rsmu_dbg_mux_control_mpccp_reg = (rsmu_dbg_mux_control_mpccp_reg & ~RSMU_DBG_MUX_CONTROL_MPCCP_RSMU_DBG_MUX_SELECT_MASK) | (rsmu_dbg_mux_select << RSMU_DBG_MUX_CONTROL_MPCCP_RSMU_DBG_MUX_SELECT_SHIFT)
#define RSMU_DBG_MUX_CONTROL_MPCCP_SET_RSMU_DBG_SIGNATURE(rsmu_dbg_mux_control_mpccp_reg, rsmu_dbg_signature) \
     rsmu_dbg_mux_control_mpccp_reg = (rsmu_dbg_mux_control_mpccp_reg & ~RSMU_DBG_MUX_CONTROL_MPCCP_RSMU_DBG_SIGNATURE_MASK) | (rsmu_dbg_signature << RSMU_DBG_MUX_CONTROL_MPCCP_RSMU_DBG_SIGNATURE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_dbg_mux_control_mpccp_t {
          unsigned int rsmu_dbg_mux_select            : RSMU_DBG_MUX_CONTROL_MPCCP_RSMU_DBG_MUX_SELECT_SIZE;
          unsigned int                                : 16;
          unsigned int rsmu_dbg_signature             : RSMU_DBG_MUX_CONTROL_MPCCP_RSMU_DBG_SIGNATURE_SIZE;
     } rsmu_dbg_mux_control_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_dbg_mux_control_mpccp_t {
          unsigned int rsmu_dbg_signature             : RSMU_DBG_MUX_CONTROL_MPCCP_RSMU_DBG_SIGNATURE_SIZE;
          unsigned int                                : 16;
          unsigned int rsmu_dbg_mux_select            : RSMU_DBG_MUX_CONTROL_MPCCP_RSMU_DBG_MUX_SELECT_SIZE;
     } rsmu_dbg_mux_control_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_dbg_mux_control_mpccp_t f;
} rsmu_dbg_mux_control_mpccp_u;


/*
 * RSMU_IP_CLOCK_GATE_CNTL_MPCCP struct
 */

#define RSMU_IP_CLOCK_GATE_CNTL_MPCCP_REG_SIZE 32
#define RSMU_IP_CLOCK_GATE_CNTL_MPCCP_RSMU_IP_MGCG_ENABLE_SIZE 1
#define RSMU_IP_CLOCK_GATE_CNTL_MPCCP_RSMU_IP_FORCE_CLKOFF_SIZE 1

#define RSMU_IP_CLOCK_GATE_CNTL_MPCCP_RSMU_IP_MGCG_ENABLE_SHIFT 0
#define RSMU_IP_CLOCK_GATE_CNTL_MPCCP_RSMU_IP_FORCE_CLKOFF_SHIFT 31

#define RSMU_IP_CLOCK_GATE_CNTL_MPCCP_RSMU_IP_MGCG_ENABLE_MASK 0x1
#define RSMU_IP_CLOCK_GATE_CNTL_MPCCP_RSMU_IP_FORCE_CLKOFF_MASK 0x80000000

#define RSMU_IP_CLOCK_GATE_CNTL_MPCCP_MASK \
     (RSMU_IP_CLOCK_GATE_CNTL_MPCCP_RSMU_IP_MGCG_ENABLE_MASK | \
      RSMU_IP_CLOCK_GATE_CNTL_MPCCP_RSMU_IP_FORCE_CLKOFF_MASK)

#define RSMU_IP_CLOCK_GATE_CNTL_MPCCP_DEFAULT 0x00000000

#define RSMU_IP_CLOCK_GATE_CNTL_MPCCP_GET_RSMU_IP_MGCG_ENABLE(rsmu_ip_clock_gate_cntl_mpccp) \
     ((rsmu_ip_clock_gate_cntl_mpccp & RSMU_IP_CLOCK_GATE_CNTL_MPCCP_RSMU_IP_MGCG_ENABLE_MASK) >> RSMU_IP_CLOCK_GATE_CNTL_MPCCP_RSMU_IP_MGCG_ENABLE_SHIFT)
#define RSMU_IP_CLOCK_GATE_CNTL_MPCCP_GET_RSMU_IP_FORCE_CLKOFF(rsmu_ip_clock_gate_cntl_mpccp) \
     ((rsmu_ip_clock_gate_cntl_mpccp & RSMU_IP_CLOCK_GATE_CNTL_MPCCP_RSMU_IP_FORCE_CLKOFF_MASK) >> RSMU_IP_CLOCK_GATE_CNTL_MPCCP_RSMU_IP_FORCE_CLKOFF_SHIFT)

#define RSMU_IP_CLOCK_GATE_CNTL_MPCCP_SET_RSMU_IP_MGCG_ENABLE(rsmu_ip_clock_gate_cntl_mpccp_reg, rsmu_ip_mgcg_enable) \
     rsmu_ip_clock_gate_cntl_mpccp_reg = (rsmu_ip_clock_gate_cntl_mpccp_reg & ~RSMU_IP_CLOCK_GATE_CNTL_MPCCP_RSMU_IP_MGCG_ENABLE_MASK) | (rsmu_ip_mgcg_enable << RSMU_IP_CLOCK_GATE_CNTL_MPCCP_RSMU_IP_MGCG_ENABLE_SHIFT)
#define RSMU_IP_CLOCK_GATE_CNTL_MPCCP_SET_RSMU_IP_FORCE_CLKOFF(rsmu_ip_clock_gate_cntl_mpccp_reg, rsmu_ip_force_clkoff) \
     rsmu_ip_clock_gate_cntl_mpccp_reg = (rsmu_ip_clock_gate_cntl_mpccp_reg & ~RSMU_IP_CLOCK_GATE_CNTL_MPCCP_RSMU_IP_FORCE_CLKOFF_MASK) | (rsmu_ip_force_clkoff << RSMU_IP_CLOCK_GATE_CNTL_MPCCP_RSMU_IP_FORCE_CLKOFF_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_ip_clock_gate_cntl_mpccp_t {
          unsigned int rsmu_ip_mgcg_enable            : RSMU_IP_CLOCK_GATE_CNTL_MPCCP_RSMU_IP_MGCG_ENABLE_SIZE;
          unsigned int                                : 30;
          unsigned int rsmu_ip_force_clkoff           : RSMU_IP_CLOCK_GATE_CNTL_MPCCP_RSMU_IP_FORCE_CLKOFF_SIZE;
     } rsmu_ip_clock_gate_cntl_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_ip_clock_gate_cntl_mpccp_t {
          unsigned int rsmu_ip_force_clkoff           : RSMU_IP_CLOCK_GATE_CNTL_MPCCP_RSMU_IP_FORCE_CLKOFF_SIZE;
          unsigned int                                : 30;
          unsigned int rsmu_ip_mgcg_enable            : RSMU_IP_CLOCK_GATE_CNTL_MPCCP_RSMU_IP_MGCG_ENABLE_SIZE;
     } rsmu_ip_clock_gate_cntl_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_ip_clock_gate_cntl_mpccp_t f;
} rsmu_ip_clock_gate_cntl_mpccp_u;


/*
 * RSMU_MSMU_FETCH_FUSE_MPCCP struct
 */

#define RSMU_MSMU_FETCH_FUSE_MPCCP_REG_SIZE 32
#define RSMU_MSMU_FETCH_FUSE_MPCCP_RSMU_FUSE_UPPER_256KB_H_OFFSET_SIZE 2
#define RSMU_MSMU_FETCH_FUSE_MPCCP_RSMU_FUSE_APERTURE_ID_H_OFFSET_SIZE 12

#define RSMU_MSMU_FETCH_FUSE_MPCCP_RSMU_FUSE_UPPER_256KB_H_OFFSET_SHIFT 0
#define RSMU_MSMU_FETCH_FUSE_MPCCP_RSMU_FUSE_APERTURE_ID_H_OFFSET_SHIFT 2

#define RSMU_MSMU_FETCH_FUSE_MPCCP_RSMU_FUSE_UPPER_256KB_H_OFFSET_MASK 0x3
#define RSMU_MSMU_FETCH_FUSE_MPCCP_RSMU_FUSE_APERTURE_ID_H_OFFSET_MASK 0x3ffc

#define RSMU_MSMU_FETCH_FUSE_MPCCP_MASK \
     (RSMU_MSMU_FETCH_FUSE_MPCCP_RSMU_FUSE_UPPER_256KB_H_OFFSET_MASK | \
      RSMU_MSMU_FETCH_FUSE_MPCCP_RSMU_FUSE_APERTURE_ID_H_OFFSET_MASK)

#define RSMU_MSMU_FETCH_FUSE_MPCCP_DEFAULT 0x00000001

#define RSMU_MSMU_FETCH_FUSE_MPCCP_GET_RSMU_FUSE_UPPER_256KB_H_OFFSET(rsmu_msmu_fetch_fuse_mpccp) \
     ((rsmu_msmu_fetch_fuse_mpccp & RSMU_MSMU_FETCH_FUSE_MPCCP_RSMU_FUSE_UPPER_256KB_H_OFFSET_MASK) >> RSMU_MSMU_FETCH_FUSE_MPCCP_RSMU_FUSE_UPPER_256KB_H_OFFSET_SHIFT)
#define RSMU_MSMU_FETCH_FUSE_MPCCP_GET_RSMU_FUSE_APERTURE_ID_H_OFFSET(rsmu_msmu_fetch_fuse_mpccp) \
     ((rsmu_msmu_fetch_fuse_mpccp & RSMU_MSMU_FETCH_FUSE_MPCCP_RSMU_FUSE_APERTURE_ID_H_OFFSET_MASK) >> RSMU_MSMU_FETCH_FUSE_MPCCP_RSMU_FUSE_APERTURE_ID_H_OFFSET_SHIFT)

#define RSMU_MSMU_FETCH_FUSE_MPCCP_SET_RSMU_FUSE_UPPER_256KB_H_OFFSET(rsmu_msmu_fetch_fuse_mpccp_reg, rsmu_fuse_upper_256kb_h_offset) \
     rsmu_msmu_fetch_fuse_mpccp_reg = (rsmu_msmu_fetch_fuse_mpccp_reg & ~RSMU_MSMU_FETCH_FUSE_MPCCP_RSMU_FUSE_UPPER_256KB_H_OFFSET_MASK) | (rsmu_fuse_upper_256kb_h_offset << RSMU_MSMU_FETCH_FUSE_MPCCP_RSMU_FUSE_UPPER_256KB_H_OFFSET_SHIFT)
#define RSMU_MSMU_FETCH_FUSE_MPCCP_SET_RSMU_FUSE_APERTURE_ID_H_OFFSET(rsmu_msmu_fetch_fuse_mpccp_reg, rsmu_fuse_aperture_id_h_offset) \
     rsmu_msmu_fetch_fuse_mpccp_reg = (rsmu_msmu_fetch_fuse_mpccp_reg & ~RSMU_MSMU_FETCH_FUSE_MPCCP_RSMU_FUSE_APERTURE_ID_H_OFFSET_MASK) | (rsmu_fuse_aperture_id_h_offset << RSMU_MSMU_FETCH_FUSE_MPCCP_RSMU_FUSE_APERTURE_ID_H_OFFSET_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_msmu_fetch_fuse_mpccp_t {
          unsigned int rsmu_fuse_upper_256kb_h_offset : RSMU_MSMU_FETCH_FUSE_MPCCP_RSMU_FUSE_UPPER_256KB_H_OFFSET_SIZE;
          unsigned int rsmu_fuse_aperture_id_h_offset : RSMU_MSMU_FETCH_FUSE_MPCCP_RSMU_FUSE_APERTURE_ID_H_OFFSET_SIZE;
          unsigned int                                : 18;
     } rsmu_msmu_fetch_fuse_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_msmu_fetch_fuse_mpccp_t {
          unsigned int                                : 18;
          unsigned int rsmu_fuse_aperture_id_h_offset : RSMU_MSMU_FETCH_FUSE_MPCCP_RSMU_FUSE_APERTURE_ID_H_OFFSET_SIZE;
          unsigned int rsmu_fuse_upper_256kb_h_offset : RSMU_MSMU_FETCH_FUSE_MPCCP_RSMU_FUSE_UPPER_256KB_H_OFFSET_SIZE;
     } rsmu_msmu_fetch_fuse_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_msmu_fetch_fuse_mpccp_t f;
} rsmu_msmu_fetch_fuse_mpccp_u;


/*
 * RSMU_STRAP_STATUS_MPCCP struct
 */

#define RSMU_STRAP_STATUS_MPCCP_REG_SIZE 32
#define RSMU_STRAP_STATUS_MPCCP_RSMU_PUBLIC_FUSE_STATUS_SIZE 1
#define RSMU_STRAP_STATUS_MPCCP_RSMU_SECURITY_FUSE_STATUS_SIZE 1
#define RSMU_STRAP_STATUS_MPCCP_RSMU_SMS_FUSE_STATUS_SIZE 1
#define RSMU_STRAP_STATUS_MPCCP_RSMU_ROM_STRAP_STATUS_SIZE 1

#define RSMU_STRAP_STATUS_MPCCP_RSMU_PUBLIC_FUSE_STATUS_SHIFT 0
#define RSMU_STRAP_STATUS_MPCCP_RSMU_SECURITY_FUSE_STATUS_SHIFT 8
#define RSMU_STRAP_STATUS_MPCCP_RSMU_SMS_FUSE_STATUS_SHIFT 16
#define RSMU_STRAP_STATUS_MPCCP_RSMU_ROM_STRAP_STATUS_SHIFT 24

#define RSMU_STRAP_STATUS_MPCCP_RSMU_PUBLIC_FUSE_STATUS_MASK 0x1
#define RSMU_STRAP_STATUS_MPCCP_RSMU_SECURITY_FUSE_STATUS_MASK 0x100
#define RSMU_STRAP_STATUS_MPCCP_RSMU_SMS_FUSE_STATUS_MASK 0x10000
#define RSMU_STRAP_STATUS_MPCCP_RSMU_ROM_STRAP_STATUS_MASK 0x1000000

#define RSMU_STRAP_STATUS_MPCCP_MASK \
     (RSMU_STRAP_STATUS_MPCCP_RSMU_PUBLIC_FUSE_STATUS_MASK | \
      RSMU_STRAP_STATUS_MPCCP_RSMU_SECURITY_FUSE_STATUS_MASK | \
      RSMU_STRAP_STATUS_MPCCP_RSMU_SMS_FUSE_STATUS_MASK | \
      RSMU_STRAP_STATUS_MPCCP_RSMU_ROM_STRAP_STATUS_MASK)

#define RSMU_STRAP_STATUS_MPCCP_DEFAULT 0x00000000

#define RSMU_STRAP_STATUS_MPCCP_GET_RSMU_PUBLIC_FUSE_STATUS(rsmu_strap_status_mpccp) \
     ((rsmu_strap_status_mpccp & RSMU_STRAP_STATUS_MPCCP_RSMU_PUBLIC_FUSE_STATUS_MASK) >> RSMU_STRAP_STATUS_MPCCP_RSMU_PUBLIC_FUSE_STATUS_SHIFT)
#define RSMU_STRAP_STATUS_MPCCP_GET_RSMU_SECURITY_FUSE_STATUS(rsmu_strap_status_mpccp) \
     ((rsmu_strap_status_mpccp & RSMU_STRAP_STATUS_MPCCP_RSMU_SECURITY_FUSE_STATUS_MASK) >> RSMU_STRAP_STATUS_MPCCP_RSMU_SECURITY_FUSE_STATUS_SHIFT)
#define RSMU_STRAP_STATUS_MPCCP_GET_RSMU_SMS_FUSE_STATUS(rsmu_strap_status_mpccp) \
     ((rsmu_strap_status_mpccp & RSMU_STRAP_STATUS_MPCCP_RSMU_SMS_FUSE_STATUS_MASK) >> RSMU_STRAP_STATUS_MPCCP_RSMU_SMS_FUSE_STATUS_SHIFT)
#define RSMU_STRAP_STATUS_MPCCP_GET_RSMU_ROM_STRAP_STATUS(rsmu_strap_status_mpccp) \
     ((rsmu_strap_status_mpccp & RSMU_STRAP_STATUS_MPCCP_RSMU_ROM_STRAP_STATUS_MASK) >> RSMU_STRAP_STATUS_MPCCP_RSMU_ROM_STRAP_STATUS_SHIFT)

#define RSMU_STRAP_STATUS_MPCCP_SET_RSMU_PUBLIC_FUSE_STATUS(rsmu_strap_status_mpccp_reg, rsmu_public_fuse_status) \
     rsmu_strap_status_mpccp_reg = (rsmu_strap_status_mpccp_reg & ~RSMU_STRAP_STATUS_MPCCP_RSMU_PUBLIC_FUSE_STATUS_MASK) | (rsmu_public_fuse_status << RSMU_STRAP_STATUS_MPCCP_RSMU_PUBLIC_FUSE_STATUS_SHIFT)
#define RSMU_STRAP_STATUS_MPCCP_SET_RSMU_SECURITY_FUSE_STATUS(rsmu_strap_status_mpccp_reg, rsmu_security_fuse_status) \
     rsmu_strap_status_mpccp_reg = (rsmu_strap_status_mpccp_reg & ~RSMU_STRAP_STATUS_MPCCP_RSMU_SECURITY_FUSE_STATUS_MASK) | (rsmu_security_fuse_status << RSMU_STRAP_STATUS_MPCCP_RSMU_SECURITY_FUSE_STATUS_SHIFT)
#define RSMU_STRAP_STATUS_MPCCP_SET_RSMU_SMS_FUSE_STATUS(rsmu_strap_status_mpccp_reg, rsmu_sms_fuse_status) \
     rsmu_strap_status_mpccp_reg = (rsmu_strap_status_mpccp_reg & ~RSMU_STRAP_STATUS_MPCCP_RSMU_SMS_FUSE_STATUS_MASK) | (rsmu_sms_fuse_status << RSMU_STRAP_STATUS_MPCCP_RSMU_SMS_FUSE_STATUS_SHIFT)
#define RSMU_STRAP_STATUS_MPCCP_SET_RSMU_ROM_STRAP_STATUS(rsmu_strap_status_mpccp_reg, rsmu_rom_strap_status) \
     rsmu_strap_status_mpccp_reg = (rsmu_strap_status_mpccp_reg & ~RSMU_STRAP_STATUS_MPCCP_RSMU_ROM_STRAP_STATUS_MASK) | (rsmu_rom_strap_status << RSMU_STRAP_STATUS_MPCCP_RSMU_ROM_STRAP_STATUS_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_strap_status_mpccp_t {
          unsigned int rsmu_public_fuse_status        : RSMU_STRAP_STATUS_MPCCP_RSMU_PUBLIC_FUSE_STATUS_SIZE;
          unsigned int                                : 7;
          unsigned int rsmu_security_fuse_status      : RSMU_STRAP_STATUS_MPCCP_RSMU_SECURITY_FUSE_STATUS_SIZE;
          unsigned int                                : 7;
          unsigned int rsmu_sms_fuse_status           : RSMU_STRAP_STATUS_MPCCP_RSMU_SMS_FUSE_STATUS_SIZE;
          unsigned int                                : 7;
          unsigned int rsmu_rom_strap_status          : RSMU_STRAP_STATUS_MPCCP_RSMU_ROM_STRAP_STATUS_SIZE;
          unsigned int                                : 7;
     } rsmu_strap_status_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_strap_status_mpccp_t {
          unsigned int                                : 7;
          unsigned int rsmu_rom_strap_status          : RSMU_STRAP_STATUS_MPCCP_RSMU_ROM_STRAP_STATUS_SIZE;
          unsigned int                                : 7;
          unsigned int rsmu_sms_fuse_status           : RSMU_STRAP_STATUS_MPCCP_RSMU_SMS_FUSE_STATUS_SIZE;
          unsigned int                                : 7;
          unsigned int rsmu_security_fuse_status      : RSMU_STRAP_STATUS_MPCCP_RSMU_SECURITY_FUSE_STATUS_SIZE;
          unsigned int                                : 7;
          unsigned int rsmu_public_fuse_status        : RSMU_STRAP_STATUS_MPCCP_RSMU_PUBLIC_FUSE_STATUS_SIZE;
     } rsmu_strap_status_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_strap_status_mpccp_t f;
} rsmu_strap_status_mpccp_u;


/*
 * RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP struct
 */

#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_REG_SIZE 32
#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_ADDR_SIZE 20
#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_INITIATORID_SIZE 10
#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_OP_SIZE 1
#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_OUTSTANDING_SIZE 1

#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_ADDR_SHIFT 0
#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_INITIATORID_SHIFT 20
#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_OP_SHIFT 30
#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_OUTSTANDING_SHIFT 31

#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_ADDR_MASK 0xfffff
#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_INITIATORID_MASK 0x3ff00000
#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_OP_MASK 0x40000000
#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_OUTSTANDING_MASK 0x80000000

#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_MASK \
     (RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_ADDR_MASK | \
      RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_INITIATORID_MASK | \
      RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_OP_MASK | \
      RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_OUTSTANDING_MASK)

#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_DEFAULT 0x00000000

#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_GET_RSMU_TIMEOUT_ERROR_ADDR(rsmu_timeout_error_log_reg_mpccp) \
     ((rsmu_timeout_error_log_reg_mpccp & RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_ADDR_MASK) >> RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_ADDR_SHIFT)
#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_GET_RSMU_TIMEOUT_ERROR_INITIATORID(rsmu_timeout_error_log_reg_mpccp) \
     ((rsmu_timeout_error_log_reg_mpccp & RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_INITIATORID_MASK) >> RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_INITIATORID_SHIFT)
#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_GET_RSMU_TIMEOUT_ERROR_OP(rsmu_timeout_error_log_reg_mpccp) \
     ((rsmu_timeout_error_log_reg_mpccp & RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_OP_MASK) >> RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_OP_SHIFT)
#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_GET_RSMU_TIMEOUT_ERROR_OUTSTANDING(rsmu_timeout_error_log_reg_mpccp) \
     ((rsmu_timeout_error_log_reg_mpccp & RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_OUTSTANDING_MASK) >> RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_OUTSTANDING_SHIFT)

#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_SET_RSMU_TIMEOUT_ERROR_ADDR(rsmu_timeout_error_log_reg_mpccp_reg, rsmu_timeout_error_addr) \
     rsmu_timeout_error_log_reg_mpccp_reg = (rsmu_timeout_error_log_reg_mpccp_reg & ~RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_ADDR_MASK) | (rsmu_timeout_error_addr << RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_ADDR_SHIFT)
#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_SET_RSMU_TIMEOUT_ERROR_INITIATORID(rsmu_timeout_error_log_reg_mpccp_reg, rsmu_timeout_error_initiatorid) \
     rsmu_timeout_error_log_reg_mpccp_reg = (rsmu_timeout_error_log_reg_mpccp_reg & ~RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_INITIATORID_MASK) | (rsmu_timeout_error_initiatorid << RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_INITIATORID_SHIFT)
#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_SET_RSMU_TIMEOUT_ERROR_OP(rsmu_timeout_error_log_reg_mpccp_reg, rsmu_timeout_error_op) \
     rsmu_timeout_error_log_reg_mpccp_reg = (rsmu_timeout_error_log_reg_mpccp_reg & ~RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_OP_MASK) | (rsmu_timeout_error_op << RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_OP_SHIFT)
#define RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_SET_RSMU_TIMEOUT_ERROR_OUTSTANDING(rsmu_timeout_error_log_reg_mpccp_reg, rsmu_timeout_error_outstanding) \
     rsmu_timeout_error_log_reg_mpccp_reg = (rsmu_timeout_error_log_reg_mpccp_reg & ~RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_OUTSTANDING_MASK) | (rsmu_timeout_error_outstanding << RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_OUTSTANDING_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_timeout_error_log_reg_mpccp_t {
          unsigned int rsmu_timeout_error_addr        : RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_ADDR_SIZE;
          unsigned int rsmu_timeout_error_initiatorid : RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_INITIATORID_SIZE;
          unsigned int rsmu_timeout_error_op          : RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_OP_SIZE;
          unsigned int rsmu_timeout_error_outstanding : RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_OUTSTANDING_SIZE;
     } rsmu_timeout_error_log_reg_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_timeout_error_log_reg_mpccp_t {
          unsigned int rsmu_timeout_error_outstanding : RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_OUTSTANDING_SIZE;
          unsigned int rsmu_timeout_error_op          : RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_OP_SIZE;
          unsigned int rsmu_timeout_error_initiatorid : RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_INITIATORID_SIZE;
          unsigned int rsmu_timeout_error_addr        : RSMU_TIMEOUT_ERROR_LOG_REG_MPCCP_RSMU_TIMEOUT_ERROR_ADDR_SIZE;
     } rsmu_timeout_error_log_reg_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_timeout_error_log_reg_mpccp_t f;
} rsmu_timeout_error_log_reg_mpccp_u;


/*
 * RSMU_IP_MASTER_STATUS_MPCCP struct
 */

#define RSMU_IP_MASTER_STATUS_MPCCP_REG_SIZE 32
#define RSMU_IP_MASTER_STATUS_MPCCP_RSMU_IP_MASTER_REQ_PENDING_SIZE 1
#define RSMU_IP_MASTER_STATUS_MPCCP_RSMU_IP_MASTER_RESP_PENDING_SIZE 1

#define RSMU_IP_MASTER_STATUS_MPCCP_RSMU_IP_MASTER_REQ_PENDING_SHIFT 0
#define RSMU_IP_MASTER_STATUS_MPCCP_RSMU_IP_MASTER_RESP_PENDING_SHIFT 1

#define RSMU_IP_MASTER_STATUS_MPCCP_RSMU_IP_MASTER_REQ_PENDING_MASK 0x1
#define RSMU_IP_MASTER_STATUS_MPCCP_RSMU_IP_MASTER_RESP_PENDING_MASK 0x2

#define RSMU_IP_MASTER_STATUS_MPCCP_MASK \
     (RSMU_IP_MASTER_STATUS_MPCCP_RSMU_IP_MASTER_REQ_PENDING_MASK | \
      RSMU_IP_MASTER_STATUS_MPCCP_RSMU_IP_MASTER_RESP_PENDING_MASK)

#define RSMU_IP_MASTER_STATUS_MPCCP_DEFAULT 0x00000000

#define RSMU_IP_MASTER_STATUS_MPCCP_GET_RSMU_IP_MASTER_REQ_PENDING(rsmu_ip_master_status_mpccp) \
     ((rsmu_ip_master_status_mpccp & RSMU_IP_MASTER_STATUS_MPCCP_RSMU_IP_MASTER_REQ_PENDING_MASK) >> RSMU_IP_MASTER_STATUS_MPCCP_RSMU_IP_MASTER_REQ_PENDING_SHIFT)
#define RSMU_IP_MASTER_STATUS_MPCCP_GET_RSMU_IP_MASTER_RESP_PENDING(rsmu_ip_master_status_mpccp) \
     ((rsmu_ip_master_status_mpccp & RSMU_IP_MASTER_STATUS_MPCCP_RSMU_IP_MASTER_RESP_PENDING_MASK) >> RSMU_IP_MASTER_STATUS_MPCCP_RSMU_IP_MASTER_RESP_PENDING_SHIFT)

#define RSMU_IP_MASTER_STATUS_MPCCP_SET_RSMU_IP_MASTER_REQ_PENDING(rsmu_ip_master_status_mpccp_reg, rsmu_ip_master_req_pending) \
     rsmu_ip_master_status_mpccp_reg = (rsmu_ip_master_status_mpccp_reg & ~RSMU_IP_MASTER_STATUS_MPCCP_RSMU_IP_MASTER_REQ_PENDING_MASK) | (rsmu_ip_master_req_pending << RSMU_IP_MASTER_STATUS_MPCCP_RSMU_IP_MASTER_REQ_PENDING_SHIFT)
#define RSMU_IP_MASTER_STATUS_MPCCP_SET_RSMU_IP_MASTER_RESP_PENDING(rsmu_ip_master_status_mpccp_reg, rsmu_ip_master_resp_pending) \
     rsmu_ip_master_status_mpccp_reg = (rsmu_ip_master_status_mpccp_reg & ~RSMU_IP_MASTER_STATUS_MPCCP_RSMU_IP_MASTER_RESP_PENDING_MASK) | (rsmu_ip_master_resp_pending << RSMU_IP_MASTER_STATUS_MPCCP_RSMU_IP_MASTER_RESP_PENDING_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_ip_master_status_mpccp_t {
          unsigned int rsmu_ip_master_req_pending     : RSMU_IP_MASTER_STATUS_MPCCP_RSMU_IP_MASTER_REQ_PENDING_SIZE;
          unsigned int rsmu_ip_master_resp_pending    : RSMU_IP_MASTER_STATUS_MPCCP_RSMU_IP_MASTER_RESP_PENDING_SIZE;
          unsigned int                                : 30;
     } rsmu_ip_master_status_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_ip_master_status_mpccp_t {
          unsigned int                                : 30;
          unsigned int rsmu_ip_master_resp_pending    : RSMU_IP_MASTER_STATUS_MPCCP_RSMU_IP_MASTER_RESP_PENDING_SIZE;
          unsigned int rsmu_ip_master_req_pending     : RSMU_IP_MASTER_STATUS_MPCCP_RSMU_IP_MASTER_REQ_PENDING_SIZE;
     } rsmu_ip_master_status_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_ip_master_status_mpccp_t f;
} rsmu_ip_master_status_mpccp_u;


/*
 * RSMU_MMIOEXT_SCRATCH_REG_0_MPCCP struct
 */

#define RSMU_MMIOEXT_SCRATCH_REG_0_MPCCP_REG_SIZE 32
#define RSMU_MMIOEXT_SCRATCH_REG_0_MPCCP_RSMU_MMIOEXT_SCRATCH_REG_0_SIZE 32

#define RSMU_MMIOEXT_SCRATCH_REG_0_MPCCP_RSMU_MMIOEXT_SCRATCH_REG_0_SHIFT 0

#define RSMU_MMIOEXT_SCRATCH_REG_0_MPCCP_RSMU_MMIOEXT_SCRATCH_REG_0_MASK 0xffffffff

#define RSMU_MMIOEXT_SCRATCH_REG_0_MPCCP_MASK \
     (RSMU_MMIOEXT_SCRATCH_REG_0_MPCCP_RSMU_MMIOEXT_SCRATCH_REG_0_MASK)

#define RSMU_MMIOEXT_SCRATCH_REG_0_MPCCP_DEFAULT 0x00000000

#define RSMU_MMIOEXT_SCRATCH_REG_0_MPCCP_GET_RSMU_MMIOEXT_SCRATCH_REG_0(rsmu_mmioext_scratch_reg_0_mpccp) \
     ((rsmu_mmioext_scratch_reg_0_mpccp & RSMU_MMIOEXT_SCRATCH_REG_0_MPCCP_RSMU_MMIOEXT_SCRATCH_REG_0_MASK) >> RSMU_MMIOEXT_SCRATCH_REG_0_MPCCP_RSMU_MMIOEXT_SCRATCH_REG_0_SHIFT)

#define RSMU_MMIOEXT_SCRATCH_REG_0_MPCCP_SET_RSMU_MMIOEXT_SCRATCH_REG_0(rsmu_mmioext_scratch_reg_0_mpccp_reg, rsmu_mmioext_scratch_reg_0) \
     rsmu_mmioext_scratch_reg_0_mpccp_reg = (rsmu_mmioext_scratch_reg_0_mpccp_reg & ~RSMU_MMIOEXT_SCRATCH_REG_0_MPCCP_RSMU_MMIOEXT_SCRATCH_REG_0_MASK) | (rsmu_mmioext_scratch_reg_0 << RSMU_MMIOEXT_SCRATCH_REG_0_MPCCP_RSMU_MMIOEXT_SCRATCH_REG_0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_mmioext_scratch_reg_0_mpccp_t {
          unsigned int rsmu_mmioext_scratch_reg_0     : RSMU_MMIOEXT_SCRATCH_REG_0_MPCCP_RSMU_MMIOEXT_SCRATCH_REG_0_SIZE;
     } rsmu_mmioext_scratch_reg_0_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_mmioext_scratch_reg_0_mpccp_t {
          unsigned int rsmu_mmioext_scratch_reg_0     : RSMU_MMIOEXT_SCRATCH_REG_0_MPCCP_RSMU_MMIOEXT_SCRATCH_REG_0_SIZE;
     } rsmu_mmioext_scratch_reg_0_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_mmioext_scratch_reg_0_mpccp_t f;
} rsmu_mmioext_scratch_reg_0_mpccp_u;


/*
 * RSMU_MMIOEXT_SCRATCH_REG_1_MPCCP struct
 */

#define RSMU_MMIOEXT_SCRATCH_REG_1_MPCCP_REG_SIZE 32
#define RSMU_MMIOEXT_SCRATCH_REG_1_MPCCP_RSMU_MMIOEXT_SCRATCH_REG_1_SIZE 32

#define RSMU_MMIOEXT_SCRATCH_REG_1_MPCCP_RSMU_MMIOEXT_SCRATCH_REG_1_SHIFT 0

#define RSMU_MMIOEXT_SCRATCH_REG_1_MPCCP_RSMU_MMIOEXT_SCRATCH_REG_1_MASK 0xffffffff

#define RSMU_MMIOEXT_SCRATCH_REG_1_MPCCP_MASK \
     (RSMU_MMIOEXT_SCRATCH_REG_1_MPCCP_RSMU_MMIOEXT_SCRATCH_REG_1_MASK)

#define RSMU_MMIOEXT_SCRATCH_REG_1_MPCCP_DEFAULT 0x00000000

#define RSMU_MMIOEXT_SCRATCH_REG_1_MPCCP_GET_RSMU_MMIOEXT_SCRATCH_REG_1(rsmu_mmioext_scratch_reg_1_mpccp) \
     ((rsmu_mmioext_scratch_reg_1_mpccp & RSMU_MMIOEXT_SCRATCH_REG_1_MPCCP_RSMU_MMIOEXT_SCRATCH_REG_1_MASK) >> RSMU_MMIOEXT_SCRATCH_REG_1_MPCCP_RSMU_MMIOEXT_SCRATCH_REG_1_SHIFT)

#define RSMU_MMIOEXT_SCRATCH_REG_1_MPCCP_SET_RSMU_MMIOEXT_SCRATCH_REG_1(rsmu_mmioext_scratch_reg_1_mpccp_reg, rsmu_mmioext_scratch_reg_1) \
     rsmu_mmioext_scratch_reg_1_mpccp_reg = (rsmu_mmioext_scratch_reg_1_mpccp_reg & ~RSMU_MMIOEXT_SCRATCH_REG_1_MPCCP_RSMU_MMIOEXT_SCRATCH_REG_1_MASK) | (rsmu_mmioext_scratch_reg_1 << RSMU_MMIOEXT_SCRATCH_REG_1_MPCCP_RSMU_MMIOEXT_SCRATCH_REG_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_mmioext_scratch_reg_1_mpccp_t {
          unsigned int rsmu_mmioext_scratch_reg_1     : RSMU_MMIOEXT_SCRATCH_REG_1_MPCCP_RSMU_MMIOEXT_SCRATCH_REG_1_SIZE;
     } rsmu_mmioext_scratch_reg_1_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_mmioext_scratch_reg_1_mpccp_t {
          unsigned int rsmu_mmioext_scratch_reg_1     : RSMU_MMIOEXT_SCRATCH_REG_1_MPCCP_RSMU_MMIOEXT_SCRATCH_REG_1_SIZE;
     } rsmu_mmioext_scratch_reg_1_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_mmioext_scratch_reg_1_mpccp_t f;
} rsmu_mmioext_scratch_reg_1_mpccp_u;


/*
 * RSMU_AEB_LOCK_0_MPCCP struct
 */

#define RSMU_AEB_LOCK_0_MPCCP_REG_SIZE 32
#define RSMU_AEB_LOCK_0_MPCCP_RSMU_AEB_LOCK_0_SIZE 29

#define RSMU_AEB_LOCK_0_MPCCP_RSMU_AEB_LOCK_0_SHIFT 3

#define RSMU_AEB_LOCK_0_MPCCP_RSMU_AEB_LOCK_0_MASK 0xfffffff8

#define RSMU_AEB_LOCK_0_MPCCP_MASK \
     (RSMU_AEB_LOCK_0_MPCCP_RSMU_AEB_LOCK_0_MASK)

#define RSMU_AEB_LOCK_0_MPCCP_DEFAULT  0x00000000

#define RSMU_AEB_LOCK_0_MPCCP_GET_RSMU_AEB_LOCK_0(rsmu_aeb_lock_0_mpccp) \
     ((rsmu_aeb_lock_0_mpccp & RSMU_AEB_LOCK_0_MPCCP_RSMU_AEB_LOCK_0_MASK) >> RSMU_AEB_LOCK_0_MPCCP_RSMU_AEB_LOCK_0_SHIFT)

#define RSMU_AEB_LOCK_0_MPCCP_SET_RSMU_AEB_LOCK_0(rsmu_aeb_lock_0_mpccp_reg, rsmu_aeb_lock_0) \
     rsmu_aeb_lock_0_mpccp_reg = (rsmu_aeb_lock_0_mpccp_reg & ~RSMU_AEB_LOCK_0_MPCCP_RSMU_AEB_LOCK_0_MASK) | (rsmu_aeb_lock_0 << RSMU_AEB_LOCK_0_MPCCP_RSMU_AEB_LOCK_0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_aeb_lock_0_mpccp_t {
          unsigned int                                : 3;
          unsigned int rsmu_aeb_lock_0                : RSMU_AEB_LOCK_0_MPCCP_RSMU_AEB_LOCK_0_SIZE;
     } rsmu_aeb_lock_0_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_aeb_lock_0_mpccp_t {
          unsigned int rsmu_aeb_lock_0                : RSMU_AEB_LOCK_0_MPCCP_RSMU_AEB_LOCK_0_SIZE;
          unsigned int                                : 3;
     } rsmu_aeb_lock_0_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_aeb_lock_0_mpccp_t f;
} rsmu_aeb_lock_0_mpccp_u;


/*
 * RSMU_AEB_LOCK_1_MPCCP struct
 */

#define RSMU_AEB_LOCK_1_MPCCP_REG_SIZE 32
#define RSMU_AEB_LOCK_1_MPCCP_RSMU_AEB_LOCK_1_SIZE 32

#define RSMU_AEB_LOCK_1_MPCCP_RSMU_AEB_LOCK_1_SHIFT 0

#define RSMU_AEB_LOCK_1_MPCCP_RSMU_AEB_LOCK_1_MASK 0xffffffff

#define RSMU_AEB_LOCK_1_MPCCP_MASK \
     (RSMU_AEB_LOCK_1_MPCCP_RSMU_AEB_LOCK_1_MASK)

#define RSMU_AEB_LOCK_1_MPCCP_DEFAULT  0x00000000

#define RSMU_AEB_LOCK_1_MPCCP_GET_RSMU_AEB_LOCK_1(rsmu_aeb_lock_1_mpccp) \
     ((rsmu_aeb_lock_1_mpccp & RSMU_AEB_LOCK_1_MPCCP_RSMU_AEB_LOCK_1_MASK) >> RSMU_AEB_LOCK_1_MPCCP_RSMU_AEB_LOCK_1_SHIFT)

#define RSMU_AEB_LOCK_1_MPCCP_SET_RSMU_AEB_LOCK_1(rsmu_aeb_lock_1_mpccp_reg, rsmu_aeb_lock_1) \
     rsmu_aeb_lock_1_mpccp_reg = (rsmu_aeb_lock_1_mpccp_reg & ~RSMU_AEB_LOCK_1_MPCCP_RSMU_AEB_LOCK_1_MASK) | (rsmu_aeb_lock_1 << RSMU_AEB_LOCK_1_MPCCP_RSMU_AEB_LOCK_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_aeb_lock_1_mpccp_t {
          unsigned int rsmu_aeb_lock_1                : RSMU_AEB_LOCK_1_MPCCP_RSMU_AEB_LOCK_1_SIZE;
     } rsmu_aeb_lock_1_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_aeb_lock_1_mpccp_t {
          unsigned int rsmu_aeb_lock_1                : RSMU_AEB_LOCK_1_MPCCP_RSMU_AEB_LOCK_1_SIZE;
     } rsmu_aeb_lock_1_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_aeb_lock_1_mpccp_t f;
} rsmu_aeb_lock_1_mpccp_u;


/*
 * RSMU_AEB_OVERRIDE_0_MPCCP struct
 */

#define RSMU_AEB_OVERRIDE_0_MPCCP_REG_SIZE 32
#define RSMU_AEB_OVERRIDE_0_MPCCP_RSMU_AEB_OVERRIDE_0_SIZE 29

#define RSMU_AEB_OVERRIDE_0_MPCCP_RSMU_AEB_OVERRIDE_0_SHIFT 3

#define RSMU_AEB_OVERRIDE_0_MPCCP_RSMU_AEB_OVERRIDE_0_MASK 0xfffffff8

#define RSMU_AEB_OVERRIDE_0_MPCCP_MASK \
     (RSMU_AEB_OVERRIDE_0_MPCCP_RSMU_AEB_OVERRIDE_0_MASK)

#define RSMU_AEB_OVERRIDE_0_MPCCP_DEFAULT 0x00000000

#define RSMU_AEB_OVERRIDE_0_MPCCP_GET_RSMU_AEB_OVERRIDE_0(rsmu_aeb_override_0_mpccp) \
     ((rsmu_aeb_override_0_mpccp & RSMU_AEB_OVERRIDE_0_MPCCP_RSMU_AEB_OVERRIDE_0_MASK) >> RSMU_AEB_OVERRIDE_0_MPCCP_RSMU_AEB_OVERRIDE_0_SHIFT)

#define RSMU_AEB_OVERRIDE_0_MPCCP_SET_RSMU_AEB_OVERRIDE_0(rsmu_aeb_override_0_mpccp_reg, rsmu_aeb_override_0) \
     rsmu_aeb_override_0_mpccp_reg = (rsmu_aeb_override_0_mpccp_reg & ~RSMU_AEB_OVERRIDE_0_MPCCP_RSMU_AEB_OVERRIDE_0_MASK) | (rsmu_aeb_override_0 << RSMU_AEB_OVERRIDE_0_MPCCP_RSMU_AEB_OVERRIDE_0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_aeb_override_0_mpccp_t {
          unsigned int                                : 3;
          unsigned int rsmu_aeb_override_0            : RSMU_AEB_OVERRIDE_0_MPCCP_RSMU_AEB_OVERRIDE_0_SIZE;
     } rsmu_aeb_override_0_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_aeb_override_0_mpccp_t {
          unsigned int rsmu_aeb_override_0            : RSMU_AEB_OVERRIDE_0_MPCCP_RSMU_AEB_OVERRIDE_0_SIZE;
          unsigned int                                : 3;
     } rsmu_aeb_override_0_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_aeb_override_0_mpccp_t f;
} rsmu_aeb_override_0_mpccp_u;


/*
 * RSMU_AEB_OVERRIDE_1_MPCCP struct
 */

#define RSMU_AEB_OVERRIDE_1_MPCCP_REG_SIZE 32
#define RSMU_AEB_OVERRIDE_1_MPCCP_RSMU_AEB_OVERRIDE_1_SIZE 32

#define RSMU_AEB_OVERRIDE_1_MPCCP_RSMU_AEB_OVERRIDE_1_SHIFT 0

#define RSMU_AEB_OVERRIDE_1_MPCCP_RSMU_AEB_OVERRIDE_1_MASK 0xffffffff

#define RSMU_AEB_OVERRIDE_1_MPCCP_MASK \
     (RSMU_AEB_OVERRIDE_1_MPCCP_RSMU_AEB_OVERRIDE_1_MASK)

#define RSMU_AEB_OVERRIDE_1_MPCCP_DEFAULT 0x00000000

#define RSMU_AEB_OVERRIDE_1_MPCCP_GET_RSMU_AEB_OVERRIDE_1(rsmu_aeb_override_1_mpccp) \
     ((rsmu_aeb_override_1_mpccp & RSMU_AEB_OVERRIDE_1_MPCCP_RSMU_AEB_OVERRIDE_1_MASK) >> RSMU_AEB_OVERRIDE_1_MPCCP_RSMU_AEB_OVERRIDE_1_SHIFT)

#define RSMU_AEB_OVERRIDE_1_MPCCP_SET_RSMU_AEB_OVERRIDE_1(rsmu_aeb_override_1_mpccp_reg, rsmu_aeb_override_1) \
     rsmu_aeb_override_1_mpccp_reg = (rsmu_aeb_override_1_mpccp_reg & ~RSMU_AEB_OVERRIDE_1_MPCCP_RSMU_AEB_OVERRIDE_1_MASK) | (rsmu_aeb_override_1 << RSMU_AEB_OVERRIDE_1_MPCCP_RSMU_AEB_OVERRIDE_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_aeb_override_1_mpccp_t {
          unsigned int rsmu_aeb_override_1            : RSMU_AEB_OVERRIDE_1_MPCCP_RSMU_AEB_OVERRIDE_1_SIZE;
     } rsmu_aeb_override_1_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_aeb_override_1_mpccp_t {
          unsigned int rsmu_aeb_override_1            : RSMU_AEB_OVERRIDE_1_MPCCP_RSMU_AEB_OVERRIDE_1_SIZE;
     } rsmu_aeb_override_1_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_aeb_override_1_mpccp_t f;
} rsmu_aeb_override_1_mpccp_u;


/*
 * RSMU_SEC_INTR_ENABLE_MPCCP struct
 */

#define RSMU_SEC_INTR_ENABLE_MPCCP_REG_SIZE 32
#define RSMU_SEC_INTR_ENABLE_MPCCP_RSMU_SEC_INTR_ENABLE_SIZE 16

#define RSMU_SEC_INTR_ENABLE_MPCCP_RSMU_SEC_INTR_ENABLE_SHIFT 0

#define RSMU_SEC_INTR_ENABLE_MPCCP_RSMU_SEC_INTR_ENABLE_MASK 0xffff

#define RSMU_SEC_INTR_ENABLE_MPCCP_MASK \
     (RSMU_SEC_INTR_ENABLE_MPCCP_RSMU_SEC_INTR_ENABLE_MASK)

#define RSMU_SEC_INTR_ENABLE_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_INTR_ENABLE_MPCCP_GET_RSMU_SEC_INTR_ENABLE(rsmu_sec_intr_enable_mpccp) \
     ((rsmu_sec_intr_enable_mpccp & RSMU_SEC_INTR_ENABLE_MPCCP_RSMU_SEC_INTR_ENABLE_MASK) >> RSMU_SEC_INTR_ENABLE_MPCCP_RSMU_SEC_INTR_ENABLE_SHIFT)

#define RSMU_SEC_INTR_ENABLE_MPCCP_SET_RSMU_SEC_INTR_ENABLE(rsmu_sec_intr_enable_mpccp_reg, rsmu_sec_intr_enable) \
     rsmu_sec_intr_enable_mpccp_reg = (rsmu_sec_intr_enable_mpccp_reg & ~RSMU_SEC_INTR_ENABLE_MPCCP_RSMU_SEC_INTR_ENABLE_MASK) | (rsmu_sec_intr_enable << RSMU_SEC_INTR_ENABLE_MPCCP_RSMU_SEC_INTR_ENABLE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_intr_enable_mpccp_t {
          unsigned int rsmu_sec_intr_enable           : RSMU_SEC_INTR_ENABLE_MPCCP_RSMU_SEC_INTR_ENABLE_SIZE;
          unsigned int                                : 16;
     } rsmu_sec_intr_enable_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_intr_enable_mpccp_t {
          unsigned int                                : 16;
          unsigned int rsmu_sec_intr_enable           : RSMU_SEC_INTR_ENABLE_MPCCP_RSMU_SEC_INTR_ENABLE_SIZE;
     } rsmu_sec_intr_enable_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_intr_enable_mpccp_t f;
} rsmu_sec_intr_enable_mpccp_u;


/*
 * RSMU_SEC_INTR_TARGET_ADDR_MPCCP struct
 */

#define RSMU_SEC_INTR_TARGET_ADDR_MPCCP_REG_SIZE 32
#define RSMU_SEC_INTR_TARGET_ADDR_MPCCP_RSMU_SEC_INTR_TARGET_ADDR_SIZE 32

#define RSMU_SEC_INTR_TARGET_ADDR_MPCCP_RSMU_SEC_INTR_TARGET_ADDR_SHIFT 0

#define RSMU_SEC_INTR_TARGET_ADDR_MPCCP_RSMU_SEC_INTR_TARGET_ADDR_MASK 0xffffffff

#define RSMU_SEC_INTR_TARGET_ADDR_MPCCP_MASK \
     (RSMU_SEC_INTR_TARGET_ADDR_MPCCP_RSMU_SEC_INTR_TARGET_ADDR_MASK)

#define RSMU_SEC_INTR_TARGET_ADDR_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_INTR_TARGET_ADDR_MPCCP_GET_RSMU_SEC_INTR_TARGET_ADDR(rsmu_sec_intr_target_addr_mpccp) \
     ((rsmu_sec_intr_target_addr_mpccp & RSMU_SEC_INTR_TARGET_ADDR_MPCCP_RSMU_SEC_INTR_TARGET_ADDR_MASK) >> RSMU_SEC_INTR_TARGET_ADDR_MPCCP_RSMU_SEC_INTR_TARGET_ADDR_SHIFT)

#define RSMU_SEC_INTR_TARGET_ADDR_MPCCP_SET_RSMU_SEC_INTR_TARGET_ADDR(rsmu_sec_intr_target_addr_mpccp_reg, rsmu_sec_intr_target_addr) \
     rsmu_sec_intr_target_addr_mpccp_reg = (rsmu_sec_intr_target_addr_mpccp_reg & ~RSMU_SEC_INTR_TARGET_ADDR_MPCCP_RSMU_SEC_INTR_TARGET_ADDR_MASK) | (rsmu_sec_intr_target_addr << RSMU_SEC_INTR_TARGET_ADDR_MPCCP_RSMU_SEC_INTR_TARGET_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_intr_target_addr_mpccp_t {
          unsigned int rsmu_sec_intr_target_addr      : RSMU_SEC_INTR_TARGET_ADDR_MPCCP_RSMU_SEC_INTR_TARGET_ADDR_SIZE;
     } rsmu_sec_intr_target_addr_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_intr_target_addr_mpccp_t {
          unsigned int rsmu_sec_intr_target_addr      : RSMU_SEC_INTR_TARGET_ADDR_MPCCP_RSMU_SEC_INTR_TARGET_ADDR_SIZE;
     } rsmu_sec_intr_target_addr_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_intr_target_addr_mpccp_t f;
} rsmu_sec_intr_target_addr_mpccp_u;


/*
 * RSMU_SEC_INTR_CONFIG_MPCCP struct
 */

#define RSMU_SEC_INTR_CONFIG_MPCCP_REG_SIZE 32
#define RSMU_SEC_INTR_CONFIG_MPCCP_RSMU_SEC_INTR_CONFIG_VC_SIZE 2

#define RSMU_SEC_INTR_CONFIG_MPCCP_RSMU_SEC_INTR_CONFIG_VC_SHIFT 0

#define RSMU_SEC_INTR_CONFIG_MPCCP_RSMU_SEC_INTR_CONFIG_VC_MASK 0x3

#define RSMU_SEC_INTR_CONFIG_MPCCP_MASK \
     (RSMU_SEC_INTR_CONFIG_MPCCP_RSMU_SEC_INTR_CONFIG_VC_MASK)

#define RSMU_SEC_INTR_CONFIG_MPCCP_DEFAULT 0x00000001

#define RSMU_SEC_INTR_CONFIG_MPCCP_GET_RSMU_SEC_INTR_CONFIG_VC(rsmu_sec_intr_config_mpccp) \
     ((rsmu_sec_intr_config_mpccp & RSMU_SEC_INTR_CONFIG_MPCCP_RSMU_SEC_INTR_CONFIG_VC_MASK) >> RSMU_SEC_INTR_CONFIG_MPCCP_RSMU_SEC_INTR_CONFIG_VC_SHIFT)

#define RSMU_SEC_INTR_CONFIG_MPCCP_SET_RSMU_SEC_INTR_CONFIG_VC(rsmu_sec_intr_config_mpccp_reg, rsmu_sec_intr_config_vc) \
     rsmu_sec_intr_config_mpccp_reg = (rsmu_sec_intr_config_mpccp_reg & ~RSMU_SEC_INTR_CONFIG_MPCCP_RSMU_SEC_INTR_CONFIG_VC_MASK) | (rsmu_sec_intr_config_vc << RSMU_SEC_INTR_CONFIG_MPCCP_RSMU_SEC_INTR_CONFIG_VC_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_intr_config_mpccp_t {
          unsigned int rsmu_sec_intr_config_vc        : RSMU_SEC_INTR_CONFIG_MPCCP_RSMU_SEC_INTR_CONFIG_VC_SIZE;
          unsigned int                                : 30;
     } rsmu_sec_intr_config_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_intr_config_mpccp_t {
          unsigned int                                : 30;
          unsigned int rsmu_sec_intr_config_vc        : RSMU_SEC_INTR_CONFIG_MPCCP_RSMU_SEC_INTR_CONFIG_VC_SIZE;
     } rsmu_sec_intr_config_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_intr_config_mpccp_t f;
} rsmu_sec_intr_config_mpccp_u;


/*
 * RSMU_SEC_INTR_STATUS_MPCCP struct
 */

#define RSMU_SEC_INTR_STATUS_MPCCP_REG_SIZE 32
#define RSMU_SEC_INTR_STATUS_MPCCP_RSMU_SEC_INTR_STATUS_SIZE 16

#define RSMU_SEC_INTR_STATUS_MPCCP_RSMU_SEC_INTR_STATUS_SHIFT 0

#define RSMU_SEC_INTR_STATUS_MPCCP_RSMU_SEC_INTR_STATUS_MASK 0xffff

#define RSMU_SEC_INTR_STATUS_MPCCP_MASK \
     (RSMU_SEC_INTR_STATUS_MPCCP_RSMU_SEC_INTR_STATUS_MASK)

#define RSMU_SEC_INTR_STATUS_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_INTR_STATUS_MPCCP_GET_RSMU_SEC_INTR_STATUS(rsmu_sec_intr_status_mpccp) \
     ((rsmu_sec_intr_status_mpccp & RSMU_SEC_INTR_STATUS_MPCCP_RSMU_SEC_INTR_STATUS_MASK) >> RSMU_SEC_INTR_STATUS_MPCCP_RSMU_SEC_INTR_STATUS_SHIFT)

#define RSMU_SEC_INTR_STATUS_MPCCP_SET_RSMU_SEC_INTR_STATUS(rsmu_sec_intr_status_mpccp_reg, rsmu_sec_intr_status) \
     rsmu_sec_intr_status_mpccp_reg = (rsmu_sec_intr_status_mpccp_reg & ~RSMU_SEC_INTR_STATUS_MPCCP_RSMU_SEC_INTR_STATUS_MASK) | (rsmu_sec_intr_status << RSMU_SEC_INTR_STATUS_MPCCP_RSMU_SEC_INTR_STATUS_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_intr_status_mpccp_t {
          unsigned int rsmu_sec_intr_status           : RSMU_SEC_INTR_STATUS_MPCCP_RSMU_SEC_INTR_STATUS_SIZE;
          unsigned int                                : 16;
     } rsmu_sec_intr_status_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_intr_status_mpccp_t {
          unsigned int                                : 16;
          unsigned int rsmu_sec_intr_status           : RSMU_SEC_INTR_STATUS_MPCCP_RSMU_SEC_INTR_STATUS_SIZE;
     } rsmu_sec_intr_status_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_intr_status_mpccp_t f;
} rsmu_sec_intr_status_mpccp_u;


/*
 * RSMU_SEC_INTR_PENDING_MPCCP struct
 */

#define RSMU_SEC_INTR_PENDING_MPCCP_REG_SIZE 32
#define RSMU_SEC_INTR_PENDING_MPCCP_RSMU_SEC_INTR_PENDING_SIZE 16

#define RSMU_SEC_INTR_PENDING_MPCCP_RSMU_SEC_INTR_PENDING_SHIFT 0

#define RSMU_SEC_INTR_PENDING_MPCCP_RSMU_SEC_INTR_PENDING_MASK 0xffff

#define RSMU_SEC_INTR_PENDING_MPCCP_MASK \
     (RSMU_SEC_INTR_PENDING_MPCCP_RSMU_SEC_INTR_PENDING_MASK)

#define RSMU_SEC_INTR_PENDING_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_INTR_PENDING_MPCCP_GET_RSMU_SEC_INTR_PENDING(rsmu_sec_intr_pending_mpccp) \
     ((rsmu_sec_intr_pending_mpccp & RSMU_SEC_INTR_PENDING_MPCCP_RSMU_SEC_INTR_PENDING_MASK) >> RSMU_SEC_INTR_PENDING_MPCCP_RSMU_SEC_INTR_PENDING_SHIFT)

#define RSMU_SEC_INTR_PENDING_MPCCP_SET_RSMU_SEC_INTR_PENDING(rsmu_sec_intr_pending_mpccp_reg, rsmu_sec_intr_pending) \
     rsmu_sec_intr_pending_mpccp_reg = (rsmu_sec_intr_pending_mpccp_reg & ~RSMU_SEC_INTR_PENDING_MPCCP_RSMU_SEC_INTR_PENDING_MASK) | (rsmu_sec_intr_pending << RSMU_SEC_INTR_PENDING_MPCCP_RSMU_SEC_INTR_PENDING_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_intr_pending_mpccp_t {
          unsigned int rsmu_sec_intr_pending          : RSMU_SEC_INTR_PENDING_MPCCP_RSMU_SEC_INTR_PENDING_SIZE;
          unsigned int                                : 16;
     } rsmu_sec_intr_pending_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_intr_pending_mpccp_t {
          unsigned int                                : 16;
          unsigned int rsmu_sec_intr_pending          : RSMU_SEC_INTR_PENDING_MPCCP_RSMU_SEC_INTR_PENDING_SIZE;
     } rsmu_sec_intr_pending_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_intr_pending_mpccp_t f;
} rsmu_sec_intr_pending_mpccp_u;


/*
 * RSMU_SEC_INTR_TYPE_MPCCP struct
 */

#define RSMU_SEC_INTR_TYPE_MPCCP_REG_SIZE 32
#define RSMU_SEC_INTR_TYPE_MPCCP_RSMU_SEC_INTR_TYPE_SIZE 16

#define RSMU_SEC_INTR_TYPE_MPCCP_RSMU_SEC_INTR_TYPE_SHIFT 0

#define RSMU_SEC_INTR_TYPE_MPCCP_RSMU_SEC_INTR_TYPE_MASK 0xffff

#define RSMU_SEC_INTR_TYPE_MPCCP_MASK \
     (RSMU_SEC_INTR_TYPE_MPCCP_RSMU_SEC_INTR_TYPE_MASK)

#define RSMU_SEC_INTR_TYPE_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_INTR_TYPE_MPCCP_GET_RSMU_SEC_INTR_TYPE(rsmu_sec_intr_type_mpccp) \
     ((rsmu_sec_intr_type_mpccp & RSMU_SEC_INTR_TYPE_MPCCP_RSMU_SEC_INTR_TYPE_MASK) >> RSMU_SEC_INTR_TYPE_MPCCP_RSMU_SEC_INTR_TYPE_SHIFT)

#define RSMU_SEC_INTR_TYPE_MPCCP_SET_RSMU_SEC_INTR_TYPE(rsmu_sec_intr_type_mpccp_reg, rsmu_sec_intr_type) \
     rsmu_sec_intr_type_mpccp_reg = (rsmu_sec_intr_type_mpccp_reg & ~RSMU_SEC_INTR_TYPE_MPCCP_RSMU_SEC_INTR_TYPE_MASK) | (rsmu_sec_intr_type << RSMU_SEC_INTR_TYPE_MPCCP_RSMU_SEC_INTR_TYPE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_intr_type_mpccp_t {
          unsigned int rsmu_sec_intr_type             : RSMU_SEC_INTR_TYPE_MPCCP_RSMU_SEC_INTR_TYPE_SIZE;
          unsigned int                                : 16;
     } rsmu_sec_intr_type_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_intr_type_mpccp_t {
          unsigned int                                : 16;
          unsigned int rsmu_sec_intr_type             : RSMU_SEC_INTR_TYPE_MPCCP_RSMU_SEC_INTR_TYPE_SIZE;
     } rsmu_sec_intr_type_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_intr_type_mpccp_t f;
} rsmu_sec_intr_type_mpccp_u;


/*
 * RSMU_SEC_INTR_INTERCEPT_MPCCP struct
 */

#define RSMU_SEC_INTR_INTERCEPT_MPCCP_REG_SIZE 32
#define RSMU_SEC_INTR_INTERCEPT_MPCCP_RSMU_SEC_INTR_OVERRIDE_SIZE 16
#define RSMU_SEC_INTR_INTERCEPT_MPCCP_RSMU_SEC_INTR_VALUE_SIZE 16

#define RSMU_SEC_INTR_INTERCEPT_MPCCP_RSMU_SEC_INTR_OVERRIDE_SHIFT 0
#define RSMU_SEC_INTR_INTERCEPT_MPCCP_RSMU_SEC_INTR_VALUE_SHIFT 16

#define RSMU_SEC_INTR_INTERCEPT_MPCCP_RSMU_SEC_INTR_OVERRIDE_MASK 0xffff
#define RSMU_SEC_INTR_INTERCEPT_MPCCP_RSMU_SEC_INTR_VALUE_MASK 0xffff0000

#define RSMU_SEC_INTR_INTERCEPT_MPCCP_MASK \
     (RSMU_SEC_INTR_INTERCEPT_MPCCP_RSMU_SEC_INTR_OVERRIDE_MASK | \
      RSMU_SEC_INTR_INTERCEPT_MPCCP_RSMU_SEC_INTR_VALUE_MASK)

#define RSMU_SEC_INTR_INTERCEPT_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_INTR_INTERCEPT_MPCCP_GET_RSMU_SEC_INTR_OVERRIDE(rsmu_sec_intr_intercept_mpccp) \
     ((rsmu_sec_intr_intercept_mpccp & RSMU_SEC_INTR_INTERCEPT_MPCCP_RSMU_SEC_INTR_OVERRIDE_MASK) >> RSMU_SEC_INTR_INTERCEPT_MPCCP_RSMU_SEC_INTR_OVERRIDE_SHIFT)
#define RSMU_SEC_INTR_INTERCEPT_MPCCP_GET_RSMU_SEC_INTR_VALUE(rsmu_sec_intr_intercept_mpccp) \
     ((rsmu_sec_intr_intercept_mpccp & RSMU_SEC_INTR_INTERCEPT_MPCCP_RSMU_SEC_INTR_VALUE_MASK) >> RSMU_SEC_INTR_INTERCEPT_MPCCP_RSMU_SEC_INTR_VALUE_SHIFT)

#define RSMU_SEC_INTR_INTERCEPT_MPCCP_SET_RSMU_SEC_INTR_OVERRIDE(rsmu_sec_intr_intercept_mpccp_reg, rsmu_sec_intr_override) \
     rsmu_sec_intr_intercept_mpccp_reg = (rsmu_sec_intr_intercept_mpccp_reg & ~RSMU_SEC_INTR_INTERCEPT_MPCCP_RSMU_SEC_INTR_OVERRIDE_MASK) | (rsmu_sec_intr_override << RSMU_SEC_INTR_INTERCEPT_MPCCP_RSMU_SEC_INTR_OVERRIDE_SHIFT)
#define RSMU_SEC_INTR_INTERCEPT_MPCCP_SET_RSMU_SEC_INTR_VALUE(rsmu_sec_intr_intercept_mpccp_reg, rsmu_sec_intr_value) \
     rsmu_sec_intr_intercept_mpccp_reg = (rsmu_sec_intr_intercept_mpccp_reg & ~RSMU_SEC_INTR_INTERCEPT_MPCCP_RSMU_SEC_INTR_VALUE_MASK) | (rsmu_sec_intr_value << RSMU_SEC_INTR_INTERCEPT_MPCCP_RSMU_SEC_INTR_VALUE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_intr_intercept_mpccp_t {
          unsigned int rsmu_sec_intr_override         : RSMU_SEC_INTR_INTERCEPT_MPCCP_RSMU_SEC_INTR_OVERRIDE_SIZE;
          unsigned int rsmu_sec_intr_value            : RSMU_SEC_INTR_INTERCEPT_MPCCP_RSMU_SEC_INTR_VALUE_SIZE;
     } rsmu_sec_intr_intercept_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_intr_intercept_mpccp_t {
          unsigned int rsmu_sec_intr_value            : RSMU_SEC_INTR_INTERCEPT_MPCCP_RSMU_SEC_INTR_VALUE_SIZE;
          unsigned int rsmu_sec_intr_override         : RSMU_SEC_INTR_INTERCEPT_MPCCP_RSMU_SEC_INTR_OVERRIDE_SIZE;
     } rsmu_sec_intr_intercept_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_intr_intercept_mpccp_t f;
} rsmu_sec_intr_intercept_mpccp_u;


/*
 * RSMU_SEC_INTR_CLEAR_MPCCP struct
 */

#define RSMU_SEC_INTR_CLEAR_MPCCP_REG_SIZE 32
#define RSMU_SEC_INTR_CLEAR_MPCCP_RSMU_SEC_INTR_CLEAR_SIZE 16

#define RSMU_SEC_INTR_CLEAR_MPCCP_RSMU_SEC_INTR_CLEAR_SHIFT 0

#define RSMU_SEC_INTR_CLEAR_MPCCP_RSMU_SEC_INTR_CLEAR_MASK 0xffff

#define RSMU_SEC_INTR_CLEAR_MPCCP_MASK \
     (RSMU_SEC_INTR_CLEAR_MPCCP_RSMU_SEC_INTR_CLEAR_MASK)

#define RSMU_SEC_INTR_CLEAR_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_INTR_CLEAR_MPCCP_GET_RSMU_SEC_INTR_CLEAR(rsmu_sec_intr_clear_mpccp) \
     ((rsmu_sec_intr_clear_mpccp & RSMU_SEC_INTR_CLEAR_MPCCP_RSMU_SEC_INTR_CLEAR_MASK) >> RSMU_SEC_INTR_CLEAR_MPCCP_RSMU_SEC_INTR_CLEAR_SHIFT)

#define RSMU_SEC_INTR_CLEAR_MPCCP_SET_RSMU_SEC_INTR_CLEAR(rsmu_sec_intr_clear_mpccp_reg, rsmu_sec_intr_clear) \
     rsmu_sec_intr_clear_mpccp_reg = (rsmu_sec_intr_clear_mpccp_reg & ~RSMU_SEC_INTR_CLEAR_MPCCP_RSMU_SEC_INTR_CLEAR_MASK) | (rsmu_sec_intr_clear << RSMU_SEC_INTR_CLEAR_MPCCP_RSMU_SEC_INTR_CLEAR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_intr_clear_mpccp_t {
          unsigned int rsmu_sec_intr_clear            : RSMU_SEC_INTR_CLEAR_MPCCP_RSMU_SEC_INTR_CLEAR_SIZE;
          unsigned int                                : 16;
     } rsmu_sec_intr_clear_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_intr_clear_mpccp_t {
          unsigned int                                : 16;
          unsigned int rsmu_sec_intr_clear            : RSMU_SEC_INTR_CLEAR_MPCCP_RSMU_SEC_INTR_CLEAR_SIZE;
     } rsmu_sec_intr_clear_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_intr_clear_mpccp_t f;
} rsmu_sec_intr_clear_mpccp_u;


/*
 * RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MPCCP struct
 */

#define RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MPCCP_REG_SIZE 32
#define RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_SIZE 24

#define RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_SHIFT 0

#define RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MASK 0xffffff

#define RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MPCCP_MASK \
     (RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MASK)

#define RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MPCCP_DEFAULT 0x00ffffff

#define RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MPCCP_GET_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU(rsmu_sec_master_trust_level_rsmu_mpccp) \
     ((rsmu_sec_master_trust_level_rsmu_mpccp & RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MASK) >> RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_SHIFT)

#define RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MPCCP_SET_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU(rsmu_sec_master_trust_level_rsmu_mpccp_reg, rsmu_sec_master_trust_level_rsmu) \
     rsmu_sec_master_trust_level_rsmu_mpccp_reg = (rsmu_sec_master_trust_level_rsmu_mpccp_reg & ~RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MASK) | (rsmu_sec_master_trust_level_rsmu << RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_master_trust_level_rsmu_mpccp_t {
          unsigned int rsmu_sec_master_trust_level_rsmu : RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_SIZE;
          unsigned int                                : 8;
     } rsmu_sec_master_trust_level_rsmu_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_master_trust_level_rsmu_mpccp_t {
          unsigned int                                : 8;
          unsigned int rsmu_sec_master_trust_level_rsmu : RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_SIZE;
     } rsmu_sec_master_trust_level_rsmu_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_master_trust_level_rsmu_mpccp_t f;
} rsmu_sec_master_trust_level_rsmu_mpccp_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP struct
 */

#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_REG_SIZE 32
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1_SIZE 1
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2_SIZE 1
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2_SIZE 8
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2_SIZE 8
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SECURITY_SLAVE_LOCK_SIZE 1
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SOFT_RESETB_ACCESS_LOCK_SIZE 1
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_PGFSM_ACCESS_LOCK_SIZE 1
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SW_STRAPRX_LOCK_SIZE 1

#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1_SHIFT 0
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2_SHIFT 1
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2_SHIFT 2
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2_SHIFT 10
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SECURITY_SLAVE_LOCK_SHIFT 18
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SOFT_RESETB_ACCESS_LOCK_SHIFT 19
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_PGFSM_ACCESS_LOCK_SHIFT 20
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SW_STRAPRX_LOCK_SHIFT 21

#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1_MASK 0x1
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2_MASK 0x2
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2_MASK 0x3fc
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2_MASK 0x3fc00
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SECURITY_SLAVE_LOCK_MASK 0x40000
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SOFT_RESETB_ACCESS_LOCK_MASK 0x80000
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_PGFSM_ACCESS_LOCK_MASK 0x100000
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SW_STRAPRX_LOCK_MASK 0x200000

#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_MASK \
     (RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1_MASK | \
      RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2_MASK | \
      RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2_MASK | \
      RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2_MASK | \
      RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SECURITY_SLAVE_LOCK_MASK | \
      RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SOFT_RESETB_ACCESS_LOCK_MASK | \
      RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_PGFSM_ACCESS_LOCK_MASK | \
      RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SW_STRAPRX_LOCK_MASK)

#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_DEFAULT 0x0001fdfc

#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_GET_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1(rsmu_sec_access_control_rsmu_mpccp) \
     ((rsmu_sec_access_control_rsmu_mpccp & RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1_MASK) >> RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_GET_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2(rsmu_sec_access_control_rsmu_mpccp) \
     ((rsmu_sec_access_control_rsmu_mpccp & RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2_MASK) >> RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_GET_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2(rsmu_sec_access_control_rsmu_mpccp) \
     ((rsmu_sec_access_control_rsmu_mpccp & RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2_MASK) >> RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_GET_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2(rsmu_sec_access_control_rsmu_mpccp) \
     ((rsmu_sec_access_control_rsmu_mpccp & RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2_MASK) >> RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_GET_RSMU_SECURITY_SLAVE_LOCK(rsmu_sec_access_control_rsmu_mpccp) \
     ((rsmu_sec_access_control_rsmu_mpccp & RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SECURITY_SLAVE_LOCK_MASK) >> RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SECURITY_SLAVE_LOCK_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_GET_RSMU_SOFT_RESETB_ACCESS_LOCK(rsmu_sec_access_control_rsmu_mpccp) \
     ((rsmu_sec_access_control_rsmu_mpccp & RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SOFT_RESETB_ACCESS_LOCK_MASK) >> RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SOFT_RESETB_ACCESS_LOCK_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_GET_RSMU_PGFSM_ACCESS_LOCK(rsmu_sec_access_control_rsmu_mpccp) \
     ((rsmu_sec_access_control_rsmu_mpccp & RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_PGFSM_ACCESS_LOCK_MASK) >> RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_PGFSM_ACCESS_LOCK_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_GET_RSMU_SW_STRAPRX_LOCK(rsmu_sec_access_control_rsmu_mpccp) \
     ((rsmu_sec_access_control_rsmu_mpccp & RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SW_STRAPRX_LOCK_MASK) >> RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SW_STRAPRX_LOCK_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_SET_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1(rsmu_sec_access_control_rsmu_mpccp_reg, rsmu_sec_check_enable_rsmu_range1) \
     rsmu_sec_access_control_rsmu_mpccp_reg = (rsmu_sec_access_control_rsmu_mpccp_reg & ~RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1_MASK) | (rsmu_sec_check_enable_rsmu_range1 << RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_SET_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2(rsmu_sec_access_control_rsmu_mpccp_reg, rsmu_sec_check_enable_rsmu_range2) \
     rsmu_sec_access_control_rsmu_mpccp_reg = (rsmu_sec_access_control_rsmu_mpccp_reg & ~RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2_MASK) | (rsmu_sec_check_enable_rsmu_range2 << RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_SET_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2(rsmu_sec_access_control_rsmu_mpccp_reg, rsmu_sec_rd_tlvl_mask_rsmu_range2) \
     rsmu_sec_access_control_rsmu_mpccp_reg = (rsmu_sec_access_control_rsmu_mpccp_reg & ~RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2_MASK) | (rsmu_sec_rd_tlvl_mask_rsmu_range2 << RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_SET_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2(rsmu_sec_access_control_rsmu_mpccp_reg, rsmu_sec_wr_tlvl_mask_rsmu_range2) \
     rsmu_sec_access_control_rsmu_mpccp_reg = (rsmu_sec_access_control_rsmu_mpccp_reg & ~RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2_MASK) | (rsmu_sec_wr_tlvl_mask_rsmu_range2 << RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_SET_RSMU_SECURITY_SLAVE_LOCK(rsmu_sec_access_control_rsmu_mpccp_reg, rsmu_security_slave_lock) \
     rsmu_sec_access_control_rsmu_mpccp_reg = (rsmu_sec_access_control_rsmu_mpccp_reg & ~RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SECURITY_SLAVE_LOCK_MASK) | (rsmu_security_slave_lock << RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SECURITY_SLAVE_LOCK_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_SET_RSMU_SOFT_RESETB_ACCESS_LOCK(rsmu_sec_access_control_rsmu_mpccp_reg, rsmu_soft_resetb_access_lock) \
     rsmu_sec_access_control_rsmu_mpccp_reg = (rsmu_sec_access_control_rsmu_mpccp_reg & ~RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SOFT_RESETB_ACCESS_LOCK_MASK) | (rsmu_soft_resetb_access_lock << RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SOFT_RESETB_ACCESS_LOCK_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_SET_RSMU_PGFSM_ACCESS_LOCK(rsmu_sec_access_control_rsmu_mpccp_reg, rsmu_pgfsm_access_lock) \
     rsmu_sec_access_control_rsmu_mpccp_reg = (rsmu_sec_access_control_rsmu_mpccp_reg & ~RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_PGFSM_ACCESS_LOCK_MASK) | (rsmu_pgfsm_access_lock << RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_PGFSM_ACCESS_LOCK_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_SET_RSMU_SW_STRAPRX_LOCK(rsmu_sec_access_control_rsmu_mpccp_reg, rsmu_sw_straprx_lock) \
     rsmu_sec_access_control_rsmu_mpccp_reg = (rsmu_sec_access_control_rsmu_mpccp_reg & ~RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SW_STRAPRX_LOCK_MASK) | (rsmu_sw_straprx_lock << RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SW_STRAPRX_LOCK_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_access_control_rsmu_mpccp_t {
          unsigned int rsmu_sec_check_enable_rsmu_range1 : RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1_SIZE;
          unsigned int rsmu_sec_check_enable_rsmu_range2 : RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2_SIZE;
          unsigned int rsmu_sec_rd_tlvl_mask_rsmu_range2 : RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2_SIZE;
          unsigned int rsmu_sec_wr_tlvl_mask_rsmu_range2 : RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2_SIZE;
          unsigned int rsmu_security_slave_lock       : RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SECURITY_SLAVE_LOCK_SIZE;
          unsigned int rsmu_soft_resetb_access_lock   : RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SOFT_RESETB_ACCESS_LOCK_SIZE;
          unsigned int rsmu_pgfsm_access_lock         : RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_PGFSM_ACCESS_LOCK_SIZE;
          unsigned int rsmu_sw_straprx_lock           : RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SW_STRAPRX_LOCK_SIZE;
          unsigned int                                : 10;
     } rsmu_sec_access_control_rsmu_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_access_control_rsmu_mpccp_t {
          unsigned int                                : 10;
          unsigned int rsmu_sw_straprx_lock           : RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SW_STRAPRX_LOCK_SIZE;
          unsigned int rsmu_pgfsm_access_lock         : RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_PGFSM_ACCESS_LOCK_SIZE;
          unsigned int rsmu_soft_resetb_access_lock   : RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SOFT_RESETB_ACCESS_LOCK_SIZE;
          unsigned int rsmu_security_slave_lock       : RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SECURITY_SLAVE_LOCK_SIZE;
          unsigned int rsmu_sec_wr_tlvl_mask_rsmu_range2 : RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2_SIZE;
          unsigned int rsmu_sec_rd_tlvl_mask_rsmu_range2 : RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2_SIZE;
          unsigned int rsmu_sec_check_enable_rsmu_range2 : RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2_SIZE;
          unsigned int rsmu_sec_check_enable_rsmu_range1 : RSMU_SEC_ACCESS_CONTROL_RSMU_MPCCP_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1_SIZE;
     } rsmu_sec_access_control_rsmu_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_access_control_rsmu_mpccp_t f;
} rsmu_sec_access_control_rsmu_mpccp_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MPCCP struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MPCCP_REG_SIZE 32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_SIZE 20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_SHIFT 0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MASK 0xfffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MPCCP_MASK \
     (RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MPCCP_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT(rsmu_sec_initid_mask_set0_group_default_mpccp) \
     ((rsmu_sec_initid_mask_set0_group_default_mpccp & RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MPCCP_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT(rsmu_sec_initid_mask_set0_group_default_mpccp_reg, rsmu_sec_initid_mask_set0_group_default) \
     rsmu_sec_initid_mask_set0_group_default_mpccp_reg = (rsmu_sec_initid_mask_set0_group_default_mpccp_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MASK) | (rsmu_sec_initid_mask_set0_group_default << RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_initid_mask_set0_group_default_mpccp_t {
          unsigned int rsmu_sec_initid_mask_set0_group_default : RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_SIZE;
          unsigned int                                : 12;
     } rsmu_sec_initid_mask_set0_group_default_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_initid_mask_set0_group_default_mpccp_t {
          unsigned int                                : 12;
          unsigned int rsmu_sec_initid_mask_set0_group_default : RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_SIZE;
     } rsmu_sec_initid_mask_set0_group_default_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_initid_mask_set0_group_default_mpccp_t f;
} rsmu_sec_initid_mask_set0_group_default_mpccp_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MPCCP struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MPCCP_REG_SIZE 32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_SIZE 18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_SHIFT 0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MASK 0x3ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MPCCP_MASK \
     (RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MPCCP_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT(rsmu_sec_unitid_mask_set0_group_default_mpccp) \
     ((rsmu_sec_unitid_mask_set0_group_default_mpccp & RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MPCCP_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT(rsmu_sec_unitid_mask_set0_group_default_mpccp_reg, rsmu_sec_unitid_mask_set0_group_default) \
     rsmu_sec_unitid_mask_set0_group_default_mpccp_reg = (rsmu_sec_unitid_mask_set0_group_default_mpccp_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MASK) | (rsmu_sec_unitid_mask_set0_group_default << RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_unitid_mask_set0_group_default_mpccp_t {
          unsigned int rsmu_sec_unitid_mask_set0_group_default : RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_SIZE;
          unsigned int                                : 14;
     } rsmu_sec_unitid_mask_set0_group_default_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_unitid_mask_set0_group_default_mpccp_t {
          unsigned int                                : 14;
          unsigned int rsmu_sec_unitid_mask_set0_group_default : RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_SIZE;
     } rsmu_sec_unitid_mask_set0_group_default_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_unitid_mask_set0_group_default_mpccp_t f;
} rsmu_sec_unitid_mask_set0_group_default_mpccp_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_REG_SIZE 32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT_SIZE 8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT_SIZE 2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT_SIZE 1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT_SHIFT 0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT_SHIFT 8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT_SHIFT 10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT_MASK 0xff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT_MASK 0x300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT_MASK 0x400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_MASK \
     (RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT(rsmu_sec_misc_mask_set0_group_default_mpccp) \
     ((rsmu_sec_misc_mask_set0_group_default_mpccp & RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_GET_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT(rsmu_sec_misc_mask_set0_group_default_mpccp) \
     ((rsmu_sec_misc_mask_set0_group_default_mpccp & RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_GET_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT(rsmu_sec_misc_mask_set0_group_default_mpccp) \
     ((rsmu_sec_misc_mask_set0_group_default_mpccp & RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT(rsmu_sec_misc_mask_set0_group_default_mpccp_reg, rsmu_sec_tlvl_mask_set0_group_default) \
     rsmu_sec_misc_mask_set0_group_default_mpccp_reg = (rsmu_sec_misc_mask_set0_group_default_mpccp_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT_MASK) | (rsmu_sec_tlvl_mask_set0_group_default << RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_SET_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT(rsmu_sec_misc_mask_set0_group_default_mpccp_reg, rsmu_sec_rw_mask_set0_group_default) \
     rsmu_sec_misc_mask_set0_group_default_mpccp_reg = (rsmu_sec_misc_mask_set0_group_default_mpccp_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT_MASK) | (rsmu_sec_rw_mask_set0_group_default << RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_SET_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT(rsmu_sec_misc_mask_set0_group_default_mpccp_reg, rsmu_sec_vf_mask_set0_group_default) \
     rsmu_sec_misc_mask_set0_group_default_mpccp_reg = (rsmu_sec_misc_mask_set0_group_default_mpccp_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT_MASK) | (rsmu_sec_vf_mask_set0_group_default << RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_misc_mask_set0_group_default_mpccp_t {
          unsigned int rsmu_sec_tlvl_mask_set0_group_default : RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT_SIZE;
          unsigned int rsmu_sec_rw_mask_set0_group_default : RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT_SIZE;
          unsigned int rsmu_sec_vf_mask_set0_group_default : RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT_SIZE;
          unsigned int                                : 21;
     } rsmu_sec_misc_mask_set0_group_default_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_misc_mask_set0_group_default_mpccp_t {
          unsigned int                                : 21;
          unsigned int rsmu_sec_vf_mask_set0_group_default : RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT_SIZE;
          unsigned int rsmu_sec_rw_mask_set0_group_default : RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT_SIZE;
          unsigned int rsmu_sec_tlvl_mask_set0_group_default : RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT_SIZE;
     } rsmu_sec_misc_mask_set0_group_default_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_misc_mask_set0_group_default_mpccp_t f;
} rsmu_sec_misc_mask_set0_group_default_mpccp_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MPCCP struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MPCCP_REG_SIZE 32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_SIZE 20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_SHIFT 0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MASK 0xfffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MPCCP_MASK \
     (RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MPCCP_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT(rsmu_sec_initid_mask_set1_group_default_mpccp) \
     ((rsmu_sec_initid_mask_set1_group_default_mpccp & RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MPCCP_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT(rsmu_sec_initid_mask_set1_group_default_mpccp_reg, rsmu_sec_initid_mask_set1_group_default) \
     rsmu_sec_initid_mask_set1_group_default_mpccp_reg = (rsmu_sec_initid_mask_set1_group_default_mpccp_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MASK) | (rsmu_sec_initid_mask_set1_group_default << RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_initid_mask_set1_group_default_mpccp_t {
          unsigned int rsmu_sec_initid_mask_set1_group_default : RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_SIZE;
          unsigned int                                : 12;
     } rsmu_sec_initid_mask_set1_group_default_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_initid_mask_set1_group_default_mpccp_t {
          unsigned int                                : 12;
          unsigned int rsmu_sec_initid_mask_set1_group_default : RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_SIZE;
     } rsmu_sec_initid_mask_set1_group_default_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_initid_mask_set1_group_default_mpccp_t f;
} rsmu_sec_initid_mask_set1_group_default_mpccp_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MPCCP struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MPCCP_REG_SIZE 32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_SIZE 18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_SHIFT 0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MASK 0x3ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MPCCP_MASK \
     (RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MPCCP_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT(rsmu_sec_unitid_mask_set1_group_default_mpccp) \
     ((rsmu_sec_unitid_mask_set1_group_default_mpccp & RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MPCCP_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT(rsmu_sec_unitid_mask_set1_group_default_mpccp_reg, rsmu_sec_unitid_mask_set1_group_default) \
     rsmu_sec_unitid_mask_set1_group_default_mpccp_reg = (rsmu_sec_unitid_mask_set1_group_default_mpccp_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MASK) | (rsmu_sec_unitid_mask_set1_group_default << RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_unitid_mask_set1_group_default_mpccp_t {
          unsigned int rsmu_sec_unitid_mask_set1_group_default : RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_SIZE;
          unsigned int                                : 14;
     } rsmu_sec_unitid_mask_set1_group_default_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_unitid_mask_set1_group_default_mpccp_t {
          unsigned int                                : 14;
          unsigned int rsmu_sec_unitid_mask_set1_group_default : RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_SIZE;
     } rsmu_sec_unitid_mask_set1_group_default_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_unitid_mask_set1_group_default_mpccp_t f;
} rsmu_sec_unitid_mask_set1_group_default_mpccp_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_REG_SIZE 32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT_SIZE 8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT_SIZE 2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT_SIZE 1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT_SHIFT 0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT_SHIFT 8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT_SHIFT 10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT_MASK 0xff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT_MASK 0x300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT_MASK 0x400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_MASK \
     (RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT(rsmu_sec_misc_mask_set1_group_default_mpccp) \
     ((rsmu_sec_misc_mask_set1_group_default_mpccp & RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_GET_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT(rsmu_sec_misc_mask_set1_group_default_mpccp) \
     ((rsmu_sec_misc_mask_set1_group_default_mpccp & RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_GET_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT(rsmu_sec_misc_mask_set1_group_default_mpccp) \
     ((rsmu_sec_misc_mask_set1_group_default_mpccp & RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT(rsmu_sec_misc_mask_set1_group_default_mpccp_reg, rsmu_sec_tlvl_mask_set1_group_default) \
     rsmu_sec_misc_mask_set1_group_default_mpccp_reg = (rsmu_sec_misc_mask_set1_group_default_mpccp_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT_MASK) | (rsmu_sec_tlvl_mask_set1_group_default << RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_SET_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT(rsmu_sec_misc_mask_set1_group_default_mpccp_reg, rsmu_sec_rw_mask_set1_group_default) \
     rsmu_sec_misc_mask_set1_group_default_mpccp_reg = (rsmu_sec_misc_mask_set1_group_default_mpccp_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT_MASK) | (rsmu_sec_rw_mask_set1_group_default << RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_SET_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT(rsmu_sec_misc_mask_set1_group_default_mpccp_reg, rsmu_sec_vf_mask_set1_group_default) \
     rsmu_sec_misc_mask_set1_group_default_mpccp_reg = (rsmu_sec_misc_mask_set1_group_default_mpccp_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT_MASK) | (rsmu_sec_vf_mask_set1_group_default << RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_misc_mask_set1_group_default_mpccp_t {
          unsigned int rsmu_sec_tlvl_mask_set1_group_default : RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT_SIZE;
          unsigned int rsmu_sec_rw_mask_set1_group_default : RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT_SIZE;
          unsigned int rsmu_sec_vf_mask_set1_group_default : RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT_SIZE;
          unsigned int                                : 21;
     } rsmu_sec_misc_mask_set1_group_default_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_misc_mask_set1_group_default_mpccp_t {
          unsigned int                                : 21;
          unsigned int rsmu_sec_vf_mask_set1_group_default : RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT_SIZE;
          unsigned int rsmu_sec_rw_mask_set1_group_default : RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT_SIZE;
          unsigned int rsmu_sec_tlvl_mask_set1_group_default : RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT_SIZE;
     } rsmu_sec_misc_mask_set1_group_default_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_misc_mask_set1_group_default_mpccp_t f;
} rsmu_sec_misc_mask_set1_group_default_mpccp_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_REG_SIZE 32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT_SIZE 3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT_SIZE 3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT_SIZE 1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT_SIZE 1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT_SHIFT 0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT_SHIFT 3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT_SHIFT 6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT_SHIFT 7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT_MASK 0x7
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT_MASK 0x38
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT_MASK 0x40
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT_MASK 0x80

#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_MASK \
     (RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT(rsmu_sec_access_control_group_default_mpccp) \
     ((rsmu_sec_access_control_group_default_mpccp & RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT(rsmu_sec_access_control_group_default_mpccp) \
     ((rsmu_sec_access_control_group_default_mpccp & RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT(rsmu_sec_access_control_group_default_mpccp) \
     ((rsmu_sec_access_control_group_default_mpccp & RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT(rsmu_sec_access_control_group_default_mpccp) \
     ((rsmu_sec_access_control_group_default_mpccp & RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT(rsmu_sec_access_control_group_default_mpccp_reg, rsmu_sec_check_enable_set0_group_default) \
     rsmu_sec_access_control_group_default_mpccp_reg = (rsmu_sec_access_control_group_default_mpccp_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT_MASK) | (rsmu_sec_check_enable_set0_group_default << RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT(rsmu_sec_access_control_group_default_mpccp_reg, rsmu_sec_check_enable_set1_group_default) \
     rsmu_sec_access_control_group_default_mpccp_reg = (rsmu_sec_access_control_group_default_mpccp_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT_MASK) | (rsmu_sec_check_enable_set1_group_default << RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT(rsmu_sec_access_control_group_default_mpccp_reg, rsmu_sec_vf_check_enable_set0_group_default) \
     rsmu_sec_access_control_group_default_mpccp_reg = (rsmu_sec_access_control_group_default_mpccp_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT_MASK) | (rsmu_sec_vf_check_enable_set0_group_default << RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT(rsmu_sec_access_control_group_default_mpccp_reg, rsmu_sec_vf_check_enable_set1_group_default) \
     rsmu_sec_access_control_group_default_mpccp_reg = (rsmu_sec_access_control_group_default_mpccp_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT_MASK) | (rsmu_sec_vf_check_enable_set1_group_default << RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_access_control_group_default_mpccp_t {
          unsigned int rsmu_sec_check_enable_set0_group_default : RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT_SIZE;
          unsigned int rsmu_sec_check_enable_set1_group_default : RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT_SIZE;
          unsigned int rsmu_sec_vf_check_enable_set0_group_default : RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT_SIZE;
          unsigned int rsmu_sec_vf_check_enable_set1_group_default : RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT_SIZE;
          unsigned int                                : 24;
     } rsmu_sec_access_control_group_default_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_access_control_group_default_mpccp_t {
          unsigned int                                : 24;
          unsigned int rsmu_sec_vf_check_enable_set1_group_default : RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT_SIZE;
          unsigned int rsmu_sec_vf_check_enable_set0_group_default : RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT_SIZE;
          unsigned int rsmu_sec_check_enable_set1_group_default : RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT_SIZE;
          unsigned int rsmu_sec_check_enable_set0_group_default : RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT_SIZE;
     } rsmu_sec_access_control_group_default_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_access_control_group_default_mpccp_t f;
} rsmu_sec_access_control_group_default_mpccp_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_0_MPCCP struct
 */

#define RSMU_SEC_START_ADDR_GROUP_0_MPCCP_REG_SIZE 32
#define RSMU_SEC_START_ADDR_GROUP_0_MPCCP_RSMU_SEC_START_ADDR_GROUP_0_SIZE 30

#define RSMU_SEC_START_ADDR_GROUP_0_MPCCP_RSMU_SEC_START_ADDR_GROUP_0_SHIFT 2

#define RSMU_SEC_START_ADDR_GROUP_0_MPCCP_RSMU_SEC_START_ADDR_GROUP_0_MASK 0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_0_MPCCP_MASK \
     (RSMU_SEC_START_ADDR_GROUP_0_MPCCP_RSMU_SEC_START_ADDR_GROUP_0_MASK)

#define RSMU_SEC_START_ADDR_GROUP_0_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_0_MPCCP_GET_RSMU_SEC_START_ADDR_GROUP_0(rsmu_sec_start_addr_group_0_mpccp) \
     ((rsmu_sec_start_addr_group_0_mpccp & RSMU_SEC_START_ADDR_GROUP_0_MPCCP_RSMU_SEC_START_ADDR_GROUP_0_MASK) >> RSMU_SEC_START_ADDR_GROUP_0_MPCCP_RSMU_SEC_START_ADDR_GROUP_0_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_0_MPCCP_SET_RSMU_SEC_START_ADDR_GROUP_0(rsmu_sec_start_addr_group_0_mpccp_reg, rsmu_sec_start_addr_group_0) \
     rsmu_sec_start_addr_group_0_mpccp_reg = (rsmu_sec_start_addr_group_0_mpccp_reg & ~RSMU_SEC_START_ADDR_GROUP_0_MPCCP_RSMU_SEC_START_ADDR_GROUP_0_MASK) | (rsmu_sec_start_addr_group_0 << RSMU_SEC_START_ADDR_GROUP_0_MPCCP_RSMU_SEC_START_ADDR_GROUP_0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_start_addr_group_0_mpccp_t {
          unsigned int                                : 2;
          unsigned int rsmu_sec_start_addr_group_0    : RSMU_SEC_START_ADDR_GROUP_0_MPCCP_RSMU_SEC_START_ADDR_GROUP_0_SIZE;
     } rsmu_sec_start_addr_group_0_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_start_addr_group_0_mpccp_t {
          unsigned int rsmu_sec_start_addr_group_0    : RSMU_SEC_START_ADDR_GROUP_0_MPCCP_RSMU_SEC_START_ADDR_GROUP_0_SIZE;
          unsigned int                                : 2;
     } rsmu_sec_start_addr_group_0_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_start_addr_group_0_mpccp_t f;
} rsmu_sec_start_addr_group_0_mpccp_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_0_MPCCP struct
 */

#define RSMU_SEC_END_ADDR_GROUP_0_MPCCP_REG_SIZE 32
#define RSMU_SEC_END_ADDR_GROUP_0_MPCCP_RSMU_SEC_END_ADDR_GROUP_0_SIZE 30

#define RSMU_SEC_END_ADDR_GROUP_0_MPCCP_RSMU_SEC_END_ADDR_GROUP_0_SHIFT 2

#define RSMU_SEC_END_ADDR_GROUP_0_MPCCP_RSMU_SEC_END_ADDR_GROUP_0_MASK 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_0_MPCCP_MASK \
     (RSMU_SEC_END_ADDR_GROUP_0_MPCCP_RSMU_SEC_END_ADDR_GROUP_0_MASK)

#define RSMU_SEC_END_ADDR_GROUP_0_MPCCP_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_0_MPCCP_GET_RSMU_SEC_END_ADDR_GROUP_0(rsmu_sec_end_addr_group_0_mpccp) \
     ((rsmu_sec_end_addr_group_0_mpccp & RSMU_SEC_END_ADDR_GROUP_0_MPCCP_RSMU_SEC_END_ADDR_GROUP_0_MASK) >> RSMU_SEC_END_ADDR_GROUP_0_MPCCP_RSMU_SEC_END_ADDR_GROUP_0_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_0_MPCCP_SET_RSMU_SEC_END_ADDR_GROUP_0(rsmu_sec_end_addr_group_0_mpccp_reg, rsmu_sec_end_addr_group_0) \
     rsmu_sec_end_addr_group_0_mpccp_reg = (rsmu_sec_end_addr_group_0_mpccp_reg & ~RSMU_SEC_END_ADDR_GROUP_0_MPCCP_RSMU_SEC_END_ADDR_GROUP_0_MASK) | (rsmu_sec_end_addr_group_0 << RSMU_SEC_END_ADDR_GROUP_0_MPCCP_RSMU_SEC_END_ADDR_GROUP_0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_end_addr_group_0_mpccp_t {
          unsigned int                                : 2;
          unsigned int rsmu_sec_end_addr_group_0      : RSMU_SEC_END_ADDR_GROUP_0_MPCCP_RSMU_SEC_END_ADDR_GROUP_0_SIZE;
     } rsmu_sec_end_addr_group_0_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_end_addr_group_0_mpccp_t {
          unsigned int rsmu_sec_end_addr_group_0      : RSMU_SEC_END_ADDR_GROUP_0_MPCCP_RSMU_SEC_END_ADDR_GROUP_0_SIZE;
          unsigned int                                : 2;
     } rsmu_sec_end_addr_group_0_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_end_addr_group_0_mpccp_t f;
} rsmu_sec_end_addr_group_0_mpccp_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_0_MPCCP struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_0_MPCCP_REG_SIZE 32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_0_SIZE 20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_0_SHIFT 0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_0_MASK 0xfffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_0_MPCCP_MASK \
     (RSMU_SEC_INITID_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_0_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_0_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_0_MPCCP_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_0(rsmu_sec_initid_mask_set0_group_0_mpccp) \
     ((rsmu_sec_initid_mask_set0_group_0_mpccp & RSMU_SEC_INITID_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_0_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_0_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_0_MPCCP_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_0(rsmu_sec_initid_mask_set0_group_0_mpccp_reg, rsmu_sec_initid_mask_set0_group_0) \
     rsmu_sec_initid_mask_set0_group_0_mpccp_reg = (rsmu_sec_initid_mask_set0_group_0_mpccp_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_0_MASK) | (rsmu_sec_initid_mask_set0_group_0 << RSMU_SEC_INITID_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_initid_mask_set0_group_0_mpccp_t {
          unsigned int rsmu_sec_initid_mask_set0_group_0 : RSMU_SEC_INITID_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_0_SIZE;
          unsigned int                                : 12;
     } rsmu_sec_initid_mask_set0_group_0_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_initid_mask_set0_group_0_mpccp_t {
          unsigned int                                : 12;
          unsigned int rsmu_sec_initid_mask_set0_group_0 : RSMU_SEC_INITID_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_0_SIZE;
     } rsmu_sec_initid_mask_set0_group_0_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_initid_mask_set0_group_0_mpccp_t f;
} rsmu_sec_initid_mask_set0_group_0_mpccp_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MPCCP struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MPCCP_REG_SIZE 32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_0_SIZE 18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_0_SHIFT 0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MASK 0x3ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MPCCP_MASK \
     (RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MPCCP_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_0(rsmu_sec_unitid_mask_set0_group_0_mpccp) \
     ((rsmu_sec_unitid_mask_set0_group_0_mpccp & RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_0_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MPCCP_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_0(rsmu_sec_unitid_mask_set0_group_0_mpccp_reg, rsmu_sec_unitid_mask_set0_group_0) \
     rsmu_sec_unitid_mask_set0_group_0_mpccp_reg = (rsmu_sec_unitid_mask_set0_group_0_mpccp_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MASK) | (rsmu_sec_unitid_mask_set0_group_0 << RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_unitid_mask_set0_group_0_mpccp_t {
          unsigned int rsmu_sec_unitid_mask_set0_group_0 : RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_0_SIZE;
          unsigned int                                : 14;
     } rsmu_sec_unitid_mask_set0_group_0_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_unitid_mask_set0_group_0_mpccp_t {
          unsigned int                                : 14;
          unsigned int rsmu_sec_unitid_mask_set0_group_0 : RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_0_SIZE;
     } rsmu_sec_unitid_mask_set0_group_0_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_unitid_mask_set0_group_0_mpccp_t f;
} rsmu_sec_unitid_mask_set0_group_0_mpccp_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_REG_SIZE 32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_0_SIZE 8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_0_SIZE 2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_0_SIZE 1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_0_SHIFT 0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_0_SHIFT 8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_0_SHIFT 10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_0_MASK 0xff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_0_MASK 0x300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_0_MASK 0x400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_MASK \
     (RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_0_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_0_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_0_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_0(rsmu_sec_misc_mask_set0_group_0_mpccp) \
     ((rsmu_sec_misc_mask_set0_group_0_mpccp & RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_0_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_0_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_GET_RSMU_SEC_RW_MASK_SET0_GROUP_0(rsmu_sec_misc_mask_set0_group_0_mpccp) \
     ((rsmu_sec_misc_mask_set0_group_0_mpccp & RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_0_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_0_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_GET_RSMU_SEC_VF_MASK_SET0_GROUP_0(rsmu_sec_misc_mask_set0_group_0_mpccp) \
     ((rsmu_sec_misc_mask_set0_group_0_mpccp & RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_0_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_0_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_0(rsmu_sec_misc_mask_set0_group_0_mpccp_reg, rsmu_sec_tlvl_mask_set0_group_0) \
     rsmu_sec_misc_mask_set0_group_0_mpccp_reg = (rsmu_sec_misc_mask_set0_group_0_mpccp_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_0_MASK) | (rsmu_sec_tlvl_mask_set0_group_0 << RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_0_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_SET_RSMU_SEC_RW_MASK_SET0_GROUP_0(rsmu_sec_misc_mask_set0_group_0_mpccp_reg, rsmu_sec_rw_mask_set0_group_0) \
     rsmu_sec_misc_mask_set0_group_0_mpccp_reg = (rsmu_sec_misc_mask_set0_group_0_mpccp_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_0_MASK) | (rsmu_sec_rw_mask_set0_group_0 << RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_0_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_SET_RSMU_SEC_VF_MASK_SET0_GROUP_0(rsmu_sec_misc_mask_set0_group_0_mpccp_reg, rsmu_sec_vf_mask_set0_group_0) \
     rsmu_sec_misc_mask_set0_group_0_mpccp_reg = (rsmu_sec_misc_mask_set0_group_0_mpccp_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_0_MASK) | (rsmu_sec_vf_mask_set0_group_0 << RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_misc_mask_set0_group_0_mpccp_t {
          unsigned int rsmu_sec_tlvl_mask_set0_group_0 : RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_0_SIZE;
          unsigned int rsmu_sec_rw_mask_set0_group_0  : RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_0_SIZE;
          unsigned int rsmu_sec_vf_mask_set0_group_0  : RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_0_SIZE;
          unsigned int                                : 21;
     } rsmu_sec_misc_mask_set0_group_0_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_misc_mask_set0_group_0_mpccp_t {
          unsigned int                                : 21;
          unsigned int rsmu_sec_vf_mask_set0_group_0  : RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_0_SIZE;
          unsigned int rsmu_sec_rw_mask_set0_group_0  : RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_0_SIZE;
          unsigned int rsmu_sec_tlvl_mask_set0_group_0 : RSMU_SEC_MISC_MASK_SET0_GROUP_0_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_0_SIZE;
     } rsmu_sec_misc_mask_set0_group_0_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_misc_mask_set0_group_0_mpccp_t f;
} rsmu_sec_misc_mask_set0_group_0_mpccp_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_0_MPCCP struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_0_MPCCP_REG_SIZE 32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_0_SIZE 20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_0_SHIFT 0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_0_MASK 0xfffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_0_MPCCP_MASK \
     (RSMU_SEC_INITID_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_0_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_0_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_0_MPCCP_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_0(rsmu_sec_initid_mask_set1_group_0_mpccp) \
     ((rsmu_sec_initid_mask_set1_group_0_mpccp & RSMU_SEC_INITID_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_0_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_0_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_0_MPCCP_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_0(rsmu_sec_initid_mask_set1_group_0_mpccp_reg, rsmu_sec_initid_mask_set1_group_0) \
     rsmu_sec_initid_mask_set1_group_0_mpccp_reg = (rsmu_sec_initid_mask_set1_group_0_mpccp_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_0_MASK) | (rsmu_sec_initid_mask_set1_group_0 << RSMU_SEC_INITID_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_initid_mask_set1_group_0_mpccp_t {
          unsigned int rsmu_sec_initid_mask_set1_group_0 : RSMU_SEC_INITID_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_0_SIZE;
          unsigned int                                : 12;
     } rsmu_sec_initid_mask_set1_group_0_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_initid_mask_set1_group_0_mpccp_t {
          unsigned int                                : 12;
          unsigned int rsmu_sec_initid_mask_set1_group_0 : RSMU_SEC_INITID_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_0_SIZE;
     } rsmu_sec_initid_mask_set1_group_0_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_initid_mask_set1_group_0_mpccp_t f;
} rsmu_sec_initid_mask_set1_group_0_mpccp_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MPCCP struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MPCCP_REG_SIZE 32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_0_SIZE 18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_0_SHIFT 0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MASK 0x3ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MPCCP_MASK \
     (RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MPCCP_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_0(rsmu_sec_unitid_mask_set1_group_0_mpccp) \
     ((rsmu_sec_unitid_mask_set1_group_0_mpccp & RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_0_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MPCCP_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_0(rsmu_sec_unitid_mask_set1_group_0_mpccp_reg, rsmu_sec_unitid_mask_set1_group_0) \
     rsmu_sec_unitid_mask_set1_group_0_mpccp_reg = (rsmu_sec_unitid_mask_set1_group_0_mpccp_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MASK) | (rsmu_sec_unitid_mask_set1_group_0 << RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_unitid_mask_set1_group_0_mpccp_t {
          unsigned int rsmu_sec_unitid_mask_set1_group_0 : RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_0_SIZE;
          unsigned int                                : 14;
     } rsmu_sec_unitid_mask_set1_group_0_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_unitid_mask_set1_group_0_mpccp_t {
          unsigned int                                : 14;
          unsigned int rsmu_sec_unitid_mask_set1_group_0 : RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_0_SIZE;
     } rsmu_sec_unitid_mask_set1_group_0_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_unitid_mask_set1_group_0_mpccp_t f;
} rsmu_sec_unitid_mask_set1_group_0_mpccp_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_REG_SIZE 32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_0_SIZE 8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_0_SIZE 2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_0_SIZE 1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_0_SHIFT 0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_0_SHIFT 8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_0_SHIFT 10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_0_MASK 0xff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_0_MASK 0x300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_0_MASK 0x400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_MASK \
     (RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_0_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_0_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_0_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_0(rsmu_sec_misc_mask_set1_group_0_mpccp) \
     ((rsmu_sec_misc_mask_set1_group_0_mpccp & RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_0_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_0_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_GET_RSMU_SEC_RW_MASK_SET1_GROUP_0(rsmu_sec_misc_mask_set1_group_0_mpccp) \
     ((rsmu_sec_misc_mask_set1_group_0_mpccp & RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_0_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_0_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_GET_RSMU_SEC_VF_MASK_SET1_GROUP_0(rsmu_sec_misc_mask_set1_group_0_mpccp) \
     ((rsmu_sec_misc_mask_set1_group_0_mpccp & RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_0_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_0_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_0(rsmu_sec_misc_mask_set1_group_0_mpccp_reg, rsmu_sec_tlvl_mask_set1_group_0) \
     rsmu_sec_misc_mask_set1_group_0_mpccp_reg = (rsmu_sec_misc_mask_set1_group_0_mpccp_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_0_MASK) | (rsmu_sec_tlvl_mask_set1_group_0 << RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_0_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_SET_RSMU_SEC_RW_MASK_SET1_GROUP_0(rsmu_sec_misc_mask_set1_group_0_mpccp_reg, rsmu_sec_rw_mask_set1_group_0) \
     rsmu_sec_misc_mask_set1_group_0_mpccp_reg = (rsmu_sec_misc_mask_set1_group_0_mpccp_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_0_MASK) | (rsmu_sec_rw_mask_set1_group_0 << RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_0_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_SET_RSMU_SEC_VF_MASK_SET1_GROUP_0(rsmu_sec_misc_mask_set1_group_0_mpccp_reg, rsmu_sec_vf_mask_set1_group_0) \
     rsmu_sec_misc_mask_set1_group_0_mpccp_reg = (rsmu_sec_misc_mask_set1_group_0_mpccp_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_0_MASK) | (rsmu_sec_vf_mask_set1_group_0 << RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_misc_mask_set1_group_0_mpccp_t {
          unsigned int rsmu_sec_tlvl_mask_set1_group_0 : RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_0_SIZE;
          unsigned int rsmu_sec_rw_mask_set1_group_0  : RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_0_SIZE;
          unsigned int rsmu_sec_vf_mask_set1_group_0  : RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_0_SIZE;
          unsigned int                                : 21;
     } rsmu_sec_misc_mask_set1_group_0_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_misc_mask_set1_group_0_mpccp_t {
          unsigned int                                : 21;
          unsigned int rsmu_sec_vf_mask_set1_group_0  : RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_0_SIZE;
          unsigned int rsmu_sec_rw_mask_set1_group_0  : RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_0_SIZE;
          unsigned int rsmu_sec_tlvl_mask_set1_group_0 : RSMU_SEC_MISC_MASK_SET1_GROUP_0_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_0_SIZE;
     } rsmu_sec_misc_mask_set1_group_0_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_misc_mask_set1_group_0_mpccp_t f;
} rsmu_sec_misc_mask_set1_group_0_mpccp_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_REG_SIZE 32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0_SIZE 3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0_SIZE 3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0_SIZE 1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0_SIZE 1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0_SHIFT 0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0_SHIFT 3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0_SHIFT 6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0_SHIFT 7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0_MASK 0x7
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0_MASK 0x38
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0_MASK 0x40
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0_MASK 0x80

#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_MASK \
     (RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0(rsmu_sec_access_control_group_0_mpccp) \
     ((rsmu_sec_access_control_group_0_mpccp & RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0(rsmu_sec_access_control_group_0_mpccp) \
     ((rsmu_sec_access_control_group_0_mpccp & RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0(rsmu_sec_access_control_group_0_mpccp) \
     ((rsmu_sec_access_control_group_0_mpccp & RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0(rsmu_sec_access_control_group_0_mpccp) \
     ((rsmu_sec_access_control_group_0_mpccp & RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0(rsmu_sec_access_control_group_0_mpccp_reg, rsmu_sec_check_enable_set0_group_0) \
     rsmu_sec_access_control_group_0_mpccp_reg = (rsmu_sec_access_control_group_0_mpccp_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0_MASK) | (rsmu_sec_check_enable_set0_group_0 << RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0(rsmu_sec_access_control_group_0_mpccp_reg, rsmu_sec_check_enable_set1_group_0) \
     rsmu_sec_access_control_group_0_mpccp_reg = (rsmu_sec_access_control_group_0_mpccp_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0_MASK) | (rsmu_sec_check_enable_set1_group_0 << RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0(rsmu_sec_access_control_group_0_mpccp_reg, rsmu_sec_vf_check_enable_set0_group_0) \
     rsmu_sec_access_control_group_0_mpccp_reg = (rsmu_sec_access_control_group_0_mpccp_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0_MASK) | (rsmu_sec_vf_check_enable_set0_group_0 << RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0(rsmu_sec_access_control_group_0_mpccp_reg, rsmu_sec_vf_check_enable_set1_group_0) \
     rsmu_sec_access_control_group_0_mpccp_reg = (rsmu_sec_access_control_group_0_mpccp_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0_MASK) | (rsmu_sec_vf_check_enable_set1_group_0 << RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_access_control_group_0_mpccp_t {
          unsigned int rsmu_sec_check_enable_set0_group_0 : RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0_SIZE;
          unsigned int rsmu_sec_check_enable_set1_group_0 : RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0_SIZE;
          unsigned int rsmu_sec_vf_check_enable_set0_group_0 : RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0_SIZE;
          unsigned int rsmu_sec_vf_check_enable_set1_group_0 : RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0_SIZE;
          unsigned int                                : 24;
     } rsmu_sec_access_control_group_0_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_access_control_group_0_mpccp_t {
          unsigned int                                : 24;
          unsigned int rsmu_sec_vf_check_enable_set1_group_0 : RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0_SIZE;
          unsigned int rsmu_sec_vf_check_enable_set0_group_0 : RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0_SIZE;
          unsigned int rsmu_sec_check_enable_set1_group_0 : RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0_SIZE;
          unsigned int rsmu_sec_check_enable_set0_group_0 : RSMU_SEC_ACCESS_CONTROL_GROUP_0_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0_SIZE;
     } rsmu_sec_access_control_group_0_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_access_control_group_0_mpccp_t f;
} rsmu_sec_access_control_group_0_mpccp_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_1_MPCCP struct
 */

#define RSMU_SEC_START_ADDR_GROUP_1_MPCCP_REG_SIZE 32
#define RSMU_SEC_START_ADDR_GROUP_1_MPCCP_RSMU_SEC_START_ADDR_GROUP_1_SIZE 30

#define RSMU_SEC_START_ADDR_GROUP_1_MPCCP_RSMU_SEC_START_ADDR_GROUP_1_SHIFT 2

#define RSMU_SEC_START_ADDR_GROUP_1_MPCCP_RSMU_SEC_START_ADDR_GROUP_1_MASK 0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_1_MPCCP_MASK \
     (RSMU_SEC_START_ADDR_GROUP_1_MPCCP_RSMU_SEC_START_ADDR_GROUP_1_MASK)

#define RSMU_SEC_START_ADDR_GROUP_1_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_1_MPCCP_GET_RSMU_SEC_START_ADDR_GROUP_1(rsmu_sec_start_addr_group_1_mpccp) \
     ((rsmu_sec_start_addr_group_1_mpccp & RSMU_SEC_START_ADDR_GROUP_1_MPCCP_RSMU_SEC_START_ADDR_GROUP_1_MASK) >> RSMU_SEC_START_ADDR_GROUP_1_MPCCP_RSMU_SEC_START_ADDR_GROUP_1_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_1_MPCCP_SET_RSMU_SEC_START_ADDR_GROUP_1(rsmu_sec_start_addr_group_1_mpccp_reg, rsmu_sec_start_addr_group_1) \
     rsmu_sec_start_addr_group_1_mpccp_reg = (rsmu_sec_start_addr_group_1_mpccp_reg & ~RSMU_SEC_START_ADDR_GROUP_1_MPCCP_RSMU_SEC_START_ADDR_GROUP_1_MASK) | (rsmu_sec_start_addr_group_1 << RSMU_SEC_START_ADDR_GROUP_1_MPCCP_RSMU_SEC_START_ADDR_GROUP_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_start_addr_group_1_mpccp_t {
          unsigned int                                : 2;
          unsigned int rsmu_sec_start_addr_group_1    : RSMU_SEC_START_ADDR_GROUP_1_MPCCP_RSMU_SEC_START_ADDR_GROUP_1_SIZE;
     } rsmu_sec_start_addr_group_1_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_start_addr_group_1_mpccp_t {
          unsigned int rsmu_sec_start_addr_group_1    : RSMU_SEC_START_ADDR_GROUP_1_MPCCP_RSMU_SEC_START_ADDR_GROUP_1_SIZE;
          unsigned int                                : 2;
     } rsmu_sec_start_addr_group_1_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_start_addr_group_1_mpccp_t f;
} rsmu_sec_start_addr_group_1_mpccp_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_1_MPCCP struct
 */

#define RSMU_SEC_END_ADDR_GROUP_1_MPCCP_REG_SIZE 32
#define RSMU_SEC_END_ADDR_GROUP_1_MPCCP_RSMU_SEC_END_ADDR_GROUP_1_SIZE 30

#define RSMU_SEC_END_ADDR_GROUP_1_MPCCP_RSMU_SEC_END_ADDR_GROUP_1_SHIFT 2

#define RSMU_SEC_END_ADDR_GROUP_1_MPCCP_RSMU_SEC_END_ADDR_GROUP_1_MASK 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_1_MPCCP_MASK \
     (RSMU_SEC_END_ADDR_GROUP_1_MPCCP_RSMU_SEC_END_ADDR_GROUP_1_MASK)

#define RSMU_SEC_END_ADDR_GROUP_1_MPCCP_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_1_MPCCP_GET_RSMU_SEC_END_ADDR_GROUP_1(rsmu_sec_end_addr_group_1_mpccp) \
     ((rsmu_sec_end_addr_group_1_mpccp & RSMU_SEC_END_ADDR_GROUP_1_MPCCP_RSMU_SEC_END_ADDR_GROUP_1_MASK) >> RSMU_SEC_END_ADDR_GROUP_1_MPCCP_RSMU_SEC_END_ADDR_GROUP_1_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_1_MPCCP_SET_RSMU_SEC_END_ADDR_GROUP_1(rsmu_sec_end_addr_group_1_mpccp_reg, rsmu_sec_end_addr_group_1) \
     rsmu_sec_end_addr_group_1_mpccp_reg = (rsmu_sec_end_addr_group_1_mpccp_reg & ~RSMU_SEC_END_ADDR_GROUP_1_MPCCP_RSMU_SEC_END_ADDR_GROUP_1_MASK) | (rsmu_sec_end_addr_group_1 << RSMU_SEC_END_ADDR_GROUP_1_MPCCP_RSMU_SEC_END_ADDR_GROUP_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_end_addr_group_1_mpccp_t {
          unsigned int                                : 2;
          unsigned int rsmu_sec_end_addr_group_1      : RSMU_SEC_END_ADDR_GROUP_1_MPCCP_RSMU_SEC_END_ADDR_GROUP_1_SIZE;
     } rsmu_sec_end_addr_group_1_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_end_addr_group_1_mpccp_t {
          unsigned int rsmu_sec_end_addr_group_1      : RSMU_SEC_END_ADDR_GROUP_1_MPCCP_RSMU_SEC_END_ADDR_GROUP_1_SIZE;
          unsigned int                                : 2;
     } rsmu_sec_end_addr_group_1_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_end_addr_group_1_mpccp_t f;
} rsmu_sec_end_addr_group_1_mpccp_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_1_MPCCP struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_1_MPCCP_REG_SIZE 32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_1_SIZE 20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_1_SHIFT 0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_1_MASK 0xfffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_1_MPCCP_MASK \
     (RSMU_SEC_INITID_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_1_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_1_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_1_MPCCP_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_1(rsmu_sec_initid_mask_set0_group_1_mpccp) \
     ((rsmu_sec_initid_mask_set0_group_1_mpccp & RSMU_SEC_INITID_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_1_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_1_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_1_MPCCP_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_1(rsmu_sec_initid_mask_set0_group_1_mpccp_reg, rsmu_sec_initid_mask_set0_group_1) \
     rsmu_sec_initid_mask_set0_group_1_mpccp_reg = (rsmu_sec_initid_mask_set0_group_1_mpccp_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_1_MASK) | (rsmu_sec_initid_mask_set0_group_1 << RSMU_SEC_INITID_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_initid_mask_set0_group_1_mpccp_t {
          unsigned int rsmu_sec_initid_mask_set0_group_1 : RSMU_SEC_INITID_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_1_SIZE;
          unsigned int                                : 12;
     } rsmu_sec_initid_mask_set0_group_1_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_initid_mask_set0_group_1_mpccp_t {
          unsigned int                                : 12;
          unsigned int rsmu_sec_initid_mask_set0_group_1 : RSMU_SEC_INITID_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_INITID_MASK_SET0_GROUP_1_SIZE;
     } rsmu_sec_initid_mask_set0_group_1_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_initid_mask_set0_group_1_mpccp_t f;
} rsmu_sec_initid_mask_set0_group_1_mpccp_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MPCCP struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MPCCP_REG_SIZE 32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_1_SIZE 18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_1_SHIFT 0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MASK 0x3ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MPCCP_MASK \
     (RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MPCCP_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_1(rsmu_sec_unitid_mask_set0_group_1_mpccp) \
     ((rsmu_sec_unitid_mask_set0_group_1_mpccp & RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_1_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MPCCP_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_1(rsmu_sec_unitid_mask_set0_group_1_mpccp_reg, rsmu_sec_unitid_mask_set0_group_1) \
     rsmu_sec_unitid_mask_set0_group_1_mpccp_reg = (rsmu_sec_unitid_mask_set0_group_1_mpccp_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MASK) | (rsmu_sec_unitid_mask_set0_group_1 << RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_unitid_mask_set0_group_1_mpccp_t {
          unsigned int rsmu_sec_unitid_mask_set0_group_1 : RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_1_SIZE;
          unsigned int                                : 14;
     } rsmu_sec_unitid_mask_set0_group_1_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_unitid_mask_set0_group_1_mpccp_t {
          unsigned int                                : 14;
          unsigned int rsmu_sec_unitid_mask_set0_group_1 : RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_UNITID_MASK_SET0_GROUP_1_SIZE;
     } rsmu_sec_unitid_mask_set0_group_1_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_unitid_mask_set0_group_1_mpccp_t f;
} rsmu_sec_unitid_mask_set0_group_1_mpccp_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_REG_SIZE 32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_1_SIZE 8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_1_SIZE 2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_1_SIZE 1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_1_SHIFT 0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_1_SHIFT 8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_1_SHIFT 10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_1_MASK 0xff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_1_MASK 0x300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_1_MASK 0x400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_MASK \
     (RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_1_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_1_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_1_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_1(rsmu_sec_misc_mask_set0_group_1_mpccp) \
     ((rsmu_sec_misc_mask_set0_group_1_mpccp & RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_1_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_1_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_GET_RSMU_SEC_RW_MASK_SET0_GROUP_1(rsmu_sec_misc_mask_set0_group_1_mpccp) \
     ((rsmu_sec_misc_mask_set0_group_1_mpccp & RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_1_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_1_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_GET_RSMU_SEC_VF_MASK_SET0_GROUP_1(rsmu_sec_misc_mask_set0_group_1_mpccp) \
     ((rsmu_sec_misc_mask_set0_group_1_mpccp & RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_1_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_1_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_1(rsmu_sec_misc_mask_set0_group_1_mpccp_reg, rsmu_sec_tlvl_mask_set0_group_1) \
     rsmu_sec_misc_mask_set0_group_1_mpccp_reg = (rsmu_sec_misc_mask_set0_group_1_mpccp_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_1_MASK) | (rsmu_sec_tlvl_mask_set0_group_1 << RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_1_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_SET_RSMU_SEC_RW_MASK_SET0_GROUP_1(rsmu_sec_misc_mask_set0_group_1_mpccp_reg, rsmu_sec_rw_mask_set0_group_1) \
     rsmu_sec_misc_mask_set0_group_1_mpccp_reg = (rsmu_sec_misc_mask_set0_group_1_mpccp_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_1_MASK) | (rsmu_sec_rw_mask_set0_group_1 << RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_1_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_SET_RSMU_SEC_VF_MASK_SET0_GROUP_1(rsmu_sec_misc_mask_set0_group_1_mpccp_reg, rsmu_sec_vf_mask_set0_group_1) \
     rsmu_sec_misc_mask_set0_group_1_mpccp_reg = (rsmu_sec_misc_mask_set0_group_1_mpccp_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_1_MASK) | (rsmu_sec_vf_mask_set0_group_1 << RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_misc_mask_set0_group_1_mpccp_t {
          unsigned int rsmu_sec_tlvl_mask_set0_group_1 : RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_1_SIZE;
          unsigned int rsmu_sec_rw_mask_set0_group_1  : RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_1_SIZE;
          unsigned int rsmu_sec_vf_mask_set0_group_1  : RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_1_SIZE;
          unsigned int                                : 21;
     } rsmu_sec_misc_mask_set0_group_1_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_misc_mask_set0_group_1_mpccp_t {
          unsigned int                                : 21;
          unsigned int rsmu_sec_vf_mask_set0_group_1  : RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_VF_MASK_SET0_GROUP_1_SIZE;
          unsigned int rsmu_sec_rw_mask_set0_group_1  : RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_RW_MASK_SET0_GROUP_1_SIZE;
          unsigned int rsmu_sec_tlvl_mask_set0_group_1 : RSMU_SEC_MISC_MASK_SET0_GROUP_1_MPCCP_RSMU_SEC_TLVL_MASK_SET0_GROUP_1_SIZE;
     } rsmu_sec_misc_mask_set0_group_1_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_misc_mask_set0_group_1_mpccp_t f;
} rsmu_sec_misc_mask_set0_group_1_mpccp_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_1_MPCCP struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_1_MPCCP_REG_SIZE 32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_1_SIZE 20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_1_SHIFT 0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_1_MASK 0xfffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_1_MPCCP_MASK \
     (RSMU_SEC_INITID_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_1_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_1_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_1_MPCCP_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_1(rsmu_sec_initid_mask_set1_group_1_mpccp) \
     ((rsmu_sec_initid_mask_set1_group_1_mpccp & RSMU_SEC_INITID_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_1_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_1_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_1_MPCCP_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_1(rsmu_sec_initid_mask_set1_group_1_mpccp_reg, rsmu_sec_initid_mask_set1_group_1) \
     rsmu_sec_initid_mask_set1_group_1_mpccp_reg = (rsmu_sec_initid_mask_set1_group_1_mpccp_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_1_MASK) | (rsmu_sec_initid_mask_set1_group_1 << RSMU_SEC_INITID_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_initid_mask_set1_group_1_mpccp_t {
          unsigned int rsmu_sec_initid_mask_set1_group_1 : RSMU_SEC_INITID_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_1_SIZE;
          unsigned int                                : 12;
     } rsmu_sec_initid_mask_set1_group_1_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_initid_mask_set1_group_1_mpccp_t {
          unsigned int                                : 12;
          unsigned int rsmu_sec_initid_mask_set1_group_1 : RSMU_SEC_INITID_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_INITID_MASK_SET1_GROUP_1_SIZE;
     } rsmu_sec_initid_mask_set1_group_1_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_initid_mask_set1_group_1_mpccp_t f;
} rsmu_sec_initid_mask_set1_group_1_mpccp_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MPCCP struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MPCCP_REG_SIZE 32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_1_SIZE 18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_1_SHIFT 0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MASK 0x3ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MPCCP_MASK \
     (RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MPCCP_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_1(rsmu_sec_unitid_mask_set1_group_1_mpccp) \
     ((rsmu_sec_unitid_mask_set1_group_1_mpccp & RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_1_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MPCCP_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_1(rsmu_sec_unitid_mask_set1_group_1_mpccp_reg, rsmu_sec_unitid_mask_set1_group_1) \
     rsmu_sec_unitid_mask_set1_group_1_mpccp_reg = (rsmu_sec_unitid_mask_set1_group_1_mpccp_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MASK) | (rsmu_sec_unitid_mask_set1_group_1 << RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_unitid_mask_set1_group_1_mpccp_t {
          unsigned int rsmu_sec_unitid_mask_set1_group_1 : RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_1_SIZE;
          unsigned int                                : 14;
     } rsmu_sec_unitid_mask_set1_group_1_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_unitid_mask_set1_group_1_mpccp_t {
          unsigned int                                : 14;
          unsigned int rsmu_sec_unitid_mask_set1_group_1 : RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_UNITID_MASK_SET1_GROUP_1_SIZE;
     } rsmu_sec_unitid_mask_set1_group_1_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_unitid_mask_set1_group_1_mpccp_t f;
} rsmu_sec_unitid_mask_set1_group_1_mpccp_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_REG_SIZE 32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_1_SIZE 8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_1_SIZE 2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_1_SIZE 1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_1_SHIFT 0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_1_SHIFT 8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_1_SHIFT 10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_1_MASK 0xff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_1_MASK 0x300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_1_MASK 0x400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_MASK \
     (RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_1_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_1_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_1_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_1(rsmu_sec_misc_mask_set1_group_1_mpccp) \
     ((rsmu_sec_misc_mask_set1_group_1_mpccp & RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_1_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_1_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_GET_RSMU_SEC_RW_MASK_SET1_GROUP_1(rsmu_sec_misc_mask_set1_group_1_mpccp) \
     ((rsmu_sec_misc_mask_set1_group_1_mpccp & RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_1_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_1_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_GET_RSMU_SEC_VF_MASK_SET1_GROUP_1(rsmu_sec_misc_mask_set1_group_1_mpccp) \
     ((rsmu_sec_misc_mask_set1_group_1_mpccp & RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_1_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_1_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_1(rsmu_sec_misc_mask_set1_group_1_mpccp_reg, rsmu_sec_tlvl_mask_set1_group_1) \
     rsmu_sec_misc_mask_set1_group_1_mpccp_reg = (rsmu_sec_misc_mask_set1_group_1_mpccp_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_1_MASK) | (rsmu_sec_tlvl_mask_set1_group_1 << RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_1_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_SET_RSMU_SEC_RW_MASK_SET1_GROUP_1(rsmu_sec_misc_mask_set1_group_1_mpccp_reg, rsmu_sec_rw_mask_set1_group_1) \
     rsmu_sec_misc_mask_set1_group_1_mpccp_reg = (rsmu_sec_misc_mask_set1_group_1_mpccp_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_1_MASK) | (rsmu_sec_rw_mask_set1_group_1 << RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_1_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_SET_RSMU_SEC_VF_MASK_SET1_GROUP_1(rsmu_sec_misc_mask_set1_group_1_mpccp_reg, rsmu_sec_vf_mask_set1_group_1) \
     rsmu_sec_misc_mask_set1_group_1_mpccp_reg = (rsmu_sec_misc_mask_set1_group_1_mpccp_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_1_MASK) | (rsmu_sec_vf_mask_set1_group_1 << RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_misc_mask_set1_group_1_mpccp_t {
          unsigned int rsmu_sec_tlvl_mask_set1_group_1 : RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_1_SIZE;
          unsigned int rsmu_sec_rw_mask_set1_group_1  : RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_1_SIZE;
          unsigned int rsmu_sec_vf_mask_set1_group_1  : RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_1_SIZE;
          unsigned int                                : 21;
     } rsmu_sec_misc_mask_set1_group_1_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_misc_mask_set1_group_1_mpccp_t {
          unsigned int                                : 21;
          unsigned int rsmu_sec_vf_mask_set1_group_1  : RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_VF_MASK_SET1_GROUP_1_SIZE;
          unsigned int rsmu_sec_rw_mask_set1_group_1  : RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_RW_MASK_SET1_GROUP_1_SIZE;
          unsigned int rsmu_sec_tlvl_mask_set1_group_1 : RSMU_SEC_MISC_MASK_SET1_GROUP_1_MPCCP_RSMU_SEC_TLVL_MASK_SET1_GROUP_1_SIZE;
     } rsmu_sec_misc_mask_set1_group_1_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_misc_mask_set1_group_1_mpccp_t f;
} rsmu_sec_misc_mask_set1_group_1_mpccp_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_REG_SIZE 32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1_SIZE 3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1_SIZE 3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1_SIZE 1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1_SIZE 1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1_SHIFT 0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1_SHIFT 3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1_SHIFT 6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1_SHIFT 7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1_MASK 0x7
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1_MASK 0x38
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1_MASK 0x40
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1_MASK 0x80

#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_MASK \
     (RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1(rsmu_sec_access_control_group_1_mpccp) \
     ((rsmu_sec_access_control_group_1_mpccp & RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1(rsmu_sec_access_control_group_1_mpccp) \
     ((rsmu_sec_access_control_group_1_mpccp & RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1(rsmu_sec_access_control_group_1_mpccp) \
     ((rsmu_sec_access_control_group_1_mpccp & RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1(rsmu_sec_access_control_group_1_mpccp) \
     ((rsmu_sec_access_control_group_1_mpccp & RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1(rsmu_sec_access_control_group_1_mpccp_reg, rsmu_sec_check_enable_set0_group_1) \
     rsmu_sec_access_control_group_1_mpccp_reg = (rsmu_sec_access_control_group_1_mpccp_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1_MASK) | (rsmu_sec_check_enable_set0_group_1 << RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1(rsmu_sec_access_control_group_1_mpccp_reg, rsmu_sec_check_enable_set1_group_1) \
     rsmu_sec_access_control_group_1_mpccp_reg = (rsmu_sec_access_control_group_1_mpccp_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1_MASK) | (rsmu_sec_check_enable_set1_group_1 << RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1(rsmu_sec_access_control_group_1_mpccp_reg, rsmu_sec_vf_check_enable_set0_group_1) \
     rsmu_sec_access_control_group_1_mpccp_reg = (rsmu_sec_access_control_group_1_mpccp_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1_MASK) | (rsmu_sec_vf_check_enable_set0_group_1 << RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1(rsmu_sec_access_control_group_1_mpccp_reg, rsmu_sec_vf_check_enable_set1_group_1) \
     rsmu_sec_access_control_group_1_mpccp_reg = (rsmu_sec_access_control_group_1_mpccp_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1_MASK) | (rsmu_sec_vf_check_enable_set1_group_1 << RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_access_control_group_1_mpccp_t {
          unsigned int rsmu_sec_check_enable_set0_group_1 : RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1_SIZE;
          unsigned int rsmu_sec_check_enable_set1_group_1 : RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1_SIZE;
          unsigned int rsmu_sec_vf_check_enable_set0_group_1 : RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1_SIZE;
          unsigned int rsmu_sec_vf_check_enable_set1_group_1 : RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1_SIZE;
          unsigned int                                : 24;
     } rsmu_sec_access_control_group_1_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_access_control_group_1_mpccp_t {
          unsigned int                                : 24;
          unsigned int rsmu_sec_vf_check_enable_set1_group_1 : RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1_SIZE;
          unsigned int rsmu_sec_vf_check_enable_set0_group_1 : RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1_SIZE;
          unsigned int rsmu_sec_check_enable_set1_group_1 : RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1_SIZE;
          unsigned int rsmu_sec_check_enable_set0_group_1 : RSMU_SEC_ACCESS_CONTROL_GROUP_1_MPCCP_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1_SIZE;
     } rsmu_sec_access_control_group_1_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_access_control_group_1_mpccp_t f;
} rsmu_sec_access_control_group_1_mpccp_u;


/*
 * RSMU_SEC_SLAVE_RANGE_ENABLE_MPCCP struct
 */

#define RSMU_SEC_SLAVE_RANGE_ENABLE_MPCCP_REG_SIZE 32
#define RSMU_SEC_SLAVE_RANGE_ENABLE_MPCCP_RSMU_SEC_SLAVE_RANGE_ENABLE_SIZE 32

#define RSMU_SEC_SLAVE_RANGE_ENABLE_MPCCP_RSMU_SEC_SLAVE_RANGE_ENABLE_SHIFT 0

#define RSMU_SEC_SLAVE_RANGE_ENABLE_MPCCP_RSMU_SEC_SLAVE_RANGE_ENABLE_MASK 0xffffffff

#define RSMU_SEC_SLAVE_RANGE_ENABLE_MPCCP_MASK \
     (RSMU_SEC_SLAVE_RANGE_ENABLE_MPCCP_RSMU_SEC_SLAVE_RANGE_ENABLE_MASK)

#define RSMU_SEC_SLAVE_RANGE_ENABLE_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_SLAVE_RANGE_ENABLE_MPCCP_GET_RSMU_SEC_SLAVE_RANGE_ENABLE(rsmu_sec_slave_range_enable_mpccp) \
     ((rsmu_sec_slave_range_enable_mpccp & RSMU_SEC_SLAVE_RANGE_ENABLE_MPCCP_RSMU_SEC_SLAVE_RANGE_ENABLE_MASK) >> RSMU_SEC_SLAVE_RANGE_ENABLE_MPCCP_RSMU_SEC_SLAVE_RANGE_ENABLE_SHIFT)

#define RSMU_SEC_SLAVE_RANGE_ENABLE_MPCCP_SET_RSMU_SEC_SLAVE_RANGE_ENABLE(rsmu_sec_slave_range_enable_mpccp_reg, rsmu_sec_slave_range_enable) \
     rsmu_sec_slave_range_enable_mpccp_reg = (rsmu_sec_slave_range_enable_mpccp_reg & ~RSMU_SEC_SLAVE_RANGE_ENABLE_MPCCP_RSMU_SEC_SLAVE_RANGE_ENABLE_MASK) | (rsmu_sec_slave_range_enable << RSMU_SEC_SLAVE_RANGE_ENABLE_MPCCP_RSMU_SEC_SLAVE_RANGE_ENABLE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_slave_range_enable_mpccp_t {
          unsigned int rsmu_sec_slave_range_enable    : RSMU_SEC_SLAVE_RANGE_ENABLE_MPCCP_RSMU_SEC_SLAVE_RANGE_ENABLE_SIZE;
     } rsmu_sec_slave_range_enable_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_slave_range_enable_mpccp_t {
          unsigned int rsmu_sec_slave_range_enable    : RSMU_SEC_SLAVE_RANGE_ENABLE_MPCCP_RSMU_SEC_SLAVE_RANGE_ENABLE_SIZE;
     } rsmu_sec_slave_range_enable_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_slave_range_enable_mpccp_t f;
} rsmu_sec_slave_range_enable_mpccp_u;


/*
 * RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP struct
 */

#define RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_REG_SIZE 32
#define RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SEC_SLAVE_ERROR_COUNTER_SIZE 16
#define RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU_SIZE 16

#define RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SEC_SLAVE_ERROR_COUNTER_SHIFT 0
#define RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU_SHIFT 16

#define RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SEC_SLAVE_ERROR_COUNTER_MASK 0xffff
#define RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU_MASK 0xffff0000

#define RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_MASK \
     (RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SEC_SLAVE_ERROR_COUNTER_MASK | \
      RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU_MASK)

#define RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_GET_RSMU_SEC_SLAVE_ERROR_COUNTER(rsmu_sec_slave_error_counter_mpccp) \
     ((rsmu_sec_slave_error_counter_mpccp & RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SEC_SLAVE_ERROR_COUNTER_MASK) >> RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SEC_SLAVE_ERROR_COUNTER_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_GET_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU(rsmu_sec_slave_error_counter_mpccp) \
     ((rsmu_sec_slave_error_counter_mpccp & RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU_MASK) >> RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU_SHIFT)

#define RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_SET_RSMU_SEC_SLAVE_ERROR_COUNTER(rsmu_sec_slave_error_counter_mpccp_reg, rsmu_sec_slave_error_counter) \
     rsmu_sec_slave_error_counter_mpccp_reg = (rsmu_sec_slave_error_counter_mpccp_reg & ~RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SEC_SLAVE_ERROR_COUNTER_MASK) | (rsmu_sec_slave_error_counter << RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SEC_SLAVE_ERROR_COUNTER_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_SET_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU(rsmu_sec_slave_error_counter_mpccp_reg, rsmu_sec_slave_error_counter_rsmu) \
     rsmu_sec_slave_error_counter_mpccp_reg = (rsmu_sec_slave_error_counter_mpccp_reg & ~RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU_MASK) | (rsmu_sec_slave_error_counter_rsmu << RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_slave_error_counter_mpccp_t {
          unsigned int rsmu_sec_slave_error_counter   : RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SEC_SLAVE_ERROR_COUNTER_SIZE;
          unsigned int rsmu_sec_slave_error_counter_rsmu : RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU_SIZE;
     } rsmu_sec_slave_error_counter_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_slave_error_counter_mpccp_t {
          unsigned int rsmu_sec_slave_error_counter_rsmu : RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU_SIZE;
          unsigned int rsmu_sec_slave_error_counter   : RSMU_SEC_SLAVE_ERROR_COUNTER_MPCCP_RSMU_SEC_SLAVE_ERROR_COUNTER_SIZE;
     } rsmu_sec_slave_error_counter_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_slave_error_counter_mpccp_t f;
} rsmu_sec_slave_error_counter_mpccp_u;


/*
 * RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP struct
 */

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_REG_SIZE 32
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_ADDR_SIZE 20
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_APERTUREID_SIZE 12

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_ADDR_SHIFT 0
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_APERTUREID_SHIFT 20

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_ADDR_MASK 0xfffff
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_APERTUREID_MASK 0xfff00000

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_MASK \
     (RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_ADDR_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_APERTUREID_MASK)

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_GET_RSMU_SEC_SLAVE_ERROR_ADDR(rsmu_sec_slave_error_log_addr_reg_mpccp) \
     ((rsmu_sec_slave_error_log_addr_reg_mpccp & RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_ADDR_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_ADDR_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_GET_RSMU_SEC_SLAVE_ERROR_APERTUREID(rsmu_sec_slave_error_log_addr_reg_mpccp) \
     ((rsmu_sec_slave_error_log_addr_reg_mpccp & RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_APERTUREID_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_APERTUREID_SHIFT)

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_SET_RSMU_SEC_SLAVE_ERROR_ADDR(rsmu_sec_slave_error_log_addr_reg_mpccp_reg, rsmu_sec_slave_error_addr) \
     rsmu_sec_slave_error_log_addr_reg_mpccp_reg = (rsmu_sec_slave_error_log_addr_reg_mpccp_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_ADDR_MASK) | (rsmu_sec_slave_error_addr << RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_ADDR_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_SET_RSMU_SEC_SLAVE_ERROR_APERTUREID(rsmu_sec_slave_error_log_addr_reg_mpccp_reg, rsmu_sec_slave_error_apertureid) \
     rsmu_sec_slave_error_log_addr_reg_mpccp_reg = (rsmu_sec_slave_error_log_addr_reg_mpccp_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_APERTUREID_MASK) | (rsmu_sec_slave_error_apertureid << RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_APERTUREID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_slave_error_log_addr_reg_mpccp_t {
          unsigned int rsmu_sec_slave_error_addr      : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_ADDR_SIZE;
          unsigned int rsmu_sec_slave_error_apertureid : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_APERTUREID_SIZE;
     } rsmu_sec_slave_error_log_addr_reg_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_slave_error_log_addr_reg_mpccp_t {
          unsigned int rsmu_sec_slave_error_apertureid : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_APERTUREID_SIZE;
          unsigned int rsmu_sec_slave_error_addr      : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_ADDR_SIZE;
     } rsmu_sec_slave_error_log_addr_reg_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_slave_error_log_addr_reg_mpccp_t f;
} rsmu_sec_slave_error_log_addr_reg_mpccp_u;


/*
 * RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP struct
 */

#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_REG_SIZE 32
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_VF_SIZE 1
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_VF_ID_SIZE 6
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_TLVL_SIZE 3
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_INITIATORID_SIZE 10
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_UNITID_SIZE 7
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_OP_SIZE 1
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_SIZE 1

#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_VF_SHIFT 0
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_VF_ID_SHIFT 1
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_TLVL_SHIFT 7
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_INITIATORID_SHIFT 10
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_UNITID_SHIFT 20
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_OP_SHIFT 30
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_SHIFT 31

#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_VF_MASK 0x1
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_VF_ID_MASK 0x7e
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_TLVL_MASK 0x380
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_INITIATORID_MASK 0xffc00
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_UNITID_MASK 0x7f00000
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_OP_MASK 0x40000000
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_MASK 0x80000000

#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_MASK \
     (RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_VF_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_VF_ID_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_TLVL_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_INITIATORID_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_UNITID_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_OP_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_MASK)

#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_GET_RSMU_SEC_SLAVE_ERROR_VF(rsmu_sec_slave_error_log_reg_mpccp) \
     ((rsmu_sec_slave_error_log_reg_mpccp & RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_VF_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_VF_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_GET_RSMU_SEC_SLAVE_ERROR_VF_ID(rsmu_sec_slave_error_log_reg_mpccp) \
     ((rsmu_sec_slave_error_log_reg_mpccp & RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_VF_ID_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_VF_ID_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_GET_RSMU_SEC_SLAVE_ERROR_TLVL(rsmu_sec_slave_error_log_reg_mpccp) \
     ((rsmu_sec_slave_error_log_reg_mpccp & RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_TLVL_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_TLVL_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_GET_RSMU_SEC_SLAVE_ERROR_INITIATORID(rsmu_sec_slave_error_log_reg_mpccp) \
     ((rsmu_sec_slave_error_log_reg_mpccp & RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_INITIATORID_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_INITIATORID_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_GET_RSMU_SEC_SLAVE_ERROR_UNITID(rsmu_sec_slave_error_log_reg_mpccp) \
     ((rsmu_sec_slave_error_log_reg_mpccp & RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_UNITID_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_UNITID_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_GET_RSMU_SEC_SLAVE_ERROR_OP(rsmu_sec_slave_error_log_reg_mpccp) \
     ((rsmu_sec_slave_error_log_reg_mpccp & RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_OP_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_OP_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_GET_RSMU_SEC_SLAVE_ERROR_OUTSTANDING(rsmu_sec_slave_error_log_reg_mpccp) \
     ((rsmu_sec_slave_error_log_reg_mpccp & RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_SHIFT)

#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_SET_RSMU_SEC_SLAVE_ERROR_VF(rsmu_sec_slave_error_log_reg_mpccp_reg, rsmu_sec_slave_error_vf) \
     rsmu_sec_slave_error_log_reg_mpccp_reg = (rsmu_sec_slave_error_log_reg_mpccp_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_VF_MASK) | (rsmu_sec_slave_error_vf << RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_VF_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_SET_RSMU_SEC_SLAVE_ERROR_VF_ID(rsmu_sec_slave_error_log_reg_mpccp_reg, rsmu_sec_slave_error_vf_id) \
     rsmu_sec_slave_error_log_reg_mpccp_reg = (rsmu_sec_slave_error_log_reg_mpccp_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_VF_ID_MASK) | (rsmu_sec_slave_error_vf_id << RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_VF_ID_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_SET_RSMU_SEC_SLAVE_ERROR_TLVL(rsmu_sec_slave_error_log_reg_mpccp_reg, rsmu_sec_slave_error_tlvl) \
     rsmu_sec_slave_error_log_reg_mpccp_reg = (rsmu_sec_slave_error_log_reg_mpccp_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_TLVL_MASK) | (rsmu_sec_slave_error_tlvl << RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_TLVL_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_SET_RSMU_SEC_SLAVE_ERROR_INITIATORID(rsmu_sec_slave_error_log_reg_mpccp_reg, rsmu_sec_slave_error_initiatorid) \
     rsmu_sec_slave_error_log_reg_mpccp_reg = (rsmu_sec_slave_error_log_reg_mpccp_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_INITIATORID_MASK) | (rsmu_sec_slave_error_initiatorid << RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_INITIATORID_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_SET_RSMU_SEC_SLAVE_ERROR_UNITID(rsmu_sec_slave_error_log_reg_mpccp_reg, rsmu_sec_slave_error_unitid) \
     rsmu_sec_slave_error_log_reg_mpccp_reg = (rsmu_sec_slave_error_log_reg_mpccp_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_UNITID_MASK) | (rsmu_sec_slave_error_unitid << RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_UNITID_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_SET_RSMU_SEC_SLAVE_ERROR_OP(rsmu_sec_slave_error_log_reg_mpccp_reg, rsmu_sec_slave_error_op) \
     rsmu_sec_slave_error_log_reg_mpccp_reg = (rsmu_sec_slave_error_log_reg_mpccp_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_OP_MASK) | (rsmu_sec_slave_error_op << RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_OP_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_SET_RSMU_SEC_SLAVE_ERROR_OUTSTANDING(rsmu_sec_slave_error_log_reg_mpccp_reg, rsmu_sec_slave_error_outstanding) \
     rsmu_sec_slave_error_log_reg_mpccp_reg = (rsmu_sec_slave_error_log_reg_mpccp_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_MASK) | (rsmu_sec_slave_error_outstanding << RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_slave_error_log_reg_mpccp_t {
          unsigned int rsmu_sec_slave_error_vf        : RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_VF_SIZE;
          unsigned int rsmu_sec_slave_error_vf_id     : RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_VF_ID_SIZE;
          unsigned int rsmu_sec_slave_error_tlvl      : RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_TLVL_SIZE;
          unsigned int rsmu_sec_slave_error_initiatorid : RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_INITIATORID_SIZE;
          unsigned int rsmu_sec_slave_error_unitid    : RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_UNITID_SIZE;
          unsigned int                                : 3;
          unsigned int rsmu_sec_slave_error_op        : RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_OP_SIZE;
          unsigned int rsmu_sec_slave_error_outstanding : RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_SIZE;
     } rsmu_sec_slave_error_log_reg_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_slave_error_log_reg_mpccp_t {
          unsigned int rsmu_sec_slave_error_outstanding : RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_SIZE;
          unsigned int rsmu_sec_slave_error_op        : RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_OP_SIZE;
          unsigned int                                : 3;
          unsigned int rsmu_sec_slave_error_unitid    : RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_UNITID_SIZE;
          unsigned int rsmu_sec_slave_error_initiatorid : RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_INITIATORID_SIZE;
          unsigned int rsmu_sec_slave_error_tlvl      : RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_TLVL_SIZE;
          unsigned int rsmu_sec_slave_error_vf_id     : RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_VF_ID_SIZE;
          unsigned int rsmu_sec_slave_error_vf        : RSMU_SEC_SLAVE_ERROR_LOG_REG_MPCCP_RSMU_SEC_SLAVE_ERROR_VF_SIZE;
     } rsmu_sec_slave_error_log_reg_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_slave_error_log_reg_mpccp_t f;
} rsmu_sec_slave_error_log_reg_mpccp_u;


/*
 * RSMU_MMIOSEC_SCRATCH_REG_0_MPCCP struct
 */

#define RSMU_MMIOSEC_SCRATCH_REG_0_MPCCP_REG_SIZE 32
#define RSMU_MMIOSEC_SCRATCH_REG_0_MPCCP_RSMU_MMIOSEC_SCRATCH_REG_0_SIZE 32

#define RSMU_MMIOSEC_SCRATCH_REG_0_MPCCP_RSMU_MMIOSEC_SCRATCH_REG_0_SHIFT 0

#define RSMU_MMIOSEC_SCRATCH_REG_0_MPCCP_RSMU_MMIOSEC_SCRATCH_REG_0_MASK 0xffffffff

#define RSMU_MMIOSEC_SCRATCH_REG_0_MPCCP_MASK \
     (RSMU_MMIOSEC_SCRATCH_REG_0_MPCCP_RSMU_MMIOSEC_SCRATCH_REG_0_MASK)

#define RSMU_MMIOSEC_SCRATCH_REG_0_MPCCP_DEFAULT 0x00000000

#define RSMU_MMIOSEC_SCRATCH_REG_0_MPCCP_GET_RSMU_MMIOSEC_SCRATCH_REG_0(rsmu_mmiosec_scratch_reg_0_mpccp) \
     ((rsmu_mmiosec_scratch_reg_0_mpccp & RSMU_MMIOSEC_SCRATCH_REG_0_MPCCP_RSMU_MMIOSEC_SCRATCH_REG_0_MASK) >> RSMU_MMIOSEC_SCRATCH_REG_0_MPCCP_RSMU_MMIOSEC_SCRATCH_REG_0_SHIFT)

#define RSMU_MMIOSEC_SCRATCH_REG_0_MPCCP_SET_RSMU_MMIOSEC_SCRATCH_REG_0(rsmu_mmiosec_scratch_reg_0_mpccp_reg, rsmu_mmiosec_scratch_reg_0) \
     rsmu_mmiosec_scratch_reg_0_mpccp_reg = (rsmu_mmiosec_scratch_reg_0_mpccp_reg & ~RSMU_MMIOSEC_SCRATCH_REG_0_MPCCP_RSMU_MMIOSEC_SCRATCH_REG_0_MASK) | (rsmu_mmiosec_scratch_reg_0 << RSMU_MMIOSEC_SCRATCH_REG_0_MPCCP_RSMU_MMIOSEC_SCRATCH_REG_0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_mmiosec_scratch_reg_0_mpccp_t {
          unsigned int rsmu_mmiosec_scratch_reg_0     : RSMU_MMIOSEC_SCRATCH_REG_0_MPCCP_RSMU_MMIOSEC_SCRATCH_REG_0_SIZE;
     } rsmu_mmiosec_scratch_reg_0_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_mmiosec_scratch_reg_0_mpccp_t {
          unsigned int rsmu_mmiosec_scratch_reg_0     : RSMU_MMIOSEC_SCRATCH_REG_0_MPCCP_RSMU_MMIOSEC_SCRATCH_REG_0_SIZE;
     } rsmu_mmiosec_scratch_reg_0_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_mmiosec_scratch_reg_0_mpccp_t f;
} rsmu_mmiosec_scratch_reg_0_mpccp_u;


/*
 * RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP struct
 */

#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_REG_SIZE 32
#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_IP_SIZE 24
#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE_SIZE 1

#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_IP_SHIFT 0
#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE_SHIFT 24

#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_IP_MASK 0xffffff
#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE_MASK 0x1000000

#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_MASK \
     (RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_IP_MASK | \
      RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE_MASK)

#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_DEFAULT 0x01ffffff

#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_GET_RSMU_SEC_MASTER_TRUST_LEVEL_IP(rsmu_sec_master_trust_level_ip_mpccp) \
     ((rsmu_sec_master_trust_level_ip_mpccp & RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_IP_MASK) >> RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_IP_SHIFT)
#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_GET_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE(rsmu_sec_master_trust_level_ip_mpccp) \
     ((rsmu_sec_master_trust_level_ip_mpccp & RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE_MASK) >> RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE_SHIFT)

#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_SET_RSMU_SEC_MASTER_TRUST_LEVEL_IP(rsmu_sec_master_trust_level_ip_mpccp_reg, rsmu_sec_master_trust_level_ip) \
     rsmu_sec_master_trust_level_ip_mpccp_reg = (rsmu_sec_master_trust_level_ip_mpccp_reg & ~RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_IP_MASK) | (rsmu_sec_master_trust_level_ip << RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_IP_SHIFT)
#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_SET_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE(rsmu_sec_master_trust_level_ip_mpccp_reg, rsmu_sec_master_trust_level_override) \
     rsmu_sec_master_trust_level_ip_mpccp_reg = (rsmu_sec_master_trust_level_ip_mpccp_reg & ~RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE_MASK) | (rsmu_sec_master_trust_level_override << RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_master_trust_level_ip_mpccp_t {
          unsigned int rsmu_sec_master_trust_level_ip : RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_IP_SIZE;
          unsigned int rsmu_sec_master_trust_level_override : RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE_SIZE;
          unsigned int                                : 7;
     } rsmu_sec_master_trust_level_ip_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_master_trust_level_ip_mpccp_t {
          unsigned int                                : 7;
          unsigned int rsmu_sec_master_trust_level_override : RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE_SIZE;
          unsigned int rsmu_sec_master_trust_level_ip : RSMU_SEC_MASTER_TRUST_LEVEL_IP_MPCCP_RSMU_SEC_MASTER_TRUST_LEVEL_IP_SIZE;
     } rsmu_sec_master_trust_level_ip_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_master_trust_level_ip_mpccp_t f;
} rsmu_sec_master_trust_level_ip_mpccp_u;


/*
 * RSMU_AEB_VALUE_0_MPCCP struct
 */

#define RSMU_AEB_VALUE_0_MPCCP_REG_SIZE 32
#define RSMU_AEB_VALUE_0_MPCCP_RSMU_AEB_VALUE_0_SIZE 32

#define RSMU_AEB_VALUE_0_MPCCP_RSMU_AEB_VALUE_0_SHIFT 0

#define RSMU_AEB_VALUE_0_MPCCP_RSMU_AEB_VALUE_0_MASK 0xffffffff

#define RSMU_AEB_VALUE_0_MPCCP_MASK \
     (RSMU_AEB_VALUE_0_MPCCP_RSMU_AEB_VALUE_0_MASK)

#define RSMU_AEB_VALUE_0_MPCCP_DEFAULT 0x00000000

#define RSMU_AEB_VALUE_0_MPCCP_GET_RSMU_AEB_VALUE_0(rsmu_aeb_value_0_mpccp) \
     ((rsmu_aeb_value_0_mpccp & RSMU_AEB_VALUE_0_MPCCP_RSMU_AEB_VALUE_0_MASK) >> RSMU_AEB_VALUE_0_MPCCP_RSMU_AEB_VALUE_0_SHIFT)

#define RSMU_AEB_VALUE_0_MPCCP_SET_RSMU_AEB_VALUE_0(rsmu_aeb_value_0_mpccp_reg, rsmu_aeb_value_0) \
     rsmu_aeb_value_0_mpccp_reg = (rsmu_aeb_value_0_mpccp_reg & ~RSMU_AEB_VALUE_0_MPCCP_RSMU_AEB_VALUE_0_MASK) | (rsmu_aeb_value_0 << RSMU_AEB_VALUE_0_MPCCP_RSMU_AEB_VALUE_0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_aeb_value_0_mpccp_t {
          unsigned int rsmu_aeb_value_0               : RSMU_AEB_VALUE_0_MPCCP_RSMU_AEB_VALUE_0_SIZE;
     } rsmu_aeb_value_0_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_aeb_value_0_mpccp_t {
          unsigned int rsmu_aeb_value_0               : RSMU_AEB_VALUE_0_MPCCP_RSMU_AEB_VALUE_0_SIZE;
     } rsmu_aeb_value_0_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_aeb_value_0_mpccp_t f;
} rsmu_aeb_value_0_mpccp_u;


/*
 * RSMU_AEB_VALUE_1_MPCCP struct
 */

#define RSMU_AEB_VALUE_1_MPCCP_REG_SIZE 32
#define RSMU_AEB_VALUE_1_MPCCP_RSMU_AEB_VALUE_1_SIZE 32

#define RSMU_AEB_VALUE_1_MPCCP_RSMU_AEB_VALUE_1_SHIFT 0

#define RSMU_AEB_VALUE_1_MPCCP_RSMU_AEB_VALUE_1_MASK 0xffffffff

#define RSMU_AEB_VALUE_1_MPCCP_MASK \
     (RSMU_AEB_VALUE_1_MPCCP_RSMU_AEB_VALUE_1_MASK)

#define RSMU_AEB_VALUE_1_MPCCP_DEFAULT 0x00000000

#define RSMU_AEB_VALUE_1_MPCCP_GET_RSMU_AEB_VALUE_1(rsmu_aeb_value_1_mpccp) \
     ((rsmu_aeb_value_1_mpccp & RSMU_AEB_VALUE_1_MPCCP_RSMU_AEB_VALUE_1_MASK) >> RSMU_AEB_VALUE_1_MPCCP_RSMU_AEB_VALUE_1_SHIFT)

#define RSMU_AEB_VALUE_1_MPCCP_SET_RSMU_AEB_VALUE_1(rsmu_aeb_value_1_mpccp_reg, rsmu_aeb_value_1) \
     rsmu_aeb_value_1_mpccp_reg = (rsmu_aeb_value_1_mpccp_reg & ~RSMU_AEB_VALUE_1_MPCCP_RSMU_AEB_VALUE_1_MASK) | (rsmu_aeb_value_1 << RSMU_AEB_VALUE_1_MPCCP_RSMU_AEB_VALUE_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_aeb_value_1_mpccp_t {
          unsigned int rsmu_aeb_value_1               : RSMU_AEB_VALUE_1_MPCCP_RSMU_AEB_VALUE_1_SIZE;
     } rsmu_aeb_value_1_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_aeb_value_1_mpccp_t {
          unsigned int rsmu_aeb_value_1               : RSMU_AEB_VALUE_1_MPCCP_RSMU_AEB_VALUE_1_SIZE;
     } rsmu_aeb_value_1_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_aeb_value_1_mpccp_t f;
} rsmu_aeb_value_1_mpccp_u;


/*
 * RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP struct
 */

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_REG_SIZE 32
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU_SIZE 10
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU_SIZE 3
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU_SIZE 7
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU_SIZE 10
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_OP_RSMU_SIZE 1
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU_SIZE 1

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU_SHIFT 0
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU_SHIFT 10
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU_SHIFT 13
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU_SHIFT 20
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_OP_RSMU_SHIFT 30
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU_SHIFT 31

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU_MASK 0x3ff
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU_MASK 0x1c00
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU_MASK 0xfe000
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU_MASK 0x3ff00000
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_OP_RSMU_MASK 0x40000000
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU_MASK 0x80000000

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_MASK \
     (RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_OP_RSMU_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU_MASK)

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_GET_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp) \
     ((rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp & RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_GET_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp) \
     ((rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp & RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_GET_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp) \
     ((rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp & RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_GET_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp) \
     ((rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp & RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_GET_RSMU_SEC_SLAVE_ERROR_OP_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp) \
     ((rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp & RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_OP_RSMU_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_OP_RSMU_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_GET_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp) \
     ((rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp & RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU_SHIFT)

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_SET_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_reg, rsmu_sec_slave_error_addr_rsmu) \
     rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_reg = (rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU_MASK) | (rsmu_sec_slave_error_addr_rsmu << RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_SET_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_reg, rsmu_sec_slave_error_tlvl_rsmu) \
     rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_reg = (rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU_MASK) | (rsmu_sec_slave_error_tlvl_rsmu << RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_SET_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_reg, rsmu_sec_slave_error_unitid_rsmu) \
     rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_reg = (rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU_MASK) | (rsmu_sec_slave_error_unitid_rsmu << RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_SET_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_reg, rsmu_sec_slave_error_initiatorid_rsmu) \
     rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_reg = (rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU_MASK) | (rsmu_sec_slave_error_initiatorid_rsmu << RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_SET_RSMU_SEC_SLAVE_ERROR_OP_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_reg, rsmu_sec_slave_error_op_rsmu) \
     rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_reg = (rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_OP_RSMU_MASK) | (rsmu_sec_slave_error_op_rsmu << RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_OP_RSMU_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_SET_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_reg, rsmu_sec_slave_error_outstanding_rsmu) \
     rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_reg = (rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU_MASK) | (rsmu_sec_slave_error_outstanding_rsmu << RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_t {
          unsigned int rsmu_sec_slave_error_addr_rsmu : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU_SIZE;
          unsigned int rsmu_sec_slave_error_tlvl_rsmu : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU_SIZE;
          unsigned int rsmu_sec_slave_error_unitid_rsmu : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU_SIZE;
          unsigned int rsmu_sec_slave_error_initiatorid_rsmu : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU_SIZE;
          unsigned int rsmu_sec_slave_error_op_rsmu   : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_OP_RSMU_SIZE;
          unsigned int rsmu_sec_slave_error_outstanding_rsmu : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU_SIZE;
     } rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_t {
          unsigned int rsmu_sec_slave_error_outstanding_rsmu : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU_SIZE;
          unsigned int rsmu_sec_slave_error_op_rsmu   : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_OP_RSMU_SIZE;
          unsigned int rsmu_sec_slave_error_initiatorid_rsmu : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU_SIZE;
          unsigned int rsmu_sec_slave_error_unitid_rsmu : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU_SIZE;
          unsigned int rsmu_sec_slave_error_tlvl_rsmu : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU_SIZE;
          unsigned int rsmu_sec_slave_error_addr_rsmu : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MPCCP_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU_SIZE;
     } rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_t f;
} rsmu_sec_slave_error_log_addr_reg_rsmu_mpccp_u;


/*
 * RSMU_SEC_SLAVE_RANGE_DISABLE_MPCCP struct
 */

#define RSMU_SEC_SLAVE_RANGE_DISABLE_MPCCP_REG_SIZE 32
#define RSMU_SEC_SLAVE_RANGE_DISABLE_MPCCP_RSMU_SEC_SLAVE_RANGE_DISABLE_SIZE 1

#define RSMU_SEC_SLAVE_RANGE_DISABLE_MPCCP_RSMU_SEC_SLAVE_RANGE_DISABLE_SHIFT 0

#define RSMU_SEC_SLAVE_RANGE_DISABLE_MPCCP_RSMU_SEC_SLAVE_RANGE_DISABLE_MASK 0x1

#define RSMU_SEC_SLAVE_RANGE_DISABLE_MPCCP_MASK \
     (RSMU_SEC_SLAVE_RANGE_DISABLE_MPCCP_RSMU_SEC_SLAVE_RANGE_DISABLE_MASK)

#define RSMU_SEC_SLAVE_RANGE_DISABLE_MPCCP_DEFAULT 0x00000000

#define RSMU_SEC_SLAVE_RANGE_DISABLE_MPCCP_GET_RSMU_SEC_SLAVE_RANGE_DISABLE(rsmu_sec_slave_range_disable_mpccp) \
     ((rsmu_sec_slave_range_disable_mpccp & RSMU_SEC_SLAVE_RANGE_DISABLE_MPCCP_RSMU_SEC_SLAVE_RANGE_DISABLE_MASK) >> RSMU_SEC_SLAVE_RANGE_DISABLE_MPCCP_RSMU_SEC_SLAVE_RANGE_DISABLE_SHIFT)

#define RSMU_SEC_SLAVE_RANGE_DISABLE_MPCCP_SET_RSMU_SEC_SLAVE_RANGE_DISABLE(rsmu_sec_slave_range_disable_mpccp_reg, rsmu_sec_slave_range_disable) \
     rsmu_sec_slave_range_disable_mpccp_reg = (rsmu_sec_slave_range_disable_mpccp_reg & ~RSMU_SEC_SLAVE_RANGE_DISABLE_MPCCP_RSMU_SEC_SLAVE_RANGE_DISABLE_MASK) | (rsmu_sec_slave_range_disable << RSMU_SEC_SLAVE_RANGE_DISABLE_MPCCP_RSMU_SEC_SLAVE_RANGE_DISABLE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _rsmu_sec_slave_range_disable_mpccp_t {
          unsigned int rsmu_sec_slave_range_disable   : RSMU_SEC_SLAVE_RANGE_DISABLE_MPCCP_RSMU_SEC_SLAVE_RANGE_DISABLE_SIZE;
          unsigned int                                : 31;
     } rsmu_sec_slave_range_disable_mpccp_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _rsmu_sec_slave_range_disable_mpccp_t {
          unsigned int                                : 31;
          unsigned int rsmu_sec_slave_range_disable   : RSMU_SEC_SLAVE_RANGE_DISABLE_MPCCP_RSMU_SEC_SLAVE_RANGE_DISABLE_SIZE;
     } rsmu_sec_slave_range_disable_mpccp_t;

#endif

typedef union {
     unsigned int val : 32;
     rsmu_sec_slave_range_disable_mpccp_t f;
} rsmu_sec_slave_range_disable_mpccp_u;


#endif


