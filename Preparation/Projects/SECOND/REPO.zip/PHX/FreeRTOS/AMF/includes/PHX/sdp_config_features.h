// Copyright (c) 2010 - 2019 Advanced Micro Devices, Inc. All rights reserved.
#ifndef __SDP_CONFIG_FEATURES_H__
#define __SDP_CONFIG_FEATURES_H__
// reference features

// imported features

// local features
#endif
