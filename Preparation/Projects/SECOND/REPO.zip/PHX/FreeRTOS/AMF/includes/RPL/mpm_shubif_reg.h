// Copyright (c) 1994 - 2021 Advanced Micro Devices, Inc. All rights reserved. 
 #if !defined (_MPM_SHUBIF_FIDDLE_H)
#define _MPM_SHUBIF_FIDDLE_H
 /*****************************************************************************************************************
 *
 *  mpm_shubif_reg.h
 *
 *  Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#define LITTLEENDIAN_CPU
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif

 /*******************************************************
 * Values
 *******************************************************/

 /*******************************************************
 * Structures
 *******************************************************/

/*
 * MPM_SYSHUB_SOC_TLB0_1 struct
 */

#define MPM_SYSHUB_SOC_TLB0_1_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_1_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_1_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_1_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_1_MASK \
      (MPM_SYSHUB_SOC_TLB0_1_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_1_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB0_1_GET_SOC_ADDR(mpm_syshub_soc_tlb0_1) \
      ((mpm_syshub_soc_tlb0_1 & MPM_SYSHUB_SOC_TLB0_1_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_1_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_1_SET_SOC_ADDR(mpm_syshub_soc_tlb0_1_reg, soc_addr) \
      mpm_syshub_soc_tlb0_1_reg = (mpm_syshub_soc_tlb0_1_reg & ~MPM_SYSHUB_SOC_TLB0_1_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_1_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_1_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_1_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_1_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_1_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_1_t f;
} mpm_syshub_soc_tlb0_1_u;


/*
 * MPM_SYSHUB_SOC_TLB1_1 struct
 */

#define MPM_SYSHUB_SOC_TLB1_1_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_1_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_1_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_1_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_1_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_1_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_1_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_1_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_1_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_1_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_1_MASK \
      (MPM_SYSHUB_SOC_TLB1_1_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_1_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_1_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_1_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB1_1_GET_COHERENCE(mpm_syshub_soc_tlb1_1) \
      ((mpm_syshub_soc_tlb1_1 & MPM_SYSHUB_SOC_TLB1_1_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_1_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_1_GET_SEG_SIZE(mpm_syshub_soc_tlb1_1) \
      ((mpm_syshub_soc_tlb1_1 & MPM_SYSHUB_SOC_TLB1_1_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_1_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_1_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_1) \
      ((mpm_syshub_soc_tlb1_1 & MPM_SYSHUB_SOC_TLB1_1_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_1_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_1_SET_COHERENCE(mpm_syshub_soc_tlb1_1_reg, coherence) \
      mpm_syshub_soc_tlb1_1_reg = (mpm_syshub_soc_tlb1_1_reg & ~MPM_SYSHUB_SOC_TLB1_1_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_1_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_1_SET_SEG_SIZE(mpm_syshub_soc_tlb1_1_reg, seg_size) \
      mpm_syshub_soc_tlb1_1_reg = (mpm_syshub_soc_tlb1_1_reg & ~MPM_SYSHUB_SOC_TLB1_1_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_1_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_1_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_1_reg, seg_offset) \
      mpm_syshub_soc_tlb1_1_reg = (mpm_syshub_soc_tlb1_1_reg & ~MPM_SYSHUB_SOC_TLB1_1_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_1_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_1_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_1_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_1_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_1_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_1_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_1_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_1_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_1_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_1_t f;
} mpm_syshub_soc_tlb1_1_u;


/*
 * MPM_SYSHUB_SOC_TLB2_1 struct
 */

#define MPM_SYSHUB_SOC_TLB2_1_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_1_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_1_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_1_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_1_MASK \
      (MPM_SYSHUB_SOC_TLB2_1_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_1_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB2_1_GET_AWUSER(mpm_syshub_soc_tlb2_1) \
      ((mpm_syshub_soc_tlb2_1 & MPM_SYSHUB_SOC_TLB2_1_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_1_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_1_SET_AWUSER(mpm_syshub_soc_tlb2_1_reg, awuser) \
      mpm_syshub_soc_tlb2_1_reg = (mpm_syshub_soc_tlb2_1_reg & ~MPM_SYSHUB_SOC_TLB2_1_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_1_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_1_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_1_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_1_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_1_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_1_t f;
} mpm_syshub_soc_tlb2_1_u;


/*
 * MPM_SYSHUB_SOC_TLB3_1 struct
 */

#define MPM_SYSHUB_SOC_TLB3_1_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_1_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_1_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_1_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_1_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_1_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_1_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_1_MASK \
      (MPM_SYSHUB_SOC_TLB3_1_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_1_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_1_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB3_1_GET_ARUSER(mpm_syshub_soc_tlb3_1) \
      ((mpm_syshub_soc_tlb3_1 & MPM_SYSHUB_SOC_TLB3_1_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_1_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_1_GET_WUSER(mpm_syshub_soc_tlb3_1) \
      ((mpm_syshub_soc_tlb3_1 & MPM_SYSHUB_SOC_TLB3_1_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_1_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_1_SET_ARUSER(mpm_syshub_soc_tlb3_1_reg, aruser) \
      mpm_syshub_soc_tlb3_1_reg = (mpm_syshub_soc_tlb3_1_reg & ~MPM_SYSHUB_SOC_TLB3_1_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_1_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_1_SET_WUSER(mpm_syshub_soc_tlb3_1_reg, wuser) \
      mpm_syshub_soc_tlb3_1_reg = (mpm_syshub_soc_tlb3_1_reg & ~MPM_SYSHUB_SOC_TLB3_1_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_1_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_1_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_1_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_1_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_1_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_1_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_1_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_1_t f;
} mpm_syshub_soc_tlb3_1_u;


/*
 * MPM_SYSHUB_SOC_TLB0_2 struct
 */

#define MPM_SYSHUB_SOC_TLB0_2_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_2_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_2_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_2_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_2_MASK \
      (MPM_SYSHUB_SOC_TLB0_2_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_2_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB0_2_GET_SOC_ADDR(mpm_syshub_soc_tlb0_2) \
      ((mpm_syshub_soc_tlb0_2 & MPM_SYSHUB_SOC_TLB0_2_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_2_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_2_SET_SOC_ADDR(mpm_syshub_soc_tlb0_2_reg, soc_addr) \
      mpm_syshub_soc_tlb0_2_reg = (mpm_syshub_soc_tlb0_2_reg & ~MPM_SYSHUB_SOC_TLB0_2_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_2_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_2_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_2_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_2_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_2_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_2_t f;
} mpm_syshub_soc_tlb0_2_u;


/*
 * MPM_SYSHUB_SOC_TLB1_2 struct
 */

#define MPM_SYSHUB_SOC_TLB1_2_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_2_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_2_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_2_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_2_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_2_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_2_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_2_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_2_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_2_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_2_MASK \
      (MPM_SYSHUB_SOC_TLB1_2_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_2_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_2_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_2_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB1_2_GET_COHERENCE(mpm_syshub_soc_tlb1_2) \
      ((mpm_syshub_soc_tlb1_2 & MPM_SYSHUB_SOC_TLB1_2_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_2_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_2_GET_SEG_SIZE(mpm_syshub_soc_tlb1_2) \
      ((mpm_syshub_soc_tlb1_2 & MPM_SYSHUB_SOC_TLB1_2_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_2_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_2_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_2) \
      ((mpm_syshub_soc_tlb1_2 & MPM_SYSHUB_SOC_TLB1_2_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_2_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_2_SET_COHERENCE(mpm_syshub_soc_tlb1_2_reg, coherence) \
      mpm_syshub_soc_tlb1_2_reg = (mpm_syshub_soc_tlb1_2_reg & ~MPM_SYSHUB_SOC_TLB1_2_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_2_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_2_SET_SEG_SIZE(mpm_syshub_soc_tlb1_2_reg, seg_size) \
      mpm_syshub_soc_tlb1_2_reg = (mpm_syshub_soc_tlb1_2_reg & ~MPM_SYSHUB_SOC_TLB1_2_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_2_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_2_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_2_reg, seg_offset) \
      mpm_syshub_soc_tlb1_2_reg = (mpm_syshub_soc_tlb1_2_reg & ~MPM_SYSHUB_SOC_TLB1_2_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_2_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_2_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_2_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_2_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_2_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_2_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_2_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_2_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_2_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_2_t f;
} mpm_syshub_soc_tlb1_2_u;


/*
 * MPM_SYSHUB_SOC_TLB2_2 struct
 */

#define MPM_SYSHUB_SOC_TLB2_2_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_2_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_2_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_2_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_2_MASK \
      (MPM_SYSHUB_SOC_TLB2_2_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_2_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB2_2_GET_AWUSER(mpm_syshub_soc_tlb2_2) \
      ((mpm_syshub_soc_tlb2_2 & MPM_SYSHUB_SOC_TLB2_2_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_2_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_2_SET_AWUSER(mpm_syshub_soc_tlb2_2_reg, awuser) \
      mpm_syshub_soc_tlb2_2_reg = (mpm_syshub_soc_tlb2_2_reg & ~MPM_SYSHUB_SOC_TLB2_2_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_2_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_2_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_2_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_2_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_2_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_2_t f;
} mpm_syshub_soc_tlb2_2_u;


/*
 * MPM_SYSHUB_SOC_TLB3_2 struct
 */

#define MPM_SYSHUB_SOC_TLB3_2_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_2_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_2_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_2_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_2_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_2_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_2_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_2_MASK \
      (MPM_SYSHUB_SOC_TLB3_2_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_2_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_2_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB3_2_GET_ARUSER(mpm_syshub_soc_tlb3_2) \
      ((mpm_syshub_soc_tlb3_2 & MPM_SYSHUB_SOC_TLB3_2_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_2_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_2_GET_WUSER(mpm_syshub_soc_tlb3_2) \
      ((mpm_syshub_soc_tlb3_2 & MPM_SYSHUB_SOC_TLB3_2_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_2_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_2_SET_ARUSER(mpm_syshub_soc_tlb3_2_reg, aruser) \
      mpm_syshub_soc_tlb3_2_reg = (mpm_syshub_soc_tlb3_2_reg & ~MPM_SYSHUB_SOC_TLB3_2_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_2_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_2_SET_WUSER(mpm_syshub_soc_tlb3_2_reg, wuser) \
      mpm_syshub_soc_tlb3_2_reg = (mpm_syshub_soc_tlb3_2_reg & ~MPM_SYSHUB_SOC_TLB3_2_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_2_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_2_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_2_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_2_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_2_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_2_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_2_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_2_t f;
} mpm_syshub_soc_tlb3_2_u;


/*
 * MPM_SYSHUB_SOC_TLB0_3 struct
 */

#define MPM_SYSHUB_SOC_TLB0_3_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_3_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_3_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_3_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_3_MASK \
      (MPM_SYSHUB_SOC_TLB0_3_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_3_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB0_3_GET_SOC_ADDR(mpm_syshub_soc_tlb0_3) \
      ((mpm_syshub_soc_tlb0_3 & MPM_SYSHUB_SOC_TLB0_3_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_3_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_3_SET_SOC_ADDR(mpm_syshub_soc_tlb0_3_reg, soc_addr) \
      mpm_syshub_soc_tlb0_3_reg = (mpm_syshub_soc_tlb0_3_reg & ~MPM_SYSHUB_SOC_TLB0_3_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_3_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_3_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_3_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_3_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_3_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_3_t f;
} mpm_syshub_soc_tlb0_3_u;


/*
 * MPM_SYSHUB_SOC_TLB1_3 struct
 */

#define MPM_SYSHUB_SOC_TLB1_3_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_3_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_3_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_3_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_3_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_3_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_3_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_3_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_3_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_3_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_3_MASK \
      (MPM_SYSHUB_SOC_TLB1_3_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_3_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_3_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_3_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB1_3_GET_COHERENCE(mpm_syshub_soc_tlb1_3) \
      ((mpm_syshub_soc_tlb1_3 & MPM_SYSHUB_SOC_TLB1_3_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_3_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_3_GET_SEG_SIZE(mpm_syshub_soc_tlb1_3) \
      ((mpm_syshub_soc_tlb1_3 & MPM_SYSHUB_SOC_TLB1_3_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_3_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_3_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_3) \
      ((mpm_syshub_soc_tlb1_3 & MPM_SYSHUB_SOC_TLB1_3_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_3_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_3_SET_COHERENCE(mpm_syshub_soc_tlb1_3_reg, coherence) \
      mpm_syshub_soc_tlb1_3_reg = (mpm_syshub_soc_tlb1_3_reg & ~MPM_SYSHUB_SOC_TLB1_3_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_3_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_3_SET_SEG_SIZE(mpm_syshub_soc_tlb1_3_reg, seg_size) \
      mpm_syshub_soc_tlb1_3_reg = (mpm_syshub_soc_tlb1_3_reg & ~MPM_SYSHUB_SOC_TLB1_3_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_3_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_3_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_3_reg, seg_offset) \
      mpm_syshub_soc_tlb1_3_reg = (mpm_syshub_soc_tlb1_3_reg & ~MPM_SYSHUB_SOC_TLB1_3_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_3_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_3_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_3_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_3_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_3_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_3_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_3_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_3_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_3_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_3_t f;
} mpm_syshub_soc_tlb1_3_u;


/*
 * MPM_SYSHUB_SOC_TLB2_3 struct
 */

#define MPM_SYSHUB_SOC_TLB2_3_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_3_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_3_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_3_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_3_MASK \
      (MPM_SYSHUB_SOC_TLB2_3_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_3_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB2_3_GET_AWUSER(mpm_syshub_soc_tlb2_3) \
      ((mpm_syshub_soc_tlb2_3 & MPM_SYSHUB_SOC_TLB2_3_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_3_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_3_SET_AWUSER(mpm_syshub_soc_tlb2_3_reg, awuser) \
      mpm_syshub_soc_tlb2_3_reg = (mpm_syshub_soc_tlb2_3_reg & ~MPM_SYSHUB_SOC_TLB2_3_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_3_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_3_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_3_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_3_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_3_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_3_t f;
} mpm_syshub_soc_tlb2_3_u;


/*
 * MPM_SYSHUB_SOC_TLB3_3 struct
 */

#define MPM_SYSHUB_SOC_TLB3_3_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_3_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_3_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_3_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_3_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_3_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_3_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_3_MASK \
      (MPM_SYSHUB_SOC_TLB3_3_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_3_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_3_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB3_3_GET_ARUSER(mpm_syshub_soc_tlb3_3) \
      ((mpm_syshub_soc_tlb3_3 & MPM_SYSHUB_SOC_TLB3_3_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_3_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_3_GET_WUSER(mpm_syshub_soc_tlb3_3) \
      ((mpm_syshub_soc_tlb3_3 & MPM_SYSHUB_SOC_TLB3_3_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_3_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_3_SET_ARUSER(mpm_syshub_soc_tlb3_3_reg, aruser) \
      mpm_syshub_soc_tlb3_3_reg = (mpm_syshub_soc_tlb3_3_reg & ~MPM_SYSHUB_SOC_TLB3_3_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_3_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_3_SET_WUSER(mpm_syshub_soc_tlb3_3_reg, wuser) \
      mpm_syshub_soc_tlb3_3_reg = (mpm_syshub_soc_tlb3_3_reg & ~MPM_SYSHUB_SOC_TLB3_3_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_3_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_3_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_3_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_3_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_3_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_3_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_3_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_3_t f;
} mpm_syshub_soc_tlb3_3_u;


/*
 * MPM_SYSHUB_SOC_TLB0_4 struct
 */

#define MPM_SYSHUB_SOC_TLB0_4_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_4_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_4_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_4_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_4_MASK \
      (MPM_SYSHUB_SOC_TLB0_4_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_4_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB0_4_GET_SOC_ADDR(mpm_syshub_soc_tlb0_4) \
      ((mpm_syshub_soc_tlb0_4 & MPM_SYSHUB_SOC_TLB0_4_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_4_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_4_SET_SOC_ADDR(mpm_syshub_soc_tlb0_4_reg, soc_addr) \
      mpm_syshub_soc_tlb0_4_reg = (mpm_syshub_soc_tlb0_4_reg & ~MPM_SYSHUB_SOC_TLB0_4_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_4_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_4_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_4_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_4_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_4_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_4_t f;
} mpm_syshub_soc_tlb0_4_u;


/*
 * MPM_SYSHUB_SOC_TLB1_4 struct
 */

#define MPM_SYSHUB_SOC_TLB1_4_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_4_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_4_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_4_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_4_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_4_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_4_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_4_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_4_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_4_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_4_MASK \
      (MPM_SYSHUB_SOC_TLB1_4_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_4_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_4_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_4_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB1_4_GET_COHERENCE(mpm_syshub_soc_tlb1_4) \
      ((mpm_syshub_soc_tlb1_4 & MPM_SYSHUB_SOC_TLB1_4_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_4_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_4_GET_SEG_SIZE(mpm_syshub_soc_tlb1_4) \
      ((mpm_syshub_soc_tlb1_4 & MPM_SYSHUB_SOC_TLB1_4_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_4_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_4_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_4) \
      ((mpm_syshub_soc_tlb1_4 & MPM_SYSHUB_SOC_TLB1_4_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_4_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_4_SET_COHERENCE(mpm_syshub_soc_tlb1_4_reg, coherence) \
      mpm_syshub_soc_tlb1_4_reg = (mpm_syshub_soc_tlb1_4_reg & ~MPM_SYSHUB_SOC_TLB1_4_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_4_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_4_SET_SEG_SIZE(mpm_syshub_soc_tlb1_4_reg, seg_size) \
      mpm_syshub_soc_tlb1_4_reg = (mpm_syshub_soc_tlb1_4_reg & ~MPM_SYSHUB_SOC_TLB1_4_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_4_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_4_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_4_reg, seg_offset) \
      mpm_syshub_soc_tlb1_4_reg = (mpm_syshub_soc_tlb1_4_reg & ~MPM_SYSHUB_SOC_TLB1_4_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_4_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_4_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_4_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_4_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_4_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_4_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_4_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_4_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_4_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_4_t f;
} mpm_syshub_soc_tlb1_4_u;


/*
 * MPM_SYSHUB_SOC_TLB2_4 struct
 */

#define MPM_SYSHUB_SOC_TLB2_4_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_4_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_4_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_4_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_4_MASK \
      (MPM_SYSHUB_SOC_TLB2_4_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_4_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB2_4_GET_AWUSER(mpm_syshub_soc_tlb2_4) \
      ((mpm_syshub_soc_tlb2_4 & MPM_SYSHUB_SOC_TLB2_4_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_4_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_4_SET_AWUSER(mpm_syshub_soc_tlb2_4_reg, awuser) \
      mpm_syshub_soc_tlb2_4_reg = (mpm_syshub_soc_tlb2_4_reg & ~MPM_SYSHUB_SOC_TLB2_4_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_4_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_4_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_4_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_4_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_4_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_4_t f;
} mpm_syshub_soc_tlb2_4_u;


/*
 * MPM_SYSHUB_SOC_TLB3_4 struct
 */

#define MPM_SYSHUB_SOC_TLB3_4_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_4_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_4_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_4_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_4_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_4_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_4_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_4_MASK \
      (MPM_SYSHUB_SOC_TLB3_4_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_4_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_4_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB3_4_GET_ARUSER(mpm_syshub_soc_tlb3_4) \
      ((mpm_syshub_soc_tlb3_4 & MPM_SYSHUB_SOC_TLB3_4_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_4_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_4_GET_WUSER(mpm_syshub_soc_tlb3_4) \
      ((mpm_syshub_soc_tlb3_4 & MPM_SYSHUB_SOC_TLB3_4_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_4_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_4_SET_ARUSER(mpm_syshub_soc_tlb3_4_reg, aruser) \
      mpm_syshub_soc_tlb3_4_reg = (mpm_syshub_soc_tlb3_4_reg & ~MPM_SYSHUB_SOC_TLB3_4_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_4_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_4_SET_WUSER(mpm_syshub_soc_tlb3_4_reg, wuser) \
      mpm_syshub_soc_tlb3_4_reg = (mpm_syshub_soc_tlb3_4_reg & ~MPM_SYSHUB_SOC_TLB3_4_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_4_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_4_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_4_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_4_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_4_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_4_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_4_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_4_t f;
} mpm_syshub_soc_tlb3_4_u;


/*
 * MPM_SYSHUB_SOC_TLB0_5 struct
 */

#define MPM_SYSHUB_SOC_TLB0_5_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_5_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_5_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_5_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_5_MASK \
      (MPM_SYSHUB_SOC_TLB0_5_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_5_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB0_5_GET_SOC_ADDR(mpm_syshub_soc_tlb0_5) \
      ((mpm_syshub_soc_tlb0_5 & MPM_SYSHUB_SOC_TLB0_5_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_5_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_5_SET_SOC_ADDR(mpm_syshub_soc_tlb0_5_reg, soc_addr) \
      mpm_syshub_soc_tlb0_5_reg = (mpm_syshub_soc_tlb0_5_reg & ~MPM_SYSHUB_SOC_TLB0_5_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_5_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_5_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_5_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_5_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_5_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_5_t f;
} mpm_syshub_soc_tlb0_5_u;


/*
 * MPM_SYSHUB_SOC_TLB1_5 struct
 */

#define MPM_SYSHUB_SOC_TLB1_5_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_5_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_5_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_5_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_5_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_5_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_5_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_5_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_5_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_5_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_5_MASK \
      (MPM_SYSHUB_SOC_TLB1_5_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_5_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_5_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_5_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB1_5_GET_COHERENCE(mpm_syshub_soc_tlb1_5) \
      ((mpm_syshub_soc_tlb1_5 & MPM_SYSHUB_SOC_TLB1_5_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_5_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_5_GET_SEG_SIZE(mpm_syshub_soc_tlb1_5) \
      ((mpm_syshub_soc_tlb1_5 & MPM_SYSHUB_SOC_TLB1_5_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_5_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_5_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_5) \
      ((mpm_syshub_soc_tlb1_5 & MPM_SYSHUB_SOC_TLB1_5_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_5_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_5_SET_COHERENCE(mpm_syshub_soc_tlb1_5_reg, coherence) \
      mpm_syshub_soc_tlb1_5_reg = (mpm_syshub_soc_tlb1_5_reg & ~MPM_SYSHUB_SOC_TLB1_5_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_5_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_5_SET_SEG_SIZE(mpm_syshub_soc_tlb1_5_reg, seg_size) \
      mpm_syshub_soc_tlb1_5_reg = (mpm_syshub_soc_tlb1_5_reg & ~MPM_SYSHUB_SOC_TLB1_5_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_5_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_5_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_5_reg, seg_offset) \
      mpm_syshub_soc_tlb1_5_reg = (mpm_syshub_soc_tlb1_5_reg & ~MPM_SYSHUB_SOC_TLB1_5_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_5_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_5_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_5_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_5_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_5_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_5_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_5_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_5_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_5_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_5_t f;
} mpm_syshub_soc_tlb1_5_u;


/*
 * MPM_SYSHUB_SOC_TLB2_5 struct
 */

#define MPM_SYSHUB_SOC_TLB2_5_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_5_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_5_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_5_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_5_MASK \
      (MPM_SYSHUB_SOC_TLB2_5_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_5_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB2_5_GET_AWUSER(mpm_syshub_soc_tlb2_5) \
      ((mpm_syshub_soc_tlb2_5 & MPM_SYSHUB_SOC_TLB2_5_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_5_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_5_SET_AWUSER(mpm_syshub_soc_tlb2_5_reg, awuser) \
      mpm_syshub_soc_tlb2_5_reg = (mpm_syshub_soc_tlb2_5_reg & ~MPM_SYSHUB_SOC_TLB2_5_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_5_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_5_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_5_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_5_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_5_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_5_t f;
} mpm_syshub_soc_tlb2_5_u;


/*
 * MPM_SYSHUB_SOC_TLB3_5 struct
 */

#define MPM_SYSHUB_SOC_TLB3_5_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_5_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_5_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_5_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_5_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_5_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_5_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_5_MASK \
      (MPM_SYSHUB_SOC_TLB3_5_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_5_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_5_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB3_5_GET_ARUSER(mpm_syshub_soc_tlb3_5) \
      ((mpm_syshub_soc_tlb3_5 & MPM_SYSHUB_SOC_TLB3_5_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_5_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_5_GET_WUSER(mpm_syshub_soc_tlb3_5) \
      ((mpm_syshub_soc_tlb3_5 & MPM_SYSHUB_SOC_TLB3_5_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_5_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_5_SET_ARUSER(mpm_syshub_soc_tlb3_5_reg, aruser) \
      mpm_syshub_soc_tlb3_5_reg = (mpm_syshub_soc_tlb3_5_reg & ~MPM_SYSHUB_SOC_TLB3_5_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_5_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_5_SET_WUSER(mpm_syshub_soc_tlb3_5_reg, wuser) \
      mpm_syshub_soc_tlb3_5_reg = (mpm_syshub_soc_tlb3_5_reg & ~MPM_SYSHUB_SOC_TLB3_5_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_5_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_5_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_5_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_5_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_5_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_5_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_5_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_5_t f;
} mpm_syshub_soc_tlb3_5_u;


/*
 * MPM_SYSHUB_SOC_TLB0_6 struct
 */

#define MPM_SYSHUB_SOC_TLB0_6_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_6_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_6_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_6_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_6_MASK \
      (MPM_SYSHUB_SOC_TLB0_6_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_6_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB0_6_GET_SOC_ADDR(mpm_syshub_soc_tlb0_6) \
      ((mpm_syshub_soc_tlb0_6 & MPM_SYSHUB_SOC_TLB0_6_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_6_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_6_SET_SOC_ADDR(mpm_syshub_soc_tlb0_6_reg, soc_addr) \
      mpm_syshub_soc_tlb0_6_reg = (mpm_syshub_soc_tlb0_6_reg & ~MPM_SYSHUB_SOC_TLB0_6_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_6_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_6_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_6_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_6_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_6_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_6_t f;
} mpm_syshub_soc_tlb0_6_u;


/*
 * MPM_SYSHUB_SOC_TLB1_6 struct
 */

#define MPM_SYSHUB_SOC_TLB1_6_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_6_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_6_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_6_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_6_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_6_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_6_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_6_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_6_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_6_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_6_MASK \
      (MPM_SYSHUB_SOC_TLB1_6_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_6_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_6_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_6_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB1_6_GET_COHERENCE(mpm_syshub_soc_tlb1_6) \
      ((mpm_syshub_soc_tlb1_6 & MPM_SYSHUB_SOC_TLB1_6_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_6_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_6_GET_SEG_SIZE(mpm_syshub_soc_tlb1_6) \
      ((mpm_syshub_soc_tlb1_6 & MPM_SYSHUB_SOC_TLB1_6_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_6_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_6_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_6) \
      ((mpm_syshub_soc_tlb1_6 & MPM_SYSHUB_SOC_TLB1_6_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_6_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_6_SET_COHERENCE(mpm_syshub_soc_tlb1_6_reg, coherence) \
      mpm_syshub_soc_tlb1_6_reg = (mpm_syshub_soc_tlb1_6_reg & ~MPM_SYSHUB_SOC_TLB1_6_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_6_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_6_SET_SEG_SIZE(mpm_syshub_soc_tlb1_6_reg, seg_size) \
      mpm_syshub_soc_tlb1_6_reg = (mpm_syshub_soc_tlb1_6_reg & ~MPM_SYSHUB_SOC_TLB1_6_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_6_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_6_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_6_reg, seg_offset) \
      mpm_syshub_soc_tlb1_6_reg = (mpm_syshub_soc_tlb1_6_reg & ~MPM_SYSHUB_SOC_TLB1_6_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_6_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_6_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_6_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_6_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_6_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_6_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_6_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_6_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_6_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_6_t f;
} mpm_syshub_soc_tlb1_6_u;


/*
 * MPM_SYSHUB_SOC_TLB2_6 struct
 */

#define MPM_SYSHUB_SOC_TLB2_6_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_6_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_6_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_6_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_6_MASK \
      (MPM_SYSHUB_SOC_TLB2_6_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_6_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB2_6_GET_AWUSER(mpm_syshub_soc_tlb2_6) \
      ((mpm_syshub_soc_tlb2_6 & MPM_SYSHUB_SOC_TLB2_6_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_6_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_6_SET_AWUSER(mpm_syshub_soc_tlb2_6_reg, awuser) \
      mpm_syshub_soc_tlb2_6_reg = (mpm_syshub_soc_tlb2_6_reg & ~MPM_SYSHUB_SOC_TLB2_6_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_6_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_6_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_6_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_6_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_6_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_6_t f;
} mpm_syshub_soc_tlb2_6_u;


/*
 * MPM_SYSHUB_SOC_TLB3_6 struct
 */

#define MPM_SYSHUB_SOC_TLB3_6_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_6_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_6_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_6_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_6_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_6_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_6_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_6_MASK \
      (MPM_SYSHUB_SOC_TLB3_6_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_6_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_6_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB3_6_GET_ARUSER(mpm_syshub_soc_tlb3_6) \
      ((mpm_syshub_soc_tlb3_6 & MPM_SYSHUB_SOC_TLB3_6_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_6_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_6_GET_WUSER(mpm_syshub_soc_tlb3_6) \
      ((mpm_syshub_soc_tlb3_6 & MPM_SYSHUB_SOC_TLB3_6_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_6_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_6_SET_ARUSER(mpm_syshub_soc_tlb3_6_reg, aruser) \
      mpm_syshub_soc_tlb3_6_reg = (mpm_syshub_soc_tlb3_6_reg & ~MPM_SYSHUB_SOC_TLB3_6_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_6_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_6_SET_WUSER(mpm_syshub_soc_tlb3_6_reg, wuser) \
      mpm_syshub_soc_tlb3_6_reg = (mpm_syshub_soc_tlb3_6_reg & ~MPM_SYSHUB_SOC_TLB3_6_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_6_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_6_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_6_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_6_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_6_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_6_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_6_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_6_t f;
} mpm_syshub_soc_tlb3_6_u;


/*
 * MPM_SYSHUB_SOC_TLB0_7 struct
 */

#define MPM_SYSHUB_SOC_TLB0_7_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_7_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_7_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_7_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_7_MASK \
      (MPM_SYSHUB_SOC_TLB0_7_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_7_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB0_7_GET_SOC_ADDR(mpm_syshub_soc_tlb0_7) \
      ((mpm_syshub_soc_tlb0_7 & MPM_SYSHUB_SOC_TLB0_7_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_7_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_7_SET_SOC_ADDR(mpm_syshub_soc_tlb0_7_reg, soc_addr) \
      mpm_syshub_soc_tlb0_7_reg = (mpm_syshub_soc_tlb0_7_reg & ~MPM_SYSHUB_SOC_TLB0_7_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_7_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_7_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_7_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_7_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_7_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_7_t f;
} mpm_syshub_soc_tlb0_7_u;


/*
 * MPM_SYSHUB_SOC_TLB1_7 struct
 */

#define MPM_SYSHUB_SOC_TLB1_7_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_7_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_7_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_7_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_7_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_7_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_7_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_7_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_7_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_7_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_7_MASK \
      (MPM_SYSHUB_SOC_TLB1_7_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_7_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_7_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_7_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB1_7_GET_COHERENCE(mpm_syshub_soc_tlb1_7) \
      ((mpm_syshub_soc_tlb1_7 & MPM_SYSHUB_SOC_TLB1_7_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_7_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_7_GET_SEG_SIZE(mpm_syshub_soc_tlb1_7) \
      ((mpm_syshub_soc_tlb1_7 & MPM_SYSHUB_SOC_TLB1_7_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_7_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_7_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_7) \
      ((mpm_syshub_soc_tlb1_7 & MPM_SYSHUB_SOC_TLB1_7_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_7_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_7_SET_COHERENCE(mpm_syshub_soc_tlb1_7_reg, coherence) \
      mpm_syshub_soc_tlb1_7_reg = (mpm_syshub_soc_tlb1_7_reg & ~MPM_SYSHUB_SOC_TLB1_7_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_7_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_7_SET_SEG_SIZE(mpm_syshub_soc_tlb1_7_reg, seg_size) \
      mpm_syshub_soc_tlb1_7_reg = (mpm_syshub_soc_tlb1_7_reg & ~MPM_SYSHUB_SOC_TLB1_7_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_7_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_7_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_7_reg, seg_offset) \
      mpm_syshub_soc_tlb1_7_reg = (mpm_syshub_soc_tlb1_7_reg & ~MPM_SYSHUB_SOC_TLB1_7_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_7_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_7_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_7_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_7_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_7_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_7_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_7_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_7_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_7_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_7_t f;
} mpm_syshub_soc_tlb1_7_u;


/*
 * MPM_SYSHUB_SOC_TLB2_7 struct
 */

#define MPM_SYSHUB_SOC_TLB2_7_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_7_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_7_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_7_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_7_MASK \
      (MPM_SYSHUB_SOC_TLB2_7_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_7_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB2_7_GET_AWUSER(mpm_syshub_soc_tlb2_7) \
      ((mpm_syshub_soc_tlb2_7 & MPM_SYSHUB_SOC_TLB2_7_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_7_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_7_SET_AWUSER(mpm_syshub_soc_tlb2_7_reg, awuser) \
      mpm_syshub_soc_tlb2_7_reg = (mpm_syshub_soc_tlb2_7_reg & ~MPM_SYSHUB_SOC_TLB2_7_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_7_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_7_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_7_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_7_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_7_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_7_t f;
} mpm_syshub_soc_tlb2_7_u;


/*
 * MPM_SYSHUB_SOC_TLB3_7 struct
 */

#define MPM_SYSHUB_SOC_TLB3_7_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_7_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_7_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_7_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_7_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_7_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_7_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_7_MASK \
      (MPM_SYSHUB_SOC_TLB3_7_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_7_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_7_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB3_7_GET_ARUSER(mpm_syshub_soc_tlb3_7) \
      ((mpm_syshub_soc_tlb3_7 & MPM_SYSHUB_SOC_TLB3_7_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_7_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_7_GET_WUSER(mpm_syshub_soc_tlb3_7) \
      ((mpm_syshub_soc_tlb3_7 & MPM_SYSHUB_SOC_TLB3_7_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_7_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_7_SET_ARUSER(mpm_syshub_soc_tlb3_7_reg, aruser) \
      mpm_syshub_soc_tlb3_7_reg = (mpm_syshub_soc_tlb3_7_reg & ~MPM_SYSHUB_SOC_TLB3_7_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_7_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_7_SET_WUSER(mpm_syshub_soc_tlb3_7_reg, wuser) \
      mpm_syshub_soc_tlb3_7_reg = (mpm_syshub_soc_tlb3_7_reg & ~MPM_SYSHUB_SOC_TLB3_7_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_7_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_7_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_7_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_7_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_7_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_7_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_7_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_7_t f;
} mpm_syshub_soc_tlb3_7_u;


/*
 * MPM_SYSHUB_SOC_TLB0_8 struct
 */

#define MPM_SYSHUB_SOC_TLB0_8_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_8_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_8_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_8_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_8_MASK \
      (MPM_SYSHUB_SOC_TLB0_8_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_8_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB0_8_GET_SOC_ADDR(mpm_syshub_soc_tlb0_8) \
      ((mpm_syshub_soc_tlb0_8 & MPM_SYSHUB_SOC_TLB0_8_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_8_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_8_SET_SOC_ADDR(mpm_syshub_soc_tlb0_8_reg, soc_addr) \
      mpm_syshub_soc_tlb0_8_reg = (mpm_syshub_soc_tlb0_8_reg & ~MPM_SYSHUB_SOC_TLB0_8_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_8_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_8_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_8_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_8_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_8_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_8_t f;
} mpm_syshub_soc_tlb0_8_u;


/*
 * MPM_SYSHUB_SOC_TLB1_8 struct
 */

#define MPM_SYSHUB_SOC_TLB1_8_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_8_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_8_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_8_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_8_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_8_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_8_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_8_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_8_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_8_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_8_MASK \
      (MPM_SYSHUB_SOC_TLB1_8_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_8_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_8_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_8_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB1_8_GET_COHERENCE(mpm_syshub_soc_tlb1_8) \
      ((mpm_syshub_soc_tlb1_8 & MPM_SYSHUB_SOC_TLB1_8_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_8_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_8_GET_SEG_SIZE(mpm_syshub_soc_tlb1_8) \
      ((mpm_syshub_soc_tlb1_8 & MPM_SYSHUB_SOC_TLB1_8_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_8_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_8_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_8) \
      ((mpm_syshub_soc_tlb1_8 & MPM_SYSHUB_SOC_TLB1_8_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_8_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_8_SET_COHERENCE(mpm_syshub_soc_tlb1_8_reg, coherence) \
      mpm_syshub_soc_tlb1_8_reg = (mpm_syshub_soc_tlb1_8_reg & ~MPM_SYSHUB_SOC_TLB1_8_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_8_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_8_SET_SEG_SIZE(mpm_syshub_soc_tlb1_8_reg, seg_size) \
      mpm_syshub_soc_tlb1_8_reg = (mpm_syshub_soc_tlb1_8_reg & ~MPM_SYSHUB_SOC_TLB1_8_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_8_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_8_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_8_reg, seg_offset) \
      mpm_syshub_soc_tlb1_8_reg = (mpm_syshub_soc_tlb1_8_reg & ~MPM_SYSHUB_SOC_TLB1_8_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_8_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_8_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_8_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_8_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_8_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_8_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_8_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_8_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_8_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_8_t f;
} mpm_syshub_soc_tlb1_8_u;


/*
 * MPM_SYSHUB_SOC_TLB2_8 struct
 */

#define MPM_SYSHUB_SOC_TLB2_8_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_8_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_8_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_8_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_8_MASK \
      (MPM_SYSHUB_SOC_TLB2_8_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_8_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB2_8_GET_AWUSER(mpm_syshub_soc_tlb2_8) \
      ((mpm_syshub_soc_tlb2_8 & MPM_SYSHUB_SOC_TLB2_8_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_8_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_8_SET_AWUSER(mpm_syshub_soc_tlb2_8_reg, awuser) \
      mpm_syshub_soc_tlb2_8_reg = (mpm_syshub_soc_tlb2_8_reg & ~MPM_SYSHUB_SOC_TLB2_8_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_8_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_8_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_8_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_8_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_8_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_8_t f;
} mpm_syshub_soc_tlb2_8_u;


/*
 * MPM_SYSHUB_SOC_TLB3_8 struct
 */

#define MPM_SYSHUB_SOC_TLB3_8_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_8_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_8_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_8_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_8_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_8_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_8_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_8_MASK \
      (MPM_SYSHUB_SOC_TLB3_8_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_8_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_8_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB3_8_GET_ARUSER(mpm_syshub_soc_tlb3_8) \
      ((mpm_syshub_soc_tlb3_8 & MPM_SYSHUB_SOC_TLB3_8_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_8_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_8_GET_WUSER(mpm_syshub_soc_tlb3_8) \
      ((mpm_syshub_soc_tlb3_8 & MPM_SYSHUB_SOC_TLB3_8_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_8_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_8_SET_ARUSER(mpm_syshub_soc_tlb3_8_reg, aruser) \
      mpm_syshub_soc_tlb3_8_reg = (mpm_syshub_soc_tlb3_8_reg & ~MPM_SYSHUB_SOC_TLB3_8_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_8_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_8_SET_WUSER(mpm_syshub_soc_tlb3_8_reg, wuser) \
      mpm_syshub_soc_tlb3_8_reg = (mpm_syshub_soc_tlb3_8_reg & ~MPM_SYSHUB_SOC_TLB3_8_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_8_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_8_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_8_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_8_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_8_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_8_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_8_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_8_t f;
} mpm_syshub_soc_tlb3_8_u;


/*
 * MPM_SYSHUB_SOC_TLB0_9 struct
 */

#define MPM_SYSHUB_SOC_TLB0_9_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_9_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_9_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_9_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_9_MASK \
      (MPM_SYSHUB_SOC_TLB0_9_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_9_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB0_9_GET_SOC_ADDR(mpm_syshub_soc_tlb0_9) \
      ((mpm_syshub_soc_tlb0_9 & MPM_SYSHUB_SOC_TLB0_9_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_9_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_9_SET_SOC_ADDR(mpm_syshub_soc_tlb0_9_reg, soc_addr) \
      mpm_syshub_soc_tlb0_9_reg = (mpm_syshub_soc_tlb0_9_reg & ~MPM_SYSHUB_SOC_TLB0_9_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_9_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_9_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_9_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_9_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_9_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_9_t f;
} mpm_syshub_soc_tlb0_9_u;


/*
 * MPM_SYSHUB_SOC_TLB1_9 struct
 */

#define MPM_SYSHUB_SOC_TLB1_9_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_9_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_9_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_9_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_9_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_9_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_9_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_9_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_9_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_9_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_9_MASK \
      (MPM_SYSHUB_SOC_TLB1_9_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_9_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_9_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_9_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB1_9_GET_COHERENCE(mpm_syshub_soc_tlb1_9) \
      ((mpm_syshub_soc_tlb1_9 & MPM_SYSHUB_SOC_TLB1_9_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_9_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_9_GET_SEG_SIZE(mpm_syshub_soc_tlb1_9) \
      ((mpm_syshub_soc_tlb1_9 & MPM_SYSHUB_SOC_TLB1_9_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_9_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_9_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_9) \
      ((mpm_syshub_soc_tlb1_9 & MPM_SYSHUB_SOC_TLB1_9_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_9_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_9_SET_COHERENCE(mpm_syshub_soc_tlb1_9_reg, coherence) \
      mpm_syshub_soc_tlb1_9_reg = (mpm_syshub_soc_tlb1_9_reg & ~MPM_SYSHUB_SOC_TLB1_9_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_9_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_9_SET_SEG_SIZE(mpm_syshub_soc_tlb1_9_reg, seg_size) \
      mpm_syshub_soc_tlb1_9_reg = (mpm_syshub_soc_tlb1_9_reg & ~MPM_SYSHUB_SOC_TLB1_9_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_9_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_9_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_9_reg, seg_offset) \
      mpm_syshub_soc_tlb1_9_reg = (mpm_syshub_soc_tlb1_9_reg & ~MPM_SYSHUB_SOC_TLB1_9_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_9_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_9_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_9_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_9_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_9_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_9_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_9_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_9_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_9_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_9_t f;
} mpm_syshub_soc_tlb1_9_u;


/*
 * MPM_SYSHUB_SOC_TLB2_9 struct
 */

#define MPM_SYSHUB_SOC_TLB2_9_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_9_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_9_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_9_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_9_MASK \
      (MPM_SYSHUB_SOC_TLB2_9_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_9_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB2_9_GET_AWUSER(mpm_syshub_soc_tlb2_9) \
      ((mpm_syshub_soc_tlb2_9 & MPM_SYSHUB_SOC_TLB2_9_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_9_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_9_SET_AWUSER(mpm_syshub_soc_tlb2_9_reg, awuser) \
      mpm_syshub_soc_tlb2_9_reg = (mpm_syshub_soc_tlb2_9_reg & ~MPM_SYSHUB_SOC_TLB2_9_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_9_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_9_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_9_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_9_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_9_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_9_t f;
} mpm_syshub_soc_tlb2_9_u;


/*
 * MPM_SYSHUB_SOC_TLB3_9 struct
 */

#define MPM_SYSHUB_SOC_TLB3_9_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_9_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_9_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_9_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_9_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_9_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_9_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_9_MASK \
      (MPM_SYSHUB_SOC_TLB3_9_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_9_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_9_DEFAULT  0x00000000

#define MPM_SYSHUB_SOC_TLB3_9_GET_ARUSER(mpm_syshub_soc_tlb3_9) \
      ((mpm_syshub_soc_tlb3_9 & MPM_SYSHUB_SOC_TLB3_9_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_9_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_9_GET_WUSER(mpm_syshub_soc_tlb3_9) \
      ((mpm_syshub_soc_tlb3_9 & MPM_SYSHUB_SOC_TLB3_9_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_9_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_9_SET_ARUSER(mpm_syshub_soc_tlb3_9_reg, aruser) \
      mpm_syshub_soc_tlb3_9_reg = (mpm_syshub_soc_tlb3_9_reg & ~MPM_SYSHUB_SOC_TLB3_9_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_9_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_9_SET_WUSER(mpm_syshub_soc_tlb3_9_reg, wuser) \
      mpm_syshub_soc_tlb3_9_reg = (mpm_syshub_soc_tlb3_9_reg & ~MPM_SYSHUB_SOC_TLB3_9_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_9_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_9_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_9_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_9_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_9_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_9_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_9_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_9_t f;
} mpm_syshub_soc_tlb3_9_u;


/*
 * MPM_SYSHUB_SOC_TLB0_10 struct
 */

#define MPM_SYSHUB_SOC_TLB0_10_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_10_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_10_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_10_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_10_MASK \
      (MPM_SYSHUB_SOC_TLB0_10_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_10_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_10_GET_SOC_ADDR(mpm_syshub_soc_tlb0_10) \
      ((mpm_syshub_soc_tlb0_10 & MPM_SYSHUB_SOC_TLB0_10_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_10_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_10_SET_SOC_ADDR(mpm_syshub_soc_tlb0_10_reg, soc_addr) \
      mpm_syshub_soc_tlb0_10_reg = (mpm_syshub_soc_tlb0_10_reg & ~MPM_SYSHUB_SOC_TLB0_10_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_10_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_10_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_10_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_10_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_10_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_10_t f;
} mpm_syshub_soc_tlb0_10_u;


/*
 * MPM_SYSHUB_SOC_TLB1_10 struct
 */

#define MPM_SYSHUB_SOC_TLB1_10_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_10_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_10_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_10_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_10_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_10_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_10_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_10_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_10_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_10_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_10_MASK \
      (MPM_SYSHUB_SOC_TLB1_10_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_10_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_10_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_10_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_10_GET_COHERENCE(mpm_syshub_soc_tlb1_10) \
      ((mpm_syshub_soc_tlb1_10 & MPM_SYSHUB_SOC_TLB1_10_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_10_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_10_GET_SEG_SIZE(mpm_syshub_soc_tlb1_10) \
      ((mpm_syshub_soc_tlb1_10 & MPM_SYSHUB_SOC_TLB1_10_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_10_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_10_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_10) \
      ((mpm_syshub_soc_tlb1_10 & MPM_SYSHUB_SOC_TLB1_10_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_10_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_10_SET_COHERENCE(mpm_syshub_soc_tlb1_10_reg, coherence) \
      mpm_syshub_soc_tlb1_10_reg = (mpm_syshub_soc_tlb1_10_reg & ~MPM_SYSHUB_SOC_TLB1_10_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_10_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_10_SET_SEG_SIZE(mpm_syshub_soc_tlb1_10_reg, seg_size) \
      mpm_syshub_soc_tlb1_10_reg = (mpm_syshub_soc_tlb1_10_reg & ~MPM_SYSHUB_SOC_TLB1_10_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_10_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_10_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_10_reg, seg_offset) \
      mpm_syshub_soc_tlb1_10_reg = (mpm_syshub_soc_tlb1_10_reg & ~MPM_SYSHUB_SOC_TLB1_10_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_10_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_10_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_10_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_10_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_10_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_10_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_10_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_10_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_10_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_10_t f;
} mpm_syshub_soc_tlb1_10_u;


/*
 * MPM_SYSHUB_SOC_TLB2_10 struct
 */

#define MPM_SYSHUB_SOC_TLB2_10_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_10_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_10_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_10_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_10_MASK \
      (MPM_SYSHUB_SOC_TLB2_10_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_10_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_10_GET_AWUSER(mpm_syshub_soc_tlb2_10) \
      ((mpm_syshub_soc_tlb2_10 & MPM_SYSHUB_SOC_TLB2_10_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_10_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_10_SET_AWUSER(mpm_syshub_soc_tlb2_10_reg, awuser) \
      mpm_syshub_soc_tlb2_10_reg = (mpm_syshub_soc_tlb2_10_reg & ~MPM_SYSHUB_SOC_TLB2_10_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_10_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_10_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_10_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_10_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_10_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_10_t f;
} mpm_syshub_soc_tlb2_10_u;


/*
 * MPM_SYSHUB_SOC_TLB3_10 struct
 */

#define MPM_SYSHUB_SOC_TLB3_10_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_10_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_10_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_10_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_10_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_10_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_10_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_10_MASK \
      (MPM_SYSHUB_SOC_TLB3_10_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_10_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_10_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_10_GET_ARUSER(mpm_syshub_soc_tlb3_10) \
      ((mpm_syshub_soc_tlb3_10 & MPM_SYSHUB_SOC_TLB3_10_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_10_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_10_GET_WUSER(mpm_syshub_soc_tlb3_10) \
      ((mpm_syshub_soc_tlb3_10 & MPM_SYSHUB_SOC_TLB3_10_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_10_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_10_SET_ARUSER(mpm_syshub_soc_tlb3_10_reg, aruser) \
      mpm_syshub_soc_tlb3_10_reg = (mpm_syshub_soc_tlb3_10_reg & ~MPM_SYSHUB_SOC_TLB3_10_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_10_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_10_SET_WUSER(mpm_syshub_soc_tlb3_10_reg, wuser) \
      mpm_syshub_soc_tlb3_10_reg = (mpm_syshub_soc_tlb3_10_reg & ~MPM_SYSHUB_SOC_TLB3_10_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_10_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_10_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_10_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_10_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_10_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_10_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_10_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_10_t f;
} mpm_syshub_soc_tlb3_10_u;


/*
 * MPM_SYSHUB_SOC_TLB0_11 struct
 */

#define MPM_SYSHUB_SOC_TLB0_11_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_11_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_11_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_11_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_11_MASK \
      (MPM_SYSHUB_SOC_TLB0_11_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_11_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_11_GET_SOC_ADDR(mpm_syshub_soc_tlb0_11) \
      ((mpm_syshub_soc_tlb0_11 & MPM_SYSHUB_SOC_TLB0_11_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_11_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_11_SET_SOC_ADDR(mpm_syshub_soc_tlb0_11_reg, soc_addr) \
      mpm_syshub_soc_tlb0_11_reg = (mpm_syshub_soc_tlb0_11_reg & ~MPM_SYSHUB_SOC_TLB0_11_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_11_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_11_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_11_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_11_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_11_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_11_t f;
} mpm_syshub_soc_tlb0_11_u;


/*
 * MPM_SYSHUB_SOC_TLB1_11 struct
 */

#define MPM_SYSHUB_SOC_TLB1_11_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_11_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_11_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_11_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_11_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_11_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_11_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_11_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_11_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_11_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_11_MASK \
      (MPM_SYSHUB_SOC_TLB1_11_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_11_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_11_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_11_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_11_GET_COHERENCE(mpm_syshub_soc_tlb1_11) \
      ((mpm_syshub_soc_tlb1_11 & MPM_SYSHUB_SOC_TLB1_11_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_11_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_11_GET_SEG_SIZE(mpm_syshub_soc_tlb1_11) \
      ((mpm_syshub_soc_tlb1_11 & MPM_SYSHUB_SOC_TLB1_11_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_11_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_11_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_11) \
      ((mpm_syshub_soc_tlb1_11 & MPM_SYSHUB_SOC_TLB1_11_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_11_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_11_SET_COHERENCE(mpm_syshub_soc_tlb1_11_reg, coherence) \
      mpm_syshub_soc_tlb1_11_reg = (mpm_syshub_soc_tlb1_11_reg & ~MPM_SYSHUB_SOC_TLB1_11_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_11_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_11_SET_SEG_SIZE(mpm_syshub_soc_tlb1_11_reg, seg_size) \
      mpm_syshub_soc_tlb1_11_reg = (mpm_syshub_soc_tlb1_11_reg & ~MPM_SYSHUB_SOC_TLB1_11_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_11_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_11_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_11_reg, seg_offset) \
      mpm_syshub_soc_tlb1_11_reg = (mpm_syshub_soc_tlb1_11_reg & ~MPM_SYSHUB_SOC_TLB1_11_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_11_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_11_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_11_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_11_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_11_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_11_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_11_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_11_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_11_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_11_t f;
} mpm_syshub_soc_tlb1_11_u;


/*
 * MPM_SYSHUB_SOC_TLB2_11 struct
 */

#define MPM_SYSHUB_SOC_TLB2_11_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_11_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_11_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_11_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_11_MASK \
      (MPM_SYSHUB_SOC_TLB2_11_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_11_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_11_GET_AWUSER(mpm_syshub_soc_tlb2_11) \
      ((mpm_syshub_soc_tlb2_11 & MPM_SYSHUB_SOC_TLB2_11_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_11_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_11_SET_AWUSER(mpm_syshub_soc_tlb2_11_reg, awuser) \
      mpm_syshub_soc_tlb2_11_reg = (mpm_syshub_soc_tlb2_11_reg & ~MPM_SYSHUB_SOC_TLB2_11_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_11_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_11_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_11_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_11_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_11_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_11_t f;
} mpm_syshub_soc_tlb2_11_u;


/*
 * MPM_SYSHUB_SOC_TLB3_11 struct
 */

#define MPM_SYSHUB_SOC_TLB3_11_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_11_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_11_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_11_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_11_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_11_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_11_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_11_MASK \
      (MPM_SYSHUB_SOC_TLB3_11_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_11_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_11_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_11_GET_ARUSER(mpm_syshub_soc_tlb3_11) \
      ((mpm_syshub_soc_tlb3_11 & MPM_SYSHUB_SOC_TLB3_11_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_11_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_11_GET_WUSER(mpm_syshub_soc_tlb3_11) \
      ((mpm_syshub_soc_tlb3_11 & MPM_SYSHUB_SOC_TLB3_11_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_11_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_11_SET_ARUSER(mpm_syshub_soc_tlb3_11_reg, aruser) \
      mpm_syshub_soc_tlb3_11_reg = (mpm_syshub_soc_tlb3_11_reg & ~MPM_SYSHUB_SOC_TLB3_11_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_11_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_11_SET_WUSER(mpm_syshub_soc_tlb3_11_reg, wuser) \
      mpm_syshub_soc_tlb3_11_reg = (mpm_syshub_soc_tlb3_11_reg & ~MPM_SYSHUB_SOC_TLB3_11_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_11_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_11_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_11_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_11_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_11_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_11_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_11_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_11_t f;
} mpm_syshub_soc_tlb3_11_u;


/*
 * MPM_SYSHUB_SOC_TLB0_12 struct
 */

#define MPM_SYSHUB_SOC_TLB0_12_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_12_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_12_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_12_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_12_MASK \
      (MPM_SYSHUB_SOC_TLB0_12_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_12_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_12_GET_SOC_ADDR(mpm_syshub_soc_tlb0_12) \
      ((mpm_syshub_soc_tlb0_12 & MPM_SYSHUB_SOC_TLB0_12_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_12_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_12_SET_SOC_ADDR(mpm_syshub_soc_tlb0_12_reg, soc_addr) \
      mpm_syshub_soc_tlb0_12_reg = (mpm_syshub_soc_tlb0_12_reg & ~MPM_SYSHUB_SOC_TLB0_12_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_12_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_12_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_12_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_12_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_12_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_12_t f;
} mpm_syshub_soc_tlb0_12_u;


/*
 * MPM_SYSHUB_SOC_TLB1_12 struct
 */

#define MPM_SYSHUB_SOC_TLB1_12_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_12_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_12_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_12_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_12_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_12_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_12_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_12_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_12_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_12_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_12_MASK \
      (MPM_SYSHUB_SOC_TLB1_12_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_12_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_12_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_12_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_12_GET_COHERENCE(mpm_syshub_soc_tlb1_12) \
      ((mpm_syshub_soc_tlb1_12 & MPM_SYSHUB_SOC_TLB1_12_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_12_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_12_GET_SEG_SIZE(mpm_syshub_soc_tlb1_12) \
      ((mpm_syshub_soc_tlb1_12 & MPM_SYSHUB_SOC_TLB1_12_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_12_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_12_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_12) \
      ((mpm_syshub_soc_tlb1_12 & MPM_SYSHUB_SOC_TLB1_12_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_12_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_12_SET_COHERENCE(mpm_syshub_soc_tlb1_12_reg, coherence) \
      mpm_syshub_soc_tlb1_12_reg = (mpm_syshub_soc_tlb1_12_reg & ~MPM_SYSHUB_SOC_TLB1_12_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_12_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_12_SET_SEG_SIZE(mpm_syshub_soc_tlb1_12_reg, seg_size) \
      mpm_syshub_soc_tlb1_12_reg = (mpm_syshub_soc_tlb1_12_reg & ~MPM_SYSHUB_SOC_TLB1_12_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_12_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_12_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_12_reg, seg_offset) \
      mpm_syshub_soc_tlb1_12_reg = (mpm_syshub_soc_tlb1_12_reg & ~MPM_SYSHUB_SOC_TLB1_12_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_12_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_12_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_12_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_12_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_12_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_12_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_12_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_12_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_12_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_12_t f;
} mpm_syshub_soc_tlb1_12_u;


/*
 * MPM_SYSHUB_SOC_TLB2_12 struct
 */

#define MPM_SYSHUB_SOC_TLB2_12_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_12_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_12_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_12_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_12_MASK \
      (MPM_SYSHUB_SOC_TLB2_12_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_12_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_12_GET_AWUSER(mpm_syshub_soc_tlb2_12) \
      ((mpm_syshub_soc_tlb2_12 & MPM_SYSHUB_SOC_TLB2_12_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_12_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_12_SET_AWUSER(mpm_syshub_soc_tlb2_12_reg, awuser) \
      mpm_syshub_soc_tlb2_12_reg = (mpm_syshub_soc_tlb2_12_reg & ~MPM_SYSHUB_SOC_TLB2_12_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_12_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_12_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_12_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_12_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_12_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_12_t f;
} mpm_syshub_soc_tlb2_12_u;


/*
 * MPM_SYSHUB_SOC_TLB3_12 struct
 */

#define MPM_SYSHUB_SOC_TLB3_12_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_12_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_12_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_12_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_12_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_12_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_12_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_12_MASK \
      (MPM_SYSHUB_SOC_TLB3_12_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_12_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_12_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_12_GET_ARUSER(mpm_syshub_soc_tlb3_12) \
      ((mpm_syshub_soc_tlb3_12 & MPM_SYSHUB_SOC_TLB3_12_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_12_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_12_GET_WUSER(mpm_syshub_soc_tlb3_12) \
      ((mpm_syshub_soc_tlb3_12 & MPM_SYSHUB_SOC_TLB3_12_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_12_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_12_SET_ARUSER(mpm_syshub_soc_tlb3_12_reg, aruser) \
      mpm_syshub_soc_tlb3_12_reg = (mpm_syshub_soc_tlb3_12_reg & ~MPM_SYSHUB_SOC_TLB3_12_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_12_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_12_SET_WUSER(mpm_syshub_soc_tlb3_12_reg, wuser) \
      mpm_syshub_soc_tlb3_12_reg = (mpm_syshub_soc_tlb3_12_reg & ~MPM_SYSHUB_SOC_TLB3_12_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_12_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_12_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_12_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_12_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_12_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_12_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_12_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_12_t f;
} mpm_syshub_soc_tlb3_12_u;


/*
 * MPM_SYSHUB_SOC_TLB0_13 struct
 */

#define MPM_SYSHUB_SOC_TLB0_13_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_13_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_13_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_13_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_13_MASK \
      (MPM_SYSHUB_SOC_TLB0_13_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_13_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_13_GET_SOC_ADDR(mpm_syshub_soc_tlb0_13) \
      ((mpm_syshub_soc_tlb0_13 & MPM_SYSHUB_SOC_TLB0_13_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_13_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_13_SET_SOC_ADDR(mpm_syshub_soc_tlb0_13_reg, soc_addr) \
      mpm_syshub_soc_tlb0_13_reg = (mpm_syshub_soc_tlb0_13_reg & ~MPM_SYSHUB_SOC_TLB0_13_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_13_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_13_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_13_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_13_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_13_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_13_t f;
} mpm_syshub_soc_tlb0_13_u;


/*
 * MPM_SYSHUB_SOC_TLB1_13 struct
 */

#define MPM_SYSHUB_SOC_TLB1_13_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_13_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_13_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_13_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_13_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_13_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_13_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_13_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_13_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_13_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_13_MASK \
      (MPM_SYSHUB_SOC_TLB1_13_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_13_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_13_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_13_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_13_GET_COHERENCE(mpm_syshub_soc_tlb1_13) \
      ((mpm_syshub_soc_tlb1_13 & MPM_SYSHUB_SOC_TLB1_13_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_13_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_13_GET_SEG_SIZE(mpm_syshub_soc_tlb1_13) \
      ((mpm_syshub_soc_tlb1_13 & MPM_SYSHUB_SOC_TLB1_13_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_13_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_13_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_13) \
      ((mpm_syshub_soc_tlb1_13 & MPM_SYSHUB_SOC_TLB1_13_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_13_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_13_SET_COHERENCE(mpm_syshub_soc_tlb1_13_reg, coherence) \
      mpm_syshub_soc_tlb1_13_reg = (mpm_syshub_soc_tlb1_13_reg & ~MPM_SYSHUB_SOC_TLB1_13_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_13_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_13_SET_SEG_SIZE(mpm_syshub_soc_tlb1_13_reg, seg_size) \
      mpm_syshub_soc_tlb1_13_reg = (mpm_syshub_soc_tlb1_13_reg & ~MPM_SYSHUB_SOC_TLB1_13_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_13_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_13_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_13_reg, seg_offset) \
      mpm_syshub_soc_tlb1_13_reg = (mpm_syshub_soc_tlb1_13_reg & ~MPM_SYSHUB_SOC_TLB1_13_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_13_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_13_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_13_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_13_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_13_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_13_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_13_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_13_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_13_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_13_t f;
} mpm_syshub_soc_tlb1_13_u;


/*
 * MPM_SYSHUB_SOC_TLB2_13 struct
 */

#define MPM_SYSHUB_SOC_TLB2_13_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_13_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_13_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_13_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_13_MASK \
      (MPM_SYSHUB_SOC_TLB2_13_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_13_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_13_GET_AWUSER(mpm_syshub_soc_tlb2_13) \
      ((mpm_syshub_soc_tlb2_13 & MPM_SYSHUB_SOC_TLB2_13_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_13_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_13_SET_AWUSER(mpm_syshub_soc_tlb2_13_reg, awuser) \
      mpm_syshub_soc_tlb2_13_reg = (mpm_syshub_soc_tlb2_13_reg & ~MPM_SYSHUB_SOC_TLB2_13_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_13_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_13_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_13_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_13_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_13_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_13_t f;
} mpm_syshub_soc_tlb2_13_u;


/*
 * MPM_SYSHUB_SOC_TLB3_13 struct
 */

#define MPM_SYSHUB_SOC_TLB3_13_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_13_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_13_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_13_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_13_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_13_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_13_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_13_MASK \
      (MPM_SYSHUB_SOC_TLB3_13_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_13_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_13_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_13_GET_ARUSER(mpm_syshub_soc_tlb3_13) \
      ((mpm_syshub_soc_tlb3_13 & MPM_SYSHUB_SOC_TLB3_13_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_13_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_13_GET_WUSER(mpm_syshub_soc_tlb3_13) \
      ((mpm_syshub_soc_tlb3_13 & MPM_SYSHUB_SOC_TLB3_13_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_13_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_13_SET_ARUSER(mpm_syshub_soc_tlb3_13_reg, aruser) \
      mpm_syshub_soc_tlb3_13_reg = (mpm_syshub_soc_tlb3_13_reg & ~MPM_SYSHUB_SOC_TLB3_13_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_13_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_13_SET_WUSER(mpm_syshub_soc_tlb3_13_reg, wuser) \
      mpm_syshub_soc_tlb3_13_reg = (mpm_syshub_soc_tlb3_13_reg & ~MPM_SYSHUB_SOC_TLB3_13_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_13_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_13_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_13_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_13_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_13_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_13_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_13_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_13_t f;
} mpm_syshub_soc_tlb3_13_u;


/*
 * MPM_SYSHUB_SOC_TLB0_14 struct
 */

#define MPM_SYSHUB_SOC_TLB0_14_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_14_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_14_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_14_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_14_MASK \
      (MPM_SYSHUB_SOC_TLB0_14_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_14_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_14_GET_SOC_ADDR(mpm_syshub_soc_tlb0_14) \
      ((mpm_syshub_soc_tlb0_14 & MPM_SYSHUB_SOC_TLB0_14_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_14_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_14_SET_SOC_ADDR(mpm_syshub_soc_tlb0_14_reg, soc_addr) \
      mpm_syshub_soc_tlb0_14_reg = (mpm_syshub_soc_tlb0_14_reg & ~MPM_SYSHUB_SOC_TLB0_14_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_14_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_14_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_14_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_14_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_14_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_14_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_14_t f;
} mpm_syshub_soc_tlb0_14_u;


/*
 * MPM_SYSHUB_SOC_TLB1_14 struct
 */

#define MPM_SYSHUB_SOC_TLB1_14_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_14_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_14_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_14_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_14_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_14_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_14_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_14_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_14_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_14_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_14_MASK \
      (MPM_SYSHUB_SOC_TLB1_14_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_14_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_14_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_14_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_14_GET_COHERENCE(mpm_syshub_soc_tlb1_14) \
      ((mpm_syshub_soc_tlb1_14 & MPM_SYSHUB_SOC_TLB1_14_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_14_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_14_GET_SEG_SIZE(mpm_syshub_soc_tlb1_14) \
      ((mpm_syshub_soc_tlb1_14 & MPM_SYSHUB_SOC_TLB1_14_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_14_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_14_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_14) \
      ((mpm_syshub_soc_tlb1_14 & MPM_SYSHUB_SOC_TLB1_14_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_14_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_14_SET_COHERENCE(mpm_syshub_soc_tlb1_14_reg, coherence) \
      mpm_syshub_soc_tlb1_14_reg = (mpm_syshub_soc_tlb1_14_reg & ~MPM_SYSHUB_SOC_TLB1_14_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_14_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_14_SET_SEG_SIZE(mpm_syshub_soc_tlb1_14_reg, seg_size) \
      mpm_syshub_soc_tlb1_14_reg = (mpm_syshub_soc_tlb1_14_reg & ~MPM_SYSHUB_SOC_TLB1_14_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_14_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_14_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_14_reg, seg_offset) \
      mpm_syshub_soc_tlb1_14_reg = (mpm_syshub_soc_tlb1_14_reg & ~MPM_SYSHUB_SOC_TLB1_14_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_14_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_14_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_14_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_14_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_14_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_14_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_14_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_14_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_14_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_14_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_14_t f;
} mpm_syshub_soc_tlb1_14_u;


/*
 * MPM_SYSHUB_SOC_TLB2_14 struct
 */

#define MPM_SYSHUB_SOC_TLB2_14_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_14_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_14_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_14_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_14_MASK \
      (MPM_SYSHUB_SOC_TLB2_14_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_14_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_14_GET_AWUSER(mpm_syshub_soc_tlb2_14) \
      ((mpm_syshub_soc_tlb2_14 & MPM_SYSHUB_SOC_TLB2_14_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_14_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_14_SET_AWUSER(mpm_syshub_soc_tlb2_14_reg, awuser) \
      mpm_syshub_soc_tlb2_14_reg = (mpm_syshub_soc_tlb2_14_reg & ~MPM_SYSHUB_SOC_TLB2_14_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_14_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_14_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_14_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_14_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_14_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_14_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_14_t f;
} mpm_syshub_soc_tlb2_14_u;


/*
 * MPM_SYSHUB_SOC_TLB3_14 struct
 */

#define MPM_SYSHUB_SOC_TLB3_14_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_14_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_14_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_14_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_14_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_14_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_14_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_14_MASK \
      (MPM_SYSHUB_SOC_TLB3_14_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_14_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_14_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_14_GET_ARUSER(mpm_syshub_soc_tlb3_14) \
      ((mpm_syshub_soc_tlb3_14 & MPM_SYSHUB_SOC_TLB3_14_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_14_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_14_GET_WUSER(mpm_syshub_soc_tlb3_14) \
      ((mpm_syshub_soc_tlb3_14 & MPM_SYSHUB_SOC_TLB3_14_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_14_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_14_SET_ARUSER(mpm_syshub_soc_tlb3_14_reg, aruser) \
      mpm_syshub_soc_tlb3_14_reg = (mpm_syshub_soc_tlb3_14_reg & ~MPM_SYSHUB_SOC_TLB3_14_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_14_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_14_SET_WUSER(mpm_syshub_soc_tlb3_14_reg, wuser) \
      mpm_syshub_soc_tlb3_14_reg = (mpm_syshub_soc_tlb3_14_reg & ~MPM_SYSHUB_SOC_TLB3_14_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_14_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_14_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_14_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_14_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_14_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_14_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_14_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_14_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_14_t f;
} mpm_syshub_soc_tlb3_14_u;


/*
 * MPM_SYSHUB_SOC_TLB0_15 struct
 */

#define MPM_SYSHUB_SOC_TLB0_15_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_15_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_15_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_15_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_15_MASK \
      (MPM_SYSHUB_SOC_TLB0_15_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_15_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_15_GET_SOC_ADDR(mpm_syshub_soc_tlb0_15) \
      ((mpm_syshub_soc_tlb0_15 & MPM_SYSHUB_SOC_TLB0_15_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_15_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_15_SET_SOC_ADDR(mpm_syshub_soc_tlb0_15_reg, soc_addr) \
      mpm_syshub_soc_tlb0_15_reg = (mpm_syshub_soc_tlb0_15_reg & ~MPM_SYSHUB_SOC_TLB0_15_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_15_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_15_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_15_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_15_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_15_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_15_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_15_t f;
} mpm_syshub_soc_tlb0_15_u;


/*
 * MPM_SYSHUB_SOC_TLB1_15 struct
 */

#define MPM_SYSHUB_SOC_TLB1_15_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_15_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_15_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_15_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_15_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_15_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_15_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_15_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_15_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_15_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_15_MASK \
      (MPM_SYSHUB_SOC_TLB1_15_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_15_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_15_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_15_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_15_GET_COHERENCE(mpm_syshub_soc_tlb1_15) \
      ((mpm_syshub_soc_tlb1_15 & MPM_SYSHUB_SOC_TLB1_15_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_15_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_15_GET_SEG_SIZE(mpm_syshub_soc_tlb1_15) \
      ((mpm_syshub_soc_tlb1_15 & MPM_SYSHUB_SOC_TLB1_15_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_15_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_15_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_15) \
      ((mpm_syshub_soc_tlb1_15 & MPM_SYSHUB_SOC_TLB1_15_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_15_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_15_SET_COHERENCE(mpm_syshub_soc_tlb1_15_reg, coherence) \
      mpm_syshub_soc_tlb1_15_reg = (mpm_syshub_soc_tlb1_15_reg & ~MPM_SYSHUB_SOC_TLB1_15_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_15_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_15_SET_SEG_SIZE(mpm_syshub_soc_tlb1_15_reg, seg_size) \
      mpm_syshub_soc_tlb1_15_reg = (mpm_syshub_soc_tlb1_15_reg & ~MPM_SYSHUB_SOC_TLB1_15_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_15_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_15_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_15_reg, seg_offset) \
      mpm_syshub_soc_tlb1_15_reg = (mpm_syshub_soc_tlb1_15_reg & ~MPM_SYSHUB_SOC_TLB1_15_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_15_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_15_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_15_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_15_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_15_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_15_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_15_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_15_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_15_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_15_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_15_t f;
} mpm_syshub_soc_tlb1_15_u;


/*
 * MPM_SYSHUB_SOC_TLB2_15 struct
 */

#define MPM_SYSHUB_SOC_TLB2_15_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_15_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_15_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_15_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_15_MASK \
      (MPM_SYSHUB_SOC_TLB2_15_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_15_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_15_GET_AWUSER(mpm_syshub_soc_tlb2_15) \
      ((mpm_syshub_soc_tlb2_15 & MPM_SYSHUB_SOC_TLB2_15_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_15_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_15_SET_AWUSER(mpm_syshub_soc_tlb2_15_reg, awuser) \
      mpm_syshub_soc_tlb2_15_reg = (mpm_syshub_soc_tlb2_15_reg & ~MPM_SYSHUB_SOC_TLB2_15_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_15_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_15_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_15_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_15_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_15_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_15_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_15_t f;
} mpm_syshub_soc_tlb2_15_u;


/*
 * MPM_SYSHUB_SOC_TLB3_15 struct
 */

#define MPM_SYSHUB_SOC_TLB3_15_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_15_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_15_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_15_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_15_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_15_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_15_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_15_MASK \
      (MPM_SYSHUB_SOC_TLB3_15_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_15_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_15_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_15_GET_ARUSER(mpm_syshub_soc_tlb3_15) \
      ((mpm_syshub_soc_tlb3_15 & MPM_SYSHUB_SOC_TLB3_15_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_15_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_15_GET_WUSER(mpm_syshub_soc_tlb3_15) \
      ((mpm_syshub_soc_tlb3_15 & MPM_SYSHUB_SOC_TLB3_15_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_15_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_15_SET_ARUSER(mpm_syshub_soc_tlb3_15_reg, aruser) \
      mpm_syshub_soc_tlb3_15_reg = (mpm_syshub_soc_tlb3_15_reg & ~MPM_SYSHUB_SOC_TLB3_15_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_15_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_15_SET_WUSER(mpm_syshub_soc_tlb3_15_reg, wuser) \
      mpm_syshub_soc_tlb3_15_reg = (mpm_syshub_soc_tlb3_15_reg & ~MPM_SYSHUB_SOC_TLB3_15_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_15_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_15_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_15_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_15_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_15_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_15_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_15_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_15_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_15_t f;
} mpm_syshub_soc_tlb3_15_u;


/*
 * MPM_SYSHUB_SOC_TLB0_16 struct
 */

#define MPM_SYSHUB_SOC_TLB0_16_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_16_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_16_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_16_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_16_MASK \
      (MPM_SYSHUB_SOC_TLB0_16_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_16_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_16_GET_SOC_ADDR(mpm_syshub_soc_tlb0_16) \
      ((mpm_syshub_soc_tlb0_16 & MPM_SYSHUB_SOC_TLB0_16_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_16_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_16_SET_SOC_ADDR(mpm_syshub_soc_tlb0_16_reg, soc_addr) \
      mpm_syshub_soc_tlb0_16_reg = (mpm_syshub_soc_tlb0_16_reg & ~MPM_SYSHUB_SOC_TLB0_16_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_16_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_16_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_16_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_16_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_16_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_16_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_16_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_16_t f;
} mpm_syshub_soc_tlb0_16_u;


/*
 * MPM_SYSHUB_SOC_TLB1_16 struct
 */

#define MPM_SYSHUB_SOC_TLB1_16_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_16_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_16_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_16_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_16_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_16_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_16_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_16_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_16_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_16_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_16_MASK \
      (MPM_SYSHUB_SOC_TLB1_16_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_16_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_16_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_16_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_16_GET_COHERENCE(mpm_syshub_soc_tlb1_16) \
      ((mpm_syshub_soc_tlb1_16 & MPM_SYSHUB_SOC_TLB1_16_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_16_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_16_GET_SEG_SIZE(mpm_syshub_soc_tlb1_16) \
      ((mpm_syshub_soc_tlb1_16 & MPM_SYSHUB_SOC_TLB1_16_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_16_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_16_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_16) \
      ((mpm_syshub_soc_tlb1_16 & MPM_SYSHUB_SOC_TLB1_16_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_16_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_16_SET_COHERENCE(mpm_syshub_soc_tlb1_16_reg, coherence) \
      mpm_syshub_soc_tlb1_16_reg = (mpm_syshub_soc_tlb1_16_reg & ~MPM_SYSHUB_SOC_TLB1_16_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_16_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_16_SET_SEG_SIZE(mpm_syshub_soc_tlb1_16_reg, seg_size) \
      mpm_syshub_soc_tlb1_16_reg = (mpm_syshub_soc_tlb1_16_reg & ~MPM_SYSHUB_SOC_TLB1_16_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_16_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_16_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_16_reg, seg_offset) \
      mpm_syshub_soc_tlb1_16_reg = (mpm_syshub_soc_tlb1_16_reg & ~MPM_SYSHUB_SOC_TLB1_16_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_16_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_16_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_16_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_16_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_16_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_16_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_16_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_16_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_16_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_16_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_16_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_16_t f;
} mpm_syshub_soc_tlb1_16_u;


/*
 * MPM_SYSHUB_SOC_TLB2_16 struct
 */

#define MPM_SYSHUB_SOC_TLB2_16_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_16_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_16_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_16_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_16_MASK \
      (MPM_SYSHUB_SOC_TLB2_16_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_16_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_16_GET_AWUSER(mpm_syshub_soc_tlb2_16) \
      ((mpm_syshub_soc_tlb2_16 & MPM_SYSHUB_SOC_TLB2_16_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_16_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_16_SET_AWUSER(mpm_syshub_soc_tlb2_16_reg, awuser) \
      mpm_syshub_soc_tlb2_16_reg = (mpm_syshub_soc_tlb2_16_reg & ~MPM_SYSHUB_SOC_TLB2_16_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_16_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_16_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_16_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_16_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_16_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_16_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_16_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_16_t f;
} mpm_syshub_soc_tlb2_16_u;


/*
 * MPM_SYSHUB_SOC_TLB3_16 struct
 */

#define MPM_SYSHUB_SOC_TLB3_16_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_16_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_16_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_16_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_16_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_16_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_16_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_16_MASK \
      (MPM_SYSHUB_SOC_TLB3_16_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_16_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_16_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_16_GET_ARUSER(mpm_syshub_soc_tlb3_16) \
      ((mpm_syshub_soc_tlb3_16 & MPM_SYSHUB_SOC_TLB3_16_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_16_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_16_GET_WUSER(mpm_syshub_soc_tlb3_16) \
      ((mpm_syshub_soc_tlb3_16 & MPM_SYSHUB_SOC_TLB3_16_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_16_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_16_SET_ARUSER(mpm_syshub_soc_tlb3_16_reg, aruser) \
      mpm_syshub_soc_tlb3_16_reg = (mpm_syshub_soc_tlb3_16_reg & ~MPM_SYSHUB_SOC_TLB3_16_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_16_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_16_SET_WUSER(mpm_syshub_soc_tlb3_16_reg, wuser) \
      mpm_syshub_soc_tlb3_16_reg = (mpm_syshub_soc_tlb3_16_reg & ~MPM_SYSHUB_SOC_TLB3_16_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_16_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_16_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_16_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_16_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_16_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_16_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_16_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_16_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_16_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_16_t f;
} mpm_syshub_soc_tlb3_16_u;


/*
 * MPM_SYSHUB_SOC_TLB0_17 struct
 */

#define MPM_SYSHUB_SOC_TLB0_17_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_17_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_17_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_17_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_17_MASK \
      (MPM_SYSHUB_SOC_TLB0_17_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_17_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_17_GET_SOC_ADDR(mpm_syshub_soc_tlb0_17) \
      ((mpm_syshub_soc_tlb0_17 & MPM_SYSHUB_SOC_TLB0_17_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_17_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_17_SET_SOC_ADDR(mpm_syshub_soc_tlb0_17_reg, soc_addr) \
      mpm_syshub_soc_tlb0_17_reg = (mpm_syshub_soc_tlb0_17_reg & ~MPM_SYSHUB_SOC_TLB0_17_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_17_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_17_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_17_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_17_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_17_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_17_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_17_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_17_t f;
} mpm_syshub_soc_tlb0_17_u;


/*
 * MPM_SYSHUB_SOC_TLB1_17 struct
 */

#define MPM_SYSHUB_SOC_TLB1_17_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_17_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_17_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_17_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_17_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_17_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_17_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_17_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_17_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_17_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_17_MASK \
      (MPM_SYSHUB_SOC_TLB1_17_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_17_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_17_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_17_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_17_GET_COHERENCE(mpm_syshub_soc_tlb1_17) \
      ((mpm_syshub_soc_tlb1_17 & MPM_SYSHUB_SOC_TLB1_17_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_17_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_17_GET_SEG_SIZE(mpm_syshub_soc_tlb1_17) \
      ((mpm_syshub_soc_tlb1_17 & MPM_SYSHUB_SOC_TLB1_17_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_17_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_17_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_17) \
      ((mpm_syshub_soc_tlb1_17 & MPM_SYSHUB_SOC_TLB1_17_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_17_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_17_SET_COHERENCE(mpm_syshub_soc_tlb1_17_reg, coherence) \
      mpm_syshub_soc_tlb1_17_reg = (mpm_syshub_soc_tlb1_17_reg & ~MPM_SYSHUB_SOC_TLB1_17_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_17_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_17_SET_SEG_SIZE(mpm_syshub_soc_tlb1_17_reg, seg_size) \
      mpm_syshub_soc_tlb1_17_reg = (mpm_syshub_soc_tlb1_17_reg & ~MPM_SYSHUB_SOC_TLB1_17_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_17_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_17_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_17_reg, seg_offset) \
      mpm_syshub_soc_tlb1_17_reg = (mpm_syshub_soc_tlb1_17_reg & ~MPM_SYSHUB_SOC_TLB1_17_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_17_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_17_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_17_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_17_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_17_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_17_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_17_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_17_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_17_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_17_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_17_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_17_t f;
} mpm_syshub_soc_tlb1_17_u;


/*
 * MPM_SYSHUB_SOC_TLB2_17 struct
 */

#define MPM_SYSHUB_SOC_TLB2_17_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_17_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_17_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_17_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_17_MASK \
      (MPM_SYSHUB_SOC_TLB2_17_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_17_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_17_GET_AWUSER(mpm_syshub_soc_tlb2_17) \
      ((mpm_syshub_soc_tlb2_17 & MPM_SYSHUB_SOC_TLB2_17_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_17_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_17_SET_AWUSER(mpm_syshub_soc_tlb2_17_reg, awuser) \
      mpm_syshub_soc_tlb2_17_reg = (mpm_syshub_soc_tlb2_17_reg & ~MPM_SYSHUB_SOC_TLB2_17_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_17_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_17_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_17_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_17_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_17_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_17_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_17_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_17_t f;
} mpm_syshub_soc_tlb2_17_u;


/*
 * MPM_SYSHUB_SOC_TLB3_17 struct
 */

#define MPM_SYSHUB_SOC_TLB3_17_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_17_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_17_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_17_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_17_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_17_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_17_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_17_MASK \
      (MPM_SYSHUB_SOC_TLB3_17_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_17_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_17_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_17_GET_ARUSER(mpm_syshub_soc_tlb3_17) \
      ((mpm_syshub_soc_tlb3_17 & MPM_SYSHUB_SOC_TLB3_17_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_17_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_17_GET_WUSER(mpm_syshub_soc_tlb3_17) \
      ((mpm_syshub_soc_tlb3_17 & MPM_SYSHUB_SOC_TLB3_17_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_17_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_17_SET_ARUSER(mpm_syshub_soc_tlb3_17_reg, aruser) \
      mpm_syshub_soc_tlb3_17_reg = (mpm_syshub_soc_tlb3_17_reg & ~MPM_SYSHUB_SOC_TLB3_17_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_17_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_17_SET_WUSER(mpm_syshub_soc_tlb3_17_reg, wuser) \
      mpm_syshub_soc_tlb3_17_reg = (mpm_syshub_soc_tlb3_17_reg & ~MPM_SYSHUB_SOC_TLB3_17_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_17_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_17_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_17_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_17_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_17_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_17_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_17_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_17_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_17_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_17_t f;
} mpm_syshub_soc_tlb3_17_u;


/*
 * MPM_SYSHUB_SOC_TLB0_18 struct
 */

#define MPM_SYSHUB_SOC_TLB0_18_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_18_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_18_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_18_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_18_MASK \
      (MPM_SYSHUB_SOC_TLB0_18_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_18_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_18_GET_SOC_ADDR(mpm_syshub_soc_tlb0_18) \
      ((mpm_syshub_soc_tlb0_18 & MPM_SYSHUB_SOC_TLB0_18_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_18_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_18_SET_SOC_ADDR(mpm_syshub_soc_tlb0_18_reg, soc_addr) \
      mpm_syshub_soc_tlb0_18_reg = (mpm_syshub_soc_tlb0_18_reg & ~MPM_SYSHUB_SOC_TLB0_18_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_18_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_18_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_18_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_18_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_18_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_18_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_18_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_18_t f;
} mpm_syshub_soc_tlb0_18_u;


/*
 * MPM_SYSHUB_SOC_TLB1_18 struct
 */

#define MPM_SYSHUB_SOC_TLB1_18_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_18_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_18_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_18_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_18_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_18_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_18_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_18_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_18_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_18_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_18_MASK \
      (MPM_SYSHUB_SOC_TLB1_18_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_18_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_18_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_18_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_18_GET_COHERENCE(mpm_syshub_soc_tlb1_18) \
      ((mpm_syshub_soc_tlb1_18 & MPM_SYSHUB_SOC_TLB1_18_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_18_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_18_GET_SEG_SIZE(mpm_syshub_soc_tlb1_18) \
      ((mpm_syshub_soc_tlb1_18 & MPM_SYSHUB_SOC_TLB1_18_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_18_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_18_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_18) \
      ((mpm_syshub_soc_tlb1_18 & MPM_SYSHUB_SOC_TLB1_18_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_18_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_18_SET_COHERENCE(mpm_syshub_soc_tlb1_18_reg, coherence) \
      mpm_syshub_soc_tlb1_18_reg = (mpm_syshub_soc_tlb1_18_reg & ~MPM_SYSHUB_SOC_TLB1_18_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_18_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_18_SET_SEG_SIZE(mpm_syshub_soc_tlb1_18_reg, seg_size) \
      mpm_syshub_soc_tlb1_18_reg = (mpm_syshub_soc_tlb1_18_reg & ~MPM_SYSHUB_SOC_TLB1_18_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_18_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_18_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_18_reg, seg_offset) \
      mpm_syshub_soc_tlb1_18_reg = (mpm_syshub_soc_tlb1_18_reg & ~MPM_SYSHUB_SOC_TLB1_18_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_18_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_18_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_18_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_18_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_18_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_18_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_18_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_18_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_18_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_18_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_18_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_18_t f;
} mpm_syshub_soc_tlb1_18_u;


/*
 * MPM_SYSHUB_SOC_TLB2_18 struct
 */

#define MPM_SYSHUB_SOC_TLB2_18_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_18_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_18_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_18_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_18_MASK \
      (MPM_SYSHUB_SOC_TLB2_18_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_18_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_18_GET_AWUSER(mpm_syshub_soc_tlb2_18) \
      ((mpm_syshub_soc_tlb2_18 & MPM_SYSHUB_SOC_TLB2_18_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_18_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_18_SET_AWUSER(mpm_syshub_soc_tlb2_18_reg, awuser) \
      mpm_syshub_soc_tlb2_18_reg = (mpm_syshub_soc_tlb2_18_reg & ~MPM_SYSHUB_SOC_TLB2_18_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_18_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_18_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_18_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_18_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_18_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_18_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_18_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_18_t f;
} mpm_syshub_soc_tlb2_18_u;


/*
 * MPM_SYSHUB_SOC_TLB3_18 struct
 */

#define MPM_SYSHUB_SOC_TLB3_18_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_18_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_18_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_18_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_18_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_18_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_18_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_18_MASK \
      (MPM_SYSHUB_SOC_TLB3_18_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_18_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_18_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_18_GET_ARUSER(mpm_syshub_soc_tlb3_18) \
      ((mpm_syshub_soc_tlb3_18 & MPM_SYSHUB_SOC_TLB3_18_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_18_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_18_GET_WUSER(mpm_syshub_soc_tlb3_18) \
      ((mpm_syshub_soc_tlb3_18 & MPM_SYSHUB_SOC_TLB3_18_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_18_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_18_SET_ARUSER(mpm_syshub_soc_tlb3_18_reg, aruser) \
      mpm_syshub_soc_tlb3_18_reg = (mpm_syshub_soc_tlb3_18_reg & ~MPM_SYSHUB_SOC_TLB3_18_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_18_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_18_SET_WUSER(mpm_syshub_soc_tlb3_18_reg, wuser) \
      mpm_syshub_soc_tlb3_18_reg = (mpm_syshub_soc_tlb3_18_reg & ~MPM_SYSHUB_SOC_TLB3_18_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_18_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_18_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_18_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_18_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_18_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_18_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_18_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_18_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_18_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_18_t f;
} mpm_syshub_soc_tlb3_18_u;


/*
 * MPM_SYSHUB_SOC_TLB0_19 struct
 */

#define MPM_SYSHUB_SOC_TLB0_19_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_19_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_19_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_19_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_19_MASK \
      (MPM_SYSHUB_SOC_TLB0_19_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_19_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_19_GET_SOC_ADDR(mpm_syshub_soc_tlb0_19) \
      ((mpm_syshub_soc_tlb0_19 & MPM_SYSHUB_SOC_TLB0_19_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_19_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_19_SET_SOC_ADDR(mpm_syshub_soc_tlb0_19_reg, soc_addr) \
      mpm_syshub_soc_tlb0_19_reg = (mpm_syshub_soc_tlb0_19_reg & ~MPM_SYSHUB_SOC_TLB0_19_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_19_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_19_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_19_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_19_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_19_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_19_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_19_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_19_t f;
} mpm_syshub_soc_tlb0_19_u;


/*
 * MPM_SYSHUB_SOC_TLB1_19 struct
 */

#define MPM_SYSHUB_SOC_TLB1_19_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_19_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_19_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_19_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_19_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_19_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_19_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_19_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_19_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_19_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_19_MASK \
      (MPM_SYSHUB_SOC_TLB1_19_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_19_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_19_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_19_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_19_GET_COHERENCE(mpm_syshub_soc_tlb1_19) \
      ((mpm_syshub_soc_tlb1_19 & MPM_SYSHUB_SOC_TLB1_19_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_19_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_19_GET_SEG_SIZE(mpm_syshub_soc_tlb1_19) \
      ((mpm_syshub_soc_tlb1_19 & MPM_SYSHUB_SOC_TLB1_19_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_19_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_19_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_19) \
      ((mpm_syshub_soc_tlb1_19 & MPM_SYSHUB_SOC_TLB1_19_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_19_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_19_SET_COHERENCE(mpm_syshub_soc_tlb1_19_reg, coherence) \
      mpm_syshub_soc_tlb1_19_reg = (mpm_syshub_soc_tlb1_19_reg & ~MPM_SYSHUB_SOC_TLB1_19_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_19_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_19_SET_SEG_SIZE(mpm_syshub_soc_tlb1_19_reg, seg_size) \
      mpm_syshub_soc_tlb1_19_reg = (mpm_syshub_soc_tlb1_19_reg & ~MPM_SYSHUB_SOC_TLB1_19_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_19_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_19_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_19_reg, seg_offset) \
      mpm_syshub_soc_tlb1_19_reg = (mpm_syshub_soc_tlb1_19_reg & ~MPM_SYSHUB_SOC_TLB1_19_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_19_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_19_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_19_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_19_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_19_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_19_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_19_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_19_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_19_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_19_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_19_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_19_t f;
} mpm_syshub_soc_tlb1_19_u;


/*
 * MPM_SYSHUB_SOC_TLB2_19 struct
 */

#define MPM_SYSHUB_SOC_TLB2_19_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_19_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_19_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_19_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_19_MASK \
      (MPM_SYSHUB_SOC_TLB2_19_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_19_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_19_GET_AWUSER(mpm_syshub_soc_tlb2_19) \
      ((mpm_syshub_soc_tlb2_19 & MPM_SYSHUB_SOC_TLB2_19_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_19_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_19_SET_AWUSER(mpm_syshub_soc_tlb2_19_reg, awuser) \
      mpm_syshub_soc_tlb2_19_reg = (mpm_syshub_soc_tlb2_19_reg & ~MPM_SYSHUB_SOC_TLB2_19_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_19_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_19_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_19_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_19_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_19_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_19_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_19_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_19_t f;
} mpm_syshub_soc_tlb2_19_u;


/*
 * MPM_SYSHUB_SOC_TLB3_19 struct
 */

#define MPM_SYSHUB_SOC_TLB3_19_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_19_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_19_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_19_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_19_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_19_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_19_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_19_MASK \
      (MPM_SYSHUB_SOC_TLB3_19_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_19_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_19_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_19_GET_ARUSER(mpm_syshub_soc_tlb3_19) \
      ((mpm_syshub_soc_tlb3_19 & MPM_SYSHUB_SOC_TLB3_19_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_19_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_19_GET_WUSER(mpm_syshub_soc_tlb3_19) \
      ((mpm_syshub_soc_tlb3_19 & MPM_SYSHUB_SOC_TLB3_19_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_19_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_19_SET_ARUSER(mpm_syshub_soc_tlb3_19_reg, aruser) \
      mpm_syshub_soc_tlb3_19_reg = (mpm_syshub_soc_tlb3_19_reg & ~MPM_SYSHUB_SOC_TLB3_19_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_19_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_19_SET_WUSER(mpm_syshub_soc_tlb3_19_reg, wuser) \
      mpm_syshub_soc_tlb3_19_reg = (mpm_syshub_soc_tlb3_19_reg & ~MPM_SYSHUB_SOC_TLB3_19_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_19_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_19_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_19_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_19_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_19_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_19_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_19_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_19_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_19_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_19_t f;
} mpm_syshub_soc_tlb3_19_u;


/*
 * MPM_SYSHUB_SOC_TLB0_20 struct
 */

#define MPM_SYSHUB_SOC_TLB0_20_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_20_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_20_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_20_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_20_MASK \
      (MPM_SYSHUB_SOC_TLB0_20_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_20_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_20_GET_SOC_ADDR(mpm_syshub_soc_tlb0_20) \
      ((mpm_syshub_soc_tlb0_20 & MPM_SYSHUB_SOC_TLB0_20_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_20_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_20_SET_SOC_ADDR(mpm_syshub_soc_tlb0_20_reg, soc_addr) \
      mpm_syshub_soc_tlb0_20_reg = (mpm_syshub_soc_tlb0_20_reg & ~MPM_SYSHUB_SOC_TLB0_20_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_20_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_20_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_20_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_20_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_20_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_20_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_20_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_20_t f;
} mpm_syshub_soc_tlb0_20_u;


/*
 * MPM_SYSHUB_SOC_TLB1_20 struct
 */

#define MPM_SYSHUB_SOC_TLB1_20_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_20_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_20_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_20_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_20_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_20_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_20_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_20_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_20_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_20_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_20_MASK \
      (MPM_SYSHUB_SOC_TLB1_20_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_20_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_20_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_20_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_20_GET_COHERENCE(mpm_syshub_soc_tlb1_20) \
      ((mpm_syshub_soc_tlb1_20 & MPM_SYSHUB_SOC_TLB1_20_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_20_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_20_GET_SEG_SIZE(mpm_syshub_soc_tlb1_20) \
      ((mpm_syshub_soc_tlb1_20 & MPM_SYSHUB_SOC_TLB1_20_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_20_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_20_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_20) \
      ((mpm_syshub_soc_tlb1_20 & MPM_SYSHUB_SOC_TLB1_20_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_20_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_20_SET_COHERENCE(mpm_syshub_soc_tlb1_20_reg, coherence) \
      mpm_syshub_soc_tlb1_20_reg = (mpm_syshub_soc_tlb1_20_reg & ~MPM_SYSHUB_SOC_TLB1_20_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_20_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_20_SET_SEG_SIZE(mpm_syshub_soc_tlb1_20_reg, seg_size) \
      mpm_syshub_soc_tlb1_20_reg = (mpm_syshub_soc_tlb1_20_reg & ~MPM_SYSHUB_SOC_TLB1_20_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_20_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_20_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_20_reg, seg_offset) \
      mpm_syshub_soc_tlb1_20_reg = (mpm_syshub_soc_tlb1_20_reg & ~MPM_SYSHUB_SOC_TLB1_20_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_20_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_20_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_20_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_20_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_20_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_20_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_20_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_20_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_20_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_20_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_20_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_20_t f;
} mpm_syshub_soc_tlb1_20_u;


/*
 * MPM_SYSHUB_SOC_TLB2_20 struct
 */

#define MPM_SYSHUB_SOC_TLB2_20_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_20_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_20_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_20_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_20_MASK \
      (MPM_SYSHUB_SOC_TLB2_20_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_20_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_20_GET_AWUSER(mpm_syshub_soc_tlb2_20) \
      ((mpm_syshub_soc_tlb2_20 & MPM_SYSHUB_SOC_TLB2_20_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_20_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_20_SET_AWUSER(mpm_syshub_soc_tlb2_20_reg, awuser) \
      mpm_syshub_soc_tlb2_20_reg = (mpm_syshub_soc_tlb2_20_reg & ~MPM_SYSHUB_SOC_TLB2_20_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_20_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_20_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_20_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_20_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_20_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_20_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_20_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_20_t f;
} mpm_syshub_soc_tlb2_20_u;


/*
 * MPM_SYSHUB_SOC_TLB3_20 struct
 */

#define MPM_SYSHUB_SOC_TLB3_20_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_20_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_20_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_20_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_20_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_20_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_20_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_20_MASK \
      (MPM_SYSHUB_SOC_TLB3_20_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_20_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_20_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_20_GET_ARUSER(mpm_syshub_soc_tlb3_20) \
      ((mpm_syshub_soc_tlb3_20 & MPM_SYSHUB_SOC_TLB3_20_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_20_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_20_GET_WUSER(mpm_syshub_soc_tlb3_20) \
      ((mpm_syshub_soc_tlb3_20 & MPM_SYSHUB_SOC_TLB3_20_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_20_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_20_SET_ARUSER(mpm_syshub_soc_tlb3_20_reg, aruser) \
      mpm_syshub_soc_tlb3_20_reg = (mpm_syshub_soc_tlb3_20_reg & ~MPM_SYSHUB_SOC_TLB3_20_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_20_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_20_SET_WUSER(mpm_syshub_soc_tlb3_20_reg, wuser) \
      mpm_syshub_soc_tlb3_20_reg = (mpm_syshub_soc_tlb3_20_reg & ~MPM_SYSHUB_SOC_TLB3_20_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_20_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_20_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_20_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_20_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_20_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_20_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_20_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_20_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_20_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_20_t f;
} mpm_syshub_soc_tlb3_20_u;


/*
 * MPM_SYSHUB_SOC_TLB0_21 struct
 */

#define MPM_SYSHUB_SOC_TLB0_21_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_21_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_21_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_21_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_21_MASK \
      (MPM_SYSHUB_SOC_TLB0_21_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_21_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_21_GET_SOC_ADDR(mpm_syshub_soc_tlb0_21) \
      ((mpm_syshub_soc_tlb0_21 & MPM_SYSHUB_SOC_TLB0_21_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_21_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_21_SET_SOC_ADDR(mpm_syshub_soc_tlb0_21_reg, soc_addr) \
      mpm_syshub_soc_tlb0_21_reg = (mpm_syshub_soc_tlb0_21_reg & ~MPM_SYSHUB_SOC_TLB0_21_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_21_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_21_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_21_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_21_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_21_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_21_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_21_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_21_t f;
} mpm_syshub_soc_tlb0_21_u;


/*
 * MPM_SYSHUB_SOC_TLB1_21 struct
 */

#define MPM_SYSHUB_SOC_TLB1_21_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_21_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_21_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_21_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_21_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_21_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_21_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_21_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_21_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_21_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_21_MASK \
      (MPM_SYSHUB_SOC_TLB1_21_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_21_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_21_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_21_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_21_GET_COHERENCE(mpm_syshub_soc_tlb1_21) \
      ((mpm_syshub_soc_tlb1_21 & MPM_SYSHUB_SOC_TLB1_21_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_21_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_21_GET_SEG_SIZE(mpm_syshub_soc_tlb1_21) \
      ((mpm_syshub_soc_tlb1_21 & MPM_SYSHUB_SOC_TLB1_21_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_21_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_21_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_21) \
      ((mpm_syshub_soc_tlb1_21 & MPM_SYSHUB_SOC_TLB1_21_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_21_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_21_SET_COHERENCE(mpm_syshub_soc_tlb1_21_reg, coherence) \
      mpm_syshub_soc_tlb1_21_reg = (mpm_syshub_soc_tlb1_21_reg & ~MPM_SYSHUB_SOC_TLB1_21_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_21_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_21_SET_SEG_SIZE(mpm_syshub_soc_tlb1_21_reg, seg_size) \
      mpm_syshub_soc_tlb1_21_reg = (mpm_syshub_soc_tlb1_21_reg & ~MPM_SYSHUB_SOC_TLB1_21_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_21_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_21_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_21_reg, seg_offset) \
      mpm_syshub_soc_tlb1_21_reg = (mpm_syshub_soc_tlb1_21_reg & ~MPM_SYSHUB_SOC_TLB1_21_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_21_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_21_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_21_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_21_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_21_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_21_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_21_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_21_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_21_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_21_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_21_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_21_t f;
} mpm_syshub_soc_tlb1_21_u;


/*
 * MPM_SYSHUB_SOC_TLB2_21 struct
 */

#define MPM_SYSHUB_SOC_TLB2_21_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_21_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_21_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_21_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_21_MASK \
      (MPM_SYSHUB_SOC_TLB2_21_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_21_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_21_GET_AWUSER(mpm_syshub_soc_tlb2_21) \
      ((mpm_syshub_soc_tlb2_21 & MPM_SYSHUB_SOC_TLB2_21_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_21_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_21_SET_AWUSER(mpm_syshub_soc_tlb2_21_reg, awuser) \
      mpm_syshub_soc_tlb2_21_reg = (mpm_syshub_soc_tlb2_21_reg & ~MPM_SYSHUB_SOC_TLB2_21_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_21_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_21_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_21_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_21_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_21_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_21_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_21_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_21_t f;
} mpm_syshub_soc_tlb2_21_u;


/*
 * MPM_SYSHUB_SOC_TLB3_21 struct
 */

#define MPM_SYSHUB_SOC_TLB3_21_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_21_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_21_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_21_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_21_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_21_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_21_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_21_MASK \
      (MPM_SYSHUB_SOC_TLB3_21_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_21_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_21_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_21_GET_ARUSER(mpm_syshub_soc_tlb3_21) \
      ((mpm_syshub_soc_tlb3_21 & MPM_SYSHUB_SOC_TLB3_21_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_21_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_21_GET_WUSER(mpm_syshub_soc_tlb3_21) \
      ((mpm_syshub_soc_tlb3_21 & MPM_SYSHUB_SOC_TLB3_21_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_21_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_21_SET_ARUSER(mpm_syshub_soc_tlb3_21_reg, aruser) \
      mpm_syshub_soc_tlb3_21_reg = (mpm_syshub_soc_tlb3_21_reg & ~MPM_SYSHUB_SOC_TLB3_21_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_21_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_21_SET_WUSER(mpm_syshub_soc_tlb3_21_reg, wuser) \
      mpm_syshub_soc_tlb3_21_reg = (mpm_syshub_soc_tlb3_21_reg & ~MPM_SYSHUB_SOC_TLB3_21_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_21_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_21_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_21_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_21_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_21_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_21_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_21_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_21_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_21_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_21_t f;
} mpm_syshub_soc_tlb3_21_u;


/*
 * MPM_SYSHUB_SOC_TLB0_22 struct
 */

#define MPM_SYSHUB_SOC_TLB0_22_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_22_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_22_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_22_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_22_MASK \
      (MPM_SYSHUB_SOC_TLB0_22_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_22_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_22_GET_SOC_ADDR(mpm_syshub_soc_tlb0_22) \
      ((mpm_syshub_soc_tlb0_22 & MPM_SYSHUB_SOC_TLB0_22_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_22_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_22_SET_SOC_ADDR(mpm_syshub_soc_tlb0_22_reg, soc_addr) \
      mpm_syshub_soc_tlb0_22_reg = (mpm_syshub_soc_tlb0_22_reg & ~MPM_SYSHUB_SOC_TLB0_22_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_22_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_22_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_22_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_22_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_22_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_22_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_22_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_22_t f;
} mpm_syshub_soc_tlb0_22_u;


/*
 * MPM_SYSHUB_SOC_TLB1_22 struct
 */

#define MPM_SYSHUB_SOC_TLB1_22_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_22_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_22_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_22_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_22_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_22_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_22_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_22_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_22_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_22_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_22_MASK \
      (MPM_SYSHUB_SOC_TLB1_22_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_22_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_22_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_22_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_22_GET_COHERENCE(mpm_syshub_soc_tlb1_22) \
      ((mpm_syshub_soc_tlb1_22 & MPM_SYSHUB_SOC_TLB1_22_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_22_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_22_GET_SEG_SIZE(mpm_syshub_soc_tlb1_22) \
      ((mpm_syshub_soc_tlb1_22 & MPM_SYSHUB_SOC_TLB1_22_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_22_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_22_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_22) \
      ((mpm_syshub_soc_tlb1_22 & MPM_SYSHUB_SOC_TLB1_22_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_22_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_22_SET_COHERENCE(mpm_syshub_soc_tlb1_22_reg, coherence) \
      mpm_syshub_soc_tlb1_22_reg = (mpm_syshub_soc_tlb1_22_reg & ~MPM_SYSHUB_SOC_TLB1_22_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_22_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_22_SET_SEG_SIZE(mpm_syshub_soc_tlb1_22_reg, seg_size) \
      mpm_syshub_soc_tlb1_22_reg = (mpm_syshub_soc_tlb1_22_reg & ~MPM_SYSHUB_SOC_TLB1_22_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_22_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_22_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_22_reg, seg_offset) \
      mpm_syshub_soc_tlb1_22_reg = (mpm_syshub_soc_tlb1_22_reg & ~MPM_SYSHUB_SOC_TLB1_22_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_22_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_22_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_22_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_22_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_22_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_22_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_22_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_22_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_22_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_22_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_22_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_22_t f;
} mpm_syshub_soc_tlb1_22_u;


/*
 * MPM_SYSHUB_SOC_TLB2_22 struct
 */

#define MPM_SYSHUB_SOC_TLB2_22_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_22_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_22_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_22_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_22_MASK \
      (MPM_SYSHUB_SOC_TLB2_22_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_22_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_22_GET_AWUSER(mpm_syshub_soc_tlb2_22) \
      ((mpm_syshub_soc_tlb2_22 & MPM_SYSHUB_SOC_TLB2_22_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_22_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_22_SET_AWUSER(mpm_syshub_soc_tlb2_22_reg, awuser) \
      mpm_syshub_soc_tlb2_22_reg = (mpm_syshub_soc_tlb2_22_reg & ~MPM_SYSHUB_SOC_TLB2_22_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_22_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_22_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_22_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_22_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_22_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_22_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_22_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_22_t f;
} mpm_syshub_soc_tlb2_22_u;


/*
 * MPM_SYSHUB_SOC_TLB3_22 struct
 */

#define MPM_SYSHUB_SOC_TLB3_22_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_22_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_22_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_22_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_22_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_22_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_22_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_22_MASK \
      (MPM_SYSHUB_SOC_TLB3_22_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_22_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_22_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_22_GET_ARUSER(mpm_syshub_soc_tlb3_22) \
      ((mpm_syshub_soc_tlb3_22 & MPM_SYSHUB_SOC_TLB3_22_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_22_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_22_GET_WUSER(mpm_syshub_soc_tlb3_22) \
      ((mpm_syshub_soc_tlb3_22 & MPM_SYSHUB_SOC_TLB3_22_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_22_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_22_SET_ARUSER(mpm_syshub_soc_tlb3_22_reg, aruser) \
      mpm_syshub_soc_tlb3_22_reg = (mpm_syshub_soc_tlb3_22_reg & ~MPM_SYSHUB_SOC_TLB3_22_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_22_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_22_SET_WUSER(mpm_syshub_soc_tlb3_22_reg, wuser) \
      mpm_syshub_soc_tlb3_22_reg = (mpm_syshub_soc_tlb3_22_reg & ~MPM_SYSHUB_SOC_TLB3_22_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_22_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_22_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_22_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_22_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_22_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_22_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_22_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_22_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_22_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_22_t f;
} mpm_syshub_soc_tlb3_22_u;


/*
 * MPM_SYSHUB_SOC_TLB0_23 struct
 */

#define MPM_SYSHUB_SOC_TLB0_23_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_23_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_23_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_23_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_23_MASK \
      (MPM_SYSHUB_SOC_TLB0_23_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_23_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_23_GET_SOC_ADDR(mpm_syshub_soc_tlb0_23) \
      ((mpm_syshub_soc_tlb0_23 & MPM_SYSHUB_SOC_TLB0_23_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_23_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_23_SET_SOC_ADDR(mpm_syshub_soc_tlb0_23_reg, soc_addr) \
      mpm_syshub_soc_tlb0_23_reg = (mpm_syshub_soc_tlb0_23_reg & ~MPM_SYSHUB_SOC_TLB0_23_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_23_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_23_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_23_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_23_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_23_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_23_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_23_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_23_t f;
} mpm_syshub_soc_tlb0_23_u;


/*
 * MPM_SYSHUB_SOC_TLB1_23 struct
 */

#define MPM_SYSHUB_SOC_TLB1_23_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_23_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_23_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_23_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_23_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_23_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_23_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_23_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_23_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_23_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_23_MASK \
      (MPM_SYSHUB_SOC_TLB1_23_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_23_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_23_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_23_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_23_GET_COHERENCE(mpm_syshub_soc_tlb1_23) \
      ((mpm_syshub_soc_tlb1_23 & MPM_SYSHUB_SOC_TLB1_23_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_23_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_23_GET_SEG_SIZE(mpm_syshub_soc_tlb1_23) \
      ((mpm_syshub_soc_tlb1_23 & MPM_SYSHUB_SOC_TLB1_23_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_23_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_23_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_23) \
      ((mpm_syshub_soc_tlb1_23 & MPM_SYSHUB_SOC_TLB1_23_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_23_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_23_SET_COHERENCE(mpm_syshub_soc_tlb1_23_reg, coherence) \
      mpm_syshub_soc_tlb1_23_reg = (mpm_syshub_soc_tlb1_23_reg & ~MPM_SYSHUB_SOC_TLB1_23_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_23_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_23_SET_SEG_SIZE(mpm_syshub_soc_tlb1_23_reg, seg_size) \
      mpm_syshub_soc_tlb1_23_reg = (mpm_syshub_soc_tlb1_23_reg & ~MPM_SYSHUB_SOC_TLB1_23_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_23_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_23_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_23_reg, seg_offset) \
      mpm_syshub_soc_tlb1_23_reg = (mpm_syshub_soc_tlb1_23_reg & ~MPM_SYSHUB_SOC_TLB1_23_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_23_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_23_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_23_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_23_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_23_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_23_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_23_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_23_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_23_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_23_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_23_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_23_t f;
} mpm_syshub_soc_tlb1_23_u;


/*
 * MPM_SYSHUB_SOC_TLB2_23 struct
 */

#define MPM_SYSHUB_SOC_TLB2_23_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_23_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_23_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_23_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_23_MASK \
      (MPM_SYSHUB_SOC_TLB2_23_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_23_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_23_GET_AWUSER(mpm_syshub_soc_tlb2_23) \
      ((mpm_syshub_soc_tlb2_23 & MPM_SYSHUB_SOC_TLB2_23_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_23_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_23_SET_AWUSER(mpm_syshub_soc_tlb2_23_reg, awuser) \
      mpm_syshub_soc_tlb2_23_reg = (mpm_syshub_soc_tlb2_23_reg & ~MPM_SYSHUB_SOC_TLB2_23_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_23_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_23_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_23_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_23_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_23_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_23_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_23_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_23_t f;
} mpm_syshub_soc_tlb2_23_u;


/*
 * MPM_SYSHUB_SOC_TLB3_23 struct
 */

#define MPM_SYSHUB_SOC_TLB3_23_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_23_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_23_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_23_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_23_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_23_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_23_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_23_MASK \
      (MPM_SYSHUB_SOC_TLB3_23_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_23_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_23_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_23_GET_ARUSER(mpm_syshub_soc_tlb3_23) \
      ((mpm_syshub_soc_tlb3_23 & MPM_SYSHUB_SOC_TLB3_23_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_23_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_23_GET_WUSER(mpm_syshub_soc_tlb3_23) \
      ((mpm_syshub_soc_tlb3_23 & MPM_SYSHUB_SOC_TLB3_23_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_23_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_23_SET_ARUSER(mpm_syshub_soc_tlb3_23_reg, aruser) \
      mpm_syshub_soc_tlb3_23_reg = (mpm_syshub_soc_tlb3_23_reg & ~MPM_SYSHUB_SOC_TLB3_23_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_23_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_23_SET_WUSER(mpm_syshub_soc_tlb3_23_reg, wuser) \
      mpm_syshub_soc_tlb3_23_reg = (mpm_syshub_soc_tlb3_23_reg & ~MPM_SYSHUB_SOC_TLB3_23_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_23_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_23_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_23_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_23_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_23_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_23_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_23_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_23_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_23_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_23_t f;
} mpm_syshub_soc_tlb3_23_u;


/*
 * MPM_SYSHUB_SOC_TLB0_24 struct
 */

#define MPM_SYSHUB_SOC_TLB0_24_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_24_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_24_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_24_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_24_MASK \
      (MPM_SYSHUB_SOC_TLB0_24_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_24_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_24_GET_SOC_ADDR(mpm_syshub_soc_tlb0_24) \
      ((mpm_syshub_soc_tlb0_24 & MPM_SYSHUB_SOC_TLB0_24_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_24_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_24_SET_SOC_ADDR(mpm_syshub_soc_tlb0_24_reg, soc_addr) \
      mpm_syshub_soc_tlb0_24_reg = (mpm_syshub_soc_tlb0_24_reg & ~MPM_SYSHUB_SOC_TLB0_24_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_24_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_24_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_24_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_24_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_24_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_24_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_24_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_24_t f;
} mpm_syshub_soc_tlb0_24_u;


/*
 * MPM_SYSHUB_SOC_TLB1_24 struct
 */

#define MPM_SYSHUB_SOC_TLB1_24_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_24_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_24_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_24_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_24_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_24_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_24_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_24_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_24_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_24_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_24_MASK \
      (MPM_SYSHUB_SOC_TLB1_24_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_24_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_24_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_24_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_24_GET_COHERENCE(mpm_syshub_soc_tlb1_24) \
      ((mpm_syshub_soc_tlb1_24 & MPM_SYSHUB_SOC_TLB1_24_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_24_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_24_GET_SEG_SIZE(mpm_syshub_soc_tlb1_24) \
      ((mpm_syshub_soc_tlb1_24 & MPM_SYSHUB_SOC_TLB1_24_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_24_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_24_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_24) \
      ((mpm_syshub_soc_tlb1_24 & MPM_SYSHUB_SOC_TLB1_24_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_24_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_24_SET_COHERENCE(mpm_syshub_soc_tlb1_24_reg, coherence) \
      mpm_syshub_soc_tlb1_24_reg = (mpm_syshub_soc_tlb1_24_reg & ~MPM_SYSHUB_SOC_TLB1_24_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_24_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_24_SET_SEG_SIZE(mpm_syshub_soc_tlb1_24_reg, seg_size) \
      mpm_syshub_soc_tlb1_24_reg = (mpm_syshub_soc_tlb1_24_reg & ~MPM_SYSHUB_SOC_TLB1_24_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_24_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_24_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_24_reg, seg_offset) \
      mpm_syshub_soc_tlb1_24_reg = (mpm_syshub_soc_tlb1_24_reg & ~MPM_SYSHUB_SOC_TLB1_24_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_24_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_24_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_24_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_24_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_24_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_24_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_24_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_24_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_24_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_24_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_24_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_24_t f;
} mpm_syshub_soc_tlb1_24_u;


/*
 * MPM_SYSHUB_SOC_TLB2_24 struct
 */

#define MPM_SYSHUB_SOC_TLB2_24_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_24_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_24_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_24_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_24_MASK \
      (MPM_SYSHUB_SOC_TLB2_24_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_24_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_24_GET_AWUSER(mpm_syshub_soc_tlb2_24) \
      ((mpm_syshub_soc_tlb2_24 & MPM_SYSHUB_SOC_TLB2_24_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_24_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_24_SET_AWUSER(mpm_syshub_soc_tlb2_24_reg, awuser) \
      mpm_syshub_soc_tlb2_24_reg = (mpm_syshub_soc_tlb2_24_reg & ~MPM_SYSHUB_SOC_TLB2_24_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_24_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_24_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_24_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_24_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_24_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_24_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_24_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_24_t f;
} mpm_syshub_soc_tlb2_24_u;


/*
 * MPM_SYSHUB_SOC_TLB3_24 struct
 */

#define MPM_SYSHUB_SOC_TLB3_24_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_24_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_24_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_24_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_24_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_24_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_24_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_24_MASK \
      (MPM_SYSHUB_SOC_TLB3_24_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_24_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_24_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_24_GET_ARUSER(mpm_syshub_soc_tlb3_24) \
      ((mpm_syshub_soc_tlb3_24 & MPM_SYSHUB_SOC_TLB3_24_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_24_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_24_GET_WUSER(mpm_syshub_soc_tlb3_24) \
      ((mpm_syshub_soc_tlb3_24 & MPM_SYSHUB_SOC_TLB3_24_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_24_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_24_SET_ARUSER(mpm_syshub_soc_tlb3_24_reg, aruser) \
      mpm_syshub_soc_tlb3_24_reg = (mpm_syshub_soc_tlb3_24_reg & ~MPM_SYSHUB_SOC_TLB3_24_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_24_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_24_SET_WUSER(mpm_syshub_soc_tlb3_24_reg, wuser) \
      mpm_syshub_soc_tlb3_24_reg = (mpm_syshub_soc_tlb3_24_reg & ~MPM_SYSHUB_SOC_TLB3_24_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_24_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_24_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_24_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_24_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_24_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_24_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_24_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_24_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_24_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_24_t f;
} mpm_syshub_soc_tlb3_24_u;


/*
 * MPM_SYSHUB_SOC_TLB0_25 struct
 */

#define MPM_SYSHUB_SOC_TLB0_25_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_25_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_25_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_25_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_25_MASK \
      (MPM_SYSHUB_SOC_TLB0_25_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_25_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_25_GET_SOC_ADDR(mpm_syshub_soc_tlb0_25) \
      ((mpm_syshub_soc_tlb0_25 & MPM_SYSHUB_SOC_TLB0_25_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_25_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_25_SET_SOC_ADDR(mpm_syshub_soc_tlb0_25_reg, soc_addr) \
      mpm_syshub_soc_tlb0_25_reg = (mpm_syshub_soc_tlb0_25_reg & ~MPM_SYSHUB_SOC_TLB0_25_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_25_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_25_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_25_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_25_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_25_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_25_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_25_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_25_t f;
} mpm_syshub_soc_tlb0_25_u;


/*
 * MPM_SYSHUB_SOC_TLB1_25 struct
 */

#define MPM_SYSHUB_SOC_TLB1_25_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_25_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_25_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_25_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_25_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_25_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_25_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_25_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_25_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_25_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_25_MASK \
      (MPM_SYSHUB_SOC_TLB1_25_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_25_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_25_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_25_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_25_GET_COHERENCE(mpm_syshub_soc_tlb1_25) \
      ((mpm_syshub_soc_tlb1_25 & MPM_SYSHUB_SOC_TLB1_25_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_25_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_25_GET_SEG_SIZE(mpm_syshub_soc_tlb1_25) \
      ((mpm_syshub_soc_tlb1_25 & MPM_SYSHUB_SOC_TLB1_25_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_25_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_25_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_25) \
      ((mpm_syshub_soc_tlb1_25 & MPM_SYSHUB_SOC_TLB1_25_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_25_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_25_SET_COHERENCE(mpm_syshub_soc_tlb1_25_reg, coherence) \
      mpm_syshub_soc_tlb1_25_reg = (mpm_syshub_soc_tlb1_25_reg & ~MPM_SYSHUB_SOC_TLB1_25_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_25_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_25_SET_SEG_SIZE(mpm_syshub_soc_tlb1_25_reg, seg_size) \
      mpm_syshub_soc_tlb1_25_reg = (mpm_syshub_soc_tlb1_25_reg & ~MPM_SYSHUB_SOC_TLB1_25_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_25_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_25_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_25_reg, seg_offset) \
      mpm_syshub_soc_tlb1_25_reg = (mpm_syshub_soc_tlb1_25_reg & ~MPM_SYSHUB_SOC_TLB1_25_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_25_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_25_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_25_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_25_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_25_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_25_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_25_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_25_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_25_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_25_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_25_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_25_t f;
} mpm_syshub_soc_tlb1_25_u;


/*
 * MPM_SYSHUB_SOC_TLB2_25 struct
 */

#define MPM_SYSHUB_SOC_TLB2_25_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_25_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_25_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_25_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_25_MASK \
      (MPM_SYSHUB_SOC_TLB2_25_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_25_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_25_GET_AWUSER(mpm_syshub_soc_tlb2_25) \
      ((mpm_syshub_soc_tlb2_25 & MPM_SYSHUB_SOC_TLB2_25_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_25_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_25_SET_AWUSER(mpm_syshub_soc_tlb2_25_reg, awuser) \
      mpm_syshub_soc_tlb2_25_reg = (mpm_syshub_soc_tlb2_25_reg & ~MPM_SYSHUB_SOC_TLB2_25_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_25_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_25_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_25_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_25_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_25_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_25_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_25_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_25_t f;
} mpm_syshub_soc_tlb2_25_u;


/*
 * MPM_SYSHUB_SOC_TLB3_25 struct
 */

#define MPM_SYSHUB_SOC_TLB3_25_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_25_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_25_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_25_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_25_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_25_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_25_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_25_MASK \
      (MPM_SYSHUB_SOC_TLB3_25_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_25_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_25_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_25_GET_ARUSER(mpm_syshub_soc_tlb3_25) \
      ((mpm_syshub_soc_tlb3_25 & MPM_SYSHUB_SOC_TLB3_25_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_25_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_25_GET_WUSER(mpm_syshub_soc_tlb3_25) \
      ((mpm_syshub_soc_tlb3_25 & MPM_SYSHUB_SOC_TLB3_25_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_25_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_25_SET_ARUSER(mpm_syshub_soc_tlb3_25_reg, aruser) \
      mpm_syshub_soc_tlb3_25_reg = (mpm_syshub_soc_tlb3_25_reg & ~MPM_SYSHUB_SOC_TLB3_25_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_25_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_25_SET_WUSER(mpm_syshub_soc_tlb3_25_reg, wuser) \
      mpm_syshub_soc_tlb3_25_reg = (mpm_syshub_soc_tlb3_25_reg & ~MPM_SYSHUB_SOC_TLB3_25_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_25_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_25_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_25_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_25_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_25_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_25_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_25_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_25_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_25_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_25_t f;
} mpm_syshub_soc_tlb3_25_u;


/*
 * MPM_SYSHUB_SOC_TLB0_26 struct
 */

#define MPM_SYSHUB_SOC_TLB0_26_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_26_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_26_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_26_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_26_MASK \
      (MPM_SYSHUB_SOC_TLB0_26_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_26_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_26_GET_SOC_ADDR(mpm_syshub_soc_tlb0_26) \
      ((mpm_syshub_soc_tlb0_26 & MPM_SYSHUB_SOC_TLB0_26_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_26_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_26_SET_SOC_ADDR(mpm_syshub_soc_tlb0_26_reg, soc_addr) \
      mpm_syshub_soc_tlb0_26_reg = (mpm_syshub_soc_tlb0_26_reg & ~MPM_SYSHUB_SOC_TLB0_26_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_26_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_26_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_26_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_26_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_26_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_26_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_26_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_26_t f;
} mpm_syshub_soc_tlb0_26_u;


/*
 * MPM_SYSHUB_SOC_TLB1_26 struct
 */

#define MPM_SYSHUB_SOC_TLB1_26_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_26_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_26_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_26_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_26_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_26_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_26_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_26_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_26_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_26_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_26_MASK \
      (MPM_SYSHUB_SOC_TLB1_26_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_26_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_26_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_26_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_26_GET_COHERENCE(mpm_syshub_soc_tlb1_26) \
      ((mpm_syshub_soc_tlb1_26 & MPM_SYSHUB_SOC_TLB1_26_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_26_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_26_GET_SEG_SIZE(mpm_syshub_soc_tlb1_26) \
      ((mpm_syshub_soc_tlb1_26 & MPM_SYSHUB_SOC_TLB1_26_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_26_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_26_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_26) \
      ((mpm_syshub_soc_tlb1_26 & MPM_SYSHUB_SOC_TLB1_26_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_26_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_26_SET_COHERENCE(mpm_syshub_soc_tlb1_26_reg, coherence) \
      mpm_syshub_soc_tlb1_26_reg = (mpm_syshub_soc_tlb1_26_reg & ~MPM_SYSHUB_SOC_TLB1_26_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_26_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_26_SET_SEG_SIZE(mpm_syshub_soc_tlb1_26_reg, seg_size) \
      mpm_syshub_soc_tlb1_26_reg = (mpm_syshub_soc_tlb1_26_reg & ~MPM_SYSHUB_SOC_TLB1_26_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_26_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_26_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_26_reg, seg_offset) \
      mpm_syshub_soc_tlb1_26_reg = (mpm_syshub_soc_tlb1_26_reg & ~MPM_SYSHUB_SOC_TLB1_26_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_26_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_26_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_26_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_26_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_26_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_26_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_26_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_26_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_26_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_26_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_26_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_26_t f;
} mpm_syshub_soc_tlb1_26_u;


/*
 * MPM_SYSHUB_SOC_TLB2_26 struct
 */

#define MPM_SYSHUB_SOC_TLB2_26_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_26_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_26_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_26_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_26_MASK \
      (MPM_SYSHUB_SOC_TLB2_26_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_26_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_26_GET_AWUSER(mpm_syshub_soc_tlb2_26) \
      ((mpm_syshub_soc_tlb2_26 & MPM_SYSHUB_SOC_TLB2_26_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_26_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_26_SET_AWUSER(mpm_syshub_soc_tlb2_26_reg, awuser) \
      mpm_syshub_soc_tlb2_26_reg = (mpm_syshub_soc_tlb2_26_reg & ~MPM_SYSHUB_SOC_TLB2_26_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_26_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_26_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_26_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_26_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_26_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_26_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_26_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_26_t f;
} mpm_syshub_soc_tlb2_26_u;


/*
 * MPM_SYSHUB_SOC_TLB3_26 struct
 */

#define MPM_SYSHUB_SOC_TLB3_26_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_26_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_26_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_26_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_26_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_26_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_26_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_26_MASK \
      (MPM_SYSHUB_SOC_TLB3_26_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_26_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_26_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_26_GET_ARUSER(mpm_syshub_soc_tlb3_26) \
      ((mpm_syshub_soc_tlb3_26 & MPM_SYSHUB_SOC_TLB3_26_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_26_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_26_GET_WUSER(mpm_syshub_soc_tlb3_26) \
      ((mpm_syshub_soc_tlb3_26 & MPM_SYSHUB_SOC_TLB3_26_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_26_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_26_SET_ARUSER(mpm_syshub_soc_tlb3_26_reg, aruser) \
      mpm_syshub_soc_tlb3_26_reg = (mpm_syshub_soc_tlb3_26_reg & ~MPM_SYSHUB_SOC_TLB3_26_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_26_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_26_SET_WUSER(mpm_syshub_soc_tlb3_26_reg, wuser) \
      mpm_syshub_soc_tlb3_26_reg = (mpm_syshub_soc_tlb3_26_reg & ~MPM_SYSHUB_SOC_TLB3_26_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_26_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_26_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_26_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_26_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_26_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_26_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_26_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_26_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_26_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_26_t f;
} mpm_syshub_soc_tlb3_26_u;


/*
 * MPM_SYSHUB_SOC_TLB0_27 struct
 */

#define MPM_SYSHUB_SOC_TLB0_27_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_27_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_27_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_27_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_27_MASK \
      (MPM_SYSHUB_SOC_TLB0_27_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_27_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_27_GET_SOC_ADDR(mpm_syshub_soc_tlb0_27) \
      ((mpm_syshub_soc_tlb0_27 & MPM_SYSHUB_SOC_TLB0_27_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_27_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_27_SET_SOC_ADDR(mpm_syshub_soc_tlb0_27_reg, soc_addr) \
      mpm_syshub_soc_tlb0_27_reg = (mpm_syshub_soc_tlb0_27_reg & ~MPM_SYSHUB_SOC_TLB0_27_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_27_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_27_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_27_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_27_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_27_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_27_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_27_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_27_t f;
} mpm_syshub_soc_tlb0_27_u;


/*
 * MPM_SYSHUB_SOC_TLB1_27 struct
 */

#define MPM_SYSHUB_SOC_TLB1_27_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_27_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_27_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_27_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_27_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_27_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_27_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_27_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_27_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_27_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_27_MASK \
      (MPM_SYSHUB_SOC_TLB1_27_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_27_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_27_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_27_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_27_GET_COHERENCE(mpm_syshub_soc_tlb1_27) \
      ((mpm_syshub_soc_tlb1_27 & MPM_SYSHUB_SOC_TLB1_27_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_27_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_27_GET_SEG_SIZE(mpm_syshub_soc_tlb1_27) \
      ((mpm_syshub_soc_tlb1_27 & MPM_SYSHUB_SOC_TLB1_27_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_27_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_27_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_27) \
      ((mpm_syshub_soc_tlb1_27 & MPM_SYSHUB_SOC_TLB1_27_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_27_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_27_SET_COHERENCE(mpm_syshub_soc_tlb1_27_reg, coherence) \
      mpm_syshub_soc_tlb1_27_reg = (mpm_syshub_soc_tlb1_27_reg & ~MPM_SYSHUB_SOC_TLB1_27_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_27_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_27_SET_SEG_SIZE(mpm_syshub_soc_tlb1_27_reg, seg_size) \
      mpm_syshub_soc_tlb1_27_reg = (mpm_syshub_soc_tlb1_27_reg & ~MPM_SYSHUB_SOC_TLB1_27_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_27_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_27_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_27_reg, seg_offset) \
      mpm_syshub_soc_tlb1_27_reg = (mpm_syshub_soc_tlb1_27_reg & ~MPM_SYSHUB_SOC_TLB1_27_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_27_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_27_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_27_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_27_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_27_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_27_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_27_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_27_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_27_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_27_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_27_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_27_t f;
} mpm_syshub_soc_tlb1_27_u;


/*
 * MPM_SYSHUB_SOC_TLB2_27 struct
 */

#define MPM_SYSHUB_SOC_TLB2_27_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_27_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_27_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_27_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_27_MASK \
      (MPM_SYSHUB_SOC_TLB2_27_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_27_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_27_GET_AWUSER(mpm_syshub_soc_tlb2_27) \
      ((mpm_syshub_soc_tlb2_27 & MPM_SYSHUB_SOC_TLB2_27_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_27_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_27_SET_AWUSER(mpm_syshub_soc_tlb2_27_reg, awuser) \
      mpm_syshub_soc_tlb2_27_reg = (mpm_syshub_soc_tlb2_27_reg & ~MPM_SYSHUB_SOC_TLB2_27_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_27_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_27_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_27_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_27_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_27_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_27_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_27_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_27_t f;
} mpm_syshub_soc_tlb2_27_u;


/*
 * MPM_SYSHUB_SOC_TLB3_27 struct
 */

#define MPM_SYSHUB_SOC_TLB3_27_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_27_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_27_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_27_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_27_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_27_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_27_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_27_MASK \
      (MPM_SYSHUB_SOC_TLB3_27_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_27_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_27_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_27_GET_ARUSER(mpm_syshub_soc_tlb3_27) \
      ((mpm_syshub_soc_tlb3_27 & MPM_SYSHUB_SOC_TLB3_27_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_27_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_27_GET_WUSER(mpm_syshub_soc_tlb3_27) \
      ((mpm_syshub_soc_tlb3_27 & MPM_SYSHUB_SOC_TLB3_27_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_27_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_27_SET_ARUSER(mpm_syshub_soc_tlb3_27_reg, aruser) \
      mpm_syshub_soc_tlb3_27_reg = (mpm_syshub_soc_tlb3_27_reg & ~MPM_SYSHUB_SOC_TLB3_27_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_27_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_27_SET_WUSER(mpm_syshub_soc_tlb3_27_reg, wuser) \
      mpm_syshub_soc_tlb3_27_reg = (mpm_syshub_soc_tlb3_27_reg & ~MPM_SYSHUB_SOC_TLB3_27_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_27_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_27_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_27_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_27_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_27_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_27_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_27_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_27_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_27_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_27_t f;
} mpm_syshub_soc_tlb3_27_u;


/*
 * MPM_SYSHUB_SOC_TLB0_28 struct
 */

#define MPM_SYSHUB_SOC_TLB0_28_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_28_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_28_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_28_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_28_MASK \
      (MPM_SYSHUB_SOC_TLB0_28_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_28_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_28_GET_SOC_ADDR(mpm_syshub_soc_tlb0_28) \
      ((mpm_syshub_soc_tlb0_28 & MPM_SYSHUB_SOC_TLB0_28_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_28_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_28_SET_SOC_ADDR(mpm_syshub_soc_tlb0_28_reg, soc_addr) \
      mpm_syshub_soc_tlb0_28_reg = (mpm_syshub_soc_tlb0_28_reg & ~MPM_SYSHUB_SOC_TLB0_28_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_28_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_28_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_28_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_28_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_28_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_28_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_28_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_28_t f;
} mpm_syshub_soc_tlb0_28_u;


/*
 * MPM_SYSHUB_SOC_TLB1_28 struct
 */

#define MPM_SYSHUB_SOC_TLB1_28_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_28_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_28_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_28_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_28_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_28_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_28_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_28_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_28_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_28_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_28_MASK \
      (MPM_SYSHUB_SOC_TLB1_28_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_28_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_28_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_28_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_28_GET_COHERENCE(mpm_syshub_soc_tlb1_28) \
      ((mpm_syshub_soc_tlb1_28 & MPM_SYSHUB_SOC_TLB1_28_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_28_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_28_GET_SEG_SIZE(mpm_syshub_soc_tlb1_28) \
      ((mpm_syshub_soc_tlb1_28 & MPM_SYSHUB_SOC_TLB1_28_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_28_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_28_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_28) \
      ((mpm_syshub_soc_tlb1_28 & MPM_SYSHUB_SOC_TLB1_28_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_28_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_28_SET_COHERENCE(mpm_syshub_soc_tlb1_28_reg, coherence) \
      mpm_syshub_soc_tlb1_28_reg = (mpm_syshub_soc_tlb1_28_reg & ~MPM_SYSHUB_SOC_TLB1_28_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_28_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_28_SET_SEG_SIZE(mpm_syshub_soc_tlb1_28_reg, seg_size) \
      mpm_syshub_soc_tlb1_28_reg = (mpm_syshub_soc_tlb1_28_reg & ~MPM_SYSHUB_SOC_TLB1_28_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_28_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_28_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_28_reg, seg_offset) \
      mpm_syshub_soc_tlb1_28_reg = (mpm_syshub_soc_tlb1_28_reg & ~MPM_SYSHUB_SOC_TLB1_28_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_28_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_28_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_28_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_28_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_28_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_28_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_28_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_28_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_28_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_28_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_28_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_28_t f;
} mpm_syshub_soc_tlb1_28_u;


/*
 * MPM_SYSHUB_SOC_TLB2_28 struct
 */

#define MPM_SYSHUB_SOC_TLB2_28_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_28_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_28_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_28_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_28_MASK \
      (MPM_SYSHUB_SOC_TLB2_28_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_28_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_28_GET_AWUSER(mpm_syshub_soc_tlb2_28) \
      ((mpm_syshub_soc_tlb2_28 & MPM_SYSHUB_SOC_TLB2_28_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_28_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_28_SET_AWUSER(mpm_syshub_soc_tlb2_28_reg, awuser) \
      mpm_syshub_soc_tlb2_28_reg = (mpm_syshub_soc_tlb2_28_reg & ~MPM_SYSHUB_SOC_TLB2_28_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_28_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_28_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_28_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_28_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_28_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_28_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_28_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_28_t f;
} mpm_syshub_soc_tlb2_28_u;


/*
 * MPM_SYSHUB_SOC_TLB3_28 struct
 */

#define MPM_SYSHUB_SOC_TLB3_28_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_28_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_28_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_28_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_28_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_28_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_28_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_28_MASK \
      (MPM_SYSHUB_SOC_TLB3_28_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_28_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_28_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_28_GET_ARUSER(mpm_syshub_soc_tlb3_28) \
      ((mpm_syshub_soc_tlb3_28 & MPM_SYSHUB_SOC_TLB3_28_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_28_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_28_GET_WUSER(mpm_syshub_soc_tlb3_28) \
      ((mpm_syshub_soc_tlb3_28 & MPM_SYSHUB_SOC_TLB3_28_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_28_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_28_SET_ARUSER(mpm_syshub_soc_tlb3_28_reg, aruser) \
      mpm_syshub_soc_tlb3_28_reg = (mpm_syshub_soc_tlb3_28_reg & ~MPM_SYSHUB_SOC_TLB3_28_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_28_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_28_SET_WUSER(mpm_syshub_soc_tlb3_28_reg, wuser) \
      mpm_syshub_soc_tlb3_28_reg = (mpm_syshub_soc_tlb3_28_reg & ~MPM_SYSHUB_SOC_TLB3_28_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_28_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_28_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_28_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_28_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_28_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_28_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_28_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_28_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_28_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_28_t f;
} mpm_syshub_soc_tlb3_28_u;


/*
 * MPM_SYSHUB_SOC_TLB0_29 struct
 */

#define MPM_SYSHUB_SOC_TLB0_29_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_29_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_29_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_29_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_29_MASK \
      (MPM_SYSHUB_SOC_TLB0_29_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_29_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_29_GET_SOC_ADDR(mpm_syshub_soc_tlb0_29) \
      ((mpm_syshub_soc_tlb0_29 & MPM_SYSHUB_SOC_TLB0_29_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_29_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_29_SET_SOC_ADDR(mpm_syshub_soc_tlb0_29_reg, soc_addr) \
      mpm_syshub_soc_tlb0_29_reg = (mpm_syshub_soc_tlb0_29_reg & ~MPM_SYSHUB_SOC_TLB0_29_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_29_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_29_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_29_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_29_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_29_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_29_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_29_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_29_t f;
} mpm_syshub_soc_tlb0_29_u;


/*
 * MPM_SYSHUB_SOC_TLB1_29 struct
 */

#define MPM_SYSHUB_SOC_TLB1_29_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_29_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_29_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_29_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_29_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_29_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_29_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_29_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_29_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_29_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_29_MASK \
      (MPM_SYSHUB_SOC_TLB1_29_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_29_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_29_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_29_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_29_GET_COHERENCE(mpm_syshub_soc_tlb1_29) \
      ((mpm_syshub_soc_tlb1_29 & MPM_SYSHUB_SOC_TLB1_29_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_29_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_29_GET_SEG_SIZE(mpm_syshub_soc_tlb1_29) \
      ((mpm_syshub_soc_tlb1_29 & MPM_SYSHUB_SOC_TLB1_29_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_29_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_29_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_29) \
      ((mpm_syshub_soc_tlb1_29 & MPM_SYSHUB_SOC_TLB1_29_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_29_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_29_SET_COHERENCE(mpm_syshub_soc_tlb1_29_reg, coherence) \
      mpm_syshub_soc_tlb1_29_reg = (mpm_syshub_soc_tlb1_29_reg & ~MPM_SYSHUB_SOC_TLB1_29_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_29_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_29_SET_SEG_SIZE(mpm_syshub_soc_tlb1_29_reg, seg_size) \
      mpm_syshub_soc_tlb1_29_reg = (mpm_syshub_soc_tlb1_29_reg & ~MPM_SYSHUB_SOC_TLB1_29_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_29_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_29_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_29_reg, seg_offset) \
      mpm_syshub_soc_tlb1_29_reg = (mpm_syshub_soc_tlb1_29_reg & ~MPM_SYSHUB_SOC_TLB1_29_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_29_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_29_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_29_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_29_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_29_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_29_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_29_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_29_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_29_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_29_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_29_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_29_t f;
} mpm_syshub_soc_tlb1_29_u;


/*
 * MPM_SYSHUB_SOC_TLB2_29 struct
 */

#define MPM_SYSHUB_SOC_TLB2_29_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_29_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_29_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_29_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_29_MASK \
      (MPM_SYSHUB_SOC_TLB2_29_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_29_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_29_GET_AWUSER(mpm_syshub_soc_tlb2_29) \
      ((mpm_syshub_soc_tlb2_29 & MPM_SYSHUB_SOC_TLB2_29_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_29_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_29_SET_AWUSER(mpm_syshub_soc_tlb2_29_reg, awuser) \
      mpm_syshub_soc_tlb2_29_reg = (mpm_syshub_soc_tlb2_29_reg & ~MPM_SYSHUB_SOC_TLB2_29_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_29_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_29_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_29_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_29_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_29_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_29_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_29_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_29_t f;
} mpm_syshub_soc_tlb2_29_u;


/*
 * MPM_SYSHUB_SOC_TLB3_29 struct
 */

#define MPM_SYSHUB_SOC_TLB3_29_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_29_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_29_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_29_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_29_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_29_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_29_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_29_MASK \
      (MPM_SYSHUB_SOC_TLB3_29_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_29_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_29_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_29_GET_ARUSER(mpm_syshub_soc_tlb3_29) \
      ((mpm_syshub_soc_tlb3_29 & MPM_SYSHUB_SOC_TLB3_29_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_29_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_29_GET_WUSER(mpm_syshub_soc_tlb3_29) \
      ((mpm_syshub_soc_tlb3_29 & MPM_SYSHUB_SOC_TLB3_29_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_29_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_29_SET_ARUSER(mpm_syshub_soc_tlb3_29_reg, aruser) \
      mpm_syshub_soc_tlb3_29_reg = (mpm_syshub_soc_tlb3_29_reg & ~MPM_SYSHUB_SOC_TLB3_29_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_29_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_29_SET_WUSER(mpm_syshub_soc_tlb3_29_reg, wuser) \
      mpm_syshub_soc_tlb3_29_reg = (mpm_syshub_soc_tlb3_29_reg & ~MPM_SYSHUB_SOC_TLB3_29_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_29_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_29_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_29_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_29_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_29_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_29_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_29_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_29_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_29_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_29_t f;
} mpm_syshub_soc_tlb3_29_u;


/*
 * MPM_SYSHUB_SOC_TLB0_30 struct
 */

#define MPM_SYSHUB_SOC_TLB0_30_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_30_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_30_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_30_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_30_MASK \
      (MPM_SYSHUB_SOC_TLB0_30_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_30_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_30_GET_SOC_ADDR(mpm_syshub_soc_tlb0_30) \
      ((mpm_syshub_soc_tlb0_30 & MPM_SYSHUB_SOC_TLB0_30_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_30_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_30_SET_SOC_ADDR(mpm_syshub_soc_tlb0_30_reg, soc_addr) \
      mpm_syshub_soc_tlb0_30_reg = (mpm_syshub_soc_tlb0_30_reg & ~MPM_SYSHUB_SOC_TLB0_30_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_30_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_30_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_30_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_30_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_30_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_30_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_30_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_30_t f;
} mpm_syshub_soc_tlb0_30_u;


/*
 * MPM_SYSHUB_SOC_TLB1_30 struct
 */

#define MPM_SYSHUB_SOC_TLB1_30_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_30_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_30_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_30_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_30_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_30_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_30_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_30_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_30_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_30_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_30_MASK \
      (MPM_SYSHUB_SOC_TLB1_30_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_30_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_30_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_30_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_30_GET_COHERENCE(mpm_syshub_soc_tlb1_30) \
      ((mpm_syshub_soc_tlb1_30 & MPM_SYSHUB_SOC_TLB1_30_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_30_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_30_GET_SEG_SIZE(mpm_syshub_soc_tlb1_30) \
      ((mpm_syshub_soc_tlb1_30 & MPM_SYSHUB_SOC_TLB1_30_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_30_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_30_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_30) \
      ((mpm_syshub_soc_tlb1_30 & MPM_SYSHUB_SOC_TLB1_30_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_30_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_30_SET_COHERENCE(mpm_syshub_soc_tlb1_30_reg, coherence) \
      mpm_syshub_soc_tlb1_30_reg = (mpm_syshub_soc_tlb1_30_reg & ~MPM_SYSHUB_SOC_TLB1_30_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_30_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_30_SET_SEG_SIZE(mpm_syshub_soc_tlb1_30_reg, seg_size) \
      mpm_syshub_soc_tlb1_30_reg = (mpm_syshub_soc_tlb1_30_reg & ~MPM_SYSHUB_SOC_TLB1_30_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_30_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_30_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_30_reg, seg_offset) \
      mpm_syshub_soc_tlb1_30_reg = (mpm_syshub_soc_tlb1_30_reg & ~MPM_SYSHUB_SOC_TLB1_30_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_30_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_30_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_30_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_30_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_30_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_30_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_30_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_30_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_30_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_30_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_30_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_30_t f;
} mpm_syshub_soc_tlb1_30_u;


/*
 * MPM_SYSHUB_SOC_TLB2_30 struct
 */

#define MPM_SYSHUB_SOC_TLB2_30_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_30_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_30_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_30_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_30_MASK \
      (MPM_SYSHUB_SOC_TLB2_30_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_30_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_30_GET_AWUSER(mpm_syshub_soc_tlb2_30) \
      ((mpm_syshub_soc_tlb2_30 & MPM_SYSHUB_SOC_TLB2_30_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_30_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_30_SET_AWUSER(mpm_syshub_soc_tlb2_30_reg, awuser) \
      mpm_syshub_soc_tlb2_30_reg = (mpm_syshub_soc_tlb2_30_reg & ~MPM_SYSHUB_SOC_TLB2_30_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_30_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_30_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_30_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_30_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_30_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_30_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_30_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_30_t f;
} mpm_syshub_soc_tlb2_30_u;


/*
 * MPM_SYSHUB_SOC_TLB3_30 struct
 */

#define MPM_SYSHUB_SOC_TLB3_30_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_30_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_30_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_30_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_30_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_30_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_30_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_30_MASK \
      (MPM_SYSHUB_SOC_TLB3_30_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_30_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_30_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_30_GET_ARUSER(mpm_syshub_soc_tlb3_30) \
      ((mpm_syshub_soc_tlb3_30 & MPM_SYSHUB_SOC_TLB3_30_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_30_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_30_GET_WUSER(mpm_syshub_soc_tlb3_30) \
      ((mpm_syshub_soc_tlb3_30 & MPM_SYSHUB_SOC_TLB3_30_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_30_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_30_SET_ARUSER(mpm_syshub_soc_tlb3_30_reg, aruser) \
      mpm_syshub_soc_tlb3_30_reg = (mpm_syshub_soc_tlb3_30_reg & ~MPM_SYSHUB_SOC_TLB3_30_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_30_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_30_SET_WUSER(mpm_syshub_soc_tlb3_30_reg, wuser) \
      mpm_syshub_soc_tlb3_30_reg = (mpm_syshub_soc_tlb3_30_reg & ~MPM_SYSHUB_SOC_TLB3_30_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_30_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_30_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_30_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_30_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_30_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_30_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_30_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_30_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_30_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_30_t f;
} mpm_syshub_soc_tlb3_30_u;


/*
 * MPM_SYSHUB_SOC_TLB0_31 struct
 */

#define MPM_SYSHUB_SOC_TLB0_31_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB0_31_SOC_ADDR_SIZE  22

#define MPM_SYSHUB_SOC_TLB0_31_SOC_ADDR_SHIFT  0

#define MPM_SYSHUB_SOC_TLB0_31_SOC_ADDR_MASK  0x003fffff

#define MPM_SYSHUB_SOC_TLB0_31_MASK \
      (MPM_SYSHUB_SOC_TLB0_31_SOC_ADDR_MASK)

#define MPM_SYSHUB_SOC_TLB0_31_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB0_31_GET_SOC_ADDR(mpm_syshub_soc_tlb0_31) \
      ((mpm_syshub_soc_tlb0_31 & MPM_SYSHUB_SOC_TLB0_31_SOC_ADDR_MASK) >> MPM_SYSHUB_SOC_TLB0_31_SOC_ADDR_SHIFT)

#define MPM_SYSHUB_SOC_TLB0_31_SET_SOC_ADDR(mpm_syshub_soc_tlb0_31_reg, soc_addr) \
      mpm_syshub_soc_tlb0_31_reg = (mpm_syshub_soc_tlb0_31_reg & ~MPM_SYSHUB_SOC_TLB0_31_SOC_ADDR_MASK) | (soc_addr << MPM_SYSHUB_SOC_TLB0_31_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_31_t {
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_31_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mpm_syshub_soc_tlb0_31_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb0_31_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MPM_SYSHUB_SOC_TLB0_31_SOC_ADDR_SIZE;
      } mpm_syshub_soc_tlb0_31_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb0_31_t f;
} mpm_syshub_soc_tlb0_31_u;


/*
 * MPM_SYSHUB_SOC_TLB1_31 struct
 */

#define MPM_SYSHUB_SOC_TLB1_31_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB1_31_COHERENCE_SIZE  1
#define MPM_SYSHUB_SOC_TLB1_31_SEG_SIZE_SIZE  4
#define MPM_SYSHUB_SOC_TLB1_31_SEG_OFFSET_SIZE  9

#define MPM_SYSHUB_SOC_TLB1_31_COHERENCE_SHIFT  0
#define MPM_SYSHUB_SOC_TLB1_31_SEG_SIZE_SHIFT  1
#define MPM_SYSHUB_SOC_TLB1_31_SEG_OFFSET_SHIFT  5

#define MPM_SYSHUB_SOC_TLB1_31_COHERENCE_MASK  0x00000001
#define MPM_SYSHUB_SOC_TLB1_31_SEG_SIZE_MASK  0x0000001e
#define MPM_SYSHUB_SOC_TLB1_31_SEG_OFFSET_MASK  0x00003fe0

#define MPM_SYSHUB_SOC_TLB1_31_MASK \
      (MPM_SYSHUB_SOC_TLB1_31_COHERENCE_MASK | \
      MPM_SYSHUB_SOC_TLB1_31_SEG_SIZE_MASK | \
      MPM_SYSHUB_SOC_TLB1_31_SEG_OFFSET_MASK)

#define MPM_SYSHUB_SOC_TLB1_31_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB1_31_GET_COHERENCE(mpm_syshub_soc_tlb1_31) \
      ((mpm_syshub_soc_tlb1_31 & MPM_SYSHUB_SOC_TLB1_31_COHERENCE_MASK) >> MPM_SYSHUB_SOC_TLB1_31_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_31_GET_SEG_SIZE(mpm_syshub_soc_tlb1_31) \
      ((mpm_syshub_soc_tlb1_31 & MPM_SYSHUB_SOC_TLB1_31_SEG_SIZE_MASK) >> MPM_SYSHUB_SOC_TLB1_31_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_31_GET_SEG_OFFSET(mpm_syshub_soc_tlb1_31) \
      ((mpm_syshub_soc_tlb1_31 & MPM_SYSHUB_SOC_TLB1_31_SEG_OFFSET_MASK) >> MPM_SYSHUB_SOC_TLB1_31_SEG_OFFSET_SHIFT)

#define MPM_SYSHUB_SOC_TLB1_31_SET_COHERENCE(mpm_syshub_soc_tlb1_31_reg, coherence) \
      mpm_syshub_soc_tlb1_31_reg = (mpm_syshub_soc_tlb1_31_reg & ~MPM_SYSHUB_SOC_TLB1_31_COHERENCE_MASK) | (coherence << MPM_SYSHUB_SOC_TLB1_31_COHERENCE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_31_SET_SEG_SIZE(mpm_syshub_soc_tlb1_31_reg, seg_size) \
      mpm_syshub_soc_tlb1_31_reg = (mpm_syshub_soc_tlb1_31_reg & ~MPM_SYSHUB_SOC_TLB1_31_SEG_SIZE_MASK) | (seg_size << MPM_SYSHUB_SOC_TLB1_31_SEG_SIZE_SHIFT)
#define MPM_SYSHUB_SOC_TLB1_31_SET_SEG_OFFSET(mpm_syshub_soc_tlb1_31_reg, seg_offset) \
      mpm_syshub_soc_tlb1_31_reg = (mpm_syshub_soc_tlb1_31_reg & ~MPM_SYSHUB_SOC_TLB1_31_SEG_OFFSET_MASK) | (seg_offset << MPM_SYSHUB_SOC_TLB1_31_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_31_t {
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_31_COHERENCE_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_31_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_31_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mpm_syshub_soc_tlb1_31_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb1_31_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MPM_SYSHUB_SOC_TLB1_31_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MPM_SYSHUB_SOC_TLB1_31_SEG_SIZE_SIZE;
            unsigned int coherence                      : MPM_SYSHUB_SOC_TLB1_31_COHERENCE_SIZE;
      } mpm_syshub_soc_tlb1_31_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb1_31_t f;
} mpm_syshub_soc_tlb1_31_u;


/*
 * MPM_SYSHUB_SOC_TLB2_31 struct
 */

#define MPM_SYSHUB_SOC_TLB2_31_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB2_31_AWUSER_SIZE  32

#define MPM_SYSHUB_SOC_TLB2_31_AWUSER_SHIFT  0

#define MPM_SYSHUB_SOC_TLB2_31_AWUSER_MASK  0xffffffff

#define MPM_SYSHUB_SOC_TLB2_31_MASK \
      (MPM_SYSHUB_SOC_TLB2_31_AWUSER_MASK)

#define MPM_SYSHUB_SOC_TLB2_31_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB2_31_GET_AWUSER(mpm_syshub_soc_tlb2_31) \
      ((mpm_syshub_soc_tlb2_31 & MPM_SYSHUB_SOC_TLB2_31_AWUSER_MASK) >> MPM_SYSHUB_SOC_TLB2_31_AWUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB2_31_SET_AWUSER(mpm_syshub_soc_tlb2_31_reg, awuser) \
      mpm_syshub_soc_tlb2_31_reg = (mpm_syshub_soc_tlb2_31_reg & ~MPM_SYSHUB_SOC_TLB2_31_AWUSER_MASK) | (awuser << MPM_SYSHUB_SOC_TLB2_31_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_31_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_31_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_31_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb2_31_t {
            unsigned int awuser                         : MPM_SYSHUB_SOC_TLB2_31_AWUSER_SIZE;
      } mpm_syshub_soc_tlb2_31_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb2_31_t f;
} mpm_syshub_soc_tlb2_31_u;


/*
 * MPM_SYSHUB_SOC_TLB3_31 struct
 */

#define MPM_SYSHUB_SOC_TLB3_31_REG_SIZE         32
#define MPM_SYSHUB_SOC_TLB3_31_ARUSER_SIZE  6
#define MPM_SYSHUB_SOC_TLB3_31_WUSER_SIZE  4

#define MPM_SYSHUB_SOC_TLB3_31_ARUSER_SHIFT  0
#define MPM_SYSHUB_SOC_TLB3_31_WUSER_SHIFT  6

#define MPM_SYSHUB_SOC_TLB3_31_ARUSER_MASK  0x0000003f
#define MPM_SYSHUB_SOC_TLB3_31_WUSER_MASK  0x000003c0

#define MPM_SYSHUB_SOC_TLB3_31_MASK \
      (MPM_SYSHUB_SOC_TLB3_31_ARUSER_MASK | \
      MPM_SYSHUB_SOC_TLB3_31_WUSER_MASK)

#define MPM_SYSHUB_SOC_TLB3_31_DEFAULT 0x00000000

#define MPM_SYSHUB_SOC_TLB3_31_GET_ARUSER(mpm_syshub_soc_tlb3_31) \
      ((mpm_syshub_soc_tlb3_31 & MPM_SYSHUB_SOC_TLB3_31_ARUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_31_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_31_GET_WUSER(mpm_syshub_soc_tlb3_31) \
      ((mpm_syshub_soc_tlb3_31 & MPM_SYSHUB_SOC_TLB3_31_WUSER_MASK) >> MPM_SYSHUB_SOC_TLB3_31_WUSER_SHIFT)

#define MPM_SYSHUB_SOC_TLB3_31_SET_ARUSER(mpm_syshub_soc_tlb3_31_reg, aruser) \
      mpm_syshub_soc_tlb3_31_reg = (mpm_syshub_soc_tlb3_31_reg & ~MPM_SYSHUB_SOC_TLB3_31_ARUSER_MASK) | (aruser << MPM_SYSHUB_SOC_TLB3_31_ARUSER_SHIFT)
#define MPM_SYSHUB_SOC_TLB3_31_SET_WUSER(mpm_syshub_soc_tlb3_31_reg, wuser) \
      mpm_syshub_soc_tlb3_31_reg = (mpm_syshub_soc_tlb3_31_reg & ~MPM_SYSHUB_SOC_TLB3_31_WUSER_MASK) | (wuser << MPM_SYSHUB_SOC_TLB3_31_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_31_t {
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_31_ARUSER_SIZE;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_31_WUSER_SIZE;
            unsigned int                                : 22;
      } mpm_syshub_soc_tlb3_31_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_soc_tlb3_31_t {
            unsigned int                                : 22;
            unsigned int wuser                          : MPM_SYSHUB_SOC_TLB3_31_WUSER_SIZE;
            unsigned int aruser                         : MPM_SYSHUB_SOC_TLB3_31_ARUSER_SIZE;
      } mpm_syshub_soc_tlb3_31_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_soc_tlb3_31_t f;
} mpm_syshub_soc_tlb3_31_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_1) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_1 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_1_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_1_reg = (mpm_syshub_tlb_sub_page_attribute_rw_1_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_1_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_1_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_1_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_1_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_2) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_2 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_2_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_2_reg = (mpm_syshub_tlb_sub_page_attribute_rw_2_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_2_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_2_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_2_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_2_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_3) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_3 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_3_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_3_reg = (mpm_syshub_tlb_sub_page_attribute_rw_3_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_3_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_3_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_3_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_3_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_4) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_4 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_4_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_4_reg = (mpm_syshub_tlb_sub_page_attribute_rw_4_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_4_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_4_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_4_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_4_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_5) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_5 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_5_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_5_reg = (mpm_syshub_tlb_sub_page_attribute_rw_5_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_5_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_5_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_5_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_5_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_6) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_6 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_6_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_6_reg = (mpm_syshub_tlb_sub_page_attribute_rw_6_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_6_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_6_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_6_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_6_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_7) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_7 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_7_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_7_reg = (mpm_syshub_tlb_sub_page_attribute_rw_7_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_7_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_7_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_7_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_7_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_8) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_8 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_8_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_8_reg = (mpm_syshub_tlb_sub_page_attribute_rw_8_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_8_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_8_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_8_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_8_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_9) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_9 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_9_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_9_reg = (mpm_syshub_tlb_sub_page_attribute_rw_9_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_9_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_9_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_9_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_9_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_10) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_10 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_10_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_10_reg = (mpm_syshub_tlb_sub_page_attribute_rw_10_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_10_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_10_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_10_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_10_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_11) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_11 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_11_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_11_reg = (mpm_syshub_tlb_sub_page_attribute_rw_11_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_11_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_11_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_11_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_11_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_12) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_12 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_12_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_12_reg = (mpm_syshub_tlb_sub_page_attribute_rw_12_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_12_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_12_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_12_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_12_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_13) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_13 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_13_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_13_reg = (mpm_syshub_tlb_sub_page_attribute_rw_13_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_13_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_13_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_13_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_13_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_14) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_14 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_14_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_14_reg = (mpm_syshub_tlb_sub_page_attribute_rw_14_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_14_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_14_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_14_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_14_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_14_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_14_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_15) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_15 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_15_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_15_reg = (mpm_syshub_tlb_sub_page_attribute_rw_15_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_15_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_15_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_15_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_15_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_15_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_15_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_16) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_16 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_16_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_16_reg = (mpm_syshub_tlb_sub_page_attribute_rw_16_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_16_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_16_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_16_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_16_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_16_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_16_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_16_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_17) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_17 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_17_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_17_reg = (mpm_syshub_tlb_sub_page_attribute_rw_17_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_17_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_17_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_17_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_17_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_17_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_17_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_17_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_18) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_18 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_18_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_18_reg = (mpm_syshub_tlb_sub_page_attribute_rw_18_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_18_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_18_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_18_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_18_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_18_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_18_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_18_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_19) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_19 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_19_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_19_reg = (mpm_syshub_tlb_sub_page_attribute_rw_19_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_19_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_19_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_19_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_19_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_19_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_19_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_19_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_20) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_20 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_20_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_20_reg = (mpm_syshub_tlb_sub_page_attribute_rw_20_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_20_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_20_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_20_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_20_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_20_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_20_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_20_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_21) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_21 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_21_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_21_reg = (mpm_syshub_tlb_sub_page_attribute_rw_21_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_21_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_21_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_21_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_21_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_21_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_21_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_21_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_22) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_22 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_22_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_22_reg = (mpm_syshub_tlb_sub_page_attribute_rw_22_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_22_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_22_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_22_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_22_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_22_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_22_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_22_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_23) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_23 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_23_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_23_reg = (mpm_syshub_tlb_sub_page_attribute_rw_23_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_23_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_23_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_23_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_23_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_23_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_23_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_23_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_24) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_24 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_24_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_24_reg = (mpm_syshub_tlb_sub_page_attribute_rw_24_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_24_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_24_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_24_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_24_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_24_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_24_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_24_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_25) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_25 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_25_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_25_reg = (mpm_syshub_tlb_sub_page_attribute_rw_25_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_25_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_25_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_25_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_25_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_25_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_25_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_25_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_26) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_26 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_26_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_26_reg = (mpm_syshub_tlb_sub_page_attribute_rw_26_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_26_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_26_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_26_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_26_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_26_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_26_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_26_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_27) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_27 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_27_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_27_reg = (mpm_syshub_tlb_sub_page_attribute_rw_27_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_27_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_27_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_27_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_27_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_27_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_27_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_27_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_28) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_28 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_28_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_28_reg = (mpm_syshub_tlb_sub_page_attribute_rw_28_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_28_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_28_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_28_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_28_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_28_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_28_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_28_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_29) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_29 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_29_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_29_reg = (mpm_syshub_tlb_sub_page_attribute_rw_29_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_29_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_29_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_29_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_29_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_29_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_29_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_29_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_30) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_30 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_30_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_30_reg = (mpm_syshub_tlb_sub_page_attribute_rw_30_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_30_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_30_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_30_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_30_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_30_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_30_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_30_u;


/*
 * MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31 struct
 */

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_REG_SIZE         32
#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_RW_ATTRIB_SIZE  32

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_RW_ATTRIB_SHIFT  0

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_RW_ATTRIB_MASK  0xffffffff

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_MASK \
      (MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_RW_ATTRIB_MASK)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_GET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_31) \
      ((mpm_syshub_tlb_sub_page_attribute_rw_31 & MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_RW_ATTRIB_MASK) >> MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_RW_ATTRIB_SHIFT)

#define MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_SET_RW_ATTRIB(mpm_syshub_tlb_sub_page_attribute_rw_31_reg, rw_attrib) \
      mpm_syshub_tlb_sub_page_attribute_rw_31_reg = (mpm_syshub_tlb_sub_page_attribute_rw_31_reg & ~MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_RW_ATTRIB_MASK) | (rw_attrib << MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_31_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_31_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_sub_page_attribute_rw_31_t {
            unsigned int rw_attrib                      : MPM_SYSHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_31_RW_ATTRIB_SIZE;
      } mpm_syshub_tlb_sub_page_attribute_rw_31_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_sub_page_attribute_rw_31_t f;
} mpm_syshub_tlb_sub_page_attribute_rw_31_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_1 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_1_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_1_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_1_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_1_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_1) \
      ((mpm_syshub_tlb_attribute_1 & MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_1) \
      ((mpm_syshub_tlb_attribute_1 & MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_1) \
      ((mpm_syshub_tlb_attribute_1 & MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_1) \
      ((mpm_syshub_tlb_attribute_1 & MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_1) \
      ((mpm_syshub_tlb_attribute_1 & MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_1_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_1_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_1_reg = (mpm_syshub_tlb_attribute_1_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_1_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_1_reg = (mpm_syshub_tlb_attribute_1_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_1_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_1_reg = (mpm_syshub_tlb_attribute_1_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_1_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_1_reg = (mpm_syshub_tlb_attribute_1_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_1_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_1_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_1_reg = (mpm_syshub_tlb_attribute_1_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_1_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_1_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_1_t f;
} mpm_syshub_tlb_attribute_1_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_2 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_2_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_2_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_2_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_2_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_2) \
      ((mpm_syshub_tlb_attribute_2 & MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_2) \
      ((mpm_syshub_tlb_attribute_2 & MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_2) \
      ((mpm_syshub_tlb_attribute_2 & MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_2) \
      ((mpm_syshub_tlb_attribute_2 & MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_2) \
      ((mpm_syshub_tlb_attribute_2 & MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_2_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_2_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_2_reg = (mpm_syshub_tlb_attribute_2_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_2_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_2_reg = (mpm_syshub_tlb_attribute_2_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_2_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_2_reg = (mpm_syshub_tlb_attribute_2_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_2_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_2_reg = (mpm_syshub_tlb_attribute_2_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_2_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_2_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_2_reg = (mpm_syshub_tlb_attribute_2_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_2_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_2_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_2_t f;
} mpm_syshub_tlb_attribute_2_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_3 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_3_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_3_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_3_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_3_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_3) \
      ((mpm_syshub_tlb_attribute_3 & MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_3) \
      ((mpm_syshub_tlb_attribute_3 & MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_3) \
      ((mpm_syshub_tlb_attribute_3 & MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_3) \
      ((mpm_syshub_tlb_attribute_3 & MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_3) \
      ((mpm_syshub_tlb_attribute_3 & MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_3_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_3_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_3_reg = (mpm_syshub_tlb_attribute_3_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_3_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_3_reg = (mpm_syshub_tlb_attribute_3_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_3_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_3_reg = (mpm_syshub_tlb_attribute_3_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_3_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_3_reg = (mpm_syshub_tlb_attribute_3_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_3_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_3_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_3_reg = (mpm_syshub_tlb_attribute_3_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_3_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_3_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_3_t f;
} mpm_syshub_tlb_attribute_3_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_4 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_4_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_4_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_4_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_4_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_4) \
      ((mpm_syshub_tlb_attribute_4 & MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_4) \
      ((mpm_syshub_tlb_attribute_4 & MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_4) \
      ((mpm_syshub_tlb_attribute_4 & MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_4) \
      ((mpm_syshub_tlb_attribute_4 & MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_4) \
      ((mpm_syshub_tlb_attribute_4 & MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_4_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_4_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_4_reg = (mpm_syshub_tlb_attribute_4_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_4_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_4_reg = (mpm_syshub_tlb_attribute_4_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_4_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_4_reg = (mpm_syshub_tlb_attribute_4_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_4_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_4_reg = (mpm_syshub_tlb_attribute_4_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_4_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_4_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_4_reg = (mpm_syshub_tlb_attribute_4_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_4_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_4_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_4_t f;
} mpm_syshub_tlb_attribute_4_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_5 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_5_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_5_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_5_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_5_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_5) \
      ((mpm_syshub_tlb_attribute_5 & MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_5) \
      ((mpm_syshub_tlb_attribute_5 & MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_5) \
      ((mpm_syshub_tlb_attribute_5 & MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_5) \
      ((mpm_syshub_tlb_attribute_5 & MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_5) \
      ((mpm_syshub_tlb_attribute_5 & MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_5_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_5_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_5_reg = (mpm_syshub_tlb_attribute_5_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_5_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_5_reg = (mpm_syshub_tlb_attribute_5_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_5_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_5_reg = (mpm_syshub_tlb_attribute_5_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_5_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_5_reg = (mpm_syshub_tlb_attribute_5_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_5_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_5_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_5_reg = (mpm_syshub_tlb_attribute_5_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_5_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_5_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_5_t f;
} mpm_syshub_tlb_attribute_5_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_6 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_6_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_6_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_6_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_6_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_6) \
      ((mpm_syshub_tlb_attribute_6 & MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_6) \
      ((mpm_syshub_tlb_attribute_6 & MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_6) \
      ((mpm_syshub_tlb_attribute_6 & MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_6) \
      ((mpm_syshub_tlb_attribute_6 & MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_6) \
      ((mpm_syshub_tlb_attribute_6 & MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_6_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_6_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_6_reg = (mpm_syshub_tlb_attribute_6_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_6_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_6_reg = (mpm_syshub_tlb_attribute_6_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_6_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_6_reg = (mpm_syshub_tlb_attribute_6_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_6_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_6_reg = (mpm_syshub_tlb_attribute_6_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_6_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_6_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_6_reg = (mpm_syshub_tlb_attribute_6_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_6_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_6_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_6_t f;
} mpm_syshub_tlb_attribute_6_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_7 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_7_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_7_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_7_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_7_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_7) \
      ((mpm_syshub_tlb_attribute_7 & MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_7) \
      ((mpm_syshub_tlb_attribute_7 & MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_7) \
      ((mpm_syshub_tlb_attribute_7 & MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_7) \
      ((mpm_syshub_tlb_attribute_7 & MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_7) \
      ((mpm_syshub_tlb_attribute_7 & MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_7_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_7_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_7_reg = (mpm_syshub_tlb_attribute_7_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_7_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_7_reg = (mpm_syshub_tlb_attribute_7_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_7_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_7_reg = (mpm_syshub_tlb_attribute_7_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_7_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_7_reg = (mpm_syshub_tlb_attribute_7_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_7_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_7_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_7_reg = (mpm_syshub_tlb_attribute_7_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_7_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_7_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_7_t f;
} mpm_syshub_tlb_attribute_7_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_8 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_8_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_8_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_8_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_8_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_8) \
      ((mpm_syshub_tlb_attribute_8 & MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_8) \
      ((mpm_syshub_tlb_attribute_8 & MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_8) \
      ((mpm_syshub_tlb_attribute_8 & MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_8) \
      ((mpm_syshub_tlb_attribute_8 & MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_8) \
      ((mpm_syshub_tlb_attribute_8 & MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_8_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_8_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_8_reg = (mpm_syshub_tlb_attribute_8_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_8_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_8_reg = (mpm_syshub_tlb_attribute_8_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_8_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_8_reg = (mpm_syshub_tlb_attribute_8_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_8_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_8_reg = (mpm_syshub_tlb_attribute_8_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_8_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_8_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_8_reg = (mpm_syshub_tlb_attribute_8_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_8_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_8_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_8_t f;
} mpm_syshub_tlb_attribute_8_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_9 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_9_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_9_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_9_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_9_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_9) \
      ((mpm_syshub_tlb_attribute_9 & MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_9) \
      ((mpm_syshub_tlb_attribute_9 & MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_9) \
      ((mpm_syshub_tlb_attribute_9 & MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_9) \
      ((mpm_syshub_tlb_attribute_9 & MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_9) \
      ((mpm_syshub_tlb_attribute_9 & MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_9_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_9_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_9_reg = (mpm_syshub_tlb_attribute_9_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_9_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_9_reg = (mpm_syshub_tlb_attribute_9_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_9_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_9_reg = (mpm_syshub_tlb_attribute_9_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_9_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_9_reg = (mpm_syshub_tlb_attribute_9_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_9_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_9_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_9_reg = (mpm_syshub_tlb_attribute_9_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_9_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_9_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_9_t f;
} mpm_syshub_tlb_attribute_9_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_10 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_10_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_10_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_10_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_10_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_10) \
      ((mpm_syshub_tlb_attribute_10 & MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_10) \
      ((mpm_syshub_tlb_attribute_10 & MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_10) \
      ((mpm_syshub_tlb_attribute_10 & MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_10) \
      ((mpm_syshub_tlb_attribute_10 & MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_10) \
      ((mpm_syshub_tlb_attribute_10 & MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_10_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_10_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_10_reg = (mpm_syshub_tlb_attribute_10_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_10_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_10_reg = (mpm_syshub_tlb_attribute_10_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_10_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_10_reg = (mpm_syshub_tlb_attribute_10_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_10_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_10_reg = (mpm_syshub_tlb_attribute_10_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_10_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_10_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_10_reg = (mpm_syshub_tlb_attribute_10_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_10_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_10_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_10_t f;
} mpm_syshub_tlb_attribute_10_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_11 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_11_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_11_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_11_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_11_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_11) \
      ((mpm_syshub_tlb_attribute_11 & MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_11) \
      ((mpm_syshub_tlb_attribute_11 & MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_11) \
      ((mpm_syshub_tlb_attribute_11 & MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_11) \
      ((mpm_syshub_tlb_attribute_11 & MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_11) \
      ((mpm_syshub_tlb_attribute_11 & MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_11_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_11_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_11_reg = (mpm_syshub_tlb_attribute_11_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_11_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_11_reg = (mpm_syshub_tlb_attribute_11_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_11_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_11_reg = (mpm_syshub_tlb_attribute_11_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_11_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_11_reg = (mpm_syshub_tlb_attribute_11_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_11_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_11_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_11_reg = (mpm_syshub_tlb_attribute_11_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_11_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_11_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_11_t f;
} mpm_syshub_tlb_attribute_11_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_12 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_12_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_12_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_12_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_12_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_12) \
      ((mpm_syshub_tlb_attribute_12 & MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_12) \
      ((mpm_syshub_tlb_attribute_12 & MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_12) \
      ((mpm_syshub_tlb_attribute_12 & MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_12) \
      ((mpm_syshub_tlb_attribute_12 & MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_12) \
      ((mpm_syshub_tlb_attribute_12 & MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_12_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_12_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_12_reg = (mpm_syshub_tlb_attribute_12_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_12_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_12_reg = (mpm_syshub_tlb_attribute_12_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_12_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_12_reg = (mpm_syshub_tlb_attribute_12_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_12_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_12_reg = (mpm_syshub_tlb_attribute_12_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_12_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_12_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_12_reg = (mpm_syshub_tlb_attribute_12_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_12_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_12_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_12_t f;
} mpm_syshub_tlb_attribute_12_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_13 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_13_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_13_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_13_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_13_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_13) \
      ((mpm_syshub_tlb_attribute_13 & MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_13) \
      ((mpm_syshub_tlb_attribute_13 & MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_13) \
      ((mpm_syshub_tlb_attribute_13 & MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_13) \
      ((mpm_syshub_tlb_attribute_13 & MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_13) \
      ((mpm_syshub_tlb_attribute_13 & MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_13_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_13_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_13_reg = (mpm_syshub_tlb_attribute_13_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_13_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_13_reg = (mpm_syshub_tlb_attribute_13_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_13_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_13_reg = (mpm_syshub_tlb_attribute_13_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_13_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_13_reg = (mpm_syshub_tlb_attribute_13_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_13_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_13_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_13_reg = (mpm_syshub_tlb_attribute_13_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_13_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_13_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_13_t f;
} mpm_syshub_tlb_attribute_13_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_14 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_14_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_14_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_14_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_14_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_14) \
      ((mpm_syshub_tlb_attribute_14 & MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_14) \
      ((mpm_syshub_tlb_attribute_14 & MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_14) \
      ((mpm_syshub_tlb_attribute_14 & MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_14) \
      ((mpm_syshub_tlb_attribute_14 & MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_14) \
      ((mpm_syshub_tlb_attribute_14 & MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_14_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_14_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_14_reg = (mpm_syshub_tlb_attribute_14_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_14_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_14_reg = (mpm_syshub_tlb_attribute_14_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_14_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_14_reg = (mpm_syshub_tlb_attribute_14_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_14_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_14_reg = (mpm_syshub_tlb_attribute_14_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_14_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_14_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_14_reg = (mpm_syshub_tlb_attribute_14_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_14_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_14_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_14_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_14_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_14_t f;
} mpm_syshub_tlb_attribute_14_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_15 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_15_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_15_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_15_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_15_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_15) \
      ((mpm_syshub_tlb_attribute_15 & MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_15) \
      ((mpm_syshub_tlb_attribute_15 & MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_15) \
      ((mpm_syshub_tlb_attribute_15 & MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_15) \
      ((mpm_syshub_tlb_attribute_15 & MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_15) \
      ((mpm_syshub_tlb_attribute_15 & MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_15_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_15_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_15_reg = (mpm_syshub_tlb_attribute_15_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_15_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_15_reg = (mpm_syshub_tlb_attribute_15_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_15_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_15_reg = (mpm_syshub_tlb_attribute_15_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_15_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_15_reg = (mpm_syshub_tlb_attribute_15_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_15_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_15_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_15_reg = (mpm_syshub_tlb_attribute_15_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_15_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_15_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_15_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_15_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_15_t f;
} mpm_syshub_tlb_attribute_15_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_16 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_16_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_16_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_16_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_16_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_16) \
      ((mpm_syshub_tlb_attribute_16 & MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_16) \
      ((mpm_syshub_tlb_attribute_16 & MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_16) \
      ((mpm_syshub_tlb_attribute_16 & MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_16) \
      ((mpm_syshub_tlb_attribute_16 & MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_16) \
      ((mpm_syshub_tlb_attribute_16 & MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_16_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_16_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_16_reg = (mpm_syshub_tlb_attribute_16_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_16_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_16_reg = (mpm_syshub_tlb_attribute_16_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_16_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_16_reg = (mpm_syshub_tlb_attribute_16_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_16_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_16_reg = (mpm_syshub_tlb_attribute_16_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_16_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_16_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_16_reg = (mpm_syshub_tlb_attribute_16_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_16_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_16_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_16_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_16_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_16_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_16_t f;
} mpm_syshub_tlb_attribute_16_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_17 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_17_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_17_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_17_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_17_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_17) \
      ((mpm_syshub_tlb_attribute_17 & MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_17) \
      ((mpm_syshub_tlb_attribute_17 & MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_17) \
      ((mpm_syshub_tlb_attribute_17 & MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_17) \
      ((mpm_syshub_tlb_attribute_17 & MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_17) \
      ((mpm_syshub_tlb_attribute_17 & MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_17_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_17_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_17_reg = (mpm_syshub_tlb_attribute_17_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_17_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_17_reg = (mpm_syshub_tlb_attribute_17_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_17_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_17_reg = (mpm_syshub_tlb_attribute_17_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_17_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_17_reg = (mpm_syshub_tlb_attribute_17_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_17_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_17_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_17_reg = (mpm_syshub_tlb_attribute_17_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_17_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_17_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_17_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_17_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_17_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_17_t f;
} mpm_syshub_tlb_attribute_17_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_18 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_18_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_18_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_18_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_18_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_18) \
      ((mpm_syshub_tlb_attribute_18 & MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_18) \
      ((mpm_syshub_tlb_attribute_18 & MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_18) \
      ((mpm_syshub_tlb_attribute_18 & MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_18) \
      ((mpm_syshub_tlb_attribute_18 & MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_18) \
      ((mpm_syshub_tlb_attribute_18 & MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_18_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_18_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_18_reg = (mpm_syshub_tlb_attribute_18_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_18_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_18_reg = (mpm_syshub_tlb_attribute_18_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_18_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_18_reg = (mpm_syshub_tlb_attribute_18_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_18_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_18_reg = (mpm_syshub_tlb_attribute_18_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_18_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_18_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_18_reg = (mpm_syshub_tlb_attribute_18_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_18_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_18_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_18_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_18_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_18_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_18_t f;
} mpm_syshub_tlb_attribute_18_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_19 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_19_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_19_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_19_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_19_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_19) \
      ((mpm_syshub_tlb_attribute_19 & MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_19) \
      ((mpm_syshub_tlb_attribute_19 & MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_19) \
      ((mpm_syshub_tlb_attribute_19 & MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_19) \
      ((mpm_syshub_tlb_attribute_19 & MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_19) \
      ((mpm_syshub_tlb_attribute_19 & MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_19_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_19_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_19_reg = (mpm_syshub_tlb_attribute_19_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_19_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_19_reg = (mpm_syshub_tlb_attribute_19_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_19_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_19_reg = (mpm_syshub_tlb_attribute_19_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_19_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_19_reg = (mpm_syshub_tlb_attribute_19_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_19_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_19_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_19_reg = (mpm_syshub_tlb_attribute_19_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_19_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_19_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_19_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_19_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_19_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_19_t f;
} mpm_syshub_tlb_attribute_19_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_20 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_20_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_20_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_20_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_20_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_20) \
      ((mpm_syshub_tlb_attribute_20 & MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_20) \
      ((mpm_syshub_tlb_attribute_20 & MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_20) \
      ((mpm_syshub_tlb_attribute_20 & MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_20) \
      ((mpm_syshub_tlb_attribute_20 & MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_20) \
      ((mpm_syshub_tlb_attribute_20 & MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_20_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_20_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_20_reg = (mpm_syshub_tlb_attribute_20_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_20_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_20_reg = (mpm_syshub_tlb_attribute_20_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_20_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_20_reg = (mpm_syshub_tlb_attribute_20_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_20_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_20_reg = (mpm_syshub_tlb_attribute_20_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_20_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_20_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_20_reg = (mpm_syshub_tlb_attribute_20_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_20_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_20_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_20_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_20_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_20_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_20_t f;
} mpm_syshub_tlb_attribute_20_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_21 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_21_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_21_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_21_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_21_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_21) \
      ((mpm_syshub_tlb_attribute_21 & MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_21) \
      ((mpm_syshub_tlb_attribute_21 & MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_21) \
      ((mpm_syshub_tlb_attribute_21 & MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_21) \
      ((mpm_syshub_tlb_attribute_21 & MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_21) \
      ((mpm_syshub_tlb_attribute_21 & MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_21_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_21_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_21_reg = (mpm_syshub_tlb_attribute_21_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_21_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_21_reg = (mpm_syshub_tlb_attribute_21_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_21_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_21_reg = (mpm_syshub_tlb_attribute_21_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_21_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_21_reg = (mpm_syshub_tlb_attribute_21_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_21_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_21_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_21_reg = (mpm_syshub_tlb_attribute_21_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_21_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_21_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_21_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_21_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_21_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_21_t f;
} mpm_syshub_tlb_attribute_21_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_22 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_22_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_22_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_22_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_22_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_22) \
      ((mpm_syshub_tlb_attribute_22 & MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_22) \
      ((mpm_syshub_tlb_attribute_22 & MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_22) \
      ((mpm_syshub_tlb_attribute_22 & MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_22) \
      ((mpm_syshub_tlb_attribute_22 & MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_22) \
      ((mpm_syshub_tlb_attribute_22 & MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_22_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_22_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_22_reg = (mpm_syshub_tlb_attribute_22_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_22_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_22_reg = (mpm_syshub_tlb_attribute_22_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_22_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_22_reg = (mpm_syshub_tlb_attribute_22_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_22_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_22_reg = (mpm_syshub_tlb_attribute_22_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_22_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_22_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_22_reg = (mpm_syshub_tlb_attribute_22_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_22_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_22_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_22_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_22_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_22_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_22_t f;
} mpm_syshub_tlb_attribute_22_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_23 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_23_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_23_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_23_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_23_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_23) \
      ((mpm_syshub_tlb_attribute_23 & MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_23) \
      ((mpm_syshub_tlb_attribute_23 & MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_23) \
      ((mpm_syshub_tlb_attribute_23 & MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_23) \
      ((mpm_syshub_tlb_attribute_23 & MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_23) \
      ((mpm_syshub_tlb_attribute_23 & MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_23_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_23_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_23_reg = (mpm_syshub_tlb_attribute_23_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_23_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_23_reg = (mpm_syshub_tlb_attribute_23_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_23_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_23_reg = (mpm_syshub_tlb_attribute_23_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_23_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_23_reg = (mpm_syshub_tlb_attribute_23_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_23_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_23_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_23_reg = (mpm_syshub_tlb_attribute_23_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_23_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_23_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_23_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_23_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_23_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_23_t f;
} mpm_syshub_tlb_attribute_23_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_24 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_24_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_24_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_24_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_24_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_24) \
      ((mpm_syshub_tlb_attribute_24 & MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_24) \
      ((mpm_syshub_tlb_attribute_24 & MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_24) \
      ((mpm_syshub_tlb_attribute_24 & MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_24) \
      ((mpm_syshub_tlb_attribute_24 & MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_24) \
      ((mpm_syshub_tlb_attribute_24 & MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_24_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_24_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_24_reg = (mpm_syshub_tlb_attribute_24_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_24_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_24_reg = (mpm_syshub_tlb_attribute_24_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_24_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_24_reg = (mpm_syshub_tlb_attribute_24_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_24_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_24_reg = (mpm_syshub_tlb_attribute_24_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_24_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_24_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_24_reg = (mpm_syshub_tlb_attribute_24_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_24_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_24_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_24_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_24_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_24_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_24_t f;
} mpm_syshub_tlb_attribute_24_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_25 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_25_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_25_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_25_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_25_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_25) \
      ((mpm_syshub_tlb_attribute_25 & MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_25) \
      ((mpm_syshub_tlb_attribute_25 & MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_25) \
      ((mpm_syshub_tlb_attribute_25 & MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_25) \
      ((mpm_syshub_tlb_attribute_25 & MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_25) \
      ((mpm_syshub_tlb_attribute_25 & MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_25_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_25_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_25_reg = (mpm_syshub_tlb_attribute_25_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_25_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_25_reg = (mpm_syshub_tlb_attribute_25_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_25_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_25_reg = (mpm_syshub_tlb_attribute_25_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_25_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_25_reg = (mpm_syshub_tlb_attribute_25_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_25_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_25_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_25_reg = (mpm_syshub_tlb_attribute_25_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_25_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_25_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_25_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_25_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_25_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_25_t f;
} mpm_syshub_tlb_attribute_25_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_26 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_26_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_26_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_26_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_26_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_26) \
      ((mpm_syshub_tlb_attribute_26 & MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_26) \
      ((mpm_syshub_tlb_attribute_26 & MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_26) \
      ((mpm_syshub_tlb_attribute_26 & MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_26) \
      ((mpm_syshub_tlb_attribute_26 & MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_26) \
      ((mpm_syshub_tlb_attribute_26 & MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_26_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_26_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_26_reg = (mpm_syshub_tlb_attribute_26_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_26_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_26_reg = (mpm_syshub_tlb_attribute_26_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_26_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_26_reg = (mpm_syshub_tlb_attribute_26_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_26_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_26_reg = (mpm_syshub_tlb_attribute_26_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_26_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_26_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_26_reg = (mpm_syshub_tlb_attribute_26_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_26_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_26_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_26_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_26_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_26_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_26_t f;
} mpm_syshub_tlb_attribute_26_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_27 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_27_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_27_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_27_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_27_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_27) \
      ((mpm_syshub_tlb_attribute_27 & MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_27) \
      ((mpm_syshub_tlb_attribute_27 & MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_27) \
      ((mpm_syshub_tlb_attribute_27 & MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_27) \
      ((mpm_syshub_tlb_attribute_27 & MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_27) \
      ((mpm_syshub_tlb_attribute_27 & MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_27_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_27_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_27_reg = (mpm_syshub_tlb_attribute_27_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_27_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_27_reg = (mpm_syshub_tlb_attribute_27_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_27_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_27_reg = (mpm_syshub_tlb_attribute_27_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_27_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_27_reg = (mpm_syshub_tlb_attribute_27_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_27_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_27_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_27_reg = (mpm_syshub_tlb_attribute_27_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_27_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_27_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_27_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_27_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_27_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_27_t f;
} mpm_syshub_tlb_attribute_27_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_28 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_28_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_28_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_28_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_28_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_28) \
      ((mpm_syshub_tlb_attribute_28 & MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_28) \
      ((mpm_syshub_tlb_attribute_28 & MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_28) \
      ((mpm_syshub_tlb_attribute_28 & MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_28) \
      ((mpm_syshub_tlb_attribute_28 & MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_28) \
      ((mpm_syshub_tlb_attribute_28 & MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_28_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_28_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_28_reg = (mpm_syshub_tlb_attribute_28_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_28_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_28_reg = (mpm_syshub_tlb_attribute_28_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_28_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_28_reg = (mpm_syshub_tlb_attribute_28_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_28_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_28_reg = (mpm_syshub_tlb_attribute_28_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_28_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_28_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_28_reg = (mpm_syshub_tlb_attribute_28_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_28_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_28_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_28_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_28_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_28_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_28_t f;
} mpm_syshub_tlb_attribute_28_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_29 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_29_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_29_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_29_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_29_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_29) \
      ((mpm_syshub_tlb_attribute_29 & MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_29) \
      ((mpm_syshub_tlb_attribute_29 & MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_29) \
      ((mpm_syshub_tlb_attribute_29 & MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_29) \
      ((mpm_syshub_tlb_attribute_29 & MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_29) \
      ((mpm_syshub_tlb_attribute_29 & MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_29_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_29_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_29_reg = (mpm_syshub_tlb_attribute_29_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_29_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_29_reg = (mpm_syshub_tlb_attribute_29_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_29_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_29_reg = (mpm_syshub_tlb_attribute_29_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_29_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_29_reg = (mpm_syshub_tlb_attribute_29_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_29_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_29_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_29_reg = (mpm_syshub_tlb_attribute_29_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_29_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_29_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_29_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_29_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_29_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_29_t f;
} mpm_syshub_tlb_attribute_29_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_30 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_30_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_30_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_30_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_30_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_30) \
      ((mpm_syshub_tlb_attribute_30 & MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_30) \
      ((mpm_syshub_tlb_attribute_30 & MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_30) \
      ((mpm_syshub_tlb_attribute_30 & MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_30) \
      ((mpm_syshub_tlb_attribute_30 & MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_30) \
      ((mpm_syshub_tlb_attribute_30 & MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_30_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_30_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_30_reg = (mpm_syshub_tlb_attribute_30_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_30_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_30_reg = (mpm_syshub_tlb_attribute_30_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_30_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_30_reg = (mpm_syshub_tlb_attribute_30_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_30_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_30_reg = (mpm_syshub_tlb_attribute_30_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_30_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_30_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_30_reg = (mpm_syshub_tlb_attribute_30_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_30_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_30_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_30_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_30_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_30_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_30_t f;
} mpm_syshub_tlb_attribute_30_u;


/*
 * MPM_SYSHUB_TLB_ATTRIBUTE_31 struct
 */

#define MPM_SYSHUB_TLB_ATTRIBUTE_31_REG_SIZE         32
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_ARPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AWPROT_1_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_DMA_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PUB_SIZE  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PRIV_SIZE  1

#define MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_ARPROT_1_SHIFT  0
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AWPROT_1_SHIFT  1
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_DMA_SHIFT  24
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PUB_SHIFT  30
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PRIV_SHIFT  31

#define MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_ARPROT_1_MASK  0x00000001
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AWPROT_1_MASK  0x00000002
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_DMA_MASK  0x01000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PUB_MASK  0x40000000
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PRIV_MASK  0x80000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_31_MASK \
      (MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_ARPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AWPROT_1_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_DMA_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PUB_MASK | \
      MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PRIV_MASK)

#define MPM_SYSHUB_TLB_ATTRIBUTE_31_DEFAULT 0x00000000

#define MPM_SYSHUB_TLB_ATTRIBUTE_31_GET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_31) \
      ((mpm_syshub_tlb_attribute_31 & MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_ARPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_GET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_31) \
      ((mpm_syshub_tlb_attribute_31 & MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AWPROT_1_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_GET_MA_PSP_DMA(mpm_syshub_tlb_attribute_31) \
      ((mpm_syshub_tlb_attribute_31 & MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_DMA_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_GET_MA_PSP_PUB(mpm_syshub_tlb_attribute_31) \
      ((mpm_syshub_tlb_attribute_31 & MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PUB_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_GET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_31) \
      ((mpm_syshub_tlb_attribute_31 & MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PRIV_MASK) >> MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PRIV_SHIFT)

#define MPM_SYSHUB_TLB_ATTRIBUTE_31_SET_MA_PSP_ARPROT_1(mpm_syshub_tlb_attribute_31_reg, ma_psp_arprot_1) \
      mpm_syshub_tlb_attribute_31_reg = (mpm_syshub_tlb_attribute_31_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_ARPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_SET_MA_PSP_AWPROT_1(mpm_syshub_tlb_attribute_31_reg, ma_psp_awprot_1) \
      mpm_syshub_tlb_attribute_31_reg = (mpm_syshub_tlb_attribute_31_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AWPROT_1_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_SET_MA_PSP_DMA(mpm_syshub_tlb_attribute_31_reg, ma_psp_dma) \
      mpm_syshub_tlb_attribute_31_reg = (mpm_syshub_tlb_attribute_31_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_DMA_MASK) | (ma_psp_dma << MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_DMA_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_SET_MA_PSP_PUB(mpm_syshub_tlb_attribute_31_reg, ma_psp_pub) \
      mpm_syshub_tlb_attribute_31_reg = (mpm_syshub_tlb_attribute_31_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PUB_MASK) | (ma_psp_pub << MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PUB_SHIFT)
#define MPM_SYSHUB_TLB_ATTRIBUTE_31_SET_MA_PSP_PRIV(mpm_syshub_tlb_attribute_31_reg, ma_psp_priv) \
      mpm_syshub_tlb_attribute_31_reg = (mpm_syshub_tlb_attribute_31_reg & ~MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PRIV_MASK) | (ma_psp_priv << MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_31_t {
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PRIV_SIZE;
      } mpm_syshub_tlb_attribute_31_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_tlb_attribute_31_t {
            unsigned int ma_psp_priv                    : MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MPM_SYSHUB_TLB_ATTRIBUTE_31_MA_PSP_ARPROT_1_SIZE;
      } mpm_syshub_tlb_attribute_31_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_tlb_attribute_31_t f;
} mpm_syshub_tlb_attribute_31_u;


/*
 * MPM_SYSHUB_INT_STATUS struct
 */

#define MPM_SYSHUB_INT_STATUS_REG_SIZE         32
#define MPM_SYSHUB_INT_STATUS_RD_ERROR_SIZE  1
#define MPM_SYSHUB_INT_STATUS_WR_ERROR_SIZE  1
#define MPM_SYSHUB_INT_STATUS_REG_ERROR_SIZE  1

#define MPM_SYSHUB_INT_STATUS_RD_ERROR_SHIFT  0
#define MPM_SYSHUB_INT_STATUS_WR_ERROR_SHIFT  1
#define MPM_SYSHUB_INT_STATUS_REG_ERROR_SHIFT  2

#define MPM_SYSHUB_INT_STATUS_RD_ERROR_MASK  0x00000001
#define MPM_SYSHUB_INT_STATUS_WR_ERROR_MASK  0x00000002
#define MPM_SYSHUB_INT_STATUS_REG_ERROR_MASK  0x00000004

#define MPM_SYSHUB_INT_STATUS_MASK \
      (MPM_SYSHUB_INT_STATUS_RD_ERROR_MASK | \
      MPM_SYSHUB_INT_STATUS_WR_ERROR_MASK | \
      MPM_SYSHUB_INT_STATUS_REG_ERROR_MASK)

#define MPM_SYSHUB_INT_STATUS_DEFAULT  0x00000000

#define MPM_SYSHUB_INT_STATUS_GET_RD_ERROR(mpm_syshub_int_status) \
      ((mpm_syshub_int_status & MPM_SYSHUB_INT_STATUS_RD_ERROR_MASK) >> MPM_SYSHUB_INT_STATUS_RD_ERROR_SHIFT)
#define MPM_SYSHUB_INT_STATUS_GET_WR_ERROR(mpm_syshub_int_status) \
      ((mpm_syshub_int_status & MPM_SYSHUB_INT_STATUS_WR_ERROR_MASK) >> MPM_SYSHUB_INT_STATUS_WR_ERROR_SHIFT)
#define MPM_SYSHUB_INT_STATUS_GET_REG_ERROR(mpm_syshub_int_status) \
      ((mpm_syshub_int_status & MPM_SYSHUB_INT_STATUS_REG_ERROR_MASK) >> MPM_SYSHUB_INT_STATUS_REG_ERROR_SHIFT)

#define MPM_SYSHUB_INT_STATUS_SET_RD_ERROR(mpm_syshub_int_status_reg, rd_error) \
      mpm_syshub_int_status_reg = (mpm_syshub_int_status_reg & ~MPM_SYSHUB_INT_STATUS_RD_ERROR_MASK) | (rd_error << MPM_SYSHUB_INT_STATUS_RD_ERROR_SHIFT)
#define MPM_SYSHUB_INT_STATUS_SET_WR_ERROR(mpm_syshub_int_status_reg, wr_error) \
      mpm_syshub_int_status_reg = (mpm_syshub_int_status_reg & ~MPM_SYSHUB_INT_STATUS_WR_ERROR_MASK) | (wr_error << MPM_SYSHUB_INT_STATUS_WR_ERROR_SHIFT)
#define MPM_SYSHUB_INT_STATUS_SET_REG_ERROR(mpm_syshub_int_status_reg, reg_error) \
      mpm_syshub_int_status_reg = (mpm_syshub_int_status_reg & ~MPM_SYSHUB_INT_STATUS_REG_ERROR_MASK) | (reg_error << MPM_SYSHUB_INT_STATUS_REG_ERROR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_int_status_t {
            unsigned int rd_error                       : MPM_SYSHUB_INT_STATUS_RD_ERROR_SIZE;
            unsigned int wr_error                       : MPM_SYSHUB_INT_STATUS_WR_ERROR_SIZE;
            unsigned int reg_error                      : MPM_SYSHUB_INT_STATUS_REG_ERROR_SIZE;
            unsigned int                                : 29;
      } mpm_syshub_int_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_int_status_t {
            unsigned int                                : 29;
            unsigned int reg_error                      : MPM_SYSHUB_INT_STATUS_REG_ERROR_SIZE;
            unsigned int wr_error                       : MPM_SYSHUB_INT_STATUS_WR_ERROR_SIZE;
            unsigned int rd_error                       : MPM_SYSHUB_INT_STATUS_RD_ERROR_SIZE;
      } mpm_syshub_int_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_int_status_t f;
} mpm_syshub_int_status_u;


/*
 * MPM_SYSHUB_WR_INT_ADDR struct
 */

#define MPM_SYSHUB_WR_INT_ADDR_REG_SIZE         32
#define MPM_SYSHUB_WR_INT_ADDR_ADDR_SIZE  32

#define MPM_SYSHUB_WR_INT_ADDR_ADDR_SHIFT  0

#define MPM_SYSHUB_WR_INT_ADDR_ADDR_MASK  0xffffffff

#define MPM_SYSHUB_WR_INT_ADDR_MASK \
      (MPM_SYSHUB_WR_INT_ADDR_ADDR_MASK)

#define MPM_SYSHUB_WR_INT_ADDR_DEFAULT 0x00000000

#define MPM_SYSHUB_WR_INT_ADDR_GET_ADDR(mpm_syshub_wr_int_addr) \
      ((mpm_syshub_wr_int_addr & MPM_SYSHUB_WR_INT_ADDR_ADDR_MASK) >> MPM_SYSHUB_WR_INT_ADDR_ADDR_SHIFT)

#define MPM_SYSHUB_WR_INT_ADDR_SET_ADDR(mpm_syshub_wr_int_addr_reg, addr) \
      mpm_syshub_wr_int_addr_reg = (mpm_syshub_wr_int_addr_reg & ~MPM_SYSHUB_WR_INT_ADDR_ADDR_MASK) | (addr << MPM_SYSHUB_WR_INT_ADDR_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_wr_int_addr_t {
            unsigned int addr                           : MPM_SYSHUB_WR_INT_ADDR_ADDR_SIZE;
      } mpm_syshub_wr_int_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_wr_int_addr_t {
            unsigned int addr                           : MPM_SYSHUB_WR_INT_ADDR_ADDR_SIZE;
      } mpm_syshub_wr_int_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_wr_int_addr_t f;
} mpm_syshub_wr_int_addr_u;


/*
 * MPM_SYSHUB_WR_INT_ID struct
 */

#define MPM_SYSHUB_WR_INT_ID_REG_SIZE         32
#define MPM_SYSHUB_WR_INT_ID_AXI_ID_SIZE  21

#define MPM_SYSHUB_WR_INT_ID_AXI_ID_SHIFT  0

#define MPM_SYSHUB_WR_INT_ID_AXI_ID_MASK  0x001fffff

#define MPM_SYSHUB_WR_INT_ID_MASK \
      (MPM_SYSHUB_WR_INT_ID_AXI_ID_MASK)

#define MPM_SYSHUB_WR_INT_ID_DEFAULT   0x00000000

#define MPM_SYSHUB_WR_INT_ID_GET_AXI_ID(mpm_syshub_wr_int_id) \
      ((mpm_syshub_wr_int_id & MPM_SYSHUB_WR_INT_ID_AXI_ID_MASK) >> MPM_SYSHUB_WR_INT_ID_AXI_ID_SHIFT)

#define MPM_SYSHUB_WR_INT_ID_SET_AXI_ID(mpm_syshub_wr_int_id_reg, axi_id) \
      mpm_syshub_wr_int_id_reg = (mpm_syshub_wr_int_id_reg & ~MPM_SYSHUB_WR_INT_ID_AXI_ID_MASK) | (axi_id << MPM_SYSHUB_WR_INT_ID_AXI_ID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_wr_int_id_t {
            unsigned int axi_id                         : MPM_SYSHUB_WR_INT_ID_AXI_ID_SIZE;
            unsigned int                                : 11;
      } mpm_syshub_wr_int_id_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_wr_int_id_t {
            unsigned int                                : 11;
            unsigned int axi_id                         : MPM_SYSHUB_WR_INT_ID_AXI_ID_SIZE;
      } mpm_syshub_wr_int_id_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_wr_int_id_t f;
} mpm_syshub_wr_int_id_u;


/*
 * MPM_SYSHUB_MISC_CTRL struct
 */

#define MPM_SYSHUB_MISC_CTRL_REG_SIZE         32
#define MPM_SYSHUB_MISC_CTRL_CLK_GATE_EN_SIZE  1
#define MPM_SYSHUB_MISC_CTRL_REG_CLK_STS_SIZE  1

#define MPM_SYSHUB_MISC_CTRL_CLK_GATE_EN_SHIFT  0
#define MPM_SYSHUB_MISC_CTRL_REG_CLK_STS_SHIFT  8

#define MPM_SYSHUB_MISC_CTRL_CLK_GATE_EN_MASK  0x00000001
#define MPM_SYSHUB_MISC_CTRL_REG_CLK_STS_MASK  0x00000100

#define MPM_SYSHUB_MISC_CTRL_MASK \
      (MPM_SYSHUB_MISC_CTRL_CLK_GATE_EN_MASK | \
      MPM_SYSHUB_MISC_CTRL_REG_CLK_STS_MASK)

#define MPM_SYSHUB_MISC_CTRL_DEFAULT   0x00000101

#define MPM_SYSHUB_MISC_CTRL_GET_CLK_GATE_EN(mpm_syshub_misc_ctrl) \
      ((mpm_syshub_misc_ctrl & MPM_SYSHUB_MISC_CTRL_CLK_GATE_EN_MASK) >> MPM_SYSHUB_MISC_CTRL_CLK_GATE_EN_SHIFT)
#define MPM_SYSHUB_MISC_CTRL_GET_REG_CLK_STS(mpm_syshub_misc_ctrl) \
      ((mpm_syshub_misc_ctrl & MPM_SYSHUB_MISC_CTRL_REG_CLK_STS_MASK) >> MPM_SYSHUB_MISC_CTRL_REG_CLK_STS_SHIFT)

#define MPM_SYSHUB_MISC_CTRL_SET_CLK_GATE_EN(mpm_syshub_misc_ctrl_reg, clk_gate_en) \
      mpm_syshub_misc_ctrl_reg = (mpm_syshub_misc_ctrl_reg & ~MPM_SYSHUB_MISC_CTRL_CLK_GATE_EN_MASK) | (clk_gate_en << MPM_SYSHUB_MISC_CTRL_CLK_GATE_EN_SHIFT)
#define MPM_SYSHUB_MISC_CTRL_SET_REG_CLK_STS(mpm_syshub_misc_ctrl_reg, reg_clk_sts) \
      mpm_syshub_misc_ctrl_reg = (mpm_syshub_misc_ctrl_reg & ~MPM_SYSHUB_MISC_CTRL_REG_CLK_STS_MASK) | (reg_clk_sts << MPM_SYSHUB_MISC_CTRL_REG_CLK_STS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_misc_ctrl_t {
            unsigned int clk_gate_en                    : MPM_SYSHUB_MISC_CTRL_CLK_GATE_EN_SIZE;
            unsigned int                                : 7;
            unsigned int reg_clk_sts                    : MPM_SYSHUB_MISC_CTRL_REG_CLK_STS_SIZE;
            unsigned int                                : 23;
      } mpm_syshub_misc_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_misc_ctrl_t {
            unsigned int                                : 23;
            unsigned int reg_clk_sts                    : MPM_SYSHUB_MISC_CTRL_REG_CLK_STS_SIZE;
            unsigned int                                : 7;
            unsigned int clk_gate_en                    : MPM_SYSHUB_MISC_CTRL_CLK_GATE_EN_SIZE;
      } mpm_syshub_misc_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_misc_ctrl_t f;
} mpm_syshub_misc_ctrl_u;


/*
 * MPM_SYSHUB_WR_INT_OTHER struct
 */

#define MPM_SYSHUB_WR_INT_OTHER_REG_SIZE         32
#define MPM_SYSHUB_WR_INT_OTHER_ERROR_TLB_SIZE  1
#define MPM_SYSHUB_WR_INT_OTHER_ERROR_PAGE_SIZE  1
#define MPM_SYSHUB_WR_INT_OTHER_ERROR_ATTRIB_SIZE  1
#define MPM_SYSHUB_WR_INT_OTHER_ERROR_PROT_SIZE  1
#define MPM_SYSHUB_WR_INT_OTHER_ERROR_MST_SIZE  1
#define MPM_SYSHUB_WR_INT_OTHER_INT_CLEAR_SIZE  1

#define MPM_SYSHUB_WR_INT_OTHER_ERROR_TLB_SHIFT  0
#define MPM_SYSHUB_WR_INT_OTHER_ERROR_PAGE_SHIFT  1
#define MPM_SYSHUB_WR_INT_OTHER_ERROR_ATTRIB_SHIFT  2
#define MPM_SYSHUB_WR_INT_OTHER_ERROR_PROT_SHIFT  3
#define MPM_SYSHUB_WR_INT_OTHER_ERROR_MST_SHIFT  4
#define MPM_SYSHUB_WR_INT_OTHER_INT_CLEAR_SHIFT  31

#define MPM_SYSHUB_WR_INT_OTHER_ERROR_TLB_MASK  0x00000001
#define MPM_SYSHUB_WR_INT_OTHER_ERROR_PAGE_MASK  0x00000002
#define MPM_SYSHUB_WR_INT_OTHER_ERROR_ATTRIB_MASK  0x00000004
#define MPM_SYSHUB_WR_INT_OTHER_ERROR_PROT_MASK  0x00000008
#define MPM_SYSHUB_WR_INT_OTHER_ERROR_MST_MASK  0x00000010
#define MPM_SYSHUB_WR_INT_OTHER_INT_CLEAR_MASK  0x80000000

#define MPM_SYSHUB_WR_INT_OTHER_MASK \
      (MPM_SYSHUB_WR_INT_OTHER_ERROR_TLB_MASK | \
      MPM_SYSHUB_WR_INT_OTHER_ERROR_PAGE_MASK | \
      MPM_SYSHUB_WR_INT_OTHER_ERROR_ATTRIB_MASK | \
      MPM_SYSHUB_WR_INT_OTHER_ERROR_PROT_MASK | \
      MPM_SYSHUB_WR_INT_OTHER_ERROR_MST_MASK | \
      MPM_SYSHUB_WR_INT_OTHER_INT_CLEAR_MASK)

#define MPM_SYSHUB_WR_INT_OTHER_DEFAULT 0x00000000

#define MPM_SYSHUB_WR_INT_OTHER_GET_ERROR_TLB(mpm_syshub_wr_int_other) \
      ((mpm_syshub_wr_int_other & MPM_SYSHUB_WR_INT_OTHER_ERROR_TLB_MASK) >> MPM_SYSHUB_WR_INT_OTHER_ERROR_TLB_SHIFT)
#define MPM_SYSHUB_WR_INT_OTHER_GET_ERROR_PAGE(mpm_syshub_wr_int_other) \
      ((mpm_syshub_wr_int_other & MPM_SYSHUB_WR_INT_OTHER_ERROR_PAGE_MASK) >> MPM_SYSHUB_WR_INT_OTHER_ERROR_PAGE_SHIFT)
#define MPM_SYSHUB_WR_INT_OTHER_GET_ERROR_ATTRIB(mpm_syshub_wr_int_other) \
      ((mpm_syshub_wr_int_other & MPM_SYSHUB_WR_INT_OTHER_ERROR_ATTRIB_MASK) >> MPM_SYSHUB_WR_INT_OTHER_ERROR_ATTRIB_SHIFT)
#define MPM_SYSHUB_WR_INT_OTHER_GET_ERROR_PROT(mpm_syshub_wr_int_other) \
      ((mpm_syshub_wr_int_other & MPM_SYSHUB_WR_INT_OTHER_ERROR_PROT_MASK) >> MPM_SYSHUB_WR_INT_OTHER_ERROR_PROT_SHIFT)
#define MPM_SYSHUB_WR_INT_OTHER_GET_ERROR_MST(mpm_syshub_wr_int_other) \
      ((mpm_syshub_wr_int_other & MPM_SYSHUB_WR_INT_OTHER_ERROR_MST_MASK) >> MPM_SYSHUB_WR_INT_OTHER_ERROR_MST_SHIFT)
#define MPM_SYSHUB_WR_INT_OTHER_GET_INT_CLEAR(mpm_syshub_wr_int_other) \
      ((mpm_syshub_wr_int_other & MPM_SYSHUB_WR_INT_OTHER_INT_CLEAR_MASK) >> MPM_SYSHUB_WR_INT_OTHER_INT_CLEAR_SHIFT)

#define MPM_SYSHUB_WR_INT_OTHER_SET_ERROR_TLB(mpm_syshub_wr_int_other_reg, error_tlb) \
      mpm_syshub_wr_int_other_reg = (mpm_syshub_wr_int_other_reg & ~MPM_SYSHUB_WR_INT_OTHER_ERROR_TLB_MASK) | (error_tlb << MPM_SYSHUB_WR_INT_OTHER_ERROR_TLB_SHIFT)
#define MPM_SYSHUB_WR_INT_OTHER_SET_ERROR_PAGE(mpm_syshub_wr_int_other_reg, error_page) \
      mpm_syshub_wr_int_other_reg = (mpm_syshub_wr_int_other_reg & ~MPM_SYSHUB_WR_INT_OTHER_ERROR_PAGE_MASK) | (error_page << MPM_SYSHUB_WR_INT_OTHER_ERROR_PAGE_SHIFT)
#define MPM_SYSHUB_WR_INT_OTHER_SET_ERROR_ATTRIB(mpm_syshub_wr_int_other_reg, error_attrib) \
      mpm_syshub_wr_int_other_reg = (mpm_syshub_wr_int_other_reg & ~MPM_SYSHUB_WR_INT_OTHER_ERROR_ATTRIB_MASK) | (error_attrib << MPM_SYSHUB_WR_INT_OTHER_ERROR_ATTRIB_SHIFT)
#define MPM_SYSHUB_WR_INT_OTHER_SET_ERROR_PROT(mpm_syshub_wr_int_other_reg, error_prot) \
      mpm_syshub_wr_int_other_reg = (mpm_syshub_wr_int_other_reg & ~MPM_SYSHUB_WR_INT_OTHER_ERROR_PROT_MASK) | (error_prot << MPM_SYSHUB_WR_INT_OTHER_ERROR_PROT_SHIFT)
#define MPM_SYSHUB_WR_INT_OTHER_SET_ERROR_MST(mpm_syshub_wr_int_other_reg, error_mst) \
      mpm_syshub_wr_int_other_reg = (mpm_syshub_wr_int_other_reg & ~MPM_SYSHUB_WR_INT_OTHER_ERROR_MST_MASK) | (error_mst << MPM_SYSHUB_WR_INT_OTHER_ERROR_MST_SHIFT)
#define MPM_SYSHUB_WR_INT_OTHER_SET_INT_CLEAR(mpm_syshub_wr_int_other_reg, int_clear) \
      mpm_syshub_wr_int_other_reg = (mpm_syshub_wr_int_other_reg & ~MPM_SYSHUB_WR_INT_OTHER_INT_CLEAR_MASK) | (int_clear << MPM_SYSHUB_WR_INT_OTHER_INT_CLEAR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_wr_int_other_t {
            unsigned int error_tlb                      : MPM_SYSHUB_WR_INT_OTHER_ERROR_TLB_SIZE;
            unsigned int error_page                     : MPM_SYSHUB_WR_INT_OTHER_ERROR_PAGE_SIZE;
            unsigned int error_attrib                   : MPM_SYSHUB_WR_INT_OTHER_ERROR_ATTRIB_SIZE;
            unsigned int error_prot                     : MPM_SYSHUB_WR_INT_OTHER_ERROR_PROT_SIZE;
            unsigned int error_mst                      : MPM_SYSHUB_WR_INT_OTHER_ERROR_MST_SIZE;
            unsigned int                                : 26;
            unsigned int int_clear                      : MPM_SYSHUB_WR_INT_OTHER_INT_CLEAR_SIZE;
      } mpm_syshub_wr_int_other_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_wr_int_other_t {
            unsigned int int_clear                      : MPM_SYSHUB_WR_INT_OTHER_INT_CLEAR_SIZE;
            unsigned int                                : 26;
            unsigned int error_mst                      : MPM_SYSHUB_WR_INT_OTHER_ERROR_MST_SIZE;
            unsigned int error_prot                     : MPM_SYSHUB_WR_INT_OTHER_ERROR_PROT_SIZE;
            unsigned int error_attrib                   : MPM_SYSHUB_WR_INT_OTHER_ERROR_ATTRIB_SIZE;
            unsigned int error_page                     : MPM_SYSHUB_WR_INT_OTHER_ERROR_PAGE_SIZE;
            unsigned int error_tlb                      : MPM_SYSHUB_WR_INT_OTHER_ERROR_TLB_SIZE;
      } mpm_syshub_wr_int_other_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_wr_int_other_t f;
} mpm_syshub_wr_int_other_u;


/*
 * MPM_SYSHUB_RD_INT_ADDR struct
 */

#define MPM_SYSHUB_RD_INT_ADDR_REG_SIZE         32
#define MPM_SYSHUB_RD_INT_ADDR_ADDR_SIZE  32

#define MPM_SYSHUB_RD_INT_ADDR_ADDR_SHIFT  0

#define MPM_SYSHUB_RD_INT_ADDR_ADDR_MASK  0xffffffff

#define MPM_SYSHUB_RD_INT_ADDR_MASK \
      (MPM_SYSHUB_RD_INT_ADDR_ADDR_MASK)

#define MPM_SYSHUB_RD_INT_ADDR_DEFAULT 0x00000000

#define MPM_SYSHUB_RD_INT_ADDR_GET_ADDR(mpm_syshub_rd_int_addr) \
      ((mpm_syshub_rd_int_addr & MPM_SYSHUB_RD_INT_ADDR_ADDR_MASK) >> MPM_SYSHUB_RD_INT_ADDR_ADDR_SHIFT)

#define MPM_SYSHUB_RD_INT_ADDR_SET_ADDR(mpm_syshub_rd_int_addr_reg, addr) \
      mpm_syshub_rd_int_addr_reg = (mpm_syshub_rd_int_addr_reg & ~MPM_SYSHUB_RD_INT_ADDR_ADDR_MASK) | (addr << MPM_SYSHUB_RD_INT_ADDR_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_rd_int_addr_t {
            unsigned int addr                           : MPM_SYSHUB_RD_INT_ADDR_ADDR_SIZE;
      } mpm_syshub_rd_int_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_rd_int_addr_t {
            unsigned int addr                           : MPM_SYSHUB_RD_INT_ADDR_ADDR_SIZE;
      } mpm_syshub_rd_int_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_rd_int_addr_t f;
} mpm_syshub_rd_int_addr_u;


/*
 * MPM_SYSHUB_RD_INT_ID struct
 */

#define MPM_SYSHUB_RD_INT_ID_REG_SIZE         32
#define MPM_SYSHUB_RD_INT_ID_AXI_ID_SIZE  21

#define MPM_SYSHUB_RD_INT_ID_AXI_ID_SHIFT  0

#define MPM_SYSHUB_RD_INT_ID_AXI_ID_MASK  0x001fffff

#define MPM_SYSHUB_RD_INT_ID_MASK \
      (MPM_SYSHUB_RD_INT_ID_AXI_ID_MASK)

#define MPM_SYSHUB_RD_INT_ID_DEFAULT   0x00000000

#define MPM_SYSHUB_RD_INT_ID_GET_AXI_ID(mpm_syshub_rd_int_id) \
      ((mpm_syshub_rd_int_id & MPM_SYSHUB_RD_INT_ID_AXI_ID_MASK) >> MPM_SYSHUB_RD_INT_ID_AXI_ID_SHIFT)

#define MPM_SYSHUB_RD_INT_ID_SET_AXI_ID(mpm_syshub_rd_int_id_reg, axi_id) \
      mpm_syshub_rd_int_id_reg = (mpm_syshub_rd_int_id_reg & ~MPM_SYSHUB_RD_INT_ID_AXI_ID_MASK) | (axi_id << MPM_SYSHUB_RD_INT_ID_AXI_ID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_rd_int_id_t {
            unsigned int axi_id                         : MPM_SYSHUB_RD_INT_ID_AXI_ID_SIZE;
            unsigned int                                : 11;
      } mpm_syshub_rd_int_id_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_rd_int_id_t {
            unsigned int                                : 11;
            unsigned int axi_id                         : MPM_SYSHUB_RD_INT_ID_AXI_ID_SIZE;
      } mpm_syshub_rd_int_id_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_rd_int_id_t f;
} mpm_syshub_rd_int_id_u;


/*
 * MPM_SYSHUB_RD_INT_OTHER struct
 */

#define MPM_SYSHUB_RD_INT_OTHER_REG_SIZE         32
#define MPM_SYSHUB_RD_INT_OTHER_ERROR_TLB_SIZE  1
#define MPM_SYSHUB_RD_INT_OTHER_ERROR_PAGE_SIZE  1
#define MPM_SYSHUB_RD_INT_OTHER_ERROR_ATTRIB_SIZE  1
#define MPM_SYSHUB_RD_INT_OTHER_ERROR_PROT_SIZE  1
#define MPM_SYSHUB_RD_INT_OTHER_ERROR_MST_SIZE  1
#define MPM_SYSHUB_RD_INT_OTHER_ERROR_LENGTH_SIZE  1
#define MPM_SYSHUB_RD_INT_OTHER_INT_CLEAR_SIZE  1

#define MPM_SYSHUB_RD_INT_OTHER_ERROR_TLB_SHIFT  0
#define MPM_SYSHUB_RD_INT_OTHER_ERROR_PAGE_SHIFT  1
#define MPM_SYSHUB_RD_INT_OTHER_ERROR_ATTRIB_SHIFT  2
#define MPM_SYSHUB_RD_INT_OTHER_ERROR_PROT_SHIFT  3
#define MPM_SYSHUB_RD_INT_OTHER_ERROR_MST_SHIFT  4
#define MPM_SYSHUB_RD_INT_OTHER_ERROR_LENGTH_SHIFT  6
#define MPM_SYSHUB_RD_INT_OTHER_INT_CLEAR_SHIFT  31

#define MPM_SYSHUB_RD_INT_OTHER_ERROR_TLB_MASK  0x00000001
#define MPM_SYSHUB_RD_INT_OTHER_ERROR_PAGE_MASK  0x00000002
#define MPM_SYSHUB_RD_INT_OTHER_ERROR_ATTRIB_MASK  0x00000004
#define MPM_SYSHUB_RD_INT_OTHER_ERROR_PROT_MASK  0x00000008
#define MPM_SYSHUB_RD_INT_OTHER_ERROR_MST_MASK  0x00000010
#define MPM_SYSHUB_RD_INT_OTHER_ERROR_LENGTH_MASK  0x00000040
#define MPM_SYSHUB_RD_INT_OTHER_INT_CLEAR_MASK  0x80000000

#define MPM_SYSHUB_RD_INT_OTHER_MASK \
      (MPM_SYSHUB_RD_INT_OTHER_ERROR_TLB_MASK | \
      MPM_SYSHUB_RD_INT_OTHER_ERROR_PAGE_MASK | \
      MPM_SYSHUB_RD_INT_OTHER_ERROR_ATTRIB_MASK | \
      MPM_SYSHUB_RD_INT_OTHER_ERROR_PROT_MASK | \
      MPM_SYSHUB_RD_INT_OTHER_ERROR_MST_MASK | \
      MPM_SYSHUB_RD_INT_OTHER_ERROR_LENGTH_MASK | \
      MPM_SYSHUB_RD_INT_OTHER_INT_CLEAR_MASK)

#define MPM_SYSHUB_RD_INT_OTHER_DEFAULT 0x00000000

#define MPM_SYSHUB_RD_INT_OTHER_GET_ERROR_TLB(mpm_syshub_rd_int_other) \
      ((mpm_syshub_rd_int_other & MPM_SYSHUB_RD_INT_OTHER_ERROR_TLB_MASK) >> MPM_SYSHUB_RD_INT_OTHER_ERROR_TLB_SHIFT)
#define MPM_SYSHUB_RD_INT_OTHER_GET_ERROR_PAGE(mpm_syshub_rd_int_other) \
      ((mpm_syshub_rd_int_other & MPM_SYSHUB_RD_INT_OTHER_ERROR_PAGE_MASK) >> MPM_SYSHUB_RD_INT_OTHER_ERROR_PAGE_SHIFT)
#define MPM_SYSHUB_RD_INT_OTHER_GET_ERROR_ATTRIB(mpm_syshub_rd_int_other) \
      ((mpm_syshub_rd_int_other & MPM_SYSHUB_RD_INT_OTHER_ERROR_ATTRIB_MASK) >> MPM_SYSHUB_RD_INT_OTHER_ERROR_ATTRIB_SHIFT)
#define MPM_SYSHUB_RD_INT_OTHER_GET_ERROR_PROT(mpm_syshub_rd_int_other) \
      ((mpm_syshub_rd_int_other & MPM_SYSHUB_RD_INT_OTHER_ERROR_PROT_MASK) >> MPM_SYSHUB_RD_INT_OTHER_ERROR_PROT_SHIFT)
#define MPM_SYSHUB_RD_INT_OTHER_GET_ERROR_MST(mpm_syshub_rd_int_other) \
      ((mpm_syshub_rd_int_other & MPM_SYSHUB_RD_INT_OTHER_ERROR_MST_MASK) >> MPM_SYSHUB_RD_INT_OTHER_ERROR_MST_SHIFT)
#define MPM_SYSHUB_RD_INT_OTHER_GET_ERROR_LENGTH(mpm_syshub_rd_int_other) \
      ((mpm_syshub_rd_int_other & MPM_SYSHUB_RD_INT_OTHER_ERROR_LENGTH_MASK) >> MPM_SYSHUB_RD_INT_OTHER_ERROR_LENGTH_SHIFT)
#define MPM_SYSHUB_RD_INT_OTHER_GET_INT_CLEAR(mpm_syshub_rd_int_other) \
      ((mpm_syshub_rd_int_other & MPM_SYSHUB_RD_INT_OTHER_INT_CLEAR_MASK) >> MPM_SYSHUB_RD_INT_OTHER_INT_CLEAR_SHIFT)

#define MPM_SYSHUB_RD_INT_OTHER_SET_ERROR_TLB(mpm_syshub_rd_int_other_reg, error_tlb) \
      mpm_syshub_rd_int_other_reg = (mpm_syshub_rd_int_other_reg & ~MPM_SYSHUB_RD_INT_OTHER_ERROR_TLB_MASK) | (error_tlb << MPM_SYSHUB_RD_INT_OTHER_ERROR_TLB_SHIFT)
#define MPM_SYSHUB_RD_INT_OTHER_SET_ERROR_PAGE(mpm_syshub_rd_int_other_reg, error_page) \
      mpm_syshub_rd_int_other_reg = (mpm_syshub_rd_int_other_reg & ~MPM_SYSHUB_RD_INT_OTHER_ERROR_PAGE_MASK) | (error_page << MPM_SYSHUB_RD_INT_OTHER_ERROR_PAGE_SHIFT)
#define MPM_SYSHUB_RD_INT_OTHER_SET_ERROR_ATTRIB(mpm_syshub_rd_int_other_reg, error_attrib) \
      mpm_syshub_rd_int_other_reg = (mpm_syshub_rd_int_other_reg & ~MPM_SYSHUB_RD_INT_OTHER_ERROR_ATTRIB_MASK) | (error_attrib << MPM_SYSHUB_RD_INT_OTHER_ERROR_ATTRIB_SHIFT)
#define MPM_SYSHUB_RD_INT_OTHER_SET_ERROR_PROT(mpm_syshub_rd_int_other_reg, error_prot) \
      mpm_syshub_rd_int_other_reg = (mpm_syshub_rd_int_other_reg & ~MPM_SYSHUB_RD_INT_OTHER_ERROR_PROT_MASK) | (error_prot << MPM_SYSHUB_RD_INT_OTHER_ERROR_PROT_SHIFT)
#define MPM_SYSHUB_RD_INT_OTHER_SET_ERROR_MST(mpm_syshub_rd_int_other_reg, error_mst) \
      mpm_syshub_rd_int_other_reg = (mpm_syshub_rd_int_other_reg & ~MPM_SYSHUB_RD_INT_OTHER_ERROR_MST_MASK) | (error_mst << MPM_SYSHUB_RD_INT_OTHER_ERROR_MST_SHIFT)
#define MPM_SYSHUB_RD_INT_OTHER_SET_ERROR_LENGTH(mpm_syshub_rd_int_other_reg, error_length) \
      mpm_syshub_rd_int_other_reg = (mpm_syshub_rd_int_other_reg & ~MPM_SYSHUB_RD_INT_OTHER_ERROR_LENGTH_MASK) | (error_length << MPM_SYSHUB_RD_INT_OTHER_ERROR_LENGTH_SHIFT)
#define MPM_SYSHUB_RD_INT_OTHER_SET_INT_CLEAR(mpm_syshub_rd_int_other_reg, int_clear) \
      mpm_syshub_rd_int_other_reg = (mpm_syshub_rd_int_other_reg & ~MPM_SYSHUB_RD_INT_OTHER_INT_CLEAR_MASK) | (int_clear << MPM_SYSHUB_RD_INT_OTHER_INT_CLEAR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_rd_int_other_t {
            unsigned int error_tlb                      : MPM_SYSHUB_RD_INT_OTHER_ERROR_TLB_SIZE;
            unsigned int error_page                     : MPM_SYSHUB_RD_INT_OTHER_ERROR_PAGE_SIZE;
            unsigned int error_attrib                   : MPM_SYSHUB_RD_INT_OTHER_ERROR_ATTRIB_SIZE;
            unsigned int error_prot                     : MPM_SYSHUB_RD_INT_OTHER_ERROR_PROT_SIZE;
            unsigned int error_mst                      : MPM_SYSHUB_RD_INT_OTHER_ERROR_MST_SIZE;
            unsigned int                                : 1;
            unsigned int error_length                   : MPM_SYSHUB_RD_INT_OTHER_ERROR_LENGTH_SIZE;
            unsigned int                                : 24;
            unsigned int int_clear                      : MPM_SYSHUB_RD_INT_OTHER_INT_CLEAR_SIZE;
      } mpm_syshub_rd_int_other_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_rd_int_other_t {
            unsigned int int_clear                      : MPM_SYSHUB_RD_INT_OTHER_INT_CLEAR_SIZE;
            unsigned int                                : 24;
            unsigned int error_length                   : MPM_SYSHUB_RD_INT_OTHER_ERROR_LENGTH_SIZE;
            unsigned int                                : 1;
            unsigned int error_mst                      : MPM_SYSHUB_RD_INT_OTHER_ERROR_MST_SIZE;
            unsigned int error_prot                     : MPM_SYSHUB_RD_INT_OTHER_ERROR_PROT_SIZE;
            unsigned int error_attrib                   : MPM_SYSHUB_RD_INT_OTHER_ERROR_ATTRIB_SIZE;
            unsigned int error_page                     : MPM_SYSHUB_RD_INT_OTHER_ERROR_PAGE_SIZE;
            unsigned int error_tlb                      : MPM_SYSHUB_RD_INT_OTHER_ERROR_TLB_SIZE;
      } mpm_syshub_rd_int_other_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_rd_int_other_t f;
} mpm_syshub_rd_int_other_u;


/*
 * MPM_SYSHUB_REG_INT_ADDR struct
 */

#define MPM_SYSHUB_REG_INT_ADDR_REG_SIZE         32
#define MPM_SYSHUB_REG_INT_ADDR_ADDR_SIZE  16

#define MPM_SYSHUB_REG_INT_ADDR_ADDR_SHIFT  0

#define MPM_SYSHUB_REG_INT_ADDR_ADDR_MASK  0x0000ffff

#define MPM_SYSHUB_REG_INT_ADDR_MASK \
      (MPM_SYSHUB_REG_INT_ADDR_ADDR_MASK)

#define MPM_SYSHUB_REG_INT_ADDR_DEFAULT 0x00000000

#define MPM_SYSHUB_REG_INT_ADDR_GET_ADDR(mpm_syshub_reg_int_addr) \
      ((mpm_syshub_reg_int_addr & MPM_SYSHUB_REG_INT_ADDR_ADDR_MASK) >> MPM_SYSHUB_REG_INT_ADDR_ADDR_SHIFT)

#define MPM_SYSHUB_REG_INT_ADDR_SET_ADDR(mpm_syshub_reg_int_addr_reg, addr) \
      mpm_syshub_reg_int_addr_reg = (mpm_syshub_reg_int_addr_reg & ~MPM_SYSHUB_REG_INT_ADDR_ADDR_MASK) | (addr << MPM_SYSHUB_REG_INT_ADDR_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_reg_int_addr_t {
            unsigned int addr                           : MPM_SYSHUB_REG_INT_ADDR_ADDR_SIZE;
            unsigned int                                : 16;
      } mpm_syshub_reg_int_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_reg_int_addr_t {
            unsigned int                                : 16;
            unsigned int addr                           : MPM_SYSHUB_REG_INT_ADDR_ADDR_SIZE;
      } mpm_syshub_reg_int_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_reg_int_addr_t f;
} mpm_syshub_reg_int_addr_u;


/*
 * MPM_SYSHUB_REG_INT_ID struct
 */

#define MPM_SYSHUB_REG_INT_ID_REG_SIZE         32
#define MPM_SYSHUB_REG_INT_ID_AXI_ID_SIZE  21

#define MPM_SYSHUB_REG_INT_ID_AXI_ID_SHIFT  0

#define MPM_SYSHUB_REG_INT_ID_AXI_ID_MASK  0x001fffff

#define MPM_SYSHUB_REG_INT_ID_MASK \
      (MPM_SYSHUB_REG_INT_ID_AXI_ID_MASK)

#define MPM_SYSHUB_REG_INT_ID_DEFAULT  0x00000000

#define MPM_SYSHUB_REG_INT_ID_GET_AXI_ID(mpm_syshub_reg_int_id) \
      ((mpm_syshub_reg_int_id & MPM_SYSHUB_REG_INT_ID_AXI_ID_MASK) >> MPM_SYSHUB_REG_INT_ID_AXI_ID_SHIFT)

#define MPM_SYSHUB_REG_INT_ID_SET_AXI_ID(mpm_syshub_reg_int_id_reg, axi_id) \
      mpm_syshub_reg_int_id_reg = (mpm_syshub_reg_int_id_reg & ~MPM_SYSHUB_REG_INT_ID_AXI_ID_MASK) | (axi_id << MPM_SYSHUB_REG_INT_ID_AXI_ID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_reg_int_id_t {
            unsigned int axi_id                         : MPM_SYSHUB_REG_INT_ID_AXI_ID_SIZE;
            unsigned int                                : 11;
      } mpm_syshub_reg_int_id_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_reg_int_id_t {
            unsigned int                                : 11;
            unsigned int axi_id                         : MPM_SYSHUB_REG_INT_ID_AXI_ID_SIZE;
      } mpm_syshub_reg_int_id_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_reg_int_id_t f;
} mpm_syshub_reg_int_id_u;


/*
 * MPM_SYSHUB_REG_INT_OTHER struct
 */

#define MPM_SYSHUB_REG_INT_OTHER_REG_SIZE         32
#define MPM_SYSHUB_REG_INT_OTHER_ERROR_MST_SIZE  1
#define MPM_SYSHUB_REG_INT_OTHER_ERROR_ADDR_SIZE  1
#define MPM_SYSHUB_REG_INT_OTHER_ERROR_PROT_SIZE  1
#define MPM_SYSHUB_REG_INT_OTHER_ERROR_GPU_VA_SIZE  1
#define MPM_SYSHUB_REG_INT_OTHER_ERROR_BYPASS_SIZE  1
#define MPM_SYSHUB_REG_INT_OTHER_ERROR_REQIO_SIZE  1
#define MPM_SYSHUB_REG_INT_OTHER_INT_CLEAR_SIZE  1

#define MPM_SYSHUB_REG_INT_OTHER_ERROR_MST_SHIFT  1
#define MPM_SYSHUB_REG_INT_OTHER_ERROR_ADDR_SHIFT  2
#define MPM_SYSHUB_REG_INT_OTHER_ERROR_PROT_SHIFT  3
#define MPM_SYSHUB_REG_INT_OTHER_ERROR_GPU_VA_SHIFT  5
#define MPM_SYSHUB_REG_INT_OTHER_ERROR_BYPASS_SHIFT  6
#define MPM_SYSHUB_REG_INT_OTHER_ERROR_REQIO_SHIFT  7
#define MPM_SYSHUB_REG_INT_OTHER_INT_CLEAR_SHIFT  31

#define MPM_SYSHUB_REG_INT_OTHER_ERROR_MST_MASK  0x00000002
#define MPM_SYSHUB_REG_INT_OTHER_ERROR_ADDR_MASK  0x00000004
#define MPM_SYSHUB_REG_INT_OTHER_ERROR_PROT_MASK  0x00000008
#define MPM_SYSHUB_REG_INT_OTHER_ERROR_GPU_VA_MASK  0x00000020
#define MPM_SYSHUB_REG_INT_OTHER_ERROR_BYPASS_MASK  0x00000040
#define MPM_SYSHUB_REG_INT_OTHER_ERROR_REQIO_MASK  0x00000080
#define MPM_SYSHUB_REG_INT_OTHER_INT_CLEAR_MASK  0x80000000

#define MPM_SYSHUB_REG_INT_OTHER_MASK \
      (MPM_SYSHUB_REG_INT_OTHER_ERROR_MST_MASK | \
      MPM_SYSHUB_REG_INT_OTHER_ERROR_ADDR_MASK | \
      MPM_SYSHUB_REG_INT_OTHER_ERROR_PROT_MASK | \
      MPM_SYSHUB_REG_INT_OTHER_ERROR_GPU_VA_MASK | \
      MPM_SYSHUB_REG_INT_OTHER_ERROR_BYPASS_MASK | \
      MPM_SYSHUB_REG_INT_OTHER_ERROR_REQIO_MASK | \
      MPM_SYSHUB_REG_INT_OTHER_INT_CLEAR_MASK)

#define MPM_SYSHUB_REG_INT_OTHER_DEFAULT 0x00000000

#define MPM_SYSHUB_REG_INT_OTHER_GET_ERROR_MST(mpm_syshub_reg_int_other) \
      ((mpm_syshub_reg_int_other & MPM_SYSHUB_REG_INT_OTHER_ERROR_MST_MASK) >> MPM_SYSHUB_REG_INT_OTHER_ERROR_MST_SHIFT)
#define MPM_SYSHUB_REG_INT_OTHER_GET_ERROR_ADDR(mpm_syshub_reg_int_other) \
      ((mpm_syshub_reg_int_other & MPM_SYSHUB_REG_INT_OTHER_ERROR_ADDR_MASK) >> MPM_SYSHUB_REG_INT_OTHER_ERROR_ADDR_SHIFT)
#define MPM_SYSHUB_REG_INT_OTHER_GET_ERROR_PROT(mpm_syshub_reg_int_other) \
      ((mpm_syshub_reg_int_other & MPM_SYSHUB_REG_INT_OTHER_ERROR_PROT_MASK) >> MPM_SYSHUB_REG_INT_OTHER_ERROR_PROT_SHIFT)
#define MPM_SYSHUB_REG_INT_OTHER_GET_ERROR_GPU_VA(mpm_syshub_reg_int_other) \
      ((mpm_syshub_reg_int_other & MPM_SYSHUB_REG_INT_OTHER_ERROR_GPU_VA_MASK) >> MPM_SYSHUB_REG_INT_OTHER_ERROR_GPU_VA_SHIFT)
#define MPM_SYSHUB_REG_INT_OTHER_GET_ERROR_BYPASS(mpm_syshub_reg_int_other) \
      ((mpm_syshub_reg_int_other & MPM_SYSHUB_REG_INT_OTHER_ERROR_BYPASS_MASK) >> MPM_SYSHUB_REG_INT_OTHER_ERROR_BYPASS_SHIFT)
#define MPM_SYSHUB_REG_INT_OTHER_GET_ERROR_REQIO(mpm_syshub_reg_int_other) \
      ((mpm_syshub_reg_int_other & MPM_SYSHUB_REG_INT_OTHER_ERROR_REQIO_MASK) >> MPM_SYSHUB_REG_INT_OTHER_ERROR_REQIO_SHIFT)
#define MPM_SYSHUB_REG_INT_OTHER_GET_INT_CLEAR(mpm_syshub_reg_int_other) \
      ((mpm_syshub_reg_int_other & MPM_SYSHUB_REG_INT_OTHER_INT_CLEAR_MASK) >> MPM_SYSHUB_REG_INT_OTHER_INT_CLEAR_SHIFT)

#define MPM_SYSHUB_REG_INT_OTHER_SET_ERROR_MST(mpm_syshub_reg_int_other_reg, error_mst) \
      mpm_syshub_reg_int_other_reg = (mpm_syshub_reg_int_other_reg & ~MPM_SYSHUB_REG_INT_OTHER_ERROR_MST_MASK) | (error_mst << MPM_SYSHUB_REG_INT_OTHER_ERROR_MST_SHIFT)
#define MPM_SYSHUB_REG_INT_OTHER_SET_ERROR_ADDR(mpm_syshub_reg_int_other_reg, error_addr) \
      mpm_syshub_reg_int_other_reg = (mpm_syshub_reg_int_other_reg & ~MPM_SYSHUB_REG_INT_OTHER_ERROR_ADDR_MASK) | (error_addr << MPM_SYSHUB_REG_INT_OTHER_ERROR_ADDR_SHIFT)
#define MPM_SYSHUB_REG_INT_OTHER_SET_ERROR_PROT(mpm_syshub_reg_int_other_reg, error_prot) \
      mpm_syshub_reg_int_other_reg = (mpm_syshub_reg_int_other_reg & ~MPM_SYSHUB_REG_INT_OTHER_ERROR_PROT_MASK) | (error_prot << MPM_SYSHUB_REG_INT_OTHER_ERROR_PROT_SHIFT)
#define MPM_SYSHUB_REG_INT_OTHER_SET_ERROR_GPU_VA(mpm_syshub_reg_int_other_reg, error_gpu_va) \
      mpm_syshub_reg_int_other_reg = (mpm_syshub_reg_int_other_reg & ~MPM_SYSHUB_REG_INT_OTHER_ERROR_GPU_VA_MASK) | (error_gpu_va << MPM_SYSHUB_REG_INT_OTHER_ERROR_GPU_VA_SHIFT)
#define MPM_SYSHUB_REG_INT_OTHER_SET_ERROR_BYPASS(mpm_syshub_reg_int_other_reg, error_bypass) \
      mpm_syshub_reg_int_other_reg = (mpm_syshub_reg_int_other_reg & ~MPM_SYSHUB_REG_INT_OTHER_ERROR_BYPASS_MASK) | (error_bypass << MPM_SYSHUB_REG_INT_OTHER_ERROR_BYPASS_SHIFT)
#define MPM_SYSHUB_REG_INT_OTHER_SET_ERROR_REQIO(mpm_syshub_reg_int_other_reg, error_reqio) \
      mpm_syshub_reg_int_other_reg = (mpm_syshub_reg_int_other_reg & ~MPM_SYSHUB_REG_INT_OTHER_ERROR_REQIO_MASK) | (error_reqio << MPM_SYSHUB_REG_INT_OTHER_ERROR_REQIO_SHIFT)
#define MPM_SYSHUB_REG_INT_OTHER_SET_INT_CLEAR(mpm_syshub_reg_int_other_reg, int_clear) \
      mpm_syshub_reg_int_other_reg = (mpm_syshub_reg_int_other_reg & ~MPM_SYSHUB_REG_INT_OTHER_INT_CLEAR_MASK) | (int_clear << MPM_SYSHUB_REG_INT_OTHER_INT_CLEAR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_reg_int_other_t {
            unsigned int                                : 1;
            unsigned int error_mst                      : MPM_SYSHUB_REG_INT_OTHER_ERROR_MST_SIZE;
            unsigned int error_addr                     : MPM_SYSHUB_REG_INT_OTHER_ERROR_ADDR_SIZE;
            unsigned int error_prot                     : MPM_SYSHUB_REG_INT_OTHER_ERROR_PROT_SIZE;
            unsigned int                                : 1;
            unsigned int error_gpu_va                   : MPM_SYSHUB_REG_INT_OTHER_ERROR_GPU_VA_SIZE;
            unsigned int error_bypass                   : MPM_SYSHUB_REG_INT_OTHER_ERROR_BYPASS_SIZE;
            unsigned int error_reqio                    : MPM_SYSHUB_REG_INT_OTHER_ERROR_REQIO_SIZE;
            unsigned int                                : 23;
            unsigned int int_clear                      : MPM_SYSHUB_REG_INT_OTHER_INT_CLEAR_SIZE;
      } mpm_syshub_reg_int_other_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_reg_int_other_t {
            unsigned int int_clear                      : MPM_SYSHUB_REG_INT_OTHER_INT_CLEAR_SIZE;
            unsigned int                                : 23;
            unsigned int error_reqio                    : MPM_SYSHUB_REG_INT_OTHER_ERROR_REQIO_SIZE;
            unsigned int error_bypass                   : MPM_SYSHUB_REG_INT_OTHER_ERROR_BYPASS_SIZE;
            unsigned int error_gpu_va                   : MPM_SYSHUB_REG_INT_OTHER_ERROR_GPU_VA_SIZE;
            unsigned int                                : 1;
            unsigned int error_prot                     : MPM_SYSHUB_REG_INT_OTHER_ERROR_PROT_SIZE;
            unsigned int error_addr                     : MPM_SYSHUB_REG_INT_OTHER_ERROR_ADDR_SIZE;
            unsigned int error_mst                      : MPM_SYSHUB_REG_INT_OTHER_ERROR_MST_SIZE;
            unsigned int                                : 1;
      } mpm_syshub_reg_int_other_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_reg_int_other_t f;
} mpm_syshub_reg_int_other_u;


/*
 * MPM_SYSHUB_AXCACHE_CFG struct
 */

#define MPM_SYSHUB_AXCACHE_CFG_REG_SIZE         32
#define MPM_SYSHUB_AXCACHE_CFG_ARCACHE_NONCOH_SIZE  4
#define MPM_SYSHUB_AXCACHE_CFG_ARCACHE_COH_SIZE  4
#define MPM_SYSHUB_AXCACHE_CFG_AWCACHE_NONCOH_SIZE  4
#define MPM_SYSHUB_AXCACHE_CFG_AWCACHE_COH_SIZE  4
#define MPM_SYSHUB_AXCACHE_CFG_QOSW_SIZE  4
#define MPM_SYSHUB_AXCACHE_CFG_QOSR_SIZE  4

#define MPM_SYSHUB_AXCACHE_CFG_ARCACHE_NONCOH_SHIFT  0
#define MPM_SYSHUB_AXCACHE_CFG_ARCACHE_COH_SHIFT  4
#define MPM_SYSHUB_AXCACHE_CFG_AWCACHE_NONCOH_SHIFT  8
#define MPM_SYSHUB_AXCACHE_CFG_AWCACHE_COH_SHIFT  12
#define MPM_SYSHUB_AXCACHE_CFG_QOSW_SHIFT  16
#define MPM_SYSHUB_AXCACHE_CFG_QOSR_SHIFT  20

#define MPM_SYSHUB_AXCACHE_CFG_ARCACHE_NONCOH_MASK  0x0000000f
#define MPM_SYSHUB_AXCACHE_CFG_ARCACHE_COH_MASK  0x000000f0
#define MPM_SYSHUB_AXCACHE_CFG_AWCACHE_NONCOH_MASK  0x00000f00
#define MPM_SYSHUB_AXCACHE_CFG_AWCACHE_COH_MASK  0x0000f000
#define MPM_SYSHUB_AXCACHE_CFG_QOSW_MASK  0x000f0000
#define MPM_SYSHUB_AXCACHE_CFG_QOSR_MASK  0x00f00000

#define MPM_SYSHUB_AXCACHE_CFG_MASK \
      (MPM_SYSHUB_AXCACHE_CFG_ARCACHE_NONCOH_MASK | \
      MPM_SYSHUB_AXCACHE_CFG_ARCACHE_COH_MASK | \
      MPM_SYSHUB_AXCACHE_CFG_AWCACHE_NONCOH_MASK | \
      MPM_SYSHUB_AXCACHE_CFG_AWCACHE_COH_MASK | \
      MPM_SYSHUB_AXCACHE_CFG_QOSW_MASK | \
      MPM_SYSHUB_AXCACHE_CFG_QOSR_MASK)

#define MPM_SYSHUB_AXCACHE_CFG_DEFAULT 0x000073b3

#define MPM_SYSHUB_AXCACHE_CFG_GET_ARCACHE_NONCOH(mpm_syshub_axcache_cfg) \
      ((mpm_syshub_axcache_cfg & MPM_SYSHUB_AXCACHE_CFG_ARCACHE_NONCOH_MASK) >> MPM_SYSHUB_AXCACHE_CFG_ARCACHE_NONCOH_SHIFT)
#define MPM_SYSHUB_AXCACHE_CFG_GET_ARCACHE_COH(mpm_syshub_axcache_cfg) \
      ((mpm_syshub_axcache_cfg & MPM_SYSHUB_AXCACHE_CFG_ARCACHE_COH_MASK) >> MPM_SYSHUB_AXCACHE_CFG_ARCACHE_COH_SHIFT)
#define MPM_SYSHUB_AXCACHE_CFG_GET_AWCACHE_NONCOH(mpm_syshub_axcache_cfg) \
      ((mpm_syshub_axcache_cfg & MPM_SYSHUB_AXCACHE_CFG_AWCACHE_NONCOH_MASK) >> MPM_SYSHUB_AXCACHE_CFG_AWCACHE_NONCOH_SHIFT)
#define MPM_SYSHUB_AXCACHE_CFG_GET_AWCACHE_COH(mpm_syshub_axcache_cfg) \
      ((mpm_syshub_axcache_cfg & MPM_SYSHUB_AXCACHE_CFG_AWCACHE_COH_MASK) >> MPM_SYSHUB_AXCACHE_CFG_AWCACHE_COH_SHIFT)
#define MPM_SYSHUB_AXCACHE_CFG_GET_QOSW(mpm_syshub_axcache_cfg) \
      ((mpm_syshub_axcache_cfg & MPM_SYSHUB_AXCACHE_CFG_QOSW_MASK) >> MPM_SYSHUB_AXCACHE_CFG_QOSW_SHIFT)
#define MPM_SYSHUB_AXCACHE_CFG_GET_QOSR(mpm_syshub_axcache_cfg) \
      ((mpm_syshub_axcache_cfg & MPM_SYSHUB_AXCACHE_CFG_QOSR_MASK) >> MPM_SYSHUB_AXCACHE_CFG_QOSR_SHIFT)

#define MPM_SYSHUB_AXCACHE_CFG_SET_ARCACHE_NONCOH(mpm_syshub_axcache_cfg_reg, arcache_noncoh) \
      mpm_syshub_axcache_cfg_reg = (mpm_syshub_axcache_cfg_reg & ~MPM_SYSHUB_AXCACHE_CFG_ARCACHE_NONCOH_MASK) | (arcache_noncoh << MPM_SYSHUB_AXCACHE_CFG_ARCACHE_NONCOH_SHIFT)
#define MPM_SYSHUB_AXCACHE_CFG_SET_ARCACHE_COH(mpm_syshub_axcache_cfg_reg, arcache_coh) \
      mpm_syshub_axcache_cfg_reg = (mpm_syshub_axcache_cfg_reg & ~MPM_SYSHUB_AXCACHE_CFG_ARCACHE_COH_MASK) | (arcache_coh << MPM_SYSHUB_AXCACHE_CFG_ARCACHE_COH_SHIFT)
#define MPM_SYSHUB_AXCACHE_CFG_SET_AWCACHE_NONCOH(mpm_syshub_axcache_cfg_reg, awcache_noncoh) \
      mpm_syshub_axcache_cfg_reg = (mpm_syshub_axcache_cfg_reg & ~MPM_SYSHUB_AXCACHE_CFG_AWCACHE_NONCOH_MASK) | (awcache_noncoh << MPM_SYSHUB_AXCACHE_CFG_AWCACHE_NONCOH_SHIFT)
#define MPM_SYSHUB_AXCACHE_CFG_SET_AWCACHE_COH(mpm_syshub_axcache_cfg_reg, awcache_coh) \
      mpm_syshub_axcache_cfg_reg = (mpm_syshub_axcache_cfg_reg & ~MPM_SYSHUB_AXCACHE_CFG_AWCACHE_COH_MASK) | (awcache_coh << MPM_SYSHUB_AXCACHE_CFG_AWCACHE_COH_SHIFT)
#define MPM_SYSHUB_AXCACHE_CFG_SET_QOSW(mpm_syshub_axcache_cfg_reg, qosw) \
      mpm_syshub_axcache_cfg_reg = (mpm_syshub_axcache_cfg_reg & ~MPM_SYSHUB_AXCACHE_CFG_QOSW_MASK) | (qosw << MPM_SYSHUB_AXCACHE_CFG_QOSW_SHIFT)
#define MPM_SYSHUB_AXCACHE_CFG_SET_QOSR(mpm_syshub_axcache_cfg_reg, qosr) \
      mpm_syshub_axcache_cfg_reg = (mpm_syshub_axcache_cfg_reg & ~MPM_SYSHUB_AXCACHE_CFG_QOSR_MASK) | (qosr << MPM_SYSHUB_AXCACHE_CFG_QOSR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_axcache_cfg_t {
            unsigned int arcache_noncoh                 : MPM_SYSHUB_AXCACHE_CFG_ARCACHE_NONCOH_SIZE;
            unsigned int arcache_coh                    : MPM_SYSHUB_AXCACHE_CFG_ARCACHE_COH_SIZE;
            unsigned int awcache_noncoh                 : MPM_SYSHUB_AXCACHE_CFG_AWCACHE_NONCOH_SIZE;
            unsigned int awcache_coh                    : MPM_SYSHUB_AXCACHE_CFG_AWCACHE_COH_SIZE;
            unsigned int qosw                           : MPM_SYSHUB_AXCACHE_CFG_QOSW_SIZE;
            unsigned int qosr                           : MPM_SYSHUB_AXCACHE_CFG_QOSR_SIZE;
            unsigned int                                : 8;
      } mpm_syshub_axcache_cfg_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_axcache_cfg_t {
            unsigned int                                : 8;
            unsigned int qosr                           : MPM_SYSHUB_AXCACHE_CFG_QOSR_SIZE;
            unsigned int qosw                           : MPM_SYSHUB_AXCACHE_CFG_QOSW_SIZE;
            unsigned int awcache_coh                    : MPM_SYSHUB_AXCACHE_CFG_AWCACHE_COH_SIZE;
            unsigned int awcache_noncoh                 : MPM_SYSHUB_AXCACHE_CFG_AWCACHE_NONCOH_SIZE;
            unsigned int arcache_coh                    : MPM_SYSHUB_AXCACHE_CFG_ARCACHE_COH_SIZE;
            unsigned int arcache_noncoh                 : MPM_SYSHUB_AXCACHE_CFG_ARCACHE_NONCOH_SIZE;
      } mpm_syshub_axcache_cfg_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_axcache_cfg_t f;
} mpm_syshub_axcache_cfg_u;


/*
 * MPM_SYSHUB_OUTSTANDING_WR struct
 */

#define MPM_SYSHUB_OUTSTANDING_WR_REG_SIZE         32
#define MPM_SYSHUB_OUTSTANDING_WR_PENDING_WR_SIZE  32

#define MPM_SYSHUB_OUTSTANDING_WR_PENDING_WR_SHIFT  0

#define MPM_SYSHUB_OUTSTANDING_WR_PENDING_WR_MASK  0xffffffff

#define MPM_SYSHUB_OUTSTANDING_WR_MASK \
      (MPM_SYSHUB_OUTSTANDING_WR_PENDING_WR_MASK)

#define MPM_SYSHUB_OUTSTANDING_WR_DEFAULT 0x00000000

#define MPM_SYSHUB_OUTSTANDING_WR_GET_PENDING_WR(mpm_syshub_outstanding_wr) \
      ((mpm_syshub_outstanding_wr & MPM_SYSHUB_OUTSTANDING_WR_PENDING_WR_MASK) >> MPM_SYSHUB_OUTSTANDING_WR_PENDING_WR_SHIFT)

#define MPM_SYSHUB_OUTSTANDING_WR_SET_PENDING_WR(mpm_syshub_outstanding_wr_reg, pending_wr) \
      mpm_syshub_outstanding_wr_reg = (mpm_syshub_outstanding_wr_reg & ~MPM_SYSHUB_OUTSTANDING_WR_PENDING_WR_MASK) | (pending_wr << MPM_SYSHUB_OUTSTANDING_WR_PENDING_WR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_outstanding_wr_t {
            unsigned int pending_wr                     : MPM_SYSHUB_OUTSTANDING_WR_PENDING_WR_SIZE;
      } mpm_syshub_outstanding_wr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_outstanding_wr_t {
            unsigned int pending_wr                     : MPM_SYSHUB_OUTSTANDING_WR_PENDING_WR_SIZE;
      } mpm_syshub_outstanding_wr_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_outstanding_wr_t f;
} mpm_syshub_outstanding_wr_u;


/*
 * MPM_SYSHUB_OUTSTANDING_RD struct
 */

#define MPM_SYSHUB_OUTSTANDING_RD_REG_SIZE         32
#define MPM_SYSHUB_OUTSTANDING_RD_PENDING_RD_SIZE  32

#define MPM_SYSHUB_OUTSTANDING_RD_PENDING_RD_SHIFT  0

#define MPM_SYSHUB_OUTSTANDING_RD_PENDING_RD_MASK  0xffffffff

#define MPM_SYSHUB_OUTSTANDING_RD_MASK \
      (MPM_SYSHUB_OUTSTANDING_RD_PENDING_RD_MASK)

#define MPM_SYSHUB_OUTSTANDING_RD_DEFAULT 0x00000000

#define MPM_SYSHUB_OUTSTANDING_RD_GET_PENDING_RD(mpm_syshub_outstanding_rd) \
      ((mpm_syshub_outstanding_rd & MPM_SYSHUB_OUTSTANDING_RD_PENDING_RD_MASK) >> MPM_SYSHUB_OUTSTANDING_RD_PENDING_RD_SHIFT)

#define MPM_SYSHUB_OUTSTANDING_RD_SET_PENDING_RD(mpm_syshub_outstanding_rd_reg, pending_rd) \
      mpm_syshub_outstanding_rd_reg = (mpm_syshub_outstanding_rd_reg & ~MPM_SYSHUB_OUTSTANDING_RD_PENDING_RD_MASK) | (pending_rd << MPM_SYSHUB_OUTSTANDING_RD_PENDING_RD_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_outstanding_rd_t {
            unsigned int pending_rd                     : MPM_SYSHUB_OUTSTANDING_RD_PENDING_RD_SIZE;
      } mpm_syshub_outstanding_rd_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_outstanding_rd_t {
            unsigned int pending_rd                     : MPM_SYSHUB_OUTSTANDING_RD_PENDING_RD_SIZE;
      } mpm_syshub_outstanding_rd_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_outstanding_rd_t f;
} mpm_syshub_outstanding_rd_u;


/*
 * MPM_SYSHUB_AWUSER_MASK struct
 */

#define MPM_SYSHUB_AWUSER_MASK_REG_SIZE         32
#define MPM_SYSHUB_AWUSER_MASK_AWUSER_MASK_SIZE  32

#define MPM_SYSHUB_AWUSER_MASK_AWUSER_MASK_SHIFT  0

#define MPM_SYSHUB_AWUSER_MASK_AWUSER_MASK_MASK  0xffffffff

#define MPM_SYSHUB_AWUSER_MASK_MASK \
      (MPM_SYSHUB_AWUSER_MASK_AWUSER_MASK_MASK)

#define MPM_SYSHUB_AWUSER_MASK_DEFAULT 0x00000000

#define MPM_SYSHUB_AWUSER_MASK_GET_AWUSER_MASK(mpm_syshub_awuser_mask) \
      ((mpm_syshub_awuser_mask & MPM_SYSHUB_AWUSER_MASK_AWUSER_MASK_MASK) >> MPM_SYSHUB_AWUSER_MASK_AWUSER_MASK_SHIFT)

#define MPM_SYSHUB_AWUSER_MASK_SET_AWUSER_MASK(mpm_syshub_awuser_mask_reg, awuser_mask) \
      mpm_syshub_awuser_mask_reg = (mpm_syshub_awuser_mask_reg & ~MPM_SYSHUB_AWUSER_MASK_AWUSER_MASK_MASK) | (awuser_mask << MPM_SYSHUB_AWUSER_MASK_AWUSER_MASK_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_awuser_mask_t {
            unsigned int awuser_mask                    : MPM_SYSHUB_AWUSER_MASK_AWUSER_MASK_SIZE;
      } mpm_syshub_awuser_mask_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_awuser_mask_t {
            unsigned int awuser_mask                    : MPM_SYSHUB_AWUSER_MASK_AWUSER_MASK_SIZE;
      } mpm_syshub_awuser_mask_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_awuser_mask_t f;
} mpm_syshub_awuser_mask_u;


/*
 * MPM_SYSHUB_AWUSER_VALUE struct
 */

#define MPM_SYSHUB_AWUSER_VALUE_REG_SIZE         32
#define MPM_SYSHUB_AWUSER_VALUE_AWUSER_VALUE_SIZE  32

#define MPM_SYSHUB_AWUSER_VALUE_AWUSER_VALUE_SHIFT  0

#define MPM_SYSHUB_AWUSER_VALUE_AWUSER_VALUE_MASK  0xffffffff

#define MPM_SYSHUB_AWUSER_VALUE_MASK \
      (MPM_SYSHUB_AWUSER_VALUE_AWUSER_VALUE_MASK)

#define MPM_SYSHUB_AWUSER_VALUE_DEFAULT 0x00000000

#define MPM_SYSHUB_AWUSER_VALUE_GET_AWUSER_VALUE(mpm_syshub_awuser_value) \
      ((mpm_syshub_awuser_value & MPM_SYSHUB_AWUSER_VALUE_AWUSER_VALUE_MASK) >> MPM_SYSHUB_AWUSER_VALUE_AWUSER_VALUE_SHIFT)

#define MPM_SYSHUB_AWUSER_VALUE_SET_AWUSER_VALUE(mpm_syshub_awuser_value_reg, awuser_value) \
      mpm_syshub_awuser_value_reg = (mpm_syshub_awuser_value_reg & ~MPM_SYSHUB_AWUSER_VALUE_AWUSER_VALUE_MASK) | (awuser_value << MPM_SYSHUB_AWUSER_VALUE_AWUSER_VALUE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_awuser_value_t {
            unsigned int awuser_value                   : MPM_SYSHUB_AWUSER_VALUE_AWUSER_VALUE_SIZE;
      } mpm_syshub_awuser_value_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_awuser_value_t {
            unsigned int awuser_value                   : MPM_SYSHUB_AWUSER_VALUE_AWUSER_VALUE_SIZE;
      } mpm_syshub_awuser_value_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_awuser_value_t f;
} mpm_syshub_awuser_value_u;


/*
 * MPM_SYSHUB_ARUSER_MASK struct
 */

#define MPM_SYSHUB_ARUSER_MASK_REG_SIZE         32
#define MPM_SYSHUB_ARUSER_MASK_ARUSER_MASK_SIZE  32

#define MPM_SYSHUB_ARUSER_MASK_ARUSER_MASK_SHIFT  0

#define MPM_SYSHUB_ARUSER_MASK_ARUSER_MASK_MASK  0xffffffff

#define MPM_SYSHUB_ARUSER_MASK_MASK \
      (MPM_SYSHUB_ARUSER_MASK_ARUSER_MASK_MASK)

#define MPM_SYSHUB_ARUSER_MASK_DEFAULT 0x00000000

#define MPM_SYSHUB_ARUSER_MASK_GET_ARUSER_MASK(mpm_syshub_aruser_mask) \
      ((mpm_syshub_aruser_mask & MPM_SYSHUB_ARUSER_MASK_ARUSER_MASK_MASK) >> MPM_SYSHUB_ARUSER_MASK_ARUSER_MASK_SHIFT)

#define MPM_SYSHUB_ARUSER_MASK_SET_ARUSER_MASK(mpm_syshub_aruser_mask_reg, aruser_mask) \
      mpm_syshub_aruser_mask_reg = (mpm_syshub_aruser_mask_reg & ~MPM_SYSHUB_ARUSER_MASK_ARUSER_MASK_MASK) | (aruser_mask << MPM_SYSHUB_ARUSER_MASK_ARUSER_MASK_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_aruser_mask_t {
            unsigned int aruser_mask                    : MPM_SYSHUB_ARUSER_MASK_ARUSER_MASK_SIZE;
      } mpm_syshub_aruser_mask_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_aruser_mask_t {
            unsigned int aruser_mask                    : MPM_SYSHUB_ARUSER_MASK_ARUSER_MASK_SIZE;
      } mpm_syshub_aruser_mask_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_aruser_mask_t f;
} mpm_syshub_aruser_mask_u;


/*
 * MPM_SYSHUB_ARUSER_VALUE struct
 */

#define MPM_SYSHUB_ARUSER_VALUE_REG_SIZE         32
#define MPM_SYSHUB_ARUSER_VALUE_ARUSER_VALUE_SIZE  32

#define MPM_SYSHUB_ARUSER_VALUE_ARUSER_VALUE_SHIFT  0

#define MPM_SYSHUB_ARUSER_VALUE_ARUSER_VALUE_MASK  0xffffffff

#define MPM_SYSHUB_ARUSER_VALUE_MASK \
      (MPM_SYSHUB_ARUSER_VALUE_ARUSER_VALUE_MASK)

#define MPM_SYSHUB_ARUSER_VALUE_DEFAULT 0x00000000

#define MPM_SYSHUB_ARUSER_VALUE_GET_ARUSER_VALUE(mpm_syshub_aruser_value) \
      ((mpm_syshub_aruser_value & MPM_SYSHUB_ARUSER_VALUE_ARUSER_VALUE_MASK) >> MPM_SYSHUB_ARUSER_VALUE_ARUSER_VALUE_SHIFT)

#define MPM_SYSHUB_ARUSER_VALUE_SET_ARUSER_VALUE(mpm_syshub_aruser_value_reg, aruser_value) \
      mpm_syshub_aruser_value_reg = (mpm_syshub_aruser_value_reg & ~MPM_SYSHUB_ARUSER_VALUE_ARUSER_VALUE_MASK) | (aruser_value << MPM_SYSHUB_ARUSER_VALUE_ARUSER_VALUE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_aruser_value_t {
            unsigned int aruser_value                   : MPM_SYSHUB_ARUSER_VALUE_ARUSER_VALUE_SIZE;
      } mpm_syshub_aruser_value_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_aruser_value_t {
            unsigned int aruser_value                   : MPM_SYSHUB_ARUSER_VALUE_ARUSER_VALUE_SIZE;
      } mpm_syshub_aruser_value_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_aruser_value_t f;
} mpm_syshub_aruser_value_u;


/*
 * MPM_SYSHUB_BRESP_MASK_CTRL struct
 */

#define MPM_SYSHUB_BRESP_MASK_CTRL_REG_SIZE         32
#define MPM_SYSHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_SIZE  2
#define MPM_SYSHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_SIZE  1
#define MPM_SYSHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_SIZE  1

#define MPM_SYSHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_SHIFT  0
#define MPM_SYSHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_SHIFT  2
#define MPM_SYSHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_SHIFT  3

#define MPM_SYSHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_MASK  0x00000003
#define MPM_SYSHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_MASK  0x00000004
#define MPM_SYSHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_MASK  0x00000008

#define MPM_SYSHUB_BRESP_MASK_CTRL_MASK \
      (MPM_SYSHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_MASK | \
      MPM_SYSHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_MASK | \
      MPM_SYSHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_MASK)

#define MPM_SYSHUB_BRESP_MASK_CTRL_DEFAULT 0x00000000

#define MPM_SYSHUB_BRESP_MASK_CTRL_GET_MASK_BRESP_ERROR(mpm_syshub_bresp_mask_ctrl) \
      ((mpm_syshub_bresp_mask_ctrl & MPM_SYSHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_MASK) >> MPM_SYSHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_SHIFT)
#define MPM_SYSHUB_BRESP_MASK_CTRL_GET_WR_RESP_INT_TRIG_EN(mpm_syshub_bresp_mask_ctrl) \
      ((mpm_syshub_bresp_mask_ctrl & MPM_SYSHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_MASK) >> MPM_SYSHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_SHIFT)
#define MPM_SYSHUB_BRESP_MASK_CTRL_GET_CLR_AXI_WR_ERR_CNT(mpm_syshub_bresp_mask_ctrl) \
      ((mpm_syshub_bresp_mask_ctrl & MPM_SYSHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_MASK) >> MPM_SYSHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_SHIFT)

#define MPM_SYSHUB_BRESP_MASK_CTRL_SET_MASK_BRESP_ERROR(mpm_syshub_bresp_mask_ctrl_reg, mask_bresp_error) \
      mpm_syshub_bresp_mask_ctrl_reg = (mpm_syshub_bresp_mask_ctrl_reg & ~MPM_SYSHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_MASK) | (mask_bresp_error << MPM_SYSHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_SHIFT)
#define MPM_SYSHUB_BRESP_MASK_CTRL_SET_WR_RESP_INT_TRIG_EN(mpm_syshub_bresp_mask_ctrl_reg, wr_resp_int_trig_en) \
      mpm_syshub_bresp_mask_ctrl_reg = (mpm_syshub_bresp_mask_ctrl_reg & ~MPM_SYSHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_MASK) | (wr_resp_int_trig_en << MPM_SYSHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_SHIFT)
#define MPM_SYSHUB_BRESP_MASK_CTRL_SET_CLR_AXI_WR_ERR_CNT(mpm_syshub_bresp_mask_ctrl_reg, clr_axi_wr_err_cnt) \
      mpm_syshub_bresp_mask_ctrl_reg = (mpm_syshub_bresp_mask_ctrl_reg & ~MPM_SYSHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_MASK) | (clr_axi_wr_err_cnt << MPM_SYSHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_bresp_mask_ctrl_t {
            unsigned int mask_bresp_error               : MPM_SYSHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_SIZE;
            unsigned int wr_resp_int_trig_en            : MPM_SYSHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_SIZE;
            unsigned int clr_axi_wr_err_cnt             : MPM_SYSHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_SIZE;
            unsigned int                                : 28;
      } mpm_syshub_bresp_mask_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_bresp_mask_ctrl_t {
            unsigned int                                : 28;
            unsigned int clr_axi_wr_err_cnt             : MPM_SYSHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_SIZE;
            unsigned int wr_resp_int_trig_en            : MPM_SYSHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_SIZE;
            unsigned int mask_bresp_error               : MPM_SYSHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_SIZE;
      } mpm_syshub_bresp_mask_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_bresp_mask_ctrl_t f;
} mpm_syshub_bresp_mask_ctrl_u;


/*
 * MPM_SYSHUB_AXI_WR_ERR_CNT struct
 */

#define MPM_SYSHUB_AXI_WR_ERR_CNT_REG_SIZE         32
#define MPM_SYSHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_SIZE  32

#define MPM_SYSHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_SHIFT  0

#define MPM_SYSHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_MASK  0xffffffff

#define MPM_SYSHUB_AXI_WR_ERR_CNT_MASK \
      (MPM_SYSHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_MASK)

#define MPM_SYSHUB_AXI_WR_ERR_CNT_DEFAULT 0x00000000

#define MPM_SYSHUB_AXI_WR_ERR_CNT_GET_AXI_WR_ERR_CNT(mpm_syshub_axi_wr_err_cnt) \
      ((mpm_syshub_axi_wr_err_cnt & MPM_SYSHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_MASK) >> MPM_SYSHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_SHIFT)

#define MPM_SYSHUB_AXI_WR_ERR_CNT_SET_AXI_WR_ERR_CNT(mpm_syshub_axi_wr_err_cnt_reg, axi_wr_err_cnt) \
      mpm_syshub_axi_wr_err_cnt_reg = (mpm_syshub_axi_wr_err_cnt_reg & ~MPM_SYSHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_MASK) | (axi_wr_err_cnt << MPM_SYSHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_axi_wr_err_cnt_t {
            unsigned int axi_wr_err_cnt                 : MPM_SYSHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_SIZE;
      } mpm_syshub_axi_wr_err_cnt_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_axi_wr_err_cnt_t {
            unsigned int axi_wr_err_cnt                 : MPM_SYSHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_SIZE;
      } mpm_syshub_axi_wr_err_cnt_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_axi_wr_err_cnt_t f;
} mpm_syshub_axi_wr_err_cnt_u;


/*
 * MPM_SYSHUB_RRESP_MASK_CTRL struct
 */

#define MPM_SYSHUB_RRESP_MASK_CTRL_REG_SIZE         32
#define MPM_SYSHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_SIZE  2
#define MPM_SYSHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_SIZE  1
#define MPM_SYSHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_SIZE  1

#define MPM_SYSHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_SHIFT  0
#define MPM_SYSHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_SHIFT  2
#define MPM_SYSHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_SHIFT  3

#define MPM_SYSHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_MASK  0x00000003
#define MPM_SYSHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_MASK  0x00000004
#define MPM_SYSHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_MASK  0x00000008

#define MPM_SYSHUB_RRESP_MASK_CTRL_MASK \
      (MPM_SYSHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_MASK | \
      MPM_SYSHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_MASK | \
      MPM_SYSHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_MASK)

#define MPM_SYSHUB_RRESP_MASK_CTRL_DEFAULT 0x00000000

#define MPM_SYSHUB_RRESP_MASK_CTRL_GET_MASK_RRESP_ERROR(mpm_syshub_rresp_mask_ctrl) \
      ((mpm_syshub_rresp_mask_ctrl & MPM_SYSHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_MASK) >> MPM_SYSHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_SHIFT)
#define MPM_SYSHUB_RRESP_MASK_CTRL_GET_RD_RESP_INT_TRIG_EN(mpm_syshub_rresp_mask_ctrl) \
      ((mpm_syshub_rresp_mask_ctrl & MPM_SYSHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_MASK) >> MPM_SYSHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_SHIFT)
#define MPM_SYSHUB_RRESP_MASK_CTRL_GET_CLR_AXI_RD_ERR_CNT(mpm_syshub_rresp_mask_ctrl) \
      ((mpm_syshub_rresp_mask_ctrl & MPM_SYSHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_MASK) >> MPM_SYSHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_SHIFT)

#define MPM_SYSHUB_RRESP_MASK_CTRL_SET_MASK_RRESP_ERROR(mpm_syshub_rresp_mask_ctrl_reg, mask_rresp_error) \
      mpm_syshub_rresp_mask_ctrl_reg = (mpm_syshub_rresp_mask_ctrl_reg & ~MPM_SYSHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_MASK) | (mask_rresp_error << MPM_SYSHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_SHIFT)
#define MPM_SYSHUB_RRESP_MASK_CTRL_SET_RD_RESP_INT_TRIG_EN(mpm_syshub_rresp_mask_ctrl_reg, rd_resp_int_trig_en) \
      mpm_syshub_rresp_mask_ctrl_reg = (mpm_syshub_rresp_mask_ctrl_reg & ~MPM_SYSHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_MASK) | (rd_resp_int_trig_en << MPM_SYSHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_SHIFT)
#define MPM_SYSHUB_RRESP_MASK_CTRL_SET_CLR_AXI_RD_ERR_CNT(mpm_syshub_rresp_mask_ctrl_reg, clr_axi_rd_err_cnt) \
      mpm_syshub_rresp_mask_ctrl_reg = (mpm_syshub_rresp_mask_ctrl_reg & ~MPM_SYSHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_MASK) | (clr_axi_rd_err_cnt << MPM_SYSHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_rresp_mask_ctrl_t {
            unsigned int mask_rresp_error               : MPM_SYSHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_SIZE;
            unsigned int rd_resp_int_trig_en            : MPM_SYSHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_SIZE;
            unsigned int clr_axi_rd_err_cnt             : MPM_SYSHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_SIZE;
            unsigned int                                : 28;
      } mpm_syshub_rresp_mask_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_rresp_mask_ctrl_t {
            unsigned int                                : 28;
            unsigned int clr_axi_rd_err_cnt             : MPM_SYSHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_SIZE;
            unsigned int rd_resp_int_trig_en            : MPM_SYSHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_SIZE;
            unsigned int mask_rresp_error               : MPM_SYSHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_SIZE;
      } mpm_syshub_rresp_mask_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_rresp_mask_ctrl_t f;
} mpm_syshub_rresp_mask_ctrl_u;


/*
 * MPM_SYSHUB_AXI_RD_ERR_CNT struct
 */

#define MPM_SYSHUB_AXI_RD_ERR_CNT_REG_SIZE         32
#define MPM_SYSHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_SIZE  32

#define MPM_SYSHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_SHIFT  0

#define MPM_SYSHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_MASK  0xffffffff

#define MPM_SYSHUB_AXI_RD_ERR_CNT_MASK \
      (MPM_SYSHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_MASK)

#define MPM_SYSHUB_AXI_RD_ERR_CNT_DEFAULT 0x00000000

#define MPM_SYSHUB_AXI_RD_ERR_CNT_GET_AXI_RD_ERR_CNT(mpm_syshub_axi_rd_err_cnt) \
      ((mpm_syshub_axi_rd_err_cnt & MPM_SYSHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_MASK) >> MPM_SYSHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_SHIFT)

#define MPM_SYSHUB_AXI_RD_ERR_CNT_SET_AXI_RD_ERR_CNT(mpm_syshub_axi_rd_err_cnt_reg, axi_rd_err_cnt) \
      mpm_syshub_axi_rd_err_cnt_reg = (mpm_syshub_axi_rd_err_cnt_reg & ~MPM_SYSHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_MASK) | (axi_rd_err_cnt << MPM_SYSHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_axi_rd_err_cnt_t {
            unsigned int axi_rd_err_cnt                 : MPM_SYSHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_SIZE;
      } mpm_syshub_axi_rd_err_cnt_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_axi_rd_err_cnt_t {
            unsigned int axi_rd_err_cnt                 : MPM_SYSHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_SIZE;
      } mpm_syshub_axi_rd_err_cnt_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_axi_rd_err_cnt_t f;
} mpm_syshub_axi_rd_err_cnt_u;


/*
 * MPM_SYSHUB_OBFF_EMUL struct
 */

#define MPM_SYSHUB_OBFF_EMUL_REG_SIZE         32
#define MPM_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SIZE  1

#define MPM_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SHIFT  1

#define MPM_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_MASK  0x00000002

#define MPM_SYSHUB_OBFF_EMUL_MASK \
      (MPM_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_MASK)

#define MPM_SYSHUB_OBFF_EMUL_DEFAULT   0x00000000

#define MPM_SYSHUB_OBFF_EMUL_GET_IP_SYSHUB_URGENT_DMA(mpm_syshub_obff_emul) \
      ((mpm_syshub_obff_emul & MPM_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_MASK) >> MPM_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SHIFT)

#define MPM_SYSHUB_OBFF_EMUL_SET_IP_SYSHUB_URGENT_DMA(mpm_syshub_obff_emul_reg, ip_syshub_urgent_dma) \
      mpm_syshub_obff_emul_reg = (mpm_syshub_obff_emul_reg & ~MPM_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_MASK) | (ip_syshub_urgent_dma << MPM_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_obff_emul_t {
            unsigned int                                : 1;
            unsigned int ip_syshub_urgent_dma           : MPM_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SIZE;
            unsigned int                                : 30;
      } mpm_syshub_obff_emul_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_obff_emul_t {
            unsigned int                                : 30;
            unsigned int ip_syshub_urgent_dma           : MPM_SYSHUB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SIZE;
            unsigned int                                : 1;
      } mpm_syshub_obff_emul_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_obff_emul_t f;
} mpm_syshub_obff_emul_u;


/*
 * MPM_SYSHUB_BYPASS struct
 */

#define MPM_SYSHUB_BYPASS_REG_SIZE         32
#define MPM_SYSHUB_BYPASS_BYPASS_MASK_SIZE  1
#define MPM_SYSHUB_BYPASS_BYPASS_VALUE_SIZE  1

#define MPM_SYSHUB_BYPASS_BYPASS_MASK_SHIFT  0
#define MPM_SYSHUB_BYPASS_BYPASS_VALUE_SHIFT  1

#define MPM_SYSHUB_BYPASS_BYPASS_MASK_MASK  0x00000001
#define MPM_SYSHUB_BYPASS_BYPASS_VALUE_MASK  0x00000002

#define MPM_SYSHUB_BYPASS_MASK \
      (MPM_SYSHUB_BYPASS_BYPASS_MASK_MASK | \
      MPM_SYSHUB_BYPASS_BYPASS_VALUE_MASK)

#define MPM_SYSHUB_BYPASS_DEFAULT      0x00000001

#define MPM_SYSHUB_BYPASS_GET_BYPASS_MASK(mpm_syshub_bypass) \
      ((mpm_syshub_bypass & MPM_SYSHUB_BYPASS_BYPASS_MASK_MASK) >> MPM_SYSHUB_BYPASS_BYPASS_MASK_SHIFT)
#define MPM_SYSHUB_BYPASS_GET_BYPASS_VALUE(mpm_syshub_bypass) \
      ((mpm_syshub_bypass & MPM_SYSHUB_BYPASS_BYPASS_VALUE_MASK) >> MPM_SYSHUB_BYPASS_BYPASS_VALUE_SHIFT)

#define MPM_SYSHUB_BYPASS_SET_BYPASS_MASK(mpm_syshub_bypass_reg, bypass_mask) \
      mpm_syshub_bypass_reg = (mpm_syshub_bypass_reg & ~MPM_SYSHUB_BYPASS_BYPASS_MASK_MASK) | (bypass_mask << MPM_SYSHUB_BYPASS_BYPASS_MASK_SHIFT)
#define MPM_SYSHUB_BYPASS_SET_BYPASS_VALUE(mpm_syshub_bypass_reg, bypass_value) \
      mpm_syshub_bypass_reg = (mpm_syshub_bypass_reg & ~MPM_SYSHUB_BYPASS_BYPASS_VALUE_MASK) | (bypass_value << MPM_SYSHUB_BYPASS_BYPASS_VALUE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_bypass_t {
            unsigned int bypass_mask                    : MPM_SYSHUB_BYPASS_BYPASS_MASK_SIZE;
            unsigned int bypass_value                   : MPM_SYSHUB_BYPASS_BYPASS_VALUE_SIZE;
            unsigned int                                : 30;
      } mpm_syshub_bypass_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_bypass_t {
            unsigned int                                : 30;
            unsigned int bypass_value                   : MPM_SYSHUB_BYPASS_BYPASS_VALUE_SIZE;
            unsigned int bypass_mask                    : MPM_SYSHUB_BYPASS_BYPASS_MASK_SIZE;
      } mpm_syshub_bypass_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_bypass_t f;
} mpm_syshub_bypass_u;


/*
 * MPM_SYSHUB_REQIO struct
 */

#define MPM_SYSHUB_REQIO_REG_SIZE         32
#define MPM_SYSHUB_REQIO_REQIO_MASK_SIZE  1
#define MPM_SYSHUB_REQIO_REQIO_VALUE_SIZE  1

#define MPM_SYSHUB_REQIO_REQIO_MASK_SHIFT  0
#define MPM_SYSHUB_REQIO_REQIO_VALUE_SHIFT  1

#define MPM_SYSHUB_REQIO_REQIO_MASK_MASK  0x00000001
#define MPM_SYSHUB_REQIO_REQIO_VALUE_MASK  0x00000002

#define MPM_SYSHUB_REQIO_MASK \
      (MPM_SYSHUB_REQIO_REQIO_MASK_MASK | \
      MPM_SYSHUB_REQIO_REQIO_VALUE_MASK)

#define MPM_SYSHUB_REQIO_DEFAULT       0x00000003

#define MPM_SYSHUB_REQIO_GET_REQIO_MASK(mpm_syshub_reqio) \
      ((mpm_syshub_reqio & MPM_SYSHUB_REQIO_REQIO_MASK_MASK) >> MPM_SYSHUB_REQIO_REQIO_MASK_SHIFT)
#define MPM_SYSHUB_REQIO_GET_REQIO_VALUE(mpm_syshub_reqio) \
      ((mpm_syshub_reqio & MPM_SYSHUB_REQIO_REQIO_VALUE_MASK) >> MPM_SYSHUB_REQIO_REQIO_VALUE_SHIFT)

#define MPM_SYSHUB_REQIO_SET_REQIO_MASK(mpm_syshub_reqio_reg, reqio_mask) \
      mpm_syshub_reqio_reg = (mpm_syshub_reqio_reg & ~MPM_SYSHUB_REQIO_REQIO_MASK_MASK) | (reqio_mask << MPM_SYSHUB_REQIO_REQIO_MASK_SHIFT)
#define MPM_SYSHUB_REQIO_SET_REQIO_VALUE(mpm_syshub_reqio_reg, reqio_value) \
      mpm_syshub_reqio_reg = (mpm_syshub_reqio_reg & ~MPM_SYSHUB_REQIO_REQIO_VALUE_MASK) | (reqio_value << MPM_SYSHUB_REQIO_REQIO_VALUE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_syshub_reqio_t {
            unsigned int reqio_mask                     : MPM_SYSHUB_REQIO_REQIO_MASK_SIZE;
            unsigned int reqio_value                    : MPM_SYSHUB_REQIO_REQIO_VALUE_SIZE;
            unsigned int                                : 30;
      } mpm_syshub_reqio_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_syshub_reqio_t {
            unsigned int                                : 30;
            unsigned int reqio_value                    : MPM_SYSHUB_REQIO_REQIO_VALUE_SIZE;
            unsigned int reqio_mask                     : MPM_SYSHUB_REQIO_REQIO_MASK_SIZE;
      } mpm_syshub_reqio_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_syshub_reqio_t f;
} mpm_syshub_reqio_u;


#endif

