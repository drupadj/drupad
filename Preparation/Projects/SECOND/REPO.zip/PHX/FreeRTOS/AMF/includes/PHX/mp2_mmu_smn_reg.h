// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MP2_MMU_SMN_FIDDLE_H)
#define _MP2_MMU_SMN_FIDDLE_H

/*****************************************************************************************************************
 *
 *	mp2_mmu_smn_reg.h
 *
 *	Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif


/*******************************************************
 * Values
 *******************************************************/


/*******************************************************
 * Structures
 *******************************************************/

/*
 * MP2_SMN_PMI_0 struct
 */

#define MP2_SMN_PMI_0_REG_SIZE         32
#define MP2_SMN_PMI_0_DATA_SIZE        32

#define MP2_SMN_PMI_0_DATA_SHIFT       0

#define MP2_SMN_PMI_0_DATA_MASK        0xffffffff

#define MP2_SMN_PMI_0_MASK \
     (MP2_SMN_PMI_0_DATA_MASK)

#define MP2_SMN_PMI_0_DEFAULT          0x00000000

#define MP2_SMN_PMI_0_GET_DATA(mp2_smn_pmi_0) \
     ((mp2_smn_pmi_0 & MP2_SMN_PMI_0_DATA_MASK) >> MP2_SMN_PMI_0_DATA_SHIFT)

#define MP2_SMN_PMI_0_SET_DATA(mp2_smn_pmi_0_reg, data) \
     mp2_smn_pmi_0_reg = (mp2_smn_pmi_0_reg & ~MP2_SMN_PMI_0_DATA_MASK) | (data << MP2_SMN_PMI_0_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smn_pmi_0_t {
          unsigned int data                           : MP2_SMN_PMI_0_DATA_SIZE;
     } mp2_smn_pmi_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smn_pmi_0_t {
          unsigned int data                           : MP2_SMN_PMI_0_DATA_SIZE;
     } mp2_smn_pmi_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smn_pmi_0_t f;
} mp2_smn_pmi_0_u;


/*
 * MP2_SMN_PMI_0_STATUS struct
 */

#define MP2_SMN_PMI_0_STATUS_REG_SIZE  32
#define MP2_SMN_PMI_0_STATUS_FULL_SIZE 1
#define MP2_SMN_PMI_0_STATUS_EMPTY_SIZE 1

#define MP2_SMN_PMI_0_STATUS_FULL_SHIFT 0
#define MP2_SMN_PMI_0_STATUS_EMPTY_SHIFT 1

#define MP2_SMN_PMI_0_STATUS_FULL_MASK 0x1
#define MP2_SMN_PMI_0_STATUS_EMPTY_MASK 0x2

#define MP2_SMN_PMI_0_STATUS_MASK \
     (MP2_SMN_PMI_0_STATUS_FULL_MASK | \
      MP2_SMN_PMI_0_STATUS_EMPTY_MASK)

#define MP2_SMN_PMI_0_STATUS_DEFAULT   0x00000002

#define MP2_SMN_PMI_0_STATUS_GET_FULL(mp2_smn_pmi_0_status) \
     ((mp2_smn_pmi_0_status & MP2_SMN_PMI_0_STATUS_FULL_MASK) >> MP2_SMN_PMI_0_STATUS_FULL_SHIFT)
#define MP2_SMN_PMI_0_STATUS_GET_EMPTY(mp2_smn_pmi_0_status) \
     ((mp2_smn_pmi_0_status & MP2_SMN_PMI_0_STATUS_EMPTY_MASK) >> MP2_SMN_PMI_0_STATUS_EMPTY_SHIFT)

#define MP2_SMN_PMI_0_STATUS_SET_FULL(mp2_smn_pmi_0_status_reg, full) \
     mp2_smn_pmi_0_status_reg = (mp2_smn_pmi_0_status_reg & ~MP2_SMN_PMI_0_STATUS_FULL_MASK) | (full << MP2_SMN_PMI_0_STATUS_FULL_SHIFT)
#define MP2_SMN_PMI_0_STATUS_SET_EMPTY(mp2_smn_pmi_0_status_reg, empty) \
     mp2_smn_pmi_0_status_reg = (mp2_smn_pmi_0_status_reg & ~MP2_SMN_PMI_0_STATUS_EMPTY_MASK) | (empty << MP2_SMN_PMI_0_STATUS_EMPTY_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smn_pmi_0_status_t {
          unsigned int full                           : MP2_SMN_PMI_0_STATUS_FULL_SIZE;
          unsigned int empty                          : MP2_SMN_PMI_0_STATUS_EMPTY_SIZE;
          unsigned int                                : 30;
     } mp2_smn_pmi_0_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smn_pmi_0_status_t {
          unsigned int                                : 30;
          unsigned int empty                          : MP2_SMN_PMI_0_STATUS_EMPTY_SIZE;
          unsigned int full                           : MP2_SMN_PMI_0_STATUS_FULL_SIZE;
     } mp2_smn_pmi_0_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smn_pmi_0_status_t f;
} mp2_smn_pmi_0_status_u;


/*
 * MP2_SMN_PMI_0_READ_POINTER struct
 */

#define MP2_SMN_PMI_0_READ_POINTER_REG_SIZE 32
#define MP2_SMN_PMI_0_READ_POINTER_CURRENT_SIZE 18

#define MP2_SMN_PMI_0_READ_POINTER_CURRENT_SHIFT 0

#define MP2_SMN_PMI_0_READ_POINTER_CURRENT_MASK 0x3ffff

#define MP2_SMN_PMI_0_READ_POINTER_MASK \
     (MP2_SMN_PMI_0_READ_POINTER_CURRENT_MASK)

#define MP2_SMN_PMI_0_READ_POINTER_DEFAULT 0x00000000

#define MP2_SMN_PMI_0_READ_POINTER_GET_CURRENT(mp2_smn_pmi_0_read_pointer) \
     ((mp2_smn_pmi_0_read_pointer & MP2_SMN_PMI_0_READ_POINTER_CURRENT_MASK) >> MP2_SMN_PMI_0_READ_POINTER_CURRENT_SHIFT)

#define MP2_SMN_PMI_0_READ_POINTER_SET_CURRENT(mp2_smn_pmi_0_read_pointer_reg, current) \
     mp2_smn_pmi_0_read_pointer_reg = (mp2_smn_pmi_0_read_pointer_reg & ~MP2_SMN_PMI_0_READ_POINTER_CURRENT_MASK) | (current << MP2_SMN_PMI_0_READ_POINTER_CURRENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smn_pmi_0_read_pointer_t {
          unsigned int current                        : MP2_SMN_PMI_0_READ_POINTER_CURRENT_SIZE;
          unsigned int                                : 14;
     } mp2_smn_pmi_0_read_pointer_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smn_pmi_0_read_pointer_t {
          unsigned int                                : 14;
          unsigned int current                        : MP2_SMN_PMI_0_READ_POINTER_CURRENT_SIZE;
     } mp2_smn_pmi_0_read_pointer_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smn_pmi_0_read_pointer_t f;
} mp2_smn_pmi_0_read_pointer_u;


/*
 * MP2_SMN_PMI_0_WRITE_POINTER struct
 */

#define MP2_SMN_PMI_0_WRITE_POINTER_REG_SIZE 32
#define MP2_SMN_PMI_0_WRITE_POINTER_CURRENT_SIZE 18

#define MP2_SMN_PMI_0_WRITE_POINTER_CURRENT_SHIFT 0

#define MP2_SMN_PMI_0_WRITE_POINTER_CURRENT_MASK 0x3ffff

#define MP2_SMN_PMI_0_WRITE_POINTER_MASK \
     (MP2_SMN_PMI_0_WRITE_POINTER_CURRENT_MASK)

#define MP2_SMN_PMI_0_WRITE_POINTER_DEFAULT 0x00000000

#define MP2_SMN_PMI_0_WRITE_POINTER_GET_CURRENT(mp2_smn_pmi_0_write_pointer) \
     ((mp2_smn_pmi_0_write_pointer & MP2_SMN_PMI_0_WRITE_POINTER_CURRENT_MASK) >> MP2_SMN_PMI_0_WRITE_POINTER_CURRENT_SHIFT)

#define MP2_SMN_PMI_0_WRITE_POINTER_SET_CURRENT(mp2_smn_pmi_0_write_pointer_reg, current) \
     mp2_smn_pmi_0_write_pointer_reg = (mp2_smn_pmi_0_write_pointer_reg & ~MP2_SMN_PMI_0_WRITE_POINTER_CURRENT_MASK) | (current << MP2_SMN_PMI_0_WRITE_POINTER_CURRENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smn_pmi_0_write_pointer_t {
          unsigned int current                        : MP2_SMN_PMI_0_WRITE_POINTER_CURRENT_SIZE;
          unsigned int                                : 14;
     } mp2_smn_pmi_0_write_pointer_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smn_pmi_0_write_pointer_t {
          unsigned int                                : 14;
          unsigned int current                        : MP2_SMN_PMI_0_WRITE_POINTER_CURRENT_SIZE;
     } mp2_smn_pmi_0_write_pointer_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smn_pmi_0_write_pointer_t f;
} mp2_smn_pmi_0_write_pointer_u;


#endif


