// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MPM_DFP_MASK_H)
#define _MPM_DFP_MASK_H

/*****************************************************************************************************************
 *
 *	mpm_dfp_mask.h
 *
 *	Register Spec Release:  <unknown>
*
*	 (c) 2000 ATI Technologies Inc.  (unpublished)
*
*	 All rights reserved.  This notice is intended as a precaution against
*	 inadvertent publication and does not imply publication or any waiver
*	 of confidentiality.  The year included in the foregoing notice is the
*	 year of creation of the work.
*
 *****************************************************************************************************************/

/*******************************************************
 * Read and Write Masks
 *******************************************************/

#define MPM_MPCLK_XBAR_CG_CTRL_READ_MASK 0x1
#define MPM_MPCLK_XBAR_CG_CTRL_WRITE_MASK 0x1

#define MPM_MPCLK_XBAR_CG_EN_READ_MASK 0x1e
#define MPM_MPCLK_XBAR_CG_EN_WRITE_MASK 0x1e

#define MPM_MPCLK_XBAR_CG_MISC_READ_MASK 0xffff
#define MPM_MPCLK_XBAR_CG_MISC_WRITE_MASK 0xffff

#define MPM_DFP_PGFSM_CTRL_READ_MASK   0x800000be
#define MPM_DFP_PGFSM_CTRL_WRITE_MASK  0xbf

#define MPM_DFP_PGFSM_TRAN_CTRL_READ_MASK 0xfff
#define MPM_DFP_PGFSM_TRAN_CTRL_WRITE_MASK 0x800000ff

#define MPM_DFP_PGFSM_TRAN_WRITE_DATA_READ_MASK 0xffffffff
#define MPM_DFP_PGFSM_TRAN_WRITE_DATA_WRITE_MASK 0xffffffff

#define MPM_DFP_PGFSM_TRAN_READ_DATA_READ_MASK 0xffffffff
#define MPM_DFP_PGFSM_TRAN_READ_DATA_WRITE_MASK 0x0

#define MPM_DFP_PGFSM_OVRD_REG_READ_MASK 0xff01
#define MPM_DFP_PGFSM_OVRD_REG_WRITE_MASK 0xff01

#define MPM_DFP_PGRAM_MMU_CNTL_READ_MASK 0xffffff
#define MPM_DFP_PGRAM_MMU_CNTL_WRITE_MASK 0xffffd5

#define MPM_DFP_PGRAM_CPU_CNTL_READ_MASK 0xffffff
#define MPM_DFP_PGRAM_CPU_CNTL_WRITE_MASK 0xffffd5

#define MPM_DFP_MPCLKDS_CTRL_READ_MASK 0x1fff
#define MPM_DFP_MPCLKDS_CTRL_WRITE_MASK 0x1ffd

#define MPM_MPAONCLK_XBAR_CG_CTRL_READ_MASK 0x1
#define MPM_MPAONCLK_XBAR_CG_CTRL_WRITE_MASK 0x1

#define MPM_MPAONCLK_XBAR_CG_EN_READ_MASK 0x6
#define MPM_MPAONCLK_XBAR_CG_EN_WRITE_MASK 0x6

#define MPM_MPAONCLK_XBAR_CG_MISC_READ_MASK 0xffff
#define MPM_MPAONCLK_XBAR_CG_MISC_WRITE_MASK 0xffff

#define MPM_DFP_PGRAM_CRU_CNTL_READ_MASK 0xffff3f
#define MPM_DFP_PGRAM_CRU_CNTL_WRITE_MASK 0xffff15

#define MPM_SOCCLK_XBAR_CG_CTRL_READ_MASK 0x1
#define MPM_SOCCLK_XBAR_CG_CTRL_WRITE_MASK 0x1

#define MPM_SOCCLK_XBAR_CG_EN_READ_MASK 0x1e
#define MPM_SOCCLK_XBAR_CG_EN_WRITE_MASK 0x1e

#define MPM_SOCCLK_XBAR_CG_MISC_READ_MASK 0xffff
#define MPM_SOCCLK_XBAR_CG_MISC_WRITE_MASK 0xffff

#define MPM_DFP_PGRAM_MHUB_CNTL_READ_MASK 0xffffff
#define MPM_DFP_PGRAM_MHUB_CNTL_WRITE_MASK 0xffffd5

#define MPM_DFP_SOCCLKDS_CTRL_READ_MASK 0x7ff
#define MPM_DFP_SOCCLKDS_CTRL_WRITE_MASK 0x7fd

#define MPM_SHUBCLK_XBAR_CG_CTRL_READ_MASK 0x1
#define MPM_SHUBCLK_XBAR_CG_CTRL_WRITE_MASK 0x1

#define MPM_SHUBCLK_XBAR_CG_EN_READ_MASK 0x1e
#define MPM_SHUBCLK_XBAR_CG_EN_WRITE_MASK 0x1e

#define MPM_SHUBCLK_XBAR_CG_MISC_READ_MASK 0xffff
#define MPM_SHUBCLK_XBAR_CG_MISC_WRITE_MASK 0xffff

#define MPM_DFP_PGRAM_SHUB_CNTL_READ_MASK 0xffffff
#define MPM_DFP_PGRAM_SHUB_CNTL_WRITE_MASK 0xffffd5

#define MPM_DFP_SHUBCLKDS_CTRL_READ_MASK 0xfff
#define MPM_DFP_SHUBCLKDS_CTRL_WRITE_MASK 0xffd

#define MPM_PG_PUB_STATUS_READ_MASK    0xf
#define MPM_PG_PUB_STATUS_WRITE_MASK   0x0

#endif


