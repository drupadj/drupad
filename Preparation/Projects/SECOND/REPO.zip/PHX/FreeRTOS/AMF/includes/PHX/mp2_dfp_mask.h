// Copyright (c) 1994 - 2022 Advanced Micro Devices, Inc. All rights reserved.

#if !defined (_MP2_DFP_MASK_H)
#define _MP2_DFP_MASK_H

/*
 *    mp2_dfp_mask.h   
 *
 *    Register Spec Release:  <unknown>
 *
 *
 *      (c) 2021 Advanced Micro Devices, Inc.  (unpublished)
 *
 *        All rights reserved.  This notice is intended as a precaution against
 *     inadvertent publication and does not imply publication or any waiver
 *      of confidentiality.  The year included in the foregoing notice is the
 *     year of creation of the work.
 *
 */

/*******************************************************
 * Read and Write Masks
 *******************************************************/

#define MP2_PSP_ACCESS_ONLY_READ_MASK  0x00000001
#define MP2_PSP_ACCESS_ONLY_WRITE_MASK 0x00000001

#define MP2_PG_PUB_STATUS_READ_MASK    0x0000001b
#define MP2_PG_PUB_STATUS_WRITE_MASK   0x00000000

#define MP2_MPCLK_XBAR_CG_CTRL_READ_MASK 0x00000001
#define MP2_MPCLK_XBAR_CG_CTRL_WRITE_MASK 0x00000001

#define MP2_MPCLK_XBAR_CG_EN_READ_MASK 0x0000001e
#define MP2_MPCLK_XBAR_CG_EN_WRITE_MASK 0x0000001e

#define MP2_MPCLK_XBAR_CG_MISC_READ_MASK 0x0000ffff
#define MP2_MPCLK_XBAR_CG_MISC_WRITE_MASK 0x0000ffff

#define MP2_DFP_ZSCIF_CTRL_READ_MASK   0x0000001f
#define MP2_DFP_ZSCIF_CTRL_WRITE_MASK  0x0000001b

#define MP2_DFP_PGFSM_CTRL_READ_MASK   0x800000b2
#define MP2_DFP_PGFSM_CTRL_WRITE_MASK  0x000000b3

#define MP2_DFP_CLK_DIV_READ_MASK      0x0000007f
#define MP2_DFP_CLK_DIV_WRITE_MASK     0x0000007f

#define MP2_DFP_PGFSM_TRAN_CTRL_READ_MASK 0x00000fff
#define MP2_DFP_PGFSM_TRAN_CTRL_WRITE_MASK 0x800000ff

#define MP2_DFP_PGFSM_TRAN_WRITE_DATA_READ_MASK 0xffffffff
#define MP2_DFP_PGFSM_TRAN_WRITE_DATA_WRITE_MASK 0xffffffff

#define MP2_DFP_PGFSM_TRAN_READ_DATA_READ_MASK 0xffffffff
#define MP2_DFP_PGFSM_TRAN_READ_DATA_WRITE_MASK 0x00000000

#define MP2_DFP_PGFSM_OVRD_REG_READ_MASK 0x0000ff01
#define MP2_DFP_PGFSM_OVRD_REG_WRITE_MASK 0x0000ff01

#define MP2_DFP_PGRAM_MMU0_CNTL_READ_MASK 0xfffffffd
#define MP2_DFP_PGRAM_MMU0_CNTL_WRITE_MASK 0xffffffd5

#define MP2_DFP_PGRAM_MMU1_CNTL_READ_MASK 0xfffffffd
#define MP2_DFP_PGRAM_MMU1_CNTL_WRITE_MASK 0xffffffd5

#define MP2_DFP_PGRAM_MMU2_CNTL_READ_MASK 0xfffffffd
#define MP2_DFP_PGRAM_MMU2_CNTL_WRITE_MASK 0xffffffd5

#define MP2_DFP_PGRAM_MMU3_CNTL_READ_MASK 0xfffffffd
#define MP2_DFP_PGRAM_MMU3_CNTL_WRITE_MASK 0xffffffd5

#define MP2_DFP_PGRAM_MMU4_CNTL_READ_MASK 0xfffffffd
#define MP2_DFP_PGRAM_MMU4_CNTL_WRITE_MASK 0xffffffd5

#define MP2_DFP_PGRAM_MMU5_CNTL_READ_MASK 0xfffffffd
#define MP2_DFP_PGRAM_MMU5_CNTL_WRITE_MASK 0xffffffd5

#define MP2_DFP_PGRAM_MMU6_CNTL_READ_MASK 0xfffffffd
#define MP2_DFP_PGRAM_MMU6_CNTL_WRITE_MASK 0xffffffd5

#define MP2_DFP_PGRAM_MMU7_CNTL_READ_MASK 0xfffffffd
#define MP2_DFP_PGRAM_MMU7_CNTL_WRITE_MASK 0xffffffd5

#define MP2_DFP_PGRAM_I3C_CNTL_READ_MASK 0xfffffffd
#define MP2_DFP_PGRAM_I3C_CNTL_WRITE_MASK 0xffffffd5

#define MP2_DFP_MPCLKDS_CTRL_READ_MASK 0x00003fff
#define MP2_DFP_MPCLKDS_CTRL_WRITE_MASK 0x00003ffd

#define MP2_DFP_SHUBCLKDS_CTRL_READ_MASK 0x00000fff
#define MP2_DFP_SHUBCLKDS_CTRL_WRITE_MASK 0x00000ffd

#define MP2_CM4_WIC_CTRL_READ_MASK     0x000007ff
#define MP2_CM4_WIC_CTRL_WRITE_MASK    0x0000073f

#define MP2_WAKE_EVENT_CTRL_READ_MASK  0x00000001
#define MP2_WAKE_EVENT_CTRL_WRITE_MASK 0x00000003

#define MP2_MPAONCLK_XBAR_CG_CTRL_READ_MASK 0x00000001
#define MP2_MPAONCLK_XBAR_CG_CTRL_WRITE_MASK 0x00000001

#define MP2_MPAONCLK_XBAR_CG_EN_READ_MASK 0x00000006
#define MP2_MPAONCLK_XBAR_CG_EN_WRITE_MASK 0x00000006

#define MP2_MPAONCLK_XBAR_CG_MISC_READ_MASK 0x0000ffff
#define MP2_MPAONCLK_XBAR_CG_MISC_WRITE_MASK 0x0000ffff

#endif


