// Copyright (c) 2010 - 2019 Advanced Micro Devices, Inc. All rights reserved.
#ifndef __TOOLS_FEATURES_H__
#define __TOOLS_FEATURES_H__
// reference features

// imported features

// local features
#define TOOLS__VARIANT tbd
#define TOOLS__VARIANT__TBD 1
#define TOOLS__REP_INFO__ENABLED 1
#define TOOLS__REP_INFO__ENABLED__1 1
#define TOOLS__GEN_RBBM_EXCLUDE_GFXDEC 1
#define TOOLS__GEN_RBBM_EXCLUDE_GFXDEC__1 1
#endif
