// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MP1_MMU_MASK_H)
#define _MP1_MMU_MASK_H

/*****************************************************************************************************************
 *
 *	mp1_mmu_mask.h
 *
 *	Register Spec Release:  <unknown>
*
*	 (c) 2000 ATI Technologies Inc.  (unpublished)
*
*	 All rights reserved.  This notice is intended as a precaution against
*	 inadvertent publication and does not imply publication or any waiver
*	 of confidentiality.  The year included in the foregoing notice is the
*	 year of creation of the work.
*
 *****************************************************************************************************************/

/*******************************************************
 * Read and Write Masks
 *******************************************************/

#define MP1_CONFIG_READ_MASK           0x8
#define MP1_CONFIG_WRITE_MASK          0x8

#define MP1_PMI_0_START_READ_MASK      0x8003ffff
#define MP1_PMI_0_START_WRITE_MASK     0x8003ffff

#define MP1_PMI_0_FIFO_READ_MASK       0xf
#define MP1_PMI_0_FIFO_WRITE_MASK      0xf

#define MP1_PMI_0_STATUS_READ_MASK     0x3
#define MP1_PMI_0_STATUS_WRITE_MASK    0x0

#define MP1_PMI_0_READ_POINTER_READ_MASK 0x3ffff
#define MP1_PMI_0_READ_POINTER_WRITE_MASK 0x0

#define MP1_PMI_0_WRITE_POINTER_READ_MASK 0x3ffff
#define MP1_PMI_0_WRITE_POINTER_WRITE_MASK 0x0

#define MP1_PMI_1_START_READ_MASK      0x8003ffff
#define MP1_PMI_1_START_WRITE_MASK     0x8003ffff

#define MP1_PMI_1_FIFO_READ_MASK       0xf
#define MP1_PMI_1_FIFO_WRITE_MASK      0xf

#define MP1_PMI_1_STATUS_READ_MASK     0x3
#define MP1_PMI_1_STATUS_WRITE_MASK    0x0

#define MP1_PMI_1_READ_POINTER_READ_MASK 0x3ffff
#define MP1_PMI_1_READ_POINTER_WRITE_MASK 0x0

#define MP1_PMI_1_WRITE_POINTER_READ_MASK 0x3ffff
#define MP1_PMI_1_WRITE_POINTER_WRITE_MASK 0x0

#define MP1_PMI_2_START_READ_MASK      0x8003ffff
#define MP1_PMI_2_START_WRITE_MASK     0x8003ffff

#define MP1_PMI_2_FIFO_READ_MASK       0xf
#define MP1_PMI_2_FIFO_WRITE_MASK      0xf

#define MP1_PMI_2_STATUS_READ_MASK     0x3
#define MP1_PMI_2_STATUS_WRITE_MASK    0x0

#define MP1_PMI_2_READ_POINTER_READ_MASK 0x3ffff
#define MP1_PMI_2_READ_POINTER_WRITE_MASK 0x0

#define MP1_PMI_2_WRITE_POINTER_READ_MASK 0x3ffff
#define MP1_PMI_2_WRITE_POINTER_WRITE_MASK 0x0

#define MP1_PMI_OUT_CONFIG_READ_MASK   0x3f
#define MP1_PMI_OUT_CONFIG_WRITE_MASK  0x3f

#define MP1_PMI_RELOAD_READ_MASK       0x0
#define MP1_PMI_RELOAD_WRITE_MASK      0x7

#define MP1_PMI_INTERRUPT_CONTROL_READ_MASK 0xfff
#define MP1_PMI_INTERRUPT_CONTROL_WRITE_MASK 0xe38

#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_READ_MASK 0xffffffff
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_WRITE_MASK 0x0

#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_READ_MASK 0xc1fffffb
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_WRITE_MASK 0xc0000000

#define MP1_MMU_MISC_CNTL_READ_MASK    0xff000d
#define MP1_MMU_MISC_CNTL_WRITE_MASK   0x3f000d

#define MP1_MMU_ACCESS_ERR_LOG_READ_MASK 0xfffff1f
#define MP1_MMU_ACCESS_ERR_LOG_WRITE_MASK 0x18

#define MP1_MMU_SRAM_UNSECURE_BAR_READ_MASK 0xffffffff
#define MP1_MMU_SRAM_UNSECURE_BAR_WRITE_MASK 0xffffffff

#define MP1_MMU_SCRATCH_0_READ_MASK    0xffffffff
#define MP1_MMU_SCRATCH_0_WRITE_MASK   0xffffffff

#define MP1_MMU_SCRATCH_1_READ_MASK    0xffffffff
#define MP1_MMU_SCRATCH_1_WRITE_MASK   0xffffffff

#define MP1_MMU_SCRATCH_2_READ_MASK    0xffffffff
#define MP1_MMU_SCRATCH_2_WRITE_MASK   0xffffffff

#define MP1_MMU_SCRATCH_3_READ_MASK    0xffffffff
#define MP1_MMU_SCRATCH_3_WRITE_MASK   0xffffffff

#define MP1_MMU_SCRATCH_4_READ_MASK    0xffffffff
#define MP1_MMU_SCRATCH_4_WRITE_MASK   0xffffffff

#define MP1_MMU_SCRATCH_5_READ_MASK    0xffffffff
#define MP1_MMU_SCRATCH_5_WRITE_MASK   0xffffffff

#define MP1_MMU_SCRATCH_6_READ_MASK    0xffffffff
#define MP1_MMU_SCRATCH_6_WRITE_MASK   0xffffffff

#define MP1_MMU_SCRATCH_7_READ_MASK    0xffffffff
#define MP1_MMU_SCRATCH_7_WRITE_MASK   0xffffffff

#define MP1_PMI_0_READ_MASK            0xffffffff
#define MP1_PMI_0_WRITE_MASK           0xffffffff

#define MP1_PMI_1_READ_MASK            0xffffffff
#define MP1_PMI_1_WRITE_MASK           0xffffffff

#define MP1_PMI_2_READ_MASK            0xffffffff
#define MP1_PMI_2_WRITE_MASK           0xffffffff

#endif


