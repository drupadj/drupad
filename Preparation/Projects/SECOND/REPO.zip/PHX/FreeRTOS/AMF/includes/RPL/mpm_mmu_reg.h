// Copyright (c) 1994 - 2021 Advanced Micro Devices, Inc. All rights reserved. 
 #if !defined (_MPM_MMU_FIDDLE_H)
#define _MPM_MMU_FIDDLE_H
 /*****************************************************************************************************************
 *
 *  mpm_mmu_reg.h
 *
 *  Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif

 /*******************************************************
 * Values
 *******************************************************/

 /*******************************************************
 * Structures
 *******************************************************/

/*
 * MPM_CONFIG struct
 */

#define MPM_CONFIG_REG_SIZE         32
#define MPM_CONFIG_EnableCacheClear_OnReset_SIZE  1

#define MPM_CONFIG_EnableCacheClear_OnReset_SHIFT  3

#define MPM_CONFIG_EnableCacheClear_OnReset_MASK  0x00000008

#define MPM_CONFIG_MASK \
      (MPM_CONFIG_EnableCacheClear_OnReset_MASK)

#define MPM_CONFIG_DEFAULT             0x00000000

#define MPM_CONFIG_GET_EnableCacheClear_OnReset(mpm_config) \
      ((mpm_config & MPM_CONFIG_EnableCacheClear_OnReset_MASK) >> MPM_CONFIG_EnableCacheClear_OnReset_SHIFT)

#define MPM_CONFIG_SET_EnableCacheClear_OnReset(mpm_config_reg, enablecacheclear_onreset) \
      mpm_config_reg = (mpm_config_reg & ~MPM_CONFIG_EnableCacheClear_OnReset_MASK) | (enablecacheclear_onreset << MPM_CONFIG_EnableCacheClear_OnReset_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_config_t {
            unsigned int                                : 3;
            unsigned int enablecacheclear_onreset       : MPM_CONFIG_EnableCacheClear_OnReset_SIZE;
            unsigned int                                : 28;
      } mpm_config_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_config_t {
            unsigned int                                : 28;
            unsigned int enablecacheclear_onreset       : MPM_CONFIG_EnableCacheClear_OnReset_SIZE;
            unsigned int                                : 3;
      } mpm_config_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_config_t f;
} mpm_config_u;


/*
 * MPM_PMI_0_START struct
 */

#define MPM_PMI_0_START_REG_SIZE         32
#define MPM_PMI_0_START_ADDR_SIZE  18
#define MPM_PMI_0_START_ENABLE_SIZE  1

#define MPM_PMI_0_START_ADDR_SHIFT  0
#define MPM_PMI_0_START_ENABLE_SHIFT  31

#define MPM_PMI_0_START_ADDR_MASK       0x0003ffff
#define MPM_PMI_0_START_ENABLE_MASK     0x80000000

#define MPM_PMI_0_START_MASK \
      (MPM_PMI_0_START_ADDR_MASK | \
      MPM_PMI_0_START_ENABLE_MASK)

#define MPM_PMI_0_START_DEFAULT        0x00000000

#define MPM_PMI_0_START_GET_ADDR(mpm_pmi_0_start) \
      ((mpm_pmi_0_start & MPM_PMI_0_START_ADDR_MASK) >> MPM_PMI_0_START_ADDR_SHIFT)
#define MPM_PMI_0_START_GET_ENABLE(mpm_pmi_0_start) \
      ((mpm_pmi_0_start & MPM_PMI_0_START_ENABLE_MASK) >> MPM_PMI_0_START_ENABLE_SHIFT)

#define MPM_PMI_0_START_SET_ADDR(mpm_pmi_0_start_reg, addr) \
      mpm_pmi_0_start_reg = (mpm_pmi_0_start_reg & ~MPM_PMI_0_START_ADDR_MASK) | (addr << MPM_PMI_0_START_ADDR_SHIFT)
#define MPM_PMI_0_START_SET_ENABLE(mpm_pmi_0_start_reg, enable) \
      mpm_pmi_0_start_reg = (mpm_pmi_0_start_reg & ~MPM_PMI_0_START_ENABLE_MASK) | (enable << MPM_PMI_0_START_ENABLE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_0_start_t {
            unsigned int addr                           : MPM_PMI_0_START_ADDR_SIZE;
            unsigned int                                : 13;
            unsigned int enable                         : MPM_PMI_0_START_ENABLE_SIZE;
      } mpm_pmi_0_start_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_0_start_t {
            unsigned int enable                         : MPM_PMI_0_START_ENABLE_SIZE;
            unsigned int                                : 13;
            unsigned int addr                           : MPM_PMI_0_START_ADDR_SIZE;
      } mpm_pmi_0_start_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_0_start_t f;
} mpm_pmi_0_start_u;


/*
 * MPM_PMI_0_FIFO struct
 */

#define MPM_PMI_0_FIFO_REG_SIZE         32
#define MPM_PMI_0_FIFO_DEPTH_SIZE  4

#define MPM_PMI_0_FIFO_DEPTH_SHIFT  0

#define MPM_PMI_0_FIFO_DEPTH_MASK       0x0000000f

#define MPM_PMI_0_FIFO_MASK \
      (MPM_PMI_0_FIFO_DEPTH_MASK)

#define MPM_PMI_0_FIFO_DEFAULT         0x00000004

#define MPM_PMI_0_FIFO_GET_DEPTH(mpm_pmi_0_fifo) \
      ((mpm_pmi_0_fifo & MPM_PMI_0_FIFO_DEPTH_MASK) >> MPM_PMI_0_FIFO_DEPTH_SHIFT)

#define MPM_PMI_0_FIFO_SET_DEPTH(mpm_pmi_0_fifo_reg, depth) \
      mpm_pmi_0_fifo_reg = (mpm_pmi_0_fifo_reg & ~MPM_PMI_0_FIFO_DEPTH_MASK) | (depth << MPM_PMI_0_FIFO_DEPTH_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_0_fifo_t {
            unsigned int depth                          : MPM_PMI_0_FIFO_DEPTH_SIZE;
            unsigned int                                : 28;
      } mpm_pmi_0_fifo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_0_fifo_t {
            unsigned int                                : 28;
            unsigned int depth                          : MPM_PMI_0_FIFO_DEPTH_SIZE;
      } mpm_pmi_0_fifo_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_0_fifo_t f;
} mpm_pmi_0_fifo_u;


/*
 * MPM_PMI_0_STATUS struct
 */

#define MPM_PMI_0_STATUS_REG_SIZE         32
#define MPM_PMI_0_STATUS_FULL_SIZE  1
#define MPM_PMI_0_STATUS_EMPTY_SIZE  1

#define MPM_PMI_0_STATUS_FULL_SHIFT  0
#define MPM_PMI_0_STATUS_EMPTY_SHIFT  1

#define MPM_PMI_0_STATUS_FULL_MASK      0x00000001
#define MPM_PMI_0_STATUS_EMPTY_MASK     0x00000002

#define MPM_PMI_0_STATUS_MASK \
      (MPM_PMI_0_STATUS_FULL_MASK | \
      MPM_PMI_0_STATUS_EMPTY_MASK)

#define MPM_PMI_0_STATUS_DEFAULT       0x00000002

#define MPM_PMI_0_STATUS_GET_FULL(mpm_pmi_0_status) \
      ((mpm_pmi_0_status & MPM_PMI_0_STATUS_FULL_MASK) >> MPM_PMI_0_STATUS_FULL_SHIFT)
#define MPM_PMI_0_STATUS_GET_EMPTY(mpm_pmi_0_status) \
      ((mpm_pmi_0_status & MPM_PMI_0_STATUS_EMPTY_MASK) >> MPM_PMI_0_STATUS_EMPTY_SHIFT)

#define MPM_PMI_0_STATUS_SET_FULL(mpm_pmi_0_status_reg, full) \
      mpm_pmi_0_status_reg = (mpm_pmi_0_status_reg & ~MPM_PMI_0_STATUS_FULL_MASK) | (full << MPM_PMI_0_STATUS_FULL_SHIFT)
#define MPM_PMI_0_STATUS_SET_EMPTY(mpm_pmi_0_status_reg, empty) \
      mpm_pmi_0_status_reg = (mpm_pmi_0_status_reg & ~MPM_PMI_0_STATUS_EMPTY_MASK) | (empty << MPM_PMI_0_STATUS_EMPTY_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_0_status_t {
            unsigned int full                           : MPM_PMI_0_STATUS_FULL_SIZE;
            unsigned int empty                          : MPM_PMI_0_STATUS_EMPTY_SIZE;
            unsigned int                                : 30;
      } mpm_pmi_0_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_0_status_t {
            unsigned int                                : 30;
            unsigned int empty                          : MPM_PMI_0_STATUS_EMPTY_SIZE;
            unsigned int full                           : MPM_PMI_0_STATUS_FULL_SIZE;
      } mpm_pmi_0_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_0_status_t f;
} mpm_pmi_0_status_u;


/*
 * MPM_PMI_0_READ_POINTER struct
 */

#define MPM_PMI_0_READ_POINTER_REG_SIZE         32
#define MPM_PMI_0_READ_POINTER_CURRENT_SIZE  18

#define MPM_PMI_0_READ_POINTER_CURRENT_SHIFT  0

#define MPM_PMI_0_READ_POINTER_CURRENT_MASK  0x0003ffff

#define MPM_PMI_0_READ_POINTER_MASK \
      (MPM_PMI_0_READ_POINTER_CURRENT_MASK)

#define MPM_PMI_0_READ_POINTER_DEFAULT 0x00000000

#define MPM_PMI_0_READ_POINTER_GET_CURRENT(mpm_pmi_0_read_pointer) \
      ((mpm_pmi_0_read_pointer & MPM_PMI_0_READ_POINTER_CURRENT_MASK) >> MPM_PMI_0_READ_POINTER_CURRENT_SHIFT)

#define MPM_PMI_0_READ_POINTER_SET_CURRENT(mpm_pmi_0_read_pointer_reg, current) \
      mpm_pmi_0_read_pointer_reg = (mpm_pmi_0_read_pointer_reg & ~MPM_PMI_0_READ_POINTER_CURRENT_MASK) | (current << MPM_PMI_0_READ_POINTER_CURRENT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_0_read_pointer_t {
            unsigned int current                        : MPM_PMI_0_READ_POINTER_CURRENT_SIZE;
            unsigned int                                : 14;
      } mpm_pmi_0_read_pointer_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_0_read_pointer_t {
            unsigned int                                : 14;
            unsigned int current                        : MPM_PMI_0_READ_POINTER_CURRENT_SIZE;
      } mpm_pmi_0_read_pointer_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_0_read_pointer_t f;
} mpm_pmi_0_read_pointer_u;


/*
 * MPM_PMI_0_WRITE_POINTER struct
 */

#define MPM_PMI_0_WRITE_POINTER_REG_SIZE         32
#define MPM_PMI_0_WRITE_POINTER_CURRENT_SIZE  18

#define MPM_PMI_0_WRITE_POINTER_CURRENT_SHIFT  0

#define MPM_PMI_0_WRITE_POINTER_CURRENT_MASK  0x0003ffff

#define MPM_PMI_0_WRITE_POINTER_MASK \
      (MPM_PMI_0_WRITE_POINTER_CURRENT_MASK)

#define MPM_PMI_0_WRITE_POINTER_DEFAULT 0x00000000

#define MPM_PMI_0_WRITE_POINTER_GET_CURRENT(mpm_pmi_0_write_pointer) \
      ((mpm_pmi_0_write_pointer & MPM_PMI_0_WRITE_POINTER_CURRENT_MASK) >> MPM_PMI_0_WRITE_POINTER_CURRENT_SHIFT)

#define MPM_PMI_0_WRITE_POINTER_SET_CURRENT(mpm_pmi_0_write_pointer_reg, current) \
      mpm_pmi_0_write_pointer_reg = (mpm_pmi_0_write_pointer_reg & ~MPM_PMI_0_WRITE_POINTER_CURRENT_MASK) | (current << MPM_PMI_0_WRITE_POINTER_CURRENT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_0_write_pointer_t {
            unsigned int current                        : MPM_PMI_0_WRITE_POINTER_CURRENT_SIZE;
            unsigned int                                : 14;
      } mpm_pmi_0_write_pointer_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_0_write_pointer_t {
            unsigned int                                : 14;
            unsigned int current                        : MPM_PMI_0_WRITE_POINTER_CURRENT_SIZE;
      } mpm_pmi_0_write_pointer_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_0_write_pointer_t f;
} mpm_pmi_0_write_pointer_u;


/*
 * MPM_PMI_1_START struct
 */

#define MPM_PMI_1_START_REG_SIZE         32
#define MPM_PMI_1_START_ADDR_SIZE  18
#define MPM_PMI_1_START_ENABLE_SIZE  1

#define MPM_PMI_1_START_ADDR_SHIFT  0
#define MPM_PMI_1_START_ENABLE_SHIFT  31

#define MPM_PMI_1_START_ADDR_MASK       0x0003ffff
#define MPM_PMI_1_START_ENABLE_MASK     0x80000000

#define MPM_PMI_1_START_MASK \
      (MPM_PMI_1_START_ADDR_MASK | \
      MPM_PMI_1_START_ENABLE_MASK)

#define MPM_PMI_1_START_DEFAULT        0x00000000

#define MPM_PMI_1_START_GET_ADDR(mpm_pmi_1_start) \
      ((mpm_pmi_1_start & MPM_PMI_1_START_ADDR_MASK) >> MPM_PMI_1_START_ADDR_SHIFT)
#define MPM_PMI_1_START_GET_ENABLE(mpm_pmi_1_start) \
      ((mpm_pmi_1_start & MPM_PMI_1_START_ENABLE_MASK) >> MPM_PMI_1_START_ENABLE_SHIFT)

#define MPM_PMI_1_START_SET_ADDR(mpm_pmi_1_start_reg, addr) \
      mpm_pmi_1_start_reg = (mpm_pmi_1_start_reg & ~MPM_PMI_1_START_ADDR_MASK) | (addr << MPM_PMI_1_START_ADDR_SHIFT)
#define MPM_PMI_1_START_SET_ENABLE(mpm_pmi_1_start_reg, enable) \
      mpm_pmi_1_start_reg = (mpm_pmi_1_start_reg & ~MPM_PMI_1_START_ENABLE_MASK) | (enable << MPM_PMI_1_START_ENABLE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_1_start_t {
            unsigned int addr                           : MPM_PMI_1_START_ADDR_SIZE;
            unsigned int                                : 13;
            unsigned int enable                         : MPM_PMI_1_START_ENABLE_SIZE;
      } mpm_pmi_1_start_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_1_start_t {
            unsigned int enable                         : MPM_PMI_1_START_ENABLE_SIZE;
            unsigned int                                : 13;
            unsigned int addr                           : MPM_PMI_1_START_ADDR_SIZE;
      } mpm_pmi_1_start_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_1_start_t f;
} mpm_pmi_1_start_u;


/*
 * MPM_PMI_1_FIFO struct
 */

#define MPM_PMI_1_FIFO_REG_SIZE         32
#define MPM_PMI_1_FIFO_DEPTH_SIZE  4

#define MPM_PMI_1_FIFO_DEPTH_SHIFT  0

#define MPM_PMI_1_FIFO_DEPTH_MASK       0x0000000f

#define MPM_PMI_1_FIFO_MASK \
      (MPM_PMI_1_FIFO_DEPTH_MASK)

#define MPM_PMI_1_FIFO_DEFAULT         0x00000004

#define MPM_PMI_1_FIFO_GET_DEPTH(mpm_pmi_1_fifo) \
      ((mpm_pmi_1_fifo & MPM_PMI_1_FIFO_DEPTH_MASK) >> MPM_PMI_1_FIFO_DEPTH_SHIFT)

#define MPM_PMI_1_FIFO_SET_DEPTH(mpm_pmi_1_fifo_reg, depth) \
      mpm_pmi_1_fifo_reg = (mpm_pmi_1_fifo_reg & ~MPM_PMI_1_FIFO_DEPTH_MASK) | (depth << MPM_PMI_1_FIFO_DEPTH_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_1_fifo_t {
            unsigned int depth                          : MPM_PMI_1_FIFO_DEPTH_SIZE;
            unsigned int                                : 28;
      } mpm_pmi_1_fifo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_1_fifo_t {
            unsigned int                                : 28;
            unsigned int depth                          : MPM_PMI_1_FIFO_DEPTH_SIZE;
      } mpm_pmi_1_fifo_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_1_fifo_t f;
} mpm_pmi_1_fifo_u;


/*
 * MPM_PMI_1_STATUS struct
 */

#define MPM_PMI_1_STATUS_REG_SIZE         32
#define MPM_PMI_1_STATUS_FULL_SIZE  1
#define MPM_PMI_1_STATUS_EMPTY_SIZE  1

#define MPM_PMI_1_STATUS_FULL_SHIFT  0
#define MPM_PMI_1_STATUS_EMPTY_SHIFT  1

#define MPM_PMI_1_STATUS_FULL_MASK      0x00000001
#define MPM_PMI_1_STATUS_EMPTY_MASK     0x00000002

#define MPM_PMI_1_STATUS_MASK \
      (MPM_PMI_1_STATUS_FULL_MASK | \
      MPM_PMI_1_STATUS_EMPTY_MASK)

#define MPM_PMI_1_STATUS_DEFAULT       0x00000002

#define MPM_PMI_1_STATUS_GET_FULL(mpm_pmi_1_status) \
      ((mpm_pmi_1_status & MPM_PMI_1_STATUS_FULL_MASK) >> MPM_PMI_1_STATUS_FULL_SHIFT)
#define MPM_PMI_1_STATUS_GET_EMPTY(mpm_pmi_1_status) \
      ((mpm_pmi_1_status & MPM_PMI_1_STATUS_EMPTY_MASK) >> MPM_PMI_1_STATUS_EMPTY_SHIFT)

#define MPM_PMI_1_STATUS_SET_FULL(mpm_pmi_1_status_reg, full) \
      mpm_pmi_1_status_reg = (mpm_pmi_1_status_reg & ~MPM_PMI_1_STATUS_FULL_MASK) | (full << MPM_PMI_1_STATUS_FULL_SHIFT)
#define MPM_PMI_1_STATUS_SET_EMPTY(mpm_pmi_1_status_reg, empty) \
      mpm_pmi_1_status_reg = (mpm_pmi_1_status_reg & ~MPM_PMI_1_STATUS_EMPTY_MASK) | (empty << MPM_PMI_1_STATUS_EMPTY_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_1_status_t {
            unsigned int full                           : MPM_PMI_1_STATUS_FULL_SIZE;
            unsigned int empty                          : MPM_PMI_1_STATUS_EMPTY_SIZE;
            unsigned int                                : 30;
      } mpm_pmi_1_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_1_status_t {
            unsigned int                                : 30;
            unsigned int empty                          : MPM_PMI_1_STATUS_EMPTY_SIZE;
            unsigned int full                           : MPM_PMI_1_STATUS_FULL_SIZE;
      } mpm_pmi_1_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_1_status_t f;
} mpm_pmi_1_status_u;


/*
 * MPM_PMI_1_READ_POINTER struct
 */

#define MPM_PMI_1_READ_POINTER_REG_SIZE         32
#define MPM_PMI_1_READ_POINTER_CURRENT_SIZE  18

#define MPM_PMI_1_READ_POINTER_CURRENT_SHIFT  0

#define MPM_PMI_1_READ_POINTER_CURRENT_MASK  0x0003ffff

#define MPM_PMI_1_READ_POINTER_MASK \
      (MPM_PMI_1_READ_POINTER_CURRENT_MASK)

#define MPM_PMI_1_READ_POINTER_DEFAULT 0x00000000

#define MPM_PMI_1_READ_POINTER_GET_CURRENT(mpm_pmi_1_read_pointer) \
      ((mpm_pmi_1_read_pointer & MPM_PMI_1_READ_POINTER_CURRENT_MASK) >> MPM_PMI_1_READ_POINTER_CURRENT_SHIFT)

#define MPM_PMI_1_READ_POINTER_SET_CURRENT(mpm_pmi_1_read_pointer_reg, current) \
      mpm_pmi_1_read_pointer_reg = (mpm_pmi_1_read_pointer_reg & ~MPM_PMI_1_READ_POINTER_CURRENT_MASK) | (current << MPM_PMI_1_READ_POINTER_CURRENT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_1_read_pointer_t {
            unsigned int current                        : MPM_PMI_1_READ_POINTER_CURRENT_SIZE;
            unsigned int                                : 14;
      } mpm_pmi_1_read_pointer_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_1_read_pointer_t {
            unsigned int                                : 14;
            unsigned int current                        : MPM_PMI_1_READ_POINTER_CURRENT_SIZE;
      } mpm_pmi_1_read_pointer_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_1_read_pointer_t f;
} mpm_pmi_1_read_pointer_u;


/*
 * MPM_PMI_1_WRITE_POINTER struct
 */

#define MPM_PMI_1_WRITE_POINTER_REG_SIZE         32
#define MPM_PMI_1_WRITE_POINTER_CURRENT_SIZE  18

#define MPM_PMI_1_WRITE_POINTER_CURRENT_SHIFT  0

#define MPM_PMI_1_WRITE_POINTER_CURRENT_MASK  0x0003ffff

#define MPM_PMI_1_WRITE_POINTER_MASK \
      (MPM_PMI_1_WRITE_POINTER_CURRENT_MASK)

#define MPM_PMI_1_WRITE_POINTER_DEFAULT 0x00000000

#define MPM_PMI_1_WRITE_POINTER_GET_CURRENT(mpm_pmi_1_write_pointer) \
      ((mpm_pmi_1_write_pointer & MPM_PMI_1_WRITE_POINTER_CURRENT_MASK) >> MPM_PMI_1_WRITE_POINTER_CURRENT_SHIFT)

#define MPM_PMI_1_WRITE_POINTER_SET_CURRENT(mpm_pmi_1_write_pointer_reg, current) \
      mpm_pmi_1_write_pointer_reg = (mpm_pmi_1_write_pointer_reg & ~MPM_PMI_1_WRITE_POINTER_CURRENT_MASK) | (current << MPM_PMI_1_WRITE_POINTER_CURRENT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_1_write_pointer_t {
            unsigned int current                        : MPM_PMI_1_WRITE_POINTER_CURRENT_SIZE;
            unsigned int                                : 14;
      } mpm_pmi_1_write_pointer_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_1_write_pointer_t {
            unsigned int                                : 14;
            unsigned int current                        : MPM_PMI_1_WRITE_POINTER_CURRENT_SIZE;
      } mpm_pmi_1_write_pointer_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_1_write_pointer_t f;
} mpm_pmi_1_write_pointer_u;


/*
 * MPM_PMI_2_START struct
 */

#define MPM_PMI_2_START_REG_SIZE         32
#define MPM_PMI_2_START_ADDR_SIZE  18
#define MPM_PMI_2_START_ENABLE_SIZE  1

#define MPM_PMI_2_START_ADDR_SHIFT  0
#define MPM_PMI_2_START_ENABLE_SHIFT  31

#define MPM_PMI_2_START_ADDR_MASK       0x0003ffff
#define MPM_PMI_2_START_ENABLE_MASK     0x80000000

#define MPM_PMI_2_START_MASK \
      (MPM_PMI_2_START_ADDR_MASK | \
      MPM_PMI_2_START_ENABLE_MASK)

#define MPM_PMI_2_START_DEFAULT        0x00000000

#define MPM_PMI_2_START_GET_ADDR(mpm_pmi_2_start) \
      ((mpm_pmi_2_start & MPM_PMI_2_START_ADDR_MASK) >> MPM_PMI_2_START_ADDR_SHIFT)
#define MPM_PMI_2_START_GET_ENABLE(mpm_pmi_2_start) \
      ((mpm_pmi_2_start & MPM_PMI_2_START_ENABLE_MASK) >> MPM_PMI_2_START_ENABLE_SHIFT)

#define MPM_PMI_2_START_SET_ADDR(mpm_pmi_2_start_reg, addr) \
      mpm_pmi_2_start_reg = (mpm_pmi_2_start_reg & ~MPM_PMI_2_START_ADDR_MASK) | (addr << MPM_PMI_2_START_ADDR_SHIFT)
#define MPM_PMI_2_START_SET_ENABLE(mpm_pmi_2_start_reg, enable) \
      mpm_pmi_2_start_reg = (mpm_pmi_2_start_reg & ~MPM_PMI_2_START_ENABLE_MASK) | (enable << MPM_PMI_2_START_ENABLE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_2_start_t {
            unsigned int addr                           : MPM_PMI_2_START_ADDR_SIZE;
            unsigned int                                : 13;
            unsigned int enable                         : MPM_PMI_2_START_ENABLE_SIZE;
      } mpm_pmi_2_start_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_2_start_t {
            unsigned int enable                         : MPM_PMI_2_START_ENABLE_SIZE;
            unsigned int                                : 13;
            unsigned int addr                           : MPM_PMI_2_START_ADDR_SIZE;
      } mpm_pmi_2_start_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_2_start_t f;
} mpm_pmi_2_start_u;


/*
 * MPM_PMI_2_FIFO struct
 */

#define MPM_PMI_2_FIFO_REG_SIZE         32
#define MPM_PMI_2_FIFO_DEPTH_SIZE  4

#define MPM_PMI_2_FIFO_DEPTH_SHIFT  0

#define MPM_PMI_2_FIFO_DEPTH_MASK       0x0000000f

#define MPM_PMI_2_FIFO_MASK \
      (MPM_PMI_2_FIFO_DEPTH_MASK)

#define MPM_PMI_2_FIFO_DEFAULT         0x00000004

#define MPM_PMI_2_FIFO_GET_DEPTH(mpm_pmi_2_fifo) \
      ((mpm_pmi_2_fifo & MPM_PMI_2_FIFO_DEPTH_MASK) >> MPM_PMI_2_FIFO_DEPTH_SHIFT)

#define MPM_PMI_2_FIFO_SET_DEPTH(mpm_pmi_2_fifo_reg, depth) \
      mpm_pmi_2_fifo_reg = (mpm_pmi_2_fifo_reg & ~MPM_PMI_2_FIFO_DEPTH_MASK) | (depth << MPM_PMI_2_FIFO_DEPTH_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_2_fifo_t {
            unsigned int depth                          : MPM_PMI_2_FIFO_DEPTH_SIZE;
            unsigned int                                : 28;
      } mpm_pmi_2_fifo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_2_fifo_t {
            unsigned int                                : 28;
            unsigned int depth                          : MPM_PMI_2_FIFO_DEPTH_SIZE;
      } mpm_pmi_2_fifo_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_2_fifo_t f;
} mpm_pmi_2_fifo_u;


/*
 * MPM_PMI_2_STATUS struct
 */

#define MPM_PMI_2_STATUS_REG_SIZE         32
#define MPM_PMI_2_STATUS_FULL_SIZE  1
#define MPM_PMI_2_STATUS_EMPTY_SIZE  1

#define MPM_PMI_2_STATUS_FULL_SHIFT  0
#define MPM_PMI_2_STATUS_EMPTY_SHIFT  1

#define MPM_PMI_2_STATUS_FULL_MASK      0x00000001
#define MPM_PMI_2_STATUS_EMPTY_MASK     0x00000002

#define MPM_PMI_2_STATUS_MASK \
      (MPM_PMI_2_STATUS_FULL_MASK | \
      MPM_PMI_2_STATUS_EMPTY_MASK)

#define MPM_PMI_2_STATUS_DEFAULT       0x00000002

#define MPM_PMI_2_STATUS_GET_FULL(mpm_pmi_2_status) \
      ((mpm_pmi_2_status & MPM_PMI_2_STATUS_FULL_MASK) >> MPM_PMI_2_STATUS_FULL_SHIFT)
#define MPM_PMI_2_STATUS_GET_EMPTY(mpm_pmi_2_status) \
      ((mpm_pmi_2_status & MPM_PMI_2_STATUS_EMPTY_MASK) >> MPM_PMI_2_STATUS_EMPTY_SHIFT)

#define MPM_PMI_2_STATUS_SET_FULL(mpm_pmi_2_status_reg, full) \
      mpm_pmi_2_status_reg = (mpm_pmi_2_status_reg & ~MPM_PMI_2_STATUS_FULL_MASK) | (full << MPM_PMI_2_STATUS_FULL_SHIFT)
#define MPM_PMI_2_STATUS_SET_EMPTY(mpm_pmi_2_status_reg, empty) \
      mpm_pmi_2_status_reg = (mpm_pmi_2_status_reg & ~MPM_PMI_2_STATUS_EMPTY_MASK) | (empty << MPM_PMI_2_STATUS_EMPTY_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_2_status_t {
            unsigned int full                           : MPM_PMI_2_STATUS_FULL_SIZE;
            unsigned int empty                          : MPM_PMI_2_STATUS_EMPTY_SIZE;
            unsigned int                                : 30;
      } mpm_pmi_2_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_2_status_t {
            unsigned int                                : 30;
            unsigned int empty                          : MPM_PMI_2_STATUS_EMPTY_SIZE;
            unsigned int full                           : MPM_PMI_2_STATUS_FULL_SIZE;
      } mpm_pmi_2_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_2_status_t f;
} mpm_pmi_2_status_u;


/*
 * MPM_PMI_2_READ_POINTER struct
 */

#define MPM_PMI_2_READ_POINTER_REG_SIZE         32
#define MPM_PMI_2_READ_POINTER_CURRENT_SIZE  18

#define MPM_PMI_2_READ_POINTER_CURRENT_SHIFT  0

#define MPM_PMI_2_READ_POINTER_CURRENT_MASK  0x0003ffff

#define MPM_PMI_2_READ_POINTER_MASK \
      (MPM_PMI_2_READ_POINTER_CURRENT_MASK)

#define MPM_PMI_2_READ_POINTER_DEFAULT 0x00000000

#define MPM_PMI_2_READ_POINTER_GET_CURRENT(mpm_pmi_2_read_pointer) \
      ((mpm_pmi_2_read_pointer & MPM_PMI_2_READ_POINTER_CURRENT_MASK) >> MPM_PMI_2_READ_POINTER_CURRENT_SHIFT)

#define MPM_PMI_2_READ_POINTER_SET_CURRENT(mpm_pmi_2_read_pointer_reg, current) \
      mpm_pmi_2_read_pointer_reg = (mpm_pmi_2_read_pointer_reg & ~MPM_PMI_2_READ_POINTER_CURRENT_MASK) | (current << MPM_PMI_2_READ_POINTER_CURRENT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_2_read_pointer_t {
            unsigned int current                        : MPM_PMI_2_READ_POINTER_CURRENT_SIZE;
            unsigned int                                : 14;
      } mpm_pmi_2_read_pointer_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_2_read_pointer_t {
            unsigned int                                : 14;
            unsigned int current                        : MPM_PMI_2_READ_POINTER_CURRENT_SIZE;
      } mpm_pmi_2_read_pointer_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_2_read_pointer_t f;
} mpm_pmi_2_read_pointer_u;


/*
 * MPM_PMI_2_WRITE_POINTER struct
 */

#define MPM_PMI_2_WRITE_POINTER_REG_SIZE         32
#define MPM_PMI_2_WRITE_POINTER_CURRENT_SIZE  18

#define MPM_PMI_2_WRITE_POINTER_CURRENT_SHIFT  0

#define MPM_PMI_2_WRITE_POINTER_CURRENT_MASK  0x0003ffff

#define MPM_PMI_2_WRITE_POINTER_MASK \
      (MPM_PMI_2_WRITE_POINTER_CURRENT_MASK)

#define MPM_PMI_2_WRITE_POINTER_DEFAULT 0x00000000

#define MPM_PMI_2_WRITE_POINTER_GET_CURRENT(mpm_pmi_2_write_pointer) \
      ((mpm_pmi_2_write_pointer & MPM_PMI_2_WRITE_POINTER_CURRENT_MASK) >> MPM_PMI_2_WRITE_POINTER_CURRENT_SHIFT)

#define MPM_PMI_2_WRITE_POINTER_SET_CURRENT(mpm_pmi_2_write_pointer_reg, current) \
      mpm_pmi_2_write_pointer_reg = (mpm_pmi_2_write_pointer_reg & ~MPM_PMI_2_WRITE_POINTER_CURRENT_MASK) | (current << MPM_PMI_2_WRITE_POINTER_CURRENT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_2_write_pointer_t {
            unsigned int current                        : MPM_PMI_2_WRITE_POINTER_CURRENT_SIZE;
            unsigned int                                : 14;
      } mpm_pmi_2_write_pointer_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_2_write_pointer_t {
            unsigned int                                : 14;
            unsigned int current                        : MPM_PMI_2_WRITE_POINTER_CURRENT_SIZE;
      } mpm_pmi_2_write_pointer_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_2_write_pointer_t f;
} mpm_pmi_2_write_pointer_u;


/*
 * MPM_PMI_OUT_CONFIG struct
 */

#define MPM_PMI_OUT_CONFIG_REG_SIZE         32
#define MPM_PMI_OUT_CONFIG_PMI0_OUT_SEL_SIZE  2
#define MPM_PMI_OUT_CONFIG_PMI1_OUT_SEL_SIZE  2
#define MPM_PMI_OUT_CONFIG_PMI2_OUT_SEL_SIZE  2

#define MPM_PMI_OUT_CONFIG_PMI0_OUT_SEL_SHIFT  0
#define MPM_PMI_OUT_CONFIG_PMI1_OUT_SEL_SHIFT  2
#define MPM_PMI_OUT_CONFIG_PMI2_OUT_SEL_SHIFT  4

#define MPM_PMI_OUT_CONFIG_PMI0_OUT_SEL_MASK  0x00000003
#define MPM_PMI_OUT_CONFIG_PMI1_OUT_SEL_MASK  0x0000000c
#define MPM_PMI_OUT_CONFIG_PMI2_OUT_SEL_MASK  0x00000030

#define MPM_PMI_OUT_CONFIG_MASK \
      (MPM_PMI_OUT_CONFIG_PMI0_OUT_SEL_MASK | \
      MPM_PMI_OUT_CONFIG_PMI1_OUT_SEL_MASK | \
      MPM_PMI_OUT_CONFIG_PMI2_OUT_SEL_MASK)

#define MPM_PMI_OUT_CONFIG_DEFAULT     0x00000024

#define MPM_PMI_OUT_CONFIG_GET_PMI0_OUT_SEL(mpm_pmi_out_config) \
      ((mpm_pmi_out_config & MPM_PMI_OUT_CONFIG_PMI0_OUT_SEL_MASK) >> MPM_PMI_OUT_CONFIG_PMI0_OUT_SEL_SHIFT)
#define MPM_PMI_OUT_CONFIG_GET_PMI1_OUT_SEL(mpm_pmi_out_config) \
      ((mpm_pmi_out_config & MPM_PMI_OUT_CONFIG_PMI1_OUT_SEL_MASK) >> MPM_PMI_OUT_CONFIG_PMI1_OUT_SEL_SHIFT)
#define MPM_PMI_OUT_CONFIG_GET_PMI2_OUT_SEL(mpm_pmi_out_config) \
      ((mpm_pmi_out_config & MPM_PMI_OUT_CONFIG_PMI2_OUT_SEL_MASK) >> MPM_PMI_OUT_CONFIG_PMI2_OUT_SEL_SHIFT)

#define MPM_PMI_OUT_CONFIG_SET_PMI0_OUT_SEL(mpm_pmi_out_config_reg, pmi0_out_sel) \
      mpm_pmi_out_config_reg = (mpm_pmi_out_config_reg & ~MPM_PMI_OUT_CONFIG_PMI0_OUT_SEL_MASK) | (pmi0_out_sel << MPM_PMI_OUT_CONFIG_PMI0_OUT_SEL_SHIFT)
#define MPM_PMI_OUT_CONFIG_SET_PMI1_OUT_SEL(mpm_pmi_out_config_reg, pmi1_out_sel) \
      mpm_pmi_out_config_reg = (mpm_pmi_out_config_reg & ~MPM_PMI_OUT_CONFIG_PMI1_OUT_SEL_MASK) | (pmi1_out_sel << MPM_PMI_OUT_CONFIG_PMI1_OUT_SEL_SHIFT)
#define MPM_PMI_OUT_CONFIG_SET_PMI2_OUT_SEL(mpm_pmi_out_config_reg, pmi2_out_sel) \
      mpm_pmi_out_config_reg = (mpm_pmi_out_config_reg & ~MPM_PMI_OUT_CONFIG_PMI2_OUT_SEL_MASK) | (pmi2_out_sel << MPM_PMI_OUT_CONFIG_PMI2_OUT_SEL_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_out_config_t {
            unsigned int pmi0_out_sel                   : MPM_PMI_OUT_CONFIG_PMI0_OUT_SEL_SIZE;
            unsigned int pmi1_out_sel                   : MPM_PMI_OUT_CONFIG_PMI1_OUT_SEL_SIZE;
            unsigned int pmi2_out_sel                   : MPM_PMI_OUT_CONFIG_PMI2_OUT_SEL_SIZE;
            unsigned int                                : 26;
      } mpm_pmi_out_config_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_out_config_t {
            unsigned int                                : 26;
            unsigned int pmi2_out_sel                   : MPM_PMI_OUT_CONFIG_PMI2_OUT_SEL_SIZE;
            unsigned int pmi1_out_sel                   : MPM_PMI_OUT_CONFIG_PMI1_OUT_SEL_SIZE;
            unsigned int pmi0_out_sel                   : MPM_PMI_OUT_CONFIG_PMI0_OUT_SEL_SIZE;
      } mpm_pmi_out_config_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_out_config_t f;
} mpm_pmi_out_config_u;


/*
 * MPM_PMI_RELOAD struct
 */

#define MPM_PMI_RELOAD_REG_SIZE         32
#define MPM_PMI_RELOAD_PMI_PARAMETERS_SIZE  3

#define MPM_PMI_RELOAD_PMI_PARAMETERS_SHIFT  0

#define MPM_PMI_RELOAD_PMI_PARAMETERS_MASK  0x00000007

#define MPM_PMI_RELOAD_MASK \
      (MPM_PMI_RELOAD_PMI_PARAMETERS_MASK)

#define MPM_PMI_RELOAD_DEFAULT         0x00000000

#define MPM_PMI_RELOAD_GET_PMI_PARAMETERS(mpm_pmi_reload) \
      ((mpm_pmi_reload & MPM_PMI_RELOAD_PMI_PARAMETERS_MASK) >> MPM_PMI_RELOAD_PMI_PARAMETERS_SHIFT)

#define MPM_PMI_RELOAD_SET_PMI_PARAMETERS(mpm_pmi_reload_reg, pmi_parameters) \
      mpm_pmi_reload_reg = (mpm_pmi_reload_reg & ~MPM_PMI_RELOAD_PMI_PARAMETERS_MASK) | (pmi_parameters << MPM_PMI_RELOAD_PMI_PARAMETERS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_reload_t {
            unsigned int pmi_parameters                 : MPM_PMI_RELOAD_PMI_PARAMETERS_SIZE;
            unsigned int                                : 29;
      } mpm_pmi_reload_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_reload_t {
            unsigned int                                : 29;
            unsigned int pmi_parameters                 : MPM_PMI_RELOAD_PMI_PARAMETERS_SIZE;
      } mpm_pmi_reload_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_reload_t f;
} mpm_pmi_reload_u;


/*
 * MPM_PMI_INTERRUPT_CONTROL struct
 */

#define MPM_PMI_INTERRUPT_CONTROL_REG_SIZE         32
#define MPM_PMI_INTERRUPT_CONTROL_PMI_PENDING_SIZE  3
#define MPM_PMI_INTERRUPT_CONTROL_PMI_INTERRUPT_MASK_SIZE  3
#define MPM_PMI_INTERRUPT_CONTROL_PMI_FULL_PENDING_SIZE  3
#define MPM_PMI_INTERRUPT_CONTROL_PMI_FULLINTERRUPT_MASK_SIZE  3

#define MPM_PMI_INTERRUPT_CONTROL_PMI_PENDING_SHIFT  0
#define MPM_PMI_INTERRUPT_CONTROL_PMI_INTERRUPT_MASK_SHIFT  3
#define MPM_PMI_INTERRUPT_CONTROL_PMI_FULL_PENDING_SHIFT  6
#define MPM_PMI_INTERRUPT_CONTROL_PMI_FULLINTERRUPT_MASK_SHIFT  9

#define MPM_PMI_INTERRUPT_CONTROL_PMI_PENDING_MASK  0x00000007
#define MPM_PMI_INTERRUPT_CONTROL_PMI_INTERRUPT_MASK_MASK  0x00000038
#define MPM_PMI_INTERRUPT_CONTROL_PMI_FULL_PENDING_MASK  0x000001c0
#define MPM_PMI_INTERRUPT_CONTROL_PMI_FULLINTERRUPT_MASK_MASK  0x00000e00

#define MPM_PMI_INTERRUPT_CONTROL_MASK \
      (MPM_PMI_INTERRUPT_CONTROL_PMI_PENDING_MASK | \
      MPM_PMI_INTERRUPT_CONTROL_PMI_INTERRUPT_MASK_MASK | \
      MPM_PMI_INTERRUPT_CONTROL_PMI_FULL_PENDING_MASK | \
      MPM_PMI_INTERRUPT_CONTROL_PMI_FULLINTERRUPT_MASK_MASK)

#define MPM_PMI_INTERRUPT_CONTROL_DEFAULT 0x00000000

#define MPM_PMI_INTERRUPT_CONTROL_GET_PMI_PENDING(mpm_pmi_interrupt_control) \
      ((mpm_pmi_interrupt_control & MPM_PMI_INTERRUPT_CONTROL_PMI_PENDING_MASK) >> MPM_PMI_INTERRUPT_CONTROL_PMI_PENDING_SHIFT)
#define MPM_PMI_INTERRUPT_CONTROL_GET_PMI_INTERRUPT_MASK(mpm_pmi_interrupt_control) \
      ((mpm_pmi_interrupt_control & MPM_PMI_INTERRUPT_CONTROL_PMI_INTERRUPT_MASK_MASK) >> MPM_PMI_INTERRUPT_CONTROL_PMI_INTERRUPT_MASK_SHIFT)
#define MPM_PMI_INTERRUPT_CONTROL_GET_PMI_FULL_PENDING(mpm_pmi_interrupt_control) \
      ((mpm_pmi_interrupt_control & MPM_PMI_INTERRUPT_CONTROL_PMI_FULL_PENDING_MASK) >> MPM_PMI_INTERRUPT_CONTROL_PMI_FULL_PENDING_SHIFT)
#define MPM_PMI_INTERRUPT_CONTROL_GET_PMI_FULLINTERRUPT_MASK(mpm_pmi_interrupt_control) \
      ((mpm_pmi_interrupt_control & MPM_PMI_INTERRUPT_CONTROL_PMI_FULLINTERRUPT_MASK_MASK) >> MPM_PMI_INTERRUPT_CONTROL_PMI_FULLINTERRUPT_MASK_SHIFT)

#define MPM_PMI_INTERRUPT_CONTROL_SET_PMI_PENDING(mpm_pmi_interrupt_control_reg, pmi_pending) \
      mpm_pmi_interrupt_control_reg = (mpm_pmi_interrupt_control_reg & ~MPM_PMI_INTERRUPT_CONTROL_PMI_PENDING_MASK) | (pmi_pending << MPM_PMI_INTERRUPT_CONTROL_PMI_PENDING_SHIFT)
#define MPM_PMI_INTERRUPT_CONTROL_SET_PMI_INTERRUPT_MASK(mpm_pmi_interrupt_control_reg, pmi_interrupt_mask) \
      mpm_pmi_interrupt_control_reg = (mpm_pmi_interrupt_control_reg & ~MPM_PMI_INTERRUPT_CONTROL_PMI_INTERRUPT_MASK_MASK) | (pmi_interrupt_mask << MPM_PMI_INTERRUPT_CONTROL_PMI_INTERRUPT_MASK_SHIFT)
#define MPM_PMI_INTERRUPT_CONTROL_SET_PMI_FULL_PENDING(mpm_pmi_interrupt_control_reg, pmi_full_pending) \
      mpm_pmi_interrupt_control_reg = (mpm_pmi_interrupt_control_reg & ~MPM_PMI_INTERRUPT_CONTROL_PMI_FULL_PENDING_MASK) | (pmi_full_pending << MPM_PMI_INTERRUPT_CONTROL_PMI_FULL_PENDING_SHIFT)
#define MPM_PMI_INTERRUPT_CONTROL_SET_PMI_FULLINTERRUPT_MASK(mpm_pmi_interrupt_control_reg, pmi_fullinterrupt_mask) \
      mpm_pmi_interrupt_control_reg = (mpm_pmi_interrupt_control_reg & ~MPM_PMI_INTERRUPT_CONTROL_PMI_FULLINTERRUPT_MASK_MASK) | (pmi_fullinterrupt_mask << MPM_PMI_INTERRUPT_CONTROL_PMI_FULLINTERRUPT_MASK_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_interrupt_control_t {
            unsigned int pmi_pending                    : MPM_PMI_INTERRUPT_CONTROL_PMI_PENDING_SIZE;
            unsigned int pmi_interrupt_mask             : MPM_PMI_INTERRUPT_CONTROL_PMI_INTERRUPT_MASK_SIZE;
            unsigned int pmi_full_pending               : MPM_PMI_INTERRUPT_CONTROL_PMI_FULL_PENDING_SIZE;
            unsigned int pmi_fullinterrupt_mask         : MPM_PMI_INTERRUPT_CONTROL_PMI_FULLINTERRUPT_MASK_SIZE;
            unsigned int                                : 20;
      } mpm_pmi_interrupt_control_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_interrupt_control_t {
            unsigned int                                : 20;
            unsigned int pmi_fullinterrupt_mask         : MPM_PMI_INTERRUPT_CONTROL_PMI_FULLINTERRUPT_MASK_SIZE;
            unsigned int pmi_full_pending               : MPM_PMI_INTERRUPT_CONTROL_PMI_FULL_PENDING_SIZE;
            unsigned int pmi_interrupt_mask             : MPM_PMI_INTERRUPT_CONTROL_PMI_INTERRUPT_MASK_SIZE;
            unsigned int pmi_pending                    : MPM_PMI_INTERRUPT_CONTROL_PMI_PENDING_SIZE;
      } mpm_pmi_interrupt_control_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_interrupt_control_t f;
} mpm_pmi_interrupt_control_u;


/*
 * MPM_MMU_SRAM_ACC_VIOLATION_LOG_ADDR struct
 */

#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_REG_SIZE         32
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SIZE  32

#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SHIFT  0

#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK  0xffffffff

#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_MASK \
      (MPM_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK)

#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_DEFAULT 0x00000000

#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_GET_ADDRESS(mpm_mmu_sram_acc_violation_log_addr) \
      ((mpm_mmu_sram_acc_violation_log_addr & MPM_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK) >> MPM_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SHIFT)

#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_SET_ADDRESS(mpm_mmu_sram_acc_violation_log_addr_reg, address) \
      mpm_mmu_sram_acc_violation_log_addr_reg = (mpm_mmu_sram_acc_violation_log_addr_reg & ~MPM_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK) | (address << MPM_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_mmu_sram_acc_violation_log_addr_t {
            unsigned int address                        : MPM_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SIZE;
      } mpm_mmu_sram_acc_violation_log_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_mmu_sram_acc_violation_log_addr_t {
            unsigned int address                        : MPM_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SIZE;
      } mpm_mmu_sram_acc_violation_log_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_mmu_sram_acc_violation_log_addr_t f;
} mpm_mmu_sram_acc_violation_log_addr_u;


/*
 * MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS struct
 */

#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_REG_SIZE         32
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE  1
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SIZE  1
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SIZE  1
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE  2
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SIZE  2
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SIZE  7
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SIZE  10
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SIZE  1
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE  1

#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT  0
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SHIFT  1
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SHIFT  3
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT  4
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SHIFT  6
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SHIFT  8
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SHIFT  15
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SHIFT  30
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT  31

#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK  0x00000001
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_MASK  0x00000002
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_MASK  0x00000008
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK  0x00000030
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_MASK  0x000000c0
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_MASK  0x00007f00
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_MASK  0x01ff8000
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_MASK  0x40000000
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK  0x80000000

#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_MASK \
      (MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK | \
      MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_MASK | \
      MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_MASK | \
      MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK | \
      MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_MASK | \
      MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_MASK | \
      MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_MASK | \
      MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_MASK | \
      MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK)

#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_DEFAULT 0x00000000

#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_DETECTED(mpm_mmu_sram_acc_violation_log_status) \
      ((mpm_mmu_sram_acc_violation_log_status & MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) >> MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_UNSECURE_BAR(mpm_mmu_sram_acc_violation_log_status) \
      ((mpm_mmu_sram_acc_violation_log_status & MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_MASK) >> MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SHIFT)
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_OP(mpm_mmu_sram_acc_violation_log_status) \
      ((mpm_mmu_sram_acc_violation_log_status & MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_MASK) >> MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SHIFT)
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_TYPE(mpm_mmu_sram_acc_violation_log_status) \
      ((mpm_mmu_sram_acc_violation_log_status & MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) >> MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_PERMISSION(mpm_mmu_sram_acc_violation_log_status) \
      ((mpm_mmu_sram_acc_violation_log_status & MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_MASK) >> MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SHIFT)
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_AXI_UNIT_ID(mpm_mmu_sram_acc_violation_log_status) \
      ((mpm_mmu_sram_acc_violation_log_status & MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_MASK) >> MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SHIFT)
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_AXI_INIT_ID(mpm_mmu_sram_acc_violation_log_status) \
      ((mpm_mmu_sram_acc_violation_log_status & MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_MASK) >> MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SHIFT)
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_SRAM_NS0_VIOL_CLEAR(mpm_mmu_sram_acc_violation_log_status) \
      ((mpm_mmu_sram_acc_violation_log_status & MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_MASK) >> MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SHIFT)
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_LOG_CLEAR(mpm_mmu_sram_acc_violation_log_status) \
      ((mpm_mmu_sram_acc_violation_log_status & MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) >> MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)

#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_DETECTED(mpm_mmu_sram_acc_violation_log_status_reg, acc_violation_detected) \
      mpm_mmu_sram_acc_violation_log_status_reg = (mpm_mmu_sram_acc_violation_log_status_reg & ~MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) | (acc_violation_detected << MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_UNSECURE_BAR(mpm_mmu_sram_acc_violation_log_status_reg, acc_violation_unsecure_bar) \
      mpm_mmu_sram_acc_violation_log_status_reg = (mpm_mmu_sram_acc_violation_log_status_reg & ~MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_MASK) | (acc_violation_unsecure_bar << MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SHIFT)
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_OP(mpm_mmu_sram_acc_violation_log_status_reg, acc_violation_op) \
      mpm_mmu_sram_acc_violation_log_status_reg = (mpm_mmu_sram_acc_violation_log_status_reg & ~MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_MASK) | (acc_violation_op << MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SHIFT)
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_TYPE(mpm_mmu_sram_acc_violation_log_status_reg, acc_violation_type) \
      mpm_mmu_sram_acc_violation_log_status_reg = (mpm_mmu_sram_acc_violation_log_status_reg & ~MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) | (acc_violation_type << MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_PERMISSION(mpm_mmu_sram_acc_violation_log_status_reg, acc_violation_permission) \
      mpm_mmu_sram_acc_violation_log_status_reg = (mpm_mmu_sram_acc_violation_log_status_reg & ~MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_MASK) | (acc_violation_permission << MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SHIFT)
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_AXI_UNIT_ID(mpm_mmu_sram_acc_violation_log_status_reg, acc_violation_axi_unit_id) \
      mpm_mmu_sram_acc_violation_log_status_reg = (mpm_mmu_sram_acc_violation_log_status_reg & ~MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_MASK) | (acc_violation_axi_unit_id << MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SHIFT)
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_AXI_INIT_ID(mpm_mmu_sram_acc_violation_log_status_reg, acc_violation_axi_init_id) \
      mpm_mmu_sram_acc_violation_log_status_reg = (mpm_mmu_sram_acc_violation_log_status_reg & ~MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_MASK) | (acc_violation_axi_init_id << MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SHIFT)
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_SRAM_NS0_VIOL_CLEAR(mpm_mmu_sram_acc_violation_log_status_reg, sram_ns0_viol_clear) \
      mpm_mmu_sram_acc_violation_log_status_reg = (mpm_mmu_sram_acc_violation_log_status_reg & ~MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_MASK) | (sram_ns0_viol_clear << MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SHIFT)
#define MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_LOG_CLEAR(mpm_mmu_sram_acc_violation_log_status_reg, acc_violation_log_clear) \
      mpm_mmu_sram_acc_violation_log_status_reg = (mpm_mmu_sram_acc_violation_log_status_reg & ~MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) | (acc_violation_log_clear << MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_mmu_sram_acc_violation_log_status_t {
            unsigned int acc_violation_detected         : MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
            unsigned int acc_violation_unsecure_bar     : MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SIZE;
            unsigned int                                : 1;
            unsigned int acc_violation_op               : MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SIZE;
            unsigned int acc_violation_type             : MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
            unsigned int acc_violation_permission       : MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SIZE;
            unsigned int acc_violation_axi_unit_id      : MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SIZE;
            unsigned int acc_violation_axi_init_id      : MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SIZE;
            unsigned int                                : 5;
            unsigned int sram_ns0_viol_clear            : MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SIZE;
            unsigned int acc_violation_log_clear        : MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
      } mpm_mmu_sram_acc_violation_log_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_mmu_sram_acc_violation_log_status_t {
            unsigned int acc_violation_log_clear        : MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
            unsigned int sram_ns0_viol_clear            : MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SIZE;
            unsigned int                                : 5;
            unsigned int acc_violation_axi_init_id      : MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SIZE;
            unsigned int acc_violation_axi_unit_id      : MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SIZE;
            unsigned int acc_violation_permission       : MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SIZE;
            unsigned int acc_violation_type             : MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
            unsigned int acc_violation_op               : MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SIZE;
            unsigned int                                : 1;
            unsigned int acc_violation_unsecure_bar     : MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SIZE;
            unsigned int acc_violation_detected         : MPM_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
      } mpm_mmu_sram_acc_violation_log_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_mmu_sram_acc_violation_log_status_t f;
} mpm_mmu_sram_acc_violation_log_status_u;


/*
 * MPM_MMU_MISC_CNTL struct
 */

#define MPM_MMU_MISC_CNTL_REG_SIZE         32
#define MPM_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SIZE  1
#define MPM_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SIZE  1
#define MPM_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SIZE  1
#define MPM_MMU_MISC_CNTL_CLK_GATE_EN_SIZE  1
#define MPM_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SIZE  1
#define MPM_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SIZE  4
#define MPM_MMU_MISC_CNTL_REGCLK_STATUS_SIZE  1
#define MPM_MMU_MISC_CNTL_SYSCLK_STATUS_SIZE  1

#define MPM_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SHIFT  0
#define MPM_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SHIFT  2
#define MPM_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SHIFT  3
#define MPM_MMU_MISC_CNTL_CLK_GATE_EN_SHIFT  16
#define MPM_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SHIFT  17
#define MPM_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SHIFT  18
#define MPM_MMU_MISC_CNTL_REGCLK_STATUS_SHIFT  22
#define MPM_MMU_MISC_CNTL_SYSCLK_STATUS_SHIFT  23

#define MPM_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_MASK  0x00000001
#define MPM_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_MASK  0x00000004
#define MPM_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_MASK  0x00000008
#define MPM_MMU_MISC_CNTL_CLK_GATE_EN_MASK  0x00010000
#define MPM_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_MASK  0x00020000
#define MPM_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_MASK  0x003c0000
#define MPM_MMU_MISC_CNTL_REGCLK_STATUS_MASK  0x00400000
#define MPM_MMU_MISC_CNTL_SYSCLK_STATUS_MASK  0x00800000

#define MPM_MMU_MISC_CNTL_MASK \
      (MPM_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_MASK | \
      MPM_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_MASK | \
      MPM_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_MASK | \
      MPM_MMU_MISC_CNTL_CLK_GATE_EN_MASK | \
      MPM_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_MASK | \
      MPM_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_MASK | \
      MPM_MMU_MISC_CNTL_REGCLK_STATUS_MASK | \
      MPM_MMU_MISC_CNTL_SYSCLK_STATUS_MASK)

#define MPM_MMU_MISC_CNTL_DEFAULT      0x00e00001

#define MPM_MMU_MISC_CNTL_GET_ALLOW_UNPRIVILIGED_REG_ACC(mpm_mmu_misc_cntl) \
      ((mpm_mmu_misc_cntl & MPM_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_MASK) >> MPM_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SHIFT)
#define MPM_MMU_MISC_CNTL_GET_ENABLE_MEM_CHECKS_PSRAM(mpm_mmu_misc_cntl) \
      ((mpm_mmu_misc_cntl & MPM_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_MASK) >> MPM_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SHIFT)
#define MPM_MMU_MISC_CNTL_GET_ENABLE_MEM_CHECKS_CPU(mpm_mmu_misc_cntl) \
      ((mpm_mmu_misc_cntl & MPM_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_MASK) >> MPM_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SHIFT)
#define MPM_MMU_MISC_CNTL_GET_CLK_GATE_EN(mpm_mmu_misc_cntl) \
      ((mpm_mmu_misc_cntl & MPM_MMU_MISC_CNTL_CLK_GATE_EN_MASK) >> MPM_MMU_MISC_CNTL_CLK_GATE_EN_SHIFT)
#define MPM_MMU_MISC_CNTL_GET_CLK_GATE_OVERRIDE(mpm_mmu_misc_cntl) \
      ((mpm_mmu_misc_cntl & MPM_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_MASK) >> MPM_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SHIFT)
#define MPM_MMU_MISC_CNTL_GET_CLK_GATE_TIMEOUT(mpm_mmu_misc_cntl) \
      ((mpm_mmu_misc_cntl & MPM_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_MASK) >> MPM_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SHIFT)
#define MPM_MMU_MISC_CNTL_GET_REGCLK_STATUS(mpm_mmu_misc_cntl) \
      ((mpm_mmu_misc_cntl & MPM_MMU_MISC_CNTL_REGCLK_STATUS_MASK) >> MPM_MMU_MISC_CNTL_REGCLK_STATUS_SHIFT)
#define MPM_MMU_MISC_CNTL_GET_SYSCLK_STATUS(mpm_mmu_misc_cntl) \
      ((mpm_mmu_misc_cntl & MPM_MMU_MISC_CNTL_SYSCLK_STATUS_MASK) >> MPM_MMU_MISC_CNTL_SYSCLK_STATUS_SHIFT)

#define MPM_MMU_MISC_CNTL_SET_ALLOW_UNPRIVILIGED_REG_ACC(mpm_mmu_misc_cntl_reg, allow_unpriviliged_reg_acc) \
      mpm_mmu_misc_cntl_reg = (mpm_mmu_misc_cntl_reg & ~MPM_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_MASK) | (allow_unpriviliged_reg_acc << MPM_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SHIFT)
#define MPM_MMU_MISC_CNTL_SET_ENABLE_MEM_CHECKS_PSRAM(mpm_mmu_misc_cntl_reg, enable_mem_checks_psram) \
      mpm_mmu_misc_cntl_reg = (mpm_mmu_misc_cntl_reg & ~MPM_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_MASK) | (enable_mem_checks_psram << MPM_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SHIFT)
#define MPM_MMU_MISC_CNTL_SET_ENABLE_MEM_CHECKS_CPU(mpm_mmu_misc_cntl_reg, enable_mem_checks_cpu) \
      mpm_mmu_misc_cntl_reg = (mpm_mmu_misc_cntl_reg & ~MPM_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_MASK) | (enable_mem_checks_cpu << MPM_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SHIFT)
#define MPM_MMU_MISC_CNTL_SET_CLK_GATE_EN(mpm_mmu_misc_cntl_reg, clk_gate_en) \
      mpm_mmu_misc_cntl_reg = (mpm_mmu_misc_cntl_reg & ~MPM_MMU_MISC_CNTL_CLK_GATE_EN_MASK) | (clk_gate_en << MPM_MMU_MISC_CNTL_CLK_GATE_EN_SHIFT)
#define MPM_MMU_MISC_CNTL_SET_CLK_GATE_OVERRIDE(mpm_mmu_misc_cntl_reg, clk_gate_override) \
      mpm_mmu_misc_cntl_reg = (mpm_mmu_misc_cntl_reg & ~MPM_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_MASK) | (clk_gate_override << MPM_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SHIFT)
#define MPM_MMU_MISC_CNTL_SET_CLK_GATE_TIMEOUT(mpm_mmu_misc_cntl_reg, clk_gate_timeout) \
      mpm_mmu_misc_cntl_reg = (mpm_mmu_misc_cntl_reg & ~MPM_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_MASK) | (clk_gate_timeout << MPM_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SHIFT)
#define MPM_MMU_MISC_CNTL_SET_REGCLK_STATUS(mpm_mmu_misc_cntl_reg, regclk_status) \
      mpm_mmu_misc_cntl_reg = (mpm_mmu_misc_cntl_reg & ~MPM_MMU_MISC_CNTL_REGCLK_STATUS_MASK) | (regclk_status << MPM_MMU_MISC_CNTL_REGCLK_STATUS_SHIFT)
#define MPM_MMU_MISC_CNTL_SET_SYSCLK_STATUS(mpm_mmu_misc_cntl_reg, sysclk_status) \
      mpm_mmu_misc_cntl_reg = (mpm_mmu_misc_cntl_reg & ~MPM_MMU_MISC_CNTL_SYSCLK_STATUS_MASK) | (sysclk_status << MPM_MMU_MISC_CNTL_SYSCLK_STATUS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_mmu_misc_cntl_t {
            unsigned int allow_unpriviliged_reg_acc     : MPM_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SIZE;
            unsigned int                                : 1;
            unsigned int enable_mem_checks_psram        : MPM_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SIZE;
            unsigned int enable_mem_checks_cpu          : MPM_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SIZE;
            unsigned int                                : 12;
            unsigned int clk_gate_en                    : MPM_MMU_MISC_CNTL_CLK_GATE_EN_SIZE;
            unsigned int clk_gate_override              : MPM_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SIZE;
            unsigned int clk_gate_timeout               : MPM_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SIZE;
            unsigned int regclk_status                  : MPM_MMU_MISC_CNTL_REGCLK_STATUS_SIZE;
            unsigned int sysclk_status                  : MPM_MMU_MISC_CNTL_SYSCLK_STATUS_SIZE;
            unsigned int                                : 8;
      } mpm_mmu_misc_cntl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_mmu_misc_cntl_t {
            unsigned int                                : 8;
            unsigned int sysclk_status                  : MPM_MMU_MISC_CNTL_SYSCLK_STATUS_SIZE;
            unsigned int regclk_status                  : MPM_MMU_MISC_CNTL_REGCLK_STATUS_SIZE;
            unsigned int clk_gate_timeout               : MPM_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SIZE;
            unsigned int clk_gate_override              : MPM_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SIZE;
            unsigned int clk_gate_en                    : MPM_MMU_MISC_CNTL_CLK_GATE_EN_SIZE;
            unsigned int                                : 12;
            unsigned int enable_mem_checks_cpu          : MPM_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SIZE;
            unsigned int enable_mem_checks_psram        : MPM_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SIZE;
            unsigned int                                : 1;
            unsigned int allow_unpriviliged_reg_acc     : MPM_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SIZE;
      } mpm_mmu_misc_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_mmu_misc_cntl_t f;
} mpm_mmu_misc_cntl_u;


/*
 * MPM_MMU_ACCESS_ERR_LOG struct
 */

#define MPM_MMU_ACCESS_ERR_LOG_REG_SIZE         32
#define MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SIZE  1
#define MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SIZE  2
#define MPM_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SIZE  1
#define MPM_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SIZE  1
#define MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SIZE  7
#define MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SIZE  10
#define MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SIZE  3

#define MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SHIFT  0
#define MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SHIFT  1
#define MPM_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SHIFT  3
#define MPM_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SHIFT  4
#define MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SHIFT  8
#define MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SHIFT  15
#define MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SHIFT  25

#define MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_MASK  0x00000001
#define MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_MASK  0x00000006
#define MPM_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_MASK  0x00000008
#define MPM_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_MASK  0x00000010
#define MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_MASK  0x00007f00
#define MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_MASK  0x01ff8000
#define MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_MASK  0x0e000000

#define MPM_MMU_ACCESS_ERR_LOG_MASK \
      (MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_MASK | \
      MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_MASK | \
      MPM_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_MASK | \
      MPM_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_MASK | \
      MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_MASK | \
      MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_MASK | \
      MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_MASK)

#define MPM_MMU_ACCESS_ERR_LOG_DEFAULT 0x00000000

#define MPM_MMU_ACCESS_ERR_LOG_GET_AXI_ACC_VIOLATION_DETECTED(mpm_mmu_access_err_log) \
      ((mpm_mmu_access_err_log & MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_MASK) >> MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SHIFT)
#define MPM_MMU_ACCESS_ERR_LOG_GET_AXI_ACC_VIOLATION_BLOCK(mpm_mmu_access_err_log) \
      ((mpm_mmu_access_err_log & MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_MASK) >> MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SHIFT)
#define MPM_MMU_ACCESS_ERR_LOG_GET_ACC_VIOLATION_LOG_CLEAR(mpm_mmu_access_err_log) \
      ((mpm_mmu_access_err_log & MPM_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_MASK) >> MPM_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SHIFT)
#define MPM_MMU_ACCESS_ERR_LOG_GET_CFG_NS0_VIOL_CLEAR(mpm_mmu_access_err_log) \
      ((mpm_mmu_access_err_log & MPM_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_MASK) >> MPM_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SHIFT)
#define MPM_MMU_ACCESS_ERR_LOG_GET_AXI_ACC_VIOLATION_AXI_UNIT_ID(mpm_mmu_access_err_log) \
      ((mpm_mmu_access_err_log & MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_MASK) >> MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SHIFT)
#define MPM_MMU_ACCESS_ERR_LOG_GET_AXI_ACC_VIOLATION_AXI_INIT_ID(mpm_mmu_access_err_log) \
      ((mpm_mmu_access_err_log & MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_MASK) >> MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SHIFT)
#define MPM_MMU_ACCESS_ERR_LOG_GET_AXI_ACC_VIOLATION_AXI_PROT(mpm_mmu_access_err_log) \
      ((mpm_mmu_access_err_log & MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_MASK) >> MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SHIFT)

#define MPM_MMU_ACCESS_ERR_LOG_SET_AXI_ACC_VIOLATION_DETECTED(mpm_mmu_access_err_log_reg, axi_acc_violation_detected) \
      mpm_mmu_access_err_log_reg = (mpm_mmu_access_err_log_reg & ~MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_MASK) | (axi_acc_violation_detected << MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SHIFT)
#define MPM_MMU_ACCESS_ERR_LOG_SET_AXI_ACC_VIOLATION_BLOCK(mpm_mmu_access_err_log_reg, axi_acc_violation_block) \
      mpm_mmu_access_err_log_reg = (mpm_mmu_access_err_log_reg & ~MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_MASK) | (axi_acc_violation_block << MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SHIFT)
#define MPM_MMU_ACCESS_ERR_LOG_SET_ACC_VIOLATION_LOG_CLEAR(mpm_mmu_access_err_log_reg, acc_violation_log_clear) \
      mpm_mmu_access_err_log_reg = (mpm_mmu_access_err_log_reg & ~MPM_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_MASK) | (acc_violation_log_clear << MPM_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SHIFT)
#define MPM_MMU_ACCESS_ERR_LOG_SET_CFG_NS0_VIOL_CLEAR(mpm_mmu_access_err_log_reg, cfg_ns0_viol_clear) \
      mpm_mmu_access_err_log_reg = (mpm_mmu_access_err_log_reg & ~MPM_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_MASK) | (cfg_ns0_viol_clear << MPM_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SHIFT)
#define MPM_MMU_ACCESS_ERR_LOG_SET_AXI_ACC_VIOLATION_AXI_UNIT_ID(mpm_mmu_access_err_log_reg, axi_acc_violation_axi_unit_id) \
      mpm_mmu_access_err_log_reg = (mpm_mmu_access_err_log_reg & ~MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_MASK) | (axi_acc_violation_axi_unit_id << MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SHIFT)
#define MPM_MMU_ACCESS_ERR_LOG_SET_AXI_ACC_VIOLATION_AXI_INIT_ID(mpm_mmu_access_err_log_reg, axi_acc_violation_axi_init_id) \
      mpm_mmu_access_err_log_reg = (mpm_mmu_access_err_log_reg & ~MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_MASK) | (axi_acc_violation_axi_init_id << MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SHIFT)
#define MPM_MMU_ACCESS_ERR_LOG_SET_AXI_ACC_VIOLATION_AXI_PROT(mpm_mmu_access_err_log_reg, axi_acc_violation_axi_prot) \
      mpm_mmu_access_err_log_reg = (mpm_mmu_access_err_log_reg & ~MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_MASK) | (axi_acc_violation_axi_prot << MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_mmu_access_err_log_t {
            unsigned int axi_acc_violation_detected     : MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SIZE;
            unsigned int axi_acc_violation_block        : MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SIZE;
            unsigned int acc_violation_log_clear        : MPM_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SIZE;
            unsigned int cfg_ns0_viol_clear             : MPM_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SIZE;
            unsigned int                                : 3;
            unsigned int axi_acc_violation_axi_unit_id  : MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SIZE;
            unsigned int axi_acc_violation_axi_init_id  : MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SIZE;
            unsigned int axi_acc_violation_axi_prot     : MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SIZE;
            unsigned int                                : 4;
      } mpm_mmu_access_err_log_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_mmu_access_err_log_t {
            unsigned int                                : 4;
            unsigned int axi_acc_violation_axi_prot     : MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SIZE;
            unsigned int axi_acc_violation_axi_init_id  : MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SIZE;
            unsigned int axi_acc_violation_axi_unit_id  : MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SIZE;
            unsigned int                                : 3;
            unsigned int cfg_ns0_viol_clear             : MPM_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SIZE;
            unsigned int acc_violation_log_clear        : MPM_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SIZE;
            unsigned int axi_acc_violation_block        : MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SIZE;
            unsigned int axi_acc_violation_detected     : MPM_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SIZE;
      } mpm_mmu_access_err_log_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_mmu_access_err_log_t f;
} mpm_mmu_access_err_log_u;


/*
 * MPM_MMU_SRAM_UNSECURE_BAR struct
 */

#define MPM_MMU_SRAM_UNSECURE_BAR_REG_SIZE         32
#define MPM_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SIZE  32

#define MPM_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SHIFT  0

#define MPM_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_MASK  0xffffffff

#define MPM_MMU_SRAM_UNSECURE_BAR_MASK \
      (MPM_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_MASK)

#define MPM_MMU_SRAM_UNSECURE_BAR_DEFAULT 0x00040000

#define MPM_MMU_SRAM_UNSECURE_BAR_GET_SRAM_UNSECURE_BAR(mpm_mmu_sram_unsecure_bar) \
      ((mpm_mmu_sram_unsecure_bar & MPM_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_MASK) >> MPM_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SHIFT)

#define MPM_MMU_SRAM_UNSECURE_BAR_SET_SRAM_UNSECURE_BAR(mpm_mmu_sram_unsecure_bar_reg, sram_unsecure_bar) \
      mpm_mmu_sram_unsecure_bar_reg = (mpm_mmu_sram_unsecure_bar_reg & ~MPM_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_MASK) | (sram_unsecure_bar << MPM_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_mmu_sram_unsecure_bar_t {
            unsigned int sram_unsecure_bar              : MPM_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SIZE;
      } mpm_mmu_sram_unsecure_bar_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_mmu_sram_unsecure_bar_t {
            unsigned int sram_unsecure_bar              : MPM_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SIZE;
      } mpm_mmu_sram_unsecure_bar_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_mmu_sram_unsecure_bar_t f;
} mpm_mmu_sram_unsecure_bar_u;


/*
 * MPM_MMU_SCRATCH_0 struct
 */

#define MPM_MMU_SCRATCH_0_REG_SIZE         32
#define MPM_MMU_SCRATCH_0_RESERVED_SIZE  32

#define MPM_MMU_SCRATCH_0_RESERVED_SHIFT  0

#define MPM_MMU_SCRATCH_0_RESERVED_MASK  0xffffffff

#define MPM_MMU_SCRATCH_0_MASK \
      (MPM_MMU_SCRATCH_0_RESERVED_MASK)

#define MPM_MMU_SCRATCH_0_DEFAULT      0x00000000

#define MPM_MMU_SCRATCH_0_GET_RESERVED(mpm_mmu_scratch_0) \
      ((mpm_mmu_scratch_0 & MPM_MMU_SCRATCH_0_RESERVED_MASK) >> MPM_MMU_SCRATCH_0_RESERVED_SHIFT)

#define MPM_MMU_SCRATCH_0_SET_RESERVED(mpm_mmu_scratch_0_reg, reserved) \
      mpm_mmu_scratch_0_reg = (mpm_mmu_scratch_0_reg & ~MPM_MMU_SCRATCH_0_RESERVED_MASK) | (reserved << MPM_MMU_SCRATCH_0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_mmu_scratch_0_t {
            unsigned int reserved                       : MPM_MMU_SCRATCH_0_RESERVED_SIZE;
      } mpm_mmu_scratch_0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_mmu_scratch_0_t {
            unsigned int reserved                       : MPM_MMU_SCRATCH_0_RESERVED_SIZE;
      } mpm_mmu_scratch_0_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_mmu_scratch_0_t f;
} mpm_mmu_scratch_0_u;


/*
 * MPM_MMU_SCRATCH_1 struct
 */

#define MPM_MMU_SCRATCH_1_REG_SIZE         32
#define MPM_MMU_SCRATCH_1_RESERVED_SIZE  32

#define MPM_MMU_SCRATCH_1_RESERVED_SHIFT  0

#define MPM_MMU_SCRATCH_1_RESERVED_MASK  0xffffffff

#define MPM_MMU_SCRATCH_1_MASK \
      (MPM_MMU_SCRATCH_1_RESERVED_MASK)

#define MPM_MMU_SCRATCH_1_DEFAULT      0x00000000

#define MPM_MMU_SCRATCH_1_GET_RESERVED(mpm_mmu_scratch_1) \
      ((mpm_mmu_scratch_1 & MPM_MMU_SCRATCH_1_RESERVED_MASK) >> MPM_MMU_SCRATCH_1_RESERVED_SHIFT)

#define MPM_MMU_SCRATCH_1_SET_RESERVED(mpm_mmu_scratch_1_reg, reserved) \
      mpm_mmu_scratch_1_reg = (mpm_mmu_scratch_1_reg & ~MPM_MMU_SCRATCH_1_RESERVED_MASK) | (reserved << MPM_MMU_SCRATCH_1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_mmu_scratch_1_t {
            unsigned int reserved                       : MPM_MMU_SCRATCH_1_RESERVED_SIZE;
      } mpm_mmu_scratch_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_mmu_scratch_1_t {
            unsigned int reserved                       : MPM_MMU_SCRATCH_1_RESERVED_SIZE;
      } mpm_mmu_scratch_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_mmu_scratch_1_t f;
} mpm_mmu_scratch_1_u;


/*
 * MPM_MMU_SCRATCH_2 struct
 */

#define MPM_MMU_SCRATCH_2_REG_SIZE         32
#define MPM_MMU_SCRATCH_2_RESERVED_SIZE  32

#define MPM_MMU_SCRATCH_2_RESERVED_SHIFT  0

#define MPM_MMU_SCRATCH_2_RESERVED_MASK  0xffffffff

#define MPM_MMU_SCRATCH_2_MASK \
      (MPM_MMU_SCRATCH_2_RESERVED_MASK)

#define MPM_MMU_SCRATCH_2_DEFAULT      0x00000000

#define MPM_MMU_SCRATCH_2_GET_RESERVED(mpm_mmu_scratch_2) \
      ((mpm_mmu_scratch_2 & MPM_MMU_SCRATCH_2_RESERVED_MASK) >> MPM_MMU_SCRATCH_2_RESERVED_SHIFT)

#define MPM_MMU_SCRATCH_2_SET_RESERVED(mpm_mmu_scratch_2_reg, reserved) \
      mpm_mmu_scratch_2_reg = (mpm_mmu_scratch_2_reg & ~MPM_MMU_SCRATCH_2_RESERVED_MASK) | (reserved << MPM_MMU_SCRATCH_2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_mmu_scratch_2_t {
            unsigned int reserved                       : MPM_MMU_SCRATCH_2_RESERVED_SIZE;
      } mpm_mmu_scratch_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_mmu_scratch_2_t {
            unsigned int reserved                       : MPM_MMU_SCRATCH_2_RESERVED_SIZE;
      } mpm_mmu_scratch_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_mmu_scratch_2_t f;
} mpm_mmu_scratch_2_u;


/*
 * MPM_MMU_SCRATCH_3 struct
 */

#define MPM_MMU_SCRATCH_3_REG_SIZE         32
#define MPM_MMU_SCRATCH_3_RESERVED_SIZE  32

#define MPM_MMU_SCRATCH_3_RESERVED_SHIFT  0

#define MPM_MMU_SCRATCH_3_RESERVED_MASK  0xffffffff

#define MPM_MMU_SCRATCH_3_MASK \
      (MPM_MMU_SCRATCH_3_RESERVED_MASK)

#define MPM_MMU_SCRATCH_3_DEFAULT      0x00000000

#define MPM_MMU_SCRATCH_3_GET_RESERVED(mpm_mmu_scratch_3) \
      ((mpm_mmu_scratch_3 & MPM_MMU_SCRATCH_3_RESERVED_MASK) >> MPM_MMU_SCRATCH_3_RESERVED_SHIFT)

#define MPM_MMU_SCRATCH_3_SET_RESERVED(mpm_mmu_scratch_3_reg, reserved) \
      mpm_mmu_scratch_3_reg = (mpm_mmu_scratch_3_reg & ~MPM_MMU_SCRATCH_3_RESERVED_MASK) | (reserved << MPM_MMU_SCRATCH_3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_mmu_scratch_3_t {
            unsigned int reserved                       : MPM_MMU_SCRATCH_3_RESERVED_SIZE;
      } mpm_mmu_scratch_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_mmu_scratch_3_t {
            unsigned int reserved                       : MPM_MMU_SCRATCH_3_RESERVED_SIZE;
      } mpm_mmu_scratch_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_mmu_scratch_3_t f;
} mpm_mmu_scratch_3_u;


/*
 * MPM_MMU_SCRATCH_4 struct
 */

#define MPM_MMU_SCRATCH_4_REG_SIZE         32
#define MPM_MMU_SCRATCH_4_RESERVED_SIZE  32

#define MPM_MMU_SCRATCH_4_RESERVED_SHIFT  0

#define MPM_MMU_SCRATCH_4_RESERVED_MASK  0xffffffff

#define MPM_MMU_SCRATCH_4_MASK \
      (MPM_MMU_SCRATCH_4_RESERVED_MASK)

#define MPM_MMU_SCRATCH_4_DEFAULT      0x00000000

#define MPM_MMU_SCRATCH_4_GET_RESERVED(mpm_mmu_scratch_4) \
      ((mpm_mmu_scratch_4 & MPM_MMU_SCRATCH_4_RESERVED_MASK) >> MPM_MMU_SCRATCH_4_RESERVED_SHIFT)

#define MPM_MMU_SCRATCH_4_SET_RESERVED(mpm_mmu_scratch_4_reg, reserved) \
      mpm_mmu_scratch_4_reg = (mpm_mmu_scratch_4_reg & ~MPM_MMU_SCRATCH_4_RESERVED_MASK) | (reserved << MPM_MMU_SCRATCH_4_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_mmu_scratch_4_t {
            unsigned int reserved                       : MPM_MMU_SCRATCH_4_RESERVED_SIZE;
      } mpm_mmu_scratch_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_mmu_scratch_4_t {
            unsigned int reserved                       : MPM_MMU_SCRATCH_4_RESERVED_SIZE;
      } mpm_mmu_scratch_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_mmu_scratch_4_t f;
} mpm_mmu_scratch_4_u;


/*
 * MPM_MMU_SCRATCH_5 struct
 */

#define MPM_MMU_SCRATCH_5_REG_SIZE         32
#define MPM_MMU_SCRATCH_5_RESERVED_SIZE  32

#define MPM_MMU_SCRATCH_5_RESERVED_SHIFT  0

#define MPM_MMU_SCRATCH_5_RESERVED_MASK  0xffffffff

#define MPM_MMU_SCRATCH_5_MASK \
      (MPM_MMU_SCRATCH_5_RESERVED_MASK)

#define MPM_MMU_SCRATCH_5_DEFAULT      0x00000000

#define MPM_MMU_SCRATCH_5_GET_RESERVED(mpm_mmu_scratch_5) \
      ((mpm_mmu_scratch_5 & MPM_MMU_SCRATCH_5_RESERVED_MASK) >> MPM_MMU_SCRATCH_5_RESERVED_SHIFT)

#define MPM_MMU_SCRATCH_5_SET_RESERVED(mpm_mmu_scratch_5_reg, reserved) \
      mpm_mmu_scratch_5_reg = (mpm_mmu_scratch_5_reg & ~MPM_MMU_SCRATCH_5_RESERVED_MASK) | (reserved << MPM_MMU_SCRATCH_5_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_mmu_scratch_5_t {
            unsigned int reserved                       : MPM_MMU_SCRATCH_5_RESERVED_SIZE;
      } mpm_mmu_scratch_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_mmu_scratch_5_t {
            unsigned int reserved                       : MPM_MMU_SCRATCH_5_RESERVED_SIZE;
      } mpm_mmu_scratch_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_mmu_scratch_5_t f;
} mpm_mmu_scratch_5_u;


/*
 * MPM_MMU_SCRATCH_6 struct
 */

#define MPM_MMU_SCRATCH_6_REG_SIZE         32
#define MPM_MMU_SCRATCH_6_RESERVED_SIZE  32

#define MPM_MMU_SCRATCH_6_RESERVED_SHIFT  0

#define MPM_MMU_SCRATCH_6_RESERVED_MASK  0xffffffff

#define MPM_MMU_SCRATCH_6_MASK \
      (MPM_MMU_SCRATCH_6_RESERVED_MASK)

#define MPM_MMU_SCRATCH_6_DEFAULT      0x00000000

#define MPM_MMU_SCRATCH_6_GET_RESERVED(mpm_mmu_scratch_6) \
      ((mpm_mmu_scratch_6 & MPM_MMU_SCRATCH_6_RESERVED_MASK) >> MPM_MMU_SCRATCH_6_RESERVED_SHIFT)

#define MPM_MMU_SCRATCH_6_SET_RESERVED(mpm_mmu_scratch_6_reg, reserved) \
      mpm_mmu_scratch_6_reg = (mpm_mmu_scratch_6_reg & ~MPM_MMU_SCRATCH_6_RESERVED_MASK) | (reserved << MPM_MMU_SCRATCH_6_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_mmu_scratch_6_t {
            unsigned int reserved                       : MPM_MMU_SCRATCH_6_RESERVED_SIZE;
      } mpm_mmu_scratch_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_mmu_scratch_6_t {
            unsigned int reserved                       : MPM_MMU_SCRATCH_6_RESERVED_SIZE;
      } mpm_mmu_scratch_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_mmu_scratch_6_t f;
} mpm_mmu_scratch_6_u;


/*
 * MPM_MMU_SCRATCH_7 struct
 */

#define MPM_MMU_SCRATCH_7_REG_SIZE         32
#define MPM_MMU_SCRATCH_7_RESERVED_SIZE  32

#define MPM_MMU_SCRATCH_7_RESERVED_SHIFT  0

#define MPM_MMU_SCRATCH_7_RESERVED_MASK  0xffffffff

#define MPM_MMU_SCRATCH_7_MASK \
      (MPM_MMU_SCRATCH_7_RESERVED_MASK)

#define MPM_MMU_SCRATCH_7_DEFAULT      0x00000000

#define MPM_MMU_SCRATCH_7_GET_RESERVED(mpm_mmu_scratch_7) \
      ((mpm_mmu_scratch_7 & MPM_MMU_SCRATCH_7_RESERVED_MASK) >> MPM_MMU_SCRATCH_7_RESERVED_SHIFT)

#define MPM_MMU_SCRATCH_7_SET_RESERVED(mpm_mmu_scratch_7_reg, reserved) \
      mpm_mmu_scratch_7_reg = (mpm_mmu_scratch_7_reg & ~MPM_MMU_SCRATCH_7_RESERVED_MASK) | (reserved << MPM_MMU_SCRATCH_7_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_mmu_scratch_7_t {
            unsigned int reserved                       : MPM_MMU_SCRATCH_7_RESERVED_SIZE;
      } mpm_mmu_scratch_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_mmu_scratch_7_t {
            unsigned int reserved                       : MPM_MMU_SCRATCH_7_RESERVED_SIZE;
      } mpm_mmu_scratch_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_mmu_scratch_7_t f;
} mpm_mmu_scratch_7_u;


/*
 * MPM_PMI_0 struct
 */

#define MPM_PMI_0_REG_SIZE         32
#define MPM_PMI_0_DATA_SIZE  32

#define MPM_PMI_0_DATA_SHIFT  0

#define MPM_PMI_0_DATA_MASK             0xffffffff

#define MPM_PMI_0_MASK \
      (MPM_PMI_0_DATA_MASK)

#define MPM_PMI_0_DEFAULT              0x00000000

#define MPM_PMI_0_GET_DATA(mpm_pmi_0) \
      ((mpm_pmi_0 & MPM_PMI_0_DATA_MASK) >> MPM_PMI_0_DATA_SHIFT)

#define MPM_PMI_0_SET_DATA(mpm_pmi_0_reg, data) \
      mpm_pmi_0_reg = (mpm_pmi_0_reg & ~MPM_PMI_0_DATA_MASK) | (data << MPM_PMI_0_DATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_0_t {
            unsigned int data                           : MPM_PMI_0_DATA_SIZE;
      } mpm_pmi_0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_0_t {
            unsigned int data                           : MPM_PMI_0_DATA_SIZE;
      } mpm_pmi_0_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_0_t f;
} mpm_pmi_0_u;


/*
 * MPM_PMI_1 struct
 */

#define MPM_PMI_1_REG_SIZE         32
#define MPM_PMI_1_DATA_SIZE  32

#define MPM_PMI_1_DATA_SHIFT  0

#define MPM_PMI_1_DATA_MASK             0xffffffff

#define MPM_PMI_1_MASK \
      (MPM_PMI_1_DATA_MASK)

#define MPM_PMI_1_DEFAULT              0x00000000

#define MPM_PMI_1_GET_DATA(mpm_pmi_1) \
      ((mpm_pmi_1 & MPM_PMI_1_DATA_MASK) >> MPM_PMI_1_DATA_SHIFT)

#define MPM_PMI_1_SET_DATA(mpm_pmi_1_reg, data) \
      mpm_pmi_1_reg = (mpm_pmi_1_reg & ~MPM_PMI_1_DATA_MASK) | (data << MPM_PMI_1_DATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_1_t {
            unsigned int data                           : MPM_PMI_1_DATA_SIZE;
      } mpm_pmi_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_1_t {
            unsigned int data                           : MPM_PMI_1_DATA_SIZE;
      } mpm_pmi_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_1_t f;
} mpm_pmi_1_u;


/*
 * MPM_PMI_2 struct
 */

#define MPM_PMI_2_REG_SIZE         32
#define MPM_PMI_2_DATA_SIZE  32

#define MPM_PMI_2_DATA_SHIFT  0

#define MPM_PMI_2_DATA_MASK             0xffffffff

#define MPM_PMI_2_MASK \
      (MPM_PMI_2_DATA_MASK)

#define MPM_PMI_2_DEFAULT              0x00000000

#define MPM_PMI_2_GET_DATA(mpm_pmi_2) \
      ((mpm_pmi_2 & MPM_PMI_2_DATA_MASK) >> MPM_PMI_2_DATA_SHIFT)

#define MPM_PMI_2_SET_DATA(mpm_pmi_2_reg, data) \
      mpm_pmi_2_reg = (mpm_pmi_2_reg & ~MPM_PMI_2_DATA_MASK) | (data << MPM_PMI_2_DATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_pmi_2_t {
            unsigned int data                           : MPM_PMI_2_DATA_SIZE;
      } mpm_pmi_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_pmi_2_t {
            unsigned int data                           : MPM_PMI_2_DATA_SIZE;
      } mpm_pmi_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_pmi_2_t f;
} mpm_pmi_2_u;


#endif

