// Copyright (c) 1994 - 2022 Advanced Micro Devices, Inc. All rights reserved.

#if !defined (_MP1_DFP_MASK_H)
#define _MP1_DFP_MASK_H

/*
 *    mp1_dfp_mask.h   
 *
 *    Register Spec Release:  <unknown>
 *
 *
 *      (c) 2021 Advanced Micro Devices, Inc.  (unpublished)
 *
 *        All rights reserved.  This notice is intended as a precaution against
 *     inadvertent publication and does not imply publication or any waiver
 *      of confidentiality.  The year included in the foregoing notice is the
 *     year of creation of the work.
 *
 */

/*******************************************************
 * Read and Write Masks
 *******************************************************/

#define MP1_PSP_ACCESS_ONLY_READ_MASK  0x00000001
#define MP1_PSP_ACCESS_ONLY_WRITE_MASK 0x00000001

#define MP1_MPCLK_XBAR_CG_CTRL_READ_MASK 0x00000001
#define MP1_MPCLK_XBAR_CG_CTRL_WRITE_MASK 0x00000001

#define MP1_MPCLK_XBAR_CG_EN_READ_MASK 0x0000001e
#define MP1_MPCLK_XBAR_CG_EN_WRITE_MASK 0x0000001e

#define MP1_MPCLK_XBAR_CG_MISC_READ_MASK 0x0000ffff
#define MP1_MPCLK_XBAR_CG_MISC_WRITE_MASK 0x0000ffff

#define MP1_DFP_ZSCIF_CTRL_READ_MASK   0x0000003e
#define MP1_DFP_ZSCIF_CTRL_WRITE_MASK  0x00000031

#define MP1_DFP_PGRAM_MMU0_CNTL_READ_MASK 0xffffff3d
#define MP1_DFP_PGRAM_MMU0_CNTL_WRITE_MASK 0xffffff15

#define MP1_DFP_PGRAM_MMU1_CNTL_READ_MASK 0xffffff3d
#define MP1_DFP_PGRAM_MMU1_CNTL_WRITE_MASK 0xffffff15

#define MP1_DFP_PGRAM_MMU2_CNTL_READ_MASK 0xffffff3d
#define MP1_DFP_PGRAM_MMU2_CNTL_WRITE_MASK 0xffffff15

#define MP1_DFP_PGRAM_MMU3_CNTL_READ_MASK 0xffffff3d
#define MP1_DFP_PGRAM_MMU3_CNTL_WRITE_MASK 0xffffff15

#define MP1_DFP_PGRAM_CPU_CNTL_READ_MASK 0xffffff3d
#define MP1_DFP_PGRAM_CPU_CNTL_WRITE_MASK 0xffffff15

#define MP1_DFP_PGRAM_CRU_CNTL_READ_MASK 0xffffff3d
#define MP1_DFP_PGRAM_CRU_CNTL_WRITE_MASK 0xffffff15

#define MP1_DFP_MPCLKDS_CTRL_READ_MASK 0x00001fff
#define MP1_DFP_MPCLKDS_CTRL_WRITE_MASK 0x00001ffd

#define MP1_DFP_SMNCLKDS_CTRL_READ_MASK 0x0000000f
#define MP1_DFP_SMNCLKDS_CTRL_WRITE_MASK 0x000000cd

#define MP1_SOCCLK_XBAR_CG_CTRL_READ_MASK 0x00000001
#define MP1_SOCCLK_XBAR_CG_CTRL_WRITE_MASK 0x00000001

#define MP1_SOCCLK_XBAR_CG_EN_READ_MASK 0x0000001e
#define MP1_SOCCLK_XBAR_CG_EN_WRITE_MASK 0x0000001e

#define MP1_SOCCLK_XBAR_CG_MISC_READ_MASK 0x0000ffff
#define MP1_SOCCLK_XBAR_CG_MISC_WRITE_MASK 0x0000ffff

#define MP1_DFP_PGRAM_MHUB_CNTL_READ_MASK 0xffffff3d
#define MP1_DFP_PGRAM_MHUB_CNTL_WRITE_MASK 0xffffff15

#define MP1_DFP_SOCCLKDS_CTRL_READ_MASK 0x000007ff
#define MP1_DFP_SOCCLKDS_CTRL_WRITE_MASK 0x000007fd

#define MP1_SHUBCLK_XBAR_CG_CTRL_READ_MASK 0x00000001
#define MP1_SHUBCLK_XBAR_CG_CTRL_WRITE_MASK 0x00000001

#define MP1_SHUBCLK_XBAR_CG_EN_READ_MASK 0x0000001e
#define MP1_SHUBCLK_XBAR_CG_EN_WRITE_MASK 0x0000001e

#define MP1_SHUBCLK_XBAR_CG_MISC_READ_MASK 0x0000ffff
#define MP1_SHUBCLK_XBAR_CG_MISC_WRITE_MASK 0x0000ffff

#define MP1_DFP_PGRAM_SHUB_CNTL_READ_MASK 0xffffff3d
#define MP1_DFP_PGRAM_SHUB_CNTL_WRITE_MASK 0xffffff15

#define MP1_DFP_SHUBCLKDS_CTRL_READ_MASK 0x00000fff
#define MP1_DFP_SHUBCLKDS_CTRL_WRITE_MASK 0x00000ffd

#endif


