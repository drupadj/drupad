/**
 * @brief Syscall_Amf_Printf : This function is to print
 *
 * @param fmt : String which you have to print
 * @param ....:
 *
 * @return void
 */

//#define ENABLE_MPM_PRINTF

#ifdef ENABLE_MPM_PRINTF
void Syscall_amf_printf(const char *fmt, ...);
//rfbLogProc rfbLog = Syscall_amf_printf;
//rfbLogProc rfbErr = Syscall_amf_printf;
#else
#define Syscall_amf_printf(fmt, ...) {}
#define rfbLog Syscall_amf_printf
#define rfbErr Syscall_amf_printf
#endif


