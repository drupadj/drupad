// Copyright (c) 2010 - 2019 Advanced Micro Devices, Inc. All rights reserved.
#ifndef __RTLLIB_FEATURES_H__
#define __RTLLIB_FEATURES_H__
// reference features

// imported features

// local features
#define GPU__RTLLIB__TECH tsmc5n210h
#define GPU__RTLLIB__TECH__TSMC5N210H 1
#define RTLLIB__TECH tsmc5n210h
#define RTLLIB__TECH__TSMC5N210H 1
#define GPU__RTLLIB__FLAVOR dgpu
#define GPU__RTLLIB__FLAVOR__DGPU 1
#define RTLLIB__FLAVOR dgpu
#define RTLLIB__FLAVOR__DGPU 1
#endif
