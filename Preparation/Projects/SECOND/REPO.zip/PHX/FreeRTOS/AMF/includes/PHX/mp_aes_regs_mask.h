// Copyright (c) 1994 - 2022 Advanced Micro Devices, Inc. All rights reserved.

#if !defined (_MP_AES_REGS_MASK_H)
#define _MP_AES_REGS_MASK_H

/*
 *    mp_aes_regs_mask.h       
 *
 *    Register Spec Release:  <unknown>
 *
 *
 *      (c) 2021 Advanced Micro Devices, Inc.  (unpublished)
 *
 *        All rights reserved.  This notice is intended as a precaution against
 *     inadvertent publication and does not imply publication or any waiver
 *      of confidentiality.  The year included in the foregoing notice is the
 *     year of creation of the work.
 *
 */

/*******************************************************
 * Read and Write Masks
 *******************************************************/

#define MP0_SYSHUB_AES_Key0_0_READ_MASK 0x00000000
#define MP0_SYSHUB_AES_Key0_0_WRITE_MASK 0xffffffff

#define MP0_SYSHUB_AES_Key0_1_READ_MASK 0x00000000
#define MP0_SYSHUB_AES_Key0_1_WRITE_MASK 0xffffffff

#define MP0_SYSHUB_AES_Key0_2_READ_MASK 0x00000000
#define MP0_SYSHUB_AES_Key0_2_WRITE_MASK 0xffffffff

#define MP0_SYSHUB_AES_Key0_3_READ_MASK 0x00000000
#define MP0_SYSHUB_AES_Key0_3_WRITE_MASK 0xffffffff

#define MP0_SYSHUB_AES_Key1_0_READ_MASK 0x00000000
#define MP0_SYSHUB_AES_Key1_0_WRITE_MASK 0xffffffff

#define MP0_SYSHUB_AES_Key1_1_READ_MASK 0x00000000
#define MP0_SYSHUB_AES_Key1_1_WRITE_MASK 0xffffffff

#define MP0_SYSHUB_AES_Key1_2_READ_MASK 0x00000000
#define MP0_SYSHUB_AES_Key1_2_WRITE_MASK 0xffffffff

#define MP0_SYSHUB_AES_Key1_3_READ_MASK 0x00000000
#define MP0_SYSHUB_AES_Key1_3_WRITE_MASK 0xffffffff

#define MP0_SYSHUB_AES_Key2_0_READ_MASK 0x00000000
#define MP0_SYSHUB_AES_Key2_0_WRITE_MASK 0xffffffff

#define MP0_SYSHUB_AES_Key2_1_READ_MASK 0x00000000
#define MP0_SYSHUB_AES_Key2_1_WRITE_MASK 0xffffffff

#define MP0_SYSHUB_AES_Key2_2_READ_MASK 0x00000000
#define MP0_SYSHUB_AES_Key2_2_WRITE_MASK 0xffffffff

#define MP0_SYSHUB_AES_Key2_3_READ_MASK 0x00000000
#define MP0_SYSHUB_AES_Key2_3_WRITE_MASK 0xffffffff

#define MP0_SYSHUB_AES_Key3_0_READ_MASK 0x00000000
#define MP0_SYSHUB_AES_Key3_0_WRITE_MASK 0xffffffff

#define MP0_SYSHUB_AES_Key3_1_READ_MASK 0x00000000
#define MP0_SYSHUB_AES_Key3_1_WRITE_MASK 0xffffffff

#define MP0_SYSHUB_AES_Key3_2_READ_MASK 0x00000000
#define MP0_SYSHUB_AES_Key3_2_WRITE_MASK 0xffffffff

#define MP0_SYSHUB_AES_Key3_3_READ_MASK 0x00000000
#define MP0_SYSHUB_AES_Key3_3_WRITE_MASK 0xffffffff

#define MP0_SYSHUB_AES_Tweak_READ_MASK 0x00000000
#define MP0_SYSHUB_AES_Tweak_WRITE_MASK 0xffffffff

#define MP0_SYSHUB_AES_CFG_EnaClkGating_READ_MASK 0x00000000
#define MP0_SYSHUB_AES_CFG_EnaClkGating_WRITE_MASK 0x00000001

#endif


