// Copyright (c) 1994 - 2021 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MP_DRM_MASK_H)
#define _MP_DRM_MASK_H

/*
 *    mp_drm_mask.h    
 *
 *    Register Spec Release:  <unknown>
 *
 *
 *      (c) 2000 ATI Technologies Inc.  (unpublished)
 *
 *       All rights reserved.  This notice is intended as a precaution against
 *     inadvertent publication and does not imply publication or any waiver
 *      of confidentiality.  The year included in the foregoing notice is the
 *     year of creation of the work.
 *
 */

/*******************************************************
 * Read and Write Masks
 *******************************************************/

#define DRM_KEYGEN_START_READ_MASK     0x00000000
#define DRM_KEYGEN_START_WRITE_MASK    0xffffffff

#define DRM_KEYGEN_CONT_READ_MASK      0x00000000
#define DRM_KEYGEN_CONT_WRITE_MASK     0xffffffff

#define DRM_KEYGEN_RADDR_READ_MASK     0x0000003f
#define DRM_KEYGEN_RADDR_WRITE_MASK    0x0000003f

#define DRM_KEYGEN_RDATA_READ_MASK     0xffffffff
#define DRM_KEYGEN_RDATA_WRITE_MASK    0xffffffff

#define DRM_KEYGEN_WADDR_READ_MASK     0x0000003f
#define DRM_KEYGEN_WADDR_WRITE_MASK    0x0000003f

#define DRM_KEYGEN_WDATA_READ_MASK     0xffffffff
#define DRM_KEYGEN_WDATA_WRITE_MASK    0xffffffff

#define DRM_HFS_START_READ_MASK        0x0000000f
#define DRM_HFS_START_WRITE_MASK       0x0000000f

#define DRM_HFS_SW_NONCE0_READ_MASK    0xffffffff
#define DRM_HFS_SW_NONCE0_WRITE_MASK   0xffffffff

#define DRM_HFS_SW_NONCE1_READ_MASK    0xffffffff
#define DRM_HFS_SW_NONCE1_WRITE_MASK   0xffffffff

#define DRM_HFS_SW_NONCE2_READ_MASK    0xffffffff
#define DRM_HFS_SW_NONCE2_WRITE_MASK   0xffffffff

#define DRM_HFS_SW_NONCE3_READ_MASK    0xffffffff
#define DRM_HFS_SW_NONCE3_WRITE_MASK   0xffffffff

#define DRM_HFS_HW_NONCE0_READ_MASK    0xffffffff
#define DRM_HFS_HW_NONCE0_WRITE_MASK   0x00000000

#define DRM_HFS_HW_NONCE1_READ_MASK    0xffffffff
#define DRM_HFS_HW_NONCE1_WRITE_MASK   0x00000000

#define DRM_HFS_HW_NONCE2_READ_MASK    0xffffffff
#define DRM_HFS_HW_NONCE2_WRITE_MASK   0x00000000

#define DRM_HFS_HW_NONCE3_READ_MASK    0xffffffff
#define DRM_HFS_HW_NONCE3_WRITE_MASK   0x00000000

#define DRM_SHARED_CLIENT_READ_MASK    0x00000001
#define DRM_SHARED_CLIENT_WRITE_MASK   0x00000001

#define DRM_TIMEOUT_READ_MASK          0xffffffff
#define DRM_TIMEOUT_WRITE_MASK         0xffffffff

#define DRM_BYTESWAP_READ_MASK         0x03010101
#define DRM_BYTESWAP_WRITE_MASK        0x03010101

#define DRM_RESET_READ_MASK            0xff810101
#define DRM_RESET_WRITE_MASK           0xff810101

#define DRM_ARB_PRIORITY_READ_MASK     0xffffffff
#define DRM_ARB_PRIORITY_WRITE_MASK    0xffffffff

#define DRM_TRNG_CNTL_READ_MASK        0x00000103
#define DRM_TRNG_CNTL_WRITE_MASK       0x00000103

#define DRM_TRNG_DATA_READ_MASK        0xffffffff
#define DRM_TRNG_DATA_WRITE_MASK       0x00000000

#define DRM_PERFMON_CNTL_READ_MASK     0x0000000f
#define DRM_PERFMON_CNTL_WRITE_MASK    0x0000000f

#define DRM_PERFCOUNTER1_SELECT_READ_MASK 0x0000003f
#define DRM_PERFCOUNTER1_SELECT_WRITE_MASK 0x0000003f

#define DRM_PERFCOUNTER2_SELECT_READ_MASK 0x0000003f
#define DRM_PERFCOUNTER2_SELECT_WRITE_MASK 0x0000003f

#define DRM_PERFCOUNTER1_LO_READ_MASK  0xffffffff
#define DRM_PERFCOUNTER1_LO_WRITE_MASK 0xffffffff

#define DRM_PERFCOUNTER1_HI_READ_MASK  0x0000ffff
#define DRM_PERFCOUNTER1_HI_WRITE_MASK 0x0000ffff

#define DRM_PERFCOUNTER2_LO_READ_MASK  0xffffffff
#define DRM_PERFCOUNTER2_LO_WRITE_MASK 0xffffffff

#define DRM_PERFCOUNTER2_HI_READ_MASK  0x0000ffff
#define DRM_PERFCOUNTER2_HI_WRITE_MASK 0x0000ffff

#define DRM_DEBUG_READ_MASK            0xffffffff
#define DRM_DEBUG_WRITE_MASK           0xffffffff

#define DRM_IH_CREDITS_READ_MASK       0x0000001f
#define DRM_IH_CREDITS_WRITE_MASK      0x0000001f

#define DRM_INT_STATUS_READ_MASK       0x00007fff
#define DRM_INT_STATUS_WRITE_MASK      0x00007fff

#define DRM_INT_MASK_READ_MASK         0x00007fff
#define DRM_INT_MASK_WRITE_MASK        0x00007fff

#define DRM_INT_ACK_READ_MASK          0x00000000
#define DRM_INT_ACK_WRITE_MASK         0x00007fff

#define DRM_STATUS_READ_MASK           0xff771fff
#define DRM_STATUS_WRITE_MASK          0x00000000

#define DRM_PROTO_ADDR_READ_MASK       0x00000fff
#define DRM_PROTO_ADDR_WRITE_MASK      0x00000fff

#define DRM_PROTO_DATA_READ_MASK       0xffffffff
#define DRM_PROTO_DATA_WRITE_MASK      0xffffffff

#define CGTT_DRM_CLK_CTRL0_READ_MASK   0xff607fff
#define CGTT_DRM_CLK_CTRL0_WRITE_MASK  0xff207fff

#define DRM_MASTER_CTRL_READ_MASK      0x0000000f
#define DRM_MASTER_CTRL_WRITE_MASK     0x0000000f

#define DRM_AUTH_SESSION_READ_MASK     0x0000000f
#define DRM_AUTH_SESSION_WRITE_MASK    0x0000000f

#define DH_TEST_READ_MASK              0x00000001
#define DH_TEST_WRITE_MASK             0x00000001

#define KHFS0_READ_MASK                0xffffffff
#define KHFS0_WRITE_MASK               0xffffffff

#define KHFS1_READ_MASK                0xffffffff
#define KHFS1_WRITE_MASK               0xffffffff

#define KHFS2_READ_MASK                0xffffffff
#define KHFS2_WRITE_MASK               0xffffffff

#define KHFS3_READ_MASK                0xffffffff
#define KHFS3_WRITE_MASK               0xffffffff

#define KSESSION0_READ_MASK            0xffffffff
#define KSESSION0_WRITE_MASK           0xffffffff

#define KSESSION1_READ_MASK            0xffffffff
#define KSESSION1_WRITE_MASK           0xffffffff

#define KSESSION2_READ_MASK            0xffffffff
#define KSESSION2_WRITE_MASK           0xffffffff

#define KSESSION3_READ_MASK            0xffffffff
#define KSESSION3_WRITE_MASK           0xffffffff

#define KSIG0_READ_MASK                0xffffffff
#define KSIG0_WRITE_MASK               0xffffffff

#define KSIG1_READ_MASK                0xffffffff
#define KSIG1_WRITE_MASK               0xffffffff

#define KSIG2_READ_MASK                0xffffffff
#define KSIG2_WRITE_MASK               0xffffffff

#define KSIG3_READ_MASK                0xffffffff
#define KSIG3_WRITE_MASK               0xffffffff

#define EXP0_READ_MASK                 0xffffffff
#define EXP0_WRITE_MASK                0xffffffff

#define EXP1_READ_MASK                 0xffffffff
#define EXP1_WRITE_MASK                0xffffffff

#define EXP2_READ_MASK                 0xffffffff
#define EXP2_WRITE_MASK                0xffffffff

#define EXP3_READ_MASK                 0xffffffff
#define EXP3_WRITE_MASK                0xffffffff

#define EXP4_READ_MASK                 0xffffffff
#define EXP4_WRITE_MASK                0xffffffff

#define EXP5_READ_MASK                 0xffffffff
#define EXP5_WRITE_MASK                0xffffffff

#define EXP6_READ_MASK                 0xffffffff
#define EXP6_WRITE_MASK                0xffffffff

#define EXP7_READ_MASK                 0xffffffff
#define EXP7_WRITE_MASK                0xffffffff

#define LX0_READ_MASK                  0xffffffff
#define LX0_WRITE_MASK                 0x00000000

#define LX1_READ_MASK                  0xffffffff
#define LX1_WRITE_MASK                 0x00000000

#define LX2_READ_MASK                  0xffffffff
#define LX2_WRITE_MASK                 0x00000000

#define LX3_READ_MASK                  0xffffffff
#define LX3_WRITE_MASK                 0x00000000

#define FAST_AES0_READ_MASK            0xffffffff
#define FAST_AES0_WRITE_MASK           0x00000000

#define FAST_AES1_READ_MASK            0xffffffff
#define FAST_AES1_WRITE_MASK           0x00000000

#define FAST_AES2_READ_MASK            0xffffffff
#define FAST_AES2_WRITE_MASK           0x00000000

#define FAST_AES3_READ_MASK            0xffffffff
#define FAST_AES3_WRITE_MASK           0x00000000

#define FAST_AES4_READ_MASK            0xffffffff
#define FAST_AES4_WRITE_MASK           0x00000000

#define FAST_AES5_READ_MASK            0xffffffff
#define FAST_AES5_WRITE_MASK           0x00000000

#define FAST_AES6_READ_MASK            0xffffffff
#define FAST_AES6_WRITE_MASK           0x00000000

#define FAST_AES7_READ_MASK            0xffffffff
#define FAST_AES7_WRITE_MASK           0x00000000

#define SLOW_AES0_READ_MASK            0xffffffff
#define SLOW_AES0_WRITE_MASK           0x00000000

#define SLOW_AES1_READ_MASK            0xffffffff
#define SLOW_AES1_WRITE_MASK           0x00000000

#define SLOW_AES2_READ_MASK            0xffffffff
#define SLOW_AES2_WRITE_MASK           0x00000000

#define SLOW_AES3_READ_MASK            0xffffffff
#define SLOW_AES3_WRITE_MASK           0x00000000

#define CCIPHER_A_IK0_READ_MASK        0xffffffff
#define CCIPHER_A_IK0_WRITE_MASK       0x00000000

#define CCIPHER_A_IK1_READ_MASK        0xffffffff
#define CCIPHER_A_IK1_WRITE_MASK       0x00000000

#define CCIPHER_A_IK2_READ_MASK        0xffffffff
#define CCIPHER_A_IK2_WRITE_MASK       0x00000000

#define CCIPHER_A_IK3_READ_MASK        0xffffffff
#define CCIPHER_A_IK3_WRITE_MASK       0x00000000

#define CCIPHER_A_S0_READ_MASK         0xffffffff
#define CCIPHER_A_S0_WRITE_MASK        0x00000000

#define CCIPHER_A_S1_READ_MASK         0xffffffff
#define CCIPHER_A_S1_WRITE_MASK        0x00000000

#define CCIPHER_A_S2_READ_MASK         0xffffffff
#define CCIPHER_A_S2_WRITE_MASK        0x00000000

#define CCIPHER_A_S3_READ_MASK         0xffffffff
#define CCIPHER_A_S3_WRITE_MASK        0x00000000

#define CCIPHER_A_S4_READ_MASK         0xffffffff
#define CCIPHER_A_S4_WRITE_MASK        0x00000000

#define CCIPHER_A_S5_READ_MASK         0xffffffff
#define CCIPHER_A_S5_WRITE_MASK        0x00000000

#define CCIPHER_A_S6_READ_MASK         0xffffffff
#define CCIPHER_A_S6_WRITE_MASK        0x00000000

#define CCIPHER_A_S7_READ_MASK         0xffffffff
#define CCIPHER_A_S7_WRITE_MASK        0x00000000

#define CCIPHER_A_S8_READ_MASK         0xffffffff
#define CCIPHER_A_S8_WRITE_MASK        0x00000000

#define CCIPHER_A_S9_READ_MASK         0xffffffff
#define CCIPHER_A_S9_WRITE_MASK        0x00000000

#define CCIPHER_A_S10_READ_MASK        0xffffffff
#define CCIPHER_A_S10_WRITE_MASK       0x00000000

#define CCIPHER_A_S11_READ_MASK        0xffffffff
#define CCIPHER_A_S11_WRITE_MASK       0x00000000

#define CCIPHER_A_S12_READ_MASK        0xffffffff
#define CCIPHER_A_S12_WRITE_MASK       0x00000000

#define CCIPHER_A_S13_READ_MASK        0xffffffff
#define CCIPHER_A_S13_WRITE_MASK       0x00000000

#define CCIPHER_A_S14_READ_MASK        0xffffffff
#define CCIPHER_A_S14_WRITE_MASK       0x00000000

#define CCIPHER_A_S15_READ_MASK        0xffffffff
#define CCIPHER_A_S15_WRITE_MASK       0x00000000

#define CCIPHER_A_S16_READ_MASK        0xffffffff
#define CCIPHER_A_S16_WRITE_MASK       0x00000000

#define CCIPHER_A_S17_READ_MASK        0xffffffff
#define CCIPHER_A_S17_WRITE_MASK       0x00000000

#define CCIPHER_A_S18_READ_MASK        0xffffffff
#define CCIPHER_A_S18_WRITE_MASK       0x00000000

#define CCIPHER_A_S19_READ_MASK        0xffffffff
#define CCIPHER_A_S19_WRITE_MASK       0x00000000

#define CCIPHER_A_S20_READ_MASK        0xffffffff
#define CCIPHER_A_S20_WRITE_MASK       0x00000000

#define CCIPHER_A_S21_READ_MASK        0xffffffff
#define CCIPHER_A_S21_WRITE_MASK       0x00000000

#define CCIPHER_A_S22_READ_MASK        0xffffffff
#define CCIPHER_A_S22_WRITE_MASK       0x00000000

#define CCIPHER_A_S23_READ_MASK        0xffffffff
#define CCIPHER_A_S23_WRITE_MASK       0x00000000

#define CCIPHER_A_S24_READ_MASK        0xffffffff
#define CCIPHER_A_S24_WRITE_MASK       0x00000000

#define CCIPHER_A_S25_READ_MASK        0xffffffff
#define CCIPHER_A_S25_WRITE_MASK       0x00000000

#define CCIPHER_A_S26_READ_MASK        0xffffffff
#define CCIPHER_A_S26_WRITE_MASK       0x00000000

#define CCIPHER_A_S27_READ_MASK        0xffffffff
#define CCIPHER_A_S27_WRITE_MASK       0x00000000

#define CCIPHER_A_S28_READ_MASK        0xffffffff
#define CCIPHER_A_S28_WRITE_MASK       0x00000000

#define CCIPHER_A_S29_READ_MASK        0xffffffff
#define CCIPHER_A_S29_WRITE_MASK       0x00000000

#define CCIPHER_A_S30_READ_MASK        0xffffffff
#define CCIPHER_A_S30_WRITE_MASK       0x00000000

#define CCIPHER_A_S31_READ_MASK        0xffffffff
#define CCIPHER_A_S31_WRITE_MASK       0x00000000

#define CCIPHER_B_IK0_READ_MASK        0xffffffff
#define CCIPHER_B_IK0_WRITE_MASK       0x00000000

#define CCIPHER_B_IK1_READ_MASK        0xffffffff
#define CCIPHER_B_IK1_WRITE_MASK       0x00000000

#define CCIPHER_B_IK2_READ_MASK        0xffffffff
#define CCIPHER_B_IK2_WRITE_MASK       0x00000000

#define CCIPHER_B_IK3_READ_MASK        0xffffffff
#define CCIPHER_B_IK3_WRITE_MASK       0x00000000

#define CCIPHER_B_S0_READ_MASK         0xffffffff
#define CCIPHER_B_S0_WRITE_MASK        0x00000000

#define CCIPHER_B_S1_READ_MASK         0xffffffff
#define CCIPHER_B_S1_WRITE_MASK        0x00000000

#define CCIPHER_B_S2_READ_MASK         0xffffffff
#define CCIPHER_B_S2_WRITE_MASK        0x00000000

#define CCIPHER_B_S3_READ_MASK         0xffffffff
#define CCIPHER_B_S3_WRITE_MASK        0x00000000

#define CCIPHER_B_S4_READ_MASK         0xffffffff
#define CCIPHER_B_S4_WRITE_MASK        0x00000000

#define CCIPHER_B_S5_READ_MASK         0xffffffff
#define CCIPHER_B_S5_WRITE_MASK        0x00000000

#define CCIPHER_B_S6_READ_MASK         0xffffffff
#define CCIPHER_B_S6_WRITE_MASK        0x00000000

#define CCIPHER_B_S7_READ_MASK         0xffffffff
#define CCIPHER_B_S7_WRITE_MASK        0x00000000

#define CCIPHER_B_S8_READ_MASK         0xffffffff
#define CCIPHER_B_S8_WRITE_MASK        0x00000000

#define CCIPHER_B_S9_READ_MASK         0xffffffff
#define CCIPHER_B_S9_WRITE_MASK        0x00000000

#define CCIPHER_B_S10_READ_MASK        0xffffffff
#define CCIPHER_B_S10_WRITE_MASK       0x00000000

#define CCIPHER_B_S11_READ_MASK        0xffffffff
#define CCIPHER_B_S11_WRITE_MASK       0x00000000

#define CCIPHER_B_S12_READ_MASK        0xffffffff
#define CCIPHER_B_S12_WRITE_MASK       0x00000000

#define CCIPHER_B_S13_READ_MASK        0xffffffff
#define CCIPHER_B_S13_WRITE_MASK       0x00000000

#define CCIPHER_B_S14_READ_MASK        0xffffffff
#define CCIPHER_B_S14_WRITE_MASK       0x00000000

#define CCIPHER_B_S15_READ_MASK        0xffffffff
#define CCIPHER_B_S15_WRITE_MASK       0x00000000

#define CCIPHER_B_S16_READ_MASK        0xffffffff
#define CCIPHER_B_S16_WRITE_MASK       0x00000000

#define CCIPHER_B_S17_READ_MASK        0xffffffff
#define CCIPHER_B_S17_WRITE_MASK       0x00000000

#define CCIPHER_B_S18_READ_MASK        0xffffffff
#define CCIPHER_B_S18_WRITE_MASK       0x00000000

#define CCIPHER_B_S19_READ_MASK        0xffffffff
#define CCIPHER_B_S19_WRITE_MASK       0x00000000

#define CCIPHER_B_S20_READ_MASK        0xffffffff
#define CCIPHER_B_S20_WRITE_MASK       0x00000000

#define CCIPHER_B_S21_READ_MASK        0xffffffff
#define CCIPHER_B_S21_WRITE_MASK       0x00000000

#define CCIPHER_B_S22_READ_MASK        0xffffffff
#define CCIPHER_B_S22_WRITE_MASK       0x00000000

#define CCIPHER_B_S23_READ_MASK        0xffffffff
#define CCIPHER_B_S23_WRITE_MASK       0x00000000

#define CCIPHER_B_S24_READ_MASK        0xffffffff
#define CCIPHER_B_S24_WRITE_MASK       0x00000000

#define CCIPHER_B_S25_READ_MASK        0xffffffff
#define CCIPHER_B_S25_WRITE_MASK       0x00000000

#define CCIPHER_B_S26_READ_MASK        0xffffffff
#define CCIPHER_B_S26_WRITE_MASK       0x00000000

#define CCIPHER_B_S27_READ_MASK        0xffffffff
#define CCIPHER_B_S27_WRITE_MASK       0x00000000

#define CCIPHER_B_S28_READ_MASK        0xffffffff
#define CCIPHER_B_S28_WRITE_MASK       0x00000000

#define CCIPHER_B_S29_READ_MASK        0xffffffff
#define CCIPHER_B_S29_WRITE_MASK       0x00000000

#define CCIPHER_B_S30_READ_MASK        0xffffffff
#define CCIPHER_B_S30_WRITE_MASK       0x00000000

#define CCIPHER_B_S31_READ_MASK        0xffffffff
#define CCIPHER_B_S31_WRITE_MASK       0x00000000

#define CLIENT2_K0_READ_MASK           0xffffffff
#define CLIENT2_K0_WRITE_MASK          0x00000000

#define CLIENT2_K1_READ_MASK           0xffffffff
#define CLIENT2_K1_WRITE_MASK          0x00000000

#define CLIENT2_K2_READ_MASK           0xffffffff
#define CLIENT2_K2_WRITE_MASK          0x00000000

#define CLIENT2_K3_READ_MASK           0xffffffff
#define CLIENT2_K3_WRITE_MASK          0x00000000

#define CLIENT2_CK0_READ_MASK          0xffffffff
#define CLIENT2_CK0_WRITE_MASK         0x00000000

#define CLIENT2_CK1_READ_MASK          0xffffffff
#define CLIENT2_CK1_WRITE_MASK         0x00000000

#define CLIENT2_CK2_READ_MASK          0xffffffff
#define CLIENT2_CK2_WRITE_MASK         0x00000000

#define CLIENT2_CK3_READ_MASK          0xffffffff
#define CLIENT2_CK3_WRITE_MASK         0x00000000

#define CLIENT2_CD0_READ_MASK          0xffffffff
#define CLIENT2_CD0_WRITE_MASK         0x00000000

#define CLIENT2_CD1_READ_MASK          0xffffffff
#define CLIENT2_CD1_WRITE_MASK         0x00000000

#define CLIENT2_CD2_READ_MASK          0xffffffff
#define CLIENT2_CD2_WRITE_MASK         0x00000000

#define CLIENT2_CD3_READ_MASK          0xffffffff
#define CLIENT2_CD3_WRITE_MASK         0x00000000

#define CLIENT2_BM_READ_MASK           0xffffffff
#define CLIENT2_BM_WRITE_MASK          0x00000000

#define CLIENT2_OFFSET_READ_MASK       0xffffffff
#define CLIENT2_OFFSET_WRITE_MASK      0x00000000

#define CLIENT2_STATUS_READ_MASK       0xffffffff
#define CLIENT2_STATUS_WRITE_MASK      0x00000000

#define CLIENT0_K0_READ_MASK           0xffffffff
#define CLIENT0_K0_WRITE_MASK          0x00000000

#define CLIENT0_K1_READ_MASK           0xffffffff
#define CLIENT0_K1_WRITE_MASK          0x00000000

#define CLIENT0_K2_READ_MASK           0xffffffff
#define CLIENT0_K2_WRITE_MASK          0x00000000

#define CLIENT0_K3_READ_MASK           0xffffffff
#define CLIENT0_K3_WRITE_MASK          0x00000000

#define CLIENT0_CK0_READ_MASK          0xffffffff
#define CLIENT0_CK0_WRITE_MASK         0x00000000

#define CLIENT0_CK1_READ_MASK          0xffffffff
#define CLIENT0_CK1_WRITE_MASK         0x00000000

#define CLIENT0_CK2_READ_MASK          0xffffffff
#define CLIENT0_CK2_WRITE_MASK         0x00000000

#define CLIENT0_CK3_READ_MASK          0xffffffff
#define CLIENT0_CK3_WRITE_MASK         0x00000000

#define CLIENT0_CD0_READ_MASK          0xffffffff
#define CLIENT0_CD0_WRITE_MASK         0x00000000

#define CLIENT0_CD1_READ_MASK          0xffffffff
#define CLIENT0_CD1_WRITE_MASK         0x00000000

#define CLIENT0_CD2_READ_MASK          0xffffffff
#define CLIENT0_CD2_WRITE_MASK         0x00000000

#define CLIENT0_CD3_READ_MASK          0xffffffff
#define CLIENT0_CD3_WRITE_MASK         0x00000000

#define CLIENT0_BM_READ_MASK           0xffffffff
#define CLIENT0_BM_WRITE_MASK          0x00000000

#define CLIENT0_OFFSET_READ_MASK       0xffffffff
#define CLIENT0_OFFSET_WRITE_MASK      0x00000000

#define CLIENT0_STATUS_READ_MASK       0xffffffff
#define CLIENT0_STATUS_WRITE_MASK      0x00000000

#define CLIENT1_K0_READ_MASK           0xffffffff
#define CLIENT1_K0_WRITE_MASK          0x00000000

#define CLIENT1_K1_READ_MASK           0xffffffff
#define CLIENT1_K1_WRITE_MASK          0x00000000

#define CLIENT1_K2_READ_MASK           0xffffffff
#define CLIENT1_K2_WRITE_MASK          0x00000000

#define CLIENT1_K3_READ_MASK           0xffffffff
#define CLIENT1_K3_WRITE_MASK          0x00000000

#define CLIENT1_CK0_READ_MASK          0xffffffff
#define CLIENT1_CK0_WRITE_MASK         0x00000000

#define CLIENT1_CK1_READ_MASK          0xffffffff
#define CLIENT1_CK1_WRITE_MASK         0x00000000

#define CLIENT1_CK2_READ_MASK          0xffffffff
#define CLIENT1_CK2_WRITE_MASK         0x00000000

#define CLIENT1_CK3_READ_MASK          0xffffffff
#define CLIENT1_CK3_WRITE_MASK         0x00000000

#define CLIENT1_CD0_READ_MASK          0xffffffff
#define CLIENT1_CD0_WRITE_MASK         0x00000000

#define CLIENT1_CD1_READ_MASK          0xffffffff
#define CLIENT1_CD1_WRITE_MASK         0x00000000

#define CLIENT1_CD2_READ_MASK          0xffffffff
#define CLIENT1_CD2_WRITE_MASK         0x00000000

#define CLIENT1_CD3_READ_MASK          0xffffffff
#define CLIENT1_CD3_WRITE_MASK         0x00000000

#define CLIENT1_BM_READ_MASK           0xffffffff
#define CLIENT1_BM_WRITE_MASK          0x00000000

#define CLIENT1_OFFSET_READ_MASK       0xffffffff
#define CLIENT1_OFFSET_WRITE_MASK      0x00000000

#define CLIENT1_PORT_STATUS_READ_MASK  0xffffffff
#define CLIENT1_PORT_STATUS_WRITE_MASK 0x00000000

#define KEFUSE0_READ_MASK              0xffffffff
#define KEFUSE0_WRITE_MASK             0xffffffff

#define KEFUSE1_READ_MASK              0xffffffff
#define KEFUSE1_WRITE_MASK             0xffffffff

#define KEFUSE2_READ_MASK              0xffffffff
#define KEFUSE2_WRITE_MASK             0xffffffff

#define KEFUSE3_READ_MASK              0xffffffff
#define KEFUSE3_WRITE_MASK             0xffffffff

#define HFS_SEED0_READ_MASK            0xffffffff
#define HFS_SEED0_WRITE_MASK           0x00000000

#define HFS_SEED1_READ_MASK            0xffffffff
#define HFS_SEED1_WRITE_MASK           0x00000000

#define HFS_SEED2_READ_MASK            0xffffffff
#define HFS_SEED2_WRITE_MASK           0x00000000

#define HFS_SEED3_READ_MASK            0xffffffff
#define HFS_SEED3_WRITE_MASK           0x00000000

#define RINGOSC_MASK_READ_MASK         0x0000ffff
#define RINGOSC_MASK_WRITE_MASK        0x0000ffff

#define AUTH_STATE_READ_MASK           0x00000007
#define AUTH_STATE_WRITE_MASK          0x00000007

#define CLIENT0_OFFSET_HI_READ_MASK    0xffffffff
#define CLIENT0_OFFSET_HI_WRITE_MASK   0xffffffff

#define CLIENT1_OFFSET_HI_READ_MASK    0xffffffff
#define CLIENT1_OFFSET_HI_WRITE_MASK   0xffffffff

#define CLIENT2_OFFSET_HI_READ_MASK    0xffffffff
#define CLIENT2_OFFSET_HI_WRITE_MASK   0xffffffff

#define SPU_PORT_STATUS_READ_MASK      0xffffffff
#define SPU_PORT_STATUS_WRITE_MASK     0x00000000

#define CLIENT3_OFFSET_HI_READ_MASK    0xffffffff
#define CLIENT3_OFFSET_HI_WRITE_MASK   0xffffffff

#define CLIENT3_K0_READ_MASK           0xffffffff
#define CLIENT3_K0_WRITE_MASK          0x00000000

#define CLIENT3_K1_READ_MASK           0xffffffff
#define CLIENT3_K1_WRITE_MASK          0x00000000

#define CLIENT3_K2_READ_MASK           0xffffffff
#define CLIENT3_K2_WRITE_MASK          0x00000000

#define CLIENT3_K3_READ_MASK           0xffffffff
#define CLIENT3_K3_WRITE_MASK          0x00000000

#define CLIENT3_CK0_READ_MASK          0xffffffff
#define CLIENT3_CK0_WRITE_MASK         0x00000000

#define CLIENT3_CK1_READ_MASK          0xffffffff
#define CLIENT3_CK1_WRITE_MASK         0x00000000

#define CLIENT3_CK2_READ_MASK          0xffffffff
#define CLIENT3_CK2_WRITE_MASK         0x00000000

#define CLIENT3_CK3_READ_MASK          0xffffffff
#define CLIENT3_CK3_WRITE_MASK         0x00000000

#define CLIENT3_CD0_READ_MASK          0xffffffff
#define CLIENT3_CD0_WRITE_MASK         0x00000000

#define CLIENT3_CD1_READ_MASK          0xffffffff
#define CLIENT3_CD1_WRITE_MASK         0x00000000

#define CLIENT3_CD2_READ_MASK          0xffffffff
#define CLIENT3_CD2_WRITE_MASK         0x00000000

#define CLIENT3_CD3_READ_MASK          0xffffffff
#define CLIENT3_CD3_WRITE_MASK         0x00000000

#define CLIENT3_BM_READ_MASK           0xffffffff
#define CLIENT3_BM_WRITE_MASK          0x00000000

#define CLIENT3_OFFSET_READ_MASK       0xffffffff
#define CLIENT3_OFFSET_WRITE_MASK      0x00000000

#define CLIENT3_STATUS_READ_MASK       0xffffffff
#define CLIENT3_STATUS_WRITE_MASK      0x00000000

#define CLIENT4_OFFSET_HI_READ_MASK    0xffffffff
#define CLIENT4_OFFSET_HI_WRITE_MASK   0xffffffff

#define CLIENT4_K0_READ_MASK           0xffffffff
#define CLIENT4_K0_WRITE_MASK          0x00000000

#define CLIENT4_K1_READ_MASK           0xffffffff
#define CLIENT4_K1_WRITE_MASK          0x00000000

#define CLIENT4_K2_READ_MASK           0xffffffff
#define CLIENT4_K2_WRITE_MASK          0x00000000

#define CLIENT4_K3_READ_MASK           0xffffffff
#define CLIENT4_K3_WRITE_MASK          0x00000000

#define CLIENT4_CK0_READ_MASK          0xffffffff
#define CLIENT4_CK0_WRITE_MASK         0x00000000

#define CLIENT4_CK1_READ_MASK          0xffffffff
#define CLIENT4_CK1_WRITE_MASK         0x00000000

#define CLIENT4_CK2_READ_MASK          0xffffffff
#define CLIENT4_CK2_WRITE_MASK         0x00000000

#define CLIENT4_CK3_READ_MASK          0xffffffff
#define CLIENT4_CK3_WRITE_MASK         0x00000000

#define CLIENT4_CD0_READ_MASK          0xffffffff
#define CLIENT4_CD0_WRITE_MASK         0x00000000

#define CLIENT4_CD1_READ_MASK          0xffffffff
#define CLIENT4_CD1_WRITE_MASK         0x00000000

#define CLIENT4_CD2_READ_MASK          0xffffffff
#define CLIENT4_CD2_WRITE_MASK         0x00000000

#define CLIENT4_CD3_READ_MASK          0xffffffff
#define CLIENT4_CD3_WRITE_MASK         0x00000000

#define CLIENT4_BM_READ_MASK           0xffffffff
#define CLIENT4_BM_WRITE_MASK          0x00000000

#define CLIENT4_OFFSET_READ_MASK       0xffffffff
#define CLIENT4_OFFSET_WRITE_MASK      0x00000000

#define CLIENT4_STATUS_READ_MASK       0xffffffff
#define CLIENT4_STATUS_WRITE_MASK      0x00000000

#define DC_TEST_DEBUG_INDEX_READ_MASK  0x000001ff
#define DC_TEST_DEBUG_INDEX_WRITE_MASK 0x000001ff

#define DC_TEST_DEBUG_DATA_READ_MASK   0xffffffff
#define DC_TEST_DEBUG_DATA_WRITE_MASK  0xffffffff

#define DRM_CNT_KEY_STATUS_READ_MASK   0x0000001f
#define DRM_CNT_KEY_STATUS_WRITE_MASK  0x0000001f

#define DRM_CLIENT4_EXT_READ_MASK      0x000007ff
#define DRM_CLIENT4_EXT_WRITE_MASK     0x000007ff

#define DRM_DEBUG_INDEX0_READ_MASK     0xffffffff
#define DRM_DEBUG_INDEX0_WRITE_MASK    0x00000000

#define DRM_DEBUG_INDEX1_READ_MASK     0xffffffff
#define DRM_DEBUG_INDEX1_WRITE_MASK    0x00000000

#define DRM_DEBUG_INDEX2_READ_MASK     0xffffffff
#define DRM_DEBUG_INDEX2_WRITE_MASK    0x00000000

#define DRM_DEBUG_INDEX3_READ_MASK     0xffffffff
#define DRM_DEBUG_INDEX3_WRITE_MASK    0x00000000

#define DRM_DEBUG_INDEX4_READ_MASK     0xffffffff
#define DRM_DEBUG_INDEX4_WRITE_MASK    0x00000000

#define DRM_DEBUG_INDEX5_READ_MASK     0xffffffff
#define DRM_DEBUG_INDEX5_WRITE_MASK    0x00000000

#define DRM_DEBUG_INDEX6_READ_MASK     0xffffffff
#define DRM_DEBUG_INDEX6_WRITE_MASK    0x00000000

#define DRM_DEBUG_INDEX7_READ_MASK     0xffffffff
#define DRM_DEBUG_INDEX7_WRITE_MASK    0x00000000

#define DRM_DEBUG_ID_READ_MASK         0xffffffff
#define DRM_DEBUG_ID_WRITE_MASK        0xffffffff

#define DRM_DSKI_COMMAND_READ_MASK     0xffffffff
#define DRM_DSKI_COMMAND_WRITE_MASK    0xffffffff

#define DRM_DSKI_KEY0_READ_MASK        0xffffffff
#define DRM_DSKI_KEY0_WRITE_MASK       0xffffffff

#define DRM_DSKI_KEY1_READ_MASK        0xffffffff
#define DRM_DSKI_KEY1_WRITE_MASK       0xffffffff

#define DRM_DSKI_KEY2_READ_MASK        0xffffffff
#define DRM_DSKI_KEY2_WRITE_MASK       0xffffffff

#define DRM_DSKI_KEY3_READ_MASK        0xffffffff
#define DRM_DSKI_KEY3_WRITE_MASK       0xffffffff

#define MP_DRM_DEBUG_READ_MASK         0x00000001
#define MP_DRM_DEBUG_WRITE_MASK        0x00000001

#define MP_DRM_ACC_VIOLATION_LOG_ADDR_READ_MASK 0xffffffff
#define MP_DRM_ACC_VIOLATION_LOG_ADDR_WRITE_MASK 0x00000000

#define MP_DRM_ACC_VIOLATION_LOG_STATUS_READ_MASK 0x1fffffc9
#define MP_DRM_ACC_VIOLATION_LOG_STATUS_WRITE_MASK 0x80000000

#endif


