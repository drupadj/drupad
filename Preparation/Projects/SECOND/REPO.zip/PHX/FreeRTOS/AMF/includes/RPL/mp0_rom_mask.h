// Copyright (c) 1994 - 2021 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MP0_ROM_MASK_H)
#define _MP0_ROM_MASK_H

/*
 *    mp0_rom_mask.h   
 *
 *    Register Spec Release:  <unknown>
 *
 *
 *      (c) 2000 ATI Technologies Inc.  (unpublished)
 *
 *       All rights reserved.  This notice is intended as a precaution against
 *     inadvertent publication and does not imply publication or any waiver
 *      of confidentiality.  The year included in the foregoing notice is the
 *     year of creation of the work.
 *
 */

/*******************************************************
 * Read and Write Masks
 *******************************************************/

#define MP0_ROM_ACC_VIOLATION_LOG_ADDR_READ_MASK 0xffffffff
#define MP0_ROM_ACC_VIOLATION_LOG_ADDR_WRITE_MASK 0x00000000

#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_READ_MASK 0x87ffffff
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_WRITE_MASK 0x80000000

#define MP0_ROM_MISC_CNTL_READ_MASK    0x47ff001f
#define MP0_ROM_MISC_CNTL_WRITE_MASK   0x053f001f

#define MP0_ROM_BOOTCODE_CNTL_READ_MASK 0x00000001
#define MP0_ROM_BOOTCODE_CNTL_WRITE_MASK 0x00000001

#define MP0_ROM_SCRATCH_0_READ_MASK    0xffffffff
#define MP0_ROM_SCRATCH_0_WRITE_MASK   0xffffffff

#define MP0_ROM_SCRATCH_1_READ_MASK    0xffffffff
#define MP0_ROM_SCRATCH_1_WRITE_MASK   0xffffffff

#define MP0_ROM_SCRATCH_2_READ_MASK    0xffffffff
#define MP0_ROM_SCRATCH_2_WRITE_MASK   0xffffffff

#define MP0_ROM_SCRATCH_3_READ_MASK    0xffffffff
#define MP0_ROM_SCRATCH_3_WRITE_MASK   0xffffffff

#define MP0_ROM_SCRATCH_4_READ_MASK    0xffffffff
#define MP0_ROM_SCRATCH_4_WRITE_MASK   0xffffffff

#define MP0_ROM_SCRATCH_5_READ_MASK    0xffffffff
#define MP0_ROM_SCRATCH_5_WRITE_MASK   0xffffffff

#define MP0_ROM_SCRATCH_6_READ_MASK    0xffffffff
#define MP0_ROM_SCRATCH_6_WRITE_MASK   0xffffffff

#define MP0_ROM_SCRATCH_7_READ_MASK    0xffffffff
#define MP0_ROM_SCRATCH_7_WRITE_MASK   0xffffffff

#endif


