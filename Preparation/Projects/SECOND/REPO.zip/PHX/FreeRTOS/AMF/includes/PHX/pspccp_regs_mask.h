// Copyright (c) 1994 - 2022 Advanced Micro Devices, Inc. All rights reserved.

#if !defined (_PSPCCP_REGS_MASK_H)
#define _PSPCCP_REGS_MASK_H

/*
 *    pspccp_regs_mask.h       
 *
 *    Register Spec Release:  <unknown>
 *
 *
 *      (c) 2021 Advanced Micro Devices, Inc.  (unpublished)
 *
 *        All rights reserved.  This notice is intended as a precaution against
 *     inadvertent publication and does not imply publication or any waiver
 *      of confidentiality.  The year included in the foregoing notice is the
 *     year of creation of the work.
 *
 */

/*******************************************************
 * Read and Write Masks
 *******************************************************/

#define PspCcpCmd_Queue_Mask_READ_MASK 0x00000007
#define PspCcpCmd_Queue_Mask_WRITE_MASK 0x00000007

#define PspCcpCmd_Queue_Priority0_READ_MASK 0x000001ff
#define PspCcpCmd_Queue_Priority0_WRITE_MASK 0x000001ff

#define PspCcpReqID_Config0_READ_MASK  0x000001ff
#define PspCcpReqID_Config0_WRITE_MASK 0x000001ff

#define PspCcpTrng_Out_READ_MASK       0xffffffff
#define PspCcpTrng_Out_WRITE_MASK      0x00000000

#define PspCcpTrng_Seed_READ_MASK      0xffffffff
#define PspCcpTrng_Seed_WRITE_MASK     0x00000000

#define PspCcpTrng_Raw_READ_MASK       0x0000ffff
#define PspCcpTrng_Raw_WRITE_MASK      0x00000000

#define PspCcpModule_Reset_READ_MASK   0x00000000
#define PspCcpModule_Reset_WRITE_MASK  0x0000ff3d

#define PspCcpCmd_Timeout_READ_MASK    0xffffffff
#define PspCcpCmd_Timeout_WRITE_MASK   0xffffffff

#define PspCcpCmd_Timeout_Granularity_READ_MASK 0xffffffff
#define PspCcpCmd_Timeout_Granularity_WRITE_MASK 0xffffffff

#define PspCcpLsb_Public_Protection_Mask_R0_READ_MASK 0x00000007
#define PspCcpLsb_Public_Protection_Mask_R0_WRITE_MASK 0x00000007

#define PspCcpLsb_Public_Protection_Mask_R1_READ_MASK 0x00000007
#define PspCcpLsb_Public_Protection_Mask_R1_WRITE_MASK 0x00000007

#define PspCcpLsb_Public_Protection_Mask_R2_READ_MASK 0x00000007
#define PspCcpLsb_Public_Protection_Mask_R2_WRITE_MASK 0x00000007

#define PspCcpLsb_Public_Protection_Mask_R3_READ_MASK 0x00000007
#define PspCcpLsb_Public_Protection_Mask_R3_WRITE_MASK 0x00000007

#define PspCcpLsb_Public_Protection_Mask_R4_READ_MASK 0x00000007
#define PspCcpLsb_Public_Protection_Mask_R4_WRITE_MASK 0x00000007

#define PspCcpLsb_Public_Protection_Mask_R5_READ_MASK 0x00000007
#define PspCcpLsb_Public_Protection_Mask_R5_WRITE_MASK 0x00000007

#define PspCcpLsb_Public_Protection_Mask_R6_READ_MASK 0x00000007
#define PspCcpLsb_Public_Protection_Mask_R6_WRITE_MASK 0x00000007

#define PspCcpLsb_Public_Protection_Mask_R7_READ_MASK 0x00000007
#define PspCcpLsb_Public_Protection_Mask_R7_WRITE_MASK 0x00000007

#define PspCcpLsb_Private_Protection_Mask_R0_READ_MASK 0x00000007
#define PspCcpLsb_Private_Protection_Mask_R0_WRITE_MASK 0x00000007

#define PspCcpLsb_Private_Protection_Mask_R1_READ_MASK 0x00000007
#define PspCcpLsb_Private_Protection_Mask_R1_WRITE_MASK 0x00000007

#define PspCcpLsb_Private_Protection_Mask_R2_READ_MASK 0x00000007
#define PspCcpLsb_Private_Protection_Mask_R2_WRITE_MASK 0x00000007

#define PspCcpLsb_Private_Protection_Mask_R3_READ_MASK 0x00000007
#define PspCcpLsb_Private_Protection_Mask_R3_WRITE_MASK 0x00000007

#define PspCcpLsb_Private_Protection_Mask_R4_READ_MASK 0x00000007
#define PspCcpLsb_Private_Protection_Mask_R4_WRITE_MASK 0x00000007

#define PspCcpLsb_Private_Protection_Mask_R5_READ_MASK 0x00000007
#define PspCcpLsb_Private_Protection_Mask_R5_WRITE_MASK 0x00000007

#define PspCcpLsb_Private_Protection_Mask_R6_READ_MASK 0x00000007
#define PspCcpLsb_Private_Protection_Mask_R6_WRITE_MASK 0x00000007

#define PspCcpLsb_Private_Protection_Mask_R7_READ_MASK 0x00000007
#define PspCcpLsb_Private_Protection_Mask_R7_WRITE_MASK 0x00000007

#define PspCcpMemory_Deep_Sleep_Enable_READ_MASK 0x00007fff
#define PspCcpMemory_Deep_Sleep_Enable_WRITE_MASK 0x00007fff

#define PspCcpMemory_Deep_Sleep_Status_READ_MASK 0x000000ff
#define PspCcpMemory_Deep_Sleep_Status_WRITE_MASK 0x00000000

#define PspCcpVersion_READ_MASK        0x3fffffff
#define PspCcpVersion_WRITE_MASK       0x00000000

#define PspCcpVqd0_Control_READ_MASK   0xffff007f
#define PspCcpVqd0_Control_WRITE_MASK  0xffff007d

#define PspCcpVqd0_Tail_Lo_READ_MASK   0xffffffff
#define PspCcpVqd0_Tail_Lo_WRITE_MASK  0xffffffff

#define PspCcpVqd0_Head_Lo_READ_MASK   0xffffffff
#define PspCcpVqd0_Head_Lo_WRITE_MASK  0xffffffff

#define PspCcpCmd_Interrupt_Enable_Q0_READ_MASK 0x0000000f
#define PspCcpCmd_Interrupt_Enable_Q0_WRITE_MASK 0x0000000f

#define PspCcpCmd_Interrupt_Status_Q0_READ_MASK 0x0000000f
#define PspCcpCmd_Interrupt_Status_Q0_WRITE_MASK 0x0000000f

#define PspCcpCmd_Status_Q0_READ_MASK  0x00001fff
#define PspCcpCmd_Status_Q0_WRITE_MASK 0x00000000

#define PspCcpCmd_Int_Status_Q0_READ_MASK 0x0000007f
#define PspCcpCmd_Int_Status_Q0_WRITE_MASK 0x00000000

#define PspCcpCmd_DMA_Status_Q0_READ_MASK 0x0007ffff
#define PspCcpCmd_DMA_Status_Q0_WRITE_MASK 0x00000000

#define PspCcpCmd_DMA_Read_Status_Q0_READ_MASK 0xffffffff
#define PspCcpCmd_DMA_Read_Status_Q0_WRITE_MASK 0x00000000

#define PspCcpCmd_DMA_Write_Status_Q0_READ_MASK 0xffffffff
#define PspCcpCmd_DMA_Write_Status_Q0_WRITE_MASK 0x00000000

#define PspCcpCmd_Abort_Q0_READ_MASK   0x00000000
#define PspCcpCmd_Abort_Q0_WRITE_MASK  0x8003ffff

#define PspCcpCmd_AxCACHE_Q0_READ_MASK 0x00000fff
#define PspCcpCmd_AxCACHE_Q0_WRITE_MASK 0x00000fff

#define PspCcpCmd_WFQ_Command_ID_Q0_READ_MASK 0x0000ffff
#define PspCcpCmd_WFQ_Command_ID_Q0_WRITE_MASK 0x0000ffff

#define PspCcpCmd_WFQ_Status_Q0_READ_MASK 0xffff003f
#define PspCcpCmd_WFQ_Status_Q0_WRITE_MASK 0x00000001

#define PspCcpVqd1_Control_READ_MASK   0xffff007f
#define PspCcpVqd1_Control_WRITE_MASK  0xffff007d

#define PspCcpVqd1_Tail_Lo_READ_MASK   0xffffffff
#define PspCcpVqd1_Tail_Lo_WRITE_MASK  0xffffffff

#define PspCcpVqd1_Head_Lo_READ_MASK   0xffffffff
#define PspCcpVqd1_Head_Lo_WRITE_MASK  0xffffffff

#define PspCcpCmd_Interrupt_Enable_Q1_READ_MASK 0x0000000f
#define PspCcpCmd_Interrupt_Enable_Q1_WRITE_MASK 0x0000000f

#define PspCcpCmd_Interrupt_Status_Q1_READ_MASK 0x0000000f
#define PspCcpCmd_Interrupt_Status_Q1_WRITE_MASK 0x0000000f

#define PspCcpCmd_Status_Q1_READ_MASK  0x00001fff
#define PspCcpCmd_Status_Q1_WRITE_MASK 0x00000000

#define PspCcpCmd_Int_Status_Q1_READ_MASK 0x0000007f
#define PspCcpCmd_Int_Status_Q1_WRITE_MASK 0x00000000

#define PspCcpCmd_DMA_Status_Q1_READ_MASK 0x0007ffff
#define PspCcpCmd_DMA_Status_Q1_WRITE_MASK 0x00000000

#define PspCcpCmd_DMA_Read_Status_Q1_READ_MASK 0xffffffff
#define PspCcpCmd_DMA_Read_Status_Q1_WRITE_MASK 0x00000000

#define PspCcpCmd_DMA_Write_Status_Q1_READ_MASK 0xffffffff
#define PspCcpCmd_DMA_Write_Status_Q1_WRITE_MASK 0x00000000

#define PspCcpCmd_Abort_Q1_READ_MASK   0x00000000
#define PspCcpCmd_Abort_Q1_WRITE_MASK  0x8003ffff

#define PspCcpCmd_AxCACHE_Q1_READ_MASK 0x00000fff
#define PspCcpCmd_AxCACHE_Q1_WRITE_MASK 0x00000fff

#define PspCcpCmd_WFQ_Command_ID_Q1_READ_MASK 0x0000ffff
#define PspCcpCmd_WFQ_Command_ID_Q1_WRITE_MASK 0x0000ffff

#define PspCcpCmd_WFQ_Status_Q1_READ_MASK 0xffff003f
#define PspCcpCmd_WFQ_Status_Q1_WRITE_MASK 0x00000001

#define PspCcpVqd2_Control_READ_MASK   0xffff007f
#define PspCcpVqd2_Control_WRITE_MASK  0xffff007d

#define PspCcpVqd2_Tail_Lo_READ_MASK   0xffffffff
#define PspCcpVqd2_Tail_Lo_WRITE_MASK  0xffffffff

#define PspCcpVqd2_Head_Lo_READ_MASK   0xffffffff
#define PspCcpVqd2_Head_Lo_WRITE_MASK  0xffffffff

#define PspCcpCmd_Interrupt_Enable_Q2_READ_MASK 0x0000000f
#define PspCcpCmd_Interrupt_Enable_Q2_WRITE_MASK 0x0000000f

#define PspCcpCmd_Interrupt_Status_Q2_READ_MASK 0x0000000f
#define PspCcpCmd_Interrupt_Status_Q2_WRITE_MASK 0x0000000f

#define PspCcpCmd_Status_Q2_READ_MASK  0x00001fff
#define PspCcpCmd_Status_Q2_WRITE_MASK 0x00000000

#define PspCcpCmd_Int_Status_Q2_READ_MASK 0x0000007f
#define PspCcpCmd_Int_Status_Q2_WRITE_MASK 0x00000000

#define PspCcpCmd_DMA_Status_Q2_READ_MASK 0x0007ffff
#define PspCcpCmd_DMA_Status_Q2_WRITE_MASK 0x00000000

#define PspCcpCmd_DMA_Read_Status_Q2_READ_MASK 0xffffffff
#define PspCcpCmd_DMA_Read_Status_Q2_WRITE_MASK 0x00000000

#define PspCcpCmd_DMA_Write_Status_Q2_READ_MASK 0xffffffff
#define PspCcpCmd_DMA_Write_Status_Q2_WRITE_MASK 0x00000000

#define PspCcpCmd_Abort_Q2_READ_MASK   0x00000000
#define PspCcpCmd_Abort_Q2_WRITE_MASK  0x8003ffff

#define PspCcpCmd_AxCACHE_Q2_READ_MASK 0x00000fff
#define PspCcpCmd_AxCACHE_Q2_WRITE_MASK 0x00000fff

#define PspCcpCmd_WFQ_Command_ID_Q2_READ_MASK 0x0000ffff
#define PspCcpCmd_WFQ_Command_ID_Q2_WRITE_MASK 0x0000ffff

#define PspCcpCmd_WFQ_Status_Q2_READ_MASK 0xffff003f
#define PspCcpCmd_WFQ_Status_Q2_WRITE_MASK 0x00000001

#define PspCcpConfig0_READ_MASK        0x0000000f
#define PspCcpConfig0_WRITE_MASK       0x0000000f

#define PspCcpTrng_Control_READ_MASK   0xe003fff7
#define PspCcpTrng_Control_WRITE_MASK  0xc003fff7

#define PspCcpDecompression0_Limit_Lo_READ_MASK 0xffffffff
#define PspCcpDecompression0_Limit_Lo_WRITE_MASK 0xffffffff

#define PspCcpDecompression0_Limit_Hi_READ_MASK 0xffffffff
#define PspCcpDecompression0_Limit_Hi_WRITE_MASK 0xffffffff

#define PspCcpDecompression0_Status_Lo_READ_MASK 0xffffffff
#define PspCcpDecompression0_Status_Lo_WRITE_MASK 0x00000000

#define PspCcpDecompression0_Status_Hi_READ_MASK 0xffffffff
#define PspCcpDecompression0_Status_Hi_WRITE_MASK 0x00000000

#define PspCcpFuse_Strap_READ_MASK     0x000000ff
#define PspCcpFuse_Strap_WRITE_MASK    0x000000ff

#define PspCcpLoad_Crypto_Key_READ_MASK 0x00000000
#define PspCcpLoad_Crypto_Key_WRITE_MASK 0xffffffff

#define PspCcpLoad_Crypto_Key_Ready_READ_MASK 0x00000001
#define PspCcpLoad_Crypto_Key_Ready_WRITE_MASK 0x00000000

#define PspCcpClock_Gating_Control_READ_MASK 0x001fffff
#define PspCcpClock_Gating_Control_WRITE_MASK 0x001fffff

#define PspCcpPgfsm_Config_Reg_READ_MASK 0xf000f7ff
#define PspCcpPgfsm_Config_Reg_WRITE_MASK 0xf000f7ff

#define PspCcpPgfsm_Write_Reg_READ_MASK 0x00000000
#define PspCcpPgfsm_Write_Reg_WRITE_MASK 0xffffffff

#define PspCcpPgfsm_Read_Reg_READ_MASK 0xffffffff
#define PspCcpPgfsm_Read_Reg_WRITE_MASK 0x00000000

#define PspCcpPg_Control_READ_MASK     0x000001ff
#define PspCcpPg_Control_WRITE_MASK    0x000001ff

#define PspCcpPg_Status_READ_MASK      0x00000003
#define PspCcpPg_Status_WRITE_MASK     0x00000000

#define PspCcp_pgmem_Control_READ_MASK 0xffffff07
#define PspCcp_pgmem_Control_WRITE_MASK 0xffffff07

#endif


