// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MP2_SMNIF_FIDDLE_H)
#define _MP2_SMNIF_FIDDLE_H

/*****************************************************************************************************************
 *
 *	mp2_smnif_reg.h
 *
 *	Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif


/*******************************************************
 * Values
 *******************************************************/


/*******************************************************
 * Structures
 *******************************************************/

/*
 * MP2_SMNIF_TLB_0 struct
 */

#define MP2_SMNIF_TLB_0_REG_SIZE       32
#define MP2_SMNIF_TLB_0_SMN_ADDR_SIZE  16

#define MP2_SMNIF_TLB_0_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_0_SMN_ADDR_MASK  0xffff

#define MP2_SMNIF_TLB_0_MASK \
     (MP2_SMNIF_TLB_0_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_0_DEFAULT        0x00000000

#define MP2_SMNIF_TLB_0_GET_SMN_ADDR(mp2_smnif_tlb_0) \
     ((mp2_smnif_tlb_0 & MP2_SMNIF_TLB_0_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_0_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_0_SET_SMN_ADDR(mp2_smnif_tlb_0_reg, smn_addr) \
     mp2_smnif_tlb_0_reg = (mp2_smnif_tlb_0_reg & ~MP2_SMNIF_TLB_0_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_0_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_0_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_0_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_0_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_0_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_0_t f;
} mp2_smnif_tlb_0_u;


/*
 * MP2_SMNIF_TLB_1 struct
 */

#define MP2_SMNIF_TLB_1_REG_SIZE       32
#define MP2_SMNIF_TLB_1_SMN_ADDR_SIZE  16

#define MP2_SMNIF_TLB_1_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_1_SMN_ADDR_MASK  0xffff

#define MP2_SMNIF_TLB_1_MASK \
     (MP2_SMNIF_TLB_1_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_1_DEFAULT        0x00000001

#define MP2_SMNIF_TLB_1_GET_SMN_ADDR(mp2_smnif_tlb_1) \
     ((mp2_smnif_tlb_1 & MP2_SMNIF_TLB_1_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_1_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_1_SET_SMN_ADDR(mp2_smnif_tlb_1_reg, smn_addr) \
     mp2_smnif_tlb_1_reg = (mp2_smnif_tlb_1_reg & ~MP2_SMNIF_TLB_1_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_1_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_1_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_1_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_1_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_1_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_1_t f;
} mp2_smnif_tlb_1_u;


/*
 * MP2_SMNIF_TLB_2 struct
 */

#define MP2_SMNIF_TLB_2_REG_SIZE       32
#define MP2_SMNIF_TLB_2_SMN_ADDR_SIZE  16

#define MP2_SMNIF_TLB_2_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_2_SMN_ADDR_MASK  0xffff

#define MP2_SMNIF_TLB_2_MASK \
     (MP2_SMNIF_TLB_2_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_2_DEFAULT        0x00000002

#define MP2_SMNIF_TLB_2_GET_SMN_ADDR(mp2_smnif_tlb_2) \
     ((mp2_smnif_tlb_2 & MP2_SMNIF_TLB_2_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_2_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_2_SET_SMN_ADDR(mp2_smnif_tlb_2_reg, smn_addr) \
     mp2_smnif_tlb_2_reg = (mp2_smnif_tlb_2_reg & ~MP2_SMNIF_TLB_2_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_2_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_2_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_2_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_2_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_2_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_2_t f;
} mp2_smnif_tlb_2_u;


/*
 * MP2_SMNIF_TLB_3 struct
 */

#define MP2_SMNIF_TLB_3_REG_SIZE       32
#define MP2_SMNIF_TLB_3_SMN_ADDR_SIZE  16

#define MP2_SMNIF_TLB_3_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_3_SMN_ADDR_MASK  0xffff

#define MP2_SMNIF_TLB_3_MASK \
     (MP2_SMNIF_TLB_3_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_3_DEFAULT        0x00000003

#define MP2_SMNIF_TLB_3_GET_SMN_ADDR(mp2_smnif_tlb_3) \
     ((mp2_smnif_tlb_3 & MP2_SMNIF_TLB_3_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_3_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_3_SET_SMN_ADDR(mp2_smnif_tlb_3_reg, smn_addr) \
     mp2_smnif_tlb_3_reg = (mp2_smnif_tlb_3_reg & ~MP2_SMNIF_TLB_3_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_3_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_3_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_3_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_3_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_3_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_3_t f;
} mp2_smnif_tlb_3_u;


/*
 * MP2_SMNIF_TLB_4 struct
 */

#define MP2_SMNIF_TLB_4_REG_SIZE       32
#define MP2_SMNIF_TLB_4_SMN_ADDR_SIZE  16

#define MP2_SMNIF_TLB_4_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_4_SMN_ADDR_MASK  0xffff

#define MP2_SMNIF_TLB_4_MASK \
     (MP2_SMNIF_TLB_4_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_4_DEFAULT        0x00000004

#define MP2_SMNIF_TLB_4_GET_SMN_ADDR(mp2_smnif_tlb_4) \
     ((mp2_smnif_tlb_4 & MP2_SMNIF_TLB_4_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_4_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_4_SET_SMN_ADDR(mp2_smnif_tlb_4_reg, smn_addr) \
     mp2_smnif_tlb_4_reg = (mp2_smnif_tlb_4_reg & ~MP2_SMNIF_TLB_4_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_4_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_4_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_4_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_4_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_4_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_4_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_4_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_4_t f;
} mp2_smnif_tlb_4_u;


/*
 * MP2_SMNIF_TLB_5 struct
 */

#define MP2_SMNIF_TLB_5_REG_SIZE       32
#define MP2_SMNIF_TLB_5_SMN_ADDR_SIZE  16

#define MP2_SMNIF_TLB_5_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_5_SMN_ADDR_MASK  0xffff

#define MP2_SMNIF_TLB_5_MASK \
     (MP2_SMNIF_TLB_5_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_5_DEFAULT        0x00000005

#define MP2_SMNIF_TLB_5_GET_SMN_ADDR(mp2_smnif_tlb_5) \
     ((mp2_smnif_tlb_5 & MP2_SMNIF_TLB_5_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_5_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_5_SET_SMN_ADDR(mp2_smnif_tlb_5_reg, smn_addr) \
     mp2_smnif_tlb_5_reg = (mp2_smnif_tlb_5_reg & ~MP2_SMNIF_TLB_5_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_5_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_5_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_5_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_5_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_5_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_5_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_5_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_5_t f;
} mp2_smnif_tlb_5_u;


/*
 * MP2_SMNIF_TLB_6 struct
 */

#define MP2_SMNIF_TLB_6_REG_SIZE       32
#define MP2_SMNIF_TLB_6_SMN_ADDR_SIZE  16

#define MP2_SMNIF_TLB_6_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_6_SMN_ADDR_MASK  0xffff

#define MP2_SMNIF_TLB_6_MASK \
     (MP2_SMNIF_TLB_6_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_6_DEFAULT        0x00000006

#define MP2_SMNIF_TLB_6_GET_SMN_ADDR(mp2_smnif_tlb_6) \
     ((mp2_smnif_tlb_6 & MP2_SMNIF_TLB_6_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_6_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_6_SET_SMN_ADDR(mp2_smnif_tlb_6_reg, smn_addr) \
     mp2_smnif_tlb_6_reg = (mp2_smnif_tlb_6_reg & ~MP2_SMNIF_TLB_6_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_6_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_6_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_6_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_6_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_6_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_6_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_6_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_6_t f;
} mp2_smnif_tlb_6_u;


/*
 * MP2_SMNIF_TLB_7 struct
 */

#define MP2_SMNIF_TLB_7_REG_SIZE       32
#define MP2_SMNIF_TLB_7_SMN_ADDR_SIZE  16

#define MP2_SMNIF_TLB_7_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_7_SMN_ADDR_MASK  0xffff

#define MP2_SMNIF_TLB_7_MASK \
     (MP2_SMNIF_TLB_7_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_7_DEFAULT        0x00000007

#define MP2_SMNIF_TLB_7_GET_SMN_ADDR(mp2_smnif_tlb_7) \
     ((mp2_smnif_tlb_7 & MP2_SMNIF_TLB_7_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_7_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_7_SET_SMN_ADDR(mp2_smnif_tlb_7_reg, smn_addr) \
     mp2_smnif_tlb_7_reg = (mp2_smnif_tlb_7_reg & ~MP2_SMNIF_TLB_7_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_7_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_7_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_7_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_7_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_7_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_7_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_7_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_7_t f;
} mp2_smnif_tlb_7_u;


/*
 * MP2_SMNIF_TLB_8 struct
 */

#define MP2_SMNIF_TLB_8_REG_SIZE       32
#define MP2_SMNIF_TLB_8_SMN_ADDR_SIZE  16

#define MP2_SMNIF_TLB_8_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_8_SMN_ADDR_MASK  0xffff

#define MP2_SMNIF_TLB_8_MASK \
     (MP2_SMNIF_TLB_8_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_8_DEFAULT        0x00000008

#define MP2_SMNIF_TLB_8_GET_SMN_ADDR(mp2_smnif_tlb_8) \
     ((mp2_smnif_tlb_8 & MP2_SMNIF_TLB_8_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_8_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_8_SET_SMN_ADDR(mp2_smnif_tlb_8_reg, smn_addr) \
     mp2_smnif_tlb_8_reg = (mp2_smnif_tlb_8_reg & ~MP2_SMNIF_TLB_8_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_8_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_8_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_8_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_8_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_8_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_8_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_8_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_8_t f;
} mp2_smnif_tlb_8_u;


/*
 * MP2_SMNIF_TLB_9 struct
 */

#define MP2_SMNIF_TLB_9_REG_SIZE       32
#define MP2_SMNIF_TLB_9_SMN_ADDR_SIZE  16

#define MP2_SMNIF_TLB_9_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_9_SMN_ADDR_MASK  0xffff

#define MP2_SMNIF_TLB_9_MASK \
     (MP2_SMNIF_TLB_9_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_9_DEFAULT        0x00000009

#define MP2_SMNIF_TLB_9_GET_SMN_ADDR(mp2_smnif_tlb_9) \
     ((mp2_smnif_tlb_9 & MP2_SMNIF_TLB_9_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_9_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_9_SET_SMN_ADDR(mp2_smnif_tlb_9_reg, smn_addr) \
     mp2_smnif_tlb_9_reg = (mp2_smnif_tlb_9_reg & ~MP2_SMNIF_TLB_9_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_9_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_9_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_9_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_9_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_9_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_9_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_9_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_9_t f;
} mp2_smnif_tlb_9_u;


/*
 * MP2_SMNIF_TLB_10 struct
 */

#define MP2_SMNIF_TLB_10_REG_SIZE      32
#define MP2_SMNIF_TLB_10_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_10_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_10_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_10_MASK \
     (MP2_SMNIF_TLB_10_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_10_DEFAULT       0x0000000a

#define MP2_SMNIF_TLB_10_GET_SMN_ADDR(mp2_smnif_tlb_10) \
     ((mp2_smnif_tlb_10 & MP2_SMNIF_TLB_10_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_10_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_10_SET_SMN_ADDR(mp2_smnif_tlb_10_reg, smn_addr) \
     mp2_smnif_tlb_10_reg = (mp2_smnif_tlb_10_reg & ~MP2_SMNIF_TLB_10_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_10_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_10_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_10_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_10_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_10_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_10_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_10_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_10_t f;
} mp2_smnif_tlb_10_u;


/*
 * MP2_SMNIF_TLB_11 struct
 */

#define MP2_SMNIF_TLB_11_REG_SIZE      32
#define MP2_SMNIF_TLB_11_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_11_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_11_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_11_MASK \
     (MP2_SMNIF_TLB_11_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_11_DEFAULT       0x0000000b

#define MP2_SMNIF_TLB_11_GET_SMN_ADDR(mp2_smnif_tlb_11) \
     ((mp2_smnif_tlb_11 & MP2_SMNIF_TLB_11_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_11_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_11_SET_SMN_ADDR(mp2_smnif_tlb_11_reg, smn_addr) \
     mp2_smnif_tlb_11_reg = (mp2_smnif_tlb_11_reg & ~MP2_SMNIF_TLB_11_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_11_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_11_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_11_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_11_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_11_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_11_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_11_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_11_t f;
} mp2_smnif_tlb_11_u;


/*
 * MP2_SMNIF_TLB_12 struct
 */

#define MP2_SMNIF_TLB_12_REG_SIZE      32
#define MP2_SMNIF_TLB_12_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_12_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_12_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_12_MASK \
     (MP2_SMNIF_TLB_12_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_12_DEFAULT       0x0000000c

#define MP2_SMNIF_TLB_12_GET_SMN_ADDR(mp2_smnif_tlb_12) \
     ((mp2_smnif_tlb_12 & MP2_SMNIF_TLB_12_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_12_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_12_SET_SMN_ADDR(mp2_smnif_tlb_12_reg, smn_addr) \
     mp2_smnif_tlb_12_reg = (mp2_smnif_tlb_12_reg & ~MP2_SMNIF_TLB_12_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_12_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_12_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_12_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_12_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_12_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_12_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_12_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_12_t f;
} mp2_smnif_tlb_12_u;


/*
 * MP2_SMNIF_TLB_13 struct
 */

#define MP2_SMNIF_TLB_13_REG_SIZE      32
#define MP2_SMNIF_TLB_13_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_13_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_13_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_13_MASK \
     (MP2_SMNIF_TLB_13_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_13_DEFAULT       0x0000000d

#define MP2_SMNIF_TLB_13_GET_SMN_ADDR(mp2_smnif_tlb_13) \
     ((mp2_smnif_tlb_13 & MP2_SMNIF_TLB_13_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_13_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_13_SET_SMN_ADDR(mp2_smnif_tlb_13_reg, smn_addr) \
     mp2_smnif_tlb_13_reg = (mp2_smnif_tlb_13_reg & ~MP2_SMNIF_TLB_13_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_13_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_13_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_13_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_13_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_13_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_13_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_13_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_13_t f;
} mp2_smnif_tlb_13_u;


/*
 * MP2_SMNIF_TLB_14 struct
 */

#define MP2_SMNIF_TLB_14_REG_SIZE      32
#define MP2_SMNIF_TLB_14_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_14_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_14_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_14_MASK \
     (MP2_SMNIF_TLB_14_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_14_DEFAULT       0x0000000e

#define MP2_SMNIF_TLB_14_GET_SMN_ADDR(mp2_smnif_tlb_14) \
     ((mp2_smnif_tlb_14 & MP2_SMNIF_TLB_14_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_14_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_14_SET_SMN_ADDR(mp2_smnif_tlb_14_reg, smn_addr) \
     mp2_smnif_tlb_14_reg = (mp2_smnif_tlb_14_reg & ~MP2_SMNIF_TLB_14_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_14_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_14_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_14_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_14_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_14_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_14_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_14_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_14_t f;
} mp2_smnif_tlb_14_u;


/*
 * MP2_SMNIF_TLB_15 struct
 */

#define MP2_SMNIF_TLB_15_REG_SIZE      32
#define MP2_SMNIF_TLB_15_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_15_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_15_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_15_MASK \
     (MP2_SMNIF_TLB_15_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_15_DEFAULT       0x0000000f

#define MP2_SMNIF_TLB_15_GET_SMN_ADDR(mp2_smnif_tlb_15) \
     ((mp2_smnif_tlb_15 & MP2_SMNIF_TLB_15_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_15_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_15_SET_SMN_ADDR(mp2_smnif_tlb_15_reg, smn_addr) \
     mp2_smnif_tlb_15_reg = (mp2_smnif_tlb_15_reg & ~MP2_SMNIF_TLB_15_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_15_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_15_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_15_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_15_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_15_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_15_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_15_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_15_t f;
} mp2_smnif_tlb_15_u;


/*
 * MP2_SMNIF_TLB_16 struct
 */

#define MP2_SMNIF_TLB_16_REG_SIZE      32
#define MP2_SMNIF_TLB_16_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_16_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_16_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_16_MASK \
     (MP2_SMNIF_TLB_16_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_16_DEFAULT       0x00000010

#define MP2_SMNIF_TLB_16_GET_SMN_ADDR(mp2_smnif_tlb_16) \
     ((mp2_smnif_tlb_16 & MP2_SMNIF_TLB_16_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_16_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_16_SET_SMN_ADDR(mp2_smnif_tlb_16_reg, smn_addr) \
     mp2_smnif_tlb_16_reg = (mp2_smnif_tlb_16_reg & ~MP2_SMNIF_TLB_16_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_16_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_16_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_16_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_16_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_16_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_16_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_16_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_16_t f;
} mp2_smnif_tlb_16_u;


/*
 * MP2_SMNIF_TLB_17 struct
 */

#define MP2_SMNIF_TLB_17_REG_SIZE      32
#define MP2_SMNIF_TLB_17_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_17_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_17_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_17_MASK \
     (MP2_SMNIF_TLB_17_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_17_DEFAULT       0x00000fff

#define MP2_SMNIF_TLB_17_GET_SMN_ADDR(mp2_smnif_tlb_17) \
     ((mp2_smnif_tlb_17 & MP2_SMNIF_TLB_17_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_17_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_17_SET_SMN_ADDR(mp2_smnif_tlb_17_reg, smn_addr) \
     mp2_smnif_tlb_17_reg = (mp2_smnif_tlb_17_reg & ~MP2_SMNIF_TLB_17_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_17_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_17_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_17_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_17_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_17_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_17_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_17_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_17_t f;
} mp2_smnif_tlb_17_u;


/*
 * MP2_SMNIF_TLB_18 struct
 */

#define MP2_SMNIF_TLB_18_REG_SIZE      32
#define MP2_SMNIF_TLB_18_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_18_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_18_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_18_MASK \
     (MP2_SMNIF_TLB_18_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_18_DEFAULT       0x00000fff

#define MP2_SMNIF_TLB_18_GET_SMN_ADDR(mp2_smnif_tlb_18) \
     ((mp2_smnif_tlb_18 & MP2_SMNIF_TLB_18_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_18_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_18_SET_SMN_ADDR(mp2_smnif_tlb_18_reg, smn_addr) \
     mp2_smnif_tlb_18_reg = (mp2_smnif_tlb_18_reg & ~MP2_SMNIF_TLB_18_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_18_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_18_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_18_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_18_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_18_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_18_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_18_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_18_t f;
} mp2_smnif_tlb_18_u;


/*
 * MP2_SMNIF_TLB_19 struct
 */

#define MP2_SMNIF_TLB_19_REG_SIZE      32
#define MP2_SMNIF_TLB_19_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_19_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_19_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_19_MASK \
     (MP2_SMNIF_TLB_19_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_19_DEFAULT       0x00000fff

#define MP2_SMNIF_TLB_19_GET_SMN_ADDR(mp2_smnif_tlb_19) \
     ((mp2_smnif_tlb_19 & MP2_SMNIF_TLB_19_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_19_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_19_SET_SMN_ADDR(mp2_smnif_tlb_19_reg, smn_addr) \
     mp2_smnif_tlb_19_reg = (mp2_smnif_tlb_19_reg & ~MP2_SMNIF_TLB_19_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_19_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_19_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_19_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_19_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_19_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_19_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_19_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_19_t f;
} mp2_smnif_tlb_19_u;


/*
 * MP2_SMNIF_TLB_20 struct
 */

#define MP2_SMNIF_TLB_20_REG_SIZE      32
#define MP2_SMNIF_TLB_20_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_20_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_20_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_20_MASK \
     (MP2_SMNIF_TLB_20_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_20_DEFAULT       0x00000fff

#define MP2_SMNIF_TLB_20_GET_SMN_ADDR(mp2_smnif_tlb_20) \
     ((mp2_smnif_tlb_20 & MP2_SMNIF_TLB_20_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_20_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_20_SET_SMN_ADDR(mp2_smnif_tlb_20_reg, smn_addr) \
     mp2_smnif_tlb_20_reg = (mp2_smnif_tlb_20_reg & ~MP2_SMNIF_TLB_20_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_20_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_20_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_20_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_20_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_20_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_20_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_20_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_20_t f;
} mp2_smnif_tlb_20_u;


/*
 * MP2_SMNIF_TLB_21 struct
 */

#define MP2_SMNIF_TLB_21_REG_SIZE      32
#define MP2_SMNIF_TLB_21_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_21_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_21_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_21_MASK \
     (MP2_SMNIF_TLB_21_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_21_DEFAULT       0x00000fff

#define MP2_SMNIF_TLB_21_GET_SMN_ADDR(mp2_smnif_tlb_21) \
     ((mp2_smnif_tlb_21 & MP2_SMNIF_TLB_21_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_21_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_21_SET_SMN_ADDR(mp2_smnif_tlb_21_reg, smn_addr) \
     mp2_smnif_tlb_21_reg = (mp2_smnif_tlb_21_reg & ~MP2_SMNIF_TLB_21_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_21_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_21_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_21_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_21_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_21_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_21_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_21_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_21_t f;
} mp2_smnif_tlb_21_u;


/*
 * MP2_SMNIF_TLB_22 struct
 */

#define MP2_SMNIF_TLB_22_REG_SIZE      32
#define MP2_SMNIF_TLB_22_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_22_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_22_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_22_MASK \
     (MP2_SMNIF_TLB_22_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_22_DEFAULT       0x00000fff

#define MP2_SMNIF_TLB_22_GET_SMN_ADDR(mp2_smnif_tlb_22) \
     ((mp2_smnif_tlb_22 & MP2_SMNIF_TLB_22_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_22_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_22_SET_SMN_ADDR(mp2_smnif_tlb_22_reg, smn_addr) \
     mp2_smnif_tlb_22_reg = (mp2_smnif_tlb_22_reg & ~MP2_SMNIF_TLB_22_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_22_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_22_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_22_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_22_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_22_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_22_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_22_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_22_t f;
} mp2_smnif_tlb_22_u;


/*
 * MP2_SMNIF_TLB_23 struct
 */

#define MP2_SMNIF_TLB_23_REG_SIZE      32
#define MP2_SMNIF_TLB_23_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_23_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_23_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_23_MASK \
     (MP2_SMNIF_TLB_23_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_23_DEFAULT       0x00000fff

#define MP2_SMNIF_TLB_23_GET_SMN_ADDR(mp2_smnif_tlb_23) \
     ((mp2_smnif_tlb_23 & MP2_SMNIF_TLB_23_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_23_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_23_SET_SMN_ADDR(mp2_smnif_tlb_23_reg, smn_addr) \
     mp2_smnif_tlb_23_reg = (mp2_smnif_tlb_23_reg & ~MP2_SMNIF_TLB_23_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_23_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_23_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_23_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_23_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_23_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_23_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_23_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_23_t f;
} mp2_smnif_tlb_23_u;


/*
 * MP2_SMNIF_TLB_24 struct
 */

#define MP2_SMNIF_TLB_24_REG_SIZE      32
#define MP2_SMNIF_TLB_24_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_24_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_24_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_24_MASK \
     (MP2_SMNIF_TLB_24_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_24_DEFAULT       0x00000fff

#define MP2_SMNIF_TLB_24_GET_SMN_ADDR(mp2_smnif_tlb_24) \
     ((mp2_smnif_tlb_24 & MP2_SMNIF_TLB_24_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_24_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_24_SET_SMN_ADDR(mp2_smnif_tlb_24_reg, smn_addr) \
     mp2_smnif_tlb_24_reg = (mp2_smnif_tlb_24_reg & ~MP2_SMNIF_TLB_24_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_24_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_24_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_24_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_24_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_24_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_24_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_24_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_24_t f;
} mp2_smnif_tlb_24_u;


/*
 * MP2_SMNIF_TLB_25 struct
 */

#define MP2_SMNIF_TLB_25_REG_SIZE      32
#define MP2_SMNIF_TLB_25_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_25_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_25_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_25_MASK \
     (MP2_SMNIF_TLB_25_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_25_DEFAULT       0x00000fff

#define MP2_SMNIF_TLB_25_GET_SMN_ADDR(mp2_smnif_tlb_25) \
     ((mp2_smnif_tlb_25 & MP2_SMNIF_TLB_25_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_25_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_25_SET_SMN_ADDR(mp2_smnif_tlb_25_reg, smn_addr) \
     mp2_smnif_tlb_25_reg = (mp2_smnif_tlb_25_reg & ~MP2_SMNIF_TLB_25_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_25_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_25_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_25_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_25_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_25_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_25_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_25_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_25_t f;
} mp2_smnif_tlb_25_u;


/*
 * MP2_SMNIF_TLB_26 struct
 */

#define MP2_SMNIF_TLB_26_REG_SIZE      32
#define MP2_SMNIF_TLB_26_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_26_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_26_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_26_MASK \
     (MP2_SMNIF_TLB_26_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_26_DEFAULT       0x00000fff

#define MP2_SMNIF_TLB_26_GET_SMN_ADDR(mp2_smnif_tlb_26) \
     ((mp2_smnif_tlb_26 & MP2_SMNIF_TLB_26_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_26_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_26_SET_SMN_ADDR(mp2_smnif_tlb_26_reg, smn_addr) \
     mp2_smnif_tlb_26_reg = (mp2_smnif_tlb_26_reg & ~MP2_SMNIF_TLB_26_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_26_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_26_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_26_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_26_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_26_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_26_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_26_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_26_t f;
} mp2_smnif_tlb_26_u;


/*
 * MP2_SMNIF_TLB_27 struct
 */

#define MP2_SMNIF_TLB_27_REG_SIZE      32
#define MP2_SMNIF_TLB_27_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_27_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_27_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_27_MASK \
     (MP2_SMNIF_TLB_27_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_27_DEFAULT       0x00000fff

#define MP2_SMNIF_TLB_27_GET_SMN_ADDR(mp2_smnif_tlb_27) \
     ((mp2_smnif_tlb_27 & MP2_SMNIF_TLB_27_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_27_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_27_SET_SMN_ADDR(mp2_smnif_tlb_27_reg, smn_addr) \
     mp2_smnif_tlb_27_reg = (mp2_smnif_tlb_27_reg & ~MP2_SMNIF_TLB_27_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_27_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_27_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_27_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_27_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_27_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_27_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_27_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_27_t f;
} mp2_smnif_tlb_27_u;


/*
 * MP2_SMNIF_TLB_28 struct
 */

#define MP2_SMNIF_TLB_28_REG_SIZE      32
#define MP2_SMNIF_TLB_28_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_28_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_28_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_28_MASK \
     (MP2_SMNIF_TLB_28_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_28_DEFAULT       0x00000fff

#define MP2_SMNIF_TLB_28_GET_SMN_ADDR(mp2_smnif_tlb_28) \
     ((mp2_smnif_tlb_28 & MP2_SMNIF_TLB_28_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_28_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_28_SET_SMN_ADDR(mp2_smnif_tlb_28_reg, smn_addr) \
     mp2_smnif_tlb_28_reg = (mp2_smnif_tlb_28_reg & ~MP2_SMNIF_TLB_28_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_28_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_28_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_28_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_28_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_28_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_28_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_28_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_28_t f;
} mp2_smnif_tlb_28_u;


/*
 * MP2_SMNIF_TLB_29 struct
 */

#define MP2_SMNIF_TLB_29_REG_SIZE      32
#define MP2_SMNIF_TLB_29_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_29_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_29_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_29_MASK \
     (MP2_SMNIF_TLB_29_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_29_DEFAULT       0x00000fff

#define MP2_SMNIF_TLB_29_GET_SMN_ADDR(mp2_smnif_tlb_29) \
     ((mp2_smnif_tlb_29 & MP2_SMNIF_TLB_29_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_29_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_29_SET_SMN_ADDR(mp2_smnif_tlb_29_reg, smn_addr) \
     mp2_smnif_tlb_29_reg = (mp2_smnif_tlb_29_reg & ~MP2_SMNIF_TLB_29_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_29_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_29_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_29_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_29_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_29_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_29_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_29_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_29_t f;
} mp2_smnif_tlb_29_u;


/*
 * MP2_SMNIF_TLB_30 struct
 */

#define MP2_SMNIF_TLB_30_REG_SIZE      32
#define MP2_SMNIF_TLB_30_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_30_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_30_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_30_MASK \
     (MP2_SMNIF_TLB_30_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_30_DEFAULT       0x00000fff

#define MP2_SMNIF_TLB_30_GET_SMN_ADDR(mp2_smnif_tlb_30) \
     ((mp2_smnif_tlb_30 & MP2_SMNIF_TLB_30_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_30_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_30_SET_SMN_ADDR(mp2_smnif_tlb_30_reg, smn_addr) \
     mp2_smnif_tlb_30_reg = (mp2_smnif_tlb_30_reg & ~MP2_SMNIF_TLB_30_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_30_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_30_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_30_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_30_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_30_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_30_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_30_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_30_t f;
} mp2_smnif_tlb_30_u;


/*
 * MP2_SMNIF_TLB_31 struct
 */

#define MP2_SMNIF_TLB_31_REG_SIZE      32
#define MP2_SMNIF_TLB_31_SMN_ADDR_SIZE 16

#define MP2_SMNIF_TLB_31_SMN_ADDR_SHIFT 0

#define MP2_SMNIF_TLB_31_SMN_ADDR_MASK 0xffff

#define MP2_SMNIF_TLB_31_MASK \
     (MP2_SMNIF_TLB_31_SMN_ADDR_MASK)

#define MP2_SMNIF_TLB_31_DEFAULT       0x00000fff

#define MP2_SMNIF_TLB_31_GET_SMN_ADDR(mp2_smnif_tlb_31) \
     ((mp2_smnif_tlb_31 & MP2_SMNIF_TLB_31_SMN_ADDR_MASK) >> MP2_SMNIF_TLB_31_SMN_ADDR_SHIFT)

#define MP2_SMNIF_TLB_31_SET_SMN_ADDR(mp2_smnif_tlb_31_reg, smn_addr) \
     mp2_smnif_tlb_31_reg = (mp2_smnif_tlb_31_reg & ~MP2_SMNIF_TLB_31_SMN_ADDR_MASK) | (smn_addr << MP2_SMNIF_TLB_31_SMN_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_31_t {
          unsigned int smn_addr                       : MP2_SMNIF_TLB_31_SMN_ADDR_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_tlb_31_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_31_t {
          unsigned int                                : 16;
          unsigned int smn_addr                       : MP2_SMNIF_TLB_31_SMN_ADDR_SIZE;
     } mp2_smnif_tlb_31_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_31_t f;
} mp2_smnif_tlb_31_u;


/*
 * MP2_SMNIF_TLV0 struct
 */

#define MP2_SMNIF_TLV0_REG_SIZE        32
#define MP2_SMNIF_TLV0_TLB0_SIZE       3
#define MP2_SMNIF_TLV0_TLB1_SIZE       3
#define MP2_SMNIF_TLV0_TLB2_SIZE       3
#define MP2_SMNIF_TLV0_TLB3_SIZE       3
#define MP2_SMNIF_TLV0_TLB4_SIZE       3
#define MP2_SMNIF_TLV0_TLB5_SIZE       3
#define MP2_SMNIF_TLV0_TLB6_SIZE       3
#define MP2_SMNIF_TLV0_TLB7_SIZE       3

#define MP2_SMNIF_TLV0_TLB0_SHIFT      0
#define MP2_SMNIF_TLV0_TLB1_SHIFT      4
#define MP2_SMNIF_TLV0_TLB2_SHIFT      8
#define MP2_SMNIF_TLV0_TLB3_SHIFT      12
#define MP2_SMNIF_TLV0_TLB4_SHIFT      16
#define MP2_SMNIF_TLV0_TLB5_SHIFT      20
#define MP2_SMNIF_TLV0_TLB6_SHIFT      24
#define MP2_SMNIF_TLV0_TLB7_SHIFT      28

#define MP2_SMNIF_TLV0_TLB0_MASK       0x7
#define MP2_SMNIF_TLV0_TLB1_MASK       0x70
#define MP2_SMNIF_TLV0_TLB2_MASK       0x700
#define MP2_SMNIF_TLV0_TLB3_MASK       0x7000
#define MP2_SMNIF_TLV0_TLB4_MASK       0x70000
#define MP2_SMNIF_TLV0_TLB5_MASK       0x700000
#define MP2_SMNIF_TLV0_TLB6_MASK       0x7000000
#define MP2_SMNIF_TLV0_TLB7_MASK       0x70000000

#define MP2_SMNIF_TLV0_MASK \
     (MP2_SMNIF_TLV0_TLB0_MASK | \
      MP2_SMNIF_TLV0_TLB1_MASK | \
      MP2_SMNIF_TLV0_TLB2_MASK | \
      MP2_SMNIF_TLV0_TLB3_MASK | \
      MP2_SMNIF_TLV0_TLB4_MASK | \
      MP2_SMNIF_TLV0_TLB5_MASK | \
      MP2_SMNIF_TLV0_TLB6_MASK | \
      MP2_SMNIF_TLV0_TLB7_MASK)

#define MP2_SMNIF_TLV0_DEFAULT         0x00000000

#define MP2_SMNIF_TLV0_GET_TLB0(mp2_smnif_tlv0) \
     ((mp2_smnif_tlv0 & MP2_SMNIF_TLV0_TLB0_MASK) >> MP2_SMNIF_TLV0_TLB0_SHIFT)
#define MP2_SMNIF_TLV0_GET_TLB1(mp2_smnif_tlv0) \
     ((mp2_smnif_tlv0 & MP2_SMNIF_TLV0_TLB1_MASK) >> MP2_SMNIF_TLV0_TLB1_SHIFT)
#define MP2_SMNIF_TLV0_GET_TLB2(mp2_smnif_tlv0) \
     ((mp2_smnif_tlv0 & MP2_SMNIF_TLV0_TLB2_MASK) >> MP2_SMNIF_TLV0_TLB2_SHIFT)
#define MP2_SMNIF_TLV0_GET_TLB3(mp2_smnif_tlv0) \
     ((mp2_smnif_tlv0 & MP2_SMNIF_TLV0_TLB3_MASK) >> MP2_SMNIF_TLV0_TLB3_SHIFT)
#define MP2_SMNIF_TLV0_GET_TLB4(mp2_smnif_tlv0) \
     ((mp2_smnif_tlv0 & MP2_SMNIF_TLV0_TLB4_MASK) >> MP2_SMNIF_TLV0_TLB4_SHIFT)
#define MP2_SMNIF_TLV0_GET_TLB5(mp2_smnif_tlv0) \
     ((mp2_smnif_tlv0 & MP2_SMNIF_TLV0_TLB5_MASK) >> MP2_SMNIF_TLV0_TLB5_SHIFT)
#define MP2_SMNIF_TLV0_GET_TLB6(mp2_smnif_tlv0) \
     ((mp2_smnif_tlv0 & MP2_SMNIF_TLV0_TLB6_MASK) >> MP2_SMNIF_TLV0_TLB6_SHIFT)
#define MP2_SMNIF_TLV0_GET_TLB7(mp2_smnif_tlv0) \
     ((mp2_smnif_tlv0 & MP2_SMNIF_TLV0_TLB7_MASK) >> MP2_SMNIF_TLV0_TLB7_SHIFT)

#define MP2_SMNIF_TLV0_SET_TLB0(mp2_smnif_tlv0_reg, tlb0) \
     mp2_smnif_tlv0_reg = (mp2_smnif_tlv0_reg & ~MP2_SMNIF_TLV0_TLB0_MASK) | (tlb0 << MP2_SMNIF_TLV0_TLB0_SHIFT)
#define MP2_SMNIF_TLV0_SET_TLB1(mp2_smnif_tlv0_reg, tlb1) \
     mp2_smnif_tlv0_reg = (mp2_smnif_tlv0_reg & ~MP2_SMNIF_TLV0_TLB1_MASK) | (tlb1 << MP2_SMNIF_TLV0_TLB1_SHIFT)
#define MP2_SMNIF_TLV0_SET_TLB2(mp2_smnif_tlv0_reg, tlb2) \
     mp2_smnif_tlv0_reg = (mp2_smnif_tlv0_reg & ~MP2_SMNIF_TLV0_TLB2_MASK) | (tlb2 << MP2_SMNIF_TLV0_TLB2_SHIFT)
#define MP2_SMNIF_TLV0_SET_TLB3(mp2_smnif_tlv0_reg, tlb3) \
     mp2_smnif_tlv0_reg = (mp2_smnif_tlv0_reg & ~MP2_SMNIF_TLV0_TLB3_MASK) | (tlb3 << MP2_SMNIF_TLV0_TLB3_SHIFT)
#define MP2_SMNIF_TLV0_SET_TLB4(mp2_smnif_tlv0_reg, tlb4) \
     mp2_smnif_tlv0_reg = (mp2_smnif_tlv0_reg & ~MP2_SMNIF_TLV0_TLB4_MASK) | (tlb4 << MP2_SMNIF_TLV0_TLB4_SHIFT)
#define MP2_SMNIF_TLV0_SET_TLB5(mp2_smnif_tlv0_reg, tlb5) \
     mp2_smnif_tlv0_reg = (mp2_smnif_tlv0_reg & ~MP2_SMNIF_TLV0_TLB5_MASK) | (tlb5 << MP2_SMNIF_TLV0_TLB5_SHIFT)
#define MP2_SMNIF_TLV0_SET_TLB6(mp2_smnif_tlv0_reg, tlb6) \
     mp2_smnif_tlv0_reg = (mp2_smnif_tlv0_reg & ~MP2_SMNIF_TLV0_TLB6_MASK) | (tlb6 << MP2_SMNIF_TLV0_TLB6_SHIFT)
#define MP2_SMNIF_TLV0_SET_TLB7(mp2_smnif_tlv0_reg, tlb7) \
     mp2_smnif_tlv0_reg = (mp2_smnif_tlv0_reg & ~MP2_SMNIF_TLV0_TLB7_MASK) | (tlb7 << MP2_SMNIF_TLV0_TLB7_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlv0_t {
          unsigned int tlb0                           : MP2_SMNIF_TLV0_TLB0_SIZE;
          unsigned int                                : 1;
          unsigned int tlb1                           : MP2_SMNIF_TLV0_TLB1_SIZE;
          unsigned int                                : 1;
          unsigned int tlb2                           : MP2_SMNIF_TLV0_TLB2_SIZE;
          unsigned int                                : 1;
          unsigned int tlb3                           : MP2_SMNIF_TLV0_TLB3_SIZE;
          unsigned int                                : 1;
          unsigned int tlb4                           : MP2_SMNIF_TLV0_TLB4_SIZE;
          unsigned int                                : 1;
          unsigned int tlb5                           : MP2_SMNIF_TLV0_TLB5_SIZE;
          unsigned int                                : 1;
          unsigned int tlb6                           : MP2_SMNIF_TLV0_TLB6_SIZE;
          unsigned int                                : 1;
          unsigned int tlb7                           : MP2_SMNIF_TLV0_TLB7_SIZE;
          unsigned int                                : 1;
     } mp2_smnif_tlv0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlv0_t {
          unsigned int                                : 1;
          unsigned int tlb7                           : MP2_SMNIF_TLV0_TLB7_SIZE;
          unsigned int                                : 1;
          unsigned int tlb6                           : MP2_SMNIF_TLV0_TLB6_SIZE;
          unsigned int                                : 1;
          unsigned int tlb5                           : MP2_SMNIF_TLV0_TLB5_SIZE;
          unsigned int                                : 1;
          unsigned int tlb4                           : MP2_SMNIF_TLV0_TLB4_SIZE;
          unsigned int                                : 1;
          unsigned int tlb3                           : MP2_SMNIF_TLV0_TLB3_SIZE;
          unsigned int                                : 1;
          unsigned int tlb2                           : MP2_SMNIF_TLV0_TLB2_SIZE;
          unsigned int                                : 1;
          unsigned int tlb1                           : MP2_SMNIF_TLV0_TLB1_SIZE;
          unsigned int                                : 1;
          unsigned int tlb0                           : MP2_SMNIF_TLV0_TLB0_SIZE;
     } mp2_smnif_tlv0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlv0_t f;
} mp2_smnif_tlv0_u;


/*
 * MP2_SMNIF_TLV1 struct
 */

#define MP2_SMNIF_TLV1_REG_SIZE        32
#define MP2_SMNIF_TLV1_TLB8_SIZE       3
#define MP2_SMNIF_TLV1_TLB9_SIZE       3
#define MP2_SMNIF_TLV1_TLB10_SIZE      3
#define MP2_SMNIF_TLV1_TLB11_SIZE      3
#define MP2_SMNIF_TLV1_TLB12_SIZE      3
#define MP2_SMNIF_TLV1_TLB13_SIZE      3
#define MP2_SMNIF_TLV1_TLB14_SIZE      3
#define MP2_SMNIF_TLV1_TLB15_SIZE      3

#define MP2_SMNIF_TLV1_TLB8_SHIFT      0
#define MP2_SMNIF_TLV1_TLB9_SHIFT      4
#define MP2_SMNIF_TLV1_TLB10_SHIFT     8
#define MP2_SMNIF_TLV1_TLB11_SHIFT     12
#define MP2_SMNIF_TLV1_TLB12_SHIFT     16
#define MP2_SMNIF_TLV1_TLB13_SHIFT     20
#define MP2_SMNIF_TLV1_TLB14_SHIFT     24
#define MP2_SMNIF_TLV1_TLB15_SHIFT     28

#define MP2_SMNIF_TLV1_TLB8_MASK       0x7
#define MP2_SMNIF_TLV1_TLB9_MASK       0x70
#define MP2_SMNIF_TLV1_TLB10_MASK      0x700
#define MP2_SMNIF_TLV1_TLB11_MASK      0x7000
#define MP2_SMNIF_TLV1_TLB12_MASK      0x70000
#define MP2_SMNIF_TLV1_TLB13_MASK      0x700000
#define MP2_SMNIF_TLV1_TLB14_MASK      0x7000000
#define MP2_SMNIF_TLV1_TLB15_MASK      0x70000000

#define MP2_SMNIF_TLV1_MASK \
     (MP2_SMNIF_TLV1_TLB8_MASK | \
      MP2_SMNIF_TLV1_TLB9_MASK | \
      MP2_SMNIF_TLV1_TLB10_MASK | \
      MP2_SMNIF_TLV1_TLB11_MASK | \
      MP2_SMNIF_TLV1_TLB12_MASK | \
      MP2_SMNIF_TLV1_TLB13_MASK | \
      MP2_SMNIF_TLV1_TLB14_MASK | \
      MP2_SMNIF_TLV1_TLB15_MASK)

#define MP2_SMNIF_TLV1_DEFAULT         0x00000000

#define MP2_SMNIF_TLV1_GET_TLB8(mp2_smnif_tlv1) \
     ((mp2_smnif_tlv1 & MP2_SMNIF_TLV1_TLB8_MASK) >> MP2_SMNIF_TLV1_TLB8_SHIFT)
#define MP2_SMNIF_TLV1_GET_TLB9(mp2_smnif_tlv1) \
     ((mp2_smnif_tlv1 & MP2_SMNIF_TLV1_TLB9_MASK) >> MP2_SMNIF_TLV1_TLB9_SHIFT)
#define MP2_SMNIF_TLV1_GET_TLB10(mp2_smnif_tlv1) \
     ((mp2_smnif_tlv1 & MP2_SMNIF_TLV1_TLB10_MASK) >> MP2_SMNIF_TLV1_TLB10_SHIFT)
#define MP2_SMNIF_TLV1_GET_TLB11(mp2_smnif_tlv1) \
     ((mp2_smnif_tlv1 & MP2_SMNIF_TLV1_TLB11_MASK) >> MP2_SMNIF_TLV1_TLB11_SHIFT)
#define MP2_SMNIF_TLV1_GET_TLB12(mp2_smnif_tlv1) \
     ((mp2_smnif_tlv1 & MP2_SMNIF_TLV1_TLB12_MASK) >> MP2_SMNIF_TLV1_TLB12_SHIFT)
#define MP2_SMNIF_TLV1_GET_TLB13(mp2_smnif_tlv1) \
     ((mp2_smnif_tlv1 & MP2_SMNIF_TLV1_TLB13_MASK) >> MP2_SMNIF_TLV1_TLB13_SHIFT)
#define MP2_SMNIF_TLV1_GET_TLB14(mp2_smnif_tlv1) \
     ((mp2_smnif_tlv1 & MP2_SMNIF_TLV1_TLB14_MASK) >> MP2_SMNIF_TLV1_TLB14_SHIFT)
#define MP2_SMNIF_TLV1_GET_TLB15(mp2_smnif_tlv1) \
     ((mp2_smnif_tlv1 & MP2_SMNIF_TLV1_TLB15_MASK) >> MP2_SMNIF_TLV1_TLB15_SHIFT)

#define MP2_SMNIF_TLV1_SET_TLB8(mp2_smnif_tlv1_reg, tlb8) \
     mp2_smnif_tlv1_reg = (mp2_smnif_tlv1_reg & ~MP2_SMNIF_TLV1_TLB8_MASK) | (tlb8 << MP2_SMNIF_TLV1_TLB8_SHIFT)
#define MP2_SMNIF_TLV1_SET_TLB9(mp2_smnif_tlv1_reg, tlb9) \
     mp2_smnif_tlv1_reg = (mp2_smnif_tlv1_reg & ~MP2_SMNIF_TLV1_TLB9_MASK) | (tlb9 << MP2_SMNIF_TLV1_TLB9_SHIFT)
#define MP2_SMNIF_TLV1_SET_TLB10(mp2_smnif_tlv1_reg, tlb10) \
     mp2_smnif_tlv1_reg = (mp2_smnif_tlv1_reg & ~MP2_SMNIF_TLV1_TLB10_MASK) | (tlb10 << MP2_SMNIF_TLV1_TLB10_SHIFT)
#define MP2_SMNIF_TLV1_SET_TLB11(mp2_smnif_tlv1_reg, tlb11) \
     mp2_smnif_tlv1_reg = (mp2_smnif_tlv1_reg & ~MP2_SMNIF_TLV1_TLB11_MASK) | (tlb11 << MP2_SMNIF_TLV1_TLB11_SHIFT)
#define MP2_SMNIF_TLV1_SET_TLB12(mp2_smnif_tlv1_reg, tlb12) \
     mp2_smnif_tlv1_reg = (mp2_smnif_tlv1_reg & ~MP2_SMNIF_TLV1_TLB12_MASK) | (tlb12 << MP2_SMNIF_TLV1_TLB12_SHIFT)
#define MP2_SMNIF_TLV1_SET_TLB13(mp2_smnif_tlv1_reg, tlb13) \
     mp2_smnif_tlv1_reg = (mp2_smnif_tlv1_reg & ~MP2_SMNIF_TLV1_TLB13_MASK) | (tlb13 << MP2_SMNIF_TLV1_TLB13_SHIFT)
#define MP2_SMNIF_TLV1_SET_TLB14(mp2_smnif_tlv1_reg, tlb14) \
     mp2_smnif_tlv1_reg = (mp2_smnif_tlv1_reg & ~MP2_SMNIF_TLV1_TLB14_MASK) | (tlb14 << MP2_SMNIF_TLV1_TLB14_SHIFT)
#define MP2_SMNIF_TLV1_SET_TLB15(mp2_smnif_tlv1_reg, tlb15) \
     mp2_smnif_tlv1_reg = (mp2_smnif_tlv1_reg & ~MP2_SMNIF_TLV1_TLB15_MASK) | (tlb15 << MP2_SMNIF_TLV1_TLB15_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlv1_t {
          unsigned int tlb8                           : MP2_SMNIF_TLV1_TLB8_SIZE;
          unsigned int                                : 1;
          unsigned int tlb9                           : MP2_SMNIF_TLV1_TLB9_SIZE;
          unsigned int                                : 1;
          unsigned int tlb10                          : MP2_SMNIF_TLV1_TLB10_SIZE;
          unsigned int                                : 1;
          unsigned int tlb11                          : MP2_SMNIF_TLV1_TLB11_SIZE;
          unsigned int                                : 1;
          unsigned int tlb12                          : MP2_SMNIF_TLV1_TLB12_SIZE;
          unsigned int                                : 1;
          unsigned int tlb13                          : MP2_SMNIF_TLV1_TLB13_SIZE;
          unsigned int                                : 1;
          unsigned int tlb14                          : MP2_SMNIF_TLV1_TLB14_SIZE;
          unsigned int                                : 1;
          unsigned int tlb15                          : MP2_SMNIF_TLV1_TLB15_SIZE;
          unsigned int                                : 1;
     } mp2_smnif_tlv1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlv1_t {
          unsigned int                                : 1;
          unsigned int tlb15                          : MP2_SMNIF_TLV1_TLB15_SIZE;
          unsigned int                                : 1;
          unsigned int tlb14                          : MP2_SMNIF_TLV1_TLB14_SIZE;
          unsigned int                                : 1;
          unsigned int tlb13                          : MP2_SMNIF_TLV1_TLB13_SIZE;
          unsigned int                                : 1;
          unsigned int tlb12                          : MP2_SMNIF_TLV1_TLB12_SIZE;
          unsigned int                                : 1;
          unsigned int tlb11                          : MP2_SMNIF_TLV1_TLB11_SIZE;
          unsigned int                                : 1;
          unsigned int tlb10                          : MP2_SMNIF_TLV1_TLB10_SIZE;
          unsigned int                                : 1;
          unsigned int tlb9                           : MP2_SMNIF_TLV1_TLB9_SIZE;
          unsigned int                                : 1;
          unsigned int tlb8                           : MP2_SMNIF_TLV1_TLB8_SIZE;
     } mp2_smnif_tlv1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlv1_t f;
} mp2_smnif_tlv1_u;


/*
 * MP2_SMNIF_TLV2 struct
 */

#define MP2_SMNIF_TLV2_REG_SIZE        32
#define MP2_SMNIF_TLV2_TLB16_SIZE      3
#define MP2_SMNIF_TLV2_TLB17_SIZE      3
#define MP2_SMNIF_TLV2_TLB18_SIZE      3
#define MP2_SMNIF_TLV2_TLB19_SIZE      3
#define MP2_SMNIF_TLV2_TLB20_SIZE      3
#define MP2_SMNIF_TLV2_TLB21_SIZE      3
#define MP2_SMNIF_TLV2_TLB22_SIZE      3
#define MP2_SMNIF_TLV2_TLB23_SIZE      3

#define MP2_SMNIF_TLV2_TLB16_SHIFT     0
#define MP2_SMNIF_TLV2_TLB17_SHIFT     4
#define MP2_SMNIF_TLV2_TLB18_SHIFT     8
#define MP2_SMNIF_TLV2_TLB19_SHIFT     12
#define MP2_SMNIF_TLV2_TLB20_SHIFT     16
#define MP2_SMNIF_TLV2_TLB21_SHIFT     20
#define MP2_SMNIF_TLV2_TLB22_SHIFT     24
#define MP2_SMNIF_TLV2_TLB23_SHIFT     28

#define MP2_SMNIF_TLV2_TLB16_MASK      0x7
#define MP2_SMNIF_TLV2_TLB17_MASK      0x70
#define MP2_SMNIF_TLV2_TLB18_MASK      0x700
#define MP2_SMNIF_TLV2_TLB19_MASK      0x7000
#define MP2_SMNIF_TLV2_TLB20_MASK      0x70000
#define MP2_SMNIF_TLV2_TLB21_MASK      0x700000
#define MP2_SMNIF_TLV2_TLB22_MASK      0x7000000
#define MP2_SMNIF_TLV2_TLB23_MASK      0x70000000

#define MP2_SMNIF_TLV2_MASK \
     (MP2_SMNIF_TLV2_TLB16_MASK | \
      MP2_SMNIF_TLV2_TLB17_MASK | \
      MP2_SMNIF_TLV2_TLB18_MASK | \
      MP2_SMNIF_TLV2_TLB19_MASK | \
      MP2_SMNIF_TLV2_TLB20_MASK | \
      MP2_SMNIF_TLV2_TLB21_MASK | \
      MP2_SMNIF_TLV2_TLB22_MASK | \
      MP2_SMNIF_TLV2_TLB23_MASK)

#define MP2_SMNIF_TLV2_DEFAULT         0x00000000

#define MP2_SMNIF_TLV2_GET_TLB16(mp2_smnif_tlv2) \
     ((mp2_smnif_tlv2 & MP2_SMNIF_TLV2_TLB16_MASK) >> MP2_SMNIF_TLV2_TLB16_SHIFT)
#define MP2_SMNIF_TLV2_GET_TLB17(mp2_smnif_tlv2) \
     ((mp2_smnif_tlv2 & MP2_SMNIF_TLV2_TLB17_MASK) >> MP2_SMNIF_TLV2_TLB17_SHIFT)
#define MP2_SMNIF_TLV2_GET_TLB18(mp2_smnif_tlv2) \
     ((mp2_smnif_tlv2 & MP2_SMNIF_TLV2_TLB18_MASK) >> MP2_SMNIF_TLV2_TLB18_SHIFT)
#define MP2_SMNIF_TLV2_GET_TLB19(mp2_smnif_tlv2) \
     ((mp2_smnif_tlv2 & MP2_SMNIF_TLV2_TLB19_MASK) >> MP2_SMNIF_TLV2_TLB19_SHIFT)
#define MP2_SMNIF_TLV2_GET_TLB20(mp2_smnif_tlv2) \
     ((mp2_smnif_tlv2 & MP2_SMNIF_TLV2_TLB20_MASK) >> MP2_SMNIF_TLV2_TLB20_SHIFT)
#define MP2_SMNIF_TLV2_GET_TLB21(mp2_smnif_tlv2) \
     ((mp2_smnif_tlv2 & MP2_SMNIF_TLV2_TLB21_MASK) >> MP2_SMNIF_TLV2_TLB21_SHIFT)
#define MP2_SMNIF_TLV2_GET_TLB22(mp2_smnif_tlv2) \
     ((mp2_smnif_tlv2 & MP2_SMNIF_TLV2_TLB22_MASK) >> MP2_SMNIF_TLV2_TLB22_SHIFT)
#define MP2_SMNIF_TLV2_GET_TLB23(mp2_smnif_tlv2) \
     ((mp2_smnif_tlv2 & MP2_SMNIF_TLV2_TLB23_MASK) >> MP2_SMNIF_TLV2_TLB23_SHIFT)

#define MP2_SMNIF_TLV2_SET_TLB16(mp2_smnif_tlv2_reg, tlb16) \
     mp2_smnif_tlv2_reg = (mp2_smnif_tlv2_reg & ~MP2_SMNIF_TLV2_TLB16_MASK) | (tlb16 << MP2_SMNIF_TLV2_TLB16_SHIFT)
#define MP2_SMNIF_TLV2_SET_TLB17(mp2_smnif_tlv2_reg, tlb17) \
     mp2_smnif_tlv2_reg = (mp2_smnif_tlv2_reg & ~MP2_SMNIF_TLV2_TLB17_MASK) | (tlb17 << MP2_SMNIF_TLV2_TLB17_SHIFT)
#define MP2_SMNIF_TLV2_SET_TLB18(mp2_smnif_tlv2_reg, tlb18) \
     mp2_smnif_tlv2_reg = (mp2_smnif_tlv2_reg & ~MP2_SMNIF_TLV2_TLB18_MASK) | (tlb18 << MP2_SMNIF_TLV2_TLB18_SHIFT)
#define MP2_SMNIF_TLV2_SET_TLB19(mp2_smnif_tlv2_reg, tlb19) \
     mp2_smnif_tlv2_reg = (mp2_smnif_tlv2_reg & ~MP2_SMNIF_TLV2_TLB19_MASK) | (tlb19 << MP2_SMNIF_TLV2_TLB19_SHIFT)
#define MP2_SMNIF_TLV2_SET_TLB20(mp2_smnif_tlv2_reg, tlb20) \
     mp2_smnif_tlv2_reg = (mp2_smnif_tlv2_reg & ~MP2_SMNIF_TLV2_TLB20_MASK) | (tlb20 << MP2_SMNIF_TLV2_TLB20_SHIFT)
#define MP2_SMNIF_TLV2_SET_TLB21(mp2_smnif_tlv2_reg, tlb21) \
     mp2_smnif_tlv2_reg = (mp2_smnif_tlv2_reg & ~MP2_SMNIF_TLV2_TLB21_MASK) | (tlb21 << MP2_SMNIF_TLV2_TLB21_SHIFT)
#define MP2_SMNIF_TLV2_SET_TLB22(mp2_smnif_tlv2_reg, tlb22) \
     mp2_smnif_tlv2_reg = (mp2_smnif_tlv2_reg & ~MP2_SMNIF_TLV2_TLB22_MASK) | (tlb22 << MP2_SMNIF_TLV2_TLB22_SHIFT)
#define MP2_SMNIF_TLV2_SET_TLB23(mp2_smnif_tlv2_reg, tlb23) \
     mp2_smnif_tlv2_reg = (mp2_smnif_tlv2_reg & ~MP2_SMNIF_TLV2_TLB23_MASK) | (tlb23 << MP2_SMNIF_TLV2_TLB23_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlv2_t {
          unsigned int tlb16                          : MP2_SMNIF_TLV2_TLB16_SIZE;
          unsigned int                                : 1;
          unsigned int tlb17                          : MP2_SMNIF_TLV2_TLB17_SIZE;
          unsigned int                                : 1;
          unsigned int tlb18                          : MP2_SMNIF_TLV2_TLB18_SIZE;
          unsigned int                                : 1;
          unsigned int tlb19                          : MP2_SMNIF_TLV2_TLB19_SIZE;
          unsigned int                                : 1;
          unsigned int tlb20                          : MP2_SMNIF_TLV2_TLB20_SIZE;
          unsigned int                                : 1;
          unsigned int tlb21                          : MP2_SMNIF_TLV2_TLB21_SIZE;
          unsigned int                                : 1;
          unsigned int tlb22                          : MP2_SMNIF_TLV2_TLB22_SIZE;
          unsigned int                                : 1;
          unsigned int tlb23                          : MP2_SMNIF_TLV2_TLB23_SIZE;
          unsigned int                                : 1;
     } mp2_smnif_tlv2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlv2_t {
          unsigned int                                : 1;
          unsigned int tlb23                          : MP2_SMNIF_TLV2_TLB23_SIZE;
          unsigned int                                : 1;
          unsigned int tlb22                          : MP2_SMNIF_TLV2_TLB22_SIZE;
          unsigned int                                : 1;
          unsigned int tlb21                          : MP2_SMNIF_TLV2_TLB21_SIZE;
          unsigned int                                : 1;
          unsigned int tlb20                          : MP2_SMNIF_TLV2_TLB20_SIZE;
          unsigned int                                : 1;
          unsigned int tlb19                          : MP2_SMNIF_TLV2_TLB19_SIZE;
          unsigned int                                : 1;
          unsigned int tlb18                          : MP2_SMNIF_TLV2_TLB18_SIZE;
          unsigned int                                : 1;
          unsigned int tlb17                          : MP2_SMNIF_TLV2_TLB17_SIZE;
          unsigned int                                : 1;
          unsigned int tlb16                          : MP2_SMNIF_TLV2_TLB16_SIZE;
     } mp2_smnif_tlv2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlv2_t f;
} mp2_smnif_tlv2_u;


/*
 * MP2_SMNIF_TLV3 struct
 */

#define MP2_SMNIF_TLV3_REG_SIZE        32
#define MP2_SMNIF_TLV3_TLB24_SIZE      3
#define MP2_SMNIF_TLV3_TLB25_SIZE      3
#define MP2_SMNIF_TLV3_TLB26_SIZE      3
#define MP2_SMNIF_TLV3_TLB27_SIZE      3
#define MP2_SMNIF_TLV3_TLB28_SIZE      3
#define MP2_SMNIF_TLV3_TLB29_SIZE      3
#define MP2_SMNIF_TLV3_TLB30_SIZE      3
#define MP2_SMNIF_TLV3_TLB31_SIZE      3

#define MP2_SMNIF_TLV3_TLB24_SHIFT     0
#define MP2_SMNIF_TLV3_TLB25_SHIFT     4
#define MP2_SMNIF_TLV3_TLB26_SHIFT     8
#define MP2_SMNIF_TLV3_TLB27_SHIFT     12
#define MP2_SMNIF_TLV3_TLB28_SHIFT     16
#define MP2_SMNIF_TLV3_TLB29_SHIFT     20
#define MP2_SMNIF_TLV3_TLB30_SHIFT     24
#define MP2_SMNIF_TLV3_TLB31_SHIFT     28

#define MP2_SMNIF_TLV3_TLB24_MASK      0x7
#define MP2_SMNIF_TLV3_TLB25_MASK      0x70
#define MP2_SMNIF_TLV3_TLB26_MASK      0x700
#define MP2_SMNIF_TLV3_TLB27_MASK      0x7000
#define MP2_SMNIF_TLV3_TLB28_MASK      0x70000
#define MP2_SMNIF_TLV3_TLB29_MASK      0x700000
#define MP2_SMNIF_TLV3_TLB30_MASK      0x7000000
#define MP2_SMNIF_TLV3_TLB31_MASK      0x70000000

#define MP2_SMNIF_TLV3_MASK \
     (MP2_SMNIF_TLV3_TLB24_MASK | \
      MP2_SMNIF_TLV3_TLB25_MASK | \
      MP2_SMNIF_TLV3_TLB26_MASK | \
      MP2_SMNIF_TLV3_TLB27_MASK | \
      MP2_SMNIF_TLV3_TLB28_MASK | \
      MP2_SMNIF_TLV3_TLB29_MASK | \
      MP2_SMNIF_TLV3_TLB30_MASK | \
      MP2_SMNIF_TLV3_TLB31_MASK)

#define MP2_SMNIF_TLV3_DEFAULT         0x00000000

#define MP2_SMNIF_TLV3_GET_TLB24(mp2_smnif_tlv3) \
     ((mp2_smnif_tlv3 & MP2_SMNIF_TLV3_TLB24_MASK) >> MP2_SMNIF_TLV3_TLB24_SHIFT)
#define MP2_SMNIF_TLV3_GET_TLB25(mp2_smnif_tlv3) \
     ((mp2_smnif_tlv3 & MP2_SMNIF_TLV3_TLB25_MASK) >> MP2_SMNIF_TLV3_TLB25_SHIFT)
#define MP2_SMNIF_TLV3_GET_TLB26(mp2_smnif_tlv3) \
     ((mp2_smnif_tlv3 & MP2_SMNIF_TLV3_TLB26_MASK) >> MP2_SMNIF_TLV3_TLB26_SHIFT)
#define MP2_SMNIF_TLV3_GET_TLB27(mp2_smnif_tlv3) \
     ((mp2_smnif_tlv3 & MP2_SMNIF_TLV3_TLB27_MASK) >> MP2_SMNIF_TLV3_TLB27_SHIFT)
#define MP2_SMNIF_TLV3_GET_TLB28(mp2_smnif_tlv3) \
     ((mp2_smnif_tlv3 & MP2_SMNIF_TLV3_TLB28_MASK) >> MP2_SMNIF_TLV3_TLB28_SHIFT)
#define MP2_SMNIF_TLV3_GET_TLB29(mp2_smnif_tlv3) \
     ((mp2_smnif_tlv3 & MP2_SMNIF_TLV3_TLB29_MASK) >> MP2_SMNIF_TLV3_TLB29_SHIFT)
#define MP2_SMNIF_TLV3_GET_TLB30(mp2_smnif_tlv3) \
     ((mp2_smnif_tlv3 & MP2_SMNIF_TLV3_TLB30_MASK) >> MP2_SMNIF_TLV3_TLB30_SHIFT)
#define MP2_SMNIF_TLV3_GET_TLB31(mp2_smnif_tlv3) \
     ((mp2_smnif_tlv3 & MP2_SMNIF_TLV3_TLB31_MASK) >> MP2_SMNIF_TLV3_TLB31_SHIFT)

#define MP2_SMNIF_TLV3_SET_TLB24(mp2_smnif_tlv3_reg, tlb24) \
     mp2_smnif_tlv3_reg = (mp2_smnif_tlv3_reg & ~MP2_SMNIF_TLV3_TLB24_MASK) | (tlb24 << MP2_SMNIF_TLV3_TLB24_SHIFT)
#define MP2_SMNIF_TLV3_SET_TLB25(mp2_smnif_tlv3_reg, tlb25) \
     mp2_smnif_tlv3_reg = (mp2_smnif_tlv3_reg & ~MP2_SMNIF_TLV3_TLB25_MASK) | (tlb25 << MP2_SMNIF_TLV3_TLB25_SHIFT)
#define MP2_SMNIF_TLV3_SET_TLB26(mp2_smnif_tlv3_reg, tlb26) \
     mp2_smnif_tlv3_reg = (mp2_smnif_tlv3_reg & ~MP2_SMNIF_TLV3_TLB26_MASK) | (tlb26 << MP2_SMNIF_TLV3_TLB26_SHIFT)
#define MP2_SMNIF_TLV3_SET_TLB27(mp2_smnif_tlv3_reg, tlb27) \
     mp2_smnif_tlv3_reg = (mp2_smnif_tlv3_reg & ~MP2_SMNIF_TLV3_TLB27_MASK) | (tlb27 << MP2_SMNIF_TLV3_TLB27_SHIFT)
#define MP2_SMNIF_TLV3_SET_TLB28(mp2_smnif_tlv3_reg, tlb28) \
     mp2_smnif_tlv3_reg = (mp2_smnif_tlv3_reg & ~MP2_SMNIF_TLV3_TLB28_MASK) | (tlb28 << MP2_SMNIF_TLV3_TLB28_SHIFT)
#define MP2_SMNIF_TLV3_SET_TLB29(mp2_smnif_tlv3_reg, tlb29) \
     mp2_smnif_tlv3_reg = (mp2_smnif_tlv3_reg & ~MP2_SMNIF_TLV3_TLB29_MASK) | (tlb29 << MP2_SMNIF_TLV3_TLB29_SHIFT)
#define MP2_SMNIF_TLV3_SET_TLB30(mp2_smnif_tlv3_reg, tlb30) \
     mp2_smnif_tlv3_reg = (mp2_smnif_tlv3_reg & ~MP2_SMNIF_TLV3_TLB30_MASK) | (tlb30 << MP2_SMNIF_TLV3_TLB30_SHIFT)
#define MP2_SMNIF_TLV3_SET_TLB31(mp2_smnif_tlv3_reg, tlb31) \
     mp2_smnif_tlv3_reg = (mp2_smnif_tlv3_reg & ~MP2_SMNIF_TLV3_TLB31_MASK) | (tlb31 << MP2_SMNIF_TLV3_TLB31_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlv3_t {
          unsigned int tlb24                          : MP2_SMNIF_TLV3_TLB24_SIZE;
          unsigned int                                : 1;
          unsigned int tlb25                          : MP2_SMNIF_TLV3_TLB25_SIZE;
          unsigned int                                : 1;
          unsigned int tlb26                          : MP2_SMNIF_TLV3_TLB26_SIZE;
          unsigned int                                : 1;
          unsigned int tlb27                          : MP2_SMNIF_TLV3_TLB27_SIZE;
          unsigned int                                : 1;
          unsigned int tlb28                          : MP2_SMNIF_TLV3_TLB28_SIZE;
          unsigned int                                : 1;
          unsigned int tlb29                          : MP2_SMNIF_TLV3_TLB29_SIZE;
          unsigned int                                : 1;
          unsigned int tlb30                          : MP2_SMNIF_TLV3_TLB30_SIZE;
          unsigned int                                : 1;
          unsigned int tlb31                          : MP2_SMNIF_TLV3_TLB31_SIZE;
          unsigned int                                : 1;
     } mp2_smnif_tlv3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlv3_t {
          unsigned int                                : 1;
          unsigned int tlb31                          : MP2_SMNIF_TLV3_TLB31_SIZE;
          unsigned int                                : 1;
          unsigned int tlb30                          : MP2_SMNIF_TLV3_TLB30_SIZE;
          unsigned int                                : 1;
          unsigned int tlb29                          : MP2_SMNIF_TLV3_TLB29_SIZE;
          unsigned int                                : 1;
          unsigned int tlb28                          : MP2_SMNIF_TLV3_TLB28_SIZE;
          unsigned int                                : 1;
          unsigned int tlb27                          : MP2_SMNIF_TLV3_TLB27_SIZE;
          unsigned int                                : 1;
          unsigned int tlb26                          : MP2_SMNIF_TLV3_TLB26_SIZE;
          unsigned int                                : 1;
          unsigned int tlb25                          : MP2_SMNIF_TLV3_TLB25_SIZE;
          unsigned int                                : 1;
          unsigned int tlb24                          : MP2_SMNIF_TLV3_TLB24_SIZE;
     } mp2_smnif_tlv3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlv3_t f;
} mp2_smnif_tlv3_u;


/*
 * MP2_SMNIF_TLB_VF0 struct
 */

#define MP2_SMNIF_TLB_VF0_REG_SIZE     32
#define MP2_SMNIF_TLB_VF0_VFID_SIZE    6
#define MP2_SMNIF_TLB_VF0_VF_SIZE      1
#define MP2_SMNIF_TLB_VF0_VALID_SIZE   1

#define MP2_SMNIF_TLB_VF0_VFID_SHIFT   0
#define MP2_SMNIF_TLB_VF0_VF_SHIFT     6
#define MP2_SMNIF_TLB_VF0_VALID_SHIFT  7

#define MP2_SMNIF_TLB_VF0_VFID_MASK    0x3f
#define MP2_SMNIF_TLB_VF0_VF_MASK      0x40
#define MP2_SMNIF_TLB_VF0_VALID_MASK   0x80

#define MP2_SMNIF_TLB_VF0_MASK \
     (MP2_SMNIF_TLB_VF0_VFID_MASK | \
      MP2_SMNIF_TLB_VF0_VF_MASK | \
      MP2_SMNIF_TLB_VF0_VALID_MASK)

#define MP2_SMNIF_TLB_VF0_DEFAULT      0x00000000

#define MP2_SMNIF_TLB_VF0_GET_VFID(mp2_smnif_tlb_vf0) \
     ((mp2_smnif_tlb_vf0 & MP2_SMNIF_TLB_VF0_VFID_MASK) >> MP2_SMNIF_TLB_VF0_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF0_GET_VF(mp2_smnif_tlb_vf0) \
     ((mp2_smnif_tlb_vf0 & MP2_SMNIF_TLB_VF0_VF_MASK) >> MP2_SMNIF_TLB_VF0_VF_SHIFT)
#define MP2_SMNIF_TLB_VF0_GET_VALID(mp2_smnif_tlb_vf0) \
     ((mp2_smnif_tlb_vf0 & MP2_SMNIF_TLB_VF0_VALID_MASK) >> MP2_SMNIF_TLB_VF0_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF0_SET_VFID(mp2_smnif_tlb_vf0_reg, vfid) \
     mp2_smnif_tlb_vf0_reg = (mp2_smnif_tlb_vf0_reg & ~MP2_SMNIF_TLB_VF0_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF0_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF0_SET_VF(mp2_smnif_tlb_vf0_reg, vf) \
     mp2_smnif_tlb_vf0_reg = (mp2_smnif_tlb_vf0_reg & ~MP2_SMNIF_TLB_VF0_VF_MASK) | (vf << MP2_SMNIF_TLB_VF0_VF_SHIFT)
#define MP2_SMNIF_TLB_VF0_SET_VALID(mp2_smnif_tlb_vf0_reg, valid) \
     mp2_smnif_tlb_vf0_reg = (mp2_smnif_tlb_vf0_reg & ~MP2_SMNIF_TLB_VF0_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF0_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf0_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF0_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF0_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF0_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf0_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF0_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF0_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF0_VFID_SIZE;
     } mp2_smnif_tlb_vf0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf0_t f;
} mp2_smnif_tlb_vf0_u;


/*
 * MP2_SMNIF_TLB_VF1 struct
 */

#define MP2_SMNIF_TLB_VF1_REG_SIZE     32
#define MP2_SMNIF_TLB_VF1_VFID_SIZE    6
#define MP2_SMNIF_TLB_VF1_VF_SIZE      1
#define MP2_SMNIF_TLB_VF1_VALID_SIZE   1

#define MP2_SMNIF_TLB_VF1_VFID_SHIFT   0
#define MP2_SMNIF_TLB_VF1_VF_SHIFT     6
#define MP2_SMNIF_TLB_VF1_VALID_SHIFT  7

#define MP2_SMNIF_TLB_VF1_VFID_MASK    0x3f
#define MP2_SMNIF_TLB_VF1_VF_MASK      0x40
#define MP2_SMNIF_TLB_VF1_VALID_MASK   0x80

#define MP2_SMNIF_TLB_VF1_MASK \
     (MP2_SMNIF_TLB_VF1_VFID_MASK | \
      MP2_SMNIF_TLB_VF1_VF_MASK | \
      MP2_SMNIF_TLB_VF1_VALID_MASK)

#define MP2_SMNIF_TLB_VF1_DEFAULT      0x00000000

#define MP2_SMNIF_TLB_VF1_GET_VFID(mp2_smnif_tlb_vf1) \
     ((mp2_smnif_tlb_vf1 & MP2_SMNIF_TLB_VF1_VFID_MASK) >> MP2_SMNIF_TLB_VF1_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF1_GET_VF(mp2_smnif_tlb_vf1) \
     ((mp2_smnif_tlb_vf1 & MP2_SMNIF_TLB_VF1_VF_MASK) >> MP2_SMNIF_TLB_VF1_VF_SHIFT)
#define MP2_SMNIF_TLB_VF1_GET_VALID(mp2_smnif_tlb_vf1) \
     ((mp2_smnif_tlb_vf1 & MP2_SMNIF_TLB_VF1_VALID_MASK) >> MP2_SMNIF_TLB_VF1_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF1_SET_VFID(mp2_smnif_tlb_vf1_reg, vfid) \
     mp2_smnif_tlb_vf1_reg = (mp2_smnif_tlb_vf1_reg & ~MP2_SMNIF_TLB_VF1_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF1_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF1_SET_VF(mp2_smnif_tlb_vf1_reg, vf) \
     mp2_smnif_tlb_vf1_reg = (mp2_smnif_tlb_vf1_reg & ~MP2_SMNIF_TLB_VF1_VF_MASK) | (vf << MP2_SMNIF_TLB_VF1_VF_SHIFT)
#define MP2_SMNIF_TLB_VF1_SET_VALID(mp2_smnif_tlb_vf1_reg, valid) \
     mp2_smnif_tlb_vf1_reg = (mp2_smnif_tlb_vf1_reg & ~MP2_SMNIF_TLB_VF1_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF1_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf1_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF1_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF1_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF1_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf1_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF1_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF1_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF1_VFID_SIZE;
     } mp2_smnif_tlb_vf1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf1_t f;
} mp2_smnif_tlb_vf1_u;


/*
 * MP2_SMNIF_TLB_VF2 struct
 */

#define MP2_SMNIF_TLB_VF2_REG_SIZE     32
#define MP2_SMNIF_TLB_VF2_VFID_SIZE    6
#define MP2_SMNIF_TLB_VF2_VF_SIZE      1
#define MP2_SMNIF_TLB_VF2_VALID_SIZE   1

#define MP2_SMNIF_TLB_VF2_VFID_SHIFT   0
#define MP2_SMNIF_TLB_VF2_VF_SHIFT     6
#define MP2_SMNIF_TLB_VF2_VALID_SHIFT  7

#define MP2_SMNIF_TLB_VF2_VFID_MASK    0x3f
#define MP2_SMNIF_TLB_VF2_VF_MASK      0x40
#define MP2_SMNIF_TLB_VF2_VALID_MASK   0x80

#define MP2_SMNIF_TLB_VF2_MASK \
     (MP2_SMNIF_TLB_VF2_VFID_MASK | \
      MP2_SMNIF_TLB_VF2_VF_MASK | \
      MP2_SMNIF_TLB_VF2_VALID_MASK)

#define MP2_SMNIF_TLB_VF2_DEFAULT      0x00000000

#define MP2_SMNIF_TLB_VF2_GET_VFID(mp2_smnif_tlb_vf2) \
     ((mp2_smnif_tlb_vf2 & MP2_SMNIF_TLB_VF2_VFID_MASK) >> MP2_SMNIF_TLB_VF2_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF2_GET_VF(mp2_smnif_tlb_vf2) \
     ((mp2_smnif_tlb_vf2 & MP2_SMNIF_TLB_VF2_VF_MASK) >> MP2_SMNIF_TLB_VF2_VF_SHIFT)
#define MP2_SMNIF_TLB_VF2_GET_VALID(mp2_smnif_tlb_vf2) \
     ((mp2_smnif_tlb_vf2 & MP2_SMNIF_TLB_VF2_VALID_MASK) >> MP2_SMNIF_TLB_VF2_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF2_SET_VFID(mp2_smnif_tlb_vf2_reg, vfid) \
     mp2_smnif_tlb_vf2_reg = (mp2_smnif_tlb_vf2_reg & ~MP2_SMNIF_TLB_VF2_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF2_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF2_SET_VF(mp2_smnif_tlb_vf2_reg, vf) \
     mp2_smnif_tlb_vf2_reg = (mp2_smnif_tlb_vf2_reg & ~MP2_SMNIF_TLB_VF2_VF_MASK) | (vf << MP2_SMNIF_TLB_VF2_VF_SHIFT)
#define MP2_SMNIF_TLB_VF2_SET_VALID(mp2_smnif_tlb_vf2_reg, valid) \
     mp2_smnif_tlb_vf2_reg = (mp2_smnif_tlb_vf2_reg & ~MP2_SMNIF_TLB_VF2_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF2_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf2_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF2_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF2_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF2_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf2_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF2_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF2_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF2_VFID_SIZE;
     } mp2_smnif_tlb_vf2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf2_t f;
} mp2_smnif_tlb_vf2_u;


/*
 * MP2_SMNIF_TLB_VF3 struct
 */

#define MP2_SMNIF_TLB_VF3_REG_SIZE     32
#define MP2_SMNIF_TLB_VF3_VFID_SIZE    6
#define MP2_SMNIF_TLB_VF3_VF_SIZE      1
#define MP2_SMNIF_TLB_VF3_VALID_SIZE   1

#define MP2_SMNIF_TLB_VF3_VFID_SHIFT   0
#define MP2_SMNIF_TLB_VF3_VF_SHIFT     6
#define MP2_SMNIF_TLB_VF3_VALID_SHIFT  7

#define MP2_SMNIF_TLB_VF3_VFID_MASK    0x3f
#define MP2_SMNIF_TLB_VF3_VF_MASK      0x40
#define MP2_SMNIF_TLB_VF3_VALID_MASK   0x80

#define MP2_SMNIF_TLB_VF3_MASK \
     (MP2_SMNIF_TLB_VF3_VFID_MASK | \
      MP2_SMNIF_TLB_VF3_VF_MASK | \
      MP2_SMNIF_TLB_VF3_VALID_MASK)

#define MP2_SMNIF_TLB_VF3_DEFAULT      0x00000000

#define MP2_SMNIF_TLB_VF3_GET_VFID(mp2_smnif_tlb_vf3) \
     ((mp2_smnif_tlb_vf3 & MP2_SMNIF_TLB_VF3_VFID_MASK) >> MP2_SMNIF_TLB_VF3_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF3_GET_VF(mp2_smnif_tlb_vf3) \
     ((mp2_smnif_tlb_vf3 & MP2_SMNIF_TLB_VF3_VF_MASK) >> MP2_SMNIF_TLB_VF3_VF_SHIFT)
#define MP2_SMNIF_TLB_VF3_GET_VALID(mp2_smnif_tlb_vf3) \
     ((mp2_smnif_tlb_vf3 & MP2_SMNIF_TLB_VF3_VALID_MASK) >> MP2_SMNIF_TLB_VF3_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF3_SET_VFID(mp2_smnif_tlb_vf3_reg, vfid) \
     mp2_smnif_tlb_vf3_reg = (mp2_smnif_tlb_vf3_reg & ~MP2_SMNIF_TLB_VF3_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF3_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF3_SET_VF(mp2_smnif_tlb_vf3_reg, vf) \
     mp2_smnif_tlb_vf3_reg = (mp2_smnif_tlb_vf3_reg & ~MP2_SMNIF_TLB_VF3_VF_MASK) | (vf << MP2_SMNIF_TLB_VF3_VF_SHIFT)
#define MP2_SMNIF_TLB_VF3_SET_VALID(mp2_smnif_tlb_vf3_reg, valid) \
     mp2_smnif_tlb_vf3_reg = (mp2_smnif_tlb_vf3_reg & ~MP2_SMNIF_TLB_VF3_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF3_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf3_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF3_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF3_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF3_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf3_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF3_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF3_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF3_VFID_SIZE;
     } mp2_smnif_tlb_vf3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf3_t f;
} mp2_smnif_tlb_vf3_u;


/*
 * MP2_SMNIF_TLB_VF4 struct
 */

#define MP2_SMNIF_TLB_VF4_REG_SIZE     32
#define MP2_SMNIF_TLB_VF4_VFID_SIZE    6
#define MP2_SMNIF_TLB_VF4_VF_SIZE      1
#define MP2_SMNIF_TLB_VF4_VALID_SIZE   1

#define MP2_SMNIF_TLB_VF4_VFID_SHIFT   0
#define MP2_SMNIF_TLB_VF4_VF_SHIFT     6
#define MP2_SMNIF_TLB_VF4_VALID_SHIFT  7

#define MP2_SMNIF_TLB_VF4_VFID_MASK    0x3f
#define MP2_SMNIF_TLB_VF4_VF_MASK      0x40
#define MP2_SMNIF_TLB_VF4_VALID_MASK   0x80

#define MP2_SMNIF_TLB_VF4_MASK \
     (MP2_SMNIF_TLB_VF4_VFID_MASK | \
      MP2_SMNIF_TLB_VF4_VF_MASK | \
      MP2_SMNIF_TLB_VF4_VALID_MASK)

#define MP2_SMNIF_TLB_VF4_DEFAULT      0x00000000

#define MP2_SMNIF_TLB_VF4_GET_VFID(mp2_smnif_tlb_vf4) \
     ((mp2_smnif_tlb_vf4 & MP2_SMNIF_TLB_VF4_VFID_MASK) >> MP2_SMNIF_TLB_VF4_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF4_GET_VF(mp2_smnif_tlb_vf4) \
     ((mp2_smnif_tlb_vf4 & MP2_SMNIF_TLB_VF4_VF_MASK) >> MP2_SMNIF_TLB_VF4_VF_SHIFT)
#define MP2_SMNIF_TLB_VF4_GET_VALID(mp2_smnif_tlb_vf4) \
     ((mp2_smnif_tlb_vf4 & MP2_SMNIF_TLB_VF4_VALID_MASK) >> MP2_SMNIF_TLB_VF4_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF4_SET_VFID(mp2_smnif_tlb_vf4_reg, vfid) \
     mp2_smnif_tlb_vf4_reg = (mp2_smnif_tlb_vf4_reg & ~MP2_SMNIF_TLB_VF4_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF4_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF4_SET_VF(mp2_smnif_tlb_vf4_reg, vf) \
     mp2_smnif_tlb_vf4_reg = (mp2_smnif_tlb_vf4_reg & ~MP2_SMNIF_TLB_VF4_VF_MASK) | (vf << MP2_SMNIF_TLB_VF4_VF_SHIFT)
#define MP2_SMNIF_TLB_VF4_SET_VALID(mp2_smnif_tlb_vf4_reg, valid) \
     mp2_smnif_tlb_vf4_reg = (mp2_smnif_tlb_vf4_reg & ~MP2_SMNIF_TLB_VF4_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF4_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf4_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF4_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF4_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF4_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf4_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf4_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF4_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF4_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF4_VFID_SIZE;
     } mp2_smnif_tlb_vf4_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf4_t f;
} mp2_smnif_tlb_vf4_u;


/*
 * MP2_SMNIF_TLB_VF5 struct
 */

#define MP2_SMNIF_TLB_VF5_REG_SIZE     32
#define MP2_SMNIF_TLB_VF5_VFID_SIZE    6
#define MP2_SMNIF_TLB_VF5_VF_SIZE      1
#define MP2_SMNIF_TLB_VF5_VALID_SIZE   1

#define MP2_SMNIF_TLB_VF5_VFID_SHIFT   0
#define MP2_SMNIF_TLB_VF5_VF_SHIFT     6
#define MP2_SMNIF_TLB_VF5_VALID_SHIFT  7

#define MP2_SMNIF_TLB_VF5_VFID_MASK    0x3f
#define MP2_SMNIF_TLB_VF5_VF_MASK      0x40
#define MP2_SMNIF_TLB_VF5_VALID_MASK   0x80

#define MP2_SMNIF_TLB_VF5_MASK \
     (MP2_SMNIF_TLB_VF5_VFID_MASK | \
      MP2_SMNIF_TLB_VF5_VF_MASK | \
      MP2_SMNIF_TLB_VF5_VALID_MASK)

#define MP2_SMNIF_TLB_VF5_DEFAULT      0x00000000

#define MP2_SMNIF_TLB_VF5_GET_VFID(mp2_smnif_tlb_vf5) \
     ((mp2_smnif_tlb_vf5 & MP2_SMNIF_TLB_VF5_VFID_MASK) >> MP2_SMNIF_TLB_VF5_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF5_GET_VF(mp2_smnif_tlb_vf5) \
     ((mp2_smnif_tlb_vf5 & MP2_SMNIF_TLB_VF5_VF_MASK) >> MP2_SMNIF_TLB_VF5_VF_SHIFT)
#define MP2_SMNIF_TLB_VF5_GET_VALID(mp2_smnif_tlb_vf5) \
     ((mp2_smnif_tlb_vf5 & MP2_SMNIF_TLB_VF5_VALID_MASK) >> MP2_SMNIF_TLB_VF5_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF5_SET_VFID(mp2_smnif_tlb_vf5_reg, vfid) \
     mp2_smnif_tlb_vf5_reg = (mp2_smnif_tlb_vf5_reg & ~MP2_SMNIF_TLB_VF5_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF5_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF5_SET_VF(mp2_smnif_tlb_vf5_reg, vf) \
     mp2_smnif_tlb_vf5_reg = (mp2_smnif_tlb_vf5_reg & ~MP2_SMNIF_TLB_VF5_VF_MASK) | (vf << MP2_SMNIF_TLB_VF5_VF_SHIFT)
#define MP2_SMNIF_TLB_VF5_SET_VALID(mp2_smnif_tlb_vf5_reg, valid) \
     mp2_smnif_tlb_vf5_reg = (mp2_smnif_tlb_vf5_reg & ~MP2_SMNIF_TLB_VF5_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF5_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf5_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF5_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF5_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF5_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf5_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf5_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF5_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF5_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF5_VFID_SIZE;
     } mp2_smnif_tlb_vf5_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf5_t f;
} mp2_smnif_tlb_vf5_u;


/*
 * MP2_SMNIF_TLB_VF6 struct
 */

#define MP2_SMNIF_TLB_VF6_REG_SIZE     32
#define MP2_SMNIF_TLB_VF6_VFID_SIZE    6
#define MP2_SMNIF_TLB_VF6_VF_SIZE      1
#define MP2_SMNIF_TLB_VF6_VALID_SIZE   1

#define MP2_SMNIF_TLB_VF6_VFID_SHIFT   0
#define MP2_SMNIF_TLB_VF6_VF_SHIFT     6
#define MP2_SMNIF_TLB_VF6_VALID_SHIFT  7

#define MP2_SMNIF_TLB_VF6_VFID_MASK    0x3f
#define MP2_SMNIF_TLB_VF6_VF_MASK      0x40
#define MP2_SMNIF_TLB_VF6_VALID_MASK   0x80

#define MP2_SMNIF_TLB_VF6_MASK \
     (MP2_SMNIF_TLB_VF6_VFID_MASK | \
      MP2_SMNIF_TLB_VF6_VF_MASK | \
      MP2_SMNIF_TLB_VF6_VALID_MASK)

#define MP2_SMNIF_TLB_VF6_DEFAULT      0x00000000

#define MP2_SMNIF_TLB_VF6_GET_VFID(mp2_smnif_tlb_vf6) \
     ((mp2_smnif_tlb_vf6 & MP2_SMNIF_TLB_VF6_VFID_MASK) >> MP2_SMNIF_TLB_VF6_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF6_GET_VF(mp2_smnif_tlb_vf6) \
     ((mp2_smnif_tlb_vf6 & MP2_SMNIF_TLB_VF6_VF_MASK) >> MP2_SMNIF_TLB_VF6_VF_SHIFT)
#define MP2_SMNIF_TLB_VF6_GET_VALID(mp2_smnif_tlb_vf6) \
     ((mp2_smnif_tlb_vf6 & MP2_SMNIF_TLB_VF6_VALID_MASK) >> MP2_SMNIF_TLB_VF6_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF6_SET_VFID(mp2_smnif_tlb_vf6_reg, vfid) \
     mp2_smnif_tlb_vf6_reg = (mp2_smnif_tlb_vf6_reg & ~MP2_SMNIF_TLB_VF6_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF6_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF6_SET_VF(mp2_smnif_tlb_vf6_reg, vf) \
     mp2_smnif_tlb_vf6_reg = (mp2_smnif_tlb_vf6_reg & ~MP2_SMNIF_TLB_VF6_VF_MASK) | (vf << MP2_SMNIF_TLB_VF6_VF_SHIFT)
#define MP2_SMNIF_TLB_VF6_SET_VALID(mp2_smnif_tlb_vf6_reg, valid) \
     mp2_smnif_tlb_vf6_reg = (mp2_smnif_tlb_vf6_reg & ~MP2_SMNIF_TLB_VF6_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF6_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf6_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF6_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF6_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF6_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf6_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf6_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF6_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF6_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF6_VFID_SIZE;
     } mp2_smnif_tlb_vf6_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf6_t f;
} mp2_smnif_tlb_vf6_u;


/*
 * MP2_SMNIF_TLB_VF7 struct
 */

#define MP2_SMNIF_TLB_VF7_REG_SIZE     32
#define MP2_SMNIF_TLB_VF7_VFID_SIZE    6
#define MP2_SMNIF_TLB_VF7_VF_SIZE      1
#define MP2_SMNIF_TLB_VF7_VALID_SIZE   1

#define MP2_SMNIF_TLB_VF7_VFID_SHIFT   0
#define MP2_SMNIF_TLB_VF7_VF_SHIFT     6
#define MP2_SMNIF_TLB_VF7_VALID_SHIFT  7

#define MP2_SMNIF_TLB_VF7_VFID_MASK    0x3f
#define MP2_SMNIF_TLB_VF7_VF_MASK      0x40
#define MP2_SMNIF_TLB_VF7_VALID_MASK   0x80

#define MP2_SMNIF_TLB_VF7_MASK \
     (MP2_SMNIF_TLB_VF7_VFID_MASK | \
      MP2_SMNIF_TLB_VF7_VF_MASK | \
      MP2_SMNIF_TLB_VF7_VALID_MASK)

#define MP2_SMNIF_TLB_VF7_DEFAULT      0x00000000

#define MP2_SMNIF_TLB_VF7_GET_VFID(mp2_smnif_tlb_vf7) \
     ((mp2_smnif_tlb_vf7 & MP2_SMNIF_TLB_VF7_VFID_MASK) >> MP2_SMNIF_TLB_VF7_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF7_GET_VF(mp2_smnif_tlb_vf7) \
     ((mp2_smnif_tlb_vf7 & MP2_SMNIF_TLB_VF7_VF_MASK) >> MP2_SMNIF_TLB_VF7_VF_SHIFT)
#define MP2_SMNIF_TLB_VF7_GET_VALID(mp2_smnif_tlb_vf7) \
     ((mp2_smnif_tlb_vf7 & MP2_SMNIF_TLB_VF7_VALID_MASK) >> MP2_SMNIF_TLB_VF7_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF7_SET_VFID(mp2_smnif_tlb_vf7_reg, vfid) \
     mp2_smnif_tlb_vf7_reg = (mp2_smnif_tlb_vf7_reg & ~MP2_SMNIF_TLB_VF7_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF7_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF7_SET_VF(mp2_smnif_tlb_vf7_reg, vf) \
     mp2_smnif_tlb_vf7_reg = (mp2_smnif_tlb_vf7_reg & ~MP2_SMNIF_TLB_VF7_VF_MASK) | (vf << MP2_SMNIF_TLB_VF7_VF_SHIFT)
#define MP2_SMNIF_TLB_VF7_SET_VALID(mp2_smnif_tlb_vf7_reg, valid) \
     mp2_smnif_tlb_vf7_reg = (mp2_smnif_tlb_vf7_reg & ~MP2_SMNIF_TLB_VF7_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF7_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf7_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF7_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF7_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF7_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf7_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf7_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF7_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF7_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF7_VFID_SIZE;
     } mp2_smnif_tlb_vf7_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf7_t f;
} mp2_smnif_tlb_vf7_u;


/*
 * MP2_SMNIF_TLB_VF8 struct
 */

#define MP2_SMNIF_TLB_VF8_REG_SIZE     32
#define MP2_SMNIF_TLB_VF8_VFID_SIZE    6
#define MP2_SMNIF_TLB_VF8_VF_SIZE      1
#define MP2_SMNIF_TLB_VF8_VALID_SIZE   1

#define MP2_SMNIF_TLB_VF8_VFID_SHIFT   0
#define MP2_SMNIF_TLB_VF8_VF_SHIFT     6
#define MP2_SMNIF_TLB_VF8_VALID_SHIFT  7

#define MP2_SMNIF_TLB_VF8_VFID_MASK    0x3f
#define MP2_SMNIF_TLB_VF8_VF_MASK      0x40
#define MP2_SMNIF_TLB_VF8_VALID_MASK   0x80

#define MP2_SMNIF_TLB_VF8_MASK \
     (MP2_SMNIF_TLB_VF8_VFID_MASK | \
      MP2_SMNIF_TLB_VF8_VF_MASK | \
      MP2_SMNIF_TLB_VF8_VALID_MASK)

#define MP2_SMNIF_TLB_VF8_DEFAULT      0x00000000

#define MP2_SMNIF_TLB_VF8_GET_VFID(mp2_smnif_tlb_vf8) \
     ((mp2_smnif_tlb_vf8 & MP2_SMNIF_TLB_VF8_VFID_MASK) >> MP2_SMNIF_TLB_VF8_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF8_GET_VF(mp2_smnif_tlb_vf8) \
     ((mp2_smnif_tlb_vf8 & MP2_SMNIF_TLB_VF8_VF_MASK) >> MP2_SMNIF_TLB_VF8_VF_SHIFT)
#define MP2_SMNIF_TLB_VF8_GET_VALID(mp2_smnif_tlb_vf8) \
     ((mp2_smnif_tlb_vf8 & MP2_SMNIF_TLB_VF8_VALID_MASK) >> MP2_SMNIF_TLB_VF8_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF8_SET_VFID(mp2_smnif_tlb_vf8_reg, vfid) \
     mp2_smnif_tlb_vf8_reg = (mp2_smnif_tlb_vf8_reg & ~MP2_SMNIF_TLB_VF8_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF8_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF8_SET_VF(mp2_smnif_tlb_vf8_reg, vf) \
     mp2_smnif_tlb_vf8_reg = (mp2_smnif_tlb_vf8_reg & ~MP2_SMNIF_TLB_VF8_VF_MASK) | (vf << MP2_SMNIF_TLB_VF8_VF_SHIFT)
#define MP2_SMNIF_TLB_VF8_SET_VALID(mp2_smnif_tlb_vf8_reg, valid) \
     mp2_smnif_tlb_vf8_reg = (mp2_smnif_tlb_vf8_reg & ~MP2_SMNIF_TLB_VF8_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF8_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf8_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF8_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF8_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF8_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf8_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf8_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF8_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF8_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF8_VFID_SIZE;
     } mp2_smnif_tlb_vf8_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf8_t f;
} mp2_smnif_tlb_vf8_u;


/*
 * MP2_SMNIF_TLB_VF9 struct
 */

#define MP2_SMNIF_TLB_VF9_REG_SIZE     32
#define MP2_SMNIF_TLB_VF9_VFID_SIZE    6
#define MP2_SMNIF_TLB_VF9_VF_SIZE      1
#define MP2_SMNIF_TLB_VF9_VALID_SIZE   1

#define MP2_SMNIF_TLB_VF9_VFID_SHIFT   0
#define MP2_SMNIF_TLB_VF9_VF_SHIFT     6
#define MP2_SMNIF_TLB_VF9_VALID_SHIFT  7

#define MP2_SMNIF_TLB_VF9_VFID_MASK    0x3f
#define MP2_SMNIF_TLB_VF9_VF_MASK      0x40
#define MP2_SMNIF_TLB_VF9_VALID_MASK   0x80

#define MP2_SMNIF_TLB_VF9_MASK \
     (MP2_SMNIF_TLB_VF9_VFID_MASK | \
      MP2_SMNIF_TLB_VF9_VF_MASK | \
      MP2_SMNIF_TLB_VF9_VALID_MASK)

#define MP2_SMNIF_TLB_VF9_DEFAULT      0x00000000

#define MP2_SMNIF_TLB_VF9_GET_VFID(mp2_smnif_tlb_vf9) \
     ((mp2_smnif_tlb_vf9 & MP2_SMNIF_TLB_VF9_VFID_MASK) >> MP2_SMNIF_TLB_VF9_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF9_GET_VF(mp2_smnif_tlb_vf9) \
     ((mp2_smnif_tlb_vf9 & MP2_SMNIF_TLB_VF9_VF_MASK) >> MP2_SMNIF_TLB_VF9_VF_SHIFT)
#define MP2_SMNIF_TLB_VF9_GET_VALID(mp2_smnif_tlb_vf9) \
     ((mp2_smnif_tlb_vf9 & MP2_SMNIF_TLB_VF9_VALID_MASK) >> MP2_SMNIF_TLB_VF9_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF9_SET_VFID(mp2_smnif_tlb_vf9_reg, vfid) \
     mp2_smnif_tlb_vf9_reg = (mp2_smnif_tlb_vf9_reg & ~MP2_SMNIF_TLB_VF9_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF9_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF9_SET_VF(mp2_smnif_tlb_vf9_reg, vf) \
     mp2_smnif_tlb_vf9_reg = (mp2_smnif_tlb_vf9_reg & ~MP2_SMNIF_TLB_VF9_VF_MASK) | (vf << MP2_SMNIF_TLB_VF9_VF_SHIFT)
#define MP2_SMNIF_TLB_VF9_SET_VALID(mp2_smnif_tlb_vf9_reg, valid) \
     mp2_smnif_tlb_vf9_reg = (mp2_smnif_tlb_vf9_reg & ~MP2_SMNIF_TLB_VF9_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF9_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf9_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF9_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF9_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF9_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf9_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf9_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF9_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF9_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF9_VFID_SIZE;
     } mp2_smnif_tlb_vf9_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf9_t f;
} mp2_smnif_tlb_vf9_u;


/*
 * MP2_SMNIF_TLB_VF10 struct
 */

#define MP2_SMNIF_TLB_VF10_REG_SIZE    32
#define MP2_SMNIF_TLB_VF10_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF10_VF_SIZE     1
#define MP2_SMNIF_TLB_VF10_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF10_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF10_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF10_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF10_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF10_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF10_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF10_MASK \
     (MP2_SMNIF_TLB_VF10_VFID_MASK | \
      MP2_SMNIF_TLB_VF10_VF_MASK | \
      MP2_SMNIF_TLB_VF10_VALID_MASK)

#define MP2_SMNIF_TLB_VF10_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF10_GET_VFID(mp2_smnif_tlb_vf10) \
     ((mp2_smnif_tlb_vf10 & MP2_SMNIF_TLB_VF10_VFID_MASK) >> MP2_SMNIF_TLB_VF10_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF10_GET_VF(mp2_smnif_tlb_vf10) \
     ((mp2_smnif_tlb_vf10 & MP2_SMNIF_TLB_VF10_VF_MASK) >> MP2_SMNIF_TLB_VF10_VF_SHIFT)
#define MP2_SMNIF_TLB_VF10_GET_VALID(mp2_smnif_tlb_vf10) \
     ((mp2_smnif_tlb_vf10 & MP2_SMNIF_TLB_VF10_VALID_MASK) >> MP2_SMNIF_TLB_VF10_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF10_SET_VFID(mp2_smnif_tlb_vf10_reg, vfid) \
     mp2_smnif_tlb_vf10_reg = (mp2_smnif_tlb_vf10_reg & ~MP2_SMNIF_TLB_VF10_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF10_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF10_SET_VF(mp2_smnif_tlb_vf10_reg, vf) \
     mp2_smnif_tlb_vf10_reg = (mp2_smnif_tlb_vf10_reg & ~MP2_SMNIF_TLB_VF10_VF_MASK) | (vf << MP2_SMNIF_TLB_VF10_VF_SHIFT)
#define MP2_SMNIF_TLB_VF10_SET_VALID(mp2_smnif_tlb_vf10_reg, valid) \
     mp2_smnif_tlb_vf10_reg = (mp2_smnif_tlb_vf10_reg & ~MP2_SMNIF_TLB_VF10_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF10_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf10_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF10_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF10_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF10_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf10_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf10_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF10_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF10_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF10_VFID_SIZE;
     } mp2_smnif_tlb_vf10_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf10_t f;
} mp2_smnif_tlb_vf10_u;


/*
 * MP2_SMNIF_TLB_VF11 struct
 */

#define MP2_SMNIF_TLB_VF11_REG_SIZE    32
#define MP2_SMNIF_TLB_VF11_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF11_VF_SIZE     1
#define MP2_SMNIF_TLB_VF11_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF11_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF11_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF11_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF11_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF11_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF11_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF11_MASK \
     (MP2_SMNIF_TLB_VF11_VFID_MASK | \
      MP2_SMNIF_TLB_VF11_VF_MASK | \
      MP2_SMNIF_TLB_VF11_VALID_MASK)

#define MP2_SMNIF_TLB_VF11_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF11_GET_VFID(mp2_smnif_tlb_vf11) \
     ((mp2_smnif_tlb_vf11 & MP2_SMNIF_TLB_VF11_VFID_MASK) >> MP2_SMNIF_TLB_VF11_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF11_GET_VF(mp2_smnif_tlb_vf11) \
     ((mp2_smnif_tlb_vf11 & MP2_SMNIF_TLB_VF11_VF_MASK) >> MP2_SMNIF_TLB_VF11_VF_SHIFT)
#define MP2_SMNIF_TLB_VF11_GET_VALID(mp2_smnif_tlb_vf11) \
     ((mp2_smnif_tlb_vf11 & MP2_SMNIF_TLB_VF11_VALID_MASK) >> MP2_SMNIF_TLB_VF11_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF11_SET_VFID(mp2_smnif_tlb_vf11_reg, vfid) \
     mp2_smnif_tlb_vf11_reg = (mp2_smnif_tlb_vf11_reg & ~MP2_SMNIF_TLB_VF11_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF11_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF11_SET_VF(mp2_smnif_tlb_vf11_reg, vf) \
     mp2_smnif_tlb_vf11_reg = (mp2_smnif_tlb_vf11_reg & ~MP2_SMNIF_TLB_VF11_VF_MASK) | (vf << MP2_SMNIF_TLB_VF11_VF_SHIFT)
#define MP2_SMNIF_TLB_VF11_SET_VALID(mp2_smnif_tlb_vf11_reg, valid) \
     mp2_smnif_tlb_vf11_reg = (mp2_smnif_tlb_vf11_reg & ~MP2_SMNIF_TLB_VF11_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF11_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf11_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF11_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF11_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF11_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf11_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf11_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF11_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF11_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF11_VFID_SIZE;
     } mp2_smnif_tlb_vf11_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf11_t f;
} mp2_smnif_tlb_vf11_u;


/*
 * MP2_SMNIF_TLB_VF12 struct
 */

#define MP2_SMNIF_TLB_VF12_REG_SIZE    32
#define MP2_SMNIF_TLB_VF12_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF12_VF_SIZE     1
#define MP2_SMNIF_TLB_VF12_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF12_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF12_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF12_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF12_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF12_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF12_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF12_MASK \
     (MP2_SMNIF_TLB_VF12_VFID_MASK | \
      MP2_SMNIF_TLB_VF12_VF_MASK | \
      MP2_SMNIF_TLB_VF12_VALID_MASK)

#define MP2_SMNIF_TLB_VF12_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF12_GET_VFID(mp2_smnif_tlb_vf12) \
     ((mp2_smnif_tlb_vf12 & MP2_SMNIF_TLB_VF12_VFID_MASK) >> MP2_SMNIF_TLB_VF12_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF12_GET_VF(mp2_smnif_tlb_vf12) \
     ((mp2_smnif_tlb_vf12 & MP2_SMNIF_TLB_VF12_VF_MASK) >> MP2_SMNIF_TLB_VF12_VF_SHIFT)
#define MP2_SMNIF_TLB_VF12_GET_VALID(mp2_smnif_tlb_vf12) \
     ((mp2_smnif_tlb_vf12 & MP2_SMNIF_TLB_VF12_VALID_MASK) >> MP2_SMNIF_TLB_VF12_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF12_SET_VFID(mp2_smnif_tlb_vf12_reg, vfid) \
     mp2_smnif_tlb_vf12_reg = (mp2_smnif_tlb_vf12_reg & ~MP2_SMNIF_TLB_VF12_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF12_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF12_SET_VF(mp2_smnif_tlb_vf12_reg, vf) \
     mp2_smnif_tlb_vf12_reg = (mp2_smnif_tlb_vf12_reg & ~MP2_SMNIF_TLB_VF12_VF_MASK) | (vf << MP2_SMNIF_TLB_VF12_VF_SHIFT)
#define MP2_SMNIF_TLB_VF12_SET_VALID(mp2_smnif_tlb_vf12_reg, valid) \
     mp2_smnif_tlb_vf12_reg = (mp2_smnif_tlb_vf12_reg & ~MP2_SMNIF_TLB_VF12_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF12_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf12_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF12_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF12_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF12_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf12_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf12_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF12_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF12_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF12_VFID_SIZE;
     } mp2_smnif_tlb_vf12_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf12_t f;
} mp2_smnif_tlb_vf12_u;


/*
 * MP2_SMNIF_TLB_VF13 struct
 */

#define MP2_SMNIF_TLB_VF13_REG_SIZE    32
#define MP2_SMNIF_TLB_VF13_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF13_VF_SIZE     1
#define MP2_SMNIF_TLB_VF13_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF13_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF13_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF13_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF13_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF13_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF13_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF13_MASK \
     (MP2_SMNIF_TLB_VF13_VFID_MASK | \
      MP2_SMNIF_TLB_VF13_VF_MASK | \
      MP2_SMNIF_TLB_VF13_VALID_MASK)

#define MP2_SMNIF_TLB_VF13_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF13_GET_VFID(mp2_smnif_tlb_vf13) \
     ((mp2_smnif_tlb_vf13 & MP2_SMNIF_TLB_VF13_VFID_MASK) >> MP2_SMNIF_TLB_VF13_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF13_GET_VF(mp2_smnif_tlb_vf13) \
     ((mp2_smnif_tlb_vf13 & MP2_SMNIF_TLB_VF13_VF_MASK) >> MP2_SMNIF_TLB_VF13_VF_SHIFT)
#define MP2_SMNIF_TLB_VF13_GET_VALID(mp2_smnif_tlb_vf13) \
     ((mp2_smnif_tlb_vf13 & MP2_SMNIF_TLB_VF13_VALID_MASK) >> MP2_SMNIF_TLB_VF13_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF13_SET_VFID(mp2_smnif_tlb_vf13_reg, vfid) \
     mp2_smnif_tlb_vf13_reg = (mp2_smnif_tlb_vf13_reg & ~MP2_SMNIF_TLB_VF13_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF13_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF13_SET_VF(mp2_smnif_tlb_vf13_reg, vf) \
     mp2_smnif_tlb_vf13_reg = (mp2_smnif_tlb_vf13_reg & ~MP2_SMNIF_TLB_VF13_VF_MASK) | (vf << MP2_SMNIF_TLB_VF13_VF_SHIFT)
#define MP2_SMNIF_TLB_VF13_SET_VALID(mp2_smnif_tlb_vf13_reg, valid) \
     mp2_smnif_tlb_vf13_reg = (mp2_smnif_tlb_vf13_reg & ~MP2_SMNIF_TLB_VF13_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF13_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf13_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF13_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF13_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF13_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf13_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf13_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF13_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF13_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF13_VFID_SIZE;
     } mp2_smnif_tlb_vf13_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf13_t f;
} mp2_smnif_tlb_vf13_u;


/*
 * MP2_SMNIF_TLB_VF14 struct
 */

#define MP2_SMNIF_TLB_VF14_REG_SIZE    32
#define MP2_SMNIF_TLB_VF14_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF14_VF_SIZE     1
#define MP2_SMNIF_TLB_VF14_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF14_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF14_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF14_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF14_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF14_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF14_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF14_MASK \
     (MP2_SMNIF_TLB_VF14_VFID_MASK | \
      MP2_SMNIF_TLB_VF14_VF_MASK | \
      MP2_SMNIF_TLB_VF14_VALID_MASK)

#define MP2_SMNIF_TLB_VF14_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF14_GET_VFID(mp2_smnif_tlb_vf14) \
     ((mp2_smnif_tlb_vf14 & MP2_SMNIF_TLB_VF14_VFID_MASK) >> MP2_SMNIF_TLB_VF14_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF14_GET_VF(mp2_smnif_tlb_vf14) \
     ((mp2_smnif_tlb_vf14 & MP2_SMNIF_TLB_VF14_VF_MASK) >> MP2_SMNIF_TLB_VF14_VF_SHIFT)
#define MP2_SMNIF_TLB_VF14_GET_VALID(mp2_smnif_tlb_vf14) \
     ((mp2_smnif_tlb_vf14 & MP2_SMNIF_TLB_VF14_VALID_MASK) >> MP2_SMNIF_TLB_VF14_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF14_SET_VFID(mp2_smnif_tlb_vf14_reg, vfid) \
     mp2_smnif_tlb_vf14_reg = (mp2_smnif_tlb_vf14_reg & ~MP2_SMNIF_TLB_VF14_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF14_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF14_SET_VF(mp2_smnif_tlb_vf14_reg, vf) \
     mp2_smnif_tlb_vf14_reg = (mp2_smnif_tlb_vf14_reg & ~MP2_SMNIF_TLB_VF14_VF_MASK) | (vf << MP2_SMNIF_TLB_VF14_VF_SHIFT)
#define MP2_SMNIF_TLB_VF14_SET_VALID(mp2_smnif_tlb_vf14_reg, valid) \
     mp2_smnif_tlb_vf14_reg = (mp2_smnif_tlb_vf14_reg & ~MP2_SMNIF_TLB_VF14_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF14_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf14_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF14_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF14_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF14_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf14_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf14_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF14_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF14_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF14_VFID_SIZE;
     } mp2_smnif_tlb_vf14_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf14_t f;
} mp2_smnif_tlb_vf14_u;


/*
 * MP2_SMNIF_TLB_VF15 struct
 */

#define MP2_SMNIF_TLB_VF15_REG_SIZE    32
#define MP2_SMNIF_TLB_VF15_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF15_VF_SIZE     1
#define MP2_SMNIF_TLB_VF15_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF15_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF15_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF15_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF15_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF15_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF15_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF15_MASK \
     (MP2_SMNIF_TLB_VF15_VFID_MASK | \
      MP2_SMNIF_TLB_VF15_VF_MASK | \
      MP2_SMNIF_TLB_VF15_VALID_MASK)

#define MP2_SMNIF_TLB_VF15_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF15_GET_VFID(mp2_smnif_tlb_vf15) \
     ((mp2_smnif_tlb_vf15 & MP2_SMNIF_TLB_VF15_VFID_MASK) >> MP2_SMNIF_TLB_VF15_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF15_GET_VF(mp2_smnif_tlb_vf15) \
     ((mp2_smnif_tlb_vf15 & MP2_SMNIF_TLB_VF15_VF_MASK) >> MP2_SMNIF_TLB_VF15_VF_SHIFT)
#define MP2_SMNIF_TLB_VF15_GET_VALID(mp2_smnif_tlb_vf15) \
     ((mp2_smnif_tlb_vf15 & MP2_SMNIF_TLB_VF15_VALID_MASK) >> MP2_SMNIF_TLB_VF15_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF15_SET_VFID(mp2_smnif_tlb_vf15_reg, vfid) \
     mp2_smnif_tlb_vf15_reg = (mp2_smnif_tlb_vf15_reg & ~MP2_SMNIF_TLB_VF15_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF15_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF15_SET_VF(mp2_smnif_tlb_vf15_reg, vf) \
     mp2_smnif_tlb_vf15_reg = (mp2_smnif_tlb_vf15_reg & ~MP2_SMNIF_TLB_VF15_VF_MASK) | (vf << MP2_SMNIF_TLB_VF15_VF_SHIFT)
#define MP2_SMNIF_TLB_VF15_SET_VALID(mp2_smnif_tlb_vf15_reg, valid) \
     mp2_smnif_tlb_vf15_reg = (mp2_smnif_tlb_vf15_reg & ~MP2_SMNIF_TLB_VF15_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF15_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf15_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF15_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF15_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF15_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf15_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf15_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF15_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF15_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF15_VFID_SIZE;
     } mp2_smnif_tlb_vf15_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf15_t f;
} mp2_smnif_tlb_vf15_u;


/*
 * MP2_SMNIF_TLB_VF16 struct
 */

#define MP2_SMNIF_TLB_VF16_REG_SIZE    32
#define MP2_SMNIF_TLB_VF16_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF16_VF_SIZE     1
#define MP2_SMNIF_TLB_VF16_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF16_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF16_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF16_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF16_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF16_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF16_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF16_MASK \
     (MP2_SMNIF_TLB_VF16_VFID_MASK | \
      MP2_SMNIF_TLB_VF16_VF_MASK | \
      MP2_SMNIF_TLB_VF16_VALID_MASK)

#define MP2_SMNIF_TLB_VF16_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF16_GET_VFID(mp2_smnif_tlb_vf16) \
     ((mp2_smnif_tlb_vf16 & MP2_SMNIF_TLB_VF16_VFID_MASK) >> MP2_SMNIF_TLB_VF16_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF16_GET_VF(mp2_smnif_tlb_vf16) \
     ((mp2_smnif_tlb_vf16 & MP2_SMNIF_TLB_VF16_VF_MASK) >> MP2_SMNIF_TLB_VF16_VF_SHIFT)
#define MP2_SMNIF_TLB_VF16_GET_VALID(mp2_smnif_tlb_vf16) \
     ((mp2_smnif_tlb_vf16 & MP2_SMNIF_TLB_VF16_VALID_MASK) >> MP2_SMNIF_TLB_VF16_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF16_SET_VFID(mp2_smnif_tlb_vf16_reg, vfid) \
     mp2_smnif_tlb_vf16_reg = (mp2_smnif_tlb_vf16_reg & ~MP2_SMNIF_TLB_VF16_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF16_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF16_SET_VF(mp2_smnif_tlb_vf16_reg, vf) \
     mp2_smnif_tlb_vf16_reg = (mp2_smnif_tlb_vf16_reg & ~MP2_SMNIF_TLB_VF16_VF_MASK) | (vf << MP2_SMNIF_TLB_VF16_VF_SHIFT)
#define MP2_SMNIF_TLB_VF16_SET_VALID(mp2_smnif_tlb_vf16_reg, valid) \
     mp2_smnif_tlb_vf16_reg = (mp2_smnif_tlb_vf16_reg & ~MP2_SMNIF_TLB_VF16_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF16_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf16_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF16_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF16_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF16_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf16_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf16_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF16_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF16_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF16_VFID_SIZE;
     } mp2_smnif_tlb_vf16_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf16_t f;
} mp2_smnif_tlb_vf16_u;


/*
 * MP2_SMNIF_TLB_VF17 struct
 */

#define MP2_SMNIF_TLB_VF17_REG_SIZE    32
#define MP2_SMNIF_TLB_VF17_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF17_VF_SIZE     1
#define MP2_SMNIF_TLB_VF17_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF17_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF17_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF17_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF17_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF17_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF17_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF17_MASK \
     (MP2_SMNIF_TLB_VF17_VFID_MASK | \
      MP2_SMNIF_TLB_VF17_VF_MASK | \
      MP2_SMNIF_TLB_VF17_VALID_MASK)

#define MP2_SMNIF_TLB_VF17_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF17_GET_VFID(mp2_smnif_tlb_vf17) \
     ((mp2_smnif_tlb_vf17 & MP2_SMNIF_TLB_VF17_VFID_MASK) >> MP2_SMNIF_TLB_VF17_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF17_GET_VF(mp2_smnif_tlb_vf17) \
     ((mp2_smnif_tlb_vf17 & MP2_SMNIF_TLB_VF17_VF_MASK) >> MP2_SMNIF_TLB_VF17_VF_SHIFT)
#define MP2_SMNIF_TLB_VF17_GET_VALID(mp2_smnif_tlb_vf17) \
     ((mp2_smnif_tlb_vf17 & MP2_SMNIF_TLB_VF17_VALID_MASK) >> MP2_SMNIF_TLB_VF17_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF17_SET_VFID(mp2_smnif_tlb_vf17_reg, vfid) \
     mp2_smnif_tlb_vf17_reg = (mp2_smnif_tlb_vf17_reg & ~MP2_SMNIF_TLB_VF17_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF17_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF17_SET_VF(mp2_smnif_tlb_vf17_reg, vf) \
     mp2_smnif_tlb_vf17_reg = (mp2_smnif_tlb_vf17_reg & ~MP2_SMNIF_TLB_VF17_VF_MASK) | (vf << MP2_SMNIF_TLB_VF17_VF_SHIFT)
#define MP2_SMNIF_TLB_VF17_SET_VALID(mp2_smnif_tlb_vf17_reg, valid) \
     mp2_smnif_tlb_vf17_reg = (mp2_smnif_tlb_vf17_reg & ~MP2_SMNIF_TLB_VF17_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF17_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf17_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF17_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF17_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF17_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf17_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf17_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF17_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF17_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF17_VFID_SIZE;
     } mp2_smnif_tlb_vf17_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf17_t f;
} mp2_smnif_tlb_vf17_u;


/*
 * MP2_SMNIF_TLB_VF18 struct
 */

#define MP2_SMNIF_TLB_VF18_REG_SIZE    32
#define MP2_SMNIF_TLB_VF18_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF18_VF_SIZE     1
#define MP2_SMNIF_TLB_VF18_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF18_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF18_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF18_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF18_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF18_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF18_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF18_MASK \
     (MP2_SMNIF_TLB_VF18_VFID_MASK | \
      MP2_SMNIF_TLB_VF18_VF_MASK | \
      MP2_SMNIF_TLB_VF18_VALID_MASK)

#define MP2_SMNIF_TLB_VF18_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF18_GET_VFID(mp2_smnif_tlb_vf18) \
     ((mp2_smnif_tlb_vf18 & MP2_SMNIF_TLB_VF18_VFID_MASK) >> MP2_SMNIF_TLB_VF18_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF18_GET_VF(mp2_smnif_tlb_vf18) \
     ((mp2_smnif_tlb_vf18 & MP2_SMNIF_TLB_VF18_VF_MASK) >> MP2_SMNIF_TLB_VF18_VF_SHIFT)
#define MP2_SMNIF_TLB_VF18_GET_VALID(mp2_smnif_tlb_vf18) \
     ((mp2_smnif_tlb_vf18 & MP2_SMNIF_TLB_VF18_VALID_MASK) >> MP2_SMNIF_TLB_VF18_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF18_SET_VFID(mp2_smnif_tlb_vf18_reg, vfid) \
     mp2_smnif_tlb_vf18_reg = (mp2_smnif_tlb_vf18_reg & ~MP2_SMNIF_TLB_VF18_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF18_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF18_SET_VF(mp2_smnif_tlb_vf18_reg, vf) \
     mp2_smnif_tlb_vf18_reg = (mp2_smnif_tlb_vf18_reg & ~MP2_SMNIF_TLB_VF18_VF_MASK) | (vf << MP2_SMNIF_TLB_VF18_VF_SHIFT)
#define MP2_SMNIF_TLB_VF18_SET_VALID(mp2_smnif_tlb_vf18_reg, valid) \
     mp2_smnif_tlb_vf18_reg = (mp2_smnif_tlb_vf18_reg & ~MP2_SMNIF_TLB_VF18_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF18_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf18_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF18_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF18_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF18_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf18_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf18_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF18_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF18_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF18_VFID_SIZE;
     } mp2_smnif_tlb_vf18_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf18_t f;
} mp2_smnif_tlb_vf18_u;


/*
 * MP2_SMNIF_TLB_VF19 struct
 */

#define MP2_SMNIF_TLB_VF19_REG_SIZE    32
#define MP2_SMNIF_TLB_VF19_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF19_VF_SIZE     1
#define MP2_SMNIF_TLB_VF19_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF19_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF19_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF19_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF19_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF19_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF19_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF19_MASK \
     (MP2_SMNIF_TLB_VF19_VFID_MASK | \
      MP2_SMNIF_TLB_VF19_VF_MASK | \
      MP2_SMNIF_TLB_VF19_VALID_MASK)

#define MP2_SMNIF_TLB_VF19_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF19_GET_VFID(mp2_smnif_tlb_vf19) \
     ((mp2_smnif_tlb_vf19 & MP2_SMNIF_TLB_VF19_VFID_MASK) >> MP2_SMNIF_TLB_VF19_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF19_GET_VF(mp2_smnif_tlb_vf19) \
     ((mp2_smnif_tlb_vf19 & MP2_SMNIF_TLB_VF19_VF_MASK) >> MP2_SMNIF_TLB_VF19_VF_SHIFT)
#define MP2_SMNIF_TLB_VF19_GET_VALID(mp2_smnif_tlb_vf19) \
     ((mp2_smnif_tlb_vf19 & MP2_SMNIF_TLB_VF19_VALID_MASK) >> MP2_SMNIF_TLB_VF19_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF19_SET_VFID(mp2_smnif_tlb_vf19_reg, vfid) \
     mp2_smnif_tlb_vf19_reg = (mp2_smnif_tlb_vf19_reg & ~MP2_SMNIF_TLB_VF19_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF19_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF19_SET_VF(mp2_smnif_tlb_vf19_reg, vf) \
     mp2_smnif_tlb_vf19_reg = (mp2_smnif_tlb_vf19_reg & ~MP2_SMNIF_TLB_VF19_VF_MASK) | (vf << MP2_SMNIF_TLB_VF19_VF_SHIFT)
#define MP2_SMNIF_TLB_VF19_SET_VALID(mp2_smnif_tlb_vf19_reg, valid) \
     mp2_smnif_tlb_vf19_reg = (mp2_smnif_tlb_vf19_reg & ~MP2_SMNIF_TLB_VF19_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF19_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf19_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF19_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF19_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF19_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf19_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf19_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF19_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF19_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF19_VFID_SIZE;
     } mp2_smnif_tlb_vf19_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf19_t f;
} mp2_smnif_tlb_vf19_u;


/*
 * MP2_SMNIF_TLB_VF20 struct
 */

#define MP2_SMNIF_TLB_VF20_REG_SIZE    32
#define MP2_SMNIF_TLB_VF20_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF20_VF_SIZE     1
#define MP2_SMNIF_TLB_VF20_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF20_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF20_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF20_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF20_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF20_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF20_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF20_MASK \
     (MP2_SMNIF_TLB_VF20_VFID_MASK | \
      MP2_SMNIF_TLB_VF20_VF_MASK | \
      MP2_SMNIF_TLB_VF20_VALID_MASK)

#define MP2_SMNIF_TLB_VF20_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF20_GET_VFID(mp2_smnif_tlb_vf20) \
     ((mp2_smnif_tlb_vf20 & MP2_SMNIF_TLB_VF20_VFID_MASK) >> MP2_SMNIF_TLB_VF20_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF20_GET_VF(mp2_smnif_tlb_vf20) \
     ((mp2_smnif_tlb_vf20 & MP2_SMNIF_TLB_VF20_VF_MASK) >> MP2_SMNIF_TLB_VF20_VF_SHIFT)
#define MP2_SMNIF_TLB_VF20_GET_VALID(mp2_smnif_tlb_vf20) \
     ((mp2_smnif_tlb_vf20 & MP2_SMNIF_TLB_VF20_VALID_MASK) >> MP2_SMNIF_TLB_VF20_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF20_SET_VFID(mp2_smnif_tlb_vf20_reg, vfid) \
     mp2_smnif_tlb_vf20_reg = (mp2_smnif_tlb_vf20_reg & ~MP2_SMNIF_TLB_VF20_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF20_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF20_SET_VF(mp2_smnif_tlb_vf20_reg, vf) \
     mp2_smnif_tlb_vf20_reg = (mp2_smnif_tlb_vf20_reg & ~MP2_SMNIF_TLB_VF20_VF_MASK) | (vf << MP2_SMNIF_TLB_VF20_VF_SHIFT)
#define MP2_SMNIF_TLB_VF20_SET_VALID(mp2_smnif_tlb_vf20_reg, valid) \
     mp2_smnif_tlb_vf20_reg = (mp2_smnif_tlb_vf20_reg & ~MP2_SMNIF_TLB_VF20_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF20_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf20_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF20_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF20_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF20_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf20_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf20_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF20_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF20_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF20_VFID_SIZE;
     } mp2_smnif_tlb_vf20_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf20_t f;
} mp2_smnif_tlb_vf20_u;


/*
 * MP2_SMNIF_TLB_VF21 struct
 */

#define MP2_SMNIF_TLB_VF21_REG_SIZE    32
#define MP2_SMNIF_TLB_VF21_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF21_VF_SIZE     1
#define MP2_SMNIF_TLB_VF21_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF21_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF21_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF21_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF21_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF21_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF21_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF21_MASK \
     (MP2_SMNIF_TLB_VF21_VFID_MASK | \
      MP2_SMNIF_TLB_VF21_VF_MASK | \
      MP2_SMNIF_TLB_VF21_VALID_MASK)

#define MP2_SMNIF_TLB_VF21_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF21_GET_VFID(mp2_smnif_tlb_vf21) \
     ((mp2_smnif_tlb_vf21 & MP2_SMNIF_TLB_VF21_VFID_MASK) >> MP2_SMNIF_TLB_VF21_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF21_GET_VF(mp2_smnif_tlb_vf21) \
     ((mp2_smnif_tlb_vf21 & MP2_SMNIF_TLB_VF21_VF_MASK) >> MP2_SMNIF_TLB_VF21_VF_SHIFT)
#define MP2_SMNIF_TLB_VF21_GET_VALID(mp2_smnif_tlb_vf21) \
     ((mp2_smnif_tlb_vf21 & MP2_SMNIF_TLB_VF21_VALID_MASK) >> MP2_SMNIF_TLB_VF21_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF21_SET_VFID(mp2_smnif_tlb_vf21_reg, vfid) \
     mp2_smnif_tlb_vf21_reg = (mp2_smnif_tlb_vf21_reg & ~MP2_SMNIF_TLB_VF21_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF21_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF21_SET_VF(mp2_smnif_tlb_vf21_reg, vf) \
     mp2_smnif_tlb_vf21_reg = (mp2_smnif_tlb_vf21_reg & ~MP2_SMNIF_TLB_VF21_VF_MASK) | (vf << MP2_SMNIF_TLB_VF21_VF_SHIFT)
#define MP2_SMNIF_TLB_VF21_SET_VALID(mp2_smnif_tlb_vf21_reg, valid) \
     mp2_smnif_tlb_vf21_reg = (mp2_smnif_tlb_vf21_reg & ~MP2_SMNIF_TLB_VF21_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF21_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf21_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF21_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF21_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF21_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf21_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf21_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF21_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF21_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF21_VFID_SIZE;
     } mp2_smnif_tlb_vf21_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf21_t f;
} mp2_smnif_tlb_vf21_u;


/*
 * MP2_SMNIF_TLB_VF22 struct
 */

#define MP2_SMNIF_TLB_VF22_REG_SIZE    32
#define MP2_SMNIF_TLB_VF22_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF22_VF_SIZE     1
#define MP2_SMNIF_TLB_VF22_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF22_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF22_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF22_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF22_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF22_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF22_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF22_MASK \
     (MP2_SMNIF_TLB_VF22_VFID_MASK | \
      MP2_SMNIF_TLB_VF22_VF_MASK | \
      MP2_SMNIF_TLB_VF22_VALID_MASK)

#define MP2_SMNIF_TLB_VF22_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF22_GET_VFID(mp2_smnif_tlb_vf22) \
     ((mp2_smnif_tlb_vf22 & MP2_SMNIF_TLB_VF22_VFID_MASK) >> MP2_SMNIF_TLB_VF22_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF22_GET_VF(mp2_smnif_tlb_vf22) \
     ((mp2_smnif_tlb_vf22 & MP2_SMNIF_TLB_VF22_VF_MASK) >> MP2_SMNIF_TLB_VF22_VF_SHIFT)
#define MP2_SMNIF_TLB_VF22_GET_VALID(mp2_smnif_tlb_vf22) \
     ((mp2_smnif_tlb_vf22 & MP2_SMNIF_TLB_VF22_VALID_MASK) >> MP2_SMNIF_TLB_VF22_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF22_SET_VFID(mp2_smnif_tlb_vf22_reg, vfid) \
     mp2_smnif_tlb_vf22_reg = (mp2_smnif_tlb_vf22_reg & ~MP2_SMNIF_TLB_VF22_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF22_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF22_SET_VF(mp2_smnif_tlb_vf22_reg, vf) \
     mp2_smnif_tlb_vf22_reg = (mp2_smnif_tlb_vf22_reg & ~MP2_SMNIF_TLB_VF22_VF_MASK) | (vf << MP2_SMNIF_TLB_VF22_VF_SHIFT)
#define MP2_SMNIF_TLB_VF22_SET_VALID(mp2_smnif_tlb_vf22_reg, valid) \
     mp2_smnif_tlb_vf22_reg = (mp2_smnif_tlb_vf22_reg & ~MP2_SMNIF_TLB_VF22_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF22_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf22_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF22_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF22_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF22_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf22_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf22_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF22_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF22_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF22_VFID_SIZE;
     } mp2_smnif_tlb_vf22_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf22_t f;
} mp2_smnif_tlb_vf22_u;


/*
 * MP2_SMNIF_TLB_VF23 struct
 */

#define MP2_SMNIF_TLB_VF23_REG_SIZE    32
#define MP2_SMNIF_TLB_VF23_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF23_VF_SIZE     1
#define MP2_SMNIF_TLB_VF23_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF23_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF23_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF23_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF23_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF23_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF23_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF23_MASK \
     (MP2_SMNIF_TLB_VF23_VFID_MASK | \
      MP2_SMNIF_TLB_VF23_VF_MASK | \
      MP2_SMNIF_TLB_VF23_VALID_MASK)

#define MP2_SMNIF_TLB_VF23_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF23_GET_VFID(mp2_smnif_tlb_vf23) \
     ((mp2_smnif_tlb_vf23 & MP2_SMNIF_TLB_VF23_VFID_MASK) >> MP2_SMNIF_TLB_VF23_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF23_GET_VF(mp2_smnif_tlb_vf23) \
     ((mp2_smnif_tlb_vf23 & MP2_SMNIF_TLB_VF23_VF_MASK) >> MP2_SMNIF_TLB_VF23_VF_SHIFT)
#define MP2_SMNIF_TLB_VF23_GET_VALID(mp2_smnif_tlb_vf23) \
     ((mp2_smnif_tlb_vf23 & MP2_SMNIF_TLB_VF23_VALID_MASK) >> MP2_SMNIF_TLB_VF23_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF23_SET_VFID(mp2_smnif_tlb_vf23_reg, vfid) \
     mp2_smnif_tlb_vf23_reg = (mp2_smnif_tlb_vf23_reg & ~MP2_SMNIF_TLB_VF23_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF23_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF23_SET_VF(mp2_smnif_tlb_vf23_reg, vf) \
     mp2_smnif_tlb_vf23_reg = (mp2_smnif_tlb_vf23_reg & ~MP2_SMNIF_TLB_VF23_VF_MASK) | (vf << MP2_SMNIF_TLB_VF23_VF_SHIFT)
#define MP2_SMNIF_TLB_VF23_SET_VALID(mp2_smnif_tlb_vf23_reg, valid) \
     mp2_smnif_tlb_vf23_reg = (mp2_smnif_tlb_vf23_reg & ~MP2_SMNIF_TLB_VF23_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF23_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf23_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF23_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF23_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF23_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf23_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf23_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF23_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF23_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF23_VFID_SIZE;
     } mp2_smnif_tlb_vf23_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf23_t f;
} mp2_smnif_tlb_vf23_u;


/*
 * MP2_SMNIF_TLB_VF24 struct
 */

#define MP2_SMNIF_TLB_VF24_REG_SIZE    32
#define MP2_SMNIF_TLB_VF24_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF24_VF_SIZE     1
#define MP2_SMNIF_TLB_VF24_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF24_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF24_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF24_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF24_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF24_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF24_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF24_MASK \
     (MP2_SMNIF_TLB_VF24_VFID_MASK | \
      MP2_SMNIF_TLB_VF24_VF_MASK | \
      MP2_SMNIF_TLB_VF24_VALID_MASK)

#define MP2_SMNIF_TLB_VF24_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF24_GET_VFID(mp2_smnif_tlb_vf24) \
     ((mp2_smnif_tlb_vf24 & MP2_SMNIF_TLB_VF24_VFID_MASK) >> MP2_SMNIF_TLB_VF24_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF24_GET_VF(mp2_smnif_tlb_vf24) \
     ((mp2_smnif_tlb_vf24 & MP2_SMNIF_TLB_VF24_VF_MASK) >> MP2_SMNIF_TLB_VF24_VF_SHIFT)
#define MP2_SMNIF_TLB_VF24_GET_VALID(mp2_smnif_tlb_vf24) \
     ((mp2_smnif_tlb_vf24 & MP2_SMNIF_TLB_VF24_VALID_MASK) >> MP2_SMNIF_TLB_VF24_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF24_SET_VFID(mp2_smnif_tlb_vf24_reg, vfid) \
     mp2_smnif_tlb_vf24_reg = (mp2_smnif_tlb_vf24_reg & ~MP2_SMNIF_TLB_VF24_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF24_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF24_SET_VF(mp2_smnif_tlb_vf24_reg, vf) \
     mp2_smnif_tlb_vf24_reg = (mp2_smnif_tlb_vf24_reg & ~MP2_SMNIF_TLB_VF24_VF_MASK) | (vf << MP2_SMNIF_TLB_VF24_VF_SHIFT)
#define MP2_SMNIF_TLB_VF24_SET_VALID(mp2_smnif_tlb_vf24_reg, valid) \
     mp2_smnif_tlb_vf24_reg = (mp2_smnif_tlb_vf24_reg & ~MP2_SMNIF_TLB_VF24_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF24_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf24_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF24_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF24_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF24_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf24_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf24_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF24_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF24_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF24_VFID_SIZE;
     } mp2_smnif_tlb_vf24_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf24_t f;
} mp2_smnif_tlb_vf24_u;


/*
 * MP2_SMNIF_TLB_VF25 struct
 */

#define MP2_SMNIF_TLB_VF25_REG_SIZE    32
#define MP2_SMNIF_TLB_VF25_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF25_VF_SIZE     1
#define MP2_SMNIF_TLB_VF25_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF25_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF25_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF25_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF25_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF25_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF25_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF25_MASK \
     (MP2_SMNIF_TLB_VF25_VFID_MASK | \
      MP2_SMNIF_TLB_VF25_VF_MASK | \
      MP2_SMNIF_TLB_VF25_VALID_MASK)

#define MP2_SMNIF_TLB_VF25_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF25_GET_VFID(mp2_smnif_tlb_vf25) \
     ((mp2_smnif_tlb_vf25 & MP2_SMNIF_TLB_VF25_VFID_MASK) >> MP2_SMNIF_TLB_VF25_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF25_GET_VF(mp2_smnif_tlb_vf25) \
     ((mp2_smnif_tlb_vf25 & MP2_SMNIF_TLB_VF25_VF_MASK) >> MP2_SMNIF_TLB_VF25_VF_SHIFT)
#define MP2_SMNIF_TLB_VF25_GET_VALID(mp2_smnif_tlb_vf25) \
     ((mp2_smnif_tlb_vf25 & MP2_SMNIF_TLB_VF25_VALID_MASK) >> MP2_SMNIF_TLB_VF25_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF25_SET_VFID(mp2_smnif_tlb_vf25_reg, vfid) \
     mp2_smnif_tlb_vf25_reg = (mp2_smnif_tlb_vf25_reg & ~MP2_SMNIF_TLB_VF25_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF25_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF25_SET_VF(mp2_smnif_tlb_vf25_reg, vf) \
     mp2_smnif_tlb_vf25_reg = (mp2_smnif_tlb_vf25_reg & ~MP2_SMNIF_TLB_VF25_VF_MASK) | (vf << MP2_SMNIF_TLB_VF25_VF_SHIFT)
#define MP2_SMNIF_TLB_VF25_SET_VALID(mp2_smnif_tlb_vf25_reg, valid) \
     mp2_smnif_tlb_vf25_reg = (mp2_smnif_tlb_vf25_reg & ~MP2_SMNIF_TLB_VF25_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF25_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf25_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF25_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF25_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF25_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf25_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf25_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF25_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF25_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF25_VFID_SIZE;
     } mp2_smnif_tlb_vf25_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf25_t f;
} mp2_smnif_tlb_vf25_u;


/*
 * MP2_SMNIF_TLB_VF26 struct
 */

#define MP2_SMNIF_TLB_VF26_REG_SIZE    32
#define MP2_SMNIF_TLB_VF26_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF26_VF_SIZE     1
#define MP2_SMNIF_TLB_VF26_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF26_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF26_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF26_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF26_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF26_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF26_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF26_MASK \
     (MP2_SMNIF_TLB_VF26_VFID_MASK | \
      MP2_SMNIF_TLB_VF26_VF_MASK | \
      MP2_SMNIF_TLB_VF26_VALID_MASK)

#define MP2_SMNIF_TLB_VF26_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF26_GET_VFID(mp2_smnif_tlb_vf26) \
     ((mp2_smnif_tlb_vf26 & MP2_SMNIF_TLB_VF26_VFID_MASK) >> MP2_SMNIF_TLB_VF26_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF26_GET_VF(mp2_smnif_tlb_vf26) \
     ((mp2_smnif_tlb_vf26 & MP2_SMNIF_TLB_VF26_VF_MASK) >> MP2_SMNIF_TLB_VF26_VF_SHIFT)
#define MP2_SMNIF_TLB_VF26_GET_VALID(mp2_smnif_tlb_vf26) \
     ((mp2_smnif_tlb_vf26 & MP2_SMNIF_TLB_VF26_VALID_MASK) >> MP2_SMNIF_TLB_VF26_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF26_SET_VFID(mp2_smnif_tlb_vf26_reg, vfid) \
     mp2_smnif_tlb_vf26_reg = (mp2_smnif_tlb_vf26_reg & ~MP2_SMNIF_TLB_VF26_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF26_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF26_SET_VF(mp2_smnif_tlb_vf26_reg, vf) \
     mp2_smnif_tlb_vf26_reg = (mp2_smnif_tlb_vf26_reg & ~MP2_SMNIF_TLB_VF26_VF_MASK) | (vf << MP2_SMNIF_TLB_VF26_VF_SHIFT)
#define MP2_SMNIF_TLB_VF26_SET_VALID(mp2_smnif_tlb_vf26_reg, valid) \
     mp2_smnif_tlb_vf26_reg = (mp2_smnif_tlb_vf26_reg & ~MP2_SMNIF_TLB_VF26_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF26_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf26_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF26_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF26_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF26_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf26_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf26_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF26_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF26_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF26_VFID_SIZE;
     } mp2_smnif_tlb_vf26_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf26_t f;
} mp2_smnif_tlb_vf26_u;


/*
 * MP2_SMNIF_TLB_VF27 struct
 */

#define MP2_SMNIF_TLB_VF27_REG_SIZE    32
#define MP2_SMNIF_TLB_VF27_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF27_VF_SIZE     1
#define MP2_SMNIF_TLB_VF27_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF27_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF27_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF27_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF27_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF27_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF27_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF27_MASK \
     (MP2_SMNIF_TLB_VF27_VFID_MASK | \
      MP2_SMNIF_TLB_VF27_VF_MASK | \
      MP2_SMNIF_TLB_VF27_VALID_MASK)

#define MP2_SMNIF_TLB_VF27_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF27_GET_VFID(mp2_smnif_tlb_vf27) \
     ((mp2_smnif_tlb_vf27 & MP2_SMNIF_TLB_VF27_VFID_MASK) >> MP2_SMNIF_TLB_VF27_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF27_GET_VF(mp2_smnif_tlb_vf27) \
     ((mp2_smnif_tlb_vf27 & MP2_SMNIF_TLB_VF27_VF_MASK) >> MP2_SMNIF_TLB_VF27_VF_SHIFT)
#define MP2_SMNIF_TLB_VF27_GET_VALID(mp2_smnif_tlb_vf27) \
     ((mp2_smnif_tlb_vf27 & MP2_SMNIF_TLB_VF27_VALID_MASK) >> MP2_SMNIF_TLB_VF27_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF27_SET_VFID(mp2_smnif_tlb_vf27_reg, vfid) \
     mp2_smnif_tlb_vf27_reg = (mp2_smnif_tlb_vf27_reg & ~MP2_SMNIF_TLB_VF27_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF27_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF27_SET_VF(mp2_smnif_tlb_vf27_reg, vf) \
     mp2_smnif_tlb_vf27_reg = (mp2_smnif_tlb_vf27_reg & ~MP2_SMNIF_TLB_VF27_VF_MASK) | (vf << MP2_SMNIF_TLB_VF27_VF_SHIFT)
#define MP2_SMNIF_TLB_VF27_SET_VALID(mp2_smnif_tlb_vf27_reg, valid) \
     mp2_smnif_tlb_vf27_reg = (mp2_smnif_tlb_vf27_reg & ~MP2_SMNIF_TLB_VF27_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF27_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf27_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF27_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF27_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF27_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf27_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf27_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF27_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF27_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF27_VFID_SIZE;
     } mp2_smnif_tlb_vf27_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf27_t f;
} mp2_smnif_tlb_vf27_u;


/*
 * MP2_SMNIF_TLB_VF28 struct
 */

#define MP2_SMNIF_TLB_VF28_REG_SIZE    32
#define MP2_SMNIF_TLB_VF28_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF28_VF_SIZE     1
#define MP2_SMNIF_TLB_VF28_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF28_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF28_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF28_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF28_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF28_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF28_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF28_MASK \
     (MP2_SMNIF_TLB_VF28_VFID_MASK | \
      MP2_SMNIF_TLB_VF28_VF_MASK | \
      MP2_SMNIF_TLB_VF28_VALID_MASK)

#define MP2_SMNIF_TLB_VF28_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF28_GET_VFID(mp2_smnif_tlb_vf28) \
     ((mp2_smnif_tlb_vf28 & MP2_SMNIF_TLB_VF28_VFID_MASK) >> MP2_SMNIF_TLB_VF28_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF28_GET_VF(mp2_smnif_tlb_vf28) \
     ((mp2_smnif_tlb_vf28 & MP2_SMNIF_TLB_VF28_VF_MASK) >> MP2_SMNIF_TLB_VF28_VF_SHIFT)
#define MP2_SMNIF_TLB_VF28_GET_VALID(mp2_smnif_tlb_vf28) \
     ((mp2_smnif_tlb_vf28 & MP2_SMNIF_TLB_VF28_VALID_MASK) >> MP2_SMNIF_TLB_VF28_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF28_SET_VFID(mp2_smnif_tlb_vf28_reg, vfid) \
     mp2_smnif_tlb_vf28_reg = (mp2_smnif_tlb_vf28_reg & ~MP2_SMNIF_TLB_VF28_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF28_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF28_SET_VF(mp2_smnif_tlb_vf28_reg, vf) \
     mp2_smnif_tlb_vf28_reg = (mp2_smnif_tlb_vf28_reg & ~MP2_SMNIF_TLB_VF28_VF_MASK) | (vf << MP2_SMNIF_TLB_VF28_VF_SHIFT)
#define MP2_SMNIF_TLB_VF28_SET_VALID(mp2_smnif_tlb_vf28_reg, valid) \
     mp2_smnif_tlb_vf28_reg = (mp2_smnif_tlb_vf28_reg & ~MP2_SMNIF_TLB_VF28_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF28_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf28_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF28_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF28_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF28_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf28_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf28_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF28_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF28_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF28_VFID_SIZE;
     } mp2_smnif_tlb_vf28_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf28_t f;
} mp2_smnif_tlb_vf28_u;


/*
 * MP2_SMNIF_TLB_VF29 struct
 */

#define MP2_SMNIF_TLB_VF29_REG_SIZE    32
#define MP2_SMNIF_TLB_VF29_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF29_VF_SIZE     1
#define MP2_SMNIF_TLB_VF29_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF29_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF29_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF29_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF29_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF29_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF29_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF29_MASK \
     (MP2_SMNIF_TLB_VF29_VFID_MASK | \
      MP2_SMNIF_TLB_VF29_VF_MASK | \
      MP2_SMNIF_TLB_VF29_VALID_MASK)

#define MP2_SMNIF_TLB_VF29_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF29_GET_VFID(mp2_smnif_tlb_vf29) \
     ((mp2_smnif_tlb_vf29 & MP2_SMNIF_TLB_VF29_VFID_MASK) >> MP2_SMNIF_TLB_VF29_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF29_GET_VF(mp2_smnif_tlb_vf29) \
     ((mp2_smnif_tlb_vf29 & MP2_SMNIF_TLB_VF29_VF_MASK) >> MP2_SMNIF_TLB_VF29_VF_SHIFT)
#define MP2_SMNIF_TLB_VF29_GET_VALID(mp2_smnif_tlb_vf29) \
     ((mp2_smnif_tlb_vf29 & MP2_SMNIF_TLB_VF29_VALID_MASK) >> MP2_SMNIF_TLB_VF29_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF29_SET_VFID(mp2_smnif_tlb_vf29_reg, vfid) \
     mp2_smnif_tlb_vf29_reg = (mp2_smnif_tlb_vf29_reg & ~MP2_SMNIF_TLB_VF29_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF29_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF29_SET_VF(mp2_smnif_tlb_vf29_reg, vf) \
     mp2_smnif_tlb_vf29_reg = (mp2_smnif_tlb_vf29_reg & ~MP2_SMNIF_TLB_VF29_VF_MASK) | (vf << MP2_SMNIF_TLB_VF29_VF_SHIFT)
#define MP2_SMNIF_TLB_VF29_SET_VALID(mp2_smnif_tlb_vf29_reg, valid) \
     mp2_smnif_tlb_vf29_reg = (mp2_smnif_tlb_vf29_reg & ~MP2_SMNIF_TLB_VF29_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF29_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf29_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF29_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF29_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF29_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf29_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf29_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF29_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF29_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF29_VFID_SIZE;
     } mp2_smnif_tlb_vf29_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf29_t f;
} mp2_smnif_tlb_vf29_u;


/*
 * MP2_SMNIF_TLB_VF30 struct
 */

#define MP2_SMNIF_TLB_VF30_REG_SIZE    32
#define MP2_SMNIF_TLB_VF30_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF30_VF_SIZE     1
#define MP2_SMNIF_TLB_VF30_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF30_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF30_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF30_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF30_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF30_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF30_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF30_MASK \
     (MP2_SMNIF_TLB_VF30_VFID_MASK | \
      MP2_SMNIF_TLB_VF30_VF_MASK | \
      MP2_SMNIF_TLB_VF30_VALID_MASK)

#define MP2_SMNIF_TLB_VF30_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF30_GET_VFID(mp2_smnif_tlb_vf30) \
     ((mp2_smnif_tlb_vf30 & MP2_SMNIF_TLB_VF30_VFID_MASK) >> MP2_SMNIF_TLB_VF30_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF30_GET_VF(mp2_smnif_tlb_vf30) \
     ((mp2_smnif_tlb_vf30 & MP2_SMNIF_TLB_VF30_VF_MASK) >> MP2_SMNIF_TLB_VF30_VF_SHIFT)
#define MP2_SMNIF_TLB_VF30_GET_VALID(mp2_smnif_tlb_vf30) \
     ((mp2_smnif_tlb_vf30 & MP2_SMNIF_TLB_VF30_VALID_MASK) >> MP2_SMNIF_TLB_VF30_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF30_SET_VFID(mp2_smnif_tlb_vf30_reg, vfid) \
     mp2_smnif_tlb_vf30_reg = (mp2_smnif_tlb_vf30_reg & ~MP2_SMNIF_TLB_VF30_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF30_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF30_SET_VF(mp2_smnif_tlb_vf30_reg, vf) \
     mp2_smnif_tlb_vf30_reg = (mp2_smnif_tlb_vf30_reg & ~MP2_SMNIF_TLB_VF30_VF_MASK) | (vf << MP2_SMNIF_TLB_VF30_VF_SHIFT)
#define MP2_SMNIF_TLB_VF30_SET_VALID(mp2_smnif_tlb_vf30_reg, valid) \
     mp2_smnif_tlb_vf30_reg = (mp2_smnif_tlb_vf30_reg & ~MP2_SMNIF_TLB_VF30_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF30_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf30_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF30_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF30_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF30_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf30_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf30_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF30_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF30_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF30_VFID_SIZE;
     } mp2_smnif_tlb_vf30_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf30_t f;
} mp2_smnif_tlb_vf30_u;


/*
 * MP2_SMNIF_TLB_VF31 struct
 */

#define MP2_SMNIF_TLB_VF31_REG_SIZE    32
#define MP2_SMNIF_TLB_VF31_VFID_SIZE   6
#define MP2_SMNIF_TLB_VF31_VF_SIZE     1
#define MP2_SMNIF_TLB_VF31_VALID_SIZE  1

#define MP2_SMNIF_TLB_VF31_VFID_SHIFT  0
#define MP2_SMNIF_TLB_VF31_VF_SHIFT    6
#define MP2_SMNIF_TLB_VF31_VALID_SHIFT 7

#define MP2_SMNIF_TLB_VF31_VFID_MASK   0x3f
#define MP2_SMNIF_TLB_VF31_VF_MASK     0x40
#define MP2_SMNIF_TLB_VF31_VALID_MASK  0x80

#define MP2_SMNIF_TLB_VF31_MASK \
     (MP2_SMNIF_TLB_VF31_VFID_MASK | \
      MP2_SMNIF_TLB_VF31_VF_MASK | \
      MP2_SMNIF_TLB_VF31_VALID_MASK)

#define MP2_SMNIF_TLB_VF31_DEFAULT     0x00000000

#define MP2_SMNIF_TLB_VF31_GET_VFID(mp2_smnif_tlb_vf31) \
     ((mp2_smnif_tlb_vf31 & MP2_SMNIF_TLB_VF31_VFID_MASK) >> MP2_SMNIF_TLB_VF31_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF31_GET_VF(mp2_smnif_tlb_vf31) \
     ((mp2_smnif_tlb_vf31 & MP2_SMNIF_TLB_VF31_VF_MASK) >> MP2_SMNIF_TLB_VF31_VF_SHIFT)
#define MP2_SMNIF_TLB_VF31_GET_VALID(mp2_smnif_tlb_vf31) \
     ((mp2_smnif_tlb_vf31 & MP2_SMNIF_TLB_VF31_VALID_MASK) >> MP2_SMNIF_TLB_VF31_VALID_SHIFT)

#define MP2_SMNIF_TLB_VF31_SET_VFID(mp2_smnif_tlb_vf31_reg, vfid) \
     mp2_smnif_tlb_vf31_reg = (mp2_smnif_tlb_vf31_reg & ~MP2_SMNIF_TLB_VF31_VFID_MASK) | (vfid << MP2_SMNIF_TLB_VF31_VFID_SHIFT)
#define MP2_SMNIF_TLB_VF31_SET_VF(mp2_smnif_tlb_vf31_reg, vf) \
     mp2_smnif_tlb_vf31_reg = (mp2_smnif_tlb_vf31_reg & ~MP2_SMNIF_TLB_VF31_VF_MASK) | (vf << MP2_SMNIF_TLB_VF31_VF_SHIFT)
#define MP2_SMNIF_TLB_VF31_SET_VALID(mp2_smnif_tlb_vf31_reg, valid) \
     mp2_smnif_tlb_vf31_reg = (mp2_smnif_tlb_vf31_reg & ~MP2_SMNIF_TLB_VF31_VALID_MASK) | (valid << MP2_SMNIF_TLB_VF31_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf31_t {
          unsigned int vfid                           : MP2_SMNIF_TLB_VF31_VFID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF31_VF_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLB_VF31_VALID_SIZE;
          unsigned int                                : 24;
     } mp2_smnif_tlb_vf31_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_vf31_t {
          unsigned int                                : 24;
          unsigned int valid                          : MP2_SMNIF_TLB_VF31_VALID_SIZE;
          unsigned int vf                             : MP2_SMNIF_TLB_VF31_VF_SIZE;
          unsigned int vfid                           : MP2_SMNIF_TLB_VF31_VFID_SIZE;
     } mp2_smnif_tlb_vf31_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_vf31_t f;
} mp2_smnif_tlb_vf31_u;


/*
 * MP2_SMNIF_TLB_QOS struct
 */

#define MP2_SMNIF_TLB_QOS_REG_SIZE     32
#define MP2_SMNIF_TLB_QOS_TLB_QOS_SIZE 32

#define MP2_SMNIF_TLB_QOS_TLB_QOS_SHIFT 0

#define MP2_SMNIF_TLB_QOS_TLB_QOS_MASK 0xffffffff

#define MP2_SMNIF_TLB_QOS_MASK \
     (MP2_SMNIF_TLB_QOS_TLB_QOS_MASK)

#define MP2_SMNIF_TLB_QOS_DEFAULT      0xffffffff

#define MP2_SMNIF_TLB_QOS_GET_TLB_QOS(mp2_smnif_tlb_qos) \
     ((mp2_smnif_tlb_qos & MP2_SMNIF_TLB_QOS_TLB_QOS_MASK) >> MP2_SMNIF_TLB_QOS_TLB_QOS_SHIFT)

#define MP2_SMNIF_TLB_QOS_SET_TLB_QOS(mp2_smnif_tlb_qos_reg, tlb_qos) \
     mp2_smnif_tlb_qos_reg = (mp2_smnif_tlb_qos_reg & ~MP2_SMNIF_TLB_QOS_TLB_QOS_MASK) | (tlb_qos << MP2_SMNIF_TLB_QOS_TLB_QOS_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_qos_t {
          unsigned int tlb_qos                        : MP2_SMNIF_TLB_QOS_TLB_QOS_SIZE;
     } mp2_smnif_tlb_qos_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_qos_t {
          unsigned int tlb_qos                        : MP2_SMNIF_TLB_QOS_TLB_QOS_SIZE;
     } mp2_smnif_tlb_qos_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_qos_t f;
} mp2_smnif_tlb_qos_u;


/*
 * MP2_SMNIF_ACC_VIOLATION_LOG_ADDR struct
 */

#define MP2_SMNIF_ACC_VIOLATION_LOG_ADDR_REG_SIZE 32
#define MP2_SMNIF_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SIZE 32

#define MP2_SMNIF_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SHIFT 0

#define MP2_SMNIF_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK 0xffffffff

#define MP2_SMNIF_ACC_VIOLATION_LOG_ADDR_MASK \
     (MP2_SMNIF_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK)

#define MP2_SMNIF_ACC_VIOLATION_LOG_ADDR_DEFAULT 0x00000000

#define MP2_SMNIF_ACC_VIOLATION_LOG_ADDR_GET_AXI_ADDR(mp2_smnif_acc_violation_log_addr) \
     ((mp2_smnif_acc_violation_log_addr & MP2_SMNIF_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK) >> MP2_SMNIF_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SHIFT)

#define MP2_SMNIF_ACC_VIOLATION_LOG_ADDR_SET_AXI_ADDR(mp2_smnif_acc_violation_log_addr_reg, axi_addr) \
     mp2_smnif_acc_violation_log_addr_reg = (mp2_smnif_acc_violation_log_addr_reg & ~MP2_SMNIF_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK) | (axi_addr << MP2_SMNIF_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_acc_violation_log_addr_t {
          unsigned int axi_addr                       : MP2_SMNIF_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SIZE;
     } mp2_smnif_acc_violation_log_addr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_acc_violation_log_addr_t {
          unsigned int axi_addr                       : MP2_SMNIF_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SIZE;
     } mp2_smnif_acc_violation_log_addr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_acc_violation_log_addr_t f;
} mp2_smnif_acc_violation_log_addr_u;


/*
 * MP2_SMNIF_ACC_VIOLATION_LOG_STATUS struct
 */

#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_REG_SIZE 32
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE 1
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE 2
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE 1
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_ID_SIZE 21
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_PROT_SIZE 3

#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT 0
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT 1
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT 3
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_ID_SHIFT 8
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_PROT_SHIFT 29

#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK 0x1
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK 0x6
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK 0x8
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK 0x1fffff00
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_PROT_MASK 0xe0000000

#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_MASK \
     (MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK | \
      MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK | \
      MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK | \
      MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK | \
      MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_PROT_MASK)

#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_DEFAULT 0x00000000

#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_DETECTED(mp2_smnif_acc_violation_log_status) \
     ((mp2_smnif_acc_violation_log_status & MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) >> MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_TYPE(mp2_smnif_acc_violation_log_status) \
     ((mp2_smnif_acc_violation_log_status & MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) >> MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_LOG_CLEAR(mp2_smnif_acc_violation_log_status) \
     ((mp2_smnif_acc_violation_log_status & MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) >> MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_GET_AXI_ID(mp2_smnif_acc_violation_log_status) \
     ((mp2_smnif_acc_violation_log_status & MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK) >> MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_ID_SHIFT)
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_GET_AXI_PROT(mp2_smnif_acc_violation_log_status) \
     ((mp2_smnif_acc_violation_log_status & MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_PROT_MASK) >> MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_PROT_SHIFT)

#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_DETECTED(mp2_smnif_acc_violation_log_status_reg, acc_violation_detected) \
     mp2_smnif_acc_violation_log_status_reg = (mp2_smnif_acc_violation_log_status_reg & ~MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) | (acc_violation_detected << MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_TYPE(mp2_smnif_acc_violation_log_status_reg, acc_violation_type) \
     mp2_smnif_acc_violation_log_status_reg = (mp2_smnif_acc_violation_log_status_reg & ~MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) | (acc_violation_type << MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_LOG_CLEAR(mp2_smnif_acc_violation_log_status_reg, acc_violation_log_clear) \
     mp2_smnif_acc_violation_log_status_reg = (mp2_smnif_acc_violation_log_status_reg & ~MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) | (acc_violation_log_clear << MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_SET_AXI_ID(mp2_smnif_acc_violation_log_status_reg, axi_id) \
     mp2_smnif_acc_violation_log_status_reg = (mp2_smnif_acc_violation_log_status_reg & ~MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK) | (axi_id << MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_ID_SHIFT)
#define MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_SET_AXI_PROT(mp2_smnif_acc_violation_log_status_reg, axi_prot) \
     mp2_smnif_acc_violation_log_status_reg = (mp2_smnif_acc_violation_log_status_reg & ~MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_PROT_MASK) | (axi_prot << MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_PROT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_acc_violation_log_status_t {
          unsigned int acc_violation_detected         : MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
          unsigned int acc_violation_type             : MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
          unsigned int acc_violation_log_clear        : MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
          unsigned int                                : 4;
          unsigned int axi_id                         : MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_ID_SIZE;
          unsigned int axi_prot                       : MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_PROT_SIZE;
     } mp2_smnif_acc_violation_log_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_acc_violation_log_status_t {
          unsigned int axi_prot                       : MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_PROT_SIZE;
          unsigned int axi_id                         : MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_ID_SIZE;
          unsigned int                                : 4;
          unsigned int acc_violation_log_clear        : MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
          unsigned int acc_violation_type             : MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
          unsigned int acc_violation_detected         : MP2_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
     } mp2_smnif_acc_violation_log_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_acc_violation_log_status_t f;
} mp2_smnif_acc_violation_log_status_u;


/*
 * MP2_SMNIF_LPBK_WR_VIOL_ADDR struct
 */

#define MP2_SMNIF_LPBK_WR_VIOL_ADDR_REG_SIZE 32
#define MP2_SMNIF_LPBK_WR_VIOL_ADDR_AXI_ADDR_SIZE 32

#define MP2_SMNIF_LPBK_WR_VIOL_ADDR_AXI_ADDR_SHIFT 0

#define MP2_SMNIF_LPBK_WR_VIOL_ADDR_AXI_ADDR_MASK 0xffffffff

#define MP2_SMNIF_LPBK_WR_VIOL_ADDR_MASK \
     (MP2_SMNIF_LPBK_WR_VIOL_ADDR_AXI_ADDR_MASK)

#define MP2_SMNIF_LPBK_WR_VIOL_ADDR_DEFAULT 0x00000000

#define MP2_SMNIF_LPBK_WR_VIOL_ADDR_GET_AXI_ADDR(mp2_smnif_lpbk_wr_viol_addr) \
     ((mp2_smnif_lpbk_wr_viol_addr & MP2_SMNIF_LPBK_WR_VIOL_ADDR_AXI_ADDR_MASK) >> MP2_SMNIF_LPBK_WR_VIOL_ADDR_AXI_ADDR_SHIFT)

#define MP2_SMNIF_LPBK_WR_VIOL_ADDR_SET_AXI_ADDR(mp2_smnif_lpbk_wr_viol_addr_reg, axi_addr) \
     mp2_smnif_lpbk_wr_viol_addr_reg = (mp2_smnif_lpbk_wr_viol_addr_reg & ~MP2_SMNIF_LPBK_WR_VIOL_ADDR_AXI_ADDR_MASK) | (axi_addr << MP2_SMNIF_LPBK_WR_VIOL_ADDR_AXI_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_lpbk_wr_viol_addr_t {
          unsigned int axi_addr                       : MP2_SMNIF_LPBK_WR_VIOL_ADDR_AXI_ADDR_SIZE;
     } mp2_smnif_lpbk_wr_viol_addr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_lpbk_wr_viol_addr_t {
          unsigned int axi_addr                       : MP2_SMNIF_LPBK_WR_VIOL_ADDR_AXI_ADDR_SIZE;
     } mp2_smnif_lpbk_wr_viol_addr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_lpbk_wr_viol_addr_t f;
} mp2_smnif_lpbk_wr_viol_addr_u;


/*
 * MP2_SMNIF_LPBK_WR_VIOL_STATUS struct
 */

#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_REG_SIZE 32
#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_DET_SIZE 1
#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_CLEAR_SIZE 1
#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_AXI_ID_SIZE 21
#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_AXI_PROT_SIZE 3

#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_DET_SHIFT 0
#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_CLEAR_SHIFT 3
#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_AXI_ID_SHIFT 8
#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_AXI_PROT_SHIFT 29

#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_DET_MASK 0x1
#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_CLEAR_MASK 0x8
#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_AXI_ID_MASK 0x1fffff00
#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_AXI_PROT_MASK 0xe0000000

#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_MASK \
     (MP2_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_DET_MASK | \
      MP2_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_CLEAR_MASK | \
      MP2_SMNIF_LPBK_WR_VIOL_STATUS_AXI_ID_MASK | \
      MP2_SMNIF_LPBK_WR_VIOL_STATUS_AXI_PROT_MASK)

#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_DEFAULT 0x00000000

#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_GET_VIOL_DET(mp2_smnif_lpbk_wr_viol_status) \
     ((mp2_smnif_lpbk_wr_viol_status & MP2_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_DET_MASK) >> MP2_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_DET_SHIFT)
#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_GET_VIOL_CLEAR(mp2_smnif_lpbk_wr_viol_status) \
     ((mp2_smnif_lpbk_wr_viol_status & MP2_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_CLEAR_MASK) >> MP2_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_CLEAR_SHIFT)
#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_GET_AXI_ID(mp2_smnif_lpbk_wr_viol_status) \
     ((mp2_smnif_lpbk_wr_viol_status & MP2_SMNIF_LPBK_WR_VIOL_STATUS_AXI_ID_MASK) >> MP2_SMNIF_LPBK_WR_VIOL_STATUS_AXI_ID_SHIFT)
#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_GET_AXI_PROT(mp2_smnif_lpbk_wr_viol_status) \
     ((mp2_smnif_lpbk_wr_viol_status & MP2_SMNIF_LPBK_WR_VIOL_STATUS_AXI_PROT_MASK) >> MP2_SMNIF_LPBK_WR_VIOL_STATUS_AXI_PROT_SHIFT)

#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_SET_VIOL_DET(mp2_smnif_lpbk_wr_viol_status_reg, viol_det) \
     mp2_smnif_lpbk_wr_viol_status_reg = (mp2_smnif_lpbk_wr_viol_status_reg & ~MP2_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_DET_MASK) | (viol_det << MP2_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_DET_SHIFT)
#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_SET_VIOL_CLEAR(mp2_smnif_lpbk_wr_viol_status_reg, viol_clear) \
     mp2_smnif_lpbk_wr_viol_status_reg = (mp2_smnif_lpbk_wr_viol_status_reg & ~MP2_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_CLEAR_MASK) | (viol_clear << MP2_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_CLEAR_SHIFT)
#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_SET_AXI_ID(mp2_smnif_lpbk_wr_viol_status_reg, axi_id) \
     mp2_smnif_lpbk_wr_viol_status_reg = (mp2_smnif_lpbk_wr_viol_status_reg & ~MP2_SMNIF_LPBK_WR_VIOL_STATUS_AXI_ID_MASK) | (axi_id << MP2_SMNIF_LPBK_WR_VIOL_STATUS_AXI_ID_SHIFT)
#define MP2_SMNIF_LPBK_WR_VIOL_STATUS_SET_AXI_PROT(mp2_smnif_lpbk_wr_viol_status_reg, axi_prot) \
     mp2_smnif_lpbk_wr_viol_status_reg = (mp2_smnif_lpbk_wr_viol_status_reg & ~MP2_SMNIF_LPBK_WR_VIOL_STATUS_AXI_PROT_MASK) | (axi_prot << MP2_SMNIF_LPBK_WR_VIOL_STATUS_AXI_PROT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_lpbk_wr_viol_status_t {
          unsigned int viol_det                       : MP2_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_DET_SIZE;
          unsigned int                                : 2;
          unsigned int viol_clear                     : MP2_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_CLEAR_SIZE;
          unsigned int                                : 4;
          unsigned int axi_id                         : MP2_SMNIF_LPBK_WR_VIOL_STATUS_AXI_ID_SIZE;
          unsigned int axi_prot                       : MP2_SMNIF_LPBK_WR_VIOL_STATUS_AXI_PROT_SIZE;
     } mp2_smnif_lpbk_wr_viol_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_lpbk_wr_viol_status_t {
          unsigned int axi_prot                       : MP2_SMNIF_LPBK_WR_VIOL_STATUS_AXI_PROT_SIZE;
          unsigned int axi_id                         : MP2_SMNIF_LPBK_WR_VIOL_STATUS_AXI_ID_SIZE;
          unsigned int                                : 4;
          unsigned int viol_clear                     : MP2_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_CLEAR_SIZE;
          unsigned int                                : 2;
          unsigned int viol_det                       : MP2_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_DET_SIZE;
     } mp2_smnif_lpbk_wr_viol_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_lpbk_wr_viol_status_t f;
} mp2_smnif_lpbk_wr_viol_status_u;


/*
 * MP2_SMNIF_LPBK_RD_VIOL_ADDR struct
 */

#define MP2_SMNIF_LPBK_RD_VIOL_ADDR_REG_SIZE 32
#define MP2_SMNIF_LPBK_RD_VIOL_ADDR_AXI_ADDR_SIZE 32

#define MP2_SMNIF_LPBK_RD_VIOL_ADDR_AXI_ADDR_SHIFT 0

#define MP2_SMNIF_LPBK_RD_VIOL_ADDR_AXI_ADDR_MASK 0xffffffff

#define MP2_SMNIF_LPBK_RD_VIOL_ADDR_MASK \
     (MP2_SMNIF_LPBK_RD_VIOL_ADDR_AXI_ADDR_MASK)

#define MP2_SMNIF_LPBK_RD_VIOL_ADDR_DEFAULT 0x00000000

#define MP2_SMNIF_LPBK_RD_VIOL_ADDR_GET_AXI_ADDR(mp2_smnif_lpbk_rd_viol_addr) \
     ((mp2_smnif_lpbk_rd_viol_addr & MP2_SMNIF_LPBK_RD_VIOL_ADDR_AXI_ADDR_MASK) >> MP2_SMNIF_LPBK_RD_VIOL_ADDR_AXI_ADDR_SHIFT)

#define MP2_SMNIF_LPBK_RD_VIOL_ADDR_SET_AXI_ADDR(mp2_smnif_lpbk_rd_viol_addr_reg, axi_addr) \
     mp2_smnif_lpbk_rd_viol_addr_reg = (mp2_smnif_lpbk_rd_viol_addr_reg & ~MP2_SMNIF_LPBK_RD_VIOL_ADDR_AXI_ADDR_MASK) | (axi_addr << MP2_SMNIF_LPBK_RD_VIOL_ADDR_AXI_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_lpbk_rd_viol_addr_t {
          unsigned int axi_addr                       : MP2_SMNIF_LPBK_RD_VIOL_ADDR_AXI_ADDR_SIZE;
     } mp2_smnif_lpbk_rd_viol_addr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_lpbk_rd_viol_addr_t {
          unsigned int axi_addr                       : MP2_SMNIF_LPBK_RD_VIOL_ADDR_AXI_ADDR_SIZE;
     } mp2_smnif_lpbk_rd_viol_addr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_lpbk_rd_viol_addr_t f;
} mp2_smnif_lpbk_rd_viol_addr_u;


/*
 * MP2_SMNIF_LPBK_RD_VIOL_STATUS struct
 */

#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_REG_SIZE 32
#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_DET_SIZE 1
#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_CLEAR_SIZE 1
#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_AXI_ID_SIZE 21
#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_AXI_PROT_SIZE 3

#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_DET_SHIFT 0
#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_CLEAR_SHIFT 3
#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_AXI_ID_SHIFT 8
#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_AXI_PROT_SHIFT 29

#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_DET_MASK 0x1
#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_CLEAR_MASK 0x8
#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_AXI_ID_MASK 0x1fffff00
#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_AXI_PROT_MASK 0xe0000000

#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_MASK \
     (MP2_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_DET_MASK | \
      MP2_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_CLEAR_MASK | \
      MP2_SMNIF_LPBK_RD_VIOL_STATUS_AXI_ID_MASK | \
      MP2_SMNIF_LPBK_RD_VIOL_STATUS_AXI_PROT_MASK)

#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_DEFAULT 0x00000000

#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_GET_VIOL_DET(mp2_smnif_lpbk_rd_viol_status) \
     ((mp2_smnif_lpbk_rd_viol_status & MP2_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_DET_MASK) >> MP2_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_DET_SHIFT)
#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_GET_VIOL_CLEAR(mp2_smnif_lpbk_rd_viol_status) \
     ((mp2_smnif_lpbk_rd_viol_status & MP2_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_CLEAR_MASK) >> MP2_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_CLEAR_SHIFT)
#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_GET_AXI_ID(mp2_smnif_lpbk_rd_viol_status) \
     ((mp2_smnif_lpbk_rd_viol_status & MP2_SMNIF_LPBK_RD_VIOL_STATUS_AXI_ID_MASK) >> MP2_SMNIF_LPBK_RD_VIOL_STATUS_AXI_ID_SHIFT)
#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_GET_AXI_PROT(mp2_smnif_lpbk_rd_viol_status) \
     ((mp2_smnif_lpbk_rd_viol_status & MP2_SMNIF_LPBK_RD_VIOL_STATUS_AXI_PROT_MASK) >> MP2_SMNIF_LPBK_RD_VIOL_STATUS_AXI_PROT_SHIFT)

#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_SET_VIOL_DET(mp2_smnif_lpbk_rd_viol_status_reg, viol_det) \
     mp2_smnif_lpbk_rd_viol_status_reg = (mp2_smnif_lpbk_rd_viol_status_reg & ~MP2_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_DET_MASK) | (viol_det << MP2_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_DET_SHIFT)
#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_SET_VIOL_CLEAR(mp2_smnif_lpbk_rd_viol_status_reg, viol_clear) \
     mp2_smnif_lpbk_rd_viol_status_reg = (mp2_smnif_lpbk_rd_viol_status_reg & ~MP2_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_CLEAR_MASK) | (viol_clear << MP2_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_CLEAR_SHIFT)
#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_SET_AXI_ID(mp2_smnif_lpbk_rd_viol_status_reg, axi_id) \
     mp2_smnif_lpbk_rd_viol_status_reg = (mp2_smnif_lpbk_rd_viol_status_reg & ~MP2_SMNIF_LPBK_RD_VIOL_STATUS_AXI_ID_MASK) | (axi_id << MP2_SMNIF_LPBK_RD_VIOL_STATUS_AXI_ID_SHIFT)
#define MP2_SMNIF_LPBK_RD_VIOL_STATUS_SET_AXI_PROT(mp2_smnif_lpbk_rd_viol_status_reg, axi_prot) \
     mp2_smnif_lpbk_rd_viol_status_reg = (mp2_smnif_lpbk_rd_viol_status_reg & ~MP2_SMNIF_LPBK_RD_VIOL_STATUS_AXI_PROT_MASK) | (axi_prot << MP2_SMNIF_LPBK_RD_VIOL_STATUS_AXI_PROT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_lpbk_rd_viol_status_t {
          unsigned int viol_det                       : MP2_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_DET_SIZE;
          unsigned int                                : 2;
          unsigned int viol_clear                     : MP2_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_CLEAR_SIZE;
          unsigned int                                : 4;
          unsigned int axi_id                         : MP2_SMNIF_LPBK_RD_VIOL_STATUS_AXI_ID_SIZE;
          unsigned int axi_prot                       : MP2_SMNIF_LPBK_RD_VIOL_STATUS_AXI_PROT_SIZE;
     } mp2_smnif_lpbk_rd_viol_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_lpbk_rd_viol_status_t {
          unsigned int axi_prot                       : MP2_SMNIF_LPBK_RD_VIOL_STATUS_AXI_PROT_SIZE;
          unsigned int axi_id                         : MP2_SMNIF_LPBK_RD_VIOL_STATUS_AXI_ID_SIZE;
          unsigned int                                : 4;
          unsigned int viol_clear                     : MP2_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_CLEAR_SIZE;
          unsigned int                                : 2;
          unsigned int viol_det                       : MP2_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_DET_SIZE;
     } mp2_smnif_lpbk_rd_viol_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_lpbk_rd_viol_status_t f;
} mp2_smnif_lpbk_rd_viol_status_u;


/*
 * MP2_SMNIF_MISC_CTRL struct
 */

#define MP2_SMNIF_MISC_CTRL_REG_SIZE   32
#define MP2_SMNIF_MISC_CTRL_CLK_GATE_EN_SIZE 1
#define MP2_SMNIF_MISC_CTRL_POSTED_WRITE_ENABLE_SIZE 1
#define MP2_SMNIF_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SIZE 1
#define MP2_SMNIF_MISC_CTRL_WRITE_REQ_CNT_EN_SIZE 1
#define MP2_SMNIF_MISC_CTRL_READ_REQ_CNT_EN_SIZE 1

#define MP2_SMNIF_MISC_CTRL_CLK_GATE_EN_SHIFT 0
#define MP2_SMNIF_MISC_CTRL_POSTED_WRITE_ENABLE_SHIFT 16
#define MP2_SMNIF_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SHIFT 17
#define MP2_SMNIF_MISC_CTRL_WRITE_REQ_CNT_EN_SHIFT 18
#define MP2_SMNIF_MISC_CTRL_READ_REQ_CNT_EN_SHIFT 19

#define MP2_SMNIF_MISC_CTRL_CLK_GATE_EN_MASK 0x1
#define MP2_SMNIF_MISC_CTRL_POSTED_WRITE_ENABLE_MASK 0x10000
#define MP2_SMNIF_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK 0x20000
#define MP2_SMNIF_MISC_CTRL_WRITE_REQ_CNT_EN_MASK 0x40000
#define MP2_SMNIF_MISC_CTRL_READ_REQ_CNT_EN_MASK 0x80000

#define MP2_SMNIF_MISC_CTRL_MASK \
     (MP2_SMNIF_MISC_CTRL_CLK_GATE_EN_MASK | \
      MP2_SMNIF_MISC_CTRL_POSTED_WRITE_ENABLE_MASK | \
      MP2_SMNIF_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK | \
      MP2_SMNIF_MISC_CTRL_WRITE_REQ_CNT_EN_MASK | \
      MP2_SMNIF_MISC_CTRL_READ_REQ_CNT_EN_MASK)

#define MP2_SMNIF_MISC_CTRL_DEFAULT    0x00020001

#define MP2_SMNIF_MISC_CTRL_GET_CLK_GATE_EN(mp2_smnif_misc_ctrl) \
     ((mp2_smnif_misc_ctrl & MP2_SMNIF_MISC_CTRL_CLK_GATE_EN_MASK) >> MP2_SMNIF_MISC_CTRL_CLK_GATE_EN_SHIFT)
#define MP2_SMNIF_MISC_CTRL_GET_POSTED_WRITE_ENABLE(mp2_smnif_misc_ctrl) \
     ((mp2_smnif_misc_ctrl & MP2_SMNIF_MISC_CTRL_POSTED_WRITE_ENABLE_MASK) >> MP2_SMNIF_MISC_CTRL_POSTED_WRITE_ENABLE_SHIFT)
#define MP2_SMNIF_MISC_CTRL_GET_ALLOW_NON_PRIV_REG_ACC(mp2_smnif_misc_ctrl) \
     ((mp2_smnif_misc_ctrl & MP2_SMNIF_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK) >> MP2_SMNIF_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SHIFT)
#define MP2_SMNIF_MISC_CTRL_GET_WRITE_REQ_CNT_EN(mp2_smnif_misc_ctrl) \
     ((mp2_smnif_misc_ctrl & MP2_SMNIF_MISC_CTRL_WRITE_REQ_CNT_EN_MASK) >> MP2_SMNIF_MISC_CTRL_WRITE_REQ_CNT_EN_SHIFT)
#define MP2_SMNIF_MISC_CTRL_GET_READ_REQ_CNT_EN(mp2_smnif_misc_ctrl) \
     ((mp2_smnif_misc_ctrl & MP2_SMNIF_MISC_CTRL_READ_REQ_CNT_EN_MASK) >> MP2_SMNIF_MISC_CTRL_READ_REQ_CNT_EN_SHIFT)

#define MP2_SMNIF_MISC_CTRL_SET_CLK_GATE_EN(mp2_smnif_misc_ctrl_reg, clk_gate_en) \
     mp2_smnif_misc_ctrl_reg = (mp2_smnif_misc_ctrl_reg & ~MP2_SMNIF_MISC_CTRL_CLK_GATE_EN_MASK) | (clk_gate_en << MP2_SMNIF_MISC_CTRL_CLK_GATE_EN_SHIFT)
#define MP2_SMNIF_MISC_CTRL_SET_POSTED_WRITE_ENABLE(mp2_smnif_misc_ctrl_reg, posted_write_enable) \
     mp2_smnif_misc_ctrl_reg = (mp2_smnif_misc_ctrl_reg & ~MP2_SMNIF_MISC_CTRL_POSTED_WRITE_ENABLE_MASK) | (posted_write_enable << MP2_SMNIF_MISC_CTRL_POSTED_WRITE_ENABLE_SHIFT)
#define MP2_SMNIF_MISC_CTRL_SET_ALLOW_NON_PRIV_REG_ACC(mp2_smnif_misc_ctrl_reg, allow_non_priv_reg_acc) \
     mp2_smnif_misc_ctrl_reg = (mp2_smnif_misc_ctrl_reg & ~MP2_SMNIF_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK) | (allow_non_priv_reg_acc << MP2_SMNIF_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SHIFT)
#define MP2_SMNIF_MISC_CTRL_SET_WRITE_REQ_CNT_EN(mp2_smnif_misc_ctrl_reg, write_req_cnt_en) \
     mp2_smnif_misc_ctrl_reg = (mp2_smnif_misc_ctrl_reg & ~MP2_SMNIF_MISC_CTRL_WRITE_REQ_CNT_EN_MASK) | (write_req_cnt_en << MP2_SMNIF_MISC_CTRL_WRITE_REQ_CNT_EN_SHIFT)
#define MP2_SMNIF_MISC_CTRL_SET_READ_REQ_CNT_EN(mp2_smnif_misc_ctrl_reg, read_req_cnt_en) \
     mp2_smnif_misc_ctrl_reg = (mp2_smnif_misc_ctrl_reg & ~MP2_SMNIF_MISC_CTRL_READ_REQ_CNT_EN_MASK) | (read_req_cnt_en << MP2_SMNIF_MISC_CTRL_READ_REQ_CNT_EN_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_misc_ctrl_t {
          unsigned int clk_gate_en                    : MP2_SMNIF_MISC_CTRL_CLK_GATE_EN_SIZE;
          unsigned int                                : 15;
          unsigned int posted_write_enable            : MP2_SMNIF_MISC_CTRL_POSTED_WRITE_ENABLE_SIZE;
          unsigned int allow_non_priv_reg_acc         : MP2_SMNIF_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SIZE;
          unsigned int write_req_cnt_en               : MP2_SMNIF_MISC_CTRL_WRITE_REQ_CNT_EN_SIZE;
          unsigned int read_req_cnt_en                : MP2_SMNIF_MISC_CTRL_READ_REQ_CNT_EN_SIZE;
          unsigned int                                : 12;
     } mp2_smnif_misc_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_misc_ctrl_t {
          unsigned int                                : 12;
          unsigned int read_req_cnt_en                : MP2_SMNIF_MISC_CTRL_READ_REQ_CNT_EN_SIZE;
          unsigned int write_req_cnt_en               : MP2_SMNIF_MISC_CTRL_WRITE_REQ_CNT_EN_SIZE;
          unsigned int allow_non_priv_reg_acc         : MP2_SMNIF_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SIZE;
          unsigned int posted_write_enable            : MP2_SMNIF_MISC_CTRL_POSTED_WRITE_ENABLE_SIZE;
          unsigned int                                : 15;
          unsigned int clk_gate_en                    : MP2_SMNIF_MISC_CTRL_CLK_GATE_EN_SIZE;
     } mp2_smnif_misc_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_misc_ctrl_t f;
} mp2_smnif_misc_ctrl_u;


/*
 * MP2_SMNIF_REQ_CNT struct
 */

#define MP2_SMNIF_REQ_CNT_REG_SIZE     32
#define MP2_SMNIF_REQ_CNT_WRITE_REQ_CNT_SIZE 8
#define MP2_SMNIF_REQ_CNT_READ_REQ_CNT_SIZE 8

#define MP2_SMNIF_REQ_CNT_WRITE_REQ_CNT_SHIFT 0
#define MP2_SMNIF_REQ_CNT_READ_REQ_CNT_SHIFT 8

#define MP2_SMNIF_REQ_CNT_WRITE_REQ_CNT_MASK 0xff
#define MP2_SMNIF_REQ_CNT_READ_REQ_CNT_MASK 0xff00

#define MP2_SMNIF_REQ_CNT_MASK \
     (MP2_SMNIF_REQ_CNT_WRITE_REQ_CNT_MASK | \
      MP2_SMNIF_REQ_CNT_READ_REQ_CNT_MASK)

#define MP2_SMNIF_REQ_CNT_DEFAULT      0x00000000

#define MP2_SMNIF_REQ_CNT_GET_WRITE_REQ_CNT(mp2_smnif_req_cnt) \
     ((mp2_smnif_req_cnt & MP2_SMNIF_REQ_CNT_WRITE_REQ_CNT_MASK) >> MP2_SMNIF_REQ_CNT_WRITE_REQ_CNT_SHIFT)
#define MP2_SMNIF_REQ_CNT_GET_READ_REQ_CNT(mp2_smnif_req_cnt) \
     ((mp2_smnif_req_cnt & MP2_SMNIF_REQ_CNT_READ_REQ_CNT_MASK) >> MP2_SMNIF_REQ_CNT_READ_REQ_CNT_SHIFT)

#define MP2_SMNIF_REQ_CNT_SET_WRITE_REQ_CNT(mp2_smnif_req_cnt_reg, write_req_cnt) \
     mp2_smnif_req_cnt_reg = (mp2_smnif_req_cnt_reg & ~MP2_SMNIF_REQ_CNT_WRITE_REQ_CNT_MASK) | (write_req_cnt << MP2_SMNIF_REQ_CNT_WRITE_REQ_CNT_SHIFT)
#define MP2_SMNIF_REQ_CNT_SET_READ_REQ_CNT(mp2_smnif_req_cnt_reg, read_req_cnt) \
     mp2_smnif_req_cnt_reg = (mp2_smnif_req_cnt_reg & ~MP2_SMNIF_REQ_CNT_READ_REQ_CNT_MASK) | (read_req_cnt << MP2_SMNIF_REQ_CNT_READ_REQ_CNT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_req_cnt_t {
          unsigned int write_req_cnt                  : MP2_SMNIF_REQ_CNT_WRITE_REQ_CNT_SIZE;
          unsigned int read_req_cnt                   : MP2_SMNIF_REQ_CNT_READ_REQ_CNT_SIZE;
          unsigned int                                : 16;
     } mp2_smnif_req_cnt_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_req_cnt_t {
          unsigned int                                : 16;
          unsigned int read_req_cnt                   : MP2_SMNIF_REQ_CNT_READ_REQ_CNT_SIZE;
          unsigned int write_req_cnt                  : MP2_SMNIF_REQ_CNT_WRITE_REQ_CNT_SIZE;
     } mp2_smnif_req_cnt_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_req_cnt_t f;
} mp2_smnif_req_cnt_u;


/*
 * MP2_SMNIF_SCRATCH0 struct
 */

#define MP2_SMNIF_SCRATCH0_REG_SIZE    32
#define MP2_SMNIF_SCRATCH0_DATA_SIZE   32

#define MP2_SMNIF_SCRATCH0_DATA_SHIFT  0

#define MP2_SMNIF_SCRATCH0_DATA_MASK   0xffffffff

#define MP2_SMNIF_SCRATCH0_MASK \
     (MP2_SMNIF_SCRATCH0_DATA_MASK)

#define MP2_SMNIF_SCRATCH0_DEFAULT     0x00000000

#define MP2_SMNIF_SCRATCH0_GET_DATA(mp2_smnif_scratch0) \
     ((mp2_smnif_scratch0 & MP2_SMNIF_SCRATCH0_DATA_MASK) >> MP2_SMNIF_SCRATCH0_DATA_SHIFT)

#define MP2_SMNIF_SCRATCH0_SET_DATA(mp2_smnif_scratch0_reg, data) \
     mp2_smnif_scratch0_reg = (mp2_smnif_scratch0_reg & ~MP2_SMNIF_SCRATCH0_DATA_MASK) | (data << MP2_SMNIF_SCRATCH0_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_scratch0_t {
          unsigned int data                           : MP2_SMNIF_SCRATCH0_DATA_SIZE;
     } mp2_smnif_scratch0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_scratch0_t {
          unsigned int data                           : MP2_SMNIF_SCRATCH0_DATA_SIZE;
     } mp2_smnif_scratch0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_scratch0_t f;
} mp2_smnif_scratch0_u;


/*
 * MP2_SMNIF_SCRATCH1 struct
 */

#define MP2_SMNIF_SCRATCH1_REG_SIZE    32
#define MP2_SMNIF_SCRATCH1_DATA_SIZE   32

#define MP2_SMNIF_SCRATCH1_DATA_SHIFT  0

#define MP2_SMNIF_SCRATCH1_DATA_MASK   0xffffffff

#define MP2_SMNIF_SCRATCH1_MASK \
     (MP2_SMNIF_SCRATCH1_DATA_MASK)

#define MP2_SMNIF_SCRATCH1_DEFAULT     0x00000000

#define MP2_SMNIF_SCRATCH1_GET_DATA(mp2_smnif_scratch1) \
     ((mp2_smnif_scratch1 & MP2_SMNIF_SCRATCH1_DATA_MASK) >> MP2_SMNIF_SCRATCH1_DATA_SHIFT)

#define MP2_SMNIF_SCRATCH1_SET_DATA(mp2_smnif_scratch1_reg, data) \
     mp2_smnif_scratch1_reg = (mp2_smnif_scratch1_reg & ~MP2_SMNIF_SCRATCH1_DATA_MASK) | (data << MP2_SMNIF_SCRATCH1_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_scratch1_t {
          unsigned int data                           : MP2_SMNIF_SCRATCH1_DATA_SIZE;
     } mp2_smnif_scratch1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_scratch1_t {
          unsigned int data                           : MP2_SMNIF_SCRATCH1_DATA_SIZE;
     } mp2_smnif_scratch1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_scratch1_t f;
} mp2_smnif_scratch1_u;


/*
 * MP2_SMNIF_SCRATCH2 struct
 */

#define MP2_SMNIF_SCRATCH2_REG_SIZE    32
#define MP2_SMNIF_SCRATCH2_DATA_SIZE   32

#define MP2_SMNIF_SCRATCH2_DATA_SHIFT  0

#define MP2_SMNIF_SCRATCH2_DATA_MASK   0xffffffff

#define MP2_SMNIF_SCRATCH2_MASK \
     (MP2_SMNIF_SCRATCH2_DATA_MASK)

#define MP2_SMNIF_SCRATCH2_DEFAULT     0x00000000

#define MP2_SMNIF_SCRATCH2_GET_DATA(mp2_smnif_scratch2) \
     ((mp2_smnif_scratch2 & MP2_SMNIF_SCRATCH2_DATA_MASK) >> MP2_SMNIF_SCRATCH2_DATA_SHIFT)

#define MP2_SMNIF_SCRATCH2_SET_DATA(mp2_smnif_scratch2_reg, data) \
     mp2_smnif_scratch2_reg = (mp2_smnif_scratch2_reg & ~MP2_SMNIF_SCRATCH2_DATA_MASK) | (data << MP2_SMNIF_SCRATCH2_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_scratch2_t {
          unsigned int data                           : MP2_SMNIF_SCRATCH2_DATA_SIZE;
     } mp2_smnif_scratch2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_scratch2_t {
          unsigned int data                           : MP2_SMNIF_SCRATCH2_DATA_SIZE;
     } mp2_smnif_scratch2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_scratch2_t f;
} mp2_smnif_scratch2_u;


/*
 * MP2_SMNIF_SCRATCH3 struct
 */

#define MP2_SMNIF_SCRATCH3_REG_SIZE    32
#define MP2_SMNIF_SCRATCH3_DATA_SIZE   32

#define MP2_SMNIF_SCRATCH3_DATA_SHIFT  0

#define MP2_SMNIF_SCRATCH3_DATA_MASK   0xffffffff

#define MP2_SMNIF_SCRATCH3_MASK \
     (MP2_SMNIF_SCRATCH3_DATA_MASK)

#define MP2_SMNIF_SCRATCH3_DEFAULT     0x00000000

#define MP2_SMNIF_SCRATCH3_GET_DATA(mp2_smnif_scratch3) \
     ((mp2_smnif_scratch3 & MP2_SMNIF_SCRATCH3_DATA_MASK) >> MP2_SMNIF_SCRATCH3_DATA_SHIFT)

#define MP2_SMNIF_SCRATCH3_SET_DATA(mp2_smnif_scratch3_reg, data) \
     mp2_smnif_scratch3_reg = (mp2_smnif_scratch3_reg & ~MP2_SMNIF_SCRATCH3_DATA_MASK) | (data << MP2_SMNIF_SCRATCH3_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_scratch3_t {
          unsigned int data                           : MP2_SMNIF_SCRATCH3_DATA_SIZE;
     } mp2_smnif_scratch3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_scratch3_t {
          unsigned int data                           : MP2_SMNIF_SCRATCH3_DATA_SIZE;
     } mp2_smnif_scratch3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_scratch3_t f;
} mp2_smnif_scratch3_u;


/*
 * MP2_SMNIF_AXI_RESP_MASK struct
 */

#define MP2_SMNIF_AXI_RESP_MASK_REG_SIZE 32
#define MP2_SMNIF_AXI_RESP_MASK_MASK_RRESP_ERROR_SIZE 1
#define MP2_SMNIF_AXI_RESP_MASK_MASK_BRESP_ERROR_SIZE 1

#define MP2_SMNIF_AXI_RESP_MASK_MASK_RRESP_ERROR_SHIFT 0
#define MP2_SMNIF_AXI_RESP_MASK_MASK_BRESP_ERROR_SHIFT 1

#define MP2_SMNIF_AXI_RESP_MASK_MASK_RRESP_ERROR_MASK 0x1
#define MP2_SMNIF_AXI_RESP_MASK_MASK_BRESP_ERROR_MASK 0x2

#define MP2_SMNIF_AXI_RESP_MASK_MASK \
     (MP2_SMNIF_AXI_RESP_MASK_MASK_RRESP_ERROR_MASK | \
      MP2_SMNIF_AXI_RESP_MASK_MASK_BRESP_ERROR_MASK)

#define MP2_SMNIF_AXI_RESP_MASK_DEFAULT 0x00000000

#define MP2_SMNIF_AXI_RESP_MASK_GET_MASK_RRESP_ERROR(mp2_smnif_axi_resp_mask) \
     ((mp2_smnif_axi_resp_mask & MP2_SMNIF_AXI_RESP_MASK_MASK_RRESP_ERROR_MASK) >> MP2_SMNIF_AXI_RESP_MASK_MASK_RRESP_ERROR_SHIFT)
#define MP2_SMNIF_AXI_RESP_MASK_GET_MASK_BRESP_ERROR(mp2_smnif_axi_resp_mask) \
     ((mp2_smnif_axi_resp_mask & MP2_SMNIF_AXI_RESP_MASK_MASK_BRESP_ERROR_MASK) >> MP2_SMNIF_AXI_RESP_MASK_MASK_BRESP_ERROR_SHIFT)

#define MP2_SMNIF_AXI_RESP_MASK_SET_MASK_RRESP_ERROR(mp2_smnif_axi_resp_mask_reg, mask_rresp_error) \
     mp2_smnif_axi_resp_mask_reg = (mp2_smnif_axi_resp_mask_reg & ~MP2_SMNIF_AXI_RESP_MASK_MASK_RRESP_ERROR_MASK) | (mask_rresp_error << MP2_SMNIF_AXI_RESP_MASK_MASK_RRESP_ERROR_SHIFT)
#define MP2_SMNIF_AXI_RESP_MASK_SET_MASK_BRESP_ERROR(mp2_smnif_axi_resp_mask_reg, mask_bresp_error) \
     mp2_smnif_axi_resp_mask_reg = (mp2_smnif_axi_resp_mask_reg & ~MP2_SMNIF_AXI_RESP_MASK_MASK_BRESP_ERROR_MASK) | (mask_bresp_error << MP2_SMNIF_AXI_RESP_MASK_MASK_BRESP_ERROR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_axi_resp_mask_t {
          unsigned int mask_rresp_error               : MP2_SMNIF_AXI_RESP_MASK_MASK_RRESP_ERROR_SIZE;
          unsigned int mask_bresp_error               : MP2_SMNIF_AXI_RESP_MASK_MASK_BRESP_ERROR_SIZE;
          unsigned int                                : 30;
     } mp2_smnif_axi_resp_mask_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_axi_resp_mask_t {
          unsigned int                                : 30;
          unsigned int mask_bresp_error               : MP2_SMNIF_AXI_RESP_MASK_MASK_BRESP_ERROR_SIZE;
          unsigned int mask_rresp_error               : MP2_SMNIF_AXI_RESP_MASK_MASK_RRESP_ERROR_SIZE;
     } mp2_smnif_axi_resp_mask_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_axi_resp_mask_t f;
} mp2_smnif_axi_resp_mask_u;


/*
 * MP2_SMNIF_AXI_WRITE_ERROR_COUNTER struct
 */

#define MP2_SMNIF_AXI_WRITE_ERROR_COUNTER_REG_SIZE 32
#define MP2_SMNIF_AXI_WRITE_ERROR_COUNTER_SMNIF_AXI_WRITE_ERROR_COUNTER_SIZE 32

#define MP2_SMNIF_AXI_WRITE_ERROR_COUNTER_SMNIF_AXI_WRITE_ERROR_COUNTER_SHIFT 0

#define MP2_SMNIF_AXI_WRITE_ERROR_COUNTER_SMNIF_AXI_WRITE_ERROR_COUNTER_MASK 0xffffffff

#define MP2_SMNIF_AXI_WRITE_ERROR_COUNTER_MASK \
     (MP2_SMNIF_AXI_WRITE_ERROR_COUNTER_SMNIF_AXI_WRITE_ERROR_COUNTER_MASK)

#define MP2_SMNIF_AXI_WRITE_ERROR_COUNTER_DEFAULT 0x00000000

#define MP2_SMNIF_AXI_WRITE_ERROR_COUNTER_GET_SMNIF_AXI_WRITE_ERROR_COUNTER(mp2_smnif_axi_write_error_counter) \
     ((mp2_smnif_axi_write_error_counter & MP2_SMNIF_AXI_WRITE_ERROR_COUNTER_SMNIF_AXI_WRITE_ERROR_COUNTER_MASK) >> MP2_SMNIF_AXI_WRITE_ERROR_COUNTER_SMNIF_AXI_WRITE_ERROR_COUNTER_SHIFT)

#define MP2_SMNIF_AXI_WRITE_ERROR_COUNTER_SET_SMNIF_AXI_WRITE_ERROR_COUNTER(mp2_smnif_axi_write_error_counter_reg, smnif_axi_write_error_counter) \
     mp2_smnif_axi_write_error_counter_reg = (mp2_smnif_axi_write_error_counter_reg & ~MP2_SMNIF_AXI_WRITE_ERROR_COUNTER_SMNIF_AXI_WRITE_ERROR_COUNTER_MASK) | (smnif_axi_write_error_counter << MP2_SMNIF_AXI_WRITE_ERROR_COUNTER_SMNIF_AXI_WRITE_ERROR_COUNTER_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_axi_write_error_counter_t {
          unsigned int smnif_axi_write_error_counter  : MP2_SMNIF_AXI_WRITE_ERROR_COUNTER_SMNIF_AXI_WRITE_ERROR_COUNTER_SIZE;
     } mp2_smnif_axi_write_error_counter_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_axi_write_error_counter_t {
          unsigned int smnif_axi_write_error_counter  : MP2_SMNIF_AXI_WRITE_ERROR_COUNTER_SMNIF_AXI_WRITE_ERROR_COUNTER_SIZE;
     } mp2_smnif_axi_write_error_counter_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_axi_write_error_counter_t f;
} mp2_smnif_axi_write_error_counter_u;


/*
 * MP2_SMNIF_AXI_READ_ERROR_COUNTER struct
 */

#define MP2_SMNIF_AXI_READ_ERROR_COUNTER_REG_SIZE 32
#define MP2_SMNIF_AXI_READ_ERROR_COUNTER_SMNIF_AXI_READ_ERROR_COUNTER_SIZE 32

#define MP2_SMNIF_AXI_READ_ERROR_COUNTER_SMNIF_AXI_READ_ERROR_COUNTER_SHIFT 0

#define MP2_SMNIF_AXI_READ_ERROR_COUNTER_SMNIF_AXI_READ_ERROR_COUNTER_MASK 0xffffffff

#define MP2_SMNIF_AXI_READ_ERROR_COUNTER_MASK \
     (MP2_SMNIF_AXI_READ_ERROR_COUNTER_SMNIF_AXI_READ_ERROR_COUNTER_MASK)

#define MP2_SMNIF_AXI_READ_ERROR_COUNTER_DEFAULT 0x00000000

#define MP2_SMNIF_AXI_READ_ERROR_COUNTER_GET_SMNIF_AXI_READ_ERROR_COUNTER(mp2_smnif_axi_read_error_counter) \
     ((mp2_smnif_axi_read_error_counter & MP2_SMNIF_AXI_READ_ERROR_COUNTER_SMNIF_AXI_READ_ERROR_COUNTER_MASK) >> MP2_SMNIF_AXI_READ_ERROR_COUNTER_SMNIF_AXI_READ_ERROR_COUNTER_SHIFT)

#define MP2_SMNIF_AXI_READ_ERROR_COUNTER_SET_SMNIF_AXI_READ_ERROR_COUNTER(mp2_smnif_axi_read_error_counter_reg, smnif_axi_read_error_counter) \
     mp2_smnif_axi_read_error_counter_reg = (mp2_smnif_axi_read_error_counter_reg & ~MP2_SMNIF_AXI_READ_ERROR_COUNTER_SMNIF_AXI_READ_ERROR_COUNTER_MASK) | (smnif_axi_read_error_counter << MP2_SMNIF_AXI_READ_ERROR_COUNTER_SMNIF_AXI_READ_ERROR_COUNTER_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_axi_read_error_counter_t {
          unsigned int smnif_axi_read_error_counter   : MP2_SMNIF_AXI_READ_ERROR_COUNTER_SMNIF_AXI_READ_ERROR_COUNTER_SIZE;
     } mp2_smnif_axi_read_error_counter_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_axi_read_error_counter_t {
          unsigned int smnif_axi_read_error_counter   : MP2_SMNIF_AXI_READ_ERROR_COUNTER_SMNIF_AXI_READ_ERROR_COUNTER_SIZE;
     } mp2_smnif_axi_read_error_counter_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_axi_read_error_counter_t f;
} mp2_smnif_axi_read_error_counter_u;


/*
 * MP2_SMNIF_TLB_AWCACHE struct
 */

#define MP2_SMNIF_TLB_AWCACHE_REG_SIZE 32
#define MP2_SMNIF_TLB_AWCACHE_AWCACHE_SIZE 32

#define MP2_SMNIF_TLB_AWCACHE_AWCACHE_SHIFT 0

#define MP2_SMNIF_TLB_AWCACHE_AWCACHE_MASK 0xffffffff

#define MP2_SMNIF_TLB_AWCACHE_MASK \
     (MP2_SMNIF_TLB_AWCACHE_AWCACHE_MASK)

#define MP2_SMNIF_TLB_AWCACHE_DEFAULT  0xffffffff

#define MP2_SMNIF_TLB_AWCACHE_GET_AWCACHE(mp2_smnif_tlb_awcache) \
     ((mp2_smnif_tlb_awcache & MP2_SMNIF_TLB_AWCACHE_AWCACHE_MASK) >> MP2_SMNIF_TLB_AWCACHE_AWCACHE_SHIFT)

#define MP2_SMNIF_TLB_AWCACHE_SET_AWCACHE(mp2_smnif_tlb_awcache_reg, awcache) \
     mp2_smnif_tlb_awcache_reg = (mp2_smnif_tlb_awcache_reg & ~MP2_SMNIF_TLB_AWCACHE_AWCACHE_MASK) | (awcache << MP2_SMNIF_TLB_AWCACHE_AWCACHE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_awcache_t {
          unsigned int awcache                        : MP2_SMNIF_TLB_AWCACHE_AWCACHE_SIZE;
     } mp2_smnif_tlb_awcache_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlb_awcache_t {
          unsigned int awcache                        : MP2_SMNIF_TLB_AWCACHE_AWCACHE_SIZE;
     } mp2_smnif_tlb_awcache_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlb_awcache_t f;
} mp2_smnif_tlb_awcache_u;


/*
 * MP2_SMNIF_SECURE_CTRL struct
 */

#define MP2_SMNIF_SECURE_CTRL_REG_SIZE 32
#define MP2_SMNIF_SECURE_CTRL_ALLOW_NONMP_SRAM_ACCESS_SIZE 1
#define MP2_SMNIF_SECURE_CTRL_BLOCK_SRAM_SPACE_SIZE 1
#define MP2_SMNIF_SECURE_CTRL_BLOCK_PRIV_SPACE_SIZE 1
#define MP2_SMNIF_SECURE_CTRL_ALLOW_RAM0_INITID_ACCESS_SIZE 1
#define MP2_SMNIF_SECURE_CTRL_ALLOW_NONMP_RAM1_ACCESS_SIZE 1
#define MP2_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_SIZE 1
#define MP2_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_STATUS_SIZE 1
#define MP2_SMNIF_SECURE_CTRL_BLOCK_OUTBOUND_ACCESS_SIZE 1
#define MP2_SMNIF_SECURE_CTRL_ALLOW_INBOUND_LIVMIN_ACCESS_SIZE 1

#define MP2_SMNIF_SECURE_CTRL_ALLOW_NONMP_SRAM_ACCESS_SHIFT 0
#define MP2_SMNIF_SECURE_CTRL_BLOCK_SRAM_SPACE_SHIFT 1
#define MP2_SMNIF_SECURE_CTRL_BLOCK_PRIV_SPACE_SHIFT 2
#define MP2_SMNIF_SECURE_CTRL_ALLOW_RAM0_INITID_ACCESS_SHIFT 6
#define MP2_SMNIF_SECURE_CTRL_ALLOW_NONMP_RAM1_ACCESS_SHIFT 7
#define MP2_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_SHIFT 15
#define MP2_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_STATUS_SHIFT 16
#define MP2_SMNIF_SECURE_CTRL_BLOCK_OUTBOUND_ACCESS_SHIFT 24
#define MP2_SMNIF_SECURE_CTRL_ALLOW_INBOUND_LIVMIN_ACCESS_SHIFT 31

#define MP2_SMNIF_SECURE_CTRL_ALLOW_NONMP_SRAM_ACCESS_MASK 0x1
#define MP2_SMNIF_SECURE_CTRL_BLOCK_SRAM_SPACE_MASK 0x2
#define MP2_SMNIF_SECURE_CTRL_BLOCK_PRIV_SPACE_MASK 0x4
#define MP2_SMNIF_SECURE_CTRL_ALLOW_RAM0_INITID_ACCESS_MASK 0x40
#define MP2_SMNIF_SECURE_CTRL_ALLOW_NONMP_RAM1_ACCESS_MASK 0x80
#define MP2_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_MASK 0x8000
#define MP2_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_STATUS_MASK 0x10000
#define MP2_SMNIF_SECURE_CTRL_BLOCK_OUTBOUND_ACCESS_MASK 0x1000000
#define MP2_SMNIF_SECURE_CTRL_ALLOW_INBOUND_LIVMIN_ACCESS_MASK 0x80000000

#define MP2_SMNIF_SECURE_CTRL_MASK \
     (MP2_SMNIF_SECURE_CTRL_ALLOW_NONMP_SRAM_ACCESS_MASK | \
      MP2_SMNIF_SECURE_CTRL_BLOCK_SRAM_SPACE_MASK | \
      MP2_SMNIF_SECURE_CTRL_BLOCK_PRIV_SPACE_MASK | \
      MP2_SMNIF_SECURE_CTRL_ALLOW_RAM0_INITID_ACCESS_MASK | \
      MP2_SMNIF_SECURE_CTRL_ALLOW_NONMP_RAM1_ACCESS_MASK | \
      MP2_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_MASK | \
      MP2_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_STATUS_MASK | \
      MP2_SMNIF_SECURE_CTRL_BLOCK_OUTBOUND_ACCESS_MASK | \
      MP2_SMNIF_SECURE_CTRL_ALLOW_INBOUND_LIVMIN_ACCESS_MASK)

#define MP2_SMNIF_SECURE_CTRL_DEFAULT  0x00000080

#define MP2_SMNIF_SECURE_CTRL_GET_ALLOW_NONMP_SRAM_ACCESS(mp2_smnif_secure_ctrl) \
     ((mp2_smnif_secure_ctrl & MP2_SMNIF_SECURE_CTRL_ALLOW_NONMP_SRAM_ACCESS_MASK) >> MP2_SMNIF_SECURE_CTRL_ALLOW_NONMP_SRAM_ACCESS_SHIFT)
#define MP2_SMNIF_SECURE_CTRL_GET_BLOCK_SRAM_SPACE(mp2_smnif_secure_ctrl) \
     ((mp2_smnif_secure_ctrl & MP2_SMNIF_SECURE_CTRL_BLOCK_SRAM_SPACE_MASK) >> MP2_SMNIF_SECURE_CTRL_BLOCK_SRAM_SPACE_SHIFT)
#define MP2_SMNIF_SECURE_CTRL_GET_BLOCK_PRIV_SPACE(mp2_smnif_secure_ctrl) \
     ((mp2_smnif_secure_ctrl & MP2_SMNIF_SECURE_CTRL_BLOCK_PRIV_SPACE_MASK) >> MP2_SMNIF_SECURE_CTRL_BLOCK_PRIV_SPACE_SHIFT)
#define MP2_SMNIF_SECURE_CTRL_GET_ALLOW_RAM0_INITID_ACCESS(mp2_smnif_secure_ctrl) \
     ((mp2_smnif_secure_ctrl & MP2_SMNIF_SECURE_CTRL_ALLOW_RAM0_INITID_ACCESS_MASK) >> MP2_SMNIF_SECURE_CTRL_ALLOW_RAM0_INITID_ACCESS_SHIFT)
#define MP2_SMNIF_SECURE_CTRL_GET_ALLOW_NONMP_RAM1_ACCESS(mp2_smnif_secure_ctrl) \
     ((mp2_smnif_secure_ctrl & MP2_SMNIF_SECURE_CTRL_ALLOW_NONMP_RAM1_ACCESS_MASK) >> MP2_SMNIF_SECURE_CTRL_ALLOW_NONMP_RAM1_ACCESS_SHIFT)
#define MP2_SMNIF_SECURE_CTRL_GET_LOCK_SMNIF_FENCE(mp2_smnif_secure_ctrl) \
     ((mp2_smnif_secure_ctrl & MP2_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_MASK) >> MP2_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_SHIFT)
#define MP2_SMNIF_SECURE_CTRL_GET_LOCK_SMNIF_FENCE_STATUS(mp2_smnif_secure_ctrl) \
     ((mp2_smnif_secure_ctrl & MP2_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_STATUS_MASK) >> MP2_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_STATUS_SHIFT)
#define MP2_SMNIF_SECURE_CTRL_GET_BLOCK_OUTBOUND_ACCESS(mp2_smnif_secure_ctrl) \
     ((mp2_smnif_secure_ctrl & MP2_SMNIF_SECURE_CTRL_BLOCK_OUTBOUND_ACCESS_MASK) >> MP2_SMNIF_SECURE_CTRL_BLOCK_OUTBOUND_ACCESS_SHIFT)
#define MP2_SMNIF_SECURE_CTRL_GET_ALLOW_INBOUND_LIVMIN_ACCESS(mp2_smnif_secure_ctrl) \
     ((mp2_smnif_secure_ctrl & MP2_SMNIF_SECURE_CTRL_ALLOW_INBOUND_LIVMIN_ACCESS_MASK) >> MP2_SMNIF_SECURE_CTRL_ALLOW_INBOUND_LIVMIN_ACCESS_SHIFT)

#define MP2_SMNIF_SECURE_CTRL_SET_ALLOW_NONMP_SRAM_ACCESS(mp2_smnif_secure_ctrl_reg, allow_nonmp_sram_access) \
     mp2_smnif_secure_ctrl_reg = (mp2_smnif_secure_ctrl_reg & ~MP2_SMNIF_SECURE_CTRL_ALLOW_NONMP_SRAM_ACCESS_MASK) | (allow_nonmp_sram_access << MP2_SMNIF_SECURE_CTRL_ALLOW_NONMP_SRAM_ACCESS_SHIFT)
#define MP2_SMNIF_SECURE_CTRL_SET_BLOCK_SRAM_SPACE(mp2_smnif_secure_ctrl_reg, block_sram_space) \
     mp2_smnif_secure_ctrl_reg = (mp2_smnif_secure_ctrl_reg & ~MP2_SMNIF_SECURE_CTRL_BLOCK_SRAM_SPACE_MASK) | (block_sram_space << MP2_SMNIF_SECURE_CTRL_BLOCK_SRAM_SPACE_SHIFT)
#define MP2_SMNIF_SECURE_CTRL_SET_BLOCK_PRIV_SPACE(mp2_smnif_secure_ctrl_reg, block_priv_space) \
     mp2_smnif_secure_ctrl_reg = (mp2_smnif_secure_ctrl_reg & ~MP2_SMNIF_SECURE_CTRL_BLOCK_PRIV_SPACE_MASK) | (block_priv_space << MP2_SMNIF_SECURE_CTRL_BLOCK_PRIV_SPACE_SHIFT)
#define MP2_SMNIF_SECURE_CTRL_SET_ALLOW_RAM0_INITID_ACCESS(mp2_smnif_secure_ctrl_reg, allow_ram0_initid_access) \
     mp2_smnif_secure_ctrl_reg = (mp2_smnif_secure_ctrl_reg & ~MP2_SMNIF_SECURE_CTRL_ALLOW_RAM0_INITID_ACCESS_MASK) | (allow_ram0_initid_access << MP2_SMNIF_SECURE_CTRL_ALLOW_RAM0_INITID_ACCESS_SHIFT)
#define MP2_SMNIF_SECURE_CTRL_SET_ALLOW_NONMP_RAM1_ACCESS(mp2_smnif_secure_ctrl_reg, allow_nonmp_ram1_access) \
     mp2_smnif_secure_ctrl_reg = (mp2_smnif_secure_ctrl_reg & ~MP2_SMNIF_SECURE_CTRL_ALLOW_NONMP_RAM1_ACCESS_MASK) | (allow_nonmp_ram1_access << MP2_SMNIF_SECURE_CTRL_ALLOW_NONMP_RAM1_ACCESS_SHIFT)
#define MP2_SMNIF_SECURE_CTRL_SET_LOCK_SMNIF_FENCE(mp2_smnif_secure_ctrl_reg, lock_smnif_fence) \
     mp2_smnif_secure_ctrl_reg = (mp2_smnif_secure_ctrl_reg & ~MP2_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_MASK) | (lock_smnif_fence << MP2_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_SHIFT)
#define MP2_SMNIF_SECURE_CTRL_SET_LOCK_SMNIF_FENCE_STATUS(mp2_smnif_secure_ctrl_reg, lock_smnif_fence_status) \
     mp2_smnif_secure_ctrl_reg = (mp2_smnif_secure_ctrl_reg & ~MP2_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_STATUS_MASK) | (lock_smnif_fence_status << MP2_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_STATUS_SHIFT)
#define MP2_SMNIF_SECURE_CTRL_SET_BLOCK_OUTBOUND_ACCESS(mp2_smnif_secure_ctrl_reg, block_outbound_access) \
     mp2_smnif_secure_ctrl_reg = (mp2_smnif_secure_ctrl_reg & ~MP2_SMNIF_SECURE_CTRL_BLOCK_OUTBOUND_ACCESS_MASK) | (block_outbound_access << MP2_SMNIF_SECURE_CTRL_BLOCK_OUTBOUND_ACCESS_SHIFT)
#define MP2_SMNIF_SECURE_CTRL_SET_ALLOW_INBOUND_LIVMIN_ACCESS(mp2_smnif_secure_ctrl_reg, allow_inbound_livmin_access) \
     mp2_smnif_secure_ctrl_reg = (mp2_smnif_secure_ctrl_reg & ~MP2_SMNIF_SECURE_CTRL_ALLOW_INBOUND_LIVMIN_ACCESS_MASK) | (allow_inbound_livmin_access << MP2_SMNIF_SECURE_CTRL_ALLOW_INBOUND_LIVMIN_ACCESS_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_secure_ctrl_t {
          unsigned int allow_nonmp_sram_access        : MP2_SMNIF_SECURE_CTRL_ALLOW_NONMP_SRAM_ACCESS_SIZE;
          unsigned int block_sram_space               : MP2_SMNIF_SECURE_CTRL_BLOCK_SRAM_SPACE_SIZE;
          unsigned int block_priv_space               : MP2_SMNIF_SECURE_CTRL_BLOCK_PRIV_SPACE_SIZE;
          unsigned int                                : 3;
          unsigned int allow_ram0_initid_access       : MP2_SMNIF_SECURE_CTRL_ALLOW_RAM0_INITID_ACCESS_SIZE;
          unsigned int allow_nonmp_ram1_access        : MP2_SMNIF_SECURE_CTRL_ALLOW_NONMP_RAM1_ACCESS_SIZE;
          unsigned int                                : 7;
          unsigned int lock_smnif_fence               : MP2_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_SIZE;
          unsigned int lock_smnif_fence_status        : MP2_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_STATUS_SIZE;
          unsigned int                                : 7;
          unsigned int block_outbound_access          : MP2_SMNIF_SECURE_CTRL_BLOCK_OUTBOUND_ACCESS_SIZE;
          unsigned int                                : 6;
          unsigned int allow_inbound_livmin_access    : MP2_SMNIF_SECURE_CTRL_ALLOW_INBOUND_LIVMIN_ACCESS_SIZE;
     } mp2_smnif_secure_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_secure_ctrl_t {
          unsigned int allow_inbound_livmin_access    : MP2_SMNIF_SECURE_CTRL_ALLOW_INBOUND_LIVMIN_ACCESS_SIZE;
          unsigned int                                : 6;
          unsigned int block_outbound_access          : MP2_SMNIF_SECURE_CTRL_BLOCK_OUTBOUND_ACCESS_SIZE;
          unsigned int                                : 7;
          unsigned int lock_smnif_fence_status        : MP2_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_STATUS_SIZE;
          unsigned int lock_smnif_fence               : MP2_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_SIZE;
          unsigned int                                : 7;
          unsigned int allow_nonmp_ram1_access        : MP2_SMNIF_SECURE_CTRL_ALLOW_NONMP_RAM1_ACCESS_SIZE;
          unsigned int allow_ram0_initid_access       : MP2_SMNIF_SECURE_CTRL_ALLOW_RAM0_INITID_ACCESS_SIZE;
          unsigned int                                : 3;
          unsigned int block_priv_space               : MP2_SMNIF_SECURE_CTRL_BLOCK_PRIV_SPACE_SIZE;
          unsigned int block_sram_space               : MP2_SMNIF_SECURE_CTRL_BLOCK_SRAM_SPACE_SIZE;
          unsigned int allow_nonmp_sram_access        : MP2_SMNIF_SECURE_CTRL_ALLOW_NONMP_SRAM_ACCESS_SIZE;
     } mp2_smnif_secure_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_secure_ctrl_t f;
} mp2_smnif_secure_ctrl_u;


/*
 * MP2_SMNIF_TLVMASK_SECURE struct
 */

#define MP2_SMNIF_TLVMASK_SECURE_REG_SIZE 32
#define MP2_SMNIF_TLVMASK_SECURE_TLV0_MASK_SIZE 3
#define MP2_SMNIF_TLVMASK_SECURE_TLV1_MASK_SIZE 3
#define MP2_SMNIF_TLVMASK_SECURE_TLV2_MASK_SIZE 3
#define MP2_SMNIF_TLVMASK_SECURE_TLV3_MASK_SIZE 3
#define MP2_SMNIF_TLVMASK_SECURE_TLV4_MASK_SIZE 3
#define MP2_SMNIF_TLVMASK_SECURE_TLV5_MASK_SIZE 3
#define MP2_SMNIF_TLVMASK_SECURE_TLV6_MASK_SIZE 3
#define MP2_SMNIF_TLVMASK_SECURE_TLV7_MASK_SIZE 3

#define MP2_SMNIF_TLVMASK_SECURE_TLV0_MASK_SHIFT 0
#define MP2_SMNIF_TLVMASK_SECURE_TLV1_MASK_SHIFT 4
#define MP2_SMNIF_TLVMASK_SECURE_TLV2_MASK_SHIFT 8
#define MP2_SMNIF_TLVMASK_SECURE_TLV3_MASK_SHIFT 12
#define MP2_SMNIF_TLVMASK_SECURE_TLV4_MASK_SHIFT 16
#define MP2_SMNIF_TLVMASK_SECURE_TLV5_MASK_SHIFT 20
#define MP2_SMNIF_TLVMASK_SECURE_TLV6_MASK_SHIFT 24
#define MP2_SMNIF_TLVMASK_SECURE_TLV7_MASK_SHIFT 28

#define MP2_SMNIF_TLVMASK_SECURE_TLV0_MASK_MASK 0x7
#define MP2_SMNIF_TLVMASK_SECURE_TLV1_MASK_MASK 0x70
#define MP2_SMNIF_TLVMASK_SECURE_TLV2_MASK_MASK 0x700
#define MP2_SMNIF_TLVMASK_SECURE_TLV3_MASK_MASK 0x7000
#define MP2_SMNIF_TLVMASK_SECURE_TLV4_MASK_MASK 0x70000
#define MP2_SMNIF_TLVMASK_SECURE_TLV5_MASK_MASK 0x700000
#define MP2_SMNIF_TLVMASK_SECURE_TLV6_MASK_MASK 0x7000000
#define MP2_SMNIF_TLVMASK_SECURE_TLV7_MASK_MASK 0x70000000

#define MP2_SMNIF_TLVMASK_SECURE_MASK \
     (MP2_SMNIF_TLVMASK_SECURE_TLV0_MASK_MASK | \
      MP2_SMNIF_TLVMASK_SECURE_TLV1_MASK_MASK | \
      MP2_SMNIF_TLVMASK_SECURE_TLV2_MASK_MASK | \
      MP2_SMNIF_TLVMASK_SECURE_TLV3_MASK_MASK | \
      MP2_SMNIF_TLVMASK_SECURE_TLV4_MASK_MASK | \
      MP2_SMNIF_TLVMASK_SECURE_TLV5_MASK_MASK | \
      MP2_SMNIF_TLVMASK_SECURE_TLV6_MASK_MASK | \
      MP2_SMNIF_TLVMASK_SECURE_TLV7_MASK_MASK)

#define MP2_SMNIF_TLVMASK_SECURE_DEFAULT 0x00000000

#define MP2_SMNIF_TLVMASK_SECURE_GET_TLV0_MASK(mp2_smnif_tlvmask_secure) \
     ((mp2_smnif_tlvmask_secure & MP2_SMNIF_TLVMASK_SECURE_TLV0_MASK_MASK) >> MP2_SMNIF_TLVMASK_SECURE_TLV0_MASK_SHIFT)
#define MP2_SMNIF_TLVMASK_SECURE_GET_TLV1_MASK(mp2_smnif_tlvmask_secure) \
     ((mp2_smnif_tlvmask_secure & MP2_SMNIF_TLVMASK_SECURE_TLV1_MASK_MASK) >> MP2_SMNIF_TLVMASK_SECURE_TLV1_MASK_SHIFT)
#define MP2_SMNIF_TLVMASK_SECURE_GET_TLV2_MASK(mp2_smnif_tlvmask_secure) \
     ((mp2_smnif_tlvmask_secure & MP2_SMNIF_TLVMASK_SECURE_TLV2_MASK_MASK) >> MP2_SMNIF_TLVMASK_SECURE_TLV2_MASK_SHIFT)
#define MP2_SMNIF_TLVMASK_SECURE_GET_TLV3_MASK(mp2_smnif_tlvmask_secure) \
     ((mp2_smnif_tlvmask_secure & MP2_SMNIF_TLVMASK_SECURE_TLV3_MASK_MASK) >> MP2_SMNIF_TLVMASK_SECURE_TLV3_MASK_SHIFT)
#define MP2_SMNIF_TLVMASK_SECURE_GET_TLV4_MASK(mp2_smnif_tlvmask_secure) \
     ((mp2_smnif_tlvmask_secure & MP2_SMNIF_TLVMASK_SECURE_TLV4_MASK_MASK) >> MP2_SMNIF_TLVMASK_SECURE_TLV4_MASK_SHIFT)
#define MP2_SMNIF_TLVMASK_SECURE_GET_TLV5_MASK(mp2_smnif_tlvmask_secure) \
     ((mp2_smnif_tlvmask_secure & MP2_SMNIF_TLVMASK_SECURE_TLV5_MASK_MASK) >> MP2_SMNIF_TLVMASK_SECURE_TLV5_MASK_SHIFT)
#define MP2_SMNIF_TLVMASK_SECURE_GET_TLV6_MASK(mp2_smnif_tlvmask_secure) \
     ((mp2_smnif_tlvmask_secure & MP2_SMNIF_TLVMASK_SECURE_TLV6_MASK_MASK) >> MP2_SMNIF_TLVMASK_SECURE_TLV6_MASK_SHIFT)
#define MP2_SMNIF_TLVMASK_SECURE_GET_TLV7_MASK(mp2_smnif_tlvmask_secure) \
     ((mp2_smnif_tlvmask_secure & MP2_SMNIF_TLVMASK_SECURE_TLV7_MASK_MASK) >> MP2_SMNIF_TLVMASK_SECURE_TLV7_MASK_SHIFT)

#define MP2_SMNIF_TLVMASK_SECURE_SET_TLV0_MASK(mp2_smnif_tlvmask_secure_reg, tlv0_mask) \
     mp2_smnif_tlvmask_secure_reg = (mp2_smnif_tlvmask_secure_reg & ~MP2_SMNIF_TLVMASK_SECURE_TLV0_MASK_MASK) | (tlv0_mask << MP2_SMNIF_TLVMASK_SECURE_TLV0_MASK_SHIFT)
#define MP2_SMNIF_TLVMASK_SECURE_SET_TLV1_MASK(mp2_smnif_tlvmask_secure_reg, tlv1_mask) \
     mp2_smnif_tlvmask_secure_reg = (mp2_smnif_tlvmask_secure_reg & ~MP2_SMNIF_TLVMASK_SECURE_TLV1_MASK_MASK) | (tlv1_mask << MP2_SMNIF_TLVMASK_SECURE_TLV1_MASK_SHIFT)
#define MP2_SMNIF_TLVMASK_SECURE_SET_TLV2_MASK(mp2_smnif_tlvmask_secure_reg, tlv2_mask) \
     mp2_smnif_tlvmask_secure_reg = (mp2_smnif_tlvmask_secure_reg & ~MP2_SMNIF_TLVMASK_SECURE_TLV2_MASK_MASK) | (tlv2_mask << MP2_SMNIF_TLVMASK_SECURE_TLV2_MASK_SHIFT)
#define MP2_SMNIF_TLVMASK_SECURE_SET_TLV3_MASK(mp2_smnif_tlvmask_secure_reg, tlv3_mask) \
     mp2_smnif_tlvmask_secure_reg = (mp2_smnif_tlvmask_secure_reg & ~MP2_SMNIF_TLVMASK_SECURE_TLV3_MASK_MASK) | (tlv3_mask << MP2_SMNIF_TLVMASK_SECURE_TLV3_MASK_SHIFT)
#define MP2_SMNIF_TLVMASK_SECURE_SET_TLV4_MASK(mp2_smnif_tlvmask_secure_reg, tlv4_mask) \
     mp2_smnif_tlvmask_secure_reg = (mp2_smnif_tlvmask_secure_reg & ~MP2_SMNIF_TLVMASK_SECURE_TLV4_MASK_MASK) | (tlv4_mask << MP2_SMNIF_TLVMASK_SECURE_TLV4_MASK_SHIFT)
#define MP2_SMNIF_TLVMASK_SECURE_SET_TLV5_MASK(mp2_smnif_tlvmask_secure_reg, tlv5_mask) \
     mp2_smnif_tlvmask_secure_reg = (mp2_smnif_tlvmask_secure_reg & ~MP2_SMNIF_TLVMASK_SECURE_TLV5_MASK_MASK) | (tlv5_mask << MP2_SMNIF_TLVMASK_SECURE_TLV5_MASK_SHIFT)
#define MP2_SMNIF_TLVMASK_SECURE_SET_TLV6_MASK(mp2_smnif_tlvmask_secure_reg, tlv6_mask) \
     mp2_smnif_tlvmask_secure_reg = (mp2_smnif_tlvmask_secure_reg & ~MP2_SMNIF_TLVMASK_SECURE_TLV6_MASK_MASK) | (tlv6_mask << MP2_SMNIF_TLVMASK_SECURE_TLV6_MASK_SHIFT)
#define MP2_SMNIF_TLVMASK_SECURE_SET_TLV7_MASK(mp2_smnif_tlvmask_secure_reg, tlv7_mask) \
     mp2_smnif_tlvmask_secure_reg = (mp2_smnif_tlvmask_secure_reg & ~MP2_SMNIF_TLVMASK_SECURE_TLV7_MASK_MASK) | (tlv7_mask << MP2_SMNIF_TLVMASK_SECURE_TLV7_MASK_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlvmask_secure_t {
          unsigned int tlv0_mask                      : MP2_SMNIF_TLVMASK_SECURE_TLV0_MASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv1_mask                      : MP2_SMNIF_TLVMASK_SECURE_TLV1_MASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv2_mask                      : MP2_SMNIF_TLVMASK_SECURE_TLV2_MASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv3_mask                      : MP2_SMNIF_TLVMASK_SECURE_TLV3_MASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv4_mask                      : MP2_SMNIF_TLVMASK_SECURE_TLV4_MASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv5_mask                      : MP2_SMNIF_TLVMASK_SECURE_TLV5_MASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv6_mask                      : MP2_SMNIF_TLVMASK_SECURE_TLV6_MASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv7_mask                      : MP2_SMNIF_TLVMASK_SECURE_TLV7_MASK_SIZE;
          unsigned int                                : 1;
     } mp2_smnif_tlvmask_secure_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlvmask_secure_t {
          unsigned int                                : 1;
          unsigned int tlv7_mask                      : MP2_SMNIF_TLVMASK_SECURE_TLV7_MASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv6_mask                      : MP2_SMNIF_TLVMASK_SECURE_TLV6_MASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv5_mask                      : MP2_SMNIF_TLVMASK_SECURE_TLV5_MASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv4_mask                      : MP2_SMNIF_TLVMASK_SECURE_TLV4_MASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv3_mask                      : MP2_SMNIF_TLVMASK_SECURE_TLV3_MASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv2_mask                      : MP2_SMNIF_TLVMASK_SECURE_TLV2_MASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv1_mask                      : MP2_SMNIF_TLVMASK_SECURE_TLV1_MASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv0_mask                      : MP2_SMNIF_TLVMASK_SECURE_TLV0_MASK_SIZE;
     } mp2_smnif_tlvmask_secure_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlvmask_secure_t f;
} mp2_smnif_tlvmask_secure_u;


/*
 * MP2_SMNIF_TLVMASK_NONSECURE struct
 */

#define MP2_SMNIF_TLVMASK_NONSECURE_REG_SIZE 32
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV0_NSMASK_SIZE 3
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV1_NSMASK_SIZE 3
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV2_NSMASK_SIZE 3
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV3_NSMASK_SIZE 3
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV4_NSMASK_SIZE 3
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV5_NSMASK_SIZE 3
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV6_NSMASK_SIZE 3
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV7_NSMASK_SIZE 3

#define MP2_SMNIF_TLVMASK_NONSECURE_TLV0_NSMASK_SHIFT 0
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV1_NSMASK_SHIFT 4
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV2_NSMASK_SHIFT 8
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV3_NSMASK_SHIFT 12
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV4_NSMASK_SHIFT 16
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV5_NSMASK_SHIFT 20
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV6_NSMASK_SHIFT 24
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV7_NSMASK_SHIFT 28

#define MP2_SMNIF_TLVMASK_NONSECURE_TLV0_NSMASK_MASK 0x7
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV1_NSMASK_MASK 0x70
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV2_NSMASK_MASK 0x700
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV3_NSMASK_MASK 0x7000
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV4_NSMASK_MASK 0x70000
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV5_NSMASK_MASK 0x700000
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV6_NSMASK_MASK 0x7000000
#define MP2_SMNIF_TLVMASK_NONSECURE_TLV7_NSMASK_MASK 0x70000000

#define MP2_SMNIF_TLVMASK_NONSECURE_MASK \
     (MP2_SMNIF_TLVMASK_NONSECURE_TLV0_NSMASK_MASK | \
      MP2_SMNIF_TLVMASK_NONSECURE_TLV1_NSMASK_MASK | \
      MP2_SMNIF_TLVMASK_NONSECURE_TLV2_NSMASK_MASK | \
      MP2_SMNIF_TLVMASK_NONSECURE_TLV3_NSMASK_MASK | \
      MP2_SMNIF_TLVMASK_NONSECURE_TLV4_NSMASK_MASK | \
      MP2_SMNIF_TLVMASK_NONSECURE_TLV5_NSMASK_MASK | \
      MP2_SMNIF_TLVMASK_NONSECURE_TLV6_NSMASK_MASK | \
      MP2_SMNIF_TLVMASK_NONSECURE_TLV7_NSMASK_MASK)

#define MP2_SMNIF_TLVMASK_NONSECURE_DEFAULT 0x77777777

#define MP2_SMNIF_TLVMASK_NONSECURE_GET_TLV0_NSMASK(mp2_smnif_tlvmask_nonsecure) \
     ((mp2_smnif_tlvmask_nonsecure & MP2_SMNIF_TLVMASK_NONSECURE_TLV0_NSMASK_MASK) >> MP2_SMNIF_TLVMASK_NONSECURE_TLV0_NSMASK_SHIFT)
#define MP2_SMNIF_TLVMASK_NONSECURE_GET_TLV1_NSMASK(mp2_smnif_tlvmask_nonsecure) \
     ((mp2_smnif_tlvmask_nonsecure & MP2_SMNIF_TLVMASK_NONSECURE_TLV1_NSMASK_MASK) >> MP2_SMNIF_TLVMASK_NONSECURE_TLV1_NSMASK_SHIFT)
#define MP2_SMNIF_TLVMASK_NONSECURE_GET_TLV2_NSMASK(mp2_smnif_tlvmask_nonsecure) \
     ((mp2_smnif_tlvmask_nonsecure & MP2_SMNIF_TLVMASK_NONSECURE_TLV2_NSMASK_MASK) >> MP2_SMNIF_TLVMASK_NONSECURE_TLV2_NSMASK_SHIFT)
#define MP2_SMNIF_TLVMASK_NONSECURE_GET_TLV3_NSMASK(mp2_smnif_tlvmask_nonsecure) \
     ((mp2_smnif_tlvmask_nonsecure & MP2_SMNIF_TLVMASK_NONSECURE_TLV3_NSMASK_MASK) >> MP2_SMNIF_TLVMASK_NONSECURE_TLV3_NSMASK_SHIFT)
#define MP2_SMNIF_TLVMASK_NONSECURE_GET_TLV4_NSMASK(mp2_smnif_tlvmask_nonsecure) \
     ((mp2_smnif_tlvmask_nonsecure & MP2_SMNIF_TLVMASK_NONSECURE_TLV4_NSMASK_MASK) >> MP2_SMNIF_TLVMASK_NONSECURE_TLV4_NSMASK_SHIFT)
#define MP2_SMNIF_TLVMASK_NONSECURE_GET_TLV5_NSMASK(mp2_smnif_tlvmask_nonsecure) \
     ((mp2_smnif_tlvmask_nonsecure & MP2_SMNIF_TLVMASK_NONSECURE_TLV5_NSMASK_MASK) >> MP2_SMNIF_TLVMASK_NONSECURE_TLV5_NSMASK_SHIFT)
#define MP2_SMNIF_TLVMASK_NONSECURE_GET_TLV6_NSMASK(mp2_smnif_tlvmask_nonsecure) \
     ((mp2_smnif_tlvmask_nonsecure & MP2_SMNIF_TLVMASK_NONSECURE_TLV6_NSMASK_MASK) >> MP2_SMNIF_TLVMASK_NONSECURE_TLV6_NSMASK_SHIFT)
#define MP2_SMNIF_TLVMASK_NONSECURE_GET_TLV7_NSMASK(mp2_smnif_tlvmask_nonsecure) \
     ((mp2_smnif_tlvmask_nonsecure & MP2_SMNIF_TLVMASK_NONSECURE_TLV7_NSMASK_MASK) >> MP2_SMNIF_TLVMASK_NONSECURE_TLV7_NSMASK_SHIFT)

#define MP2_SMNIF_TLVMASK_NONSECURE_SET_TLV0_NSMASK(mp2_smnif_tlvmask_nonsecure_reg, tlv0_nsmask) \
     mp2_smnif_tlvmask_nonsecure_reg = (mp2_smnif_tlvmask_nonsecure_reg & ~MP2_SMNIF_TLVMASK_NONSECURE_TLV0_NSMASK_MASK) | (tlv0_nsmask << MP2_SMNIF_TLVMASK_NONSECURE_TLV0_NSMASK_SHIFT)
#define MP2_SMNIF_TLVMASK_NONSECURE_SET_TLV1_NSMASK(mp2_smnif_tlvmask_nonsecure_reg, tlv1_nsmask) \
     mp2_smnif_tlvmask_nonsecure_reg = (mp2_smnif_tlvmask_nonsecure_reg & ~MP2_SMNIF_TLVMASK_NONSECURE_TLV1_NSMASK_MASK) | (tlv1_nsmask << MP2_SMNIF_TLVMASK_NONSECURE_TLV1_NSMASK_SHIFT)
#define MP2_SMNIF_TLVMASK_NONSECURE_SET_TLV2_NSMASK(mp2_smnif_tlvmask_nonsecure_reg, tlv2_nsmask) \
     mp2_smnif_tlvmask_nonsecure_reg = (mp2_smnif_tlvmask_nonsecure_reg & ~MP2_SMNIF_TLVMASK_NONSECURE_TLV2_NSMASK_MASK) | (tlv2_nsmask << MP2_SMNIF_TLVMASK_NONSECURE_TLV2_NSMASK_SHIFT)
#define MP2_SMNIF_TLVMASK_NONSECURE_SET_TLV3_NSMASK(mp2_smnif_tlvmask_nonsecure_reg, tlv3_nsmask) \
     mp2_smnif_tlvmask_nonsecure_reg = (mp2_smnif_tlvmask_nonsecure_reg & ~MP2_SMNIF_TLVMASK_NONSECURE_TLV3_NSMASK_MASK) | (tlv3_nsmask << MP2_SMNIF_TLVMASK_NONSECURE_TLV3_NSMASK_SHIFT)
#define MP2_SMNIF_TLVMASK_NONSECURE_SET_TLV4_NSMASK(mp2_smnif_tlvmask_nonsecure_reg, tlv4_nsmask) \
     mp2_smnif_tlvmask_nonsecure_reg = (mp2_smnif_tlvmask_nonsecure_reg & ~MP2_SMNIF_TLVMASK_NONSECURE_TLV4_NSMASK_MASK) | (tlv4_nsmask << MP2_SMNIF_TLVMASK_NONSECURE_TLV4_NSMASK_SHIFT)
#define MP2_SMNIF_TLVMASK_NONSECURE_SET_TLV5_NSMASK(mp2_smnif_tlvmask_nonsecure_reg, tlv5_nsmask) \
     mp2_smnif_tlvmask_nonsecure_reg = (mp2_smnif_tlvmask_nonsecure_reg & ~MP2_SMNIF_TLVMASK_NONSECURE_TLV5_NSMASK_MASK) | (tlv5_nsmask << MP2_SMNIF_TLVMASK_NONSECURE_TLV5_NSMASK_SHIFT)
#define MP2_SMNIF_TLVMASK_NONSECURE_SET_TLV6_NSMASK(mp2_smnif_tlvmask_nonsecure_reg, tlv6_nsmask) \
     mp2_smnif_tlvmask_nonsecure_reg = (mp2_smnif_tlvmask_nonsecure_reg & ~MP2_SMNIF_TLVMASK_NONSECURE_TLV6_NSMASK_MASK) | (tlv6_nsmask << MP2_SMNIF_TLVMASK_NONSECURE_TLV6_NSMASK_SHIFT)
#define MP2_SMNIF_TLVMASK_NONSECURE_SET_TLV7_NSMASK(mp2_smnif_tlvmask_nonsecure_reg, tlv7_nsmask) \
     mp2_smnif_tlvmask_nonsecure_reg = (mp2_smnif_tlvmask_nonsecure_reg & ~MP2_SMNIF_TLVMASK_NONSECURE_TLV7_NSMASK_MASK) | (tlv7_nsmask << MP2_SMNIF_TLVMASK_NONSECURE_TLV7_NSMASK_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlvmask_nonsecure_t {
          unsigned int tlv0_nsmask                    : MP2_SMNIF_TLVMASK_NONSECURE_TLV0_NSMASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv1_nsmask                    : MP2_SMNIF_TLVMASK_NONSECURE_TLV1_NSMASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv2_nsmask                    : MP2_SMNIF_TLVMASK_NONSECURE_TLV2_NSMASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv3_nsmask                    : MP2_SMNIF_TLVMASK_NONSECURE_TLV3_NSMASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv4_nsmask                    : MP2_SMNIF_TLVMASK_NONSECURE_TLV4_NSMASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv5_nsmask                    : MP2_SMNIF_TLVMASK_NONSECURE_TLV5_NSMASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv6_nsmask                    : MP2_SMNIF_TLVMASK_NONSECURE_TLV6_NSMASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv7_nsmask                    : MP2_SMNIF_TLVMASK_NONSECURE_TLV7_NSMASK_SIZE;
          unsigned int                                : 1;
     } mp2_smnif_tlvmask_nonsecure_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlvmask_nonsecure_t {
          unsigned int                                : 1;
          unsigned int tlv7_nsmask                    : MP2_SMNIF_TLVMASK_NONSECURE_TLV7_NSMASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv6_nsmask                    : MP2_SMNIF_TLVMASK_NONSECURE_TLV6_NSMASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv5_nsmask                    : MP2_SMNIF_TLVMASK_NONSECURE_TLV5_NSMASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv4_nsmask                    : MP2_SMNIF_TLVMASK_NONSECURE_TLV4_NSMASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv3_nsmask                    : MP2_SMNIF_TLVMASK_NONSECURE_TLV3_NSMASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv2_nsmask                    : MP2_SMNIF_TLVMASK_NONSECURE_TLV2_NSMASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv1_nsmask                    : MP2_SMNIF_TLVMASK_NONSECURE_TLV1_NSMASK_SIZE;
          unsigned int                                : 1;
          unsigned int tlv0_nsmask                    : MP2_SMNIF_TLVMASK_NONSECURE_TLV0_NSMASK_SIZE;
     } mp2_smnif_tlvmask_nonsecure_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlvmask_nonsecure_t f;
} mp2_smnif_tlvmask_nonsecure_u;


/*
 * MP2_SMNIF_TLR_0 struct
 */

#define MP2_SMNIF_TLR_0_REG_SIZE       32
#define MP2_SMNIF_TLR_0_MASK_SIZE      8
#define MP2_SMNIF_TLR_0_RD_ACC_SIZE    1
#define MP2_SMNIF_TLR_0_WR_ACC_SIZE    1
#define MP2_SMNIF_TLR_0_SLV_ADDR_SIZE  4
#define MP2_SMNIF_TLR_0_VF_ACC_SIZE    1
#define MP2_SMNIF_TLR_0_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_0_VALID_SIZE     1

#define MP2_SMNIF_TLR_0_MASK_SHIFT     0
#define MP2_SMNIF_TLR_0_RD_ACC_SHIFT   8
#define MP2_SMNIF_TLR_0_WR_ACC_SHIFT   9
#define MP2_SMNIF_TLR_0_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_0_VF_ACC_SHIFT   14
#define MP2_SMNIF_TLR_0_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_0_VALID_SHIFT    16

#define MP2_SMNIF_TLR_0_MASK_MASK      0xff
#define MP2_SMNIF_TLR_0_RD_ACC_MASK    0x100
#define MP2_SMNIF_TLR_0_WR_ACC_MASK    0x200
#define MP2_SMNIF_TLR_0_SLV_ADDR_MASK  0x3c00
#define MP2_SMNIF_TLR_0_VF_ACC_MASK    0x4000
#define MP2_SMNIF_TLR_0_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_0_VALID_MASK     0x10000

#define MP2_SMNIF_TLR_0_MASK \
     (MP2_SMNIF_TLR_0_MASK_MASK | \
      MP2_SMNIF_TLR_0_RD_ACC_MASK | \
      MP2_SMNIF_TLR_0_WR_ACC_MASK | \
      MP2_SMNIF_TLR_0_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_0_VF_ACC_MASK | \
      MP2_SMNIF_TLR_0_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_0_VALID_MASK)

#define MP2_SMNIF_TLR_0_DEFAULT        0x000103ff

#define MP2_SMNIF_TLR_0_GET_MASK(mp2_smnif_tlr_0) \
     ((mp2_smnif_tlr_0 & MP2_SMNIF_TLR_0_MASK_MASK) >> MP2_SMNIF_TLR_0_MASK_SHIFT)
#define MP2_SMNIF_TLR_0_GET_RD_ACC(mp2_smnif_tlr_0) \
     ((mp2_smnif_tlr_0 & MP2_SMNIF_TLR_0_RD_ACC_MASK) >> MP2_SMNIF_TLR_0_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_0_GET_WR_ACC(mp2_smnif_tlr_0) \
     ((mp2_smnif_tlr_0 & MP2_SMNIF_TLR_0_WR_ACC_MASK) >> MP2_SMNIF_TLR_0_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_0_GET_SLV_ADDR(mp2_smnif_tlr_0) \
     ((mp2_smnif_tlr_0 & MP2_SMNIF_TLR_0_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_0_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_0_GET_VF_ACC(mp2_smnif_tlr_0) \
     ((mp2_smnif_tlr_0 & MP2_SMNIF_TLR_0_VF_ACC_MASK) >> MP2_SMNIF_TLR_0_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_0_GET_VF_ACC_ENB(mp2_smnif_tlr_0) \
     ((mp2_smnif_tlr_0 & MP2_SMNIF_TLR_0_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_0_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_0_GET_VALID(mp2_smnif_tlr_0) \
     ((mp2_smnif_tlr_0 & MP2_SMNIF_TLR_0_VALID_MASK) >> MP2_SMNIF_TLR_0_VALID_SHIFT)

#define MP2_SMNIF_TLR_0_SET_MASK(mp2_smnif_tlr_0_reg, mask) \
     mp2_smnif_tlr_0_reg = (mp2_smnif_tlr_0_reg & ~MP2_SMNIF_TLR_0_MASK_MASK) | (mask << MP2_SMNIF_TLR_0_MASK_SHIFT)
#define MP2_SMNIF_TLR_0_SET_RD_ACC(mp2_smnif_tlr_0_reg, rd_acc) \
     mp2_smnif_tlr_0_reg = (mp2_smnif_tlr_0_reg & ~MP2_SMNIF_TLR_0_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_0_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_0_SET_WR_ACC(mp2_smnif_tlr_0_reg, wr_acc) \
     mp2_smnif_tlr_0_reg = (mp2_smnif_tlr_0_reg & ~MP2_SMNIF_TLR_0_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_0_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_0_SET_SLV_ADDR(mp2_smnif_tlr_0_reg, slv_addr) \
     mp2_smnif_tlr_0_reg = (mp2_smnif_tlr_0_reg & ~MP2_SMNIF_TLR_0_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_0_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_0_SET_VF_ACC(mp2_smnif_tlr_0_reg, vf_acc) \
     mp2_smnif_tlr_0_reg = (mp2_smnif_tlr_0_reg & ~MP2_SMNIF_TLR_0_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_0_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_0_SET_VF_ACC_ENB(mp2_smnif_tlr_0_reg, vf_acc_enb) \
     mp2_smnif_tlr_0_reg = (mp2_smnif_tlr_0_reg & ~MP2_SMNIF_TLR_0_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_0_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_0_SET_VALID(mp2_smnif_tlr_0_reg, valid) \
     mp2_smnif_tlr_0_reg = (mp2_smnif_tlr_0_reg & ~MP2_SMNIF_TLR_0_VALID_MASK) | (valid << MP2_SMNIF_TLR_0_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_0_t {
          unsigned int mask                           : MP2_SMNIF_TLR_0_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_0_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_0_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_0_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_0_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_0_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_0_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_0_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_0_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_0_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_0_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_0_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_0_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_0_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_0_MASK_SIZE;
     } mp2_smnif_tlr_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_0_t f;
} mp2_smnif_tlr_0_u;


/*
 * MP2_SMNIF_TLR_ADDR_0 struct
 */

#define MP2_SMNIF_TLR_ADDR_0_REG_SIZE  32
#define MP2_SMNIF_TLR_ADDR_0_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_0_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_0_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_0_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_0_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_0_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_0_MASK \
     (MP2_SMNIF_TLR_ADDR_0_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_0_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_0_DEFAULT   0xffff0000

#define MP2_SMNIF_TLR_ADDR_0_GET_START_ADDR(mp2_smnif_tlr_addr_0) \
     ((mp2_smnif_tlr_addr_0 & MP2_SMNIF_TLR_ADDR_0_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_0_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_0_GET_END_ADDR(mp2_smnif_tlr_addr_0) \
     ((mp2_smnif_tlr_addr_0 & MP2_SMNIF_TLR_ADDR_0_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_0_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_0_SET_START_ADDR(mp2_smnif_tlr_addr_0_reg, start_addr) \
     mp2_smnif_tlr_addr_0_reg = (mp2_smnif_tlr_addr_0_reg & ~MP2_SMNIF_TLR_ADDR_0_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_0_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_0_SET_END_ADDR(mp2_smnif_tlr_addr_0_reg, end_addr) \
     mp2_smnif_tlr_addr_0_reg = (mp2_smnif_tlr_addr_0_reg & ~MP2_SMNIF_TLR_ADDR_0_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_0_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_0_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_0_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_0_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_0_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_0_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_0_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_0_t f;
} mp2_smnif_tlr_addr_0_u;


/*
 * MP2_SMNIF_TLR_1 struct
 */

#define MP2_SMNIF_TLR_1_REG_SIZE       32
#define MP2_SMNIF_TLR_1_MASK_SIZE      8
#define MP2_SMNIF_TLR_1_RD_ACC_SIZE    1
#define MP2_SMNIF_TLR_1_WR_ACC_SIZE    1
#define MP2_SMNIF_TLR_1_SLV_ADDR_SIZE  4
#define MP2_SMNIF_TLR_1_VF_ACC_SIZE    1
#define MP2_SMNIF_TLR_1_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_1_VALID_SIZE     1

#define MP2_SMNIF_TLR_1_MASK_SHIFT     0
#define MP2_SMNIF_TLR_1_RD_ACC_SHIFT   8
#define MP2_SMNIF_TLR_1_WR_ACC_SHIFT   9
#define MP2_SMNIF_TLR_1_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_1_VF_ACC_SHIFT   14
#define MP2_SMNIF_TLR_1_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_1_VALID_SHIFT    16

#define MP2_SMNIF_TLR_1_MASK_MASK      0xff
#define MP2_SMNIF_TLR_1_RD_ACC_MASK    0x100
#define MP2_SMNIF_TLR_1_WR_ACC_MASK    0x200
#define MP2_SMNIF_TLR_1_SLV_ADDR_MASK  0x3c00
#define MP2_SMNIF_TLR_1_VF_ACC_MASK    0x4000
#define MP2_SMNIF_TLR_1_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_1_VALID_MASK     0x10000

#define MP2_SMNIF_TLR_1_MASK \
     (MP2_SMNIF_TLR_1_MASK_MASK | \
      MP2_SMNIF_TLR_1_RD_ACC_MASK | \
      MP2_SMNIF_TLR_1_WR_ACC_MASK | \
      MP2_SMNIF_TLR_1_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_1_VF_ACC_MASK | \
      MP2_SMNIF_TLR_1_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_1_VALID_MASK)

#define MP2_SMNIF_TLR_1_DEFAULT        0x000107ff

#define MP2_SMNIF_TLR_1_GET_MASK(mp2_smnif_tlr_1) \
     ((mp2_smnif_tlr_1 & MP2_SMNIF_TLR_1_MASK_MASK) >> MP2_SMNIF_TLR_1_MASK_SHIFT)
#define MP2_SMNIF_TLR_1_GET_RD_ACC(mp2_smnif_tlr_1) \
     ((mp2_smnif_tlr_1 & MP2_SMNIF_TLR_1_RD_ACC_MASK) >> MP2_SMNIF_TLR_1_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_1_GET_WR_ACC(mp2_smnif_tlr_1) \
     ((mp2_smnif_tlr_1 & MP2_SMNIF_TLR_1_WR_ACC_MASK) >> MP2_SMNIF_TLR_1_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_1_GET_SLV_ADDR(mp2_smnif_tlr_1) \
     ((mp2_smnif_tlr_1 & MP2_SMNIF_TLR_1_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_1_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_1_GET_VF_ACC(mp2_smnif_tlr_1) \
     ((mp2_smnif_tlr_1 & MP2_SMNIF_TLR_1_VF_ACC_MASK) >> MP2_SMNIF_TLR_1_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_1_GET_VF_ACC_ENB(mp2_smnif_tlr_1) \
     ((mp2_smnif_tlr_1 & MP2_SMNIF_TLR_1_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_1_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_1_GET_VALID(mp2_smnif_tlr_1) \
     ((mp2_smnif_tlr_1 & MP2_SMNIF_TLR_1_VALID_MASK) >> MP2_SMNIF_TLR_1_VALID_SHIFT)

#define MP2_SMNIF_TLR_1_SET_MASK(mp2_smnif_tlr_1_reg, mask) \
     mp2_smnif_tlr_1_reg = (mp2_smnif_tlr_1_reg & ~MP2_SMNIF_TLR_1_MASK_MASK) | (mask << MP2_SMNIF_TLR_1_MASK_SHIFT)
#define MP2_SMNIF_TLR_1_SET_RD_ACC(mp2_smnif_tlr_1_reg, rd_acc) \
     mp2_smnif_tlr_1_reg = (mp2_smnif_tlr_1_reg & ~MP2_SMNIF_TLR_1_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_1_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_1_SET_WR_ACC(mp2_smnif_tlr_1_reg, wr_acc) \
     mp2_smnif_tlr_1_reg = (mp2_smnif_tlr_1_reg & ~MP2_SMNIF_TLR_1_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_1_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_1_SET_SLV_ADDR(mp2_smnif_tlr_1_reg, slv_addr) \
     mp2_smnif_tlr_1_reg = (mp2_smnif_tlr_1_reg & ~MP2_SMNIF_TLR_1_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_1_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_1_SET_VF_ACC(mp2_smnif_tlr_1_reg, vf_acc) \
     mp2_smnif_tlr_1_reg = (mp2_smnif_tlr_1_reg & ~MP2_SMNIF_TLR_1_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_1_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_1_SET_VF_ACC_ENB(mp2_smnif_tlr_1_reg, vf_acc_enb) \
     mp2_smnif_tlr_1_reg = (mp2_smnif_tlr_1_reg & ~MP2_SMNIF_TLR_1_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_1_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_1_SET_VALID(mp2_smnif_tlr_1_reg, valid) \
     mp2_smnif_tlr_1_reg = (mp2_smnif_tlr_1_reg & ~MP2_SMNIF_TLR_1_VALID_MASK) | (valid << MP2_SMNIF_TLR_1_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_1_t {
          unsigned int mask                           : MP2_SMNIF_TLR_1_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_1_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_1_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_1_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_1_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_1_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_1_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_1_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_1_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_1_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_1_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_1_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_1_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_1_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_1_MASK_SIZE;
     } mp2_smnif_tlr_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_1_t f;
} mp2_smnif_tlr_1_u;


/*
 * MP2_SMNIF_TLR_ADDR_1 struct
 */

#define MP2_SMNIF_TLR_ADDR_1_REG_SIZE  32
#define MP2_SMNIF_TLR_ADDR_1_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_1_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_1_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_1_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_1_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_1_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_1_MASK \
     (MP2_SMNIF_TLR_ADDR_1_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_1_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_1_DEFAULT   0xffff0000

#define MP2_SMNIF_TLR_ADDR_1_GET_START_ADDR(mp2_smnif_tlr_addr_1) \
     ((mp2_smnif_tlr_addr_1 & MP2_SMNIF_TLR_ADDR_1_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_1_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_1_GET_END_ADDR(mp2_smnif_tlr_addr_1) \
     ((mp2_smnif_tlr_addr_1 & MP2_SMNIF_TLR_ADDR_1_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_1_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_1_SET_START_ADDR(mp2_smnif_tlr_addr_1_reg, start_addr) \
     mp2_smnif_tlr_addr_1_reg = (mp2_smnif_tlr_addr_1_reg & ~MP2_SMNIF_TLR_ADDR_1_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_1_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_1_SET_END_ADDR(mp2_smnif_tlr_addr_1_reg, end_addr) \
     mp2_smnif_tlr_addr_1_reg = (mp2_smnif_tlr_addr_1_reg & ~MP2_SMNIF_TLR_ADDR_1_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_1_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_1_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_1_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_1_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_1_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_1_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_1_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_1_t f;
} mp2_smnif_tlr_addr_1_u;


/*
 * MP2_SMNIF_TLR_2 struct
 */

#define MP2_SMNIF_TLR_2_REG_SIZE       32
#define MP2_SMNIF_TLR_2_MASK_SIZE      8
#define MP2_SMNIF_TLR_2_RD_ACC_SIZE    1
#define MP2_SMNIF_TLR_2_WR_ACC_SIZE    1
#define MP2_SMNIF_TLR_2_SLV_ADDR_SIZE  4
#define MP2_SMNIF_TLR_2_VF_ACC_SIZE    1
#define MP2_SMNIF_TLR_2_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_2_VALID_SIZE     1

#define MP2_SMNIF_TLR_2_MASK_SHIFT     0
#define MP2_SMNIF_TLR_2_RD_ACC_SHIFT   8
#define MP2_SMNIF_TLR_2_WR_ACC_SHIFT   9
#define MP2_SMNIF_TLR_2_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_2_VF_ACC_SHIFT   14
#define MP2_SMNIF_TLR_2_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_2_VALID_SHIFT    16

#define MP2_SMNIF_TLR_2_MASK_MASK      0xff
#define MP2_SMNIF_TLR_2_RD_ACC_MASK    0x100
#define MP2_SMNIF_TLR_2_WR_ACC_MASK    0x200
#define MP2_SMNIF_TLR_2_SLV_ADDR_MASK  0x3c00
#define MP2_SMNIF_TLR_2_VF_ACC_MASK    0x4000
#define MP2_SMNIF_TLR_2_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_2_VALID_MASK     0x10000

#define MP2_SMNIF_TLR_2_MASK \
     (MP2_SMNIF_TLR_2_MASK_MASK | \
      MP2_SMNIF_TLR_2_RD_ACC_MASK | \
      MP2_SMNIF_TLR_2_WR_ACC_MASK | \
      MP2_SMNIF_TLR_2_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_2_VF_ACC_MASK | \
      MP2_SMNIF_TLR_2_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_2_VALID_MASK)

#define MP2_SMNIF_TLR_2_DEFAULT        0x00010bff

#define MP2_SMNIF_TLR_2_GET_MASK(mp2_smnif_tlr_2) \
     ((mp2_smnif_tlr_2 & MP2_SMNIF_TLR_2_MASK_MASK) >> MP2_SMNIF_TLR_2_MASK_SHIFT)
#define MP2_SMNIF_TLR_2_GET_RD_ACC(mp2_smnif_tlr_2) \
     ((mp2_smnif_tlr_2 & MP2_SMNIF_TLR_2_RD_ACC_MASK) >> MP2_SMNIF_TLR_2_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_2_GET_WR_ACC(mp2_smnif_tlr_2) \
     ((mp2_smnif_tlr_2 & MP2_SMNIF_TLR_2_WR_ACC_MASK) >> MP2_SMNIF_TLR_2_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_2_GET_SLV_ADDR(mp2_smnif_tlr_2) \
     ((mp2_smnif_tlr_2 & MP2_SMNIF_TLR_2_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_2_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_2_GET_VF_ACC(mp2_smnif_tlr_2) \
     ((mp2_smnif_tlr_2 & MP2_SMNIF_TLR_2_VF_ACC_MASK) >> MP2_SMNIF_TLR_2_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_2_GET_VF_ACC_ENB(mp2_smnif_tlr_2) \
     ((mp2_smnif_tlr_2 & MP2_SMNIF_TLR_2_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_2_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_2_GET_VALID(mp2_smnif_tlr_2) \
     ((mp2_smnif_tlr_2 & MP2_SMNIF_TLR_2_VALID_MASK) >> MP2_SMNIF_TLR_2_VALID_SHIFT)

#define MP2_SMNIF_TLR_2_SET_MASK(mp2_smnif_tlr_2_reg, mask) \
     mp2_smnif_tlr_2_reg = (mp2_smnif_tlr_2_reg & ~MP2_SMNIF_TLR_2_MASK_MASK) | (mask << MP2_SMNIF_TLR_2_MASK_SHIFT)
#define MP2_SMNIF_TLR_2_SET_RD_ACC(mp2_smnif_tlr_2_reg, rd_acc) \
     mp2_smnif_tlr_2_reg = (mp2_smnif_tlr_2_reg & ~MP2_SMNIF_TLR_2_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_2_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_2_SET_WR_ACC(mp2_smnif_tlr_2_reg, wr_acc) \
     mp2_smnif_tlr_2_reg = (mp2_smnif_tlr_2_reg & ~MP2_SMNIF_TLR_2_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_2_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_2_SET_SLV_ADDR(mp2_smnif_tlr_2_reg, slv_addr) \
     mp2_smnif_tlr_2_reg = (mp2_smnif_tlr_2_reg & ~MP2_SMNIF_TLR_2_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_2_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_2_SET_VF_ACC(mp2_smnif_tlr_2_reg, vf_acc) \
     mp2_smnif_tlr_2_reg = (mp2_smnif_tlr_2_reg & ~MP2_SMNIF_TLR_2_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_2_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_2_SET_VF_ACC_ENB(mp2_smnif_tlr_2_reg, vf_acc_enb) \
     mp2_smnif_tlr_2_reg = (mp2_smnif_tlr_2_reg & ~MP2_SMNIF_TLR_2_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_2_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_2_SET_VALID(mp2_smnif_tlr_2_reg, valid) \
     mp2_smnif_tlr_2_reg = (mp2_smnif_tlr_2_reg & ~MP2_SMNIF_TLR_2_VALID_MASK) | (valid << MP2_SMNIF_TLR_2_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_2_t {
          unsigned int mask                           : MP2_SMNIF_TLR_2_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_2_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_2_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_2_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_2_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_2_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_2_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_2_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_2_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_2_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_2_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_2_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_2_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_2_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_2_MASK_SIZE;
     } mp2_smnif_tlr_2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_2_t f;
} mp2_smnif_tlr_2_u;


/*
 * MP2_SMNIF_TLR_ADDR_2 struct
 */

#define MP2_SMNIF_TLR_ADDR_2_REG_SIZE  32
#define MP2_SMNIF_TLR_ADDR_2_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_2_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_2_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_2_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_2_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_2_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_2_MASK \
     (MP2_SMNIF_TLR_ADDR_2_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_2_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_2_DEFAULT   0xffff0000

#define MP2_SMNIF_TLR_ADDR_2_GET_START_ADDR(mp2_smnif_tlr_addr_2) \
     ((mp2_smnif_tlr_addr_2 & MP2_SMNIF_TLR_ADDR_2_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_2_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_2_GET_END_ADDR(mp2_smnif_tlr_addr_2) \
     ((mp2_smnif_tlr_addr_2 & MP2_SMNIF_TLR_ADDR_2_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_2_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_2_SET_START_ADDR(mp2_smnif_tlr_addr_2_reg, start_addr) \
     mp2_smnif_tlr_addr_2_reg = (mp2_smnif_tlr_addr_2_reg & ~MP2_SMNIF_TLR_ADDR_2_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_2_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_2_SET_END_ADDR(mp2_smnif_tlr_addr_2_reg, end_addr) \
     mp2_smnif_tlr_addr_2_reg = (mp2_smnif_tlr_addr_2_reg & ~MP2_SMNIF_TLR_ADDR_2_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_2_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_2_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_2_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_2_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_2_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_2_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_2_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_2_t f;
} mp2_smnif_tlr_addr_2_u;


/*
 * MP2_SMNIF_TLR_3 struct
 */

#define MP2_SMNIF_TLR_3_REG_SIZE       32
#define MP2_SMNIF_TLR_3_MASK_SIZE      8
#define MP2_SMNIF_TLR_3_RD_ACC_SIZE    1
#define MP2_SMNIF_TLR_3_WR_ACC_SIZE    1
#define MP2_SMNIF_TLR_3_SLV_ADDR_SIZE  4
#define MP2_SMNIF_TLR_3_VF_ACC_SIZE    1
#define MP2_SMNIF_TLR_3_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_3_VALID_SIZE     1

#define MP2_SMNIF_TLR_3_MASK_SHIFT     0
#define MP2_SMNIF_TLR_3_RD_ACC_SHIFT   8
#define MP2_SMNIF_TLR_3_WR_ACC_SHIFT   9
#define MP2_SMNIF_TLR_3_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_3_VF_ACC_SHIFT   14
#define MP2_SMNIF_TLR_3_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_3_VALID_SHIFT    16

#define MP2_SMNIF_TLR_3_MASK_MASK      0xff
#define MP2_SMNIF_TLR_3_RD_ACC_MASK    0x100
#define MP2_SMNIF_TLR_3_WR_ACC_MASK    0x200
#define MP2_SMNIF_TLR_3_SLV_ADDR_MASK  0x3c00
#define MP2_SMNIF_TLR_3_VF_ACC_MASK    0x4000
#define MP2_SMNIF_TLR_3_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_3_VALID_MASK     0x10000

#define MP2_SMNIF_TLR_3_MASK \
     (MP2_SMNIF_TLR_3_MASK_MASK | \
      MP2_SMNIF_TLR_3_RD_ACC_MASK | \
      MP2_SMNIF_TLR_3_WR_ACC_MASK | \
      MP2_SMNIF_TLR_3_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_3_VF_ACC_MASK | \
      MP2_SMNIF_TLR_3_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_3_VALID_MASK)

#define MP2_SMNIF_TLR_3_DEFAULT        0x00010fff

#define MP2_SMNIF_TLR_3_GET_MASK(mp2_smnif_tlr_3) \
     ((mp2_smnif_tlr_3 & MP2_SMNIF_TLR_3_MASK_MASK) >> MP2_SMNIF_TLR_3_MASK_SHIFT)
#define MP2_SMNIF_TLR_3_GET_RD_ACC(mp2_smnif_tlr_3) \
     ((mp2_smnif_tlr_3 & MP2_SMNIF_TLR_3_RD_ACC_MASK) >> MP2_SMNIF_TLR_3_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_3_GET_WR_ACC(mp2_smnif_tlr_3) \
     ((mp2_smnif_tlr_3 & MP2_SMNIF_TLR_3_WR_ACC_MASK) >> MP2_SMNIF_TLR_3_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_3_GET_SLV_ADDR(mp2_smnif_tlr_3) \
     ((mp2_smnif_tlr_3 & MP2_SMNIF_TLR_3_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_3_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_3_GET_VF_ACC(mp2_smnif_tlr_3) \
     ((mp2_smnif_tlr_3 & MP2_SMNIF_TLR_3_VF_ACC_MASK) >> MP2_SMNIF_TLR_3_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_3_GET_VF_ACC_ENB(mp2_smnif_tlr_3) \
     ((mp2_smnif_tlr_3 & MP2_SMNIF_TLR_3_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_3_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_3_GET_VALID(mp2_smnif_tlr_3) \
     ((mp2_smnif_tlr_3 & MP2_SMNIF_TLR_3_VALID_MASK) >> MP2_SMNIF_TLR_3_VALID_SHIFT)

#define MP2_SMNIF_TLR_3_SET_MASK(mp2_smnif_tlr_3_reg, mask) \
     mp2_smnif_tlr_3_reg = (mp2_smnif_tlr_3_reg & ~MP2_SMNIF_TLR_3_MASK_MASK) | (mask << MP2_SMNIF_TLR_3_MASK_SHIFT)
#define MP2_SMNIF_TLR_3_SET_RD_ACC(mp2_smnif_tlr_3_reg, rd_acc) \
     mp2_smnif_tlr_3_reg = (mp2_smnif_tlr_3_reg & ~MP2_SMNIF_TLR_3_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_3_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_3_SET_WR_ACC(mp2_smnif_tlr_3_reg, wr_acc) \
     mp2_smnif_tlr_3_reg = (mp2_smnif_tlr_3_reg & ~MP2_SMNIF_TLR_3_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_3_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_3_SET_SLV_ADDR(mp2_smnif_tlr_3_reg, slv_addr) \
     mp2_smnif_tlr_3_reg = (mp2_smnif_tlr_3_reg & ~MP2_SMNIF_TLR_3_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_3_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_3_SET_VF_ACC(mp2_smnif_tlr_3_reg, vf_acc) \
     mp2_smnif_tlr_3_reg = (mp2_smnif_tlr_3_reg & ~MP2_SMNIF_TLR_3_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_3_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_3_SET_VF_ACC_ENB(mp2_smnif_tlr_3_reg, vf_acc_enb) \
     mp2_smnif_tlr_3_reg = (mp2_smnif_tlr_3_reg & ~MP2_SMNIF_TLR_3_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_3_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_3_SET_VALID(mp2_smnif_tlr_3_reg, valid) \
     mp2_smnif_tlr_3_reg = (mp2_smnif_tlr_3_reg & ~MP2_SMNIF_TLR_3_VALID_MASK) | (valid << MP2_SMNIF_TLR_3_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_3_t {
          unsigned int mask                           : MP2_SMNIF_TLR_3_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_3_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_3_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_3_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_3_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_3_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_3_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_3_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_3_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_3_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_3_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_3_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_3_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_3_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_3_MASK_SIZE;
     } mp2_smnif_tlr_3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_3_t f;
} mp2_smnif_tlr_3_u;


/*
 * MP2_SMNIF_TLR_ADDR_3 struct
 */

#define MP2_SMNIF_TLR_ADDR_3_REG_SIZE  32
#define MP2_SMNIF_TLR_ADDR_3_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_3_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_3_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_3_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_3_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_3_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_3_MASK \
     (MP2_SMNIF_TLR_ADDR_3_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_3_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_3_DEFAULT   0xffff0000

#define MP2_SMNIF_TLR_ADDR_3_GET_START_ADDR(mp2_smnif_tlr_addr_3) \
     ((mp2_smnif_tlr_addr_3 & MP2_SMNIF_TLR_ADDR_3_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_3_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_3_GET_END_ADDR(mp2_smnif_tlr_addr_3) \
     ((mp2_smnif_tlr_addr_3 & MP2_SMNIF_TLR_ADDR_3_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_3_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_3_SET_START_ADDR(mp2_smnif_tlr_addr_3_reg, start_addr) \
     mp2_smnif_tlr_addr_3_reg = (mp2_smnif_tlr_addr_3_reg & ~MP2_SMNIF_TLR_ADDR_3_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_3_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_3_SET_END_ADDR(mp2_smnif_tlr_addr_3_reg, end_addr) \
     mp2_smnif_tlr_addr_3_reg = (mp2_smnif_tlr_addr_3_reg & ~MP2_SMNIF_TLR_ADDR_3_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_3_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_3_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_3_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_3_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_3_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_3_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_3_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_3_t f;
} mp2_smnif_tlr_addr_3_u;


/*
 * MP2_SMNIF_TLR_4 struct
 */

#define MP2_SMNIF_TLR_4_REG_SIZE       32
#define MP2_SMNIF_TLR_4_MASK_SIZE      8
#define MP2_SMNIF_TLR_4_RD_ACC_SIZE    1
#define MP2_SMNIF_TLR_4_WR_ACC_SIZE    1
#define MP2_SMNIF_TLR_4_SLV_ADDR_SIZE  4
#define MP2_SMNIF_TLR_4_VF_ACC_SIZE    1
#define MP2_SMNIF_TLR_4_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_4_VALID_SIZE     1

#define MP2_SMNIF_TLR_4_MASK_SHIFT     0
#define MP2_SMNIF_TLR_4_RD_ACC_SHIFT   8
#define MP2_SMNIF_TLR_4_WR_ACC_SHIFT   9
#define MP2_SMNIF_TLR_4_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_4_VF_ACC_SHIFT   14
#define MP2_SMNIF_TLR_4_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_4_VALID_SHIFT    16

#define MP2_SMNIF_TLR_4_MASK_MASK      0xff
#define MP2_SMNIF_TLR_4_RD_ACC_MASK    0x100
#define MP2_SMNIF_TLR_4_WR_ACC_MASK    0x200
#define MP2_SMNIF_TLR_4_SLV_ADDR_MASK  0x3c00
#define MP2_SMNIF_TLR_4_VF_ACC_MASK    0x4000
#define MP2_SMNIF_TLR_4_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_4_VALID_MASK     0x10000

#define MP2_SMNIF_TLR_4_MASK \
     (MP2_SMNIF_TLR_4_MASK_MASK | \
      MP2_SMNIF_TLR_4_RD_ACC_MASK | \
      MP2_SMNIF_TLR_4_WR_ACC_MASK | \
      MP2_SMNIF_TLR_4_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_4_VF_ACC_MASK | \
      MP2_SMNIF_TLR_4_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_4_VALID_MASK)

#define MP2_SMNIF_TLR_4_DEFAULT        0x000113ff

#define MP2_SMNIF_TLR_4_GET_MASK(mp2_smnif_tlr_4) \
     ((mp2_smnif_tlr_4 & MP2_SMNIF_TLR_4_MASK_MASK) >> MP2_SMNIF_TLR_4_MASK_SHIFT)
#define MP2_SMNIF_TLR_4_GET_RD_ACC(mp2_smnif_tlr_4) \
     ((mp2_smnif_tlr_4 & MP2_SMNIF_TLR_4_RD_ACC_MASK) >> MP2_SMNIF_TLR_4_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_4_GET_WR_ACC(mp2_smnif_tlr_4) \
     ((mp2_smnif_tlr_4 & MP2_SMNIF_TLR_4_WR_ACC_MASK) >> MP2_SMNIF_TLR_4_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_4_GET_SLV_ADDR(mp2_smnif_tlr_4) \
     ((mp2_smnif_tlr_4 & MP2_SMNIF_TLR_4_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_4_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_4_GET_VF_ACC(mp2_smnif_tlr_4) \
     ((mp2_smnif_tlr_4 & MP2_SMNIF_TLR_4_VF_ACC_MASK) >> MP2_SMNIF_TLR_4_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_4_GET_VF_ACC_ENB(mp2_smnif_tlr_4) \
     ((mp2_smnif_tlr_4 & MP2_SMNIF_TLR_4_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_4_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_4_GET_VALID(mp2_smnif_tlr_4) \
     ((mp2_smnif_tlr_4 & MP2_SMNIF_TLR_4_VALID_MASK) >> MP2_SMNIF_TLR_4_VALID_SHIFT)

#define MP2_SMNIF_TLR_4_SET_MASK(mp2_smnif_tlr_4_reg, mask) \
     mp2_smnif_tlr_4_reg = (mp2_smnif_tlr_4_reg & ~MP2_SMNIF_TLR_4_MASK_MASK) | (mask << MP2_SMNIF_TLR_4_MASK_SHIFT)
#define MP2_SMNIF_TLR_4_SET_RD_ACC(mp2_smnif_tlr_4_reg, rd_acc) \
     mp2_smnif_tlr_4_reg = (mp2_smnif_tlr_4_reg & ~MP2_SMNIF_TLR_4_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_4_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_4_SET_WR_ACC(mp2_smnif_tlr_4_reg, wr_acc) \
     mp2_smnif_tlr_4_reg = (mp2_smnif_tlr_4_reg & ~MP2_SMNIF_TLR_4_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_4_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_4_SET_SLV_ADDR(mp2_smnif_tlr_4_reg, slv_addr) \
     mp2_smnif_tlr_4_reg = (mp2_smnif_tlr_4_reg & ~MP2_SMNIF_TLR_4_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_4_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_4_SET_VF_ACC(mp2_smnif_tlr_4_reg, vf_acc) \
     mp2_smnif_tlr_4_reg = (mp2_smnif_tlr_4_reg & ~MP2_SMNIF_TLR_4_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_4_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_4_SET_VF_ACC_ENB(mp2_smnif_tlr_4_reg, vf_acc_enb) \
     mp2_smnif_tlr_4_reg = (mp2_smnif_tlr_4_reg & ~MP2_SMNIF_TLR_4_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_4_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_4_SET_VALID(mp2_smnif_tlr_4_reg, valid) \
     mp2_smnif_tlr_4_reg = (mp2_smnif_tlr_4_reg & ~MP2_SMNIF_TLR_4_VALID_MASK) | (valid << MP2_SMNIF_TLR_4_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_4_t {
          unsigned int mask                           : MP2_SMNIF_TLR_4_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_4_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_4_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_4_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_4_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_4_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_4_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_4_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_4_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_4_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_4_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_4_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_4_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_4_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_4_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_4_MASK_SIZE;
     } mp2_smnif_tlr_4_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_4_t f;
} mp2_smnif_tlr_4_u;


/*
 * MP2_SMNIF_TLR_ADDR_4 struct
 */

#define MP2_SMNIF_TLR_ADDR_4_REG_SIZE  32
#define MP2_SMNIF_TLR_ADDR_4_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_4_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_4_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_4_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_4_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_4_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_4_MASK \
     (MP2_SMNIF_TLR_ADDR_4_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_4_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_4_DEFAULT   0xffff0000

#define MP2_SMNIF_TLR_ADDR_4_GET_START_ADDR(mp2_smnif_tlr_addr_4) \
     ((mp2_smnif_tlr_addr_4 & MP2_SMNIF_TLR_ADDR_4_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_4_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_4_GET_END_ADDR(mp2_smnif_tlr_addr_4) \
     ((mp2_smnif_tlr_addr_4 & MP2_SMNIF_TLR_ADDR_4_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_4_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_4_SET_START_ADDR(mp2_smnif_tlr_addr_4_reg, start_addr) \
     mp2_smnif_tlr_addr_4_reg = (mp2_smnif_tlr_addr_4_reg & ~MP2_SMNIF_TLR_ADDR_4_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_4_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_4_SET_END_ADDR(mp2_smnif_tlr_addr_4_reg, end_addr) \
     mp2_smnif_tlr_addr_4_reg = (mp2_smnif_tlr_addr_4_reg & ~MP2_SMNIF_TLR_ADDR_4_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_4_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_4_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_4_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_4_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_4_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_4_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_4_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_4_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_4_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_4_t f;
} mp2_smnif_tlr_addr_4_u;


/*
 * MP2_SMNIF_TLR_5 struct
 */

#define MP2_SMNIF_TLR_5_REG_SIZE       32
#define MP2_SMNIF_TLR_5_MASK_SIZE      8
#define MP2_SMNIF_TLR_5_RD_ACC_SIZE    1
#define MP2_SMNIF_TLR_5_WR_ACC_SIZE    1
#define MP2_SMNIF_TLR_5_SLV_ADDR_SIZE  4
#define MP2_SMNIF_TLR_5_VF_ACC_SIZE    1
#define MP2_SMNIF_TLR_5_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_5_VALID_SIZE     1

#define MP2_SMNIF_TLR_5_MASK_SHIFT     0
#define MP2_SMNIF_TLR_5_RD_ACC_SHIFT   8
#define MP2_SMNIF_TLR_5_WR_ACC_SHIFT   9
#define MP2_SMNIF_TLR_5_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_5_VF_ACC_SHIFT   14
#define MP2_SMNIF_TLR_5_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_5_VALID_SHIFT    16

#define MP2_SMNIF_TLR_5_MASK_MASK      0xff
#define MP2_SMNIF_TLR_5_RD_ACC_MASK    0x100
#define MP2_SMNIF_TLR_5_WR_ACC_MASK    0x200
#define MP2_SMNIF_TLR_5_SLV_ADDR_MASK  0x3c00
#define MP2_SMNIF_TLR_5_VF_ACC_MASK    0x4000
#define MP2_SMNIF_TLR_5_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_5_VALID_MASK     0x10000

#define MP2_SMNIF_TLR_5_MASK \
     (MP2_SMNIF_TLR_5_MASK_MASK | \
      MP2_SMNIF_TLR_5_RD_ACC_MASK | \
      MP2_SMNIF_TLR_5_WR_ACC_MASK | \
      MP2_SMNIF_TLR_5_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_5_VF_ACC_MASK | \
      MP2_SMNIF_TLR_5_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_5_VALID_MASK)

#define MP2_SMNIF_TLR_5_DEFAULT        0x000117ff

#define MP2_SMNIF_TLR_5_GET_MASK(mp2_smnif_tlr_5) \
     ((mp2_smnif_tlr_5 & MP2_SMNIF_TLR_5_MASK_MASK) >> MP2_SMNIF_TLR_5_MASK_SHIFT)
#define MP2_SMNIF_TLR_5_GET_RD_ACC(mp2_smnif_tlr_5) \
     ((mp2_smnif_tlr_5 & MP2_SMNIF_TLR_5_RD_ACC_MASK) >> MP2_SMNIF_TLR_5_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_5_GET_WR_ACC(mp2_smnif_tlr_5) \
     ((mp2_smnif_tlr_5 & MP2_SMNIF_TLR_5_WR_ACC_MASK) >> MP2_SMNIF_TLR_5_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_5_GET_SLV_ADDR(mp2_smnif_tlr_5) \
     ((mp2_smnif_tlr_5 & MP2_SMNIF_TLR_5_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_5_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_5_GET_VF_ACC(mp2_smnif_tlr_5) \
     ((mp2_smnif_tlr_5 & MP2_SMNIF_TLR_5_VF_ACC_MASK) >> MP2_SMNIF_TLR_5_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_5_GET_VF_ACC_ENB(mp2_smnif_tlr_5) \
     ((mp2_smnif_tlr_5 & MP2_SMNIF_TLR_5_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_5_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_5_GET_VALID(mp2_smnif_tlr_5) \
     ((mp2_smnif_tlr_5 & MP2_SMNIF_TLR_5_VALID_MASK) >> MP2_SMNIF_TLR_5_VALID_SHIFT)

#define MP2_SMNIF_TLR_5_SET_MASK(mp2_smnif_tlr_5_reg, mask) \
     mp2_smnif_tlr_5_reg = (mp2_smnif_tlr_5_reg & ~MP2_SMNIF_TLR_5_MASK_MASK) | (mask << MP2_SMNIF_TLR_5_MASK_SHIFT)
#define MP2_SMNIF_TLR_5_SET_RD_ACC(mp2_smnif_tlr_5_reg, rd_acc) \
     mp2_smnif_tlr_5_reg = (mp2_smnif_tlr_5_reg & ~MP2_SMNIF_TLR_5_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_5_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_5_SET_WR_ACC(mp2_smnif_tlr_5_reg, wr_acc) \
     mp2_smnif_tlr_5_reg = (mp2_smnif_tlr_5_reg & ~MP2_SMNIF_TLR_5_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_5_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_5_SET_SLV_ADDR(mp2_smnif_tlr_5_reg, slv_addr) \
     mp2_smnif_tlr_5_reg = (mp2_smnif_tlr_5_reg & ~MP2_SMNIF_TLR_5_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_5_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_5_SET_VF_ACC(mp2_smnif_tlr_5_reg, vf_acc) \
     mp2_smnif_tlr_5_reg = (mp2_smnif_tlr_5_reg & ~MP2_SMNIF_TLR_5_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_5_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_5_SET_VF_ACC_ENB(mp2_smnif_tlr_5_reg, vf_acc_enb) \
     mp2_smnif_tlr_5_reg = (mp2_smnif_tlr_5_reg & ~MP2_SMNIF_TLR_5_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_5_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_5_SET_VALID(mp2_smnif_tlr_5_reg, valid) \
     mp2_smnif_tlr_5_reg = (mp2_smnif_tlr_5_reg & ~MP2_SMNIF_TLR_5_VALID_MASK) | (valid << MP2_SMNIF_TLR_5_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_5_t {
          unsigned int mask                           : MP2_SMNIF_TLR_5_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_5_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_5_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_5_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_5_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_5_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_5_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_5_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_5_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_5_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_5_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_5_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_5_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_5_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_5_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_5_MASK_SIZE;
     } mp2_smnif_tlr_5_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_5_t f;
} mp2_smnif_tlr_5_u;


/*
 * MP2_SMNIF_TLR_ADDR_5 struct
 */

#define MP2_SMNIF_TLR_ADDR_5_REG_SIZE  32
#define MP2_SMNIF_TLR_ADDR_5_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_5_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_5_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_5_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_5_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_5_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_5_MASK \
     (MP2_SMNIF_TLR_ADDR_5_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_5_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_5_DEFAULT   0xffff0000

#define MP2_SMNIF_TLR_ADDR_5_GET_START_ADDR(mp2_smnif_tlr_addr_5) \
     ((mp2_smnif_tlr_addr_5 & MP2_SMNIF_TLR_ADDR_5_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_5_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_5_GET_END_ADDR(mp2_smnif_tlr_addr_5) \
     ((mp2_smnif_tlr_addr_5 & MP2_SMNIF_TLR_ADDR_5_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_5_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_5_SET_START_ADDR(mp2_smnif_tlr_addr_5_reg, start_addr) \
     mp2_smnif_tlr_addr_5_reg = (mp2_smnif_tlr_addr_5_reg & ~MP2_SMNIF_TLR_ADDR_5_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_5_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_5_SET_END_ADDR(mp2_smnif_tlr_addr_5_reg, end_addr) \
     mp2_smnif_tlr_addr_5_reg = (mp2_smnif_tlr_addr_5_reg & ~MP2_SMNIF_TLR_ADDR_5_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_5_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_5_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_5_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_5_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_5_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_5_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_5_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_5_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_5_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_5_t f;
} mp2_smnif_tlr_addr_5_u;


/*
 * MP2_SMNIF_TLR_6 struct
 */

#define MP2_SMNIF_TLR_6_REG_SIZE       32
#define MP2_SMNIF_TLR_6_MASK_SIZE      8
#define MP2_SMNIF_TLR_6_RD_ACC_SIZE    1
#define MP2_SMNIF_TLR_6_WR_ACC_SIZE    1
#define MP2_SMNIF_TLR_6_SLV_ADDR_SIZE  4
#define MP2_SMNIF_TLR_6_VF_ACC_SIZE    1
#define MP2_SMNIF_TLR_6_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_6_VALID_SIZE     1

#define MP2_SMNIF_TLR_6_MASK_SHIFT     0
#define MP2_SMNIF_TLR_6_RD_ACC_SHIFT   8
#define MP2_SMNIF_TLR_6_WR_ACC_SHIFT   9
#define MP2_SMNIF_TLR_6_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_6_VF_ACC_SHIFT   14
#define MP2_SMNIF_TLR_6_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_6_VALID_SHIFT    16

#define MP2_SMNIF_TLR_6_MASK_MASK      0xff
#define MP2_SMNIF_TLR_6_RD_ACC_MASK    0x100
#define MP2_SMNIF_TLR_6_WR_ACC_MASK    0x200
#define MP2_SMNIF_TLR_6_SLV_ADDR_MASK  0x3c00
#define MP2_SMNIF_TLR_6_VF_ACC_MASK    0x4000
#define MP2_SMNIF_TLR_6_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_6_VALID_MASK     0x10000

#define MP2_SMNIF_TLR_6_MASK \
     (MP2_SMNIF_TLR_6_MASK_MASK | \
      MP2_SMNIF_TLR_6_RD_ACC_MASK | \
      MP2_SMNIF_TLR_6_WR_ACC_MASK | \
      MP2_SMNIF_TLR_6_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_6_VF_ACC_MASK | \
      MP2_SMNIF_TLR_6_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_6_VALID_MASK)

#define MP2_SMNIF_TLR_6_DEFAULT        0x00011bff

#define MP2_SMNIF_TLR_6_GET_MASK(mp2_smnif_tlr_6) \
     ((mp2_smnif_tlr_6 & MP2_SMNIF_TLR_6_MASK_MASK) >> MP2_SMNIF_TLR_6_MASK_SHIFT)
#define MP2_SMNIF_TLR_6_GET_RD_ACC(mp2_smnif_tlr_6) \
     ((mp2_smnif_tlr_6 & MP2_SMNIF_TLR_6_RD_ACC_MASK) >> MP2_SMNIF_TLR_6_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_6_GET_WR_ACC(mp2_smnif_tlr_6) \
     ((mp2_smnif_tlr_6 & MP2_SMNIF_TLR_6_WR_ACC_MASK) >> MP2_SMNIF_TLR_6_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_6_GET_SLV_ADDR(mp2_smnif_tlr_6) \
     ((mp2_smnif_tlr_6 & MP2_SMNIF_TLR_6_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_6_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_6_GET_VF_ACC(mp2_smnif_tlr_6) \
     ((mp2_smnif_tlr_6 & MP2_SMNIF_TLR_6_VF_ACC_MASK) >> MP2_SMNIF_TLR_6_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_6_GET_VF_ACC_ENB(mp2_smnif_tlr_6) \
     ((mp2_smnif_tlr_6 & MP2_SMNIF_TLR_6_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_6_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_6_GET_VALID(mp2_smnif_tlr_6) \
     ((mp2_smnif_tlr_6 & MP2_SMNIF_TLR_6_VALID_MASK) >> MP2_SMNIF_TLR_6_VALID_SHIFT)

#define MP2_SMNIF_TLR_6_SET_MASK(mp2_smnif_tlr_6_reg, mask) \
     mp2_smnif_tlr_6_reg = (mp2_smnif_tlr_6_reg & ~MP2_SMNIF_TLR_6_MASK_MASK) | (mask << MP2_SMNIF_TLR_6_MASK_SHIFT)
#define MP2_SMNIF_TLR_6_SET_RD_ACC(mp2_smnif_tlr_6_reg, rd_acc) \
     mp2_smnif_tlr_6_reg = (mp2_smnif_tlr_6_reg & ~MP2_SMNIF_TLR_6_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_6_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_6_SET_WR_ACC(mp2_smnif_tlr_6_reg, wr_acc) \
     mp2_smnif_tlr_6_reg = (mp2_smnif_tlr_6_reg & ~MP2_SMNIF_TLR_6_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_6_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_6_SET_SLV_ADDR(mp2_smnif_tlr_6_reg, slv_addr) \
     mp2_smnif_tlr_6_reg = (mp2_smnif_tlr_6_reg & ~MP2_SMNIF_TLR_6_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_6_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_6_SET_VF_ACC(mp2_smnif_tlr_6_reg, vf_acc) \
     mp2_smnif_tlr_6_reg = (mp2_smnif_tlr_6_reg & ~MP2_SMNIF_TLR_6_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_6_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_6_SET_VF_ACC_ENB(mp2_smnif_tlr_6_reg, vf_acc_enb) \
     mp2_smnif_tlr_6_reg = (mp2_smnif_tlr_6_reg & ~MP2_SMNIF_TLR_6_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_6_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_6_SET_VALID(mp2_smnif_tlr_6_reg, valid) \
     mp2_smnif_tlr_6_reg = (mp2_smnif_tlr_6_reg & ~MP2_SMNIF_TLR_6_VALID_MASK) | (valid << MP2_SMNIF_TLR_6_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_6_t {
          unsigned int mask                           : MP2_SMNIF_TLR_6_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_6_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_6_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_6_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_6_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_6_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_6_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_6_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_6_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_6_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_6_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_6_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_6_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_6_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_6_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_6_MASK_SIZE;
     } mp2_smnif_tlr_6_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_6_t f;
} mp2_smnif_tlr_6_u;


/*
 * MP2_SMNIF_TLR_ADDR_6 struct
 */

#define MP2_SMNIF_TLR_ADDR_6_REG_SIZE  32
#define MP2_SMNIF_TLR_ADDR_6_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_6_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_6_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_6_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_6_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_6_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_6_MASK \
     (MP2_SMNIF_TLR_ADDR_6_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_6_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_6_DEFAULT   0xffff0000

#define MP2_SMNIF_TLR_ADDR_6_GET_START_ADDR(mp2_smnif_tlr_addr_6) \
     ((mp2_smnif_tlr_addr_6 & MP2_SMNIF_TLR_ADDR_6_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_6_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_6_GET_END_ADDR(mp2_smnif_tlr_addr_6) \
     ((mp2_smnif_tlr_addr_6 & MP2_SMNIF_TLR_ADDR_6_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_6_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_6_SET_START_ADDR(mp2_smnif_tlr_addr_6_reg, start_addr) \
     mp2_smnif_tlr_addr_6_reg = (mp2_smnif_tlr_addr_6_reg & ~MP2_SMNIF_TLR_ADDR_6_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_6_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_6_SET_END_ADDR(mp2_smnif_tlr_addr_6_reg, end_addr) \
     mp2_smnif_tlr_addr_6_reg = (mp2_smnif_tlr_addr_6_reg & ~MP2_SMNIF_TLR_ADDR_6_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_6_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_6_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_6_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_6_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_6_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_6_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_6_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_6_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_6_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_6_t f;
} mp2_smnif_tlr_addr_6_u;


/*
 * MP2_SMNIF_TLR_7 struct
 */

#define MP2_SMNIF_TLR_7_REG_SIZE       32
#define MP2_SMNIF_TLR_7_MASK_SIZE      8
#define MP2_SMNIF_TLR_7_RD_ACC_SIZE    1
#define MP2_SMNIF_TLR_7_WR_ACC_SIZE    1
#define MP2_SMNIF_TLR_7_SLV_ADDR_SIZE  4
#define MP2_SMNIF_TLR_7_VF_ACC_SIZE    1
#define MP2_SMNIF_TLR_7_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_7_VALID_SIZE     1

#define MP2_SMNIF_TLR_7_MASK_SHIFT     0
#define MP2_SMNIF_TLR_7_RD_ACC_SHIFT   8
#define MP2_SMNIF_TLR_7_WR_ACC_SHIFT   9
#define MP2_SMNIF_TLR_7_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_7_VF_ACC_SHIFT   14
#define MP2_SMNIF_TLR_7_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_7_VALID_SHIFT    16

#define MP2_SMNIF_TLR_7_MASK_MASK      0xff
#define MP2_SMNIF_TLR_7_RD_ACC_MASK    0x100
#define MP2_SMNIF_TLR_7_WR_ACC_MASK    0x200
#define MP2_SMNIF_TLR_7_SLV_ADDR_MASK  0x3c00
#define MP2_SMNIF_TLR_7_VF_ACC_MASK    0x4000
#define MP2_SMNIF_TLR_7_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_7_VALID_MASK     0x10000

#define MP2_SMNIF_TLR_7_MASK \
     (MP2_SMNIF_TLR_7_MASK_MASK | \
      MP2_SMNIF_TLR_7_RD_ACC_MASK | \
      MP2_SMNIF_TLR_7_WR_ACC_MASK | \
      MP2_SMNIF_TLR_7_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_7_VF_ACC_MASK | \
      MP2_SMNIF_TLR_7_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_7_VALID_MASK)

#define MP2_SMNIF_TLR_7_DEFAULT        0x00011fff

#define MP2_SMNIF_TLR_7_GET_MASK(mp2_smnif_tlr_7) \
     ((mp2_smnif_tlr_7 & MP2_SMNIF_TLR_7_MASK_MASK) >> MP2_SMNIF_TLR_7_MASK_SHIFT)
#define MP2_SMNIF_TLR_7_GET_RD_ACC(mp2_smnif_tlr_7) \
     ((mp2_smnif_tlr_7 & MP2_SMNIF_TLR_7_RD_ACC_MASK) >> MP2_SMNIF_TLR_7_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_7_GET_WR_ACC(mp2_smnif_tlr_7) \
     ((mp2_smnif_tlr_7 & MP2_SMNIF_TLR_7_WR_ACC_MASK) >> MP2_SMNIF_TLR_7_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_7_GET_SLV_ADDR(mp2_smnif_tlr_7) \
     ((mp2_smnif_tlr_7 & MP2_SMNIF_TLR_7_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_7_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_7_GET_VF_ACC(mp2_smnif_tlr_7) \
     ((mp2_smnif_tlr_7 & MP2_SMNIF_TLR_7_VF_ACC_MASK) >> MP2_SMNIF_TLR_7_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_7_GET_VF_ACC_ENB(mp2_smnif_tlr_7) \
     ((mp2_smnif_tlr_7 & MP2_SMNIF_TLR_7_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_7_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_7_GET_VALID(mp2_smnif_tlr_7) \
     ((mp2_smnif_tlr_7 & MP2_SMNIF_TLR_7_VALID_MASK) >> MP2_SMNIF_TLR_7_VALID_SHIFT)

#define MP2_SMNIF_TLR_7_SET_MASK(mp2_smnif_tlr_7_reg, mask) \
     mp2_smnif_tlr_7_reg = (mp2_smnif_tlr_7_reg & ~MP2_SMNIF_TLR_7_MASK_MASK) | (mask << MP2_SMNIF_TLR_7_MASK_SHIFT)
#define MP2_SMNIF_TLR_7_SET_RD_ACC(mp2_smnif_tlr_7_reg, rd_acc) \
     mp2_smnif_tlr_7_reg = (mp2_smnif_tlr_7_reg & ~MP2_SMNIF_TLR_7_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_7_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_7_SET_WR_ACC(mp2_smnif_tlr_7_reg, wr_acc) \
     mp2_smnif_tlr_7_reg = (mp2_smnif_tlr_7_reg & ~MP2_SMNIF_TLR_7_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_7_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_7_SET_SLV_ADDR(mp2_smnif_tlr_7_reg, slv_addr) \
     mp2_smnif_tlr_7_reg = (mp2_smnif_tlr_7_reg & ~MP2_SMNIF_TLR_7_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_7_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_7_SET_VF_ACC(mp2_smnif_tlr_7_reg, vf_acc) \
     mp2_smnif_tlr_7_reg = (mp2_smnif_tlr_7_reg & ~MP2_SMNIF_TLR_7_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_7_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_7_SET_VF_ACC_ENB(mp2_smnif_tlr_7_reg, vf_acc_enb) \
     mp2_smnif_tlr_7_reg = (mp2_smnif_tlr_7_reg & ~MP2_SMNIF_TLR_7_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_7_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_7_SET_VALID(mp2_smnif_tlr_7_reg, valid) \
     mp2_smnif_tlr_7_reg = (mp2_smnif_tlr_7_reg & ~MP2_SMNIF_TLR_7_VALID_MASK) | (valid << MP2_SMNIF_TLR_7_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_7_t {
          unsigned int mask                           : MP2_SMNIF_TLR_7_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_7_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_7_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_7_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_7_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_7_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_7_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_7_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_7_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_7_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_7_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_7_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_7_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_7_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_7_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_7_MASK_SIZE;
     } mp2_smnif_tlr_7_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_7_t f;
} mp2_smnif_tlr_7_u;


/*
 * MP2_SMNIF_TLR_ADDR_7 struct
 */

#define MP2_SMNIF_TLR_ADDR_7_REG_SIZE  32
#define MP2_SMNIF_TLR_ADDR_7_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_7_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_7_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_7_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_7_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_7_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_7_MASK \
     (MP2_SMNIF_TLR_ADDR_7_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_7_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_7_DEFAULT   0xffff0000

#define MP2_SMNIF_TLR_ADDR_7_GET_START_ADDR(mp2_smnif_tlr_addr_7) \
     ((mp2_smnif_tlr_addr_7 & MP2_SMNIF_TLR_ADDR_7_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_7_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_7_GET_END_ADDR(mp2_smnif_tlr_addr_7) \
     ((mp2_smnif_tlr_addr_7 & MP2_SMNIF_TLR_ADDR_7_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_7_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_7_SET_START_ADDR(mp2_smnif_tlr_addr_7_reg, start_addr) \
     mp2_smnif_tlr_addr_7_reg = (mp2_smnif_tlr_addr_7_reg & ~MP2_SMNIF_TLR_ADDR_7_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_7_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_7_SET_END_ADDR(mp2_smnif_tlr_addr_7_reg, end_addr) \
     mp2_smnif_tlr_addr_7_reg = (mp2_smnif_tlr_addr_7_reg & ~MP2_SMNIF_TLR_ADDR_7_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_7_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_7_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_7_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_7_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_7_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_7_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_7_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_7_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_7_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_7_t f;
} mp2_smnif_tlr_addr_7_u;


/*
 * MP2_SMNIF_TLR_8 struct
 */

#define MP2_SMNIF_TLR_8_REG_SIZE       32
#define MP2_SMNIF_TLR_8_MASK_SIZE      8
#define MP2_SMNIF_TLR_8_RD_ACC_SIZE    1
#define MP2_SMNIF_TLR_8_WR_ACC_SIZE    1
#define MP2_SMNIF_TLR_8_SLV_ADDR_SIZE  4
#define MP2_SMNIF_TLR_8_VF_ACC_SIZE    1
#define MP2_SMNIF_TLR_8_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_8_VALID_SIZE     1

#define MP2_SMNIF_TLR_8_MASK_SHIFT     0
#define MP2_SMNIF_TLR_8_RD_ACC_SHIFT   8
#define MP2_SMNIF_TLR_8_WR_ACC_SHIFT   9
#define MP2_SMNIF_TLR_8_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_8_VF_ACC_SHIFT   14
#define MP2_SMNIF_TLR_8_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_8_VALID_SHIFT    16

#define MP2_SMNIF_TLR_8_MASK_MASK      0xff
#define MP2_SMNIF_TLR_8_RD_ACC_MASK    0x100
#define MP2_SMNIF_TLR_8_WR_ACC_MASK    0x200
#define MP2_SMNIF_TLR_8_SLV_ADDR_MASK  0x3c00
#define MP2_SMNIF_TLR_8_VF_ACC_MASK    0x4000
#define MP2_SMNIF_TLR_8_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_8_VALID_MASK     0x10000

#define MP2_SMNIF_TLR_8_MASK \
     (MP2_SMNIF_TLR_8_MASK_MASK | \
      MP2_SMNIF_TLR_8_RD_ACC_MASK | \
      MP2_SMNIF_TLR_8_WR_ACC_MASK | \
      MP2_SMNIF_TLR_8_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_8_VF_ACC_MASK | \
      MP2_SMNIF_TLR_8_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_8_VALID_MASK)

#define MP2_SMNIF_TLR_8_DEFAULT        0x000123ff

#define MP2_SMNIF_TLR_8_GET_MASK(mp2_smnif_tlr_8) \
     ((mp2_smnif_tlr_8 & MP2_SMNIF_TLR_8_MASK_MASK) >> MP2_SMNIF_TLR_8_MASK_SHIFT)
#define MP2_SMNIF_TLR_8_GET_RD_ACC(mp2_smnif_tlr_8) \
     ((mp2_smnif_tlr_8 & MP2_SMNIF_TLR_8_RD_ACC_MASK) >> MP2_SMNIF_TLR_8_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_8_GET_WR_ACC(mp2_smnif_tlr_8) \
     ((mp2_smnif_tlr_8 & MP2_SMNIF_TLR_8_WR_ACC_MASK) >> MP2_SMNIF_TLR_8_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_8_GET_SLV_ADDR(mp2_smnif_tlr_8) \
     ((mp2_smnif_tlr_8 & MP2_SMNIF_TLR_8_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_8_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_8_GET_VF_ACC(mp2_smnif_tlr_8) \
     ((mp2_smnif_tlr_8 & MP2_SMNIF_TLR_8_VF_ACC_MASK) >> MP2_SMNIF_TLR_8_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_8_GET_VF_ACC_ENB(mp2_smnif_tlr_8) \
     ((mp2_smnif_tlr_8 & MP2_SMNIF_TLR_8_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_8_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_8_GET_VALID(mp2_smnif_tlr_8) \
     ((mp2_smnif_tlr_8 & MP2_SMNIF_TLR_8_VALID_MASK) >> MP2_SMNIF_TLR_8_VALID_SHIFT)

#define MP2_SMNIF_TLR_8_SET_MASK(mp2_smnif_tlr_8_reg, mask) \
     mp2_smnif_tlr_8_reg = (mp2_smnif_tlr_8_reg & ~MP2_SMNIF_TLR_8_MASK_MASK) | (mask << MP2_SMNIF_TLR_8_MASK_SHIFT)
#define MP2_SMNIF_TLR_8_SET_RD_ACC(mp2_smnif_tlr_8_reg, rd_acc) \
     mp2_smnif_tlr_8_reg = (mp2_smnif_tlr_8_reg & ~MP2_SMNIF_TLR_8_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_8_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_8_SET_WR_ACC(mp2_smnif_tlr_8_reg, wr_acc) \
     mp2_smnif_tlr_8_reg = (mp2_smnif_tlr_8_reg & ~MP2_SMNIF_TLR_8_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_8_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_8_SET_SLV_ADDR(mp2_smnif_tlr_8_reg, slv_addr) \
     mp2_smnif_tlr_8_reg = (mp2_smnif_tlr_8_reg & ~MP2_SMNIF_TLR_8_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_8_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_8_SET_VF_ACC(mp2_smnif_tlr_8_reg, vf_acc) \
     mp2_smnif_tlr_8_reg = (mp2_smnif_tlr_8_reg & ~MP2_SMNIF_TLR_8_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_8_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_8_SET_VF_ACC_ENB(mp2_smnif_tlr_8_reg, vf_acc_enb) \
     mp2_smnif_tlr_8_reg = (mp2_smnif_tlr_8_reg & ~MP2_SMNIF_TLR_8_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_8_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_8_SET_VALID(mp2_smnif_tlr_8_reg, valid) \
     mp2_smnif_tlr_8_reg = (mp2_smnif_tlr_8_reg & ~MP2_SMNIF_TLR_8_VALID_MASK) | (valid << MP2_SMNIF_TLR_8_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_8_t {
          unsigned int mask                           : MP2_SMNIF_TLR_8_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_8_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_8_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_8_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_8_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_8_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_8_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_8_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_8_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_8_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_8_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_8_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_8_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_8_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_8_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_8_MASK_SIZE;
     } mp2_smnif_tlr_8_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_8_t f;
} mp2_smnif_tlr_8_u;


/*
 * MP2_SMNIF_TLR_ADDR_8 struct
 */

#define MP2_SMNIF_TLR_ADDR_8_REG_SIZE  32
#define MP2_SMNIF_TLR_ADDR_8_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_8_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_8_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_8_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_8_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_8_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_8_MASK \
     (MP2_SMNIF_TLR_ADDR_8_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_8_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_8_DEFAULT   0xffff0000

#define MP2_SMNIF_TLR_ADDR_8_GET_START_ADDR(mp2_smnif_tlr_addr_8) \
     ((mp2_smnif_tlr_addr_8 & MP2_SMNIF_TLR_ADDR_8_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_8_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_8_GET_END_ADDR(mp2_smnif_tlr_addr_8) \
     ((mp2_smnif_tlr_addr_8 & MP2_SMNIF_TLR_ADDR_8_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_8_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_8_SET_START_ADDR(mp2_smnif_tlr_addr_8_reg, start_addr) \
     mp2_smnif_tlr_addr_8_reg = (mp2_smnif_tlr_addr_8_reg & ~MP2_SMNIF_TLR_ADDR_8_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_8_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_8_SET_END_ADDR(mp2_smnif_tlr_addr_8_reg, end_addr) \
     mp2_smnif_tlr_addr_8_reg = (mp2_smnif_tlr_addr_8_reg & ~MP2_SMNIF_TLR_ADDR_8_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_8_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_8_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_8_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_8_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_8_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_8_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_8_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_8_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_8_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_8_t f;
} mp2_smnif_tlr_addr_8_u;


/*
 * MP2_SMNIF_TLR_9 struct
 */

#define MP2_SMNIF_TLR_9_REG_SIZE       32
#define MP2_SMNIF_TLR_9_MASK_SIZE      8
#define MP2_SMNIF_TLR_9_RD_ACC_SIZE    1
#define MP2_SMNIF_TLR_9_WR_ACC_SIZE    1
#define MP2_SMNIF_TLR_9_SLV_ADDR_SIZE  4
#define MP2_SMNIF_TLR_9_VF_ACC_SIZE    1
#define MP2_SMNIF_TLR_9_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_9_VALID_SIZE     1

#define MP2_SMNIF_TLR_9_MASK_SHIFT     0
#define MP2_SMNIF_TLR_9_RD_ACC_SHIFT   8
#define MP2_SMNIF_TLR_9_WR_ACC_SHIFT   9
#define MP2_SMNIF_TLR_9_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_9_VF_ACC_SHIFT   14
#define MP2_SMNIF_TLR_9_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_9_VALID_SHIFT    16

#define MP2_SMNIF_TLR_9_MASK_MASK      0xff
#define MP2_SMNIF_TLR_9_RD_ACC_MASK    0x100
#define MP2_SMNIF_TLR_9_WR_ACC_MASK    0x200
#define MP2_SMNIF_TLR_9_SLV_ADDR_MASK  0x3c00
#define MP2_SMNIF_TLR_9_VF_ACC_MASK    0x4000
#define MP2_SMNIF_TLR_9_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_9_VALID_MASK     0x10000

#define MP2_SMNIF_TLR_9_MASK \
     (MP2_SMNIF_TLR_9_MASK_MASK | \
      MP2_SMNIF_TLR_9_RD_ACC_MASK | \
      MP2_SMNIF_TLR_9_WR_ACC_MASK | \
      MP2_SMNIF_TLR_9_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_9_VF_ACC_MASK | \
      MP2_SMNIF_TLR_9_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_9_VALID_MASK)

#define MP2_SMNIF_TLR_9_DEFAULT        0x000127ff

#define MP2_SMNIF_TLR_9_GET_MASK(mp2_smnif_tlr_9) \
     ((mp2_smnif_tlr_9 & MP2_SMNIF_TLR_9_MASK_MASK) >> MP2_SMNIF_TLR_9_MASK_SHIFT)
#define MP2_SMNIF_TLR_9_GET_RD_ACC(mp2_smnif_tlr_9) \
     ((mp2_smnif_tlr_9 & MP2_SMNIF_TLR_9_RD_ACC_MASK) >> MP2_SMNIF_TLR_9_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_9_GET_WR_ACC(mp2_smnif_tlr_9) \
     ((mp2_smnif_tlr_9 & MP2_SMNIF_TLR_9_WR_ACC_MASK) >> MP2_SMNIF_TLR_9_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_9_GET_SLV_ADDR(mp2_smnif_tlr_9) \
     ((mp2_smnif_tlr_9 & MP2_SMNIF_TLR_9_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_9_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_9_GET_VF_ACC(mp2_smnif_tlr_9) \
     ((mp2_smnif_tlr_9 & MP2_SMNIF_TLR_9_VF_ACC_MASK) >> MP2_SMNIF_TLR_9_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_9_GET_VF_ACC_ENB(mp2_smnif_tlr_9) \
     ((mp2_smnif_tlr_9 & MP2_SMNIF_TLR_9_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_9_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_9_GET_VALID(mp2_smnif_tlr_9) \
     ((mp2_smnif_tlr_9 & MP2_SMNIF_TLR_9_VALID_MASK) >> MP2_SMNIF_TLR_9_VALID_SHIFT)

#define MP2_SMNIF_TLR_9_SET_MASK(mp2_smnif_tlr_9_reg, mask) \
     mp2_smnif_tlr_9_reg = (mp2_smnif_tlr_9_reg & ~MP2_SMNIF_TLR_9_MASK_MASK) | (mask << MP2_SMNIF_TLR_9_MASK_SHIFT)
#define MP2_SMNIF_TLR_9_SET_RD_ACC(mp2_smnif_tlr_9_reg, rd_acc) \
     mp2_smnif_tlr_9_reg = (mp2_smnif_tlr_9_reg & ~MP2_SMNIF_TLR_9_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_9_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_9_SET_WR_ACC(mp2_smnif_tlr_9_reg, wr_acc) \
     mp2_smnif_tlr_9_reg = (mp2_smnif_tlr_9_reg & ~MP2_SMNIF_TLR_9_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_9_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_9_SET_SLV_ADDR(mp2_smnif_tlr_9_reg, slv_addr) \
     mp2_smnif_tlr_9_reg = (mp2_smnif_tlr_9_reg & ~MP2_SMNIF_TLR_9_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_9_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_9_SET_VF_ACC(mp2_smnif_tlr_9_reg, vf_acc) \
     mp2_smnif_tlr_9_reg = (mp2_smnif_tlr_9_reg & ~MP2_SMNIF_TLR_9_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_9_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_9_SET_VF_ACC_ENB(mp2_smnif_tlr_9_reg, vf_acc_enb) \
     mp2_smnif_tlr_9_reg = (mp2_smnif_tlr_9_reg & ~MP2_SMNIF_TLR_9_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_9_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_9_SET_VALID(mp2_smnif_tlr_9_reg, valid) \
     mp2_smnif_tlr_9_reg = (mp2_smnif_tlr_9_reg & ~MP2_SMNIF_TLR_9_VALID_MASK) | (valid << MP2_SMNIF_TLR_9_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_9_t {
          unsigned int mask                           : MP2_SMNIF_TLR_9_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_9_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_9_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_9_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_9_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_9_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_9_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_9_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_9_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_9_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_9_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_9_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_9_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_9_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_9_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_9_MASK_SIZE;
     } mp2_smnif_tlr_9_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_9_t f;
} mp2_smnif_tlr_9_u;


/*
 * MP2_SMNIF_TLR_ADDR_9 struct
 */

#define MP2_SMNIF_TLR_ADDR_9_REG_SIZE  32
#define MP2_SMNIF_TLR_ADDR_9_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_9_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_9_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_9_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_9_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_9_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_9_MASK \
     (MP2_SMNIF_TLR_ADDR_9_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_9_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_9_DEFAULT   0xffff0000

#define MP2_SMNIF_TLR_ADDR_9_GET_START_ADDR(mp2_smnif_tlr_addr_9) \
     ((mp2_smnif_tlr_addr_9 & MP2_SMNIF_TLR_ADDR_9_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_9_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_9_GET_END_ADDR(mp2_smnif_tlr_addr_9) \
     ((mp2_smnif_tlr_addr_9 & MP2_SMNIF_TLR_ADDR_9_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_9_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_9_SET_START_ADDR(mp2_smnif_tlr_addr_9_reg, start_addr) \
     mp2_smnif_tlr_addr_9_reg = (mp2_smnif_tlr_addr_9_reg & ~MP2_SMNIF_TLR_ADDR_9_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_9_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_9_SET_END_ADDR(mp2_smnif_tlr_addr_9_reg, end_addr) \
     mp2_smnif_tlr_addr_9_reg = (mp2_smnif_tlr_addr_9_reg & ~MP2_SMNIF_TLR_ADDR_9_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_9_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_9_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_9_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_9_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_9_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_9_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_9_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_9_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_9_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_9_t f;
} mp2_smnif_tlr_addr_9_u;


/*
 * MP2_SMNIF_TLR_10 struct
 */

#define MP2_SMNIF_TLR_10_REG_SIZE      32
#define MP2_SMNIF_TLR_10_MASK_SIZE     8
#define MP2_SMNIF_TLR_10_RD_ACC_SIZE   1
#define MP2_SMNIF_TLR_10_WR_ACC_SIZE   1
#define MP2_SMNIF_TLR_10_SLV_ADDR_SIZE 4
#define MP2_SMNIF_TLR_10_VF_ACC_SIZE   1
#define MP2_SMNIF_TLR_10_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_10_VALID_SIZE    1

#define MP2_SMNIF_TLR_10_MASK_SHIFT    0
#define MP2_SMNIF_TLR_10_RD_ACC_SHIFT  8
#define MP2_SMNIF_TLR_10_WR_ACC_SHIFT  9
#define MP2_SMNIF_TLR_10_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_10_VF_ACC_SHIFT  14
#define MP2_SMNIF_TLR_10_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_10_VALID_SHIFT   16

#define MP2_SMNIF_TLR_10_MASK_MASK     0xff
#define MP2_SMNIF_TLR_10_RD_ACC_MASK   0x100
#define MP2_SMNIF_TLR_10_WR_ACC_MASK   0x200
#define MP2_SMNIF_TLR_10_SLV_ADDR_MASK 0x3c00
#define MP2_SMNIF_TLR_10_VF_ACC_MASK   0x4000
#define MP2_SMNIF_TLR_10_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_10_VALID_MASK    0x10000

#define MP2_SMNIF_TLR_10_MASK \
     (MP2_SMNIF_TLR_10_MASK_MASK | \
      MP2_SMNIF_TLR_10_RD_ACC_MASK | \
      MP2_SMNIF_TLR_10_WR_ACC_MASK | \
      MP2_SMNIF_TLR_10_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_10_VF_ACC_MASK | \
      MP2_SMNIF_TLR_10_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_10_VALID_MASK)

#define MP2_SMNIF_TLR_10_DEFAULT       0x00012bff

#define MP2_SMNIF_TLR_10_GET_MASK(mp2_smnif_tlr_10) \
     ((mp2_smnif_tlr_10 & MP2_SMNIF_TLR_10_MASK_MASK) >> MP2_SMNIF_TLR_10_MASK_SHIFT)
#define MP2_SMNIF_TLR_10_GET_RD_ACC(mp2_smnif_tlr_10) \
     ((mp2_smnif_tlr_10 & MP2_SMNIF_TLR_10_RD_ACC_MASK) >> MP2_SMNIF_TLR_10_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_10_GET_WR_ACC(mp2_smnif_tlr_10) \
     ((mp2_smnif_tlr_10 & MP2_SMNIF_TLR_10_WR_ACC_MASK) >> MP2_SMNIF_TLR_10_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_10_GET_SLV_ADDR(mp2_smnif_tlr_10) \
     ((mp2_smnif_tlr_10 & MP2_SMNIF_TLR_10_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_10_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_10_GET_VF_ACC(mp2_smnif_tlr_10) \
     ((mp2_smnif_tlr_10 & MP2_SMNIF_TLR_10_VF_ACC_MASK) >> MP2_SMNIF_TLR_10_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_10_GET_VF_ACC_ENB(mp2_smnif_tlr_10) \
     ((mp2_smnif_tlr_10 & MP2_SMNIF_TLR_10_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_10_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_10_GET_VALID(mp2_smnif_tlr_10) \
     ((mp2_smnif_tlr_10 & MP2_SMNIF_TLR_10_VALID_MASK) >> MP2_SMNIF_TLR_10_VALID_SHIFT)

#define MP2_SMNIF_TLR_10_SET_MASK(mp2_smnif_tlr_10_reg, mask) \
     mp2_smnif_tlr_10_reg = (mp2_smnif_tlr_10_reg & ~MP2_SMNIF_TLR_10_MASK_MASK) | (mask << MP2_SMNIF_TLR_10_MASK_SHIFT)
#define MP2_SMNIF_TLR_10_SET_RD_ACC(mp2_smnif_tlr_10_reg, rd_acc) \
     mp2_smnif_tlr_10_reg = (mp2_smnif_tlr_10_reg & ~MP2_SMNIF_TLR_10_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_10_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_10_SET_WR_ACC(mp2_smnif_tlr_10_reg, wr_acc) \
     mp2_smnif_tlr_10_reg = (mp2_smnif_tlr_10_reg & ~MP2_SMNIF_TLR_10_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_10_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_10_SET_SLV_ADDR(mp2_smnif_tlr_10_reg, slv_addr) \
     mp2_smnif_tlr_10_reg = (mp2_smnif_tlr_10_reg & ~MP2_SMNIF_TLR_10_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_10_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_10_SET_VF_ACC(mp2_smnif_tlr_10_reg, vf_acc) \
     mp2_smnif_tlr_10_reg = (mp2_smnif_tlr_10_reg & ~MP2_SMNIF_TLR_10_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_10_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_10_SET_VF_ACC_ENB(mp2_smnif_tlr_10_reg, vf_acc_enb) \
     mp2_smnif_tlr_10_reg = (mp2_smnif_tlr_10_reg & ~MP2_SMNIF_TLR_10_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_10_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_10_SET_VALID(mp2_smnif_tlr_10_reg, valid) \
     mp2_smnif_tlr_10_reg = (mp2_smnif_tlr_10_reg & ~MP2_SMNIF_TLR_10_VALID_MASK) | (valid << MP2_SMNIF_TLR_10_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_10_t {
          unsigned int mask                           : MP2_SMNIF_TLR_10_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_10_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_10_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_10_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_10_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_10_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_10_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_10_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_10_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_10_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_10_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_10_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_10_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_10_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_10_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_10_MASK_SIZE;
     } mp2_smnif_tlr_10_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_10_t f;
} mp2_smnif_tlr_10_u;


/*
 * MP2_SMNIF_TLR_ADDR_10 struct
 */

#define MP2_SMNIF_TLR_ADDR_10_REG_SIZE 32
#define MP2_SMNIF_TLR_ADDR_10_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_10_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_10_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_10_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_10_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_10_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_10_MASK \
     (MP2_SMNIF_TLR_ADDR_10_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_10_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_10_DEFAULT  0xffff0000

#define MP2_SMNIF_TLR_ADDR_10_GET_START_ADDR(mp2_smnif_tlr_addr_10) \
     ((mp2_smnif_tlr_addr_10 & MP2_SMNIF_TLR_ADDR_10_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_10_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_10_GET_END_ADDR(mp2_smnif_tlr_addr_10) \
     ((mp2_smnif_tlr_addr_10 & MP2_SMNIF_TLR_ADDR_10_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_10_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_10_SET_START_ADDR(mp2_smnif_tlr_addr_10_reg, start_addr) \
     mp2_smnif_tlr_addr_10_reg = (mp2_smnif_tlr_addr_10_reg & ~MP2_SMNIF_TLR_ADDR_10_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_10_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_10_SET_END_ADDR(mp2_smnif_tlr_addr_10_reg, end_addr) \
     mp2_smnif_tlr_addr_10_reg = (mp2_smnif_tlr_addr_10_reg & ~MP2_SMNIF_TLR_ADDR_10_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_10_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_10_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_10_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_10_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_10_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_10_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_10_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_10_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_10_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_10_t f;
} mp2_smnif_tlr_addr_10_u;


/*
 * MP2_SMNIF_TLR_11 struct
 */

#define MP2_SMNIF_TLR_11_REG_SIZE      32
#define MP2_SMNIF_TLR_11_MASK_SIZE     8
#define MP2_SMNIF_TLR_11_RD_ACC_SIZE   1
#define MP2_SMNIF_TLR_11_WR_ACC_SIZE   1
#define MP2_SMNIF_TLR_11_SLV_ADDR_SIZE 4
#define MP2_SMNIF_TLR_11_VF_ACC_SIZE   1
#define MP2_SMNIF_TLR_11_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_11_VALID_SIZE    1

#define MP2_SMNIF_TLR_11_MASK_SHIFT    0
#define MP2_SMNIF_TLR_11_RD_ACC_SHIFT  8
#define MP2_SMNIF_TLR_11_WR_ACC_SHIFT  9
#define MP2_SMNIF_TLR_11_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_11_VF_ACC_SHIFT  14
#define MP2_SMNIF_TLR_11_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_11_VALID_SHIFT   16

#define MP2_SMNIF_TLR_11_MASK_MASK     0xff
#define MP2_SMNIF_TLR_11_RD_ACC_MASK   0x100
#define MP2_SMNIF_TLR_11_WR_ACC_MASK   0x200
#define MP2_SMNIF_TLR_11_SLV_ADDR_MASK 0x3c00
#define MP2_SMNIF_TLR_11_VF_ACC_MASK   0x4000
#define MP2_SMNIF_TLR_11_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_11_VALID_MASK    0x10000

#define MP2_SMNIF_TLR_11_MASK \
     (MP2_SMNIF_TLR_11_MASK_MASK | \
      MP2_SMNIF_TLR_11_RD_ACC_MASK | \
      MP2_SMNIF_TLR_11_WR_ACC_MASK | \
      MP2_SMNIF_TLR_11_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_11_VF_ACC_MASK | \
      MP2_SMNIF_TLR_11_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_11_VALID_MASK)

#define MP2_SMNIF_TLR_11_DEFAULT       0x00012fff

#define MP2_SMNIF_TLR_11_GET_MASK(mp2_smnif_tlr_11) \
     ((mp2_smnif_tlr_11 & MP2_SMNIF_TLR_11_MASK_MASK) >> MP2_SMNIF_TLR_11_MASK_SHIFT)
#define MP2_SMNIF_TLR_11_GET_RD_ACC(mp2_smnif_tlr_11) \
     ((mp2_smnif_tlr_11 & MP2_SMNIF_TLR_11_RD_ACC_MASK) >> MP2_SMNIF_TLR_11_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_11_GET_WR_ACC(mp2_smnif_tlr_11) \
     ((mp2_smnif_tlr_11 & MP2_SMNIF_TLR_11_WR_ACC_MASK) >> MP2_SMNIF_TLR_11_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_11_GET_SLV_ADDR(mp2_smnif_tlr_11) \
     ((mp2_smnif_tlr_11 & MP2_SMNIF_TLR_11_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_11_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_11_GET_VF_ACC(mp2_smnif_tlr_11) \
     ((mp2_smnif_tlr_11 & MP2_SMNIF_TLR_11_VF_ACC_MASK) >> MP2_SMNIF_TLR_11_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_11_GET_VF_ACC_ENB(mp2_smnif_tlr_11) \
     ((mp2_smnif_tlr_11 & MP2_SMNIF_TLR_11_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_11_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_11_GET_VALID(mp2_smnif_tlr_11) \
     ((mp2_smnif_tlr_11 & MP2_SMNIF_TLR_11_VALID_MASK) >> MP2_SMNIF_TLR_11_VALID_SHIFT)

#define MP2_SMNIF_TLR_11_SET_MASK(mp2_smnif_tlr_11_reg, mask) \
     mp2_smnif_tlr_11_reg = (mp2_smnif_tlr_11_reg & ~MP2_SMNIF_TLR_11_MASK_MASK) | (mask << MP2_SMNIF_TLR_11_MASK_SHIFT)
#define MP2_SMNIF_TLR_11_SET_RD_ACC(mp2_smnif_tlr_11_reg, rd_acc) \
     mp2_smnif_tlr_11_reg = (mp2_smnif_tlr_11_reg & ~MP2_SMNIF_TLR_11_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_11_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_11_SET_WR_ACC(mp2_smnif_tlr_11_reg, wr_acc) \
     mp2_smnif_tlr_11_reg = (mp2_smnif_tlr_11_reg & ~MP2_SMNIF_TLR_11_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_11_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_11_SET_SLV_ADDR(mp2_smnif_tlr_11_reg, slv_addr) \
     mp2_smnif_tlr_11_reg = (mp2_smnif_tlr_11_reg & ~MP2_SMNIF_TLR_11_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_11_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_11_SET_VF_ACC(mp2_smnif_tlr_11_reg, vf_acc) \
     mp2_smnif_tlr_11_reg = (mp2_smnif_tlr_11_reg & ~MP2_SMNIF_TLR_11_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_11_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_11_SET_VF_ACC_ENB(mp2_smnif_tlr_11_reg, vf_acc_enb) \
     mp2_smnif_tlr_11_reg = (mp2_smnif_tlr_11_reg & ~MP2_SMNIF_TLR_11_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_11_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_11_SET_VALID(mp2_smnif_tlr_11_reg, valid) \
     mp2_smnif_tlr_11_reg = (mp2_smnif_tlr_11_reg & ~MP2_SMNIF_TLR_11_VALID_MASK) | (valid << MP2_SMNIF_TLR_11_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_11_t {
          unsigned int mask                           : MP2_SMNIF_TLR_11_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_11_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_11_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_11_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_11_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_11_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_11_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_11_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_11_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_11_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_11_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_11_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_11_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_11_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_11_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_11_MASK_SIZE;
     } mp2_smnif_tlr_11_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_11_t f;
} mp2_smnif_tlr_11_u;


/*
 * MP2_SMNIF_TLR_ADDR_11 struct
 */

#define MP2_SMNIF_TLR_ADDR_11_REG_SIZE 32
#define MP2_SMNIF_TLR_ADDR_11_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_11_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_11_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_11_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_11_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_11_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_11_MASK \
     (MP2_SMNIF_TLR_ADDR_11_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_11_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_11_DEFAULT  0xffff0000

#define MP2_SMNIF_TLR_ADDR_11_GET_START_ADDR(mp2_smnif_tlr_addr_11) \
     ((mp2_smnif_tlr_addr_11 & MP2_SMNIF_TLR_ADDR_11_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_11_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_11_GET_END_ADDR(mp2_smnif_tlr_addr_11) \
     ((mp2_smnif_tlr_addr_11 & MP2_SMNIF_TLR_ADDR_11_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_11_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_11_SET_START_ADDR(mp2_smnif_tlr_addr_11_reg, start_addr) \
     mp2_smnif_tlr_addr_11_reg = (mp2_smnif_tlr_addr_11_reg & ~MP2_SMNIF_TLR_ADDR_11_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_11_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_11_SET_END_ADDR(mp2_smnif_tlr_addr_11_reg, end_addr) \
     mp2_smnif_tlr_addr_11_reg = (mp2_smnif_tlr_addr_11_reg & ~MP2_SMNIF_TLR_ADDR_11_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_11_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_11_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_11_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_11_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_11_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_11_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_11_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_11_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_11_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_11_t f;
} mp2_smnif_tlr_addr_11_u;


/*
 * MP2_SMNIF_TLR_12 struct
 */

#define MP2_SMNIF_TLR_12_REG_SIZE      32
#define MP2_SMNIF_TLR_12_MASK_SIZE     8
#define MP2_SMNIF_TLR_12_RD_ACC_SIZE   1
#define MP2_SMNIF_TLR_12_WR_ACC_SIZE   1
#define MP2_SMNIF_TLR_12_SLV_ADDR_SIZE 4
#define MP2_SMNIF_TLR_12_VF_ACC_SIZE   1
#define MP2_SMNIF_TLR_12_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_12_VALID_SIZE    1

#define MP2_SMNIF_TLR_12_MASK_SHIFT    0
#define MP2_SMNIF_TLR_12_RD_ACC_SHIFT  8
#define MP2_SMNIF_TLR_12_WR_ACC_SHIFT  9
#define MP2_SMNIF_TLR_12_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_12_VF_ACC_SHIFT  14
#define MP2_SMNIF_TLR_12_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_12_VALID_SHIFT   16

#define MP2_SMNIF_TLR_12_MASK_MASK     0xff
#define MP2_SMNIF_TLR_12_RD_ACC_MASK   0x100
#define MP2_SMNIF_TLR_12_WR_ACC_MASK   0x200
#define MP2_SMNIF_TLR_12_SLV_ADDR_MASK 0x3c00
#define MP2_SMNIF_TLR_12_VF_ACC_MASK   0x4000
#define MP2_SMNIF_TLR_12_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_12_VALID_MASK    0x10000

#define MP2_SMNIF_TLR_12_MASK \
     (MP2_SMNIF_TLR_12_MASK_MASK | \
      MP2_SMNIF_TLR_12_RD_ACC_MASK | \
      MP2_SMNIF_TLR_12_WR_ACC_MASK | \
      MP2_SMNIF_TLR_12_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_12_VF_ACC_MASK | \
      MP2_SMNIF_TLR_12_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_12_VALID_MASK)

#define MP2_SMNIF_TLR_12_DEFAULT       0x000133ff

#define MP2_SMNIF_TLR_12_GET_MASK(mp2_smnif_tlr_12) \
     ((mp2_smnif_tlr_12 & MP2_SMNIF_TLR_12_MASK_MASK) >> MP2_SMNIF_TLR_12_MASK_SHIFT)
#define MP2_SMNIF_TLR_12_GET_RD_ACC(mp2_smnif_tlr_12) \
     ((mp2_smnif_tlr_12 & MP2_SMNIF_TLR_12_RD_ACC_MASK) >> MP2_SMNIF_TLR_12_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_12_GET_WR_ACC(mp2_smnif_tlr_12) \
     ((mp2_smnif_tlr_12 & MP2_SMNIF_TLR_12_WR_ACC_MASK) >> MP2_SMNIF_TLR_12_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_12_GET_SLV_ADDR(mp2_smnif_tlr_12) \
     ((mp2_smnif_tlr_12 & MP2_SMNIF_TLR_12_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_12_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_12_GET_VF_ACC(mp2_smnif_tlr_12) \
     ((mp2_smnif_tlr_12 & MP2_SMNIF_TLR_12_VF_ACC_MASK) >> MP2_SMNIF_TLR_12_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_12_GET_VF_ACC_ENB(mp2_smnif_tlr_12) \
     ((mp2_smnif_tlr_12 & MP2_SMNIF_TLR_12_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_12_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_12_GET_VALID(mp2_smnif_tlr_12) \
     ((mp2_smnif_tlr_12 & MP2_SMNIF_TLR_12_VALID_MASK) >> MP2_SMNIF_TLR_12_VALID_SHIFT)

#define MP2_SMNIF_TLR_12_SET_MASK(mp2_smnif_tlr_12_reg, mask) \
     mp2_smnif_tlr_12_reg = (mp2_smnif_tlr_12_reg & ~MP2_SMNIF_TLR_12_MASK_MASK) | (mask << MP2_SMNIF_TLR_12_MASK_SHIFT)
#define MP2_SMNIF_TLR_12_SET_RD_ACC(mp2_smnif_tlr_12_reg, rd_acc) \
     mp2_smnif_tlr_12_reg = (mp2_smnif_tlr_12_reg & ~MP2_SMNIF_TLR_12_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_12_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_12_SET_WR_ACC(mp2_smnif_tlr_12_reg, wr_acc) \
     mp2_smnif_tlr_12_reg = (mp2_smnif_tlr_12_reg & ~MP2_SMNIF_TLR_12_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_12_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_12_SET_SLV_ADDR(mp2_smnif_tlr_12_reg, slv_addr) \
     mp2_smnif_tlr_12_reg = (mp2_smnif_tlr_12_reg & ~MP2_SMNIF_TLR_12_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_12_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_12_SET_VF_ACC(mp2_smnif_tlr_12_reg, vf_acc) \
     mp2_smnif_tlr_12_reg = (mp2_smnif_tlr_12_reg & ~MP2_SMNIF_TLR_12_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_12_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_12_SET_VF_ACC_ENB(mp2_smnif_tlr_12_reg, vf_acc_enb) \
     mp2_smnif_tlr_12_reg = (mp2_smnif_tlr_12_reg & ~MP2_SMNIF_TLR_12_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_12_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_12_SET_VALID(mp2_smnif_tlr_12_reg, valid) \
     mp2_smnif_tlr_12_reg = (mp2_smnif_tlr_12_reg & ~MP2_SMNIF_TLR_12_VALID_MASK) | (valid << MP2_SMNIF_TLR_12_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_12_t {
          unsigned int mask                           : MP2_SMNIF_TLR_12_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_12_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_12_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_12_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_12_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_12_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_12_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_12_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_12_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_12_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_12_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_12_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_12_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_12_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_12_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_12_MASK_SIZE;
     } mp2_smnif_tlr_12_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_12_t f;
} mp2_smnif_tlr_12_u;


/*
 * MP2_SMNIF_TLR_ADDR_12 struct
 */

#define MP2_SMNIF_TLR_ADDR_12_REG_SIZE 32
#define MP2_SMNIF_TLR_ADDR_12_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_12_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_12_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_12_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_12_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_12_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_12_MASK \
     (MP2_SMNIF_TLR_ADDR_12_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_12_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_12_DEFAULT  0xffff0000

#define MP2_SMNIF_TLR_ADDR_12_GET_START_ADDR(mp2_smnif_tlr_addr_12) \
     ((mp2_smnif_tlr_addr_12 & MP2_SMNIF_TLR_ADDR_12_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_12_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_12_GET_END_ADDR(mp2_smnif_tlr_addr_12) \
     ((mp2_smnif_tlr_addr_12 & MP2_SMNIF_TLR_ADDR_12_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_12_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_12_SET_START_ADDR(mp2_smnif_tlr_addr_12_reg, start_addr) \
     mp2_smnif_tlr_addr_12_reg = (mp2_smnif_tlr_addr_12_reg & ~MP2_SMNIF_TLR_ADDR_12_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_12_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_12_SET_END_ADDR(mp2_smnif_tlr_addr_12_reg, end_addr) \
     mp2_smnif_tlr_addr_12_reg = (mp2_smnif_tlr_addr_12_reg & ~MP2_SMNIF_TLR_ADDR_12_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_12_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_12_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_12_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_12_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_12_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_12_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_12_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_12_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_12_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_12_t f;
} mp2_smnif_tlr_addr_12_u;


/*
 * MP2_SMNIF_TLR_13 struct
 */

#define MP2_SMNIF_TLR_13_REG_SIZE      32
#define MP2_SMNIF_TLR_13_MASK_SIZE     8
#define MP2_SMNIF_TLR_13_RD_ACC_SIZE   1
#define MP2_SMNIF_TLR_13_WR_ACC_SIZE   1
#define MP2_SMNIF_TLR_13_SLV_ADDR_SIZE 4
#define MP2_SMNIF_TLR_13_VF_ACC_SIZE   1
#define MP2_SMNIF_TLR_13_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_13_VALID_SIZE    1

#define MP2_SMNIF_TLR_13_MASK_SHIFT    0
#define MP2_SMNIF_TLR_13_RD_ACC_SHIFT  8
#define MP2_SMNIF_TLR_13_WR_ACC_SHIFT  9
#define MP2_SMNIF_TLR_13_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_13_VF_ACC_SHIFT  14
#define MP2_SMNIF_TLR_13_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_13_VALID_SHIFT   16

#define MP2_SMNIF_TLR_13_MASK_MASK     0xff
#define MP2_SMNIF_TLR_13_RD_ACC_MASK   0x100
#define MP2_SMNIF_TLR_13_WR_ACC_MASK   0x200
#define MP2_SMNIF_TLR_13_SLV_ADDR_MASK 0x3c00
#define MP2_SMNIF_TLR_13_VF_ACC_MASK   0x4000
#define MP2_SMNIF_TLR_13_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_13_VALID_MASK    0x10000

#define MP2_SMNIF_TLR_13_MASK \
     (MP2_SMNIF_TLR_13_MASK_MASK | \
      MP2_SMNIF_TLR_13_RD_ACC_MASK | \
      MP2_SMNIF_TLR_13_WR_ACC_MASK | \
      MP2_SMNIF_TLR_13_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_13_VF_ACC_MASK | \
      MP2_SMNIF_TLR_13_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_13_VALID_MASK)

#define MP2_SMNIF_TLR_13_DEFAULT       0x000137ff

#define MP2_SMNIF_TLR_13_GET_MASK(mp2_smnif_tlr_13) \
     ((mp2_smnif_tlr_13 & MP2_SMNIF_TLR_13_MASK_MASK) >> MP2_SMNIF_TLR_13_MASK_SHIFT)
#define MP2_SMNIF_TLR_13_GET_RD_ACC(mp2_smnif_tlr_13) \
     ((mp2_smnif_tlr_13 & MP2_SMNIF_TLR_13_RD_ACC_MASK) >> MP2_SMNIF_TLR_13_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_13_GET_WR_ACC(mp2_smnif_tlr_13) \
     ((mp2_smnif_tlr_13 & MP2_SMNIF_TLR_13_WR_ACC_MASK) >> MP2_SMNIF_TLR_13_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_13_GET_SLV_ADDR(mp2_smnif_tlr_13) \
     ((mp2_smnif_tlr_13 & MP2_SMNIF_TLR_13_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_13_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_13_GET_VF_ACC(mp2_smnif_tlr_13) \
     ((mp2_smnif_tlr_13 & MP2_SMNIF_TLR_13_VF_ACC_MASK) >> MP2_SMNIF_TLR_13_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_13_GET_VF_ACC_ENB(mp2_smnif_tlr_13) \
     ((mp2_smnif_tlr_13 & MP2_SMNIF_TLR_13_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_13_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_13_GET_VALID(mp2_smnif_tlr_13) \
     ((mp2_smnif_tlr_13 & MP2_SMNIF_TLR_13_VALID_MASK) >> MP2_SMNIF_TLR_13_VALID_SHIFT)

#define MP2_SMNIF_TLR_13_SET_MASK(mp2_smnif_tlr_13_reg, mask) \
     mp2_smnif_tlr_13_reg = (mp2_smnif_tlr_13_reg & ~MP2_SMNIF_TLR_13_MASK_MASK) | (mask << MP2_SMNIF_TLR_13_MASK_SHIFT)
#define MP2_SMNIF_TLR_13_SET_RD_ACC(mp2_smnif_tlr_13_reg, rd_acc) \
     mp2_smnif_tlr_13_reg = (mp2_smnif_tlr_13_reg & ~MP2_SMNIF_TLR_13_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_13_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_13_SET_WR_ACC(mp2_smnif_tlr_13_reg, wr_acc) \
     mp2_smnif_tlr_13_reg = (mp2_smnif_tlr_13_reg & ~MP2_SMNIF_TLR_13_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_13_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_13_SET_SLV_ADDR(mp2_smnif_tlr_13_reg, slv_addr) \
     mp2_smnif_tlr_13_reg = (mp2_smnif_tlr_13_reg & ~MP2_SMNIF_TLR_13_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_13_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_13_SET_VF_ACC(mp2_smnif_tlr_13_reg, vf_acc) \
     mp2_smnif_tlr_13_reg = (mp2_smnif_tlr_13_reg & ~MP2_SMNIF_TLR_13_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_13_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_13_SET_VF_ACC_ENB(mp2_smnif_tlr_13_reg, vf_acc_enb) \
     mp2_smnif_tlr_13_reg = (mp2_smnif_tlr_13_reg & ~MP2_SMNIF_TLR_13_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_13_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_13_SET_VALID(mp2_smnif_tlr_13_reg, valid) \
     mp2_smnif_tlr_13_reg = (mp2_smnif_tlr_13_reg & ~MP2_SMNIF_TLR_13_VALID_MASK) | (valid << MP2_SMNIF_TLR_13_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_13_t {
          unsigned int mask                           : MP2_SMNIF_TLR_13_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_13_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_13_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_13_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_13_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_13_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_13_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_13_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_13_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_13_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_13_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_13_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_13_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_13_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_13_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_13_MASK_SIZE;
     } mp2_smnif_tlr_13_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_13_t f;
} mp2_smnif_tlr_13_u;


/*
 * MP2_SMNIF_TLR_ADDR_13 struct
 */

#define MP2_SMNIF_TLR_ADDR_13_REG_SIZE 32
#define MP2_SMNIF_TLR_ADDR_13_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_13_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_13_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_13_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_13_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_13_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_13_MASK \
     (MP2_SMNIF_TLR_ADDR_13_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_13_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_13_DEFAULT  0xffff0000

#define MP2_SMNIF_TLR_ADDR_13_GET_START_ADDR(mp2_smnif_tlr_addr_13) \
     ((mp2_smnif_tlr_addr_13 & MP2_SMNIF_TLR_ADDR_13_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_13_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_13_GET_END_ADDR(mp2_smnif_tlr_addr_13) \
     ((mp2_smnif_tlr_addr_13 & MP2_SMNIF_TLR_ADDR_13_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_13_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_13_SET_START_ADDR(mp2_smnif_tlr_addr_13_reg, start_addr) \
     mp2_smnif_tlr_addr_13_reg = (mp2_smnif_tlr_addr_13_reg & ~MP2_SMNIF_TLR_ADDR_13_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_13_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_13_SET_END_ADDR(mp2_smnif_tlr_addr_13_reg, end_addr) \
     mp2_smnif_tlr_addr_13_reg = (mp2_smnif_tlr_addr_13_reg & ~MP2_SMNIF_TLR_ADDR_13_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_13_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_13_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_13_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_13_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_13_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_13_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_13_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_13_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_13_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_13_t f;
} mp2_smnif_tlr_addr_13_u;


/*
 * MP2_SMNIF_TLR_14 struct
 */

#define MP2_SMNIF_TLR_14_REG_SIZE      32
#define MP2_SMNIF_TLR_14_MASK_SIZE     8
#define MP2_SMNIF_TLR_14_RD_ACC_SIZE   1
#define MP2_SMNIF_TLR_14_WR_ACC_SIZE   1
#define MP2_SMNIF_TLR_14_SLV_ADDR_SIZE 4
#define MP2_SMNIF_TLR_14_VF_ACC_SIZE   1
#define MP2_SMNIF_TLR_14_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_14_VALID_SIZE    1

#define MP2_SMNIF_TLR_14_MASK_SHIFT    0
#define MP2_SMNIF_TLR_14_RD_ACC_SHIFT  8
#define MP2_SMNIF_TLR_14_WR_ACC_SHIFT  9
#define MP2_SMNIF_TLR_14_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_14_VF_ACC_SHIFT  14
#define MP2_SMNIF_TLR_14_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_14_VALID_SHIFT   16

#define MP2_SMNIF_TLR_14_MASK_MASK     0xff
#define MP2_SMNIF_TLR_14_RD_ACC_MASK   0x100
#define MP2_SMNIF_TLR_14_WR_ACC_MASK   0x200
#define MP2_SMNIF_TLR_14_SLV_ADDR_MASK 0x3c00
#define MP2_SMNIF_TLR_14_VF_ACC_MASK   0x4000
#define MP2_SMNIF_TLR_14_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_14_VALID_MASK    0x10000

#define MP2_SMNIF_TLR_14_MASK \
     (MP2_SMNIF_TLR_14_MASK_MASK | \
      MP2_SMNIF_TLR_14_RD_ACC_MASK | \
      MP2_SMNIF_TLR_14_WR_ACC_MASK | \
      MP2_SMNIF_TLR_14_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_14_VF_ACC_MASK | \
      MP2_SMNIF_TLR_14_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_14_VALID_MASK)

#define MP2_SMNIF_TLR_14_DEFAULT       0x00013bff

#define MP2_SMNIF_TLR_14_GET_MASK(mp2_smnif_tlr_14) \
     ((mp2_smnif_tlr_14 & MP2_SMNIF_TLR_14_MASK_MASK) >> MP2_SMNIF_TLR_14_MASK_SHIFT)
#define MP2_SMNIF_TLR_14_GET_RD_ACC(mp2_smnif_tlr_14) \
     ((mp2_smnif_tlr_14 & MP2_SMNIF_TLR_14_RD_ACC_MASK) >> MP2_SMNIF_TLR_14_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_14_GET_WR_ACC(mp2_smnif_tlr_14) \
     ((mp2_smnif_tlr_14 & MP2_SMNIF_TLR_14_WR_ACC_MASK) >> MP2_SMNIF_TLR_14_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_14_GET_SLV_ADDR(mp2_smnif_tlr_14) \
     ((mp2_smnif_tlr_14 & MP2_SMNIF_TLR_14_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_14_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_14_GET_VF_ACC(mp2_smnif_tlr_14) \
     ((mp2_smnif_tlr_14 & MP2_SMNIF_TLR_14_VF_ACC_MASK) >> MP2_SMNIF_TLR_14_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_14_GET_VF_ACC_ENB(mp2_smnif_tlr_14) \
     ((mp2_smnif_tlr_14 & MP2_SMNIF_TLR_14_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_14_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_14_GET_VALID(mp2_smnif_tlr_14) \
     ((mp2_smnif_tlr_14 & MP2_SMNIF_TLR_14_VALID_MASK) >> MP2_SMNIF_TLR_14_VALID_SHIFT)

#define MP2_SMNIF_TLR_14_SET_MASK(mp2_smnif_tlr_14_reg, mask) \
     mp2_smnif_tlr_14_reg = (mp2_smnif_tlr_14_reg & ~MP2_SMNIF_TLR_14_MASK_MASK) | (mask << MP2_SMNIF_TLR_14_MASK_SHIFT)
#define MP2_SMNIF_TLR_14_SET_RD_ACC(mp2_smnif_tlr_14_reg, rd_acc) \
     mp2_smnif_tlr_14_reg = (mp2_smnif_tlr_14_reg & ~MP2_SMNIF_TLR_14_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_14_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_14_SET_WR_ACC(mp2_smnif_tlr_14_reg, wr_acc) \
     mp2_smnif_tlr_14_reg = (mp2_smnif_tlr_14_reg & ~MP2_SMNIF_TLR_14_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_14_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_14_SET_SLV_ADDR(mp2_smnif_tlr_14_reg, slv_addr) \
     mp2_smnif_tlr_14_reg = (mp2_smnif_tlr_14_reg & ~MP2_SMNIF_TLR_14_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_14_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_14_SET_VF_ACC(mp2_smnif_tlr_14_reg, vf_acc) \
     mp2_smnif_tlr_14_reg = (mp2_smnif_tlr_14_reg & ~MP2_SMNIF_TLR_14_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_14_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_14_SET_VF_ACC_ENB(mp2_smnif_tlr_14_reg, vf_acc_enb) \
     mp2_smnif_tlr_14_reg = (mp2_smnif_tlr_14_reg & ~MP2_SMNIF_TLR_14_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_14_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_14_SET_VALID(mp2_smnif_tlr_14_reg, valid) \
     mp2_smnif_tlr_14_reg = (mp2_smnif_tlr_14_reg & ~MP2_SMNIF_TLR_14_VALID_MASK) | (valid << MP2_SMNIF_TLR_14_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_14_t {
          unsigned int mask                           : MP2_SMNIF_TLR_14_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_14_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_14_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_14_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_14_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_14_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_14_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_14_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_14_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_14_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_14_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_14_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_14_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_14_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_14_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_14_MASK_SIZE;
     } mp2_smnif_tlr_14_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_14_t f;
} mp2_smnif_tlr_14_u;


/*
 * MP2_SMNIF_TLR_ADDR_14 struct
 */

#define MP2_SMNIF_TLR_ADDR_14_REG_SIZE 32
#define MP2_SMNIF_TLR_ADDR_14_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_14_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_14_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_14_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_14_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_14_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_14_MASK \
     (MP2_SMNIF_TLR_ADDR_14_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_14_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_14_DEFAULT  0xffff0000

#define MP2_SMNIF_TLR_ADDR_14_GET_START_ADDR(mp2_smnif_tlr_addr_14) \
     ((mp2_smnif_tlr_addr_14 & MP2_SMNIF_TLR_ADDR_14_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_14_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_14_GET_END_ADDR(mp2_smnif_tlr_addr_14) \
     ((mp2_smnif_tlr_addr_14 & MP2_SMNIF_TLR_ADDR_14_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_14_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_14_SET_START_ADDR(mp2_smnif_tlr_addr_14_reg, start_addr) \
     mp2_smnif_tlr_addr_14_reg = (mp2_smnif_tlr_addr_14_reg & ~MP2_SMNIF_TLR_ADDR_14_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_14_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_14_SET_END_ADDR(mp2_smnif_tlr_addr_14_reg, end_addr) \
     mp2_smnif_tlr_addr_14_reg = (mp2_smnif_tlr_addr_14_reg & ~MP2_SMNIF_TLR_ADDR_14_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_14_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_14_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_14_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_14_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_14_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_14_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_14_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_14_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_14_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_14_t f;
} mp2_smnif_tlr_addr_14_u;


/*
 * MP2_SMNIF_TLR_15 struct
 */

#define MP2_SMNIF_TLR_15_REG_SIZE      32
#define MP2_SMNIF_TLR_15_MASK_SIZE     8
#define MP2_SMNIF_TLR_15_RD_ACC_SIZE   1
#define MP2_SMNIF_TLR_15_WR_ACC_SIZE   1
#define MP2_SMNIF_TLR_15_SLV_ADDR_SIZE 4
#define MP2_SMNIF_TLR_15_VF_ACC_SIZE   1
#define MP2_SMNIF_TLR_15_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_15_VALID_SIZE    1

#define MP2_SMNIF_TLR_15_MASK_SHIFT    0
#define MP2_SMNIF_TLR_15_RD_ACC_SHIFT  8
#define MP2_SMNIF_TLR_15_WR_ACC_SHIFT  9
#define MP2_SMNIF_TLR_15_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_15_VF_ACC_SHIFT  14
#define MP2_SMNIF_TLR_15_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_15_VALID_SHIFT   16

#define MP2_SMNIF_TLR_15_MASK_MASK     0xff
#define MP2_SMNIF_TLR_15_RD_ACC_MASK   0x100
#define MP2_SMNIF_TLR_15_WR_ACC_MASK   0x200
#define MP2_SMNIF_TLR_15_SLV_ADDR_MASK 0x3c00
#define MP2_SMNIF_TLR_15_VF_ACC_MASK   0x4000
#define MP2_SMNIF_TLR_15_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_15_VALID_MASK    0x10000

#define MP2_SMNIF_TLR_15_MASK \
     (MP2_SMNIF_TLR_15_MASK_MASK | \
      MP2_SMNIF_TLR_15_RD_ACC_MASK | \
      MP2_SMNIF_TLR_15_WR_ACC_MASK | \
      MP2_SMNIF_TLR_15_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_15_VF_ACC_MASK | \
      MP2_SMNIF_TLR_15_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_15_VALID_MASK)

#define MP2_SMNIF_TLR_15_DEFAULT       0x00013fff

#define MP2_SMNIF_TLR_15_GET_MASK(mp2_smnif_tlr_15) \
     ((mp2_smnif_tlr_15 & MP2_SMNIF_TLR_15_MASK_MASK) >> MP2_SMNIF_TLR_15_MASK_SHIFT)
#define MP2_SMNIF_TLR_15_GET_RD_ACC(mp2_smnif_tlr_15) \
     ((mp2_smnif_tlr_15 & MP2_SMNIF_TLR_15_RD_ACC_MASK) >> MP2_SMNIF_TLR_15_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_15_GET_WR_ACC(mp2_smnif_tlr_15) \
     ((mp2_smnif_tlr_15 & MP2_SMNIF_TLR_15_WR_ACC_MASK) >> MP2_SMNIF_TLR_15_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_15_GET_SLV_ADDR(mp2_smnif_tlr_15) \
     ((mp2_smnif_tlr_15 & MP2_SMNIF_TLR_15_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_15_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_15_GET_VF_ACC(mp2_smnif_tlr_15) \
     ((mp2_smnif_tlr_15 & MP2_SMNIF_TLR_15_VF_ACC_MASK) >> MP2_SMNIF_TLR_15_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_15_GET_VF_ACC_ENB(mp2_smnif_tlr_15) \
     ((mp2_smnif_tlr_15 & MP2_SMNIF_TLR_15_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_15_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_15_GET_VALID(mp2_smnif_tlr_15) \
     ((mp2_smnif_tlr_15 & MP2_SMNIF_TLR_15_VALID_MASK) >> MP2_SMNIF_TLR_15_VALID_SHIFT)

#define MP2_SMNIF_TLR_15_SET_MASK(mp2_smnif_tlr_15_reg, mask) \
     mp2_smnif_tlr_15_reg = (mp2_smnif_tlr_15_reg & ~MP2_SMNIF_TLR_15_MASK_MASK) | (mask << MP2_SMNIF_TLR_15_MASK_SHIFT)
#define MP2_SMNIF_TLR_15_SET_RD_ACC(mp2_smnif_tlr_15_reg, rd_acc) \
     mp2_smnif_tlr_15_reg = (mp2_smnif_tlr_15_reg & ~MP2_SMNIF_TLR_15_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_15_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_15_SET_WR_ACC(mp2_smnif_tlr_15_reg, wr_acc) \
     mp2_smnif_tlr_15_reg = (mp2_smnif_tlr_15_reg & ~MP2_SMNIF_TLR_15_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_15_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_15_SET_SLV_ADDR(mp2_smnif_tlr_15_reg, slv_addr) \
     mp2_smnif_tlr_15_reg = (mp2_smnif_tlr_15_reg & ~MP2_SMNIF_TLR_15_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_15_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_15_SET_VF_ACC(mp2_smnif_tlr_15_reg, vf_acc) \
     mp2_smnif_tlr_15_reg = (mp2_smnif_tlr_15_reg & ~MP2_SMNIF_TLR_15_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_15_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_15_SET_VF_ACC_ENB(mp2_smnif_tlr_15_reg, vf_acc_enb) \
     mp2_smnif_tlr_15_reg = (mp2_smnif_tlr_15_reg & ~MP2_SMNIF_TLR_15_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_15_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_15_SET_VALID(mp2_smnif_tlr_15_reg, valid) \
     mp2_smnif_tlr_15_reg = (mp2_smnif_tlr_15_reg & ~MP2_SMNIF_TLR_15_VALID_MASK) | (valid << MP2_SMNIF_TLR_15_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_15_t {
          unsigned int mask                           : MP2_SMNIF_TLR_15_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_15_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_15_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_15_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_15_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_15_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_15_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_15_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_15_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_15_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_15_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_15_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_15_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_15_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_15_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_15_MASK_SIZE;
     } mp2_smnif_tlr_15_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_15_t f;
} mp2_smnif_tlr_15_u;


/*
 * MP2_SMNIF_TLR_ADDR_15 struct
 */

#define MP2_SMNIF_TLR_ADDR_15_REG_SIZE 32
#define MP2_SMNIF_TLR_ADDR_15_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_15_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_15_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_15_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_15_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_15_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_15_MASK \
     (MP2_SMNIF_TLR_ADDR_15_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_15_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_15_DEFAULT  0xffff0000

#define MP2_SMNIF_TLR_ADDR_15_GET_START_ADDR(mp2_smnif_tlr_addr_15) \
     ((mp2_smnif_tlr_addr_15 & MP2_SMNIF_TLR_ADDR_15_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_15_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_15_GET_END_ADDR(mp2_smnif_tlr_addr_15) \
     ((mp2_smnif_tlr_addr_15 & MP2_SMNIF_TLR_ADDR_15_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_15_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_15_SET_START_ADDR(mp2_smnif_tlr_addr_15_reg, start_addr) \
     mp2_smnif_tlr_addr_15_reg = (mp2_smnif_tlr_addr_15_reg & ~MP2_SMNIF_TLR_ADDR_15_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_15_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_15_SET_END_ADDR(mp2_smnif_tlr_addr_15_reg, end_addr) \
     mp2_smnif_tlr_addr_15_reg = (mp2_smnif_tlr_addr_15_reg & ~MP2_SMNIF_TLR_ADDR_15_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_15_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_15_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_15_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_15_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_15_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_15_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_15_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_15_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_15_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_15_t f;
} mp2_smnif_tlr_addr_15_u;


/*
 * MP2_SMNIF_TLR_16 struct
 */

#define MP2_SMNIF_TLR_16_REG_SIZE      32
#define MP2_SMNIF_TLR_16_MASK_SIZE     8
#define MP2_SMNIF_TLR_16_RD_ACC_SIZE   1
#define MP2_SMNIF_TLR_16_WR_ACC_SIZE   1
#define MP2_SMNIF_TLR_16_SLV_ADDR_SIZE 4
#define MP2_SMNIF_TLR_16_VF_ACC_SIZE   1
#define MP2_SMNIF_TLR_16_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_16_VALID_SIZE    1

#define MP2_SMNIF_TLR_16_MASK_SHIFT    0
#define MP2_SMNIF_TLR_16_RD_ACC_SHIFT  8
#define MP2_SMNIF_TLR_16_WR_ACC_SHIFT  9
#define MP2_SMNIF_TLR_16_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_16_VF_ACC_SHIFT  14
#define MP2_SMNIF_TLR_16_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_16_VALID_SHIFT   16

#define MP2_SMNIF_TLR_16_MASK_MASK     0xff
#define MP2_SMNIF_TLR_16_RD_ACC_MASK   0x100
#define MP2_SMNIF_TLR_16_WR_ACC_MASK   0x200
#define MP2_SMNIF_TLR_16_SLV_ADDR_MASK 0x3c00
#define MP2_SMNIF_TLR_16_VF_ACC_MASK   0x4000
#define MP2_SMNIF_TLR_16_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_16_VALID_MASK    0x10000

#define MP2_SMNIF_TLR_16_MASK \
     (MP2_SMNIF_TLR_16_MASK_MASK | \
      MP2_SMNIF_TLR_16_RD_ACC_MASK | \
      MP2_SMNIF_TLR_16_WR_ACC_MASK | \
      MP2_SMNIF_TLR_16_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_16_VF_ACC_MASK | \
      MP2_SMNIF_TLR_16_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_16_VALID_MASK)

#define MP2_SMNIF_TLR_16_DEFAULT       0x00000000

#define MP2_SMNIF_TLR_16_GET_MASK(mp2_smnif_tlr_16) \
     ((mp2_smnif_tlr_16 & MP2_SMNIF_TLR_16_MASK_MASK) >> MP2_SMNIF_TLR_16_MASK_SHIFT)
#define MP2_SMNIF_TLR_16_GET_RD_ACC(mp2_smnif_tlr_16) \
     ((mp2_smnif_tlr_16 & MP2_SMNIF_TLR_16_RD_ACC_MASK) >> MP2_SMNIF_TLR_16_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_16_GET_WR_ACC(mp2_smnif_tlr_16) \
     ((mp2_smnif_tlr_16 & MP2_SMNIF_TLR_16_WR_ACC_MASK) >> MP2_SMNIF_TLR_16_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_16_GET_SLV_ADDR(mp2_smnif_tlr_16) \
     ((mp2_smnif_tlr_16 & MP2_SMNIF_TLR_16_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_16_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_16_GET_VF_ACC(mp2_smnif_tlr_16) \
     ((mp2_smnif_tlr_16 & MP2_SMNIF_TLR_16_VF_ACC_MASK) >> MP2_SMNIF_TLR_16_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_16_GET_VF_ACC_ENB(mp2_smnif_tlr_16) \
     ((mp2_smnif_tlr_16 & MP2_SMNIF_TLR_16_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_16_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_16_GET_VALID(mp2_smnif_tlr_16) \
     ((mp2_smnif_tlr_16 & MP2_SMNIF_TLR_16_VALID_MASK) >> MP2_SMNIF_TLR_16_VALID_SHIFT)

#define MP2_SMNIF_TLR_16_SET_MASK(mp2_smnif_tlr_16_reg, mask) \
     mp2_smnif_tlr_16_reg = (mp2_smnif_tlr_16_reg & ~MP2_SMNIF_TLR_16_MASK_MASK) | (mask << MP2_SMNIF_TLR_16_MASK_SHIFT)
#define MP2_SMNIF_TLR_16_SET_RD_ACC(mp2_smnif_tlr_16_reg, rd_acc) \
     mp2_smnif_tlr_16_reg = (mp2_smnif_tlr_16_reg & ~MP2_SMNIF_TLR_16_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_16_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_16_SET_WR_ACC(mp2_smnif_tlr_16_reg, wr_acc) \
     mp2_smnif_tlr_16_reg = (mp2_smnif_tlr_16_reg & ~MP2_SMNIF_TLR_16_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_16_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_16_SET_SLV_ADDR(mp2_smnif_tlr_16_reg, slv_addr) \
     mp2_smnif_tlr_16_reg = (mp2_smnif_tlr_16_reg & ~MP2_SMNIF_TLR_16_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_16_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_16_SET_VF_ACC(mp2_smnif_tlr_16_reg, vf_acc) \
     mp2_smnif_tlr_16_reg = (mp2_smnif_tlr_16_reg & ~MP2_SMNIF_TLR_16_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_16_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_16_SET_VF_ACC_ENB(mp2_smnif_tlr_16_reg, vf_acc_enb) \
     mp2_smnif_tlr_16_reg = (mp2_smnif_tlr_16_reg & ~MP2_SMNIF_TLR_16_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_16_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_16_SET_VALID(mp2_smnif_tlr_16_reg, valid) \
     mp2_smnif_tlr_16_reg = (mp2_smnif_tlr_16_reg & ~MP2_SMNIF_TLR_16_VALID_MASK) | (valid << MP2_SMNIF_TLR_16_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_16_t {
          unsigned int mask                           : MP2_SMNIF_TLR_16_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_16_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_16_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_16_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_16_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_16_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_16_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_16_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_16_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_16_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_16_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_16_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_16_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_16_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_16_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_16_MASK_SIZE;
     } mp2_smnif_tlr_16_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_16_t f;
} mp2_smnif_tlr_16_u;


/*
 * MP2_SMNIF_TLR_ADDR_16 struct
 */

#define MP2_SMNIF_TLR_ADDR_16_REG_SIZE 32
#define MP2_SMNIF_TLR_ADDR_16_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_16_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_16_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_16_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_16_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_16_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_16_MASK \
     (MP2_SMNIF_TLR_ADDR_16_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_16_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_16_DEFAULT  0x00000000

#define MP2_SMNIF_TLR_ADDR_16_GET_START_ADDR(mp2_smnif_tlr_addr_16) \
     ((mp2_smnif_tlr_addr_16 & MP2_SMNIF_TLR_ADDR_16_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_16_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_16_GET_END_ADDR(mp2_smnif_tlr_addr_16) \
     ((mp2_smnif_tlr_addr_16 & MP2_SMNIF_TLR_ADDR_16_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_16_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_16_SET_START_ADDR(mp2_smnif_tlr_addr_16_reg, start_addr) \
     mp2_smnif_tlr_addr_16_reg = (mp2_smnif_tlr_addr_16_reg & ~MP2_SMNIF_TLR_ADDR_16_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_16_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_16_SET_END_ADDR(mp2_smnif_tlr_addr_16_reg, end_addr) \
     mp2_smnif_tlr_addr_16_reg = (mp2_smnif_tlr_addr_16_reg & ~MP2_SMNIF_TLR_ADDR_16_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_16_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_16_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_16_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_16_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_16_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_16_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_16_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_16_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_16_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_16_t f;
} mp2_smnif_tlr_addr_16_u;


/*
 * MP2_SMNIF_TLR_17 struct
 */

#define MP2_SMNIF_TLR_17_REG_SIZE      32
#define MP2_SMNIF_TLR_17_MASK_SIZE     8
#define MP2_SMNIF_TLR_17_RD_ACC_SIZE   1
#define MP2_SMNIF_TLR_17_WR_ACC_SIZE   1
#define MP2_SMNIF_TLR_17_SLV_ADDR_SIZE 4
#define MP2_SMNIF_TLR_17_VF_ACC_SIZE   1
#define MP2_SMNIF_TLR_17_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_17_VALID_SIZE    1

#define MP2_SMNIF_TLR_17_MASK_SHIFT    0
#define MP2_SMNIF_TLR_17_RD_ACC_SHIFT  8
#define MP2_SMNIF_TLR_17_WR_ACC_SHIFT  9
#define MP2_SMNIF_TLR_17_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_17_VF_ACC_SHIFT  14
#define MP2_SMNIF_TLR_17_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_17_VALID_SHIFT   16

#define MP2_SMNIF_TLR_17_MASK_MASK     0xff
#define MP2_SMNIF_TLR_17_RD_ACC_MASK   0x100
#define MP2_SMNIF_TLR_17_WR_ACC_MASK   0x200
#define MP2_SMNIF_TLR_17_SLV_ADDR_MASK 0x3c00
#define MP2_SMNIF_TLR_17_VF_ACC_MASK   0x4000
#define MP2_SMNIF_TLR_17_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_17_VALID_MASK    0x10000

#define MP2_SMNIF_TLR_17_MASK \
     (MP2_SMNIF_TLR_17_MASK_MASK | \
      MP2_SMNIF_TLR_17_RD_ACC_MASK | \
      MP2_SMNIF_TLR_17_WR_ACC_MASK | \
      MP2_SMNIF_TLR_17_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_17_VF_ACC_MASK | \
      MP2_SMNIF_TLR_17_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_17_VALID_MASK)

#define MP2_SMNIF_TLR_17_DEFAULT       0x00000000

#define MP2_SMNIF_TLR_17_GET_MASK(mp2_smnif_tlr_17) \
     ((mp2_smnif_tlr_17 & MP2_SMNIF_TLR_17_MASK_MASK) >> MP2_SMNIF_TLR_17_MASK_SHIFT)
#define MP2_SMNIF_TLR_17_GET_RD_ACC(mp2_smnif_tlr_17) \
     ((mp2_smnif_tlr_17 & MP2_SMNIF_TLR_17_RD_ACC_MASK) >> MP2_SMNIF_TLR_17_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_17_GET_WR_ACC(mp2_smnif_tlr_17) \
     ((mp2_smnif_tlr_17 & MP2_SMNIF_TLR_17_WR_ACC_MASK) >> MP2_SMNIF_TLR_17_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_17_GET_SLV_ADDR(mp2_smnif_tlr_17) \
     ((mp2_smnif_tlr_17 & MP2_SMNIF_TLR_17_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_17_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_17_GET_VF_ACC(mp2_smnif_tlr_17) \
     ((mp2_smnif_tlr_17 & MP2_SMNIF_TLR_17_VF_ACC_MASK) >> MP2_SMNIF_TLR_17_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_17_GET_VF_ACC_ENB(mp2_smnif_tlr_17) \
     ((mp2_smnif_tlr_17 & MP2_SMNIF_TLR_17_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_17_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_17_GET_VALID(mp2_smnif_tlr_17) \
     ((mp2_smnif_tlr_17 & MP2_SMNIF_TLR_17_VALID_MASK) >> MP2_SMNIF_TLR_17_VALID_SHIFT)

#define MP2_SMNIF_TLR_17_SET_MASK(mp2_smnif_tlr_17_reg, mask) \
     mp2_smnif_tlr_17_reg = (mp2_smnif_tlr_17_reg & ~MP2_SMNIF_TLR_17_MASK_MASK) | (mask << MP2_SMNIF_TLR_17_MASK_SHIFT)
#define MP2_SMNIF_TLR_17_SET_RD_ACC(mp2_smnif_tlr_17_reg, rd_acc) \
     mp2_smnif_tlr_17_reg = (mp2_smnif_tlr_17_reg & ~MP2_SMNIF_TLR_17_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_17_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_17_SET_WR_ACC(mp2_smnif_tlr_17_reg, wr_acc) \
     mp2_smnif_tlr_17_reg = (mp2_smnif_tlr_17_reg & ~MP2_SMNIF_TLR_17_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_17_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_17_SET_SLV_ADDR(mp2_smnif_tlr_17_reg, slv_addr) \
     mp2_smnif_tlr_17_reg = (mp2_smnif_tlr_17_reg & ~MP2_SMNIF_TLR_17_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_17_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_17_SET_VF_ACC(mp2_smnif_tlr_17_reg, vf_acc) \
     mp2_smnif_tlr_17_reg = (mp2_smnif_tlr_17_reg & ~MP2_SMNIF_TLR_17_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_17_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_17_SET_VF_ACC_ENB(mp2_smnif_tlr_17_reg, vf_acc_enb) \
     mp2_smnif_tlr_17_reg = (mp2_smnif_tlr_17_reg & ~MP2_SMNIF_TLR_17_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_17_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_17_SET_VALID(mp2_smnif_tlr_17_reg, valid) \
     mp2_smnif_tlr_17_reg = (mp2_smnif_tlr_17_reg & ~MP2_SMNIF_TLR_17_VALID_MASK) | (valid << MP2_SMNIF_TLR_17_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_17_t {
          unsigned int mask                           : MP2_SMNIF_TLR_17_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_17_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_17_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_17_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_17_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_17_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_17_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_17_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_17_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_17_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_17_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_17_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_17_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_17_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_17_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_17_MASK_SIZE;
     } mp2_smnif_tlr_17_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_17_t f;
} mp2_smnif_tlr_17_u;


/*
 * MP2_SMNIF_TLR_ADDR_17 struct
 */

#define MP2_SMNIF_TLR_ADDR_17_REG_SIZE 32
#define MP2_SMNIF_TLR_ADDR_17_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_17_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_17_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_17_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_17_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_17_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_17_MASK \
     (MP2_SMNIF_TLR_ADDR_17_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_17_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_17_DEFAULT  0x00000000

#define MP2_SMNIF_TLR_ADDR_17_GET_START_ADDR(mp2_smnif_tlr_addr_17) \
     ((mp2_smnif_tlr_addr_17 & MP2_SMNIF_TLR_ADDR_17_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_17_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_17_GET_END_ADDR(mp2_smnif_tlr_addr_17) \
     ((mp2_smnif_tlr_addr_17 & MP2_SMNIF_TLR_ADDR_17_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_17_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_17_SET_START_ADDR(mp2_smnif_tlr_addr_17_reg, start_addr) \
     mp2_smnif_tlr_addr_17_reg = (mp2_smnif_tlr_addr_17_reg & ~MP2_SMNIF_TLR_ADDR_17_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_17_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_17_SET_END_ADDR(mp2_smnif_tlr_addr_17_reg, end_addr) \
     mp2_smnif_tlr_addr_17_reg = (mp2_smnif_tlr_addr_17_reg & ~MP2_SMNIF_TLR_ADDR_17_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_17_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_17_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_17_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_17_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_17_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_17_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_17_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_17_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_17_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_17_t f;
} mp2_smnif_tlr_addr_17_u;


/*
 * MP2_SMNIF_TLR_18 struct
 */

#define MP2_SMNIF_TLR_18_REG_SIZE      32
#define MP2_SMNIF_TLR_18_MASK_SIZE     8
#define MP2_SMNIF_TLR_18_RD_ACC_SIZE   1
#define MP2_SMNIF_TLR_18_WR_ACC_SIZE   1
#define MP2_SMNIF_TLR_18_SLV_ADDR_SIZE 4
#define MP2_SMNIF_TLR_18_VF_ACC_SIZE   1
#define MP2_SMNIF_TLR_18_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_18_VALID_SIZE    1

#define MP2_SMNIF_TLR_18_MASK_SHIFT    0
#define MP2_SMNIF_TLR_18_RD_ACC_SHIFT  8
#define MP2_SMNIF_TLR_18_WR_ACC_SHIFT  9
#define MP2_SMNIF_TLR_18_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_18_VF_ACC_SHIFT  14
#define MP2_SMNIF_TLR_18_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_18_VALID_SHIFT   16

#define MP2_SMNIF_TLR_18_MASK_MASK     0xff
#define MP2_SMNIF_TLR_18_RD_ACC_MASK   0x100
#define MP2_SMNIF_TLR_18_WR_ACC_MASK   0x200
#define MP2_SMNIF_TLR_18_SLV_ADDR_MASK 0x3c00
#define MP2_SMNIF_TLR_18_VF_ACC_MASK   0x4000
#define MP2_SMNIF_TLR_18_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_18_VALID_MASK    0x10000

#define MP2_SMNIF_TLR_18_MASK \
     (MP2_SMNIF_TLR_18_MASK_MASK | \
      MP2_SMNIF_TLR_18_RD_ACC_MASK | \
      MP2_SMNIF_TLR_18_WR_ACC_MASK | \
      MP2_SMNIF_TLR_18_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_18_VF_ACC_MASK | \
      MP2_SMNIF_TLR_18_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_18_VALID_MASK)

#define MP2_SMNIF_TLR_18_DEFAULT       0x00000000

#define MP2_SMNIF_TLR_18_GET_MASK(mp2_smnif_tlr_18) \
     ((mp2_smnif_tlr_18 & MP2_SMNIF_TLR_18_MASK_MASK) >> MP2_SMNIF_TLR_18_MASK_SHIFT)
#define MP2_SMNIF_TLR_18_GET_RD_ACC(mp2_smnif_tlr_18) \
     ((mp2_smnif_tlr_18 & MP2_SMNIF_TLR_18_RD_ACC_MASK) >> MP2_SMNIF_TLR_18_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_18_GET_WR_ACC(mp2_smnif_tlr_18) \
     ((mp2_smnif_tlr_18 & MP2_SMNIF_TLR_18_WR_ACC_MASK) >> MP2_SMNIF_TLR_18_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_18_GET_SLV_ADDR(mp2_smnif_tlr_18) \
     ((mp2_smnif_tlr_18 & MP2_SMNIF_TLR_18_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_18_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_18_GET_VF_ACC(mp2_smnif_tlr_18) \
     ((mp2_smnif_tlr_18 & MP2_SMNIF_TLR_18_VF_ACC_MASK) >> MP2_SMNIF_TLR_18_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_18_GET_VF_ACC_ENB(mp2_smnif_tlr_18) \
     ((mp2_smnif_tlr_18 & MP2_SMNIF_TLR_18_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_18_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_18_GET_VALID(mp2_smnif_tlr_18) \
     ((mp2_smnif_tlr_18 & MP2_SMNIF_TLR_18_VALID_MASK) >> MP2_SMNIF_TLR_18_VALID_SHIFT)

#define MP2_SMNIF_TLR_18_SET_MASK(mp2_smnif_tlr_18_reg, mask) \
     mp2_smnif_tlr_18_reg = (mp2_smnif_tlr_18_reg & ~MP2_SMNIF_TLR_18_MASK_MASK) | (mask << MP2_SMNIF_TLR_18_MASK_SHIFT)
#define MP2_SMNIF_TLR_18_SET_RD_ACC(mp2_smnif_tlr_18_reg, rd_acc) \
     mp2_smnif_tlr_18_reg = (mp2_smnif_tlr_18_reg & ~MP2_SMNIF_TLR_18_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_18_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_18_SET_WR_ACC(mp2_smnif_tlr_18_reg, wr_acc) \
     mp2_smnif_tlr_18_reg = (mp2_smnif_tlr_18_reg & ~MP2_SMNIF_TLR_18_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_18_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_18_SET_SLV_ADDR(mp2_smnif_tlr_18_reg, slv_addr) \
     mp2_smnif_tlr_18_reg = (mp2_smnif_tlr_18_reg & ~MP2_SMNIF_TLR_18_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_18_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_18_SET_VF_ACC(mp2_smnif_tlr_18_reg, vf_acc) \
     mp2_smnif_tlr_18_reg = (mp2_smnif_tlr_18_reg & ~MP2_SMNIF_TLR_18_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_18_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_18_SET_VF_ACC_ENB(mp2_smnif_tlr_18_reg, vf_acc_enb) \
     mp2_smnif_tlr_18_reg = (mp2_smnif_tlr_18_reg & ~MP2_SMNIF_TLR_18_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_18_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_18_SET_VALID(mp2_smnif_tlr_18_reg, valid) \
     mp2_smnif_tlr_18_reg = (mp2_smnif_tlr_18_reg & ~MP2_SMNIF_TLR_18_VALID_MASK) | (valid << MP2_SMNIF_TLR_18_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_18_t {
          unsigned int mask                           : MP2_SMNIF_TLR_18_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_18_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_18_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_18_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_18_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_18_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_18_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_18_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_18_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_18_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_18_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_18_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_18_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_18_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_18_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_18_MASK_SIZE;
     } mp2_smnif_tlr_18_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_18_t f;
} mp2_smnif_tlr_18_u;


/*
 * MP2_SMNIF_TLR_ADDR_18 struct
 */

#define MP2_SMNIF_TLR_ADDR_18_REG_SIZE 32
#define MP2_SMNIF_TLR_ADDR_18_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_18_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_18_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_18_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_18_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_18_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_18_MASK \
     (MP2_SMNIF_TLR_ADDR_18_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_18_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_18_DEFAULT  0x00000000

#define MP2_SMNIF_TLR_ADDR_18_GET_START_ADDR(mp2_smnif_tlr_addr_18) \
     ((mp2_smnif_tlr_addr_18 & MP2_SMNIF_TLR_ADDR_18_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_18_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_18_GET_END_ADDR(mp2_smnif_tlr_addr_18) \
     ((mp2_smnif_tlr_addr_18 & MP2_SMNIF_TLR_ADDR_18_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_18_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_18_SET_START_ADDR(mp2_smnif_tlr_addr_18_reg, start_addr) \
     mp2_smnif_tlr_addr_18_reg = (mp2_smnif_tlr_addr_18_reg & ~MP2_SMNIF_TLR_ADDR_18_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_18_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_18_SET_END_ADDR(mp2_smnif_tlr_addr_18_reg, end_addr) \
     mp2_smnif_tlr_addr_18_reg = (mp2_smnif_tlr_addr_18_reg & ~MP2_SMNIF_TLR_ADDR_18_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_18_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_18_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_18_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_18_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_18_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_18_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_18_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_18_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_18_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_18_t f;
} mp2_smnif_tlr_addr_18_u;


/*
 * MP2_SMNIF_TLR_19 struct
 */

#define MP2_SMNIF_TLR_19_REG_SIZE      32
#define MP2_SMNIF_TLR_19_MASK_SIZE     8
#define MP2_SMNIF_TLR_19_RD_ACC_SIZE   1
#define MP2_SMNIF_TLR_19_WR_ACC_SIZE   1
#define MP2_SMNIF_TLR_19_SLV_ADDR_SIZE 4
#define MP2_SMNIF_TLR_19_VF_ACC_SIZE   1
#define MP2_SMNIF_TLR_19_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_19_VALID_SIZE    1

#define MP2_SMNIF_TLR_19_MASK_SHIFT    0
#define MP2_SMNIF_TLR_19_RD_ACC_SHIFT  8
#define MP2_SMNIF_TLR_19_WR_ACC_SHIFT  9
#define MP2_SMNIF_TLR_19_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_19_VF_ACC_SHIFT  14
#define MP2_SMNIF_TLR_19_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_19_VALID_SHIFT   16

#define MP2_SMNIF_TLR_19_MASK_MASK     0xff
#define MP2_SMNIF_TLR_19_RD_ACC_MASK   0x100
#define MP2_SMNIF_TLR_19_WR_ACC_MASK   0x200
#define MP2_SMNIF_TLR_19_SLV_ADDR_MASK 0x3c00
#define MP2_SMNIF_TLR_19_VF_ACC_MASK   0x4000
#define MP2_SMNIF_TLR_19_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_19_VALID_MASK    0x10000

#define MP2_SMNIF_TLR_19_MASK \
     (MP2_SMNIF_TLR_19_MASK_MASK | \
      MP2_SMNIF_TLR_19_RD_ACC_MASK | \
      MP2_SMNIF_TLR_19_WR_ACC_MASK | \
      MP2_SMNIF_TLR_19_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_19_VF_ACC_MASK | \
      MP2_SMNIF_TLR_19_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_19_VALID_MASK)

#define MP2_SMNIF_TLR_19_DEFAULT       0x00000000

#define MP2_SMNIF_TLR_19_GET_MASK(mp2_smnif_tlr_19) \
     ((mp2_smnif_tlr_19 & MP2_SMNIF_TLR_19_MASK_MASK) >> MP2_SMNIF_TLR_19_MASK_SHIFT)
#define MP2_SMNIF_TLR_19_GET_RD_ACC(mp2_smnif_tlr_19) \
     ((mp2_smnif_tlr_19 & MP2_SMNIF_TLR_19_RD_ACC_MASK) >> MP2_SMNIF_TLR_19_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_19_GET_WR_ACC(mp2_smnif_tlr_19) \
     ((mp2_smnif_tlr_19 & MP2_SMNIF_TLR_19_WR_ACC_MASK) >> MP2_SMNIF_TLR_19_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_19_GET_SLV_ADDR(mp2_smnif_tlr_19) \
     ((mp2_smnif_tlr_19 & MP2_SMNIF_TLR_19_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_19_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_19_GET_VF_ACC(mp2_smnif_tlr_19) \
     ((mp2_smnif_tlr_19 & MP2_SMNIF_TLR_19_VF_ACC_MASK) >> MP2_SMNIF_TLR_19_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_19_GET_VF_ACC_ENB(mp2_smnif_tlr_19) \
     ((mp2_smnif_tlr_19 & MP2_SMNIF_TLR_19_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_19_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_19_GET_VALID(mp2_smnif_tlr_19) \
     ((mp2_smnif_tlr_19 & MP2_SMNIF_TLR_19_VALID_MASK) >> MP2_SMNIF_TLR_19_VALID_SHIFT)

#define MP2_SMNIF_TLR_19_SET_MASK(mp2_smnif_tlr_19_reg, mask) \
     mp2_smnif_tlr_19_reg = (mp2_smnif_tlr_19_reg & ~MP2_SMNIF_TLR_19_MASK_MASK) | (mask << MP2_SMNIF_TLR_19_MASK_SHIFT)
#define MP2_SMNIF_TLR_19_SET_RD_ACC(mp2_smnif_tlr_19_reg, rd_acc) \
     mp2_smnif_tlr_19_reg = (mp2_smnif_tlr_19_reg & ~MP2_SMNIF_TLR_19_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_19_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_19_SET_WR_ACC(mp2_smnif_tlr_19_reg, wr_acc) \
     mp2_smnif_tlr_19_reg = (mp2_smnif_tlr_19_reg & ~MP2_SMNIF_TLR_19_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_19_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_19_SET_SLV_ADDR(mp2_smnif_tlr_19_reg, slv_addr) \
     mp2_smnif_tlr_19_reg = (mp2_smnif_tlr_19_reg & ~MP2_SMNIF_TLR_19_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_19_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_19_SET_VF_ACC(mp2_smnif_tlr_19_reg, vf_acc) \
     mp2_smnif_tlr_19_reg = (mp2_smnif_tlr_19_reg & ~MP2_SMNIF_TLR_19_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_19_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_19_SET_VF_ACC_ENB(mp2_smnif_tlr_19_reg, vf_acc_enb) \
     mp2_smnif_tlr_19_reg = (mp2_smnif_tlr_19_reg & ~MP2_SMNIF_TLR_19_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_19_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_19_SET_VALID(mp2_smnif_tlr_19_reg, valid) \
     mp2_smnif_tlr_19_reg = (mp2_smnif_tlr_19_reg & ~MP2_SMNIF_TLR_19_VALID_MASK) | (valid << MP2_SMNIF_TLR_19_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_19_t {
          unsigned int mask                           : MP2_SMNIF_TLR_19_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_19_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_19_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_19_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_19_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_19_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_19_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_19_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_19_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_19_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_19_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_19_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_19_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_19_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_19_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_19_MASK_SIZE;
     } mp2_smnif_tlr_19_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_19_t f;
} mp2_smnif_tlr_19_u;


/*
 * MP2_SMNIF_TLR_ADDR_19 struct
 */

#define MP2_SMNIF_TLR_ADDR_19_REG_SIZE 32
#define MP2_SMNIF_TLR_ADDR_19_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_19_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_19_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_19_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_19_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_19_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_19_MASK \
     (MP2_SMNIF_TLR_ADDR_19_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_19_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_19_DEFAULT  0x00000000

#define MP2_SMNIF_TLR_ADDR_19_GET_START_ADDR(mp2_smnif_tlr_addr_19) \
     ((mp2_smnif_tlr_addr_19 & MP2_SMNIF_TLR_ADDR_19_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_19_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_19_GET_END_ADDR(mp2_smnif_tlr_addr_19) \
     ((mp2_smnif_tlr_addr_19 & MP2_SMNIF_TLR_ADDR_19_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_19_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_19_SET_START_ADDR(mp2_smnif_tlr_addr_19_reg, start_addr) \
     mp2_smnif_tlr_addr_19_reg = (mp2_smnif_tlr_addr_19_reg & ~MP2_SMNIF_TLR_ADDR_19_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_19_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_19_SET_END_ADDR(mp2_smnif_tlr_addr_19_reg, end_addr) \
     mp2_smnif_tlr_addr_19_reg = (mp2_smnif_tlr_addr_19_reg & ~MP2_SMNIF_TLR_ADDR_19_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_19_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_19_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_19_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_19_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_19_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_19_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_19_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_19_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_19_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_19_t f;
} mp2_smnif_tlr_addr_19_u;


/*
 * MP2_SMNIF_TLR_20 struct
 */

#define MP2_SMNIF_TLR_20_REG_SIZE      32
#define MP2_SMNIF_TLR_20_MASK_SIZE     8
#define MP2_SMNIF_TLR_20_RD_ACC_SIZE   1
#define MP2_SMNIF_TLR_20_WR_ACC_SIZE   1
#define MP2_SMNIF_TLR_20_SLV_ADDR_SIZE 4
#define MP2_SMNIF_TLR_20_VF_ACC_SIZE   1
#define MP2_SMNIF_TLR_20_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_20_VALID_SIZE    1

#define MP2_SMNIF_TLR_20_MASK_SHIFT    0
#define MP2_SMNIF_TLR_20_RD_ACC_SHIFT  8
#define MP2_SMNIF_TLR_20_WR_ACC_SHIFT  9
#define MP2_SMNIF_TLR_20_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_20_VF_ACC_SHIFT  14
#define MP2_SMNIF_TLR_20_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_20_VALID_SHIFT   16

#define MP2_SMNIF_TLR_20_MASK_MASK     0xff
#define MP2_SMNIF_TLR_20_RD_ACC_MASK   0x100
#define MP2_SMNIF_TLR_20_WR_ACC_MASK   0x200
#define MP2_SMNIF_TLR_20_SLV_ADDR_MASK 0x3c00
#define MP2_SMNIF_TLR_20_VF_ACC_MASK   0x4000
#define MP2_SMNIF_TLR_20_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_20_VALID_MASK    0x10000

#define MP2_SMNIF_TLR_20_MASK \
     (MP2_SMNIF_TLR_20_MASK_MASK | \
      MP2_SMNIF_TLR_20_RD_ACC_MASK | \
      MP2_SMNIF_TLR_20_WR_ACC_MASK | \
      MP2_SMNIF_TLR_20_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_20_VF_ACC_MASK | \
      MP2_SMNIF_TLR_20_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_20_VALID_MASK)

#define MP2_SMNIF_TLR_20_DEFAULT       0x00000000

#define MP2_SMNIF_TLR_20_GET_MASK(mp2_smnif_tlr_20) \
     ((mp2_smnif_tlr_20 & MP2_SMNIF_TLR_20_MASK_MASK) >> MP2_SMNIF_TLR_20_MASK_SHIFT)
#define MP2_SMNIF_TLR_20_GET_RD_ACC(mp2_smnif_tlr_20) \
     ((mp2_smnif_tlr_20 & MP2_SMNIF_TLR_20_RD_ACC_MASK) >> MP2_SMNIF_TLR_20_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_20_GET_WR_ACC(mp2_smnif_tlr_20) \
     ((mp2_smnif_tlr_20 & MP2_SMNIF_TLR_20_WR_ACC_MASK) >> MP2_SMNIF_TLR_20_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_20_GET_SLV_ADDR(mp2_smnif_tlr_20) \
     ((mp2_smnif_tlr_20 & MP2_SMNIF_TLR_20_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_20_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_20_GET_VF_ACC(mp2_smnif_tlr_20) \
     ((mp2_smnif_tlr_20 & MP2_SMNIF_TLR_20_VF_ACC_MASK) >> MP2_SMNIF_TLR_20_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_20_GET_VF_ACC_ENB(mp2_smnif_tlr_20) \
     ((mp2_smnif_tlr_20 & MP2_SMNIF_TLR_20_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_20_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_20_GET_VALID(mp2_smnif_tlr_20) \
     ((mp2_smnif_tlr_20 & MP2_SMNIF_TLR_20_VALID_MASK) >> MP2_SMNIF_TLR_20_VALID_SHIFT)

#define MP2_SMNIF_TLR_20_SET_MASK(mp2_smnif_tlr_20_reg, mask) \
     mp2_smnif_tlr_20_reg = (mp2_smnif_tlr_20_reg & ~MP2_SMNIF_TLR_20_MASK_MASK) | (mask << MP2_SMNIF_TLR_20_MASK_SHIFT)
#define MP2_SMNIF_TLR_20_SET_RD_ACC(mp2_smnif_tlr_20_reg, rd_acc) \
     mp2_smnif_tlr_20_reg = (mp2_smnif_tlr_20_reg & ~MP2_SMNIF_TLR_20_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_20_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_20_SET_WR_ACC(mp2_smnif_tlr_20_reg, wr_acc) \
     mp2_smnif_tlr_20_reg = (mp2_smnif_tlr_20_reg & ~MP2_SMNIF_TLR_20_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_20_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_20_SET_SLV_ADDR(mp2_smnif_tlr_20_reg, slv_addr) \
     mp2_smnif_tlr_20_reg = (mp2_smnif_tlr_20_reg & ~MP2_SMNIF_TLR_20_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_20_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_20_SET_VF_ACC(mp2_smnif_tlr_20_reg, vf_acc) \
     mp2_smnif_tlr_20_reg = (mp2_smnif_tlr_20_reg & ~MP2_SMNIF_TLR_20_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_20_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_20_SET_VF_ACC_ENB(mp2_smnif_tlr_20_reg, vf_acc_enb) \
     mp2_smnif_tlr_20_reg = (mp2_smnif_tlr_20_reg & ~MP2_SMNIF_TLR_20_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_20_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_20_SET_VALID(mp2_smnif_tlr_20_reg, valid) \
     mp2_smnif_tlr_20_reg = (mp2_smnif_tlr_20_reg & ~MP2_SMNIF_TLR_20_VALID_MASK) | (valid << MP2_SMNIF_TLR_20_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_20_t {
          unsigned int mask                           : MP2_SMNIF_TLR_20_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_20_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_20_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_20_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_20_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_20_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_20_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_20_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_20_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_20_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_20_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_20_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_20_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_20_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_20_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_20_MASK_SIZE;
     } mp2_smnif_tlr_20_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_20_t f;
} mp2_smnif_tlr_20_u;


/*
 * MP2_SMNIF_TLR_ADDR_20 struct
 */

#define MP2_SMNIF_TLR_ADDR_20_REG_SIZE 32
#define MP2_SMNIF_TLR_ADDR_20_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_20_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_20_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_20_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_20_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_20_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_20_MASK \
     (MP2_SMNIF_TLR_ADDR_20_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_20_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_20_DEFAULT  0x00000000

#define MP2_SMNIF_TLR_ADDR_20_GET_START_ADDR(mp2_smnif_tlr_addr_20) \
     ((mp2_smnif_tlr_addr_20 & MP2_SMNIF_TLR_ADDR_20_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_20_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_20_GET_END_ADDR(mp2_smnif_tlr_addr_20) \
     ((mp2_smnif_tlr_addr_20 & MP2_SMNIF_TLR_ADDR_20_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_20_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_20_SET_START_ADDR(mp2_smnif_tlr_addr_20_reg, start_addr) \
     mp2_smnif_tlr_addr_20_reg = (mp2_smnif_tlr_addr_20_reg & ~MP2_SMNIF_TLR_ADDR_20_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_20_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_20_SET_END_ADDR(mp2_smnif_tlr_addr_20_reg, end_addr) \
     mp2_smnif_tlr_addr_20_reg = (mp2_smnif_tlr_addr_20_reg & ~MP2_SMNIF_TLR_ADDR_20_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_20_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_20_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_20_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_20_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_20_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_20_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_20_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_20_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_20_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_20_t f;
} mp2_smnif_tlr_addr_20_u;


/*
 * MP2_SMNIF_TLR_21 struct
 */

#define MP2_SMNIF_TLR_21_REG_SIZE      32
#define MP2_SMNIF_TLR_21_MASK_SIZE     8
#define MP2_SMNIF_TLR_21_RD_ACC_SIZE   1
#define MP2_SMNIF_TLR_21_WR_ACC_SIZE   1
#define MP2_SMNIF_TLR_21_SLV_ADDR_SIZE 4
#define MP2_SMNIF_TLR_21_VF_ACC_SIZE   1
#define MP2_SMNIF_TLR_21_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_21_VALID_SIZE    1

#define MP2_SMNIF_TLR_21_MASK_SHIFT    0
#define MP2_SMNIF_TLR_21_RD_ACC_SHIFT  8
#define MP2_SMNIF_TLR_21_WR_ACC_SHIFT  9
#define MP2_SMNIF_TLR_21_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_21_VF_ACC_SHIFT  14
#define MP2_SMNIF_TLR_21_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_21_VALID_SHIFT   16

#define MP2_SMNIF_TLR_21_MASK_MASK     0xff
#define MP2_SMNIF_TLR_21_RD_ACC_MASK   0x100
#define MP2_SMNIF_TLR_21_WR_ACC_MASK   0x200
#define MP2_SMNIF_TLR_21_SLV_ADDR_MASK 0x3c00
#define MP2_SMNIF_TLR_21_VF_ACC_MASK   0x4000
#define MP2_SMNIF_TLR_21_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_21_VALID_MASK    0x10000

#define MP2_SMNIF_TLR_21_MASK \
     (MP2_SMNIF_TLR_21_MASK_MASK | \
      MP2_SMNIF_TLR_21_RD_ACC_MASK | \
      MP2_SMNIF_TLR_21_WR_ACC_MASK | \
      MP2_SMNIF_TLR_21_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_21_VF_ACC_MASK | \
      MP2_SMNIF_TLR_21_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_21_VALID_MASK)

#define MP2_SMNIF_TLR_21_DEFAULT       0x00000000

#define MP2_SMNIF_TLR_21_GET_MASK(mp2_smnif_tlr_21) \
     ((mp2_smnif_tlr_21 & MP2_SMNIF_TLR_21_MASK_MASK) >> MP2_SMNIF_TLR_21_MASK_SHIFT)
#define MP2_SMNIF_TLR_21_GET_RD_ACC(mp2_smnif_tlr_21) \
     ((mp2_smnif_tlr_21 & MP2_SMNIF_TLR_21_RD_ACC_MASK) >> MP2_SMNIF_TLR_21_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_21_GET_WR_ACC(mp2_smnif_tlr_21) \
     ((mp2_smnif_tlr_21 & MP2_SMNIF_TLR_21_WR_ACC_MASK) >> MP2_SMNIF_TLR_21_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_21_GET_SLV_ADDR(mp2_smnif_tlr_21) \
     ((mp2_smnif_tlr_21 & MP2_SMNIF_TLR_21_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_21_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_21_GET_VF_ACC(mp2_smnif_tlr_21) \
     ((mp2_smnif_tlr_21 & MP2_SMNIF_TLR_21_VF_ACC_MASK) >> MP2_SMNIF_TLR_21_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_21_GET_VF_ACC_ENB(mp2_smnif_tlr_21) \
     ((mp2_smnif_tlr_21 & MP2_SMNIF_TLR_21_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_21_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_21_GET_VALID(mp2_smnif_tlr_21) \
     ((mp2_smnif_tlr_21 & MP2_SMNIF_TLR_21_VALID_MASK) >> MP2_SMNIF_TLR_21_VALID_SHIFT)

#define MP2_SMNIF_TLR_21_SET_MASK(mp2_smnif_tlr_21_reg, mask) \
     mp2_smnif_tlr_21_reg = (mp2_smnif_tlr_21_reg & ~MP2_SMNIF_TLR_21_MASK_MASK) | (mask << MP2_SMNIF_TLR_21_MASK_SHIFT)
#define MP2_SMNIF_TLR_21_SET_RD_ACC(mp2_smnif_tlr_21_reg, rd_acc) \
     mp2_smnif_tlr_21_reg = (mp2_smnif_tlr_21_reg & ~MP2_SMNIF_TLR_21_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_21_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_21_SET_WR_ACC(mp2_smnif_tlr_21_reg, wr_acc) \
     mp2_smnif_tlr_21_reg = (mp2_smnif_tlr_21_reg & ~MP2_SMNIF_TLR_21_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_21_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_21_SET_SLV_ADDR(mp2_smnif_tlr_21_reg, slv_addr) \
     mp2_smnif_tlr_21_reg = (mp2_smnif_tlr_21_reg & ~MP2_SMNIF_TLR_21_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_21_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_21_SET_VF_ACC(mp2_smnif_tlr_21_reg, vf_acc) \
     mp2_smnif_tlr_21_reg = (mp2_smnif_tlr_21_reg & ~MP2_SMNIF_TLR_21_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_21_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_21_SET_VF_ACC_ENB(mp2_smnif_tlr_21_reg, vf_acc_enb) \
     mp2_smnif_tlr_21_reg = (mp2_smnif_tlr_21_reg & ~MP2_SMNIF_TLR_21_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_21_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_21_SET_VALID(mp2_smnif_tlr_21_reg, valid) \
     mp2_smnif_tlr_21_reg = (mp2_smnif_tlr_21_reg & ~MP2_SMNIF_TLR_21_VALID_MASK) | (valid << MP2_SMNIF_TLR_21_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_21_t {
          unsigned int mask                           : MP2_SMNIF_TLR_21_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_21_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_21_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_21_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_21_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_21_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_21_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_21_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_21_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_21_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_21_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_21_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_21_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_21_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_21_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_21_MASK_SIZE;
     } mp2_smnif_tlr_21_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_21_t f;
} mp2_smnif_tlr_21_u;


/*
 * MP2_SMNIF_TLR_ADDR_21 struct
 */

#define MP2_SMNIF_TLR_ADDR_21_REG_SIZE 32
#define MP2_SMNIF_TLR_ADDR_21_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_21_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_21_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_21_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_21_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_21_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_21_MASK \
     (MP2_SMNIF_TLR_ADDR_21_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_21_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_21_DEFAULT  0x00000000

#define MP2_SMNIF_TLR_ADDR_21_GET_START_ADDR(mp2_smnif_tlr_addr_21) \
     ((mp2_smnif_tlr_addr_21 & MP2_SMNIF_TLR_ADDR_21_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_21_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_21_GET_END_ADDR(mp2_smnif_tlr_addr_21) \
     ((mp2_smnif_tlr_addr_21 & MP2_SMNIF_TLR_ADDR_21_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_21_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_21_SET_START_ADDR(mp2_smnif_tlr_addr_21_reg, start_addr) \
     mp2_smnif_tlr_addr_21_reg = (mp2_smnif_tlr_addr_21_reg & ~MP2_SMNIF_TLR_ADDR_21_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_21_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_21_SET_END_ADDR(mp2_smnif_tlr_addr_21_reg, end_addr) \
     mp2_smnif_tlr_addr_21_reg = (mp2_smnif_tlr_addr_21_reg & ~MP2_SMNIF_TLR_ADDR_21_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_21_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_21_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_21_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_21_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_21_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_21_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_21_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_21_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_21_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_21_t f;
} mp2_smnif_tlr_addr_21_u;


/*
 * MP2_SMNIF_TLR_22 struct
 */

#define MP2_SMNIF_TLR_22_REG_SIZE      32
#define MP2_SMNIF_TLR_22_MASK_SIZE     8
#define MP2_SMNIF_TLR_22_RD_ACC_SIZE   1
#define MP2_SMNIF_TLR_22_WR_ACC_SIZE   1
#define MP2_SMNIF_TLR_22_SLV_ADDR_SIZE 4
#define MP2_SMNIF_TLR_22_VF_ACC_SIZE   1
#define MP2_SMNIF_TLR_22_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_22_VALID_SIZE    1

#define MP2_SMNIF_TLR_22_MASK_SHIFT    0
#define MP2_SMNIF_TLR_22_RD_ACC_SHIFT  8
#define MP2_SMNIF_TLR_22_WR_ACC_SHIFT  9
#define MP2_SMNIF_TLR_22_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_22_VF_ACC_SHIFT  14
#define MP2_SMNIF_TLR_22_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_22_VALID_SHIFT   16

#define MP2_SMNIF_TLR_22_MASK_MASK     0xff
#define MP2_SMNIF_TLR_22_RD_ACC_MASK   0x100
#define MP2_SMNIF_TLR_22_WR_ACC_MASK   0x200
#define MP2_SMNIF_TLR_22_SLV_ADDR_MASK 0x3c00
#define MP2_SMNIF_TLR_22_VF_ACC_MASK   0x4000
#define MP2_SMNIF_TLR_22_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_22_VALID_MASK    0x10000

#define MP2_SMNIF_TLR_22_MASK \
     (MP2_SMNIF_TLR_22_MASK_MASK | \
      MP2_SMNIF_TLR_22_RD_ACC_MASK | \
      MP2_SMNIF_TLR_22_WR_ACC_MASK | \
      MP2_SMNIF_TLR_22_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_22_VF_ACC_MASK | \
      MP2_SMNIF_TLR_22_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_22_VALID_MASK)

#define MP2_SMNIF_TLR_22_DEFAULT       0x00000000

#define MP2_SMNIF_TLR_22_GET_MASK(mp2_smnif_tlr_22) \
     ((mp2_smnif_tlr_22 & MP2_SMNIF_TLR_22_MASK_MASK) >> MP2_SMNIF_TLR_22_MASK_SHIFT)
#define MP2_SMNIF_TLR_22_GET_RD_ACC(mp2_smnif_tlr_22) \
     ((mp2_smnif_tlr_22 & MP2_SMNIF_TLR_22_RD_ACC_MASK) >> MP2_SMNIF_TLR_22_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_22_GET_WR_ACC(mp2_smnif_tlr_22) \
     ((mp2_smnif_tlr_22 & MP2_SMNIF_TLR_22_WR_ACC_MASK) >> MP2_SMNIF_TLR_22_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_22_GET_SLV_ADDR(mp2_smnif_tlr_22) \
     ((mp2_smnif_tlr_22 & MP2_SMNIF_TLR_22_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_22_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_22_GET_VF_ACC(mp2_smnif_tlr_22) \
     ((mp2_smnif_tlr_22 & MP2_SMNIF_TLR_22_VF_ACC_MASK) >> MP2_SMNIF_TLR_22_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_22_GET_VF_ACC_ENB(mp2_smnif_tlr_22) \
     ((mp2_smnif_tlr_22 & MP2_SMNIF_TLR_22_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_22_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_22_GET_VALID(mp2_smnif_tlr_22) \
     ((mp2_smnif_tlr_22 & MP2_SMNIF_TLR_22_VALID_MASK) >> MP2_SMNIF_TLR_22_VALID_SHIFT)

#define MP2_SMNIF_TLR_22_SET_MASK(mp2_smnif_tlr_22_reg, mask) \
     mp2_smnif_tlr_22_reg = (mp2_smnif_tlr_22_reg & ~MP2_SMNIF_TLR_22_MASK_MASK) | (mask << MP2_SMNIF_TLR_22_MASK_SHIFT)
#define MP2_SMNIF_TLR_22_SET_RD_ACC(mp2_smnif_tlr_22_reg, rd_acc) \
     mp2_smnif_tlr_22_reg = (mp2_smnif_tlr_22_reg & ~MP2_SMNIF_TLR_22_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_22_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_22_SET_WR_ACC(mp2_smnif_tlr_22_reg, wr_acc) \
     mp2_smnif_tlr_22_reg = (mp2_smnif_tlr_22_reg & ~MP2_SMNIF_TLR_22_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_22_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_22_SET_SLV_ADDR(mp2_smnif_tlr_22_reg, slv_addr) \
     mp2_smnif_tlr_22_reg = (mp2_smnif_tlr_22_reg & ~MP2_SMNIF_TLR_22_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_22_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_22_SET_VF_ACC(mp2_smnif_tlr_22_reg, vf_acc) \
     mp2_smnif_tlr_22_reg = (mp2_smnif_tlr_22_reg & ~MP2_SMNIF_TLR_22_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_22_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_22_SET_VF_ACC_ENB(mp2_smnif_tlr_22_reg, vf_acc_enb) \
     mp2_smnif_tlr_22_reg = (mp2_smnif_tlr_22_reg & ~MP2_SMNIF_TLR_22_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_22_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_22_SET_VALID(mp2_smnif_tlr_22_reg, valid) \
     mp2_smnif_tlr_22_reg = (mp2_smnif_tlr_22_reg & ~MP2_SMNIF_TLR_22_VALID_MASK) | (valid << MP2_SMNIF_TLR_22_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_22_t {
          unsigned int mask                           : MP2_SMNIF_TLR_22_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_22_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_22_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_22_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_22_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_22_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_22_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_22_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_22_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_22_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_22_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_22_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_22_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_22_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_22_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_22_MASK_SIZE;
     } mp2_smnif_tlr_22_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_22_t f;
} mp2_smnif_tlr_22_u;


/*
 * MP2_SMNIF_TLR_ADDR_22 struct
 */

#define MP2_SMNIF_TLR_ADDR_22_REG_SIZE 32
#define MP2_SMNIF_TLR_ADDR_22_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_22_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_22_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_22_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_22_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_22_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_22_MASK \
     (MP2_SMNIF_TLR_ADDR_22_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_22_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_22_DEFAULT  0x00000000

#define MP2_SMNIF_TLR_ADDR_22_GET_START_ADDR(mp2_smnif_tlr_addr_22) \
     ((mp2_smnif_tlr_addr_22 & MP2_SMNIF_TLR_ADDR_22_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_22_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_22_GET_END_ADDR(mp2_smnif_tlr_addr_22) \
     ((mp2_smnif_tlr_addr_22 & MP2_SMNIF_TLR_ADDR_22_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_22_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_22_SET_START_ADDR(mp2_smnif_tlr_addr_22_reg, start_addr) \
     mp2_smnif_tlr_addr_22_reg = (mp2_smnif_tlr_addr_22_reg & ~MP2_SMNIF_TLR_ADDR_22_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_22_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_22_SET_END_ADDR(mp2_smnif_tlr_addr_22_reg, end_addr) \
     mp2_smnif_tlr_addr_22_reg = (mp2_smnif_tlr_addr_22_reg & ~MP2_SMNIF_TLR_ADDR_22_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_22_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_22_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_22_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_22_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_22_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_22_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_22_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_22_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_22_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_22_t f;
} mp2_smnif_tlr_addr_22_u;


/*
 * MP2_SMNIF_TLR_23 struct
 */

#define MP2_SMNIF_TLR_23_REG_SIZE      32
#define MP2_SMNIF_TLR_23_MASK_SIZE     8
#define MP2_SMNIF_TLR_23_RD_ACC_SIZE   1
#define MP2_SMNIF_TLR_23_WR_ACC_SIZE   1
#define MP2_SMNIF_TLR_23_SLV_ADDR_SIZE 4
#define MP2_SMNIF_TLR_23_VF_ACC_SIZE   1
#define MP2_SMNIF_TLR_23_VF_ACC_ENB_SIZE 1
#define MP2_SMNIF_TLR_23_VALID_SIZE    1

#define MP2_SMNIF_TLR_23_MASK_SHIFT    0
#define MP2_SMNIF_TLR_23_RD_ACC_SHIFT  8
#define MP2_SMNIF_TLR_23_WR_ACC_SHIFT  9
#define MP2_SMNIF_TLR_23_SLV_ADDR_SHIFT 10
#define MP2_SMNIF_TLR_23_VF_ACC_SHIFT  14
#define MP2_SMNIF_TLR_23_VF_ACC_ENB_SHIFT 15
#define MP2_SMNIF_TLR_23_VALID_SHIFT   16

#define MP2_SMNIF_TLR_23_MASK_MASK     0xff
#define MP2_SMNIF_TLR_23_RD_ACC_MASK   0x100
#define MP2_SMNIF_TLR_23_WR_ACC_MASK   0x200
#define MP2_SMNIF_TLR_23_SLV_ADDR_MASK 0x3c00
#define MP2_SMNIF_TLR_23_VF_ACC_MASK   0x4000
#define MP2_SMNIF_TLR_23_VF_ACC_ENB_MASK 0x8000
#define MP2_SMNIF_TLR_23_VALID_MASK    0x10000

#define MP2_SMNIF_TLR_23_MASK \
     (MP2_SMNIF_TLR_23_MASK_MASK | \
      MP2_SMNIF_TLR_23_RD_ACC_MASK | \
      MP2_SMNIF_TLR_23_WR_ACC_MASK | \
      MP2_SMNIF_TLR_23_SLV_ADDR_MASK | \
      MP2_SMNIF_TLR_23_VF_ACC_MASK | \
      MP2_SMNIF_TLR_23_VF_ACC_ENB_MASK | \
      MP2_SMNIF_TLR_23_VALID_MASK)

#define MP2_SMNIF_TLR_23_DEFAULT       0x00000000

#define MP2_SMNIF_TLR_23_GET_MASK(mp2_smnif_tlr_23) \
     ((mp2_smnif_tlr_23 & MP2_SMNIF_TLR_23_MASK_MASK) >> MP2_SMNIF_TLR_23_MASK_SHIFT)
#define MP2_SMNIF_TLR_23_GET_RD_ACC(mp2_smnif_tlr_23) \
     ((mp2_smnif_tlr_23 & MP2_SMNIF_TLR_23_RD_ACC_MASK) >> MP2_SMNIF_TLR_23_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_23_GET_WR_ACC(mp2_smnif_tlr_23) \
     ((mp2_smnif_tlr_23 & MP2_SMNIF_TLR_23_WR_ACC_MASK) >> MP2_SMNIF_TLR_23_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_23_GET_SLV_ADDR(mp2_smnif_tlr_23) \
     ((mp2_smnif_tlr_23 & MP2_SMNIF_TLR_23_SLV_ADDR_MASK) >> MP2_SMNIF_TLR_23_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_23_GET_VF_ACC(mp2_smnif_tlr_23) \
     ((mp2_smnif_tlr_23 & MP2_SMNIF_TLR_23_VF_ACC_MASK) >> MP2_SMNIF_TLR_23_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_23_GET_VF_ACC_ENB(mp2_smnif_tlr_23) \
     ((mp2_smnif_tlr_23 & MP2_SMNIF_TLR_23_VF_ACC_ENB_MASK) >> MP2_SMNIF_TLR_23_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_23_GET_VALID(mp2_smnif_tlr_23) \
     ((mp2_smnif_tlr_23 & MP2_SMNIF_TLR_23_VALID_MASK) >> MP2_SMNIF_TLR_23_VALID_SHIFT)

#define MP2_SMNIF_TLR_23_SET_MASK(mp2_smnif_tlr_23_reg, mask) \
     mp2_smnif_tlr_23_reg = (mp2_smnif_tlr_23_reg & ~MP2_SMNIF_TLR_23_MASK_MASK) | (mask << MP2_SMNIF_TLR_23_MASK_SHIFT)
#define MP2_SMNIF_TLR_23_SET_RD_ACC(mp2_smnif_tlr_23_reg, rd_acc) \
     mp2_smnif_tlr_23_reg = (mp2_smnif_tlr_23_reg & ~MP2_SMNIF_TLR_23_RD_ACC_MASK) | (rd_acc << MP2_SMNIF_TLR_23_RD_ACC_SHIFT)
#define MP2_SMNIF_TLR_23_SET_WR_ACC(mp2_smnif_tlr_23_reg, wr_acc) \
     mp2_smnif_tlr_23_reg = (mp2_smnif_tlr_23_reg & ~MP2_SMNIF_TLR_23_WR_ACC_MASK) | (wr_acc << MP2_SMNIF_TLR_23_WR_ACC_SHIFT)
#define MP2_SMNIF_TLR_23_SET_SLV_ADDR(mp2_smnif_tlr_23_reg, slv_addr) \
     mp2_smnif_tlr_23_reg = (mp2_smnif_tlr_23_reg & ~MP2_SMNIF_TLR_23_SLV_ADDR_MASK) | (slv_addr << MP2_SMNIF_TLR_23_SLV_ADDR_SHIFT)
#define MP2_SMNIF_TLR_23_SET_VF_ACC(mp2_smnif_tlr_23_reg, vf_acc) \
     mp2_smnif_tlr_23_reg = (mp2_smnif_tlr_23_reg & ~MP2_SMNIF_TLR_23_VF_ACC_MASK) | (vf_acc << MP2_SMNIF_TLR_23_VF_ACC_SHIFT)
#define MP2_SMNIF_TLR_23_SET_VF_ACC_ENB(mp2_smnif_tlr_23_reg, vf_acc_enb) \
     mp2_smnif_tlr_23_reg = (mp2_smnif_tlr_23_reg & ~MP2_SMNIF_TLR_23_VF_ACC_ENB_MASK) | (vf_acc_enb << MP2_SMNIF_TLR_23_VF_ACC_ENB_SHIFT)
#define MP2_SMNIF_TLR_23_SET_VALID(mp2_smnif_tlr_23_reg, valid) \
     mp2_smnif_tlr_23_reg = (mp2_smnif_tlr_23_reg & ~MP2_SMNIF_TLR_23_VALID_MASK) | (valid << MP2_SMNIF_TLR_23_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_23_t {
          unsigned int mask                           : MP2_SMNIF_TLR_23_MASK_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_23_RD_ACC_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_23_WR_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_23_SLV_ADDR_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_23_VF_ACC_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_23_VF_ACC_ENB_SIZE;
          unsigned int valid                          : MP2_SMNIF_TLR_23_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_smnif_tlr_23_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_23_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_SMNIF_TLR_23_VALID_SIZE;
          unsigned int vf_acc_enb                     : MP2_SMNIF_TLR_23_VF_ACC_ENB_SIZE;
          unsigned int vf_acc                         : MP2_SMNIF_TLR_23_VF_ACC_SIZE;
          unsigned int slv_addr                       : MP2_SMNIF_TLR_23_SLV_ADDR_SIZE;
          unsigned int wr_acc                         : MP2_SMNIF_TLR_23_WR_ACC_SIZE;
          unsigned int rd_acc                         : MP2_SMNIF_TLR_23_RD_ACC_SIZE;
          unsigned int mask                           : MP2_SMNIF_TLR_23_MASK_SIZE;
     } mp2_smnif_tlr_23_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_23_t f;
} mp2_smnif_tlr_23_u;


/*
 * MP2_SMNIF_TLR_ADDR_23 struct
 */

#define MP2_SMNIF_TLR_ADDR_23_REG_SIZE 32
#define MP2_SMNIF_TLR_ADDR_23_START_ADDR_SIZE 16
#define MP2_SMNIF_TLR_ADDR_23_END_ADDR_SIZE 16

#define MP2_SMNIF_TLR_ADDR_23_START_ADDR_SHIFT 0
#define MP2_SMNIF_TLR_ADDR_23_END_ADDR_SHIFT 16

#define MP2_SMNIF_TLR_ADDR_23_START_ADDR_MASK 0xffff
#define MP2_SMNIF_TLR_ADDR_23_END_ADDR_MASK 0xffff0000

#define MP2_SMNIF_TLR_ADDR_23_MASK \
     (MP2_SMNIF_TLR_ADDR_23_START_ADDR_MASK | \
      MP2_SMNIF_TLR_ADDR_23_END_ADDR_MASK)

#define MP2_SMNIF_TLR_ADDR_23_DEFAULT  0x00000000

#define MP2_SMNIF_TLR_ADDR_23_GET_START_ADDR(mp2_smnif_tlr_addr_23) \
     ((mp2_smnif_tlr_addr_23 & MP2_SMNIF_TLR_ADDR_23_START_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_23_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_23_GET_END_ADDR(mp2_smnif_tlr_addr_23) \
     ((mp2_smnif_tlr_addr_23 & MP2_SMNIF_TLR_ADDR_23_END_ADDR_MASK) >> MP2_SMNIF_TLR_ADDR_23_END_ADDR_SHIFT)

#define MP2_SMNIF_TLR_ADDR_23_SET_START_ADDR(mp2_smnif_tlr_addr_23_reg, start_addr) \
     mp2_smnif_tlr_addr_23_reg = (mp2_smnif_tlr_addr_23_reg & ~MP2_SMNIF_TLR_ADDR_23_START_ADDR_MASK) | (start_addr << MP2_SMNIF_TLR_ADDR_23_START_ADDR_SHIFT)
#define MP2_SMNIF_TLR_ADDR_23_SET_END_ADDR(mp2_smnif_tlr_addr_23_reg, end_addr) \
     mp2_smnif_tlr_addr_23_reg = (mp2_smnif_tlr_addr_23_reg & ~MP2_SMNIF_TLR_ADDR_23_END_ADDR_MASK) | (end_addr << MP2_SMNIF_TLR_ADDR_23_END_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_23_t {
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_23_START_ADDR_SIZE;
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_23_END_ADDR_SIZE;
     } mp2_smnif_tlr_addr_23_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlr_addr_23_t {
          unsigned int end_addr                       : MP2_SMNIF_TLR_ADDR_23_END_ADDR_SIZE;
          unsigned int start_addr                     : MP2_SMNIF_TLR_ADDR_23_START_ADDR_SIZE;
     } mp2_smnif_tlr_addr_23_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlr_addr_23_t f;
} mp2_smnif_tlr_addr_23_u;


/*
 * MP2_SMNIF_TLVV_WR_VIOL_ADDR struct
 */

#define MP2_SMNIF_TLVV_WR_VIOL_ADDR_REG_SIZE 32
#define MP2_SMNIF_TLVV_WR_VIOL_ADDR_AXI_ADDR_SIZE 32

#define MP2_SMNIF_TLVV_WR_VIOL_ADDR_AXI_ADDR_SHIFT 0

#define MP2_SMNIF_TLVV_WR_VIOL_ADDR_AXI_ADDR_MASK 0xffffffff

#define MP2_SMNIF_TLVV_WR_VIOL_ADDR_MASK \
     (MP2_SMNIF_TLVV_WR_VIOL_ADDR_AXI_ADDR_MASK)

#define MP2_SMNIF_TLVV_WR_VIOL_ADDR_DEFAULT 0x00000000

#define MP2_SMNIF_TLVV_WR_VIOL_ADDR_GET_AXI_ADDR(mp2_smnif_tlvv_wr_viol_addr) \
     ((mp2_smnif_tlvv_wr_viol_addr & MP2_SMNIF_TLVV_WR_VIOL_ADDR_AXI_ADDR_MASK) >> MP2_SMNIF_TLVV_WR_VIOL_ADDR_AXI_ADDR_SHIFT)

#define MP2_SMNIF_TLVV_WR_VIOL_ADDR_SET_AXI_ADDR(mp2_smnif_tlvv_wr_viol_addr_reg, axi_addr) \
     mp2_smnif_tlvv_wr_viol_addr_reg = (mp2_smnif_tlvv_wr_viol_addr_reg & ~MP2_SMNIF_TLVV_WR_VIOL_ADDR_AXI_ADDR_MASK) | (axi_addr << MP2_SMNIF_TLVV_WR_VIOL_ADDR_AXI_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlvv_wr_viol_addr_t {
          unsigned int axi_addr                       : MP2_SMNIF_TLVV_WR_VIOL_ADDR_AXI_ADDR_SIZE;
     } mp2_smnif_tlvv_wr_viol_addr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlvv_wr_viol_addr_t {
          unsigned int axi_addr                       : MP2_SMNIF_TLVV_WR_VIOL_ADDR_AXI_ADDR_SIZE;
     } mp2_smnif_tlvv_wr_viol_addr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlvv_wr_viol_addr_t f;
} mp2_smnif_tlvv_wr_viol_addr_u;


/*
 * MP2_SMNIF_TLVV_WR_VIOL_STATUS struct
 */

#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_REG_SIZE 32
#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_DET_SIZE 1
#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_CLEAR_SIZE 1
#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_AXI_ID_SIZE 21
#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_AXI_PROT_SIZE 3

#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_DET_SHIFT 0
#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_CLEAR_SHIFT 3
#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_AXI_ID_SHIFT 8
#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_AXI_PROT_SHIFT 29

#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_DET_MASK 0x1
#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_CLEAR_MASK 0x8
#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_AXI_ID_MASK 0x1fffff00
#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_AXI_PROT_MASK 0xe0000000

#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_MASK \
     (MP2_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_DET_MASK | \
      MP2_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_CLEAR_MASK | \
      MP2_SMNIF_TLVV_WR_VIOL_STATUS_AXI_ID_MASK | \
      MP2_SMNIF_TLVV_WR_VIOL_STATUS_AXI_PROT_MASK)

#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_DEFAULT 0x00000000

#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_GET_VIOL_DET(mp2_smnif_tlvv_wr_viol_status) \
     ((mp2_smnif_tlvv_wr_viol_status & MP2_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_DET_MASK) >> MP2_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_DET_SHIFT)
#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_GET_VIOL_CLEAR(mp2_smnif_tlvv_wr_viol_status) \
     ((mp2_smnif_tlvv_wr_viol_status & MP2_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_CLEAR_MASK) >> MP2_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_CLEAR_SHIFT)
#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_GET_AXI_ID(mp2_smnif_tlvv_wr_viol_status) \
     ((mp2_smnif_tlvv_wr_viol_status & MP2_SMNIF_TLVV_WR_VIOL_STATUS_AXI_ID_MASK) >> MP2_SMNIF_TLVV_WR_VIOL_STATUS_AXI_ID_SHIFT)
#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_GET_AXI_PROT(mp2_smnif_tlvv_wr_viol_status) \
     ((mp2_smnif_tlvv_wr_viol_status & MP2_SMNIF_TLVV_WR_VIOL_STATUS_AXI_PROT_MASK) >> MP2_SMNIF_TLVV_WR_VIOL_STATUS_AXI_PROT_SHIFT)

#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_SET_VIOL_DET(mp2_smnif_tlvv_wr_viol_status_reg, viol_det) \
     mp2_smnif_tlvv_wr_viol_status_reg = (mp2_smnif_tlvv_wr_viol_status_reg & ~MP2_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_DET_MASK) | (viol_det << MP2_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_DET_SHIFT)
#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_SET_VIOL_CLEAR(mp2_smnif_tlvv_wr_viol_status_reg, viol_clear) \
     mp2_smnif_tlvv_wr_viol_status_reg = (mp2_smnif_tlvv_wr_viol_status_reg & ~MP2_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_CLEAR_MASK) | (viol_clear << MP2_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_CLEAR_SHIFT)
#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_SET_AXI_ID(mp2_smnif_tlvv_wr_viol_status_reg, axi_id) \
     mp2_smnif_tlvv_wr_viol_status_reg = (mp2_smnif_tlvv_wr_viol_status_reg & ~MP2_SMNIF_TLVV_WR_VIOL_STATUS_AXI_ID_MASK) | (axi_id << MP2_SMNIF_TLVV_WR_VIOL_STATUS_AXI_ID_SHIFT)
#define MP2_SMNIF_TLVV_WR_VIOL_STATUS_SET_AXI_PROT(mp2_smnif_tlvv_wr_viol_status_reg, axi_prot) \
     mp2_smnif_tlvv_wr_viol_status_reg = (mp2_smnif_tlvv_wr_viol_status_reg & ~MP2_SMNIF_TLVV_WR_VIOL_STATUS_AXI_PROT_MASK) | (axi_prot << MP2_SMNIF_TLVV_WR_VIOL_STATUS_AXI_PROT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlvv_wr_viol_status_t {
          unsigned int viol_det                       : MP2_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_DET_SIZE;
          unsigned int                                : 2;
          unsigned int viol_clear                     : MP2_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_CLEAR_SIZE;
          unsigned int                                : 4;
          unsigned int axi_id                         : MP2_SMNIF_TLVV_WR_VIOL_STATUS_AXI_ID_SIZE;
          unsigned int axi_prot                       : MP2_SMNIF_TLVV_WR_VIOL_STATUS_AXI_PROT_SIZE;
     } mp2_smnif_tlvv_wr_viol_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlvv_wr_viol_status_t {
          unsigned int axi_prot                       : MP2_SMNIF_TLVV_WR_VIOL_STATUS_AXI_PROT_SIZE;
          unsigned int axi_id                         : MP2_SMNIF_TLVV_WR_VIOL_STATUS_AXI_ID_SIZE;
          unsigned int                                : 4;
          unsigned int viol_clear                     : MP2_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_CLEAR_SIZE;
          unsigned int                                : 2;
          unsigned int viol_det                       : MP2_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_DET_SIZE;
     } mp2_smnif_tlvv_wr_viol_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlvv_wr_viol_status_t f;
} mp2_smnif_tlvv_wr_viol_status_u;


/*
 * MP2_SMNIF_TLVV_RD_VIOL_ADDR struct
 */

#define MP2_SMNIF_TLVV_RD_VIOL_ADDR_REG_SIZE 32
#define MP2_SMNIF_TLVV_RD_VIOL_ADDR_AXI_ADDR_SIZE 32

#define MP2_SMNIF_TLVV_RD_VIOL_ADDR_AXI_ADDR_SHIFT 0

#define MP2_SMNIF_TLVV_RD_VIOL_ADDR_AXI_ADDR_MASK 0xffffffff

#define MP2_SMNIF_TLVV_RD_VIOL_ADDR_MASK \
     (MP2_SMNIF_TLVV_RD_VIOL_ADDR_AXI_ADDR_MASK)

#define MP2_SMNIF_TLVV_RD_VIOL_ADDR_DEFAULT 0x00000000

#define MP2_SMNIF_TLVV_RD_VIOL_ADDR_GET_AXI_ADDR(mp2_smnif_tlvv_rd_viol_addr) \
     ((mp2_smnif_tlvv_rd_viol_addr & MP2_SMNIF_TLVV_RD_VIOL_ADDR_AXI_ADDR_MASK) >> MP2_SMNIF_TLVV_RD_VIOL_ADDR_AXI_ADDR_SHIFT)

#define MP2_SMNIF_TLVV_RD_VIOL_ADDR_SET_AXI_ADDR(mp2_smnif_tlvv_rd_viol_addr_reg, axi_addr) \
     mp2_smnif_tlvv_rd_viol_addr_reg = (mp2_smnif_tlvv_rd_viol_addr_reg & ~MP2_SMNIF_TLVV_RD_VIOL_ADDR_AXI_ADDR_MASK) | (axi_addr << MP2_SMNIF_TLVV_RD_VIOL_ADDR_AXI_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlvv_rd_viol_addr_t {
          unsigned int axi_addr                       : MP2_SMNIF_TLVV_RD_VIOL_ADDR_AXI_ADDR_SIZE;
     } mp2_smnif_tlvv_rd_viol_addr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlvv_rd_viol_addr_t {
          unsigned int axi_addr                       : MP2_SMNIF_TLVV_RD_VIOL_ADDR_AXI_ADDR_SIZE;
     } mp2_smnif_tlvv_rd_viol_addr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlvv_rd_viol_addr_t f;
} mp2_smnif_tlvv_rd_viol_addr_u;


/*
 * MP2_SMNIF_TLVV_RD_VIOL_STATUS struct
 */

#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_REG_SIZE 32
#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_DET_SIZE 1
#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_CLEAR_SIZE 1
#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_AXI_ID_SIZE 21
#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_AXI_PROT_SIZE 3

#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_DET_SHIFT 0
#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_CLEAR_SHIFT 3
#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_AXI_ID_SHIFT 8
#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_AXI_PROT_SHIFT 29

#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_DET_MASK 0x1
#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_CLEAR_MASK 0x8
#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_AXI_ID_MASK 0x1fffff00
#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_AXI_PROT_MASK 0xe0000000

#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_MASK \
     (MP2_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_DET_MASK | \
      MP2_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_CLEAR_MASK | \
      MP2_SMNIF_TLVV_RD_VIOL_STATUS_AXI_ID_MASK | \
      MP2_SMNIF_TLVV_RD_VIOL_STATUS_AXI_PROT_MASK)

#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_DEFAULT 0x00000000

#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_GET_VIOL_DET(mp2_smnif_tlvv_rd_viol_status) \
     ((mp2_smnif_tlvv_rd_viol_status & MP2_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_DET_MASK) >> MP2_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_DET_SHIFT)
#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_GET_VIOL_CLEAR(mp2_smnif_tlvv_rd_viol_status) \
     ((mp2_smnif_tlvv_rd_viol_status & MP2_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_CLEAR_MASK) >> MP2_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_CLEAR_SHIFT)
#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_GET_AXI_ID(mp2_smnif_tlvv_rd_viol_status) \
     ((mp2_smnif_tlvv_rd_viol_status & MP2_SMNIF_TLVV_RD_VIOL_STATUS_AXI_ID_MASK) >> MP2_SMNIF_TLVV_RD_VIOL_STATUS_AXI_ID_SHIFT)
#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_GET_AXI_PROT(mp2_smnif_tlvv_rd_viol_status) \
     ((mp2_smnif_tlvv_rd_viol_status & MP2_SMNIF_TLVV_RD_VIOL_STATUS_AXI_PROT_MASK) >> MP2_SMNIF_TLVV_RD_VIOL_STATUS_AXI_PROT_SHIFT)

#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_SET_VIOL_DET(mp2_smnif_tlvv_rd_viol_status_reg, viol_det) \
     mp2_smnif_tlvv_rd_viol_status_reg = (mp2_smnif_tlvv_rd_viol_status_reg & ~MP2_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_DET_MASK) | (viol_det << MP2_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_DET_SHIFT)
#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_SET_VIOL_CLEAR(mp2_smnif_tlvv_rd_viol_status_reg, viol_clear) \
     mp2_smnif_tlvv_rd_viol_status_reg = (mp2_smnif_tlvv_rd_viol_status_reg & ~MP2_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_CLEAR_MASK) | (viol_clear << MP2_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_CLEAR_SHIFT)
#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_SET_AXI_ID(mp2_smnif_tlvv_rd_viol_status_reg, axi_id) \
     mp2_smnif_tlvv_rd_viol_status_reg = (mp2_smnif_tlvv_rd_viol_status_reg & ~MP2_SMNIF_TLVV_RD_VIOL_STATUS_AXI_ID_MASK) | (axi_id << MP2_SMNIF_TLVV_RD_VIOL_STATUS_AXI_ID_SHIFT)
#define MP2_SMNIF_TLVV_RD_VIOL_STATUS_SET_AXI_PROT(mp2_smnif_tlvv_rd_viol_status_reg, axi_prot) \
     mp2_smnif_tlvv_rd_viol_status_reg = (mp2_smnif_tlvv_rd_viol_status_reg & ~MP2_SMNIF_TLVV_RD_VIOL_STATUS_AXI_PROT_MASK) | (axi_prot << MP2_SMNIF_TLVV_RD_VIOL_STATUS_AXI_PROT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_tlvv_rd_viol_status_t {
          unsigned int viol_det                       : MP2_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_DET_SIZE;
          unsigned int                                : 2;
          unsigned int viol_clear                     : MP2_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_CLEAR_SIZE;
          unsigned int                                : 4;
          unsigned int axi_id                         : MP2_SMNIF_TLVV_RD_VIOL_STATUS_AXI_ID_SIZE;
          unsigned int axi_prot                       : MP2_SMNIF_TLVV_RD_VIOL_STATUS_AXI_PROT_SIZE;
     } mp2_smnif_tlvv_rd_viol_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_tlvv_rd_viol_status_t {
          unsigned int axi_prot                       : MP2_SMNIF_TLVV_RD_VIOL_STATUS_AXI_PROT_SIZE;
          unsigned int axi_id                         : MP2_SMNIF_TLVV_RD_VIOL_STATUS_AXI_ID_SIZE;
          unsigned int                                : 4;
          unsigned int viol_clear                     : MP2_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_CLEAR_SIZE;
          unsigned int                                : 2;
          unsigned int viol_det                       : MP2_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_DET_SIZE;
     } mp2_smnif_tlvv_rd_viol_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_tlvv_rd_viol_status_t f;
} mp2_smnif_tlvv_rd_viol_status_u;


/*
 * MP2_SMNIF_RAM0_READ_INITID_IP0 struct
 */

#define MP2_SMNIF_RAM0_READ_INITID_IP0_REG_SIZE 32
#define MP2_SMNIF_RAM0_READ_INITID_IP0_RD_INITID_0_SIZE 10

#define MP2_SMNIF_RAM0_READ_INITID_IP0_RD_INITID_0_SHIFT 0

#define MP2_SMNIF_RAM0_READ_INITID_IP0_RD_INITID_0_MASK 0x3ff

#define MP2_SMNIF_RAM0_READ_INITID_IP0_MASK \
     (MP2_SMNIF_RAM0_READ_INITID_IP0_RD_INITID_0_MASK)

#define MP2_SMNIF_RAM0_READ_INITID_IP0_DEFAULT 0x00000000

#define MP2_SMNIF_RAM0_READ_INITID_IP0_GET_RD_INITID_0(mp2_smnif_ram0_read_initid_ip0) \
     ((mp2_smnif_ram0_read_initid_ip0 & MP2_SMNIF_RAM0_READ_INITID_IP0_RD_INITID_0_MASK) >> MP2_SMNIF_RAM0_READ_INITID_IP0_RD_INITID_0_SHIFT)

#define MP2_SMNIF_RAM0_READ_INITID_IP0_SET_RD_INITID_0(mp2_smnif_ram0_read_initid_ip0_reg, rd_initid_0) \
     mp2_smnif_ram0_read_initid_ip0_reg = (mp2_smnif_ram0_read_initid_ip0_reg & ~MP2_SMNIF_RAM0_READ_INITID_IP0_RD_INITID_0_MASK) | (rd_initid_0 << MP2_SMNIF_RAM0_READ_INITID_IP0_RD_INITID_0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_ram0_read_initid_ip0_t {
          unsigned int rd_initid_0                    : MP2_SMNIF_RAM0_READ_INITID_IP0_RD_INITID_0_SIZE;
          unsigned int                                : 22;
     } mp2_smnif_ram0_read_initid_ip0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_ram0_read_initid_ip0_t {
          unsigned int                                : 22;
          unsigned int rd_initid_0                    : MP2_SMNIF_RAM0_READ_INITID_IP0_RD_INITID_0_SIZE;
     } mp2_smnif_ram0_read_initid_ip0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_ram0_read_initid_ip0_t f;
} mp2_smnif_ram0_read_initid_ip0_u;


/*
 * MP2_SMNIF_RAM0_READ_INITID_IP1 struct
 */

#define MP2_SMNIF_RAM0_READ_INITID_IP1_REG_SIZE 32
#define MP2_SMNIF_RAM0_READ_INITID_IP1_RD_INITID_1_SIZE 10

#define MP2_SMNIF_RAM0_READ_INITID_IP1_RD_INITID_1_SHIFT 0

#define MP2_SMNIF_RAM0_READ_INITID_IP1_RD_INITID_1_MASK 0x3ff

#define MP2_SMNIF_RAM0_READ_INITID_IP1_MASK \
     (MP2_SMNIF_RAM0_READ_INITID_IP1_RD_INITID_1_MASK)

#define MP2_SMNIF_RAM0_READ_INITID_IP1_DEFAULT 0x00000000

#define MP2_SMNIF_RAM0_READ_INITID_IP1_GET_RD_INITID_1(mp2_smnif_ram0_read_initid_ip1) \
     ((mp2_smnif_ram0_read_initid_ip1 & MP2_SMNIF_RAM0_READ_INITID_IP1_RD_INITID_1_MASK) >> MP2_SMNIF_RAM0_READ_INITID_IP1_RD_INITID_1_SHIFT)

#define MP2_SMNIF_RAM0_READ_INITID_IP1_SET_RD_INITID_1(mp2_smnif_ram0_read_initid_ip1_reg, rd_initid_1) \
     mp2_smnif_ram0_read_initid_ip1_reg = (mp2_smnif_ram0_read_initid_ip1_reg & ~MP2_SMNIF_RAM0_READ_INITID_IP1_RD_INITID_1_MASK) | (rd_initid_1 << MP2_SMNIF_RAM0_READ_INITID_IP1_RD_INITID_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_ram0_read_initid_ip1_t {
          unsigned int rd_initid_1                    : MP2_SMNIF_RAM0_READ_INITID_IP1_RD_INITID_1_SIZE;
          unsigned int                                : 22;
     } mp2_smnif_ram0_read_initid_ip1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_ram0_read_initid_ip1_t {
          unsigned int                                : 22;
          unsigned int rd_initid_1                    : MP2_SMNIF_RAM0_READ_INITID_IP1_RD_INITID_1_SIZE;
     } mp2_smnif_ram0_read_initid_ip1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_ram0_read_initid_ip1_t f;
} mp2_smnif_ram0_read_initid_ip1_u;


/*
 * MP2_SMNIF_RAM0_READ_INITID_IP2 struct
 */

#define MP2_SMNIF_RAM0_READ_INITID_IP2_REG_SIZE 32
#define MP2_SMNIF_RAM0_READ_INITID_IP2_RD_INITID_2_SIZE 10

#define MP2_SMNIF_RAM0_READ_INITID_IP2_RD_INITID_2_SHIFT 0

#define MP2_SMNIF_RAM0_READ_INITID_IP2_RD_INITID_2_MASK 0x3ff

#define MP2_SMNIF_RAM0_READ_INITID_IP2_MASK \
     (MP2_SMNIF_RAM0_READ_INITID_IP2_RD_INITID_2_MASK)

#define MP2_SMNIF_RAM0_READ_INITID_IP2_DEFAULT 0x00000000

#define MP2_SMNIF_RAM0_READ_INITID_IP2_GET_RD_INITID_2(mp2_smnif_ram0_read_initid_ip2) \
     ((mp2_smnif_ram0_read_initid_ip2 & MP2_SMNIF_RAM0_READ_INITID_IP2_RD_INITID_2_MASK) >> MP2_SMNIF_RAM0_READ_INITID_IP2_RD_INITID_2_SHIFT)

#define MP2_SMNIF_RAM0_READ_INITID_IP2_SET_RD_INITID_2(mp2_smnif_ram0_read_initid_ip2_reg, rd_initid_2) \
     mp2_smnif_ram0_read_initid_ip2_reg = (mp2_smnif_ram0_read_initid_ip2_reg & ~MP2_SMNIF_RAM0_READ_INITID_IP2_RD_INITID_2_MASK) | (rd_initid_2 << MP2_SMNIF_RAM0_READ_INITID_IP2_RD_INITID_2_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_ram0_read_initid_ip2_t {
          unsigned int rd_initid_2                    : MP2_SMNIF_RAM0_READ_INITID_IP2_RD_INITID_2_SIZE;
          unsigned int                                : 22;
     } mp2_smnif_ram0_read_initid_ip2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_ram0_read_initid_ip2_t {
          unsigned int                                : 22;
          unsigned int rd_initid_2                    : MP2_SMNIF_RAM0_READ_INITID_IP2_RD_INITID_2_SIZE;
     } mp2_smnif_ram0_read_initid_ip2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_ram0_read_initid_ip2_t f;
} mp2_smnif_ram0_read_initid_ip2_u;


/*
 * MP2_SMNIF_RAM0_READ_INITID_IP3 struct
 */

#define MP2_SMNIF_RAM0_READ_INITID_IP3_REG_SIZE 32
#define MP2_SMNIF_RAM0_READ_INITID_IP3_RD_INITID_3_SIZE 10

#define MP2_SMNIF_RAM0_READ_INITID_IP3_RD_INITID_3_SHIFT 0

#define MP2_SMNIF_RAM0_READ_INITID_IP3_RD_INITID_3_MASK 0x3ff

#define MP2_SMNIF_RAM0_READ_INITID_IP3_MASK \
     (MP2_SMNIF_RAM0_READ_INITID_IP3_RD_INITID_3_MASK)

#define MP2_SMNIF_RAM0_READ_INITID_IP3_DEFAULT 0x00000000

#define MP2_SMNIF_RAM0_READ_INITID_IP3_GET_RD_INITID_3(mp2_smnif_ram0_read_initid_ip3) \
     ((mp2_smnif_ram0_read_initid_ip3 & MP2_SMNIF_RAM0_READ_INITID_IP3_RD_INITID_3_MASK) >> MP2_SMNIF_RAM0_READ_INITID_IP3_RD_INITID_3_SHIFT)

#define MP2_SMNIF_RAM0_READ_INITID_IP3_SET_RD_INITID_3(mp2_smnif_ram0_read_initid_ip3_reg, rd_initid_3) \
     mp2_smnif_ram0_read_initid_ip3_reg = (mp2_smnif_ram0_read_initid_ip3_reg & ~MP2_SMNIF_RAM0_READ_INITID_IP3_RD_INITID_3_MASK) | (rd_initid_3 << MP2_SMNIF_RAM0_READ_INITID_IP3_RD_INITID_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_ram0_read_initid_ip3_t {
          unsigned int rd_initid_3                    : MP2_SMNIF_RAM0_READ_INITID_IP3_RD_INITID_3_SIZE;
          unsigned int                                : 22;
     } mp2_smnif_ram0_read_initid_ip3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_ram0_read_initid_ip3_t {
          unsigned int                                : 22;
          unsigned int rd_initid_3                    : MP2_SMNIF_RAM0_READ_INITID_IP3_RD_INITID_3_SIZE;
     } mp2_smnif_ram0_read_initid_ip3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_ram0_read_initid_ip3_t f;
} mp2_smnif_ram0_read_initid_ip3_u;


/*
 * MP2_SMNIF_RAM0_WRITE_INITID_IP0 struct
 */

#define MP2_SMNIF_RAM0_WRITE_INITID_IP0_REG_SIZE 32
#define MP2_SMNIF_RAM0_WRITE_INITID_IP0_WR_INITID_0_SIZE 10

#define MP2_SMNIF_RAM0_WRITE_INITID_IP0_WR_INITID_0_SHIFT 0

#define MP2_SMNIF_RAM0_WRITE_INITID_IP0_WR_INITID_0_MASK 0x3ff

#define MP2_SMNIF_RAM0_WRITE_INITID_IP0_MASK \
     (MP2_SMNIF_RAM0_WRITE_INITID_IP0_WR_INITID_0_MASK)

#define MP2_SMNIF_RAM0_WRITE_INITID_IP0_DEFAULT 0x00000000

#define MP2_SMNIF_RAM0_WRITE_INITID_IP0_GET_WR_INITID_0(mp2_smnif_ram0_write_initid_ip0) \
     ((mp2_smnif_ram0_write_initid_ip0 & MP2_SMNIF_RAM0_WRITE_INITID_IP0_WR_INITID_0_MASK) >> MP2_SMNIF_RAM0_WRITE_INITID_IP0_WR_INITID_0_SHIFT)

#define MP2_SMNIF_RAM0_WRITE_INITID_IP0_SET_WR_INITID_0(mp2_smnif_ram0_write_initid_ip0_reg, wr_initid_0) \
     mp2_smnif_ram0_write_initid_ip0_reg = (mp2_smnif_ram0_write_initid_ip0_reg & ~MP2_SMNIF_RAM0_WRITE_INITID_IP0_WR_INITID_0_MASK) | (wr_initid_0 << MP2_SMNIF_RAM0_WRITE_INITID_IP0_WR_INITID_0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_ram0_write_initid_ip0_t {
          unsigned int wr_initid_0                    : MP2_SMNIF_RAM0_WRITE_INITID_IP0_WR_INITID_0_SIZE;
          unsigned int                                : 22;
     } mp2_smnif_ram0_write_initid_ip0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_ram0_write_initid_ip0_t {
          unsigned int                                : 22;
          unsigned int wr_initid_0                    : MP2_SMNIF_RAM0_WRITE_INITID_IP0_WR_INITID_0_SIZE;
     } mp2_smnif_ram0_write_initid_ip0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_ram0_write_initid_ip0_t f;
} mp2_smnif_ram0_write_initid_ip0_u;


/*
 * MP2_SMNIF_RAM0_WRITE_INITID_IP1 struct
 */

#define MP2_SMNIF_RAM0_WRITE_INITID_IP1_REG_SIZE 32
#define MP2_SMNIF_RAM0_WRITE_INITID_IP1_WR_INITID_1_SIZE 10

#define MP2_SMNIF_RAM0_WRITE_INITID_IP1_WR_INITID_1_SHIFT 0

#define MP2_SMNIF_RAM0_WRITE_INITID_IP1_WR_INITID_1_MASK 0x3ff

#define MP2_SMNIF_RAM0_WRITE_INITID_IP1_MASK \
     (MP2_SMNIF_RAM0_WRITE_INITID_IP1_WR_INITID_1_MASK)

#define MP2_SMNIF_RAM0_WRITE_INITID_IP1_DEFAULT 0x00000000

#define MP2_SMNIF_RAM0_WRITE_INITID_IP1_GET_WR_INITID_1(mp2_smnif_ram0_write_initid_ip1) \
     ((mp2_smnif_ram0_write_initid_ip1 & MP2_SMNIF_RAM0_WRITE_INITID_IP1_WR_INITID_1_MASK) >> MP2_SMNIF_RAM0_WRITE_INITID_IP1_WR_INITID_1_SHIFT)

#define MP2_SMNIF_RAM0_WRITE_INITID_IP1_SET_WR_INITID_1(mp2_smnif_ram0_write_initid_ip1_reg, wr_initid_1) \
     mp2_smnif_ram0_write_initid_ip1_reg = (mp2_smnif_ram0_write_initid_ip1_reg & ~MP2_SMNIF_RAM0_WRITE_INITID_IP1_WR_INITID_1_MASK) | (wr_initid_1 << MP2_SMNIF_RAM0_WRITE_INITID_IP1_WR_INITID_1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_ram0_write_initid_ip1_t {
          unsigned int wr_initid_1                    : MP2_SMNIF_RAM0_WRITE_INITID_IP1_WR_INITID_1_SIZE;
          unsigned int                                : 22;
     } mp2_smnif_ram0_write_initid_ip1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_ram0_write_initid_ip1_t {
          unsigned int                                : 22;
          unsigned int wr_initid_1                    : MP2_SMNIF_RAM0_WRITE_INITID_IP1_WR_INITID_1_SIZE;
     } mp2_smnif_ram0_write_initid_ip1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_ram0_write_initid_ip1_t f;
} mp2_smnif_ram0_write_initid_ip1_u;


/*
 * MP2_SMNIF_RAM0_WRITE_INITID_IP2 struct
 */

#define MP2_SMNIF_RAM0_WRITE_INITID_IP2_REG_SIZE 32
#define MP2_SMNIF_RAM0_WRITE_INITID_IP2_WR_INITID_2_SIZE 10

#define MP2_SMNIF_RAM0_WRITE_INITID_IP2_WR_INITID_2_SHIFT 0

#define MP2_SMNIF_RAM0_WRITE_INITID_IP2_WR_INITID_2_MASK 0x3ff

#define MP2_SMNIF_RAM0_WRITE_INITID_IP2_MASK \
     (MP2_SMNIF_RAM0_WRITE_INITID_IP2_WR_INITID_2_MASK)

#define MP2_SMNIF_RAM0_WRITE_INITID_IP2_DEFAULT 0x00000000

#define MP2_SMNIF_RAM0_WRITE_INITID_IP2_GET_WR_INITID_2(mp2_smnif_ram0_write_initid_ip2) \
     ((mp2_smnif_ram0_write_initid_ip2 & MP2_SMNIF_RAM0_WRITE_INITID_IP2_WR_INITID_2_MASK) >> MP2_SMNIF_RAM0_WRITE_INITID_IP2_WR_INITID_2_SHIFT)

#define MP2_SMNIF_RAM0_WRITE_INITID_IP2_SET_WR_INITID_2(mp2_smnif_ram0_write_initid_ip2_reg, wr_initid_2) \
     mp2_smnif_ram0_write_initid_ip2_reg = (mp2_smnif_ram0_write_initid_ip2_reg & ~MP2_SMNIF_RAM0_WRITE_INITID_IP2_WR_INITID_2_MASK) | (wr_initid_2 << MP2_SMNIF_RAM0_WRITE_INITID_IP2_WR_INITID_2_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_ram0_write_initid_ip2_t {
          unsigned int wr_initid_2                    : MP2_SMNIF_RAM0_WRITE_INITID_IP2_WR_INITID_2_SIZE;
          unsigned int                                : 22;
     } mp2_smnif_ram0_write_initid_ip2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_ram0_write_initid_ip2_t {
          unsigned int                                : 22;
          unsigned int wr_initid_2                    : MP2_SMNIF_RAM0_WRITE_INITID_IP2_WR_INITID_2_SIZE;
     } mp2_smnif_ram0_write_initid_ip2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_ram0_write_initid_ip2_t f;
} mp2_smnif_ram0_write_initid_ip2_u;


/*
 * MP2_SMNIF_RAM0_WRITE_INITID_IP3 struct
 */

#define MP2_SMNIF_RAM0_WRITE_INITID_IP3_REG_SIZE 32
#define MP2_SMNIF_RAM0_WRITE_INITID_IP3_WR_INITID_3_SIZE 10

#define MP2_SMNIF_RAM0_WRITE_INITID_IP3_WR_INITID_3_SHIFT 0

#define MP2_SMNIF_RAM0_WRITE_INITID_IP3_WR_INITID_3_MASK 0x3ff

#define MP2_SMNIF_RAM0_WRITE_INITID_IP3_MASK \
     (MP2_SMNIF_RAM0_WRITE_INITID_IP3_WR_INITID_3_MASK)

#define MP2_SMNIF_RAM0_WRITE_INITID_IP3_DEFAULT 0x00000000

#define MP2_SMNIF_RAM0_WRITE_INITID_IP3_GET_WR_INITID_3(mp2_smnif_ram0_write_initid_ip3) \
     ((mp2_smnif_ram0_write_initid_ip3 & MP2_SMNIF_RAM0_WRITE_INITID_IP3_WR_INITID_3_MASK) >> MP2_SMNIF_RAM0_WRITE_INITID_IP3_WR_INITID_3_SHIFT)

#define MP2_SMNIF_RAM0_WRITE_INITID_IP3_SET_WR_INITID_3(mp2_smnif_ram0_write_initid_ip3_reg, wr_initid_3) \
     mp2_smnif_ram0_write_initid_ip3_reg = (mp2_smnif_ram0_write_initid_ip3_reg & ~MP2_SMNIF_RAM0_WRITE_INITID_IP3_WR_INITID_3_MASK) | (wr_initid_3 << MP2_SMNIF_RAM0_WRITE_INITID_IP3_WR_INITID_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_ram0_write_initid_ip3_t {
          unsigned int wr_initid_3                    : MP2_SMNIF_RAM0_WRITE_INITID_IP3_WR_INITID_3_SIZE;
          unsigned int                                : 22;
     } mp2_smnif_ram0_write_initid_ip3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_ram0_write_initid_ip3_t {
          unsigned int                                : 22;
          unsigned int wr_initid_3                    : MP2_SMNIF_RAM0_WRITE_INITID_IP3_WR_INITID_3_SIZE;
     } mp2_smnif_ram0_write_initid_ip3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_ram0_write_initid_ip3_t f;
} mp2_smnif_ram0_write_initid_ip3_u;


#endif


