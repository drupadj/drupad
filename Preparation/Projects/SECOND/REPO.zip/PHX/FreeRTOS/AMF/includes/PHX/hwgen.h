/*
* Copyright (C) 2021 Advanced Micro Devices, Inc. All Rights Reserved
*/

#include "FreeRTOS.h"

void *pvMalloc( size_t xWantedSize );
void vFree( void *pv );

/* Device and Vendor ID */
#define REALTEK_PCI_VID 0x10EC
#define QUALCOM_PCI_VID 0x17CB

#define REALTEK_LAN_DID1  0x8168
#define QUALCOM_WLAN_DID1 0x1101
#define QUALCOM_WLAN_DID2 0x1103

