// Copyright (c) 1994 - 2021 Advanced Micro Devices, Inc. All rights reserved. 
 #if !defined (_MPM_HUBIF_NB_FIDDLE_H)
#define _MPM_HUBIF_NB_FIDDLE_H
 /*****************************************************************************************************************
 *
 *  mpm_hubif_nb_reg.h
 *
 *  Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#define LITTLEENDIAN_CPU 1
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif

 /*******************************************************
 * Values
 *******************************************************/

 /*******************************************************
 * Structures
 *******************************************************/

/*
 * MPM_HUBIF_NB_AX_ADDR_LO struct
 */

#define MPM_HUBIF_NB_AX_ADDR_LO_REG_SIZE         32
#define MPM_HUBIF_NB_AX_ADDR_LO_AX_ADDR_LO_SIZE  32

#define MPM_HUBIF_NB_AX_ADDR_LO_AX_ADDR_LO_SHIFT  0

#define MPM_HUBIF_NB_AX_ADDR_LO_AX_ADDR_LO_MASK  0xffffffff

#define MPM_HUBIF_NB_AX_ADDR_LO_MASK \
      (MPM_HUBIF_NB_AX_ADDR_LO_AX_ADDR_LO_MASK)

#define MPM_HUBIF_NB_AX_ADDR_LO_DEFAULT 0x00000000

#define MPM_HUBIF_NB_AX_ADDR_LO_GET_AX_ADDR_LO(mpm_hubif_nb_ax_addr_lo) \
      ((mpm_hubif_nb_ax_addr_lo & MPM_HUBIF_NB_AX_ADDR_LO_AX_ADDR_LO_MASK) >> MPM_HUBIF_NB_AX_ADDR_LO_AX_ADDR_LO_SHIFT)

#define MPM_HUBIF_NB_AX_ADDR_LO_SET_AX_ADDR_LO(mpm_hubif_nb_ax_addr_lo_reg, ax_addr_lo) \
      mpm_hubif_nb_ax_addr_lo_reg = (mpm_hubif_nb_ax_addr_lo_reg & ~MPM_HUBIF_NB_AX_ADDR_LO_AX_ADDR_LO_MASK) | (ax_addr_lo << MPM_HUBIF_NB_AX_ADDR_LO_AX_ADDR_LO_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_ax_addr_lo_t {
            unsigned int ax_addr_lo                     : MPM_HUBIF_NB_AX_ADDR_LO_AX_ADDR_LO_SIZE;
      } mpm_hubif_nb_ax_addr_lo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_ax_addr_lo_t {
            unsigned int ax_addr_lo                     : MPM_HUBIF_NB_AX_ADDR_LO_AX_ADDR_LO_SIZE;
      } mpm_hubif_nb_ax_addr_lo_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_ax_addr_lo_t f;
} mpm_hubif_nb_ax_addr_lo_u;


/*
 * MPM_HUBIF_NB_AX_MISC struct
 */

#define MPM_HUBIF_NB_AX_MISC_REG_SIZE         32
#define MPM_HUBIF_NB_AX_MISC_AX_ADDR_HI_SIZE  16
#define MPM_HUBIF_NB_AX_MISC_AX_ID_SIZE  8
#define MPM_HUBIF_NB_AX_MISC_AX_QOS_SIZE  4

#define MPM_HUBIF_NB_AX_MISC_AX_ADDR_HI_SHIFT  0
#define MPM_HUBIF_NB_AX_MISC_AX_ID_SHIFT  16
#define MPM_HUBIF_NB_AX_MISC_AX_QOS_SHIFT  24

#define MPM_HUBIF_NB_AX_MISC_AX_ADDR_HI_MASK  0x0000ffff
#define MPM_HUBIF_NB_AX_MISC_AX_ID_MASK  0x00ff0000
#define MPM_HUBIF_NB_AX_MISC_AX_QOS_MASK  0x0f000000

#define MPM_HUBIF_NB_AX_MISC_MASK \
      (MPM_HUBIF_NB_AX_MISC_AX_ADDR_HI_MASK | \
      MPM_HUBIF_NB_AX_MISC_AX_ID_MASK | \
      MPM_HUBIF_NB_AX_MISC_AX_QOS_MASK)

#define MPM_HUBIF_NB_AX_MISC_DEFAULT   0x00000000

#define MPM_HUBIF_NB_AX_MISC_GET_AX_ADDR_HI(mpm_hubif_nb_ax_misc) \
      ((mpm_hubif_nb_ax_misc & MPM_HUBIF_NB_AX_MISC_AX_ADDR_HI_MASK) >> MPM_HUBIF_NB_AX_MISC_AX_ADDR_HI_SHIFT)
#define MPM_HUBIF_NB_AX_MISC_GET_AX_ID(mpm_hubif_nb_ax_misc) \
      ((mpm_hubif_nb_ax_misc & MPM_HUBIF_NB_AX_MISC_AX_ID_MASK) >> MPM_HUBIF_NB_AX_MISC_AX_ID_SHIFT)
#define MPM_HUBIF_NB_AX_MISC_GET_AX_QOS(mpm_hubif_nb_ax_misc) \
      ((mpm_hubif_nb_ax_misc & MPM_HUBIF_NB_AX_MISC_AX_QOS_MASK) >> MPM_HUBIF_NB_AX_MISC_AX_QOS_SHIFT)

#define MPM_HUBIF_NB_AX_MISC_SET_AX_ADDR_HI(mpm_hubif_nb_ax_misc_reg, ax_addr_hi) \
      mpm_hubif_nb_ax_misc_reg = (mpm_hubif_nb_ax_misc_reg & ~MPM_HUBIF_NB_AX_MISC_AX_ADDR_HI_MASK) | (ax_addr_hi << MPM_HUBIF_NB_AX_MISC_AX_ADDR_HI_SHIFT)
#define MPM_HUBIF_NB_AX_MISC_SET_AX_ID(mpm_hubif_nb_ax_misc_reg, ax_id) \
      mpm_hubif_nb_ax_misc_reg = (mpm_hubif_nb_ax_misc_reg & ~MPM_HUBIF_NB_AX_MISC_AX_ID_MASK) | (ax_id << MPM_HUBIF_NB_AX_MISC_AX_ID_SHIFT)
#define MPM_HUBIF_NB_AX_MISC_SET_AX_QOS(mpm_hubif_nb_ax_misc_reg, ax_qos) \
      mpm_hubif_nb_ax_misc_reg = (mpm_hubif_nb_ax_misc_reg & ~MPM_HUBIF_NB_AX_MISC_AX_QOS_MASK) | (ax_qos << MPM_HUBIF_NB_AX_MISC_AX_QOS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_ax_misc_t {
            unsigned int ax_addr_hi                     : MPM_HUBIF_NB_AX_MISC_AX_ADDR_HI_SIZE;
            unsigned int ax_id                          : MPM_HUBIF_NB_AX_MISC_AX_ID_SIZE;
            unsigned int ax_qos                         : MPM_HUBIF_NB_AX_MISC_AX_QOS_SIZE;
            unsigned int                                : 4;
      } mpm_hubif_nb_ax_misc_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_ax_misc_t {
            unsigned int                                : 4;
            unsigned int ax_qos                         : MPM_HUBIF_NB_AX_MISC_AX_QOS_SIZE;
            unsigned int ax_id                          : MPM_HUBIF_NB_AX_MISC_AX_ID_SIZE;
            unsigned int ax_addr_hi                     : MPM_HUBIF_NB_AX_MISC_AX_ADDR_HI_SIZE;
      } mpm_hubif_nb_ax_misc_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_ax_misc_t f;
} mpm_hubif_nb_ax_misc_u;


/*
 * MPM_HUBIF_NB_AX_MISC_2 struct
 */

#define MPM_HUBIF_NB_AX_MISC_2_REG_SIZE         32
#define MPM_HUBIF_NB_AX_MISC_2_AX_LEN_SIZE  8
#define MPM_HUBIF_NB_AX_MISC_2_AX_SIZE_SIZE  3
#define MPM_HUBIF_NB_AX_MISC_2_AX_BURST_SIZE  2
#define MPM_HUBIF_NB_AX_MISC_2_AX_CACHE_SIZE  4
#define MPM_HUBIF_NB_AX_MISC_2_AX_PROT_SIZE  3
#define MPM_HUBIF_NB_AX_MISC_2_AX_LOCK_SIZE  2
#define MPM_HUBIF_NB_AX_MISC_2_AX_OPCODE_SIZE  1
#define MPM_HUBIF_NB_AX_MISC_2_AX_TRAN_STRT_SIZE  1
#define MPM_HUBIF_NB_AX_MISC_2_AX_TRAN_END_SIZE  1

#define MPM_HUBIF_NB_AX_MISC_2_AX_LEN_SHIFT  0
#define MPM_HUBIF_NB_AX_MISC_2_AX_SIZE_SHIFT  8
#define MPM_HUBIF_NB_AX_MISC_2_AX_BURST_SHIFT  11
#define MPM_HUBIF_NB_AX_MISC_2_AX_CACHE_SHIFT  13
#define MPM_HUBIF_NB_AX_MISC_2_AX_PROT_SHIFT  17
#define MPM_HUBIF_NB_AX_MISC_2_AX_LOCK_SHIFT  26
#define MPM_HUBIF_NB_AX_MISC_2_AX_OPCODE_SHIFT  28
#define MPM_HUBIF_NB_AX_MISC_2_AX_TRAN_STRT_SHIFT  29
#define MPM_HUBIF_NB_AX_MISC_2_AX_TRAN_END_SHIFT  30

#define MPM_HUBIF_NB_AX_MISC_2_AX_LEN_MASK  0x000000ff
#define MPM_HUBIF_NB_AX_MISC_2_AX_SIZE_MASK  0x00000700
#define MPM_HUBIF_NB_AX_MISC_2_AX_BURST_MASK  0x00001800
#define MPM_HUBIF_NB_AX_MISC_2_AX_CACHE_MASK  0x0001e000
#define MPM_HUBIF_NB_AX_MISC_2_AX_PROT_MASK  0x000e0000
#define MPM_HUBIF_NB_AX_MISC_2_AX_LOCK_MASK  0x0c000000
#define MPM_HUBIF_NB_AX_MISC_2_AX_OPCODE_MASK  0x10000000
#define MPM_HUBIF_NB_AX_MISC_2_AX_TRAN_STRT_MASK  0x20000000
#define MPM_HUBIF_NB_AX_MISC_2_AX_TRAN_END_MASK  0x40000000

#define MPM_HUBIF_NB_AX_MISC_2_MASK \
      (MPM_HUBIF_NB_AX_MISC_2_AX_LEN_MASK | \
      MPM_HUBIF_NB_AX_MISC_2_AX_SIZE_MASK | \
      MPM_HUBIF_NB_AX_MISC_2_AX_BURST_MASK | \
      MPM_HUBIF_NB_AX_MISC_2_AX_CACHE_MASK | \
      MPM_HUBIF_NB_AX_MISC_2_AX_PROT_MASK | \
      MPM_HUBIF_NB_AX_MISC_2_AX_LOCK_MASK | \
      MPM_HUBIF_NB_AX_MISC_2_AX_OPCODE_MASK | \
      MPM_HUBIF_NB_AX_MISC_2_AX_TRAN_STRT_MASK | \
      MPM_HUBIF_NB_AX_MISC_2_AX_TRAN_END_MASK)

#define MPM_HUBIF_NB_AX_MISC_2_DEFAULT 0x00000000

#define MPM_HUBIF_NB_AX_MISC_2_GET_AX_LEN(mpm_hubif_nb_ax_misc_2) \
      ((mpm_hubif_nb_ax_misc_2 & MPM_HUBIF_NB_AX_MISC_2_AX_LEN_MASK) >> MPM_HUBIF_NB_AX_MISC_2_AX_LEN_SHIFT)
#define MPM_HUBIF_NB_AX_MISC_2_GET_AX_SIZE(mpm_hubif_nb_ax_misc_2) \
      ((mpm_hubif_nb_ax_misc_2 & MPM_HUBIF_NB_AX_MISC_2_AX_SIZE_MASK) >> MPM_HUBIF_NB_AX_MISC_2_AX_SIZE_SHIFT)
#define MPM_HUBIF_NB_AX_MISC_2_GET_AX_BURST(mpm_hubif_nb_ax_misc_2) \
      ((mpm_hubif_nb_ax_misc_2 & MPM_HUBIF_NB_AX_MISC_2_AX_BURST_MASK) >> MPM_HUBIF_NB_AX_MISC_2_AX_BURST_SHIFT)
#define MPM_HUBIF_NB_AX_MISC_2_GET_AX_CACHE(mpm_hubif_nb_ax_misc_2) \
      ((mpm_hubif_nb_ax_misc_2 & MPM_HUBIF_NB_AX_MISC_2_AX_CACHE_MASK) >> MPM_HUBIF_NB_AX_MISC_2_AX_CACHE_SHIFT)
#define MPM_HUBIF_NB_AX_MISC_2_GET_AX_PROT(mpm_hubif_nb_ax_misc_2) \
      ((mpm_hubif_nb_ax_misc_2 & MPM_HUBIF_NB_AX_MISC_2_AX_PROT_MASK) >> MPM_HUBIF_NB_AX_MISC_2_AX_PROT_SHIFT)
#define MPM_HUBIF_NB_AX_MISC_2_GET_AX_LOCK(mpm_hubif_nb_ax_misc_2) \
      ((mpm_hubif_nb_ax_misc_2 & MPM_HUBIF_NB_AX_MISC_2_AX_LOCK_MASK) >> MPM_HUBIF_NB_AX_MISC_2_AX_LOCK_SHIFT)
#define MPM_HUBIF_NB_AX_MISC_2_GET_AX_OPCODE(mpm_hubif_nb_ax_misc_2) \
      ((mpm_hubif_nb_ax_misc_2 & MPM_HUBIF_NB_AX_MISC_2_AX_OPCODE_MASK) >> MPM_HUBIF_NB_AX_MISC_2_AX_OPCODE_SHIFT)
#define MPM_HUBIF_NB_AX_MISC_2_GET_AX_TRAN_STRT(mpm_hubif_nb_ax_misc_2) \
      ((mpm_hubif_nb_ax_misc_2 & MPM_HUBIF_NB_AX_MISC_2_AX_TRAN_STRT_MASK) >> MPM_HUBIF_NB_AX_MISC_2_AX_TRAN_STRT_SHIFT)
#define MPM_HUBIF_NB_AX_MISC_2_GET_AX_TRAN_END(mpm_hubif_nb_ax_misc_2) \
      ((mpm_hubif_nb_ax_misc_2 & MPM_HUBIF_NB_AX_MISC_2_AX_TRAN_END_MASK) >> MPM_HUBIF_NB_AX_MISC_2_AX_TRAN_END_SHIFT)

#define MPM_HUBIF_NB_AX_MISC_2_SET_AX_LEN(mpm_hubif_nb_ax_misc_2_reg, ax_len) \
      mpm_hubif_nb_ax_misc_2_reg = (mpm_hubif_nb_ax_misc_2_reg & ~MPM_HUBIF_NB_AX_MISC_2_AX_LEN_MASK) | (ax_len << MPM_HUBIF_NB_AX_MISC_2_AX_LEN_SHIFT)
#define MPM_HUBIF_NB_AX_MISC_2_SET_AX_SIZE(mpm_hubif_nb_ax_misc_2_reg, ax_size) \
      mpm_hubif_nb_ax_misc_2_reg = (mpm_hubif_nb_ax_misc_2_reg & ~MPM_HUBIF_NB_AX_MISC_2_AX_SIZE_MASK) | (ax_size << MPM_HUBIF_NB_AX_MISC_2_AX_SIZE_SHIFT)
#define MPM_HUBIF_NB_AX_MISC_2_SET_AX_BURST(mpm_hubif_nb_ax_misc_2_reg, ax_burst) \
      mpm_hubif_nb_ax_misc_2_reg = (mpm_hubif_nb_ax_misc_2_reg & ~MPM_HUBIF_NB_AX_MISC_2_AX_BURST_MASK) | (ax_burst << MPM_HUBIF_NB_AX_MISC_2_AX_BURST_SHIFT)
#define MPM_HUBIF_NB_AX_MISC_2_SET_AX_CACHE(mpm_hubif_nb_ax_misc_2_reg, ax_cache) \
      mpm_hubif_nb_ax_misc_2_reg = (mpm_hubif_nb_ax_misc_2_reg & ~MPM_HUBIF_NB_AX_MISC_2_AX_CACHE_MASK) | (ax_cache << MPM_HUBIF_NB_AX_MISC_2_AX_CACHE_SHIFT)
#define MPM_HUBIF_NB_AX_MISC_2_SET_AX_PROT(mpm_hubif_nb_ax_misc_2_reg, ax_prot) \
      mpm_hubif_nb_ax_misc_2_reg = (mpm_hubif_nb_ax_misc_2_reg & ~MPM_HUBIF_NB_AX_MISC_2_AX_PROT_MASK) | (ax_prot << MPM_HUBIF_NB_AX_MISC_2_AX_PROT_SHIFT)
#define MPM_HUBIF_NB_AX_MISC_2_SET_AX_LOCK(mpm_hubif_nb_ax_misc_2_reg, ax_lock) \
      mpm_hubif_nb_ax_misc_2_reg = (mpm_hubif_nb_ax_misc_2_reg & ~MPM_HUBIF_NB_AX_MISC_2_AX_LOCK_MASK) | (ax_lock << MPM_HUBIF_NB_AX_MISC_2_AX_LOCK_SHIFT)
#define MPM_HUBIF_NB_AX_MISC_2_SET_AX_OPCODE(mpm_hubif_nb_ax_misc_2_reg, ax_opcode) \
      mpm_hubif_nb_ax_misc_2_reg = (mpm_hubif_nb_ax_misc_2_reg & ~MPM_HUBIF_NB_AX_MISC_2_AX_OPCODE_MASK) | (ax_opcode << MPM_HUBIF_NB_AX_MISC_2_AX_OPCODE_SHIFT)
#define MPM_HUBIF_NB_AX_MISC_2_SET_AX_TRAN_STRT(mpm_hubif_nb_ax_misc_2_reg, ax_tran_strt) \
      mpm_hubif_nb_ax_misc_2_reg = (mpm_hubif_nb_ax_misc_2_reg & ~MPM_HUBIF_NB_AX_MISC_2_AX_TRAN_STRT_MASK) | (ax_tran_strt << MPM_HUBIF_NB_AX_MISC_2_AX_TRAN_STRT_SHIFT)
#define MPM_HUBIF_NB_AX_MISC_2_SET_AX_TRAN_END(mpm_hubif_nb_ax_misc_2_reg, ax_tran_end) \
      mpm_hubif_nb_ax_misc_2_reg = (mpm_hubif_nb_ax_misc_2_reg & ~MPM_HUBIF_NB_AX_MISC_2_AX_TRAN_END_MASK) | (ax_tran_end << MPM_HUBIF_NB_AX_MISC_2_AX_TRAN_END_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_ax_misc_2_t {
            unsigned int ax_len                         : MPM_HUBIF_NB_AX_MISC_2_AX_LEN_SIZE;
            unsigned int ax_size                        : MPM_HUBIF_NB_AX_MISC_2_AX_SIZE_SIZE;
            unsigned int ax_burst                       : MPM_HUBIF_NB_AX_MISC_2_AX_BURST_SIZE;
            unsigned int ax_cache                       : MPM_HUBIF_NB_AX_MISC_2_AX_CACHE_SIZE;
            unsigned int ax_prot                        : MPM_HUBIF_NB_AX_MISC_2_AX_PROT_SIZE;
            unsigned int                                : 6;
            unsigned int ax_lock                        : MPM_HUBIF_NB_AX_MISC_2_AX_LOCK_SIZE;
            unsigned int ax_opcode                      : MPM_HUBIF_NB_AX_MISC_2_AX_OPCODE_SIZE;
            unsigned int ax_tran_strt                   : MPM_HUBIF_NB_AX_MISC_2_AX_TRAN_STRT_SIZE;
            unsigned int ax_tran_end                    : MPM_HUBIF_NB_AX_MISC_2_AX_TRAN_END_SIZE;
            unsigned int                                : 1;
      } mpm_hubif_nb_ax_misc_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_ax_misc_2_t {
            unsigned int                                : 1;
            unsigned int ax_tran_end                    : MPM_HUBIF_NB_AX_MISC_2_AX_TRAN_END_SIZE;
            unsigned int ax_tran_strt                   : MPM_HUBIF_NB_AX_MISC_2_AX_TRAN_STRT_SIZE;
            unsigned int ax_opcode                      : MPM_HUBIF_NB_AX_MISC_2_AX_OPCODE_SIZE;
            unsigned int ax_lock                        : MPM_HUBIF_NB_AX_MISC_2_AX_LOCK_SIZE;
            unsigned int                                : 6;
            unsigned int ax_prot                        : MPM_HUBIF_NB_AX_MISC_2_AX_PROT_SIZE;
            unsigned int ax_cache                       : MPM_HUBIF_NB_AX_MISC_2_AX_CACHE_SIZE;
            unsigned int ax_burst                       : MPM_HUBIF_NB_AX_MISC_2_AX_BURST_SIZE;
            unsigned int ax_size                        : MPM_HUBIF_NB_AX_MISC_2_AX_SIZE_SIZE;
            unsigned int ax_len                         : MPM_HUBIF_NB_AX_MISC_2_AX_LEN_SIZE;
      } mpm_hubif_nb_ax_misc_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_ax_misc_2_t f;
} mpm_hubif_nb_ax_misc_2_u;


/*
 * MPM_HUBIF_NB_AX_MISC_3 struct
 */

#define MPM_HUBIF_NB_AX_MISC_3_REG_SIZE         32
#define MPM_HUBIF_NB_AX_MISC_3_AX_USER_SIZE  6

#define MPM_HUBIF_NB_AX_MISC_3_AX_USER_SHIFT  0

#define MPM_HUBIF_NB_AX_MISC_3_AX_USER_MASK  0x0000003f

#define MPM_HUBIF_NB_AX_MISC_3_MASK \
      (MPM_HUBIF_NB_AX_MISC_3_AX_USER_MASK)

#define MPM_HUBIF_NB_AX_MISC_3_DEFAULT 0x00000000

#define MPM_HUBIF_NB_AX_MISC_3_GET_AX_USER(mpm_hubif_nb_ax_misc_3) \
      ((mpm_hubif_nb_ax_misc_3 & MPM_HUBIF_NB_AX_MISC_3_AX_USER_MASK) >> MPM_HUBIF_NB_AX_MISC_3_AX_USER_SHIFT)

#define MPM_HUBIF_NB_AX_MISC_3_SET_AX_USER(mpm_hubif_nb_ax_misc_3_reg, ax_user) \
      mpm_hubif_nb_ax_misc_3_reg = (mpm_hubif_nb_ax_misc_3_reg & ~MPM_HUBIF_NB_AX_MISC_3_AX_USER_MASK) | (ax_user << MPM_HUBIF_NB_AX_MISC_3_AX_USER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_ax_misc_3_t {
            unsigned int ax_user                        : MPM_HUBIF_NB_AX_MISC_3_AX_USER_SIZE;
            unsigned int                                : 26;
      } mpm_hubif_nb_ax_misc_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_ax_misc_3_t {
            unsigned int                                : 26;
            unsigned int ax_user                        : MPM_HUBIF_NB_AX_MISC_3_AX_USER_SIZE;
      } mpm_hubif_nb_ax_misc_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_ax_misc_3_t f;
} mpm_hubif_nb_ax_misc_3_u;


/*
 * MPM_HUBIF_NB_WSTRB0 struct
 */

#define MPM_HUBIF_NB_WSTRB0_REG_SIZE         32
#define MPM_HUBIF_NB_WSTRB0_AX_WSTRB_SIZE  32

#define MPM_HUBIF_NB_WSTRB0_AX_WSTRB_SHIFT  0

#define MPM_HUBIF_NB_WSTRB0_AX_WSTRB_MASK  0xffffffff

#define MPM_HUBIF_NB_WSTRB0_MASK \
      (MPM_HUBIF_NB_WSTRB0_AX_WSTRB_MASK)

#define MPM_HUBIF_NB_WSTRB0_DEFAULT    0x00000000

#define MPM_HUBIF_NB_WSTRB0_GET_AX_WSTRB(mpm_hubif_nb_wstrb0) \
      ((mpm_hubif_nb_wstrb0 & MPM_HUBIF_NB_WSTRB0_AX_WSTRB_MASK) >> MPM_HUBIF_NB_WSTRB0_AX_WSTRB_SHIFT)

#define MPM_HUBIF_NB_WSTRB0_SET_AX_WSTRB(mpm_hubif_nb_wstrb0_reg, ax_wstrb) \
      mpm_hubif_nb_wstrb0_reg = (mpm_hubif_nb_wstrb0_reg & ~MPM_HUBIF_NB_WSTRB0_AX_WSTRB_MASK) | (ax_wstrb << MPM_HUBIF_NB_WSTRB0_AX_WSTRB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_wstrb0_t {
            unsigned int ax_wstrb                       : MPM_HUBIF_NB_WSTRB0_AX_WSTRB_SIZE;
      } mpm_hubif_nb_wstrb0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_wstrb0_t {
            unsigned int ax_wstrb                       : MPM_HUBIF_NB_WSTRB0_AX_WSTRB_SIZE;
      } mpm_hubif_nb_wstrb0_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_wstrb0_t f;
} mpm_hubif_nb_wstrb0_u;


/*
 * MPM_HUBIF_NB_WSTRB1 struct
 */

#define MPM_HUBIF_NB_WSTRB1_REG_SIZE         32
#define MPM_HUBIF_NB_WSTRB1_AX_WSTRB_SIZE  32

#define MPM_HUBIF_NB_WSTRB1_AX_WSTRB_SHIFT  0

#define MPM_HUBIF_NB_WSTRB1_AX_WSTRB_MASK  0xffffffff

#define MPM_HUBIF_NB_WSTRB1_MASK \
      (MPM_HUBIF_NB_WSTRB1_AX_WSTRB_MASK)

#define MPM_HUBIF_NB_WSTRB1_DEFAULT    0x00000000

#define MPM_HUBIF_NB_WSTRB1_GET_AX_WSTRB(mpm_hubif_nb_wstrb1) \
      ((mpm_hubif_nb_wstrb1 & MPM_HUBIF_NB_WSTRB1_AX_WSTRB_MASK) >> MPM_HUBIF_NB_WSTRB1_AX_WSTRB_SHIFT)

#define MPM_HUBIF_NB_WSTRB1_SET_AX_WSTRB(mpm_hubif_nb_wstrb1_reg, ax_wstrb) \
      mpm_hubif_nb_wstrb1_reg = (mpm_hubif_nb_wstrb1_reg & ~MPM_HUBIF_NB_WSTRB1_AX_WSTRB_MASK) | (ax_wstrb << MPM_HUBIF_NB_WSTRB1_AX_WSTRB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_wstrb1_t {
            unsigned int ax_wstrb                       : MPM_HUBIF_NB_WSTRB1_AX_WSTRB_SIZE;
      } mpm_hubif_nb_wstrb1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_wstrb1_t {
            unsigned int ax_wstrb                       : MPM_HUBIF_NB_WSTRB1_AX_WSTRB_SIZE;
      } mpm_hubif_nb_wstrb1_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_wstrb1_t f;
} mpm_hubif_nb_wstrb1_u;


/*
 * MPM_HUBIF_NB_WDATA0 struct
 */

#define MPM_HUBIF_NB_WDATA0_REG_SIZE         32
#define MPM_HUBIF_NB_WDATA0_AX_WDATA_SIZE  32

#define MPM_HUBIF_NB_WDATA0_AX_WDATA_SHIFT  0

#define MPM_HUBIF_NB_WDATA0_AX_WDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_WDATA0_MASK \
      (MPM_HUBIF_NB_WDATA0_AX_WDATA_MASK)

#define MPM_HUBIF_NB_WDATA0_DEFAULT    0x00000000

#define MPM_HUBIF_NB_WDATA0_GET_AX_WDATA(mpm_hubif_nb_wdata0) \
      ((mpm_hubif_nb_wdata0 & MPM_HUBIF_NB_WDATA0_AX_WDATA_MASK) >> MPM_HUBIF_NB_WDATA0_AX_WDATA_SHIFT)

#define MPM_HUBIF_NB_WDATA0_SET_AX_WDATA(mpm_hubif_nb_wdata0_reg, ax_wdata) \
      mpm_hubif_nb_wdata0_reg = (mpm_hubif_nb_wdata0_reg & ~MPM_HUBIF_NB_WDATA0_AX_WDATA_MASK) | (ax_wdata << MPM_HUBIF_NB_WDATA0_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata0_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA0_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata0_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA0_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata0_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_wdata0_t f;
} mpm_hubif_nb_wdata0_u;


/*
 * MPM_HUBIF_NB_WDATA1 struct
 */

#define MPM_HUBIF_NB_WDATA1_REG_SIZE         32
#define MPM_HUBIF_NB_WDATA1_AX_WDATA_SIZE  32

#define MPM_HUBIF_NB_WDATA1_AX_WDATA_SHIFT  0

#define MPM_HUBIF_NB_WDATA1_AX_WDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_WDATA1_MASK \
      (MPM_HUBIF_NB_WDATA1_AX_WDATA_MASK)

#define MPM_HUBIF_NB_WDATA1_DEFAULT    0x00000000

#define MPM_HUBIF_NB_WDATA1_GET_AX_WDATA(mpm_hubif_nb_wdata1) \
      ((mpm_hubif_nb_wdata1 & MPM_HUBIF_NB_WDATA1_AX_WDATA_MASK) >> MPM_HUBIF_NB_WDATA1_AX_WDATA_SHIFT)

#define MPM_HUBIF_NB_WDATA1_SET_AX_WDATA(mpm_hubif_nb_wdata1_reg, ax_wdata) \
      mpm_hubif_nb_wdata1_reg = (mpm_hubif_nb_wdata1_reg & ~MPM_HUBIF_NB_WDATA1_AX_WDATA_MASK) | (ax_wdata << MPM_HUBIF_NB_WDATA1_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata1_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA1_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata1_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA1_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata1_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_wdata1_t f;
} mpm_hubif_nb_wdata1_u;


/*
 * MPM_HUBIF_NB_WDATA2 struct
 */

#define MPM_HUBIF_NB_WDATA2_REG_SIZE         32
#define MPM_HUBIF_NB_WDATA2_AX_WDATA_SIZE  32

#define MPM_HUBIF_NB_WDATA2_AX_WDATA_SHIFT  0

#define MPM_HUBIF_NB_WDATA2_AX_WDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_WDATA2_MASK \
      (MPM_HUBIF_NB_WDATA2_AX_WDATA_MASK)

#define MPM_HUBIF_NB_WDATA2_DEFAULT    0x00000000

#define MPM_HUBIF_NB_WDATA2_GET_AX_WDATA(mpm_hubif_nb_wdata2) \
      ((mpm_hubif_nb_wdata2 & MPM_HUBIF_NB_WDATA2_AX_WDATA_MASK) >> MPM_HUBIF_NB_WDATA2_AX_WDATA_SHIFT)

#define MPM_HUBIF_NB_WDATA2_SET_AX_WDATA(mpm_hubif_nb_wdata2_reg, ax_wdata) \
      mpm_hubif_nb_wdata2_reg = (mpm_hubif_nb_wdata2_reg & ~MPM_HUBIF_NB_WDATA2_AX_WDATA_MASK) | (ax_wdata << MPM_HUBIF_NB_WDATA2_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata2_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA2_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata2_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA2_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata2_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_wdata2_t f;
} mpm_hubif_nb_wdata2_u;


/*
 * MPM_HUBIF_NB_WDATA3 struct
 */

#define MPM_HUBIF_NB_WDATA3_REG_SIZE         32
#define MPM_HUBIF_NB_WDATA3_AX_WDATA_SIZE  32

#define MPM_HUBIF_NB_WDATA3_AX_WDATA_SHIFT  0

#define MPM_HUBIF_NB_WDATA3_AX_WDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_WDATA3_MASK \
      (MPM_HUBIF_NB_WDATA3_AX_WDATA_MASK)

#define MPM_HUBIF_NB_WDATA3_DEFAULT    0x00000000

#define MPM_HUBIF_NB_WDATA3_GET_AX_WDATA(mpm_hubif_nb_wdata3) \
      ((mpm_hubif_nb_wdata3 & MPM_HUBIF_NB_WDATA3_AX_WDATA_MASK) >> MPM_HUBIF_NB_WDATA3_AX_WDATA_SHIFT)

#define MPM_HUBIF_NB_WDATA3_SET_AX_WDATA(mpm_hubif_nb_wdata3_reg, ax_wdata) \
      mpm_hubif_nb_wdata3_reg = (mpm_hubif_nb_wdata3_reg & ~MPM_HUBIF_NB_WDATA3_AX_WDATA_MASK) | (ax_wdata << MPM_HUBIF_NB_WDATA3_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata3_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA3_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata3_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA3_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata3_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_wdata3_t f;
} mpm_hubif_nb_wdata3_u;


/*
 * MPM_HUBIF_NB_WDATA4 struct
 */

#define MPM_HUBIF_NB_WDATA4_REG_SIZE         32
#define MPM_HUBIF_NB_WDATA4_AX_WDATA_SIZE  32

#define MPM_HUBIF_NB_WDATA4_AX_WDATA_SHIFT  0

#define MPM_HUBIF_NB_WDATA4_AX_WDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_WDATA4_MASK \
      (MPM_HUBIF_NB_WDATA4_AX_WDATA_MASK)

#define MPM_HUBIF_NB_WDATA4_DEFAULT    0x00000000

#define MPM_HUBIF_NB_WDATA4_GET_AX_WDATA(mpm_hubif_nb_wdata4) \
      ((mpm_hubif_nb_wdata4 & MPM_HUBIF_NB_WDATA4_AX_WDATA_MASK) >> MPM_HUBIF_NB_WDATA4_AX_WDATA_SHIFT)

#define MPM_HUBIF_NB_WDATA4_SET_AX_WDATA(mpm_hubif_nb_wdata4_reg, ax_wdata) \
      mpm_hubif_nb_wdata4_reg = (mpm_hubif_nb_wdata4_reg & ~MPM_HUBIF_NB_WDATA4_AX_WDATA_MASK) | (ax_wdata << MPM_HUBIF_NB_WDATA4_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata4_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA4_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata4_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA4_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata4_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_wdata4_t f;
} mpm_hubif_nb_wdata4_u;


/*
 * MPM_HUBIF_NB_WDATA5 struct
 */

#define MPM_HUBIF_NB_WDATA5_REG_SIZE         32
#define MPM_HUBIF_NB_WDATA5_AX_WDATA_SIZE  32

#define MPM_HUBIF_NB_WDATA5_AX_WDATA_SHIFT  0

#define MPM_HUBIF_NB_WDATA5_AX_WDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_WDATA5_MASK \
      (MPM_HUBIF_NB_WDATA5_AX_WDATA_MASK)

#define MPM_HUBIF_NB_WDATA5_DEFAULT    0x00000000

#define MPM_HUBIF_NB_WDATA5_GET_AX_WDATA(mpm_hubif_nb_wdata5) \
      ((mpm_hubif_nb_wdata5 & MPM_HUBIF_NB_WDATA5_AX_WDATA_MASK) >> MPM_HUBIF_NB_WDATA5_AX_WDATA_SHIFT)

#define MPM_HUBIF_NB_WDATA5_SET_AX_WDATA(mpm_hubif_nb_wdata5_reg, ax_wdata) \
      mpm_hubif_nb_wdata5_reg = (mpm_hubif_nb_wdata5_reg & ~MPM_HUBIF_NB_WDATA5_AX_WDATA_MASK) | (ax_wdata << MPM_HUBIF_NB_WDATA5_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata5_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA5_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata5_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA5_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata5_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_wdata5_t f;
} mpm_hubif_nb_wdata5_u;


/*
 * MPM_HUBIF_NB_WDATA6 struct
 */

#define MPM_HUBIF_NB_WDATA6_REG_SIZE         32
#define MPM_HUBIF_NB_WDATA6_AX_WDATA_SIZE  32

#define MPM_HUBIF_NB_WDATA6_AX_WDATA_SHIFT  0

#define MPM_HUBIF_NB_WDATA6_AX_WDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_WDATA6_MASK \
      (MPM_HUBIF_NB_WDATA6_AX_WDATA_MASK)

#define MPM_HUBIF_NB_WDATA6_DEFAULT    0x00000000

#define MPM_HUBIF_NB_WDATA6_GET_AX_WDATA(mpm_hubif_nb_wdata6) \
      ((mpm_hubif_nb_wdata6 & MPM_HUBIF_NB_WDATA6_AX_WDATA_MASK) >> MPM_HUBIF_NB_WDATA6_AX_WDATA_SHIFT)

#define MPM_HUBIF_NB_WDATA6_SET_AX_WDATA(mpm_hubif_nb_wdata6_reg, ax_wdata) \
      mpm_hubif_nb_wdata6_reg = (mpm_hubif_nb_wdata6_reg & ~MPM_HUBIF_NB_WDATA6_AX_WDATA_MASK) | (ax_wdata << MPM_HUBIF_NB_WDATA6_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata6_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA6_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata6_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA6_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata6_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_wdata6_t f;
} mpm_hubif_nb_wdata6_u;


/*
 * MPM_HUBIF_NB_WDATA7 struct
 */

#define MPM_HUBIF_NB_WDATA7_REG_SIZE         32
#define MPM_HUBIF_NB_WDATA7_AX_WDATA_SIZE  32

#define MPM_HUBIF_NB_WDATA7_AX_WDATA_SHIFT  0

#define MPM_HUBIF_NB_WDATA7_AX_WDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_WDATA7_MASK \
      (MPM_HUBIF_NB_WDATA7_AX_WDATA_MASK)

#define MPM_HUBIF_NB_WDATA7_DEFAULT    0x00000000

#define MPM_HUBIF_NB_WDATA7_GET_AX_WDATA(mpm_hubif_nb_wdata7) \
      ((mpm_hubif_nb_wdata7 & MPM_HUBIF_NB_WDATA7_AX_WDATA_MASK) >> MPM_HUBIF_NB_WDATA7_AX_WDATA_SHIFT)

#define MPM_HUBIF_NB_WDATA7_SET_AX_WDATA(mpm_hubif_nb_wdata7_reg, ax_wdata) \
      mpm_hubif_nb_wdata7_reg = (mpm_hubif_nb_wdata7_reg & ~MPM_HUBIF_NB_WDATA7_AX_WDATA_MASK) | (ax_wdata << MPM_HUBIF_NB_WDATA7_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata7_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA7_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata7_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA7_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata7_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_wdata7_t f;
} mpm_hubif_nb_wdata7_u;


/*
 * MPM_HUBIF_NB_WDATA8 struct
 */

#define MPM_HUBIF_NB_WDATA8_REG_SIZE         32
#define MPM_HUBIF_NB_WDATA8_AX_WDATA_SIZE  32

#define MPM_HUBIF_NB_WDATA8_AX_WDATA_SHIFT  0

#define MPM_HUBIF_NB_WDATA8_AX_WDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_WDATA8_MASK \
      (MPM_HUBIF_NB_WDATA8_AX_WDATA_MASK)

#define MPM_HUBIF_NB_WDATA8_DEFAULT    0x00000000

#define MPM_HUBIF_NB_WDATA8_GET_AX_WDATA(mpm_hubif_nb_wdata8) \
      ((mpm_hubif_nb_wdata8 & MPM_HUBIF_NB_WDATA8_AX_WDATA_MASK) >> MPM_HUBIF_NB_WDATA8_AX_WDATA_SHIFT)

#define MPM_HUBIF_NB_WDATA8_SET_AX_WDATA(mpm_hubif_nb_wdata8_reg, ax_wdata) \
      mpm_hubif_nb_wdata8_reg = (mpm_hubif_nb_wdata8_reg & ~MPM_HUBIF_NB_WDATA8_AX_WDATA_MASK) | (ax_wdata << MPM_HUBIF_NB_WDATA8_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata8_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA8_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata8_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA8_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata8_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_wdata8_t f;
} mpm_hubif_nb_wdata8_u;


/*
 * MPM_HUBIF_NB_WDATA9 struct
 */

#define MPM_HUBIF_NB_WDATA9_REG_SIZE         32
#define MPM_HUBIF_NB_WDATA9_AX_WDATA_SIZE  32

#define MPM_HUBIF_NB_WDATA9_AX_WDATA_SHIFT  0

#define MPM_HUBIF_NB_WDATA9_AX_WDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_WDATA9_MASK \
      (MPM_HUBIF_NB_WDATA9_AX_WDATA_MASK)

#define MPM_HUBIF_NB_WDATA9_DEFAULT    0x00000000

#define MPM_HUBIF_NB_WDATA9_GET_AX_WDATA(mpm_hubif_nb_wdata9) \
      ((mpm_hubif_nb_wdata9 & MPM_HUBIF_NB_WDATA9_AX_WDATA_MASK) >> MPM_HUBIF_NB_WDATA9_AX_WDATA_SHIFT)

#define MPM_HUBIF_NB_WDATA9_SET_AX_WDATA(mpm_hubif_nb_wdata9_reg, ax_wdata) \
      mpm_hubif_nb_wdata9_reg = (mpm_hubif_nb_wdata9_reg & ~MPM_HUBIF_NB_WDATA9_AX_WDATA_MASK) | (ax_wdata << MPM_HUBIF_NB_WDATA9_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata9_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA9_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata9_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA9_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata9_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_wdata9_t f;
} mpm_hubif_nb_wdata9_u;


/*
 * MPM_HUBIF_NB_WDATA10 struct
 */

#define MPM_HUBIF_NB_WDATA10_REG_SIZE         32
#define MPM_HUBIF_NB_WDATA10_AX_WDATA_SIZE  32

#define MPM_HUBIF_NB_WDATA10_AX_WDATA_SHIFT  0

#define MPM_HUBIF_NB_WDATA10_AX_WDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_WDATA10_MASK \
      (MPM_HUBIF_NB_WDATA10_AX_WDATA_MASK)

#define MPM_HUBIF_NB_WDATA10_DEFAULT   0x00000000

#define MPM_HUBIF_NB_WDATA10_GET_AX_WDATA(mpm_hubif_nb_wdata10) \
      ((mpm_hubif_nb_wdata10 & MPM_HUBIF_NB_WDATA10_AX_WDATA_MASK) >> MPM_HUBIF_NB_WDATA10_AX_WDATA_SHIFT)

#define MPM_HUBIF_NB_WDATA10_SET_AX_WDATA(mpm_hubif_nb_wdata10_reg, ax_wdata) \
      mpm_hubif_nb_wdata10_reg = (mpm_hubif_nb_wdata10_reg & ~MPM_HUBIF_NB_WDATA10_AX_WDATA_MASK) | (ax_wdata << MPM_HUBIF_NB_WDATA10_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata10_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA10_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata10_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA10_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata10_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_wdata10_t f;
} mpm_hubif_nb_wdata10_u;


/*
 * MPM_HUBIF_NB_WDATA11 struct
 */

#define MPM_HUBIF_NB_WDATA11_REG_SIZE         32
#define MPM_HUBIF_NB_WDATA11_AX_WDATA_SIZE  32

#define MPM_HUBIF_NB_WDATA11_AX_WDATA_SHIFT  0

#define MPM_HUBIF_NB_WDATA11_AX_WDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_WDATA11_MASK \
      (MPM_HUBIF_NB_WDATA11_AX_WDATA_MASK)

#define MPM_HUBIF_NB_WDATA11_DEFAULT   0x00000000

#define MPM_HUBIF_NB_WDATA11_GET_AX_WDATA(mpm_hubif_nb_wdata11) \
      ((mpm_hubif_nb_wdata11 & MPM_HUBIF_NB_WDATA11_AX_WDATA_MASK) >> MPM_HUBIF_NB_WDATA11_AX_WDATA_SHIFT)

#define MPM_HUBIF_NB_WDATA11_SET_AX_WDATA(mpm_hubif_nb_wdata11_reg, ax_wdata) \
      mpm_hubif_nb_wdata11_reg = (mpm_hubif_nb_wdata11_reg & ~MPM_HUBIF_NB_WDATA11_AX_WDATA_MASK) | (ax_wdata << MPM_HUBIF_NB_WDATA11_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata11_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA11_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata11_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA11_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata11_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_wdata11_t f;
} mpm_hubif_nb_wdata11_u;


/*
 * MPM_HUBIF_NB_WDATA12 struct
 */

#define MPM_HUBIF_NB_WDATA12_REG_SIZE         32
#define MPM_HUBIF_NB_WDATA12_AX_WDATA_SIZE  32

#define MPM_HUBIF_NB_WDATA12_AX_WDATA_SHIFT  0

#define MPM_HUBIF_NB_WDATA12_AX_WDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_WDATA12_MASK \
      (MPM_HUBIF_NB_WDATA12_AX_WDATA_MASK)

#define MPM_HUBIF_NB_WDATA12_DEFAULT   0x00000000

#define MPM_HUBIF_NB_WDATA12_GET_AX_WDATA(mpm_hubif_nb_wdata12) \
      ((mpm_hubif_nb_wdata12 & MPM_HUBIF_NB_WDATA12_AX_WDATA_MASK) >> MPM_HUBIF_NB_WDATA12_AX_WDATA_SHIFT)

#define MPM_HUBIF_NB_WDATA12_SET_AX_WDATA(mpm_hubif_nb_wdata12_reg, ax_wdata) \
      mpm_hubif_nb_wdata12_reg = (mpm_hubif_nb_wdata12_reg & ~MPM_HUBIF_NB_WDATA12_AX_WDATA_MASK) | (ax_wdata << MPM_HUBIF_NB_WDATA12_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata12_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA12_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata12_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA12_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata12_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_wdata12_t f;
} mpm_hubif_nb_wdata12_u;


/*
 * MPM_HUBIF_NB_WDATA13 struct
 */

#define MPM_HUBIF_NB_WDATA13_REG_SIZE         32
#define MPM_HUBIF_NB_WDATA13_AX_WDATA_SIZE  32

#define MPM_HUBIF_NB_WDATA13_AX_WDATA_SHIFT  0

#define MPM_HUBIF_NB_WDATA13_AX_WDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_WDATA13_MASK \
      (MPM_HUBIF_NB_WDATA13_AX_WDATA_MASK)

#define MPM_HUBIF_NB_WDATA13_DEFAULT   0x00000000

#define MPM_HUBIF_NB_WDATA13_GET_AX_WDATA(mpm_hubif_nb_wdata13) \
      ((mpm_hubif_nb_wdata13 & MPM_HUBIF_NB_WDATA13_AX_WDATA_MASK) >> MPM_HUBIF_NB_WDATA13_AX_WDATA_SHIFT)

#define MPM_HUBIF_NB_WDATA13_SET_AX_WDATA(mpm_hubif_nb_wdata13_reg, ax_wdata) \
      mpm_hubif_nb_wdata13_reg = (mpm_hubif_nb_wdata13_reg & ~MPM_HUBIF_NB_WDATA13_AX_WDATA_MASK) | (ax_wdata << MPM_HUBIF_NB_WDATA13_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata13_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA13_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata13_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA13_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata13_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_wdata13_t f;
} mpm_hubif_nb_wdata13_u;


/*
 * MPM_HUBIF_NB_WDATA14 struct
 */

#define MPM_HUBIF_NB_WDATA14_REG_SIZE         32
#define MPM_HUBIF_NB_WDATA14_AX_WDATA_SIZE  32

#define MPM_HUBIF_NB_WDATA14_AX_WDATA_SHIFT  0

#define MPM_HUBIF_NB_WDATA14_AX_WDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_WDATA14_MASK \
      (MPM_HUBIF_NB_WDATA14_AX_WDATA_MASK)

#define MPM_HUBIF_NB_WDATA14_DEFAULT   0x00000000

#define MPM_HUBIF_NB_WDATA14_GET_AX_WDATA(mpm_hubif_nb_wdata14) \
      ((mpm_hubif_nb_wdata14 & MPM_HUBIF_NB_WDATA14_AX_WDATA_MASK) >> MPM_HUBIF_NB_WDATA14_AX_WDATA_SHIFT)

#define MPM_HUBIF_NB_WDATA14_SET_AX_WDATA(mpm_hubif_nb_wdata14_reg, ax_wdata) \
      mpm_hubif_nb_wdata14_reg = (mpm_hubif_nb_wdata14_reg & ~MPM_HUBIF_NB_WDATA14_AX_WDATA_MASK) | (ax_wdata << MPM_HUBIF_NB_WDATA14_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata14_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA14_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata14_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA14_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata14_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_wdata14_t f;
} mpm_hubif_nb_wdata14_u;


/*
 * MPM_HUBIF_NB_WDATA15 struct
 */

#define MPM_HUBIF_NB_WDATA15_REG_SIZE         32
#define MPM_HUBIF_NB_WDATA15_AX_WDATA_SIZE  32

#define MPM_HUBIF_NB_WDATA15_AX_WDATA_SHIFT  0

#define MPM_HUBIF_NB_WDATA15_AX_WDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_WDATA15_MASK \
      (MPM_HUBIF_NB_WDATA15_AX_WDATA_MASK)

#define MPM_HUBIF_NB_WDATA15_DEFAULT   0x00000000

#define MPM_HUBIF_NB_WDATA15_GET_AX_WDATA(mpm_hubif_nb_wdata15) \
      ((mpm_hubif_nb_wdata15 & MPM_HUBIF_NB_WDATA15_AX_WDATA_MASK) >> MPM_HUBIF_NB_WDATA15_AX_WDATA_SHIFT)

#define MPM_HUBIF_NB_WDATA15_SET_AX_WDATA(mpm_hubif_nb_wdata15_reg, ax_wdata) \
      mpm_hubif_nb_wdata15_reg = (mpm_hubif_nb_wdata15_reg & ~MPM_HUBIF_NB_WDATA15_AX_WDATA_MASK) | (ax_wdata << MPM_HUBIF_NB_WDATA15_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata15_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA15_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_wdata15_t {
            unsigned int ax_wdata                       : MPM_HUBIF_NB_WDATA15_AX_WDATA_SIZE;
      } mpm_hubif_nb_wdata15_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_wdata15_t f;
} mpm_hubif_nb_wdata15_u;


/*
 * MPM_HUBIF_NB_RDATA0 struct
 */

#define MPM_HUBIF_NB_RDATA0_REG_SIZE         32
#define MPM_HUBIF_NB_RDATA0_AX_RDATA_SIZE  32

#define MPM_HUBIF_NB_RDATA0_AX_RDATA_SHIFT  0

#define MPM_HUBIF_NB_RDATA0_AX_RDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_RDATA0_MASK \
      (MPM_HUBIF_NB_RDATA0_AX_RDATA_MASK)

#define MPM_HUBIF_NB_RDATA0_DEFAULT    0x00000000

#define MPM_HUBIF_NB_RDATA0_GET_AX_RDATA(mpm_hubif_nb_rdata0) \
      ((mpm_hubif_nb_rdata0 & MPM_HUBIF_NB_RDATA0_AX_RDATA_MASK) >> MPM_HUBIF_NB_RDATA0_AX_RDATA_SHIFT)

#define MPM_HUBIF_NB_RDATA0_SET_AX_RDATA(mpm_hubif_nb_rdata0_reg, ax_rdata) \
      mpm_hubif_nb_rdata0_reg = (mpm_hubif_nb_rdata0_reg & ~MPM_HUBIF_NB_RDATA0_AX_RDATA_MASK) | (ax_rdata << MPM_HUBIF_NB_RDATA0_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata0_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA0_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata0_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA0_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata0_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_rdata0_t f;
} mpm_hubif_nb_rdata0_u;


/*
 * MPM_HUBIF_NB_RDATA1 struct
 */

#define MPM_HUBIF_NB_RDATA1_REG_SIZE         32
#define MPM_HUBIF_NB_RDATA1_AX_RDATA_SIZE  32

#define MPM_HUBIF_NB_RDATA1_AX_RDATA_SHIFT  0

#define MPM_HUBIF_NB_RDATA1_AX_RDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_RDATA1_MASK \
      (MPM_HUBIF_NB_RDATA1_AX_RDATA_MASK)

#define MPM_HUBIF_NB_RDATA1_DEFAULT    0x00000000

#define MPM_HUBIF_NB_RDATA1_GET_AX_RDATA(mpm_hubif_nb_rdata1) \
      ((mpm_hubif_nb_rdata1 & MPM_HUBIF_NB_RDATA1_AX_RDATA_MASK) >> MPM_HUBIF_NB_RDATA1_AX_RDATA_SHIFT)

#define MPM_HUBIF_NB_RDATA1_SET_AX_RDATA(mpm_hubif_nb_rdata1_reg, ax_rdata) \
      mpm_hubif_nb_rdata1_reg = (mpm_hubif_nb_rdata1_reg & ~MPM_HUBIF_NB_RDATA1_AX_RDATA_MASK) | (ax_rdata << MPM_HUBIF_NB_RDATA1_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata1_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA1_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata1_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA1_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata1_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_rdata1_t f;
} mpm_hubif_nb_rdata1_u;


/*
 * MPM_HUBIF_NB_RDATA2 struct
 */

#define MPM_HUBIF_NB_RDATA2_REG_SIZE         32
#define MPM_HUBIF_NB_RDATA2_AX_RDATA_SIZE  32

#define MPM_HUBIF_NB_RDATA2_AX_RDATA_SHIFT  0

#define MPM_HUBIF_NB_RDATA2_AX_RDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_RDATA2_MASK \
      (MPM_HUBIF_NB_RDATA2_AX_RDATA_MASK)

#define MPM_HUBIF_NB_RDATA2_DEFAULT    0x00000000

#define MPM_HUBIF_NB_RDATA2_GET_AX_RDATA(mpm_hubif_nb_rdata2) \
      ((mpm_hubif_nb_rdata2 & MPM_HUBIF_NB_RDATA2_AX_RDATA_MASK) >> MPM_HUBIF_NB_RDATA2_AX_RDATA_SHIFT)

#define MPM_HUBIF_NB_RDATA2_SET_AX_RDATA(mpm_hubif_nb_rdata2_reg, ax_rdata) \
      mpm_hubif_nb_rdata2_reg = (mpm_hubif_nb_rdata2_reg & ~MPM_HUBIF_NB_RDATA2_AX_RDATA_MASK) | (ax_rdata << MPM_HUBIF_NB_RDATA2_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata2_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA2_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata2_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA2_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata2_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_rdata2_t f;
} mpm_hubif_nb_rdata2_u;


/*
 * MPM_HUBIF_NB_RDATA3 struct
 */

#define MPM_HUBIF_NB_RDATA3_REG_SIZE         32
#define MPM_HUBIF_NB_RDATA3_AX_RDATA_SIZE  32

#define MPM_HUBIF_NB_RDATA3_AX_RDATA_SHIFT  0

#define MPM_HUBIF_NB_RDATA3_AX_RDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_RDATA3_MASK \
      (MPM_HUBIF_NB_RDATA3_AX_RDATA_MASK)

#define MPM_HUBIF_NB_RDATA3_DEFAULT    0x00000000

#define MPM_HUBIF_NB_RDATA3_GET_AX_RDATA(mpm_hubif_nb_rdata3) \
      ((mpm_hubif_nb_rdata3 & MPM_HUBIF_NB_RDATA3_AX_RDATA_MASK) >> MPM_HUBIF_NB_RDATA3_AX_RDATA_SHIFT)

#define MPM_HUBIF_NB_RDATA3_SET_AX_RDATA(mpm_hubif_nb_rdata3_reg, ax_rdata) \
      mpm_hubif_nb_rdata3_reg = (mpm_hubif_nb_rdata3_reg & ~MPM_HUBIF_NB_RDATA3_AX_RDATA_MASK) | (ax_rdata << MPM_HUBIF_NB_RDATA3_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata3_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA3_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata3_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA3_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata3_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_rdata3_t f;
} mpm_hubif_nb_rdata3_u;


/*
 * MPM_HUBIF_NB_RDATA4 struct
 */

#define MPM_HUBIF_NB_RDATA4_REG_SIZE         32
#define MPM_HUBIF_NB_RDATA4_AX_RDATA_SIZE  32

#define MPM_HUBIF_NB_RDATA4_AX_RDATA_SHIFT  0

#define MPM_HUBIF_NB_RDATA4_AX_RDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_RDATA4_MASK \
      (MPM_HUBIF_NB_RDATA4_AX_RDATA_MASK)

#define MPM_HUBIF_NB_RDATA4_DEFAULT    0x00000000

#define MPM_HUBIF_NB_RDATA4_GET_AX_RDATA(mpm_hubif_nb_rdata4) \
      ((mpm_hubif_nb_rdata4 & MPM_HUBIF_NB_RDATA4_AX_RDATA_MASK) >> MPM_HUBIF_NB_RDATA4_AX_RDATA_SHIFT)

#define MPM_HUBIF_NB_RDATA4_SET_AX_RDATA(mpm_hubif_nb_rdata4_reg, ax_rdata) \
      mpm_hubif_nb_rdata4_reg = (mpm_hubif_nb_rdata4_reg & ~MPM_HUBIF_NB_RDATA4_AX_RDATA_MASK) | (ax_rdata << MPM_HUBIF_NB_RDATA4_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata4_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA4_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata4_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA4_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata4_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_rdata4_t f;
} mpm_hubif_nb_rdata4_u;


/*
 * MPM_HUBIF_NB_RDATA5 struct
 */

#define MPM_HUBIF_NB_RDATA5_REG_SIZE         32
#define MPM_HUBIF_NB_RDATA5_AX_RDATA_SIZE  32

#define MPM_HUBIF_NB_RDATA5_AX_RDATA_SHIFT  0

#define MPM_HUBIF_NB_RDATA5_AX_RDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_RDATA5_MASK \
      (MPM_HUBIF_NB_RDATA5_AX_RDATA_MASK)

#define MPM_HUBIF_NB_RDATA5_DEFAULT    0x00000000

#define MPM_HUBIF_NB_RDATA5_GET_AX_RDATA(mpm_hubif_nb_rdata5) \
      ((mpm_hubif_nb_rdata5 & MPM_HUBIF_NB_RDATA5_AX_RDATA_MASK) >> MPM_HUBIF_NB_RDATA5_AX_RDATA_SHIFT)

#define MPM_HUBIF_NB_RDATA5_SET_AX_RDATA(mpm_hubif_nb_rdata5_reg, ax_rdata) \
      mpm_hubif_nb_rdata5_reg = (mpm_hubif_nb_rdata5_reg & ~MPM_HUBIF_NB_RDATA5_AX_RDATA_MASK) | (ax_rdata << MPM_HUBIF_NB_RDATA5_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata5_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA5_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata5_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA5_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata5_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_rdata5_t f;
} mpm_hubif_nb_rdata5_u;


/*
 * MPM_HUBIF_NB_RDATA6 struct
 */

#define MPM_HUBIF_NB_RDATA6_REG_SIZE         32
#define MPM_HUBIF_NB_RDATA6_AX_RDATA_SIZE  32

#define MPM_HUBIF_NB_RDATA6_AX_RDATA_SHIFT  0

#define MPM_HUBIF_NB_RDATA6_AX_RDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_RDATA6_MASK \
      (MPM_HUBIF_NB_RDATA6_AX_RDATA_MASK)

#define MPM_HUBIF_NB_RDATA6_DEFAULT    0x00000000

#define MPM_HUBIF_NB_RDATA6_GET_AX_RDATA(mpm_hubif_nb_rdata6) \
      ((mpm_hubif_nb_rdata6 & MPM_HUBIF_NB_RDATA6_AX_RDATA_MASK) >> MPM_HUBIF_NB_RDATA6_AX_RDATA_SHIFT)

#define MPM_HUBIF_NB_RDATA6_SET_AX_RDATA(mpm_hubif_nb_rdata6_reg, ax_rdata) \
      mpm_hubif_nb_rdata6_reg = (mpm_hubif_nb_rdata6_reg & ~MPM_HUBIF_NB_RDATA6_AX_RDATA_MASK) | (ax_rdata << MPM_HUBIF_NB_RDATA6_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata6_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA6_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata6_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA6_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata6_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_rdata6_t f;
} mpm_hubif_nb_rdata6_u;


/*
 * MPM_HUBIF_NB_RDATA7 struct
 */

#define MPM_HUBIF_NB_RDATA7_REG_SIZE         32
#define MPM_HUBIF_NB_RDATA7_AX_RDATA_SIZE  32

#define MPM_HUBIF_NB_RDATA7_AX_RDATA_SHIFT  0

#define MPM_HUBIF_NB_RDATA7_AX_RDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_RDATA7_MASK \
      (MPM_HUBIF_NB_RDATA7_AX_RDATA_MASK)

#define MPM_HUBIF_NB_RDATA7_DEFAULT    0x00000000

#define MPM_HUBIF_NB_RDATA7_GET_AX_RDATA(mpm_hubif_nb_rdata7) \
      ((mpm_hubif_nb_rdata7 & MPM_HUBIF_NB_RDATA7_AX_RDATA_MASK) >> MPM_HUBIF_NB_RDATA7_AX_RDATA_SHIFT)

#define MPM_HUBIF_NB_RDATA7_SET_AX_RDATA(mpm_hubif_nb_rdata7_reg, ax_rdata) \
      mpm_hubif_nb_rdata7_reg = (mpm_hubif_nb_rdata7_reg & ~MPM_HUBIF_NB_RDATA7_AX_RDATA_MASK) | (ax_rdata << MPM_HUBIF_NB_RDATA7_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata7_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA7_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata7_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA7_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata7_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_rdata7_t f;
} mpm_hubif_nb_rdata7_u;


/*
 * MPM_HUBIF_NB_RDATA8 struct
 */

#define MPM_HUBIF_NB_RDATA8_REG_SIZE         32
#define MPM_HUBIF_NB_RDATA8_AX_RDATA_SIZE  32

#define MPM_HUBIF_NB_RDATA8_AX_RDATA_SHIFT  0

#define MPM_HUBIF_NB_RDATA8_AX_RDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_RDATA8_MASK \
      (MPM_HUBIF_NB_RDATA8_AX_RDATA_MASK)

#define MPM_HUBIF_NB_RDATA8_DEFAULT    0x00000000

#define MPM_HUBIF_NB_RDATA8_GET_AX_RDATA(mpm_hubif_nb_rdata8) \
      ((mpm_hubif_nb_rdata8 & MPM_HUBIF_NB_RDATA8_AX_RDATA_MASK) >> MPM_HUBIF_NB_RDATA8_AX_RDATA_SHIFT)

#define MPM_HUBIF_NB_RDATA8_SET_AX_RDATA(mpm_hubif_nb_rdata8_reg, ax_rdata) \
      mpm_hubif_nb_rdata8_reg = (mpm_hubif_nb_rdata8_reg & ~MPM_HUBIF_NB_RDATA8_AX_RDATA_MASK) | (ax_rdata << MPM_HUBIF_NB_RDATA8_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata8_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA8_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata8_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA8_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata8_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_rdata8_t f;
} mpm_hubif_nb_rdata8_u;


/*
 * MPM_HUBIF_NB_RDATA9 struct
 */

#define MPM_HUBIF_NB_RDATA9_REG_SIZE         32
#define MPM_HUBIF_NB_RDATA9_AX_RDATA_SIZE  32

#define MPM_HUBIF_NB_RDATA9_AX_RDATA_SHIFT  0

#define MPM_HUBIF_NB_RDATA9_AX_RDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_RDATA9_MASK \
      (MPM_HUBIF_NB_RDATA9_AX_RDATA_MASK)

#define MPM_HUBIF_NB_RDATA9_DEFAULT    0x00000000

#define MPM_HUBIF_NB_RDATA9_GET_AX_RDATA(mpm_hubif_nb_rdata9) \
      ((mpm_hubif_nb_rdata9 & MPM_HUBIF_NB_RDATA9_AX_RDATA_MASK) >> MPM_HUBIF_NB_RDATA9_AX_RDATA_SHIFT)

#define MPM_HUBIF_NB_RDATA9_SET_AX_RDATA(mpm_hubif_nb_rdata9_reg, ax_rdata) \
      mpm_hubif_nb_rdata9_reg = (mpm_hubif_nb_rdata9_reg & ~MPM_HUBIF_NB_RDATA9_AX_RDATA_MASK) | (ax_rdata << MPM_HUBIF_NB_RDATA9_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata9_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA9_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata9_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA9_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata9_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_rdata9_t f;
} mpm_hubif_nb_rdata9_u;


/*
 * MPM_HUBIF_NB_RDATA10 struct
 */

#define MPM_HUBIF_NB_RDATA10_REG_SIZE         32
#define MPM_HUBIF_NB_RDATA10_AX_RDATA_SIZE  32

#define MPM_HUBIF_NB_RDATA10_AX_RDATA_SHIFT  0

#define MPM_HUBIF_NB_RDATA10_AX_RDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_RDATA10_MASK \
      (MPM_HUBIF_NB_RDATA10_AX_RDATA_MASK)

#define MPM_HUBIF_NB_RDATA10_DEFAULT   0x00000000

#define MPM_HUBIF_NB_RDATA10_GET_AX_RDATA(mpm_hubif_nb_rdata10) \
      ((mpm_hubif_nb_rdata10 & MPM_HUBIF_NB_RDATA10_AX_RDATA_MASK) >> MPM_HUBIF_NB_RDATA10_AX_RDATA_SHIFT)

#define MPM_HUBIF_NB_RDATA10_SET_AX_RDATA(mpm_hubif_nb_rdata10_reg, ax_rdata) \
      mpm_hubif_nb_rdata10_reg = (mpm_hubif_nb_rdata10_reg & ~MPM_HUBIF_NB_RDATA10_AX_RDATA_MASK) | (ax_rdata << MPM_HUBIF_NB_RDATA10_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata10_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA10_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata10_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA10_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata10_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_rdata10_t f;
} mpm_hubif_nb_rdata10_u;


/*
 * MPM_HUBIF_NB_RDATA11 struct
 */

#define MPM_HUBIF_NB_RDATA11_REG_SIZE         32
#define MPM_HUBIF_NB_RDATA11_AX_RDATA_SIZE  32

#define MPM_HUBIF_NB_RDATA11_AX_RDATA_SHIFT  0

#define MPM_HUBIF_NB_RDATA11_AX_RDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_RDATA11_MASK \
      (MPM_HUBIF_NB_RDATA11_AX_RDATA_MASK)

#define MPM_HUBIF_NB_RDATA11_DEFAULT   0x00000000

#define MPM_HUBIF_NB_RDATA11_GET_AX_RDATA(mpm_hubif_nb_rdata11) \
      ((mpm_hubif_nb_rdata11 & MPM_HUBIF_NB_RDATA11_AX_RDATA_MASK) >> MPM_HUBIF_NB_RDATA11_AX_RDATA_SHIFT)

#define MPM_HUBIF_NB_RDATA11_SET_AX_RDATA(mpm_hubif_nb_rdata11_reg, ax_rdata) \
      mpm_hubif_nb_rdata11_reg = (mpm_hubif_nb_rdata11_reg & ~MPM_HUBIF_NB_RDATA11_AX_RDATA_MASK) | (ax_rdata << MPM_HUBIF_NB_RDATA11_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata11_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA11_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata11_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA11_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata11_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_rdata11_t f;
} mpm_hubif_nb_rdata11_u;


/*
 * MPM_HUBIF_NB_RDATA12 struct
 */

#define MPM_HUBIF_NB_RDATA12_REG_SIZE         32
#define MPM_HUBIF_NB_RDATA12_AX_RDATA_SIZE  32

#define MPM_HUBIF_NB_RDATA12_AX_RDATA_SHIFT  0

#define MPM_HUBIF_NB_RDATA12_AX_RDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_RDATA12_MASK \
      (MPM_HUBIF_NB_RDATA12_AX_RDATA_MASK)

#define MPM_HUBIF_NB_RDATA12_DEFAULT   0x00000000

#define MPM_HUBIF_NB_RDATA12_GET_AX_RDATA(mpm_hubif_nb_rdata12) \
      ((mpm_hubif_nb_rdata12 & MPM_HUBIF_NB_RDATA12_AX_RDATA_MASK) >> MPM_HUBIF_NB_RDATA12_AX_RDATA_SHIFT)

#define MPM_HUBIF_NB_RDATA12_SET_AX_RDATA(mpm_hubif_nb_rdata12_reg, ax_rdata) \
      mpm_hubif_nb_rdata12_reg = (mpm_hubif_nb_rdata12_reg & ~MPM_HUBIF_NB_RDATA12_AX_RDATA_MASK) | (ax_rdata << MPM_HUBIF_NB_RDATA12_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata12_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA12_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata12_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA12_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata12_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_rdata12_t f;
} mpm_hubif_nb_rdata12_u;


/*
 * MPM_HUBIF_NB_RDATA13 struct
 */

#define MPM_HUBIF_NB_RDATA13_REG_SIZE         32
#define MPM_HUBIF_NB_RDATA13_AX_RDATA_SIZE  32

#define MPM_HUBIF_NB_RDATA13_AX_RDATA_SHIFT  0

#define MPM_HUBIF_NB_RDATA13_AX_RDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_RDATA13_MASK \
      (MPM_HUBIF_NB_RDATA13_AX_RDATA_MASK)

#define MPM_HUBIF_NB_RDATA13_DEFAULT   0x00000000

#define MPM_HUBIF_NB_RDATA13_GET_AX_RDATA(mpm_hubif_nb_rdata13) \
      ((mpm_hubif_nb_rdata13 & MPM_HUBIF_NB_RDATA13_AX_RDATA_MASK) >> MPM_HUBIF_NB_RDATA13_AX_RDATA_SHIFT)

#define MPM_HUBIF_NB_RDATA13_SET_AX_RDATA(mpm_hubif_nb_rdata13_reg, ax_rdata) \
      mpm_hubif_nb_rdata13_reg = (mpm_hubif_nb_rdata13_reg & ~MPM_HUBIF_NB_RDATA13_AX_RDATA_MASK) | (ax_rdata << MPM_HUBIF_NB_RDATA13_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata13_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA13_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata13_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA13_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata13_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_rdata13_t f;
} mpm_hubif_nb_rdata13_u;


/*
 * MPM_HUBIF_NB_RDATA14 struct
 */

#define MPM_HUBIF_NB_RDATA14_REG_SIZE         32
#define MPM_HUBIF_NB_RDATA14_AX_RDATA_SIZE  32

#define MPM_HUBIF_NB_RDATA14_AX_RDATA_SHIFT  0

#define MPM_HUBIF_NB_RDATA14_AX_RDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_RDATA14_MASK \
      (MPM_HUBIF_NB_RDATA14_AX_RDATA_MASK)

#define MPM_HUBIF_NB_RDATA14_DEFAULT   0x00000000

#define MPM_HUBIF_NB_RDATA14_GET_AX_RDATA(mpm_hubif_nb_rdata14) \
      ((mpm_hubif_nb_rdata14 & MPM_HUBIF_NB_RDATA14_AX_RDATA_MASK) >> MPM_HUBIF_NB_RDATA14_AX_RDATA_SHIFT)

#define MPM_HUBIF_NB_RDATA14_SET_AX_RDATA(mpm_hubif_nb_rdata14_reg, ax_rdata) \
      mpm_hubif_nb_rdata14_reg = (mpm_hubif_nb_rdata14_reg & ~MPM_HUBIF_NB_RDATA14_AX_RDATA_MASK) | (ax_rdata << MPM_HUBIF_NB_RDATA14_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata14_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA14_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata14_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA14_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata14_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_rdata14_t f;
} mpm_hubif_nb_rdata14_u;


/*
 * MPM_HUBIF_NB_RDATA15 struct
 */

#define MPM_HUBIF_NB_RDATA15_REG_SIZE         32
#define MPM_HUBIF_NB_RDATA15_AX_RDATA_SIZE  32

#define MPM_HUBIF_NB_RDATA15_AX_RDATA_SHIFT  0

#define MPM_HUBIF_NB_RDATA15_AX_RDATA_MASK  0xffffffff

#define MPM_HUBIF_NB_RDATA15_MASK \
      (MPM_HUBIF_NB_RDATA15_AX_RDATA_MASK)

#define MPM_HUBIF_NB_RDATA15_DEFAULT   0x00000000

#define MPM_HUBIF_NB_RDATA15_GET_AX_RDATA(mpm_hubif_nb_rdata15) \
      ((mpm_hubif_nb_rdata15 & MPM_HUBIF_NB_RDATA15_AX_RDATA_MASK) >> MPM_HUBIF_NB_RDATA15_AX_RDATA_SHIFT)

#define MPM_HUBIF_NB_RDATA15_SET_AX_RDATA(mpm_hubif_nb_rdata15_reg, ax_rdata) \
      mpm_hubif_nb_rdata15_reg = (mpm_hubif_nb_rdata15_reg & ~MPM_HUBIF_NB_RDATA15_AX_RDATA_MASK) | (ax_rdata << MPM_HUBIF_NB_RDATA15_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata15_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA15_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_rdata15_t {
            unsigned int ax_rdata                       : MPM_HUBIF_NB_RDATA15_AX_RDATA_SIZE;
      } mpm_hubif_nb_rdata15_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_rdata15_t f;
} mpm_hubif_nb_rdata15_u;


/*
 * MPM_HUBIF_NB_AXI_RESP struct
 */

#define MPM_HUBIF_NB_AXI_RESP_REG_SIZE         32
#define MPM_HUBIF_NB_AXI_RESP_AXI_RESP_SIZE  32

#define MPM_HUBIF_NB_AXI_RESP_AXI_RESP_SHIFT  0

#define MPM_HUBIF_NB_AXI_RESP_AXI_RESP_MASK  0xffffffff

#define MPM_HUBIF_NB_AXI_RESP_MASK \
      (MPM_HUBIF_NB_AXI_RESP_AXI_RESP_MASK)

#define MPM_HUBIF_NB_AXI_RESP_DEFAULT  0xffffffff

#define MPM_HUBIF_NB_AXI_RESP_GET_AXI_RESP(mpm_hubif_nb_axi_resp) \
      ((mpm_hubif_nb_axi_resp & MPM_HUBIF_NB_AXI_RESP_AXI_RESP_MASK) >> MPM_HUBIF_NB_AXI_RESP_AXI_RESP_SHIFT)

#define MPM_HUBIF_NB_AXI_RESP_SET_AXI_RESP(mpm_hubif_nb_axi_resp_reg, axi_resp) \
      mpm_hubif_nb_axi_resp_reg = (mpm_hubif_nb_axi_resp_reg & ~MPM_HUBIF_NB_AXI_RESP_AXI_RESP_MASK) | (axi_resp << MPM_HUBIF_NB_AXI_RESP_AXI_RESP_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_axi_resp_t {
            unsigned int axi_resp                       : MPM_HUBIF_NB_AXI_RESP_AXI_RESP_SIZE;
      } mpm_hubif_nb_axi_resp_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_axi_resp_t {
            unsigned int axi_resp                       : MPM_HUBIF_NB_AXI_RESP_AXI_RESP_SIZE;
      } mpm_hubif_nb_axi_resp_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_axi_resp_t f;
} mpm_hubif_nb_axi_resp_u;


/*
 * MPM_HUBIF_NB_MISC_CTRL struct
 */

#define MPM_HUBIF_NB_MISC_CTRL_REG_SIZE         32
#define MPM_HUBIF_NB_MISC_CTRL_CLK_GATE_EN_SIZE  1
#define MPM_HUBIF_NB_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SIZE  1

#define MPM_HUBIF_NB_MISC_CTRL_CLK_GATE_EN_SHIFT  0
#define MPM_HUBIF_NB_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SHIFT  16

#define MPM_HUBIF_NB_MISC_CTRL_CLK_GATE_EN_MASK  0x00000001
#define MPM_HUBIF_NB_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK  0x00010000

#define MPM_HUBIF_NB_MISC_CTRL_MASK \
      (MPM_HUBIF_NB_MISC_CTRL_CLK_GATE_EN_MASK | \
      MPM_HUBIF_NB_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK)

#define MPM_HUBIF_NB_MISC_CTRL_DEFAULT 0x00010000

#define MPM_HUBIF_NB_MISC_CTRL_GET_CLK_GATE_EN(mpm_hubif_nb_misc_ctrl) \
      ((mpm_hubif_nb_misc_ctrl & MPM_HUBIF_NB_MISC_CTRL_CLK_GATE_EN_MASK) >> MPM_HUBIF_NB_MISC_CTRL_CLK_GATE_EN_SHIFT)
#define MPM_HUBIF_NB_MISC_CTRL_GET_ALLOW_NON_PRIV_REG_ACC(mpm_hubif_nb_misc_ctrl) \
      ((mpm_hubif_nb_misc_ctrl & MPM_HUBIF_NB_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK) >> MPM_HUBIF_NB_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SHIFT)

#define MPM_HUBIF_NB_MISC_CTRL_SET_CLK_GATE_EN(mpm_hubif_nb_misc_ctrl_reg, clk_gate_en) \
      mpm_hubif_nb_misc_ctrl_reg = (mpm_hubif_nb_misc_ctrl_reg & ~MPM_HUBIF_NB_MISC_CTRL_CLK_GATE_EN_MASK) | (clk_gate_en << MPM_HUBIF_NB_MISC_CTRL_CLK_GATE_EN_SHIFT)
#define MPM_HUBIF_NB_MISC_CTRL_SET_ALLOW_NON_PRIV_REG_ACC(mpm_hubif_nb_misc_ctrl_reg, allow_non_priv_reg_acc) \
      mpm_hubif_nb_misc_ctrl_reg = (mpm_hubif_nb_misc_ctrl_reg & ~MPM_HUBIF_NB_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK) | (allow_non_priv_reg_acc << MPM_HUBIF_NB_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_misc_ctrl_t {
            unsigned int clk_gate_en                    : MPM_HUBIF_NB_MISC_CTRL_CLK_GATE_EN_SIZE;
            unsigned int                                : 15;
            unsigned int allow_non_priv_reg_acc         : MPM_HUBIF_NB_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SIZE;
            unsigned int                                : 15;
      } mpm_hubif_nb_misc_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_misc_ctrl_t {
            unsigned int                                : 15;
            unsigned int allow_non_priv_reg_acc         : MPM_HUBIF_NB_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SIZE;
            unsigned int                                : 15;
            unsigned int clk_gate_en                    : MPM_HUBIF_NB_MISC_CTRL_CLK_GATE_EN_SIZE;
      } mpm_hubif_nb_misc_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_misc_ctrl_t f;
} mpm_hubif_nb_misc_ctrl_u;


/*
 * MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS struct
 */

#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_REG_SIZE         32
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE  1
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE  2
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE  1
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_ID_SIZE  21
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SIZE  3

#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT  0
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT  1
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT  3
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_ID_SHIFT  8
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SHIFT  29

#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK  0x00000001
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK  0x00000006
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK  0x00000008
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK  0x1fffff00
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_APROT_MASK  0xe0000000

#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_MASK \
      (MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK | \
      MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK | \
      MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK | \
      MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK | \
      MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_APROT_MASK)

#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_DEFAULT 0x00000000

#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_DETECTED(mpm_hubif_nb_acc_violation_log_status) \
      ((mpm_hubif_nb_acc_violation_log_status & MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) >> MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_TYPE(mpm_hubif_nb_acc_violation_log_status) \
      ((mpm_hubif_nb_acc_violation_log_status & MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) >> MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_LOG_CLEAR(mpm_hubif_nb_acc_violation_log_status) \
      ((mpm_hubif_nb_acc_violation_log_status & MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) >> MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_GET_AXI_ID(mpm_hubif_nb_acc_violation_log_status) \
      ((mpm_hubif_nb_acc_violation_log_status & MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK) >> MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_ID_SHIFT)
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_GET_AXI_APROT(mpm_hubif_nb_acc_violation_log_status) \
      ((mpm_hubif_nb_acc_violation_log_status & MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_APROT_MASK) >> MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SHIFT)

#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_DETECTED(mpm_hubif_nb_acc_violation_log_status_reg, acc_violation_detected) \
      mpm_hubif_nb_acc_violation_log_status_reg = (mpm_hubif_nb_acc_violation_log_status_reg & ~MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) | (acc_violation_detected << MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_TYPE(mpm_hubif_nb_acc_violation_log_status_reg, acc_violation_type) \
      mpm_hubif_nb_acc_violation_log_status_reg = (mpm_hubif_nb_acc_violation_log_status_reg & ~MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) | (acc_violation_type << MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_LOG_CLEAR(mpm_hubif_nb_acc_violation_log_status_reg, acc_violation_log_clear) \
      mpm_hubif_nb_acc_violation_log_status_reg = (mpm_hubif_nb_acc_violation_log_status_reg & ~MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) | (acc_violation_log_clear << MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_SET_AXI_ID(mpm_hubif_nb_acc_violation_log_status_reg, axi_id) \
      mpm_hubif_nb_acc_violation_log_status_reg = (mpm_hubif_nb_acc_violation_log_status_reg & ~MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK) | (axi_id << MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_ID_SHIFT)
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_SET_AXI_APROT(mpm_hubif_nb_acc_violation_log_status_reg, axi_aprot) \
      mpm_hubif_nb_acc_violation_log_status_reg = (mpm_hubif_nb_acc_violation_log_status_reg & ~MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_APROT_MASK) | (axi_aprot << MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_acc_violation_log_status_t {
            unsigned int acc_violation_detected         : MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
            unsigned int acc_violation_type             : MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
            unsigned int acc_violation_log_clear        : MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
            unsigned int                                : 4;
            unsigned int axi_id                         : MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_ID_SIZE;
            unsigned int axi_aprot                      : MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SIZE;
      } mpm_hubif_nb_acc_violation_log_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_acc_violation_log_status_t {
            unsigned int axi_aprot                      : MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SIZE;
            unsigned int axi_id                         : MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_ID_SIZE;
            unsigned int                                : 4;
            unsigned int acc_violation_log_clear        : MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
            unsigned int acc_violation_type             : MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
            unsigned int acc_violation_detected         : MPM_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
      } mpm_hubif_nb_acc_violation_log_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_acc_violation_log_status_t f;
} mpm_hubif_nb_acc_violation_log_status_u;


/*
 * MPM_HUBIF_NB_ACC_VIOLATION_LOG_ADDR struct
 */

#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_REG_SIZE         32
#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SIZE  32

#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SHIFT  0

#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK  0xffffffff

#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_MASK \
      (MPM_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK)

#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_DEFAULT 0x00000000

#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_GET_AXI_ADDR(mpm_hubif_nb_acc_violation_log_addr) \
      ((mpm_hubif_nb_acc_violation_log_addr & MPM_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK) >> MPM_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SHIFT)

#define MPM_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_SET_AXI_ADDR(mpm_hubif_nb_acc_violation_log_addr_reg, axi_addr) \
      mpm_hubif_nb_acc_violation_log_addr_reg = (mpm_hubif_nb_acc_violation_log_addr_reg & ~MPM_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK) | (axi_addr << MPM_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_acc_violation_log_addr_t {
            unsigned int axi_addr                       : MPM_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SIZE;
      } mpm_hubif_nb_acc_violation_log_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_acc_violation_log_addr_t {
            unsigned int axi_addr                       : MPM_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SIZE;
      } mpm_hubif_nb_acc_violation_log_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_acc_violation_log_addr_t f;
} mpm_hubif_nb_acc_violation_log_addr_u;


/*
 * MPM_HUBIF_NB_OBFF_EMUL struct
 */

#define MPM_HUBIF_NB_OBFF_EMUL_REG_SIZE         32
#define MPM_HUBIF_NB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SIZE  1

#define MPM_HUBIF_NB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SHIFT  1

#define MPM_HUBIF_NB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_MASK  0x00000002

#define MPM_HUBIF_NB_OBFF_EMUL_MASK \
      (MPM_HUBIF_NB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_MASK)

#define MPM_HUBIF_NB_OBFF_EMUL_DEFAULT 0x00000000

#define MPM_HUBIF_NB_OBFF_EMUL_GET_IP_SYSHUB_URGENT_DMA(mpm_hubif_nb_obff_emul) \
      ((mpm_hubif_nb_obff_emul & MPM_HUBIF_NB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_MASK) >> MPM_HUBIF_NB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SHIFT)

#define MPM_HUBIF_NB_OBFF_EMUL_SET_IP_SYSHUB_URGENT_DMA(mpm_hubif_nb_obff_emul_reg, ip_syshub_urgent_dma) \
      mpm_hubif_nb_obff_emul_reg = (mpm_hubif_nb_obff_emul_reg & ~MPM_HUBIF_NB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_MASK) | (ip_syshub_urgent_dma << MPM_HUBIF_NB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_obff_emul_t {
            unsigned int                                : 1;
            unsigned int ip_syshub_urgent_dma           : MPM_HUBIF_NB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SIZE;
            unsigned int                                : 30;
      } mpm_hubif_nb_obff_emul_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_obff_emul_t {
            unsigned int                                : 30;
            unsigned int ip_syshub_urgent_dma           : MPM_HUBIF_NB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SIZE;
            unsigned int                                : 1;
      } mpm_hubif_nb_obff_emul_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_obff_emul_t f;
} mpm_hubif_nb_obff_emul_u;


/*
 * MPM_HUBIF_NB_BYPASS struct
 */

#define MPM_HUBIF_NB_BYPASS_REG_SIZE         32
#define MPM_HUBIF_NB_BYPASS_BYPASS_MASK_SIZE  1
#define MPM_HUBIF_NB_BYPASS_BYPASS_VALUE_SIZE  1

#define MPM_HUBIF_NB_BYPASS_BYPASS_MASK_SHIFT  0
#define MPM_HUBIF_NB_BYPASS_BYPASS_VALUE_SHIFT  1

#define MPM_HUBIF_NB_BYPASS_BYPASS_MASK_MASK  0x00000001
#define MPM_HUBIF_NB_BYPASS_BYPASS_VALUE_MASK  0x00000002

#define MPM_HUBIF_NB_BYPASS_MASK \
      (MPM_HUBIF_NB_BYPASS_BYPASS_MASK_MASK | \
      MPM_HUBIF_NB_BYPASS_BYPASS_VALUE_MASK)

#define MPM_HUBIF_NB_BYPASS_DEFAULT    0x00000001

#define MPM_HUBIF_NB_BYPASS_GET_BYPASS_MASK(mpm_hubif_nb_bypass) \
      ((mpm_hubif_nb_bypass & MPM_HUBIF_NB_BYPASS_BYPASS_MASK_MASK) >> MPM_HUBIF_NB_BYPASS_BYPASS_MASK_SHIFT)
#define MPM_HUBIF_NB_BYPASS_GET_BYPASS_VALUE(mpm_hubif_nb_bypass) \
      ((mpm_hubif_nb_bypass & MPM_HUBIF_NB_BYPASS_BYPASS_VALUE_MASK) >> MPM_HUBIF_NB_BYPASS_BYPASS_VALUE_SHIFT)

#define MPM_HUBIF_NB_BYPASS_SET_BYPASS_MASK(mpm_hubif_nb_bypass_reg, bypass_mask) \
      mpm_hubif_nb_bypass_reg = (mpm_hubif_nb_bypass_reg & ~MPM_HUBIF_NB_BYPASS_BYPASS_MASK_MASK) | (bypass_mask << MPM_HUBIF_NB_BYPASS_BYPASS_MASK_SHIFT)
#define MPM_HUBIF_NB_BYPASS_SET_BYPASS_VALUE(mpm_hubif_nb_bypass_reg, bypass_value) \
      mpm_hubif_nb_bypass_reg = (mpm_hubif_nb_bypass_reg & ~MPM_HUBIF_NB_BYPASS_BYPASS_VALUE_MASK) | (bypass_value << MPM_HUBIF_NB_BYPASS_BYPASS_VALUE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_bypass_t {
            unsigned int bypass_mask                    : MPM_HUBIF_NB_BYPASS_BYPASS_MASK_SIZE;
            unsigned int bypass_value                   : MPM_HUBIF_NB_BYPASS_BYPASS_VALUE_SIZE;
            unsigned int                                : 30;
      } mpm_hubif_nb_bypass_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_bypass_t {
            unsigned int                                : 30;
            unsigned int bypass_value                   : MPM_HUBIF_NB_BYPASS_BYPASS_VALUE_SIZE;
            unsigned int bypass_mask                    : MPM_HUBIF_NB_BYPASS_BYPASS_MASK_SIZE;
      } mpm_hubif_nb_bypass_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_bypass_t f;
} mpm_hubif_nb_bypass_u;


/*
 * MPM_HUBIF_NB_REQIO struct
 */

#define MPM_HUBIF_NB_REQIO_REG_SIZE         32
#define MPM_HUBIF_NB_REQIO_REQIO_MASK_SIZE  1
#define MPM_HUBIF_NB_REQIO_REQIO_VALUE_SIZE  1

#define MPM_HUBIF_NB_REQIO_REQIO_MASK_SHIFT  0
#define MPM_HUBIF_NB_REQIO_REQIO_VALUE_SHIFT  1

#define MPM_HUBIF_NB_REQIO_REQIO_MASK_MASK  0x00000001
#define MPM_HUBIF_NB_REQIO_REQIO_VALUE_MASK  0x00000002

#define MPM_HUBIF_NB_REQIO_MASK \
      (MPM_HUBIF_NB_REQIO_REQIO_MASK_MASK | \
      MPM_HUBIF_NB_REQIO_REQIO_VALUE_MASK)

#define MPM_HUBIF_NB_REQIO_DEFAULT     0x00000003

#define MPM_HUBIF_NB_REQIO_GET_REQIO_MASK(mpm_hubif_nb_reqio) \
      ((mpm_hubif_nb_reqio & MPM_HUBIF_NB_REQIO_REQIO_MASK_MASK) >> MPM_HUBIF_NB_REQIO_REQIO_MASK_SHIFT)
#define MPM_HUBIF_NB_REQIO_GET_REQIO_VALUE(mpm_hubif_nb_reqio) \
      ((mpm_hubif_nb_reqio & MPM_HUBIF_NB_REQIO_REQIO_VALUE_MASK) >> MPM_HUBIF_NB_REQIO_REQIO_VALUE_SHIFT)

#define MPM_HUBIF_NB_REQIO_SET_REQIO_MASK(mpm_hubif_nb_reqio_reg, reqio_mask) \
      mpm_hubif_nb_reqio_reg = (mpm_hubif_nb_reqio_reg & ~MPM_HUBIF_NB_REQIO_REQIO_MASK_MASK) | (reqio_mask << MPM_HUBIF_NB_REQIO_REQIO_MASK_SHIFT)
#define MPM_HUBIF_NB_REQIO_SET_REQIO_VALUE(mpm_hubif_nb_reqio_reg, reqio_value) \
      mpm_hubif_nb_reqio_reg = (mpm_hubif_nb_reqio_reg & ~MPM_HUBIF_NB_REQIO_REQIO_VALUE_MASK) | (reqio_value << MPM_HUBIF_NB_REQIO_REQIO_VALUE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_hubif_nb_reqio_t {
            unsigned int reqio_mask                     : MPM_HUBIF_NB_REQIO_REQIO_MASK_SIZE;
            unsigned int reqio_value                    : MPM_HUBIF_NB_REQIO_REQIO_VALUE_SIZE;
            unsigned int                                : 30;
      } mpm_hubif_nb_reqio_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_hubif_nb_reqio_t {
            unsigned int                                : 30;
            unsigned int reqio_value                    : MPM_HUBIF_NB_REQIO_REQIO_VALUE_SIZE;
            unsigned int reqio_mask                     : MPM_HUBIF_NB_REQIO_REQIO_MASK_SIZE;
      } mpm_hubif_nb_reqio_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_hubif_nb_reqio_t f;
} mpm_hubif_nb_reqio_u;


#endif

