// Copyright (c) 1994 - 2021 Advanced Micro Devices, Inc. All rights reserved. 
 #if !defined (_MP0_ROM_FIDDLE_H)
#define _MP0_ROM_FIDDLE_H
 /*****************************************************************************************************************
 *
 *  mp0_rom_reg.h
 *
 *  Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif

 /*******************************************************
 * Values
 *******************************************************/

 /*******************************************************
 * Structures
 *******************************************************/

/*
 * MP0_ROM_ACC_VIOLATION_LOG_ADDR struct
 */

#define MP0_ROM_ACC_VIOLATION_LOG_ADDR_REG_SIZE         32
#define MP0_ROM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SIZE  32

#define MP0_ROM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SHIFT  0

#define MP0_ROM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK  0xffffffff

#define MP0_ROM_ACC_VIOLATION_LOG_ADDR_MASK \
      (MP0_ROM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK)

#define MP0_ROM_ACC_VIOLATION_LOG_ADDR_DEFAULT 0x00000000

#define MP0_ROM_ACC_VIOLATION_LOG_ADDR_GET_ADDRESS(mp0_rom_acc_violation_log_addr) \
      ((mp0_rom_acc_violation_log_addr & MP0_ROM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK) >> MP0_ROM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SHIFT)

#define MP0_ROM_ACC_VIOLATION_LOG_ADDR_SET_ADDRESS(mp0_rom_acc_violation_log_addr_reg, address) \
      mp0_rom_acc_violation_log_addr_reg = (mp0_rom_acc_violation_log_addr_reg & ~MP0_ROM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK) | (address << MP0_ROM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_rom_acc_violation_log_addr_t {
            unsigned int address                        : MP0_ROM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SIZE;
      } mp0_rom_acc_violation_log_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_rom_acc_violation_log_addr_t {
            unsigned int address                        : MP0_ROM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SIZE;
      } mp0_rom_acc_violation_log_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_rom_acc_violation_log_addr_t f;
} mp0_rom_acc_violation_log_addr_u;


/*
 * MP0_ROM_ACC_VIOLATION_LOG_STATUS struct
 */

#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_REG_SIZE         32
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE  1
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_BLOCK_SIZE  2
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE  2
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PROT_SIZE  3
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNIT_ID_SIZE  7
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_INIT_ID_SIZE  10
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ROM_WRITE_DETECTED_SIZE  1
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_UNSECURE_ROM_ACC_DETECTED_SIZE  1
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE  1

#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT  0
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_BLOCK_SHIFT  1
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT  3
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PROT_SHIFT  5
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNIT_ID_SHIFT  8
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_INIT_ID_SHIFT  15
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ROM_WRITE_DETECTED_SHIFT  25
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_UNSECURE_ROM_ACC_DETECTED_SHIFT  26
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT  31

#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK  0x00000001
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_BLOCK_MASK  0x00000006
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK  0x00000018
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PROT_MASK  0x000000e0
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNIT_ID_MASK  0x00007f00
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_INIT_ID_MASK  0x01ff8000
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ROM_WRITE_DETECTED_MASK  0x02000000
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_UNSECURE_ROM_ACC_DETECTED_MASK  0x04000000
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK  0x80000000

#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_MASK \
      (MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK | \
      MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_BLOCK_MASK | \
      MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK | \
      MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PROT_MASK | \
      MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNIT_ID_MASK | \
      MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_INIT_ID_MASK | \
      MP0_ROM_ACC_VIOLATION_LOG_STATUS_ROM_WRITE_DETECTED_MASK | \
      MP0_ROM_ACC_VIOLATION_LOG_STATUS_UNSECURE_ROM_ACC_DETECTED_MASK | \
      MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK)

#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_DEFAULT 0x00000000

#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_DETECTED(mp0_rom_acc_violation_log_status) \
      ((mp0_rom_acc_violation_log_status & MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) >> MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_BLOCK(mp0_rom_acc_violation_log_status) \
      ((mp0_rom_acc_violation_log_status & MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_BLOCK_MASK) >> MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_BLOCK_SHIFT)
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_TYPE(mp0_rom_acc_violation_log_status) \
      ((mp0_rom_acc_violation_log_status & MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) >> MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_PROT(mp0_rom_acc_violation_log_status) \
      ((mp0_rom_acc_violation_log_status & MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PROT_MASK) >> MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PROT_SHIFT)
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_UNIT_ID(mp0_rom_acc_violation_log_status) \
      ((mp0_rom_acc_violation_log_status & MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNIT_ID_MASK) >> MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNIT_ID_SHIFT)
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_INIT_ID(mp0_rom_acc_violation_log_status) \
      ((mp0_rom_acc_violation_log_status & MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_INIT_ID_MASK) >> MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_INIT_ID_SHIFT)
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_GET_ROM_WRITE_DETECTED(mp0_rom_acc_violation_log_status) \
      ((mp0_rom_acc_violation_log_status & MP0_ROM_ACC_VIOLATION_LOG_STATUS_ROM_WRITE_DETECTED_MASK) >> MP0_ROM_ACC_VIOLATION_LOG_STATUS_ROM_WRITE_DETECTED_SHIFT)
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_GET_UNSECURE_ROM_ACC_DETECTED(mp0_rom_acc_violation_log_status) \
      ((mp0_rom_acc_violation_log_status & MP0_ROM_ACC_VIOLATION_LOG_STATUS_UNSECURE_ROM_ACC_DETECTED_MASK) >> MP0_ROM_ACC_VIOLATION_LOG_STATUS_UNSECURE_ROM_ACC_DETECTED_SHIFT)
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_LOG_CLEAR(mp0_rom_acc_violation_log_status) \
      ((mp0_rom_acc_violation_log_status & MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) >> MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)

#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_DETECTED(mp0_rom_acc_violation_log_status_reg, acc_violation_detected) \
      mp0_rom_acc_violation_log_status_reg = (mp0_rom_acc_violation_log_status_reg & ~MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) | (acc_violation_detected << MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_BLOCK(mp0_rom_acc_violation_log_status_reg, acc_violation_block) \
      mp0_rom_acc_violation_log_status_reg = (mp0_rom_acc_violation_log_status_reg & ~MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_BLOCK_MASK) | (acc_violation_block << MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_BLOCK_SHIFT)
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_TYPE(mp0_rom_acc_violation_log_status_reg, acc_violation_type) \
      mp0_rom_acc_violation_log_status_reg = (mp0_rom_acc_violation_log_status_reg & ~MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) | (acc_violation_type << MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_PROT(mp0_rom_acc_violation_log_status_reg, acc_violation_prot) \
      mp0_rom_acc_violation_log_status_reg = (mp0_rom_acc_violation_log_status_reg & ~MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PROT_MASK) | (acc_violation_prot << MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PROT_SHIFT)
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_UNIT_ID(mp0_rom_acc_violation_log_status_reg, acc_violation_unit_id) \
      mp0_rom_acc_violation_log_status_reg = (mp0_rom_acc_violation_log_status_reg & ~MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNIT_ID_MASK) | (acc_violation_unit_id << MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNIT_ID_SHIFT)
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_INIT_ID(mp0_rom_acc_violation_log_status_reg, acc_violation_init_id) \
      mp0_rom_acc_violation_log_status_reg = (mp0_rom_acc_violation_log_status_reg & ~MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_INIT_ID_MASK) | (acc_violation_init_id << MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_INIT_ID_SHIFT)
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_SET_ROM_WRITE_DETECTED(mp0_rom_acc_violation_log_status_reg, rom_write_detected) \
      mp0_rom_acc_violation_log_status_reg = (mp0_rom_acc_violation_log_status_reg & ~MP0_ROM_ACC_VIOLATION_LOG_STATUS_ROM_WRITE_DETECTED_MASK) | (rom_write_detected << MP0_ROM_ACC_VIOLATION_LOG_STATUS_ROM_WRITE_DETECTED_SHIFT)
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_SET_UNSECURE_ROM_ACC_DETECTED(mp0_rom_acc_violation_log_status_reg, unsecure_rom_acc_detected) \
      mp0_rom_acc_violation_log_status_reg = (mp0_rom_acc_violation_log_status_reg & ~MP0_ROM_ACC_VIOLATION_LOG_STATUS_UNSECURE_ROM_ACC_DETECTED_MASK) | (unsecure_rom_acc_detected << MP0_ROM_ACC_VIOLATION_LOG_STATUS_UNSECURE_ROM_ACC_DETECTED_SHIFT)
#define MP0_ROM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_LOG_CLEAR(mp0_rom_acc_violation_log_status_reg, acc_violation_log_clear) \
      mp0_rom_acc_violation_log_status_reg = (mp0_rom_acc_violation_log_status_reg & ~MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) | (acc_violation_log_clear << MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_rom_acc_violation_log_status_t {
            unsigned int acc_violation_detected         : MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
            unsigned int acc_violation_block            : MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_BLOCK_SIZE;
            unsigned int acc_violation_type             : MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
            unsigned int acc_violation_prot             : MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PROT_SIZE;
            unsigned int acc_violation_unit_id          : MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNIT_ID_SIZE;
            unsigned int acc_violation_init_id          : MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_INIT_ID_SIZE;
            unsigned int rom_write_detected             : MP0_ROM_ACC_VIOLATION_LOG_STATUS_ROM_WRITE_DETECTED_SIZE;
            unsigned int unsecure_rom_acc_detected      : MP0_ROM_ACC_VIOLATION_LOG_STATUS_UNSECURE_ROM_ACC_DETECTED_SIZE;
            unsigned int                                : 4;
            unsigned int acc_violation_log_clear        : MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
      } mp0_rom_acc_violation_log_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_rom_acc_violation_log_status_t {
            unsigned int acc_violation_log_clear        : MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
            unsigned int                                : 4;
            unsigned int unsecure_rom_acc_detected      : MP0_ROM_ACC_VIOLATION_LOG_STATUS_UNSECURE_ROM_ACC_DETECTED_SIZE;
            unsigned int rom_write_detected             : MP0_ROM_ACC_VIOLATION_LOG_STATUS_ROM_WRITE_DETECTED_SIZE;
            unsigned int acc_violation_init_id          : MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_INIT_ID_SIZE;
            unsigned int acc_violation_unit_id          : MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNIT_ID_SIZE;
            unsigned int acc_violation_prot             : MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PROT_SIZE;
            unsigned int acc_violation_type             : MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
            unsigned int acc_violation_block            : MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_BLOCK_SIZE;
            unsigned int acc_violation_detected         : MP0_ROM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
      } mp0_rom_acc_violation_log_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_rom_acc_violation_log_status_t f;
} mp0_rom_acc_violation_log_status_u;


/*
 * MP0_ROM_MISC_CNTL struct
 */

#define MP0_ROM_MISC_CNTL_REG_SIZE         32
#define MP0_ROM_MISC_CNTL_DISABLE_ROM_SIZE  1
#define MP0_ROM_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SIZE  1
#define MP0_ROM_MISC_CNTL_ALLOW_UNPRIVILIGED_ROM_ACC_SIZE  1
#define MP0_ROM_MISC_CNTL_RETURN_ERR_ON_VIOLATED_READ_SIZE  1
#define MP0_ROM_MISC_CNTL_HIDE_ROM_KEY_SIZE  1
#define MP0_ROM_MISC_CNTL_CLK_GATE_EN_SIZE  1
#define MP0_ROM_MISC_CNTL_CLK_GATE_OVERRIDE_SIZE  1
#define MP0_ROM_MISC_CNTL_CLK_GATE_TIMEOUT_SIZE  4
#define MP0_ROM_MISC_CNTL_REGCLK_STATUS_SIZE  1
#define MP0_ROM_MISC_CNTL_SYSCLK_STATUS_SIZE  1
#define MP0_ROM_MISC_CNTL_ROM_SD_SIZE  1
#define MP0_ROM_MISC_CNTL_ROM_ROP_SIZE  1
#define MP0_ROM_MISC_CNTL_IGNORE_ROP_SD_SIZE  1
#define MP0_ROM_MISC_CNTL_ROMBIST_DISABLE_SIZE  1

#define MP0_ROM_MISC_CNTL_DISABLE_ROM_SHIFT  0
#define MP0_ROM_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SHIFT  1
#define MP0_ROM_MISC_CNTL_ALLOW_UNPRIVILIGED_ROM_ACC_SHIFT  2
#define MP0_ROM_MISC_CNTL_RETURN_ERR_ON_VIOLATED_READ_SHIFT  3
#define MP0_ROM_MISC_CNTL_HIDE_ROM_KEY_SHIFT  4
#define MP0_ROM_MISC_CNTL_CLK_GATE_EN_SHIFT  16
#define MP0_ROM_MISC_CNTL_CLK_GATE_OVERRIDE_SHIFT  17
#define MP0_ROM_MISC_CNTL_CLK_GATE_TIMEOUT_SHIFT  18
#define MP0_ROM_MISC_CNTL_REGCLK_STATUS_SHIFT  22
#define MP0_ROM_MISC_CNTL_SYSCLK_STATUS_SHIFT  23
#define MP0_ROM_MISC_CNTL_ROM_SD_SHIFT  24
#define MP0_ROM_MISC_CNTL_ROM_ROP_SHIFT  25
#define MP0_ROM_MISC_CNTL_IGNORE_ROP_SD_SHIFT  26
#define MP0_ROM_MISC_CNTL_ROMBIST_DISABLE_SHIFT  30

#define MP0_ROM_MISC_CNTL_DISABLE_ROM_MASK  0x00000001
#define MP0_ROM_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_MASK  0x00000002
#define MP0_ROM_MISC_CNTL_ALLOW_UNPRIVILIGED_ROM_ACC_MASK  0x00000004
#define MP0_ROM_MISC_CNTL_RETURN_ERR_ON_VIOLATED_READ_MASK  0x00000008
#define MP0_ROM_MISC_CNTL_HIDE_ROM_KEY_MASK  0x00000010
#define MP0_ROM_MISC_CNTL_CLK_GATE_EN_MASK  0x00010000
#define MP0_ROM_MISC_CNTL_CLK_GATE_OVERRIDE_MASK  0x00020000
#define MP0_ROM_MISC_CNTL_CLK_GATE_TIMEOUT_MASK  0x003c0000
#define MP0_ROM_MISC_CNTL_REGCLK_STATUS_MASK  0x00400000
#define MP0_ROM_MISC_CNTL_SYSCLK_STATUS_MASK  0x00800000
#define MP0_ROM_MISC_CNTL_ROM_SD_MASK   0x01000000
#define MP0_ROM_MISC_CNTL_ROM_ROP_MASK  0x02000000
#define MP0_ROM_MISC_CNTL_IGNORE_ROP_SD_MASK  0x04000000
#define MP0_ROM_MISC_CNTL_ROMBIST_DISABLE_MASK  0x40000000

#define MP0_ROM_MISC_CNTL_MASK \
      (MP0_ROM_MISC_CNTL_DISABLE_ROM_MASK | \
      MP0_ROM_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_MASK | \
      MP0_ROM_MISC_CNTL_ALLOW_UNPRIVILIGED_ROM_ACC_MASK | \
      MP0_ROM_MISC_CNTL_RETURN_ERR_ON_VIOLATED_READ_MASK | \
      MP0_ROM_MISC_CNTL_HIDE_ROM_KEY_MASK | \
      MP0_ROM_MISC_CNTL_CLK_GATE_EN_MASK | \
      MP0_ROM_MISC_CNTL_CLK_GATE_OVERRIDE_MASK | \
      MP0_ROM_MISC_CNTL_CLK_GATE_TIMEOUT_MASK | \
      MP0_ROM_MISC_CNTL_REGCLK_STATUS_MASK | \
      MP0_ROM_MISC_CNTL_SYSCLK_STATUS_MASK | \
      MP0_ROM_MISC_CNTL_ROM_SD_MASK | \
      MP0_ROM_MISC_CNTL_ROM_ROP_MASK | \
      MP0_ROM_MISC_CNTL_IGNORE_ROP_SD_MASK | \
      MP0_ROM_MISC_CNTL_ROMBIST_DISABLE_MASK)

#define MP0_ROM_MISC_CNTL_DEFAULT      0x02e0000e

#define MP0_ROM_MISC_CNTL_GET_DISABLE_ROM(mp0_rom_misc_cntl) \
      ((mp0_rom_misc_cntl & MP0_ROM_MISC_CNTL_DISABLE_ROM_MASK) >> MP0_ROM_MISC_CNTL_DISABLE_ROM_SHIFT)
#define MP0_ROM_MISC_CNTL_GET_ALLOW_UNPRIVILIGED_REG_ACC(mp0_rom_misc_cntl) \
      ((mp0_rom_misc_cntl & MP0_ROM_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_MASK) >> MP0_ROM_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SHIFT)
#define MP0_ROM_MISC_CNTL_GET_ALLOW_UNPRIVILIGED_ROM_ACC(mp0_rom_misc_cntl) \
      ((mp0_rom_misc_cntl & MP0_ROM_MISC_CNTL_ALLOW_UNPRIVILIGED_ROM_ACC_MASK) >> MP0_ROM_MISC_CNTL_ALLOW_UNPRIVILIGED_ROM_ACC_SHIFT)
#define MP0_ROM_MISC_CNTL_GET_RETURN_ERR_ON_VIOLATED_READ(mp0_rom_misc_cntl) \
      ((mp0_rom_misc_cntl & MP0_ROM_MISC_CNTL_RETURN_ERR_ON_VIOLATED_READ_MASK) >> MP0_ROM_MISC_CNTL_RETURN_ERR_ON_VIOLATED_READ_SHIFT)
#define MP0_ROM_MISC_CNTL_GET_HIDE_ROM_KEY(mp0_rom_misc_cntl) \
      ((mp0_rom_misc_cntl & MP0_ROM_MISC_CNTL_HIDE_ROM_KEY_MASK) >> MP0_ROM_MISC_CNTL_HIDE_ROM_KEY_SHIFT)
#define MP0_ROM_MISC_CNTL_GET_CLK_GATE_EN(mp0_rom_misc_cntl) \
      ((mp0_rom_misc_cntl & MP0_ROM_MISC_CNTL_CLK_GATE_EN_MASK) >> MP0_ROM_MISC_CNTL_CLK_GATE_EN_SHIFT)
#define MP0_ROM_MISC_CNTL_GET_CLK_GATE_OVERRIDE(mp0_rom_misc_cntl) \
      ((mp0_rom_misc_cntl & MP0_ROM_MISC_CNTL_CLK_GATE_OVERRIDE_MASK) >> MP0_ROM_MISC_CNTL_CLK_GATE_OVERRIDE_SHIFT)
#define MP0_ROM_MISC_CNTL_GET_CLK_GATE_TIMEOUT(mp0_rom_misc_cntl) \
      ((mp0_rom_misc_cntl & MP0_ROM_MISC_CNTL_CLK_GATE_TIMEOUT_MASK) >> MP0_ROM_MISC_CNTL_CLK_GATE_TIMEOUT_SHIFT)
#define MP0_ROM_MISC_CNTL_GET_REGCLK_STATUS(mp0_rom_misc_cntl) \
      ((mp0_rom_misc_cntl & MP0_ROM_MISC_CNTL_REGCLK_STATUS_MASK) >> MP0_ROM_MISC_CNTL_REGCLK_STATUS_SHIFT)
#define MP0_ROM_MISC_CNTL_GET_SYSCLK_STATUS(mp0_rom_misc_cntl) \
      ((mp0_rom_misc_cntl & MP0_ROM_MISC_CNTL_SYSCLK_STATUS_MASK) >> MP0_ROM_MISC_CNTL_SYSCLK_STATUS_SHIFT)
#define MP0_ROM_MISC_CNTL_GET_ROM_SD(mp0_rom_misc_cntl) \
      ((mp0_rom_misc_cntl & MP0_ROM_MISC_CNTL_ROM_SD_MASK) >> MP0_ROM_MISC_CNTL_ROM_SD_SHIFT)
#define MP0_ROM_MISC_CNTL_GET_ROM_ROP(mp0_rom_misc_cntl) \
      ((mp0_rom_misc_cntl & MP0_ROM_MISC_CNTL_ROM_ROP_MASK) >> MP0_ROM_MISC_CNTL_ROM_ROP_SHIFT)
#define MP0_ROM_MISC_CNTL_GET_IGNORE_ROP_SD(mp0_rom_misc_cntl) \
      ((mp0_rom_misc_cntl & MP0_ROM_MISC_CNTL_IGNORE_ROP_SD_MASK) >> MP0_ROM_MISC_CNTL_IGNORE_ROP_SD_SHIFT)
#define MP0_ROM_MISC_CNTL_GET_ROMBIST_DISABLE(mp0_rom_misc_cntl) \
      ((mp0_rom_misc_cntl & MP0_ROM_MISC_CNTL_ROMBIST_DISABLE_MASK) >> MP0_ROM_MISC_CNTL_ROMBIST_DISABLE_SHIFT)

#define MP0_ROM_MISC_CNTL_SET_DISABLE_ROM(mp0_rom_misc_cntl_reg, disable_rom) \
      mp0_rom_misc_cntl_reg = (mp0_rom_misc_cntl_reg & ~MP0_ROM_MISC_CNTL_DISABLE_ROM_MASK) | (disable_rom << MP0_ROM_MISC_CNTL_DISABLE_ROM_SHIFT)
#define MP0_ROM_MISC_CNTL_SET_ALLOW_UNPRIVILIGED_REG_ACC(mp0_rom_misc_cntl_reg, allow_unpriviliged_reg_acc) \
      mp0_rom_misc_cntl_reg = (mp0_rom_misc_cntl_reg & ~MP0_ROM_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_MASK) | (allow_unpriviliged_reg_acc << MP0_ROM_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SHIFT)
#define MP0_ROM_MISC_CNTL_SET_ALLOW_UNPRIVILIGED_ROM_ACC(mp0_rom_misc_cntl_reg, allow_unpriviliged_rom_acc) \
      mp0_rom_misc_cntl_reg = (mp0_rom_misc_cntl_reg & ~MP0_ROM_MISC_CNTL_ALLOW_UNPRIVILIGED_ROM_ACC_MASK) | (allow_unpriviliged_rom_acc << MP0_ROM_MISC_CNTL_ALLOW_UNPRIVILIGED_ROM_ACC_SHIFT)
#define MP0_ROM_MISC_CNTL_SET_RETURN_ERR_ON_VIOLATED_READ(mp0_rom_misc_cntl_reg, return_err_on_violated_read) \
      mp0_rom_misc_cntl_reg = (mp0_rom_misc_cntl_reg & ~MP0_ROM_MISC_CNTL_RETURN_ERR_ON_VIOLATED_READ_MASK) | (return_err_on_violated_read << MP0_ROM_MISC_CNTL_RETURN_ERR_ON_VIOLATED_READ_SHIFT)
#define MP0_ROM_MISC_CNTL_SET_HIDE_ROM_KEY(mp0_rom_misc_cntl_reg, hide_rom_key) \
      mp0_rom_misc_cntl_reg = (mp0_rom_misc_cntl_reg & ~MP0_ROM_MISC_CNTL_HIDE_ROM_KEY_MASK) | (hide_rom_key << MP0_ROM_MISC_CNTL_HIDE_ROM_KEY_SHIFT)
#define MP0_ROM_MISC_CNTL_SET_CLK_GATE_EN(mp0_rom_misc_cntl_reg, clk_gate_en) \
      mp0_rom_misc_cntl_reg = (mp0_rom_misc_cntl_reg & ~MP0_ROM_MISC_CNTL_CLK_GATE_EN_MASK) | (clk_gate_en << MP0_ROM_MISC_CNTL_CLK_GATE_EN_SHIFT)
#define MP0_ROM_MISC_CNTL_SET_CLK_GATE_OVERRIDE(mp0_rom_misc_cntl_reg, clk_gate_override) \
      mp0_rom_misc_cntl_reg = (mp0_rom_misc_cntl_reg & ~MP0_ROM_MISC_CNTL_CLK_GATE_OVERRIDE_MASK) | (clk_gate_override << MP0_ROM_MISC_CNTL_CLK_GATE_OVERRIDE_SHIFT)
#define MP0_ROM_MISC_CNTL_SET_CLK_GATE_TIMEOUT(mp0_rom_misc_cntl_reg, clk_gate_timeout) \
      mp0_rom_misc_cntl_reg = (mp0_rom_misc_cntl_reg & ~MP0_ROM_MISC_CNTL_CLK_GATE_TIMEOUT_MASK) | (clk_gate_timeout << MP0_ROM_MISC_CNTL_CLK_GATE_TIMEOUT_SHIFT)
#define MP0_ROM_MISC_CNTL_SET_REGCLK_STATUS(mp0_rom_misc_cntl_reg, regclk_status) \
      mp0_rom_misc_cntl_reg = (mp0_rom_misc_cntl_reg & ~MP0_ROM_MISC_CNTL_REGCLK_STATUS_MASK) | (regclk_status << MP0_ROM_MISC_CNTL_REGCLK_STATUS_SHIFT)
#define MP0_ROM_MISC_CNTL_SET_SYSCLK_STATUS(mp0_rom_misc_cntl_reg, sysclk_status) \
      mp0_rom_misc_cntl_reg = (mp0_rom_misc_cntl_reg & ~MP0_ROM_MISC_CNTL_SYSCLK_STATUS_MASK) | (sysclk_status << MP0_ROM_MISC_CNTL_SYSCLK_STATUS_SHIFT)
#define MP0_ROM_MISC_CNTL_SET_ROM_SD(mp0_rom_misc_cntl_reg, rom_sd) \
      mp0_rom_misc_cntl_reg = (mp0_rom_misc_cntl_reg & ~MP0_ROM_MISC_CNTL_ROM_SD_MASK) | (rom_sd << MP0_ROM_MISC_CNTL_ROM_SD_SHIFT)
#define MP0_ROM_MISC_CNTL_SET_ROM_ROP(mp0_rom_misc_cntl_reg, rom_rop) \
      mp0_rom_misc_cntl_reg = (mp0_rom_misc_cntl_reg & ~MP0_ROM_MISC_CNTL_ROM_ROP_MASK) | (rom_rop << MP0_ROM_MISC_CNTL_ROM_ROP_SHIFT)
#define MP0_ROM_MISC_CNTL_SET_IGNORE_ROP_SD(mp0_rom_misc_cntl_reg, ignore_rop_sd) \
      mp0_rom_misc_cntl_reg = (mp0_rom_misc_cntl_reg & ~MP0_ROM_MISC_CNTL_IGNORE_ROP_SD_MASK) | (ignore_rop_sd << MP0_ROM_MISC_CNTL_IGNORE_ROP_SD_SHIFT)
#define MP0_ROM_MISC_CNTL_SET_ROMBIST_DISABLE(mp0_rom_misc_cntl_reg, rombist_disable) \
      mp0_rom_misc_cntl_reg = (mp0_rom_misc_cntl_reg & ~MP0_ROM_MISC_CNTL_ROMBIST_DISABLE_MASK) | (rombist_disable << MP0_ROM_MISC_CNTL_ROMBIST_DISABLE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_rom_misc_cntl_t {
            unsigned int disable_rom                    : MP0_ROM_MISC_CNTL_DISABLE_ROM_SIZE;
            unsigned int allow_unpriviliged_reg_acc     : MP0_ROM_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SIZE;
            unsigned int allow_unpriviliged_rom_acc     : MP0_ROM_MISC_CNTL_ALLOW_UNPRIVILIGED_ROM_ACC_SIZE;
            unsigned int return_err_on_violated_read    : MP0_ROM_MISC_CNTL_RETURN_ERR_ON_VIOLATED_READ_SIZE;
            unsigned int hide_rom_key                   : MP0_ROM_MISC_CNTL_HIDE_ROM_KEY_SIZE;
            unsigned int                                : 11;
            unsigned int clk_gate_en                    : MP0_ROM_MISC_CNTL_CLK_GATE_EN_SIZE;
            unsigned int clk_gate_override              : MP0_ROM_MISC_CNTL_CLK_GATE_OVERRIDE_SIZE;
            unsigned int clk_gate_timeout               : MP0_ROM_MISC_CNTL_CLK_GATE_TIMEOUT_SIZE;
            unsigned int regclk_status                  : MP0_ROM_MISC_CNTL_REGCLK_STATUS_SIZE;
            unsigned int sysclk_status                  : MP0_ROM_MISC_CNTL_SYSCLK_STATUS_SIZE;
            unsigned int rom_sd                         : MP0_ROM_MISC_CNTL_ROM_SD_SIZE;
            unsigned int rom_rop                        : MP0_ROM_MISC_CNTL_ROM_ROP_SIZE;
            unsigned int ignore_rop_sd                  : MP0_ROM_MISC_CNTL_IGNORE_ROP_SD_SIZE;
            unsigned int                                : 3;
            unsigned int rombist_disable                : MP0_ROM_MISC_CNTL_ROMBIST_DISABLE_SIZE;
            unsigned int                                : 1;
      } mp0_rom_misc_cntl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_rom_misc_cntl_t {
            unsigned int                                : 1;
            unsigned int rombist_disable                : MP0_ROM_MISC_CNTL_ROMBIST_DISABLE_SIZE;
            unsigned int                                : 3;
            unsigned int ignore_rop_sd                  : MP0_ROM_MISC_CNTL_IGNORE_ROP_SD_SIZE;
            unsigned int rom_rop                        : MP0_ROM_MISC_CNTL_ROM_ROP_SIZE;
            unsigned int rom_sd                         : MP0_ROM_MISC_CNTL_ROM_SD_SIZE;
            unsigned int sysclk_status                  : MP0_ROM_MISC_CNTL_SYSCLK_STATUS_SIZE;
            unsigned int regclk_status                  : MP0_ROM_MISC_CNTL_REGCLK_STATUS_SIZE;
            unsigned int clk_gate_timeout               : MP0_ROM_MISC_CNTL_CLK_GATE_TIMEOUT_SIZE;
            unsigned int clk_gate_override              : MP0_ROM_MISC_CNTL_CLK_GATE_OVERRIDE_SIZE;
            unsigned int clk_gate_en                    : MP0_ROM_MISC_CNTL_CLK_GATE_EN_SIZE;
            unsigned int                                : 11;
            unsigned int hide_rom_key                   : MP0_ROM_MISC_CNTL_HIDE_ROM_KEY_SIZE;
            unsigned int return_err_on_violated_read    : MP0_ROM_MISC_CNTL_RETURN_ERR_ON_VIOLATED_READ_SIZE;
            unsigned int allow_unpriviliged_rom_acc     : MP0_ROM_MISC_CNTL_ALLOW_UNPRIVILIGED_ROM_ACC_SIZE;
            unsigned int allow_unpriviliged_reg_acc     : MP0_ROM_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SIZE;
            unsigned int disable_rom                    : MP0_ROM_MISC_CNTL_DISABLE_ROM_SIZE;
      } mp0_rom_misc_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_rom_misc_cntl_t f;
} mp0_rom_misc_cntl_u;


/*
 * MP0_ROM_BOOTCODE_CNTL struct
 */

#define MP0_ROM_BOOTCODE_CNTL_REG_SIZE         32
#define MP0_ROM_BOOTCODE_CNTL_ALLOW_DAP_ENABLEMENT_SIZE  1

#define MP0_ROM_BOOTCODE_CNTL_ALLOW_DAP_ENABLEMENT_SHIFT  0

#define MP0_ROM_BOOTCODE_CNTL_ALLOW_DAP_ENABLEMENT_MASK  0x00000001

#define MP0_ROM_BOOTCODE_CNTL_MASK \
      (MP0_ROM_BOOTCODE_CNTL_ALLOW_DAP_ENABLEMENT_MASK)

#define MP0_ROM_BOOTCODE_CNTL_DEFAULT  0x00000000

#define MP0_ROM_BOOTCODE_CNTL_GET_ALLOW_DAP_ENABLEMENT(mp0_rom_bootcode_cntl) \
      ((mp0_rom_bootcode_cntl & MP0_ROM_BOOTCODE_CNTL_ALLOW_DAP_ENABLEMENT_MASK) >> MP0_ROM_BOOTCODE_CNTL_ALLOW_DAP_ENABLEMENT_SHIFT)

#define MP0_ROM_BOOTCODE_CNTL_SET_ALLOW_DAP_ENABLEMENT(mp0_rom_bootcode_cntl_reg, allow_dap_enablement) \
      mp0_rom_bootcode_cntl_reg = (mp0_rom_bootcode_cntl_reg & ~MP0_ROM_BOOTCODE_CNTL_ALLOW_DAP_ENABLEMENT_MASK) | (allow_dap_enablement << MP0_ROM_BOOTCODE_CNTL_ALLOW_DAP_ENABLEMENT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_rom_bootcode_cntl_t {
            unsigned int allow_dap_enablement           : MP0_ROM_BOOTCODE_CNTL_ALLOW_DAP_ENABLEMENT_SIZE;
            unsigned int                                : 31;
      } mp0_rom_bootcode_cntl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_rom_bootcode_cntl_t {
            unsigned int                                : 31;
            unsigned int allow_dap_enablement           : MP0_ROM_BOOTCODE_CNTL_ALLOW_DAP_ENABLEMENT_SIZE;
      } mp0_rom_bootcode_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_rom_bootcode_cntl_t f;
} mp0_rom_bootcode_cntl_u;


/*
 * MP0_ROM_SCRATCH_0 struct
 */

#define MP0_ROM_SCRATCH_0_REG_SIZE         32
#define MP0_ROM_SCRATCH_0_RESERVED_SIZE  32

#define MP0_ROM_SCRATCH_0_RESERVED_SHIFT  0

#define MP0_ROM_SCRATCH_0_RESERVED_MASK  0xffffffff

#define MP0_ROM_SCRATCH_0_MASK \
      (MP0_ROM_SCRATCH_0_RESERVED_MASK)

#define MP0_ROM_SCRATCH_0_DEFAULT      0x00000000

#define MP0_ROM_SCRATCH_0_GET_RESERVED(mp0_rom_scratch_0) \
      ((mp0_rom_scratch_0 & MP0_ROM_SCRATCH_0_RESERVED_MASK) >> MP0_ROM_SCRATCH_0_RESERVED_SHIFT)

#define MP0_ROM_SCRATCH_0_SET_RESERVED(mp0_rom_scratch_0_reg, reserved) \
      mp0_rom_scratch_0_reg = (mp0_rom_scratch_0_reg & ~MP0_ROM_SCRATCH_0_RESERVED_MASK) | (reserved << MP0_ROM_SCRATCH_0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_rom_scratch_0_t {
            unsigned int reserved                       : MP0_ROM_SCRATCH_0_RESERVED_SIZE;
      } mp0_rom_scratch_0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_rom_scratch_0_t {
            unsigned int reserved                       : MP0_ROM_SCRATCH_0_RESERVED_SIZE;
      } mp0_rom_scratch_0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_rom_scratch_0_t f;
} mp0_rom_scratch_0_u;


/*
 * MP0_ROM_SCRATCH_1 struct
 */

#define MP0_ROM_SCRATCH_1_REG_SIZE         32
#define MP0_ROM_SCRATCH_1_RESERVED_SIZE  32

#define MP0_ROM_SCRATCH_1_RESERVED_SHIFT  0

#define MP0_ROM_SCRATCH_1_RESERVED_MASK  0xffffffff

#define MP0_ROM_SCRATCH_1_MASK \
      (MP0_ROM_SCRATCH_1_RESERVED_MASK)

#define MP0_ROM_SCRATCH_1_DEFAULT      0x00000000

#define MP0_ROM_SCRATCH_1_GET_RESERVED(mp0_rom_scratch_1) \
      ((mp0_rom_scratch_1 & MP0_ROM_SCRATCH_1_RESERVED_MASK) >> MP0_ROM_SCRATCH_1_RESERVED_SHIFT)

#define MP0_ROM_SCRATCH_1_SET_RESERVED(mp0_rom_scratch_1_reg, reserved) \
      mp0_rom_scratch_1_reg = (mp0_rom_scratch_1_reg & ~MP0_ROM_SCRATCH_1_RESERVED_MASK) | (reserved << MP0_ROM_SCRATCH_1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_rom_scratch_1_t {
            unsigned int reserved                       : MP0_ROM_SCRATCH_1_RESERVED_SIZE;
      } mp0_rom_scratch_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_rom_scratch_1_t {
            unsigned int reserved                       : MP0_ROM_SCRATCH_1_RESERVED_SIZE;
      } mp0_rom_scratch_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_rom_scratch_1_t f;
} mp0_rom_scratch_1_u;


/*
 * MP0_ROM_SCRATCH_2 struct
 */

#define MP0_ROM_SCRATCH_2_REG_SIZE         32
#define MP0_ROM_SCRATCH_2_RESERVED_SIZE  32

#define MP0_ROM_SCRATCH_2_RESERVED_SHIFT  0

#define MP0_ROM_SCRATCH_2_RESERVED_MASK  0xffffffff

#define MP0_ROM_SCRATCH_2_MASK \
      (MP0_ROM_SCRATCH_2_RESERVED_MASK)

#define MP0_ROM_SCRATCH_2_DEFAULT      0x00000000

#define MP0_ROM_SCRATCH_2_GET_RESERVED(mp0_rom_scratch_2) \
      ((mp0_rom_scratch_2 & MP0_ROM_SCRATCH_2_RESERVED_MASK) >> MP0_ROM_SCRATCH_2_RESERVED_SHIFT)

#define MP0_ROM_SCRATCH_2_SET_RESERVED(mp0_rom_scratch_2_reg, reserved) \
      mp0_rom_scratch_2_reg = (mp0_rom_scratch_2_reg & ~MP0_ROM_SCRATCH_2_RESERVED_MASK) | (reserved << MP0_ROM_SCRATCH_2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_rom_scratch_2_t {
            unsigned int reserved                       : MP0_ROM_SCRATCH_2_RESERVED_SIZE;
      } mp0_rom_scratch_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_rom_scratch_2_t {
            unsigned int reserved                       : MP0_ROM_SCRATCH_2_RESERVED_SIZE;
      } mp0_rom_scratch_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_rom_scratch_2_t f;
} mp0_rom_scratch_2_u;


/*
 * MP0_ROM_SCRATCH_3 struct
 */

#define MP0_ROM_SCRATCH_3_REG_SIZE         32
#define MP0_ROM_SCRATCH_3_RESERVED_SIZE  32

#define MP0_ROM_SCRATCH_3_RESERVED_SHIFT  0

#define MP0_ROM_SCRATCH_3_RESERVED_MASK  0xffffffff

#define MP0_ROM_SCRATCH_3_MASK \
      (MP0_ROM_SCRATCH_3_RESERVED_MASK)

#define MP0_ROM_SCRATCH_3_DEFAULT      0x00000000

#define MP0_ROM_SCRATCH_3_GET_RESERVED(mp0_rom_scratch_3) \
      ((mp0_rom_scratch_3 & MP0_ROM_SCRATCH_3_RESERVED_MASK) >> MP0_ROM_SCRATCH_3_RESERVED_SHIFT)

#define MP0_ROM_SCRATCH_3_SET_RESERVED(mp0_rom_scratch_3_reg, reserved) \
      mp0_rom_scratch_3_reg = (mp0_rom_scratch_3_reg & ~MP0_ROM_SCRATCH_3_RESERVED_MASK) | (reserved << MP0_ROM_SCRATCH_3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_rom_scratch_3_t {
            unsigned int reserved                       : MP0_ROM_SCRATCH_3_RESERVED_SIZE;
      } mp0_rom_scratch_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_rom_scratch_3_t {
            unsigned int reserved                       : MP0_ROM_SCRATCH_3_RESERVED_SIZE;
      } mp0_rom_scratch_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_rom_scratch_3_t f;
} mp0_rom_scratch_3_u;


/*
 * MP0_ROM_SCRATCH_4 struct
 */

#define MP0_ROM_SCRATCH_4_REG_SIZE         32
#define MP0_ROM_SCRATCH_4_RESERVED_SIZE  32

#define MP0_ROM_SCRATCH_4_RESERVED_SHIFT  0

#define MP0_ROM_SCRATCH_4_RESERVED_MASK  0xffffffff

#define MP0_ROM_SCRATCH_4_MASK \
      (MP0_ROM_SCRATCH_4_RESERVED_MASK)

#define MP0_ROM_SCRATCH_4_DEFAULT      0x00000000

#define MP0_ROM_SCRATCH_4_GET_RESERVED(mp0_rom_scratch_4) \
      ((mp0_rom_scratch_4 & MP0_ROM_SCRATCH_4_RESERVED_MASK) >> MP0_ROM_SCRATCH_4_RESERVED_SHIFT)

#define MP0_ROM_SCRATCH_4_SET_RESERVED(mp0_rom_scratch_4_reg, reserved) \
      mp0_rom_scratch_4_reg = (mp0_rom_scratch_4_reg & ~MP0_ROM_SCRATCH_4_RESERVED_MASK) | (reserved << MP0_ROM_SCRATCH_4_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_rom_scratch_4_t {
            unsigned int reserved                       : MP0_ROM_SCRATCH_4_RESERVED_SIZE;
      } mp0_rom_scratch_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_rom_scratch_4_t {
            unsigned int reserved                       : MP0_ROM_SCRATCH_4_RESERVED_SIZE;
      } mp0_rom_scratch_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_rom_scratch_4_t f;
} mp0_rom_scratch_4_u;


/*
 * MP0_ROM_SCRATCH_5 struct
 */

#define MP0_ROM_SCRATCH_5_REG_SIZE         32
#define MP0_ROM_SCRATCH_5_RESERVED_SIZE  32

#define MP0_ROM_SCRATCH_5_RESERVED_SHIFT  0

#define MP0_ROM_SCRATCH_5_RESERVED_MASK  0xffffffff

#define MP0_ROM_SCRATCH_5_MASK \
      (MP0_ROM_SCRATCH_5_RESERVED_MASK)

#define MP0_ROM_SCRATCH_5_DEFAULT      0x00000000

#define MP0_ROM_SCRATCH_5_GET_RESERVED(mp0_rom_scratch_5) \
      ((mp0_rom_scratch_5 & MP0_ROM_SCRATCH_5_RESERVED_MASK) >> MP0_ROM_SCRATCH_5_RESERVED_SHIFT)

#define MP0_ROM_SCRATCH_5_SET_RESERVED(mp0_rom_scratch_5_reg, reserved) \
      mp0_rom_scratch_5_reg = (mp0_rom_scratch_5_reg & ~MP0_ROM_SCRATCH_5_RESERVED_MASK) | (reserved << MP0_ROM_SCRATCH_5_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_rom_scratch_5_t {
            unsigned int reserved                       : MP0_ROM_SCRATCH_5_RESERVED_SIZE;
      } mp0_rom_scratch_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_rom_scratch_5_t {
            unsigned int reserved                       : MP0_ROM_SCRATCH_5_RESERVED_SIZE;
      } mp0_rom_scratch_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_rom_scratch_5_t f;
} mp0_rom_scratch_5_u;


/*
 * MP0_ROM_SCRATCH_6 struct
 */

#define MP0_ROM_SCRATCH_6_REG_SIZE         32
#define MP0_ROM_SCRATCH_6_RESERVED_SIZE  32

#define MP0_ROM_SCRATCH_6_RESERVED_SHIFT  0

#define MP0_ROM_SCRATCH_6_RESERVED_MASK  0xffffffff

#define MP0_ROM_SCRATCH_6_MASK \
      (MP0_ROM_SCRATCH_6_RESERVED_MASK)

#define MP0_ROM_SCRATCH_6_DEFAULT      0x00000000

#define MP0_ROM_SCRATCH_6_GET_RESERVED(mp0_rom_scratch_6) \
      ((mp0_rom_scratch_6 & MP0_ROM_SCRATCH_6_RESERVED_MASK) >> MP0_ROM_SCRATCH_6_RESERVED_SHIFT)

#define MP0_ROM_SCRATCH_6_SET_RESERVED(mp0_rom_scratch_6_reg, reserved) \
      mp0_rom_scratch_6_reg = (mp0_rom_scratch_6_reg & ~MP0_ROM_SCRATCH_6_RESERVED_MASK) | (reserved << MP0_ROM_SCRATCH_6_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_rom_scratch_6_t {
            unsigned int reserved                       : MP0_ROM_SCRATCH_6_RESERVED_SIZE;
      } mp0_rom_scratch_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_rom_scratch_6_t {
            unsigned int reserved                       : MP0_ROM_SCRATCH_6_RESERVED_SIZE;
      } mp0_rom_scratch_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_rom_scratch_6_t f;
} mp0_rom_scratch_6_u;


/*
 * MP0_ROM_SCRATCH_7 struct
 */

#define MP0_ROM_SCRATCH_7_REG_SIZE         32
#define MP0_ROM_SCRATCH_7_RESERVED_SIZE  32

#define MP0_ROM_SCRATCH_7_RESERVED_SHIFT  0

#define MP0_ROM_SCRATCH_7_RESERVED_MASK  0xffffffff

#define MP0_ROM_SCRATCH_7_MASK \
      (MP0_ROM_SCRATCH_7_RESERVED_MASK)

#define MP0_ROM_SCRATCH_7_DEFAULT      0x00000000

#define MP0_ROM_SCRATCH_7_GET_RESERVED(mp0_rom_scratch_7) \
      ((mp0_rom_scratch_7 & MP0_ROM_SCRATCH_7_RESERVED_MASK) >> MP0_ROM_SCRATCH_7_RESERVED_SHIFT)

#define MP0_ROM_SCRATCH_7_SET_RESERVED(mp0_rom_scratch_7_reg, reserved) \
      mp0_rom_scratch_7_reg = (mp0_rom_scratch_7_reg & ~MP0_ROM_SCRATCH_7_RESERVED_MASK) | (reserved << MP0_ROM_SCRATCH_7_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_rom_scratch_7_t {
            unsigned int reserved                       : MP0_ROM_SCRATCH_7_RESERVED_SIZE;
      } mp0_rom_scratch_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_rom_scratch_7_t {
            unsigned int reserved                       : MP0_ROM_SCRATCH_7_RESERVED_SIZE;
      } mp0_rom_scratch_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_rom_scratch_7_t f;
} mp0_rom_scratch_7_u;


#endif

