// Copyright (c) 1994 - 2021 Advanced Micro Devices, Inc. All rights reserved. 
 #if !defined (_RSMU_MP0_FIDDLE_H)
#define _RSMU_MP0_FIDDLE_H
 /*****************************************************************************************************************
 *
 *  rsmu_mp0_reg.h
 *
 *  Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif

 /*******************************************************
 * Values
 *******************************************************/

 /*******************************************************
 * Structures
 *******************************************************/

/*
 * RSMU_MEM_POWER_CTRL_MP0 struct
 */

#define RSMU_MEM_POWER_CTRL_MP0_REG_SIZE         32
#define RSMU_MEM_POWER_CTRL_MP0_RSMU_FUSE_RM_FUSES_SIZE  12
#define RSMU_MEM_POWER_CTRL_MP0_RSMU_FUSE_CUSTOM_RM_FUSES_SIZE  14
#define RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_PDP_BC1_SIZE  1
#define RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_PDP_BC2_SIZE  1
#define RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_HD_BC1_SIZE  1
#define RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_HD_BC2_SIZE  1
#define RSMU_MEM_POWER_CTRL_MP0_RSMU_LIVMIN_DIS_SRAM_SIZE  1

#define RSMU_MEM_POWER_CTRL_MP0_RSMU_FUSE_RM_FUSES_SHIFT  0
#define RSMU_MEM_POWER_CTRL_MP0_RSMU_FUSE_CUSTOM_RM_FUSES_SHIFT  12
#define RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_PDP_BC1_SHIFT  26
#define RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_PDP_BC2_SHIFT  27
#define RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_HD_BC1_SHIFT  28
#define RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_HD_BC2_SHIFT  29
#define RSMU_MEM_POWER_CTRL_MP0_RSMU_LIVMIN_DIS_SRAM_SHIFT  30

#define RSMU_MEM_POWER_CTRL_MP0_RSMU_FUSE_RM_FUSES_MASK  0x00000fff
#define RSMU_MEM_POWER_CTRL_MP0_RSMU_FUSE_CUSTOM_RM_FUSES_MASK  0x03fff000
#define RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_PDP_BC1_MASK  0x04000000
#define RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_PDP_BC2_MASK  0x08000000
#define RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_HD_BC1_MASK  0x10000000
#define RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_HD_BC2_MASK  0x20000000
#define RSMU_MEM_POWER_CTRL_MP0_RSMU_LIVMIN_DIS_SRAM_MASK  0x40000000

#define RSMU_MEM_POWER_CTRL_MP0_MASK \
      (RSMU_MEM_POWER_CTRL_MP0_RSMU_FUSE_RM_FUSES_MASK | \
      RSMU_MEM_POWER_CTRL_MP0_RSMU_FUSE_CUSTOM_RM_FUSES_MASK | \
      RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_PDP_BC1_MASK | \
      RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_PDP_BC2_MASK | \
      RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_HD_BC1_MASK | \
      RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_HD_BC2_MASK | \
      RSMU_MEM_POWER_CTRL_MP0_RSMU_LIVMIN_DIS_SRAM_MASK)

#define RSMU_MEM_POWER_CTRL_MP0_DEFAULT 0x14000000

#define RSMU_MEM_POWER_CTRL_MP0_GET_RSMU_FUSE_RM_FUSES(rsmu_mem_power_ctrl_mp0) \
      ((rsmu_mem_power_ctrl_mp0 & RSMU_MEM_POWER_CTRL_MP0_RSMU_FUSE_RM_FUSES_MASK) >> RSMU_MEM_POWER_CTRL_MP0_RSMU_FUSE_RM_FUSES_SHIFT)
#define RSMU_MEM_POWER_CTRL_MP0_GET_RSMU_FUSE_CUSTOM_RM_FUSES(rsmu_mem_power_ctrl_mp0) \
      ((rsmu_mem_power_ctrl_mp0 & RSMU_MEM_POWER_CTRL_MP0_RSMU_FUSE_CUSTOM_RM_FUSES_MASK) >> RSMU_MEM_POWER_CTRL_MP0_RSMU_FUSE_CUSTOM_RM_FUSES_SHIFT)
#define RSMU_MEM_POWER_CTRL_MP0_GET_RSMU_MEM_POWER_CTRL_PDP_BC1(rsmu_mem_power_ctrl_mp0) \
      ((rsmu_mem_power_ctrl_mp0 & RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_PDP_BC1_MASK) >> RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_PDP_BC1_SHIFT)
#define RSMU_MEM_POWER_CTRL_MP0_GET_RSMU_MEM_POWER_CTRL_PDP_BC2(rsmu_mem_power_ctrl_mp0) \
      ((rsmu_mem_power_ctrl_mp0 & RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_PDP_BC2_MASK) >> RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_PDP_BC2_SHIFT)
#define RSMU_MEM_POWER_CTRL_MP0_GET_RSMU_MEM_POWER_CTRL_HD_BC1(rsmu_mem_power_ctrl_mp0) \
      ((rsmu_mem_power_ctrl_mp0 & RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_HD_BC1_MASK) >> RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_HD_BC1_SHIFT)
#define RSMU_MEM_POWER_CTRL_MP0_GET_RSMU_MEM_POWER_CTRL_HD_BC2(rsmu_mem_power_ctrl_mp0) \
      ((rsmu_mem_power_ctrl_mp0 & RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_HD_BC2_MASK) >> RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_HD_BC2_SHIFT)
#define RSMU_MEM_POWER_CTRL_MP0_GET_RSMU_LIVMIN_DIS_SRAM(rsmu_mem_power_ctrl_mp0) \
      ((rsmu_mem_power_ctrl_mp0 & RSMU_MEM_POWER_CTRL_MP0_RSMU_LIVMIN_DIS_SRAM_MASK) >> RSMU_MEM_POWER_CTRL_MP0_RSMU_LIVMIN_DIS_SRAM_SHIFT)

#define RSMU_MEM_POWER_CTRL_MP0_SET_RSMU_FUSE_RM_FUSES(rsmu_mem_power_ctrl_mp0_reg, rsmu_fuse_rm_fuses) \
      rsmu_mem_power_ctrl_mp0_reg = (rsmu_mem_power_ctrl_mp0_reg & ~RSMU_MEM_POWER_CTRL_MP0_RSMU_FUSE_RM_FUSES_MASK) | (rsmu_fuse_rm_fuses << RSMU_MEM_POWER_CTRL_MP0_RSMU_FUSE_RM_FUSES_SHIFT)
#define RSMU_MEM_POWER_CTRL_MP0_SET_RSMU_FUSE_CUSTOM_RM_FUSES(rsmu_mem_power_ctrl_mp0_reg, rsmu_fuse_custom_rm_fuses) \
      rsmu_mem_power_ctrl_mp0_reg = (rsmu_mem_power_ctrl_mp0_reg & ~RSMU_MEM_POWER_CTRL_MP0_RSMU_FUSE_CUSTOM_RM_FUSES_MASK) | (rsmu_fuse_custom_rm_fuses << RSMU_MEM_POWER_CTRL_MP0_RSMU_FUSE_CUSTOM_RM_FUSES_SHIFT)
#define RSMU_MEM_POWER_CTRL_MP0_SET_RSMU_MEM_POWER_CTRL_PDP_BC1(rsmu_mem_power_ctrl_mp0_reg, rsmu_mem_power_ctrl_pdp_bc1) \
      rsmu_mem_power_ctrl_mp0_reg = (rsmu_mem_power_ctrl_mp0_reg & ~RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_PDP_BC1_MASK) | (rsmu_mem_power_ctrl_pdp_bc1 << RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_PDP_BC1_SHIFT)
#define RSMU_MEM_POWER_CTRL_MP0_SET_RSMU_MEM_POWER_CTRL_PDP_BC2(rsmu_mem_power_ctrl_mp0_reg, rsmu_mem_power_ctrl_pdp_bc2) \
      rsmu_mem_power_ctrl_mp0_reg = (rsmu_mem_power_ctrl_mp0_reg & ~RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_PDP_BC2_MASK) | (rsmu_mem_power_ctrl_pdp_bc2 << RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_PDP_BC2_SHIFT)
#define RSMU_MEM_POWER_CTRL_MP0_SET_RSMU_MEM_POWER_CTRL_HD_BC1(rsmu_mem_power_ctrl_mp0_reg, rsmu_mem_power_ctrl_hd_bc1) \
      rsmu_mem_power_ctrl_mp0_reg = (rsmu_mem_power_ctrl_mp0_reg & ~RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_HD_BC1_MASK) | (rsmu_mem_power_ctrl_hd_bc1 << RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_HD_BC1_SHIFT)
#define RSMU_MEM_POWER_CTRL_MP0_SET_RSMU_MEM_POWER_CTRL_HD_BC2(rsmu_mem_power_ctrl_mp0_reg, rsmu_mem_power_ctrl_hd_bc2) \
      rsmu_mem_power_ctrl_mp0_reg = (rsmu_mem_power_ctrl_mp0_reg & ~RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_HD_BC2_MASK) | (rsmu_mem_power_ctrl_hd_bc2 << RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_HD_BC2_SHIFT)
#define RSMU_MEM_POWER_CTRL_MP0_SET_RSMU_LIVMIN_DIS_SRAM(rsmu_mem_power_ctrl_mp0_reg, rsmu_livmin_dis_sram) \
      rsmu_mem_power_ctrl_mp0_reg = (rsmu_mem_power_ctrl_mp0_reg & ~RSMU_MEM_POWER_CTRL_MP0_RSMU_LIVMIN_DIS_SRAM_MASK) | (rsmu_livmin_dis_sram << RSMU_MEM_POWER_CTRL_MP0_RSMU_LIVMIN_DIS_SRAM_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_mem_power_ctrl_mp0_t {
            unsigned int rsmu_fuse_rm_fuses             : RSMU_MEM_POWER_CTRL_MP0_RSMU_FUSE_RM_FUSES_SIZE;
            unsigned int rsmu_fuse_custom_rm_fuses      : RSMU_MEM_POWER_CTRL_MP0_RSMU_FUSE_CUSTOM_RM_FUSES_SIZE;
            unsigned int rsmu_mem_power_ctrl_pdp_bc1    : RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_PDP_BC1_SIZE;
            unsigned int rsmu_mem_power_ctrl_pdp_bc2    : RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_PDP_BC2_SIZE;
            unsigned int rsmu_mem_power_ctrl_hd_bc1     : RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_HD_BC1_SIZE;
            unsigned int rsmu_mem_power_ctrl_hd_bc2     : RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_HD_BC2_SIZE;
            unsigned int rsmu_livmin_dis_sram           : RSMU_MEM_POWER_CTRL_MP0_RSMU_LIVMIN_DIS_SRAM_SIZE;
            unsigned int                                : 1;
      } rsmu_mem_power_ctrl_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_mem_power_ctrl_mp0_t {
            unsigned int                                : 1;
            unsigned int rsmu_livmin_dis_sram           : RSMU_MEM_POWER_CTRL_MP0_RSMU_LIVMIN_DIS_SRAM_SIZE;
            unsigned int rsmu_mem_power_ctrl_hd_bc2     : RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_HD_BC2_SIZE;
            unsigned int rsmu_mem_power_ctrl_hd_bc1     : RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_HD_BC1_SIZE;
            unsigned int rsmu_mem_power_ctrl_pdp_bc2    : RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_PDP_BC2_SIZE;
            unsigned int rsmu_mem_power_ctrl_pdp_bc1    : RSMU_MEM_POWER_CTRL_MP0_RSMU_MEM_POWER_CTRL_PDP_BC1_SIZE;
            unsigned int rsmu_fuse_custom_rm_fuses      : RSMU_MEM_POWER_CTRL_MP0_RSMU_FUSE_CUSTOM_RM_FUSES_SIZE;
            unsigned int rsmu_fuse_rm_fuses             : RSMU_MEM_POWER_CTRL_MP0_RSMU_FUSE_RM_FUSES_SIZE;
      } rsmu_mem_power_ctrl_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_mem_power_ctrl_mp0_t f;
} rsmu_mem_power_ctrl_mp0_u;


/*
 * RSMU_SMS_FUSE_CFG_MP0 struct
 */

#define RSMU_SMS_FUSE_CFG_MP0_REG_SIZE         32
#define RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RESETB_SIZE  1
#define RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RUN_BIHR_SIZE  1
#define RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RUN_MBIST_SIZE  1
#define RSMU_SMS_FUSE_CFG_MP0_RSMU_FISO_RESET_SIZE  1
#define RSMU_SMS_FUSE_CFG_MP0_RSMU_FISO_SET_SIZE  1

#define RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RESETB_SHIFT  0
#define RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RUN_BIHR_SHIFT  1
#define RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RUN_MBIST_SHIFT  2
#define RSMU_SMS_FUSE_CFG_MP0_RSMU_FISO_RESET_SHIFT  3
#define RSMU_SMS_FUSE_CFG_MP0_RSMU_FISO_SET_SHIFT  4

#define RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RESETB_MASK  0x00000001
#define RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RUN_BIHR_MASK  0x00000002
#define RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RUN_MBIST_MASK  0x00000004
#define RSMU_SMS_FUSE_CFG_MP0_RSMU_FISO_RESET_MASK  0x00000008
#define RSMU_SMS_FUSE_CFG_MP0_RSMU_FISO_SET_MASK  0x00000010

#define RSMU_SMS_FUSE_CFG_MP0_MASK \
      (RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RESETB_MASK | \
      RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RUN_BIHR_MASK | \
      RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RUN_MBIST_MASK | \
      RSMU_SMS_FUSE_CFG_MP0_RSMU_FISO_RESET_MASK | \
      RSMU_SMS_FUSE_CFG_MP0_RSMU_FISO_SET_MASK)

#define RSMU_SMS_FUSE_CFG_MP0_DEFAULT  0x00000000

#define RSMU_SMS_FUSE_CFG_MP0_GET_RSMU_SMS_FUSE_RESETB(rsmu_sms_fuse_cfg_mp0) \
      ((rsmu_sms_fuse_cfg_mp0 & RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RESETB_MASK) >> RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RESETB_SHIFT)
#define RSMU_SMS_FUSE_CFG_MP0_GET_RSMU_SMS_FUSE_RUN_BIHR(rsmu_sms_fuse_cfg_mp0) \
      ((rsmu_sms_fuse_cfg_mp0 & RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RUN_BIHR_MASK) >> RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RUN_BIHR_SHIFT)
#define RSMU_SMS_FUSE_CFG_MP0_GET_RSMU_SMS_FUSE_RUN_MBIST(rsmu_sms_fuse_cfg_mp0) \
      ((rsmu_sms_fuse_cfg_mp0 & RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RUN_MBIST_MASK) >> RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RUN_MBIST_SHIFT)
#define RSMU_SMS_FUSE_CFG_MP0_GET_RSMU_FISO_RESET(rsmu_sms_fuse_cfg_mp0) \
      ((rsmu_sms_fuse_cfg_mp0 & RSMU_SMS_FUSE_CFG_MP0_RSMU_FISO_RESET_MASK) >> RSMU_SMS_FUSE_CFG_MP0_RSMU_FISO_RESET_SHIFT)
#define RSMU_SMS_FUSE_CFG_MP0_GET_RSMU_FISO_SET(rsmu_sms_fuse_cfg_mp0) \
      ((rsmu_sms_fuse_cfg_mp0 & RSMU_SMS_FUSE_CFG_MP0_RSMU_FISO_SET_MASK) >> RSMU_SMS_FUSE_CFG_MP0_RSMU_FISO_SET_SHIFT)

#define RSMU_SMS_FUSE_CFG_MP0_SET_RSMU_SMS_FUSE_RESETB(rsmu_sms_fuse_cfg_mp0_reg, rsmu_sms_fuse_resetb) \
      rsmu_sms_fuse_cfg_mp0_reg = (rsmu_sms_fuse_cfg_mp0_reg & ~RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RESETB_MASK) | (rsmu_sms_fuse_resetb << RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RESETB_SHIFT)
#define RSMU_SMS_FUSE_CFG_MP0_SET_RSMU_SMS_FUSE_RUN_BIHR(rsmu_sms_fuse_cfg_mp0_reg, rsmu_sms_fuse_run_bihr) \
      rsmu_sms_fuse_cfg_mp0_reg = (rsmu_sms_fuse_cfg_mp0_reg & ~RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RUN_BIHR_MASK) | (rsmu_sms_fuse_run_bihr << RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RUN_BIHR_SHIFT)
#define RSMU_SMS_FUSE_CFG_MP0_SET_RSMU_SMS_FUSE_RUN_MBIST(rsmu_sms_fuse_cfg_mp0_reg, rsmu_sms_fuse_run_mbist) \
      rsmu_sms_fuse_cfg_mp0_reg = (rsmu_sms_fuse_cfg_mp0_reg & ~RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RUN_MBIST_MASK) | (rsmu_sms_fuse_run_mbist << RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RUN_MBIST_SHIFT)
#define RSMU_SMS_FUSE_CFG_MP0_SET_RSMU_FISO_RESET(rsmu_sms_fuse_cfg_mp0_reg, rsmu_fiso_reset) \
      rsmu_sms_fuse_cfg_mp0_reg = (rsmu_sms_fuse_cfg_mp0_reg & ~RSMU_SMS_FUSE_CFG_MP0_RSMU_FISO_RESET_MASK) | (rsmu_fiso_reset << RSMU_SMS_FUSE_CFG_MP0_RSMU_FISO_RESET_SHIFT)
#define RSMU_SMS_FUSE_CFG_MP0_SET_RSMU_FISO_SET(rsmu_sms_fuse_cfg_mp0_reg, rsmu_fiso_set) \
      rsmu_sms_fuse_cfg_mp0_reg = (rsmu_sms_fuse_cfg_mp0_reg & ~RSMU_SMS_FUSE_CFG_MP0_RSMU_FISO_SET_MASK) | (rsmu_fiso_set << RSMU_SMS_FUSE_CFG_MP0_RSMU_FISO_SET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sms_fuse_cfg_mp0_t {
            unsigned int rsmu_sms_fuse_resetb           : RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RESETB_SIZE;
            unsigned int rsmu_sms_fuse_run_bihr         : RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RUN_BIHR_SIZE;
            unsigned int rsmu_sms_fuse_run_mbist        : RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RUN_MBIST_SIZE;
            unsigned int rsmu_fiso_reset                : RSMU_SMS_FUSE_CFG_MP0_RSMU_FISO_RESET_SIZE;
            unsigned int rsmu_fiso_set                  : RSMU_SMS_FUSE_CFG_MP0_RSMU_FISO_SET_SIZE;
            unsigned int                                : 27;
      } rsmu_sms_fuse_cfg_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sms_fuse_cfg_mp0_t {
            unsigned int                                : 27;
            unsigned int rsmu_fiso_set                  : RSMU_SMS_FUSE_CFG_MP0_RSMU_FISO_SET_SIZE;
            unsigned int rsmu_fiso_reset                : RSMU_SMS_FUSE_CFG_MP0_RSMU_FISO_RESET_SIZE;
            unsigned int rsmu_sms_fuse_run_mbist        : RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RUN_MBIST_SIZE;
            unsigned int rsmu_sms_fuse_run_bihr         : RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RUN_BIHR_SIZE;
            unsigned int rsmu_sms_fuse_resetb           : RSMU_SMS_FUSE_CFG_MP0_RSMU_SMS_FUSE_RESETB_SIZE;
      } rsmu_sms_fuse_cfg_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sms_fuse_cfg_mp0_t f;
} rsmu_sms_fuse_cfg_mp0_u;


/*
 * RSMU_SMS_FUSE_ADDR_BASE_MP0 struct
 */

#define RSMU_SMS_FUSE_ADDR_BASE_MP0_REG_SIZE         32
#define RSMU_SMS_FUSE_ADDR_BASE_MP0_RSMU_SMS_FUSE_ADDR_BASE_SIZE  20

#define RSMU_SMS_FUSE_ADDR_BASE_MP0_RSMU_SMS_FUSE_ADDR_BASE_SHIFT  0

#define RSMU_SMS_FUSE_ADDR_BASE_MP0_RSMU_SMS_FUSE_ADDR_BASE_MASK  0x000fffff

#define RSMU_SMS_FUSE_ADDR_BASE_MP0_MASK \
      (RSMU_SMS_FUSE_ADDR_BASE_MP0_RSMU_SMS_FUSE_ADDR_BASE_MASK)

#define RSMU_SMS_FUSE_ADDR_BASE_MP0_DEFAULT 0x00000000

#define RSMU_SMS_FUSE_ADDR_BASE_MP0_GET_RSMU_SMS_FUSE_ADDR_BASE(rsmu_sms_fuse_addr_base_mp0) \
      ((rsmu_sms_fuse_addr_base_mp0 & RSMU_SMS_FUSE_ADDR_BASE_MP0_RSMU_SMS_FUSE_ADDR_BASE_MASK) >> RSMU_SMS_FUSE_ADDR_BASE_MP0_RSMU_SMS_FUSE_ADDR_BASE_SHIFT)

#define RSMU_SMS_FUSE_ADDR_BASE_MP0_SET_RSMU_SMS_FUSE_ADDR_BASE(rsmu_sms_fuse_addr_base_mp0_reg, rsmu_sms_fuse_addr_base) \
      rsmu_sms_fuse_addr_base_mp0_reg = (rsmu_sms_fuse_addr_base_mp0_reg & ~RSMU_SMS_FUSE_ADDR_BASE_MP0_RSMU_SMS_FUSE_ADDR_BASE_MASK) | (rsmu_sms_fuse_addr_base << RSMU_SMS_FUSE_ADDR_BASE_MP0_RSMU_SMS_FUSE_ADDR_BASE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sms_fuse_addr_base_mp0_t {
            unsigned int rsmu_sms_fuse_addr_base        : RSMU_SMS_FUSE_ADDR_BASE_MP0_RSMU_SMS_FUSE_ADDR_BASE_SIZE;
            unsigned int                                : 12;
      } rsmu_sms_fuse_addr_base_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sms_fuse_addr_base_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sms_fuse_addr_base        : RSMU_SMS_FUSE_ADDR_BASE_MP0_RSMU_SMS_FUSE_ADDR_BASE_SIZE;
      } rsmu_sms_fuse_addr_base_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sms_fuse_addr_base_mp0_t f;
} rsmu_sms_fuse_addr_base_mp0_u;


/*
 * RSMU_SMS_FUSE_ADDR_OFFSET_MP0 struct
 */

#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_REG_SIZE         32
#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0_SIZE  8
#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1_SIZE  8
#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2_SIZE  8
#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3_SIZE  8

#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0_SHIFT  0
#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1_SHIFT  8
#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2_SHIFT  16
#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3_SHIFT  24

#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0_MASK  0x000000ff
#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1_MASK  0x0000ff00
#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2_MASK  0x00ff0000
#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3_MASK  0xff000000

#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_MASK \
      (RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0_MASK | \
      RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1_MASK | \
      RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2_MASK | \
      RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3_MASK)

#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_DEFAULT 0x00000000

#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_GET_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0(rsmu_sms_fuse_addr_offset_mp0) \
      ((rsmu_sms_fuse_addr_offset_mp0 & RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0_MASK) >> RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0_SHIFT)
#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_GET_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1(rsmu_sms_fuse_addr_offset_mp0) \
      ((rsmu_sms_fuse_addr_offset_mp0 & RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1_MASK) >> RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1_SHIFT)
#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_GET_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2(rsmu_sms_fuse_addr_offset_mp0) \
      ((rsmu_sms_fuse_addr_offset_mp0 & RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2_MASK) >> RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2_SHIFT)
#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_GET_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3(rsmu_sms_fuse_addr_offset_mp0) \
      ((rsmu_sms_fuse_addr_offset_mp0 & RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3_MASK) >> RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3_SHIFT)

#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_SET_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0(rsmu_sms_fuse_addr_offset_mp0_reg, rsmu_sms_fuse_addr_offset_grp0) \
      rsmu_sms_fuse_addr_offset_mp0_reg = (rsmu_sms_fuse_addr_offset_mp0_reg & ~RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0_MASK) | (rsmu_sms_fuse_addr_offset_grp0 << RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0_SHIFT)
#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_SET_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1(rsmu_sms_fuse_addr_offset_mp0_reg, rsmu_sms_fuse_addr_offset_grp1) \
      rsmu_sms_fuse_addr_offset_mp0_reg = (rsmu_sms_fuse_addr_offset_mp0_reg & ~RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1_MASK) | (rsmu_sms_fuse_addr_offset_grp1 << RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1_SHIFT)
#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_SET_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2(rsmu_sms_fuse_addr_offset_mp0_reg, rsmu_sms_fuse_addr_offset_grp2) \
      rsmu_sms_fuse_addr_offset_mp0_reg = (rsmu_sms_fuse_addr_offset_mp0_reg & ~RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2_MASK) | (rsmu_sms_fuse_addr_offset_grp2 << RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2_SHIFT)
#define RSMU_SMS_FUSE_ADDR_OFFSET_MP0_SET_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3(rsmu_sms_fuse_addr_offset_mp0_reg, rsmu_sms_fuse_addr_offset_grp3) \
      rsmu_sms_fuse_addr_offset_mp0_reg = (rsmu_sms_fuse_addr_offset_mp0_reg & ~RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3_MASK) | (rsmu_sms_fuse_addr_offset_grp3 << RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sms_fuse_addr_offset_mp0_t {
            unsigned int rsmu_sms_fuse_addr_offset_grp0 : RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0_SIZE;
            unsigned int rsmu_sms_fuse_addr_offset_grp1 : RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1_SIZE;
            unsigned int rsmu_sms_fuse_addr_offset_grp2 : RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2_SIZE;
            unsigned int rsmu_sms_fuse_addr_offset_grp3 : RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3_SIZE;
      } rsmu_sms_fuse_addr_offset_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sms_fuse_addr_offset_mp0_t {
            unsigned int rsmu_sms_fuse_addr_offset_grp3 : RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP3_SIZE;
            unsigned int rsmu_sms_fuse_addr_offset_grp2 : RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP2_SIZE;
            unsigned int rsmu_sms_fuse_addr_offset_grp1 : RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP1_SIZE;
            unsigned int rsmu_sms_fuse_addr_offset_grp0 : RSMU_SMS_FUSE_ADDR_OFFSET_MP0_RSMU_SMS_FUSE_ADDR_OFFSET_GRP0_SIZE;
      } rsmu_sms_fuse_addr_offset_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sms_fuse_addr_offset_mp0_t f;
} rsmu_sms_fuse_addr_offset_mp0_u;


/*
 * RSMU_STRAP_CONTROL_MP0 struct
 */

#define RSMU_STRAP_CONTROL_MP0_REG_SIZE         32
#define RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_READY_SIZE  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_VALID_SIZE  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_RELOAD_SIZE  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_ROM_READY_SIZE  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_ROM_VALID_SIZE  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_ROM_RELOAD_SIZE  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_PIN_RELOAD_SIZE  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_SEC_FUSE_READY_SIZE  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_SEC_FUSE_VALID_SIZE  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP0_SIZE  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP1_SIZE  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP2_SIZE  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP3_SIZE  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP0_SIZE  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP1_SIZE  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP2_SIZE  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP3_SIZE  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP0_SIZE  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP1_SIZE  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP2_SIZE  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP3_SIZE  1

#define RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_READY_SHIFT  0
#define RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_VALID_SHIFT  1
#define RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_RELOAD_SHIFT  2
#define RSMU_STRAP_CONTROL_MP0_RSMU_ROM_READY_SHIFT  3
#define RSMU_STRAP_CONTROL_MP0_RSMU_ROM_VALID_SHIFT  4
#define RSMU_STRAP_CONTROL_MP0_RSMU_ROM_RELOAD_SHIFT  5
#define RSMU_STRAP_CONTROL_MP0_RSMU_PIN_RELOAD_SHIFT  6
#define RSMU_STRAP_CONTROL_MP0_RSMU_SEC_FUSE_READY_SHIFT  7
#define RSMU_STRAP_CONTROL_MP0_RSMU_SEC_FUSE_VALID_SHIFT  8
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP0_SHIFT  9
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP1_SHIFT  10
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP2_SHIFT  11
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP3_SHIFT  12
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP0_SHIFT  13
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP1_SHIFT  14
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP2_SHIFT  15
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP3_SHIFT  16
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP0_SHIFT  17
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP1_SHIFT  18
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP2_SHIFT  19
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP3_SHIFT  20

#define RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_READY_MASK  0x00000001
#define RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_VALID_MASK  0x00000002
#define RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_RELOAD_MASK  0x00000004
#define RSMU_STRAP_CONTROL_MP0_RSMU_ROM_READY_MASK  0x00000008
#define RSMU_STRAP_CONTROL_MP0_RSMU_ROM_VALID_MASK  0x00000010
#define RSMU_STRAP_CONTROL_MP0_RSMU_ROM_RELOAD_MASK  0x00000020
#define RSMU_STRAP_CONTROL_MP0_RSMU_PIN_RELOAD_MASK  0x00000040
#define RSMU_STRAP_CONTROL_MP0_RSMU_SEC_FUSE_READY_MASK  0x00000080
#define RSMU_STRAP_CONTROL_MP0_RSMU_SEC_FUSE_VALID_MASK  0x00000100
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP0_MASK  0x00000200
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP1_MASK  0x00000400
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP2_MASK  0x00000800
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP3_MASK  0x00001000
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP0_MASK  0x00002000
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP1_MASK  0x00004000
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP2_MASK  0x00008000
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP3_MASK  0x00010000
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP0_MASK  0x00020000
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP1_MASK  0x00040000
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP2_MASK  0x00080000
#define RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP3_MASK  0x00100000

#define RSMU_STRAP_CONTROL_MP0_MASK \
      (RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_READY_MASK | \
      RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_VALID_MASK | \
      RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_RELOAD_MASK | \
      RSMU_STRAP_CONTROL_MP0_RSMU_ROM_READY_MASK | \
      RSMU_STRAP_CONTROL_MP0_RSMU_ROM_VALID_MASK | \
      RSMU_STRAP_CONTROL_MP0_RSMU_ROM_RELOAD_MASK | \
      RSMU_STRAP_CONTROL_MP0_RSMU_PIN_RELOAD_MASK | \
      RSMU_STRAP_CONTROL_MP0_RSMU_SEC_FUSE_READY_MASK | \
      RSMU_STRAP_CONTROL_MP0_RSMU_SEC_FUSE_VALID_MASK | \
      RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP0_MASK | \
      RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP1_MASK | \
      RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP2_MASK | \
      RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP3_MASK | \
      RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP0_MASK | \
      RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP1_MASK | \
      RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP2_MASK | \
      RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP3_MASK | \
      RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP0_MASK | \
      RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP1_MASK | \
      RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP2_MASK | \
      RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP3_MASK)

#define RSMU_STRAP_CONTROL_MP0_DEFAULT 0x00000000

#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_PUB_FUSE_READY(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_READY_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_READY_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_PUB_FUSE_VALID(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_VALID_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_VALID_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_PUB_FUSE_RELOAD(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_RELOAD_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_RELOAD_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_ROM_READY(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_ROM_READY_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_ROM_READY_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_ROM_VALID(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_ROM_VALID_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_ROM_VALID_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_ROM_RELOAD(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_ROM_RELOAD_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_ROM_RELOAD_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_PIN_RELOAD(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_PIN_RELOAD_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_PIN_RELOAD_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_SEC_FUSE_READY(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_SEC_FUSE_READY_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_SEC_FUSE_READY_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_SEC_FUSE_VALID(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_SEC_FUSE_VALID_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_SEC_FUSE_VALID_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_SMS_FUSE_READY_GRP0(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP0_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP0_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_SMS_FUSE_READY_GRP1(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP1_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP1_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_SMS_FUSE_READY_GRP2(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP2_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP2_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_SMS_FUSE_READY_GRP3(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP3_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP3_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_SMS_FUSE_VALID_GRP0(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP0_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP0_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_SMS_FUSE_VALID_GRP1(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP1_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP1_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_SMS_FUSE_VALID_GRP2(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP2_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP2_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_SMS_FUSE_VALID_GRP3(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP3_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP3_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_SMS_FUSE_BIST_FAIL_GRP0(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP0_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP0_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_SMS_FUSE_BIST_FAIL_GRP1(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP1_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP1_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_SMS_FUSE_BIST_FAIL_GRP2(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP2_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP2_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_GET_RSMU_SMS_FUSE_BIST_FAIL_GRP3(rsmu_strap_control_mp0) \
      ((rsmu_strap_control_mp0 & RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP3_MASK) >> RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP3_SHIFT)

#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_PUB_FUSE_READY(rsmu_strap_control_mp0_reg, rsmu_pub_fuse_ready) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_READY_MASK) | (rsmu_pub_fuse_ready << RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_READY_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_PUB_FUSE_VALID(rsmu_strap_control_mp0_reg, rsmu_pub_fuse_valid) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_VALID_MASK) | (rsmu_pub_fuse_valid << RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_VALID_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_PUB_FUSE_RELOAD(rsmu_strap_control_mp0_reg, rsmu_pub_fuse_reload) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_RELOAD_MASK) | (rsmu_pub_fuse_reload << RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_RELOAD_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_ROM_READY(rsmu_strap_control_mp0_reg, rsmu_rom_ready) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_ROM_READY_MASK) | (rsmu_rom_ready << RSMU_STRAP_CONTROL_MP0_RSMU_ROM_READY_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_ROM_VALID(rsmu_strap_control_mp0_reg, rsmu_rom_valid) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_ROM_VALID_MASK) | (rsmu_rom_valid << RSMU_STRAP_CONTROL_MP0_RSMU_ROM_VALID_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_ROM_RELOAD(rsmu_strap_control_mp0_reg, rsmu_rom_reload) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_ROM_RELOAD_MASK) | (rsmu_rom_reload << RSMU_STRAP_CONTROL_MP0_RSMU_ROM_RELOAD_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_PIN_RELOAD(rsmu_strap_control_mp0_reg, rsmu_pin_reload) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_PIN_RELOAD_MASK) | (rsmu_pin_reload << RSMU_STRAP_CONTROL_MP0_RSMU_PIN_RELOAD_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_SEC_FUSE_READY(rsmu_strap_control_mp0_reg, rsmu_sec_fuse_ready) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_SEC_FUSE_READY_MASK) | (rsmu_sec_fuse_ready << RSMU_STRAP_CONTROL_MP0_RSMU_SEC_FUSE_READY_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_SEC_FUSE_VALID(rsmu_strap_control_mp0_reg, rsmu_sec_fuse_valid) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_SEC_FUSE_VALID_MASK) | (rsmu_sec_fuse_valid << RSMU_STRAP_CONTROL_MP0_RSMU_SEC_FUSE_VALID_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_SMS_FUSE_READY_GRP0(rsmu_strap_control_mp0_reg, rsmu_sms_fuse_ready_grp0) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP0_MASK) | (rsmu_sms_fuse_ready_grp0 << RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP0_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_SMS_FUSE_READY_GRP1(rsmu_strap_control_mp0_reg, rsmu_sms_fuse_ready_grp1) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP1_MASK) | (rsmu_sms_fuse_ready_grp1 << RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP1_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_SMS_FUSE_READY_GRP2(rsmu_strap_control_mp0_reg, rsmu_sms_fuse_ready_grp2) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP2_MASK) | (rsmu_sms_fuse_ready_grp2 << RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP2_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_SMS_FUSE_READY_GRP3(rsmu_strap_control_mp0_reg, rsmu_sms_fuse_ready_grp3) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP3_MASK) | (rsmu_sms_fuse_ready_grp3 << RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP3_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_SMS_FUSE_VALID_GRP0(rsmu_strap_control_mp0_reg, rsmu_sms_fuse_valid_grp0) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP0_MASK) | (rsmu_sms_fuse_valid_grp0 << RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP0_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_SMS_FUSE_VALID_GRP1(rsmu_strap_control_mp0_reg, rsmu_sms_fuse_valid_grp1) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP1_MASK) | (rsmu_sms_fuse_valid_grp1 << RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP1_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_SMS_FUSE_VALID_GRP2(rsmu_strap_control_mp0_reg, rsmu_sms_fuse_valid_grp2) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP2_MASK) | (rsmu_sms_fuse_valid_grp2 << RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP2_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_SMS_FUSE_VALID_GRP3(rsmu_strap_control_mp0_reg, rsmu_sms_fuse_valid_grp3) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP3_MASK) | (rsmu_sms_fuse_valid_grp3 << RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP3_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_SMS_FUSE_BIST_FAIL_GRP0(rsmu_strap_control_mp0_reg, rsmu_sms_fuse_bist_fail_grp0) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP0_MASK) | (rsmu_sms_fuse_bist_fail_grp0 << RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP0_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_SMS_FUSE_BIST_FAIL_GRP1(rsmu_strap_control_mp0_reg, rsmu_sms_fuse_bist_fail_grp1) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP1_MASK) | (rsmu_sms_fuse_bist_fail_grp1 << RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP1_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_SMS_FUSE_BIST_FAIL_GRP2(rsmu_strap_control_mp0_reg, rsmu_sms_fuse_bist_fail_grp2) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP2_MASK) | (rsmu_sms_fuse_bist_fail_grp2 << RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP2_SHIFT)
#define RSMU_STRAP_CONTROL_MP0_SET_RSMU_SMS_FUSE_BIST_FAIL_GRP3(rsmu_strap_control_mp0_reg, rsmu_sms_fuse_bist_fail_grp3) \
      rsmu_strap_control_mp0_reg = (rsmu_strap_control_mp0_reg & ~RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP3_MASK) | (rsmu_sms_fuse_bist_fail_grp3 << RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP3_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_strap_control_mp0_t {
            unsigned int rsmu_pub_fuse_ready            : RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_READY_SIZE;
            unsigned int rsmu_pub_fuse_valid            : RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_VALID_SIZE;
            unsigned int rsmu_pub_fuse_reload           : RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_RELOAD_SIZE;
            unsigned int rsmu_rom_ready                 : RSMU_STRAP_CONTROL_MP0_RSMU_ROM_READY_SIZE;
            unsigned int rsmu_rom_valid                 : RSMU_STRAP_CONTROL_MP0_RSMU_ROM_VALID_SIZE;
            unsigned int rsmu_rom_reload                : RSMU_STRAP_CONTROL_MP0_RSMU_ROM_RELOAD_SIZE;
            unsigned int rsmu_pin_reload                : RSMU_STRAP_CONTROL_MP0_RSMU_PIN_RELOAD_SIZE;
            unsigned int rsmu_sec_fuse_ready            : RSMU_STRAP_CONTROL_MP0_RSMU_SEC_FUSE_READY_SIZE;
            unsigned int rsmu_sec_fuse_valid            : RSMU_STRAP_CONTROL_MP0_RSMU_SEC_FUSE_VALID_SIZE;
            unsigned int rsmu_sms_fuse_ready_grp0       : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP0_SIZE;
            unsigned int rsmu_sms_fuse_ready_grp1       : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP1_SIZE;
            unsigned int rsmu_sms_fuse_ready_grp2       : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP2_SIZE;
            unsigned int rsmu_sms_fuse_ready_grp3       : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP3_SIZE;
            unsigned int rsmu_sms_fuse_valid_grp0       : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP0_SIZE;
            unsigned int rsmu_sms_fuse_valid_grp1       : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP1_SIZE;
            unsigned int rsmu_sms_fuse_valid_grp2       : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP2_SIZE;
            unsigned int rsmu_sms_fuse_valid_grp3       : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP3_SIZE;
            unsigned int rsmu_sms_fuse_bist_fail_grp0   : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP0_SIZE;
            unsigned int rsmu_sms_fuse_bist_fail_grp1   : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP1_SIZE;
            unsigned int rsmu_sms_fuse_bist_fail_grp2   : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP2_SIZE;
            unsigned int rsmu_sms_fuse_bist_fail_grp3   : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP3_SIZE;
            unsigned int                                : 11;
      } rsmu_strap_control_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_strap_control_mp0_t {
            unsigned int                                : 11;
            unsigned int rsmu_sms_fuse_bist_fail_grp3   : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP3_SIZE;
            unsigned int rsmu_sms_fuse_bist_fail_grp2   : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP2_SIZE;
            unsigned int rsmu_sms_fuse_bist_fail_grp1   : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP1_SIZE;
            unsigned int rsmu_sms_fuse_bist_fail_grp0   : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_BIST_FAIL_GRP0_SIZE;
            unsigned int rsmu_sms_fuse_valid_grp3       : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP3_SIZE;
            unsigned int rsmu_sms_fuse_valid_grp2       : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP2_SIZE;
            unsigned int rsmu_sms_fuse_valid_grp1       : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP1_SIZE;
            unsigned int rsmu_sms_fuse_valid_grp0       : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_VALID_GRP0_SIZE;
            unsigned int rsmu_sms_fuse_ready_grp3       : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP3_SIZE;
            unsigned int rsmu_sms_fuse_ready_grp2       : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP2_SIZE;
            unsigned int rsmu_sms_fuse_ready_grp1       : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP1_SIZE;
            unsigned int rsmu_sms_fuse_ready_grp0       : RSMU_STRAP_CONTROL_MP0_RSMU_SMS_FUSE_READY_GRP0_SIZE;
            unsigned int rsmu_sec_fuse_valid            : RSMU_STRAP_CONTROL_MP0_RSMU_SEC_FUSE_VALID_SIZE;
            unsigned int rsmu_sec_fuse_ready            : RSMU_STRAP_CONTROL_MP0_RSMU_SEC_FUSE_READY_SIZE;
            unsigned int rsmu_pin_reload                : RSMU_STRAP_CONTROL_MP0_RSMU_PIN_RELOAD_SIZE;
            unsigned int rsmu_rom_reload                : RSMU_STRAP_CONTROL_MP0_RSMU_ROM_RELOAD_SIZE;
            unsigned int rsmu_rom_valid                 : RSMU_STRAP_CONTROL_MP0_RSMU_ROM_VALID_SIZE;
            unsigned int rsmu_rom_ready                 : RSMU_STRAP_CONTROL_MP0_RSMU_ROM_READY_SIZE;
            unsigned int rsmu_pub_fuse_reload           : RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_RELOAD_SIZE;
            unsigned int rsmu_pub_fuse_valid            : RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_VALID_SIZE;
            unsigned int rsmu_pub_fuse_ready            : RSMU_STRAP_CONTROL_MP0_RSMU_PUB_FUSE_READY_SIZE;
      } rsmu_strap_control_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_strap_control_mp0_t f;
} rsmu_strap_control_mp0_u;


/*
 * RSMU_COUNTER_0_MP0 struct
 */

#define RSMU_COUNTER_0_MP0_REG_SIZE         32
#define RSMU_COUNTER_0_MP0_RSMU_COUNTER_0_SIZE  32

#define RSMU_COUNTER_0_MP0_RSMU_COUNTER_0_SHIFT  0

#define RSMU_COUNTER_0_MP0_RSMU_COUNTER_0_MASK  0xffffffff

#define RSMU_COUNTER_0_MP0_MASK \
      (RSMU_COUNTER_0_MP0_RSMU_COUNTER_0_MASK)

#define RSMU_COUNTER_0_MP0_DEFAULT     0x00000000

#define RSMU_COUNTER_0_MP0_GET_RSMU_COUNTER_0(rsmu_counter_0_mp0) \
      ((rsmu_counter_0_mp0 & RSMU_COUNTER_0_MP0_RSMU_COUNTER_0_MASK) >> RSMU_COUNTER_0_MP0_RSMU_COUNTER_0_SHIFT)

#define RSMU_COUNTER_0_MP0_SET_RSMU_COUNTER_0(rsmu_counter_0_mp0_reg, rsmu_counter_0) \
      rsmu_counter_0_mp0_reg = (rsmu_counter_0_mp0_reg & ~RSMU_COUNTER_0_MP0_RSMU_COUNTER_0_MASK) | (rsmu_counter_0 << RSMU_COUNTER_0_MP0_RSMU_COUNTER_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_counter_0_mp0_t {
            unsigned int rsmu_counter_0                 : RSMU_COUNTER_0_MP0_RSMU_COUNTER_0_SIZE;
      } rsmu_counter_0_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_counter_0_mp0_t {
            unsigned int rsmu_counter_0                 : RSMU_COUNTER_0_MP0_RSMU_COUNTER_0_SIZE;
      } rsmu_counter_0_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_counter_0_mp0_t f;
} rsmu_counter_0_mp0_u;


/*
 * RSMU_COUNTER_1_MP0 struct
 */

#define RSMU_COUNTER_1_MP0_REG_SIZE         32
#define RSMU_COUNTER_1_MP0_RSMU_COUNTER_1_SIZE  24

#define RSMU_COUNTER_1_MP0_RSMU_COUNTER_1_SHIFT  0

#define RSMU_COUNTER_1_MP0_RSMU_COUNTER_1_MASK  0x00ffffff

#define RSMU_COUNTER_1_MP0_MASK \
      (RSMU_COUNTER_1_MP0_RSMU_COUNTER_1_MASK)

#define RSMU_COUNTER_1_MP0_DEFAULT     0x00000000

#define RSMU_COUNTER_1_MP0_GET_RSMU_COUNTER_1(rsmu_counter_1_mp0) \
      ((rsmu_counter_1_mp0 & RSMU_COUNTER_1_MP0_RSMU_COUNTER_1_MASK) >> RSMU_COUNTER_1_MP0_RSMU_COUNTER_1_SHIFT)

#define RSMU_COUNTER_1_MP0_SET_RSMU_COUNTER_1(rsmu_counter_1_mp0_reg, rsmu_counter_1) \
      rsmu_counter_1_mp0_reg = (rsmu_counter_1_mp0_reg & ~RSMU_COUNTER_1_MP0_RSMU_COUNTER_1_MASK) | (rsmu_counter_1 << RSMU_COUNTER_1_MP0_RSMU_COUNTER_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_counter_1_mp0_t {
            unsigned int rsmu_counter_1                 : RSMU_COUNTER_1_MP0_RSMU_COUNTER_1_SIZE;
            unsigned int                                : 8;
      } rsmu_counter_1_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_counter_1_mp0_t {
            unsigned int                                : 8;
            unsigned int rsmu_counter_1                 : RSMU_COUNTER_1_MP0_RSMU_COUNTER_1_SIZE;
      } rsmu_counter_1_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_counter_1_mp0_t f;
} rsmu_counter_1_mp0_u;


/*
 * RSMU_MMIOPUB_SCRATCH_REG_0_MP0 struct
 */

#define RSMU_MMIOPUB_SCRATCH_REG_0_MP0_REG_SIZE         32
#define RSMU_MMIOPUB_SCRATCH_REG_0_MP0_RSMU_MMIOPUB_SCRATCH_REG_0_SIZE  32

#define RSMU_MMIOPUB_SCRATCH_REG_0_MP0_RSMU_MMIOPUB_SCRATCH_REG_0_SHIFT  0

#define RSMU_MMIOPUB_SCRATCH_REG_0_MP0_RSMU_MMIOPUB_SCRATCH_REG_0_MASK  0xffffffff

#define RSMU_MMIOPUB_SCRATCH_REG_0_MP0_MASK \
      (RSMU_MMIOPUB_SCRATCH_REG_0_MP0_RSMU_MMIOPUB_SCRATCH_REG_0_MASK)

#define RSMU_MMIOPUB_SCRATCH_REG_0_MP0_DEFAULT 0x00000000

#define RSMU_MMIOPUB_SCRATCH_REG_0_MP0_GET_RSMU_MMIOPUB_SCRATCH_REG_0(rsmu_mmiopub_scratch_reg_0_mp0) \
      ((rsmu_mmiopub_scratch_reg_0_mp0 & RSMU_MMIOPUB_SCRATCH_REG_0_MP0_RSMU_MMIOPUB_SCRATCH_REG_0_MASK) >> RSMU_MMIOPUB_SCRATCH_REG_0_MP0_RSMU_MMIOPUB_SCRATCH_REG_0_SHIFT)

#define RSMU_MMIOPUB_SCRATCH_REG_0_MP0_SET_RSMU_MMIOPUB_SCRATCH_REG_0(rsmu_mmiopub_scratch_reg_0_mp0_reg, rsmu_mmiopub_scratch_reg_0) \
      rsmu_mmiopub_scratch_reg_0_mp0_reg = (rsmu_mmiopub_scratch_reg_0_mp0_reg & ~RSMU_MMIOPUB_SCRATCH_REG_0_MP0_RSMU_MMIOPUB_SCRATCH_REG_0_MASK) | (rsmu_mmiopub_scratch_reg_0 << RSMU_MMIOPUB_SCRATCH_REG_0_MP0_RSMU_MMIOPUB_SCRATCH_REG_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_mmiopub_scratch_reg_0_mp0_t {
            unsigned int rsmu_mmiopub_scratch_reg_0     : RSMU_MMIOPUB_SCRATCH_REG_0_MP0_RSMU_MMIOPUB_SCRATCH_REG_0_SIZE;
      } rsmu_mmiopub_scratch_reg_0_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_mmiopub_scratch_reg_0_mp0_t {
            unsigned int rsmu_mmiopub_scratch_reg_0     : RSMU_MMIOPUB_SCRATCH_REG_0_MP0_RSMU_MMIOPUB_SCRATCH_REG_0_SIZE;
      } rsmu_mmiopub_scratch_reg_0_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_mmiopub_scratch_reg_0_mp0_t f;
} rsmu_mmiopub_scratch_reg_0_mp0_u;


/*
 * RSMU_VF_ENABLE_MP0 struct
 */

#define RSMU_VF_ENABLE_MP0_REG_SIZE         32
#define RSMU_VF_ENABLE_MP0_RSMU_VF_ENABLE_SIZE  1

#define RSMU_VF_ENABLE_MP0_RSMU_VF_ENABLE_SHIFT  0

#define RSMU_VF_ENABLE_MP0_RSMU_VF_ENABLE_MASK  0x00000001

#define RSMU_VF_ENABLE_MP0_MASK \
      (RSMU_VF_ENABLE_MP0_RSMU_VF_ENABLE_MASK)

#define RSMU_VF_ENABLE_MP0_DEFAULT     0x00000000

#define RSMU_VF_ENABLE_MP0_GET_RSMU_VF_ENABLE(rsmu_vf_enable_mp0) \
      ((rsmu_vf_enable_mp0 & RSMU_VF_ENABLE_MP0_RSMU_VF_ENABLE_MASK) >> RSMU_VF_ENABLE_MP0_RSMU_VF_ENABLE_SHIFT)

#define RSMU_VF_ENABLE_MP0_SET_RSMU_VF_ENABLE(rsmu_vf_enable_mp0_reg, rsmu_vf_enable) \
      rsmu_vf_enable_mp0_reg = (rsmu_vf_enable_mp0_reg & ~RSMU_VF_ENABLE_MP0_RSMU_VF_ENABLE_MASK) | (rsmu_vf_enable << RSMU_VF_ENABLE_MP0_RSMU_VF_ENABLE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_vf_enable_mp0_t {
            unsigned int rsmu_vf_enable                 : RSMU_VF_ENABLE_MP0_RSMU_VF_ENABLE_SIZE;
            unsigned int                                : 31;
      } rsmu_vf_enable_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_vf_enable_mp0_t {
            unsigned int                                : 31;
            unsigned int rsmu_vf_enable                 : RSMU_VF_ENABLE_MP0_RSMU_VF_ENABLE_SIZE;
      } rsmu_vf_enable_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_vf_enable_mp0_t f;
} rsmu_vf_enable_mp0_u;


/*
 * RSMU_MGCG_CONTROL_MP0 struct
 */

#define RSMU_MGCG_CONTROL_MP0_REG_SIZE         32
#define RSMU_MGCG_CONTROL_MP0_RSMU_AXI_SLAVE_MGCG_OVERRIDE_SIZE  1
#define RSMU_MGCG_CONTROL_MP0_RSMU_AXI_MASTER_MGCG_OVERRIDE_SIZE  1
#define RSMU_MGCG_CONTROL_MP0_RSMU_SEC_INTR_MGCG_OVERRIDE_SIZE  1
#define RSMU_MGCG_CONTROL_MP0_RSMU_PWRMGT_INTR_MGCG_OVERRIDE_SIZE  1
#define RSMU_MGCG_CONTROL_MP0_RSMU_REG_WRAPPER_MGCG_OVERRIDE_SIZE  1
#define RSMU_MGCG_CONTROL_MP0_RSMU_STRAP_MASTER_MGCG_OVERRIDE_SIZE  1
#define RSMU_MGCG_CONTROL_MP0_RSMU_VWIRE_SRC_MGCG_OVERRIDE_SIZE  1
#define RSMU_MGCG_CONTROL_MP0_RSMU_REGIF_MASTER_MGCG_OVERRIDE_SIZE  1
#define RSMU_MGCG_CONTROL_MP0_RSMU_PGFSM_MGCG_OVERRIDE_SIZE  1
#define RSMU_MGCG_CONTROL_MP0_RSMU_IH_MGCG_OVERRIDE_SIZE  1
#define RSMU_MGCG_CONTROL_MP0_RSMU_SEM_MGCG_OVERRIDE_SIZE  1
#define RSMU_MGCG_CONTROL_MP0_RSMU_DPM_MGCG_OVERRIDE_SIZE  1

#define RSMU_MGCG_CONTROL_MP0_RSMU_AXI_SLAVE_MGCG_OVERRIDE_SHIFT  0
#define RSMU_MGCG_CONTROL_MP0_RSMU_AXI_MASTER_MGCG_OVERRIDE_SHIFT  1
#define RSMU_MGCG_CONTROL_MP0_RSMU_SEC_INTR_MGCG_OVERRIDE_SHIFT  2
#define RSMU_MGCG_CONTROL_MP0_RSMU_PWRMGT_INTR_MGCG_OVERRIDE_SHIFT  3
#define RSMU_MGCG_CONTROL_MP0_RSMU_REG_WRAPPER_MGCG_OVERRIDE_SHIFT  4
#define RSMU_MGCG_CONTROL_MP0_RSMU_STRAP_MASTER_MGCG_OVERRIDE_SHIFT  5
#define RSMU_MGCG_CONTROL_MP0_RSMU_VWIRE_SRC_MGCG_OVERRIDE_SHIFT  6
#define RSMU_MGCG_CONTROL_MP0_RSMU_REGIF_MASTER_MGCG_OVERRIDE_SHIFT  7
#define RSMU_MGCG_CONTROL_MP0_RSMU_PGFSM_MGCG_OVERRIDE_SHIFT  8
#define RSMU_MGCG_CONTROL_MP0_RSMU_IH_MGCG_OVERRIDE_SHIFT  9
#define RSMU_MGCG_CONTROL_MP0_RSMU_SEM_MGCG_OVERRIDE_SHIFT  10
#define RSMU_MGCG_CONTROL_MP0_RSMU_DPM_MGCG_OVERRIDE_SHIFT  11

#define RSMU_MGCG_CONTROL_MP0_RSMU_AXI_SLAVE_MGCG_OVERRIDE_MASK  0x00000001
#define RSMU_MGCG_CONTROL_MP0_RSMU_AXI_MASTER_MGCG_OVERRIDE_MASK  0x00000002
#define RSMU_MGCG_CONTROL_MP0_RSMU_SEC_INTR_MGCG_OVERRIDE_MASK  0x00000004
#define RSMU_MGCG_CONTROL_MP0_RSMU_PWRMGT_INTR_MGCG_OVERRIDE_MASK  0x00000008
#define RSMU_MGCG_CONTROL_MP0_RSMU_REG_WRAPPER_MGCG_OVERRIDE_MASK  0x00000010
#define RSMU_MGCG_CONTROL_MP0_RSMU_STRAP_MASTER_MGCG_OVERRIDE_MASK  0x00000020
#define RSMU_MGCG_CONTROL_MP0_RSMU_VWIRE_SRC_MGCG_OVERRIDE_MASK  0x00000040
#define RSMU_MGCG_CONTROL_MP0_RSMU_REGIF_MASTER_MGCG_OVERRIDE_MASK  0x00000080
#define RSMU_MGCG_CONTROL_MP0_RSMU_PGFSM_MGCG_OVERRIDE_MASK  0x00000100
#define RSMU_MGCG_CONTROL_MP0_RSMU_IH_MGCG_OVERRIDE_MASK  0x00000200
#define RSMU_MGCG_CONTROL_MP0_RSMU_SEM_MGCG_OVERRIDE_MASK  0x00000400
#define RSMU_MGCG_CONTROL_MP0_RSMU_DPM_MGCG_OVERRIDE_MASK  0x00000800

#define RSMU_MGCG_CONTROL_MP0_MASK \
      (RSMU_MGCG_CONTROL_MP0_RSMU_AXI_SLAVE_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MP0_RSMU_AXI_MASTER_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MP0_RSMU_SEC_INTR_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MP0_RSMU_PWRMGT_INTR_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MP0_RSMU_REG_WRAPPER_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MP0_RSMU_STRAP_MASTER_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MP0_RSMU_VWIRE_SRC_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MP0_RSMU_REGIF_MASTER_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MP0_RSMU_PGFSM_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MP0_RSMU_IH_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MP0_RSMU_SEM_MGCG_OVERRIDE_MASK | \
      RSMU_MGCG_CONTROL_MP0_RSMU_DPM_MGCG_OVERRIDE_MASK)

#define RSMU_MGCG_CONTROL_MP0_DEFAULT  0x00000000

#define RSMU_MGCG_CONTROL_MP0_GET_RSMU_AXI_SLAVE_MGCG_OVERRIDE(rsmu_mgcg_control_mp0) \
      ((rsmu_mgcg_control_mp0 & RSMU_MGCG_CONTROL_MP0_RSMU_AXI_SLAVE_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MP0_RSMU_AXI_SLAVE_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_GET_RSMU_AXI_MASTER_MGCG_OVERRIDE(rsmu_mgcg_control_mp0) \
      ((rsmu_mgcg_control_mp0 & RSMU_MGCG_CONTROL_MP0_RSMU_AXI_MASTER_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MP0_RSMU_AXI_MASTER_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_GET_RSMU_SEC_INTR_MGCG_OVERRIDE(rsmu_mgcg_control_mp0) \
      ((rsmu_mgcg_control_mp0 & RSMU_MGCG_CONTROL_MP0_RSMU_SEC_INTR_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MP0_RSMU_SEC_INTR_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_GET_RSMU_PWRMGT_INTR_MGCG_OVERRIDE(rsmu_mgcg_control_mp0) \
      ((rsmu_mgcg_control_mp0 & RSMU_MGCG_CONTROL_MP0_RSMU_PWRMGT_INTR_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MP0_RSMU_PWRMGT_INTR_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_GET_RSMU_REG_WRAPPER_MGCG_OVERRIDE(rsmu_mgcg_control_mp0) \
      ((rsmu_mgcg_control_mp0 & RSMU_MGCG_CONTROL_MP0_RSMU_REG_WRAPPER_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MP0_RSMU_REG_WRAPPER_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_GET_RSMU_STRAP_MASTER_MGCG_OVERRIDE(rsmu_mgcg_control_mp0) \
      ((rsmu_mgcg_control_mp0 & RSMU_MGCG_CONTROL_MP0_RSMU_STRAP_MASTER_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MP0_RSMU_STRAP_MASTER_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_GET_RSMU_VWIRE_SRC_MGCG_OVERRIDE(rsmu_mgcg_control_mp0) \
      ((rsmu_mgcg_control_mp0 & RSMU_MGCG_CONTROL_MP0_RSMU_VWIRE_SRC_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MP0_RSMU_VWIRE_SRC_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_GET_RSMU_REGIF_MASTER_MGCG_OVERRIDE(rsmu_mgcg_control_mp0) \
      ((rsmu_mgcg_control_mp0 & RSMU_MGCG_CONTROL_MP0_RSMU_REGIF_MASTER_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MP0_RSMU_REGIF_MASTER_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_GET_RSMU_PGFSM_MGCG_OVERRIDE(rsmu_mgcg_control_mp0) \
      ((rsmu_mgcg_control_mp0 & RSMU_MGCG_CONTROL_MP0_RSMU_PGFSM_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MP0_RSMU_PGFSM_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_GET_RSMU_IH_MGCG_OVERRIDE(rsmu_mgcg_control_mp0) \
      ((rsmu_mgcg_control_mp0 & RSMU_MGCG_CONTROL_MP0_RSMU_IH_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MP0_RSMU_IH_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_GET_RSMU_SEM_MGCG_OVERRIDE(rsmu_mgcg_control_mp0) \
      ((rsmu_mgcg_control_mp0 & RSMU_MGCG_CONTROL_MP0_RSMU_SEM_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MP0_RSMU_SEM_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_GET_RSMU_DPM_MGCG_OVERRIDE(rsmu_mgcg_control_mp0) \
      ((rsmu_mgcg_control_mp0 & RSMU_MGCG_CONTROL_MP0_RSMU_DPM_MGCG_OVERRIDE_MASK) >> RSMU_MGCG_CONTROL_MP0_RSMU_DPM_MGCG_OVERRIDE_SHIFT)

#define RSMU_MGCG_CONTROL_MP0_SET_RSMU_AXI_SLAVE_MGCG_OVERRIDE(rsmu_mgcg_control_mp0_reg, rsmu_axi_slave_mgcg_override) \
      rsmu_mgcg_control_mp0_reg = (rsmu_mgcg_control_mp0_reg & ~RSMU_MGCG_CONTROL_MP0_RSMU_AXI_SLAVE_MGCG_OVERRIDE_MASK) | (rsmu_axi_slave_mgcg_override << RSMU_MGCG_CONTROL_MP0_RSMU_AXI_SLAVE_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_SET_RSMU_AXI_MASTER_MGCG_OVERRIDE(rsmu_mgcg_control_mp0_reg, rsmu_axi_master_mgcg_override) \
      rsmu_mgcg_control_mp0_reg = (rsmu_mgcg_control_mp0_reg & ~RSMU_MGCG_CONTROL_MP0_RSMU_AXI_MASTER_MGCG_OVERRIDE_MASK) | (rsmu_axi_master_mgcg_override << RSMU_MGCG_CONTROL_MP0_RSMU_AXI_MASTER_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_SET_RSMU_SEC_INTR_MGCG_OVERRIDE(rsmu_mgcg_control_mp0_reg, rsmu_sec_intr_mgcg_override) \
      rsmu_mgcg_control_mp0_reg = (rsmu_mgcg_control_mp0_reg & ~RSMU_MGCG_CONTROL_MP0_RSMU_SEC_INTR_MGCG_OVERRIDE_MASK) | (rsmu_sec_intr_mgcg_override << RSMU_MGCG_CONTROL_MP0_RSMU_SEC_INTR_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_SET_RSMU_PWRMGT_INTR_MGCG_OVERRIDE(rsmu_mgcg_control_mp0_reg, rsmu_pwrmgt_intr_mgcg_override) \
      rsmu_mgcg_control_mp0_reg = (rsmu_mgcg_control_mp0_reg & ~RSMU_MGCG_CONTROL_MP0_RSMU_PWRMGT_INTR_MGCG_OVERRIDE_MASK) | (rsmu_pwrmgt_intr_mgcg_override << RSMU_MGCG_CONTROL_MP0_RSMU_PWRMGT_INTR_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_SET_RSMU_REG_WRAPPER_MGCG_OVERRIDE(rsmu_mgcg_control_mp0_reg, rsmu_reg_wrapper_mgcg_override) \
      rsmu_mgcg_control_mp0_reg = (rsmu_mgcg_control_mp0_reg & ~RSMU_MGCG_CONTROL_MP0_RSMU_REG_WRAPPER_MGCG_OVERRIDE_MASK) | (rsmu_reg_wrapper_mgcg_override << RSMU_MGCG_CONTROL_MP0_RSMU_REG_WRAPPER_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_SET_RSMU_STRAP_MASTER_MGCG_OVERRIDE(rsmu_mgcg_control_mp0_reg, rsmu_strap_master_mgcg_override) \
      rsmu_mgcg_control_mp0_reg = (rsmu_mgcg_control_mp0_reg & ~RSMU_MGCG_CONTROL_MP0_RSMU_STRAP_MASTER_MGCG_OVERRIDE_MASK) | (rsmu_strap_master_mgcg_override << RSMU_MGCG_CONTROL_MP0_RSMU_STRAP_MASTER_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_SET_RSMU_VWIRE_SRC_MGCG_OVERRIDE(rsmu_mgcg_control_mp0_reg, rsmu_vwire_src_mgcg_override) \
      rsmu_mgcg_control_mp0_reg = (rsmu_mgcg_control_mp0_reg & ~RSMU_MGCG_CONTROL_MP0_RSMU_VWIRE_SRC_MGCG_OVERRIDE_MASK) | (rsmu_vwire_src_mgcg_override << RSMU_MGCG_CONTROL_MP0_RSMU_VWIRE_SRC_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_SET_RSMU_REGIF_MASTER_MGCG_OVERRIDE(rsmu_mgcg_control_mp0_reg, rsmu_regif_master_mgcg_override) \
      rsmu_mgcg_control_mp0_reg = (rsmu_mgcg_control_mp0_reg & ~RSMU_MGCG_CONTROL_MP0_RSMU_REGIF_MASTER_MGCG_OVERRIDE_MASK) | (rsmu_regif_master_mgcg_override << RSMU_MGCG_CONTROL_MP0_RSMU_REGIF_MASTER_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_SET_RSMU_PGFSM_MGCG_OVERRIDE(rsmu_mgcg_control_mp0_reg, rsmu_pgfsm_mgcg_override) \
      rsmu_mgcg_control_mp0_reg = (rsmu_mgcg_control_mp0_reg & ~RSMU_MGCG_CONTROL_MP0_RSMU_PGFSM_MGCG_OVERRIDE_MASK) | (rsmu_pgfsm_mgcg_override << RSMU_MGCG_CONTROL_MP0_RSMU_PGFSM_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_SET_RSMU_IH_MGCG_OVERRIDE(rsmu_mgcg_control_mp0_reg, rsmu_ih_mgcg_override) \
      rsmu_mgcg_control_mp0_reg = (rsmu_mgcg_control_mp0_reg & ~RSMU_MGCG_CONTROL_MP0_RSMU_IH_MGCG_OVERRIDE_MASK) | (rsmu_ih_mgcg_override << RSMU_MGCG_CONTROL_MP0_RSMU_IH_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_SET_RSMU_SEM_MGCG_OVERRIDE(rsmu_mgcg_control_mp0_reg, rsmu_sem_mgcg_override) \
      rsmu_mgcg_control_mp0_reg = (rsmu_mgcg_control_mp0_reg & ~RSMU_MGCG_CONTROL_MP0_RSMU_SEM_MGCG_OVERRIDE_MASK) | (rsmu_sem_mgcg_override << RSMU_MGCG_CONTROL_MP0_RSMU_SEM_MGCG_OVERRIDE_SHIFT)
#define RSMU_MGCG_CONTROL_MP0_SET_RSMU_DPM_MGCG_OVERRIDE(rsmu_mgcg_control_mp0_reg, rsmu_dpm_mgcg_override) \
      rsmu_mgcg_control_mp0_reg = (rsmu_mgcg_control_mp0_reg & ~RSMU_MGCG_CONTROL_MP0_RSMU_DPM_MGCG_OVERRIDE_MASK) | (rsmu_dpm_mgcg_override << RSMU_MGCG_CONTROL_MP0_RSMU_DPM_MGCG_OVERRIDE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_mgcg_control_mp0_t {
            unsigned int rsmu_axi_slave_mgcg_override   : RSMU_MGCG_CONTROL_MP0_RSMU_AXI_SLAVE_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_axi_master_mgcg_override  : RSMU_MGCG_CONTROL_MP0_RSMU_AXI_MASTER_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_sec_intr_mgcg_override    : RSMU_MGCG_CONTROL_MP0_RSMU_SEC_INTR_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_pwrmgt_intr_mgcg_override : RSMU_MGCG_CONTROL_MP0_RSMU_PWRMGT_INTR_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_reg_wrapper_mgcg_override : RSMU_MGCG_CONTROL_MP0_RSMU_REG_WRAPPER_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_strap_master_mgcg_override : RSMU_MGCG_CONTROL_MP0_RSMU_STRAP_MASTER_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_vwire_src_mgcg_override   : RSMU_MGCG_CONTROL_MP0_RSMU_VWIRE_SRC_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_regif_master_mgcg_override : RSMU_MGCG_CONTROL_MP0_RSMU_REGIF_MASTER_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_pgfsm_mgcg_override       : RSMU_MGCG_CONTROL_MP0_RSMU_PGFSM_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_ih_mgcg_override          : RSMU_MGCG_CONTROL_MP0_RSMU_IH_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_sem_mgcg_override         : RSMU_MGCG_CONTROL_MP0_RSMU_SEM_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_dpm_mgcg_override         : RSMU_MGCG_CONTROL_MP0_RSMU_DPM_MGCG_OVERRIDE_SIZE;
            unsigned int                                : 20;
      } rsmu_mgcg_control_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_mgcg_control_mp0_t {
            unsigned int                                : 20;
            unsigned int rsmu_dpm_mgcg_override         : RSMU_MGCG_CONTROL_MP0_RSMU_DPM_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_sem_mgcg_override         : RSMU_MGCG_CONTROL_MP0_RSMU_SEM_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_ih_mgcg_override          : RSMU_MGCG_CONTROL_MP0_RSMU_IH_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_pgfsm_mgcg_override       : RSMU_MGCG_CONTROL_MP0_RSMU_PGFSM_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_regif_master_mgcg_override : RSMU_MGCG_CONTROL_MP0_RSMU_REGIF_MASTER_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_vwire_src_mgcg_override   : RSMU_MGCG_CONTROL_MP0_RSMU_VWIRE_SRC_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_strap_master_mgcg_override : RSMU_MGCG_CONTROL_MP0_RSMU_STRAP_MASTER_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_reg_wrapper_mgcg_override : RSMU_MGCG_CONTROL_MP0_RSMU_REG_WRAPPER_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_pwrmgt_intr_mgcg_override : RSMU_MGCG_CONTROL_MP0_RSMU_PWRMGT_INTR_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_sec_intr_mgcg_override    : RSMU_MGCG_CONTROL_MP0_RSMU_SEC_INTR_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_axi_master_mgcg_override  : RSMU_MGCG_CONTROL_MP0_RSMU_AXI_MASTER_MGCG_OVERRIDE_SIZE;
            unsigned int rsmu_axi_slave_mgcg_override   : RSMU_MGCG_CONTROL_MP0_RSMU_AXI_SLAVE_MGCG_OVERRIDE_SIZE;
      } rsmu_mgcg_control_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_mgcg_control_mp0_t f;
} rsmu_mgcg_control_mp0_u;


/*
 * RSMU_SEC_AXI_MASTER_ENABLE_MP0 struct
 */

#define RSMU_SEC_AXI_MASTER_ENABLE_MP0_REG_SIZE         32
#define RSMU_SEC_AXI_MASTER_ENABLE_MP0_RSMU_SEC_AXI_MASTER_ENABLE_SIZE  1

#define RSMU_SEC_AXI_MASTER_ENABLE_MP0_RSMU_SEC_AXI_MASTER_ENABLE_SHIFT  0

#define RSMU_SEC_AXI_MASTER_ENABLE_MP0_RSMU_SEC_AXI_MASTER_ENABLE_MASK  0x00000001

#define RSMU_SEC_AXI_MASTER_ENABLE_MP0_MASK \
      (RSMU_SEC_AXI_MASTER_ENABLE_MP0_RSMU_SEC_AXI_MASTER_ENABLE_MASK)

#define RSMU_SEC_AXI_MASTER_ENABLE_MP0_DEFAULT 0x00000001

#define RSMU_SEC_AXI_MASTER_ENABLE_MP0_GET_RSMU_SEC_AXI_MASTER_ENABLE(rsmu_sec_axi_master_enable_mp0) \
      ((rsmu_sec_axi_master_enable_mp0 & RSMU_SEC_AXI_MASTER_ENABLE_MP0_RSMU_SEC_AXI_MASTER_ENABLE_MASK) >> RSMU_SEC_AXI_MASTER_ENABLE_MP0_RSMU_SEC_AXI_MASTER_ENABLE_SHIFT)

#define RSMU_SEC_AXI_MASTER_ENABLE_MP0_SET_RSMU_SEC_AXI_MASTER_ENABLE(rsmu_sec_axi_master_enable_mp0_reg, rsmu_sec_axi_master_enable) \
      rsmu_sec_axi_master_enable_mp0_reg = (rsmu_sec_axi_master_enable_mp0_reg & ~RSMU_SEC_AXI_MASTER_ENABLE_MP0_RSMU_SEC_AXI_MASTER_ENABLE_MASK) | (rsmu_sec_axi_master_enable << RSMU_SEC_AXI_MASTER_ENABLE_MP0_RSMU_SEC_AXI_MASTER_ENABLE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_axi_master_enable_mp0_t {
            unsigned int rsmu_sec_axi_master_enable     : RSMU_SEC_AXI_MASTER_ENABLE_MP0_RSMU_SEC_AXI_MASTER_ENABLE_SIZE;
            unsigned int                                : 31;
      } rsmu_sec_axi_master_enable_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_axi_master_enable_mp0_t {
            unsigned int                                : 31;
            unsigned int rsmu_sec_axi_master_enable     : RSMU_SEC_AXI_MASTER_ENABLE_MP0_RSMU_SEC_AXI_MASTER_ENABLE_SIZE;
      } rsmu_sec_axi_master_enable_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_axi_master_enable_mp0_t f;
} rsmu_sec_axi_master_enable_mp0_u;


/*
 * RSMU_AXI_MASTER_QOS_CNTL_MP0 struct
 */

#define RSMU_AXI_MASTER_QOS_CNTL_MP0_REG_SIZE         32
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_MASTER_QOS_OVRD_MODE_SIZE  1
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_MASTER_QOS_OVRD_VALUE_SIZE  4
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_AWQOS_OVRD_MODE_SIZE  1
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_AWQOS_OVRD_VALUE_SIZE  4
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_ARQOS_OVRD_MODE_SIZE  1
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_ARQOS_OVRD_VALUE_SIZE  4

#define RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_MASTER_QOS_OVRD_MODE_SHIFT  0
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_MASTER_QOS_OVRD_VALUE_SHIFT  1
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_AWQOS_OVRD_MODE_SHIFT  5
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_AWQOS_OVRD_VALUE_SHIFT  6
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_ARQOS_OVRD_MODE_SHIFT  10
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_ARQOS_OVRD_VALUE_SHIFT  11

#define RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_MASTER_QOS_OVRD_MODE_MASK  0x00000001
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_MASTER_QOS_OVRD_VALUE_MASK  0x0000001e
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_AWQOS_OVRD_MODE_MASK  0x00000020
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_AWQOS_OVRD_VALUE_MASK  0x000003c0
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_ARQOS_OVRD_MODE_MASK  0x00000400
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_ARQOS_OVRD_VALUE_MASK  0x00007800

#define RSMU_AXI_MASTER_QOS_CNTL_MP0_MASK \
      (RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_MASTER_QOS_OVRD_MODE_MASK | \
      RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_MASTER_QOS_OVRD_VALUE_MASK | \
      RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_AWQOS_OVRD_MODE_MASK | \
      RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_AWQOS_OVRD_VALUE_MASK | \
      RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_ARQOS_OVRD_MODE_MASK | \
      RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_ARQOS_OVRD_VALUE_MASK)

#define RSMU_AXI_MASTER_QOS_CNTL_MP0_DEFAULT 0x00000842

#define RSMU_AXI_MASTER_QOS_CNTL_MP0_GET_RSMU_MASTER_QOS_OVRD_MODE(rsmu_axi_master_qos_cntl_mp0) \
      ((rsmu_axi_master_qos_cntl_mp0 & RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_MASTER_QOS_OVRD_MODE_MASK) >> RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_MASTER_QOS_OVRD_MODE_SHIFT)
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_GET_RSMU_MASTER_QOS_OVRD_VALUE(rsmu_axi_master_qos_cntl_mp0) \
      ((rsmu_axi_master_qos_cntl_mp0 & RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_MASTER_QOS_OVRD_VALUE_MASK) >> RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_MASTER_QOS_OVRD_VALUE_SHIFT)
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_GET_RSMU_IP_MASTER_AWQOS_OVRD_MODE(rsmu_axi_master_qos_cntl_mp0) \
      ((rsmu_axi_master_qos_cntl_mp0 & RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_AWQOS_OVRD_MODE_MASK) >> RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_AWQOS_OVRD_MODE_SHIFT)
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_GET_RSMU_IP_MASTER_AWQOS_OVRD_VALUE(rsmu_axi_master_qos_cntl_mp0) \
      ((rsmu_axi_master_qos_cntl_mp0 & RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_AWQOS_OVRD_VALUE_MASK) >> RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_AWQOS_OVRD_VALUE_SHIFT)
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_GET_RSMU_IP_MASTER_ARQOS_OVRD_MODE(rsmu_axi_master_qos_cntl_mp0) \
      ((rsmu_axi_master_qos_cntl_mp0 & RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_ARQOS_OVRD_MODE_MASK) >> RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_ARQOS_OVRD_MODE_SHIFT)
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_GET_RSMU_IP_MASTER_ARQOS_OVRD_VALUE(rsmu_axi_master_qos_cntl_mp0) \
      ((rsmu_axi_master_qos_cntl_mp0 & RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_ARQOS_OVRD_VALUE_MASK) >> RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_ARQOS_OVRD_VALUE_SHIFT)

#define RSMU_AXI_MASTER_QOS_CNTL_MP0_SET_RSMU_MASTER_QOS_OVRD_MODE(rsmu_axi_master_qos_cntl_mp0_reg, rsmu_master_qos_ovrd_mode) \
      rsmu_axi_master_qos_cntl_mp0_reg = (rsmu_axi_master_qos_cntl_mp0_reg & ~RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_MASTER_QOS_OVRD_MODE_MASK) | (rsmu_master_qos_ovrd_mode << RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_MASTER_QOS_OVRD_MODE_SHIFT)
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_SET_RSMU_MASTER_QOS_OVRD_VALUE(rsmu_axi_master_qos_cntl_mp0_reg, rsmu_master_qos_ovrd_value) \
      rsmu_axi_master_qos_cntl_mp0_reg = (rsmu_axi_master_qos_cntl_mp0_reg & ~RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_MASTER_QOS_OVRD_VALUE_MASK) | (rsmu_master_qos_ovrd_value << RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_MASTER_QOS_OVRD_VALUE_SHIFT)
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_SET_RSMU_IP_MASTER_AWQOS_OVRD_MODE(rsmu_axi_master_qos_cntl_mp0_reg, rsmu_ip_master_awqos_ovrd_mode) \
      rsmu_axi_master_qos_cntl_mp0_reg = (rsmu_axi_master_qos_cntl_mp0_reg & ~RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_AWQOS_OVRD_MODE_MASK) | (rsmu_ip_master_awqos_ovrd_mode << RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_AWQOS_OVRD_MODE_SHIFT)
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_SET_RSMU_IP_MASTER_AWQOS_OVRD_VALUE(rsmu_axi_master_qos_cntl_mp0_reg, rsmu_ip_master_awqos_ovrd_value) \
      rsmu_axi_master_qos_cntl_mp0_reg = (rsmu_axi_master_qos_cntl_mp0_reg & ~RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_AWQOS_OVRD_VALUE_MASK) | (rsmu_ip_master_awqos_ovrd_value << RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_AWQOS_OVRD_VALUE_SHIFT)
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_SET_RSMU_IP_MASTER_ARQOS_OVRD_MODE(rsmu_axi_master_qos_cntl_mp0_reg, rsmu_ip_master_arqos_ovrd_mode) \
      rsmu_axi_master_qos_cntl_mp0_reg = (rsmu_axi_master_qos_cntl_mp0_reg & ~RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_ARQOS_OVRD_MODE_MASK) | (rsmu_ip_master_arqos_ovrd_mode << RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_ARQOS_OVRD_MODE_SHIFT)
#define RSMU_AXI_MASTER_QOS_CNTL_MP0_SET_RSMU_IP_MASTER_ARQOS_OVRD_VALUE(rsmu_axi_master_qos_cntl_mp0_reg, rsmu_ip_master_arqos_ovrd_value) \
      rsmu_axi_master_qos_cntl_mp0_reg = (rsmu_axi_master_qos_cntl_mp0_reg & ~RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_ARQOS_OVRD_VALUE_MASK) | (rsmu_ip_master_arqos_ovrd_value << RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_ARQOS_OVRD_VALUE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_axi_master_qos_cntl_mp0_t {
            unsigned int rsmu_master_qos_ovrd_mode      : RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_MASTER_QOS_OVRD_MODE_SIZE;
            unsigned int rsmu_master_qos_ovrd_value     : RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_MASTER_QOS_OVRD_VALUE_SIZE;
            unsigned int rsmu_ip_master_awqos_ovrd_mode : RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_AWQOS_OVRD_MODE_SIZE;
            unsigned int rsmu_ip_master_awqos_ovrd_value : RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_AWQOS_OVRD_VALUE_SIZE;
            unsigned int rsmu_ip_master_arqos_ovrd_mode : RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_ARQOS_OVRD_MODE_SIZE;
            unsigned int rsmu_ip_master_arqos_ovrd_value : RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_ARQOS_OVRD_VALUE_SIZE;
            unsigned int                                : 17;
      } rsmu_axi_master_qos_cntl_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_axi_master_qos_cntl_mp0_t {
            unsigned int                                : 17;
            unsigned int rsmu_ip_master_arqos_ovrd_value : RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_ARQOS_OVRD_VALUE_SIZE;
            unsigned int rsmu_ip_master_arqos_ovrd_mode : RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_ARQOS_OVRD_MODE_SIZE;
            unsigned int rsmu_ip_master_awqos_ovrd_value : RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_AWQOS_OVRD_VALUE_SIZE;
            unsigned int rsmu_ip_master_awqos_ovrd_mode : RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_IP_MASTER_AWQOS_OVRD_MODE_SIZE;
            unsigned int rsmu_master_qos_ovrd_value     : RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_MASTER_QOS_OVRD_VALUE_SIZE;
            unsigned int rsmu_master_qos_ovrd_mode      : RSMU_AXI_MASTER_QOS_CNTL_MP0_RSMU_MASTER_QOS_OVRD_MODE_SIZE;
      } rsmu_axi_master_qos_cntl_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_axi_master_qos_cntl_mp0_t f;
} rsmu_axi_master_qos_cntl_mp0_u;


/*
 * RSMU_MASTER_ERROR_COUNTER_MP0 struct
 */

#define RSMU_MASTER_ERROR_COUNTER_MP0_REG_SIZE         32
#define RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_SMN_SLVERR_COUNTER_SIZE  8
#define RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_SMN_DECERR_COUNTER_SIZE  8
#define RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_MASTER_SLVERR_COUNTER_SIZE  8
#define RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_MASTER_DECERR_COUNTER_SIZE  8

#define RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_SMN_SLVERR_COUNTER_SHIFT  0
#define RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_SMN_DECERR_COUNTER_SHIFT  8
#define RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_MASTER_SLVERR_COUNTER_SHIFT  16
#define RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_MASTER_DECERR_COUNTER_SHIFT  24

#define RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_SMN_SLVERR_COUNTER_MASK  0x000000ff
#define RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_SMN_DECERR_COUNTER_MASK  0x0000ff00
#define RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_MASTER_SLVERR_COUNTER_MASK  0x00ff0000
#define RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_MASTER_DECERR_COUNTER_MASK  0xff000000

#define RSMU_MASTER_ERROR_COUNTER_MP0_MASK \
      (RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_SMN_SLVERR_COUNTER_MASK | \
      RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_SMN_DECERR_COUNTER_MASK | \
      RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_MASTER_SLVERR_COUNTER_MASK | \
      RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_MASTER_DECERR_COUNTER_MASK)

#define RSMU_MASTER_ERROR_COUNTER_MP0_DEFAULT 0x00000000

#define RSMU_MASTER_ERROR_COUNTER_MP0_GET_RSMU_SMN_SLVERR_COUNTER(rsmu_master_error_counter_mp0) \
      ((rsmu_master_error_counter_mp0 & RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_SMN_SLVERR_COUNTER_MASK) >> RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_SMN_SLVERR_COUNTER_SHIFT)
#define RSMU_MASTER_ERROR_COUNTER_MP0_GET_RSMU_SMN_DECERR_COUNTER(rsmu_master_error_counter_mp0) \
      ((rsmu_master_error_counter_mp0 & RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_SMN_DECERR_COUNTER_MASK) >> RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_SMN_DECERR_COUNTER_SHIFT)
#define RSMU_MASTER_ERROR_COUNTER_MP0_GET_RSMU_MASTER_SLVERR_COUNTER(rsmu_master_error_counter_mp0) \
      ((rsmu_master_error_counter_mp0 & RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_MASTER_SLVERR_COUNTER_MASK) >> RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_MASTER_SLVERR_COUNTER_SHIFT)
#define RSMU_MASTER_ERROR_COUNTER_MP0_GET_RSMU_MASTER_DECERR_COUNTER(rsmu_master_error_counter_mp0) \
      ((rsmu_master_error_counter_mp0 & RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_MASTER_DECERR_COUNTER_MASK) >> RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_MASTER_DECERR_COUNTER_SHIFT)

#define RSMU_MASTER_ERROR_COUNTER_MP0_SET_RSMU_SMN_SLVERR_COUNTER(rsmu_master_error_counter_mp0_reg, rsmu_smn_slverr_counter) \
      rsmu_master_error_counter_mp0_reg = (rsmu_master_error_counter_mp0_reg & ~RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_SMN_SLVERR_COUNTER_MASK) | (rsmu_smn_slverr_counter << RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_SMN_SLVERR_COUNTER_SHIFT)
#define RSMU_MASTER_ERROR_COUNTER_MP0_SET_RSMU_SMN_DECERR_COUNTER(rsmu_master_error_counter_mp0_reg, rsmu_smn_decerr_counter) \
      rsmu_master_error_counter_mp0_reg = (rsmu_master_error_counter_mp0_reg & ~RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_SMN_DECERR_COUNTER_MASK) | (rsmu_smn_decerr_counter << RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_SMN_DECERR_COUNTER_SHIFT)
#define RSMU_MASTER_ERROR_COUNTER_MP0_SET_RSMU_MASTER_SLVERR_COUNTER(rsmu_master_error_counter_mp0_reg, rsmu_master_slverr_counter) \
      rsmu_master_error_counter_mp0_reg = (rsmu_master_error_counter_mp0_reg & ~RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_MASTER_SLVERR_COUNTER_MASK) | (rsmu_master_slverr_counter << RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_MASTER_SLVERR_COUNTER_SHIFT)
#define RSMU_MASTER_ERROR_COUNTER_MP0_SET_RSMU_MASTER_DECERR_COUNTER(rsmu_master_error_counter_mp0_reg, rsmu_master_decerr_counter) \
      rsmu_master_error_counter_mp0_reg = (rsmu_master_error_counter_mp0_reg & ~RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_MASTER_DECERR_COUNTER_MASK) | (rsmu_master_decerr_counter << RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_MASTER_DECERR_COUNTER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_master_error_counter_mp0_t {
            unsigned int rsmu_smn_slverr_counter        : RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_SMN_SLVERR_COUNTER_SIZE;
            unsigned int rsmu_smn_decerr_counter        : RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_SMN_DECERR_COUNTER_SIZE;
            unsigned int rsmu_master_slverr_counter     : RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_MASTER_SLVERR_COUNTER_SIZE;
            unsigned int rsmu_master_decerr_counter     : RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_MASTER_DECERR_COUNTER_SIZE;
      } rsmu_master_error_counter_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_master_error_counter_mp0_t {
            unsigned int rsmu_master_decerr_counter     : RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_MASTER_DECERR_COUNTER_SIZE;
            unsigned int rsmu_master_slverr_counter     : RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_MASTER_SLVERR_COUNTER_SIZE;
            unsigned int rsmu_smn_decerr_counter        : RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_SMN_DECERR_COUNTER_SIZE;
            unsigned int rsmu_smn_slverr_counter        : RSMU_MASTER_ERROR_COUNTER_MP0_RSMU_SMN_SLVERR_COUNTER_SIZE;
      } rsmu_master_error_counter_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_master_error_counter_mp0_t f;
} rsmu_master_error_counter_mp0_u;


/*
 * RSMU_SLAVE_TIMEOUT_VALUE_MP0 struct
 */

#define RSMU_SLAVE_TIMEOUT_VALUE_MP0_REG_SIZE         32
#define RSMU_SLAVE_TIMEOUT_VALUE_MP0_RSMU_SLAVE_TIMEOUT_VALUE_SIZE  32

#define RSMU_SLAVE_TIMEOUT_VALUE_MP0_RSMU_SLAVE_TIMEOUT_VALUE_SHIFT  0

#define RSMU_SLAVE_TIMEOUT_VALUE_MP0_RSMU_SLAVE_TIMEOUT_VALUE_MASK  0xffffffff

#define RSMU_SLAVE_TIMEOUT_VALUE_MP0_MASK \
      (RSMU_SLAVE_TIMEOUT_VALUE_MP0_RSMU_SLAVE_TIMEOUT_VALUE_MASK)

#define RSMU_SLAVE_TIMEOUT_VALUE_MP0_DEFAULT 0x00ffffff

#define RSMU_SLAVE_TIMEOUT_VALUE_MP0_GET_RSMU_SLAVE_TIMEOUT_VALUE(rsmu_slave_timeout_value_mp0) \
      ((rsmu_slave_timeout_value_mp0 & RSMU_SLAVE_TIMEOUT_VALUE_MP0_RSMU_SLAVE_TIMEOUT_VALUE_MASK) >> RSMU_SLAVE_TIMEOUT_VALUE_MP0_RSMU_SLAVE_TIMEOUT_VALUE_SHIFT)

#define RSMU_SLAVE_TIMEOUT_VALUE_MP0_SET_RSMU_SLAVE_TIMEOUT_VALUE(rsmu_slave_timeout_value_mp0_reg, rsmu_slave_timeout_value) \
      rsmu_slave_timeout_value_mp0_reg = (rsmu_slave_timeout_value_mp0_reg & ~RSMU_SLAVE_TIMEOUT_VALUE_MP0_RSMU_SLAVE_TIMEOUT_VALUE_MASK) | (rsmu_slave_timeout_value << RSMU_SLAVE_TIMEOUT_VALUE_MP0_RSMU_SLAVE_TIMEOUT_VALUE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_slave_timeout_value_mp0_t {
            unsigned int rsmu_slave_timeout_value       : RSMU_SLAVE_TIMEOUT_VALUE_MP0_RSMU_SLAVE_TIMEOUT_VALUE_SIZE;
      } rsmu_slave_timeout_value_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_slave_timeout_value_mp0_t {
            unsigned int rsmu_slave_timeout_value       : RSMU_SLAVE_TIMEOUT_VALUE_MP0_RSMU_SLAVE_TIMEOUT_VALUE_SIZE;
      } rsmu_slave_timeout_value_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_slave_timeout_value_mp0_t f;
} rsmu_slave_timeout_value_mp0_u;


/*
 * RSMU_RESET_TIMEOUT_CONTROL_MP0 struct
 */

#define RSMU_RESET_TIMEOUT_CONTROL_MP0_REG_SIZE         32
#define RSMU_RESET_TIMEOUT_CONTROL_MP0_RSMU_SLAVE_TIMEOUT_ENABLE_SIZE  1
#define RSMU_RESET_TIMEOUT_CONTROL_MP0_RSMU_SLAVE_RESET_TIMEOUT_VALUE_SIZE  8

#define RSMU_RESET_TIMEOUT_CONTROL_MP0_RSMU_SLAVE_TIMEOUT_ENABLE_SHIFT  0
#define RSMU_RESET_TIMEOUT_CONTROL_MP0_RSMU_SLAVE_RESET_TIMEOUT_VALUE_SHIFT  1

#define RSMU_RESET_TIMEOUT_CONTROL_MP0_RSMU_SLAVE_TIMEOUT_ENABLE_MASK  0x00000001
#define RSMU_RESET_TIMEOUT_CONTROL_MP0_RSMU_SLAVE_RESET_TIMEOUT_VALUE_MASK  0x000001fe

#define RSMU_RESET_TIMEOUT_CONTROL_MP0_MASK \
      (RSMU_RESET_TIMEOUT_CONTROL_MP0_RSMU_SLAVE_TIMEOUT_ENABLE_MASK | \
      RSMU_RESET_TIMEOUT_CONTROL_MP0_RSMU_SLAVE_RESET_TIMEOUT_VALUE_MASK)

#define RSMU_RESET_TIMEOUT_CONTROL_MP0_DEFAULT 0x00000004

#define RSMU_RESET_TIMEOUT_CONTROL_MP0_GET_RSMU_SLAVE_TIMEOUT_ENABLE(rsmu_reset_timeout_control_mp0) \
      ((rsmu_reset_timeout_control_mp0 & RSMU_RESET_TIMEOUT_CONTROL_MP0_RSMU_SLAVE_TIMEOUT_ENABLE_MASK) >> RSMU_RESET_TIMEOUT_CONTROL_MP0_RSMU_SLAVE_TIMEOUT_ENABLE_SHIFT)
#define RSMU_RESET_TIMEOUT_CONTROL_MP0_GET_RSMU_SLAVE_RESET_TIMEOUT_VALUE(rsmu_reset_timeout_control_mp0) \
      ((rsmu_reset_timeout_control_mp0 & RSMU_RESET_TIMEOUT_CONTROL_MP0_RSMU_SLAVE_RESET_TIMEOUT_VALUE_MASK) >> RSMU_RESET_TIMEOUT_CONTROL_MP0_RSMU_SLAVE_RESET_TIMEOUT_VALUE_SHIFT)

#define RSMU_RESET_TIMEOUT_CONTROL_MP0_SET_RSMU_SLAVE_TIMEOUT_ENABLE(rsmu_reset_timeout_control_mp0_reg, rsmu_slave_timeout_enable) \
      rsmu_reset_timeout_control_mp0_reg = (rsmu_reset_timeout_control_mp0_reg & ~RSMU_RESET_TIMEOUT_CONTROL_MP0_RSMU_SLAVE_TIMEOUT_ENABLE_MASK) | (rsmu_slave_timeout_enable << RSMU_RESET_TIMEOUT_CONTROL_MP0_RSMU_SLAVE_TIMEOUT_ENABLE_SHIFT)
#define RSMU_RESET_TIMEOUT_CONTROL_MP0_SET_RSMU_SLAVE_RESET_TIMEOUT_VALUE(rsmu_reset_timeout_control_mp0_reg, rsmu_slave_reset_timeout_value) \
      rsmu_reset_timeout_control_mp0_reg = (rsmu_reset_timeout_control_mp0_reg & ~RSMU_RESET_TIMEOUT_CONTROL_MP0_RSMU_SLAVE_RESET_TIMEOUT_VALUE_MASK) | (rsmu_slave_reset_timeout_value << RSMU_RESET_TIMEOUT_CONTROL_MP0_RSMU_SLAVE_RESET_TIMEOUT_VALUE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_reset_timeout_control_mp0_t {
            unsigned int rsmu_slave_timeout_enable      : RSMU_RESET_TIMEOUT_CONTROL_MP0_RSMU_SLAVE_TIMEOUT_ENABLE_SIZE;
            unsigned int rsmu_slave_reset_timeout_value : RSMU_RESET_TIMEOUT_CONTROL_MP0_RSMU_SLAVE_RESET_TIMEOUT_VALUE_SIZE;
            unsigned int                                : 23;
      } rsmu_reset_timeout_control_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_reset_timeout_control_mp0_t {
            unsigned int                                : 23;
            unsigned int rsmu_slave_reset_timeout_value : RSMU_RESET_TIMEOUT_CONTROL_MP0_RSMU_SLAVE_RESET_TIMEOUT_VALUE_SIZE;
            unsigned int rsmu_slave_timeout_enable      : RSMU_RESET_TIMEOUT_CONTROL_MP0_RSMU_SLAVE_TIMEOUT_ENABLE_SIZE;
      } rsmu_reset_timeout_control_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_reset_timeout_control_mp0_t f;
} rsmu_reset_timeout_control_mp0_u;


/*
 * RSMU_SLAVE_ERROR_COUNTER_MP0 struct
 */

#define RSMU_SLAVE_ERROR_COUNTER_MP0_REG_SIZE         32
#define RSMU_SLAVE_ERROR_COUNTER_MP0_RSMU_SLAVE_ERROR_COUNTER_SIZE  8

#define RSMU_SLAVE_ERROR_COUNTER_MP0_RSMU_SLAVE_ERROR_COUNTER_SHIFT  0

#define RSMU_SLAVE_ERROR_COUNTER_MP0_RSMU_SLAVE_ERROR_COUNTER_MASK  0x000000ff

#define RSMU_SLAVE_ERROR_COUNTER_MP0_MASK \
      (RSMU_SLAVE_ERROR_COUNTER_MP0_RSMU_SLAVE_ERROR_COUNTER_MASK)

#define RSMU_SLAVE_ERROR_COUNTER_MP0_DEFAULT 0x00000000

#define RSMU_SLAVE_ERROR_COUNTER_MP0_GET_RSMU_SLAVE_ERROR_COUNTER(rsmu_slave_error_counter_mp0) \
      ((rsmu_slave_error_counter_mp0 & RSMU_SLAVE_ERROR_COUNTER_MP0_RSMU_SLAVE_ERROR_COUNTER_MASK) >> RSMU_SLAVE_ERROR_COUNTER_MP0_RSMU_SLAVE_ERROR_COUNTER_SHIFT)

#define RSMU_SLAVE_ERROR_COUNTER_MP0_SET_RSMU_SLAVE_ERROR_COUNTER(rsmu_slave_error_counter_mp0_reg, rsmu_slave_error_counter) \
      rsmu_slave_error_counter_mp0_reg = (rsmu_slave_error_counter_mp0_reg & ~RSMU_SLAVE_ERROR_COUNTER_MP0_RSMU_SLAVE_ERROR_COUNTER_MASK) | (rsmu_slave_error_counter << RSMU_SLAVE_ERROR_COUNTER_MP0_RSMU_SLAVE_ERROR_COUNTER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_slave_error_counter_mp0_t {
            unsigned int rsmu_slave_error_counter       : RSMU_SLAVE_ERROR_COUNTER_MP0_RSMU_SLAVE_ERROR_COUNTER_SIZE;
            unsigned int                                : 24;
      } rsmu_slave_error_counter_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_slave_error_counter_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_slave_error_counter       : RSMU_SLAVE_ERROR_COUNTER_MP0_RSMU_SLAVE_ERROR_COUNTER_SIZE;
      } rsmu_slave_error_counter_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_slave_error_counter_mp0_t f;
} rsmu_slave_error_counter_mp0_u;


/*
 * RSMU_DBG_MUX_CONTROL_MP0 struct
 */

#define RSMU_DBG_MUX_CONTROL_MP0_REG_SIZE         32
#define RSMU_DBG_MUX_CONTROL_MP0_RSMU_DBG_MUX_SELECT_SIZE  8
#define RSMU_DBG_MUX_CONTROL_MP0_RSMU_DBG_SIGNATURE_SIZE  8

#define RSMU_DBG_MUX_CONTROL_MP0_RSMU_DBG_MUX_SELECT_SHIFT  0
#define RSMU_DBG_MUX_CONTROL_MP0_RSMU_DBG_SIGNATURE_SHIFT  24

#define RSMU_DBG_MUX_CONTROL_MP0_RSMU_DBG_MUX_SELECT_MASK  0x000000ff
#define RSMU_DBG_MUX_CONTROL_MP0_RSMU_DBG_SIGNATURE_MASK  0xff000000

#define RSMU_DBG_MUX_CONTROL_MP0_MASK \
      (RSMU_DBG_MUX_CONTROL_MP0_RSMU_DBG_MUX_SELECT_MASK | \
      RSMU_DBG_MUX_CONTROL_MP0_RSMU_DBG_SIGNATURE_MASK)

#define RSMU_DBG_MUX_CONTROL_MP0_DEFAULT 0x5a0000ff

#define RSMU_DBG_MUX_CONTROL_MP0_GET_RSMU_DBG_MUX_SELECT(rsmu_dbg_mux_control_mp0) \
      ((rsmu_dbg_mux_control_mp0 & RSMU_DBG_MUX_CONTROL_MP0_RSMU_DBG_MUX_SELECT_MASK) >> RSMU_DBG_MUX_CONTROL_MP0_RSMU_DBG_MUX_SELECT_SHIFT)
#define RSMU_DBG_MUX_CONTROL_MP0_GET_RSMU_DBG_SIGNATURE(rsmu_dbg_mux_control_mp0) \
      ((rsmu_dbg_mux_control_mp0 & RSMU_DBG_MUX_CONTROL_MP0_RSMU_DBG_SIGNATURE_MASK) >> RSMU_DBG_MUX_CONTROL_MP0_RSMU_DBG_SIGNATURE_SHIFT)

#define RSMU_DBG_MUX_CONTROL_MP0_SET_RSMU_DBG_MUX_SELECT(rsmu_dbg_mux_control_mp0_reg, rsmu_dbg_mux_select) \
      rsmu_dbg_mux_control_mp0_reg = (rsmu_dbg_mux_control_mp0_reg & ~RSMU_DBG_MUX_CONTROL_MP0_RSMU_DBG_MUX_SELECT_MASK) | (rsmu_dbg_mux_select << RSMU_DBG_MUX_CONTROL_MP0_RSMU_DBG_MUX_SELECT_SHIFT)
#define RSMU_DBG_MUX_CONTROL_MP0_SET_RSMU_DBG_SIGNATURE(rsmu_dbg_mux_control_mp0_reg, rsmu_dbg_signature) \
      rsmu_dbg_mux_control_mp0_reg = (rsmu_dbg_mux_control_mp0_reg & ~RSMU_DBG_MUX_CONTROL_MP0_RSMU_DBG_SIGNATURE_MASK) | (rsmu_dbg_signature << RSMU_DBG_MUX_CONTROL_MP0_RSMU_DBG_SIGNATURE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_dbg_mux_control_mp0_t {
            unsigned int rsmu_dbg_mux_select            : RSMU_DBG_MUX_CONTROL_MP0_RSMU_DBG_MUX_SELECT_SIZE;
            unsigned int                                : 16;
            unsigned int rsmu_dbg_signature             : RSMU_DBG_MUX_CONTROL_MP0_RSMU_DBG_SIGNATURE_SIZE;
      } rsmu_dbg_mux_control_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_dbg_mux_control_mp0_t {
            unsigned int rsmu_dbg_signature             : RSMU_DBG_MUX_CONTROL_MP0_RSMU_DBG_SIGNATURE_SIZE;
            unsigned int                                : 16;
            unsigned int rsmu_dbg_mux_select            : RSMU_DBG_MUX_CONTROL_MP0_RSMU_DBG_MUX_SELECT_SIZE;
      } rsmu_dbg_mux_control_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_dbg_mux_control_mp0_t f;
} rsmu_dbg_mux_control_mp0_u;


/*
 * RSMU_AXI_MASTER_TRAN_COUNTER_MP0 struct
 */

#define RSMU_AXI_MASTER_TRAN_COUNTER_MP0_REG_SIZE         32
#define RSMU_AXI_MASTER_TRAN_COUNTER_MP0_RSMU_AXI_MASTER_WRITE_COUNTER_SIZE  6
#define RSMU_AXI_MASTER_TRAN_COUNTER_MP0_RSMU_AXI_MASTER_READ_COUNTER_SIZE  8

#define RSMU_AXI_MASTER_TRAN_COUNTER_MP0_RSMU_AXI_MASTER_WRITE_COUNTER_SHIFT  0
#define RSMU_AXI_MASTER_TRAN_COUNTER_MP0_RSMU_AXI_MASTER_READ_COUNTER_SHIFT  6

#define RSMU_AXI_MASTER_TRAN_COUNTER_MP0_RSMU_AXI_MASTER_WRITE_COUNTER_MASK  0x0000003f
#define RSMU_AXI_MASTER_TRAN_COUNTER_MP0_RSMU_AXI_MASTER_READ_COUNTER_MASK  0x00003fc0

#define RSMU_AXI_MASTER_TRAN_COUNTER_MP0_MASK \
      (RSMU_AXI_MASTER_TRAN_COUNTER_MP0_RSMU_AXI_MASTER_WRITE_COUNTER_MASK | \
      RSMU_AXI_MASTER_TRAN_COUNTER_MP0_RSMU_AXI_MASTER_READ_COUNTER_MASK)

#define RSMU_AXI_MASTER_TRAN_COUNTER_MP0_DEFAULT 0x00000000

#define RSMU_AXI_MASTER_TRAN_COUNTER_MP0_GET_RSMU_AXI_MASTER_WRITE_COUNTER(rsmu_axi_master_tran_counter_mp0) \
      ((rsmu_axi_master_tran_counter_mp0 & RSMU_AXI_MASTER_TRAN_COUNTER_MP0_RSMU_AXI_MASTER_WRITE_COUNTER_MASK) >> RSMU_AXI_MASTER_TRAN_COUNTER_MP0_RSMU_AXI_MASTER_WRITE_COUNTER_SHIFT)
#define RSMU_AXI_MASTER_TRAN_COUNTER_MP0_GET_RSMU_AXI_MASTER_READ_COUNTER(rsmu_axi_master_tran_counter_mp0) \
      ((rsmu_axi_master_tran_counter_mp0 & RSMU_AXI_MASTER_TRAN_COUNTER_MP0_RSMU_AXI_MASTER_READ_COUNTER_MASK) >> RSMU_AXI_MASTER_TRAN_COUNTER_MP0_RSMU_AXI_MASTER_READ_COUNTER_SHIFT)

#define RSMU_AXI_MASTER_TRAN_COUNTER_MP0_SET_RSMU_AXI_MASTER_WRITE_COUNTER(rsmu_axi_master_tran_counter_mp0_reg, rsmu_axi_master_write_counter) \
      rsmu_axi_master_tran_counter_mp0_reg = (rsmu_axi_master_tran_counter_mp0_reg & ~RSMU_AXI_MASTER_TRAN_COUNTER_MP0_RSMU_AXI_MASTER_WRITE_COUNTER_MASK) | (rsmu_axi_master_write_counter << RSMU_AXI_MASTER_TRAN_COUNTER_MP0_RSMU_AXI_MASTER_WRITE_COUNTER_SHIFT)
#define RSMU_AXI_MASTER_TRAN_COUNTER_MP0_SET_RSMU_AXI_MASTER_READ_COUNTER(rsmu_axi_master_tran_counter_mp0_reg, rsmu_axi_master_read_counter) \
      rsmu_axi_master_tran_counter_mp0_reg = (rsmu_axi_master_tran_counter_mp0_reg & ~RSMU_AXI_MASTER_TRAN_COUNTER_MP0_RSMU_AXI_MASTER_READ_COUNTER_MASK) | (rsmu_axi_master_read_counter << RSMU_AXI_MASTER_TRAN_COUNTER_MP0_RSMU_AXI_MASTER_READ_COUNTER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_axi_master_tran_counter_mp0_t {
            unsigned int rsmu_axi_master_write_counter  : RSMU_AXI_MASTER_TRAN_COUNTER_MP0_RSMU_AXI_MASTER_WRITE_COUNTER_SIZE;
            unsigned int rsmu_axi_master_read_counter   : RSMU_AXI_MASTER_TRAN_COUNTER_MP0_RSMU_AXI_MASTER_READ_COUNTER_SIZE;
            unsigned int                                : 18;
      } rsmu_axi_master_tran_counter_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_axi_master_tran_counter_mp0_t {
            unsigned int                                : 18;
            unsigned int rsmu_axi_master_read_counter   : RSMU_AXI_MASTER_TRAN_COUNTER_MP0_RSMU_AXI_MASTER_READ_COUNTER_SIZE;
            unsigned int rsmu_axi_master_write_counter  : RSMU_AXI_MASTER_TRAN_COUNTER_MP0_RSMU_AXI_MASTER_WRITE_COUNTER_SIZE;
      } rsmu_axi_master_tran_counter_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_axi_master_tran_counter_mp0_t f;
} rsmu_axi_master_tran_counter_mp0_u;


/*
 * RSMU_GOLDEN_COUNTER_0_MP0 struct
 */

#define RSMU_GOLDEN_COUNTER_0_MP0_REG_SIZE         32
#define RSMU_GOLDEN_COUNTER_0_MP0_RSMU_GOLDEN_COUNTER_0_SIZE  32

#define RSMU_GOLDEN_COUNTER_0_MP0_RSMU_GOLDEN_COUNTER_0_SHIFT  0

#define RSMU_GOLDEN_COUNTER_0_MP0_RSMU_GOLDEN_COUNTER_0_MASK  0xffffffff

#define RSMU_GOLDEN_COUNTER_0_MP0_MASK \
      (RSMU_GOLDEN_COUNTER_0_MP0_RSMU_GOLDEN_COUNTER_0_MASK)

#define RSMU_GOLDEN_COUNTER_0_MP0_DEFAULT 0x00000000

#define RSMU_GOLDEN_COUNTER_0_MP0_GET_RSMU_GOLDEN_COUNTER_0(rsmu_golden_counter_0_mp0) \
      ((rsmu_golden_counter_0_mp0 & RSMU_GOLDEN_COUNTER_0_MP0_RSMU_GOLDEN_COUNTER_0_MASK) >> RSMU_GOLDEN_COUNTER_0_MP0_RSMU_GOLDEN_COUNTER_0_SHIFT)

#define RSMU_GOLDEN_COUNTER_0_MP0_SET_RSMU_GOLDEN_COUNTER_0(rsmu_golden_counter_0_mp0_reg, rsmu_golden_counter_0) \
      rsmu_golden_counter_0_mp0_reg = (rsmu_golden_counter_0_mp0_reg & ~RSMU_GOLDEN_COUNTER_0_MP0_RSMU_GOLDEN_COUNTER_0_MASK) | (rsmu_golden_counter_0 << RSMU_GOLDEN_COUNTER_0_MP0_RSMU_GOLDEN_COUNTER_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_golden_counter_0_mp0_t {
            unsigned int rsmu_golden_counter_0          : RSMU_GOLDEN_COUNTER_0_MP0_RSMU_GOLDEN_COUNTER_0_SIZE;
      } rsmu_golden_counter_0_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_golden_counter_0_mp0_t {
            unsigned int rsmu_golden_counter_0          : RSMU_GOLDEN_COUNTER_0_MP0_RSMU_GOLDEN_COUNTER_0_SIZE;
      } rsmu_golden_counter_0_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_golden_counter_0_mp0_t f;
} rsmu_golden_counter_0_mp0_u;


/*
 * RSMU_GOLDEN_COUNTER_1_MP0 struct
 */

#define RSMU_GOLDEN_COUNTER_1_MP0_REG_SIZE         32
#define RSMU_GOLDEN_COUNTER_1_MP0_RSMU_GOLDEN_COUNTER_1_SIZE  24

#define RSMU_GOLDEN_COUNTER_1_MP0_RSMU_GOLDEN_COUNTER_1_SHIFT  0

#define RSMU_GOLDEN_COUNTER_1_MP0_RSMU_GOLDEN_COUNTER_1_MASK  0x00ffffff

#define RSMU_GOLDEN_COUNTER_1_MP0_MASK \
      (RSMU_GOLDEN_COUNTER_1_MP0_RSMU_GOLDEN_COUNTER_1_MASK)

#define RSMU_GOLDEN_COUNTER_1_MP0_DEFAULT 0x00000000

#define RSMU_GOLDEN_COUNTER_1_MP0_GET_RSMU_GOLDEN_COUNTER_1(rsmu_golden_counter_1_mp0) \
      ((rsmu_golden_counter_1_mp0 & RSMU_GOLDEN_COUNTER_1_MP0_RSMU_GOLDEN_COUNTER_1_MASK) >> RSMU_GOLDEN_COUNTER_1_MP0_RSMU_GOLDEN_COUNTER_1_SHIFT)

#define RSMU_GOLDEN_COUNTER_1_MP0_SET_RSMU_GOLDEN_COUNTER_1(rsmu_golden_counter_1_mp0_reg, rsmu_golden_counter_1) \
      rsmu_golden_counter_1_mp0_reg = (rsmu_golden_counter_1_mp0_reg & ~RSMU_GOLDEN_COUNTER_1_MP0_RSMU_GOLDEN_COUNTER_1_MASK) | (rsmu_golden_counter_1 << RSMU_GOLDEN_COUNTER_1_MP0_RSMU_GOLDEN_COUNTER_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_golden_counter_1_mp0_t {
            unsigned int rsmu_golden_counter_1          : RSMU_GOLDEN_COUNTER_1_MP0_RSMU_GOLDEN_COUNTER_1_SIZE;
            unsigned int                                : 8;
      } rsmu_golden_counter_1_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_golden_counter_1_mp0_t {
            unsigned int                                : 8;
            unsigned int rsmu_golden_counter_1          : RSMU_GOLDEN_COUNTER_1_MP0_RSMU_GOLDEN_COUNTER_1_SIZE;
      } rsmu_golden_counter_1_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_golden_counter_1_mp0_t f;
} rsmu_golden_counter_1_mp0_u;


/*
 * RSMU_IP_CLOCK_GATE_CNTL_MP0 struct
 */

#define RSMU_IP_CLOCK_GATE_CNTL_MP0_REG_SIZE         32
#define RSMU_IP_CLOCK_GATE_CNTL_MP0_RSMU_IP_MGCG_ENABLE_SIZE  1
#define RSMU_IP_CLOCK_GATE_CNTL_MP0_RSMU_IP_FORCE_CLKOFF_SIZE  1

#define RSMU_IP_CLOCK_GATE_CNTL_MP0_RSMU_IP_MGCG_ENABLE_SHIFT  0
#define RSMU_IP_CLOCK_GATE_CNTL_MP0_RSMU_IP_FORCE_CLKOFF_SHIFT  31

#define RSMU_IP_CLOCK_GATE_CNTL_MP0_RSMU_IP_MGCG_ENABLE_MASK  0x00000001
#define RSMU_IP_CLOCK_GATE_CNTL_MP0_RSMU_IP_FORCE_CLKOFF_MASK  0x80000000

#define RSMU_IP_CLOCK_GATE_CNTL_MP0_MASK \
      (RSMU_IP_CLOCK_GATE_CNTL_MP0_RSMU_IP_MGCG_ENABLE_MASK | \
      RSMU_IP_CLOCK_GATE_CNTL_MP0_RSMU_IP_FORCE_CLKOFF_MASK)

#define RSMU_IP_CLOCK_GATE_CNTL_MP0_DEFAULT 0x00000000

#define RSMU_IP_CLOCK_GATE_CNTL_MP0_GET_RSMU_IP_MGCG_ENABLE(rsmu_ip_clock_gate_cntl_mp0) \
      ((rsmu_ip_clock_gate_cntl_mp0 & RSMU_IP_CLOCK_GATE_CNTL_MP0_RSMU_IP_MGCG_ENABLE_MASK) >> RSMU_IP_CLOCK_GATE_CNTL_MP0_RSMU_IP_MGCG_ENABLE_SHIFT)
#define RSMU_IP_CLOCK_GATE_CNTL_MP0_GET_RSMU_IP_FORCE_CLKOFF(rsmu_ip_clock_gate_cntl_mp0) \
      ((rsmu_ip_clock_gate_cntl_mp0 & RSMU_IP_CLOCK_GATE_CNTL_MP0_RSMU_IP_FORCE_CLKOFF_MASK) >> RSMU_IP_CLOCK_GATE_CNTL_MP0_RSMU_IP_FORCE_CLKOFF_SHIFT)

#define RSMU_IP_CLOCK_GATE_CNTL_MP0_SET_RSMU_IP_MGCG_ENABLE(rsmu_ip_clock_gate_cntl_mp0_reg, rsmu_ip_mgcg_enable) \
      rsmu_ip_clock_gate_cntl_mp0_reg = (rsmu_ip_clock_gate_cntl_mp0_reg & ~RSMU_IP_CLOCK_GATE_CNTL_MP0_RSMU_IP_MGCG_ENABLE_MASK) | (rsmu_ip_mgcg_enable << RSMU_IP_CLOCK_GATE_CNTL_MP0_RSMU_IP_MGCG_ENABLE_SHIFT)
#define RSMU_IP_CLOCK_GATE_CNTL_MP0_SET_RSMU_IP_FORCE_CLKOFF(rsmu_ip_clock_gate_cntl_mp0_reg, rsmu_ip_force_clkoff) \
      rsmu_ip_clock_gate_cntl_mp0_reg = (rsmu_ip_clock_gate_cntl_mp0_reg & ~RSMU_IP_CLOCK_GATE_CNTL_MP0_RSMU_IP_FORCE_CLKOFF_MASK) | (rsmu_ip_force_clkoff << RSMU_IP_CLOCK_GATE_CNTL_MP0_RSMU_IP_FORCE_CLKOFF_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_ip_clock_gate_cntl_mp0_t {
            unsigned int rsmu_ip_mgcg_enable            : RSMU_IP_CLOCK_GATE_CNTL_MP0_RSMU_IP_MGCG_ENABLE_SIZE;
            unsigned int                                : 30;
            unsigned int rsmu_ip_force_clkoff           : RSMU_IP_CLOCK_GATE_CNTL_MP0_RSMU_IP_FORCE_CLKOFF_SIZE;
      } rsmu_ip_clock_gate_cntl_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_ip_clock_gate_cntl_mp0_t {
            unsigned int rsmu_ip_force_clkoff           : RSMU_IP_CLOCK_GATE_CNTL_MP0_RSMU_IP_FORCE_CLKOFF_SIZE;
            unsigned int                                : 30;
            unsigned int rsmu_ip_mgcg_enable            : RSMU_IP_CLOCK_GATE_CNTL_MP0_RSMU_IP_MGCG_ENABLE_SIZE;
      } rsmu_ip_clock_gate_cntl_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_ip_clock_gate_cntl_mp0_t f;
} rsmu_ip_clock_gate_cntl_mp0_u;


/*
 * RSMU_MSMU_FETCH_FUSE_MP0 struct
 */

#define RSMU_MSMU_FETCH_FUSE_MP0_REG_SIZE         32
#define RSMU_MSMU_FETCH_FUSE_MP0_RSMU_FUSE_UPPER_256KB_H_OFFSET_SIZE  2
#define RSMU_MSMU_FETCH_FUSE_MP0_RSMU_FUSE_APERTURE_ID_H_OFFSET_SIZE  12

#define RSMU_MSMU_FETCH_FUSE_MP0_RSMU_FUSE_UPPER_256KB_H_OFFSET_SHIFT  0
#define RSMU_MSMU_FETCH_FUSE_MP0_RSMU_FUSE_APERTURE_ID_H_OFFSET_SHIFT  2

#define RSMU_MSMU_FETCH_FUSE_MP0_RSMU_FUSE_UPPER_256KB_H_OFFSET_MASK  0x00000003
#define RSMU_MSMU_FETCH_FUSE_MP0_RSMU_FUSE_APERTURE_ID_H_OFFSET_MASK  0x00003ffc

#define RSMU_MSMU_FETCH_FUSE_MP0_MASK \
      (RSMU_MSMU_FETCH_FUSE_MP0_RSMU_FUSE_UPPER_256KB_H_OFFSET_MASK | \
      RSMU_MSMU_FETCH_FUSE_MP0_RSMU_FUSE_APERTURE_ID_H_OFFSET_MASK)

#define RSMU_MSMU_FETCH_FUSE_MP0_DEFAULT 0x00000001

#define RSMU_MSMU_FETCH_FUSE_MP0_GET_RSMU_FUSE_UPPER_256KB_H_OFFSET(rsmu_msmu_fetch_fuse_mp0) \
      ((rsmu_msmu_fetch_fuse_mp0 & RSMU_MSMU_FETCH_FUSE_MP0_RSMU_FUSE_UPPER_256KB_H_OFFSET_MASK) >> RSMU_MSMU_FETCH_FUSE_MP0_RSMU_FUSE_UPPER_256KB_H_OFFSET_SHIFT)
#define RSMU_MSMU_FETCH_FUSE_MP0_GET_RSMU_FUSE_APERTURE_ID_H_OFFSET(rsmu_msmu_fetch_fuse_mp0) \
      ((rsmu_msmu_fetch_fuse_mp0 & RSMU_MSMU_FETCH_FUSE_MP0_RSMU_FUSE_APERTURE_ID_H_OFFSET_MASK) >> RSMU_MSMU_FETCH_FUSE_MP0_RSMU_FUSE_APERTURE_ID_H_OFFSET_SHIFT)

#define RSMU_MSMU_FETCH_FUSE_MP0_SET_RSMU_FUSE_UPPER_256KB_H_OFFSET(rsmu_msmu_fetch_fuse_mp0_reg, rsmu_fuse_upper_256kb_h_offset) \
      rsmu_msmu_fetch_fuse_mp0_reg = (rsmu_msmu_fetch_fuse_mp0_reg & ~RSMU_MSMU_FETCH_FUSE_MP0_RSMU_FUSE_UPPER_256KB_H_OFFSET_MASK) | (rsmu_fuse_upper_256kb_h_offset << RSMU_MSMU_FETCH_FUSE_MP0_RSMU_FUSE_UPPER_256KB_H_OFFSET_SHIFT)
#define RSMU_MSMU_FETCH_FUSE_MP0_SET_RSMU_FUSE_APERTURE_ID_H_OFFSET(rsmu_msmu_fetch_fuse_mp0_reg, rsmu_fuse_aperture_id_h_offset) \
      rsmu_msmu_fetch_fuse_mp0_reg = (rsmu_msmu_fetch_fuse_mp0_reg & ~RSMU_MSMU_FETCH_FUSE_MP0_RSMU_FUSE_APERTURE_ID_H_OFFSET_MASK) | (rsmu_fuse_aperture_id_h_offset << RSMU_MSMU_FETCH_FUSE_MP0_RSMU_FUSE_APERTURE_ID_H_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_msmu_fetch_fuse_mp0_t {
            unsigned int rsmu_fuse_upper_256kb_h_offset : RSMU_MSMU_FETCH_FUSE_MP0_RSMU_FUSE_UPPER_256KB_H_OFFSET_SIZE;
            unsigned int rsmu_fuse_aperture_id_h_offset : RSMU_MSMU_FETCH_FUSE_MP0_RSMU_FUSE_APERTURE_ID_H_OFFSET_SIZE;
            unsigned int                                : 18;
      } rsmu_msmu_fetch_fuse_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_msmu_fetch_fuse_mp0_t {
            unsigned int                                : 18;
            unsigned int rsmu_fuse_aperture_id_h_offset : RSMU_MSMU_FETCH_FUSE_MP0_RSMU_FUSE_APERTURE_ID_H_OFFSET_SIZE;
            unsigned int rsmu_fuse_upper_256kb_h_offset : RSMU_MSMU_FETCH_FUSE_MP0_RSMU_FUSE_UPPER_256KB_H_OFFSET_SIZE;
      } rsmu_msmu_fetch_fuse_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_msmu_fetch_fuse_mp0_t f;
} rsmu_msmu_fetch_fuse_mp0_u;


/*
 * RSMU_STRAP_STATUS_MP0 struct
 */

#define RSMU_STRAP_STATUS_MP0_REG_SIZE         32
#define RSMU_STRAP_STATUS_MP0_RSMU_PUBLIC_FUSE_STATUS_SIZE  1
#define RSMU_STRAP_STATUS_MP0_RSMU_SECURITY_FUSE_STATUS_SIZE  1
#define RSMU_STRAP_STATUS_MP0_RSMU_SMS_FUSE_STATUS_SIZE  1
#define RSMU_STRAP_STATUS_MP0_RSMU_ROM_STRAP_STATUS_SIZE  1

#define RSMU_STRAP_STATUS_MP0_RSMU_PUBLIC_FUSE_STATUS_SHIFT  0
#define RSMU_STRAP_STATUS_MP0_RSMU_SECURITY_FUSE_STATUS_SHIFT  8
#define RSMU_STRAP_STATUS_MP0_RSMU_SMS_FUSE_STATUS_SHIFT  16
#define RSMU_STRAP_STATUS_MP0_RSMU_ROM_STRAP_STATUS_SHIFT  24

#define RSMU_STRAP_STATUS_MP0_RSMU_PUBLIC_FUSE_STATUS_MASK  0x00000001
#define RSMU_STRAP_STATUS_MP0_RSMU_SECURITY_FUSE_STATUS_MASK  0x00000100
#define RSMU_STRAP_STATUS_MP0_RSMU_SMS_FUSE_STATUS_MASK  0x00010000
#define RSMU_STRAP_STATUS_MP0_RSMU_ROM_STRAP_STATUS_MASK  0x01000000

#define RSMU_STRAP_STATUS_MP0_MASK \
      (RSMU_STRAP_STATUS_MP0_RSMU_PUBLIC_FUSE_STATUS_MASK | \
      RSMU_STRAP_STATUS_MP0_RSMU_SECURITY_FUSE_STATUS_MASK | \
      RSMU_STRAP_STATUS_MP0_RSMU_SMS_FUSE_STATUS_MASK | \
      RSMU_STRAP_STATUS_MP0_RSMU_ROM_STRAP_STATUS_MASK)

#define RSMU_STRAP_STATUS_MP0_DEFAULT  0x00000000

#define RSMU_STRAP_STATUS_MP0_GET_RSMU_PUBLIC_FUSE_STATUS(rsmu_strap_status_mp0) \
      ((rsmu_strap_status_mp0 & RSMU_STRAP_STATUS_MP0_RSMU_PUBLIC_FUSE_STATUS_MASK) >> RSMU_STRAP_STATUS_MP0_RSMU_PUBLIC_FUSE_STATUS_SHIFT)
#define RSMU_STRAP_STATUS_MP0_GET_RSMU_SECURITY_FUSE_STATUS(rsmu_strap_status_mp0) \
      ((rsmu_strap_status_mp0 & RSMU_STRAP_STATUS_MP0_RSMU_SECURITY_FUSE_STATUS_MASK) >> RSMU_STRAP_STATUS_MP0_RSMU_SECURITY_FUSE_STATUS_SHIFT)
#define RSMU_STRAP_STATUS_MP0_GET_RSMU_SMS_FUSE_STATUS(rsmu_strap_status_mp0) \
      ((rsmu_strap_status_mp0 & RSMU_STRAP_STATUS_MP0_RSMU_SMS_FUSE_STATUS_MASK) >> RSMU_STRAP_STATUS_MP0_RSMU_SMS_FUSE_STATUS_SHIFT)
#define RSMU_STRAP_STATUS_MP0_GET_RSMU_ROM_STRAP_STATUS(rsmu_strap_status_mp0) \
      ((rsmu_strap_status_mp0 & RSMU_STRAP_STATUS_MP0_RSMU_ROM_STRAP_STATUS_MASK) >> RSMU_STRAP_STATUS_MP0_RSMU_ROM_STRAP_STATUS_SHIFT)

#define RSMU_STRAP_STATUS_MP0_SET_RSMU_PUBLIC_FUSE_STATUS(rsmu_strap_status_mp0_reg, rsmu_public_fuse_status) \
      rsmu_strap_status_mp0_reg = (rsmu_strap_status_mp0_reg & ~RSMU_STRAP_STATUS_MP0_RSMU_PUBLIC_FUSE_STATUS_MASK) | (rsmu_public_fuse_status << RSMU_STRAP_STATUS_MP0_RSMU_PUBLIC_FUSE_STATUS_SHIFT)
#define RSMU_STRAP_STATUS_MP0_SET_RSMU_SECURITY_FUSE_STATUS(rsmu_strap_status_mp0_reg, rsmu_security_fuse_status) \
      rsmu_strap_status_mp0_reg = (rsmu_strap_status_mp0_reg & ~RSMU_STRAP_STATUS_MP0_RSMU_SECURITY_FUSE_STATUS_MASK) | (rsmu_security_fuse_status << RSMU_STRAP_STATUS_MP0_RSMU_SECURITY_FUSE_STATUS_SHIFT)
#define RSMU_STRAP_STATUS_MP0_SET_RSMU_SMS_FUSE_STATUS(rsmu_strap_status_mp0_reg, rsmu_sms_fuse_status) \
      rsmu_strap_status_mp0_reg = (rsmu_strap_status_mp0_reg & ~RSMU_STRAP_STATUS_MP0_RSMU_SMS_FUSE_STATUS_MASK) | (rsmu_sms_fuse_status << RSMU_STRAP_STATUS_MP0_RSMU_SMS_FUSE_STATUS_SHIFT)
#define RSMU_STRAP_STATUS_MP0_SET_RSMU_ROM_STRAP_STATUS(rsmu_strap_status_mp0_reg, rsmu_rom_strap_status) \
      rsmu_strap_status_mp0_reg = (rsmu_strap_status_mp0_reg & ~RSMU_STRAP_STATUS_MP0_RSMU_ROM_STRAP_STATUS_MASK) | (rsmu_rom_strap_status << RSMU_STRAP_STATUS_MP0_RSMU_ROM_STRAP_STATUS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_strap_status_mp0_t {
            unsigned int rsmu_public_fuse_status        : RSMU_STRAP_STATUS_MP0_RSMU_PUBLIC_FUSE_STATUS_SIZE;
            unsigned int                                : 7;
            unsigned int rsmu_security_fuse_status      : RSMU_STRAP_STATUS_MP0_RSMU_SECURITY_FUSE_STATUS_SIZE;
            unsigned int                                : 7;
            unsigned int rsmu_sms_fuse_status           : RSMU_STRAP_STATUS_MP0_RSMU_SMS_FUSE_STATUS_SIZE;
            unsigned int                                : 7;
            unsigned int rsmu_rom_strap_status          : RSMU_STRAP_STATUS_MP0_RSMU_ROM_STRAP_STATUS_SIZE;
            unsigned int                                : 7;
      } rsmu_strap_status_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_strap_status_mp0_t {
            unsigned int                                : 7;
            unsigned int rsmu_rom_strap_status          : RSMU_STRAP_STATUS_MP0_RSMU_ROM_STRAP_STATUS_SIZE;
            unsigned int                                : 7;
            unsigned int rsmu_sms_fuse_status           : RSMU_STRAP_STATUS_MP0_RSMU_SMS_FUSE_STATUS_SIZE;
            unsigned int                                : 7;
            unsigned int rsmu_security_fuse_status      : RSMU_STRAP_STATUS_MP0_RSMU_SECURITY_FUSE_STATUS_SIZE;
            unsigned int                                : 7;
            unsigned int rsmu_public_fuse_status        : RSMU_STRAP_STATUS_MP0_RSMU_PUBLIC_FUSE_STATUS_SIZE;
      } rsmu_strap_status_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_strap_status_mp0_t f;
} rsmu_strap_status_mp0_u;


/*
 * RSMU_SMS_FUSE_CLEAR_SET0_MP0 struct
 */

#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_REG_SIZE         32
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP0_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP1_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP2_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP3_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP4_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP5_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP6_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP7_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP8_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP9_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP10_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP11_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP12_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP13_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP14_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP15_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP16_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP17_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP18_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP19_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP20_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP21_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP22_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP23_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP24_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP25_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP26_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP27_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP28_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP29_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP30_SIZE  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP31_SIZE  1

#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP0_SHIFT  0
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP1_SHIFT  1
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP2_SHIFT  2
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP3_SHIFT  3
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP4_SHIFT  4
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP5_SHIFT  5
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP6_SHIFT  6
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP7_SHIFT  7
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP8_SHIFT  8
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP9_SHIFT  9
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP10_SHIFT  10
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP11_SHIFT  11
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP12_SHIFT  12
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP13_SHIFT  13
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP14_SHIFT  14
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP15_SHIFT  15
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP16_SHIFT  16
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP17_SHIFT  17
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP18_SHIFT  18
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP19_SHIFT  19
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP20_SHIFT  20
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP21_SHIFT  21
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP22_SHIFT  22
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP23_SHIFT  23
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP24_SHIFT  24
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP25_SHIFT  25
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP26_SHIFT  26
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP27_SHIFT  27
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP28_SHIFT  28
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP29_SHIFT  29
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP30_SHIFT  30
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP31_SHIFT  31

#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP0_MASK  0x00000001
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP1_MASK  0x00000002
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP2_MASK  0x00000004
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP3_MASK  0x00000008
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP4_MASK  0x00000010
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP5_MASK  0x00000020
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP6_MASK  0x00000040
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP7_MASK  0x00000080
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP8_MASK  0x00000100
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP9_MASK  0x00000200
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP10_MASK  0x00000400
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP11_MASK  0x00000800
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP12_MASK  0x00001000
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP13_MASK  0x00002000
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP14_MASK  0x00004000
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP15_MASK  0x00008000
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP16_MASK  0x00010000
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP17_MASK  0x00020000
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP18_MASK  0x00040000
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP19_MASK  0x00080000
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP20_MASK  0x00100000
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP21_MASK  0x00200000
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP22_MASK  0x00400000
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP23_MASK  0x00800000
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP24_MASK  0x01000000
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP25_MASK  0x02000000
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP26_MASK  0x04000000
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP27_MASK  0x08000000
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP28_MASK  0x10000000
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP29_MASK  0x20000000
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP30_MASK  0x40000000
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP31_MASK  0x80000000

#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_MASK \
      (RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP0_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP1_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP2_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP3_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP4_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP5_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP6_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP7_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP8_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP9_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP10_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP11_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP12_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP13_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP14_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP15_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP16_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP17_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP18_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP19_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP20_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP21_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP22_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP23_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP24_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP25_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP26_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP27_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP28_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP29_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP30_MASK | \
      RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP31_MASK)

#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_DEFAULT 0x00000000

#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP0(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP0_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP0_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP1(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP1_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP1_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP2(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP2_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP2_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP3(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP3_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP3_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP4(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP4_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP4_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP5(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP5_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP5_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP6(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP6_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP6_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP7(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP7_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP7_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP8(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP8_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP8_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP9(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP9_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP9_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP10(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP10_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP10_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP11(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP11_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP11_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP12(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP12_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP12_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP13(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP13_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP13_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP14(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP14_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP14_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP15(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP15_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP15_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP16(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP16_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP16_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP17(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP17_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP17_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP18(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP18_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP18_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP19(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP19_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP19_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP20(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP20_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP20_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP21(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP21_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP21_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP22(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP22_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP22_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP23(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP23_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP23_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP24(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP24_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP24_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP25(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP25_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP25_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP26(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP26_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP26_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP27(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP27_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP27_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP28(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP28_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP28_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP29(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP29_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP29_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP30(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP30_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP30_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_GET_RSMU_SMS_FUSE_CLEAR_GRP31(rsmu_sms_fuse_clear_set0_mp0) \
      ((rsmu_sms_fuse_clear_set0_mp0 & RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP31_MASK) >> RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP31_SHIFT)

#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP0(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp0) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP0_MASK) | (rsmu_sms_fuse_clear_grp0 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP0_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP1(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp1) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP1_MASK) | (rsmu_sms_fuse_clear_grp1 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP1_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP2(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp2) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP2_MASK) | (rsmu_sms_fuse_clear_grp2 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP2_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP3(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp3) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP3_MASK) | (rsmu_sms_fuse_clear_grp3 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP3_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP4(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp4) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP4_MASK) | (rsmu_sms_fuse_clear_grp4 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP4_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP5(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp5) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP5_MASK) | (rsmu_sms_fuse_clear_grp5 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP5_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP6(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp6) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP6_MASK) | (rsmu_sms_fuse_clear_grp6 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP6_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP7(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp7) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP7_MASK) | (rsmu_sms_fuse_clear_grp7 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP7_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP8(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp8) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP8_MASK) | (rsmu_sms_fuse_clear_grp8 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP8_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP9(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp9) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP9_MASK) | (rsmu_sms_fuse_clear_grp9 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP9_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP10(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp10) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP10_MASK) | (rsmu_sms_fuse_clear_grp10 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP10_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP11(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp11) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP11_MASK) | (rsmu_sms_fuse_clear_grp11 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP11_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP12(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp12) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP12_MASK) | (rsmu_sms_fuse_clear_grp12 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP12_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP13(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp13) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP13_MASK) | (rsmu_sms_fuse_clear_grp13 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP13_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP14(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp14) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP14_MASK) | (rsmu_sms_fuse_clear_grp14 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP14_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP15(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp15) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP15_MASK) | (rsmu_sms_fuse_clear_grp15 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP15_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP16(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp16) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP16_MASK) | (rsmu_sms_fuse_clear_grp16 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP16_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP17(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp17) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP17_MASK) | (rsmu_sms_fuse_clear_grp17 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP17_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP18(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp18) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP18_MASK) | (rsmu_sms_fuse_clear_grp18 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP18_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP19(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp19) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP19_MASK) | (rsmu_sms_fuse_clear_grp19 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP19_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP20(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp20) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP20_MASK) | (rsmu_sms_fuse_clear_grp20 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP20_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP21(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp21) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP21_MASK) | (rsmu_sms_fuse_clear_grp21 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP21_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP22(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp22) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP22_MASK) | (rsmu_sms_fuse_clear_grp22 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP22_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP23(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp23) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP23_MASK) | (rsmu_sms_fuse_clear_grp23 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP23_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP24(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp24) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP24_MASK) | (rsmu_sms_fuse_clear_grp24 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP24_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP25(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp25) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP25_MASK) | (rsmu_sms_fuse_clear_grp25 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP25_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP26(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp26) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP26_MASK) | (rsmu_sms_fuse_clear_grp26 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP26_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP27(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp27) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP27_MASK) | (rsmu_sms_fuse_clear_grp27 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP27_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP28(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp28) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP28_MASK) | (rsmu_sms_fuse_clear_grp28 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP28_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP29(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp29) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP29_MASK) | (rsmu_sms_fuse_clear_grp29 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP29_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP30(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp30) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP30_MASK) | (rsmu_sms_fuse_clear_grp30 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP30_SHIFT)
#define RSMU_SMS_FUSE_CLEAR_SET0_MP0_SET_RSMU_SMS_FUSE_CLEAR_GRP31(rsmu_sms_fuse_clear_set0_mp0_reg, rsmu_sms_fuse_clear_grp31) \
      rsmu_sms_fuse_clear_set0_mp0_reg = (rsmu_sms_fuse_clear_set0_mp0_reg & ~RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP31_MASK) | (rsmu_sms_fuse_clear_grp31 << RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP31_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sms_fuse_clear_set0_mp0_t {
            unsigned int rsmu_sms_fuse_clear_grp0       : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP0_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp1       : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP1_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp2       : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP2_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp3       : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP3_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp4       : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP4_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp5       : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP5_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp6       : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP6_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp7       : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP7_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp8       : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP8_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp9       : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP9_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp10      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP10_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp11      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP11_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp12      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP12_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp13      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP13_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp14      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP14_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp15      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP15_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp16      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP16_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp17      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP17_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp18      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP18_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp19      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP19_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp20      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP20_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp21      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP21_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp22      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP22_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp23      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP23_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp24      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP24_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp25      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP25_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp26      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP26_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp27      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP27_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp28      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP28_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp29      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP29_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp30      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP30_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp31      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP31_SIZE;
      } rsmu_sms_fuse_clear_set0_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sms_fuse_clear_set0_mp0_t {
            unsigned int rsmu_sms_fuse_clear_grp31      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP31_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp30      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP30_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp29      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP29_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp28      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP28_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp27      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP27_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp26      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP26_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp25      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP25_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp24      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP24_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp23      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP23_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp22      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP22_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp21      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP21_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp20      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP20_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp19      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP19_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp18      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP18_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp17      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP17_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp16      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP16_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp15      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP15_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp14      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP14_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp13      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP13_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp12      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP12_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp11      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP11_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp10      : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP10_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp9       : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP9_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp8       : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP8_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp7       : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP7_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp6       : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP6_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp5       : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP5_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp4       : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP4_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp3       : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP3_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp2       : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP2_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp1       : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP1_SIZE;
            unsigned int rsmu_sms_fuse_clear_grp0       : RSMU_SMS_FUSE_CLEAR_SET0_MP0_RSMU_SMS_FUSE_CLEAR_GRP0_SIZE;
      } rsmu_sms_fuse_clear_set0_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sms_fuse_clear_set0_mp0_t f;
} rsmu_sms_fuse_clear_set0_mp0_u;


/*
 * RSMU_TIMEOUT_ERROR_LOG_REG_MP0 struct
 */

#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_REG_SIZE         32
#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_ADDR_SIZE  20
#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_INITIATORID_SIZE  10
#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_OP_SIZE  1
#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_OUTSTANDING_SIZE  1

#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_ADDR_SHIFT  0
#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_INITIATORID_SHIFT  20
#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_OP_SHIFT  30
#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_OUTSTANDING_SHIFT  31

#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_ADDR_MASK  0x000fffff
#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_INITIATORID_MASK  0x3ff00000
#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_OP_MASK  0x40000000
#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_OUTSTANDING_MASK  0x80000000

#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_MASK \
      (RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_ADDR_MASK | \
      RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_INITIATORID_MASK | \
      RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_OP_MASK | \
      RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_OUTSTANDING_MASK)

#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_DEFAULT 0x00000000

#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_GET_RSMU_TIMEOUT_ERROR_ADDR(rsmu_timeout_error_log_reg_mp0) \
      ((rsmu_timeout_error_log_reg_mp0 & RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_ADDR_MASK) >> RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_ADDR_SHIFT)
#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_GET_RSMU_TIMEOUT_ERROR_INITIATORID(rsmu_timeout_error_log_reg_mp0) \
      ((rsmu_timeout_error_log_reg_mp0 & RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_INITIATORID_MASK) >> RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_INITIATORID_SHIFT)
#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_GET_RSMU_TIMEOUT_ERROR_OP(rsmu_timeout_error_log_reg_mp0) \
      ((rsmu_timeout_error_log_reg_mp0 & RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_OP_MASK) >> RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_OP_SHIFT)
#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_GET_RSMU_TIMEOUT_ERROR_OUTSTANDING(rsmu_timeout_error_log_reg_mp0) \
      ((rsmu_timeout_error_log_reg_mp0 & RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_OUTSTANDING_MASK) >> RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_OUTSTANDING_SHIFT)

#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_SET_RSMU_TIMEOUT_ERROR_ADDR(rsmu_timeout_error_log_reg_mp0_reg, rsmu_timeout_error_addr) \
      rsmu_timeout_error_log_reg_mp0_reg = (rsmu_timeout_error_log_reg_mp0_reg & ~RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_ADDR_MASK) | (rsmu_timeout_error_addr << RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_ADDR_SHIFT)
#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_SET_RSMU_TIMEOUT_ERROR_INITIATORID(rsmu_timeout_error_log_reg_mp0_reg, rsmu_timeout_error_initiatorid) \
      rsmu_timeout_error_log_reg_mp0_reg = (rsmu_timeout_error_log_reg_mp0_reg & ~RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_INITIATORID_MASK) | (rsmu_timeout_error_initiatorid << RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_INITIATORID_SHIFT)
#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_SET_RSMU_TIMEOUT_ERROR_OP(rsmu_timeout_error_log_reg_mp0_reg, rsmu_timeout_error_op) \
      rsmu_timeout_error_log_reg_mp0_reg = (rsmu_timeout_error_log_reg_mp0_reg & ~RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_OP_MASK) | (rsmu_timeout_error_op << RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_OP_SHIFT)
#define RSMU_TIMEOUT_ERROR_LOG_REG_MP0_SET_RSMU_TIMEOUT_ERROR_OUTSTANDING(rsmu_timeout_error_log_reg_mp0_reg, rsmu_timeout_error_outstanding) \
      rsmu_timeout_error_log_reg_mp0_reg = (rsmu_timeout_error_log_reg_mp0_reg & ~RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_OUTSTANDING_MASK) | (rsmu_timeout_error_outstanding << RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_OUTSTANDING_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_timeout_error_log_reg_mp0_t {
            unsigned int rsmu_timeout_error_addr        : RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_ADDR_SIZE;
            unsigned int rsmu_timeout_error_initiatorid : RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_INITIATORID_SIZE;
            unsigned int rsmu_timeout_error_op          : RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_OP_SIZE;
            unsigned int rsmu_timeout_error_outstanding : RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_OUTSTANDING_SIZE;
      } rsmu_timeout_error_log_reg_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_timeout_error_log_reg_mp0_t {
            unsigned int rsmu_timeout_error_outstanding : RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_OUTSTANDING_SIZE;
            unsigned int rsmu_timeout_error_op          : RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_OP_SIZE;
            unsigned int rsmu_timeout_error_initiatorid : RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_INITIATORID_SIZE;
            unsigned int rsmu_timeout_error_addr        : RSMU_TIMEOUT_ERROR_LOG_REG_MP0_RSMU_TIMEOUT_ERROR_ADDR_SIZE;
      } rsmu_timeout_error_log_reg_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_timeout_error_log_reg_mp0_t f;
} rsmu_timeout_error_log_reg_mp0_u;


/*
 * RSMU_IP_MASTER_STATUS_MP0 struct
 */

#define RSMU_IP_MASTER_STATUS_MP0_REG_SIZE         32
#define RSMU_IP_MASTER_STATUS_MP0_RSMU_IP_MASTER_REQ_PENDING_SIZE  1
#define RSMU_IP_MASTER_STATUS_MP0_RSMU_IP_MASTER_RESP_PENDING_SIZE  1

#define RSMU_IP_MASTER_STATUS_MP0_RSMU_IP_MASTER_REQ_PENDING_SHIFT  0
#define RSMU_IP_MASTER_STATUS_MP0_RSMU_IP_MASTER_RESP_PENDING_SHIFT  1

#define RSMU_IP_MASTER_STATUS_MP0_RSMU_IP_MASTER_REQ_PENDING_MASK  0x00000001
#define RSMU_IP_MASTER_STATUS_MP0_RSMU_IP_MASTER_RESP_PENDING_MASK  0x00000002

#define RSMU_IP_MASTER_STATUS_MP0_MASK \
      (RSMU_IP_MASTER_STATUS_MP0_RSMU_IP_MASTER_REQ_PENDING_MASK | \
      RSMU_IP_MASTER_STATUS_MP0_RSMU_IP_MASTER_RESP_PENDING_MASK)

#define RSMU_IP_MASTER_STATUS_MP0_DEFAULT 0x00000000

#define RSMU_IP_MASTER_STATUS_MP0_GET_RSMU_IP_MASTER_REQ_PENDING(rsmu_ip_master_status_mp0) \
      ((rsmu_ip_master_status_mp0 & RSMU_IP_MASTER_STATUS_MP0_RSMU_IP_MASTER_REQ_PENDING_MASK) >> RSMU_IP_MASTER_STATUS_MP0_RSMU_IP_MASTER_REQ_PENDING_SHIFT)
#define RSMU_IP_MASTER_STATUS_MP0_GET_RSMU_IP_MASTER_RESP_PENDING(rsmu_ip_master_status_mp0) \
      ((rsmu_ip_master_status_mp0 & RSMU_IP_MASTER_STATUS_MP0_RSMU_IP_MASTER_RESP_PENDING_MASK) >> RSMU_IP_MASTER_STATUS_MP0_RSMU_IP_MASTER_RESP_PENDING_SHIFT)

#define RSMU_IP_MASTER_STATUS_MP0_SET_RSMU_IP_MASTER_REQ_PENDING(rsmu_ip_master_status_mp0_reg, rsmu_ip_master_req_pending) \
      rsmu_ip_master_status_mp0_reg = (rsmu_ip_master_status_mp0_reg & ~RSMU_IP_MASTER_STATUS_MP0_RSMU_IP_MASTER_REQ_PENDING_MASK) | (rsmu_ip_master_req_pending << RSMU_IP_MASTER_STATUS_MP0_RSMU_IP_MASTER_REQ_PENDING_SHIFT)
#define RSMU_IP_MASTER_STATUS_MP0_SET_RSMU_IP_MASTER_RESP_PENDING(rsmu_ip_master_status_mp0_reg, rsmu_ip_master_resp_pending) \
      rsmu_ip_master_status_mp0_reg = (rsmu_ip_master_status_mp0_reg & ~RSMU_IP_MASTER_STATUS_MP0_RSMU_IP_MASTER_RESP_PENDING_MASK) | (rsmu_ip_master_resp_pending << RSMU_IP_MASTER_STATUS_MP0_RSMU_IP_MASTER_RESP_PENDING_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_ip_master_status_mp0_t {
            unsigned int rsmu_ip_master_req_pending     : RSMU_IP_MASTER_STATUS_MP0_RSMU_IP_MASTER_REQ_PENDING_SIZE;
            unsigned int rsmu_ip_master_resp_pending    : RSMU_IP_MASTER_STATUS_MP0_RSMU_IP_MASTER_RESP_PENDING_SIZE;
            unsigned int                                : 30;
      } rsmu_ip_master_status_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_ip_master_status_mp0_t {
            unsigned int                                : 30;
            unsigned int rsmu_ip_master_resp_pending    : RSMU_IP_MASTER_STATUS_MP0_RSMU_IP_MASTER_RESP_PENDING_SIZE;
            unsigned int rsmu_ip_master_req_pending     : RSMU_IP_MASTER_STATUS_MP0_RSMU_IP_MASTER_REQ_PENDING_SIZE;
      } rsmu_ip_master_status_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_ip_master_status_mp0_t f;
} rsmu_ip_master_status_mp0_u;


/*
 * RSMU_MMIOEXT_SCRATCH_REG_0_MP0 struct
 */

#define RSMU_MMIOEXT_SCRATCH_REG_0_MP0_REG_SIZE         32
#define RSMU_MMIOEXT_SCRATCH_REG_0_MP0_RSMU_MMIOEXT_SCRATCH_REG_0_SIZE  32

#define RSMU_MMIOEXT_SCRATCH_REG_0_MP0_RSMU_MMIOEXT_SCRATCH_REG_0_SHIFT  0

#define RSMU_MMIOEXT_SCRATCH_REG_0_MP0_RSMU_MMIOEXT_SCRATCH_REG_0_MASK  0xffffffff

#define RSMU_MMIOEXT_SCRATCH_REG_0_MP0_MASK \
      (RSMU_MMIOEXT_SCRATCH_REG_0_MP0_RSMU_MMIOEXT_SCRATCH_REG_0_MASK)

#define RSMU_MMIOEXT_SCRATCH_REG_0_MP0_DEFAULT 0x00000000

#define RSMU_MMIOEXT_SCRATCH_REG_0_MP0_GET_RSMU_MMIOEXT_SCRATCH_REG_0(rsmu_mmioext_scratch_reg_0_mp0) \
      ((rsmu_mmioext_scratch_reg_0_mp0 & RSMU_MMIOEXT_SCRATCH_REG_0_MP0_RSMU_MMIOEXT_SCRATCH_REG_0_MASK) >> RSMU_MMIOEXT_SCRATCH_REG_0_MP0_RSMU_MMIOEXT_SCRATCH_REG_0_SHIFT)

#define RSMU_MMIOEXT_SCRATCH_REG_0_MP0_SET_RSMU_MMIOEXT_SCRATCH_REG_0(rsmu_mmioext_scratch_reg_0_mp0_reg, rsmu_mmioext_scratch_reg_0) \
      rsmu_mmioext_scratch_reg_0_mp0_reg = (rsmu_mmioext_scratch_reg_0_mp0_reg & ~RSMU_MMIOEXT_SCRATCH_REG_0_MP0_RSMU_MMIOEXT_SCRATCH_REG_0_MASK) | (rsmu_mmioext_scratch_reg_0 << RSMU_MMIOEXT_SCRATCH_REG_0_MP0_RSMU_MMIOEXT_SCRATCH_REG_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_mmioext_scratch_reg_0_mp0_t {
            unsigned int rsmu_mmioext_scratch_reg_0     : RSMU_MMIOEXT_SCRATCH_REG_0_MP0_RSMU_MMIOEXT_SCRATCH_REG_0_SIZE;
      } rsmu_mmioext_scratch_reg_0_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_mmioext_scratch_reg_0_mp0_t {
            unsigned int rsmu_mmioext_scratch_reg_0     : RSMU_MMIOEXT_SCRATCH_REG_0_MP0_RSMU_MMIOEXT_SCRATCH_REG_0_SIZE;
      } rsmu_mmioext_scratch_reg_0_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_mmioext_scratch_reg_0_mp0_t f;
} rsmu_mmioext_scratch_reg_0_mp0_u;


/*
 * RSMU_MMIOEXT_SCRATCH_REG_1_MP0 struct
 */

#define RSMU_MMIOEXT_SCRATCH_REG_1_MP0_REG_SIZE         32
#define RSMU_MMIOEXT_SCRATCH_REG_1_MP0_RSMU_MMIOEXT_SCRATCH_REG_1_SIZE  32

#define RSMU_MMIOEXT_SCRATCH_REG_1_MP0_RSMU_MMIOEXT_SCRATCH_REG_1_SHIFT  0

#define RSMU_MMIOEXT_SCRATCH_REG_1_MP0_RSMU_MMIOEXT_SCRATCH_REG_1_MASK  0xffffffff

#define RSMU_MMIOEXT_SCRATCH_REG_1_MP0_MASK \
      (RSMU_MMIOEXT_SCRATCH_REG_1_MP0_RSMU_MMIOEXT_SCRATCH_REG_1_MASK)

#define RSMU_MMIOEXT_SCRATCH_REG_1_MP0_DEFAULT 0x00000000

#define RSMU_MMIOEXT_SCRATCH_REG_1_MP0_GET_RSMU_MMIOEXT_SCRATCH_REG_1(rsmu_mmioext_scratch_reg_1_mp0) \
      ((rsmu_mmioext_scratch_reg_1_mp0 & RSMU_MMIOEXT_SCRATCH_REG_1_MP0_RSMU_MMIOEXT_SCRATCH_REG_1_MASK) >> RSMU_MMIOEXT_SCRATCH_REG_1_MP0_RSMU_MMIOEXT_SCRATCH_REG_1_SHIFT)

#define RSMU_MMIOEXT_SCRATCH_REG_1_MP0_SET_RSMU_MMIOEXT_SCRATCH_REG_1(rsmu_mmioext_scratch_reg_1_mp0_reg, rsmu_mmioext_scratch_reg_1) \
      rsmu_mmioext_scratch_reg_1_mp0_reg = (rsmu_mmioext_scratch_reg_1_mp0_reg & ~RSMU_MMIOEXT_SCRATCH_REG_1_MP0_RSMU_MMIOEXT_SCRATCH_REG_1_MASK) | (rsmu_mmioext_scratch_reg_1 << RSMU_MMIOEXT_SCRATCH_REG_1_MP0_RSMU_MMIOEXT_SCRATCH_REG_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_mmioext_scratch_reg_1_mp0_t {
            unsigned int rsmu_mmioext_scratch_reg_1     : RSMU_MMIOEXT_SCRATCH_REG_1_MP0_RSMU_MMIOEXT_SCRATCH_REG_1_SIZE;
      } rsmu_mmioext_scratch_reg_1_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_mmioext_scratch_reg_1_mp0_t {
            unsigned int rsmu_mmioext_scratch_reg_1     : RSMU_MMIOEXT_SCRATCH_REG_1_MP0_RSMU_MMIOEXT_SCRATCH_REG_1_SIZE;
      } rsmu_mmioext_scratch_reg_1_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_mmioext_scratch_reg_1_mp0_t f;
} rsmu_mmioext_scratch_reg_1_mp0_u;


/*
 * RSMU_VERSION_MP0 struct
 */

#define RSMU_VERSION_MP0_REG_SIZE         32
#define RSMU_VERSION_MP0_RSMU_VERSION_LOW_SIZE  8
#define RSMU_VERSION_MP0_RSMU_VERSION_MIDDLE_SIZE  8
#define RSMU_VERSION_MP0_RSMU_VERSION_HIGH_SIZE  8

#define RSMU_VERSION_MP0_RSMU_VERSION_LOW_SHIFT  0
#define RSMU_VERSION_MP0_RSMU_VERSION_MIDDLE_SHIFT  8
#define RSMU_VERSION_MP0_RSMU_VERSION_HIGH_SHIFT  16

#define RSMU_VERSION_MP0_RSMU_VERSION_LOW_MASK  0x000000ff
#define RSMU_VERSION_MP0_RSMU_VERSION_MIDDLE_MASK  0x0000ff00
#define RSMU_VERSION_MP0_RSMU_VERSION_HIGH_MASK  0x00ff0000

#define RSMU_VERSION_MP0_MASK \
      (RSMU_VERSION_MP0_RSMU_VERSION_LOW_MASK | \
      RSMU_VERSION_MP0_RSMU_VERSION_MIDDLE_MASK | \
      RSMU_VERSION_MP0_RSMU_VERSION_HIGH_MASK)

#define RSMU_VERSION_MP0_DEFAULT       0x00000000

#define RSMU_VERSION_MP0_GET_RSMU_VERSION_LOW(rsmu_version_mp0) \
      ((rsmu_version_mp0 & RSMU_VERSION_MP0_RSMU_VERSION_LOW_MASK) >> RSMU_VERSION_MP0_RSMU_VERSION_LOW_SHIFT)
#define RSMU_VERSION_MP0_GET_RSMU_VERSION_MIDDLE(rsmu_version_mp0) \
      ((rsmu_version_mp0 & RSMU_VERSION_MP0_RSMU_VERSION_MIDDLE_MASK) >> RSMU_VERSION_MP0_RSMU_VERSION_MIDDLE_SHIFT)
#define RSMU_VERSION_MP0_GET_RSMU_VERSION_HIGH(rsmu_version_mp0) \
      ((rsmu_version_mp0 & RSMU_VERSION_MP0_RSMU_VERSION_HIGH_MASK) >> RSMU_VERSION_MP0_RSMU_VERSION_HIGH_SHIFT)

#define RSMU_VERSION_MP0_SET_RSMU_VERSION_LOW(rsmu_version_mp0_reg, rsmu_version_low) \
      rsmu_version_mp0_reg = (rsmu_version_mp0_reg & ~RSMU_VERSION_MP0_RSMU_VERSION_LOW_MASK) | (rsmu_version_low << RSMU_VERSION_MP0_RSMU_VERSION_LOW_SHIFT)
#define RSMU_VERSION_MP0_SET_RSMU_VERSION_MIDDLE(rsmu_version_mp0_reg, rsmu_version_middle) \
      rsmu_version_mp0_reg = (rsmu_version_mp0_reg & ~RSMU_VERSION_MP0_RSMU_VERSION_MIDDLE_MASK) | (rsmu_version_middle << RSMU_VERSION_MP0_RSMU_VERSION_MIDDLE_SHIFT)
#define RSMU_VERSION_MP0_SET_RSMU_VERSION_HIGH(rsmu_version_mp0_reg, rsmu_version_high) \
      rsmu_version_mp0_reg = (rsmu_version_mp0_reg & ~RSMU_VERSION_MP0_RSMU_VERSION_HIGH_MASK) | (rsmu_version_high << RSMU_VERSION_MP0_RSMU_VERSION_HIGH_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_version_mp0_t {
            unsigned int rsmu_version_low               : RSMU_VERSION_MP0_RSMU_VERSION_LOW_SIZE;
            unsigned int rsmu_version_middle            : RSMU_VERSION_MP0_RSMU_VERSION_MIDDLE_SIZE;
            unsigned int rsmu_version_high              : RSMU_VERSION_MP0_RSMU_VERSION_HIGH_SIZE;
            unsigned int                                : 8;
      } rsmu_version_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_version_mp0_t {
            unsigned int                                : 8;
            unsigned int rsmu_version_high              : RSMU_VERSION_MP0_RSMU_VERSION_HIGH_SIZE;
            unsigned int rsmu_version_middle            : RSMU_VERSION_MP0_RSMU_VERSION_MIDDLE_SIZE;
            unsigned int rsmu_version_low               : RSMU_VERSION_MP0_RSMU_VERSION_LOW_SIZE;
      } rsmu_version_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_version_mp0_t f;
} rsmu_version_mp0_u;


/*
 * RSMU_AEB_LOCK_0_MP0 struct
 */

#define RSMU_AEB_LOCK_0_MP0_REG_SIZE         32
#define RSMU_AEB_LOCK_0_MP0_RSMU_AEB_LOCK_0_SIZE  29

#define RSMU_AEB_LOCK_0_MP0_RSMU_AEB_LOCK_0_SHIFT  3

#define RSMU_AEB_LOCK_0_MP0_RSMU_AEB_LOCK_0_MASK  0xfffffff8

#define RSMU_AEB_LOCK_0_MP0_MASK \
      (RSMU_AEB_LOCK_0_MP0_RSMU_AEB_LOCK_0_MASK)

#define RSMU_AEB_LOCK_0_MP0_DEFAULT    0x00000000

#define RSMU_AEB_LOCK_0_MP0_GET_RSMU_AEB_LOCK_0(rsmu_aeb_lock_0_mp0) \
      ((rsmu_aeb_lock_0_mp0 & RSMU_AEB_LOCK_0_MP0_RSMU_AEB_LOCK_0_MASK) >> RSMU_AEB_LOCK_0_MP0_RSMU_AEB_LOCK_0_SHIFT)

#define RSMU_AEB_LOCK_0_MP0_SET_RSMU_AEB_LOCK_0(rsmu_aeb_lock_0_mp0_reg, rsmu_aeb_lock_0) \
      rsmu_aeb_lock_0_mp0_reg = (rsmu_aeb_lock_0_mp0_reg & ~RSMU_AEB_LOCK_0_MP0_RSMU_AEB_LOCK_0_MASK) | (rsmu_aeb_lock_0 << RSMU_AEB_LOCK_0_MP0_RSMU_AEB_LOCK_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_aeb_lock_0_mp0_t {
            unsigned int                                : 3;
            unsigned int rsmu_aeb_lock_0                : RSMU_AEB_LOCK_0_MP0_RSMU_AEB_LOCK_0_SIZE;
      } rsmu_aeb_lock_0_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_aeb_lock_0_mp0_t {
            unsigned int rsmu_aeb_lock_0                : RSMU_AEB_LOCK_0_MP0_RSMU_AEB_LOCK_0_SIZE;
            unsigned int                                : 3;
      } rsmu_aeb_lock_0_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_aeb_lock_0_mp0_t f;
} rsmu_aeb_lock_0_mp0_u;


/*
 * RSMU_AEB_LOCK_1_MP0 struct
 */

#define RSMU_AEB_LOCK_1_MP0_REG_SIZE         32
#define RSMU_AEB_LOCK_1_MP0_RSMU_AEB_LOCK_1_SIZE  32

#define RSMU_AEB_LOCK_1_MP0_RSMU_AEB_LOCK_1_SHIFT  0

#define RSMU_AEB_LOCK_1_MP0_RSMU_AEB_LOCK_1_MASK  0xffffffff

#define RSMU_AEB_LOCK_1_MP0_MASK \
      (RSMU_AEB_LOCK_1_MP0_RSMU_AEB_LOCK_1_MASK)

#define RSMU_AEB_LOCK_1_MP0_DEFAULT    0x00000000

#define RSMU_AEB_LOCK_1_MP0_GET_RSMU_AEB_LOCK_1(rsmu_aeb_lock_1_mp0) \
      ((rsmu_aeb_lock_1_mp0 & RSMU_AEB_LOCK_1_MP0_RSMU_AEB_LOCK_1_MASK) >> RSMU_AEB_LOCK_1_MP0_RSMU_AEB_LOCK_1_SHIFT)

#define RSMU_AEB_LOCK_1_MP0_SET_RSMU_AEB_LOCK_1(rsmu_aeb_lock_1_mp0_reg, rsmu_aeb_lock_1) \
      rsmu_aeb_lock_1_mp0_reg = (rsmu_aeb_lock_1_mp0_reg & ~RSMU_AEB_LOCK_1_MP0_RSMU_AEB_LOCK_1_MASK) | (rsmu_aeb_lock_1 << RSMU_AEB_LOCK_1_MP0_RSMU_AEB_LOCK_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_aeb_lock_1_mp0_t {
            unsigned int rsmu_aeb_lock_1                : RSMU_AEB_LOCK_1_MP0_RSMU_AEB_LOCK_1_SIZE;
      } rsmu_aeb_lock_1_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_aeb_lock_1_mp0_t {
            unsigned int rsmu_aeb_lock_1                : RSMU_AEB_LOCK_1_MP0_RSMU_AEB_LOCK_1_SIZE;
      } rsmu_aeb_lock_1_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_aeb_lock_1_mp0_t f;
} rsmu_aeb_lock_1_mp0_u;


/*
 * RSMU_AEB_OVERRIDE_0_MP0 struct
 */

#define RSMU_AEB_OVERRIDE_0_MP0_REG_SIZE         32
#define RSMU_AEB_OVERRIDE_0_MP0_RSMU_AEB_OVERRIDE_0_SIZE  29

#define RSMU_AEB_OVERRIDE_0_MP0_RSMU_AEB_OVERRIDE_0_SHIFT  3

#define RSMU_AEB_OVERRIDE_0_MP0_RSMU_AEB_OVERRIDE_0_MASK  0xfffffff8

#define RSMU_AEB_OVERRIDE_0_MP0_MASK \
      (RSMU_AEB_OVERRIDE_0_MP0_RSMU_AEB_OVERRIDE_0_MASK)

#define RSMU_AEB_OVERRIDE_0_MP0_DEFAULT 0x00000000

#define RSMU_AEB_OVERRIDE_0_MP0_GET_RSMU_AEB_OVERRIDE_0(rsmu_aeb_override_0_mp0) \
      ((rsmu_aeb_override_0_mp0 & RSMU_AEB_OVERRIDE_0_MP0_RSMU_AEB_OVERRIDE_0_MASK) >> RSMU_AEB_OVERRIDE_0_MP0_RSMU_AEB_OVERRIDE_0_SHIFT)

#define RSMU_AEB_OVERRIDE_0_MP0_SET_RSMU_AEB_OVERRIDE_0(rsmu_aeb_override_0_mp0_reg, rsmu_aeb_override_0) \
      rsmu_aeb_override_0_mp0_reg = (rsmu_aeb_override_0_mp0_reg & ~RSMU_AEB_OVERRIDE_0_MP0_RSMU_AEB_OVERRIDE_0_MASK) | (rsmu_aeb_override_0 << RSMU_AEB_OVERRIDE_0_MP0_RSMU_AEB_OVERRIDE_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_aeb_override_0_mp0_t {
            unsigned int                                : 3;
            unsigned int rsmu_aeb_override_0            : RSMU_AEB_OVERRIDE_0_MP0_RSMU_AEB_OVERRIDE_0_SIZE;
      } rsmu_aeb_override_0_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_aeb_override_0_mp0_t {
            unsigned int rsmu_aeb_override_0            : RSMU_AEB_OVERRIDE_0_MP0_RSMU_AEB_OVERRIDE_0_SIZE;
            unsigned int                                : 3;
      } rsmu_aeb_override_0_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_aeb_override_0_mp0_t f;
} rsmu_aeb_override_0_mp0_u;


/*
 * RSMU_AEB_OVERRIDE_1_MP0 struct
 */

#define RSMU_AEB_OVERRIDE_1_MP0_REG_SIZE         32
#define RSMU_AEB_OVERRIDE_1_MP0_RSMU_AEB_OVERRIDE_1_SIZE  32

#define RSMU_AEB_OVERRIDE_1_MP0_RSMU_AEB_OVERRIDE_1_SHIFT  0

#define RSMU_AEB_OVERRIDE_1_MP0_RSMU_AEB_OVERRIDE_1_MASK  0xffffffff

#define RSMU_AEB_OVERRIDE_1_MP0_MASK \
      (RSMU_AEB_OVERRIDE_1_MP0_RSMU_AEB_OVERRIDE_1_MASK)

#define RSMU_AEB_OVERRIDE_1_MP0_DEFAULT 0x00000000

#define RSMU_AEB_OVERRIDE_1_MP0_GET_RSMU_AEB_OVERRIDE_1(rsmu_aeb_override_1_mp0) \
      ((rsmu_aeb_override_1_mp0 & RSMU_AEB_OVERRIDE_1_MP0_RSMU_AEB_OVERRIDE_1_MASK) >> RSMU_AEB_OVERRIDE_1_MP0_RSMU_AEB_OVERRIDE_1_SHIFT)

#define RSMU_AEB_OVERRIDE_1_MP0_SET_RSMU_AEB_OVERRIDE_1(rsmu_aeb_override_1_mp0_reg, rsmu_aeb_override_1) \
      rsmu_aeb_override_1_mp0_reg = (rsmu_aeb_override_1_mp0_reg & ~RSMU_AEB_OVERRIDE_1_MP0_RSMU_AEB_OVERRIDE_1_MASK) | (rsmu_aeb_override_1 << RSMU_AEB_OVERRIDE_1_MP0_RSMU_AEB_OVERRIDE_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_aeb_override_1_mp0_t {
            unsigned int rsmu_aeb_override_1            : RSMU_AEB_OVERRIDE_1_MP0_RSMU_AEB_OVERRIDE_1_SIZE;
      } rsmu_aeb_override_1_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_aeb_override_1_mp0_t {
            unsigned int rsmu_aeb_override_1            : RSMU_AEB_OVERRIDE_1_MP0_RSMU_AEB_OVERRIDE_1_SIZE;
      } rsmu_aeb_override_1_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_aeb_override_1_mp0_t f;
} rsmu_aeb_override_1_mp0_u;


/*
 * RSMU_SEC_INTR_ENABLE_MP0 struct
 */

#define RSMU_SEC_INTR_ENABLE_MP0_REG_SIZE         32
#define RSMU_SEC_INTR_ENABLE_MP0_RSMU_SEC_INTR_ENABLE_SIZE  16

#define RSMU_SEC_INTR_ENABLE_MP0_RSMU_SEC_INTR_ENABLE_SHIFT  0

#define RSMU_SEC_INTR_ENABLE_MP0_RSMU_SEC_INTR_ENABLE_MASK  0x0000ffff

#define RSMU_SEC_INTR_ENABLE_MP0_MASK \
      (RSMU_SEC_INTR_ENABLE_MP0_RSMU_SEC_INTR_ENABLE_MASK)

#define RSMU_SEC_INTR_ENABLE_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INTR_ENABLE_MP0_GET_RSMU_SEC_INTR_ENABLE(rsmu_sec_intr_enable_mp0) \
      ((rsmu_sec_intr_enable_mp0 & RSMU_SEC_INTR_ENABLE_MP0_RSMU_SEC_INTR_ENABLE_MASK) >> RSMU_SEC_INTR_ENABLE_MP0_RSMU_SEC_INTR_ENABLE_SHIFT)

#define RSMU_SEC_INTR_ENABLE_MP0_SET_RSMU_SEC_INTR_ENABLE(rsmu_sec_intr_enable_mp0_reg, rsmu_sec_intr_enable) \
      rsmu_sec_intr_enable_mp0_reg = (rsmu_sec_intr_enable_mp0_reg & ~RSMU_SEC_INTR_ENABLE_MP0_RSMU_SEC_INTR_ENABLE_MASK) | (rsmu_sec_intr_enable << RSMU_SEC_INTR_ENABLE_MP0_RSMU_SEC_INTR_ENABLE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_intr_enable_mp0_t {
            unsigned int rsmu_sec_intr_enable           : RSMU_SEC_INTR_ENABLE_MP0_RSMU_SEC_INTR_ENABLE_SIZE;
            unsigned int                                : 16;
      } rsmu_sec_intr_enable_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_intr_enable_mp0_t {
            unsigned int                                : 16;
            unsigned int rsmu_sec_intr_enable           : RSMU_SEC_INTR_ENABLE_MP0_RSMU_SEC_INTR_ENABLE_SIZE;
      } rsmu_sec_intr_enable_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_intr_enable_mp0_t f;
} rsmu_sec_intr_enable_mp0_u;


/*
 * RSMU_SEC_INTR_TARGET_ADDR_MP0 struct
 */

#define RSMU_SEC_INTR_TARGET_ADDR_MP0_REG_SIZE         32
#define RSMU_SEC_INTR_TARGET_ADDR_MP0_RSMU_SEC_INTR_TARGET_ADDR_SIZE  32

#define RSMU_SEC_INTR_TARGET_ADDR_MP0_RSMU_SEC_INTR_TARGET_ADDR_SHIFT  0

#define RSMU_SEC_INTR_TARGET_ADDR_MP0_RSMU_SEC_INTR_TARGET_ADDR_MASK  0xffffffff

#define RSMU_SEC_INTR_TARGET_ADDR_MP0_MASK \
      (RSMU_SEC_INTR_TARGET_ADDR_MP0_RSMU_SEC_INTR_TARGET_ADDR_MASK)

#define RSMU_SEC_INTR_TARGET_ADDR_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INTR_TARGET_ADDR_MP0_GET_RSMU_SEC_INTR_TARGET_ADDR(rsmu_sec_intr_target_addr_mp0) \
      ((rsmu_sec_intr_target_addr_mp0 & RSMU_SEC_INTR_TARGET_ADDR_MP0_RSMU_SEC_INTR_TARGET_ADDR_MASK) >> RSMU_SEC_INTR_TARGET_ADDR_MP0_RSMU_SEC_INTR_TARGET_ADDR_SHIFT)

#define RSMU_SEC_INTR_TARGET_ADDR_MP0_SET_RSMU_SEC_INTR_TARGET_ADDR(rsmu_sec_intr_target_addr_mp0_reg, rsmu_sec_intr_target_addr) \
      rsmu_sec_intr_target_addr_mp0_reg = (rsmu_sec_intr_target_addr_mp0_reg & ~RSMU_SEC_INTR_TARGET_ADDR_MP0_RSMU_SEC_INTR_TARGET_ADDR_MASK) | (rsmu_sec_intr_target_addr << RSMU_SEC_INTR_TARGET_ADDR_MP0_RSMU_SEC_INTR_TARGET_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_intr_target_addr_mp0_t {
            unsigned int rsmu_sec_intr_target_addr      : RSMU_SEC_INTR_TARGET_ADDR_MP0_RSMU_SEC_INTR_TARGET_ADDR_SIZE;
      } rsmu_sec_intr_target_addr_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_intr_target_addr_mp0_t {
            unsigned int rsmu_sec_intr_target_addr      : RSMU_SEC_INTR_TARGET_ADDR_MP0_RSMU_SEC_INTR_TARGET_ADDR_SIZE;
      } rsmu_sec_intr_target_addr_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_intr_target_addr_mp0_t f;
} rsmu_sec_intr_target_addr_mp0_u;


/*
 * RSMU_SEC_INTR_CONFIG_MP0 struct
 */

#define RSMU_SEC_INTR_CONFIG_MP0_REG_SIZE         32
#define RSMU_SEC_INTR_CONFIG_MP0_RSMU_SEC_INTR_CONFIG_VC_SIZE  2

#define RSMU_SEC_INTR_CONFIG_MP0_RSMU_SEC_INTR_CONFIG_VC_SHIFT  0

#define RSMU_SEC_INTR_CONFIG_MP0_RSMU_SEC_INTR_CONFIG_VC_MASK  0x00000003

#define RSMU_SEC_INTR_CONFIG_MP0_MASK \
      (RSMU_SEC_INTR_CONFIG_MP0_RSMU_SEC_INTR_CONFIG_VC_MASK)

#define RSMU_SEC_INTR_CONFIG_MP0_DEFAULT 0x00000001

#define RSMU_SEC_INTR_CONFIG_MP0_GET_RSMU_SEC_INTR_CONFIG_VC(rsmu_sec_intr_config_mp0) \
      ((rsmu_sec_intr_config_mp0 & RSMU_SEC_INTR_CONFIG_MP0_RSMU_SEC_INTR_CONFIG_VC_MASK) >> RSMU_SEC_INTR_CONFIG_MP0_RSMU_SEC_INTR_CONFIG_VC_SHIFT)

#define RSMU_SEC_INTR_CONFIG_MP0_SET_RSMU_SEC_INTR_CONFIG_VC(rsmu_sec_intr_config_mp0_reg, rsmu_sec_intr_config_vc) \
      rsmu_sec_intr_config_mp0_reg = (rsmu_sec_intr_config_mp0_reg & ~RSMU_SEC_INTR_CONFIG_MP0_RSMU_SEC_INTR_CONFIG_VC_MASK) | (rsmu_sec_intr_config_vc << RSMU_SEC_INTR_CONFIG_MP0_RSMU_SEC_INTR_CONFIG_VC_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_intr_config_mp0_t {
            unsigned int rsmu_sec_intr_config_vc        : RSMU_SEC_INTR_CONFIG_MP0_RSMU_SEC_INTR_CONFIG_VC_SIZE;
            unsigned int                                : 30;
      } rsmu_sec_intr_config_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_intr_config_mp0_t {
            unsigned int                                : 30;
            unsigned int rsmu_sec_intr_config_vc        : RSMU_SEC_INTR_CONFIG_MP0_RSMU_SEC_INTR_CONFIG_VC_SIZE;
      } rsmu_sec_intr_config_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_intr_config_mp0_t f;
} rsmu_sec_intr_config_mp0_u;


/*
 * RSMU_SEC_INTR_STATUS_MP0 struct
 */

#define RSMU_SEC_INTR_STATUS_MP0_REG_SIZE         32
#define RSMU_SEC_INTR_STATUS_MP0_RSMU_SEC_INTR_STATUS_SIZE  16

#define RSMU_SEC_INTR_STATUS_MP0_RSMU_SEC_INTR_STATUS_SHIFT  0

#define RSMU_SEC_INTR_STATUS_MP0_RSMU_SEC_INTR_STATUS_MASK  0x0000ffff

#define RSMU_SEC_INTR_STATUS_MP0_MASK \
      (RSMU_SEC_INTR_STATUS_MP0_RSMU_SEC_INTR_STATUS_MASK)

#define RSMU_SEC_INTR_STATUS_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INTR_STATUS_MP0_GET_RSMU_SEC_INTR_STATUS(rsmu_sec_intr_status_mp0) \
      ((rsmu_sec_intr_status_mp0 & RSMU_SEC_INTR_STATUS_MP0_RSMU_SEC_INTR_STATUS_MASK) >> RSMU_SEC_INTR_STATUS_MP0_RSMU_SEC_INTR_STATUS_SHIFT)

#define RSMU_SEC_INTR_STATUS_MP0_SET_RSMU_SEC_INTR_STATUS(rsmu_sec_intr_status_mp0_reg, rsmu_sec_intr_status) \
      rsmu_sec_intr_status_mp0_reg = (rsmu_sec_intr_status_mp0_reg & ~RSMU_SEC_INTR_STATUS_MP0_RSMU_SEC_INTR_STATUS_MASK) | (rsmu_sec_intr_status << RSMU_SEC_INTR_STATUS_MP0_RSMU_SEC_INTR_STATUS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_intr_status_mp0_t {
            unsigned int rsmu_sec_intr_status           : RSMU_SEC_INTR_STATUS_MP0_RSMU_SEC_INTR_STATUS_SIZE;
            unsigned int                                : 16;
      } rsmu_sec_intr_status_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_intr_status_mp0_t {
            unsigned int                                : 16;
            unsigned int rsmu_sec_intr_status           : RSMU_SEC_INTR_STATUS_MP0_RSMU_SEC_INTR_STATUS_SIZE;
      } rsmu_sec_intr_status_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_intr_status_mp0_t f;
} rsmu_sec_intr_status_mp0_u;


/*
 * RSMU_SEC_INTR_PENDING_MP0 struct
 */

#define RSMU_SEC_INTR_PENDING_MP0_REG_SIZE         32
#define RSMU_SEC_INTR_PENDING_MP0_RSMU_SEC_INTR_PENDING_SIZE  16

#define RSMU_SEC_INTR_PENDING_MP0_RSMU_SEC_INTR_PENDING_SHIFT  0

#define RSMU_SEC_INTR_PENDING_MP0_RSMU_SEC_INTR_PENDING_MASK  0x0000ffff

#define RSMU_SEC_INTR_PENDING_MP0_MASK \
      (RSMU_SEC_INTR_PENDING_MP0_RSMU_SEC_INTR_PENDING_MASK)

#define RSMU_SEC_INTR_PENDING_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INTR_PENDING_MP0_GET_RSMU_SEC_INTR_PENDING(rsmu_sec_intr_pending_mp0) \
      ((rsmu_sec_intr_pending_mp0 & RSMU_SEC_INTR_PENDING_MP0_RSMU_SEC_INTR_PENDING_MASK) >> RSMU_SEC_INTR_PENDING_MP0_RSMU_SEC_INTR_PENDING_SHIFT)

#define RSMU_SEC_INTR_PENDING_MP0_SET_RSMU_SEC_INTR_PENDING(rsmu_sec_intr_pending_mp0_reg, rsmu_sec_intr_pending) \
      rsmu_sec_intr_pending_mp0_reg = (rsmu_sec_intr_pending_mp0_reg & ~RSMU_SEC_INTR_PENDING_MP0_RSMU_SEC_INTR_PENDING_MASK) | (rsmu_sec_intr_pending << RSMU_SEC_INTR_PENDING_MP0_RSMU_SEC_INTR_PENDING_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_intr_pending_mp0_t {
            unsigned int rsmu_sec_intr_pending          : RSMU_SEC_INTR_PENDING_MP0_RSMU_SEC_INTR_PENDING_SIZE;
            unsigned int                                : 16;
      } rsmu_sec_intr_pending_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_intr_pending_mp0_t {
            unsigned int                                : 16;
            unsigned int rsmu_sec_intr_pending          : RSMU_SEC_INTR_PENDING_MP0_RSMU_SEC_INTR_PENDING_SIZE;
      } rsmu_sec_intr_pending_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_intr_pending_mp0_t f;
} rsmu_sec_intr_pending_mp0_u;


/*
 * RSMU_SEC_INTR_TYPE_MP0 struct
 */

#define RSMU_SEC_INTR_TYPE_MP0_REG_SIZE         32
#define RSMU_SEC_INTR_TYPE_MP0_RSMU_SEC_INTR_TYPE_SIZE  16

#define RSMU_SEC_INTR_TYPE_MP0_RSMU_SEC_INTR_TYPE_SHIFT  0

#define RSMU_SEC_INTR_TYPE_MP0_RSMU_SEC_INTR_TYPE_MASK  0x0000ffff

#define RSMU_SEC_INTR_TYPE_MP0_MASK \
      (RSMU_SEC_INTR_TYPE_MP0_RSMU_SEC_INTR_TYPE_MASK)

#define RSMU_SEC_INTR_TYPE_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INTR_TYPE_MP0_GET_RSMU_SEC_INTR_TYPE(rsmu_sec_intr_type_mp0) \
      ((rsmu_sec_intr_type_mp0 & RSMU_SEC_INTR_TYPE_MP0_RSMU_SEC_INTR_TYPE_MASK) >> RSMU_SEC_INTR_TYPE_MP0_RSMU_SEC_INTR_TYPE_SHIFT)

#define RSMU_SEC_INTR_TYPE_MP0_SET_RSMU_SEC_INTR_TYPE(rsmu_sec_intr_type_mp0_reg, rsmu_sec_intr_type) \
      rsmu_sec_intr_type_mp0_reg = (rsmu_sec_intr_type_mp0_reg & ~RSMU_SEC_INTR_TYPE_MP0_RSMU_SEC_INTR_TYPE_MASK) | (rsmu_sec_intr_type << RSMU_SEC_INTR_TYPE_MP0_RSMU_SEC_INTR_TYPE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_intr_type_mp0_t {
            unsigned int rsmu_sec_intr_type             : RSMU_SEC_INTR_TYPE_MP0_RSMU_SEC_INTR_TYPE_SIZE;
            unsigned int                                : 16;
      } rsmu_sec_intr_type_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_intr_type_mp0_t {
            unsigned int                                : 16;
            unsigned int rsmu_sec_intr_type             : RSMU_SEC_INTR_TYPE_MP0_RSMU_SEC_INTR_TYPE_SIZE;
      } rsmu_sec_intr_type_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_intr_type_mp0_t f;
} rsmu_sec_intr_type_mp0_u;


/*
 * RSMU_SEC_INTR_INTERCEPT_MP0 struct
 */

#define RSMU_SEC_INTR_INTERCEPT_MP0_REG_SIZE         32
#define RSMU_SEC_INTR_INTERCEPT_MP0_RSMU_SEC_INTR_OVERRIDE_SIZE  16
#define RSMU_SEC_INTR_INTERCEPT_MP0_RSMU_SEC_INTR_VALUE_SIZE  16

#define RSMU_SEC_INTR_INTERCEPT_MP0_RSMU_SEC_INTR_OVERRIDE_SHIFT  0
#define RSMU_SEC_INTR_INTERCEPT_MP0_RSMU_SEC_INTR_VALUE_SHIFT  16

#define RSMU_SEC_INTR_INTERCEPT_MP0_RSMU_SEC_INTR_OVERRIDE_MASK  0x0000ffff
#define RSMU_SEC_INTR_INTERCEPT_MP0_RSMU_SEC_INTR_VALUE_MASK  0xffff0000

#define RSMU_SEC_INTR_INTERCEPT_MP0_MASK \
      (RSMU_SEC_INTR_INTERCEPT_MP0_RSMU_SEC_INTR_OVERRIDE_MASK | \
      RSMU_SEC_INTR_INTERCEPT_MP0_RSMU_SEC_INTR_VALUE_MASK)

#define RSMU_SEC_INTR_INTERCEPT_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INTR_INTERCEPT_MP0_GET_RSMU_SEC_INTR_OVERRIDE(rsmu_sec_intr_intercept_mp0) \
      ((rsmu_sec_intr_intercept_mp0 & RSMU_SEC_INTR_INTERCEPT_MP0_RSMU_SEC_INTR_OVERRIDE_MASK) >> RSMU_SEC_INTR_INTERCEPT_MP0_RSMU_SEC_INTR_OVERRIDE_SHIFT)
#define RSMU_SEC_INTR_INTERCEPT_MP0_GET_RSMU_SEC_INTR_VALUE(rsmu_sec_intr_intercept_mp0) \
      ((rsmu_sec_intr_intercept_mp0 & RSMU_SEC_INTR_INTERCEPT_MP0_RSMU_SEC_INTR_VALUE_MASK) >> RSMU_SEC_INTR_INTERCEPT_MP0_RSMU_SEC_INTR_VALUE_SHIFT)

#define RSMU_SEC_INTR_INTERCEPT_MP0_SET_RSMU_SEC_INTR_OVERRIDE(rsmu_sec_intr_intercept_mp0_reg, rsmu_sec_intr_override) \
      rsmu_sec_intr_intercept_mp0_reg = (rsmu_sec_intr_intercept_mp0_reg & ~RSMU_SEC_INTR_INTERCEPT_MP0_RSMU_SEC_INTR_OVERRIDE_MASK) | (rsmu_sec_intr_override << RSMU_SEC_INTR_INTERCEPT_MP0_RSMU_SEC_INTR_OVERRIDE_SHIFT)
#define RSMU_SEC_INTR_INTERCEPT_MP0_SET_RSMU_SEC_INTR_VALUE(rsmu_sec_intr_intercept_mp0_reg, rsmu_sec_intr_value) \
      rsmu_sec_intr_intercept_mp0_reg = (rsmu_sec_intr_intercept_mp0_reg & ~RSMU_SEC_INTR_INTERCEPT_MP0_RSMU_SEC_INTR_VALUE_MASK) | (rsmu_sec_intr_value << RSMU_SEC_INTR_INTERCEPT_MP0_RSMU_SEC_INTR_VALUE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_intr_intercept_mp0_t {
            unsigned int rsmu_sec_intr_override         : RSMU_SEC_INTR_INTERCEPT_MP0_RSMU_SEC_INTR_OVERRIDE_SIZE;
            unsigned int rsmu_sec_intr_value            : RSMU_SEC_INTR_INTERCEPT_MP0_RSMU_SEC_INTR_VALUE_SIZE;
      } rsmu_sec_intr_intercept_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_intr_intercept_mp0_t {
            unsigned int rsmu_sec_intr_value            : RSMU_SEC_INTR_INTERCEPT_MP0_RSMU_SEC_INTR_VALUE_SIZE;
            unsigned int rsmu_sec_intr_override         : RSMU_SEC_INTR_INTERCEPT_MP0_RSMU_SEC_INTR_OVERRIDE_SIZE;
      } rsmu_sec_intr_intercept_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_intr_intercept_mp0_t f;
} rsmu_sec_intr_intercept_mp0_u;


/*
 * RSMU_SEC_INTR_CLEAR_MP0 struct
 */

#define RSMU_SEC_INTR_CLEAR_MP0_REG_SIZE         32
#define RSMU_SEC_INTR_CLEAR_MP0_RSMU_SEC_INTR_CLEAR_SIZE  16

#define RSMU_SEC_INTR_CLEAR_MP0_RSMU_SEC_INTR_CLEAR_SHIFT  0

#define RSMU_SEC_INTR_CLEAR_MP0_RSMU_SEC_INTR_CLEAR_MASK  0x0000ffff

#define RSMU_SEC_INTR_CLEAR_MP0_MASK \
      (RSMU_SEC_INTR_CLEAR_MP0_RSMU_SEC_INTR_CLEAR_MASK)

#define RSMU_SEC_INTR_CLEAR_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INTR_CLEAR_MP0_GET_RSMU_SEC_INTR_CLEAR(rsmu_sec_intr_clear_mp0) \
      ((rsmu_sec_intr_clear_mp0 & RSMU_SEC_INTR_CLEAR_MP0_RSMU_SEC_INTR_CLEAR_MASK) >> RSMU_SEC_INTR_CLEAR_MP0_RSMU_SEC_INTR_CLEAR_SHIFT)

#define RSMU_SEC_INTR_CLEAR_MP0_SET_RSMU_SEC_INTR_CLEAR(rsmu_sec_intr_clear_mp0_reg, rsmu_sec_intr_clear) \
      rsmu_sec_intr_clear_mp0_reg = (rsmu_sec_intr_clear_mp0_reg & ~RSMU_SEC_INTR_CLEAR_MP0_RSMU_SEC_INTR_CLEAR_MASK) | (rsmu_sec_intr_clear << RSMU_SEC_INTR_CLEAR_MP0_RSMU_SEC_INTR_CLEAR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_intr_clear_mp0_t {
            unsigned int rsmu_sec_intr_clear            : RSMU_SEC_INTR_CLEAR_MP0_RSMU_SEC_INTR_CLEAR_SIZE;
            unsigned int                                : 16;
      } rsmu_sec_intr_clear_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_intr_clear_mp0_t {
            unsigned int                                : 16;
            unsigned int rsmu_sec_intr_clear            : RSMU_SEC_INTR_CLEAR_MP0_RSMU_SEC_INTR_CLEAR_SIZE;
      } rsmu_sec_intr_clear_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_intr_clear_mp0_t f;
} rsmu_sec_intr_clear_mp0_u;


/*
 * RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MP0 struct
 */

#define RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MP0_REG_SIZE         32
#define RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_SIZE  24

#define RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_SHIFT  0

#define RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MASK  0x00ffffff

#define RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MP0_MASK \
      (RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MASK)

#define RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MP0_DEFAULT 0x00ffffff

#define RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MP0_GET_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU(rsmu_sec_master_trust_level_rsmu_mp0) \
      ((rsmu_sec_master_trust_level_rsmu_mp0 & RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MASK) >> RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_SHIFT)

#define RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MP0_SET_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU(rsmu_sec_master_trust_level_rsmu_mp0_reg, rsmu_sec_master_trust_level_rsmu) \
      rsmu_sec_master_trust_level_rsmu_mp0_reg = (rsmu_sec_master_trust_level_rsmu_mp0_reg & ~RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MASK) | (rsmu_sec_master_trust_level_rsmu << RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_master_trust_level_rsmu_mp0_t {
            unsigned int rsmu_sec_master_trust_level_rsmu : RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_SIZE;
            unsigned int                                : 8;
      } rsmu_sec_master_trust_level_rsmu_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_master_trust_level_rsmu_mp0_t {
            unsigned int                                : 8;
            unsigned int rsmu_sec_master_trust_level_rsmu : RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_RSMU_SIZE;
      } rsmu_sec_master_trust_level_rsmu_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_master_trust_level_rsmu_mp0_t f;
} rsmu_sec_master_trust_level_rsmu_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_RSMU_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2_SIZE  8
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2_SIZE  8
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SECURITY_SLAVE_LOCK_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SOFT_RESETB_ACCESS_LOCK_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_PGFSM_ACCESS_LOCK_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SW_STRAPRX_LOCK_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2_SHIFT  1
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2_SHIFT  2
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2_SHIFT  10
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SECURITY_SLAVE_LOCK_SHIFT  18
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SOFT_RESETB_ACCESS_LOCK_SHIFT  19
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_PGFSM_ACCESS_LOCK_SHIFT  20
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SW_STRAPRX_LOCK_SHIFT  21

#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1_MASK  0x00000001
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2_MASK  0x00000002
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2_MASK  0x000003fc
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2_MASK  0x0003fc00
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SECURITY_SLAVE_LOCK_MASK  0x00040000
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SOFT_RESETB_ACCESS_LOCK_MASK  0x00080000
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_PGFSM_ACCESS_LOCK_MASK  0x00100000
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SW_STRAPRX_LOCK_MASK  0x00200000

#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1_MASK | \
      RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2_MASK | \
      RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2_MASK | \
      RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2_MASK | \
      RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SECURITY_SLAVE_LOCK_MASK | \
      RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SOFT_RESETB_ACCESS_LOCK_MASK | \
      RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_PGFSM_ACCESS_LOCK_MASK | \
      RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SW_STRAPRX_LOCK_MASK)

#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_DEFAULT 0x0001fdfc

#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_GET_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1(rsmu_sec_access_control_rsmu_mp0) \
      ((rsmu_sec_access_control_rsmu_mp0 & RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1_MASK) >> RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_GET_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2(rsmu_sec_access_control_rsmu_mp0) \
      ((rsmu_sec_access_control_rsmu_mp0 & RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2_MASK) >> RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_GET_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2(rsmu_sec_access_control_rsmu_mp0) \
      ((rsmu_sec_access_control_rsmu_mp0 & RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2_MASK) >> RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_GET_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2(rsmu_sec_access_control_rsmu_mp0) \
      ((rsmu_sec_access_control_rsmu_mp0 & RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2_MASK) >> RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_GET_RSMU_SECURITY_SLAVE_LOCK(rsmu_sec_access_control_rsmu_mp0) \
      ((rsmu_sec_access_control_rsmu_mp0 & RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SECURITY_SLAVE_LOCK_MASK) >> RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SECURITY_SLAVE_LOCK_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_GET_RSMU_SOFT_RESETB_ACCESS_LOCK(rsmu_sec_access_control_rsmu_mp0) \
      ((rsmu_sec_access_control_rsmu_mp0 & RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SOFT_RESETB_ACCESS_LOCK_MASK) >> RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SOFT_RESETB_ACCESS_LOCK_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_GET_RSMU_PGFSM_ACCESS_LOCK(rsmu_sec_access_control_rsmu_mp0) \
      ((rsmu_sec_access_control_rsmu_mp0 & RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_PGFSM_ACCESS_LOCK_MASK) >> RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_PGFSM_ACCESS_LOCK_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_GET_RSMU_SW_STRAPRX_LOCK(rsmu_sec_access_control_rsmu_mp0) \
      ((rsmu_sec_access_control_rsmu_mp0 & RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SW_STRAPRX_LOCK_MASK) >> RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SW_STRAPRX_LOCK_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_SET_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1(rsmu_sec_access_control_rsmu_mp0_reg, rsmu_sec_check_enable_rsmu_range1) \
      rsmu_sec_access_control_rsmu_mp0_reg = (rsmu_sec_access_control_rsmu_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1_MASK) | (rsmu_sec_check_enable_rsmu_range1 << RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_SET_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2(rsmu_sec_access_control_rsmu_mp0_reg, rsmu_sec_check_enable_rsmu_range2) \
      rsmu_sec_access_control_rsmu_mp0_reg = (rsmu_sec_access_control_rsmu_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2_MASK) | (rsmu_sec_check_enable_rsmu_range2 << RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_SET_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2(rsmu_sec_access_control_rsmu_mp0_reg, rsmu_sec_rd_tlvl_mask_rsmu_range2) \
      rsmu_sec_access_control_rsmu_mp0_reg = (rsmu_sec_access_control_rsmu_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2_MASK) | (rsmu_sec_rd_tlvl_mask_rsmu_range2 << RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_SET_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2(rsmu_sec_access_control_rsmu_mp0_reg, rsmu_sec_wr_tlvl_mask_rsmu_range2) \
      rsmu_sec_access_control_rsmu_mp0_reg = (rsmu_sec_access_control_rsmu_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2_MASK) | (rsmu_sec_wr_tlvl_mask_rsmu_range2 << RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_SET_RSMU_SECURITY_SLAVE_LOCK(rsmu_sec_access_control_rsmu_mp0_reg, rsmu_security_slave_lock) \
      rsmu_sec_access_control_rsmu_mp0_reg = (rsmu_sec_access_control_rsmu_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SECURITY_SLAVE_LOCK_MASK) | (rsmu_security_slave_lock << RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SECURITY_SLAVE_LOCK_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_SET_RSMU_SOFT_RESETB_ACCESS_LOCK(rsmu_sec_access_control_rsmu_mp0_reg, rsmu_soft_resetb_access_lock) \
      rsmu_sec_access_control_rsmu_mp0_reg = (rsmu_sec_access_control_rsmu_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SOFT_RESETB_ACCESS_LOCK_MASK) | (rsmu_soft_resetb_access_lock << RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SOFT_RESETB_ACCESS_LOCK_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_SET_RSMU_PGFSM_ACCESS_LOCK(rsmu_sec_access_control_rsmu_mp0_reg, rsmu_pgfsm_access_lock) \
      rsmu_sec_access_control_rsmu_mp0_reg = (rsmu_sec_access_control_rsmu_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_PGFSM_ACCESS_LOCK_MASK) | (rsmu_pgfsm_access_lock << RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_PGFSM_ACCESS_LOCK_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_SET_RSMU_SW_STRAPRX_LOCK(rsmu_sec_access_control_rsmu_mp0_reg, rsmu_sw_straprx_lock) \
      rsmu_sec_access_control_rsmu_mp0_reg = (rsmu_sec_access_control_rsmu_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SW_STRAPRX_LOCK_MASK) | (rsmu_sw_straprx_lock << RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SW_STRAPRX_LOCK_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_rsmu_mp0_t {
            unsigned int rsmu_sec_check_enable_rsmu_range1 : RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1_SIZE;
            unsigned int rsmu_sec_check_enable_rsmu_range2 : RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2_SIZE;
            unsigned int rsmu_sec_rd_tlvl_mask_rsmu_range2 : RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2_SIZE;
            unsigned int rsmu_sec_wr_tlvl_mask_rsmu_range2 : RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2_SIZE;
            unsigned int rsmu_security_slave_lock       : RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SECURITY_SLAVE_LOCK_SIZE;
            unsigned int rsmu_soft_resetb_access_lock   : RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SOFT_RESETB_ACCESS_LOCK_SIZE;
            unsigned int rsmu_pgfsm_access_lock         : RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_PGFSM_ACCESS_LOCK_SIZE;
            unsigned int rsmu_sw_straprx_lock           : RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SW_STRAPRX_LOCK_SIZE;
            unsigned int                                : 10;
      } rsmu_sec_access_control_rsmu_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_rsmu_mp0_t {
            unsigned int                                : 10;
            unsigned int rsmu_sw_straprx_lock           : RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SW_STRAPRX_LOCK_SIZE;
            unsigned int rsmu_pgfsm_access_lock         : RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_PGFSM_ACCESS_LOCK_SIZE;
            unsigned int rsmu_soft_resetb_access_lock   : RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SOFT_RESETB_ACCESS_LOCK_SIZE;
            unsigned int rsmu_security_slave_lock       : RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SECURITY_SLAVE_LOCK_SIZE;
            unsigned int rsmu_sec_wr_tlvl_mask_rsmu_range2 : RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_WR_TLVL_MASK_RSMU_RANGE2_SIZE;
            unsigned int rsmu_sec_rd_tlvl_mask_rsmu_range2 : RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_RD_TLVL_MASK_RSMU_RANGE2_SIZE;
            unsigned int rsmu_sec_check_enable_rsmu_range2 : RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE2_SIZE;
            unsigned int rsmu_sec_check_enable_rsmu_range1 : RSMU_SEC_ACCESS_CONTROL_RSMU_MP0_RSMU_SEC_CHECK_ENABLE_RSMU_RANGE1_SIZE;
      } rsmu_sec_access_control_rsmu_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_rsmu_mp0_t f;
} rsmu_sec_access_control_rsmu_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT(rsmu_sec_initid_mask_set0_group_default_mp0) \
      ((rsmu_sec_initid_mask_set0_group_default_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT(rsmu_sec_initid_mask_set0_group_default_mp0_reg, rsmu_sec_initid_mask_set0_group_default) \
      rsmu_sec_initid_mask_set0_group_default_mp0_reg = (rsmu_sec_initid_mask_set0_group_default_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MASK) | (rsmu_sec_initid_mask_set0_group_default << RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_default_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_default : RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_default_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_default_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_default : RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_DEFAULT_SIZE;
      } rsmu_sec_initid_mask_set0_group_default_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_default_mp0_t f;
} rsmu_sec_initid_mask_set0_group_default_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT(rsmu_sec_unitid_mask_set0_group_default_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_default_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT(rsmu_sec_unitid_mask_set0_group_default_mp0_reg, rsmu_sec_unitid_mask_set0_group_default) \
      rsmu_sec_unitid_mask_set0_group_default_mp0_reg = (rsmu_sec_unitid_mask_set0_group_default_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MASK) | (rsmu_sec_unitid_mask_set0_group_default << RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_default_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_default : RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_default_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_default_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_default : RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_DEFAULT_SIZE;
      } rsmu_sec_unitid_mask_set0_group_default_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_default_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_default_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT(rsmu_sec_misc_mask_set0_group_default_mp0) \
      ((rsmu_sec_misc_mask_set0_group_default_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT(rsmu_sec_misc_mask_set0_group_default_mp0) \
      ((rsmu_sec_misc_mask_set0_group_default_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT(rsmu_sec_misc_mask_set0_group_default_mp0) \
      ((rsmu_sec_misc_mask_set0_group_default_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT(rsmu_sec_misc_mask_set0_group_default_mp0_reg, rsmu_sec_tlvl_mask_set0_group_default) \
      rsmu_sec_misc_mask_set0_group_default_mp0_reg = (rsmu_sec_misc_mask_set0_group_default_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT_MASK) | (rsmu_sec_tlvl_mask_set0_group_default << RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT(rsmu_sec_misc_mask_set0_group_default_mp0_reg, rsmu_sec_rw_mask_set0_group_default) \
      rsmu_sec_misc_mask_set0_group_default_mp0_reg = (rsmu_sec_misc_mask_set0_group_default_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT_MASK) | (rsmu_sec_rw_mask_set0_group_default << RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT(rsmu_sec_misc_mask_set0_group_default_mp0_reg, rsmu_sec_vf_mask_set0_group_default) \
      rsmu_sec_misc_mask_set0_group_default_mp0_reg = (rsmu_sec_misc_mask_set0_group_default_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT_MASK) | (rsmu_sec_vf_mask_set0_group_default << RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_default_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_default : RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_default : RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_default : RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_default_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_default_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_default : RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_DEFAULT_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_default : RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_DEFAULT_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_default : RSMU_SEC_MISC_MASK_SET0_GROUP_DEFAULT_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_DEFAULT_SIZE;
      } rsmu_sec_misc_mask_set0_group_default_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_default_mp0_t f;
} rsmu_sec_misc_mask_set0_group_default_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT(rsmu_sec_initid_mask_set1_group_default_mp0) \
      ((rsmu_sec_initid_mask_set1_group_default_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT(rsmu_sec_initid_mask_set1_group_default_mp0_reg, rsmu_sec_initid_mask_set1_group_default) \
      rsmu_sec_initid_mask_set1_group_default_mp0_reg = (rsmu_sec_initid_mask_set1_group_default_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MASK) | (rsmu_sec_initid_mask_set1_group_default << RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_default_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_default : RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_default_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_default_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_default : RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_DEFAULT_SIZE;
      } rsmu_sec_initid_mask_set1_group_default_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_default_mp0_t f;
} rsmu_sec_initid_mask_set1_group_default_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT(rsmu_sec_unitid_mask_set1_group_default_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_default_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT(rsmu_sec_unitid_mask_set1_group_default_mp0_reg, rsmu_sec_unitid_mask_set1_group_default) \
      rsmu_sec_unitid_mask_set1_group_default_mp0_reg = (rsmu_sec_unitid_mask_set1_group_default_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MASK) | (rsmu_sec_unitid_mask_set1_group_default << RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_default_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_default : RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_default_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_default_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_default : RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_DEFAULT_SIZE;
      } rsmu_sec_unitid_mask_set1_group_default_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_default_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_default_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT(rsmu_sec_misc_mask_set1_group_default_mp0) \
      ((rsmu_sec_misc_mask_set1_group_default_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT(rsmu_sec_misc_mask_set1_group_default_mp0) \
      ((rsmu_sec_misc_mask_set1_group_default_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT(rsmu_sec_misc_mask_set1_group_default_mp0) \
      ((rsmu_sec_misc_mask_set1_group_default_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT(rsmu_sec_misc_mask_set1_group_default_mp0_reg, rsmu_sec_tlvl_mask_set1_group_default) \
      rsmu_sec_misc_mask_set1_group_default_mp0_reg = (rsmu_sec_misc_mask_set1_group_default_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT_MASK) | (rsmu_sec_tlvl_mask_set1_group_default << RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT(rsmu_sec_misc_mask_set1_group_default_mp0_reg, rsmu_sec_rw_mask_set1_group_default) \
      rsmu_sec_misc_mask_set1_group_default_mp0_reg = (rsmu_sec_misc_mask_set1_group_default_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT_MASK) | (rsmu_sec_rw_mask_set1_group_default << RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT(rsmu_sec_misc_mask_set1_group_default_mp0_reg, rsmu_sec_vf_mask_set1_group_default) \
      rsmu_sec_misc_mask_set1_group_default_mp0_reg = (rsmu_sec_misc_mask_set1_group_default_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT_MASK) | (rsmu_sec_vf_mask_set1_group_default << RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_default_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_default : RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_default : RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_default : RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_default_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_default_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_default : RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_DEFAULT_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_default : RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_DEFAULT_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_default : RSMU_SEC_MISC_MASK_SET1_GROUP_DEFAULT_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_DEFAULT_SIZE;
      } rsmu_sec_misc_mask_set1_group_default_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_default_mp0_t f;
} rsmu_sec_misc_mask_set1_group_default_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT(rsmu_sec_access_control_group_default_mp0) \
      ((rsmu_sec_access_control_group_default_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT(rsmu_sec_access_control_group_default_mp0) \
      ((rsmu_sec_access_control_group_default_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT(rsmu_sec_access_control_group_default_mp0) \
      ((rsmu_sec_access_control_group_default_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT(rsmu_sec_access_control_group_default_mp0) \
      ((rsmu_sec_access_control_group_default_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT(rsmu_sec_access_control_group_default_mp0_reg, rsmu_sec_check_enable_set0_group_default) \
      rsmu_sec_access_control_group_default_mp0_reg = (rsmu_sec_access_control_group_default_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT_MASK) | (rsmu_sec_check_enable_set0_group_default << RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT(rsmu_sec_access_control_group_default_mp0_reg, rsmu_sec_check_enable_set1_group_default) \
      rsmu_sec_access_control_group_default_mp0_reg = (rsmu_sec_access_control_group_default_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT_MASK) | (rsmu_sec_check_enable_set1_group_default << RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT(rsmu_sec_access_control_group_default_mp0_reg, rsmu_sec_vf_check_enable_set0_group_default) \
      rsmu_sec_access_control_group_default_mp0_reg = (rsmu_sec_access_control_group_default_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT_MASK) | (rsmu_sec_vf_check_enable_set0_group_default << RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT(rsmu_sec_access_control_group_default_mp0_reg, rsmu_sec_vf_check_enable_set1_group_default) \
      rsmu_sec_access_control_group_default_mp0_reg = (rsmu_sec_access_control_group_default_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT_MASK) | (rsmu_sec_vf_check_enable_set1_group_default << RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_default_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_default : RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_default : RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_default : RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_default : RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_default_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_default_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_default : RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_DEFAULT_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_default : RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_DEFAULT_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_default : RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_DEFAULT_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_default : RSMU_SEC_ACCESS_CONTROL_GROUP_DEFAULT_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_DEFAULT_SIZE;
      } rsmu_sec_access_control_group_default_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_default_mp0_t f;
} rsmu_sec_access_control_group_default_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_0_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_0_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_0_MP0_RSMU_SEC_START_ADDR_GROUP_0_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_0_MP0_RSMU_SEC_START_ADDR_GROUP_0_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_0_MP0_RSMU_SEC_START_ADDR_GROUP_0_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_0_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_0_MP0_RSMU_SEC_START_ADDR_GROUP_0_MASK)

#define RSMU_SEC_START_ADDR_GROUP_0_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_0_MP0_GET_RSMU_SEC_START_ADDR_GROUP_0(rsmu_sec_start_addr_group_0_mp0) \
      ((rsmu_sec_start_addr_group_0_mp0 & RSMU_SEC_START_ADDR_GROUP_0_MP0_RSMU_SEC_START_ADDR_GROUP_0_MASK) >> RSMU_SEC_START_ADDR_GROUP_0_MP0_RSMU_SEC_START_ADDR_GROUP_0_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_0_MP0_SET_RSMU_SEC_START_ADDR_GROUP_0(rsmu_sec_start_addr_group_0_mp0_reg, rsmu_sec_start_addr_group_0) \
      rsmu_sec_start_addr_group_0_mp0_reg = (rsmu_sec_start_addr_group_0_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_0_MP0_RSMU_SEC_START_ADDR_GROUP_0_MASK) | (rsmu_sec_start_addr_group_0 << RSMU_SEC_START_ADDR_GROUP_0_MP0_RSMU_SEC_START_ADDR_GROUP_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_0_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_0    : RSMU_SEC_START_ADDR_GROUP_0_MP0_RSMU_SEC_START_ADDR_GROUP_0_SIZE;
      } rsmu_sec_start_addr_group_0_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_0_mp0_t {
            unsigned int rsmu_sec_start_addr_group_0    : RSMU_SEC_START_ADDR_GROUP_0_MP0_RSMU_SEC_START_ADDR_GROUP_0_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_0_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_0_mp0_t f;
} rsmu_sec_start_addr_group_0_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_0_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_0_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_0_MP0_RSMU_SEC_END_ADDR_GROUP_0_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_0_MP0_RSMU_SEC_END_ADDR_GROUP_0_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_0_MP0_RSMU_SEC_END_ADDR_GROUP_0_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_0_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_0_MP0_RSMU_SEC_END_ADDR_GROUP_0_MASK)

#define RSMU_SEC_END_ADDR_GROUP_0_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_0_MP0_GET_RSMU_SEC_END_ADDR_GROUP_0(rsmu_sec_end_addr_group_0_mp0) \
      ((rsmu_sec_end_addr_group_0_mp0 & RSMU_SEC_END_ADDR_GROUP_0_MP0_RSMU_SEC_END_ADDR_GROUP_0_MASK) >> RSMU_SEC_END_ADDR_GROUP_0_MP0_RSMU_SEC_END_ADDR_GROUP_0_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_0_MP0_SET_RSMU_SEC_END_ADDR_GROUP_0(rsmu_sec_end_addr_group_0_mp0_reg, rsmu_sec_end_addr_group_0) \
      rsmu_sec_end_addr_group_0_mp0_reg = (rsmu_sec_end_addr_group_0_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_0_MP0_RSMU_SEC_END_ADDR_GROUP_0_MASK) | (rsmu_sec_end_addr_group_0 << RSMU_SEC_END_ADDR_GROUP_0_MP0_RSMU_SEC_END_ADDR_GROUP_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_0_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_0      : RSMU_SEC_END_ADDR_GROUP_0_MP0_RSMU_SEC_END_ADDR_GROUP_0_SIZE;
      } rsmu_sec_end_addr_group_0_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_0_mp0_t {
            unsigned int rsmu_sec_end_addr_group_0      : RSMU_SEC_END_ADDR_GROUP_0_MP0_RSMU_SEC_END_ADDR_GROUP_0_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_0_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_0_mp0_t f;
} rsmu_sec_end_addr_group_0_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_0_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_0_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_0_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_0_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_0_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_0_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_0_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_0_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_0_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_0_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_0_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_0_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_0_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_0(rsmu_sec_initid_mask_set0_group_0_mp0) \
      ((rsmu_sec_initid_mask_set0_group_0_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_0_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_0_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_0_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_0_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_0_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_0(rsmu_sec_initid_mask_set0_group_0_mp0_reg, rsmu_sec_initid_mask_set0_group_0) \
      rsmu_sec_initid_mask_set0_group_0_mp0_reg = (rsmu_sec_initid_mask_set0_group_0_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_0_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_0_MASK) | (rsmu_sec_initid_mask_set0_group_0 << RSMU_SEC_INITID_MASK_SET0_GROUP_0_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_0_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_0 : RSMU_SEC_INITID_MASK_SET0_GROUP_0_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_0_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_0_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_0_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_0 : RSMU_SEC_INITID_MASK_SET0_GROUP_0_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_0_SIZE;
      } rsmu_sec_initid_mask_set0_group_0_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_0_mp0_t f;
} rsmu_sec_initid_mask_set0_group_0_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_0_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_0_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_0(rsmu_sec_unitid_mask_set0_group_0_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_0_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_0_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_0(rsmu_sec_unitid_mask_set0_group_0_mp0_reg, rsmu_sec_unitid_mask_set0_group_0) \
      rsmu_sec_unitid_mask_set0_group_0_mp0_reg = (rsmu_sec_unitid_mask_set0_group_0_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MASK) | (rsmu_sec_unitid_mask_set0_group_0 << RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_0_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_0 : RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_0_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_0_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_0_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_0 : RSMU_SEC_UNITID_MASK_SET0_GROUP_0_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_0_SIZE;
      } rsmu_sec_unitid_mask_set0_group_0_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_0_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_0_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_0_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_0_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_0_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_0_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_0_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_0_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_0_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_0_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_0_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_0_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_0_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_0_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_0(rsmu_sec_misc_mask_set0_group_0_mp0) \
      ((rsmu_sec_misc_mask_set0_group_0_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_0_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_0_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_0(rsmu_sec_misc_mask_set0_group_0_mp0) \
      ((rsmu_sec_misc_mask_set0_group_0_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_0_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_0_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_0(rsmu_sec_misc_mask_set0_group_0_mp0) \
      ((rsmu_sec_misc_mask_set0_group_0_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_0_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_0_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_0(rsmu_sec_misc_mask_set0_group_0_mp0_reg, rsmu_sec_tlvl_mask_set0_group_0) \
      rsmu_sec_misc_mask_set0_group_0_mp0_reg = (rsmu_sec_misc_mask_set0_group_0_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_0_MASK) | (rsmu_sec_tlvl_mask_set0_group_0 << RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_0_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_0(rsmu_sec_misc_mask_set0_group_0_mp0_reg, rsmu_sec_rw_mask_set0_group_0) \
      rsmu_sec_misc_mask_set0_group_0_mp0_reg = (rsmu_sec_misc_mask_set0_group_0_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_0_MASK) | (rsmu_sec_rw_mask_set0_group_0 << RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_0_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_0(rsmu_sec_misc_mask_set0_group_0_mp0_reg, rsmu_sec_vf_mask_set0_group_0) \
      rsmu_sec_misc_mask_set0_group_0_mp0_reg = (rsmu_sec_misc_mask_set0_group_0_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_0_MASK) | (rsmu_sec_vf_mask_set0_group_0 << RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_0_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_0 : RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_0_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_0  : RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_0_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_0  : RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_0_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_0_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_0_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_0  : RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_0_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_0  : RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_0_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_0 : RSMU_SEC_MISC_MASK_SET0_GROUP_0_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_0_SIZE;
      } rsmu_sec_misc_mask_set0_group_0_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_0_mp0_t f;
} rsmu_sec_misc_mask_set0_group_0_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_0_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_0_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_0_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_0_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_0_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_0_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_0_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_0_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_0_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_0_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_0_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_0_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_0_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_0(rsmu_sec_initid_mask_set1_group_0_mp0) \
      ((rsmu_sec_initid_mask_set1_group_0_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_0_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_0_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_0_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_0_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_0_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_0(rsmu_sec_initid_mask_set1_group_0_mp0_reg, rsmu_sec_initid_mask_set1_group_0) \
      rsmu_sec_initid_mask_set1_group_0_mp0_reg = (rsmu_sec_initid_mask_set1_group_0_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_0_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_0_MASK) | (rsmu_sec_initid_mask_set1_group_0 << RSMU_SEC_INITID_MASK_SET1_GROUP_0_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_0_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_0 : RSMU_SEC_INITID_MASK_SET1_GROUP_0_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_0_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_0_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_0_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_0 : RSMU_SEC_INITID_MASK_SET1_GROUP_0_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_0_SIZE;
      } rsmu_sec_initid_mask_set1_group_0_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_0_mp0_t f;
} rsmu_sec_initid_mask_set1_group_0_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_0_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_0_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_0(rsmu_sec_unitid_mask_set1_group_0_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_0_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_0_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_0(rsmu_sec_unitid_mask_set1_group_0_mp0_reg, rsmu_sec_unitid_mask_set1_group_0) \
      rsmu_sec_unitid_mask_set1_group_0_mp0_reg = (rsmu_sec_unitid_mask_set1_group_0_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MASK) | (rsmu_sec_unitid_mask_set1_group_0 << RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_0_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_0 : RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_0_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_0_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_0_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_0 : RSMU_SEC_UNITID_MASK_SET1_GROUP_0_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_0_SIZE;
      } rsmu_sec_unitid_mask_set1_group_0_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_0_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_0_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_0_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_0_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_0_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_0_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_0_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_0_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_0_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_0_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_0_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_0_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_0_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_0_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_0(rsmu_sec_misc_mask_set1_group_0_mp0) \
      ((rsmu_sec_misc_mask_set1_group_0_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_0_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_0_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_0(rsmu_sec_misc_mask_set1_group_0_mp0) \
      ((rsmu_sec_misc_mask_set1_group_0_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_0_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_0_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_0(rsmu_sec_misc_mask_set1_group_0_mp0) \
      ((rsmu_sec_misc_mask_set1_group_0_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_0_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_0_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_0(rsmu_sec_misc_mask_set1_group_0_mp0_reg, rsmu_sec_tlvl_mask_set1_group_0) \
      rsmu_sec_misc_mask_set1_group_0_mp0_reg = (rsmu_sec_misc_mask_set1_group_0_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_0_MASK) | (rsmu_sec_tlvl_mask_set1_group_0 << RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_0_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_0(rsmu_sec_misc_mask_set1_group_0_mp0_reg, rsmu_sec_rw_mask_set1_group_0) \
      rsmu_sec_misc_mask_set1_group_0_mp0_reg = (rsmu_sec_misc_mask_set1_group_0_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_0_MASK) | (rsmu_sec_rw_mask_set1_group_0 << RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_0_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_0(rsmu_sec_misc_mask_set1_group_0_mp0_reg, rsmu_sec_vf_mask_set1_group_0) \
      rsmu_sec_misc_mask_set1_group_0_mp0_reg = (rsmu_sec_misc_mask_set1_group_0_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_0_MASK) | (rsmu_sec_vf_mask_set1_group_0 << RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_0_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_0 : RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_0_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_0  : RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_0_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_0  : RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_0_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_0_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_0_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_0  : RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_0_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_0  : RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_0_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_0 : RSMU_SEC_MISC_MASK_SET1_GROUP_0_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_0_SIZE;
      } rsmu_sec_misc_mask_set1_group_0_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_0_mp0_t f;
} rsmu_sec_misc_mask_set1_group_0_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0(rsmu_sec_access_control_group_0_mp0) \
      ((rsmu_sec_access_control_group_0_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0(rsmu_sec_access_control_group_0_mp0) \
      ((rsmu_sec_access_control_group_0_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0(rsmu_sec_access_control_group_0_mp0) \
      ((rsmu_sec_access_control_group_0_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0(rsmu_sec_access_control_group_0_mp0) \
      ((rsmu_sec_access_control_group_0_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0(rsmu_sec_access_control_group_0_mp0_reg, rsmu_sec_check_enable_set0_group_0) \
      rsmu_sec_access_control_group_0_mp0_reg = (rsmu_sec_access_control_group_0_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0_MASK) | (rsmu_sec_check_enable_set0_group_0 << RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0(rsmu_sec_access_control_group_0_mp0_reg, rsmu_sec_check_enable_set1_group_0) \
      rsmu_sec_access_control_group_0_mp0_reg = (rsmu_sec_access_control_group_0_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0_MASK) | (rsmu_sec_check_enable_set1_group_0 << RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0(rsmu_sec_access_control_group_0_mp0_reg, rsmu_sec_vf_check_enable_set0_group_0) \
      rsmu_sec_access_control_group_0_mp0_reg = (rsmu_sec_access_control_group_0_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0_MASK) | (rsmu_sec_vf_check_enable_set0_group_0 << RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0(rsmu_sec_access_control_group_0_mp0_reg, rsmu_sec_vf_check_enable_set1_group_0) \
      rsmu_sec_access_control_group_0_mp0_reg = (rsmu_sec_access_control_group_0_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0_MASK) | (rsmu_sec_vf_check_enable_set1_group_0 << RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_0_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_0 : RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_0 : RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_0 : RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_0 : RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_0_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_0_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_0 : RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_0_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_0 : RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_0_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_0 : RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_0_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_0 : RSMU_SEC_ACCESS_CONTROL_GROUP_0_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_0_SIZE;
      } rsmu_sec_access_control_group_0_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_0_mp0_t f;
} rsmu_sec_access_control_group_0_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_1_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_1_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_1_MP0_RSMU_SEC_START_ADDR_GROUP_1_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_1_MP0_RSMU_SEC_START_ADDR_GROUP_1_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_1_MP0_RSMU_SEC_START_ADDR_GROUP_1_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_1_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_1_MP0_RSMU_SEC_START_ADDR_GROUP_1_MASK)

#define RSMU_SEC_START_ADDR_GROUP_1_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_1_MP0_GET_RSMU_SEC_START_ADDR_GROUP_1(rsmu_sec_start_addr_group_1_mp0) \
      ((rsmu_sec_start_addr_group_1_mp0 & RSMU_SEC_START_ADDR_GROUP_1_MP0_RSMU_SEC_START_ADDR_GROUP_1_MASK) >> RSMU_SEC_START_ADDR_GROUP_1_MP0_RSMU_SEC_START_ADDR_GROUP_1_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_1_MP0_SET_RSMU_SEC_START_ADDR_GROUP_1(rsmu_sec_start_addr_group_1_mp0_reg, rsmu_sec_start_addr_group_1) \
      rsmu_sec_start_addr_group_1_mp0_reg = (rsmu_sec_start_addr_group_1_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_1_MP0_RSMU_SEC_START_ADDR_GROUP_1_MASK) | (rsmu_sec_start_addr_group_1 << RSMU_SEC_START_ADDR_GROUP_1_MP0_RSMU_SEC_START_ADDR_GROUP_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_1_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_1    : RSMU_SEC_START_ADDR_GROUP_1_MP0_RSMU_SEC_START_ADDR_GROUP_1_SIZE;
      } rsmu_sec_start_addr_group_1_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_1_mp0_t {
            unsigned int rsmu_sec_start_addr_group_1    : RSMU_SEC_START_ADDR_GROUP_1_MP0_RSMU_SEC_START_ADDR_GROUP_1_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_1_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_1_mp0_t f;
} rsmu_sec_start_addr_group_1_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_1_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_1_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_1_MP0_RSMU_SEC_END_ADDR_GROUP_1_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_1_MP0_RSMU_SEC_END_ADDR_GROUP_1_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_1_MP0_RSMU_SEC_END_ADDR_GROUP_1_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_1_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_1_MP0_RSMU_SEC_END_ADDR_GROUP_1_MASK)

#define RSMU_SEC_END_ADDR_GROUP_1_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_1_MP0_GET_RSMU_SEC_END_ADDR_GROUP_1(rsmu_sec_end_addr_group_1_mp0) \
      ((rsmu_sec_end_addr_group_1_mp0 & RSMU_SEC_END_ADDR_GROUP_1_MP0_RSMU_SEC_END_ADDR_GROUP_1_MASK) >> RSMU_SEC_END_ADDR_GROUP_1_MP0_RSMU_SEC_END_ADDR_GROUP_1_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_1_MP0_SET_RSMU_SEC_END_ADDR_GROUP_1(rsmu_sec_end_addr_group_1_mp0_reg, rsmu_sec_end_addr_group_1) \
      rsmu_sec_end_addr_group_1_mp0_reg = (rsmu_sec_end_addr_group_1_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_1_MP0_RSMU_SEC_END_ADDR_GROUP_1_MASK) | (rsmu_sec_end_addr_group_1 << RSMU_SEC_END_ADDR_GROUP_1_MP0_RSMU_SEC_END_ADDR_GROUP_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_1_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_1      : RSMU_SEC_END_ADDR_GROUP_1_MP0_RSMU_SEC_END_ADDR_GROUP_1_SIZE;
      } rsmu_sec_end_addr_group_1_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_1_mp0_t {
            unsigned int rsmu_sec_end_addr_group_1      : RSMU_SEC_END_ADDR_GROUP_1_MP0_RSMU_SEC_END_ADDR_GROUP_1_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_1_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_1_mp0_t f;
} rsmu_sec_end_addr_group_1_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_1_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_1_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_1_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_1_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_1_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_1_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_1_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_1_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_1_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_1_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_1_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_1_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_1_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_1(rsmu_sec_initid_mask_set0_group_1_mp0) \
      ((rsmu_sec_initid_mask_set0_group_1_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_1_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_1_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_1_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_1_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_1_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_1(rsmu_sec_initid_mask_set0_group_1_mp0_reg, rsmu_sec_initid_mask_set0_group_1) \
      rsmu_sec_initid_mask_set0_group_1_mp0_reg = (rsmu_sec_initid_mask_set0_group_1_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_1_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_1_MASK) | (rsmu_sec_initid_mask_set0_group_1 << RSMU_SEC_INITID_MASK_SET0_GROUP_1_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_1_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_1 : RSMU_SEC_INITID_MASK_SET0_GROUP_1_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_1_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_1_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_1_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_1 : RSMU_SEC_INITID_MASK_SET0_GROUP_1_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_1_SIZE;
      } rsmu_sec_initid_mask_set0_group_1_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_1_mp0_t f;
} rsmu_sec_initid_mask_set0_group_1_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_1_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_1_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_1(rsmu_sec_unitid_mask_set0_group_1_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_1_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_1_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_1(rsmu_sec_unitid_mask_set0_group_1_mp0_reg, rsmu_sec_unitid_mask_set0_group_1) \
      rsmu_sec_unitid_mask_set0_group_1_mp0_reg = (rsmu_sec_unitid_mask_set0_group_1_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MASK) | (rsmu_sec_unitid_mask_set0_group_1 << RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_1_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_1 : RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_1_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_1_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_1_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_1 : RSMU_SEC_UNITID_MASK_SET0_GROUP_1_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_1_SIZE;
      } rsmu_sec_unitid_mask_set0_group_1_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_1_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_1_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_1_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_1_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_1_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_1_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_1_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_1_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_1_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_1_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_1_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_1_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_1_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_1_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_1(rsmu_sec_misc_mask_set0_group_1_mp0) \
      ((rsmu_sec_misc_mask_set0_group_1_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_1_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_1_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_1(rsmu_sec_misc_mask_set0_group_1_mp0) \
      ((rsmu_sec_misc_mask_set0_group_1_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_1_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_1_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_1(rsmu_sec_misc_mask_set0_group_1_mp0) \
      ((rsmu_sec_misc_mask_set0_group_1_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_1_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_1_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_1(rsmu_sec_misc_mask_set0_group_1_mp0_reg, rsmu_sec_tlvl_mask_set0_group_1) \
      rsmu_sec_misc_mask_set0_group_1_mp0_reg = (rsmu_sec_misc_mask_set0_group_1_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_1_MASK) | (rsmu_sec_tlvl_mask_set0_group_1 << RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_1_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_1(rsmu_sec_misc_mask_set0_group_1_mp0_reg, rsmu_sec_rw_mask_set0_group_1) \
      rsmu_sec_misc_mask_set0_group_1_mp0_reg = (rsmu_sec_misc_mask_set0_group_1_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_1_MASK) | (rsmu_sec_rw_mask_set0_group_1 << RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_1_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_1(rsmu_sec_misc_mask_set0_group_1_mp0_reg, rsmu_sec_vf_mask_set0_group_1) \
      rsmu_sec_misc_mask_set0_group_1_mp0_reg = (rsmu_sec_misc_mask_set0_group_1_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_1_MASK) | (rsmu_sec_vf_mask_set0_group_1 << RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_1_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_1 : RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_1_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_1  : RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_1_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_1  : RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_1_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_1_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_1_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_1  : RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_1_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_1  : RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_1_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_1 : RSMU_SEC_MISC_MASK_SET0_GROUP_1_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_1_SIZE;
      } rsmu_sec_misc_mask_set0_group_1_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_1_mp0_t f;
} rsmu_sec_misc_mask_set0_group_1_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_1_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_1_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_1_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_1_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_1_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_1_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_1_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_1_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_1_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_1_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_1_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_1_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_1_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_1(rsmu_sec_initid_mask_set1_group_1_mp0) \
      ((rsmu_sec_initid_mask_set1_group_1_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_1_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_1_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_1_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_1_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_1_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_1(rsmu_sec_initid_mask_set1_group_1_mp0_reg, rsmu_sec_initid_mask_set1_group_1) \
      rsmu_sec_initid_mask_set1_group_1_mp0_reg = (rsmu_sec_initid_mask_set1_group_1_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_1_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_1_MASK) | (rsmu_sec_initid_mask_set1_group_1 << RSMU_SEC_INITID_MASK_SET1_GROUP_1_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_1_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_1 : RSMU_SEC_INITID_MASK_SET1_GROUP_1_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_1_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_1_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_1_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_1 : RSMU_SEC_INITID_MASK_SET1_GROUP_1_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_1_SIZE;
      } rsmu_sec_initid_mask_set1_group_1_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_1_mp0_t f;
} rsmu_sec_initid_mask_set1_group_1_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_1_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_1_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_1(rsmu_sec_unitid_mask_set1_group_1_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_1_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_1_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_1(rsmu_sec_unitid_mask_set1_group_1_mp0_reg, rsmu_sec_unitid_mask_set1_group_1) \
      rsmu_sec_unitid_mask_set1_group_1_mp0_reg = (rsmu_sec_unitid_mask_set1_group_1_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MASK) | (rsmu_sec_unitid_mask_set1_group_1 << RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_1_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_1 : RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_1_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_1_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_1_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_1 : RSMU_SEC_UNITID_MASK_SET1_GROUP_1_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_1_SIZE;
      } rsmu_sec_unitid_mask_set1_group_1_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_1_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_1_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_1_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_1_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_1_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_1_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_1_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_1_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_1_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_1_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_1_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_1_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_1_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_1_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_1(rsmu_sec_misc_mask_set1_group_1_mp0) \
      ((rsmu_sec_misc_mask_set1_group_1_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_1_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_1_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_1(rsmu_sec_misc_mask_set1_group_1_mp0) \
      ((rsmu_sec_misc_mask_set1_group_1_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_1_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_1_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_1(rsmu_sec_misc_mask_set1_group_1_mp0) \
      ((rsmu_sec_misc_mask_set1_group_1_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_1_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_1_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_1(rsmu_sec_misc_mask_set1_group_1_mp0_reg, rsmu_sec_tlvl_mask_set1_group_1) \
      rsmu_sec_misc_mask_set1_group_1_mp0_reg = (rsmu_sec_misc_mask_set1_group_1_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_1_MASK) | (rsmu_sec_tlvl_mask_set1_group_1 << RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_1_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_1(rsmu_sec_misc_mask_set1_group_1_mp0_reg, rsmu_sec_rw_mask_set1_group_1) \
      rsmu_sec_misc_mask_set1_group_1_mp0_reg = (rsmu_sec_misc_mask_set1_group_1_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_1_MASK) | (rsmu_sec_rw_mask_set1_group_1 << RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_1_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_1(rsmu_sec_misc_mask_set1_group_1_mp0_reg, rsmu_sec_vf_mask_set1_group_1) \
      rsmu_sec_misc_mask_set1_group_1_mp0_reg = (rsmu_sec_misc_mask_set1_group_1_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_1_MASK) | (rsmu_sec_vf_mask_set1_group_1 << RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_1_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_1 : RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_1_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_1  : RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_1_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_1  : RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_1_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_1_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_1_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_1  : RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_1_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_1  : RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_1_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_1 : RSMU_SEC_MISC_MASK_SET1_GROUP_1_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_1_SIZE;
      } rsmu_sec_misc_mask_set1_group_1_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_1_mp0_t f;
} rsmu_sec_misc_mask_set1_group_1_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1(rsmu_sec_access_control_group_1_mp0) \
      ((rsmu_sec_access_control_group_1_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1(rsmu_sec_access_control_group_1_mp0) \
      ((rsmu_sec_access_control_group_1_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1(rsmu_sec_access_control_group_1_mp0) \
      ((rsmu_sec_access_control_group_1_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1(rsmu_sec_access_control_group_1_mp0) \
      ((rsmu_sec_access_control_group_1_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1(rsmu_sec_access_control_group_1_mp0_reg, rsmu_sec_check_enable_set0_group_1) \
      rsmu_sec_access_control_group_1_mp0_reg = (rsmu_sec_access_control_group_1_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1_MASK) | (rsmu_sec_check_enable_set0_group_1 << RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1(rsmu_sec_access_control_group_1_mp0_reg, rsmu_sec_check_enable_set1_group_1) \
      rsmu_sec_access_control_group_1_mp0_reg = (rsmu_sec_access_control_group_1_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1_MASK) | (rsmu_sec_check_enable_set1_group_1 << RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1(rsmu_sec_access_control_group_1_mp0_reg, rsmu_sec_vf_check_enable_set0_group_1) \
      rsmu_sec_access_control_group_1_mp0_reg = (rsmu_sec_access_control_group_1_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1_MASK) | (rsmu_sec_vf_check_enable_set0_group_1 << RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1(rsmu_sec_access_control_group_1_mp0_reg, rsmu_sec_vf_check_enable_set1_group_1) \
      rsmu_sec_access_control_group_1_mp0_reg = (rsmu_sec_access_control_group_1_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1_MASK) | (rsmu_sec_vf_check_enable_set1_group_1 << RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_1_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_1 : RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_1 : RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_1 : RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_1 : RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_1_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_1_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_1 : RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_1_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_1 : RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_1_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_1 : RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_1_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_1 : RSMU_SEC_ACCESS_CONTROL_GROUP_1_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_1_SIZE;
      } rsmu_sec_access_control_group_1_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_1_mp0_t f;
} rsmu_sec_access_control_group_1_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_2_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_2_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_2_MP0_RSMU_SEC_START_ADDR_GROUP_2_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_2_MP0_RSMU_SEC_START_ADDR_GROUP_2_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_2_MP0_RSMU_SEC_START_ADDR_GROUP_2_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_2_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_2_MP0_RSMU_SEC_START_ADDR_GROUP_2_MASK)

#define RSMU_SEC_START_ADDR_GROUP_2_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_2_MP0_GET_RSMU_SEC_START_ADDR_GROUP_2(rsmu_sec_start_addr_group_2_mp0) \
      ((rsmu_sec_start_addr_group_2_mp0 & RSMU_SEC_START_ADDR_GROUP_2_MP0_RSMU_SEC_START_ADDR_GROUP_2_MASK) >> RSMU_SEC_START_ADDR_GROUP_2_MP0_RSMU_SEC_START_ADDR_GROUP_2_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_2_MP0_SET_RSMU_SEC_START_ADDR_GROUP_2(rsmu_sec_start_addr_group_2_mp0_reg, rsmu_sec_start_addr_group_2) \
      rsmu_sec_start_addr_group_2_mp0_reg = (rsmu_sec_start_addr_group_2_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_2_MP0_RSMU_SEC_START_ADDR_GROUP_2_MASK) | (rsmu_sec_start_addr_group_2 << RSMU_SEC_START_ADDR_GROUP_2_MP0_RSMU_SEC_START_ADDR_GROUP_2_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_2_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_2    : RSMU_SEC_START_ADDR_GROUP_2_MP0_RSMU_SEC_START_ADDR_GROUP_2_SIZE;
      } rsmu_sec_start_addr_group_2_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_2_mp0_t {
            unsigned int rsmu_sec_start_addr_group_2    : RSMU_SEC_START_ADDR_GROUP_2_MP0_RSMU_SEC_START_ADDR_GROUP_2_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_2_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_2_mp0_t f;
} rsmu_sec_start_addr_group_2_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_2_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_2_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_2_MP0_RSMU_SEC_END_ADDR_GROUP_2_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_2_MP0_RSMU_SEC_END_ADDR_GROUP_2_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_2_MP0_RSMU_SEC_END_ADDR_GROUP_2_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_2_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_2_MP0_RSMU_SEC_END_ADDR_GROUP_2_MASK)

#define RSMU_SEC_END_ADDR_GROUP_2_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_2_MP0_GET_RSMU_SEC_END_ADDR_GROUP_2(rsmu_sec_end_addr_group_2_mp0) \
      ((rsmu_sec_end_addr_group_2_mp0 & RSMU_SEC_END_ADDR_GROUP_2_MP0_RSMU_SEC_END_ADDR_GROUP_2_MASK) >> RSMU_SEC_END_ADDR_GROUP_2_MP0_RSMU_SEC_END_ADDR_GROUP_2_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_2_MP0_SET_RSMU_SEC_END_ADDR_GROUP_2(rsmu_sec_end_addr_group_2_mp0_reg, rsmu_sec_end_addr_group_2) \
      rsmu_sec_end_addr_group_2_mp0_reg = (rsmu_sec_end_addr_group_2_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_2_MP0_RSMU_SEC_END_ADDR_GROUP_2_MASK) | (rsmu_sec_end_addr_group_2 << RSMU_SEC_END_ADDR_GROUP_2_MP0_RSMU_SEC_END_ADDR_GROUP_2_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_2_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_2      : RSMU_SEC_END_ADDR_GROUP_2_MP0_RSMU_SEC_END_ADDR_GROUP_2_SIZE;
      } rsmu_sec_end_addr_group_2_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_2_mp0_t {
            unsigned int rsmu_sec_end_addr_group_2      : RSMU_SEC_END_ADDR_GROUP_2_MP0_RSMU_SEC_END_ADDR_GROUP_2_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_2_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_2_mp0_t f;
} rsmu_sec_end_addr_group_2_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_2_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_2_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_2_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_2_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_2_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_2_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_2_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_2_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_2_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_2_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_2_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_2_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_2_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_2(rsmu_sec_initid_mask_set0_group_2_mp0) \
      ((rsmu_sec_initid_mask_set0_group_2_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_2_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_2_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_2_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_2_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_2_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_2(rsmu_sec_initid_mask_set0_group_2_mp0_reg, rsmu_sec_initid_mask_set0_group_2) \
      rsmu_sec_initid_mask_set0_group_2_mp0_reg = (rsmu_sec_initid_mask_set0_group_2_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_2_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_2_MASK) | (rsmu_sec_initid_mask_set0_group_2 << RSMU_SEC_INITID_MASK_SET0_GROUP_2_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_2_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_2_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_2 : RSMU_SEC_INITID_MASK_SET0_GROUP_2_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_2_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_2_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_2_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_2 : RSMU_SEC_INITID_MASK_SET0_GROUP_2_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_2_SIZE;
      } rsmu_sec_initid_mask_set0_group_2_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_2_mp0_t f;
} rsmu_sec_initid_mask_set0_group_2_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_2_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_2_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_2_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_2_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_2_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_2_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_2_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_2_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_2_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_2_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_2_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_2_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_2_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_2(rsmu_sec_unitid_mask_set0_group_2_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_2_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_2_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_2_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_2_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_2_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_2_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_2(rsmu_sec_unitid_mask_set0_group_2_mp0_reg, rsmu_sec_unitid_mask_set0_group_2) \
      rsmu_sec_unitid_mask_set0_group_2_mp0_reg = (rsmu_sec_unitid_mask_set0_group_2_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_2_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_2_MASK) | (rsmu_sec_unitid_mask_set0_group_2 << RSMU_SEC_UNITID_MASK_SET0_GROUP_2_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_2_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_2_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_2 : RSMU_SEC_UNITID_MASK_SET0_GROUP_2_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_2_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_2_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_2_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_2 : RSMU_SEC_UNITID_MASK_SET0_GROUP_2_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_2_SIZE;
      } rsmu_sec_unitid_mask_set0_group_2_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_2_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_2_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_2_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_2_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_2_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_2_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_2_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_2_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_2_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_2_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_2_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_2_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_2_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_2_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_2(rsmu_sec_misc_mask_set0_group_2_mp0) \
      ((rsmu_sec_misc_mask_set0_group_2_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_2_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_2_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_2(rsmu_sec_misc_mask_set0_group_2_mp0) \
      ((rsmu_sec_misc_mask_set0_group_2_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_2_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_2_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_2(rsmu_sec_misc_mask_set0_group_2_mp0) \
      ((rsmu_sec_misc_mask_set0_group_2_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_2_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_2_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_2(rsmu_sec_misc_mask_set0_group_2_mp0_reg, rsmu_sec_tlvl_mask_set0_group_2) \
      rsmu_sec_misc_mask_set0_group_2_mp0_reg = (rsmu_sec_misc_mask_set0_group_2_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_2_MASK) | (rsmu_sec_tlvl_mask_set0_group_2 << RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_2_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_2(rsmu_sec_misc_mask_set0_group_2_mp0_reg, rsmu_sec_rw_mask_set0_group_2) \
      rsmu_sec_misc_mask_set0_group_2_mp0_reg = (rsmu_sec_misc_mask_set0_group_2_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_2_MASK) | (rsmu_sec_rw_mask_set0_group_2 << RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_2_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_2(rsmu_sec_misc_mask_set0_group_2_mp0_reg, rsmu_sec_vf_mask_set0_group_2) \
      rsmu_sec_misc_mask_set0_group_2_mp0_reg = (rsmu_sec_misc_mask_set0_group_2_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_2_MASK) | (rsmu_sec_vf_mask_set0_group_2 << RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_2_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_2_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_2 : RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_2_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_2  : RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_2_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_2  : RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_2_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_2_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_2_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_2  : RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_2_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_2  : RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_2_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_2 : RSMU_SEC_MISC_MASK_SET0_GROUP_2_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_2_SIZE;
      } rsmu_sec_misc_mask_set0_group_2_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_2_mp0_t f;
} rsmu_sec_misc_mask_set0_group_2_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_2_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_2_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_2_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_2_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_2_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_2_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_2_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_2_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_2_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_2_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_2_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_2_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_2_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_2(rsmu_sec_initid_mask_set1_group_2_mp0) \
      ((rsmu_sec_initid_mask_set1_group_2_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_2_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_2_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_2_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_2_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_2_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_2(rsmu_sec_initid_mask_set1_group_2_mp0_reg, rsmu_sec_initid_mask_set1_group_2) \
      rsmu_sec_initid_mask_set1_group_2_mp0_reg = (rsmu_sec_initid_mask_set1_group_2_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_2_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_2_MASK) | (rsmu_sec_initid_mask_set1_group_2 << RSMU_SEC_INITID_MASK_SET1_GROUP_2_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_2_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_2_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_2 : RSMU_SEC_INITID_MASK_SET1_GROUP_2_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_2_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_2_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_2_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_2 : RSMU_SEC_INITID_MASK_SET1_GROUP_2_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_2_SIZE;
      } rsmu_sec_initid_mask_set1_group_2_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_2_mp0_t f;
} rsmu_sec_initid_mask_set1_group_2_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_2_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_2_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_2_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_2_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_2_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_2_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_2_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_2_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_2_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_2_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_2_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_2_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_2_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_2(rsmu_sec_unitid_mask_set1_group_2_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_2_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_2_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_2_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_2_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_2_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_2_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_2(rsmu_sec_unitid_mask_set1_group_2_mp0_reg, rsmu_sec_unitid_mask_set1_group_2) \
      rsmu_sec_unitid_mask_set1_group_2_mp0_reg = (rsmu_sec_unitid_mask_set1_group_2_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_2_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_2_MASK) | (rsmu_sec_unitid_mask_set1_group_2 << RSMU_SEC_UNITID_MASK_SET1_GROUP_2_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_2_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_2_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_2 : RSMU_SEC_UNITID_MASK_SET1_GROUP_2_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_2_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_2_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_2_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_2 : RSMU_SEC_UNITID_MASK_SET1_GROUP_2_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_2_SIZE;
      } rsmu_sec_unitid_mask_set1_group_2_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_2_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_2_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_2_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_2_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_2_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_2_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_2_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_2_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_2_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_2_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_2_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_2_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_2_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_2_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_2(rsmu_sec_misc_mask_set1_group_2_mp0) \
      ((rsmu_sec_misc_mask_set1_group_2_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_2_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_2_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_2(rsmu_sec_misc_mask_set1_group_2_mp0) \
      ((rsmu_sec_misc_mask_set1_group_2_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_2_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_2_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_2(rsmu_sec_misc_mask_set1_group_2_mp0) \
      ((rsmu_sec_misc_mask_set1_group_2_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_2_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_2_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_2(rsmu_sec_misc_mask_set1_group_2_mp0_reg, rsmu_sec_tlvl_mask_set1_group_2) \
      rsmu_sec_misc_mask_set1_group_2_mp0_reg = (rsmu_sec_misc_mask_set1_group_2_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_2_MASK) | (rsmu_sec_tlvl_mask_set1_group_2 << RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_2_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_2(rsmu_sec_misc_mask_set1_group_2_mp0_reg, rsmu_sec_rw_mask_set1_group_2) \
      rsmu_sec_misc_mask_set1_group_2_mp0_reg = (rsmu_sec_misc_mask_set1_group_2_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_2_MASK) | (rsmu_sec_rw_mask_set1_group_2 << RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_2_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_2(rsmu_sec_misc_mask_set1_group_2_mp0_reg, rsmu_sec_vf_mask_set1_group_2) \
      rsmu_sec_misc_mask_set1_group_2_mp0_reg = (rsmu_sec_misc_mask_set1_group_2_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_2_MASK) | (rsmu_sec_vf_mask_set1_group_2 << RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_2_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_2_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_2 : RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_2_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_2  : RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_2_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_2  : RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_2_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_2_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_2_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_2  : RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_2_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_2  : RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_2_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_2 : RSMU_SEC_MISC_MASK_SET1_GROUP_2_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_2_SIZE;
      } rsmu_sec_misc_mask_set1_group_2_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_2_mp0_t f;
} rsmu_sec_misc_mask_set1_group_2_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_2_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_2_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_2_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_2_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_2_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_2_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_2_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_2_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_2_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_2_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_2_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_2_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_2_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_2_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_2_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_2_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_2(rsmu_sec_access_control_group_2_mp0) \
      ((rsmu_sec_access_control_group_2_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_2_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_2_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_2(rsmu_sec_access_control_group_2_mp0) \
      ((rsmu_sec_access_control_group_2_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_2_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_2_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_2(rsmu_sec_access_control_group_2_mp0) \
      ((rsmu_sec_access_control_group_2_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_2_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_2_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_2(rsmu_sec_access_control_group_2_mp0) \
      ((rsmu_sec_access_control_group_2_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_2_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_2_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_2(rsmu_sec_access_control_group_2_mp0_reg, rsmu_sec_check_enable_set0_group_2) \
      rsmu_sec_access_control_group_2_mp0_reg = (rsmu_sec_access_control_group_2_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_2_MASK) | (rsmu_sec_check_enable_set0_group_2 << RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_2_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_2(rsmu_sec_access_control_group_2_mp0_reg, rsmu_sec_check_enable_set1_group_2) \
      rsmu_sec_access_control_group_2_mp0_reg = (rsmu_sec_access_control_group_2_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_2_MASK) | (rsmu_sec_check_enable_set1_group_2 << RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_2_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_2(rsmu_sec_access_control_group_2_mp0_reg, rsmu_sec_vf_check_enable_set0_group_2) \
      rsmu_sec_access_control_group_2_mp0_reg = (rsmu_sec_access_control_group_2_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_2_MASK) | (rsmu_sec_vf_check_enable_set0_group_2 << RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_2_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_2(rsmu_sec_access_control_group_2_mp0_reg, rsmu_sec_vf_check_enable_set1_group_2) \
      rsmu_sec_access_control_group_2_mp0_reg = (rsmu_sec_access_control_group_2_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_2_MASK) | (rsmu_sec_vf_check_enable_set1_group_2 << RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_2_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_2_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_2 : RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_2_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_2 : RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_2_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_2 : RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_2_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_2 : RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_2_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_2_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_2_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_2 : RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_2_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_2 : RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_2_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_2 : RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_2_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_2 : RSMU_SEC_ACCESS_CONTROL_GROUP_2_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_2_SIZE;
      } rsmu_sec_access_control_group_2_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_2_mp0_t f;
} rsmu_sec_access_control_group_2_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_3_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_3_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_3_MP0_RSMU_SEC_START_ADDR_GROUP_3_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_3_MP0_RSMU_SEC_START_ADDR_GROUP_3_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_3_MP0_RSMU_SEC_START_ADDR_GROUP_3_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_3_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_3_MP0_RSMU_SEC_START_ADDR_GROUP_3_MASK)

#define RSMU_SEC_START_ADDR_GROUP_3_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_3_MP0_GET_RSMU_SEC_START_ADDR_GROUP_3(rsmu_sec_start_addr_group_3_mp0) \
      ((rsmu_sec_start_addr_group_3_mp0 & RSMU_SEC_START_ADDR_GROUP_3_MP0_RSMU_SEC_START_ADDR_GROUP_3_MASK) >> RSMU_SEC_START_ADDR_GROUP_3_MP0_RSMU_SEC_START_ADDR_GROUP_3_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_3_MP0_SET_RSMU_SEC_START_ADDR_GROUP_3(rsmu_sec_start_addr_group_3_mp0_reg, rsmu_sec_start_addr_group_3) \
      rsmu_sec_start_addr_group_3_mp0_reg = (rsmu_sec_start_addr_group_3_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_3_MP0_RSMU_SEC_START_ADDR_GROUP_3_MASK) | (rsmu_sec_start_addr_group_3 << RSMU_SEC_START_ADDR_GROUP_3_MP0_RSMU_SEC_START_ADDR_GROUP_3_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_3_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_3    : RSMU_SEC_START_ADDR_GROUP_3_MP0_RSMU_SEC_START_ADDR_GROUP_3_SIZE;
      } rsmu_sec_start_addr_group_3_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_3_mp0_t {
            unsigned int rsmu_sec_start_addr_group_3    : RSMU_SEC_START_ADDR_GROUP_3_MP0_RSMU_SEC_START_ADDR_GROUP_3_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_3_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_3_mp0_t f;
} rsmu_sec_start_addr_group_3_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_3_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_3_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_3_MP0_RSMU_SEC_END_ADDR_GROUP_3_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_3_MP0_RSMU_SEC_END_ADDR_GROUP_3_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_3_MP0_RSMU_SEC_END_ADDR_GROUP_3_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_3_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_3_MP0_RSMU_SEC_END_ADDR_GROUP_3_MASK)

#define RSMU_SEC_END_ADDR_GROUP_3_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_3_MP0_GET_RSMU_SEC_END_ADDR_GROUP_3(rsmu_sec_end_addr_group_3_mp0) \
      ((rsmu_sec_end_addr_group_3_mp0 & RSMU_SEC_END_ADDR_GROUP_3_MP0_RSMU_SEC_END_ADDR_GROUP_3_MASK) >> RSMU_SEC_END_ADDR_GROUP_3_MP0_RSMU_SEC_END_ADDR_GROUP_3_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_3_MP0_SET_RSMU_SEC_END_ADDR_GROUP_3(rsmu_sec_end_addr_group_3_mp0_reg, rsmu_sec_end_addr_group_3) \
      rsmu_sec_end_addr_group_3_mp0_reg = (rsmu_sec_end_addr_group_3_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_3_MP0_RSMU_SEC_END_ADDR_GROUP_3_MASK) | (rsmu_sec_end_addr_group_3 << RSMU_SEC_END_ADDR_GROUP_3_MP0_RSMU_SEC_END_ADDR_GROUP_3_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_3_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_3      : RSMU_SEC_END_ADDR_GROUP_3_MP0_RSMU_SEC_END_ADDR_GROUP_3_SIZE;
      } rsmu_sec_end_addr_group_3_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_3_mp0_t {
            unsigned int rsmu_sec_end_addr_group_3      : RSMU_SEC_END_ADDR_GROUP_3_MP0_RSMU_SEC_END_ADDR_GROUP_3_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_3_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_3_mp0_t f;
} rsmu_sec_end_addr_group_3_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_3_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_3_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_3_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_3_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_3_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_3_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_3_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_3_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_3_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_3_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_3_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_3_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_3_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_3(rsmu_sec_initid_mask_set0_group_3_mp0) \
      ((rsmu_sec_initid_mask_set0_group_3_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_3_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_3_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_3_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_3_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_3_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_3(rsmu_sec_initid_mask_set0_group_3_mp0_reg, rsmu_sec_initid_mask_set0_group_3) \
      rsmu_sec_initid_mask_set0_group_3_mp0_reg = (rsmu_sec_initid_mask_set0_group_3_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_3_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_3_MASK) | (rsmu_sec_initid_mask_set0_group_3 << RSMU_SEC_INITID_MASK_SET0_GROUP_3_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_3_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_3_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_3 : RSMU_SEC_INITID_MASK_SET0_GROUP_3_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_3_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_3_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_3_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_3 : RSMU_SEC_INITID_MASK_SET0_GROUP_3_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_3_SIZE;
      } rsmu_sec_initid_mask_set0_group_3_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_3_mp0_t f;
} rsmu_sec_initid_mask_set0_group_3_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_3_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_3_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_3_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_3_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_3_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_3_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_3_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_3_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_3_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_3_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_3_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_3_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_3_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_3(rsmu_sec_unitid_mask_set0_group_3_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_3_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_3_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_3_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_3_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_3_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_3_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_3(rsmu_sec_unitid_mask_set0_group_3_mp0_reg, rsmu_sec_unitid_mask_set0_group_3) \
      rsmu_sec_unitid_mask_set0_group_3_mp0_reg = (rsmu_sec_unitid_mask_set0_group_3_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_3_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_3_MASK) | (rsmu_sec_unitid_mask_set0_group_3 << RSMU_SEC_UNITID_MASK_SET0_GROUP_3_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_3_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_3_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_3 : RSMU_SEC_UNITID_MASK_SET0_GROUP_3_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_3_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_3_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_3_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_3 : RSMU_SEC_UNITID_MASK_SET0_GROUP_3_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_3_SIZE;
      } rsmu_sec_unitid_mask_set0_group_3_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_3_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_3_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_3_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_3_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_3_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_3_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_3_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_3_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_3_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_3_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_3_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_3_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_3_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_3_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_3(rsmu_sec_misc_mask_set0_group_3_mp0) \
      ((rsmu_sec_misc_mask_set0_group_3_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_3_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_3_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_3(rsmu_sec_misc_mask_set0_group_3_mp0) \
      ((rsmu_sec_misc_mask_set0_group_3_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_3_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_3_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_3(rsmu_sec_misc_mask_set0_group_3_mp0) \
      ((rsmu_sec_misc_mask_set0_group_3_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_3_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_3_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_3(rsmu_sec_misc_mask_set0_group_3_mp0_reg, rsmu_sec_tlvl_mask_set0_group_3) \
      rsmu_sec_misc_mask_set0_group_3_mp0_reg = (rsmu_sec_misc_mask_set0_group_3_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_3_MASK) | (rsmu_sec_tlvl_mask_set0_group_3 << RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_3_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_3(rsmu_sec_misc_mask_set0_group_3_mp0_reg, rsmu_sec_rw_mask_set0_group_3) \
      rsmu_sec_misc_mask_set0_group_3_mp0_reg = (rsmu_sec_misc_mask_set0_group_3_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_3_MASK) | (rsmu_sec_rw_mask_set0_group_3 << RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_3_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_3(rsmu_sec_misc_mask_set0_group_3_mp0_reg, rsmu_sec_vf_mask_set0_group_3) \
      rsmu_sec_misc_mask_set0_group_3_mp0_reg = (rsmu_sec_misc_mask_set0_group_3_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_3_MASK) | (rsmu_sec_vf_mask_set0_group_3 << RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_3_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_3_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_3 : RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_3_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_3  : RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_3_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_3  : RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_3_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_3_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_3_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_3  : RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_3_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_3  : RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_3_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_3 : RSMU_SEC_MISC_MASK_SET0_GROUP_3_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_3_SIZE;
      } rsmu_sec_misc_mask_set0_group_3_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_3_mp0_t f;
} rsmu_sec_misc_mask_set0_group_3_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_3_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_3_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_3_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_3_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_3_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_3_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_3_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_3_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_3_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_3_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_3_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_3_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_3_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_3(rsmu_sec_initid_mask_set1_group_3_mp0) \
      ((rsmu_sec_initid_mask_set1_group_3_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_3_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_3_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_3_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_3_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_3_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_3(rsmu_sec_initid_mask_set1_group_3_mp0_reg, rsmu_sec_initid_mask_set1_group_3) \
      rsmu_sec_initid_mask_set1_group_3_mp0_reg = (rsmu_sec_initid_mask_set1_group_3_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_3_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_3_MASK) | (rsmu_sec_initid_mask_set1_group_3 << RSMU_SEC_INITID_MASK_SET1_GROUP_3_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_3_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_3_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_3 : RSMU_SEC_INITID_MASK_SET1_GROUP_3_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_3_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_3_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_3_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_3 : RSMU_SEC_INITID_MASK_SET1_GROUP_3_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_3_SIZE;
      } rsmu_sec_initid_mask_set1_group_3_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_3_mp0_t f;
} rsmu_sec_initid_mask_set1_group_3_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_3_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_3_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_3_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_3_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_3_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_3_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_3_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_3_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_3_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_3_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_3_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_3_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_3_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_3(rsmu_sec_unitid_mask_set1_group_3_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_3_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_3_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_3_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_3_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_3_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_3_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_3(rsmu_sec_unitid_mask_set1_group_3_mp0_reg, rsmu_sec_unitid_mask_set1_group_3) \
      rsmu_sec_unitid_mask_set1_group_3_mp0_reg = (rsmu_sec_unitid_mask_set1_group_3_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_3_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_3_MASK) | (rsmu_sec_unitid_mask_set1_group_3 << RSMU_SEC_UNITID_MASK_SET1_GROUP_3_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_3_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_3_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_3 : RSMU_SEC_UNITID_MASK_SET1_GROUP_3_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_3_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_3_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_3_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_3 : RSMU_SEC_UNITID_MASK_SET1_GROUP_3_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_3_SIZE;
      } rsmu_sec_unitid_mask_set1_group_3_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_3_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_3_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_3_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_3_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_3_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_3_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_3_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_3_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_3_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_3_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_3_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_3_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_3_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_3_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_3(rsmu_sec_misc_mask_set1_group_3_mp0) \
      ((rsmu_sec_misc_mask_set1_group_3_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_3_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_3_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_3(rsmu_sec_misc_mask_set1_group_3_mp0) \
      ((rsmu_sec_misc_mask_set1_group_3_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_3_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_3_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_3(rsmu_sec_misc_mask_set1_group_3_mp0) \
      ((rsmu_sec_misc_mask_set1_group_3_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_3_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_3_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_3(rsmu_sec_misc_mask_set1_group_3_mp0_reg, rsmu_sec_tlvl_mask_set1_group_3) \
      rsmu_sec_misc_mask_set1_group_3_mp0_reg = (rsmu_sec_misc_mask_set1_group_3_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_3_MASK) | (rsmu_sec_tlvl_mask_set1_group_3 << RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_3_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_3(rsmu_sec_misc_mask_set1_group_3_mp0_reg, rsmu_sec_rw_mask_set1_group_3) \
      rsmu_sec_misc_mask_set1_group_3_mp0_reg = (rsmu_sec_misc_mask_set1_group_3_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_3_MASK) | (rsmu_sec_rw_mask_set1_group_3 << RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_3_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_3(rsmu_sec_misc_mask_set1_group_3_mp0_reg, rsmu_sec_vf_mask_set1_group_3) \
      rsmu_sec_misc_mask_set1_group_3_mp0_reg = (rsmu_sec_misc_mask_set1_group_3_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_3_MASK) | (rsmu_sec_vf_mask_set1_group_3 << RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_3_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_3_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_3 : RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_3_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_3  : RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_3_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_3  : RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_3_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_3_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_3_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_3  : RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_3_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_3  : RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_3_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_3 : RSMU_SEC_MISC_MASK_SET1_GROUP_3_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_3_SIZE;
      } rsmu_sec_misc_mask_set1_group_3_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_3_mp0_t f;
} rsmu_sec_misc_mask_set1_group_3_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_3_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_3_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_3_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_3_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_3_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_3_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_3_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_3_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_3_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_3_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_3_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_3_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_3_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_3_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_3_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_3_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_3(rsmu_sec_access_control_group_3_mp0) \
      ((rsmu_sec_access_control_group_3_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_3_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_3_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_3(rsmu_sec_access_control_group_3_mp0) \
      ((rsmu_sec_access_control_group_3_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_3_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_3_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_3(rsmu_sec_access_control_group_3_mp0) \
      ((rsmu_sec_access_control_group_3_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_3_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_3_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_3(rsmu_sec_access_control_group_3_mp0) \
      ((rsmu_sec_access_control_group_3_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_3_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_3_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_3(rsmu_sec_access_control_group_3_mp0_reg, rsmu_sec_check_enable_set0_group_3) \
      rsmu_sec_access_control_group_3_mp0_reg = (rsmu_sec_access_control_group_3_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_3_MASK) | (rsmu_sec_check_enable_set0_group_3 << RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_3_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_3(rsmu_sec_access_control_group_3_mp0_reg, rsmu_sec_check_enable_set1_group_3) \
      rsmu_sec_access_control_group_3_mp0_reg = (rsmu_sec_access_control_group_3_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_3_MASK) | (rsmu_sec_check_enable_set1_group_3 << RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_3_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_3(rsmu_sec_access_control_group_3_mp0_reg, rsmu_sec_vf_check_enable_set0_group_3) \
      rsmu_sec_access_control_group_3_mp0_reg = (rsmu_sec_access_control_group_3_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_3_MASK) | (rsmu_sec_vf_check_enable_set0_group_3 << RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_3_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_3(rsmu_sec_access_control_group_3_mp0_reg, rsmu_sec_vf_check_enable_set1_group_3) \
      rsmu_sec_access_control_group_3_mp0_reg = (rsmu_sec_access_control_group_3_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_3_MASK) | (rsmu_sec_vf_check_enable_set1_group_3 << RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_3_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_3_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_3 : RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_3_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_3 : RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_3_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_3 : RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_3_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_3 : RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_3_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_3_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_3_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_3 : RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_3_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_3 : RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_3_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_3 : RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_3_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_3 : RSMU_SEC_ACCESS_CONTROL_GROUP_3_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_3_SIZE;
      } rsmu_sec_access_control_group_3_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_3_mp0_t f;
} rsmu_sec_access_control_group_3_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_4_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_4_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_4_MP0_RSMU_SEC_START_ADDR_GROUP_4_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_4_MP0_RSMU_SEC_START_ADDR_GROUP_4_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_4_MP0_RSMU_SEC_START_ADDR_GROUP_4_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_4_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_4_MP0_RSMU_SEC_START_ADDR_GROUP_4_MASK)

#define RSMU_SEC_START_ADDR_GROUP_4_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_4_MP0_GET_RSMU_SEC_START_ADDR_GROUP_4(rsmu_sec_start_addr_group_4_mp0) \
      ((rsmu_sec_start_addr_group_4_mp0 & RSMU_SEC_START_ADDR_GROUP_4_MP0_RSMU_SEC_START_ADDR_GROUP_4_MASK) >> RSMU_SEC_START_ADDR_GROUP_4_MP0_RSMU_SEC_START_ADDR_GROUP_4_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_4_MP0_SET_RSMU_SEC_START_ADDR_GROUP_4(rsmu_sec_start_addr_group_4_mp0_reg, rsmu_sec_start_addr_group_4) \
      rsmu_sec_start_addr_group_4_mp0_reg = (rsmu_sec_start_addr_group_4_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_4_MP0_RSMU_SEC_START_ADDR_GROUP_4_MASK) | (rsmu_sec_start_addr_group_4 << RSMU_SEC_START_ADDR_GROUP_4_MP0_RSMU_SEC_START_ADDR_GROUP_4_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_4_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_4    : RSMU_SEC_START_ADDR_GROUP_4_MP0_RSMU_SEC_START_ADDR_GROUP_4_SIZE;
      } rsmu_sec_start_addr_group_4_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_4_mp0_t {
            unsigned int rsmu_sec_start_addr_group_4    : RSMU_SEC_START_ADDR_GROUP_4_MP0_RSMU_SEC_START_ADDR_GROUP_4_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_4_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_4_mp0_t f;
} rsmu_sec_start_addr_group_4_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_4_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_4_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_4_MP0_RSMU_SEC_END_ADDR_GROUP_4_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_4_MP0_RSMU_SEC_END_ADDR_GROUP_4_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_4_MP0_RSMU_SEC_END_ADDR_GROUP_4_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_4_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_4_MP0_RSMU_SEC_END_ADDR_GROUP_4_MASK)

#define RSMU_SEC_END_ADDR_GROUP_4_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_4_MP0_GET_RSMU_SEC_END_ADDR_GROUP_4(rsmu_sec_end_addr_group_4_mp0) \
      ((rsmu_sec_end_addr_group_4_mp0 & RSMU_SEC_END_ADDR_GROUP_4_MP0_RSMU_SEC_END_ADDR_GROUP_4_MASK) >> RSMU_SEC_END_ADDR_GROUP_4_MP0_RSMU_SEC_END_ADDR_GROUP_4_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_4_MP0_SET_RSMU_SEC_END_ADDR_GROUP_4(rsmu_sec_end_addr_group_4_mp0_reg, rsmu_sec_end_addr_group_4) \
      rsmu_sec_end_addr_group_4_mp0_reg = (rsmu_sec_end_addr_group_4_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_4_MP0_RSMU_SEC_END_ADDR_GROUP_4_MASK) | (rsmu_sec_end_addr_group_4 << RSMU_SEC_END_ADDR_GROUP_4_MP0_RSMU_SEC_END_ADDR_GROUP_4_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_4_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_4      : RSMU_SEC_END_ADDR_GROUP_4_MP0_RSMU_SEC_END_ADDR_GROUP_4_SIZE;
      } rsmu_sec_end_addr_group_4_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_4_mp0_t {
            unsigned int rsmu_sec_end_addr_group_4      : RSMU_SEC_END_ADDR_GROUP_4_MP0_RSMU_SEC_END_ADDR_GROUP_4_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_4_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_4_mp0_t f;
} rsmu_sec_end_addr_group_4_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_4_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_4_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_4_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_4_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_4_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_4_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_4_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_4_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_4_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_4_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_4_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_4_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_4_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_4(rsmu_sec_initid_mask_set0_group_4_mp0) \
      ((rsmu_sec_initid_mask_set0_group_4_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_4_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_4_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_4_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_4_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_4_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_4(rsmu_sec_initid_mask_set0_group_4_mp0_reg, rsmu_sec_initid_mask_set0_group_4) \
      rsmu_sec_initid_mask_set0_group_4_mp0_reg = (rsmu_sec_initid_mask_set0_group_4_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_4_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_4_MASK) | (rsmu_sec_initid_mask_set0_group_4 << RSMU_SEC_INITID_MASK_SET0_GROUP_4_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_4_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_4_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_4 : RSMU_SEC_INITID_MASK_SET0_GROUP_4_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_4_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_4_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_4_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_4 : RSMU_SEC_INITID_MASK_SET0_GROUP_4_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_4_SIZE;
      } rsmu_sec_initid_mask_set0_group_4_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_4_mp0_t f;
} rsmu_sec_initid_mask_set0_group_4_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_4_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_4_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_4_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_4_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_4_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_4_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_4_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_4_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_4_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_4_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_4_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_4_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_4_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_4(rsmu_sec_unitid_mask_set0_group_4_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_4_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_4_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_4_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_4_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_4_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_4_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_4(rsmu_sec_unitid_mask_set0_group_4_mp0_reg, rsmu_sec_unitid_mask_set0_group_4) \
      rsmu_sec_unitid_mask_set0_group_4_mp0_reg = (rsmu_sec_unitid_mask_set0_group_4_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_4_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_4_MASK) | (rsmu_sec_unitid_mask_set0_group_4 << RSMU_SEC_UNITID_MASK_SET0_GROUP_4_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_4_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_4_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_4 : RSMU_SEC_UNITID_MASK_SET0_GROUP_4_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_4_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_4_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_4_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_4 : RSMU_SEC_UNITID_MASK_SET0_GROUP_4_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_4_SIZE;
      } rsmu_sec_unitid_mask_set0_group_4_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_4_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_4_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_4_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_4_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_4_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_4_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_4_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_4_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_4_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_4_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_4_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_4_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_4_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_4_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_4(rsmu_sec_misc_mask_set0_group_4_mp0) \
      ((rsmu_sec_misc_mask_set0_group_4_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_4_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_4_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_4(rsmu_sec_misc_mask_set0_group_4_mp0) \
      ((rsmu_sec_misc_mask_set0_group_4_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_4_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_4_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_4(rsmu_sec_misc_mask_set0_group_4_mp0) \
      ((rsmu_sec_misc_mask_set0_group_4_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_4_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_4_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_4(rsmu_sec_misc_mask_set0_group_4_mp0_reg, rsmu_sec_tlvl_mask_set0_group_4) \
      rsmu_sec_misc_mask_set0_group_4_mp0_reg = (rsmu_sec_misc_mask_set0_group_4_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_4_MASK) | (rsmu_sec_tlvl_mask_set0_group_4 << RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_4_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_4(rsmu_sec_misc_mask_set0_group_4_mp0_reg, rsmu_sec_rw_mask_set0_group_4) \
      rsmu_sec_misc_mask_set0_group_4_mp0_reg = (rsmu_sec_misc_mask_set0_group_4_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_4_MASK) | (rsmu_sec_rw_mask_set0_group_4 << RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_4_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_4(rsmu_sec_misc_mask_set0_group_4_mp0_reg, rsmu_sec_vf_mask_set0_group_4) \
      rsmu_sec_misc_mask_set0_group_4_mp0_reg = (rsmu_sec_misc_mask_set0_group_4_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_4_MASK) | (rsmu_sec_vf_mask_set0_group_4 << RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_4_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_4_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_4 : RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_4_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_4  : RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_4_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_4  : RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_4_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_4_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_4_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_4  : RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_4_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_4  : RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_4_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_4 : RSMU_SEC_MISC_MASK_SET0_GROUP_4_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_4_SIZE;
      } rsmu_sec_misc_mask_set0_group_4_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_4_mp0_t f;
} rsmu_sec_misc_mask_set0_group_4_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_4_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_4_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_4_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_4_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_4_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_4_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_4_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_4_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_4_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_4_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_4_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_4_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_4_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_4(rsmu_sec_initid_mask_set1_group_4_mp0) \
      ((rsmu_sec_initid_mask_set1_group_4_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_4_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_4_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_4_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_4_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_4_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_4(rsmu_sec_initid_mask_set1_group_4_mp0_reg, rsmu_sec_initid_mask_set1_group_4) \
      rsmu_sec_initid_mask_set1_group_4_mp0_reg = (rsmu_sec_initid_mask_set1_group_4_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_4_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_4_MASK) | (rsmu_sec_initid_mask_set1_group_4 << RSMU_SEC_INITID_MASK_SET1_GROUP_4_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_4_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_4_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_4 : RSMU_SEC_INITID_MASK_SET1_GROUP_4_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_4_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_4_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_4_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_4 : RSMU_SEC_INITID_MASK_SET1_GROUP_4_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_4_SIZE;
      } rsmu_sec_initid_mask_set1_group_4_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_4_mp0_t f;
} rsmu_sec_initid_mask_set1_group_4_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_4_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_4_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_4_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_4_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_4_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_4_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_4_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_4_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_4_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_4_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_4_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_4_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_4_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_4(rsmu_sec_unitid_mask_set1_group_4_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_4_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_4_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_4_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_4_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_4_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_4_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_4(rsmu_sec_unitid_mask_set1_group_4_mp0_reg, rsmu_sec_unitid_mask_set1_group_4) \
      rsmu_sec_unitid_mask_set1_group_4_mp0_reg = (rsmu_sec_unitid_mask_set1_group_4_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_4_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_4_MASK) | (rsmu_sec_unitid_mask_set1_group_4 << RSMU_SEC_UNITID_MASK_SET1_GROUP_4_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_4_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_4_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_4 : RSMU_SEC_UNITID_MASK_SET1_GROUP_4_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_4_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_4_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_4_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_4 : RSMU_SEC_UNITID_MASK_SET1_GROUP_4_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_4_SIZE;
      } rsmu_sec_unitid_mask_set1_group_4_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_4_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_4_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_4_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_4_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_4_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_4_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_4_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_4_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_4_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_4_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_4_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_4_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_4_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_4_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_4(rsmu_sec_misc_mask_set1_group_4_mp0) \
      ((rsmu_sec_misc_mask_set1_group_4_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_4_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_4_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_4(rsmu_sec_misc_mask_set1_group_4_mp0) \
      ((rsmu_sec_misc_mask_set1_group_4_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_4_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_4_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_4(rsmu_sec_misc_mask_set1_group_4_mp0) \
      ((rsmu_sec_misc_mask_set1_group_4_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_4_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_4_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_4(rsmu_sec_misc_mask_set1_group_4_mp0_reg, rsmu_sec_tlvl_mask_set1_group_4) \
      rsmu_sec_misc_mask_set1_group_4_mp0_reg = (rsmu_sec_misc_mask_set1_group_4_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_4_MASK) | (rsmu_sec_tlvl_mask_set1_group_4 << RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_4_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_4(rsmu_sec_misc_mask_set1_group_4_mp0_reg, rsmu_sec_rw_mask_set1_group_4) \
      rsmu_sec_misc_mask_set1_group_4_mp0_reg = (rsmu_sec_misc_mask_set1_group_4_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_4_MASK) | (rsmu_sec_rw_mask_set1_group_4 << RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_4_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_4(rsmu_sec_misc_mask_set1_group_4_mp0_reg, rsmu_sec_vf_mask_set1_group_4) \
      rsmu_sec_misc_mask_set1_group_4_mp0_reg = (rsmu_sec_misc_mask_set1_group_4_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_4_MASK) | (rsmu_sec_vf_mask_set1_group_4 << RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_4_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_4_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_4 : RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_4_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_4  : RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_4_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_4  : RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_4_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_4_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_4_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_4  : RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_4_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_4  : RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_4_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_4 : RSMU_SEC_MISC_MASK_SET1_GROUP_4_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_4_SIZE;
      } rsmu_sec_misc_mask_set1_group_4_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_4_mp0_t f;
} rsmu_sec_misc_mask_set1_group_4_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_4_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_4_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_4_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_4_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_4_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_4_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_4_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_4_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_4_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_4_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_4_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_4_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_4_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_4_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_4_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_4_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_4(rsmu_sec_access_control_group_4_mp0) \
      ((rsmu_sec_access_control_group_4_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_4_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_4_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_4(rsmu_sec_access_control_group_4_mp0) \
      ((rsmu_sec_access_control_group_4_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_4_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_4_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_4(rsmu_sec_access_control_group_4_mp0) \
      ((rsmu_sec_access_control_group_4_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_4_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_4_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_4(rsmu_sec_access_control_group_4_mp0) \
      ((rsmu_sec_access_control_group_4_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_4_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_4_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_4(rsmu_sec_access_control_group_4_mp0_reg, rsmu_sec_check_enable_set0_group_4) \
      rsmu_sec_access_control_group_4_mp0_reg = (rsmu_sec_access_control_group_4_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_4_MASK) | (rsmu_sec_check_enable_set0_group_4 << RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_4_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_4(rsmu_sec_access_control_group_4_mp0_reg, rsmu_sec_check_enable_set1_group_4) \
      rsmu_sec_access_control_group_4_mp0_reg = (rsmu_sec_access_control_group_4_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_4_MASK) | (rsmu_sec_check_enable_set1_group_4 << RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_4_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_4(rsmu_sec_access_control_group_4_mp0_reg, rsmu_sec_vf_check_enable_set0_group_4) \
      rsmu_sec_access_control_group_4_mp0_reg = (rsmu_sec_access_control_group_4_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_4_MASK) | (rsmu_sec_vf_check_enable_set0_group_4 << RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_4_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_4(rsmu_sec_access_control_group_4_mp0_reg, rsmu_sec_vf_check_enable_set1_group_4) \
      rsmu_sec_access_control_group_4_mp0_reg = (rsmu_sec_access_control_group_4_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_4_MASK) | (rsmu_sec_vf_check_enable_set1_group_4 << RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_4_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_4_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_4 : RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_4_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_4 : RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_4_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_4 : RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_4_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_4 : RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_4_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_4_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_4_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_4 : RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_4_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_4 : RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_4_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_4 : RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_4_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_4 : RSMU_SEC_ACCESS_CONTROL_GROUP_4_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_4_SIZE;
      } rsmu_sec_access_control_group_4_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_4_mp0_t f;
} rsmu_sec_access_control_group_4_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_5_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_5_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_5_MP0_RSMU_SEC_START_ADDR_GROUP_5_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_5_MP0_RSMU_SEC_START_ADDR_GROUP_5_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_5_MP0_RSMU_SEC_START_ADDR_GROUP_5_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_5_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_5_MP0_RSMU_SEC_START_ADDR_GROUP_5_MASK)

#define RSMU_SEC_START_ADDR_GROUP_5_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_5_MP0_GET_RSMU_SEC_START_ADDR_GROUP_5(rsmu_sec_start_addr_group_5_mp0) \
      ((rsmu_sec_start_addr_group_5_mp0 & RSMU_SEC_START_ADDR_GROUP_5_MP0_RSMU_SEC_START_ADDR_GROUP_5_MASK) >> RSMU_SEC_START_ADDR_GROUP_5_MP0_RSMU_SEC_START_ADDR_GROUP_5_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_5_MP0_SET_RSMU_SEC_START_ADDR_GROUP_5(rsmu_sec_start_addr_group_5_mp0_reg, rsmu_sec_start_addr_group_5) \
      rsmu_sec_start_addr_group_5_mp0_reg = (rsmu_sec_start_addr_group_5_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_5_MP0_RSMU_SEC_START_ADDR_GROUP_5_MASK) | (rsmu_sec_start_addr_group_5 << RSMU_SEC_START_ADDR_GROUP_5_MP0_RSMU_SEC_START_ADDR_GROUP_5_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_5_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_5    : RSMU_SEC_START_ADDR_GROUP_5_MP0_RSMU_SEC_START_ADDR_GROUP_5_SIZE;
      } rsmu_sec_start_addr_group_5_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_5_mp0_t {
            unsigned int rsmu_sec_start_addr_group_5    : RSMU_SEC_START_ADDR_GROUP_5_MP0_RSMU_SEC_START_ADDR_GROUP_5_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_5_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_5_mp0_t f;
} rsmu_sec_start_addr_group_5_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_5_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_5_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_5_MP0_RSMU_SEC_END_ADDR_GROUP_5_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_5_MP0_RSMU_SEC_END_ADDR_GROUP_5_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_5_MP0_RSMU_SEC_END_ADDR_GROUP_5_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_5_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_5_MP0_RSMU_SEC_END_ADDR_GROUP_5_MASK)

#define RSMU_SEC_END_ADDR_GROUP_5_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_5_MP0_GET_RSMU_SEC_END_ADDR_GROUP_5(rsmu_sec_end_addr_group_5_mp0) \
      ((rsmu_sec_end_addr_group_5_mp0 & RSMU_SEC_END_ADDR_GROUP_5_MP0_RSMU_SEC_END_ADDR_GROUP_5_MASK) >> RSMU_SEC_END_ADDR_GROUP_5_MP0_RSMU_SEC_END_ADDR_GROUP_5_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_5_MP0_SET_RSMU_SEC_END_ADDR_GROUP_5(rsmu_sec_end_addr_group_5_mp0_reg, rsmu_sec_end_addr_group_5) \
      rsmu_sec_end_addr_group_5_mp0_reg = (rsmu_sec_end_addr_group_5_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_5_MP0_RSMU_SEC_END_ADDR_GROUP_5_MASK) | (rsmu_sec_end_addr_group_5 << RSMU_SEC_END_ADDR_GROUP_5_MP0_RSMU_SEC_END_ADDR_GROUP_5_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_5_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_5      : RSMU_SEC_END_ADDR_GROUP_5_MP0_RSMU_SEC_END_ADDR_GROUP_5_SIZE;
      } rsmu_sec_end_addr_group_5_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_5_mp0_t {
            unsigned int rsmu_sec_end_addr_group_5      : RSMU_SEC_END_ADDR_GROUP_5_MP0_RSMU_SEC_END_ADDR_GROUP_5_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_5_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_5_mp0_t f;
} rsmu_sec_end_addr_group_5_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_5_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_5_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_5_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_5_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_5_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_5_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_5_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_5_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_5_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_5_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_5_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_5_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_5_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_5(rsmu_sec_initid_mask_set0_group_5_mp0) \
      ((rsmu_sec_initid_mask_set0_group_5_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_5_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_5_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_5_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_5_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_5_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_5(rsmu_sec_initid_mask_set0_group_5_mp0_reg, rsmu_sec_initid_mask_set0_group_5) \
      rsmu_sec_initid_mask_set0_group_5_mp0_reg = (rsmu_sec_initid_mask_set0_group_5_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_5_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_5_MASK) | (rsmu_sec_initid_mask_set0_group_5 << RSMU_SEC_INITID_MASK_SET0_GROUP_5_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_5_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_5_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_5 : RSMU_SEC_INITID_MASK_SET0_GROUP_5_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_5_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_5_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_5_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_5 : RSMU_SEC_INITID_MASK_SET0_GROUP_5_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_5_SIZE;
      } rsmu_sec_initid_mask_set0_group_5_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_5_mp0_t f;
} rsmu_sec_initid_mask_set0_group_5_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_5_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_5_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_5_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_5_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_5_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_5_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_5_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_5_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_5_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_5_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_5_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_5_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_5_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_5(rsmu_sec_unitid_mask_set0_group_5_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_5_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_5_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_5_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_5_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_5_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_5_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_5(rsmu_sec_unitid_mask_set0_group_5_mp0_reg, rsmu_sec_unitid_mask_set0_group_5) \
      rsmu_sec_unitid_mask_set0_group_5_mp0_reg = (rsmu_sec_unitid_mask_set0_group_5_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_5_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_5_MASK) | (rsmu_sec_unitid_mask_set0_group_5 << RSMU_SEC_UNITID_MASK_SET0_GROUP_5_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_5_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_5_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_5 : RSMU_SEC_UNITID_MASK_SET0_GROUP_5_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_5_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_5_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_5_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_5 : RSMU_SEC_UNITID_MASK_SET0_GROUP_5_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_5_SIZE;
      } rsmu_sec_unitid_mask_set0_group_5_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_5_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_5_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_5_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_5_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_5_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_5_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_5_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_5_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_5_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_5_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_5_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_5_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_5_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_5_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_5(rsmu_sec_misc_mask_set0_group_5_mp0) \
      ((rsmu_sec_misc_mask_set0_group_5_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_5_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_5_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_5(rsmu_sec_misc_mask_set0_group_5_mp0) \
      ((rsmu_sec_misc_mask_set0_group_5_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_5_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_5_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_5(rsmu_sec_misc_mask_set0_group_5_mp0) \
      ((rsmu_sec_misc_mask_set0_group_5_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_5_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_5_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_5(rsmu_sec_misc_mask_set0_group_5_mp0_reg, rsmu_sec_tlvl_mask_set0_group_5) \
      rsmu_sec_misc_mask_set0_group_5_mp0_reg = (rsmu_sec_misc_mask_set0_group_5_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_5_MASK) | (rsmu_sec_tlvl_mask_set0_group_5 << RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_5_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_5(rsmu_sec_misc_mask_set0_group_5_mp0_reg, rsmu_sec_rw_mask_set0_group_5) \
      rsmu_sec_misc_mask_set0_group_5_mp0_reg = (rsmu_sec_misc_mask_set0_group_5_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_5_MASK) | (rsmu_sec_rw_mask_set0_group_5 << RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_5_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_5(rsmu_sec_misc_mask_set0_group_5_mp0_reg, rsmu_sec_vf_mask_set0_group_5) \
      rsmu_sec_misc_mask_set0_group_5_mp0_reg = (rsmu_sec_misc_mask_set0_group_5_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_5_MASK) | (rsmu_sec_vf_mask_set0_group_5 << RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_5_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_5_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_5 : RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_5_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_5  : RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_5_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_5  : RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_5_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_5_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_5_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_5  : RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_5_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_5  : RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_5_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_5 : RSMU_SEC_MISC_MASK_SET0_GROUP_5_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_5_SIZE;
      } rsmu_sec_misc_mask_set0_group_5_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_5_mp0_t f;
} rsmu_sec_misc_mask_set0_group_5_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_5_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_5_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_5_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_5_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_5_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_5_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_5_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_5_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_5_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_5_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_5_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_5_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_5_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_5(rsmu_sec_initid_mask_set1_group_5_mp0) \
      ((rsmu_sec_initid_mask_set1_group_5_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_5_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_5_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_5_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_5_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_5_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_5(rsmu_sec_initid_mask_set1_group_5_mp0_reg, rsmu_sec_initid_mask_set1_group_5) \
      rsmu_sec_initid_mask_set1_group_5_mp0_reg = (rsmu_sec_initid_mask_set1_group_5_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_5_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_5_MASK) | (rsmu_sec_initid_mask_set1_group_5 << RSMU_SEC_INITID_MASK_SET1_GROUP_5_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_5_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_5_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_5 : RSMU_SEC_INITID_MASK_SET1_GROUP_5_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_5_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_5_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_5_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_5 : RSMU_SEC_INITID_MASK_SET1_GROUP_5_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_5_SIZE;
      } rsmu_sec_initid_mask_set1_group_5_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_5_mp0_t f;
} rsmu_sec_initid_mask_set1_group_5_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_5_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_5_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_5_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_5_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_5_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_5_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_5_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_5_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_5_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_5_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_5_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_5_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_5_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_5(rsmu_sec_unitid_mask_set1_group_5_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_5_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_5_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_5_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_5_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_5_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_5_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_5(rsmu_sec_unitid_mask_set1_group_5_mp0_reg, rsmu_sec_unitid_mask_set1_group_5) \
      rsmu_sec_unitid_mask_set1_group_5_mp0_reg = (rsmu_sec_unitid_mask_set1_group_5_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_5_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_5_MASK) | (rsmu_sec_unitid_mask_set1_group_5 << RSMU_SEC_UNITID_MASK_SET1_GROUP_5_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_5_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_5_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_5 : RSMU_SEC_UNITID_MASK_SET1_GROUP_5_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_5_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_5_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_5_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_5 : RSMU_SEC_UNITID_MASK_SET1_GROUP_5_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_5_SIZE;
      } rsmu_sec_unitid_mask_set1_group_5_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_5_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_5_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_5_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_5_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_5_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_5_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_5_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_5_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_5_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_5_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_5_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_5_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_5_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_5_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_5(rsmu_sec_misc_mask_set1_group_5_mp0) \
      ((rsmu_sec_misc_mask_set1_group_5_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_5_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_5_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_5(rsmu_sec_misc_mask_set1_group_5_mp0) \
      ((rsmu_sec_misc_mask_set1_group_5_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_5_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_5_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_5(rsmu_sec_misc_mask_set1_group_5_mp0) \
      ((rsmu_sec_misc_mask_set1_group_5_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_5_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_5_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_5(rsmu_sec_misc_mask_set1_group_5_mp0_reg, rsmu_sec_tlvl_mask_set1_group_5) \
      rsmu_sec_misc_mask_set1_group_5_mp0_reg = (rsmu_sec_misc_mask_set1_group_5_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_5_MASK) | (rsmu_sec_tlvl_mask_set1_group_5 << RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_5_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_5(rsmu_sec_misc_mask_set1_group_5_mp0_reg, rsmu_sec_rw_mask_set1_group_5) \
      rsmu_sec_misc_mask_set1_group_5_mp0_reg = (rsmu_sec_misc_mask_set1_group_5_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_5_MASK) | (rsmu_sec_rw_mask_set1_group_5 << RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_5_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_5(rsmu_sec_misc_mask_set1_group_5_mp0_reg, rsmu_sec_vf_mask_set1_group_5) \
      rsmu_sec_misc_mask_set1_group_5_mp0_reg = (rsmu_sec_misc_mask_set1_group_5_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_5_MASK) | (rsmu_sec_vf_mask_set1_group_5 << RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_5_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_5_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_5 : RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_5_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_5  : RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_5_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_5  : RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_5_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_5_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_5_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_5  : RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_5_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_5  : RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_5_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_5 : RSMU_SEC_MISC_MASK_SET1_GROUP_5_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_5_SIZE;
      } rsmu_sec_misc_mask_set1_group_5_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_5_mp0_t f;
} rsmu_sec_misc_mask_set1_group_5_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_5_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_5_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_5_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_5_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_5_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_5_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_5_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_5_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_5_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_5_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_5_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_5_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_5_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_5_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_5_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_5_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_5(rsmu_sec_access_control_group_5_mp0) \
      ((rsmu_sec_access_control_group_5_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_5_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_5_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_5(rsmu_sec_access_control_group_5_mp0) \
      ((rsmu_sec_access_control_group_5_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_5_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_5_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_5(rsmu_sec_access_control_group_5_mp0) \
      ((rsmu_sec_access_control_group_5_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_5_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_5_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_5(rsmu_sec_access_control_group_5_mp0) \
      ((rsmu_sec_access_control_group_5_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_5_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_5_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_5(rsmu_sec_access_control_group_5_mp0_reg, rsmu_sec_check_enable_set0_group_5) \
      rsmu_sec_access_control_group_5_mp0_reg = (rsmu_sec_access_control_group_5_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_5_MASK) | (rsmu_sec_check_enable_set0_group_5 << RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_5_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_5(rsmu_sec_access_control_group_5_mp0_reg, rsmu_sec_check_enable_set1_group_5) \
      rsmu_sec_access_control_group_5_mp0_reg = (rsmu_sec_access_control_group_5_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_5_MASK) | (rsmu_sec_check_enable_set1_group_5 << RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_5_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_5(rsmu_sec_access_control_group_5_mp0_reg, rsmu_sec_vf_check_enable_set0_group_5) \
      rsmu_sec_access_control_group_5_mp0_reg = (rsmu_sec_access_control_group_5_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_5_MASK) | (rsmu_sec_vf_check_enable_set0_group_5 << RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_5_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_5(rsmu_sec_access_control_group_5_mp0_reg, rsmu_sec_vf_check_enable_set1_group_5) \
      rsmu_sec_access_control_group_5_mp0_reg = (rsmu_sec_access_control_group_5_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_5_MASK) | (rsmu_sec_vf_check_enable_set1_group_5 << RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_5_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_5_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_5 : RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_5_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_5 : RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_5_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_5 : RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_5_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_5 : RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_5_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_5_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_5_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_5 : RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_5_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_5 : RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_5_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_5 : RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_5_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_5 : RSMU_SEC_ACCESS_CONTROL_GROUP_5_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_5_SIZE;
      } rsmu_sec_access_control_group_5_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_5_mp0_t f;
} rsmu_sec_access_control_group_5_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_6_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_6_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_6_MP0_RSMU_SEC_START_ADDR_GROUP_6_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_6_MP0_RSMU_SEC_START_ADDR_GROUP_6_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_6_MP0_RSMU_SEC_START_ADDR_GROUP_6_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_6_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_6_MP0_RSMU_SEC_START_ADDR_GROUP_6_MASK)

#define RSMU_SEC_START_ADDR_GROUP_6_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_6_MP0_GET_RSMU_SEC_START_ADDR_GROUP_6(rsmu_sec_start_addr_group_6_mp0) \
      ((rsmu_sec_start_addr_group_6_mp0 & RSMU_SEC_START_ADDR_GROUP_6_MP0_RSMU_SEC_START_ADDR_GROUP_6_MASK) >> RSMU_SEC_START_ADDR_GROUP_6_MP0_RSMU_SEC_START_ADDR_GROUP_6_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_6_MP0_SET_RSMU_SEC_START_ADDR_GROUP_6(rsmu_sec_start_addr_group_6_mp0_reg, rsmu_sec_start_addr_group_6) \
      rsmu_sec_start_addr_group_6_mp0_reg = (rsmu_sec_start_addr_group_6_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_6_MP0_RSMU_SEC_START_ADDR_GROUP_6_MASK) | (rsmu_sec_start_addr_group_6 << RSMU_SEC_START_ADDR_GROUP_6_MP0_RSMU_SEC_START_ADDR_GROUP_6_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_6_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_6    : RSMU_SEC_START_ADDR_GROUP_6_MP0_RSMU_SEC_START_ADDR_GROUP_6_SIZE;
      } rsmu_sec_start_addr_group_6_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_6_mp0_t {
            unsigned int rsmu_sec_start_addr_group_6    : RSMU_SEC_START_ADDR_GROUP_6_MP0_RSMU_SEC_START_ADDR_GROUP_6_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_6_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_6_mp0_t f;
} rsmu_sec_start_addr_group_6_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_6_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_6_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_6_MP0_RSMU_SEC_END_ADDR_GROUP_6_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_6_MP0_RSMU_SEC_END_ADDR_GROUP_6_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_6_MP0_RSMU_SEC_END_ADDR_GROUP_6_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_6_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_6_MP0_RSMU_SEC_END_ADDR_GROUP_6_MASK)

#define RSMU_SEC_END_ADDR_GROUP_6_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_6_MP0_GET_RSMU_SEC_END_ADDR_GROUP_6(rsmu_sec_end_addr_group_6_mp0) \
      ((rsmu_sec_end_addr_group_6_mp0 & RSMU_SEC_END_ADDR_GROUP_6_MP0_RSMU_SEC_END_ADDR_GROUP_6_MASK) >> RSMU_SEC_END_ADDR_GROUP_6_MP0_RSMU_SEC_END_ADDR_GROUP_6_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_6_MP0_SET_RSMU_SEC_END_ADDR_GROUP_6(rsmu_sec_end_addr_group_6_mp0_reg, rsmu_sec_end_addr_group_6) \
      rsmu_sec_end_addr_group_6_mp0_reg = (rsmu_sec_end_addr_group_6_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_6_MP0_RSMU_SEC_END_ADDR_GROUP_6_MASK) | (rsmu_sec_end_addr_group_6 << RSMU_SEC_END_ADDR_GROUP_6_MP0_RSMU_SEC_END_ADDR_GROUP_6_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_6_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_6      : RSMU_SEC_END_ADDR_GROUP_6_MP0_RSMU_SEC_END_ADDR_GROUP_6_SIZE;
      } rsmu_sec_end_addr_group_6_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_6_mp0_t {
            unsigned int rsmu_sec_end_addr_group_6      : RSMU_SEC_END_ADDR_GROUP_6_MP0_RSMU_SEC_END_ADDR_GROUP_6_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_6_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_6_mp0_t f;
} rsmu_sec_end_addr_group_6_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_6_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_6_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_6_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_6_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_6_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_6_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_6_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_6_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_6_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_6_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_6_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_6_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_6_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_6(rsmu_sec_initid_mask_set0_group_6_mp0) \
      ((rsmu_sec_initid_mask_set0_group_6_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_6_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_6_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_6_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_6_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_6_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_6(rsmu_sec_initid_mask_set0_group_6_mp0_reg, rsmu_sec_initid_mask_set0_group_6) \
      rsmu_sec_initid_mask_set0_group_6_mp0_reg = (rsmu_sec_initid_mask_set0_group_6_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_6_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_6_MASK) | (rsmu_sec_initid_mask_set0_group_6 << RSMU_SEC_INITID_MASK_SET0_GROUP_6_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_6_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_6_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_6 : RSMU_SEC_INITID_MASK_SET0_GROUP_6_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_6_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_6_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_6_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_6 : RSMU_SEC_INITID_MASK_SET0_GROUP_6_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_6_SIZE;
      } rsmu_sec_initid_mask_set0_group_6_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_6_mp0_t f;
} rsmu_sec_initid_mask_set0_group_6_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_6_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_6_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_6_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_6_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_6_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_6_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_6_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_6_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_6_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_6_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_6_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_6_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_6_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_6(rsmu_sec_unitid_mask_set0_group_6_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_6_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_6_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_6_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_6_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_6_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_6_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_6(rsmu_sec_unitid_mask_set0_group_6_mp0_reg, rsmu_sec_unitid_mask_set0_group_6) \
      rsmu_sec_unitid_mask_set0_group_6_mp0_reg = (rsmu_sec_unitid_mask_set0_group_6_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_6_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_6_MASK) | (rsmu_sec_unitid_mask_set0_group_6 << RSMU_SEC_UNITID_MASK_SET0_GROUP_6_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_6_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_6_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_6 : RSMU_SEC_UNITID_MASK_SET0_GROUP_6_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_6_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_6_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_6_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_6 : RSMU_SEC_UNITID_MASK_SET0_GROUP_6_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_6_SIZE;
      } rsmu_sec_unitid_mask_set0_group_6_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_6_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_6_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_6_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_6_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_6_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_6_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_6_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_6_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_6_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_6_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_6_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_6_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_6_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_6_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_6(rsmu_sec_misc_mask_set0_group_6_mp0) \
      ((rsmu_sec_misc_mask_set0_group_6_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_6_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_6_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_6(rsmu_sec_misc_mask_set0_group_6_mp0) \
      ((rsmu_sec_misc_mask_set0_group_6_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_6_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_6_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_6(rsmu_sec_misc_mask_set0_group_6_mp0) \
      ((rsmu_sec_misc_mask_set0_group_6_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_6_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_6_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_6(rsmu_sec_misc_mask_set0_group_6_mp0_reg, rsmu_sec_tlvl_mask_set0_group_6) \
      rsmu_sec_misc_mask_set0_group_6_mp0_reg = (rsmu_sec_misc_mask_set0_group_6_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_6_MASK) | (rsmu_sec_tlvl_mask_set0_group_6 << RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_6_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_6(rsmu_sec_misc_mask_set0_group_6_mp0_reg, rsmu_sec_rw_mask_set0_group_6) \
      rsmu_sec_misc_mask_set0_group_6_mp0_reg = (rsmu_sec_misc_mask_set0_group_6_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_6_MASK) | (rsmu_sec_rw_mask_set0_group_6 << RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_6_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_6(rsmu_sec_misc_mask_set0_group_6_mp0_reg, rsmu_sec_vf_mask_set0_group_6) \
      rsmu_sec_misc_mask_set0_group_6_mp0_reg = (rsmu_sec_misc_mask_set0_group_6_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_6_MASK) | (rsmu_sec_vf_mask_set0_group_6 << RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_6_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_6_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_6 : RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_6_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_6  : RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_6_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_6  : RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_6_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_6_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_6_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_6  : RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_6_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_6  : RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_6_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_6 : RSMU_SEC_MISC_MASK_SET0_GROUP_6_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_6_SIZE;
      } rsmu_sec_misc_mask_set0_group_6_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_6_mp0_t f;
} rsmu_sec_misc_mask_set0_group_6_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_6_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_6_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_6_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_6_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_6_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_6_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_6_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_6_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_6_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_6_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_6_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_6_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_6_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_6(rsmu_sec_initid_mask_set1_group_6_mp0) \
      ((rsmu_sec_initid_mask_set1_group_6_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_6_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_6_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_6_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_6_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_6_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_6(rsmu_sec_initid_mask_set1_group_6_mp0_reg, rsmu_sec_initid_mask_set1_group_6) \
      rsmu_sec_initid_mask_set1_group_6_mp0_reg = (rsmu_sec_initid_mask_set1_group_6_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_6_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_6_MASK) | (rsmu_sec_initid_mask_set1_group_6 << RSMU_SEC_INITID_MASK_SET1_GROUP_6_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_6_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_6_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_6 : RSMU_SEC_INITID_MASK_SET1_GROUP_6_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_6_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_6_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_6_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_6 : RSMU_SEC_INITID_MASK_SET1_GROUP_6_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_6_SIZE;
      } rsmu_sec_initid_mask_set1_group_6_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_6_mp0_t f;
} rsmu_sec_initid_mask_set1_group_6_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_6_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_6_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_6_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_6_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_6_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_6_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_6_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_6_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_6_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_6_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_6_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_6_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_6_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_6(rsmu_sec_unitid_mask_set1_group_6_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_6_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_6_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_6_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_6_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_6_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_6_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_6(rsmu_sec_unitid_mask_set1_group_6_mp0_reg, rsmu_sec_unitid_mask_set1_group_6) \
      rsmu_sec_unitid_mask_set1_group_6_mp0_reg = (rsmu_sec_unitid_mask_set1_group_6_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_6_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_6_MASK) | (rsmu_sec_unitid_mask_set1_group_6 << RSMU_SEC_UNITID_MASK_SET1_GROUP_6_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_6_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_6_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_6 : RSMU_SEC_UNITID_MASK_SET1_GROUP_6_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_6_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_6_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_6_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_6 : RSMU_SEC_UNITID_MASK_SET1_GROUP_6_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_6_SIZE;
      } rsmu_sec_unitid_mask_set1_group_6_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_6_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_6_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_6_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_6_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_6_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_6_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_6_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_6_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_6_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_6_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_6_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_6_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_6_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_6_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_6(rsmu_sec_misc_mask_set1_group_6_mp0) \
      ((rsmu_sec_misc_mask_set1_group_6_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_6_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_6_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_6(rsmu_sec_misc_mask_set1_group_6_mp0) \
      ((rsmu_sec_misc_mask_set1_group_6_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_6_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_6_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_6(rsmu_sec_misc_mask_set1_group_6_mp0) \
      ((rsmu_sec_misc_mask_set1_group_6_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_6_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_6_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_6(rsmu_sec_misc_mask_set1_group_6_mp0_reg, rsmu_sec_tlvl_mask_set1_group_6) \
      rsmu_sec_misc_mask_set1_group_6_mp0_reg = (rsmu_sec_misc_mask_set1_group_6_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_6_MASK) | (rsmu_sec_tlvl_mask_set1_group_6 << RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_6_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_6(rsmu_sec_misc_mask_set1_group_6_mp0_reg, rsmu_sec_rw_mask_set1_group_6) \
      rsmu_sec_misc_mask_set1_group_6_mp0_reg = (rsmu_sec_misc_mask_set1_group_6_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_6_MASK) | (rsmu_sec_rw_mask_set1_group_6 << RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_6_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_6(rsmu_sec_misc_mask_set1_group_6_mp0_reg, rsmu_sec_vf_mask_set1_group_6) \
      rsmu_sec_misc_mask_set1_group_6_mp0_reg = (rsmu_sec_misc_mask_set1_group_6_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_6_MASK) | (rsmu_sec_vf_mask_set1_group_6 << RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_6_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_6_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_6 : RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_6_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_6  : RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_6_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_6  : RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_6_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_6_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_6_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_6  : RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_6_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_6  : RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_6_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_6 : RSMU_SEC_MISC_MASK_SET1_GROUP_6_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_6_SIZE;
      } rsmu_sec_misc_mask_set1_group_6_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_6_mp0_t f;
} rsmu_sec_misc_mask_set1_group_6_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_6_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_6_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_6_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_6_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_6_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_6_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_6_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_6_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_6_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_6_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_6_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_6_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_6_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_6_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_6_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_6_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_6(rsmu_sec_access_control_group_6_mp0) \
      ((rsmu_sec_access_control_group_6_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_6_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_6_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_6(rsmu_sec_access_control_group_6_mp0) \
      ((rsmu_sec_access_control_group_6_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_6_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_6_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_6(rsmu_sec_access_control_group_6_mp0) \
      ((rsmu_sec_access_control_group_6_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_6_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_6_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_6(rsmu_sec_access_control_group_6_mp0) \
      ((rsmu_sec_access_control_group_6_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_6_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_6_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_6(rsmu_sec_access_control_group_6_mp0_reg, rsmu_sec_check_enable_set0_group_6) \
      rsmu_sec_access_control_group_6_mp0_reg = (rsmu_sec_access_control_group_6_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_6_MASK) | (rsmu_sec_check_enable_set0_group_6 << RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_6_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_6(rsmu_sec_access_control_group_6_mp0_reg, rsmu_sec_check_enable_set1_group_6) \
      rsmu_sec_access_control_group_6_mp0_reg = (rsmu_sec_access_control_group_6_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_6_MASK) | (rsmu_sec_check_enable_set1_group_6 << RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_6_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_6(rsmu_sec_access_control_group_6_mp0_reg, rsmu_sec_vf_check_enable_set0_group_6) \
      rsmu_sec_access_control_group_6_mp0_reg = (rsmu_sec_access_control_group_6_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_6_MASK) | (rsmu_sec_vf_check_enable_set0_group_6 << RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_6_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_6(rsmu_sec_access_control_group_6_mp0_reg, rsmu_sec_vf_check_enable_set1_group_6) \
      rsmu_sec_access_control_group_6_mp0_reg = (rsmu_sec_access_control_group_6_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_6_MASK) | (rsmu_sec_vf_check_enable_set1_group_6 << RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_6_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_6_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_6 : RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_6_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_6 : RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_6_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_6 : RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_6_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_6 : RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_6_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_6_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_6_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_6 : RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_6_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_6 : RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_6_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_6 : RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_6_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_6 : RSMU_SEC_ACCESS_CONTROL_GROUP_6_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_6_SIZE;
      } rsmu_sec_access_control_group_6_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_6_mp0_t f;
} rsmu_sec_access_control_group_6_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_7_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_7_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_7_MP0_RSMU_SEC_START_ADDR_GROUP_7_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_7_MP0_RSMU_SEC_START_ADDR_GROUP_7_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_7_MP0_RSMU_SEC_START_ADDR_GROUP_7_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_7_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_7_MP0_RSMU_SEC_START_ADDR_GROUP_7_MASK)

#define RSMU_SEC_START_ADDR_GROUP_7_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_7_MP0_GET_RSMU_SEC_START_ADDR_GROUP_7(rsmu_sec_start_addr_group_7_mp0) \
      ((rsmu_sec_start_addr_group_7_mp0 & RSMU_SEC_START_ADDR_GROUP_7_MP0_RSMU_SEC_START_ADDR_GROUP_7_MASK) >> RSMU_SEC_START_ADDR_GROUP_7_MP0_RSMU_SEC_START_ADDR_GROUP_7_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_7_MP0_SET_RSMU_SEC_START_ADDR_GROUP_7(rsmu_sec_start_addr_group_7_mp0_reg, rsmu_sec_start_addr_group_7) \
      rsmu_sec_start_addr_group_7_mp0_reg = (rsmu_sec_start_addr_group_7_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_7_MP0_RSMU_SEC_START_ADDR_GROUP_7_MASK) | (rsmu_sec_start_addr_group_7 << RSMU_SEC_START_ADDR_GROUP_7_MP0_RSMU_SEC_START_ADDR_GROUP_7_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_7_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_7    : RSMU_SEC_START_ADDR_GROUP_7_MP0_RSMU_SEC_START_ADDR_GROUP_7_SIZE;
      } rsmu_sec_start_addr_group_7_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_7_mp0_t {
            unsigned int rsmu_sec_start_addr_group_7    : RSMU_SEC_START_ADDR_GROUP_7_MP0_RSMU_SEC_START_ADDR_GROUP_7_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_7_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_7_mp0_t f;
} rsmu_sec_start_addr_group_7_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_7_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_7_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_7_MP0_RSMU_SEC_END_ADDR_GROUP_7_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_7_MP0_RSMU_SEC_END_ADDR_GROUP_7_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_7_MP0_RSMU_SEC_END_ADDR_GROUP_7_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_7_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_7_MP0_RSMU_SEC_END_ADDR_GROUP_7_MASK)

#define RSMU_SEC_END_ADDR_GROUP_7_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_7_MP0_GET_RSMU_SEC_END_ADDR_GROUP_7(rsmu_sec_end_addr_group_7_mp0) \
      ((rsmu_sec_end_addr_group_7_mp0 & RSMU_SEC_END_ADDR_GROUP_7_MP0_RSMU_SEC_END_ADDR_GROUP_7_MASK) >> RSMU_SEC_END_ADDR_GROUP_7_MP0_RSMU_SEC_END_ADDR_GROUP_7_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_7_MP0_SET_RSMU_SEC_END_ADDR_GROUP_7(rsmu_sec_end_addr_group_7_mp0_reg, rsmu_sec_end_addr_group_7) \
      rsmu_sec_end_addr_group_7_mp0_reg = (rsmu_sec_end_addr_group_7_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_7_MP0_RSMU_SEC_END_ADDR_GROUP_7_MASK) | (rsmu_sec_end_addr_group_7 << RSMU_SEC_END_ADDR_GROUP_7_MP0_RSMU_SEC_END_ADDR_GROUP_7_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_7_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_7      : RSMU_SEC_END_ADDR_GROUP_7_MP0_RSMU_SEC_END_ADDR_GROUP_7_SIZE;
      } rsmu_sec_end_addr_group_7_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_7_mp0_t {
            unsigned int rsmu_sec_end_addr_group_7      : RSMU_SEC_END_ADDR_GROUP_7_MP0_RSMU_SEC_END_ADDR_GROUP_7_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_7_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_7_mp0_t f;
} rsmu_sec_end_addr_group_7_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_7_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_7_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_7_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_7_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_7_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_7_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_7_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_7_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_7_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_7_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_7_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_7_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_7_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_7(rsmu_sec_initid_mask_set0_group_7_mp0) \
      ((rsmu_sec_initid_mask_set0_group_7_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_7_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_7_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_7_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_7_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_7_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_7(rsmu_sec_initid_mask_set0_group_7_mp0_reg, rsmu_sec_initid_mask_set0_group_7) \
      rsmu_sec_initid_mask_set0_group_7_mp0_reg = (rsmu_sec_initid_mask_set0_group_7_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_7_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_7_MASK) | (rsmu_sec_initid_mask_set0_group_7 << RSMU_SEC_INITID_MASK_SET0_GROUP_7_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_7_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_7_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_7 : RSMU_SEC_INITID_MASK_SET0_GROUP_7_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_7_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_7_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_7_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_7 : RSMU_SEC_INITID_MASK_SET0_GROUP_7_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_7_SIZE;
      } rsmu_sec_initid_mask_set0_group_7_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_7_mp0_t f;
} rsmu_sec_initid_mask_set0_group_7_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_7_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_7_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_7_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_7_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_7_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_7_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_7_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_7_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_7_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_7_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_7_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_7_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_7_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_7(rsmu_sec_unitid_mask_set0_group_7_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_7_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_7_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_7_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_7_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_7_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_7_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_7(rsmu_sec_unitid_mask_set0_group_7_mp0_reg, rsmu_sec_unitid_mask_set0_group_7) \
      rsmu_sec_unitid_mask_set0_group_7_mp0_reg = (rsmu_sec_unitid_mask_set0_group_7_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_7_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_7_MASK) | (rsmu_sec_unitid_mask_set0_group_7 << RSMU_SEC_UNITID_MASK_SET0_GROUP_7_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_7_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_7_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_7 : RSMU_SEC_UNITID_MASK_SET0_GROUP_7_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_7_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_7_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_7_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_7 : RSMU_SEC_UNITID_MASK_SET0_GROUP_7_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_7_SIZE;
      } rsmu_sec_unitid_mask_set0_group_7_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_7_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_7_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_7_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_7_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_7_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_7_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_7_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_7_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_7_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_7_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_7_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_7_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_7_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_7_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_7(rsmu_sec_misc_mask_set0_group_7_mp0) \
      ((rsmu_sec_misc_mask_set0_group_7_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_7_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_7_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_7(rsmu_sec_misc_mask_set0_group_7_mp0) \
      ((rsmu_sec_misc_mask_set0_group_7_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_7_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_7_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_7(rsmu_sec_misc_mask_set0_group_7_mp0) \
      ((rsmu_sec_misc_mask_set0_group_7_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_7_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_7_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_7(rsmu_sec_misc_mask_set0_group_7_mp0_reg, rsmu_sec_tlvl_mask_set0_group_7) \
      rsmu_sec_misc_mask_set0_group_7_mp0_reg = (rsmu_sec_misc_mask_set0_group_7_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_7_MASK) | (rsmu_sec_tlvl_mask_set0_group_7 << RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_7_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_7(rsmu_sec_misc_mask_set0_group_7_mp0_reg, rsmu_sec_rw_mask_set0_group_7) \
      rsmu_sec_misc_mask_set0_group_7_mp0_reg = (rsmu_sec_misc_mask_set0_group_7_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_7_MASK) | (rsmu_sec_rw_mask_set0_group_7 << RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_7_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_7(rsmu_sec_misc_mask_set0_group_7_mp0_reg, rsmu_sec_vf_mask_set0_group_7) \
      rsmu_sec_misc_mask_set0_group_7_mp0_reg = (rsmu_sec_misc_mask_set0_group_7_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_7_MASK) | (rsmu_sec_vf_mask_set0_group_7 << RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_7_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_7_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_7 : RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_7_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_7  : RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_7_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_7  : RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_7_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_7_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_7_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_7  : RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_7_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_7  : RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_7_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_7 : RSMU_SEC_MISC_MASK_SET0_GROUP_7_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_7_SIZE;
      } rsmu_sec_misc_mask_set0_group_7_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_7_mp0_t f;
} rsmu_sec_misc_mask_set0_group_7_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_7_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_7_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_7_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_7_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_7_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_7_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_7_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_7_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_7_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_7_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_7_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_7_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_7_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_7(rsmu_sec_initid_mask_set1_group_7_mp0) \
      ((rsmu_sec_initid_mask_set1_group_7_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_7_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_7_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_7_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_7_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_7_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_7(rsmu_sec_initid_mask_set1_group_7_mp0_reg, rsmu_sec_initid_mask_set1_group_7) \
      rsmu_sec_initid_mask_set1_group_7_mp0_reg = (rsmu_sec_initid_mask_set1_group_7_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_7_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_7_MASK) | (rsmu_sec_initid_mask_set1_group_7 << RSMU_SEC_INITID_MASK_SET1_GROUP_7_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_7_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_7_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_7 : RSMU_SEC_INITID_MASK_SET1_GROUP_7_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_7_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_7_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_7_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_7 : RSMU_SEC_INITID_MASK_SET1_GROUP_7_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_7_SIZE;
      } rsmu_sec_initid_mask_set1_group_7_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_7_mp0_t f;
} rsmu_sec_initid_mask_set1_group_7_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_7_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_7_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_7_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_7_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_7_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_7_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_7_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_7_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_7_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_7_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_7_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_7_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_7_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_7(rsmu_sec_unitid_mask_set1_group_7_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_7_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_7_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_7_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_7_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_7_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_7_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_7(rsmu_sec_unitid_mask_set1_group_7_mp0_reg, rsmu_sec_unitid_mask_set1_group_7) \
      rsmu_sec_unitid_mask_set1_group_7_mp0_reg = (rsmu_sec_unitid_mask_set1_group_7_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_7_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_7_MASK) | (rsmu_sec_unitid_mask_set1_group_7 << RSMU_SEC_UNITID_MASK_SET1_GROUP_7_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_7_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_7_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_7 : RSMU_SEC_UNITID_MASK_SET1_GROUP_7_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_7_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_7_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_7_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_7 : RSMU_SEC_UNITID_MASK_SET1_GROUP_7_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_7_SIZE;
      } rsmu_sec_unitid_mask_set1_group_7_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_7_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_7_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_7_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_7_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_7_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_7_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_7_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_7_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_7_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_7_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_7_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_7_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_7_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_7_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_7(rsmu_sec_misc_mask_set1_group_7_mp0) \
      ((rsmu_sec_misc_mask_set1_group_7_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_7_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_7_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_7(rsmu_sec_misc_mask_set1_group_7_mp0) \
      ((rsmu_sec_misc_mask_set1_group_7_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_7_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_7_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_7(rsmu_sec_misc_mask_set1_group_7_mp0) \
      ((rsmu_sec_misc_mask_set1_group_7_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_7_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_7_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_7(rsmu_sec_misc_mask_set1_group_7_mp0_reg, rsmu_sec_tlvl_mask_set1_group_7) \
      rsmu_sec_misc_mask_set1_group_7_mp0_reg = (rsmu_sec_misc_mask_set1_group_7_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_7_MASK) | (rsmu_sec_tlvl_mask_set1_group_7 << RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_7_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_7(rsmu_sec_misc_mask_set1_group_7_mp0_reg, rsmu_sec_rw_mask_set1_group_7) \
      rsmu_sec_misc_mask_set1_group_7_mp0_reg = (rsmu_sec_misc_mask_set1_group_7_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_7_MASK) | (rsmu_sec_rw_mask_set1_group_7 << RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_7_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_7(rsmu_sec_misc_mask_set1_group_7_mp0_reg, rsmu_sec_vf_mask_set1_group_7) \
      rsmu_sec_misc_mask_set1_group_7_mp0_reg = (rsmu_sec_misc_mask_set1_group_7_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_7_MASK) | (rsmu_sec_vf_mask_set1_group_7 << RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_7_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_7_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_7 : RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_7_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_7  : RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_7_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_7  : RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_7_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_7_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_7_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_7  : RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_7_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_7  : RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_7_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_7 : RSMU_SEC_MISC_MASK_SET1_GROUP_7_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_7_SIZE;
      } rsmu_sec_misc_mask_set1_group_7_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_7_mp0_t f;
} rsmu_sec_misc_mask_set1_group_7_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_7_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_7_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_7_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_7_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_7_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_7_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_7_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_7_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_7_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_7_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_7_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_7_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_7_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_7_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_7_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_7_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_7(rsmu_sec_access_control_group_7_mp0) \
      ((rsmu_sec_access_control_group_7_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_7_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_7_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_7(rsmu_sec_access_control_group_7_mp0) \
      ((rsmu_sec_access_control_group_7_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_7_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_7_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_7(rsmu_sec_access_control_group_7_mp0) \
      ((rsmu_sec_access_control_group_7_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_7_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_7_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_7(rsmu_sec_access_control_group_7_mp0) \
      ((rsmu_sec_access_control_group_7_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_7_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_7_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_7(rsmu_sec_access_control_group_7_mp0_reg, rsmu_sec_check_enable_set0_group_7) \
      rsmu_sec_access_control_group_7_mp0_reg = (rsmu_sec_access_control_group_7_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_7_MASK) | (rsmu_sec_check_enable_set0_group_7 << RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_7_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_7(rsmu_sec_access_control_group_7_mp0_reg, rsmu_sec_check_enable_set1_group_7) \
      rsmu_sec_access_control_group_7_mp0_reg = (rsmu_sec_access_control_group_7_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_7_MASK) | (rsmu_sec_check_enable_set1_group_7 << RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_7_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_7(rsmu_sec_access_control_group_7_mp0_reg, rsmu_sec_vf_check_enable_set0_group_7) \
      rsmu_sec_access_control_group_7_mp0_reg = (rsmu_sec_access_control_group_7_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_7_MASK) | (rsmu_sec_vf_check_enable_set0_group_7 << RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_7_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_7(rsmu_sec_access_control_group_7_mp0_reg, rsmu_sec_vf_check_enable_set1_group_7) \
      rsmu_sec_access_control_group_7_mp0_reg = (rsmu_sec_access_control_group_7_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_7_MASK) | (rsmu_sec_vf_check_enable_set1_group_7 << RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_7_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_7_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_7 : RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_7_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_7 : RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_7_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_7 : RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_7_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_7 : RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_7_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_7_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_7_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_7 : RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_7_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_7 : RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_7_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_7 : RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_7_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_7 : RSMU_SEC_ACCESS_CONTROL_GROUP_7_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_7_SIZE;
      } rsmu_sec_access_control_group_7_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_7_mp0_t f;
} rsmu_sec_access_control_group_7_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_8_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_8_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_8_MP0_RSMU_SEC_START_ADDR_GROUP_8_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_8_MP0_RSMU_SEC_START_ADDR_GROUP_8_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_8_MP0_RSMU_SEC_START_ADDR_GROUP_8_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_8_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_8_MP0_RSMU_SEC_START_ADDR_GROUP_8_MASK)

#define RSMU_SEC_START_ADDR_GROUP_8_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_8_MP0_GET_RSMU_SEC_START_ADDR_GROUP_8(rsmu_sec_start_addr_group_8_mp0) \
      ((rsmu_sec_start_addr_group_8_mp0 & RSMU_SEC_START_ADDR_GROUP_8_MP0_RSMU_SEC_START_ADDR_GROUP_8_MASK) >> RSMU_SEC_START_ADDR_GROUP_8_MP0_RSMU_SEC_START_ADDR_GROUP_8_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_8_MP0_SET_RSMU_SEC_START_ADDR_GROUP_8(rsmu_sec_start_addr_group_8_mp0_reg, rsmu_sec_start_addr_group_8) \
      rsmu_sec_start_addr_group_8_mp0_reg = (rsmu_sec_start_addr_group_8_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_8_MP0_RSMU_SEC_START_ADDR_GROUP_8_MASK) | (rsmu_sec_start_addr_group_8 << RSMU_SEC_START_ADDR_GROUP_8_MP0_RSMU_SEC_START_ADDR_GROUP_8_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_8_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_8    : RSMU_SEC_START_ADDR_GROUP_8_MP0_RSMU_SEC_START_ADDR_GROUP_8_SIZE;
      } rsmu_sec_start_addr_group_8_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_8_mp0_t {
            unsigned int rsmu_sec_start_addr_group_8    : RSMU_SEC_START_ADDR_GROUP_8_MP0_RSMU_SEC_START_ADDR_GROUP_8_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_8_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_8_mp0_t f;
} rsmu_sec_start_addr_group_8_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_8_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_8_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_8_MP0_RSMU_SEC_END_ADDR_GROUP_8_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_8_MP0_RSMU_SEC_END_ADDR_GROUP_8_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_8_MP0_RSMU_SEC_END_ADDR_GROUP_8_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_8_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_8_MP0_RSMU_SEC_END_ADDR_GROUP_8_MASK)

#define RSMU_SEC_END_ADDR_GROUP_8_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_8_MP0_GET_RSMU_SEC_END_ADDR_GROUP_8(rsmu_sec_end_addr_group_8_mp0) \
      ((rsmu_sec_end_addr_group_8_mp0 & RSMU_SEC_END_ADDR_GROUP_8_MP0_RSMU_SEC_END_ADDR_GROUP_8_MASK) >> RSMU_SEC_END_ADDR_GROUP_8_MP0_RSMU_SEC_END_ADDR_GROUP_8_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_8_MP0_SET_RSMU_SEC_END_ADDR_GROUP_8(rsmu_sec_end_addr_group_8_mp0_reg, rsmu_sec_end_addr_group_8) \
      rsmu_sec_end_addr_group_8_mp0_reg = (rsmu_sec_end_addr_group_8_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_8_MP0_RSMU_SEC_END_ADDR_GROUP_8_MASK) | (rsmu_sec_end_addr_group_8 << RSMU_SEC_END_ADDR_GROUP_8_MP0_RSMU_SEC_END_ADDR_GROUP_8_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_8_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_8      : RSMU_SEC_END_ADDR_GROUP_8_MP0_RSMU_SEC_END_ADDR_GROUP_8_SIZE;
      } rsmu_sec_end_addr_group_8_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_8_mp0_t {
            unsigned int rsmu_sec_end_addr_group_8      : RSMU_SEC_END_ADDR_GROUP_8_MP0_RSMU_SEC_END_ADDR_GROUP_8_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_8_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_8_mp0_t f;
} rsmu_sec_end_addr_group_8_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_8_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_8_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_8_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_8_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_8_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_8_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_8_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_8_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_8_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_8_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_8_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_8_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_8_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_8(rsmu_sec_initid_mask_set0_group_8_mp0) \
      ((rsmu_sec_initid_mask_set0_group_8_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_8_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_8_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_8_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_8_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_8_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_8(rsmu_sec_initid_mask_set0_group_8_mp0_reg, rsmu_sec_initid_mask_set0_group_8) \
      rsmu_sec_initid_mask_set0_group_8_mp0_reg = (rsmu_sec_initid_mask_set0_group_8_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_8_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_8_MASK) | (rsmu_sec_initid_mask_set0_group_8 << RSMU_SEC_INITID_MASK_SET0_GROUP_8_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_8_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_8_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_8 : RSMU_SEC_INITID_MASK_SET0_GROUP_8_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_8_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_8_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_8_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_8 : RSMU_SEC_INITID_MASK_SET0_GROUP_8_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_8_SIZE;
      } rsmu_sec_initid_mask_set0_group_8_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_8_mp0_t f;
} rsmu_sec_initid_mask_set0_group_8_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_8_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_8_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_8_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_8_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_8_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_8_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_8_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_8_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_8_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_8_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_8_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_8_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_8_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_8(rsmu_sec_unitid_mask_set0_group_8_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_8_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_8_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_8_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_8_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_8_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_8_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_8(rsmu_sec_unitid_mask_set0_group_8_mp0_reg, rsmu_sec_unitid_mask_set0_group_8) \
      rsmu_sec_unitid_mask_set0_group_8_mp0_reg = (rsmu_sec_unitid_mask_set0_group_8_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_8_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_8_MASK) | (rsmu_sec_unitid_mask_set0_group_8 << RSMU_SEC_UNITID_MASK_SET0_GROUP_8_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_8_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_8_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_8 : RSMU_SEC_UNITID_MASK_SET0_GROUP_8_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_8_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_8_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_8_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_8 : RSMU_SEC_UNITID_MASK_SET0_GROUP_8_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_8_SIZE;
      } rsmu_sec_unitid_mask_set0_group_8_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_8_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_8_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_8_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_8_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_8_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_8_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_8_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_8_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_8_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_8_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_8_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_8_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_8_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_8_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_8(rsmu_sec_misc_mask_set0_group_8_mp0) \
      ((rsmu_sec_misc_mask_set0_group_8_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_8_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_8_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_8(rsmu_sec_misc_mask_set0_group_8_mp0) \
      ((rsmu_sec_misc_mask_set0_group_8_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_8_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_8_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_8(rsmu_sec_misc_mask_set0_group_8_mp0) \
      ((rsmu_sec_misc_mask_set0_group_8_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_8_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_8_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_8(rsmu_sec_misc_mask_set0_group_8_mp0_reg, rsmu_sec_tlvl_mask_set0_group_8) \
      rsmu_sec_misc_mask_set0_group_8_mp0_reg = (rsmu_sec_misc_mask_set0_group_8_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_8_MASK) | (rsmu_sec_tlvl_mask_set0_group_8 << RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_8_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_8(rsmu_sec_misc_mask_set0_group_8_mp0_reg, rsmu_sec_rw_mask_set0_group_8) \
      rsmu_sec_misc_mask_set0_group_8_mp0_reg = (rsmu_sec_misc_mask_set0_group_8_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_8_MASK) | (rsmu_sec_rw_mask_set0_group_8 << RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_8_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_8(rsmu_sec_misc_mask_set0_group_8_mp0_reg, rsmu_sec_vf_mask_set0_group_8) \
      rsmu_sec_misc_mask_set0_group_8_mp0_reg = (rsmu_sec_misc_mask_set0_group_8_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_8_MASK) | (rsmu_sec_vf_mask_set0_group_8 << RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_8_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_8_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_8 : RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_8_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_8  : RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_8_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_8  : RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_8_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_8_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_8_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_8  : RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_8_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_8  : RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_8_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_8 : RSMU_SEC_MISC_MASK_SET0_GROUP_8_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_8_SIZE;
      } rsmu_sec_misc_mask_set0_group_8_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_8_mp0_t f;
} rsmu_sec_misc_mask_set0_group_8_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_8_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_8_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_8_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_8_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_8_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_8_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_8_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_8_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_8_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_8_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_8_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_8_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_8_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_8(rsmu_sec_initid_mask_set1_group_8_mp0) \
      ((rsmu_sec_initid_mask_set1_group_8_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_8_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_8_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_8_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_8_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_8_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_8(rsmu_sec_initid_mask_set1_group_8_mp0_reg, rsmu_sec_initid_mask_set1_group_8) \
      rsmu_sec_initid_mask_set1_group_8_mp0_reg = (rsmu_sec_initid_mask_set1_group_8_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_8_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_8_MASK) | (rsmu_sec_initid_mask_set1_group_8 << RSMU_SEC_INITID_MASK_SET1_GROUP_8_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_8_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_8_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_8 : RSMU_SEC_INITID_MASK_SET1_GROUP_8_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_8_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_8_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_8_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_8 : RSMU_SEC_INITID_MASK_SET1_GROUP_8_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_8_SIZE;
      } rsmu_sec_initid_mask_set1_group_8_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_8_mp0_t f;
} rsmu_sec_initid_mask_set1_group_8_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_8_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_8_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_8_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_8_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_8_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_8_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_8_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_8_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_8_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_8_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_8_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_8_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_8_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_8(rsmu_sec_unitid_mask_set1_group_8_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_8_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_8_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_8_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_8_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_8_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_8_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_8(rsmu_sec_unitid_mask_set1_group_8_mp0_reg, rsmu_sec_unitid_mask_set1_group_8) \
      rsmu_sec_unitid_mask_set1_group_8_mp0_reg = (rsmu_sec_unitid_mask_set1_group_8_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_8_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_8_MASK) | (rsmu_sec_unitid_mask_set1_group_8 << RSMU_SEC_UNITID_MASK_SET1_GROUP_8_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_8_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_8_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_8 : RSMU_SEC_UNITID_MASK_SET1_GROUP_8_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_8_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_8_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_8_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_8 : RSMU_SEC_UNITID_MASK_SET1_GROUP_8_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_8_SIZE;
      } rsmu_sec_unitid_mask_set1_group_8_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_8_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_8_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_8_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_8_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_8_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_8_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_8_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_8_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_8_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_8_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_8_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_8_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_8_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_8_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_8(rsmu_sec_misc_mask_set1_group_8_mp0) \
      ((rsmu_sec_misc_mask_set1_group_8_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_8_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_8_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_8(rsmu_sec_misc_mask_set1_group_8_mp0) \
      ((rsmu_sec_misc_mask_set1_group_8_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_8_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_8_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_8(rsmu_sec_misc_mask_set1_group_8_mp0) \
      ((rsmu_sec_misc_mask_set1_group_8_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_8_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_8_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_8(rsmu_sec_misc_mask_set1_group_8_mp0_reg, rsmu_sec_tlvl_mask_set1_group_8) \
      rsmu_sec_misc_mask_set1_group_8_mp0_reg = (rsmu_sec_misc_mask_set1_group_8_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_8_MASK) | (rsmu_sec_tlvl_mask_set1_group_8 << RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_8_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_8(rsmu_sec_misc_mask_set1_group_8_mp0_reg, rsmu_sec_rw_mask_set1_group_8) \
      rsmu_sec_misc_mask_set1_group_8_mp0_reg = (rsmu_sec_misc_mask_set1_group_8_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_8_MASK) | (rsmu_sec_rw_mask_set1_group_8 << RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_8_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_8(rsmu_sec_misc_mask_set1_group_8_mp0_reg, rsmu_sec_vf_mask_set1_group_8) \
      rsmu_sec_misc_mask_set1_group_8_mp0_reg = (rsmu_sec_misc_mask_set1_group_8_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_8_MASK) | (rsmu_sec_vf_mask_set1_group_8 << RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_8_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_8_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_8 : RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_8_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_8  : RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_8_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_8  : RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_8_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_8_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_8_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_8  : RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_8_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_8  : RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_8_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_8 : RSMU_SEC_MISC_MASK_SET1_GROUP_8_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_8_SIZE;
      } rsmu_sec_misc_mask_set1_group_8_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_8_mp0_t f;
} rsmu_sec_misc_mask_set1_group_8_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_8_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_8_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_8_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_8_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_8_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_8_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_8_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_8_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_8_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_8_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_8_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_8_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_8_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_8_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_8_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_8_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_8(rsmu_sec_access_control_group_8_mp0) \
      ((rsmu_sec_access_control_group_8_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_8_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_8_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_8(rsmu_sec_access_control_group_8_mp0) \
      ((rsmu_sec_access_control_group_8_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_8_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_8_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_8(rsmu_sec_access_control_group_8_mp0) \
      ((rsmu_sec_access_control_group_8_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_8_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_8_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_8(rsmu_sec_access_control_group_8_mp0) \
      ((rsmu_sec_access_control_group_8_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_8_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_8_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_8(rsmu_sec_access_control_group_8_mp0_reg, rsmu_sec_check_enable_set0_group_8) \
      rsmu_sec_access_control_group_8_mp0_reg = (rsmu_sec_access_control_group_8_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_8_MASK) | (rsmu_sec_check_enable_set0_group_8 << RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_8_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_8(rsmu_sec_access_control_group_8_mp0_reg, rsmu_sec_check_enable_set1_group_8) \
      rsmu_sec_access_control_group_8_mp0_reg = (rsmu_sec_access_control_group_8_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_8_MASK) | (rsmu_sec_check_enable_set1_group_8 << RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_8_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_8(rsmu_sec_access_control_group_8_mp0_reg, rsmu_sec_vf_check_enable_set0_group_8) \
      rsmu_sec_access_control_group_8_mp0_reg = (rsmu_sec_access_control_group_8_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_8_MASK) | (rsmu_sec_vf_check_enable_set0_group_8 << RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_8_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_8(rsmu_sec_access_control_group_8_mp0_reg, rsmu_sec_vf_check_enable_set1_group_8) \
      rsmu_sec_access_control_group_8_mp0_reg = (rsmu_sec_access_control_group_8_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_8_MASK) | (rsmu_sec_vf_check_enable_set1_group_8 << RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_8_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_8_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_8 : RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_8_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_8 : RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_8_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_8 : RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_8_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_8 : RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_8_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_8_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_8_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_8 : RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_8_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_8 : RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_8_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_8 : RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_8_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_8 : RSMU_SEC_ACCESS_CONTROL_GROUP_8_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_8_SIZE;
      } rsmu_sec_access_control_group_8_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_8_mp0_t f;
} rsmu_sec_access_control_group_8_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_9_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_9_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_9_MP0_RSMU_SEC_START_ADDR_GROUP_9_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_9_MP0_RSMU_SEC_START_ADDR_GROUP_9_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_9_MP0_RSMU_SEC_START_ADDR_GROUP_9_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_9_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_9_MP0_RSMU_SEC_START_ADDR_GROUP_9_MASK)

#define RSMU_SEC_START_ADDR_GROUP_9_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_9_MP0_GET_RSMU_SEC_START_ADDR_GROUP_9(rsmu_sec_start_addr_group_9_mp0) \
      ((rsmu_sec_start_addr_group_9_mp0 & RSMU_SEC_START_ADDR_GROUP_9_MP0_RSMU_SEC_START_ADDR_GROUP_9_MASK) >> RSMU_SEC_START_ADDR_GROUP_9_MP0_RSMU_SEC_START_ADDR_GROUP_9_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_9_MP0_SET_RSMU_SEC_START_ADDR_GROUP_9(rsmu_sec_start_addr_group_9_mp0_reg, rsmu_sec_start_addr_group_9) \
      rsmu_sec_start_addr_group_9_mp0_reg = (rsmu_sec_start_addr_group_9_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_9_MP0_RSMU_SEC_START_ADDR_GROUP_9_MASK) | (rsmu_sec_start_addr_group_9 << RSMU_SEC_START_ADDR_GROUP_9_MP0_RSMU_SEC_START_ADDR_GROUP_9_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_9_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_9    : RSMU_SEC_START_ADDR_GROUP_9_MP0_RSMU_SEC_START_ADDR_GROUP_9_SIZE;
      } rsmu_sec_start_addr_group_9_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_9_mp0_t {
            unsigned int rsmu_sec_start_addr_group_9    : RSMU_SEC_START_ADDR_GROUP_9_MP0_RSMU_SEC_START_ADDR_GROUP_9_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_9_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_9_mp0_t f;
} rsmu_sec_start_addr_group_9_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_9_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_9_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_9_MP0_RSMU_SEC_END_ADDR_GROUP_9_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_9_MP0_RSMU_SEC_END_ADDR_GROUP_9_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_9_MP0_RSMU_SEC_END_ADDR_GROUP_9_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_9_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_9_MP0_RSMU_SEC_END_ADDR_GROUP_9_MASK)

#define RSMU_SEC_END_ADDR_GROUP_9_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_9_MP0_GET_RSMU_SEC_END_ADDR_GROUP_9(rsmu_sec_end_addr_group_9_mp0) \
      ((rsmu_sec_end_addr_group_9_mp0 & RSMU_SEC_END_ADDR_GROUP_9_MP0_RSMU_SEC_END_ADDR_GROUP_9_MASK) >> RSMU_SEC_END_ADDR_GROUP_9_MP0_RSMU_SEC_END_ADDR_GROUP_9_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_9_MP0_SET_RSMU_SEC_END_ADDR_GROUP_9(rsmu_sec_end_addr_group_9_mp0_reg, rsmu_sec_end_addr_group_9) \
      rsmu_sec_end_addr_group_9_mp0_reg = (rsmu_sec_end_addr_group_9_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_9_MP0_RSMU_SEC_END_ADDR_GROUP_9_MASK) | (rsmu_sec_end_addr_group_9 << RSMU_SEC_END_ADDR_GROUP_9_MP0_RSMU_SEC_END_ADDR_GROUP_9_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_9_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_9      : RSMU_SEC_END_ADDR_GROUP_9_MP0_RSMU_SEC_END_ADDR_GROUP_9_SIZE;
      } rsmu_sec_end_addr_group_9_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_9_mp0_t {
            unsigned int rsmu_sec_end_addr_group_9      : RSMU_SEC_END_ADDR_GROUP_9_MP0_RSMU_SEC_END_ADDR_GROUP_9_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_9_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_9_mp0_t f;
} rsmu_sec_end_addr_group_9_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_9_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_9_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_9_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_9_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_9_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_9_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_9_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_9_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_9_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_9_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_9_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_9_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_9_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_9(rsmu_sec_initid_mask_set0_group_9_mp0) \
      ((rsmu_sec_initid_mask_set0_group_9_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_9_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_9_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_9_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_9_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_9_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_9(rsmu_sec_initid_mask_set0_group_9_mp0_reg, rsmu_sec_initid_mask_set0_group_9) \
      rsmu_sec_initid_mask_set0_group_9_mp0_reg = (rsmu_sec_initid_mask_set0_group_9_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_9_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_9_MASK) | (rsmu_sec_initid_mask_set0_group_9 << RSMU_SEC_INITID_MASK_SET0_GROUP_9_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_9_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_9_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_9 : RSMU_SEC_INITID_MASK_SET0_GROUP_9_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_9_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_9_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_9_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_9 : RSMU_SEC_INITID_MASK_SET0_GROUP_9_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_9_SIZE;
      } rsmu_sec_initid_mask_set0_group_9_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_9_mp0_t f;
} rsmu_sec_initid_mask_set0_group_9_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_9_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_9_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_9_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_9_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_9_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_9_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_9_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_9_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_9_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_9_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_9_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_9_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_9_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_9(rsmu_sec_unitid_mask_set0_group_9_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_9_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_9_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_9_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_9_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_9_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_9_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_9(rsmu_sec_unitid_mask_set0_group_9_mp0_reg, rsmu_sec_unitid_mask_set0_group_9) \
      rsmu_sec_unitid_mask_set0_group_9_mp0_reg = (rsmu_sec_unitid_mask_set0_group_9_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_9_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_9_MASK) | (rsmu_sec_unitid_mask_set0_group_9 << RSMU_SEC_UNITID_MASK_SET0_GROUP_9_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_9_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_9_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_9 : RSMU_SEC_UNITID_MASK_SET0_GROUP_9_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_9_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_9_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_9_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_9 : RSMU_SEC_UNITID_MASK_SET0_GROUP_9_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_9_SIZE;
      } rsmu_sec_unitid_mask_set0_group_9_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_9_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_9_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_9_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_9_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_9_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_9_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_9_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_9_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_9_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_9_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_9_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_9_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_9_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_9_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_9(rsmu_sec_misc_mask_set0_group_9_mp0) \
      ((rsmu_sec_misc_mask_set0_group_9_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_9_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_9_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_9(rsmu_sec_misc_mask_set0_group_9_mp0) \
      ((rsmu_sec_misc_mask_set0_group_9_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_9_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_9_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_9(rsmu_sec_misc_mask_set0_group_9_mp0) \
      ((rsmu_sec_misc_mask_set0_group_9_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_9_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_9_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_9(rsmu_sec_misc_mask_set0_group_9_mp0_reg, rsmu_sec_tlvl_mask_set0_group_9) \
      rsmu_sec_misc_mask_set0_group_9_mp0_reg = (rsmu_sec_misc_mask_set0_group_9_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_9_MASK) | (rsmu_sec_tlvl_mask_set0_group_9 << RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_9_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_9(rsmu_sec_misc_mask_set0_group_9_mp0_reg, rsmu_sec_rw_mask_set0_group_9) \
      rsmu_sec_misc_mask_set0_group_9_mp0_reg = (rsmu_sec_misc_mask_set0_group_9_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_9_MASK) | (rsmu_sec_rw_mask_set0_group_9 << RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_9_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_9(rsmu_sec_misc_mask_set0_group_9_mp0_reg, rsmu_sec_vf_mask_set0_group_9) \
      rsmu_sec_misc_mask_set0_group_9_mp0_reg = (rsmu_sec_misc_mask_set0_group_9_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_9_MASK) | (rsmu_sec_vf_mask_set0_group_9 << RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_9_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_9_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_9 : RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_9_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_9  : RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_9_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_9  : RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_9_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_9_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_9_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_9  : RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_9_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_9  : RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_9_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_9 : RSMU_SEC_MISC_MASK_SET0_GROUP_9_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_9_SIZE;
      } rsmu_sec_misc_mask_set0_group_9_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_9_mp0_t f;
} rsmu_sec_misc_mask_set0_group_9_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_9_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_9_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_9_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_9_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_9_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_9_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_9_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_9_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_9_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_9_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_9_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_9_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_9_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_9(rsmu_sec_initid_mask_set1_group_9_mp0) \
      ((rsmu_sec_initid_mask_set1_group_9_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_9_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_9_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_9_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_9_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_9_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_9(rsmu_sec_initid_mask_set1_group_9_mp0_reg, rsmu_sec_initid_mask_set1_group_9) \
      rsmu_sec_initid_mask_set1_group_9_mp0_reg = (rsmu_sec_initid_mask_set1_group_9_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_9_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_9_MASK) | (rsmu_sec_initid_mask_set1_group_9 << RSMU_SEC_INITID_MASK_SET1_GROUP_9_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_9_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_9_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_9 : RSMU_SEC_INITID_MASK_SET1_GROUP_9_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_9_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_9_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_9_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_9 : RSMU_SEC_INITID_MASK_SET1_GROUP_9_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_9_SIZE;
      } rsmu_sec_initid_mask_set1_group_9_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_9_mp0_t f;
} rsmu_sec_initid_mask_set1_group_9_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_9_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_9_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_9_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_9_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_9_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_9_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_9_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_9_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_9_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_9_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_9_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_9_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_9_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_9(rsmu_sec_unitid_mask_set1_group_9_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_9_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_9_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_9_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_9_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_9_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_9_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_9(rsmu_sec_unitid_mask_set1_group_9_mp0_reg, rsmu_sec_unitid_mask_set1_group_9) \
      rsmu_sec_unitid_mask_set1_group_9_mp0_reg = (rsmu_sec_unitid_mask_set1_group_9_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_9_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_9_MASK) | (rsmu_sec_unitid_mask_set1_group_9 << RSMU_SEC_UNITID_MASK_SET1_GROUP_9_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_9_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_9_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_9 : RSMU_SEC_UNITID_MASK_SET1_GROUP_9_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_9_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_9_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_9_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_9 : RSMU_SEC_UNITID_MASK_SET1_GROUP_9_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_9_SIZE;
      } rsmu_sec_unitid_mask_set1_group_9_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_9_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_9_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_9_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_9_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_9_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_9_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_9_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_9_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_9_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_9_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_9_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_9_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_9_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_9_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_9(rsmu_sec_misc_mask_set1_group_9_mp0) \
      ((rsmu_sec_misc_mask_set1_group_9_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_9_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_9_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_9(rsmu_sec_misc_mask_set1_group_9_mp0) \
      ((rsmu_sec_misc_mask_set1_group_9_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_9_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_9_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_9(rsmu_sec_misc_mask_set1_group_9_mp0) \
      ((rsmu_sec_misc_mask_set1_group_9_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_9_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_9_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_9(rsmu_sec_misc_mask_set1_group_9_mp0_reg, rsmu_sec_tlvl_mask_set1_group_9) \
      rsmu_sec_misc_mask_set1_group_9_mp0_reg = (rsmu_sec_misc_mask_set1_group_9_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_9_MASK) | (rsmu_sec_tlvl_mask_set1_group_9 << RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_9_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_9(rsmu_sec_misc_mask_set1_group_9_mp0_reg, rsmu_sec_rw_mask_set1_group_9) \
      rsmu_sec_misc_mask_set1_group_9_mp0_reg = (rsmu_sec_misc_mask_set1_group_9_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_9_MASK) | (rsmu_sec_rw_mask_set1_group_9 << RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_9_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_9(rsmu_sec_misc_mask_set1_group_9_mp0_reg, rsmu_sec_vf_mask_set1_group_9) \
      rsmu_sec_misc_mask_set1_group_9_mp0_reg = (rsmu_sec_misc_mask_set1_group_9_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_9_MASK) | (rsmu_sec_vf_mask_set1_group_9 << RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_9_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_9_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_9 : RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_9_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_9  : RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_9_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_9  : RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_9_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_9_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_9_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_9  : RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_9_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_9  : RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_9_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_9 : RSMU_SEC_MISC_MASK_SET1_GROUP_9_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_9_SIZE;
      } rsmu_sec_misc_mask_set1_group_9_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_9_mp0_t f;
} rsmu_sec_misc_mask_set1_group_9_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_9_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_9_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_9_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_9_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_9_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_9_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_9_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_9_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_9_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_9_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_9_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_9_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_9_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_9_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_9_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_9_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_9(rsmu_sec_access_control_group_9_mp0) \
      ((rsmu_sec_access_control_group_9_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_9_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_9_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_9(rsmu_sec_access_control_group_9_mp0) \
      ((rsmu_sec_access_control_group_9_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_9_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_9_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_9(rsmu_sec_access_control_group_9_mp0) \
      ((rsmu_sec_access_control_group_9_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_9_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_9_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_9(rsmu_sec_access_control_group_9_mp0) \
      ((rsmu_sec_access_control_group_9_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_9_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_9_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_9(rsmu_sec_access_control_group_9_mp0_reg, rsmu_sec_check_enable_set0_group_9) \
      rsmu_sec_access_control_group_9_mp0_reg = (rsmu_sec_access_control_group_9_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_9_MASK) | (rsmu_sec_check_enable_set0_group_9 << RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_9_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_9(rsmu_sec_access_control_group_9_mp0_reg, rsmu_sec_check_enable_set1_group_9) \
      rsmu_sec_access_control_group_9_mp0_reg = (rsmu_sec_access_control_group_9_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_9_MASK) | (rsmu_sec_check_enable_set1_group_9 << RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_9_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_9(rsmu_sec_access_control_group_9_mp0_reg, rsmu_sec_vf_check_enable_set0_group_9) \
      rsmu_sec_access_control_group_9_mp0_reg = (rsmu_sec_access_control_group_9_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_9_MASK) | (rsmu_sec_vf_check_enable_set0_group_9 << RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_9_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_9(rsmu_sec_access_control_group_9_mp0_reg, rsmu_sec_vf_check_enable_set1_group_9) \
      rsmu_sec_access_control_group_9_mp0_reg = (rsmu_sec_access_control_group_9_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_9_MASK) | (rsmu_sec_vf_check_enable_set1_group_9 << RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_9_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_9_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_9 : RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_9_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_9 : RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_9_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_9 : RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_9_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_9 : RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_9_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_9_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_9_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_9 : RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_9_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_9 : RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_9_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_9 : RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_9_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_9 : RSMU_SEC_ACCESS_CONTROL_GROUP_9_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_9_SIZE;
      } rsmu_sec_access_control_group_9_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_9_mp0_t f;
} rsmu_sec_access_control_group_9_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_10_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_10_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_10_MP0_RSMU_SEC_START_ADDR_GROUP_10_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_10_MP0_RSMU_SEC_START_ADDR_GROUP_10_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_10_MP0_RSMU_SEC_START_ADDR_GROUP_10_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_10_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_10_MP0_RSMU_SEC_START_ADDR_GROUP_10_MASK)

#define RSMU_SEC_START_ADDR_GROUP_10_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_10_MP0_GET_RSMU_SEC_START_ADDR_GROUP_10(rsmu_sec_start_addr_group_10_mp0) \
      ((rsmu_sec_start_addr_group_10_mp0 & RSMU_SEC_START_ADDR_GROUP_10_MP0_RSMU_SEC_START_ADDR_GROUP_10_MASK) >> RSMU_SEC_START_ADDR_GROUP_10_MP0_RSMU_SEC_START_ADDR_GROUP_10_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_10_MP0_SET_RSMU_SEC_START_ADDR_GROUP_10(rsmu_sec_start_addr_group_10_mp0_reg, rsmu_sec_start_addr_group_10) \
      rsmu_sec_start_addr_group_10_mp0_reg = (rsmu_sec_start_addr_group_10_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_10_MP0_RSMU_SEC_START_ADDR_GROUP_10_MASK) | (rsmu_sec_start_addr_group_10 << RSMU_SEC_START_ADDR_GROUP_10_MP0_RSMU_SEC_START_ADDR_GROUP_10_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_10_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_10   : RSMU_SEC_START_ADDR_GROUP_10_MP0_RSMU_SEC_START_ADDR_GROUP_10_SIZE;
      } rsmu_sec_start_addr_group_10_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_10_mp0_t {
            unsigned int rsmu_sec_start_addr_group_10   : RSMU_SEC_START_ADDR_GROUP_10_MP0_RSMU_SEC_START_ADDR_GROUP_10_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_10_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_10_mp0_t f;
} rsmu_sec_start_addr_group_10_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_10_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_10_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_10_MP0_RSMU_SEC_END_ADDR_GROUP_10_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_10_MP0_RSMU_SEC_END_ADDR_GROUP_10_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_10_MP0_RSMU_SEC_END_ADDR_GROUP_10_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_10_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_10_MP0_RSMU_SEC_END_ADDR_GROUP_10_MASK)

#define RSMU_SEC_END_ADDR_GROUP_10_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_10_MP0_GET_RSMU_SEC_END_ADDR_GROUP_10(rsmu_sec_end_addr_group_10_mp0) \
      ((rsmu_sec_end_addr_group_10_mp0 & RSMU_SEC_END_ADDR_GROUP_10_MP0_RSMU_SEC_END_ADDR_GROUP_10_MASK) >> RSMU_SEC_END_ADDR_GROUP_10_MP0_RSMU_SEC_END_ADDR_GROUP_10_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_10_MP0_SET_RSMU_SEC_END_ADDR_GROUP_10(rsmu_sec_end_addr_group_10_mp0_reg, rsmu_sec_end_addr_group_10) \
      rsmu_sec_end_addr_group_10_mp0_reg = (rsmu_sec_end_addr_group_10_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_10_MP0_RSMU_SEC_END_ADDR_GROUP_10_MASK) | (rsmu_sec_end_addr_group_10 << RSMU_SEC_END_ADDR_GROUP_10_MP0_RSMU_SEC_END_ADDR_GROUP_10_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_10_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_10     : RSMU_SEC_END_ADDR_GROUP_10_MP0_RSMU_SEC_END_ADDR_GROUP_10_SIZE;
      } rsmu_sec_end_addr_group_10_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_10_mp0_t {
            unsigned int rsmu_sec_end_addr_group_10     : RSMU_SEC_END_ADDR_GROUP_10_MP0_RSMU_SEC_END_ADDR_GROUP_10_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_10_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_10_mp0_t f;
} rsmu_sec_end_addr_group_10_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_10_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_10_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_10_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_10_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_10_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_10_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_10_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_10_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_10_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_10_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_10_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_10_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_10_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_10(rsmu_sec_initid_mask_set0_group_10_mp0) \
      ((rsmu_sec_initid_mask_set0_group_10_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_10_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_10_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_10_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_10_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_10_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_10(rsmu_sec_initid_mask_set0_group_10_mp0_reg, rsmu_sec_initid_mask_set0_group_10) \
      rsmu_sec_initid_mask_set0_group_10_mp0_reg = (rsmu_sec_initid_mask_set0_group_10_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_10_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_10_MASK) | (rsmu_sec_initid_mask_set0_group_10 << RSMU_SEC_INITID_MASK_SET0_GROUP_10_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_10_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_10_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_10 : RSMU_SEC_INITID_MASK_SET0_GROUP_10_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_10_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_10_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_10_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_10 : RSMU_SEC_INITID_MASK_SET0_GROUP_10_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_10_SIZE;
      } rsmu_sec_initid_mask_set0_group_10_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_10_mp0_t f;
} rsmu_sec_initid_mask_set0_group_10_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_10_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_10_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_10_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_10_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_10_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_10_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_10_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_10_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_10_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_10_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_10_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_10_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_10_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_10(rsmu_sec_unitid_mask_set0_group_10_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_10_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_10_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_10_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_10_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_10_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_10_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_10(rsmu_sec_unitid_mask_set0_group_10_mp0_reg, rsmu_sec_unitid_mask_set0_group_10) \
      rsmu_sec_unitid_mask_set0_group_10_mp0_reg = (rsmu_sec_unitid_mask_set0_group_10_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_10_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_10_MASK) | (rsmu_sec_unitid_mask_set0_group_10 << RSMU_SEC_UNITID_MASK_SET0_GROUP_10_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_10_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_10_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_10 : RSMU_SEC_UNITID_MASK_SET0_GROUP_10_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_10_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_10_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_10_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_10 : RSMU_SEC_UNITID_MASK_SET0_GROUP_10_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_10_SIZE;
      } rsmu_sec_unitid_mask_set0_group_10_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_10_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_10_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_10_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_10_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_10_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_10_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_10_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_10_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_10_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_10_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_10_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_10_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_10_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_10_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_10(rsmu_sec_misc_mask_set0_group_10_mp0) \
      ((rsmu_sec_misc_mask_set0_group_10_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_10_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_10_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_10(rsmu_sec_misc_mask_set0_group_10_mp0) \
      ((rsmu_sec_misc_mask_set0_group_10_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_10_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_10_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_10(rsmu_sec_misc_mask_set0_group_10_mp0) \
      ((rsmu_sec_misc_mask_set0_group_10_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_10_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_10_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_10(rsmu_sec_misc_mask_set0_group_10_mp0_reg, rsmu_sec_tlvl_mask_set0_group_10) \
      rsmu_sec_misc_mask_set0_group_10_mp0_reg = (rsmu_sec_misc_mask_set0_group_10_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_10_MASK) | (rsmu_sec_tlvl_mask_set0_group_10 << RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_10_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_10(rsmu_sec_misc_mask_set0_group_10_mp0_reg, rsmu_sec_rw_mask_set0_group_10) \
      rsmu_sec_misc_mask_set0_group_10_mp0_reg = (rsmu_sec_misc_mask_set0_group_10_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_10_MASK) | (rsmu_sec_rw_mask_set0_group_10 << RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_10_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_10(rsmu_sec_misc_mask_set0_group_10_mp0_reg, rsmu_sec_vf_mask_set0_group_10) \
      rsmu_sec_misc_mask_set0_group_10_mp0_reg = (rsmu_sec_misc_mask_set0_group_10_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_10_MASK) | (rsmu_sec_vf_mask_set0_group_10 << RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_10_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_10_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_10 : RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_10_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_10 : RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_10_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_10 : RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_10_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_10_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_10_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_10 : RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_10_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_10 : RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_10_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_10 : RSMU_SEC_MISC_MASK_SET0_GROUP_10_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_10_SIZE;
      } rsmu_sec_misc_mask_set0_group_10_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_10_mp0_t f;
} rsmu_sec_misc_mask_set0_group_10_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_10_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_10_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_10_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_10_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_10_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_10_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_10_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_10_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_10_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_10_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_10_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_10_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_10_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_10(rsmu_sec_initid_mask_set1_group_10_mp0) \
      ((rsmu_sec_initid_mask_set1_group_10_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_10_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_10_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_10_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_10_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_10_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_10(rsmu_sec_initid_mask_set1_group_10_mp0_reg, rsmu_sec_initid_mask_set1_group_10) \
      rsmu_sec_initid_mask_set1_group_10_mp0_reg = (rsmu_sec_initid_mask_set1_group_10_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_10_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_10_MASK) | (rsmu_sec_initid_mask_set1_group_10 << RSMU_SEC_INITID_MASK_SET1_GROUP_10_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_10_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_10_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_10 : RSMU_SEC_INITID_MASK_SET1_GROUP_10_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_10_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_10_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_10_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_10 : RSMU_SEC_INITID_MASK_SET1_GROUP_10_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_10_SIZE;
      } rsmu_sec_initid_mask_set1_group_10_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_10_mp0_t f;
} rsmu_sec_initid_mask_set1_group_10_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_10_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_10_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_10_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_10_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_10_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_10_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_10_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_10_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_10_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_10_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_10_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_10_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_10_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_10(rsmu_sec_unitid_mask_set1_group_10_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_10_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_10_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_10_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_10_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_10_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_10_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_10(rsmu_sec_unitid_mask_set1_group_10_mp0_reg, rsmu_sec_unitid_mask_set1_group_10) \
      rsmu_sec_unitid_mask_set1_group_10_mp0_reg = (rsmu_sec_unitid_mask_set1_group_10_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_10_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_10_MASK) | (rsmu_sec_unitid_mask_set1_group_10 << RSMU_SEC_UNITID_MASK_SET1_GROUP_10_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_10_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_10_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_10 : RSMU_SEC_UNITID_MASK_SET1_GROUP_10_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_10_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_10_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_10_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_10 : RSMU_SEC_UNITID_MASK_SET1_GROUP_10_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_10_SIZE;
      } rsmu_sec_unitid_mask_set1_group_10_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_10_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_10_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_10_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_10_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_10_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_10_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_10_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_10_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_10_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_10_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_10_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_10_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_10_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_10_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_10(rsmu_sec_misc_mask_set1_group_10_mp0) \
      ((rsmu_sec_misc_mask_set1_group_10_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_10_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_10_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_10(rsmu_sec_misc_mask_set1_group_10_mp0) \
      ((rsmu_sec_misc_mask_set1_group_10_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_10_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_10_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_10(rsmu_sec_misc_mask_set1_group_10_mp0) \
      ((rsmu_sec_misc_mask_set1_group_10_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_10_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_10_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_10(rsmu_sec_misc_mask_set1_group_10_mp0_reg, rsmu_sec_tlvl_mask_set1_group_10) \
      rsmu_sec_misc_mask_set1_group_10_mp0_reg = (rsmu_sec_misc_mask_set1_group_10_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_10_MASK) | (rsmu_sec_tlvl_mask_set1_group_10 << RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_10_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_10(rsmu_sec_misc_mask_set1_group_10_mp0_reg, rsmu_sec_rw_mask_set1_group_10) \
      rsmu_sec_misc_mask_set1_group_10_mp0_reg = (rsmu_sec_misc_mask_set1_group_10_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_10_MASK) | (rsmu_sec_rw_mask_set1_group_10 << RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_10_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_10(rsmu_sec_misc_mask_set1_group_10_mp0_reg, rsmu_sec_vf_mask_set1_group_10) \
      rsmu_sec_misc_mask_set1_group_10_mp0_reg = (rsmu_sec_misc_mask_set1_group_10_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_10_MASK) | (rsmu_sec_vf_mask_set1_group_10 << RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_10_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_10_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_10 : RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_10_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_10 : RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_10_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_10 : RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_10_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_10_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_10_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_10 : RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_10_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_10 : RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_10_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_10 : RSMU_SEC_MISC_MASK_SET1_GROUP_10_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_10_SIZE;
      } rsmu_sec_misc_mask_set1_group_10_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_10_mp0_t f;
} rsmu_sec_misc_mask_set1_group_10_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_10_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_10_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_10_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_10_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_10_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_10_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_10_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_10_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_10_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_10_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_10_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_10_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_10_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_10_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_10_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_10_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_10(rsmu_sec_access_control_group_10_mp0) \
      ((rsmu_sec_access_control_group_10_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_10_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_10_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_10(rsmu_sec_access_control_group_10_mp0) \
      ((rsmu_sec_access_control_group_10_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_10_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_10_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_10(rsmu_sec_access_control_group_10_mp0) \
      ((rsmu_sec_access_control_group_10_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_10_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_10_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_10(rsmu_sec_access_control_group_10_mp0) \
      ((rsmu_sec_access_control_group_10_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_10_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_10_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_10(rsmu_sec_access_control_group_10_mp0_reg, rsmu_sec_check_enable_set0_group_10) \
      rsmu_sec_access_control_group_10_mp0_reg = (rsmu_sec_access_control_group_10_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_10_MASK) | (rsmu_sec_check_enable_set0_group_10 << RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_10_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_10(rsmu_sec_access_control_group_10_mp0_reg, rsmu_sec_check_enable_set1_group_10) \
      rsmu_sec_access_control_group_10_mp0_reg = (rsmu_sec_access_control_group_10_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_10_MASK) | (rsmu_sec_check_enable_set1_group_10 << RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_10_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_10(rsmu_sec_access_control_group_10_mp0_reg, rsmu_sec_vf_check_enable_set0_group_10) \
      rsmu_sec_access_control_group_10_mp0_reg = (rsmu_sec_access_control_group_10_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_10_MASK) | (rsmu_sec_vf_check_enable_set0_group_10 << RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_10_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_10(rsmu_sec_access_control_group_10_mp0_reg, rsmu_sec_vf_check_enable_set1_group_10) \
      rsmu_sec_access_control_group_10_mp0_reg = (rsmu_sec_access_control_group_10_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_10_MASK) | (rsmu_sec_vf_check_enable_set1_group_10 << RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_10_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_10_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_10 : RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_10_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_10 : RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_10_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_10 : RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_10_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_10 : RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_10_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_10_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_10_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_10 : RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_10_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_10 : RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_10_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_10 : RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_10_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_10 : RSMU_SEC_ACCESS_CONTROL_GROUP_10_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_10_SIZE;
      } rsmu_sec_access_control_group_10_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_10_mp0_t f;
} rsmu_sec_access_control_group_10_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_11_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_11_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_11_MP0_RSMU_SEC_START_ADDR_GROUP_11_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_11_MP0_RSMU_SEC_START_ADDR_GROUP_11_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_11_MP0_RSMU_SEC_START_ADDR_GROUP_11_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_11_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_11_MP0_RSMU_SEC_START_ADDR_GROUP_11_MASK)

#define RSMU_SEC_START_ADDR_GROUP_11_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_11_MP0_GET_RSMU_SEC_START_ADDR_GROUP_11(rsmu_sec_start_addr_group_11_mp0) \
      ((rsmu_sec_start_addr_group_11_mp0 & RSMU_SEC_START_ADDR_GROUP_11_MP0_RSMU_SEC_START_ADDR_GROUP_11_MASK) >> RSMU_SEC_START_ADDR_GROUP_11_MP0_RSMU_SEC_START_ADDR_GROUP_11_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_11_MP0_SET_RSMU_SEC_START_ADDR_GROUP_11(rsmu_sec_start_addr_group_11_mp0_reg, rsmu_sec_start_addr_group_11) \
      rsmu_sec_start_addr_group_11_mp0_reg = (rsmu_sec_start_addr_group_11_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_11_MP0_RSMU_SEC_START_ADDR_GROUP_11_MASK) | (rsmu_sec_start_addr_group_11 << RSMU_SEC_START_ADDR_GROUP_11_MP0_RSMU_SEC_START_ADDR_GROUP_11_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_11_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_11   : RSMU_SEC_START_ADDR_GROUP_11_MP0_RSMU_SEC_START_ADDR_GROUP_11_SIZE;
      } rsmu_sec_start_addr_group_11_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_11_mp0_t {
            unsigned int rsmu_sec_start_addr_group_11   : RSMU_SEC_START_ADDR_GROUP_11_MP0_RSMU_SEC_START_ADDR_GROUP_11_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_11_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_11_mp0_t f;
} rsmu_sec_start_addr_group_11_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_11_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_11_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_11_MP0_RSMU_SEC_END_ADDR_GROUP_11_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_11_MP0_RSMU_SEC_END_ADDR_GROUP_11_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_11_MP0_RSMU_SEC_END_ADDR_GROUP_11_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_11_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_11_MP0_RSMU_SEC_END_ADDR_GROUP_11_MASK)

#define RSMU_SEC_END_ADDR_GROUP_11_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_11_MP0_GET_RSMU_SEC_END_ADDR_GROUP_11(rsmu_sec_end_addr_group_11_mp0) \
      ((rsmu_sec_end_addr_group_11_mp0 & RSMU_SEC_END_ADDR_GROUP_11_MP0_RSMU_SEC_END_ADDR_GROUP_11_MASK) >> RSMU_SEC_END_ADDR_GROUP_11_MP0_RSMU_SEC_END_ADDR_GROUP_11_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_11_MP0_SET_RSMU_SEC_END_ADDR_GROUP_11(rsmu_sec_end_addr_group_11_mp0_reg, rsmu_sec_end_addr_group_11) \
      rsmu_sec_end_addr_group_11_mp0_reg = (rsmu_sec_end_addr_group_11_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_11_MP0_RSMU_SEC_END_ADDR_GROUP_11_MASK) | (rsmu_sec_end_addr_group_11 << RSMU_SEC_END_ADDR_GROUP_11_MP0_RSMU_SEC_END_ADDR_GROUP_11_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_11_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_11     : RSMU_SEC_END_ADDR_GROUP_11_MP0_RSMU_SEC_END_ADDR_GROUP_11_SIZE;
      } rsmu_sec_end_addr_group_11_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_11_mp0_t {
            unsigned int rsmu_sec_end_addr_group_11     : RSMU_SEC_END_ADDR_GROUP_11_MP0_RSMU_SEC_END_ADDR_GROUP_11_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_11_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_11_mp0_t f;
} rsmu_sec_end_addr_group_11_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_11_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_11_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_11_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_11_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_11_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_11_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_11_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_11_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_11_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_11_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_11_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_11_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_11_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_11(rsmu_sec_initid_mask_set0_group_11_mp0) \
      ((rsmu_sec_initid_mask_set0_group_11_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_11_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_11_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_11_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_11_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_11_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_11(rsmu_sec_initid_mask_set0_group_11_mp0_reg, rsmu_sec_initid_mask_set0_group_11) \
      rsmu_sec_initid_mask_set0_group_11_mp0_reg = (rsmu_sec_initid_mask_set0_group_11_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_11_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_11_MASK) | (rsmu_sec_initid_mask_set0_group_11 << RSMU_SEC_INITID_MASK_SET0_GROUP_11_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_11_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_11_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_11 : RSMU_SEC_INITID_MASK_SET0_GROUP_11_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_11_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_11_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_11_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_11 : RSMU_SEC_INITID_MASK_SET0_GROUP_11_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_11_SIZE;
      } rsmu_sec_initid_mask_set0_group_11_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_11_mp0_t f;
} rsmu_sec_initid_mask_set0_group_11_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_11_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_11_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_11_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_11_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_11_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_11_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_11_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_11_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_11_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_11_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_11_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_11_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_11_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_11(rsmu_sec_unitid_mask_set0_group_11_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_11_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_11_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_11_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_11_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_11_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_11_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_11(rsmu_sec_unitid_mask_set0_group_11_mp0_reg, rsmu_sec_unitid_mask_set0_group_11) \
      rsmu_sec_unitid_mask_set0_group_11_mp0_reg = (rsmu_sec_unitid_mask_set0_group_11_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_11_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_11_MASK) | (rsmu_sec_unitid_mask_set0_group_11 << RSMU_SEC_UNITID_MASK_SET0_GROUP_11_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_11_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_11_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_11 : RSMU_SEC_UNITID_MASK_SET0_GROUP_11_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_11_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_11_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_11_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_11 : RSMU_SEC_UNITID_MASK_SET0_GROUP_11_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_11_SIZE;
      } rsmu_sec_unitid_mask_set0_group_11_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_11_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_11_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_11_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_11_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_11_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_11_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_11_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_11_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_11_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_11_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_11_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_11_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_11_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_11_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_11(rsmu_sec_misc_mask_set0_group_11_mp0) \
      ((rsmu_sec_misc_mask_set0_group_11_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_11_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_11_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_11(rsmu_sec_misc_mask_set0_group_11_mp0) \
      ((rsmu_sec_misc_mask_set0_group_11_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_11_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_11_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_11(rsmu_sec_misc_mask_set0_group_11_mp0) \
      ((rsmu_sec_misc_mask_set0_group_11_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_11_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_11_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_11(rsmu_sec_misc_mask_set0_group_11_mp0_reg, rsmu_sec_tlvl_mask_set0_group_11) \
      rsmu_sec_misc_mask_set0_group_11_mp0_reg = (rsmu_sec_misc_mask_set0_group_11_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_11_MASK) | (rsmu_sec_tlvl_mask_set0_group_11 << RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_11_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_11(rsmu_sec_misc_mask_set0_group_11_mp0_reg, rsmu_sec_rw_mask_set0_group_11) \
      rsmu_sec_misc_mask_set0_group_11_mp0_reg = (rsmu_sec_misc_mask_set0_group_11_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_11_MASK) | (rsmu_sec_rw_mask_set0_group_11 << RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_11_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_11(rsmu_sec_misc_mask_set0_group_11_mp0_reg, rsmu_sec_vf_mask_set0_group_11) \
      rsmu_sec_misc_mask_set0_group_11_mp0_reg = (rsmu_sec_misc_mask_set0_group_11_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_11_MASK) | (rsmu_sec_vf_mask_set0_group_11 << RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_11_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_11_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_11 : RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_11_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_11 : RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_11_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_11 : RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_11_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_11_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_11_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_11 : RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_11_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_11 : RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_11_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_11 : RSMU_SEC_MISC_MASK_SET0_GROUP_11_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_11_SIZE;
      } rsmu_sec_misc_mask_set0_group_11_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_11_mp0_t f;
} rsmu_sec_misc_mask_set0_group_11_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_11_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_11_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_11_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_11_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_11_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_11_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_11_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_11_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_11_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_11_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_11_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_11_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_11_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_11(rsmu_sec_initid_mask_set1_group_11_mp0) \
      ((rsmu_sec_initid_mask_set1_group_11_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_11_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_11_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_11_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_11_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_11_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_11(rsmu_sec_initid_mask_set1_group_11_mp0_reg, rsmu_sec_initid_mask_set1_group_11) \
      rsmu_sec_initid_mask_set1_group_11_mp0_reg = (rsmu_sec_initid_mask_set1_group_11_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_11_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_11_MASK) | (rsmu_sec_initid_mask_set1_group_11 << RSMU_SEC_INITID_MASK_SET1_GROUP_11_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_11_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_11_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_11 : RSMU_SEC_INITID_MASK_SET1_GROUP_11_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_11_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_11_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_11_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_11 : RSMU_SEC_INITID_MASK_SET1_GROUP_11_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_11_SIZE;
      } rsmu_sec_initid_mask_set1_group_11_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_11_mp0_t f;
} rsmu_sec_initid_mask_set1_group_11_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_11_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_11_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_11_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_11_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_11_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_11_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_11_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_11_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_11_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_11_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_11_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_11_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_11_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_11(rsmu_sec_unitid_mask_set1_group_11_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_11_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_11_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_11_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_11_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_11_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_11_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_11(rsmu_sec_unitid_mask_set1_group_11_mp0_reg, rsmu_sec_unitid_mask_set1_group_11) \
      rsmu_sec_unitid_mask_set1_group_11_mp0_reg = (rsmu_sec_unitid_mask_set1_group_11_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_11_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_11_MASK) | (rsmu_sec_unitid_mask_set1_group_11 << RSMU_SEC_UNITID_MASK_SET1_GROUP_11_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_11_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_11_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_11 : RSMU_SEC_UNITID_MASK_SET1_GROUP_11_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_11_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_11_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_11_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_11 : RSMU_SEC_UNITID_MASK_SET1_GROUP_11_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_11_SIZE;
      } rsmu_sec_unitid_mask_set1_group_11_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_11_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_11_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_11_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_11_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_11_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_11_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_11_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_11_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_11_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_11_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_11_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_11_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_11_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_11_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_11(rsmu_sec_misc_mask_set1_group_11_mp0) \
      ((rsmu_sec_misc_mask_set1_group_11_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_11_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_11_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_11(rsmu_sec_misc_mask_set1_group_11_mp0) \
      ((rsmu_sec_misc_mask_set1_group_11_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_11_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_11_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_11(rsmu_sec_misc_mask_set1_group_11_mp0) \
      ((rsmu_sec_misc_mask_set1_group_11_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_11_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_11_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_11(rsmu_sec_misc_mask_set1_group_11_mp0_reg, rsmu_sec_tlvl_mask_set1_group_11) \
      rsmu_sec_misc_mask_set1_group_11_mp0_reg = (rsmu_sec_misc_mask_set1_group_11_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_11_MASK) | (rsmu_sec_tlvl_mask_set1_group_11 << RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_11_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_11(rsmu_sec_misc_mask_set1_group_11_mp0_reg, rsmu_sec_rw_mask_set1_group_11) \
      rsmu_sec_misc_mask_set1_group_11_mp0_reg = (rsmu_sec_misc_mask_set1_group_11_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_11_MASK) | (rsmu_sec_rw_mask_set1_group_11 << RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_11_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_11(rsmu_sec_misc_mask_set1_group_11_mp0_reg, rsmu_sec_vf_mask_set1_group_11) \
      rsmu_sec_misc_mask_set1_group_11_mp0_reg = (rsmu_sec_misc_mask_set1_group_11_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_11_MASK) | (rsmu_sec_vf_mask_set1_group_11 << RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_11_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_11_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_11 : RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_11_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_11 : RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_11_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_11 : RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_11_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_11_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_11_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_11 : RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_11_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_11 : RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_11_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_11 : RSMU_SEC_MISC_MASK_SET1_GROUP_11_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_11_SIZE;
      } rsmu_sec_misc_mask_set1_group_11_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_11_mp0_t f;
} rsmu_sec_misc_mask_set1_group_11_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_11_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_11_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_11_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_11_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_11_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_11_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_11_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_11_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_11_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_11_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_11_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_11_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_11_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_11_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_11_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_11_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_11(rsmu_sec_access_control_group_11_mp0) \
      ((rsmu_sec_access_control_group_11_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_11_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_11_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_11(rsmu_sec_access_control_group_11_mp0) \
      ((rsmu_sec_access_control_group_11_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_11_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_11_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_11(rsmu_sec_access_control_group_11_mp0) \
      ((rsmu_sec_access_control_group_11_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_11_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_11_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_11(rsmu_sec_access_control_group_11_mp0) \
      ((rsmu_sec_access_control_group_11_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_11_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_11_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_11(rsmu_sec_access_control_group_11_mp0_reg, rsmu_sec_check_enable_set0_group_11) \
      rsmu_sec_access_control_group_11_mp0_reg = (rsmu_sec_access_control_group_11_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_11_MASK) | (rsmu_sec_check_enable_set0_group_11 << RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_11_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_11(rsmu_sec_access_control_group_11_mp0_reg, rsmu_sec_check_enable_set1_group_11) \
      rsmu_sec_access_control_group_11_mp0_reg = (rsmu_sec_access_control_group_11_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_11_MASK) | (rsmu_sec_check_enable_set1_group_11 << RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_11_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_11(rsmu_sec_access_control_group_11_mp0_reg, rsmu_sec_vf_check_enable_set0_group_11) \
      rsmu_sec_access_control_group_11_mp0_reg = (rsmu_sec_access_control_group_11_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_11_MASK) | (rsmu_sec_vf_check_enable_set0_group_11 << RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_11_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_11(rsmu_sec_access_control_group_11_mp0_reg, rsmu_sec_vf_check_enable_set1_group_11) \
      rsmu_sec_access_control_group_11_mp0_reg = (rsmu_sec_access_control_group_11_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_11_MASK) | (rsmu_sec_vf_check_enable_set1_group_11 << RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_11_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_11_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_11 : RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_11_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_11 : RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_11_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_11 : RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_11_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_11 : RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_11_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_11_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_11_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_11 : RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_11_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_11 : RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_11_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_11 : RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_11_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_11 : RSMU_SEC_ACCESS_CONTROL_GROUP_11_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_11_SIZE;
      } rsmu_sec_access_control_group_11_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_11_mp0_t f;
} rsmu_sec_access_control_group_11_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_12_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_12_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_12_MP0_RSMU_SEC_START_ADDR_GROUP_12_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_12_MP0_RSMU_SEC_START_ADDR_GROUP_12_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_12_MP0_RSMU_SEC_START_ADDR_GROUP_12_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_12_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_12_MP0_RSMU_SEC_START_ADDR_GROUP_12_MASK)

#define RSMU_SEC_START_ADDR_GROUP_12_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_12_MP0_GET_RSMU_SEC_START_ADDR_GROUP_12(rsmu_sec_start_addr_group_12_mp0) \
      ((rsmu_sec_start_addr_group_12_mp0 & RSMU_SEC_START_ADDR_GROUP_12_MP0_RSMU_SEC_START_ADDR_GROUP_12_MASK) >> RSMU_SEC_START_ADDR_GROUP_12_MP0_RSMU_SEC_START_ADDR_GROUP_12_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_12_MP0_SET_RSMU_SEC_START_ADDR_GROUP_12(rsmu_sec_start_addr_group_12_mp0_reg, rsmu_sec_start_addr_group_12) \
      rsmu_sec_start_addr_group_12_mp0_reg = (rsmu_sec_start_addr_group_12_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_12_MP0_RSMU_SEC_START_ADDR_GROUP_12_MASK) | (rsmu_sec_start_addr_group_12 << RSMU_SEC_START_ADDR_GROUP_12_MP0_RSMU_SEC_START_ADDR_GROUP_12_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_12_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_12   : RSMU_SEC_START_ADDR_GROUP_12_MP0_RSMU_SEC_START_ADDR_GROUP_12_SIZE;
      } rsmu_sec_start_addr_group_12_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_12_mp0_t {
            unsigned int rsmu_sec_start_addr_group_12   : RSMU_SEC_START_ADDR_GROUP_12_MP0_RSMU_SEC_START_ADDR_GROUP_12_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_12_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_12_mp0_t f;
} rsmu_sec_start_addr_group_12_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_12_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_12_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_12_MP0_RSMU_SEC_END_ADDR_GROUP_12_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_12_MP0_RSMU_SEC_END_ADDR_GROUP_12_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_12_MP0_RSMU_SEC_END_ADDR_GROUP_12_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_12_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_12_MP0_RSMU_SEC_END_ADDR_GROUP_12_MASK)

#define RSMU_SEC_END_ADDR_GROUP_12_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_12_MP0_GET_RSMU_SEC_END_ADDR_GROUP_12(rsmu_sec_end_addr_group_12_mp0) \
      ((rsmu_sec_end_addr_group_12_mp0 & RSMU_SEC_END_ADDR_GROUP_12_MP0_RSMU_SEC_END_ADDR_GROUP_12_MASK) >> RSMU_SEC_END_ADDR_GROUP_12_MP0_RSMU_SEC_END_ADDR_GROUP_12_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_12_MP0_SET_RSMU_SEC_END_ADDR_GROUP_12(rsmu_sec_end_addr_group_12_mp0_reg, rsmu_sec_end_addr_group_12) \
      rsmu_sec_end_addr_group_12_mp0_reg = (rsmu_sec_end_addr_group_12_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_12_MP0_RSMU_SEC_END_ADDR_GROUP_12_MASK) | (rsmu_sec_end_addr_group_12 << RSMU_SEC_END_ADDR_GROUP_12_MP0_RSMU_SEC_END_ADDR_GROUP_12_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_12_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_12     : RSMU_SEC_END_ADDR_GROUP_12_MP0_RSMU_SEC_END_ADDR_GROUP_12_SIZE;
      } rsmu_sec_end_addr_group_12_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_12_mp0_t {
            unsigned int rsmu_sec_end_addr_group_12     : RSMU_SEC_END_ADDR_GROUP_12_MP0_RSMU_SEC_END_ADDR_GROUP_12_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_12_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_12_mp0_t f;
} rsmu_sec_end_addr_group_12_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_12_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_12_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_12_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_12_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_12_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_12_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_12_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_12_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_12_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_12_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_12_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_12_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_12_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_12(rsmu_sec_initid_mask_set0_group_12_mp0) \
      ((rsmu_sec_initid_mask_set0_group_12_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_12_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_12_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_12_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_12_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_12_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_12(rsmu_sec_initid_mask_set0_group_12_mp0_reg, rsmu_sec_initid_mask_set0_group_12) \
      rsmu_sec_initid_mask_set0_group_12_mp0_reg = (rsmu_sec_initid_mask_set0_group_12_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_12_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_12_MASK) | (rsmu_sec_initid_mask_set0_group_12 << RSMU_SEC_INITID_MASK_SET0_GROUP_12_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_12_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_12_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_12 : RSMU_SEC_INITID_MASK_SET0_GROUP_12_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_12_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_12_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_12_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_12 : RSMU_SEC_INITID_MASK_SET0_GROUP_12_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_12_SIZE;
      } rsmu_sec_initid_mask_set0_group_12_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_12_mp0_t f;
} rsmu_sec_initid_mask_set0_group_12_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_12_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_12_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_12_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_12_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_12_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_12_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_12_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_12_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_12_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_12_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_12_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_12_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_12_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_12(rsmu_sec_unitid_mask_set0_group_12_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_12_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_12_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_12_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_12_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_12_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_12_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_12(rsmu_sec_unitid_mask_set0_group_12_mp0_reg, rsmu_sec_unitid_mask_set0_group_12) \
      rsmu_sec_unitid_mask_set0_group_12_mp0_reg = (rsmu_sec_unitid_mask_set0_group_12_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_12_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_12_MASK) | (rsmu_sec_unitid_mask_set0_group_12 << RSMU_SEC_UNITID_MASK_SET0_GROUP_12_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_12_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_12_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_12 : RSMU_SEC_UNITID_MASK_SET0_GROUP_12_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_12_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_12_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_12_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_12 : RSMU_SEC_UNITID_MASK_SET0_GROUP_12_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_12_SIZE;
      } rsmu_sec_unitid_mask_set0_group_12_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_12_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_12_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_12_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_12_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_12_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_12_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_12_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_12_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_12_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_12_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_12_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_12_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_12_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_12_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_12(rsmu_sec_misc_mask_set0_group_12_mp0) \
      ((rsmu_sec_misc_mask_set0_group_12_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_12_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_12_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_12(rsmu_sec_misc_mask_set0_group_12_mp0) \
      ((rsmu_sec_misc_mask_set0_group_12_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_12_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_12_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_12(rsmu_sec_misc_mask_set0_group_12_mp0) \
      ((rsmu_sec_misc_mask_set0_group_12_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_12_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_12_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_12(rsmu_sec_misc_mask_set0_group_12_mp0_reg, rsmu_sec_tlvl_mask_set0_group_12) \
      rsmu_sec_misc_mask_set0_group_12_mp0_reg = (rsmu_sec_misc_mask_set0_group_12_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_12_MASK) | (rsmu_sec_tlvl_mask_set0_group_12 << RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_12_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_12(rsmu_sec_misc_mask_set0_group_12_mp0_reg, rsmu_sec_rw_mask_set0_group_12) \
      rsmu_sec_misc_mask_set0_group_12_mp0_reg = (rsmu_sec_misc_mask_set0_group_12_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_12_MASK) | (rsmu_sec_rw_mask_set0_group_12 << RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_12_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_12(rsmu_sec_misc_mask_set0_group_12_mp0_reg, rsmu_sec_vf_mask_set0_group_12) \
      rsmu_sec_misc_mask_set0_group_12_mp0_reg = (rsmu_sec_misc_mask_set0_group_12_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_12_MASK) | (rsmu_sec_vf_mask_set0_group_12 << RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_12_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_12_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_12 : RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_12_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_12 : RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_12_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_12 : RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_12_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_12_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_12_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_12 : RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_12_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_12 : RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_12_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_12 : RSMU_SEC_MISC_MASK_SET0_GROUP_12_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_12_SIZE;
      } rsmu_sec_misc_mask_set0_group_12_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_12_mp0_t f;
} rsmu_sec_misc_mask_set0_group_12_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_12_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_12_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_12_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_12_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_12_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_12_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_12_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_12_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_12_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_12_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_12_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_12_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_12_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_12(rsmu_sec_initid_mask_set1_group_12_mp0) \
      ((rsmu_sec_initid_mask_set1_group_12_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_12_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_12_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_12_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_12_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_12_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_12(rsmu_sec_initid_mask_set1_group_12_mp0_reg, rsmu_sec_initid_mask_set1_group_12) \
      rsmu_sec_initid_mask_set1_group_12_mp0_reg = (rsmu_sec_initid_mask_set1_group_12_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_12_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_12_MASK) | (rsmu_sec_initid_mask_set1_group_12 << RSMU_SEC_INITID_MASK_SET1_GROUP_12_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_12_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_12_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_12 : RSMU_SEC_INITID_MASK_SET1_GROUP_12_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_12_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_12_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_12_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_12 : RSMU_SEC_INITID_MASK_SET1_GROUP_12_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_12_SIZE;
      } rsmu_sec_initid_mask_set1_group_12_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_12_mp0_t f;
} rsmu_sec_initid_mask_set1_group_12_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_12_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_12_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_12_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_12_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_12_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_12_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_12_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_12_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_12_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_12_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_12_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_12_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_12_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_12(rsmu_sec_unitid_mask_set1_group_12_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_12_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_12_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_12_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_12_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_12_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_12_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_12(rsmu_sec_unitid_mask_set1_group_12_mp0_reg, rsmu_sec_unitid_mask_set1_group_12) \
      rsmu_sec_unitid_mask_set1_group_12_mp0_reg = (rsmu_sec_unitid_mask_set1_group_12_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_12_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_12_MASK) | (rsmu_sec_unitid_mask_set1_group_12 << RSMU_SEC_UNITID_MASK_SET1_GROUP_12_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_12_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_12_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_12 : RSMU_SEC_UNITID_MASK_SET1_GROUP_12_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_12_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_12_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_12_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_12 : RSMU_SEC_UNITID_MASK_SET1_GROUP_12_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_12_SIZE;
      } rsmu_sec_unitid_mask_set1_group_12_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_12_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_12_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_12_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_12_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_12_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_12_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_12_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_12_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_12_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_12_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_12_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_12_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_12_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_12_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_12(rsmu_sec_misc_mask_set1_group_12_mp0) \
      ((rsmu_sec_misc_mask_set1_group_12_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_12_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_12_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_12(rsmu_sec_misc_mask_set1_group_12_mp0) \
      ((rsmu_sec_misc_mask_set1_group_12_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_12_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_12_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_12(rsmu_sec_misc_mask_set1_group_12_mp0) \
      ((rsmu_sec_misc_mask_set1_group_12_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_12_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_12_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_12(rsmu_sec_misc_mask_set1_group_12_mp0_reg, rsmu_sec_tlvl_mask_set1_group_12) \
      rsmu_sec_misc_mask_set1_group_12_mp0_reg = (rsmu_sec_misc_mask_set1_group_12_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_12_MASK) | (rsmu_sec_tlvl_mask_set1_group_12 << RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_12_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_12(rsmu_sec_misc_mask_set1_group_12_mp0_reg, rsmu_sec_rw_mask_set1_group_12) \
      rsmu_sec_misc_mask_set1_group_12_mp0_reg = (rsmu_sec_misc_mask_set1_group_12_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_12_MASK) | (rsmu_sec_rw_mask_set1_group_12 << RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_12_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_12(rsmu_sec_misc_mask_set1_group_12_mp0_reg, rsmu_sec_vf_mask_set1_group_12) \
      rsmu_sec_misc_mask_set1_group_12_mp0_reg = (rsmu_sec_misc_mask_set1_group_12_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_12_MASK) | (rsmu_sec_vf_mask_set1_group_12 << RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_12_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_12_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_12 : RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_12_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_12 : RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_12_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_12 : RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_12_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_12_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_12_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_12 : RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_12_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_12 : RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_12_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_12 : RSMU_SEC_MISC_MASK_SET1_GROUP_12_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_12_SIZE;
      } rsmu_sec_misc_mask_set1_group_12_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_12_mp0_t f;
} rsmu_sec_misc_mask_set1_group_12_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_12_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_12_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_12_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_12_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_12_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_12_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_12_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_12_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_12_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_12_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_12_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_12_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_12_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_12_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_12_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_12_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_12(rsmu_sec_access_control_group_12_mp0) \
      ((rsmu_sec_access_control_group_12_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_12_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_12_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_12(rsmu_sec_access_control_group_12_mp0) \
      ((rsmu_sec_access_control_group_12_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_12_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_12_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_12(rsmu_sec_access_control_group_12_mp0) \
      ((rsmu_sec_access_control_group_12_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_12_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_12_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_12(rsmu_sec_access_control_group_12_mp0) \
      ((rsmu_sec_access_control_group_12_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_12_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_12_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_12(rsmu_sec_access_control_group_12_mp0_reg, rsmu_sec_check_enable_set0_group_12) \
      rsmu_sec_access_control_group_12_mp0_reg = (rsmu_sec_access_control_group_12_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_12_MASK) | (rsmu_sec_check_enable_set0_group_12 << RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_12_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_12(rsmu_sec_access_control_group_12_mp0_reg, rsmu_sec_check_enable_set1_group_12) \
      rsmu_sec_access_control_group_12_mp0_reg = (rsmu_sec_access_control_group_12_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_12_MASK) | (rsmu_sec_check_enable_set1_group_12 << RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_12_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_12(rsmu_sec_access_control_group_12_mp0_reg, rsmu_sec_vf_check_enable_set0_group_12) \
      rsmu_sec_access_control_group_12_mp0_reg = (rsmu_sec_access_control_group_12_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_12_MASK) | (rsmu_sec_vf_check_enable_set0_group_12 << RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_12_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_12(rsmu_sec_access_control_group_12_mp0_reg, rsmu_sec_vf_check_enable_set1_group_12) \
      rsmu_sec_access_control_group_12_mp0_reg = (rsmu_sec_access_control_group_12_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_12_MASK) | (rsmu_sec_vf_check_enable_set1_group_12 << RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_12_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_12_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_12 : RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_12_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_12 : RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_12_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_12 : RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_12_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_12 : RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_12_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_12_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_12_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_12 : RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_12_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_12 : RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_12_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_12 : RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_12_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_12 : RSMU_SEC_ACCESS_CONTROL_GROUP_12_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_12_SIZE;
      } rsmu_sec_access_control_group_12_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_12_mp0_t f;
} rsmu_sec_access_control_group_12_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_13_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_13_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_13_MP0_RSMU_SEC_START_ADDR_GROUP_13_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_13_MP0_RSMU_SEC_START_ADDR_GROUP_13_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_13_MP0_RSMU_SEC_START_ADDR_GROUP_13_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_13_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_13_MP0_RSMU_SEC_START_ADDR_GROUP_13_MASK)

#define RSMU_SEC_START_ADDR_GROUP_13_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_13_MP0_GET_RSMU_SEC_START_ADDR_GROUP_13(rsmu_sec_start_addr_group_13_mp0) \
      ((rsmu_sec_start_addr_group_13_mp0 & RSMU_SEC_START_ADDR_GROUP_13_MP0_RSMU_SEC_START_ADDR_GROUP_13_MASK) >> RSMU_SEC_START_ADDR_GROUP_13_MP0_RSMU_SEC_START_ADDR_GROUP_13_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_13_MP0_SET_RSMU_SEC_START_ADDR_GROUP_13(rsmu_sec_start_addr_group_13_mp0_reg, rsmu_sec_start_addr_group_13) \
      rsmu_sec_start_addr_group_13_mp0_reg = (rsmu_sec_start_addr_group_13_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_13_MP0_RSMU_SEC_START_ADDR_GROUP_13_MASK) | (rsmu_sec_start_addr_group_13 << RSMU_SEC_START_ADDR_GROUP_13_MP0_RSMU_SEC_START_ADDR_GROUP_13_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_13_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_13   : RSMU_SEC_START_ADDR_GROUP_13_MP0_RSMU_SEC_START_ADDR_GROUP_13_SIZE;
      } rsmu_sec_start_addr_group_13_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_13_mp0_t {
            unsigned int rsmu_sec_start_addr_group_13   : RSMU_SEC_START_ADDR_GROUP_13_MP0_RSMU_SEC_START_ADDR_GROUP_13_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_13_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_13_mp0_t f;
} rsmu_sec_start_addr_group_13_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_13_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_13_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_13_MP0_RSMU_SEC_END_ADDR_GROUP_13_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_13_MP0_RSMU_SEC_END_ADDR_GROUP_13_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_13_MP0_RSMU_SEC_END_ADDR_GROUP_13_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_13_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_13_MP0_RSMU_SEC_END_ADDR_GROUP_13_MASK)

#define RSMU_SEC_END_ADDR_GROUP_13_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_13_MP0_GET_RSMU_SEC_END_ADDR_GROUP_13(rsmu_sec_end_addr_group_13_mp0) \
      ((rsmu_sec_end_addr_group_13_mp0 & RSMU_SEC_END_ADDR_GROUP_13_MP0_RSMU_SEC_END_ADDR_GROUP_13_MASK) >> RSMU_SEC_END_ADDR_GROUP_13_MP0_RSMU_SEC_END_ADDR_GROUP_13_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_13_MP0_SET_RSMU_SEC_END_ADDR_GROUP_13(rsmu_sec_end_addr_group_13_mp0_reg, rsmu_sec_end_addr_group_13) \
      rsmu_sec_end_addr_group_13_mp0_reg = (rsmu_sec_end_addr_group_13_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_13_MP0_RSMU_SEC_END_ADDR_GROUP_13_MASK) | (rsmu_sec_end_addr_group_13 << RSMU_SEC_END_ADDR_GROUP_13_MP0_RSMU_SEC_END_ADDR_GROUP_13_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_13_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_13     : RSMU_SEC_END_ADDR_GROUP_13_MP0_RSMU_SEC_END_ADDR_GROUP_13_SIZE;
      } rsmu_sec_end_addr_group_13_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_13_mp0_t {
            unsigned int rsmu_sec_end_addr_group_13     : RSMU_SEC_END_ADDR_GROUP_13_MP0_RSMU_SEC_END_ADDR_GROUP_13_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_13_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_13_mp0_t f;
} rsmu_sec_end_addr_group_13_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_13_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_13_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_13_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_13_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_13_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_13_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_13_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_13_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_13_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_13_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_13_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_13_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_13_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_13(rsmu_sec_initid_mask_set0_group_13_mp0) \
      ((rsmu_sec_initid_mask_set0_group_13_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_13_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_13_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_13_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_13_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_13_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_13(rsmu_sec_initid_mask_set0_group_13_mp0_reg, rsmu_sec_initid_mask_set0_group_13) \
      rsmu_sec_initid_mask_set0_group_13_mp0_reg = (rsmu_sec_initid_mask_set0_group_13_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_13_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_13_MASK) | (rsmu_sec_initid_mask_set0_group_13 << RSMU_SEC_INITID_MASK_SET0_GROUP_13_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_13_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_13_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_13 : RSMU_SEC_INITID_MASK_SET0_GROUP_13_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_13_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_13_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_13_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_13 : RSMU_SEC_INITID_MASK_SET0_GROUP_13_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_13_SIZE;
      } rsmu_sec_initid_mask_set0_group_13_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_13_mp0_t f;
} rsmu_sec_initid_mask_set0_group_13_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_13_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_13_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_13_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_13_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_13_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_13_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_13_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_13_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_13_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_13_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_13_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_13_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_13_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_13(rsmu_sec_unitid_mask_set0_group_13_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_13_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_13_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_13_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_13_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_13_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_13_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_13(rsmu_sec_unitid_mask_set0_group_13_mp0_reg, rsmu_sec_unitid_mask_set0_group_13) \
      rsmu_sec_unitid_mask_set0_group_13_mp0_reg = (rsmu_sec_unitid_mask_set0_group_13_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_13_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_13_MASK) | (rsmu_sec_unitid_mask_set0_group_13 << RSMU_SEC_UNITID_MASK_SET0_GROUP_13_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_13_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_13_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_13 : RSMU_SEC_UNITID_MASK_SET0_GROUP_13_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_13_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_13_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_13_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_13 : RSMU_SEC_UNITID_MASK_SET0_GROUP_13_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_13_SIZE;
      } rsmu_sec_unitid_mask_set0_group_13_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_13_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_13_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_13_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_13_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_13_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_13_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_13_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_13_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_13_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_13_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_13_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_13_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_13_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_13_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_13(rsmu_sec_misc_mask_set0_group_13_mp0) \
      ((rsmu_sec_misc_mask_set0_group_13_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_13_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_13_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_13(rsmu_sec_misc_mask_set0_group_13_mp0) \
      ((rsmu_sec_misc_mask_set0_group_13_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_13_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_13_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_13(rsmu_sec_misc_mask_set0_group_13_mp0) \
      ((rsmu_sec_misc_mask_set0_group_13_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_13_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_13_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_13(rsmu_sec_misc_mask_set0_group_13_mp0_reg, rsmu_sec_tlvl_mask_set0_group_13) \
      rsmu_sec_misc_mask_set0_group_13_mp0_reg = (rsmu_sec_misc_mask_set0_group_13_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_13_MASK) | (rsmu_sec_tlvl_mask_set0_group_13 << RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_13_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_13(rsmu_sec_misc_mask_set0_group_13_mp0_reg, rsmu_sec_rw_mask_set0_group_13) \
      rsmu_sec_misc_mask_set0_group_13_mp0_reg = (rsmu_sec_misc_mask_set0_group_13_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_13_MASK) | (rsmu_sec_rw_mask_set0_group_13 << RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_13_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_13(rsmu_sec_misc_mask_set0_group_13_mp0_reg, rsmu_sec_vf_mask_set0_group_13) \
      rsmu_sec_misc_mask_set0_group_13_mp0_reg = (rsmu_sec_misc_mask_set0_group_13_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_13_MASK) | (rsmu_sec_vf_mask_set0_group_13 << RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_13_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_13_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_13 : RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_13_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_13 : RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_13_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_13 : RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_13_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_13_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_13_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_13 : RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_13_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_13 : RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_13_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_13 : RSMU_SEC_MISC_MASK_SET0_GROUP_13_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_13_SIZE;
      } rsmu_sec_misc_mask_set0_group_13_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_13_mp0_t f;
} rsmu_sec_misc_mask_set0_group_13_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_13_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_13_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_13_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_13_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_13_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_13_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_13_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_13_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_13_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_13_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_13_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_13_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_13_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_13(rsmu_sec_initid_mask_set1_group_13_mp0) \
      ((rsmu_sec_initid_mask_set1_group_13_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_13_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_13_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_13_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_13_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_13_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_13(rsmu_sec_initid_mask_set1_group_13_mp0_reg, rsmu_sec_initid_mask_set1_group_13) \
      rsmu_sec_initid_mask_set1_group_13_mp0_reg = (rsmu_sec_initid_mask_set1_group_13_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_13_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_13_MASK) | (rsmu_sec_initid_mask_set1_group_13 << RSMU_SEC_INITID_MASK_SET1_GROUP_13_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_13_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_13_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_13 : RSMU_SEC_INITID_MASK_SET1_GROUP_13_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_13_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_13_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_13_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_13 : RSMU_SEC_INITID_MASK_SET1_GROUP_13_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_13_SIZE;
      } rsmu_sec_initid_mask_set1_group_13_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_13_mp0_t f;
} rsmu_sec_initid_mask_set1_group_13_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_13_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_13_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_13_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_13_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_13_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_13_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_13_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_13_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_13_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_13_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_13_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_13_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_13_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_13(rsmu_sec_unitid_mask_set1_group_13_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_13_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_13_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_13_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_13_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_13_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_13_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_13(rsmu_sec_unitid_mask_set1_group_13_mp0_reg, rsmu_sec_unitid_mask_set1_group_13) \
      rsmu_sec_unitid_mask_set1_group_13_mp0_reg = (rsmu_sec_unitid_mask_set1_group_13_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_13_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_13_MASK) | (rsmu_sec_unitid_mask_set1_group_13 << RSMU_SEC_UNITID_MASK_SET1_GROUP_13_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_13_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_13_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_13 : RSMU_SEC_UNITID_MASK_SET1_GROUP_13_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_13_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_13_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_13_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_13 : RSMU_SEC_UNITID_MASK_SET1_GROUP_13_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_13_SIZE;
      } rsmu_sec_unitid_mask_set1_group_13_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_13_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_13_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_13_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_13_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_13_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_13_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_13_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_13_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_13_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_13_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_13_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_13_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_13_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_13_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_13(rsmu_sec_misc_mask_set1_group_13_mp0) \
      ((rsmu_sec_misc_mask_set1_group_13_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_13_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_13_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_13(rsmu_sec_misc_mask_set1_group_13_mp0) \
      ((rsmu_sec_misc_mask_set1_group_13_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_13_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_13_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_13(rsmu_sec_misc_mask_set1_group_13_mp0) \
      ((rsmu_sec_misc_mask_set1_group_13_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_13_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_13_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_13(rsmu_sec_misc_mask_set1_group_13_mp0_reg, rsmu_sec_tlvl_mask_set1_group_13) \
      rsmu_sec_misc_mask_set1_group_13_mp0_reg = (rsmu_sec_misc_mask_set1_group_13_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_13_MASK) | (rsmu_sec_tlvl_mask_set1_group_13 << RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_13_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_13(rsmu_sec_misc_mask_set1_group_13_mp0_reg, rsmu_sec_rw_mask_set1_group_13) \
      rsmu_sec_misc_mask_set1_group_13_mp0_reg = (rsmu_sec_misc_mask_set1_group_13_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_13_MASK) | (rsmu_sec_rw_mask_set1_group_13 << RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_13_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_13(rsmu_sec_misc_mask_set1_group_13_mp0_reg, rsmu_sec_vf_mask_set1_group_13) \
      rsmu_sec_misc_mask_set1_group_13_mp0_reg = (rsmu_sec_misc_mask_set1_group_13_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_13_MASK) | (rsmu_sec_vf_mask_set1_group_13 << RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_13_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_13_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_13 : RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_13_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_13 : RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_13_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_13 : RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_13_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_13_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_13_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_13 : RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_13_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_13 : RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_13_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_13 : RSMU_SEC_MISC_MASK_SET1_GROUP_13_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_13_SIZE;
      } rsmu_sec_misc_mask_set1_group_13_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_13_mp0_t f;
} rsmu_sec_misc_mask_set1_group_13_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_13_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_13_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_13_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_13_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_13_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_13_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_13_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_13_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_13_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_13_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_13_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_13_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_13_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_13_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_13_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_13_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_13(rsmu_sec_access_control_group_13_mp0) \
      ((rsmu_sec_access_control_group_13_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_13_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_13_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_13(rsmu_sec_access_control_group_13_mp0) \
      ((rsmu_sec_access_control_group_13_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_13_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_13_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_13(rsmu_sec_access_control_group_13_mp0) \
      ((rsmu_sec_access_control_group_13_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_13_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_13_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_13(rsmu_sec_access_control_group_13_mp0) \
      ((rsmu_sec_access_control_group_13_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_13_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_13_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_13(rsmu_sec_access_control_group_13_mp0_reg, rsmu_sec_check_enable_set0_group_13) \
      rsmu_sec_access_control_group_13_mp0_reg = (rsmu_sec_access_control_group_13_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_13_MASK) | (rsmu_sec_check_enable_set0_group_13 << RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_13_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_13(rsmu_sec_access_control_group_13_mp0_reg, rsmu_sec_check_enable_set1_group_13) \
      rsmu_sec_access_control_group_13_mp0_reg = (rsmu_sec_access_control_group_13_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_13_MASK) | (rsmu_sec_check_enable_set1_group_13 << RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_13_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_13(rsmu_sec_access_control_group_13_mp0_reg, rsmu_sec_vf_check_enable_set0_group_13) \
      rsmu_sec_access_control_group_13_mp0_reg = (rsmu_sec_access_control_group_13_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_13_MASK) | (rsmu_sec_vf_check_enable_set0_group_13 << RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_13_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_13(rsmu_sec_access_control_group_13_mp0_reg, rsmu_sec_vf_check_enable_set1_group_13) \
      rsmu_sec_access_control_group_13_mp0_reg = (rsmu_sec_access_control_group_13_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_13_MASK) | (rsmu_sec_vf_check_enable_set1_group_13 << RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_13_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_13_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_13 : RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_13_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_13 : RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_13_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_13 : RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_13_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_13 : RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_13_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_13_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_13_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_13 : RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_13_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_13 : RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_13_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_13 : RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_13_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_13 : RSMU_SEC_ACCESS_CONTROL_GROUP_13_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_13_SIZE;
      } rsmu_sec_access_control_group_13_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_13_mp0_t f;
} rsmu_sec_access_control_group_13_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_14_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_14_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_14_MP0_RSMU_SEC_START_ADDR_GROUP_14_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_14_MP0_RSMU_SEC_START_ADDR_GROUP_14_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_14_MP0_RSMU_SEC_START_ADDR_GROUP_14_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_14_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_14_MP0_RSMU_SEC_START_ADDR_GROUP_14_MASK)

#define RSMU_SEC_START_ADDR_GROUP_14_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_14_MP0_GET_RSMU_SEC_START_ADDR_GROUP_14(rsmu_sec_start_addr_group_14_mp0) \
      ((rsmu_sec_start_addr_group_14_mp0 & RSMU_SEC_START_ADDR_GROUP_14_MP0_RSMU_SEC_START_ADDR_GROUP_14_MASK) >> RSMU_SEC_START_ADDR_GROUP_14_MP0_RSMU_SEC_START_ADDR_GROUP_14_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_14_MP0_SET_RSMU_SEC_START_ADDR_GROUP_14(rsmu_sec_start_addr_group_14_mp0_reg, rsmu_sec_start_addr_group_14) \
      rsmu_sec_start_addr_group_14_mp0_reg = (rsmu_sec_start_addr_group_14_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_14_MP0_RSMU_SEC_START_ADDR_GROUP_14_MASK) | (rsmu_sec_start_addr_group_14 << RSMU_SEC_START_ADDR_GROUP_14_MP0_RSMU_SEC_START_ADDR_GROUP_14_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_14_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_14   : RSMU_SEC_START_ADDR_GROUP_14_MP0_RSMU_SEC_START_ADDR_GROUP_14_SIZE;
      } rsmu_sec_start_addr_group_14_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_14_mp0_t {
            unsigned int rsmu_sec_start_addr_group_14   : RSMU_SEC_START_ADDR_GROUP_14_MP0_RSMU_SEC_START_ADDR_GROUP_14_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_14_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_14_mp0_t f;
} rsmu_sec_start_addr_group_14_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_14_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_14_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_14_MP0_RSMU_SEC_END_ADDR_GROUP_14_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_14_MP0_RSMU_SEC_END_ADDR_GROUP_14_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_14_MP0_RSMU_SEC_END_ADDR_GROUP_14_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_14_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_14_MP0_RSMU_SEC_END_ADDR_GROUP_14_MASK)

#define RSMU_SEC_END_ADDR_GROUP_14_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_14_MP0_GET_RSMU_SEC_END_ADDR_GROUP_14(rsmu_sec_end_addr_group_14_mp0) \
      ((rsmu_sec_end_addr_group_14_mp0 & RSMU_SEC_END_ADDR_GROUP_14_MP0_RSMU_SEC_END_ADDR_GROUP_14_MASK) >> RSMU_SEC_END_ADDR_GROUP_14_MP0_RSMU_SEC_END_ADDR_GROUP_14_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_14_MP0_SET_RSMU_SEC_END_ADDR_GROUP_14(rsmu_sec_end_addr_group_14_mp0_reg, rsmu_sec_end_addr_group_14) \
      rsmu_sec_end_addr_group_14_mp0_reg = (rsmu_sec_end_addr_group_14_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_14_MP0_RSMU_SEC_END_ADDR_GROUP_14_MASK) | (rsmu_sec_end_addr_group_14 << RSMU_SEC_END_ADDR_GROUP_14_MP0_RSMU_SEC_END_ADDR_GROUP_14_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_14_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_14     : RSMU_SEC_END_ADDR_GROUP_14_MP0_RSMU_SEC_END_ADDR_GROUP_14_SIZE;
      } rsmu_sec_end_addr_group_14_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_14_mp0_t {
            unsigned int rsmu_sec_end_addr_group_14     : RSMU_SEC_END_ADDR_GROUP_14_MP0_RSMU_SEC_END_ADDR_GROUP_14_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_14_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_14_mp0_t f;
} rsmu_sec_end_addr_group_14_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_14_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_14_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_14_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_14_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_14_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_14_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_14_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_14_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_14_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_14_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_14_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_14_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_14_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_14(rsmu_sec_initid_mask_set0_group_14_mp0) \
      ((rsmu_sec_initid_mask_set0_group_14_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_14_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_14_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_14_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_14_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_14_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_14(rsmu_sec_initid_mask_set0_group_14_mp0_reg, rsmu_sec_initid_mask_set0_group_14) \
      rsmu_sec_initid_mask_set0_group_14_mp0_reg = (rsmu_sec_initid_mask_set0_group_14_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_14_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_14_MASK) | (rsmu_sec_initid_mask_set0_group_14 << RSMU_SEC_INITID_MASK_SET0_GROUP_14_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_14_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_14_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_14 : RSMU_SEC_INITID_MASK_SET0_GROUP_14_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_14_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_14_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_14_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_14 : RSMU_SEC_INITID_MASK_SET0_GROUP_14_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_14_SIZE;
      } rsmu_sec_initid_mask_set0_group_14_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_14_mp0_t f;
} rsmu_sec_initid_mask_set0_group_14_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_14_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_14_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_14_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_14_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_14_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_14_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_14_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_14_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_14_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_14_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_14_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_14_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_14_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_14(rsmu_sec_unitid_mask_set0_group_14_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_14_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_14_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_14_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_14_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_14_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_14_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_14(rsmu_sec_unitid_mask_set0_group_14_mp0_reg, rsmu_sec_unitid_mask_set0_group_14) \
      rsmu_sec_unitid_mask_set0_group_14_mp0_reg = (rsmu_sec_unitid_mask_set0_group_14_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_14_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_14_MASK) | (rsmu_sec_unitid_mask_set0_group_14 << RSMU_SEC_UNITID_MASK_SET0_GROUP_14_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_14_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_14_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_14 : RSMU_SEC_UNITID_MASK_SET0_GROUP_14_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_14_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_14_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_14_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_14 : RSMU_SEC_UNITID_MASK_SET0_GROUP_14_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_14_SIZE;
      } rsmu_sec_unitid_mask_set0_group_14_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_14_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_14_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_14_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_14_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_14_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_14_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_14_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_14_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_14_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_14_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_14_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_14_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_14_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_14_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_14(rsmu_sec_misc_mask_set0_group_14_mp0) \
      ((rsmu_sec_misc_mask_set0_group_14_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_14_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_14_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_14(rsmu_sec_misc_mask_set0_group_14_mp0) \
      ((rsmu_sec_misc_mask_set0_group_14_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_14_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_14_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_14(rsmu_sec_misc_mask_set0_group_14_mp0) \
      ((rsmu_sec_misc_mask_set0_group_14_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_14_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_14_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_14(rsmu_sec_misc_mask_set0_group_14_mp0_reg, rsmu_sec_tlvl_mask_set0_group_14) \
      rsmu_sec_misc_mask_set0_group_14_mp0_reg = (rsmu_sec_misc_mask_set0_group_14_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_14_MASK) | (rsmu_sec_tlvl_mask_set0_group_14 << RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_14_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_14(rsmu_sec_misc_mask_set0_group_14_mp0_reg, rsmu_sec_rw_mask_set0_group_14) \
      rsmu_sec_misc_mask_set0_group_14_mp0_reg = (rsmu_sec_misc_mask_set0_group_14_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_14_MASK) | (rsmu_sec_rw_mask_set0_group_14 << RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_14_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_14(rsmu_sec_misc_mask_set0_group_14_mp0_reg, rsmu_sec_vf_mask_set0_group_14) \
      rsmu_sec_misc_mask_set0_group_14_mp0_reg = (rsmu_sec_misc_mask_set0_group_14_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_14_MASK) | (rsmu_sec_vf_mask_set0_group_14 << RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_14_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_14_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_14 : RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_14_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_14 : RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_14_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_14 : RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_14_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_14_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_14_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_14 : RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_14_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_14 : RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_14_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_14 : RSMU_SEC_MISC_MASK_SET0_GROUP_14_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_14_SIZE;
      } rsmu_sec_misc_mask_set0_group_14_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_14_mp0_t f;
} rsmu_sec_misc_mask_set0_group_14_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_14_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_14_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_14_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_14_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_14_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_14_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_14_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_14_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_14_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_14_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_14_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_14_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_14_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_14(rsmu_sec_initid_mask_set1_group_14_mp0) \
      ((rsmu_sec_initid_mask_set1_group_14_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_14_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_14_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_14_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_14_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_14_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_14(rsmu_sec_initid_mask_set1_group_14_mp0_reg, rsmu_sec_initid_mask_set1_group_14) \
      rsmu_sec_initid_mask_set1_group_14_mp0_reg = (rsmu_sec_initid_mask_set1_group_14_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_14_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_14_MASK) | (rsmu_sec_initid_mask_set1_group_14 << RSMU_SEC_INITID_MASK_SET1_GROUP_14_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_14_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_14_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_14 : RSMU_SEC_INITID_MASK_SET1_GROUP_14_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_14_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_14_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_14_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_14 : RSMU_SEC_INITID_MASK_SET1_GROUP_14_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_14_SIZE;
      } rsmu_sec_initid_mask_set1_group_14_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_14_mp0_t f;
} rsmu_sec_initid_mask_set1_group_14_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_14_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_14_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_14_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_14_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_14_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_14_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_14_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_14_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_14_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_14_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_14_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_14_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_14_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_14(rsmu_sec_unitid_mask_set1_group_14_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_14_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_14_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_14_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_14_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_14_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_14_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_14(rsmu_sec_unitid_mask_set1_group_14_mp0_reg, rsmu_sec_unitid_mask_set1_group_14) \
      rsmu_sec_unitid_mask_set1_group_14_mp0_reg = (rsmu_sec_unitid_mask_set1_group_14_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_14_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_14_MASK) | (rsmu_sec_unitid_mask_set1_group_14 << RSMU_SEC_UNITID_MASK_SET1_GROUP_14_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_14_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_14_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_14 : RSMU_SEC_UNITID_MASK_SET1_GROUP_14_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_14_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_14_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_14_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_14 : RSMU_SEC_UNITID_MASK_SET1_GROUP_14_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_14_SIZE;
      } rsmu_sec_unitid_mask_set1_group_14_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_14_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_14_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_14_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_14_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_14_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_14_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_14_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_14_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_14_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_14_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_14_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_14_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_14_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_14_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_14(rsmu_sec_misc_mask_set1_group_14_mp0) \
      ((rsmu_sec_misc_mask_set1_group_14_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_14_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_14_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_14(rsmu_sec_misc_mask_set1_group_14_mp0) \
      ((rsmu_sec_misc_mask_set1_group_14_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_14_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_14_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_14(rsmu_sec_misc_mask_set1_group_14_mp0) \
      ((rsmu_sec_misc_mask_set1_group_14_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_14_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_14_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_14(rsmu_sec_misc_mask_set1_group_14_mp0_reg, rsmu_sec_tlvl_mask_set1_group_14) \
      rsmu_sec_misc_mask_set1_group_14_mp0_reg = (rsmu_sec_misc_mask_set1_group_14_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_14_MASK) | (rsmu_sec_tlvl_mask_set1_group_14 << RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_14_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_14(rsmu_sec_misc_mask_set1_group_14_mp0_reg, rsmu_sec_rw_mask_set1_group_14) \
      rsmu_sec_misc_mask_set1_group_14_mp0_reg = (rsmu_sec_misc_mask_set1_group_14_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_14_MASK) | (rsmu_sec_rw_mask_set1_group_14 << RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_14_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_14(rsmu_sec_misc_mask_set1_group_14_mp0_reg, rsmu_sec_vf_mask_set1_group_14) \
      rsmu_sec_misc_mask_set1_group_14_mp0_reg = (rsmu_sec_misc_mask_set1_group_14_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_14_MASK) | (rsmu_sec_vf_mask_set1_group_14 << RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_14_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_14_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_14 : RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_14_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_14 : RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_14_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_14 : RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_14_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_14_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_14_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_14 : RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_14_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_14 : RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_14_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_14 : RSMU_SEC_MISC_MASK_SET1_GROUP_14_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_14_SIZE;
      } rsmu_sec_misc_mask_set1_group_14_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_14_mp0_t f;
} rsmu_sec_misc_mask_set1_group_14_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_14_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_14_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_14_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_14_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_14_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_14_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_14_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_14_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_14_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_14_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_14_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_14_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_14_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_14_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_14_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_14_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_14(rsmu_sec_access_control_group_14_mp0) \
      ((rsmu_sec_access_control_group_14_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_14_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_14_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_14(rsmu_sec_access_control_group_14_mp0) \
      ((rsmu_sec_access_control_group_14_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_14_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_14_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_14(rsmu_sec_access_control_group_14_mp0) \
      ((rsmu_sec_access_control_group_14_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_14_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_14_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_14(rsmu_sec_access_control_group_14_mp0) \
      ((rsmu_sec_access_control_group_14_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_14_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_14_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_14(rsmu_sec_access_control_group_14_mp0_reg, rsmu_sec_check_enable_set0_group_14) \
      rsmu_sec_access_control_group_14_mp0_reg = (rsmu_sec_access_control_group_14_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_14_MASK) | (rsmu_sec_check_enable_set0_group_14 << RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_14_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_14(rsmu_sec_access_control_group_14_mp0_reg, rsmu_sec_check_enable_set1_group_14) \
      rsmu_sec_access_control_group_14_mp0_reg = (rsmu_sec_access_control_group_14_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_14_MASK) | (rsmu_sec_check_enable_set1_group_14 << RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_14_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_14(rsmu_sec_access_control_group_14_mp0_reg, rsmu_sec_vf_check_enable_set0_group_14) \
      rsmu_sec_access_control_group_14_mp0_reg = (rsmu_sec_access_control_group_14_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_14_MASK) | (rsmu_sec_vf_check_enable_set0_group_14 << RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_14_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_14(rsmu_sec_access_control_group_14_mp0_reg, rsmu_sec_vf_check_enable_set1_group_14) \
      rsmu_sec_access_control_group_14_mp0_reg = (rsmu_sec_access_control_group_14_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_14_MASK) | (rsmu_sec_vf_check_enable_set1_group_14 << RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_14_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_14_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_14 : RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_14_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_14 : RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_14_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_14 : RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_14_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_14 : RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_14_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_14_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_14_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_14 : RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_14_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_14 : RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_14_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_14 : RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_14_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_14 : RSMU_SEC_ACCESS_CONTROL_GROUP_14_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_14_SIZE;
      } rsmu_sec_access_control_group_14_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_14_mp0_t f;
} rsmu_sec_access_control_group_14_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_15_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_15_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_15_MP0_RSMU_SEC_START_ADDR_GROUP_15_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_15_MP0_RSMU_SEC_START_ADDR_GROUP_15_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_15_MP0_RSMU_SEC_START_ADDR_GROUP_15_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_15_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_15_MP0_RSMU_SEC_START_ADDR_GROUP_15_MASK)

#define RSMU_SEC_START_ADDR_GROUP_15_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_15_MP0_GET_RSMU_SEC_START_ADDR_GROUP_15(rsmu_sec_start_addr_group_15_mp0) \
      ((rsmu_sec_start_addr_group_15_mp0 & RSMU_SEC_START_ADDR_GROUP_15_MP0_RSMU_SEC_START_ADDR_GROUP_15_MASK) >> RSMU_SEC_START_ADDR_GROUP_15_MP0_RSMU_SEC_START_ADDR_GROUP_15_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_15_MP0_SET_RSMU_SEC_START_ADDR_GROUP_15(rsmu_sec_start_addr_group_15_mp0_reg, rsmu_sec_start_addr_group_15) \
      rsmu_sec_start_addr_group_15_mp0_reg = (rsmu_sec_start_addr_group_15_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_15_MP0_RSMU_SEC_START_ADDR_GROUP_15_MASK) | (rsmu_sec_start_addr_group_15 << RSMU_SEC_START_ADDR_GROUP_15_MP0_RSMU_SEC_START_ADDR_GROUP_15_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_15_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_15   : RSMU_SEC_START_ADDR_GROUP_15_MP0_RSMU_SEC_START_ADDR_GROUP_15_SIZE;
      } rsmu_sec_start_addr_group_15_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_15_mp0_t {
            unsigned int rsmu_sec_start_addr_group_15   : RSMU_SEC_START_ADDR_GROUP_15_MP0_RSMU_SEC_START_ADDR_GROUP_15_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_15_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_15_mp0_t f;
} rsmu_sec_start_addr_group_15_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_15_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_15_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_15_MP0_RSMU_SEC_END_ADDR_GROUP_15_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_15_MP0_RSMU_SEC_END_ADDR_GROUP_15_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_15_MP0_RSMU_SEC_END_ADDR_GROUP_15_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_15_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_15_MP0_RSMU_SEC_END_ADDR_GROUP_15_MASK)

#define RSMU_SEC_END_ADDR_GROUP_15_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_15_MP0_GET_RSMU_SEC_END_ADDR_GROUP_15(rsmu_sec_end_addr_group_15_mp0) \
      ((rsmu_sec_end_addr_group_15_mp0 & RSMU_SEC_END_ADDR_GROUP_15_MP0_RSMU_SEC_END_ADDR_GROUP_15_MASK) >> RSMU_SEC_END_ADDR_GROUP_15_MP0_RSMU_SEC_END_ADDR_GROUP_15_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_15_MP0_SET_RSMU_SEC_END_ADDR_GROUP_15(rsmu_sec_end_addr_group_15_mp0_reg, rsmu_sec_end_addr_group_15) \
      rsmu_sec_end_addr_group_15_mp0_reg = (rsmu_sec_end_addr_group_15_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_15_MP0_RSMU_SEC_END_ADDR_GROUP_15_MASK) | (rsmu_sec_end_addr_group_15 << RSMU_SEC_END_ADDR_GROUP_15_MP0_RSMU_SEC_END_ADDR_GROUP_15_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_15_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_15     : RSMU_SEC_END_ADDR_GROUP_15_MP0_RSMU_SEC_END_ADDR_GROUP_15_SIZE;
      } rsmu_sec_end_addr_group_15_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_15_mp0_t {
            unsigned int rsmu_sec_end_addr_group_15     : RSMU_SEC_END_ADDR_GROUP_15_MP0_RSMU_SEC_END_ADDR_GROUP_15_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_15_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_15_mp0_t f;
} rsmu_sec_end_addr_group_15_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_15_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_15_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_15_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_15_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_15_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_15_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_15_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_15_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_15_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_15_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_15_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_15_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_15_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_15(rsmu_sec_initid_mask_set0_group_15_mp0) \
      ((rsmu_sec_initid_mask_set0_group_15_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_15_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_15_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_15_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_15_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_15_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_15(rsmu_sec_initid_mask_set0_group_15_mp0_reg, rsmu_sec_initid_mask_set0_group_15) \
      rsmu_sec_initid_mask_set0_group_15_mp0_reg = (rsmu_sec_initid_mask_set0_group_15_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_15_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_15_MASK) | (rsmu_sec_initid_mask_set0_group_15 << RSMU_SEC_INITID_MASK_SET0_GROUP_15_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_15_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_15_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_15 : RSMU_SEC_INITID_MASK_SET0_GROUP_15_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_15_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_15_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_15_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_15 : RSMU_SEC_INITID_MASK_SET0_GROUP_15_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_15_SIZE;
      } rsmu_sec_initid_mask_set0_group_15_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_15_mp0_t f;
} rsmu_sec_initid_mask_set0_group_15_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_15_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_15_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_15_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_15_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_15_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_15_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_15_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_15_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_15_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_15_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_15_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_15_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_15_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_15(rsmu_sec_unitid_mask_set0_group_15_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_15_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_15_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_15_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_15_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_15_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_15_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_15(rsmu_sec_unitid_mask_set0_group_15_mp0_reg, rsmu_sec_unitid_mask_set0_group_15) \
      rsmu_sec_unitid_mask_set0_group_15_mp0_reg = (rsmu_sec_unitid_mask_set0_group_15_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_15_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_15_MASK) | (rsmu_sec_unitid_mask_set0_group_15 << RSMU_SEC_UNITID_MASK_SET0_GROUP_15_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_15_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_15_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_15 : RSMU_SEC_UNITID_MASK_SET0_GROUP_15_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_15_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_15_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_15_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_15 : RSMU_SEC_UNITID_MASK_SET0_GROUP_15_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_15_SIZE;
      } rsmu_sec_unitid_mask_set0_group_15_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_15_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_15_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_15_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_15_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_15_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_15_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_15_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_15_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_15_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_15_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_15_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_15_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_15_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_15_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_15(rsmu_sec_misc_mask_set0_group_15_mp0) \
      ((rsmu_sec_misc_mask_set0_group_15_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_15_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_15_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_15(rsmu_sec_misc_mask_set0_group_15_mp0) \
      ((rsmu_sec_misc_mask_set0_group_15_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_15_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_15_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_15(rsmu_sec_misc_mask_set0_group_15_mp0) \
      ((rsmu_sec_misc_mask_set0_group_15_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_15_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_15_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_15(rsmu_sec_misc_mask_set0_group_15_mp0_reg, rsmu_sec_tlvl_mask_set0_group_15) \
      rsmu_sec_misc_mask_set0_group_15_mp0_reg = (rsmu_sec_misc_mask_set0_group_15_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_15_MASK) | (rsmu_sec_tlvl_mask_set0_group_15 << RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_15_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_15(rsmu_sec_misc_mask_set0_group_15_mp0_reg, rsmu_sec_rw_mask_set0_group_15) \
      rsmu_sec_misc_mask_set0_group_15_mp0_reg = (rsmu_sec_misc_mask_set0_group_15_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_15_MASK) | (rsmu_sec_rw_mask_set0_group_15 << RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_15_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_15(rsmu_sec_misc_mask_set0_group_15_mp0_reg, rsmu_sec_vf_mask_set0_group_15) \
      rsmu_sec_misc_mask_set0_group_15_mp0_reg = (rsmu_sec_misc_mask_set0_group_15_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_15_MASK) | (rsmu_sec_vf_mask_set0_group_15 << RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_15_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_15_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_15 : RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_15_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_15 : RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_15_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_15 : RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_15_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_15_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_15_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_15 : RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_15_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_15 : RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_15_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_15 : RSMU_SEC_MISC_MASK_SET0_GROUP_15_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_15_SIZE;
      } rsmu_sec_misc_mask_set0_group_15_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_15_mp0_t f;
} rsmu_sec_misc_mask_set0_group_15_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_15_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_15_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_15_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_15_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_15_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_15_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_15_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_15_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_15_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_15_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_15_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_15_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_15_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_15(rsmu_sec_initid_mask_set1_group_15_mp0) \
      ((rsmu_sec_initid_mask_set1_group_15_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_15_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_15_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_15_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_15_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_15_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_15(rsmu_sec_initid_mask_set1_group_15_mp0_reg, rsmu_sec_initid_mask_set1_group_15) \
      rsmu_sec_initid_mask_set1_group_15_mp0_reg = (rsmu_sec_initid_mask_set1_group_15_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_15_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_15_MASK) | (rsmu_sec_initid_mask_set1_group_15 << RSMU_SEC_INITID_MASK_SET1_GROUP_15_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_15_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_15_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_15 : RSMU_SEC_INITID_MASK_SET1_GROUP_15_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_15_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_15_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_15_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_15 : RSMU_SEC_INITID_MASK_SET1_GROUP_15_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_15_SIZE;
      } rsmu_sec_initid_mask_set1_group_15_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_15_mp0_t f;
} rsmu_sec_initid_mask_set1_group_15_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_15_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_15_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_15_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_15_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_15_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_15_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_15_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_15_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_15_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_15_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_15_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_15_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_15_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_15(rsmu_sec_unitid_mask_set1_group_15_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_15_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_15_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_15_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_15_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_15_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_15_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_15(rsmu_sec_unitid_mask_set1_group_15_mp0_reg, rsmu_sec_unitid_mask_set1_group_15) \
      rsmu_sec_unitid_mask_set1_group_15_mp0_reg = (rsmu_sec_unitid_mask_set1_group_15_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_15_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_15_MASK) | (rsmu_sec_unitid_mask_set1_group_15 << RSMU_SEC_UNITID_MASK_SET1_GROUP_15_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_15_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_15_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_15 : RSMU_SEC_UNITID_MASK_SET1_GROUP_15_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_15_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_15_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_15_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_15 : RSMU_SEC_UNITID_MASK_SET1_GROUP_15_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_15_SIZE;
      } rsmu_sec_unitid_mask_set1_group_15_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_15_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_15_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_15_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_15_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_15_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_15_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_15_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_15_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_15_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_15_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_15_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_15_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_15_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_15_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_15(rsmu_sec_misc_mask_set1_group_15_mp0) \
      ((rsmu_sec_misc_mask_set1_group_15_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_15_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_15_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_15(rsmu_sec_misc_mask_set1_group_15_mp0) \
      ((rsmu_sec_misc_mask_set1_group_15_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_15_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_15_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_15(rsmu_sec_misc_mask_set1_group_15_mp0) \
      ((rsmu_sec_misc_mask_set1_group_15_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_15_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_15_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_15(rsmu_sec_misc_mask_set1_group_15_mp0_reg, rsmu_sec_tlvl_mask_set1_group_15) \
      rsmu_sec_misc_mask_set1_group_15_mp0_reg = (rsmu_sec_misc_mask_set1_group_15_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_15_MASK) | (rsmu_sec_tlvl_mask_set1_group_15 << RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_15_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_15(rsmu_sec_misc_mask_set1_group_15_mp0_reg, rsmu_sec_rw_mask_set1_group_15) \
      rsmu_sec_misc_mask_set1_group_15_mp0_reg = (rsmu_sec_misc_mask_set1_group_15_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_15_MASK) | (rsmu_sec_rw_mask_set1_group_15 << RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_15_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_15(rsmu_sec_misc_mask_set1_group_15_mp0_reg, rsmu_sec_vf_mask_set1_group_15) \
      rsmu_sec_misc_mask_set1_group_15_mp0_reg = (rsmu_sec_misc_mask_set1_group_15_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_15_MASK) | (rsmu_sec_vf_mask_set1_group_15 << RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_15_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_15_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_15 : RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_15_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_15 : RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_15_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_15 : RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_15_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_15_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_15_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_15 : RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_15_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_15 : RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_15_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_15 : RSMU_SEC_MISC_MASK_SET1_GROUP_15_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_15_SIZE;
      } rsmu_sec_misc_mask_set1_group_15_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_15_mp0_t f;
} rsmu_sec_misc_mask_set1_group_15_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_15_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_15_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_15_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_15_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_15_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_15_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_15_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_15_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_15_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_15_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_15_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_15_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_15_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_15_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_15_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_15_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_15(rsmu_sec_access_control_group_15_mp0) \
      ((rsmu_sec_access_control_group_15_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_15_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_15_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_15(rsmu_sec_access_control_group_15_mp0) \
      ((rsmu_sec_access_control_group_15_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_15_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_15_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_15(rsmu_sec_access_control_group_15_mp0) \
      ((rsmu_sec_access_control_group_15_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_15_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_15_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_15(rsmu_sec_access_control_group_15_mp0) \
      ((rsmu_sec_access_control_group_15_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_15_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_15_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_15(rsmu_sec_access_control_group_15_mp0_reg, rsmu_sec_check_enable_set0_group_15) \
      rsmu_sec_access_control_group_15_mp0_reg = (rsmu_sec_access_control_group_15_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_15_MASK) | (rsmu_sec_check_enable_set0_group_15 << RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_15_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_15(rsmu_sec_access_control_group_15_mp0_reg, rsmu_sec_check_enable_set1_group_15) \
      rsmu_sec_access_control_group_15_mp0_reg = (rsmu_sec_access_control_group_15_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_15_MASK) | (rsmu_sec_check_enable_set1_group_15 << RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_15_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_15(rsmu_sec_access_control_group_15_mp0_reg, rsmu_sec_vf_check_enable_set0_group_15) \
      rsmu_sec_access_control_group_15_mp0_reg = (rsmu_sec_access_control_group_15_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_15_MASK) | (rsmu_sec_vf_check_enable_set0_group_15 << RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_15_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_15(rsmu_sec_access_control_group_15_mp0_reg, rsmu_sec_vf_check_enable_set1_group_15) \
      rsmu_sec_access_control_group_15_mp0_reg = (rsmu_sec_access_control_group_15_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_15_MASK) | (rsmu_sec_vf_check_enable_set1_group_15 << RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_15_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_15_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_15 : RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_15_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_15 : RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_15_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_15 : RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_15_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_15 : RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_15_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_15_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_15_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_15 : RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_15_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_15 : RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_15_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_15 : RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_15_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_15 : RSMU_SEC_ACCESS_CONTROL_GROUP_15_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_15_SIZE;
      } rsmu_sec_access_control_group_15_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_15_mp0_t f;
} rsmu_sec_access_control_group_15_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_16_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_16_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_16_MP0_RSMU_SEC_START_ADDR_GROUP_16_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_16_MP0_RSMU_SEC_START_ADDR_GROUP_16_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_16_MP0_RSMU_SEC_START_ADDR_GROUP_16_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_16_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_16_MP0_RSMU_SEC_START_ADDR_GROUP_16_MASK)

#define RSMU_SEC_START_ADDR_GROUP_16_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_16_MP0_GET_RSMU_SEC_START_ADDR_GROUP_16(rsmu_sec_start_addr_group_16_mp0) \
      ((rsmu_sec_start_addr_group_16_mp0 & RSMU_SEC_START_ADDR_GROUP_16_MP0_RSMU_SEC_START_ADDR_GROUP_16_MASK) >> RSMU_SEC_START_ADDR_GROUP_16_MP0_RSMU_SEC_START_ADDR_GROUP_16_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_16_MP0_SET_RSMU_SEC_START_ADDR_GROUP_16(rsmu_sec_start_addr_group_16_mp0_reg, rsmu_sec_start_addr_group_16) \
      rsmu_sec_start_addr_group_16_mp0_reg = (rsmu_sec_start_addr_group_16_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_16_MP0_RSMU_SEC_START_ADDR_GROUP_16_MASK) | (rsmu_sec_start_addr_group_16 << RSMU_SEC_START_ADDR_GROUP_16_MP0_RSMU_SEC_START_ADDR_GROUP_16_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_16_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_16   : RSMU_SEC_START_ADDR_GROUP_16_MP0_RSMU_SEC_START_ADDR_GROUP_16_SIZE;
      } rsmu_sec_start_addr_group_16_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_16_mp0_t {
            unsigned int rsmu_sec_start_addr_group_16   : RSMU_SEC_START_ADDR_GROUP_16_MP0_RSMU_SEC_START_ADDR_GROUP_16_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_16_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_16_mp0_t f;
} rsmu_sec_start_addr_group_16_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_16_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_16_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_16_MP0_RSMU_SEC_END_ADDR_GROUP_16_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_16_MP0_RSMU_SEC_END_ADDR_GROUP_16_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_16_MP0_RSMU_SEC_END_ADDR_GROUP_16_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_16_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_16_MP0_RSMU_SEC_END_ADDR_GROUP_16_MASK)

#define RSMU_SEC_END_ADDR_GROUP_16_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_16_MP0_GET_RSMU_SEC_END_ADDR_GROUP_16(rsmu_sec_end_addr_group_16_mp0) \
      ((rsmu_sec_end_addr_group_16_mp0 & RSMU_SEC_END_ADDR_GROUP_16_MP0_RSMU_SEC_END_ADDR_GROUP_16_MASK) >> RSMU_SEC_END_ADDR_GROUP_16_MP0_RSMU_SEC_END_ADDR_GROUP_16_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_16_MP0_SET_RSMU_SEC_END_ADDR_GROUP_16(rsmu_sec_end_addr_group_16_mp0_reg, rsmu_sec_end_addr_group_16) \
      rsmu_sec_end_addr_group_16_mp0_reg = (rsmu_sec_end_addr_group_16_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_16_MP0_RSMU_SEC_END_ADDR_GROUP_16_MASK) | (rsmu_sec_end_addr_group_16 << RSMU_SEC_END_ADDR_GROUP_16_MP0_RSMU_SEC_END_ADDR_GROUP_16_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_16_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_16     : RSMU_SEC_END_ADDR_GROUP_16_MP0_RSMU_SEC_END_ADDR_GROUP_16_SIZE;
      } rsmu_sec_end_addr_group_16_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_16_mp0_t {
            unsigned int rsmu_sec_end_addr_group_16     : RSMU_SEC_END_ADDR_GROUP_16_MP0_RSMU_SEC_END_ADDR_GROUP_16_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_16_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_16_mp0_t f;
} rsmu_sec_end_addr_group_16_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_16_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_16_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_16_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_16_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_16_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_16_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_16_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_16_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_16_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_16_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_16_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_16_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_16_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_16(rsmu_sec_initid_mask_set0_group_16_mp0) \
      ((rsmu_sec_initid_mask_set0_group_16_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_16_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_16_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_16_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_16_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_16_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_16(rsmu_sec_initid_mask_set0_group_16_mp0_reg, rsmu_sec_initid_mask_set0_group_16) \
      rsmu_sec_initid_mask_set0_group_16_mp0_reg = (rsmu_sec_initid_mask_set0_group_16_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_16_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_16_MASK) | (rsmu_sec_initid_mask_set0_group_16 << RSMU_SEC_INITID_MASK_SET0_GROUP_16_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_16_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_16_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_16 : RSMU_SEC_INITID_MASK_SET0_GROUP_16_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_16_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_16_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_16_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_16 : RSMU_SEC_INITID_MASK_SET0_GROUP_16_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_16_SIZE;
      } rsmu_sec_initid_mask_set0_group_16_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_16_mp0_t f;
} rsmu_sec_initid_mask_set0_group_16_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_16_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_16_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_16_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_16_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_16_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_16_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_16_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_16_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_16_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_16_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_16_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_16_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_16_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_16(rsmu_sec_unitid_mask_set0_group_16_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_16_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_16_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_16_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_16_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_16_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_16_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_16(rsmu_sec_unitid_mask_set0_group_16_mp0_reg, rsmu_sec_unitid_mask_set0_group_16) \
      rsmu_sec_unitid_mask_set0_group_16_mp0_reg = (rsmu_sec_unitid_mask_set0_group_16_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_16_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_16_MASK) | (rsmu_sec_unitid_mask_set0_group_16 << RSMU_SEC_UNITID_MASK_SET0_GROUP_16_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_16_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_16_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_16 : RSMU_SEC_UNITID_MASK_SET0_GROUP_16_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_16_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_16_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_16_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_16 : RSMU_SEC_UNITID_MASK_SET0_GROUP_16_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_16_SIZE;
      } rsmu_sec_unitid_mask_set0_group_16_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_16_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_16_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_16_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_16_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_16_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_16_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_16_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_16_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_16_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_16_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_16_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_16_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_16_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_16_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_16(rsmu_sec_misc_mask_set0_group_16_mp0) \
      ((rsmu_sec_misc_mask_set0_group_16_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_16_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_16_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_16(rsmu_sec_misc_mask_set0_group_16_mp0) \
      ((rsmu_sec_misc_mask_set0_group_16_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_16_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_16_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_16(rsmu_sec_misc_mask_set0_group_16_mp0) \
      ((rsmu_sec_misc_mask_set0_group_16_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_16_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_16_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_16(rsmu_sec_misc_mask_set0_group_16_mp0_reg, rsmu_sec_tlvl_mask_set0_group_16) \
      rsmu_sec_misc_mask_set0_group_16_mp0_reg = (rsmu_sec_misc_mask_set0_group_16_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_16_MASK) | (rsmu_sec_tlvl_mask_set0_group_16 << RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_16_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_16(rsmu_sec_misc_mask_set0_group_16_mp0_reg, rsmu_sec_rw_mask_set0_group_16) \
      rsmu_sec_misc_mask_set0_group_16_mp0_reg = (rsmu_sec_misc_mask_set0_group_16_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_16_MASK) | (rsmu_sec_rw_mask_set0_group_16 << RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_16_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_16(rsmu_sec_misc_mask_set0_group_16_mp0_reg, rsmu_sec_vf_mask_set0_group_16) \
      rsmu_sec_misc_mask_set0_group_16_mp0_reg = (rsmu_sec_misc_mask_set0_group_16_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_16_MASK) | (rsmu_sec_vf_mask_set0_group_16 << RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_16_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_16_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_16 : RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_16_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_16 : RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_16_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_16 : RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_16_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_16_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_16_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_16 : RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_16_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_16 : RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_16_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_16 : RSMU_SEC_MISC_MASK_SET0_GROUP_16_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_16_SIZE;
      } rsmu_sec_misc_mask_set0_group_16_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_16_mp0_t f;
} rsmu_sec_misc_mask_set0_group_16_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_16_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_16_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_16_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_16_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_16_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_16_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_16_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_16_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_16_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_16_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_16_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_16_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_16_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_16(rsmu_sec_initid_mask_set1_group_16_mp0) \
      ((rsmu_sec_initid_mask_set1_group_16_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_16_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_16_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_16_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_16_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_16_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_16(rsmu_sec_initid_mask_set1_group_16_mp0_reg, rsmu_sec_initid_mask_set1_group_16) \
      rsmu_sec_initid_mask_set1_group_16_mp0_reg = (rsmu_sec_initid_mask_set1_group_16_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_16_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_16_MASK) | (rsmu_sec_initid_mask_set1_group_16 << RSMU_SEC_INITID_MASK_SET1_GROUP_16_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_16_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_16_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_16 : RSMU_SEC_INITID_MASK_SET1_GROUP_16_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_16_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_16_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_16_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_16 : RSMU_SEC_INITID_MASK_SET1_GROUP_16_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_16_SIZE;
      } rsmu_sec_initid_mask_set1_group_16_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_16_mp0_t f;
} rsmu_sec_initid_mask_set1_group_16_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_16_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_16_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_16_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_16_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_16_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_16_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_16_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_16_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_16_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_16_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_16_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_16_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_16_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_16(rsmu_sec_unitid_mask_set1_group_16_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_16_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_16_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_16_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_16_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_16_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_16_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_16(rsmu_sec_unitid_mask_set1_group_16_mp0_reg, rsmu_sec_unitid_mask_set1_group_16) \
      rsmu_sec_unitid_mask_set1_group_16_mp0_reg = (rsmu_sec_unitid_mask_set1_group_16_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_16_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_16_MASK) | (rsmu_sec_unitid_mask_set1_group_16 << RSMU_SEC_UNITID_MASK_SET1_GROUP_16_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_16_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_16_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_16 : RSMU_SEC_UNITID_MASK_SET1_GROUP_16_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_16_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_16_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_16_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_16 : RSMU_SEC_UNITID_MASK_SET1_GROUP_16_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_16_SIZE;
      } rsmu_sec_unitid_mask_set1_group_16_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_16_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_16_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_16_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_16_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_16_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_16_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_16_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_16_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_16_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_16_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_16_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_16_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_16_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_16_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_16(rsmu_sec_misc_mask_set1_group_16_mp0) \
      ((rsmu_sec_misc_mask_set1_group_16_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_16_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_16_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_16(rsmu_sec_misc_mask_set1_group_16_mp0) \
      ((rsmu_sec_misc_mask_set1_group_16_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_16_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_16_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_16(rsmu_sec_misc_mask_set1_group_16_mp0) \
      ((rsmu_sec_misc_mask_set1_group_16_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_16_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_16_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_16(rsmu_sec_misc_mask_set1_group_16_mp0_reg, rsmu_sec_tlvl_mask_set1_group_16) \
      rsmu_sec_misc_mask_set1_group_16_mp0_reg = (rsmu_sec_misc_mask_set1_group_16_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_16_MASK) | (rsmu_sec_tlvl_mask_set1_group_16 << RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_16_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_16(rsmu_sec_misc_mask_set1_group_16_mp0_reg, rsmu_sec_rw_mask_set1_group_16) \
      rsmu_sec_misc_mask_set1_group_16_mp0_reg = (rsmu_sec_misc_mask_set1_group_16_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_16_MASK) | (rsmu_sec_rw_mask_set1_group_16 << RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_16_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_16(rsmu_sec_misc_mask_set1_group_16_mp0_reg, rsmu_sec_vf_mask_set1_group_16) \
      rsmu_sec_misc_mask_set1_group_16_mp0_reg = (rsmu_sec_misc_mask_set1_group_16_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_16_MASK) | (rsmu_sec_vf_mask_set1_group_16 << RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_16_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_16_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_16 : RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_16_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_16 : RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_16_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_16 : RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_16_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_16_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_16_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_16 : RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_16_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_16 : RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_16_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_16 : RSMU_SEC_MISC_MASK_SET1_GROUP_16_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_16_SIZE;
      } rsmu_sec_misc_mask_set1_group_16_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_16_mp0_t f;
} rsmu_sec_misc_mask_set1_group_16_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_16_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_16_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_16_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_16_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_16_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_16_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_16_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_16_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_16_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_16_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_16_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_16_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_16_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_16_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_16_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_16_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_16(rsmu_sec_access_control_group_16_mp0) \
      ((rsmu_sec_access_control_group_16_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_16_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_16_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_16(rsmu_sec_access_control_group_16_mp0) \
      ((rsmu_sec_access_control_group_16_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_16_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_16_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_16(rsmu_sec_access_control_group_16_mp0) \
      ((rsmu_sec_access_control_group_16_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_16_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_16_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_16(rsmu_sec_access_control_group_16_mp0) \
      ((rsmu_sec_access_control_group_16_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_16_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_16_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_16(rsmu_sec_access_control_group_16_mp0_reg, rsmu_sec_check_enable_set0_group_16) \
      rsmu_sec_access_control_group_16_mp0_reg = (rsmu_sec_access_control_group_16_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_16_MASK) | (rsmu_sec_check_enable_set0_group_16 << RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_16_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_16(rsmu_sec_access_control_group_16_mp0_reg, rsmu_sec_check_enable_set1_group_16) \
      rsmu_sec_access_control_group_16_mp0_reg = (rsmu_sec_access_control_group_16_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_16_MASK) | (rsmu_sec_check_enable_set1_group_16 << RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_16_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_16(rsmu_sec_access_control_group_16_mp0_reg, rsmu_sec_vf_check_enable_set0_group_16) \
      rsmu_sec_access_control_group_16_mp0_reg = (rsmu_sec_access_control_group_16_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_16_MASK) | (rsmu_sec_vf_check_enable_set0_group_16 << RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_16_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_16(rsmu_sec_access_control_group_16_mp0_reg, rsmu_sec_vf_check_enable_set1_group_16) \
      rsmu_sec_access_control_group_16_mp0_reg = (rsmu_sec_access_control_group_16_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_16_MASK) | (rsmu_sec_vf_check_enable_set1_group_16 << RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_16_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_16_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_16 : RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_16_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_16 : RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_16_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_16 : RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_16_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_16 : RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_16_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_16_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_16_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_16 : RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_16_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_16 : RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_16_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_16 : RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_16_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_16 : RSMU_SEC_ACCESS_CONTROL_GROUP_16_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_16_SIZE;
      } rsmu_sec_access_control_group_16_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_16_mp0_t f;
} rsmu_sec_access_control_group_16_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_17_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_17_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_17_MP0_RSMU_SEC_START_ADDR_GROUP_17_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_17_MP0_RSMU_SEC_START_ADDR_GROUP_17_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_17_MP0_RSMU_SEC_START_ADDR_GROUP_17_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_17_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_17_MP0_RSMU_SEC_START_ADDR_GROUP_17_MASK)

#define RSMU_SEC_START_ADDR_GROUP_17_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_17_MP0_GET_RSMU_SEC_START_ADDR_GROUP_17(rsmu_sec_start_addr_group_17_mp0) \
      ((rsmu_sec_start_addr_group_17_mp0 & RSMU_SEC_START_ADDR_GROUP_17_MP0_RSMU_SEC_START_ADDR_GROUP_17_MASK) >> RSMU_SEC_START_ADDR_GROUP_17_MP0_RSMU_SEC_START_ADDR_GROUP_17_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_17_MP0_SET_RSMU_SEC_START_ADDR_GROUP_17(rsmu_sec_start_addr_group_17_mp0_reg, rsmu_sec_start_addr_group_17) \
      rsmu_sec_start_addr_group_17_mp0_reg = (rsmu_sec_start_addr_group_17_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_17_MP0_RSMU_SEC_START_ADDR_GROUP_17_MASK) | (rsmu_sec_start_addr_group_17 << RSMU_SEC_START_ADDR_GROUP_17_MP0_RSMU_SEC_START_ADDR_GROUP_17_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_17_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_17   : RSMU_SEC_START_ADDR_GROUP_17_MP0_RSMU_SEC_START_ADDR_GROUP_17_SIZE;
      } rsmu_sec_start_addr_group_17_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_17_mp0_t {
            unsigned int rsmu_sec_start_addr_group_17   : RSMU_SEC_START_ADDR_GROUP_17_MP0_RSMU_SEC_START_ADDR_GROUP_17_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_17_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_17_mp0_t f;
} rsmu_sec_start_addr_group_17_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_17_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_17_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_17_MP0_RSMU_SEC_END_ADDR_GROUP_17_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_17_MP0_RSMU_SEC_END_ADDR_GROUP_17_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_17_MP0_RSMU_SEC_END_ADDR_GROUP_17_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_17_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_17_MP0_RSMU_SEC_END_ADDR_GROUP_17_MASK)

#define RSMU_SEC_END_ADDR_GROUP_17_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_17_MP0_GET_RSMU_SEC_END_ADDR_GROUP_17(rsmu_sec_end_addr_group_17_mp0) \
      ((rsmu_sec_end_addr_group_17_mp0 & RSMU_SEC_END_ADDR_GROUP_17_MP0_RSMU_SEC_END_ADDR_GROUP_17_MASK) >> RSMU_SEC_END_ADDR_GROUP_17_MP0_RSMU_SEC_END_ADDR_GROUP_17_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_17_MP0_SET_RSMU_SEC_END_ADDR_GROUP_17(rsmu_sec_end_addr_group_17_mp0_reg, rsmu_sec_end_addr_group_17) \
      rsmu_sec_end_addr_group_17_mp0_reg = (rsmu_sec_end_addr_group_17_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_17_MP0_RSMU_SEC_END_ADDR_GROUP_17_MASK) | (rsmu_sec_end_addr_group_17 << RSMU_SEC_END_ADDR_GROUP_17_MP0_RSMU_SEC_END_ADDR_GROUP_17_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_17_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_17     : RSMU_SEC_END_ADDR_GROUP_17_MP0_RSMU_SEC_END_ADDR_GROUP_17_SIZE;
      } rsmu_sec_end_addr_group_17_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_17_mp0_t {
            unsigned int rsmu_sec_end_addr_group_17     : RSMU_SEC_END_ADDR_GROUP_17_MP0_RSMU_SEC_END_ADDR_GROUP_17_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_17_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_17_mp0_t f;
} rsmu_sec_end_addr_group_17_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_17_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_17_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_17_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_17_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_17_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_17_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_17_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_17_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_17_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_17_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_17_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_17_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_17_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_17(rsmu_sec_initid_mask_set0_group_17_mp0) \
      ((rsmu_sec_initid_mask_set0_group_17_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_17_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_17_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_17_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_17_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_17_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_17(rsmu_sec_initid_mask_set0_group_17_mp0_reg, rsmu_sec_initid_mask_set0_group_17) \
      rsmu_sec_initid_mask_set0_group_17_mp0_reg = (rsmu_sec_initid_mask_set0_group_17_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_17_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_17_MASK) | (rsmu_sec_initid_mask_set0_group_17 << RSMU_SEC_INITID_MASK_SET0_GROUP_17_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_17_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_17_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_17 : RSMU_SEC_INITID_MASK_SET0_GROUP_17_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_17_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_17_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_17_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_17 : RSMU_SEC_INITID_MASK_SET0_GROUP_17_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_17_SIZE;
      } rsmu_sec_initid_mask_set0_group_17_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_17_mp0_t f;
} rsmu_sec_initid_mask_set0_group_17_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_17_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_17_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_17_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_17_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_17_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_17_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_17_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_17_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_17_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_17_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_17_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_17_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_17_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_17(rsmu_sec_unitid_mask_set0_group_17_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_17_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_17_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_17_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_17_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_17_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_17_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_17(rsmu_sec_unitid_mask_set0_group_17_mp0_reg, rsmu_sec_unitid_mask_set0_group_17) \
      rsmu_sec_unitid_mask_set0_group_17_mp0_reg = (rsmu_sec_unitid_mask_set0_group_17_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_17_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_17_MASK) | (rsmu_sec_unitid_mask_set0_group_17 << RSMU_SEC_UNITID_MASK_SET0_GROUP_17_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_17_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_17_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_17 : RSMU_SEC_UNITID_MASK_SET0_GROUP_17_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_17_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_17_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_17_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_17 : RSMU_SEC_UNITID_MASK_SET0_GROUP_17_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_17_SIZE;
      } rsmu_sec_unitid_mask_set0_group_17_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_17_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_17_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_17_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_17_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_17_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_17_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_17_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_17_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_17_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_17_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_17_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_17_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_17_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_17_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_17(rsmu_sec_misc_mask_set0_group_17_mp0) \
      ((rsmu_sec_misc_mask_set0_group_17_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_17_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_17_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_17(rsmu_sec_misc_mask_set0_group_17_mp0) \
      ((rsmu_sec_misc_mask_set0_group_17_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_17_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_17_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_17(rsmu_sec_misc_mask_set0_group_17_mp0) \
      ((rsmu_sec_misc_mask_set0_group_17_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_17_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_17_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_17(rsmu_sec_misc_mask_set0_group_17_mp0_reg, rsmu_sec_tlvl_mask_set0_group_17) \
      rsmu_sec_misc_mask_set0_group_17_mp0_reg = (rsmu_sec_misc_mask_set0_group_17_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_17_MASK) | (rsmu_sec_tlvl_mask_set0_group_17 << RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_17_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_17(rsmu_sec_misc_mask_set0_group_17_mp0_reg, rsmu_sec_rw_mask_set0_group_17) \
      rsmu_sec_misc_mask_set0_group_17_mp0_reg = (rsmu_sec_misc_mask_set0_group_17_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_17_MASK) | (rsmu_sec_rw_mask_set0_group_17 << RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_17_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_17(rsmu_sec_misc_mask_set0_group_17_mp0_reg, rsmu_sec_vf_mask_set0_group_17) \
      rsmu_sec_misc_mask_set0_group_17_mp0_reg = (rsmu_sec_misc_mask_set0_group_17_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_17_MASK) | (rsmu_sec_vf_mask_set0_group_17 << RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_17_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_17_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_17 : RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_17_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_17 : RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_17_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_17 : RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_17_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_17_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_17_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_17 : RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_17_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_17 : RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_17_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_17 : RSMU_SEC_MISC_MASK_SET0_GROUP_17_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_17_SIZE;
      } rsmu_sec_misc_mask_set0_group_17_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_17_mp0_t f;
} rsmu_sec_misc_mask_set0_group_17_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_17_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_17_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_17_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_17_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_17_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_17_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_17_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_17_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_17_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_17_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_17_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_17_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_17_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_17(rsmu_sec_initid_mask_set1_group_17_mp0) \
      ((rsmu_sec_initid_mask_set1_group_17_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_17_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_17_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_17_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_17_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_17_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_17(rsmu_sec_initid_mask_set1_group_17_mp0_reg, rsmu_sec_initid_mask_set1_group_17) \
      rsmu_sec_initid_mask_set1_group_17_mp0_reg = (rsmu_sec_initid_mask_set1_group_17_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_17_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_17_MASK) | (rsmu_sec_initid_mask_set1_group_17 << RSMU_SEC_INITID_MASK_SET1_GROUP_17_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_17_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_17_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_17 : RSMU_SEC_INITID_MASK_SET1_GROUP_17_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_17_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_17_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_17_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_17 : RSMU_SEC_INITID_MASK_SET1_GROUP_17_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_17_SIZE;
      } rsmu_sec_initid_mask_set1_group_17_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_17_mp0_t f;
} rsmu_sec_initid_mask_set1_group_17_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_17_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_17_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_17_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_17_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_17_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_17_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_17_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_17_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_17_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_17_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_17_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_17_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_17_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_17(rsmu_sec_unitid_mask_set1_group_17_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_17_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_17_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_17_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_17_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_17_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_17_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_17(rsmu_sec_unitid_mask_set1_group_17_mp0_reg, rsmu_sec_unitid_mask_set1_group_17) \
      rsmu_sec_unitid_mask_set1_group_17_mp0_reg = (rsmu_sec_unitid_mask_set1_group_17_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_17_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_17_MASK) | (rsmu_sec_unitid_mask_set1_group_17 << RSMU_SEC_UNITID_MASK_SET1_GROUP_17_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_17_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_17_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_17 : RSMU_SEC_UNITID_MASK_SET1_GROUP_17_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_17_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_17_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_17_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_17 : RSMU_SEC_UNITID_MASK_SET1_GROUP_17_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_17_SIZE;
      } rsmu_sec_unitid_mask_set1_group_17_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_17_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_17_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_17_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_17_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_17_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_17_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_17_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_17_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_17_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_17_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_17_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_17_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_17_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_17_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_17(rsmu_sec_misc_mask_set1_group_17_mp0) \
      ((rsmu_sec_misc_mask_set1_group_17_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_17_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_17_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_17(rsmu_sec_misc_mask_set1_group_17_mp0) \
      ((rsmu_sec_misc_mask_set1_group_17_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_17_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_17_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_17(rsmu_sec_misc_mask_set1_group_17_mp0) \
      ((rsmu_sec_misc_mask_set1_group_17_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_17_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_17_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_17(rsmu_sec_misc_mask_set1_group_17_mp0_reg, rsmu_sec_tlvl_mask_set1_group_17) \
      rsmu_sec_misc_mask_set1_group_17_mp0_reg = (rsmu_sec_misc_mask_set1_group_17_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_17_MASK) | (rsmu_sec_tlvl_mask_set1_group_17 << RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_17_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_17(rsmu_sec_misc_mask_set1_group_17_mp0_reg, rsmu_sec_rw_mask_set1_group_17) \
      rsmu_sec_misc_mask_set1_group_17_mp0_reg = (rsmu_sec_misc_mask_set1_group_17_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_17_MASK) | (rsmu_sec_rw_mask_set1_group_17 << RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_17_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_17(rsmu_sec_misc_mask_set1_group_17_mp0_reg, rsmu_sec_vf_mask_set1_group_17) \
      rsmu_sec_misc_mask_set1_group_17_mp0_reg = (rsmu_sec_misc_mask_set1_group_17_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_17_MASK) | (rsmu_sec_vf_mask_set1_group_17 << RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_17_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_17_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_17 : RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_17_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_17 : RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_17_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_17 : RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_17_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_17_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_17_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_17 : RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_17_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_17 : RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_17_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_17 : RSMU_SEC_MISC_MASK_SET1_GROUP_17_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_17_SIZE;
      } rsmu_sec_misc_mask_set1_group_17_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_17_mp0_t f;
} rsmu_sec_misc_mask_set1_group_17_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_17_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_17_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_17_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_17_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_17_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_17_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_17_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_17_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_17_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_17_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_17_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_17_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_17_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_17_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_17_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_17_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_17(rsmu_sec_access_control_group_17_mp0) \
      ((rsmu_sec_access_control_group_17_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_17_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_17_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_17(rsmu_sec_access_control_group_17_mp0) \
      ((rsmu_sec_access_control_group_17_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_17_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_17_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_17(rsmu_sec_access_control_group_17_mp0) \
      ((rsmu_sec_access_control_group_17_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_17_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_17_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_17(rsmu_sec_access_control_group_17_mp0) \
      ((rsmu_sec_access_control_group_17_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_17_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_17_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_17(rsmu_sec_access_control_group_17_mp0_reg, rsmu_sec_check_enable_set0_group_17) \
      rsmu_sec_access_control_group_17_mp0_reg = (rsmu_sec_access_control_group_17_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_17_MASK) | (rsmu_sec_check_enable_set0_group_17 << RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_17_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_17(rsmu_sec_access_control_group_17_mp0_reg, rsmu_sec_check_enable_set1_group_17) \
      rsmu_sec_access_control_group_17_mp0_reg = (rsmu_sec_access_control_group_17_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_17_MASK) | (rsmu_sec_check_enable_set1_group_17 << RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_17_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_17(rsmu_sec_access_control_group_17_mp0_reg, rsmu_sec_vf_check_enable_set0_group_17) \
      rsmu_sec_access_control_group_17_mp0_reg = (rsmu_sec_access_control_group_17_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_17_MASK) | (rsmu_sec_vf_check_enable_set0_group_17 << RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_17_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_17(rsmu_sec_access_control_group_17_mp0_reg, rsmu_sec_vf_check_enable_set1_group_17) \
      rsmu_sec_access_control_group_17_mp0_reg = (rsmu_sec_access_control_group_17_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_17_MASK) | (rsmu_sec_vf_check_enable_set1_group_17 << RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_17_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_17_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_17 : RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_17_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_17 : RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_17_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_17 : RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_17_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_17 : RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_17_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_17_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_17_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_17 : RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_17_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_17 : RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_17_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_17 : RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_17_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_17 : RSMU_SEC_ACCESS_CONTROL_GROUP_17_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_17_SIZE;
      } rsmu_sec_access_control_group_17_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_17_mp0_t f;
} rsmu_sec_access_control_group_17_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_18_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_18_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_18_MP0_RSMU_SEC_START_ADDR_GROUP_18_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_18_MP0_RSMU_SEC_START_ADDR_GROUP_18_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_18_MP0_RSMU_SEC_START_ADDR_GROUP_18_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_18_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_18_MP0_RSMU_SEC_START_ADDR_GROUP_18_MASK)

#define RSMU_SEC_START_ADDR_GROUP_18_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_18_MP0_GET_RSMU_SEC_START_ADDR_GROUP_18(rsmu_sec_start_addr_group_18_mp0) \
      ((rsmu_sec_start_addr_group_18_mp0 & RSMU_SEC_START_ADDR_GROUP_18_MP0_RSMU_SEC_START_ADDR_GROUP_18_MASK) >> RSMU_SEC_START_ADDR_GROUP_18_MP0_RSMU_SEC_START_ADDR_GROUP_18_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_18_MP0_SET_RSMU_SEC_START_ADDR_GROUP_18(rsmu_sec_start_addr_group_18_mp0_reg, rsmu_sec_start_addr_group_18) \
      rsmu_sec_start_addr_group_18_mp0_reg = (rsmu_sec_start_addr_group_18_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_18_MP0_RSMU_SEC_START_ADDR_GROUP_18_MASK) | (rsmu_sec_start_addr_group_18 << RSMU_SEC_START_ADDR_GROUP_18_MP0_RSMU_SEC_START_ADDR_GROUP_18_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_18_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_18   : RSMU_SEC_START_ADDR_GROUP_18_MP0_RSMU_SEC_START_ADDR_GROUP_18_SIZE;
      } rsmu_sec_start_addr_group_18_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_18_mp0_t {
            unsigned int rsmu_sec_start_addr_group_18   : RSMU_SEC_START_ADDR_GROUP_18_MP0_RSMU_SEC_START_ADDR_GROUP_18_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_18_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_18_mp0_t f;
} rsmu_sec_start_addr_group_18_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_18_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_18_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_18_MP0_RSMU_SEC_END_ADDR_GROUP_18_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_18_MP0_RSMU_SEC_END_ADDR_GROUP_18_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_18_MP0_RSMU_SEC_END_ADDR_GROUP_18_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_18_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_18_MP0_RSMU_SEC_END_ADDR_GROUP_18_MASK)

#define RSMU_SEC_END_ADDR_GROUP_18_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_18_MP0_GET_RSMU_SEC_END_ADDR_GROUP_18(rsmu_sec_end_addr_group_18_mp0) \
      ((rsmu_sec_end_addr_group_18_mp0 & RSMU_SEC_END_ADDR_GROUP_18_MP0_RSMU_SEC_END_ADDR_GROUP_18_MASK) >> RSMU_SEC_END_ADDR_GROUP_18_MP0_RSMU_SEC_END_ADDR_GROUP_18_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_18_MP0_SET_RSMU_SEC_END_ADDR_GROUP_18(rsmu_sec_end_addr_group_18_mp0_reg, rsmu_sec_end_addr_group_18) \
      rsmu_sec_end_addr_group_18_mp0_reg = (rsmu_sec_end_addr_group_18_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_18_MP0_RSMU_SEC_END_ADDR_GROUP_18_MASK) | (rsmu_sec_end_addr_group_18 << RSMU_SEC_END_ADDR_GROUP_18_MP0_RSMU_SEC_END_ADDR_GROUP_18_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_18_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_18     : RSMU_SEC_END_ADDR_GROUP_18_MP0_RSMU_SEC_END_ADDR_GROUP_18_SIZE;
      } rsmu_sec_end_addr_group_18_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_18_mp0_t {
            unsigned int rsmu_sec_end_addr_group_18     : RSMU_SEC_END_ADDR_GROUP_18_MP0_RSMU_SEC_END_ADDR_GROUP_18_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_18_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_18_mp0_t f;
} rsmu_sec_end_addr_group_18_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_18_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_18_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_18_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_18_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_18_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_18_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_18_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_18_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_18_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_18_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_18_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_18_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_18_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_18(rsmu_sec_initid_mask_set0_group_18_mp0) \
      ((rsmu_sec_initid_mask_set0_group_18_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_18_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_18_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_18_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_18_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_18_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_18(rsmu_sec_initid_mask_set0_group_18_mp0_reg, rsmu_sec_initid_mask_set0_group_18) \
      rsmu_sec_initid_mask_set0_group_18_mp0_reg = (rsmu_sec_initid_mask_set0_group_18_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_18_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_18_MASK) | (rsmu_sec_initid_mask_set0_group_18 << RSMU_SEC_INITID_MASK_SET0_GROUP_18_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_18_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_18_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_18 : RSMU_SEC_INITID_MASK_SET0_GROUP_18_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_18_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_18_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_18_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_18 : RSMU_SEC_INITID_MASK_SET0_GROUP_18_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_18_SIZE;
      } rsmu_sec_initid_mask_set0_group_18_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_18_mp0_t f;
} rsmu_sec_initid_mask_set0_group_18_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_18_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_18_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_18_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_18_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_18_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_18_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_18_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_18_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_18_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_18_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_18_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_18_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_18_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_18(rsmu_sec_unitid_mask_set0_group_18_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_18_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_18_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_18_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_18_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_18_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_18_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_18(rsmu_sec_unitid_mask_set0_group_18_mp0_reg, rsmu_sec_unitid_mask_set0_group_18) \
      rsmu_sec_unitid_mask_set0_group_18_mp0_reg = (rsmu_sec_unitid_mask_set0_group_18_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_18_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_18_MASK) | (rsmu_sec_unitid_mask_set0_group_18 << RSMU_SEC_UNITID_MASK_SET0_GROUP_18_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_18_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_18_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_18 : RSMU_SEC_UNITID_MASK_SET0_GROUP_18_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_18_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_18_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_18_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_18 : RSMU_SEC_UNITID_MASK_SET0_GROUP_18_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_18_SIZE;
      } rsmu_sec_unitid_mask_set0_group_18_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_18_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_18_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_18_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_18_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_18_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_18_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_18_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_18_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_18_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_18_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_18_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_18_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_18_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_18_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_18(rsmu_sec_misc_mask_set0_group_18_mp0) \
      ((rsmu_sec_misc_mask_set0_group_18_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_18_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_18_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_18(rsmu_sec_misc_mask_set0_group_18_mp0) \
      ((rsmu_sec_misc_mask_set0_group_18_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_18_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_18_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_18(rsmu_sec_misc_mask_set0_group_18_mp0) \
      ((rsmu_sec_misc_mask_set0_group_18_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_18_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_18_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_18(rsmu_sec_misc_mask_set0_group_18_mp0_reg, rsmu_sec_tlvl_mask_set0_group_18) \
      rsmu_sec_misc_mask_set0_group_18_mp0_reg = (rsmu_sec_misc_mask_set0_group_18_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_18_MASK) | (rsmu_sec_tlvl_mask_set0_group_18 << RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_18_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_18(rsmu_sec_misc_mask_set0_group_18_mp0_reg, rsmu_sec_rw_mask_set0_group_18) \
      rsmu_sec_misc_mask_set0_group_18_mp0_reg = (rsmu_sec_misc_mask_set0_group_18_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_18_MASK) | (rsmu_sec_rw_mask_set0_group_18 << RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_18_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_18(rsmu_sec_misc_mask_set0_group_18_mp0_reg, rsmu_sec_vf_mask_set0_group_18) \
      rsmu_sec_misc_mask_set0_group_18_mp0_reg = (rsmu_sec_misc_mask_set0_group_18_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_18_MASK) | (rsmu_sec_vf_mask_set0_group_18 << RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_18_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_18_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_18 : RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_18_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_18 : RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_18_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_18 : RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_18_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_18_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_18_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_18 : RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_18_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_18 : RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_18_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_18 : RSMU_SEC_MISC_MASK_SET0_GROUP_18_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_18_SIZE;
      } rsmu_sec_misc_mask_set0_group_18_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_18_mp0_t f;
} rsmu_sec_misc_mask_set0_group_18_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_18_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_18_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_18_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_18_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_18_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_18_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_18_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_18_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_18_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_18_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_18_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_18_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_18_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_18(rsmu_sec_initid_mask_set1_group_18_mp0) \
      ((rsmu_sec_initid_mask_set1_group_18_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_18_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_18_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_18_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_18_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_18_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_18(rsmu_sec_initid_mask_set1_group_18_mp0_reg, rsmu_sec_initid_mask_set1_group_18) \
      rsmu_sec_initid_mask_set1_group_18_mp0_reg = (rsmu_sec_initid_mask_set1_group_18_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_18_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_18_MASK) | (rsmu_sec_initid_mask_set1_group_18 << RSMU_SEC_INITID_MASK_SET1_GROUP_18_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_18_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_18_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_18 : RSMU_SEC_INITID_MASK_SET1_GROUP_18_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_18_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_18_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_18_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_18 : RSMU_SEC_INITID_MASK_SET1_GROUP_18_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_18_SIZE;
      } rsmu_sec_initid_mask_set1_group_18_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_18_mp0_t f;
} rsmu_sec_initid_mask_set1_group_18_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_18_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_18_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_18_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_18_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_18_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_18_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_18_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_18_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_18_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_18_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_18_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_18_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_18_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_18(rsmu_sec_unitid_mask_set1_group_18_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_18_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_18_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_18_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_18_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_18_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_18_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_18(rsmu_sec_unitid_mask_set1_group_18_mp0_reg, rsmu_sec_unitid_mask_set1_group_18) \
      rsmu_sec_unitid_mask_set1_group_18_mp0_reg = (rsmu_sec_unitid_mask_set1_group_18_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_18_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_18_MASK) | (rsmu_sec_unitid_mask_set1_group_18 << RSMU_SEC_UNITID_MASK_SET1_GROUP_18_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_18_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_18_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_18 : RSMU_SEC_UNITID_MASK_SET1_GROUP_18_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_18_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_18_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_18_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_18 : RSMU_SEC_UNITID_MASK_SET1_GROUP_18_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_18_SIZE;
      } rsmu_sec_unitid_mask_set1_group_18_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_18_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_18_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_18_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_18_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_18_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_18_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_18_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_18_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_18_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_18_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_18_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_18_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_18_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_18_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_18(rsmu_sec_misc_mask_set1_group_18_mp0) \
      ((rsmu_sec_misc_mask_set1_group_18_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_18_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_18_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_18(rsmu_sec_misc_mask_set1_group_18_mp0) \
      ((rsmu_sec_misc_mask_set1_group_18_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_18_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_18_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_18(rsmu_sec_misc_mask_set1_group_18_mp0) \
      ((rsmu_sec_misc_mask_set1_group_18_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_18_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_18_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_18(rsmu_sec_misc_mask_set1_group_18_mp0_reg, rsmu_sec_tlvl_mask_set1_group_18) \
      rsmu_sec_misc_mask_set1_group_18_mp0_reg = (rsmu_sec_misc_mask_set1_group_18_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_18_MASK) | (rsmu_sec_tlvl_mask_set1_group_18 << RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_18_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_18(rsmu_sec_misc_mask_set1_group_18_mp0_reg, rsmu_sec_rw_mask_set1_group_18) \
      rsmu_sec_misc_mask_set1_group_18_mp0_reg = (rsmu_sec_misc_mask_set1_group_18_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_18_MASK) | (rsmu_sec_rw_mask_set1_group_18 << RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_18_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_18(rsmu_sec_misc_mask_set1_group_18_mp0_reg, rsmu_sec_vf_mask_set1_group_18) \
      rsmu_sec_misc_mask_set1_group_18_mp0_reg = (rsmu_sec_misc_mask_set1_group_18_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_18_MASK) | (rsmu_sec_vf_mask_set1_group_18 << RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_18_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_18_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_18 : RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_18_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_18 : RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_18_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_18 : RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_18_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_18_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_18_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_18 : RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_18_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_18 : RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_18_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_18 : RSMU_SEC_MISC_MASK_SET1_GROUP_18_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_18_SIZE;
      } rsmu_sec_misc_mask_set1_group_18_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_18_mp0_t f;
} rsmu_sec_misc_mask_set1_group_18_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_18_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_18_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_18_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_18_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_18_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_18_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_18_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_18_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_18_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_18_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_18_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_18_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_18_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_18_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_18_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_18_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_18(rsmu_sec_access_control_group_18_mp0) \
      ((rsmu_sec_access_control_group_18_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_18_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_18_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_18(rsmu_sec_access_control_group_18_mp0) \
      ((rsmu_sec_access_control_group_18_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_18_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_18_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_18(rsmu_sec_access_control_group_18_mp0) \
      ((rsmu_sec_access_control_group_18_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_18_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_18_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_18(rsmu_sec_access_control_group_18_mp0) \
      ((rsmu_sec_access_control_group_18_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_18_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_18_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_18(rsmu_sec_access_control_group_18_mp0_reg, rsmu_sec_check_enable_set0_group_18) \
      rsmu_sec_access_control_group_18_mp0_reg = (rsmu_sec_access_control_group_18_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_18_MASK) | (rsmu_sec_check_enable_set0_group_18 << RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_18_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_18(rsmu_sec_access_control_group_18_mp0_reg, rsmu_sec_check_enable_set1_group_18) \
      rsmu_sec_access_control_group_18_mp0_reg = (rsmu_sec_access_control_group_18_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_18_MASK) | (rsmu_sec_check_enable_set1_group_18 << RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_18_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_18(rsmu_sec_access_control_group_18_mp0_reg, rsmu_sec_vf_check_enable_set0_group_18) \
      rsmu_sec_access_control_group_18_mp0_reg = (rsmu_sec_access_control_group_18_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_18_MASK) | (rsmu_sec_vf_check_enable_set0_group_18 << RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_18_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_18(rsmu_sec_access_control_group_18_mp0_reg, rsmu_sec_vf_check_enable_set1_group_18) \
      rsmu_sec_access_control_group_18_mp0_reg = (rsmu_sec_access_control_group_18_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_18_MASK) | (rsmu_sec_vf_check_enable_set1_group_18 << RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_18_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_18_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_18 : RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_18_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_18 : RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_18_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_18 : RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_18_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_18 : RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_18_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_18_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_18_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_18 : RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_18_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_18 : RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_18_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_18 : RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_18_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_18 : RSMU_SEC_ACCESS_CONTROL_GROUP_18_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_18_SIZE;
      } rsmu_sec_access_control_group_18_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_18_mp0_t f;
} rsmu_sec_access_control_group_18_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_19_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_19_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_19_MP0_RSMU_SEC_START_ADDR_GROUP_19_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_19_MP0_RSMU_SEC_START_ADDR_GROUP_19_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_19_MP0_RSMU_SEC_START_ADDR_GROUP_19_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_19_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_19_MP0_RSMU_SEC_START_ADDR_GROUP_19_MASK)

#define RSMU_SEC_START_ADDR_GROUP_19_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_19_MP0_GET_RSMU_SEC_START_ADDR_GROUP_19(rsmu_sec_start_addr_group_19_mp0) \
      ((rsmu_sec_start_addr_group_19_mp0 & RSMU_SEC_START_ADDR_GROUP_19_MP0_RSMU_SEC_START_ADDR_GROUP_19_MASK) >> RSMU_SEC_START_ADDR_GROUP_19_MP0_RSMU_SEC_START_ADDR_GROUP_19_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_19_MP0_SET_RSMU_SEC_START_ADDR_GROUP_19(rsmu_sec_start_addr_group_19_mp0_reg, rsmu_sec_start_addr_group_19) \
      rsmu_sec_start_addr_group_19_mp0_reg = (rsmu_sec_start_addr_group_19_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_19_MP0_RSMU_SEC_START_ADDR_GROUP_19_MASK) | (rsmu_sec_start_addr_group_19 << RSMU_SEC_START_ADDR_GROUP_19_MP0_RSMU_SEC_START_ADDR_GROUP_19_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_19_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_19   : RSMU_SEC_START_ADDR_GROUP_19_MP0_RSMU_SEC_START_ADDR_GROUP_19_SIZE;
      } rsmu_sec_start_addr_group_19_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_19_mp0_t {
            unsigned int rsmu_sec_start_addr_group_19   : RSMU_SEC_START_ADDR_GROUP_19_MP0_RSMU_SEC_START_ADDR_GROUP_19_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_19_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_19_mp0_t f;
} rsmu_sec_start_addr_group_19_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_19_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_19_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_19_MP0_RSMU_SEC_END_ADDR_GROUP_19_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_19_MP0_RSMU_SEC_END_ADDR_GROUP_19_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_19_MP0_RSMU_SEC_END_ADDR_GROUP_19_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_19_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_19_MP0_RSMU_SEC_END_ADDR_GROUP_19_MASK)

#define RSMU_SEC_END_ADDR_GROUP_19_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_19_MP0_GET_RSMU_SEC_END_ADDR_GROUP_19(rsmu_sec_end_addr_group_19_mp0) \
      ((rsmu_sec_end_addr_group_19_mp0 & RSMU_SEC_END_ADDR_GROUP_19_MP0_RSMU_SEC_END_ADDR_GROUP_19_MASK) >> RSMU_SEC_END_ADDR_GROUP_19_MP0_RSMU_SEC_END_ADDR_GROUP_19_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_19_MP0_SET_RSMU_SEC_END_ADDR_GROUP_19(rsmu_sec_end_addr_group_19_mp0_reg, rsmu_sec_end_addr_group_19) \
      rsmu_sec_end_addr_group_19_mp0_reg = (rsmu_sec_end_addr_group_19_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_19_MP0_RSMU_SEC_END_ADDR_GROUP_19_MASK) | (rsmu_sec_end_addr_group_19 << RSMU_SEC_END_ADDR_GROUP_19_MP0_RSMU_SEC_END_ADDR_GROUP_19_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_19_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_19     : RSMU_SEC_END_ADDR_GROUP_19_MP0_RSMU_SEC_END_ADDR_GROUP_19_SIZE;
      } rsmu_sec_end_addr_group_19_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_19_mp0_t {
            unsigned int rsmu_sec_end_addr_group_19     : RSMU_SEC_END_ADDR_GROUP_19_MP0_RSMU_SEC_END_ADDR_GROUP_19_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_19_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_19_mp0_t f;
} rsmu_sec_end_addr_group_19_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_19_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_19_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_19_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_19_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_19_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_19_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_19_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_19_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_19_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_19_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_19_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_19_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_19_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_19(rsmu_sec_initid_mask_set0_group_19_mp0) \
      ((rsmu_sec_initid_mask_set0_group_19_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_19_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_19_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_19_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_19_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_19_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_19(rsmu_sec_initid_mask_set0_group_19_mp0_reg, rsmu_sec_initid_mask_set0_group_19) \
      rsmu_sec_initid_mask_set0_group_19_mp0_reg = (rsmu_sec_initid_mask_set0_group_19_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_19_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_19_MASK) | (rsmu_sec_initid_mask_set0_group_19 << RSMU_SEC_INITID_MASK_SET0_GROUP_19_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_19_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_19_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_19 : RSMU_SEC_INITID_MASK_SET0_GROUP_19_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_19_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_19_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_19_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_19 : RSMU_SEC_INITID_MASK_SET0_GROUP_19_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_19_SIZE;
      } rsmu_sec_initid_mask_set0_group_19_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_19_mp0_t f;
} rsmu_sec_initid_mask_set0_group_19_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_19_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_19_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_19_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_19_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_19_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_19_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_19_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_19_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_19_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_19_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_19_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_19_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_19_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_19(rsmu_sec_unitid_mask_set0_group_19_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_19_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_19_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_19_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_19_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_19_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_19_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_19(rsmu_sec_unitid_mask_set0_group_19_mp0_reg, rsmu_sec_unitid_mask_set0_group_19) \
      rsmu_sec_unitid_mask_set0_group_19_mp0_reg = (rsmu_sec_unitid_mask_set0_group_19_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_19_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_19_MASK) | (rsmu_sec_unitid_mask_set0_group_19 << RSMU_SEC_UNITID_MASK_SET0_GROUP_19_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_19_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_19_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_19 : RSMU_SEC_UNITID_MASK_SET0_GROUP_19_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_19_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_19_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_19_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_19 : RSMU_SEC_UNITID_MASK_SET0_GROUP_19_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_19_SIZE;
      } rsmu_sec_unitid_mask_set0_group_19_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_19_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_19_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_19_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_19_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_19_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_19_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_19_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_19_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_19_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_19_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_19_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_19_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_19_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_19_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_19(rsmu_sec_misc_mask_set0_group_19_mp0) \
      ((rsmu_sec_misc_mask_set0_group_19_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_19_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_19_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_19(rsmu_sec_misc_mask_set0_group_19_mp0) \
      ((rsmu_sec_misc_mask_set0_group_19_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_19_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_19_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_19(rsmu_sec_misc_mask_set0_group_19_mp0) \
      ((rsmu_sec_misc_mask_set0_group_19_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_19_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_19_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_19(rsmu_sec_misc_mask_set0_group_19_mp0_reg, rsmu_sec_tlvl_mask_set0_group_19) \
      rsmu_sec_misc_mask_set0_group_19_mp0_reg = (rsmu_sec_misc_mask_set0_group_19_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_19_MASK) | (rsmu_sec_tlvl_mask_set0_group_19 << RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_19_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_19(rsmu_sec_misc_mask_set0_group_19_mp0_reg, rsmu_sec_rw_mask_set0_group_19) \
      rsmu_sec_misc_mask_set0_group_19_mp0_reg = (rsmu_sec_misc_mask_set0_group_19_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_19_MASK) | (rsmu_sec_rw_mask_set0_group_19 << RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_19_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_19(rsmu_sec_misc_mask_set0_group_19_mp0_reg, rsmu_sec_vf_mask_set0_group_19) \
      rsmu_sec_misc_mask_set0_group_19_mp0_reg = (rsmu_sec_misc_mask_set0_group_19_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_19_MASK) | (rsmu_sec_vf_mask_set0_group_19 << RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_19_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_19_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_19 : RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_19_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_19 : RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_19_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_19 : RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_19_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_19_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_19_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_19 : RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_19_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_19 : RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_19_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_19 : RSMU_SEC_MISC_MASK_SET0_GROUP_19_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_19_SIZE;
      } rsmu_sec_misc_mask_set0_group_19_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_19_mp0_t f;
} rsmu_sec_misc_mask_set0_group_19_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_19_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_19_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_19_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_19_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_19_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_19_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_19_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_19_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_19_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_19_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_19_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_19_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_19_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_19(rsmu_sec_initid_mask_set1_group_19_mp0) \
      ((rsmu_sec_initid_mask_set1_group_19_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_19_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_19_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_19_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_19_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_19_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_19(rsmu_sec_initid_mask_set1_group_19_mp0_reg, rsmu_sec_initid_mask_set1_group_19) \
      rsmu_sec_initid_mask_set1_group_19_mp0_reg = (rsmu_sec_initid_mask_set1_group_19_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_19_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_19_MASK) | (rsmu_sec_initid_mask_set1_group_19 << RSMU_SEC_INITID_MASK_SET1_GROUP_19_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_19_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_19_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_19 : RSMU_SEC_INITID_MASK_SET1_GROUP_19_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_19_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_19_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_19_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_19 : RSMU_SEC_INITID_MASK_SET1_GROUP_19_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_19_SIZE;
      } rsmu_sec_initid_mask_set1_group_19_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_19_mp0_t f;
} rsmu_sec_initid_mask_set1_group_19_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_19_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_19_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_19_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_19_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_19_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_19_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_19_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_19_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_19_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_19_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_19_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_19_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_19_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_19(rsmu_sec_unitid_mask_set1_group_19_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_19_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_19_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_19_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_19_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_19_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_19_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_19(rsmu_sec_unitid_mask_set1_group_19_mp0_reg, rsmu_sec_unitid_mask_set1_group_19) \
      rsmu_sec_unitid_mask_set1_group_19_mp0_reg = (rsmu_sec_unitid_mask_set1_group_19_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_19_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_19_MASK) | (rsmu_sec_unitid_mask_set1_group_19 << RSMU_SEC_UNITID_MASK_SET1_GROUP_19_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_19_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_19_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_19 : RSMU_SEC_UNITID_MASK_SET1_GROUP_19_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_19_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_19_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_19_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_19 : RSMU_SEC_UNITID_MASK_SET1_GROUP_19_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_19_SIZE;
      } rsmu_sec_unitid_mask_set1_group_19_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_19_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_19_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_19_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_19_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_19_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_19_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_19_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_19_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_19_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_19_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_19_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_19_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_19_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_19_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_19(rsmu_sec_misc_mask_set1_group_19_mp0) \
      ((rsmu_sec_misc_mask_set1_group_19_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_19_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_19_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_19(rsmu_sec_misc_mask_set1_group_19_mp0) \
      ((rsmu_sec_misc_mask_set1_group_19_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_19_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_19_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_19(rsmu_sec_misc_mask_set1_group_19_mp0) \
      ((rsmu_sec_misc_mask_set1_group_19_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_19_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_19_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_19(rsmu_sec_misc_mask_set1_group_19_mp0_reg, rsmu_sec_tlvl_mask_set1_group_19) \
      rsmu_sec_misc_mask_set1_group_19_mp0_reg = (rsmu_sec_misc_mask_set1_group_19_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_19_MASK) | (rsmu_sec_tlvl_mask_set1_group_19 << RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_19_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_19(rsmu_sec_misc_mask_set1_group_19_mp0_reg, rsmu_sec_rw_mask_set1_group_19) \
      rsmu_sec_misc_mask_set1_group_19_mp0_reg = (rsmu_sec_misc_mask_set1_group_19_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_19_MASK) | (rsmu_sec_rw_mask_set1_group_19 << RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_19_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_19(rsmu_sec_misc_mask_set1_group_19_mp0_reg, rsmu_sec_vf_mask_set1_group_19) \
      rsmu_sec_misc_mask_set1_group_19_mp0_reg = (rsmu_sec_misc_mask_set1_group_19_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_19_MASK) | (rsmu_sec_vf_mask_set1_group_19 << RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_19_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_19_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_19 : RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_19_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_19 : RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_19_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_19 : RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_19_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_19_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_19_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_19 : RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_19_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_19 : RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_19_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_19 : RSMU_SEC_MISC_MASK_SET1_GROUP_19_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_19_SIZE;
      } rsmu_sec_misc_mask_set1_group_19_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_19_mp0_t f;
} rsmu_sec_misc_mask_set1_group_19_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_19_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_19_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_19_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_19_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_19_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_19_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_19_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_19_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_19_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_19_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_19_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_19_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_19_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_19_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_19_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_19_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_19(rsmu_sec_access_control_group_19_mp0) \
      ((rsmu_sec_access_control_group_19_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_19_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_19_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_19(rsmu_sec_access_control_group_19_mp0) \
      ((rsmu_sec_access_control_group_19_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_19_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_19_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_19(rsmu_sec_access_control_group_19_mp0) \
      ((rsmu_sec_access_control_group_19_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_19_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_19_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_19(rsmu_sec_access_control_group_19_mp0) \
      ((rsmu_sec_access_control_group_19_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_19_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_19_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_19(rsmu_sec_access_control_group_19_mp0_reg, rsmu_sec_check_enable_set0_group_19) \
      rsmu_sec_access_control_group_19_mp0_reg = (rsmu_sec_access_control_group_19_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_19_MASK) | (rsmu_sec_check_enable_set0_group_19 << RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_19_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_19(rsmu_sec_access_control_group_19_mp0_reg, rsmu_sec_check_enable_set1_group_19) \
      rsmu_sec_access_control_group_19_mp0_reg = (rsmu_sec_access_control_group_19_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_19_MASK) | (rsmu_sec_check_enable_set1_group_19 << RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_19_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_19(rsmu_sec_access_control_group_19_mp0_reg, rsmu_sec_vf_check_enable_set0_group_19) \
      rsmu_sec_access_control_group_19_mp0_reg = (rsmu_sec_access_control_group_19_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_19_MASK) | (rsmu_sec_vf_check_enable_set0_group_19 << RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_19_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_19(rsmu_sec_access_control_group_19_mp0_reg, rsmu_sec_vf_check_enable_set1_group_19) \
      rsmu_sec_access_control_group_19_mp0_reg = (rsmu_sec_access_control_group_19_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_19_MASK) | (rsmu_sec_vf_check_enable_set1_group_19 << RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_19_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_19_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_19 : RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_19_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_19 : RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_19_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_19 : RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_19_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_19 : RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_19_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_19_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_19_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_19 : RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_19_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_19 : RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_19_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_19 : RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_19_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_19 : RSMU_SEC_ACCESS_CONTROL_GROUP_19_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_19_SIZE;
      } rsmu_sec_access_control_group_19_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_19_mp0_t f;
} rsmu_sec_access_control_group_19_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_20_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_20_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_20_MP0_RSMU_SEC_START_ADDR_GROUP_20_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_20_MP0_RSMU_SEC_START_ADDR_GROUP_20_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_20_MP0_RSMU_SEC_START_ADDR_GROUP_20_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_20_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_20_MP0_RSMU_SEC_START_ADDR_GROUP_20_MASK)

#define RSMU_SEC_START_ADDR_GROUP_20_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_20_MP0_GET_RSMU_SEC_START_ADDR_GROUP_20(rsmu_sec_start_addr_group_20_mp0) \
      ((rsmu_sec_start_addr_group_20_mp0 & RSMU_SEC_START_ADDR_GROUP_20_MP0_RSMU_SEC_START_ADDR_GROUP_20_MASK) >> RSMU_SEC_START_ADDR_GROUP_20_MP0_RSMU_SEC_START_ADDR_GROUP_20_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_20_MP0_SET_RSMU_SEC_START_ADDR_GROUP_20(rsmu_sec_start_addr_group_20_mp0_reg, rsmu_sec_start_addr_group_20) \
      rsmu_sec_start_addr_group_20_mp0_reg = (rsmu_sec_start_addr_group_20_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_20_MP0_RSMU_SEC_START_ADDR_GROUP_20_MASK) | (rsmu_sec_start_addr_group_20 << RSMU_SEC_START_ADDR_GROUP_20_MP0_RSMU_SEC_START_ADDR_GROUP_20_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_20_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_20   : RSMU_SEC_START_ADDR_GROUP_20_MP0_RSMU_SEC_START_ADDR_GROUP_20_SIZE;
      } rsmu_sec_start_addr_group_20_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_20_mp0_t {
            unsigned int rsmu_sec_start_addr_group_20   : RSMU_SEC_START_ADDR_GROUP_20_MP0_RSMU_SEC_START_ADDR_GROUP_20_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_20_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_20_mp0_t f;
} rsmu_sec_start_addr_group_20_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_20_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_20_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_20_MP0_RSMU_SEC_END_ADDR_GROUP_20_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_20_MP0_RSMU_SEC_END_ADDR_GROUP_20_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_20_MP0_RSMU_SEC_END_ADDR_GROUP_20_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_20_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_20_MP0_RSMU_SEC_END_ADDR_GROUP_20_MASK)

#define RSMU_SEC_END_ADDR_GROUP_20_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_20_MP0_GET_RSMU_SEC_END_ADDR_GROUP_20(rsmu_sec_end_addr_group_20_mp0) \
      ((rsmu_sec_end_addr_group_20_mp0 & RSMU_SEC_END_ADDR_GROUP_20_MP0_RSMU_SEC_END_ADDR_GROUP_20_MASK) >> RSMU_SEC_END_ADDR_GROUP_20_MP0_RSMU_SEC_END_ADDR_GROUP_20_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_20_MP0_SET_RSMU_SEC_END_ADDR_GROUP_20(rsmu_sec_end_addr_group_20_mp0_reg, rsmu_sec_end_addr_group_20) \
      rsmu_sec_end_addr_group_20_mp0_reg = (rsmu_sec_end_addr_group_20_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_20_MP0_RSMU_SEC_END_ADDR_GROUP_20_MASK) | (rsmu_sec_end_addr_group_20 << RSMU_SEC_END_ADDR_GROUP_20_MP0_RSMU_SEC_END_ADDR_GROUP_20_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_20_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_20     : RSMU_SEC_END_ADDR_GROUP_20_MP0_RSMU_SEC_END_ADDR_GROUP_20_SIZE;
      } rsmu_sec_end_addr_group_20_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_20_mp0_t {
            unsigned int rsmu_sec_end_addr_group_20     : RSMU_SEC_END_ADDR_GROUP_20_MP0_RSMU_SEC_END_ADDR_GROUP_20_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_20_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_20_mp0_t f;
} rsmu_sec_end_addr_group_20_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_20_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_20_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_20_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_20_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_20_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_20_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_20_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_20_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_20_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_20_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_20_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_20_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_20_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_20(rsmu_sec_initid_mask_set0_group_20_mp0) \
      ((rsmu_sec_initid_mask_set0_group_20_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_20_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_20_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_20_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_20_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_20_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_20(rsmu_sec_initid_mask_set0_group_20_mp0_reg, rsmu_sec_initid_mask_set0_group_20) \
      rsmu_sec_initid_mask_set0_group_20_mp0_reg = (rsmu_sec_initid_mask_set0_group_20_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_20_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_20_MASK) | (rsmu_sec_initid_mask_set0_group_20 << RSMU_SEC_INITID_MASK_SET0_GROUP_20_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_20_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_20_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_20 : RSMU_SEC_INITID_MASK_SET0_GROUP_20_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_20_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_20_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_20_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_20 : RSMU_SEC_INITID_MASK_SET0_GROUP_20_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_20_SIZE;
      } rsmu_sec_initid_mask_set0_group_20_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_20_mp0_t f;
} rsmu_sec_initid_mask_set0_group_20_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_20_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_20_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_20_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_20_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_20_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_20_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_20_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_20_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_20_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_20_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_20_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_20_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_20_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_20(rsmu_sec_unitid_mask_set0_group_20_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_20_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_20_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_20_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_20_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_20_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_20_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_20(rsmu_sec_unitid_mask_set0_group_20_mp0_reg, rsmu_sec_unitid_mask_set0_group_20) \
      rsmu_sec_unitid_mask_set0_group_20_mp0_reg = (rsmu_sec_unitid_mask_set0_group_20_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_20_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_20_MASK) | (rsmu_sec_unitid_mask_set0_group_20 << RSMU_SEC_UNITID_MASK_SET0_GROUP_20_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_20_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_20_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_20 : RSMU_SEC_UNITID_MASK_SET0_GROUP_20_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_20_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_20_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_20_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_20 : RSMU_SEC_UNITID_MASK_SET0_GROUP_20_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_20_SIZE;
      } rsmu_sec_unitid_mask_set0_group_20_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_20_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_20_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_20_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_20_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_20_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_20_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_20_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_20_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_20_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_20_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_20_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_20_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_20_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_20_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_20(rsmu_sec_misc_mask_set0_group_20_mp0) \
      ((rsmu_sec_misc_mask_set0_group_20_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_20_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_20_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_20(rsmu_sec_misc_mask_set0_group_20_mp0) \
      ((rsmu_sec_misc_mask_set0_group_20_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_20_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_20_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_20(rsmu_sec_misc_mask_set0_group_20_mp0) \
      ((rsmu_sec_misc_mask_set0_group_20_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_20_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_20_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_20(rsmu_sec_misc_mask_set0_group_20_mp0_reg, rsmu_sec_tlvl_mask_set0_group_20) \
      rsmu_sec_misc_mask_set0_group_20_mp0_reg = (rsmu_sec_misc_mask_set0_group_20_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_20_MASK) | (rsmu_sec_tlvl_mask_set0_group_20 << RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_20_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_20(rsmu_sec_misc_mask_set0_group_20_mp0_reg, rsmu_sec_rw_mask_set0_group_20) \
      rsmu_sec_misc_mask_set0_group_20_mp0_reg = (rsmu_sec_misc_mask_set0_group_20_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_20_MASK) | (rsmu_sec_rw_mask_set0_group_20 << RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_20_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_20(rsmu_sec_misc_mask_set0_group_20_mp0_reg, rsmu_sec_vf_mask_set0_group_20) \
      rsmu_sec_misc_mask_set0_group_20_mp0_reg = (rsmu_sec_misc_mask_set0_group_20_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_20_MASK) | (rsmu_sec_vf_mask_set0_group_20 << RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_20_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_20_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_20 : RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_20_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_20 : RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_20_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_20 : RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_20_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_20_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_20_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_20 : RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_20_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_20 : RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_20_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_20 : RSMU_SEC_MISC_MASK_SET0_GROUP_20_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_20_SIZE;
      } rsmu_sec_misc_mask_set0_group_20_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_20_mp0_t f;
} rsmu_sec_misc_mask_set0_group_20_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_20_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_20_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_20_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_20_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_20_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_20_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_20_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_20_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_20_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_20_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_20_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_20_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_20_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_20(rsmu_sec_initid_mask_set1_group_20_mp0) \
      ((rsmu_sec_initid_mask_set1_group_20_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_20_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_20_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_20_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_20_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_20_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_20(rsmu_sec_initid_mask_set1_group_20_mp0_reg, rsmu_sec_initid_mask_set1_group_20) \
      rsmu_sec_initid_mask_set1_group_20_mp0_reg = (rsmu_sec_initid_mask_set1_group_20_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_20_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_20_MASK) | (rsmu_sec_initid_mask_set1_group_20 << RSMU_SEC_INITID_MASK_SET1_GROUP_20_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_20_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_20_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_20 : RSMU_SEC_INITID_MASK_SET1_GROUP_20_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_20_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_20_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_20_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_20 : RSMU_SEC_INITID_MASK_SET1_GROUP_20_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_20_SIZE;
      } rsmu_sec_initid_mask_set1_group_20_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_20_mp0_t f;
} rsmu_sec_initid_mask_set1_group_20_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_20_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_20_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_20_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_20_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_20_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_20_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_20_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_20_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_20_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_20_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_20_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_20_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_20_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_20(rsmu_sec_unitid_mask_set1_group_20_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_20_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_20_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_20_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_20_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_20_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_20_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_20(rsmu_sec_unitid_mask_set1_group_20_mp0_reg, rsmu_sec_unitid_mask_set1_group_20) \
      rsmu_sec_unitid_mask_set1_group_20_mp0_reg = (rsmu_sec_unitid_mask_set1_group_20_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_20_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_20_MASK) | (rsmu_sec_unitid_mask_set1_group_20 << RSMU_SEC_UNITID_MASK_SET1_GROUP_20_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_20_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_20_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_20 : RSMU_SEC_UNITID_MASK_SET1_GROUP_20_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_20_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_20_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_20_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_20 : RSMU_SEC_UNITID_MASK_SET1_GROUP_20_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_20_SIZE;
      } rsmu_sec_unitid_mask_set1_group_20_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_20_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_20_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_20_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_20_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_20_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_20_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_20_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_20_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_20_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_20_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_20_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_20_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_20_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_20_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_20(rsmu_sec_misc_mask_set1_group_20_mp0) \
      ((rsmu_sec_misc_mask_set1_group_20_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_20_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_20_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_20(rsmu_sec_misc_mask_set1_group_20_mp0) \
      ((rsmu_sec_misc_mask_set1_group_20_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_20_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_20_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_20(rsmu_sec_misc_mask_set1_group_20_mp0) \
      ((rsmu_sec_misc_mask_set1_group_20_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_20_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_20_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_20(rsmu_sec_misc_mask_set1_group_20_mp0_reg, rsmu_sec_tlvl_mask_set1_group_20) \
      rsmu_sec_misc_mask_set1_group_20_mp0_reg = (rsmu_sec_misc_mask_set1_group_20_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_20_MASK) | (rsmu_sec_tlvl_mask_set1_group_20 << RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_20_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_20(rsmu_sec_misc_mask_set1_group_20_mp0_reg, rsmu_sec_rw_mask_set1_group_20) \
      rsmu_sec_misc_mask_set1_group_20_mp0_reg = (rsmu_sec_misc_mask_set1_group_20_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_20_MASK) | (rsmu_sec_rw_mask_set1_group_20 << RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_20_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_20(rsmu_sec_misc_mask_set1_group_20_mp0_reg, rsmu_sec_vf_mask_set1_group_20) \
      rsmu_sec_misc_mask_set1_group_20_mp0_reg = (rsmu_sec_misc_mask_set1_group_20_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_20_MASK) | (rsmu_sec_vf_mask_set1_group_20 << RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_20_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_20_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_20 : RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_20_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_20 : RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_20_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_20 : RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_20_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_20_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_20_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_20 : RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_20_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_20 : RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_20_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_20 : RSMU_SEC_MISC_MASK_SET1_GROUP_20_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_20_SIZE;
      } rsmu_sec_misc_mask_set1_group_20_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_20_mp0_t f;
} rsmu_sec_misc_mask_set1_group_20_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_20_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_20_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_20_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_20_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_20_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_20_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_20_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_20_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_20_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_20_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_20_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_20_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_20_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_20_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_20_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_20_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_20(rsmu_sec_access_control_group_20_mp0) \
      ((rsmu_sec_access_control_group_20_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_20_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_20_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_20(rsmu_sec_access_control_group_20_mp0) \
      ((rsmu_sec_access_control_group_20_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_20_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_20_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_20(rsmu_sec_access_control_group_20_mp0) \
      ((rsmu_sec_access_control_group_20_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_20_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_20_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_20(rsmu_sec_access_control_group_20_mp0) \
      ((rsmu_sec_access_control_group_20_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_20_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_20_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_20(rsmu_sec_access_control_group_20_mp0_reg, rsmu_sec_check_enable_set0_group_20) \
      rsmu_sec_access_control_group_20_mp0_reg = (rsmu_sec_access_control_group_20_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_20_MASK) | (rsmu_sec_check_enable_set0_group_20 << RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_20_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_20(rsmu_sec_access_control_group_20_mp0_reg, rsmu_sec_check_enable_set1_group_20) \
      rsmu_sec_access_control_group_20_mp0_reg = (rsmu_sec_access_control_group_20_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_20_MASK) | (rsmu_sec_check_enable_set1_group_20 << RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_20_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_20(rsmu_sec_access_control_group_20_mp0_reg, rsmu_sec_vf_check_enable_set0_group_20) \
      rsmu_sec_access_control_group_20_mp0_reg = (rsmu_sec_access_control_group_20_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_20_MASK) | (rsmu_sec_vf_check_enable_set0_group_20 << RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_20_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_20(rsmu_sec_access_control_group_20_mp0_reg, rsmu_sec_vf_check_enable_set1_group_20) \
      rsmu_sec_access_control_group_20_mp0_reg = (rsmu_sec_access_control_group_20_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_20_MASK) | (rsmu_sec_vf_check_enable_set1_group_20 << RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_20_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_20_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_20 : RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_20_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_20 : RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_20_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_20 : RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_20_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_20 : RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_20_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_20_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_20_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_20 : RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_20_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_20 : RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_20_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_20 : RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_20_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_20 : RSMU_SEC_ACCESS_CONTROL_GROUP_20_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_20_SIZE;
      } rsmu_sec_access_control_group_20_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_20_mp0_t f;
} rsmu_sec_access_control_group_20_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_21_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_21_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_21_MP0_RSMU_SEC_START_ADDR_GROUP_21_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_21_MP0_RSMU_SEC_START_ADDR_GROUP_21_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_21_MP0_RSMU_SEC_START_ADDR_GROUP_21_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_21_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_21_MP0_RSMU_SEC_START_ADDR_GROUP_21_MASK)

#define RSMU_SEC_START_ADDR_GROUP_21_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_21_MP0_GET_RSMU_SEC_START_ADDR_GROUP_21(rsmu_sec_start_addr_group_21_mp0) \
      ((rsmu_sec_start_addr_group_21_mp0 & RSMU_SEC_START_ADDR_GROUP_21_MP0_RSMU_SEC_START_ADDR_GROUP_21_MASK) >> RSMU_SEC_START_ADDR_GROUP_21_MP0_RSMU_SEC_START_ADDR_GROUP_21_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_21_MP0_SET_RSMU_SEC_START_ADDR_GROUP_21(rsmu_sec_start_addr_group_21_mp0_reg, rsmu_sec_start_addr_group_21) \
      rsmu_sec_start_addr_group_21_mp0_reg = (rsmu_sec_start_addr_group_21_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_21_MP0_RSMU_SEC_START_ADDR_GROUP_21_MASK) | (rsmu_sec_start_addr_group_21 << RSMU_SEC_START_ADDR_GROUP_21_MP0_RSMU_SEC_START_ADDR_GROUP_21_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_21_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_21   : RSMU_SEC_START_ADDR_GROUP_21_MP0_RSMU_SEC_START_ADDR_GROUP_21_SIZE;
      } rsmu_sec_start_addr_group_21_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_21_mp0_t {
            unsigned int rsmu_sec_start_addr_group_21   : RSMU_SEC_START_ADDR_GROUP_21_MP0_RSMU_SEC_START_ADDR_GROUP_21_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_21_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_21_mp0_t f;
} rsmu_sec_start_addr_group_21_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_21_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_21_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_21_MP0_RSMU_SEC_END_ADDR_GROUP_21_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_21_MP0_RSMU_SEC_END_ADDR_GROUP_21_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_21_MP0_RSMU_SEC_END_ADDR_GROUP_21_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_21_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_21_MP0_RSMU_SEC_END_ADDR_GROUP_21_MASK)

#define RSMU_SEC_END_ADDR_GROUP_21_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_21_MP0_GET_RSMU_SEC_END_ADDR_GROUP_21(rsmu_sec_end_addr_group_21_mp0) \
      ((rsmu_sec_end_addr_group_21_mp0 & RSMU_SEC_END_ADDR_GROUP_21_MP0_RSMU_SEC_END_ADDR_GROUP_21_MASK) >> RSMU_SEC_END_ADDR_GROUP_21_MP0_RSMU_SEC_END_ADDR_GROUP_21_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_21_MP0_SET_RSMU_SEC_END_ADDR_GROUP_21(rsmu_sec_end_addr_group_21_mp0_reg, rsmu_sec_end_addr_group_21) \
      rsmu_sec_end_addr_group_21_mp0_reg = (rsmu_sec_end_addr_group_21_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_21_MP0_RSMU_SEC_END_ADDR_GROUP_21_MASK) | (rsmu_sec_end_addr_group_21 << RSMU_SEC_END_ADDR_GROUP_21_MP0_RSMU_SEC_END_ADDR_GROUP_21_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_21_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_21     : RSMU_SEC_END_ADDR_GROUP_21_MP0_RSMU_SEC_END_ADDR_GROUP_21_SIZE;
      } rsmu_sec_end_addr_group_21_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_21_mp0_t {
            unsigned int rsmu_sec_end_addr_group_21     : RSMU_SEC_END_ADDR_GROUP_21_MP0_RSMU_SEC_END_ADDR_GROUP_21_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_21_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_21_mp0_t f;
} rsmu_sec_end_addr_group_21_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_21_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_21_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_21_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_21_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_21_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_21_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_21_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_21_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_21_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_21_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_21_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_21_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_21_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_21(rsmu_sec_initid_mask_set0_group_21_mp0) \
      ((rsmu_sec_initid_mask_set0_group_21_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_21_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_21_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_21_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_21_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_21_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_21(rsmu_sec_initid_mask_set0_group_21_mp0_reg, rsmu_sec_initid_mask_set0_group_21) \
      rsmu_sec_initid_mask_set0_group_21_mp0_reg = (rsmu_sec_initid_mask_set0_group_21_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_21_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_21_MASK) | (rsmu_sec_initid_mask_set0_group_21 << RSMU_SEC_INITID_MASK_SET0_GROUP_21_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_21_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_21_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_21 : RSMU_SEC_INITID_MASK_SET0_GROUP_21_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_21_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_21_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_21_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_21 : RSMU_SEC_INITID_MASK_SET0_GROUP_21_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_21_SIZE;
      } rsmu_sec_initid_mask_set0_group_21_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_21_mp0_t f;
} rsmu_sec_initid_mask_set0_group_21_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_21_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_21_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_21_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_21_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_21_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_21_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_21_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_21_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_21_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_21_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_21_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_21_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_21_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_21(rsmu_sec_unitid_mask_set0_group_21_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_21_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_21_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_21_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_21_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_21_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_21_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_21(rsmu_sec_unitid_mask_set0_group_21_mp0_reg, rsmu_sec_unitid_mask_set0_group_21) \
      rsmu_sec_unitid_mask_set0_group_21_mp0_reg = (rsmu_sec_unitid_mask_set0_group_21_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_21_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_21_MASK) | (rsmu_sec_unitid_mask_set0_group_21 << RSMU_SEC_UNITID_MASK_SET0_GROUP_21_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_21_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_21_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_21 : RSMU_SEC_UNITID_MASK_SET0_GROUP_21_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_21_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_21_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_21_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_21 : RSMU_SEC_UNITID_MASK_SET0_GROUP_21_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_21_SIZE;
      } rsmu_sec_unitid_mask_set0_group_21_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_21_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_21_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_21_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_21_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_21_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_21_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_21_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_21_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_21_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_21_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_21_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_21_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_21_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_21_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_21(rsmu_sec_misc_mask_set0_group_21_mp0) \
      ((rsmu_sec_misc_mask_set0_group_21_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_21_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_21_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_21(rsmu_sec_misc_mask_set0_group_21_mp0) \
      ((rsmu_sec_misc_mask_set0_group_21_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_21_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_21_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_21(rsmu_sec_misc_mask_set0_group_21_mp0) \
      ((rsmu_sec_misc_mask_set0_group_21_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_21_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_21_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_21(rsmu_sec_misc_mask_set0_group_21_mp0_reg, rsmu_sec_tlvl_mask_set0_group_21) \
      rsmu_sec_misc_mask_set0_group_21_mp0_reg = (rsmu_sec_misc_mask_set0_group_21_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_21_MASK) | (rsmu_sec_tlvl_mask_set0_group_21 << RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_21_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_21(rsmu_sec_misc_mask_set0_group_21_mp0_reg, rsmu_sec_rw_mask_set0_group_21) \
      rsmu_sec_misc_mask_set0_group_21_mp0_reg = (rsmu_sec_misc_mask_set0_group_21_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_21_MASK) | (rsmu_sec_rw_mask_set0_group_21 << RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_21_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_21(rsmu_sec_misc_mask_set0_group_21_mp0_reg, rsmu_sec_vf_mask_set0_group_21) \
      rsmu_sec_misc_mask_set0_group_21_mp0_reg = (rsmu_sec_misc_mask_set0_group_21_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_21_MASK) | (rsmu_sec_vf_mask_set0_group_21 << RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_21_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_21_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_21 : RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_21_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_21 : RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_21_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_21 : RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_21_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_21_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_21_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_21 : RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_21_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_21 : RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_21_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_21 : RSMU_SEC_MISC_MASK_SET0_GROUP_21_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_21_SIZE;
      } rsmu_sec_misc_mask_set0_group_21_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_21_mp0_t f;
} rsmu_sec_misc_mask_set0_group_21_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_21_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_21_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_21_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_21_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_21_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_21_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_21_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_21_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_21_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_21_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_21_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_21_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_21_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_21(rsmu_sec_initid_mask_set1_group_21_mp0) \
      ((rsmu_sec_initid_mask_set1_group_21_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_21_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_21_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_21_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_21_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_21_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_21(rsmu_sec_initid_mask_set1_group_21_mp0_reg, rsmu_sec_initid_mask_set1_group_21) \
      rsmu_sec_initid_mask_set1_group_21_mp0_reg = (rsmu_sec_initid_mask_set1_group_21_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_21_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_21_MASK) | (rsmu_sec_initid_mask_set1_group_21 << RSMU_SEC_INITID_MASK_SET1_GROUP_21_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_21_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_21_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_21 : RSMU_SEC_INITID_MASK_SET1_GROUP_21_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_21_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_21_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_21_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_21 : RSMU_SEC_INITID_MASK_SET1_GROUP_21_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_21_SIZE;
      } rsmu_sec_initid_mask_set1_group_21_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_21_mp0_t f;
} rsmu_sec_initid_mask_set1_group_21_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_21_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_21_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_21_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_21_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_21_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_21_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_21_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_21_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_21_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_21_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_21_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_21_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_21_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_21(rsmu_sec_unitid_mask_set1_group_21_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_21_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_21_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_21_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_21_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_21_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_21_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_21(rsmu_sec_unitid_mask_set1_group_21_mp0_reg, rsmu_sec_unitid_mask_set1_group_21) \
      rsmu_sec_unitid_mask_set1_group_21_mp0_reg = (rsmu_sec_unitid_mask_set1_group_21_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_21_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_21_MASK) | (rsmu_sec_unitid_mask_set1_group_21 << RSMU_SEC_UNITID_MASK_SET1_GROUP_21_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_21_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_21_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_21 : RSMU_SEC_UNITID_MASK_SET1_GROUP_21_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_21_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_21_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_21_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_21 : RSMU_SEC_UNITID_MASK_SET1_GROUP_21_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_21_SIZE;
      } rsmu_sec_unitid_mask_set1_group_21_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_21_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_21_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_21_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_21_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_21_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_21_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_21_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_21_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_21_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_21_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_21_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_21_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_21_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_21_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_21(rsmu_sec_misc_mask_set1_group_21_mp0) \
      ((rsmu_sec_misc_mask_set1_group_21_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_21_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_21_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_21(rsmu_sec_misc_mask_set1_group_21_mp0) \
      ((rsmu_sec_misc_mask_set1_group_21_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_21_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_21_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_21(rsmu_sec_misc_mask_set1_group_21_mp0) \
      ((rsmu_sec_misc_mask_set1_group_21_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_21_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_21_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_21(rsmu_sec_misc_mask_set1_group_21_mp0_reg, rsmu_sec_tlvl_mask_set1_group_21) \
      rsmu_sec_misc_mask_set1_group_21_mp0_reg = (rsmu_sec_misc_mask_set1_group_21_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_21_MASK) | (rsmu_sec_tlvl_mask_set1_group_21 << RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_21_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_21(rsmu_sec_misc_mask_set1_group_21_mp0_reg, rsmu_sec_rw_mask_set1_group_21) \
      rsmu_sec_misc_mask_set1_group_21_mp0_reg = (rsmu_sec_misc_mask_set1_group_21_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_21_MASK) | (rsmu_sec_rw_mask_set1_group_21 << RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_21_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_21(rsmu_sec_misc_mask_set1_group_21_mp0_reg, rsmu_sec_vf_mask_set1_group_21) \
      rsmu_sec_misc_mask_set1_group_21_mp0_reg = (rsmu_sec_misc_mask_set1_group_21_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_21_MASK) | (rsmu_sec_vf_mask_set1_group_21 << RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_21_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_21_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_21 : RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_21_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_21 : RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_21_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_21 : RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_21_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_21_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_21_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_21 : RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_21_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_21 : RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_21_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_21 : RSMU_SEC_MISC_MASK_SET1_GROUP_21_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_21_SIZE;
      } rsmu_sec_misc_mask_set1_group_21_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_21_mp0_t f;
} rsmu_sec_misc_mask_set1_group_21_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_21_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_21_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_21_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_21_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_21_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_21_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_21_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_21_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_21_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_21_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_21_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_21_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_21_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_21_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_21_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_21_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_21(rsmu_sec_access_control_group_21_mp0) \
      ((rsmu_sec_access_control_group_21_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_21_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_21_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_21(rsmu_sec_access_control_group_21_mp0) \
      ((rsmu_sec_access_control_group_21_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_21_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_21_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_21(rsmu_sec_access_control_group_21_mp0) \
      ((rsmu_sec_access_control_group_21_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_21_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_21_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_21(rsmu_sec_access_control_group_21_mp0) \
      ((rsmu_sec_access_control_group_21_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_21_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_21_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_21(rsmu_sec_access_control_group_21_mp0_reg, rsmu_sec_check_enable_set0_group_21) \
      rsmu_sec_access_control_group_21_mp0_reg = (rsmu_sec_access_control_group_21_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_21_MASK) | (rsmu_sec_check_enable_set0_group_21 << RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_21_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_21(rsmu_sec_access_control_group_21_mp0_reg, rsmu_sec_check_enable_set1_group_21) \
      rsmu_sec_access_control_group_21_mp0_reg = (rsmu_sec_access_control_group_21_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_21_MASK) | (rsmu_sec_check_enable_set1_group_21 << RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_21_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_21(rsmu_sec_access_control_group_21_mp0_reg, rsmu_sec_vf_check_enable_set0_group_21) \
      rsmu_sec_access_control_group_21_mp0_reg = (rsmu_sec_access_control_group_21_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_21_MASK) | (rsmu_sec_vf_check_enable_set0_group_21 << RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_21_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_21(rsmu_sec_access_control_group_21_mp0_reg, rsmu_sec_vf_check_enable_set1_group_21) \
      rsmu_sec_access_control_group_21_mp0_reg = (rsmu_sec_access_control_group_21_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_21_MASK) | (rsmu_sec_vf_check_enable_set1_group_21 << RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_21_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_21_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_21 : RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_21_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_21 : RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_21_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_21 : RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_21_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_21 : RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_21_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_21_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_21_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_21 : RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_21_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_21 : RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_21_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_21 : RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_21_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_21 : RSMU_SEC_ACCESS_CONTROL_GROUP_21_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_21_SIZE;
      } rsmu_sec_access_control_group_21_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_21_mp0_t f;
} rsmu_sec_access_control_group_21_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_22_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_22_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_22_MP0_RSMU_SEC_START_ADDR_GROUP_22_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_22_MP0_RSMU_SEC_START_ADDR_GROUP_22_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_22_MP0_RSMU_SEC_START_ADDR_GROUP_22_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_22_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_22_MP0_RSMU_SEC_START_ADDR_GROUP_22_MASK)

#define RSMU_SEC_START_ADDR_GROUP_22_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_22_MP0_GET_RSMU_SEC_START_ADDR_GROUP_22(rsmu_sec_start_addr_group_22_mp0) \
      ((rsmu_sec_start_addr_group_22_mp0 & RSMU_SEC_START_ADDR_GROUP_22_MP0_RSMU_SEC_START_ADDR_GROUP_22_MASK) >> RSMU_SEC_START_ADDR_GROUP_22_MP0_RSMU_SEC_START_ADDR_GROUP_22_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_22_MP0_SET_RSMU_SEC_START_ADDR_GROUP_22(rsmu_sec_start_addr_group_22_mp0_reg, rsmu_sec_start_addr_group_22) \
      rsmu_sec_start_addr_group_22_mp0_reg = (rsmu_sec_start_addr_group_22_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_22_MP0_RSMU_SEC_START_ADDR_GROUP_22_MASK) | (rsmu_sec_start_addr_group_22 << RSMU_SEC_START_ADDR_GROUP_22_MP0_RSMU_SEC_START_ADDR_GROUP_22_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_22_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_22   : RSMU_SEC_START_ADDR_GROUP_22_MP0_RSMU_SEC_START_ADDR_GROUP_22_SIZE;
      } rsmu_sec_start_addr_group_22_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_22_mp0_t {
            unsigned int rsmu_sec_start_addr_group_22   : RSMU_SEC_START_ADDR_GROUP_22_MP0_RSMU_SEC_START_ADDR_GROUP_22_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_22_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_22_mp0_t f;
} rsmu_sec_start_addr_group_22_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_22_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_22_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_22_MP0_RSMU_SEC_END_ADDR_GROUP_22_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_22_MP0_RSMU_SEC_END_ADDR_GROUP_22_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_22_MP0_RSMU_SEC_END_ADDR_GROUP_22_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_22_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_22_MP0_RSMU_SEC_END_ADDR_GROUP_22_MASK)

#define RSMU_SEC_END_ADDR_GROUP_22_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_22_MP0_GET_RSMU_SEC_END_ADDR_GROUP_22(rsmu_sec_end_addr_group_22_mp0) \
      ((rsmu_sec_end_addr_group_22_mp0 & RSMU_SEC_END_ADDR_GROUP_22_MP0_RSMU_SEC_END_ADDR_GROUP_22_MASK) >> RSMU_SEC_END_ADDR_GROUP_22_MP0_RSMU_SEC_END_ADDR_GROUP_22_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_22_MP0_SET_RSMU_SEC_END_ADDR_GROUP_22(rsmu_sec_end_addr_group_22_mp0_reg, rsmu_sec_end_addr_group_22) \
      rsmu_sec_end_addr_group_22_mp0_reg = (rsmu_sec_end_addr_group_22_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_22_MP0_RSMU_SEC_END_ADDR_GROUP_22_MASK) | (rsmu_sec_end_addr_group_22 << RSMU_SEC_END_ADDR_GROUP_22_MP0_RSMU_SEC_END_ADDR_GROUP_22_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_22_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_22     : RSMU_SEC_END_ADDR_GROUP_22_MP0_RSMU_SEC_END_ADDR_GROUP_22_SIZE;
      } rsmu_sec_end_addr_group_22_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_22_mp0_t {
            unsigned int rsmu_sec_end_addr_group_22     : RSMU_SEC_END_ADDR_GROUP_22_MP0_RSMU_SEC_END_ADDR_GROUP_22_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_22_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_22_mp0_t f;
} rsmu_sec_end_addr_group_22_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_22_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_22_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_22_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_22_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_22_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_22_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_22_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_22_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_22_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_22_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_22_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_22_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_22_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_22(rsmu_sec_initid_mask_set0_group_22_mp0) \
      ((rsmu_sec_initid_mask_set0_group_22_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_22_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_22_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_22_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_22_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_22_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_22(rsmu_sec_initid_mask_set0_group_22_mp0_reg, rsmu_sec_initid_mask_set0_group_22) \
      rsmu_sec_initid_mask_set0_group_22_mp0_reg = (rsmu_sec_initid_mask_set0_group_22_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_22_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_22_MASK) | (rsmu_sec_initid_mask_set0_group_22 << RSMU_SEC_INITID_MASK_SET0_GROUP_22_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_22_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_22_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_22 : RSMU_SEC_INITID_MASK_SET0_GROUP_22_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_22_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_22_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_22_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_22 : RSMU_SEC_INITID_MASK_SET0_GROUP_22_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_22_SIZE;
      } rsmu_sec_initid_mask_set0_group_22_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_22_mp0_t f;
} rsmu_sec_initid_mask_set0_group_22_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_22_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_22_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_22_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_22_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_22_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_22_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_22_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_22_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_22_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_22_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_22_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_22_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_22_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_22(rsmu_sec_unitid_mask_set0_group_22_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_22_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_22_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_22_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_22_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_22_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_22_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_22(rsmu_sec_unitid_mask_set0_group_22_mp0_reg, rsmu_sec_unitid_mask_set0_group_22) \
      rsmu_sec_unitid_mask_set0_group_22_mp0_reg = (rsmu_sec_unitid_mask_set0_group_22_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_22_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_22_MASK) | (rsmu_sec_unitid_mask_set0_group_22 << RSMU_SEC_UNITID_MASK_SET0_GROUP_22_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_22_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_22_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_22 : RSMU_SEC_UNITID_MASK_SET0_GROUP_22_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_22_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_22_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_22_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_22 : RSMU_SEC_UNITID_MASK_SET0_GROUP_22_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_22_SIZE;
      } rsmu_sec_unitid_mask_set0_group_22_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_22_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_22_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_22_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_22_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_22_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_22_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_22_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_22_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_22_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_22_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_22_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_22_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_22_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_22_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_22(rsmu_sec_misc_mask_set0_group_22_mp0) \
      ((rsmu_sec_misc_mask_set0_group_22_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_22_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_22_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_22(rsmu_sec_misc_mask_set0_group_22_mp0) \
      ((rsmu_sec_misc_mask_set0_group_22_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_22_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_22_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_22(rsmu_sec_misc_mask_set0_group_22_mp0) \
      ((rsmu_sec_misc_mask_set0_group_22_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_22_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_22_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_22(rsmu_sec_misc_mask_set0_group_22_mp0_reg, rsmu_sec_tlvl_mask_set0_group_22) \
      rsmu_sec_misc_mask_set0_group_22_mp0_reg = (rsmu_sec_misc_mask_set0_group_22_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_22_MASK) | (rsmu_sec_tlvl_mask_set0_group_22 << RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_22_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_22(rsmu_sec_misc_mask_set0_group_22_mp0_reg, rsmu_sec_rw_mask_set0_group_22) \
      rsmu_sec_misc_mask_set0_group_22_mp0_reg = (rsmu_sec_misc_mask_set0_group_22_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_22_MASK) | (rsmu_sec_rw_mask_set0_group_22 << RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_22_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_22(rsmu_sec_misc_mask_set0_group_22_mp0_reg, rsmu_sec_vf_mask_set0_group_22) \
      rsmu_sec_misc_mask_set0_group_22_mp0_reg = (rsmu_sec_misc_mask_set0_group_22_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_22_MASK) | (rsmu_sec_vf_mask_set0_group_22 << RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_22_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_22_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_22 : RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_22_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_22 : RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_22_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_22 : RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_22_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_22_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_22_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_22 : RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_22_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_22 : RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_22_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_22 : RSMU_SEC_MISC_MASK_SET0_GROUP_22_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_22_SIZE;
      } rsmu_sec_misc_mask_set0_group_22_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_22_mp0_t f;
} rsmu_sec_misc_mask_set0_group_22_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_22_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_22_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_22_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_22_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_22_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_22_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_22_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_22_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_22_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_22_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_22_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_22_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_22_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_22(rsmu_sec_initid_mask_set1_group_22_mp0) \
      ((rsmu_sec_initid_mask_set1_group_22_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_22_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_22_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_22_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_22_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_22_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_22(rsmu_sec_initid_mask_set1_group_22_mp0_reg, rsmu_sec_initid_mask_set1_group_22) \
      rsmu_sec_initid_mask_set1_group_22_mp0_reg = (rsmu_sec_initid_mask_set1_group_22_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_22_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_22_MASK) | (rsmu_sec_initid_mask_set1_group_22 << RSMU_SEC_INITID_MASK_SET1_GROUP_22_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_22_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_22_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_22 : RSMU_SEC_INITID_MASK_SET1_GROUP_22_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_22_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_22_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_22_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_22 : RSMU_SEC_INITID_MASK_SET1_GROUP_22_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_22_SIZE;
      } rsmu_sec_initid_mask_set1_group_22_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_22_mp0_t f;
} rsmu_sec_initid_mask_set1_group_22_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_22_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_22_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_22_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_22_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_22_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_22_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_22_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_22_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_22_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_22_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_22_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_22_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_22_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_22(rsmu_sec_unitid_mask_set1_group_22_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_22_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_22_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_22_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_22_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_22_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_22_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_22(rsmu_sec_unitid_mask_set1_group_22_mp0_reg, rsmu_sec_unitid_mask_set1_group_22) \
      rsmu_sec_unitid_mask_set1_group_22_mp0_reg = (rsmu_sec_unitid_mask_set1_group_22_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_22_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_22_MASK) | (rsmu_sec_unitid_mask_set1_group_22 << RSMU_SEC_UNITID_MASK_SET1_GROUP_22_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_22_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_22_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_22 : RSMU_SEC_UNITID_MASK_SET1_GROUP_22_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_22_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_22_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_22_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_22 : RSMU_SEC_UNITID_MASK_SET1_GROUP_22_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_22_SIZE;
      } rsmu_sec_unitid_mask_set1_group_22_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_22_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_22_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_22_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_22_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_22_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_22_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_22_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_22_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_22_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_22_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_22_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_22_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_22_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_22_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_22(rsmu_sec_misc_mask_set1_group_22_mp0) \
      ((rsmu_sec_misc_mask_set1_group_22_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_22_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_22_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_22(rsmu_sec_misc_mask_set1_group_22_mp0) \
      ((rsmu_sec_misc_mask_set1_group_22_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_22_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_22_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_22(rsmu_sec_misc_mask_set1_group_22_mp0) \
      ((rsmu_sec_misc_mask_set1_group_22_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_22_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_22_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_22(rsmu_sec_misc_mask_set1_group_22_mp0_reg, rsmu_sec_tlvl_mask_set1_group_22) \
      rsmu_sec_misc_mask_set1_group_22_mp0_reg = (rsmu_sec_misc_mask_set1_group_22_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_22_MASK) | (rsmu_sec_tlvl_mask_set1_group_22 << RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_22_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_22(rsmu_sec_misc_mask_set1_group_22_mp0_reg, rsmu_sec_rw_mask_set1_group_22) \
      rsmu_sec_misc_mask_set1_group_22_mp0_reg = (rsmu_sec_misc_mask_set1_group_22_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_22_MASK) | (rsmu_sec_rw_mask_set1_group_22 << RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_22_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_22(rsmu_sec_misc_mask_set1_group_22_mp0_reg, rsmu_sec_vf_mask_set1_group_22) \
      rsmu_sec_misc_mask_set1_group_22_mp0_reg = (rsmu_sec_misc_mask_set1_group_22_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_22_MASK) | (rsmu_sec_vf_mask_set1_group_22 << RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_22_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_22_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_22 : RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_22_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_22 : RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_22_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_22 : RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_22_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_22_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_22_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_22 : RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_22_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_22 : RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_22_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_22 : RSMU_SEC_MISC_MASK_SET1_GROUP_22_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_22_SIZE;
      } rsmu_sec_misc_mask_set1_group_22_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_22_mp0_t f;
} rsmu_sec_misc_mask_set1_group_22_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_22_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_22_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_22_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_22_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_22_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_22_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_22_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_22_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_22_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_22_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_22_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_22_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_22_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_22_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_22_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_22_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_22(rsmu_sec_access_control_group_22_mp0) \
      ((rsmu_sec_access_control_group_22_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_22_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_22_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_22(rsmu_sec_access_control_group_22_mp0) \
      ((rsmu_sec_access_control_group_22_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_22_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_22_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_22(rsmu_sec_access_control_group_22_mp0) \
      ((rsmu_sec_access_control_group_22_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_22_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_22_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_22(rsmu_sec_access_control_group_22_mp0) \
      ((rsmu_sec_access_control_group_22_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_22_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_22_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_22(rsmu_sec_access_control_group_22_mp0_reg, rsmu_sec_check_enable_set0_group_22) \
      rsmu_sec_access_control_group_22_mp0_reg = (rsmu_sec_access_control_group_22_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_22_MASK) | (rsmu_sec_check_enable_set0_group_22 << RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_22_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_22(rsmu_sec_access_control_group_22_mp0_reg, rsmu_sec_check_enable_set1_group_22) \
      rsmu_sec_access_control_group_22_mp0_reg = (rsmu_sec_access_control_group_22_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_22_MASK) | (rsmu_sec_check_enable_set1_group_22 << RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_22_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_22(rsmu_sec_access_control_group_22_mp0_reg, rsmu_sec_vf_check_enable_set0_group_22) \
      rsmu_sec_access_control_group_22_mp0_reg = (rsmu_sec_access_control_group_22_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_22_MASK) | (rsmu_sec_vf_check_enable_set0_group_22 << RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_22_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_22(rsmu_sec_access_control_group_22_mp0_reg, rsmu_sec_vf_check_enable_set1_group_22) \
      rsmu_sec_access_control_group_22_mp0_reg = (rsmu_sec_access_control_group_22_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_22_MASK) | (rsmu_sec_vf_check_enable_set1_group_22 << RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_22_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_22_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_22 : RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_22_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_22 : RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_22_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_22 : RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_22_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_22 : RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_22_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_22_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_22_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_22 : RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_22_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_22 : RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_22_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_22 : RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_22_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_22 : RSMU_SEC_ACCESS_CONTROL_GROUP_22_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_22_SIZE;
      } rsmu_sec_access_control_group_22_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_22_mp0_t f;
} rsmu_sec_access_control_group_22_mp0_u;


/*
 * RSMU_SEC_START_ADDR_GROUP_23_MP0 struct
 */

#define RSMU_SEC_START_ADDR_GROUP_23_MP0_REG_SIZE         32
#define RSMU_SEC_START_ADDR_GROUP_23_MP0_RSMU_SEC_START_ADDR_GROUP_23_SIZE  30

#define RSMU_SEC_START_ADDR_GROUP_23_MP0_RSMU_SEC_START_ADDR_GROUP_23_SHIFT  2

#define RSMU_SEC_START_ADDR_GROUP_23_MP0_RSMU_SEC_START_ADDR_GROUP_23_MASK  0xfffffffc

#define RSMU_SEC_START_ADDR_GROUP_23_MP0_MASK \
      (RSMU_SEC_START_ADDR_GROUP_23_MP0_RSMU_SEC_START_ADDR_GROUP_23_MASK)

#define RSMU_SEC_START_ADDR_GROUP_23_MP0_DEFAULT 0x00000000

#define RSMU_SEC_START_ADDR_GROUP_23_MP0_GET_RSMU_SEC_START_ADDR_GROUP_23(rsmu_sec_start_addr_group_23_mp0) \
      ((rsmu_sec_start_addr_group_23_mp0 & RSMU_SEC_START_ADDR_GROUP_23_MP0_RSMU_SEC_START_ADDR_GROUP_23_MASK) >> RSMU_SEC_START_ADDR_GROUP_23_MP0_RSMU_SEC_START_ADDR_GROUP_23_SHIFT)

#define RSMU_SEC_START_ADDR_GROUP_23_MP0_SET_RSMU_SEC_START_ADDR_GROUP_23(rsmu_sec_start_addr_group_23_mp0_reg, rsmu_sec_start_addr_group_23) \
      rsmu_sec_start_addr_group_23_mp0_reg = (rsmu_sec_start_addr_group_23_mp0_reg & ~RSMU_SEC_START_ADDR_GROUP_23_MP0_RSMU_SEC_START_ADDR_GROUP_23_MASK) | (rsmu_sec_start_addr_group_23 << RSMU_SEC_START_ADDR_GROUP_23_MP0_RSMU_SEC_START_ADDR_GROUP_23_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_23_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_start_addr_group_23   : RSMU_SEC_START_ADDR_GROUP_23_MP0_RSMU_SEC_START_ADDR_GROUP_23_SIZE;
      } rsmu_sec_start_addr_group_23_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_start_addr_group_23_mp0_t {
            unsigned int rsmu_sec_start_addr_group_23   : RSMU_SEC_START_ADDR_GROUP_23_MP0_RSMU_SEC_START_ADDR_GROUP_23_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_start_addr_group_23_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_start_addr_group_23_mp0_t f;
} rsmu_sec_start_addr_group_23_mp0_u;


/*
 * RSMU_SEC_END_ADDR_GROUP_23_MP0 struct
 */

#define RSMU_SEC_END_ADDR_GROUP_23_MP0_REG_SIZE         32
#define RSMU_SEC_END_ADDR_GROUP_23_MP0_RSMU_SEC_END_ADDR_GROUP_23_SIZE  30

#define RSMU_SEC_END_ADDR_GROUP_23_MP0_RSMU_SEC_END_ADDR_GROUP_23_SHIFT  2

#define RSMU_SEC_END_ADDR_GROUP_23_MP0_RSMU_SEC_END_ADDR_GROUP_23_MASK  0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_23_MP0_MASK \
      (RSMU_SEC_END_ADDR_GROUP_23_MP0_RSMU_SEC_END_ADDR_GROUP_23_MASK)

#define RSMU_SEC_END_ADDR_GROUP_23_MP0_DEFAULT 0xfffffffc

#define RSMU_SEC_END_ADDR_GROUP_23_MP0_GET_RSMU_SEC_END_ADDR_GROUP_23(rsmu_sec_end_addr_group_23_mp0) \
      ((rsmu_sec_end_addr_group_23_mp0 & RSMU_SEC_END_ADDR_GROUP_23_MP0_RSMU_SEC_END_ADDR_GROUP_23_MASK) >> RSMU_SEC_END_ADDR_GROUP_23_MP0_RSMU_SEC_END_ADDR_GROUP_23_SHIFT)

#define RSMU_SEC_END_ADDR_GROUP_23_MP0_SET_RSMU_SEC_END_ADDR_GROUP_23(rsmu_sec_end_addr_group_23_mp0_reg, rsmu_sec_end_addr_group_23) \
      rsmu_sec_end_addr_group_23_mp0_reg = (rsmu_sec_end_addr_group_23_mp0_reg & ~RSMU_SEC_END_ADDR_GROUP_23_MP0_RSMU_SEC_END_ADDR_GROUP_23_MASK) | (rsmu_sec_end_addr_group_23 << RSMU_SEC_END_ADDR_GROUP_23_MP0_RSMU_SEC_END_ADDR_GROUP_23_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_23_mp0_t {
            unsigned int                                : 2;
            unsigned int rsmu_sec_end_addr_group_23     : RSMU_SEC_END_ADDR_GROUP_23_MP0_RSMU_SEC_END_ADDR_GROUP_23_SIZE;
      } rsmu_sec_end_addr_group_23_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_end_addr_group_23_mp0_t {
            unsigned int rsmu_sec_end_addr_group_23     : RSMU_SEC_END_ADDR_GROUP_23_MP0_RSMU_SEC_END_ADDR_GROUP_23_SIZE;
            unsigned int                                : 2;
      } rsmu_sec_end_addr_group_23_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_end_addr_group_23_mp0_t f;
} rsmu_sec_end_addr_group_23_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET0_GROUP_23_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET0_GROUP_23_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET0_GROUP_23_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_23_SIZE  20

#define RSMU_SEC_INITID_MASK_SET0_GROUP_23_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_23_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET0_GROUP_23_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_23_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET0_GROUP_23_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET0_GROUP_23_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_23_MASK)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_23_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET0_GROUP_23_MP0_GET_RSMU_SEC_INITID_MASK_SET0_GROUP_23(rsmu_sec_initid_mask_set0_group_23_mp0) \
      ((rsmu_sec_initid_mask_set0_group_23_mp0 & RSMU_SEC_INITID_MASK_SET0_GROUP_23_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_23_MASK) >> RSMU_SEC_INITID_MASK_SET0_GROUP_23_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_23_SHIFT)

#define RSMU_SEC_INITID_MASK_SET0_GROUP_23_MP0_SET_RSMU_SEC_INITID_MASK_SET0_GROUP_23(rsmu_sec_initid_mask_set0_group_23_mp0_reg, rsmu_sec_initid_mask_set0_group_23) \
      rsmu_sec_initid_mask_set0_group_23_mp0_reg = (rsmu_sec_initid_mask_set0_group_23_mp0_reg & ~RSMU_SEC_INITID_MASK_SET0_GROUP_23_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_23_MASK) | (rsmu_sec_initid_mask_set0_group_23 << RSMU_SEC_INITID_MASK_SET0_GROUP_23_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_23_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_23_mp0_t {
            unsigned int rsmu_sec_initid_mask_set0_group_23 : RSMU_SEC_INITID_MASK_SET0_GROUP_23_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_23_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set0_group_23_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set0_group_23_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set0_group_23 : RSMU_SEC_INITID_MASK_SET0_GROUP_23_MP0_RSMU_SEC_INITID_MASK_SET0_GROUP_23_SIZE;
      } rsmu_sec_initid_mask_set0_group_23_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set0_group_23_mp0_t f;
} rsmu_sec_initid_mask_set0_group_23_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET0_GROUP_23_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_23_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET0_GROUP_23_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_23_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_23_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_23_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_23_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_23_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_23_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET0_GROUP_23_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_23_MASK)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_23_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_23_MP0_GET_RSMU_SEC_UNITID_MASK_SET0_GROUP_23(rsmu_sec_unitid_mask_set0_group_23_mp0) \
      ((rsmu_sec_unitid_mask_set0_group_23_mp0 & RSMU_SEC_UNITID_MASK_SET0_GROUP_23_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_23_MASK) >> RSMU_SEC_UNITID_MASK_SET0_GROUP_23_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_23_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET0_GROUP_23_MP0_SET_RSMU_SEC_UNITID_MASK_SET0_GROUP_23(rsmu_sec_unitid_mask_set0_group_23_mp0_reg, rsmu_sec_unitid_mask_set0_group_23) \
      rsmu_sec_unitid_mask_set0_group_23_mp0_reg = (rsmu_sec_unitid_mask_set0_group_23_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET0_GROUP_23_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_23_MASK) | (rsmu_sec_unitid_mask_set0_group_23 << RSMU_SEC_UNITID_MASK_SET0_GROUP_23_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_23_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_23_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set0_group_23 : RSMU_SEC_UNITID_MASK_SET0_GROUP_23_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_23_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set0_group_23_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set0_group_23_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set0_group_23 : RSMU_SEC_UNITID_MASK_SET0_GROUP_23_MP0_RSMU_SEC_UNITID_MASK_SET0_GROUP_23_SIZE;
      } rsmu_sec_unitid_mask_set0_group_23_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set0_group_23_mp0_t f;
} rsmu_sec_unitid_mask_set0_group_23_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_23_SIZE  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_23_SIZE  2
#define RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_23_SIZE  1

#define RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_23_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_23_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_23_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_23_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_23_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_23_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_23_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_23_MASK | \
      RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_23_MASK)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_GET_RSMU_SEC_TLVL_MASK_SET0_GROUP_23(rsmu_sec_misc_mask_set0_group_23_mp0) \
      ((rsmu_sec_misc_mask_set0_group_23_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_23_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_23_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_GET_RSMU_SEC_RW_MASK_SET0_GROUP_23(rsmu_sec_misc_mask_set0_group_23_mp0) \
      ((rsmu_sec_misc_mask_set0_group_23_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_23_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_23_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_GET_RSMU_SEC_VF_MASK_SET0_GROUP_23(rsmu_sec_misc_mask_set0_group_23_mp0) \
      ((rsmu_sec_misc_mask_set0_group_23_mp0 & RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_23_MASK) >> RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_23_SHIFT)

#define RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_SET_RSMU_SEC_TLVL_MASK_SET0_GROUP_23(rsmu_sec_misc_mask_set0_group_23_mp0_reg, rsmu_sec_tlvl_mask_set0_group_23) \
      rsmu_sec_misc_mask_set0_group_23_mp0_reg = (rsmu_sec_misc_mask_set0_group_23_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_23_MASK) | (rsmu_sec_tlvl_mask_set0_group_23 << RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_23_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_SET_RSMU_SEC_RW_MASK_SET0_GROUP_23(rsmu_sec_misc_mask_set0_group_23_mp0_reg, rsmu_sec_rw_mask_set0_group_23) \
      rsmu_sec_misc_mask_set0_group_23_mp0_reg = (rsmu_sec_misc_mask_set0_group_23_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_23_MASK) | (rsmu_sec_rw_mask_set0_group_23 << RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_23_SHIFT)
#define RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_SET_RSMU_SEC_VF_MASK_SET0_GROUP_23(rsmu_sec_misc_mask_set0_group_23_mp0_reg, rsmu_sec_vf_mask_set0_group_23) \
      rsmu_sec_misc_mask_set0_group_23_mp0_reg = (rsmu_sec_misc_mask_set0_group_23_mp0_reg & ~RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_23_MASK) | (rsmu_sec_vf_mask_set0_group_23 << RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_23_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_23_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set0_group_23 : RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_23_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_23 : RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_23_SIZE;
            unsigned int rsmu_sec_vf_mask_set0_group_23 : RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_23_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set0_group_23_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set0_group_23_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set0_group_23 : RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_VF_MASK_SET0_GROUP_23_SIZE;
            unsigned int rsmu_sec_rw_mask_set0_group_23 : RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_RW_MASK_SET0_GROUP_23_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set0_group_23 : RSMU_SEC_MISC_MASK_SET0_GROUP_23_MP0_RSMU_SEC_TLVL_MASK_SET0_GROUP_23_SIZE;
      } rsmu_sec_misc_mask_set0_group_23_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set0_group_23_mp0_t f;
} rsmu_sec_misc_mask_set0_group_23_mp0_u;


/*
 * RSMU_SEC_INITID_MASK_SET1_GROUP_23_MP0 struct
 */

#define RSMU_SEC_INITID_MASK_SET1_GROUP_23_MP0_REG_SIZE         32
#define RSMU_SEC_INITID_MASK_SET1_GROUP_23_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_23_SIZE  20

#define RSMU_SEC_INITID_MASK_SET1_GROUP_23_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_23_SHIFT  0

#define RSMU_SEC_INITID_MASK_SET1_GROUP_23_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_23_MASK  0x000fffff

#define RSMU_SEC_INITID_MASK_SET1_GROUP_23_MP0_MASK \
      (RSMU_SEC_INITID_MASK_SET1_GROUP_23_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_23_MASK)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_23_MP0_DEFAULT 0x00000000

#define RSMU_SEC_INITID_MASK_SET1_GROUP_23_MP0_GET_RSMU_SEC_INITID_MASK_SET1_GROUP_23(rsmu_sec_initid_mask_set1_group_23_mp0) \
      ((rsmu_sec_initid_mask_set1_group_23_mp0 & RSMU_SEC_INITID_MASK_SET1_GROUP_23_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_23_MASK) >> RSMU_SEC_INITID_MASK_SET1_GROUP_23_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_23_SHIFT)

#define RSMU_SEC_INITID_MASK_SET1_GROUP_23_MP0_SET_RSMU_SEC_INITID_MASK_SET1_GROUP_23(rsmu_sec_initid_mask_set1_group_23_mp0_reg, rsmu_sec_initid_mask_set1_group_23) \
      rsmu_sec_initid_mask_set1_group_23_mp0_reg = (rsmu_sec_initid_mask_set1_group_23_mp0_reg & ~RSMU_SEC_INITID_MASK_SET1_GROUP_23_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_23_MASK) | (rsmu_sec_initid_mask_set1_group_23 << RSMU_SEC_INITID_MASK_SET1_GROUP_23_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_23_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_23_mp0_t {
            unsigned int rsmu_sec_initid_mask_set1_group_23 : RSMU_SEC_INITID_MASK_SET1_GROUP_23_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_23_SIZE;
            unsigned int                                : 12;
      } rsmu_sec_initid_mask_set1_group_23_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_initid_mask_set1_group_23_mp0_t {
            unsigned int                                : 12;
            unsigned int rsmu_sec_initid_mask_set1_group_23 : RSMU_SEC_INITID_MASK_SET1_GROUP_23_MP0_RSMU_SEC_INITID_MASK_SET1_GROUP_23_SIZE;
      } rsmu_sec_initid_mask_set1_group_23_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_initid_mask_set1_group_23_mp0_t f;
} rsmu_sec_initid_mask_set1_group_23_mp0_u;


/*
 * RSMU_SEC_UNITID_MASK_SET1_GROUP_23_MP0 struct
 */

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_23_MP0_REG_SIZE         32
#define RSMU_SEC_UNITID_MASK_SET1_GROUP_23_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_23_SIZE  18

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_23_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_23_SHIFT  0

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_23_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_23_MASK  0x0003ffff

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_23_MP0_MASK \
      (RSMU_SEC_UNITID_MASK_SET1_GROUP_23_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_23_MASK)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_23_MP0_DEFAULT 0x00000000

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_23_MP0_GET_RSMU_SEC_UNITID_MASK_SET1_GROUP_23(rsmu_sec_unitid_mask_set1_group_23_mp0) \
      ((rsmu_sec_unitid_mask_set1_group_23_mp0 & RSMU_SEC_UNITID_MASK_SET1_GROUP_23_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_23_MASK) >> RSMU_SEC_UNITID_MASK_SET1_GROUP_23_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_23_SHIFT)

#define RSMU_SEC_UNITID_MASK_SET1_GROUP_23_MP0_SET_RSMU_SEC_UNITID_MASK_SET1_GROUP_23(rsmu_sec_unitid_mask_set1_group_23_mp0_reg, rsmu_sec_unitid_mask_set1_group_23) \
      rsmu_sec_unitid_mask_set1_group_23_mp0_reg = (rsmu_sec_unitid_mask_set1_group_23_mp0_reg & ~RSMU_SEC_UNITID_MASK_SET1_GROUP_23_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_23_MASK) | (rsmu_sec_unitid_mask_set1_group_23 << RSMU_SEC_UNITID_MASK_SET1_GROUP_23_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_23_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_23_mp0_t {
            unsigned int rsmu_sec_unitid_mask_set1_group_23 : RSMU_SEC_UNITID_MASK_SET1_GROUP_23_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_23_SIZE;
            unsigned int                                : 14;
      } rsmu_sec_unitid_mask_set1_group_23_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_unitid_mask_set1_group_23_mp0_t {
            unsigned int                                : 14;
            unsigned int rsmu_sec_unitid_mask_set1_group_23 : RSMU_SEC_UNITID_MASK_SET1_GROUP_23_MP0_RSMU_SEC_UNITID_MASK_SET1_GROUP_23_SIZE;
      } rsmu_sec_unitid_mask_set1_group_23_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_unitid_mask_set1_group_23_mp0_t f;
} rsmu_sec_unitid_mask_set1_group_23_mp0_u;


/*
 * RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0 struct
 */

#define RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_REG_SIZE         32
#define RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_23_SIZE  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_23_SIZE  2
#define RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_23_SIZE  1

#define RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_23_SHIFT  0
#define RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_23_SHIFT  8
#define RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_23_SHIFT  10

#define RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_23_MASK  0x000000ff
#define RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_23_MASK  0x00000300
#define RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_23_MASK  0x00000400

#define RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_MASK \
      (RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_23_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_23_MASK | \
      RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_23_MASK)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_DEFAULT 0x00000000

#define RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_GET_RSMU_SEC_TLVL_MASK_SET1_GROUP_23(rsmu_sec_misc_mask_set1_group_23_mp0) \
      ((rsmu_sec_misc_mask_set1_group_23_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_23_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_23_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_GET_RSMU_SEC_RW_MASK_SET1_GROUP_23(rsmu_sec_misc_mask_set1_group_23_mp0) \
      ((rsmu_sec_misc_mask_set1_group_23_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_23_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_23_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_GET_RSMU_SEC_VF_MASK_SET1_GROUP_23(rsmu_sec_misc_mask_set1_group_23_mp0) \
      ((rsmu_sec_misc_mask_set1_group_23_mp0 & RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_23_MASK) >> RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_23_SHIFT)

#define RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_SET_RSMU_SEC_TLVL_MASK_SET1_GROUP_23(rsmu_sec_misc_mask_set1_group_23_mp0_reg, rsmu_sec_tlvl_mask_set1_group_23) \
      rsmu_sec_misc_mask_set1_group_23_mp0_reg = (rsmu_sec_misc_mask_set1_group_23_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_23_MASK) | (rsmu_sec_tlvl_mask_set1_group_23 << RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_23_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_SET_RSMU_SEC_RW_MASK_SET1_GROUP_23(rsmu_sec_misc_mask_set1_group_23_mp0_reg, rsmu_sec_rw_mask_set1_group_23) \
      rsmu_sec_misc_mask_set1_group_23_mp0_reg = (rsmu_sec_misc_mask_set1_group_23_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_23_MASK) | (rsmu_sec_rw_mask_set1_group_23 << RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_23_SHIFT)
#define RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_SET_RSMU_SEC_VF_MASK_SET1_GROUP_23(rsmu_sec_misc_mask_set1_group_23_mp0_reg, rsmu_sec_vf_mask_set1_group_23) \
      rsmu_sec_misc_mask_set1_group_23_mp0_reg = (rsmu_sec_misc_mask_set1_group_23_mp0_reg & ~RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_23_MASK) | (rsmu_sec_vf_mask_set1_group_23 << RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_23_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_23_mp0_t {
            unsigned int rsmu_sec_tlvl_mask_set1_group_23 : RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_23_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_23 : RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_23_SIZE;
            unsigned int rsmu_sec_vf_mask_set1_group_23 : RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_23_SIZE;
            unsigned int                                : 21;
      } rsmu_sec_misc_mask_set1_group_23_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_misc_mask_set1_group_23_mp0_t {
            unsigned int                                : 21;
            unsigned int rsmu_sec_vf_mask_set1_group_23 : RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_VF_MASK_SET1_GROUP_23_SIZE;
            unsigned int rsmu_sec_rw_mask_set1_group_23 : RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_RW_MASK_SET1_GROUP_23_SIZE;
            unsigned int rsmu_sec_tlvl_mask_set1_group_23 : RSMU_SEC_MISC_MASK_SET1_GROUP_23_MP0_RSMU_SEC_TLVL_MASK_SET1_GROUP_23_SIZE;
      } rsmu_sec_misc_mask_set1_group_23_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_misc_mask_set1_group_23_mp0_t f;
} rsmu_sec_misc_mask_set1_group_23_mp0_u;


/*
 * RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0 struct
 */

#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_REG_SIZE         32
#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_23_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_23_SIZE  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_23_SIZE  1
#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_23_SIZE  1

#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_23_SHIFT  0
#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_23_SHIFT  3
#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_23_SHIFT  6
#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_23_SHIFT  7

#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_23_MASK  0x00000007
#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_23_MASK  0x00000038
#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_23_MASK  0x00000040
#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_23_MASK  0x00000080

#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_MASK \
      (RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_23_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_23_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_23_MASK | \
      RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_23_MASK)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_DEFAULT 0x00000000

#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_23(rsmu_sec_access_control_group_23_mp0) \
      ((rsmu_sec_access_control_group_23_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_23_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_23_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_GET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_23(rsmu_sec_access_control_group_23_mp0) \
      ((rsmu_sec_access_control_group_23_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_23_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_23_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_23(rsmu_sec_access_control_group_23_mp0) \
      ((rsmu_sec_access_control_group_23_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_23_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_23_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_GET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_23(rsmu_sec_access_control_group_23_mp0) \
      ((rsmu_sec_access_control_group_23_mp0 & RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_23_MASK) >> RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_23_SHIFT)

#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_23(rsmu_sec_access_control_group_23_mp0_reg, rsmu_sec_check_enable_set0_group_23) \
      rsmu_sec_access_control_group_23_mp0_reg = (rsmu_sec_access_control_group_23_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_23_MASK) | (rsmu_sec_check_enable_set0_group_23 << RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_23_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_SET_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_23(rsmu_sec_access_control_group_23_mp0_reg, rsmu_sec_check_enable_set1_group_23) \
      rsmu_sec_access_control_group_23_mp0_reg = (rsmu_sec_access_control_group_23_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_23_MASK) | (rsmu_sec_check_enable_set1_group_23 << RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_23_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_23(rsmu_sec_access_control_group_23_mp0_reg, rsmu_sec_vf_check_enable_set0_group_23) \
      rsmu_sec_access_control_group_23_mp0_reg = (rsmu_sec_access_control_group_23_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_23_MASK) | (rsmu_sec_vf_check_enable_set0_group_23 << RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_23_SHIFT)
#define RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_SET_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_23(rsmu_sec_access_control_group_23_mp0_reg, rsmu_sec_vf_check_enable_set1_group_23) \
      rsmu_sec_access_control_group_23_mp0_reg = (rsmu_sec_access_control_group_23_mp0_reg & ~RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_23_MASK) | (rsmu_sec_vf_check_enable_set1_group_23 << RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_23_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_23_mp0_t {
            unsigned int rsmu_sec_check_enable_set0_group_23 : RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_23_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_23 : RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_23_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_23 : RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_23_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set1_group_23 : RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_23_SIZE;
            unsigned int                                : 24;
      } rsmu_sec_access_control_group_23_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_access_control_group_23_mp0_t {
            unsigned int                                : 24;
            unsigned int rsmu_sec_vf_check_enable_set1_group_23 : RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET1_GROUP_23_SIZE;
            unsigned int rsmu_sec_vf_check_enable_set0_group_23 : RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_VF_CHECK_ENABLE_SET0_GROUP_23_SIZE;
            unsigned int rsmu_sec_check_enable_set1_group_23 : RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_CHECK_ENABLE_SET1_GROUP_23_SIZE;
            unsigned int rsmu_sec_check_enable_set0_group_23 : RSMU_SEC_ACCESS_CONTROL_GROUP_23_MP0_RSMU_SEC_CHECK_ENABLE_SET0_GROUP_23_SIZE;
      } rsmu_sec_access_control_group_23_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_access_control_group_23_mp0_t f;
} rsmu_sec_access_control_group_23_mp0_u;


/*
 * RSMU_SEC_SLAVE_RANGE_ENABLE_MP0 struct
 */

#define RSMU_SEC_SLAVE_RANGE_ENABLE_MP0_REG_SIZE         32
#define RSMU_SEC_SLAVE_RANGE_ENABLE_MP0_RSMU_SEC_SLAVE_RANGE_ENABLE_SIZE  32

#define RSMU_SEC_SLAVE_RANGE_ENABLE_MP0_RSMU_SEC_SLAVE_RANGE_ENABLE_SHIFT  0

#define RSMU_SEC_SLAVE_RANGE_ENABLE_MP0_RSMU_SEC_SLAVE_RANGE_ENABLE_MASK  0xffffffff

#define RSMU_SEC_SLAVE_RANGE_ENABLE_MP0_MASK \
      (RSMU_SEC_SLAVE_RANGE_ENABLE_MP0_RSMU_SEC_SLAVE_RANGE_ENABLE_MASK)

#define RSMU_SEC_SLAVE_RANGE_ENABLE_MP0_DEFAULT 0x00000000

#define RSMU_SEC_SLAVE_RANGE_ENABLE_MP0_GET_RSMU_SEC_SLAVE_RANGE_ENABLE(rsmu_sec_slave_range_enable_mp0) \
      ((rsmu_sec_slave_range_enable_mp0 & RSMU_SEC_SLAVE_RANGE_ENABLE_MP0_RSMU_SEC_SLAVE_RANGE_ENABLE_MASK) >> RSMU_SEC_SLAVE_RANGE_ENABLE_MP0_RSMU_SEC_SLAVE_RANGE_ENABLE_SHIFT)

#define RSMU_SEC_SLAVE_RANGE_ENABLE_MP0_SET_RSMU_SEC_SLAVE_RANGE_ENABLE(rsmu_sec_slave_range_enable_mp0_reg, rsmu_sec_slave_range_enable) \
      rsmu_sec_slave_range_enable_mp0_reg = (rsmu_sec_slave_range_enable_mp0_reg & ~RSMU_SEC_SLAVE_RANGE_ENABLE_MP0_RSMU_SEC_SLAVE_RANGE_ENABLE_MASK) | (rsmu_sec_slave_range_enable << RSMU_SEC_SLAVE_RANGE_ENABLE_MP0_RSMU_SEC_SLAVE_RANGE_ENABLE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_slave_range_enable_mp0_t {
            unsigned int rsmu_sec_slave_range_enable    : RSMU_SEC_SLAVE_RANGE_ENABLE_MP0_RSMU_SEC_SLAVE_RANGE_ENABLE_SIZE;
      } rsmu_sec_slave_range_enable_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_slave_range_enable_mp0_t {
            unsigned int rsmu_sec_slave_range_enable    : RSMU_SEC_SLAVE_RANGE_ENABLE_MP0_RSMU_SEC_SLAVE_RANGE_ENABLE_SIZE;
      } rsmu_sec_slave_range_enable_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_slave_range_enable_mp0_t f;
} rsmu_sec_slave_range_enable_mp0_u;


/*
 * RSMU_SEC_SLAVE_ERROR_COUNTER_MP0 struct
 */

#define RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_REG_SIZE         32
#define RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_RSMU_SEC_SLAVE_ERROR_COUNTER_SIZE  16
#define RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU_SIZE  16

#define RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_RSMU_SEC_SLAVE_ERROR_COUNTER_SHIFT  0
#define RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU_SHIFT  16

#define RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_RSMU_SEC_SLAVE_ERROR_COUNTER_MASK  0x0000ffff
#define RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU_MASK  0xffff0000

#define RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_MASK \
      (RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_RSMU_SEC_SLAVE_ERROR_COUNTER_MASK | \
      RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU_MASK)

#define RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_DEFAULT 0x00000000

#define RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_GET_RSMU_SEC_SLAVE_ERROR_COUNTER(rsmu_sec_slave_error_counter_mp0) \
      ((rsmu_sec_slave_error_counter_mp0 & RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_RSMU_SEC_SLAVE_ERROR_COUNTER_MASK) >> RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_RSMU_SEC_SLAVE_ERROR_COUNTER_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_GET_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU(rsmu_sec_slave_error_counter_mp0) \
      ((rsmu_sec_slave_error_counter_mp0 & RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU_MASK) >> RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU_SHIFT)

#define RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_SET_RSMU_SEC_SLAVE_ERROR_COUNTER(rsmu_sec_slave_error_counter_mp0_reg, rsmu_sec_slave_error_counter) \
      rsmu_sec_slave_error_counter_mp0_reg = (rsmu_sec_slave_error_counter_mp0_reg & ~RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_RSMU_SEC_SLAVE_ERROR_COUNTER_MASK) | (rsmu_sec_slave_error_counter << RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_RSMU_SEC_SLAVE_ERROR_COUNTER_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_SET_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU(rsmu_sec_slave_error_counter_mp0_reg, rsmu_sec_slave_error_counter_rsmu) \
      rsmu_sec_slave_error_counter_mp0_reg = (rsmu_sec_slave_error_counter_mp0_reg & ~RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU_MASK) | (rsmu_sec_slave_error_counter_rsmu << RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_slave_error_counter_mp0_t {
            unsigned int rsmu_sec_slave_error_counter   : RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_RSMU_SEC_SLAVE_ERROR_COUNTER_SIZE;
            unsigned int rsmu_sec_slave_error_counter_rsmu : RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU_SIZE;
      } rsmu_sec_slave_error_counter_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_slave_error_counter_mp0_t {
            unsigned int rsmu_sec_slave_error_counter_rsmu : RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_RSMU_SEC_SLAVE_ERROR_COUNTER_RSMU_SIZE;
            unsigned int rsmu_sec_slave_error_counter   : RSMU_SEC_SLAVE_ERROR_COUNTER_MP0_RSMU_SEC_SLAVE_ERROR_COUNTER_SIZE;
      } rsmu_sec_slave_error_counter_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_slave_error_counter_mp0_t f;
} rsmu_sec_slave_error_counter_mp0_u;


/*
 * RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0 struct
 */

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_REG_SIZE         32
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_RSMU_SEC_SLAVE_ERROR_ADDR_SIZE  20
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_RSMU_SEC_SLAVE_ERROR_APERTUREID_SIZE  12

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_RSMU_SEC_SLAVE_ERROR_ADDR_SHIFT  0
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_RSMU_SEC_SLAVE_ERROR_APERTUREID_SHIFT  20

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_RSMU_SEC_SLAVE_ERROR_ADDR_MASK  0x000fffff
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_RSMU_SEC_SLAVE_ERROR_APERTUREID_MASK  0xfff00000

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_MASK \
      (RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_RSMU_SEC_SLAVE_ERROR_ADDR_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_RSMU_SEC_SLAVE_ERROR_APERTUREID_MASK)

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_DEFAULT 0x00000000

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_GET_RSMU_SEC_SLAVE_ERROR_ADDR(rsmu_sec_slave_error_log_addr_reg_mp0) \
      ((rsmu_sec_slave_error_log_addr_reg_mp0 & RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_RSMU_SEC_SLAVE_ERROR_ADDR_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_RSMU_SEC_SLAVE_ERROR_ADDR_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_GET_RSMU_SEC_SLAVE_ERROR_APERTUREID(rsmu_sec_slave_error_log_addr_reg_mp0) \
      ((rsmu_sec_slave_error_log_addr_reg_mp0 & RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_RSMU_SEC_SLAVE_ERROR_APERTUREID_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_RSMU_SEC_SLAVE_ERROR_APERTUREID_SHIFT)

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_SET_RSMU_SEC_SLAVE_ERROR_ADDR(rsmu_sec_slave_error_log_addr_reg_mp0_reg, rsmu_sec_slave_error_addr) \
      rsmu_sec_slave_error_log_addr_reg_mp0_reg = (rsmu_sec_slave_error_log_addr_reg_mp0_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_RSMU_SEC_SLAVE_ERROR_ADDR_MASK) | (rsmu_sec_slave_error_addr << RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_RSMU_SEC_SLAVE_ERROR_ADDR_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_SET_RSMU_SEC_SLAVE_ERROR_APERTUREID(rsmu_sec_slave_error_log_addr_reg_mp0_reg, rsmu_sec_slave_error_apertureid) \
      rsmu_sec_slave_error_log_addr_reg_mp0_reg = (rsmu_sec_slave_error_log_addr_reg_mp0_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_RSMU_SEC_SLAVE_ERROR_APERTUREID_MASK) | (rsmu_sec_slave_error_apertureid << RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_RSMU_SEC_SLAVE_ERROR_APERTUREID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_slave_error_log_addr_reg_mp0_t {
            unsigned int rsmu_sec_slave_error_addr      : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_RSMU_SEC_SLAVE_ERROR_ADDR_SIZE;
            unsigned int rsmu_sec_slave_error_apertureid : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_RSMU_SEC_SLAVE_ERROR_APERTUREID_SIZE;
      } rsmu_sec_slave_error_log_addr_reg_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_slave_error_log_addr_reg_mp0_t {
            unsigned int rsmu_sec_slave_error_apertureid : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_RSMU_SEC_SLAVE_ERROR_APERTUREID_SIZE;
            unsigned int rsmu_sec_slave_error_addr      : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_MP0_RSMU_SEC_SLAVE_ERROR_ADDR_SIZE;
      } rsmu_sec_slave_error_log_addr_reg_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_slave_error_log_addr_reg_mp0_t f;
} rsmu_sec_slave_error_log_addr_reg_mp0_u;


/*
 * RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0 struct
 */

#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_REG_SIZE         32
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_VF_SIZE  1
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_VF_ID_SIZE  6
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_TLVL_SIZE  3
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_INITIATORID_SIZE  10
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_UNITID_SIZE  7
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_OP_SIZE  1
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_SIZE  1

#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_VF_SHIFT  0
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_VF_ID_SHIFT  1
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_TLVL_SHIFT  7
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_INITIATORID_SHIFT  10
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_UNITID_SHIFT  20
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_OP_SHIFT  30
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_SHIFT  31

#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_VF_MASK  0x00000001
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_VF_ID_MASK  0x0000007e
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_TLVL_MASK  0x00000380
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_INITIATORID_MASK  0x000ffc00
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_UNITID_MASK  0x07f00000
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_OP_MASK  0x40000000
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_MASK  0x80000000

#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_MASK \
      (RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_VF_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_VF_ID_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_TLVL_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_INITIATORID_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_UNITID_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_OP_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_MASK)

#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_DEFAULT 0x00000000

#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_GET_RSMU_SEC_SLAVE_ERROR_VF(rsmu_sec_slave_error_log_reg_mp0) \
      ((rsmu_sec_slave_error_log_reg_mp0 & RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_VF_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_VF_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_GET_RSMU_SEC_SLAVE_ERROR_VF_ID(rsmu_sec_slave_error_log_reg_mp0) \
      ((rsmu_sec_slave_error_log_reg_mp0 & RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_VF_ID_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_VF_ID_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_GET_RSMU_SEC_SLAVE_ERROR_TLVL(rsmu_sec_slave_error_log_reg_mp0) \
      ((rsmu_sec_slave_error_log_reg_mp0 & RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_TLVL_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_TLVL_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_GET_RSMU_SEC_SLAVE_ERROR_INITIATORID(rsmu_sec_slave_error_log_reg_mp0) \
      ((rsmu_sec_slave_error_log_reg_mp0 & RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_INITIATORID_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_INITIATORID_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_GET_RSMU_SEC_SLAVE_ERROR_UNITID(rsmu_sec_slave_error_log_reg_mp0) \
      ((rsmu_sec_slave_error_log_reg_mp0 & RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_UNITID_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_UNITID_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_GET_RSMU_SEC_SLAVE_ERROR_OP(rsmu_sec_slave_error_log_reg_mp0) \
      ((rsmu_sec_slave_error_log_reg_mp0 & RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_OP_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_OP_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_GET_RSMU_SEC_SLAVE_ERROR_OUTSTANDING(rsmu_sec_slave_error_log_reg_mp0) \
      ((rsmu_sec_slave_error_log_reg_mp0 & RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_SHIFT)

#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_SET_RSMU_SEC_SLAVE_ERROR_VF(rsmu_sec_slave_error_log_reg_mp0_reg, rsmu_sec_slave_error_vf) \
      rsmu_sec_slave_error_log_reg_mp0_reg = (rsmu_sec_slave_error_log_reg_mp0_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_VF_MASK) | (rsmu_sec_slave_error_vf << RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_VF_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_SET_RSMU_SEC_SLAVE_ERROR_VF_ID(rsmu_sec_slave_error_log_reg_mp0_reg, rsmu_sec_slave_error_vf_id) \
      rsmu_sec_slave_error_log_reg_mp0_reg = (rsmu_sec_slave_error_log_reg_mp0_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_VF_ID_MASK) | (rsmu_sec_slave_error_vf_id << RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_VF_ID_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_SET_RSMU_SEC_SLAVE_ERROR_TLVL(rsmu_sec_slave_error_log_reg_mp0_reg, rsmu_sec_slave_error_tlvl) \
      rsmu_sec_slave_error_log_reg_mp0_reg = (rsmu_sec_slave_error_log_reg_mp0_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_TLVL_MASK) | (rsmu_sec_slave_error_tlvl << RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_TLVL_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_SET_RSMU_SEC_SLAVE_ERROR_INITIATORID(rsmu_sec_slave_error_log_reg_mp0_reg, rsmu_sec_slave_error_initiatorid) \
      rsmu_sec_slave_error_log_reg_mp0_reg = (rsmu_sec_slave_error_log_reg_mp0_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_INITIATORID_MASK) | (rsmu_sec_slave_error_initiatorid << RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_INITIATORID_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_SET_RSMU_SEC_SLAVE_ERROR_UNITID(rsmu_sec_slave_error_log_reg_mp0_reg, rsmu_sec_slave_error_unitid) \
      rsmu_sec_slave_error_log_reg_mp0_reg = (rsmu_sec_slave_error_log_reg_mp0_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_UNITID_MASK) | (rsmu_sec_slave_error_unitid << RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_UNITID_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_SET_RSMU_SEC_SLAVE_ERROR_OP(rsmu_sec_slave_error_log_reg_mp0_reg, rsmu_sec_slave_error_op) \
      rsmu_sec_slave_error_log_reg_mp0_reg = (rsmu_sec_slave_error_log_reg_mp0_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_OP_MASK) | (rsmu_sec_slave_error_op << RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_OP_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_SET_RSMU_SEC_SLAVE_ERROR_OUTSTANDING(rsmu_sec_slave_error_log_reg_mp0_reg, rsmu_sec_slave_error_outstanding) \
      rsmu_sec_slave_error_log_reg_mp0_reg = (rsmu_sec_slave_error_log_reg_mp0_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_MASK) | (rsmu_sec_slave_error_outstanding << RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_slave_error_log_reg_mp0_t {
            unsigned int rsmu_sec_slave_error_vf        : RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_VF_SIZE;
            unsigned int rsmu_sec_slave_error_vf_id     : RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_VF_ID_SIZE;
            unsigned int rsmu_sec_slave_error_tlvl      : RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_TLVL_SIZE;
            unsigned int rsmu_sec_slave_error_initiatorid : RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_INITIATORID_SIZE;
            unsigned int rsmu_sec_slave_error_unitid    : RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_UNITID_SIZE;
            unsigned int                                : 3;
            unsigned int rsmu_sec_slave_error_op        : RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_OP_SIZE;
            unsigned int rsmu_sec_slave_error_outstanding : RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_SIZE;
      } rsmu_sec_slave_error_log_reg_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_slave_error_log_reg_mp0_t {
            unsigned int rsmu_sec_slave_error_outstanding : RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_SIZE;
            unsigned int rsmu_sec_slave_error_op        : RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_OP_SIZE;
            unsigned int                                : 3;
            unsigned int rsmu_sec_slave_error_unitid    : RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_UNITID_SIZE;
            unsigned int rsmu_sec_slave_error_initiatorid : RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_INITIATORID_SIZE;
            unsigned int rsmu_sec_slave_error_tlvl      : RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_TLVL_SIZE;
            unsigned int rsmu_sec_slave_error_vf_id     : RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_VF_ID_SIZE;
            unsigned int rsmu_sec_slave_error_vf        : RSMU_SEC_SLAVE_ERROR_LOG_REG_MP0_RSMU_SEC_SLAVE_ERROR_VF_SIZE;
      } rsmu_sec_slave_error_log_reg_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_slave_error_log_reg_mp0_t f;
} rsmu_sec_slave_error_log_reg_mp0_u;


/*
 * RSMU_MMIOSEC_SCRATCH_REG_0_MP0 struct
 */

#define RSMU_MMIOSEC_SCRATCH_REG_0_MP0_REG_SIZE         32
#define RSMU_MMIOSEC_SCRATCH_REG_0_MP0_RSMU_MMIOSEC_SCRATCH_REG_0_SIZE  32

#define RSMU_MMIOSEC_SCRATCH_REG_0_MP0_RSMU_MMIOSEC_SCRATCH_REG_0_SHIFT  0

#define RSMU_MMIOSEC_SCRATCH_REG_0_MP0_RSMU_MMIOSEC_SCRATCH_REG_0_MASK  0xffffffff

#define RSMU_MMIOSEC_SCRATCH_REG_0_MP0_MASK \
      (RSMU_MMIOSEC_SCRATCH_REG_0_MP0_RSMU_MMIOSEC_SCRATCH_REG_0_MASK)

#define RSMU_MMIOSEC_SCRATCH_REG_0_MP0_DEFAULT 0x00000000

#define RSMU_MMIOSEC_SCRATCH_REG_0_MP0_GET_RSMU_MMIOSEC_SCRATCH_REG_0(rsmu_mmiosec_scratch_reg_0_mp0) \
      ((rsmu_mmiosec_scratch_reg_0_mp0 & RSMU_MMIOSEC_SCRATCH_REG_0_MP0_RSMU_MMIOSEC_SCRATCH_REG_0_MASK) >> RSMU_MMIOSEC_SCRATCH_REG_0_MP0_RSMU_MMIOSEC_SCRATCH_REG_0_SHIFT)

#define RSMU_MMIOSEC_SCRATCH_REG_0_MP0_SET_RSMU_MMIOSEC_SCRATCH_REG_0(rsmu_mmiosec_scratch_reg_0_mp0_reg, rsmu_mmiosec_scratch_reg_0) \
      rsmu_mmiosec_scratch_reg_0_mp0_reg = (rsmu_mmiosec_scratch_reg_0_mp0_reg & ~RSMU_MMIOSEC_SCRATCH_REG_0_MP0_RSMU_MMIOSEC_SCRATCH_REG_0_MASK) | (rsmu_mmiosec_scratch_reg_0 << RSMU_MMIOSEC_SCRATCH_REG_0_MP0_RSMU_MMIOSEC_SCRATCH_REG_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_mmiosec_scratch_reg_0_mp0_t {
            unsigned int rsmu_mmiosec_scratch_reg_0     : RSMU_MMIOSEC_SCRATCH_REG_0_MP0_RSMU_MMIOSEC_SCRATCH_REG_0_SIZE;
      } rsmu_mmiosec_scratch_reg_0_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_mmiosec_scratch_reg_0_mp0_t {
            unsigned int rsmu_mmiosec_scratch_reg_0     : RSMU_MMIOSEC_SCRATCH_REG_0_MP0_RSMU_MMIOSEC_SCRATCH_REG_0_SIZE;
      } rsmu_mmiosec_scratch_reg_0_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_mmiosec_scratch_reg_0_mp0_t f;
} rsmu_mmiosec_scratch_reg_0_mp0_u;


/*
 * RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0 struct
 */

#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_REG_SIZE         32
#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_IP_SIZE  24
#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE_SIZE  1

#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_IP_SHIFT  0
#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE_SHIFT  24

#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_IP_MASK  0x00ffffff
#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE_MASK  0x01000000

#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_MASK \
      (RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_IP_MASK | \
      RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE_MASK)

#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_DEFAULT 0x00ffffff

#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_GET_RSMU_SEC_MASTER_TRUST_LEVEL_IP(rsmu_sec_master_trust_level_ip_mp0) \
      ((rsmu_sec_master_trust_level_ip_mp0 & RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_IP_MASK) >> RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_IP_SHIFT)
#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_GET_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE(rsmu_sec_master_trust_level_ip_mp0) \
      ((rsmu_sec_master_trust_level_ip_mp0 & RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE_MASK) >> RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE_SHIFT)

#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_SET_RSMU_SEC_MASTER_TRUST_LEVEL_IP(rsmu_sec_master_trust_level_ip_mp0_reg, rsmu_sec_master_trust_level_ip) \
      rsmu_sec_master_trust_level_ip_mp0_reg = (rsmu_sec_master_trust_level_ip_mp0_reg & ~RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_IP_MASK) | (rsmu_sec_master_trust_level_ip << RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_IP_SHIFT)
#define RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_SET_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE(rsmu_sec_master_trust_level_ip_mp0_reg, rsmu_sec_master_trust_level_override) \
      rsmu_sec_master_trust_level_ip_mp0_reg = (rsmu_sec_master_trust_level_ip_mp0_reg & ~RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE_MASK) | (rsmu_sec_master_trust_level_override << RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_master_trust_level_ip_mp0_t {
            unsigned int rsmu_sec_master_trust_level_ip : RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_IP_SIZE;
            unsigned int rsmu_sec_master_trust_level_override : RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE_SIZE;
            unsigned int                                : 7;
      } rsmu_sec_master_trust_level_ip_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_master_trust_level_ip_mp0_t {
            unsigned int                                : 7;
            unsigned int rsmu_sec_master_trust_level_override : RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_OVERRIDE_SIZE;
            unsigned int rsmu_sec_master_trust_level_ip : RSMU_SEC_MASTER_TRUST_LEVEL_IP_MP0_RSMU_SEC_MASTER_TRUST_LEVEL_IP_SIZE;
      } rsmu_sec_master_trust_level_ip_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_master_trust_level_ip_mp0_t f;
} rsmu_sec_master_trust_level_ip_mp0_u;


/*
 * RSMU_AEB_VALUE_0_MP0 struct
 */

#define RSMU_AEB_VALUE_0_MP0_REG_SIZE         32
#define RSMU_AEB_VALUE_0_MP0_RSMU_AEB_VALUE_0_SIZE  32

#define RSMU_AEB_VALUE_0_MP0_RSMU_AEB_VALUE_0_SHIFT  0

#define RSMU_AEB_VALUE_0_MP0_RSMU_AEB_VALUE_0_MASK  0xffffffff

#define RSMU_AEB_VALUE_0_MP0_MASK \
      (RSMU_AEB_VALUE_0_MP0_RSMU_AEB_VALUE_0_MASK)

#define RSMU_AEB_VALUE_0_MP0_DEFAULT   0x00000000

#define RSMU_AEB_VALUE_0_MP0_GET_RSMU_AEB_VALUE_0(rsmu_aeb_value_0_mp0) \
      ((rsmu_aeb_value_0_mp0 & RSMU_AEB_VALUE_0_MP0_RSMU_AEB_VALUE_0_MASK) >> RSMU_AEB_VALUE_0_MP0_RSMU_AEB_VALUE_0_SHIFT)

#define RSMU_AEB_VALUE_0_MP0_SET_RSMU_AEB_VALUE_0(rsmu_aeb_value_0_mp0_reg, rsmu_aeb_value_0) \
      rsmu_aeb_value_0_mp0_reg = (rsmu_aeb_value_0_mp0_reg & ~RSMU_AEB_VALUE_0_MP0_RSMU_AEB_VALUE_0_MASK) | (rsmu_aeb_value_0 << RSMU_AEB_VALUE_0_MP0_RSMU_AEB_VALUE_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_aeb_value_0_mp0_t {
            unsigned int rsmu_aeb_value_0               : RSMU_AEB_VALUE_0_MP0_RSMU_AEB_VALUE_0_SIZE;
      } rsmu_aeb_value_0_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_aeb_value_0_mp0_t {
            unsigned int rsmu_aeb_value_0               : RSMU_AEB_VALUE_0_MP0_RSMU_AEB_VALUE_0_SIZE;
      } rsmu_aeb_value_0_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_aeb_value_0_mp0_t f;
} rsmu_aeb_value_0_mp0_u;


/*
 * RSMU_AEB_VALUE_1_MP0 struct
 */

#define RSMU_AEB_VALUE_1_MP0_REG_SIZE         32
#define RSMU_AEB_VALUE_1_MP0_RSMU_AEB_VALUE_1_SIZE  32

#define RSMU_AEB_VALUE_1_MP0_RSMU_AEB_VALUE_1_SHIFT  0

#define RSMU_AEB_VALUE_1_MP0_RSMU_AEB_VALUE_1_MASK  0xffffffff

#define RSMU_AEB_VALUE_1_MP0_MASK \
      (RSMU_AEB_VALUE_1_MP0_RSMU_AEB_VALUE_1_MASK)

#define RSMU_AEB_VALUE_1_MP0_DEFAULT   0x00000000

#define RSMU_AEB_VALUE_1_MP0_GET_RSMU_AEB_VALUE_1(rsmu_aeb_value_1_mp0) \
      ((rsmu_aeb_value_1_mp0 & RSMU_AEB_VALUE_1_MP0_RSMU_AEB_VALUE_1_MASK) >> RSMU_AEB_VALUE_1_MP0_RSMU_AEB_VALUE_1_SHIFT)

#define RSMU_AEB_VALUE_1_MP0_SET_RSMU_AEB_VALUE_1(rsmu_aeb_value_1_mp0_reg, rsmu_aeb_value_1) \
      rsmu_aeb_value_1_mp0_reg = (rsmu_aeb_value_1_mp0_reg & ~RSMU_AEB_VALUE_1_MP0_RSMU_AEB_VALUE_1_MASK) | (rsmu_aeb_value_1 << RSMU_AEB_VALUE_1_MP0_RSMU_AEB_VALUE_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_aeb_value_1_mp0_t {
            unsigned int rsmu_aeb_value_1               : RSMU_AEB_VALUE_1_MP0_RSMU_AEB_VALUE_1_SIZE;
      } rsmu_aeb_value_1_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_aeb_value_1_mp0_t {
            unsigned int rsmu_aeb_value_1               : RSMU_AEB_VALUE_1_MP0_RSMU_AEB_VALUE_1_SIZE;
      } rsmu_aeb_value_1_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_aeb_value_1_mp0_t f;
} rsmu_aeb_value_1_mp0_u;


/*
 * RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0 struct
 */

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_REG_SIZE         32
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU_SIZE  10
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU_SIZE  3
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU_SIZE  7
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU_SIZE  10
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_OP_RSMU_SIZE  1
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU_SIZE  1

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU_SHIFT  0
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU_SHIFT  10
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU_SHIFT  13
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU_SHIFT  20
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_OP_RSMU_SHIFT  30
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU_SHIFT  31

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU_MASK  0x000003ff
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU_MASK  0x00001c00
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU_MASK  0x000fe000
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU_MASK  0x3ff00000
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_OP_RSMU_MASK  0x40000000
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU_MASK  0x80000000

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_MASK \
      (RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_OP_RSMU_MASK | \
      RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU_MASK)

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_DEFAULT 0x00000000

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_GET_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mp0) \
      ((rsmu_sec_slave_error_log_addr_reg_rsmu_mp0 & RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_GET_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mp0) \
      ((rsmu_sec_slave_error_log_addr_reg_rsmu_mp0 & RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_GET_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mp0) \
      ((rsmu_sec_slave_error_log_addr_reg_rsmu_mp0 & RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_GET_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mp0) \
      ((rsmu_sec_slave_error_log_addr_reg_rsmu_mp0 & RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_GET_RSMU_SEC_SLAVE_ERROR_OP_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mp0) \
      ((rsmu_sec_slave_error_log_addr_reg_rsmu_mp0 & RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_OP_RSMU_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_OP_RSMU_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_GET_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mp0) \
      ((rsmu_sec_slave_error_log_addr_reg_rsmu_mp0 & RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU_MASK) >> RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU_SHIFT)

#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_SET_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_reg, rsmu_sec_slave_error_addr_rsmu) \
      rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_reg = (rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU_MASK) | (rsmu_sec_slave_error_addr_rsmu << RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_SET_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_reg, rsmu_sec_slave_error_tlvl_rsmu) \
      rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_reg = (rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU_MASK) | (rsmu_sec_slave_error_tlvl_rsmu << RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_SET_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_reg, rsmu_sec_slave_error_unitid_rsmu) \
      rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_reg = (rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU_MASK) | (rsmu_sec_slave_error_unitid_rsmu << RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_SET_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_reg, rsmu_sec_slave_error_initiatorid_rsmu) \
      rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_reg = (rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU_MASK) | (rsmu_sec_slave_error_initiatorid_rsmu << RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_SET_RSMU_SEC_SLAVE_ERROR_OP_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_reg, rsmu_sec_slave_error_op_rsmu) \
      rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_reg = (rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_OP_RSMU_MASK) | (rsmu_sec_slave_error_op_rsmu << RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_OP_RSMU_SHIFT)
#define RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_SET_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU(rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_reg, rsmu_sec_slave_error_outstanding_rsmu) \
      rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_reg = (rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_reg & ~RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU_MASK) | (rsmu_sec_slave_error_outstanding_rsmu << RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_t {
            unsigned int rsmu_sec_slave_error_addr_rsmu : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU_SIZE;
            unsigned int rsmu_sec_slave_error_tlvl_rsmu : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU_SIZE;
            unsigned int rsmu_sec_slave_error_unitid_rsmu : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU_SIZE;
            unsigned int rsmu_sec_slave_error_initiatorid_rsmu : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU_SIZE;
            unsigned int rsmu_sec_slave_error_op_rsmu   : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_OP_RSMU_SIZE;
            unsigned int rsmu_sec_slave_error_outstanding_rsmu : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU_SIZE;
      } rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_t {
            unsigned int rsmu_sec_slave_error_outstanding_rsmu : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_OUTSTANDING_RSMU_SIZE;
            unsigned int rsmu_sec_slave_error_op_rsmu   : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_OP_RSMU_SIZE;
            unsigned int rsmu_sec_slave_error_initiatorid_rsmu : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_INITIATORID_RSMU_SIZE;
            unsigned int rsmu_sec_slave_error_unitid_rsmu : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_UNITID_RSMU_SIZE;
            unsigned int rsmu_sec_slave_error_tlvl_rsmu : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_TLVL_RSMU_SIZE;
            unsigned int rsmu_sec_slave_error_addr_rsmu : RSMU_SEC_SLAVE_ERROR_LOG_ADDR_REG_RSMU_MP0_RSMU_SEC_SLAVE_ERROR_ADDR_RSMU_SIZE;
      } rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_t f;
} rsmu_sec_slave_error_log_addr_reg_rsmu_mp0_u;


/*
 * RSMU_SEC_SLAVE_RANGE_DISABLE_MP0 struct
 */

#define RSMU_SEC_SLAVE_RANGE_DISABLE_MP0_REG_SIZE         32
#define RSMU_SEC_SLAVE_RANGE_DISABLE_MP0_RSMU_SEC_SLAVE_RANGE_DISABLE_SIZE  1

#define RSMU_SEC_SLAVE_RANGE_DISABLE_MP0_RSMU_SEC_SLAVE_RANGE_DISABLE_SHIFT  0

#define RSMU_SEC_SLAVE_RANGE_DISABLE_MP0_RSMU_SEC_SLAVE_RANGE_DISABLE_MASK  0x00000001

#define RSMU_SEC_SLAVE_RANGE_DISABLE_MP0_MASK \
      (RSMU_SEC_SLAVE_RANGE_DISABLE_MP0_RSMU_SEC_SLAVE_RANGE_DISABLE_MASK)

#define RSMU_SEC_SLAVE_RANGE_DISABLE_MP0_DEFAULT 0x00000000

#define RSMU_SEC_SLAVE_RANGE_DISABLE_MP0_GET_RSMU_SEC_SLAVE_RANGE_DISABLE(rsmu_sec_slave_range_disable_mp0) \
      ((rsmu_sec_slave_range_disable_mp0 & RSMU_SEC_SLAVE_RANGE_DISABLE_MP0_RSMU_SEC_SLAVE_RANGE_DISABLE_MASK) >> RSMU_SEC_SLAVE_RANGE_DISABLE_MP0_RSMU_SEC_SLAVE_RANGE_DISABLE_SHIFT)

#define RSMU_SEC_SLAVE_RANGE_DISABLE_MP0_SET_RSMU_SEC_SLAVE_RANGE_DISABLE(rsmu_sec_slave_range_disable_mp0_reg, rsmu_sec_slave_range_disable) \
      rsmu_sec_slave_range_disable_mp0_reg = (rsmu_sec_slave_range_disable_mp0_reg & ~RSMU_SEC_SLAVE_RANGE_DISABLE_MP0_RSMU_SEC_SLAVE_RANGE_DISABLE_MASK) | (rsmu_sec_slave_range_disable << RSMU_SEC_SLAVE_RANGE_DISABLE_MP0_RSMU_SEC_SLAVE_RANGE_DISABLE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct rsmu_sec_slave_range_disable_mp0_t {
            unsigned int rsmu_sec_slave_range_disable   : RSMU_SEC_SLAVE_RANGE_DISABLE_MP0_RSMU_SEC_SLAVE_RANGE_DISABLE_SIZE;
            unsigned int                                : 31;
      } rsmu_sec_slave_range_disable_mp0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct rsmu_sec_slave_range_disable_mp0_t {
            unsigned int                                : 31;
            unsigned int rsmu_sec_slave_range_disable   : RSMU_SEC_SLAVE_RANGE_DISABLE_MP0_RSMU_SEC_SLAVE_RANGE_DISABLE_SIZE;
      } rsmu_sec_slave_range_disable_mp0_t;

#endif

typedef union {
     unsigned int val : 32;
          rsmu_sec_slave_range_disable_mp0_t f;
} rsmu_sec_slave_range_disable_mp0_u;


#endif

