// Copyright (c) 1994 - 2021 Advanced Micro Devices, Inc. All rights reserved. 
 #if !defined (_MP1_SMNIF_FIDDLE_H)
#define _MP1_SMNIF_FIDDLE_H
 /*****************************************************************************************************************
 *
 *  mp1_smnif_reg.h
 *
 *  Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif

 /*******************************************************
 * Values
 *******************************************************/

 /*******************************************************
 * Structures
 *******************************************************/

/*
 * MP1_SMNIF_TLB_0 struct
 */

#define MP1_SMNIF_TLB_0_REG_SIZE         32
#define MP1_SMNIF_TLB_0_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_0_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_0_SMN_ADDR_MASK   0x0000ffff

#define MP1_SMNIF_TLB_0_MASK \
      (MP1_SMNIF_TLB_0_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_0_DEFAULT        0x00000000

#define MP1_SMNIF_TLB_0_GET_SMN_ADDR(mp1_smnif_tlb_0) \
      ((mp1_smnif_tlb_0 & MP1_SMNIF_TLB_0_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_0_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_0_SET_SMN_ADDR(mp1_smnif_tlb_0_reg, smn_addr) \
      mp1_smnif_tlb_0_reg = (mp1_smnif_tlb_0_reg & ~MP1_SMNIF_TLB_0_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_0_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_0_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_0_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_0_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_0_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_0_t f;
} mp1_smnif_tlb_0_u;


/*
 * MP1_SMNIF_TLB_1 struct
 */

#define MP1_SMNIF_TLB_1_REG_SIZE         32
#define MP1_SMNIF_TLB_1_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_1_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_1_SMN_ADDR_MASK   0x0000ffff

#define MP1_SMNIF_TLB_1_MASK \
      (MP1_SMNIF_TLB_1_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_1_DEFAULT        0x00000001

#define MP1_SMNIF_TLB_1_GET_SMN_ADDR(mp1_smnif_tlb_1) \
      ((mp1_smnif_tlb_1 & MP1_SMNIF_TLB_1_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_1_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_1_SET_SMN_ADDR(mp1_smnif_tlb_1_reg, smn_addr) \
      mp1_smnif_tlb_1_reg = (mp1_smnif_tlb_1_reg & ~MP1_SMNIF_TLB_1_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_1_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_1_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_1_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_1_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_1_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_1_t f;
} mp1_smnif_tlb_1_u;


/*
 * MP1_SMNIF_TLB_2 struct
 */

#define MP1_SMNIF_TLB_2_REG_SIZE         32
#define MP1_SMNIF_TLB_2_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_2_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_2_SMN_ADDR_MASK   0x0000ffff

#define MP1_SMNIF_TLB_2_MASK \
      (MP1_SMNIF_TLB_2_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_2_DEFAULT        0x00000002

#define MP1_SMNIF_TLB_2_GET_SMN_ADDR(mp1_smnif_tlb_2) \
      ((mp1_smnif_tlb_2 & MP1_SMNIF_TLB_2_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_2_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_2_SET_SMN_ADDR(mp1_smnif_tlb_2_reg, smn_addr) \
      mp1_smnif_tlb_2_reg = (mp1_smnif_tlb_2_reg & ~MP1_SMNIF_TLB_2_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_2_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_2_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_2_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_2_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_2_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_2_t f;
} mp1_smnif_tlb_2_u;


/*
 * MP1_SMNIF_TLB_3 struct
 */

#define MP1_SMNIF_TLB_3_REG_SIZE         32
#define MP1_SMNIF_TLB_3_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_3_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_3_SMN_ADDR_MASK   0x0000ffff

#define MP1_SMNIF_TLB_3_MASK \
      (MP1_SMNIF_TLB_3_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_3_DEFAULT        0x00000003

#define MP1_SMNIF_TLB_3_GET_SMN_ADDR(mp1_smnif_tlb_3) \
      ((mp1_smnif_tlb_3 & MP1_SMNIF_TLB_3_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_3_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_3_SET_SMN_ADDR(mp1_smnif_tlb_3_reg, smn_addr) \
      mp1_smnif_tlb_3_reg = (mp1_smnif_tlb_3_reg & ~MP1_SMNIF_TLB_3_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_3_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_3_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_3_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_3_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_3_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_3_t f;
} mp1_smnif_tlb_3_u;


/*
 * MP1_SMNIF_TLB_4 struct
 */

#define MP1_SMNIF_TLB_4_REG_SIZE         32
#define MP1_SMNIF_TLB_4_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_4_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_4_SMN_ADDR_MASK   0x0000ffff

#define MP1_SMNIF_TLB_4_MASK \
      (MP1_SMNIF_TLB_4_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_4_DEFAULT        0x00000004

#define MP1_SMNIF_TLB_4_GET_SMN_ADDR(mp1_smnif_tlb_4) \
      ((mp1_smnif_tlb_4 & MP1_SMNIF_TLB_4_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_4_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_4_SET_SMN_ADDR(mp1_smnif_tlb_4_reg, smn_addr) \
      mp1_smnif_tlb_4_reg = (mp1_smnif_tlb_4_reg & ~MP1_SMNIF_TLB_4_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_4_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_4_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_4_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_4_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_4_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_4_t f;
} mp1_smnif_tlb_4_u;


/*
 * MP1_SMNIF_TLB_5 struct
 */

#define MP1_SMNIF_TLB_5_REG_SIZE         32
#define MP1_SMNIF_TLB_5_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_5_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_5_SMN_ADDR_MASK   0x0000ffff

#define MP1_SMNIF_TLB_5_MASK \
      (MP1_SMNIF_TLB_5_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_5_DEFAULT        0x00000005

#define MP1_SMNIF_TLB_5_GET_SMN_ADDR(mp1_smnif_tlb_5) \
      ((mp1_smnif_tlb_5 & MP1_SMNIF_TLB_5_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_5_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_5_SET_SMN_ADDR(mp1_smnif_tlb_5_reg, smn_addr) \
      mp1_smnif_tlb_5_reg = (mp1_smnif_tlb_5_reg & ~MP1_SMNIF_TLB_5_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_5_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_5_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_5_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_5_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_5_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_5_t f;
} mp1_smnif_tlb_5_u;


/*
 * MP1_SMNIF_TLB_6 struct
 */

#define MP1_SMNIF_TLB_6_REG_SIZE         32
#define MP1_SMNIF_TLB_6_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_6_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_6_SMN_ADDR_MASK   0x0000ffff

#define MP1_SMNIF_TLB_6_MASK \
      (MP1_SMNIF_TLB_6_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_6_DEFAULT        0x00000006

#define MP1_SMNIF_TLB_6_GET_SMN_ADDR(mp1_smnif_tlb_6) \
      ((mp1_smnif_tlb_6 & MP1_SMNIF_TLB_6_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_6_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_6_SET_SMN_ADDR(mp1_smnif_tlb_6_reg, smn_addr) \
      mp1_smnif_tlb_6_reg = (mp1_smnif_tlb_6_reg & ~MP1_SMNIF_TLB_6_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_6_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_6_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_6_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_6_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_6_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_6_t f;
} mp1_smnif_tlb_6_u;


/*
 * MP1_SMNIF_TLB_7 struct
 */

#define MP1_SMNIF_TLB_7_REG_SIZE         32
#define MP1_SMNIF_TLB_7_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_7_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_7_SMN_ADDR_MASK   0x0000ffff

#define MP1_SMNIF_TLB_7_MASK \
      (MP1_SMNIF_TLB_7_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_7_DEFAULT        0x00000007

#define MP1_SMNIF_TLB_7_GET_SMN_ADDR(mp1_smnif_tlb_7) \
      ((mp1_smnif_tlb_7 & MP1_SMNIF_TLB_7_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_7_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_7_SET_SMN_ADDR(mp1_smnif_tlb_7_reg, smn_addr) \
      mp1_smnif_tlb_7_reg = (mp1_smnif_tlb_7_reg & ~MP1_SMNIF_TLB_7_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_7_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_7_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_7_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_7_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_7_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_7_t f;
} mp1_smnif_tlb_7_u;


/*
 * MP1_SMNIF_TLB_8 struct
 */

#define MP1_SMNIF_TLB_8_REG_SIZE         32
#define MP1_SMNIF_TLB_8_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_8_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_8_SMN_ADDR_MASK   0x0000ffff

#define MP1_SMNIF_TLB_8_MASK \
      (MP1_SMNIF_TLB_8_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_8_DEFAULT        0x00000008

#define MP1_SMNIF_TLB_8_GET_SMN_ADDR(mp1_smnif_tlb_8) \
      ((mp1_smnif_tlb_8 & MP1_SMNIF_TLB_8_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_8_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_8_SET_SMN_ADDR(mp1_smnif_tlb_8_reg, smn_addr) \
      mp1_smnif_tlb_8_reg = (mp1_smnif_tlb_8_reg & ~MP1_SMNIF_TLB_8_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_8_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_8_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_8_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_8_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_8_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_8_t f;
} mp1_smnif_tlb_8_u;


/*
 * MP1_SMNIF_TLB_9 struct
 */

#define MP1_SMNIF_TLB_9_REG_SIZE         32
#define MP1_SMNIF_TLB_9_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_9_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_9_SMN_ADDR_MASK   0x0000ffff

#define MP1_SMNIF_TLB_9_MASK \
      (MP1_SMNIF_TLB_9_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_9_DEFAULT        0x00000009

#define MP1_SMNIF_TLB_9_GET_SMN_ADDR(mp1_smnif_tlb_9) \
      ((mp1_smnif_tlb_9 & MP1_SMNIF_TLB_9_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_9_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_9_SET_SMN_ADDR(mp1_smnif_tlb_9_reg, smn_addr) \
      mp1_smnif_tlb_9_reg = (mp1_smnif_tlb_9_reg & ~MP1_SMNIF_TLB_9_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_9_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_9_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_9_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_9_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_9_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_9_t f;
} mp1_smnif_tlb_9_u;


/*
 * MP1_SMNIF_TLB_10 struct
 */

#define MP1_SMNIF_TLB_10_REG_SIZE         32
#define MP1_SMNIF_TLB_10_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_10_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_10_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_10_MASK \
      (MP1_SMNIF_TLB_10_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_10_DEFAULT       0x0000000a

#define MP1_SMNIF_TLB_10_GET_SMN_ADDR(mp1_smnif_tlb_10) \
      ((mp1_smnif_tlb_10 & MP1_SMNIF_TLB_10_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_10_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_10_SET_SMN_ADDR(mp1_smnif_tlb_10_reg, smn_addr) \
      mp1_smnif_tlb_10_reg = (mp1_smnif_tlb_10_reg & ~MP1_SMNIF_TLB_10_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_10_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_10_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_10_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_10_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_10_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_10_t f;
} mp1_smnif_tlb_10_u;


/*
 * MP1_SMNIF_TLB_11 struct
 */

#define MP1_SMNIF_TLB_11_REG_SIZE         32
#define MP1_SMNIF_TLB_11_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_11_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_11_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_11_MASK \
      (MP1_SMNIF_TLB_11_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_11_DEFAULT       0x0000000b

#define MP1_SMNIF_TLB_11_GET_SMN_ADDR(mp1_smnif_tlb_11) \
      ((mp1_smnif_tlb_11 & MP1_SMNIF_TLB_11_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_11_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_11_SET_SMN_ADDR(mp1_smnif_tlb_11_reg, smn_addr) \
      mp1_smnif_tlb_11_reg = (mp1_smnif_tlb_11_reg & ~MP1_SMNIF_TLB_11_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_11_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_11_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_11_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_11_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_11_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_11_t f;
} mp1_smnif_tlb_11_u;


/*
 * MP1_SMNIF_TLB_12 struct
 */

#define MP1_SMNIF_TLB_12_REG_SIZE         32
#define MP1_SMNIF_TLB_12_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_12_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_12_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_12_MASK \
      (MP1_SMNIF_TLB_12_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_12_DEFAULT       0x0000000c

#define MP1_SMNIF_TLB_12_GET_SMN_ADDR(mp1_smnif_tlb_12) \
      ((mp1_smnif_tlb_12 & MP1_SMNIF_TLB_12_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_12_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_12_SET_SMN_ADDR(mp1_smnif_tlb_12_reg, smn_addr) \
      mp1_smnif_tlb_12_reg = (mp1_smnif_tlb_12_reg & ~MP1_SMNIF_TLB_12_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_12_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_12_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_12_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_12_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_12_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_12_t f;
} mp1_smnif_tlb_12_u;


/*
 * MP1_SMNIF_TLB_13 struct
 */

#define MP1_SMNIF_TLB_13_REG_SIZE         32
#define MP1_SMNIF_TLB_13_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_13_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_13_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_13_MASK \
      (MP1_SMNIF_TLB_13_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_13_DEFAULT       0x0000000d

#define MP1_SMNIF_TLB_13_GET_SMN_ADDR(mp1_smnif_tlb_13) \
      ((mp1_smnif_tlb_13 & MP1_SMNIF_TLB_13_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_13_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_13_SET_SMN_ADDR(mp1_smnif_tlb_13_reg, smn_addr) \
      mp1_smnif_tlb_13_reg = (mp1_smnif_tlb_13_reg & ~MP1_SMNIF_TLB_13_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_13_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_13_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_13_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_13_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_13_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_13_t f;
} mp1_smnif_tlb_13_u;


/*
 * MP1_SMNIF_TLB_14 struct
 */

#define MP1_SMNIF_TLB_14_REG_SIZE         32
#define MP1_SMNIF_TLB_14_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_14_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_14_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_14_MASK \
      (MP1_SMNIF_TLB_14_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_14_DEFAULT       0x0000000e

#define MP1_SMNIF_TLB_14_GET_SMN_ADDR(mp1_smnif_tlb_14) \
      ((mp1_smnif_tlb_14 & MP1_SMNIF_TLB_14_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_14_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_14_SET_SMN_ADDR(mp1_smnif_tlb_14_reg, smn_addr) \
      mp1_smnif_tlb_14_reg = (mp1_smnif_tlb_14_reg & ~MP1_SMNIF_TLB_14_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_14_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_14_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_14_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_14_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_14_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_14_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_14_t f;
} mp1_smnif_tlb_14_u;


/*
 * MP1_SMNIF_TLB_15 struct
 */

#define MP1_SMNIF_TLB_15_REG_SIZE         32
#define MP1_SMNIF_TLB_15_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_15_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_15_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_15_MASK \
      (MP1_SMNIF_TLB_15_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_15_DEFAULT       0x0000000f

#define MP1_SMNIF_TLB_15_GET_SMN_ADDR(mp1_smnif_tlb_15) \
      ((mp1_smnif_tlb_15 & MP1_SMNIF_TLB_15_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_15_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_15_SET_SMN_ADDR(mp1_smnif_tlb_15_reg, smn_addr) \
      mp1_smnif_tlb_15_reg = (mp1_smnif_tlb_15_reg & ~MP1_SMNIF_TLB_15_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_15_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_15_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_15_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_15_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_15_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_15_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_15_t f;
} mp1_smnif_tlb_15_u;


/*
 * MP1_SMNIF_TLB_16 struct
 */

#define MP1_SMNIF_TLB_16_REG_SIZE         32
#define MP1_SMNIF_TLB_16_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_16_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_16_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_16_MASK \
      (MP1_SMNIF_TLB_16_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_16_DEFAULT       0x00000010

#define MP1_SMNIF_TLB_16_GET_SMN_ADDR(mp1_smnif_tlb_16) \
      ((mp1_smnif_tlb_16 & MP1_SMNIF_TLB_16_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_16_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_16_SET_SMN_ADDR(mp1_smnif_tlb_16_reg, smn_addr) \
      mp1_smnif_tlb_16_reg = (mp1_smnif_tlb_16_reg & ~MP1_SMNIF_TLB_16_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_16_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_16_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_16_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_16_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_16_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_16_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_16_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_16_t f;
} mp1_smnif_tlb_16_u;


/*
 * MP1_SMNIF_TLB_17 struct
 */

#define MP1_SMNIF_TLB_17_REG_SIZE         32
#define MP1_SMNIF_TLB_17_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_17_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_17_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_17_MASK \
      (MP1_SMNIF_TLB_17_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_17_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_17_GET_SMN_ADDR(mp1_smnif_tlb_17) \
      ((mp1_smnif_tlb_17 & MP1_SMNIF_TLB_17_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_17_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_17_SET_SMN_ADDR(mp1_smnif_tlb_17_reg, smn_addr) \
      mp1_smnif_tlb_17_reg = (mp1_smnif_tlb_17_reg & ~MP1_SMNIF_TLB_17_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_17_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_17_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_17_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_17_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_17_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_17_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_17_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_17_t f;
} mp1_smnif_tlb_17_u;


/*
 * MP1_SMNIF_TLB_18 struct
 */

#define MP1_SMNIF_TLB_18_REG_SIZE         32
#define MP1_SMNIF_TLB_18_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_18_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_18_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_18_MASK \
      (MP1_SMNIF_TLB_18_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_18_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_18_GET_SMN_ADDR(mp1_smnif_tlb_18) \
      ((mp1_smnif_tlb_18 & MP1_SMNIF_TLB_18_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_18_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_18_SET_SMN_ADDR(mp1_smnif_tlb_18_reg, smn_addr) \
      mp1_smnif_tlb_18_reg = (mp1_smnif_tlb_18_reg & ~MP1_SMNIF_TLB_18_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_18_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_18_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_18_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_18_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_18_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_18_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_18_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_18_t f;
} mp1_smnif_tlb_18_u;


/*
 * MP1_SMNIF_TLB_19 struct
 */

#define MP1_SMNIF_TLB_19_REG_SIZE         32
#define MP1_SMNIF_TLB_19_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_19_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_19_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_19_MASK \
      (MP1_SMNIF_TLB_19_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_19_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_19_GET_SMN_ADDR(mp1_smnif_tlb_19) \
      ((mp1_smnif_tlb_19 & MP1_SMNIF_TLB_19_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_19_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_19_SET_SMN_ADDR(mp1_smnif_tlb_19_reg, smn_addr) \
      mp1_smnif_tlb_19_reg = (mp1_smnif_tlb_19_reg & ~MP1_SMNIF_TLB_19_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_19_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_19_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_19_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_19_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_19_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_19_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_19_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_19_t f;
} mp1_smnif_tlb_19_u;


/*
 * MP1_SMNIF_TLB_20 struct
 */

#define MP1_SMNIF_TLB_20_REG_SIZE         32
#define MP1_SMNIF_TLB_20_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_20_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_20_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_20_MASK \
      (MP1_SMNIF_TLB_20_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_20_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_20_GET_SMN_ADDR(mp1_smnif_tlb_20) \
      ((mp1_smnif_tlb_20 & MP1_SMNIF_TLB_20_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_20_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_20_SET_SMN_ADDR(mp1_smnif_tlb_20_reg, smn_addr) \
      mp1_smnif_tlb_20_reg = (mp1_smnif_tlb_20_reg & ~MP1_SMNIF_TLB_20_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_20_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_20_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_20_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_20_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_20_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_20_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_20_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_20_t f;
} mp1_smnif_tlb_20_u;


/*
 * MP1_SMNIF_TLB_21 struct
 */

#define MP1_SMNIF_TLB_21_REG_SIZE         32
#define MP1_SMNIF_TLB_21_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_21_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_21_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_21_MASK \
      (MP1_SMNIF_TLB_21_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_21_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_21_GET_SMN_ADDR(mp1_smnif_tlb_21) \
      ((mp1_smnif_tlb_21 & MP1_SMNIF_TLB_21_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_21_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_21_SET_SMN_ADDR(mp1_smnif_tlb_21_reg, smn_addr) \
      mp1_smnif_tlb_21_reg = (mp1_smnif_tlb_21_reg & ~MP1_SMNIF_TLB_21_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_21_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_21_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_21_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_21_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_21_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_21_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_21_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_21_t f;
} mp1_smnif_tlb_21_u;


/*
 * MP1_SMNIF_TLB_22 struct
 */

#define MP1_SMNIF_TLB_22_REG_SIZE         32
#define MP1_SMNIF_TLB_22_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_22_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_22_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_22_MASK \
      (MP1_SMNIF_TLB_22_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_22_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_22_GET_SMN_ADDR(mp1_smnif_tlb_22) \
      ((mp1_smnif_tlb_22 & MP1_SMNIF_TLB_22_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_22_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_22_SET_SMN_ADDR(mp1_smnif_tlb_22_reg, smn_addr) \
      mp1_smnif_tlb_22_reg = (mp1_smnif_tlb_22_reg & ~MP1_SMNIF_TLB_22_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_22_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_22_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_22_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_22_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_22_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_22_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_22_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_22_t f;
} mp1_smnif_tlb_22_u;


/*
 * MP1_SMNIF_TLB_23 struct
 */

#define MP1_SMNIF_TLB_23_REG_SIZE         32
#define MP1_SMNIF_TLB_23_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_23_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_23_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_23_MASK \
      (MP1_SMNIF_TLB_23_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_23_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_23_GET_SMN_ADDR(mp1_smnif_tlb_23) \
      ((mp1_smnif_tlb_23 & MP1_SMNIF_TLB_23_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_23_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_23_SET_SMN_ADDR(mp1_smnif_tlb_23_reg, smn_addr) \
      mp1_smnif_tlb_23_reg = (mp1_smnif_tlb_23_reg & ~MP1_SMNIF_TLB_23_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_23_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_23_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_23_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_23_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_23_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_23_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_23_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_23_t f;
} mp1_smnif_tlb_23_u;


/*
 * MP1_SMNIF_TLB_24 struct
 */

#define MP1_SMNIF_TLB_24_REG_SIZE         32
#define MP1_SMNIF_TLB_24_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_24_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_24_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_24_MASK \
      (MP1_SMNIF_TLB_24_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_24_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_24_GET_SMN_ADDR(mp1_smnif_tlb_24) \
      ((mp1_smnif_tlb_24 & MP1_SMNIF_TLB_24_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_24_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_24_SET_SMN_ADDR(mp1_smnif_tlb_24_reg, smn_addr) \
      mp1_smnif_tlb_24_reg = (mp1_smnif_tlb_24_reg & ~MP1_SMNIF_TLB_24_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_24_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_24_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_24_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_24_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_24_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_24_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_24_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_24_t f;
} mp1_smnif_tlb_24_u;


/*
 * MP1_SMNIF_TLB_25 struct
 */

#define MP1_SMNIF_TLB_25_REG_SIZE         32
#define MP1_SMNIF_TLB_25_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_25_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_25_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_25_MASK \
      (MP1_SMNIF_TLB_25_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_25_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_25_GET_SMN_ADDR(mp1_smnif_tlb_25) \
      ((mp1_smnif_tlb_25 & MP1_SMNIF_TLB_25_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_25_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_25_SET_SMN_ADDR(mp1_smnif_tlb_25_reg, smn_addr) \
      mp1_smnif_tlb_25_reg = (mp1_smnif_tlb_25_reg & ~MP1_SMNIF_TLB_25_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_25_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_25_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_25_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_25_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_25_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_25_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_25_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_25_t f;
} mp1_smnif_tlb_25_u;


/*
 * MP1_SMNIF_TLB_26 struct
 */

#define MP1_SMNIF_TLB_26_REG_SIZE         32
#define MP1_SMNIF_TLB_26_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_26_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_26_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_26_MASK \
      (MP1_SMNIF_TLB_26_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_26_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_26_GET_SMN_ADDR(mp1_smnif_tlb_26) \
      ((mp1_smnif_tlb_26 & MP1_SMNIF_TLB_26_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_26_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_26_SET_SMN_ADDR(mp1_smnif_tlb_26_reg, smn_addr) \
      mp1_smnif_tlb_26_reg = (mp1_smnif_tlb_26_reg & ~MP1_SMNIF_TLB_26_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_26_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_26_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_26_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_26_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_26_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_26_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_26_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_26_t f;
} mp1_smnif_tlb_26_u;


/*
 * MP1_SMNIF_TLB_27 struct
 */

#define MP1_SMNIF_TLB_27_REG_SIZE         32
#define MP1_SMNIF_TLB_27_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_27_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_27_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_27_MASK \
      (MP1_SMNIF_TLB_27_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_27_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_27_GET_SMN_ADDR(mp1_smnif_tlb_27) \
      ((mp1_smnif_tlb_27 & MP1_SMNIF_TLB_27_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_27_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_27_SET_SMN_ADDR(mp1_smnif_tlb_27_reg, smn_addr) \
      mp1_smnif_tlb_27_reg = (mp1_smnif_tlb_27_reg & ~MP1_SMNIF_TLB_27_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_27_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_27_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_27_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_27_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_27_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_27_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_27_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_27_t f;
} mp1_smnif_tlb_27_u;


/*
 * MP1_SMNIF_TLB_28 struct
 */

#define MP1_SMNIF_TLB_28_REG_SIZE         32
#define MP1_SMNIF_TLB_28_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_28_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_28_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_28_MASK \
      (MP1_SMNIF_TLB_28_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_28_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_28_GET_SMN_ADDR(mp1_smnif_tlb_28) \
      ((mp1_smnif_tlb_28 & MP1_SMNIF_TLB_28_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_28_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_28_SET_SMN_ADDR(mp1_smnif_tlb_28_reg, smn_addr) \
      mp1_smnif_tlb_28_reg = (mp1_smnif_tlb_28_reg & ~MP1_SMNIF_TLB_28_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_28_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_28_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_28_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_28_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_28_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_28_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_28_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_28_t f;
} mp1_smnif_tlb_28_u;


/*
 * MP1_SMNIF_TLB_29 struct
 */

#define MP1_SMNIF_TLB_29_REG_SIZE         32
#define MP1_SMNIF_TLB_29_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_29_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_29_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_29_MASK \
      (MP1_SMNIF_TLB_29_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_29_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_29_GET_SMN_ADDR(mp1_smnif_tlb_29) \
      ((mp1_smnif_tlb_29 & MP1_SMNIF_TLB_29_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_29_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_29_SET_SMN_ADDR(mp1_smnif_tlb_29_reg, smn_addr) \
      mp1_smnif_tlb_29_reg = (mp1_smnif_tlb_29_reg & ~MP1_SMNIF_TLB_29_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_29_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_29_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_29_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_29_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_29_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_29_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_29_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_29_t f;
} mp1_smnif_tlb_29_u;


/*
 * MP1_SMNIF_TLB_30 struct
 */

#define MP1_SMNIF_TLB_30_REG_SIZE         32
#define MP1_SMNIF_TLB_30_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_30_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_30_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_30_MASK \
      (MP1_SMNIF_TLB_30_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_30_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_30_GET_SMN_ADDR(mp1_smnif_tlb_30) \
      ((mp1_smnif_tlb_30 & MP1_SMNIF_TLB_30_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_30_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_30_SET_SMN_ADDR(mp1_smnif_tlb_30_reg, smn_addr) \
      mp1_smnif_tlb_30_reg = (mp1_smnif_tlb_30_reg & ~MP1_SMNIF_TLB_30_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_30_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_30_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_30_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_30_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_30_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_30_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_30_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_30_t f;
} mp1_smnif_tlb_30_u;


/*
 * MP1_SMNIF_TLB_31 struct
 */

#define MP1_SMNIF_TLB_31_REG_SIZE         32
#define MP1_SMNIF_TLB_31_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_31_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_31_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_31_MASK \
      (MP1_SMNIF_TLB_31_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_31_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_31_GET_SMN_ADDR(mp1_smnif_tlb_31) \
      ((mp1_smnif_tlb_31 & MP1_SMNIF_TLB_31_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_31_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_31_SET_SMN_ADDR(mp1_smnif_tlb_31_reg, smn_addr) \
      mp1_smnif_tlb_31_reg = (mp1_smnif_tlb_31_reg & ~MP1_SMNIF_TLB_31_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_31_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_31_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_31_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_31_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_31_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_31_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_31_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_31_t f;
} mp1_smnif_tlb_31_u;


/*
 * MP1_SMNIF_TLB_32 struct
 */

#define MP1_SMNIF_TLB_32_REG_SIZE         32
#define MP1_SMNIF_TLB_32_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_32_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_32_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_32_MASK \
      (MP1_SMNIF_TLB_32_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_32_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_32_GET_SMN_ADDR(mp1_smnif_tlb_32) \
      ((mp1_smnif_tlb_32 & MP1_SMNIF_TLB_32_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_32_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_32_SET_SMN_ADDR(mp1_smnif_tlb_32_reg, smn_addr) \
      mp1_smnif_tlb_32_reg = (mp1_smnif_tlb_32_reg & ~MP1_SMNIF_TLB_32_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_32_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_32_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_32_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_32_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_32_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_32_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_32_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_32_t f;
} mp1_smnif_tlb_32_u;


/*
 * MP1_SMNIF_TLB_33 struct
 */

#define MP1_SMNIF_TLB_33_REG_SIZE         32
#define MP1_SMNIF_TLB_33_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_33_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_33_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_33_MASK \
      (MP1_SMNIF_TLB_33_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_33_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_33_GET_SMN_ADDR(mp1_smnif_tlb_33) \
      ((mp1_smnif_tlb_33 & MP1_SMNIF_TLB_33_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_33_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_33_SET_SMN_ADDR(mp1_smnif_tlb_33_reg, smn_addr) \
      mp1_smnif_tlb_33_reg = (mp1_smnif_tlb_33_reg & ~MP1_SMNIF_TLB_33_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_33_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_33_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_33_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_33_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_33_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_33_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_33_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_33_t f;
} mp1_smnif_tlb_33_u;


/*
 * MP1_SMNIF_TLB_34 struct
 */

#define MP1_SMNIF_TLB_34_REG_SIZE         32
#define MP1_SMNIF_TLB_34_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_34_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_34_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_34_MASK \
      (MP1_SMNIF_TLB_34_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_34_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_34_GET_SMN_ADDR(mp1_smnif_tlb_34) \
      ((mp1_smnif_tlb_34 & MP1_SMNIF_TLB_34_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_34_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_34_SET_SMN_ADDR(mp1_smnif_tlb_34_reg, smn_addr) \
      mp1_smnif_tlb_34_reg = (mp1_smnif_tlb_34_reg & ~MP1_SMNIF_TLB_34_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_34_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_34_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_34_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_34_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_34_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_34_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_34_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_34_t f;
} mp1_smnif_tlb_34_u;


/*
 * MP1_SMNIF_TLB_35 struct
 */

#define MP1_SMNIF_TLB_35_REG_SIZE         32
#define MP1_SMNIF_TLB_35_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_35_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_35_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_35_MASK \
      (MP1_SMNIF_TLB_35_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_35_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_35_GET_SMN_ADDR(mp1_smnif_tlb_35) \
      ((mp1_smnif_tlb_35 & MP1_SMNIF_TLB_35_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_35_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_35_SET_SMN_ADDR(mp1_smnif_tlb_35_reg, smn_addr) \
      mp1_smnif_tlb_35_reg = (mp1_smnif_tlb_35_reg & ~MP1_SMNIF_TLB_35_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_35_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_35_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_35_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_35_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_35_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_35_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_35_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_35_t f;
} mp1_smnif_tlb_35_u;


/*
 * MP1_SMNIF_TLB_36 struct
 */

#define MP1_SMNIF_TLB_36_REG_SIZE         32
#define MP1_SMNIF_TLB_36_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_36_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_36_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_36_MASK \
      (MP1_SMNIF_TLB_36_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_36_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_36_GET_SMN_ADDR(mp1_smnif_tlb_36) \
      ((mp1_smnif_tlb_36 & MP1_SMNIF_TLB_36_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_36_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_36_SET_SMN_ADDR(mp1_smnif_tlb_36_reg, smn_addr) \
      mp1_smnif_tlb_36_reg = (mp1_smnif_tlb_36_reg & ~MP1_SMNIF_TLB_36_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_36_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_36_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_36_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_36_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_36_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_36_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_36_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_36_t f;
} mp1_smnif_tlb_36_u;


/*
 * MP1_SMNIF_TLB_37 struct
 */

#define MP1_SMNIF_TLB_37_REG_SIZE         32
#define MP1_SMNIF_TLB_37_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_37_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_37_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_37_MASK \
      (MP1_SMNIF_TLB_37_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_37_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_37_GET_SMN_ADDR(mp1_smnif_tlb_37) \
      ((mp1_smnif_tlb_37 & MP1_SMNIF_TLB_37_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_37_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_37_SET_SMN_ADDR(mp1_smnif_tlb_37_reg, smn_addr) \
      mp1_smnif_tlb_37_reg = (mp1_smnif_tlb_37_reg & ~MP1_SMNIF_TLB_37_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_37_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_37_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_37_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_37_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_37_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_37_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_37_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_37_t f;
} mp1_smnif_tlb_37_u;


/*
 * MP1_SMNIF_TLB_38 struct
 */

#define MP1_SMNIF_TLB_38_REG_SIZE         32
#define MP1_SMNIF_TLB_38_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_38_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_38_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_38_MASK \
      (MP1_SMNIF_TLB_38_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_38_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_38_GET_SMN_ADDR(mp1_smnif_tlb_38) \
      ((mp1_smnif_tlb_38 & MP1_SMNIF_TLB_38_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_38_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_38_SET_SMN_ADDR(mp1_smnif_tlb_38_reg, smn_addr) \
      mp1_smnif_tlb_38_reg = (mp1_smnif_tlb_38_reg & ~MP1_SMNIF_TLB_38_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_38_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_38_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_38_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_38_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_38_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_38_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_38_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_38_t f;
} mp1_smnif_tlb_38_u;


/*
 * MP1_SMNIF_TLB_39 struct
 */

#define MP1_SMNIF_TLB_39_REG_SIZE         32
#define MP1_SMNIF_TLB_39_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_39_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_39_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_39_MASK \
      (MP1_SMNIF_TLB_39_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_39_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_39_GET_SMN_ADDR(mp1_smnif_tlb_39) \
      ((mp1_smnif_tlb_39 & MP1_SMNIF_TLB_39_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_39_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_39_SET_SMN_ADDR(mp1_smnif_tlb_39_reg, smn_addr) \
      mp1_smnif_tlb_39_reg = (mp1_smnif_tlb_39_reg & ~MP1_SMNIF_TLB_39_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_39_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_39_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_39_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_39_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_39_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_39_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_39_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_39_t f;
} mp1_smnif_tlb_39_u;


/*
 * MP1_SMNIF_TLB_40 struct
 */

#define MP1_SMNIF_TLB_40_REG_SIZE         32
#define MP1_SMNIF_TLB_40_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_40_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_40_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_40_MASK \
      (MP1_SMNIF_TLB_40_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_40_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_40_GET_SMN_ADDR(mp1_smnif_tlb_40) \
      ((mp1_smnif_tlb_40 & MP1_SMNIF_TLB_40_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_40_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_40_SET_SMN_ADDR(mp1_smnif_tlb_40_reg, smn_addr) \
      mp1_smnif_tlb_40_reg = (mp1_smnif_tlb_40_reg & ~MP1_SMNIF_TLB_40_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_40_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_40_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_40_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_40_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_40_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_40_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_40_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_40_t f;
} mp1_smnif_tlb_40_u;


/*
 * MP1_SMNIF_TLB_41 struct
 */

#define MP1_SMNIF_TLB_41_REG_SIZE         32
#define MP1_SMNIF_TLB_41_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_41_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_41_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_41_MASK \
      (MP1_SMNIF_TLB_41_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_41_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_41_GET_SMN_ADDR(mp1_smnif_tlb_41) \
      ((mp1_smnif_tlb_41 & MP1_SMNIF_TLB_41_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_41_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_41_SET_SMN_ADDR(mp1_smnif_tlb_41_reg, smn_addr) \
      mp1_smnif_tlb_41_reg = (mp1_smnif_tlb_41_reg & ~MP1_SMNIF_TLB_41_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_41_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_41_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_41_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_41_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_41_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_41_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_41_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_41_t f;
} mp1_smnif_tlb_41_u;


/*
 * MP1_SMNIF_TLB_42 struct
 */

#define MP1_SMNIF_TLB_42_REG_SIZE         32
#define MP1_SMNIF_TLB_42_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_42_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_42_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_42_MASK \
      (MP1_SMNIF_TLB_42_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_42_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_42_GET_SMN_ADDR(mp1_smnif_tlb_42) \
      ((mp1_smnif_tlb_42 & MP1_SMNIF_TLB_42_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_42_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_42_SET_SMN_ADDR(mp1_smnif_tlb_42_reg, smn_addr) \
      mp1_smnif_tlb_42_reg = (mp1_smnif_tlb_42_reg & ~MP1_SMNIF_TLB_42_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_42_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_42_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_42_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_42_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_42_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_42_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_42_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_42_t f;
} mp1_smnif_tlb_42_u;


/*
 * MP1_SMNIF_TLB_43 struct
 */

#define MP1_SMNIF_TLB_43_REG_SIZE         32
#define MP1_SMNIF_TLB_43_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_43_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_43_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_43_MASK \
      (MP1_SMNIF_TLB_43_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_43_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_43_GET_SMN_ADDR(mp1_smnif_tlb_43) \
      ((mp1_smnif_tlb_43 & MP1_SMNIF_TLB_43_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_43_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_43_SET_SMN_ADDR(mp1_smnif_tlb_43_reg, smn_addr) \
      mp1_smnif_tlb_43_reg = (mp1_smnif_tlb_43_reg & ~MP1_SMNIF_TLB_43_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_43_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_43_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_43_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_43_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_43_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_43_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_43_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_43_t f;
} mp1_smnif_tlb_43_u;


/*
 * MP1_SMNIF_TLB_44 struct
 */

#define MP1_SMNIF_TLB_44_REG_SIZE         32
#define MP1_SMNIF_TLB_44_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_44_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_44_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_44_MASK \
      (MP1_SMNIF_TLB_44_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_44_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_44_GET_SMN_ADDR(mp1_smnif_tlb_44) \
      ((mp1_smnif_tlb_44 & MP1_SMNIF_TLB_44_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_44_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_44_SET_SMN_ADDR(mp1_smnif_tlb_44_reg, smn_addr) \
      mp1_smnif_tlb_44_reg = (mp1_smnif_tlb_44_reg & ~MP1_SMNIF_TLB_44_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_44_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_44_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_44_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_44_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_44_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_44_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_44_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_44_t f;
} mp1_smnif_tlb_44_u;


/*
 * MP1_SMNIF_TLB_45 struct
 */

#define MP1_SMNIF_TLB_45_REG_SIZE         32
#define MP1_SMNIF_TLB_45_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_45_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_45_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_45_MASK \
      (MP1_SMNIF_TLB_45_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_45_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_45_GET_SMN_ADDR(mp1_smnif_tlb_45) \
      ((mp1_smnif_tlb_45 & MP1_SMNIF_TLB_45_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_45_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_45_SET_SMN_ADDR(mp1_smnif_tlb_45_reg, smn_addr) \
      mp1_smnif_tlb_45_reg = (mp1_smnif_tlb_45_reg & ~MP1_SMNIF_TLB_45_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_45_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_45_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_45_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_45_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_45_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_45_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_45_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_45_t f;
} mp1_smnif_tlb_45_u;


/*
 * MP1_SMNIF_TLB_46 struct
 */

#define MP1_SMNIF_TLB_46_REG_SIZE         32
#define MP1_SMNIF_TLB_46_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_46_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_46_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_46_MASK \
      (MP1_SMNIF_TLB_46_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_46_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_46_GET_SMN_ADDR(mp1_smnif_tlb_46) \
      ((mp1_smnif_tlb_46 & MP1_SMNIF_TLB_46_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_46_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_46_SET_SMN_ADDR(mp1_smnif_tlb_46_reg, smn_addr) \
      mp1_smnif_tlb_46_reg = (mp1_smnif_tlb_46_reg & ~MP1_SMNIF_TLB_46_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_46_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_46_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_46_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_46_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_46_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_46_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_46_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_46_t f;
} mp1_smnif_tlb_46_u;


/*
 * MP1_SMNIF_TLB_47 struct
 */

#define MP1_SMNIF_TLB_47_REG_SIZE         32
#define MP1_SMNIF_TLB_47_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_47_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_47_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_47_MASK \
      (MP1_SMNIF_TLB_47_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_47_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_47_GET_SMN_ADDR(mp1_smnif_tlb_47) \
      ((mp1_smnif_tlb_47 & MP1_SMNIF_TLB_47_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_47_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_47_SET_SMN_ADDR(mp1_smnif_tlb_47_reg, smn_addr) \
      mp1_smnif_tlb_47_reg = (mp1_smnif_tlb_47_reg & ~MP1_SMNIF_TLB_47_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_47_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_47_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_47_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_47_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_47_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_47_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_47_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_47_t f;
} mp1_smnif_tlb_47_u;


/*
 * MP1_SMNIF_TLB_48 struct
 */

#define MP1_SMNIF_TLB_48_REG_SIZE         32
#define MP1_SMNIF_TLB_48_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_48_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_48_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_48_MASK \
      (MP1_SMNIF_TLB_48_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_48_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_48_GET_SMN_ADDR(mp1_smnif_tlb_48) \
      ((mp1_smnif_tlb_48 & MP1_SMNIF_TLB_48_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_48_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_48_SET_SMN_ADDR(mp1_smnif_tlb_48_reg, smn_addr) \
      mp1_smnif_tlb_48_reg = (mp1_smnif_tlb_48_reg & ~MP1_SMNIF_TLB_48_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_48_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_48_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_48_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_48_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_48_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_48_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_48_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_48_t f;
} mp1_smnif_tlb_48_u;


/*
 * MP1_SMNIF_TLB_49 struct
 */

#define MP1_SMNIF_TLB_49_REG_SIZE         32
#define MP1_SMNIF_TLB_49_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_49_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_49_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_49_MASK \
      (MP1_SMNIF_TLB_49_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_49_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_49_GET_SMN_ADDR(mp1_smnif_tlb_49) \
      ((mp1_smnif_tlb_49 & MP1_SMNIF_TLB_49_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_49_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_49_SET_SMN_ADDR(mp1_smnif_tlb_49_reg, smn_addr) \
      mp1_smnif_tlb_49_reg = (mp1_smnif_tlb_49_reg & ~MP1_SMNIF_TLB_49_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_49_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_49_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_49_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_49_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_49_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_49_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_49_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_49_t f;
} mp1_smnif_tlb_49_u;


/*
 * MP1_SMNIF_TLB_50 struct
 */

#define MP1_SMNIF_TLB_50_REG_SIZE         32
#define MP1_SMNIF_TLB_50_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_50_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_50_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_50_MASK \
      (MP1_SMNIF_TLB_50_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_50_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_50_GET_SMN_ADDR(mp1_smnif_tlb_50) \
      ((mp1_smnif_tlb_50 & MP1_SMNIF_TLB_50_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_50_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_50_SET_SMN_ADDR(mp1_smnif_tlb_50_reg, smn_addr) \
      mp1_smnif_tlb_50_reg = (mp1_smnif_tlb_50_reg & ~MP1_SMNIF_TLB_50_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_50_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_50_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_50_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_50_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_50_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_50_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_50_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_50_t f;
} mp1_smnif_tlb_50_u;


/*
 * MP1_SMNIF_TLB_51 struct
 */

#define MP1_SMNIF_TLB_51_REG_SIZE         32
#define MP1_SMNIF_TLB_51_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_51_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_51_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_51_MASK \
      (MP1_SMNIF_TLB_51_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_51_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_51_GET_SMN_ADDR(mp1_smnif_tlb_51) \
      ((mp1_smnif_tlb_51 & MP1_SMNIF_TLB_51_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_51_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_51_SET_SMN_ADDR(mp1_smnif_tlb_51_reg, smn_addr) \
      mp1_smnif_tlb_51_reg = (mp1_smnif_tlb_51_reg & ~MP1_SMNIF_TLB_51_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_51_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_51_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_51_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_51_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_51_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_51_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_51_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_51_t f;
} mp1_smnif_tlb_51_u;


/*
 * MP1_SMNIF_TLB_52 struct
 */

#define MP1_SMNIF_TLB_52_REG_SIZE         32
#define MP1_SMNIF_TLB_52_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_52_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_52_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_52_MASK \
      (MP1_SMNIF_TLB_52_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_52_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_52_GET_SMN_ADDR(mp1_smnif_tlb_52) \
      ((mp1_smnif_tlb_52 & MP1_SMNIF_TLB_52_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_52_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_52_SET_SMN_ADDR(mp1_smnif_tlb_52_reg, smn_addr) \
      mp1_smnif_tlb_52_reg = (mp1_smnif_tlb_52_reg & ~MP1_SMNIF_TLB_52_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_52_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_52_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_52_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_52_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_52_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_52_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_52_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_52_t f;
} mp1_smnif_tlb_52_u;


/*
 * MP1_SMNIF_TLB_53 struct
 */

#define MP1_SMNIF_TLB_53_REG_SIZE         32
#define MP1_SMNIF_TLB_53_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_53_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_53_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_53_MASK \
      (MP1_SMNIF_TLB_53_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_53_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_53_GET_SMN_ADDR(mp1_smnif_tlb_53) \
      ((mp1_smnif_tlb_53 & MP1_SMNIF_TLB_53_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_53_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_53_SET_SMN_ADDR(mp1_smnif_tlb_53_reg, smn_addr) \
      mp1_smnif_tlb_53_reg = (mp1_smnif_tlb_53_reg & ~MP1_SMNIF_TLB_53_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_53_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_53_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_53_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_53_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_53_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_53_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_53_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_53_t f;
} mp1_smnif_tlb_53_u;


/*
 * MP1_SMNIF_TLB_54 struct
 */

#define MP1_SMNIF_TLB_54_REG_SIZE         32
#define MP1_SMNIF_TLB_54_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_54_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_54_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_54_MASK \
      (MP1_SMNIF_TLB_54_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_54_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_54_GET_SMN_ADDR(mp1_smnif_tlb_54) \
      ((mp1_smnif_tlb_54 & MP1_SMNIF_TLB_54_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_54_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_54_SET_SMN_ADDR(mp1_smnif_tlb_54_reg, smn_addr) \
      mp1_smnif_tlb_54_reg = (mp1_smnif_tlb_54_reg & ~MP1_SMNIF_TLB_54_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_54_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_54_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_54_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_54_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_54_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_54_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_54_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_54_t f;
} mp1_smnif_tlb_54_u;


/*
 * MP1_SMNIF_TLB_55 struct
 */

#define MP1_SMNIF_TLB_55_REG_SIZE         32
#define MP1_SMNIF_TLB_55_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_55_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_55_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_55_MASK \
      (MP1_SMNIF_TLB_55_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_55_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_55_GET_SMN_ADDR(mp1_smnif_tlb_55) \
      ((mp1_smnif_tlb_55 & MP1_SMNIF_TLB_55_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_55_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_55_SET_SMN_ADDR(mp1_smnif_tlb_55_reg, smn_addr) \
      mp1_smnif_tlb_55_reg = (mp1_smnif_tlb_55_reg & ~MP1_SMNIF_TLB_55_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_55_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_55_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_55_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_55_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_55_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_55_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_55_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_55_t f;
} mp1_smnif_tlb_55_u;


/*
 * MP1_SMNIF_TLB_56 struct
 */

#define MP1_SMNIF_TLB_56_REG_SIZE         32
#define MP1_SMNIF_TLB_56_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_56_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_56_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_56_MASK \
      (MP1_SMNIF_TLB_56_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_56_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_56_GET_SMN_ADDR(mp1_smnif_tlb_56) \
      ((mp1_smnif_tlb_56 & MP1_SMNIF_TLB_56_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_56_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_56_SET_SMN_ADDR(mp1_smnif_tlb_56_reg, smn_addr) \
      mp1_smnif_tlb_56_reg = (mp1_smnif_tlb_56_reg & ~MP1_SMNIF_TLB_56_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_56_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_56_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_56_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_56_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_56_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_56_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_56_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_56_t f;
} mp1_smnif_tlb_56_u;


/*
 * MP1_SMNIF_TLB_57 struct
 */

#define MP1_SMNIF_TLB_57_REG_SIZE         32
#define MP1_SMNIF_TLB_57_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_57_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_57_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_57_MASK \
      (MP1_SMNIF_TLB_57_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_57_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_57_GET_SMN_ADDR(mp1_smnif_tlb_57) \
      ((mp1_smnif_tlb_57 & MP1_SMNIF_TLB_57_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_57_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_57_SET_SMN_ADDR(mp1_smnif_tlb_57_reg, smn_addr) \
      mp1_smnif_tlb_57_reg = (mp1_smnif_tlb_57_reg & ~MP1_SMNIF_TLB_57_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_57_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_57_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_57_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_57_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_57_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_57_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_57_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_57_t f;
} mp1_smnif_tlb_57_u;


/*
 * MP1_SMNIF_TLB_58 struct
 */

#define MP1_SMNIF_TLB_58_REG_SIZE         32
#define MP1_SMNIF_TLB_58_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_58_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_58_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_58_MASK \
      (MP1_SMNIF_TLB_58_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_58_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_58_GET_SMN_ADDR(mp1_smnif_tlb_58) \
      ((mp1_smnif_tlb_58 & MP1_SMNIF_TLB_58_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_58_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_58_SET_SMN_ADDR(mp1_smnif_tlb_58_reg, smn_addr) \
      mp1_smnif_tlb_58_reg = (mp1_smnif_tlb_58_reg & ~MP1_SMNIF_TLB_58_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_58_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_58_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_58_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_58_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_58_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_58_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_58_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_58_t f;
} mp1_smnif_tlb_58_u;


/*
 * MP1_SMNIF_TLB_59 struct
 */

#define MP1_SMNIF_TLB_59_REG_SIZE         32
#define MP1_SMNIF_TLB_59_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_59_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_59_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_59_MASK \
      (MP1_SMNIF_TLB_59_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_59_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_59_GET_SMN_ADDR(mp1_smnif_tlb_59) \
      ((mp1_smnif_tlb_59 & MP1_SMNIF_TLB_59_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_59_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_59_SET_SMN_ADDR(mp1_smnif_tlb_59_reg, smn_addr) \
      mp1_smnif_tlb_59_reg = (mp1_smnif_tlb_59_reg & ~MP1_SMNIF_TLB_59_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_59_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_59_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_59_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_59_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_59_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_59_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_59_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_59_t f;
} mp1_smnif_tlb_59_u;


/*
 * MP1_SMNIF_TLB_60 struct
 */

#define MP1_SMNIF_TLB_60_REG_SIZE         32
#define MP1_SMNIF_TLB_60_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_60_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_60_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_60_MASK \
      (MP1_SMNIF_TLB_60_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_60_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_60_GET_SMN_ADDR(mp1_smnif_tlb_60) \
      ((mp1_smnif_tlb_60 & MP1_SMNIF_TLB_60_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_60_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_60_SET_SMN_ADDR(mp1_smnif_tlb_60_reg, smn_addr) \
      mp1_smnif_tlb_60_reg = (mp1_smnif_tlb_60_reg & ~MP1_SMNIF_TLB_60_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_60_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_60_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_60_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_60_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_60_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_60_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_60_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_60_t f;
} mp1_smnif_tlb_60_u;


/*
 * MP1_SMNIF_TLB_61 struct
 */

#define MP1_SMNIF_TLB_61_REG_SIZE         32
#define MP1_SMNIF_TLB_61_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_61_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_61_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_61_MASK \
      (MP1_SMNIF_TLB_61_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_61_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_61_GET_SMN_ADDR(mp1_smnif_tlb_61) \
      ((mp1_smnif_tlb_61 & MP1_SMNIF_TLB_61_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_61_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_61_SET_SMN_ADDR(mp1_smnif_tlb_61_reg, smn_addr) \
      mp1_smnif_tlb_61_reg = (mp1_smnif_tlb_61_reg & ~MP1_SMNIF_TLB_61_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_61_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_61_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_61_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_61_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_61_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_61_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_61_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_61_t f;
} mp1_smnif_tlb_61_u;


/*
 * MP1_SMNIF_TLB_62 struct
 */

#define MP1_SMNIF_TLB_62_REG_SIZE         32
#define MP1_SMNIF_TLB_62_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_62_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_62_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_62_MASK \
      (MP1_SMNIF_TLB_62_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_62_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_62_GET_SMN_ADDR(mp1_smnif_tlb_62) \
      ((mp1_smnif_tlb_62 & MP1_SMNIF_TLB_62_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_62_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_62_SET_SMN_ADDR(mp1_smnif_tlb_62_reg, smn_addr) \
      mp1_smnif_tlb_62_reg = (mp1_smnif_tlb_62_reg & ~MP1_SMNIF_TLB_62_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_62_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_62_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_62_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_62_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_62_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_62_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_62_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_62_t f;
} mp1_smnif_tlb_62_u;


/*
 * MP1_SMNIF_TLB_63 struct
 */

#define MP1_SMNIF_TLB_63_REG_SIZE         32
#define MP1_SMNIF_TLB_63_SMN_ADDR_SIZE  16

#define MP1_SMNIF_TLB_63_SMN_ADDR_SHIFT  0

#define MP1_SMNIF_TLB_63_SMN_ADDR_MASK  0x0000ffff

#define MP1_SMNIF_TLB_63_MASK \
      (MP1_SMNIF_TLB_63_SMN_ADDR_MASK)

#define MP1_SMNIF_TLB_63_DEFAULT       0x00000fff

#define MP1_SMNIF_TLB_63_GET_SMN_ADDR(mp1_smnif_tlb_63) \
      ((mp1_smnif_tlb_63 & MP1_SMNIF_TLB_63_SMN_ADDR_MASK) >> MP1_SMNIF_TLB_63_SMN_ADDR_SHIFT)

#define MP1_SMNIF_TLB_63_SET_SMN_ADDR(mp1_smnif_tlb_63_reg, smn_addr) \
      mp1_smnif_tlb_63_reg = (mp1_smnif_tlb_63_reg & ~MP1_SMNIF_TLB_63_SMN_ADDR_MASK) | (smn_addr << MP1_SMNIF_TLB_63_SMN_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_63_t {
            unsigned int smn_addr                       : MP1_SMNIF_TLB_63_SMN_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_tlb_63_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_63_t {
            unsigned int                                : 16;
            unsigned int smn_addr                       : MP1_SMNIF_TLB_63_SMN_ADDR_SIZE;
      } mp1_smnif_tlb_63_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_63_t f;
} mp1_smnif_tlb_63_u;


/*
 * MP1_SMNIF_TLV0 struct
 */

#define MP1_SMNIF_TLV0_REG_SIZE         32
#define MP1_SMNIF_TLV0_TLB0_SIZE  3
#define MP1_SMNIF_TLV0_TLB1_SIZE  3
#define MP1_SMNIF_TLV0_TLB2_SIZE  3
#define MP1_SMNIF_TLV0_TLB3_SIZE  3
#define MP1_SMNIF_TLV0_TLB4_SIZE  3
#define MP1_SMNIF_TLV0_TLB5_SIZE  3
#define MP1_SMNIF_TLV0_TLB6_SIZE  3
#define MP1_SMNIF_TLV0_TLB7_SIZE  3

#define MP1_SMNIF_TLV0_TLB0_SHIFT  0
#define MP1_SMNIF_TLV0_TLB1_SHIFT  4
#define MP1_SMNIF_TLV0_TLB2_SHIFT  8
#define MP1_SMNIF_TLV0_TLB3_SHIFT  12
#define MP1_SMNIF_TLV0_TLB4_SHIFT  16
#define MP1_SMNIF_TLV0_TLB5_SHIFT  20
#define MP1_SMNIF_TLV0_TLB6_SHIFT  24
#define MP1_SMNIF_TLV0_TLB7_SHIFT  28

#define MP1_SMNIF_TLV0_TLB0_MASK        0x00000007
#define MP1_SMNIF_TLV0_TLB1_MASK        0x00000070
#define MP1_SMNIF_TLV0_TLB2_MASK        0x00000700
#define MP1_SMNIF_TLV0_TLB3_MASK        0x00007000
#define MP1_SMNIF_TLV0_TLB4_MASK        0x00070000
#define MP1_SMNIF_TLV0_TLB5_MASK        0x00700000
#define MP1_SMNIF_TLV0_TLB6_MASK        0x07000000
#define MP1_SMNIF_TLV0_TLB7_MASK        0x70000000

#define MP1_SMNIF_TLV0_MASK \
      (MP1_SMNIF_TLV0_TLB0_MASK | \
      MP1_SMNIF_TLV0_TLB1_MASK | \
      MP1_SMNIF_TLV0_TLB2_MASK | \
      MP1_SMNIF_TLV0_TLB3_MASK | \
      MP1_SMNIF_TLV0_TLB4_MASK | \
      MP1_SMNIF_TLV0_TLB5_MASK | \
      MP1_SMNIF_TLV0_TLB6_MASK | \
      MP1_SMNIF_TLV0_TLB7_MASK)

#define MP1_SMNIF_TLV0_DEFAULT         0x00000000

#define MP1_SMNIF_TLV0_GET_TLB0(mp1_smnif_tlv0) \
      ((mp1_smnif_tlv0 & MP1_SMNIF_TLV0_TLB0_MASK) >> MP1_SMNIF_TLV0_TLB0_SHIFT)
#define MP1_SMNIF_TLV0_GET_TLB1(mp1_smnif_tlv0) \
      ((mp1_smnif_tlv0 & MP1_SMNIF_TLV0_TLB1_MASK) >> MP1_SMNIF_TLV0_TLB1_SHIFT)
#define MP1_SMNIF_TLV0_GET_TLB2(mp1_smnif_tlv0) \
      ((mp1_smnif_tlv0 & MP1_SMNIF_TLV0_TLB2_MASK) >> MP1_SMNIF_TLV0_TLB2_SHIFT)
#define MP1_SMNIF_TLV0_GET_TLB3(mp1_smnif_tlv0) \
      ((mp1_smnif_tlv0 & MP1_SMNIF_TLV0_TLB3_MASK) >> MP1_SMNIF_TLV0_TLB3_SHIFT)
#define MP1_SMNIF_TLV0_GET_TLB4(mp1_smnif_tlv0) \
      ((mp1_smnif_tlv0 & MP1_SMNIF_TLV0_TLB4_MASK) >> MP1_SMNIF_TLV0_TLB4_SHIFT)
#define MP1_SMNIF_TLV0_GET_TLB5(mp1_smnif_tlv0) \
      ((mp1_smnif_tlv0 & MP1_SMNIF_TLV0_TLB5_MASK) >> MP1_SMNIF_TLV0_TLB5_SHIFT)
#define MP1_SMNIF_TLV0_GET_TLB6(mp1_smnif_tlv0) \
      ((mp1_smnif_tlv0 & MP1_SMNIF_TLV0_TLB6_MASK) >> MP1_SMNIF_TLV0_TLB6_SHIFT)
#define MP1_SMNIF_TLV0_GET_TLB7(mp1_smnif_tlv0) \
      ((mp1_smnif_tlv0 & MP1_SMNIF_TLV0_TLB7_MASK) >> MP1_SMNIF_TLV0_TLB7_SHIFT)

#define MP1_SMNIF_TLV0_SET_TLB0(mp1_smnif_tlv0_reg, tlb0) \
      mp1_smnif_tlv0_reg = (mp1_smnif_tlv0_reg & ~MP1_SMNIF_TLV0_TLB0_MASK) | (tlb0 << MP1_SMNIF_TLV0_TLB0_SHIFT)
#define MP1_SMNIF_TLV0_SET_TLB1(mp1_smnif_tlv0_reg, tlb1) \
      mp1_smnif_tlv0_reg = (mp1_smnif_tlv0_reg & ~MP1_SMNIF_TLV0_TLB1_MASK) | (tlb1 << MP1_SMNIF_TLV0_TLB1_SHIFT)
#define MP1_SMNIF_TLV0_SET_TLB2(mp1_smnif_tlv0_reg, tlb2) \
      mp1_smnif_tlv0_reg = (mp1_smnif_tlv0_reg & ~MP1_SMNIF_TLV0_TLB2_MASK) | (tlb2 << MP1_SMNIF_TLV0_TLB2_SHIFT)
#define MP1_SMNIF_TLV0_SET_TLB3(mp1_smnif_tlv0_reg, tlb3) \
      mp1_smnif_tlv0_reg = (mp1_smnif_tlv0_reg & ~MP1_SMNIF_TLV0_TLB3_MASK) | (tlb3 << MP1_SMNIF_TLV0_TLB3_SHIFT)
#define MP1_SMNIF_TLV0_SET_TLB4(mp1_smnif_tlv0_reg, tlb4) \
      mp1_smnif_tlv0_reg = (mp1_smnif_tlv0_reg & ~MP1_SMNIF_TLV0_TLB4_MASK) | (tlb4 << MP1_SMNIF_TLV0_TLB4_SHIFT)
#define MP1_SMNIF_TLV0_SET_TLB5(mp1_smnif_tlv0_reg, tlb5) \
      mp1_smnif_tlv0_reg = (mp1_smnif_tlv0_reg & ~MP1_SMNIF_TLV0_TLB5_MASK) | (tlb5 << MP1_SMNIF_TLV0_TLB5_SHIFT)
#define MP1_SMNIF_TLV0_SET_TLB6(mp1_smnif_tlv0_reg, tlb6) \
      mp1_smnif_tlv0_reg = (mp1_smnif_tlv0_reg & ~MP1_SMNIF_TLV0_TLB6_MASK) | (tlb6 << MP1_SMNIF_TLV0_TLB6_SHIFT)
#define MP1_SMNIF_TLV0_SET_TLB7(mp1_smnif_tlv0_reg, tlb7) \
      mp1_smnif_tlv0_reg = (mp1_smnif_tlv0_reg & ~MP1_SMNIF_TLV0_TLB7_MASK) | (tlb7 << MP1_SMNIF_TLV0_TLB7_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlv0_t {
            unsigned int tlb0                           : MP1_SMNIF_TLV0_TLB0_SIZE;
            unsigned int                                : 1;
            unsigned int tlb1                           : MP1_SMNIF_TLV0_TLB1_SIZE;
            unsigned int                                : 1;
            unsigned int tlb2                           : MP1_SMNIF_TLV0_TLB2_SIZE;
            unsigned int                                : 1;
            unsigned int tlb3                           : MP1_SMNIF_TLV0_TLB3_SIZE;
            unsigned int                                : 1;
            unsigned int tlb4                           : MP1_SMNIF_TLV0_TLB4_SIZE;
            unsigned int                                : 1;
            unsigned int tlb5                           : MP1_SMNIF_TLV0_TLB5_SIZE;
            unsigned int                                : 1;
            unsigned int tlb6                           : MP1_SMNIF_TLV0_TLB6_SIZE;
            unsigned int                                : 1;
            unsigned int tlb7                           : MP1_SMNIF_TLV0_TLB7_SIZE;
            unsigned int                                : 1;
      } mp1_smnif_tlv0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlv0_t {
            unsigned int                                : 1;
            unsigned int tlb7                           : MP1_SMNIF_TLV0_TLB7_SIZE;
            unsigned int                                : 1;
            unsigned int tlb6                           : MP1_SMNIF_TLV0_TLB6_SIZE;
            unsigned int                                : 1;
            unsigned int tlb5                           : MP1_SMNIF_TLV0_TLB5_SIZE;
            unsigned int                                : 1;
            unsigned int tlb4                           : MP1_SMNIF_TLV0_TLB4_SIZE;
            unsigned int                                : 1;
            unsigned int tlb3                           : MP1_SMNIF_TLV0_TLB3_SIZE;
            unsigned int                                : 1;
            unsigned int tlb2                           : MP1_SMNIF_TLV0_TLB2_SIZE;
            unsigned int                                : 1;
            unsigned int tlb1                           : MP1_SMNIF_TLV0_TLB1_SIZE;
            unsigned int                                : 1;
            unsigned int tlb0                           : MP1_SMNIF_TLV0_TLB0_SIZE;
      } mp1_smnif_tlv0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlv0_t f;
} mp1_smnif_tlv0_u;


/*
 * MP1_SMNIF_TLV1 struct
 */

#define MP1_SMNIF_TLV1_REG_SIZE         32
#define MP1_SMNIF_TLV1_TLB8_SIZE  3
#define MP1_SMNIF_TLV1_TLB9_SIZE  3
#define MP1_SMNIF_TLV1_TLB10_SIZE  3
#define MP1_SMNIF_TLV1_TLB11_SIZE  3
#define MP1_SMNIF_TLV1_TLB12_SIZE  3
#define MP1_SMNIF_TLV1_TLB13_SIZE  3
#define MP1_SMNIF_TLV1_TLB14_SIZE  3
#define MP1_SMNIF_TLV1_TLB15_SIZE  3

#define MP1_SMNIF_TLV1_TLB8_SHIFT  0
#define MP1_SMNIF_TLV1_TLB9_SHIFT  4
#define MP1_SMNIF_TLV1_TLB10_SHIFT  8
#define MP1_SMNIF_TLV1_TLB11_SHIFT  12
#define MP1_SMNIF_TLV1_TLB12_SHIFT  16
#define MP1_SMNIF_TLV1_TLB13_SHIFT  20
#define MP1_SMNIF_TLV1_TLB14_SHIFT  24
#define MP1_SMNIF_TLV1_TLB15_SHIFT  28

#define MP1_SMNIF_TLV1_TLB8_MASK        0x00000007
#define MP1_SMNIF_TLV1_TLB9_MASK        0x00000070
#define MP1_SMNIF_TLV1_TLB10_MASK       0x00000700
#define MP1_SMNIF_TLV1_TLB11_MASK       0x00007000
#define MP1_SMNIF_TLV1_TLB12_MASK       0x00070000
#define MP1_SMNIF_TLV1_TLB13_MASK       0x00700000
#define MP1_SMNIF_TLV1_TLB14_MASK       0x07000000
#define MP1_SMNIF_TLV1_TLB15_MASK       0x70000000

#define MP1_SMNIF_TLV1_MASK \
      (MP1_SMNIF_TLV1_TLB8_MASK | \
      MP1_SMNIF_TLV1_TLB9_MASK | \
      MP1_SMNIF_TLV1_TLB10_MASK | \
      MP1_SMNIF_TLV1_TLB11_MASK | \
      MP1_SMNIF_TLV1_TLB12_MASK | \
      MP1_SMNIF_TLV1_TLB13_MASK | \
      MP1_SMNIF_TLV1_TLB14_MASK | \
      MP1_SMNIF_TLV1_TLB15_MASK)

#define MP1_SMNIF_TLV1_DEFAULT         0x00000000

#define MP1_SMNIF_TLV1_GET_TLB8(mp1_smnif_tlv1) \
      ((mp1_smnif_tlv1 & MP1_SMNIF_TLV1_TLB8_MASK) >> MP1_SMNIF_TLV1_TLB8_SHIFT)
#define MP1_SMNIF_TLV1_GET_TLB9(mp1_smnif_tlv1) \
      ((mp1_smnif_tlv1 & MP1_SMNIF_TLV1_TLB9_MASK) >> MP1_SMNIF_TLV1_TLB9_SHIFT)
#define MP1_SMNIF_TLV1_GET_TLB10(mp1_smnif_tlv1) \
      ((mp1_smnif_tlv1 & MP1_SMNIF_TLV1_TLB10_MASK) >> MP1_SMNIF_TLV1_TLB10_SHIFT)
#define MP1_SMNIF_TLV1_GET_TLB11(mp1_smnif_tlv1) \
      ((mp1_smnif_tlv1 & MP1_SMNIF_TLV1_TLB11_MASK) >> MP1_SMNIF_TLV1_TLB11_SHIFT)
#define MP1_SMNIF_TLV1_GET_TLB12(mp1_smnif_tlv1) \
      ((mp1_smnif_tlv1 & MP1_SMNIF_TLV1_TLB12_MASK) >> MP1_SMNIF_TLV1_TLB12_SHIFT)
#define MP1_SMNIF_TLV1_GET_TLB13(mp1_smnif_tlv1) \
      ((mp1_smnif_tlv1 & MP1_SMNIF_TLV1_TLB13_MASK) >> MP1_SMNIF_TLV1_TLB13_SHIFT)
#define MP1_SMNIF_TLV1_GET_TLB14(mp1_smnif_tlv1) \
      ((mp1_smnif_tlv1 & MP1_SMNIF_TLV1_TLB14_MASK) >> MP1_SMNIF_TLV1_TLB14_SHIFT)
#define MP1_SMNIF_TLV1_GET_TLB15(mp1_smnif_tlv1) \
      ((mp1_smnif_tlv1 & MP1_SMNIF_TLV1_TLB15_MASK) >> MP1_SMNIF_TLV1_TLB15_SHIFT)

#define MP1_SMNIF_TLV1_SET_TLB8(mp1_smnif_tlv1_reg, tlb8) \
      mp1_smnif_tlv1_reg = (mp1_smnif_tlv1_reg & ~MP1_SMNIF_TLV1_TLB8_MASK) | (tlb8 << MP1_SMNIF_TLV1_TLB8_SHIFT)
#define MP1_SMNIF_TLV1_SET_TLB9(mp1_smnif_tlv1_reg, tlb9) \
      mp1_smnif_tlv1_reg = (mp1_smnif_tlv1_reg & ~MP1_SMNIF_TLV1_TLB9_MASK) | (tlb9 << MP1_SMNIF_TLV1_TLB9_SHIFT)
#define MP1_SMNIF_TLV1_SET_TLB10(mp1_smnif_tlv1_reg, tlb10) \
      mp1_smnif_tlv1_reg = (mp1_smnif_tlv1_reg & ~MP1_SMNIF_TLV1_TLB10_MASK) | (tlb10 << MP1_SMNIF_TLV1_TLB10_SHIFT)
#define MP1_SMNIF_TLV1_SET_TLB11(mp1_smnif_tlv1_reg, tlb11) \
      mp1_smnif_tlv1_reg = (mp1_smnif_tlv1_reg & ~MP1_SMNIF_TLV1_TLB11_MASK) | (tlb11 << MP1_SMNIF_TLV1_TLB11_SHIFT)
#define MP1_SMNIF_TLV1_SET_TLB12(mp1_smnif_tlv1_reg, tlb12) \
      mp1_smnif_tlv1_reg = (mp1_smnif_tlv1_reg & ~MP1_SMNIF_TLV1_TLB12_MASK) | (tlb12 << MP1_SMNIF_TLV1_TLB12_SHIFT)
#define MP1_SMNIF_TLV1_SET_TLB13(mp1_smnif_tlv1_reg, tlb13) \
      mp1_smnif_tlv1_reg = (mp1_smnif_tlv1_reg & ~MP1_SMNIF_TLV1_TLB13_MASK) | (tlb13 << MP1_SMNIF_TLV1_TLB13_SHIFT)
#define MP1_SMNIF_TLV1_SET_TLB14(mp1_smnif_tlv1_reg, tlb14) \
      mp1_smnif_tlv1_reg = (mp1_smnif_tlv1_reg & ~MP1_SMNIF_TLV1_TLB14_MASK) | (tlb14 << MP1_SMNIF_TLV1_TLB14_SHIFT)
#define MP1_SMNIF_TLV1_SET_TLB15(mp1_smnif_tlv1_reg, tlb15) \
      mp1_smnif_tlv1_reg = (mp1_smnif_tlv1_reg & ~MP1_SMNIF_TLV1_TLB15_MASK) | (tlb15 << MP1_SMNIF_TLV1_TLB15_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlv1_t {
            unsigned int tlb8                           : MP1_SMNIF_TLV1_TLB8_SIZE;
            unsigned int                                : 1;
            unsigned int tlb9                           : MP1_SMNIF_TLV1_TLB9_SIZE;
            unsigned int                                : 1;
            unsigned int tlb10                          : MP1_SMNIF_TLV1_TLB10_SIZE;
            unsigned int                                : 1;
            unsigned int tlb11                          : MP1_SMNIF_TLV1_TLB11_SIZE;
            unsigned int                                : 1;
            unsigned int tlb12                          : MP1_SMNIF_TLV1_TLB12_SIZE;
            unsigned int                                : 1;
            unsigned int tlb13                          : MP1_SMNIF_TLV1_TLB13_SIZE;
            unsigned int                                : 1;
            unsigned int tlb14                          : MP1_SMNIF_TLV1_TLB14_SIZE;
            unsigned int                                : 1;
            unsigned int tlb15                          : MP1_SMNIF_TLV1_TLB15_SIZE;
            unsigned int                                : 1;
      } mp1_smnif_tlv1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlv1_t {
            unsigned int                                : 1;
            unsigned int tlb15                          : MP1_SMNIF_TLV1_TLB15_SIZE;
            unsigned int                                : 1;
            unsigned int tlb14                          : MP1_SMNIF_TLV1_TLB14_SIZE;
            unsigned int                                : 1;
            unsigned int tlb13                          : MP1_SMNIF_TLV1_TLB13_SIZE;
            unsigned int                                : 1;
            unsigned int tlb12                          : MP1_SMNIF_TLV1_TLB12_SIZE;
            unsigned int                                : 1;
            unsigned int tlb11                          : MP1_SMNIF_TLV1_TLB11_SIZE;
            unsigned int                                : 1;
            unsigned int tlb10                          : MP1_SMNIF_TLV1_TLB10_SIZE;
            unsigned int                                : 1;
            unsigned int tlb9                           : MP1_SMNIF_TLV1_TLB9_SIZE;
            unsigned int                                : 1;
            unsigned int tlb8                           : MP1_SMNIF_TLV1_TLB8_SIZE;
      } mp1_smnif_tlv1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlv1_t f;
} mp1_smnif_tlv1_u;


/*
 * MP1_SMNIF_TLV2 struct
 */

#define MP1_SMNIF_TLV2_REG_SIZE         32
#define MP1_SMNIF_TLV2_TLB16_SIZE  3
#define MP1_SMNIF_TLV2_TLB17_SIZE  3
#define MP1_SMNIF_TLV2_TLB18_SIZE  3
#define MP1_SMNIF_TLV2_TLB19_SIZE  3
#define MP1_SMNIF_TLV2_TLB20_SIZE  3
#define MP1_SMNIF_TLV2_TLB21_SIZE  3
#define MP1_SMNIF_TLV2_TLB22_SIZE  3
#define MP1_SMNIF_TLV2_TLB23_SIZE  3

#define MP1_SMNIF_TLV2_TLB16_SHIFT  0
#define MP1_SMNIF_TLV2_TLB17_SHIFT  4
#define MP1_SMNIF_TLV2_TLB18_SHIFT  8
#define MP1_SMNIF_TLV2_TLB19_SHIFT  12
#define MP1_SMNIF_TLV2_TLB20_SHIFT  16
#define MP1_SMNIF_TLV2_TLB21_SHIFT  20
#define MP1_SMNIF_TLV2_TLB22_SHIFT  24
#define MP1_SMNIF_TLV2_TLB23_SHIFT  28

#define MP1_SMNIF_TLV2_TLB16_MASK       0x00000007
#define MP1_SMNIF_TLV2_TLB17_MASK       0x00000070
#define MP1_SMNIF_TLV2_TLB18_MASK       0x00000700
#define MP1_SMNIF_TLV2_TLB19_MASK       0x00007000
#define MP1_SMNIF_TLV2_TLB20_MASK       0x00070000
#define MP1_SMNIF_TLV2_TLB21_MASK       0x00700000
#define MP1_SMNIF_TLV2_TLB22_MASK       0x07000000
#define MP1_SMNIF_TLV2_TLB23_MASK       0x70000000

#define MP1_SMNIF_TLV2_MASK \
      (MP1_SMNIF_TLV2_TLB16_MASK | \
      MP1_SMNIF_TLV2_TLB17_MASK | \
      MP1_SMNIF_TLV2_TLB18_MASK | \
      MP1_SMNIF_TLV2_TLB19_MASK | \
      MP1_SMNIF_TLV2_TLB20_MASK | \
      MP1_SMNIF_TLV2_TLB21_MASK | \
      MP1_SMNIF_TLV2_TLB22_MASK | \
      MP1_SMNIF_TLV2_TLB23_MASK)

#define MP1_SMNIF_TLV2_DEFAULT         0x00000000

#define MP1_SMNIF_TLV2_GET_TLB16(mp1_smnif_tlv2) \
      ((mp1_smnif_tlv2 & MP1_SMNIF_TLV2_TLB16_MASK) >> MP1_SMNIF_TLV2_TLB16_SHIFT)
#define MP1_SMNIF_TLV2_GET_TLB17(mp1_smnif_tlv2) \
      ((mp1_smnif_tlv2 & MP1_SMNIF_TLV2_TLB17_MASK) >> MP1_SMNIF_TLV2_TLB17_SHIFT)
#define MP1_SMNIF_TLV2_GET_TLB18(mp1_smnif_tlv2) \
      ((mp1_smnif_tlv2 & MP1_SMNIF_TLV2_TLB18_MASK) >> MP1_SMNIF_TLV2_TLB18_SHIFT)
#define MP1_SMNIF_TLV2_GET_TLB19(mp1_smnif_tlv2) \
      ((mp1_smnif_tlv2 & MP1_SMNIF_TLV2_TLB19_MASK) >> MP1_SMNIF_TLV2_TLB19_SHIFT)
#define MP1_SMNIF_TLV2_GET_TLB20(mp1_smnif_tlv2) \
      ((mp1_smnif_tlv2 & MP1_SMNIF_TLV2_TLB20_MASK) >> MP1_SMNIF_TLV2_TLB20_SHIFT)
#define MP1_SMNIF_TLV2_GET_TLB21(mp1_smnif_tlv2) \
      ((mp1_smnif_tlv2 & MP1_SMNIF_TLV2_TLB21_MASK) >> MP1_SMNIF_TLV2_TLB21_SHIFT)
#define MP1_SMNIF_TLV2_GET_TLB22(mp1_smnif_tlv2) \
      ((mp1_smnif_tlv2 & MP1_SMNIF_TLV2_TLB22_MASK) >> MP1_SMNIF_TLV2_TLB22_SHIFT)
#define MP1_SMNIF_TLV2_GET_TLB23(mp1_smnif_tlv2) \
      ((mp1_smnif_tlv2 & MP1_SMNIF_TLV2_TLB23_MASK) >> MP1_SMNIF_TLV2_TLB23_SHIFT)

#define MP1_SMNIF_TLV2_SET_TLB16(mp1_smnif_tlv2_reg, tlb16) \
      mp1_smnif_tlv2_reg = (mp1_smnif_tlv2_reg & ~MP1_SMNIF_TLV2_TLB16_MASK) | (tlb16 << MP1_SMNIF_TLV2_TLB16_SHIFT)
#define MP1_SMNIF_TLV2_SET_TLB17(mp1_smnif_tlv2_reg, tlb17) \
      mp1_smnif_tlv2_reg = (mp1_smnif_tlv2_reg & ~MP1_SMNIF_TLV2_TLB17_MASK) | (tlb17 << MP1_SMNIF_TLV2_TLB17_SHIFT)
#define MP1_SMNIF_TLV2_SET_TLB18(mp1_smnif_tlv2_reg, tlb18) \
      mp1_smnif_tlv2_reg = (mp1_smnif_tlv2_reg & ~MP1_SMNIF_TLV2_TLB18_MASK) | (tlb18 << MP1_SMNIF_TLV2_TLB18_SHIFT)
#define MP1_SMNIF_TLV2_SET_TLB19(mp1_smnif_tlv2_reg, tlb19) \
      mp1_smnif_tlv2_reg = (mp1_smnif_tlv2_reg & ~MP1_SMNIF_TLV2_TLB19_MASK) | (tlb19 << MP1_SMNIF_TLV2_TLB19_SHIFT)
#define MP1_SMNIF_TLV2_SET_TLB20(mp1_smnif_tlv2_reg, tlb20) \
      mp1_smnif_tlv2_reg = (mp1_smnif_tlv2_reg & ~MP1_SMNIF_TLV2_TLB20_MASK) | (tlb20 << MP1_SMNIF_TLV2_TLB20_SHIFT)
#define MP1_SMNIF_TLV2_SET_TLB21(mp1_smnif_tlv2_reg, tlb21) \
      mp1_smnif_tlv2_reg = (mp1_smnif_tlv2_reg & ~MP1_SMNIF_TLV2_TLB21_MASK) | (tlb21 << MP1_SMNIF_TLV2_TLB21_SHIFT)
#define MP1_SMNIF_TLV2_SET_TLB22(mp1_smnif_tlv2_reg, tlb22) \
      mp1_smnif_tlv2_reg = (mp1_smnif_tlv2_reg & ~MP1_SMNIF_TLV2_TLB22_MASK) | (tlb22 << MP1_SMNIF_TLV2_TLB22_SHIFT)
#define MP1_SMNIF_TLV2_SET_TLB23(mp1_smnif_tlv2_reg, tlb23) \
      mp1_smnif_tlv2_reg = (mp1_smnif_tlv2_reg & ~MP1_SMNIF_TLV2_TLB23_MASK) | (tlb23 << MP1_SMNIF_TLV2_TLB23_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlv2_t {
            unsigned int tlb16                          : MP1_SMNIF_TLV2_TLB16_SIZE;
            unsigned int                                : 1;
            unsigned int tlb17                          : MP1_SMNIF_TLV2_TLB17_SIZE;
            unsigned int                                : 1;
            unsigned int tlb18                          : MP1_SMNIF_TLV2_TLB18_SIZE;
            unsigned int                                : 1;
            unsigned int tlb19                          : MP1_SMNIF_TLV2_TLB19_SIZE;
            unsigned int                                : 1;
            unsigned int tlb20                          : MP1_SMNIF_TLV2_TLB20_SIZE;
            unsigned int                                : 1;
            unsigned int tlb21                          : MP1_SMNIF_TLV2_TLB21_SIZE;
            unsigned int                                : 1;
            unsigned int tlb22                          : MP1_SMNIF_TLV2_TLB22_SIZE;
            unsigned int                                : 1;
            unsigned int tlb23                          : MP1_SMNIF_TLV2_TLB23_SIZE;
            unsigned int                                : 1;
      } mp1_smnif_tlv2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlv2_t {
            unsigned int                                : 1;
            unsigned int tlb23                          : MP1_SMNIF_TLV2_TLB23_SIZE;
            unsigned int                                : 1;
            unsigned int tlb22                          : MP1_SMNIF_TLV2_TLB22_SIZE;
            unsigned int                                : 1;
            unsigned int tlb21                          : MP1_SMNIF_TLV2_TLB21_SIZE;
            unsigned int                                : 1;
            unsigned int tlb20                          : MP1_SMNIF_TLV2_TLB20_SIZE;
            unsigned int                                : 1;
            unsigned int tlb19                          : MP1_SMNIF_TLV2_TLB19_SIZE;
            unsigned int                                : 1;
            unsigned int tlb18                          : MP1_SMNIF_TLV2_TLB18_SIZE;
            unsigned int                                : 1;
            unsigned int tlb17                          : MP1_SMNIF_TLV2_TLB17_SIZE;
            unsigned int                                : 1;
            unsigned int tlb16                          : MP1_SMNIF_TLV2_TLB16_SIZE;
      } mp1_smnif_tlv2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlv2_t f;
} mp1_smnif_tlv2_u;


/*
 * MP1_SMNIF_TLV3 struct
 */

#define MP1_SMNIF_TLV3_REG_SIZE         32
#define MP1_SMNIF_TLV3_TLB24_SIZE  3
#define MP1_SMNIF_TLV3_TLB25_SIZE  3
#define MP1_SMNIF_TLV3_TLB26_SIZE  3
#define MP1_SMNIF_TLV3_TLB27_SIZE  3
#define MP1_SMNIF_TLV3_TLB28_SIZE  3
#define MP1_SMNIF_TLV3_TLB29_SIZE  3
#define MP1_SMNIF_TLV3_TLB30_SIZE  3
#define MP1_SMNIF_TLV3_TLB31_SIZE  3

#define MP1_SMNIF_TLV3_TLB24_SHIFT  0
#define MP1_SMNIF_TLV3_TLB25_SHIFT  4
#define MP1_SMNIF_TLV3_TLB26_SHIFT  8
#define MP1_SMNIF_TLV3_TLB27_SHIFT  12
#define MP1_SMNIF_TLV3_TLB28_SHIFT  16
#define MP1_SMNIF_TLV3_TLB29_SHIFT  20
#define MP1_SMNIF_TLV3_TLB30_SHIFT  24
#define MP1_SMNIF_TLV3_TLB31_SHIFT  28

#define MP1_SMNIF_TLV3_TLB24_MASK       0x00000007
#define MP1_SMNIF_TLV3_TLB25_MASK       0x00000070
#define MP1_SMNIF_TLV3_TLB26_MASK       0x00000700
#define MP1_SMNIF_TLV3_TLB27_MASK       0x00007000
#define MP1_SMNIF_TLV3_TLB28_MASK       0x00070000
#define MP1_SMNIF_TLV3_TLB29_MASK       0x00700000
#define MP1_SMNIF_TLV3_TLB30_MASK       0x07000000
#define MP1_SMNIF_TLV3_TLB31_MASK       0x70000000

#define MP1_SMNIF_TLV3_MASK \
      (MP1_SMNIF_TLV3_TLB24_MASK | \
      MP1_SMNIF_TLV3_TLB25_MASK | \
      MP1_SMNIF_TLV3_TLB26_MASK | \
      MP1_SMNIF_TLV3_TLB27_MASK | \
      MP1_SMNIF_TLV3_TLB28_MASK | \
      MP1_SMNIF_TLV3_TLB29_MASK | \
      MP1_SMNIF_TLV3_TLB30_MASK | \
      MP1_SMNIF_TLV3_TLB31_MASK)

#define MP1_SMNIF_TLV3_DEFAULT         0x00000000

#define MP1_SMNIF_TLV3_GET_TLB24(mp1_smnif_tlv3) \
      ((mp1_smnif_tlv3 & MP1_SMNIF_TLV3_TLB24_MASK) >> MP1_SMNIF_TLV3_TLB24_SHIFT)
#define MP1_SMNIF_TLV3_GET_TLB25(mp1_smnif_tlv3) \
      ((mp1_smnif_tlv3 & MP1_SMNIF_TLV3_TLB25_MASK) >> MP1_SMNIF_TLV3_TLB25_SHIFT)
#define MP1_SMNIF_TLV3_GET_TLB26(mp1_smnif_tlv3) \
      ((mp1_smnif_tlv3 & MP1_SMNIF_TLV3_TLB26_MASK) >> MP1_SMNIF_TLV3_TLB26_SHIFT)
#define MP1_SMNIF_TLV3_GET_TLB27(mp1_smnif_tlv3) \
      ((mp1_smnif_tlv3 & MP1_SMNIF_TLV3_TLB27_MASK) >> MP1_SMNIF_TLV3_TLB27_SHIFT)
#define MP1_SMNIF_TLV3_GET_TLB28(mp1_smnif_tlv3) \
      ((mp1_smnif_tlv3 & MP1_SMNIF_TLV3_TLB28_MASK) >> MP1_SMNIF_TLV3_TLB28_SHIFT)
#define MP1_SMNIF_TLV3_GET_TLB29(mp1_smnif_tlv3) \
      ((mp1_smnif_tlv3 & MP1_SMNIF_TLV3_TLB29_MASK) >> MP1_SMNIF_TLV3_TLB29_SHIFT)
#define MP1_SMNIF_TLV3_GET_TLB30(mp1_smnif_tlv3) \
      ((mp1_smnif_tlv3 & MP1_SMNIF_TLV3_TLB30_MASK) >> MP1_SMNIF_TLV3_TLB30_SHIFT)
#define MP1_SMNIF_TLV3_GET_TLB31(mp1_smnif_tlv3) \
      ((mp1_smnif_tlv3 & MP1_SMNIF_TLV3_TLB31_MASK) >> MP1_SMNIF_TLV3_TLB31_SHIFT)

#define MP1_SMNIF_TLV3_SET_TLB24(mp1_smnif_tlv3_reg, tlb24) \
      mp1_smnif_tlv3_reg = (mp1_smnif_tlv3_reg & ~MP1_SMNIF_TLV3_TLB24_MASK) | (tlb24 << MP1_SMNIF_TLV3_TLB24_SHIFT)
#define MP1_SMNIF_TLV3_SET_TLB25(mp1_smnif_tlv3_reg, tlb25) \
      mp1_smnif_tlv3_reg = (mp1_smnif_tlv3_reg & ~MP1_SMNIF_TLV3_TLB25_MASK) | (tlb25 << MP1_SMNIF_TLV3_TLB25_SHIFT)
#define MP1_SMNIF_TLV3_SET_TLB26(mp1_smnif_tlv3_reg, tlb26) \
      mp1_smnif_tlv3_reg = (mp1_smnif_tlv3_reg & ~MP1_SMNIF_TLV3_TLB26_MASK) | (tlb26 << MP1_SMNIF_TLV3_TLB26_SHIFT)
#define MP1_SMNIF_TLV3_SET_TLB27(mp1_smnif_tlv3_reg, tlb27) \
      mp1_smnif_tlv3_reg = (mp1_smnif_tlv3_reg & ~MP1_SMNIF_TLV3_TLB27_MASK) | (tlb27 << MP1_SMNIF_TLV3_TLB27_SHIFT)
#define MP1_SMNIF_TLV3_SET_TLB28(mp1_smnif_tlv3_reg, tlb28) \
      mp1_smnif_tlv3_reg = (mp1_smnif_tlv3_reg & ~MP1_SMNIF_TLV3_TLB28_MASK) | (tlb28 << MP1_SMNIF_TLV3_TLB28_SHIFT)
#define MP1_SMNIF_TLV3_SET_TLB29(mp1_smnif_tlv3_reg, tlb29) \
      mp1_smnif_tlv3_reg = (mp1_smnif_tlv3_reg & ~MP1_SMNIF_TLV3_TLB29_MASK) | (tlb29 << MP1_SMNIF_TLV3_TLB29_SHIFT)
#define MP1_SMNIF_TLV3_SET_TLB30(mp1_smnif_tlv3_reg, tlb30) \
      mp1_smnif_tlv3_reg = (mp1_smnif_tlv3_reg & ~MP1_SMNIF_TLV3_TLB30_MASK) | (tlb30 << MP1_SMNIF_TLV3_TLB30_SHIFT)
#define MP1_SMNIF_TLV3_SET_TLB31(mp1_smnif_tlv3_reg, tlb31) \
      mp1_smnif_tlv3_reg = (mp1_smnif_tlv3_reg & ~MP1_SMNIF_TLV3_TLB31_MASK) | (tlb31 << MP1_SMNIF_TLV3_TLB31_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlv3_t {
            unsigned int tlb24                          : MP1_SMNIF_TLV3_TLB24_SIZE;
            unsigned int                                : 1;
            unsigned int tlb25                          : MP1_SMNIF_TLV3_TLB25_SIZE;
            unsigned int                                : 1;
            unsigned int tlb26                          : MP1_SMNIF_TLV3_TLB26_SIZE;
            unsigned int                                : 1;
            unsigned int tlb27                          : MP1_SMNIF_TLV3_TLB27_SIZE;
            unsigned int                                : 1;
            unsigned int tlb28                          : MP1_SMNIF_TLV3_TLB28_SIZE;
            unsigned int                                : 1;
            unsigned int tlb29                          : MP1_SMNIF_TLV3_TLB29_SIZE;
            unsigned int                                : 1;
            unsigned int tlb30                          : MP1_SMNIF_TLV3_TLB30_SIZE;
            unsigned int                                : 1;
            unsigned int tlb31                          : MP1_SMNIF_TLV3_TLB31_SIZE;
            unsigned int                                : 1;
      } mp1_smnif_tlv3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlv3_t {
            unsigned int                                : 1;
            unsigned int tlb31                          : MP1_SMNIF_TLV3_TLB31_SIZE;
            unsigned int                                : 1;
            unsigned int tlb30                          : MP1_SMNIF_TLV3_TLB30_SIZE;
            unsigned int                                : 1;
            unsigned int tlb29                          : MP1_SMNIF_TLV3_TLB29_SIZE;
            unsigned int                                : 1;
            unsigned int tlb28                          : MP1_SMNIF_TLV3_TLB28_SIZE;
            unsigned int                                : 1;
            unsigned int tlb27                          : MP1_SMNIF_TLV3_TLB27_SIZE;
            unsigned int                                : 1;
            unsigned int tlb26                          : MP1_SMNIF_TLV3_TLB26_SIZE;
            unsigned int                                : 1;
            unsigned int tlb25                          : MP1_SMNIF_TLV3_TLB25_SIZE;
            unsigned int                                : 1;
            unsigned int tlb24                          : MP1_SMNIF_TLV3_TLB24_SIZE;
      } mp1_smnif_tlv3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlv3_t f;
} mp1_smnif_tlv3_u;


/*
 * MP1_SMNIF_TLV4 struct
 */

#define MP1_SMNIF_TLV4_REG_SIZE         32
#define MP1_SMNIF_TLV4_TLB32_SIZE  3
#define MP1_SMNIF_TLV4_TLB33_SIZE  3
#define MP1_SMNIF_TLV4_TLB34_SIZE  3
#define MP1_SMNIF_TLV4_TLB35_SIZE  3
#define MP1_SMNIF_TLV4_TLB36_SIZE  3
#define MP1_SMNIF_TLV4_TLB37_SIZE  3
#define MP1_SMNIF_TLV4_TLB38_SIZE  3
#define MP1_SMNIF_TLV4_TLB39_SIZE  3

#define MP1_SMNIF_TLV4_TLB32_SHIFT  0
#define MP1_SMNIF_TLV4_TLB33_SHIFT  4
#define MP1_SMNIF_TLV4_TLB34_SHIFT  8
#define MP1_SMNIF_TLV4_TLB35_SHIFT  12
#define MP1_SMNIF_TLV4_TLB36_SHIFT  16
#define MP1_SMNIF_TLV4_TLB37_SHIFT  20
#define MP1_SMNIF_TLV4_TLB38_SHIFT  24
#define MP1_SMNIF_TLV4_TLB39_SHIFT  28

#define MP1_SMNIF_TLV4_TLB32_MASK       0x00000007
#define MP1_SMNIF_TLV4_TLB33_MASK       0x00000070
#define MP1_SMNIF_TLV4_TLB34_MASK       0x00000700
#define MP1_SMNIF_TLV4_TLB35_MASK       0x00007000
#define MP1_SMNIF_TLV4_TLB36_MASK       0x00070000
#define MP1_SMNIF_TLV4_TLB37_MASK       0x00700000
#define MP1_SMNIF_TLV4_TLB38_MASK       0x07000000
#define MP1_SMNIF_TLV4_TLB39_MASK       0x70000000

#define MP1_SMNIF_TLV4_MASK \
      (MP1_SMNIF_TLV4_TLB32_MASK | \
      MP1_SMNIF_TLV4_TLB33_MASK | \
      MP1_SMNIF_TLV4_TLB34_MASK | \
      MP1_SMNIF_TLV4_TLB35_MASK | \
      MP1_SMNIF_TLV4_TLB36_MASK | \
      MP1_SMNIF_TLV4_TLB37_MASK | \
      MP1_SMNIF_TLV4_TLB38_MASK | \
      MP1_SMNIF_TLV4_TLB39_MASK)

#define MP1_SMNIF_TLV4_DEFAULT         0x00000000

#define MP1_SMNIF_TLV4_GET_TLB32(mp1_smnif_tlv4) \
      ((mp1_smnif_tlv4 & MP1_SMNIF_TLV4_TLB32_MASK) >> MP1_SMNIF_TLV4_TLB32_SHIFT)
#define MP1_SMNIF_TLV4_GET_TLB33(mp1_smnif_tlv4) \
      ((mp1_smnif_tlv4 & MP1_SMNIF_TLV4_TLB33_MASK) >> MP1_SMNIF_TLV4_TLB33_SHIFT)
#define MP1_SMNIF_TLV4_GET_TLB34(mp1_smnif_tlv4) \
      ((mp1_smnif_tlv4 & MP1_SMNIF_TLV4_TLB34_MASK) >> MP1_SMNIF_TLV4_TLB34_SHIFT)
#define MP1_SMNIF_TLV4_GET_TLB35(mp1_smnif_tlv4) \
      ((mp1_smnif_tlv4 & MP1_SMNIF_TLV4_TLB35_MASK) >> MP1_SMNIF_TLV4_TLB35_SHIFT)
#define MP1_SMNIF_TLV4_GET_TLB36(mp1_smnif_tlv4) \
      ((mp1_smnif_tlv4 & MP1_SMNIF_TLV4_TLB36_MASK) >> MP1_SMNIF_TLV4_TLB36_SHIFT)
#define MP1_SMNIF_TLV4_GET_TLB37(mp1_smnif_tlv4) \
      ((mp1_smnif_tlv4 & MP1_SMNIF_TLV4_TLB37_MASK) >> MP1_SMNIF_TLV4_TLB37_SHIFT)
#define MP1_SMNIF_TLV4_GET_TLB38(mp1_smnif_tlv4) \
      ((mp1_smnif_tlv4 & MP1_SMNIF_TLV4_TLB38_MASK) >> MP1_SMNIF_TLV4_TLB38_SHIFT)
#define MP1_SMNIF_TLV4_GET_TLB39(mp1_smnif_tlv4) \
      ((mp1_smnif_tlv4 & MP1_SMNIF_TLV4_TLB39_MASK) >> MP1_SMNIF_TLV4_TLB39_SHIFT)

#define MP1_SMNIF_TLV4_SET_TLB32(mp1_smnif_tlv4_reg, tlb32) \
      mp1_smnif_tlv4_reg = (mp1_smnif_tlv4_reg & ~MP1_SMNIF_TLV4_TLB32_MASK) | (tlb32 << MP1_SMNIF_TLV4_TLB32_SHIFT)
#define MP1_SMNIF_TLV4_SET_TLB33(mp1_smnif_tlv4_reg, tlb33) \
      mp1_smnif_tlv4_reg = (mp1_smnif_tlv4_reg & ~MP1_SMNIF_TLV4_TLB33_MASK) | (tlb33 << MP1_SMNIF_TLV4_TLB33_SHIFT)
#define MP1_SMNIF_TLV4_SET_TLB34(mp1_smnif_tlv4_reg, tlb34) \
      mp1_smnif_tlv4_reg = (mp1_smnif_tlv4_reg & ~MP1_SMNIF_TLV4_TLB34_MASK) | (tlb34 << MP1_SMNIF_TLV4_TLB34_SHIFT)
#define MP1_SMNIF_TLV4_SET_TLB35(mp1_smnif_tlv4_reg, tlb35) \
      mp1_smnif_tlv4_reg = (mp1_smnif_tlv4_reg & ~MP1_SMNIF_TLV4_TLB35_MASK) | (tlb35 << MP1_SMNIF_TLV4_TLB35_SHIFT)
#define MP1_SMNIF_TLV4_SET_TLB36(mp1_smnif_tlv4_reg, tlb36) \
      mp1_smnif_tlv4_reg = (mp1_smnif_tlv4_reg & ~MP1_SMNIF_TLV4_TLB36_MASK) | (tlb36 << MP1_SMNIF_TLV4_TLB36_SHIFT)
#define MP1_SMNIF_TLV4_SET_TLB37(mp1_smnif_tlv4_reg, tlb37) \
      mp1_smnif_tlv4_reg = (mp1_smnif_tlv4_reg & ~MP1_SMNIF_TLV4_TLB37_MASK) | (tlb37 << MP1_SMNIF_TLV4_TLB37_SHIFT)
#define MP1_SMNIF_TLV4_SET_TLB38(mp1_smnif_tlv4_reg, tlb38) \
      mp1_smnif_tlv4_reg = (mp1_smnif_tlv4_reg & ~MP1_SMNIF_TLV4_TLB38_MASK) | (tlb38 << MP1_SMNIF_TLV4_TLB38_SHIFT)
#define MP1_SMNIF_TLV4_SET_TLB39(mp1_smnif_tlv4_reg, tlb39) \
      mp1_smnif_tlv4_reg = (mp1_smnif_tlv4_reg & ~MP1_SMNIF_TLV4_TLB39_MASK) | (tlb39 << MP1_SMNIF_TLV4_TLB39_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlv4_t {
            unsigned int tlb32                          : MP1_SMNIF_TLV4_TLB32_SIZE;
            unsigned int                                : 1;
            unsigned int tlb33                          : MP1_SMNIF_TLV4_TLB33_SIZE;
            unsigned int                                : 1;
            unsigned int tlb34                          : MP1_SMNIF_TLV4_TLB34_SIZE;
            unsigned int                                : 1;
            unsigned int tlb35                          : MP1_SMNIF_TLV4_TLB35_SIZE;
            unsigned int                                : 1;
            unsigned int tlb36                          : MP1_SMNIF_TLV4_TLB36_SIZE;
            unsigned int                                : 1;
            unsigned int tlb37                          : MP1_SMNIF_TLV4_TLB37_SIZE;
            unsigned int                                : 1;
            unsigned int tlb38                          : MP1_SMNIF_TLV4_TLB38_SIZE;
            unsigned int                                : 1;
            unsigned int tlb39                          : MP1_SMNIF_TLV4_TLB39_SIZE;
            unsigned int                                : 1;
      } mp1_smnif_tlv4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlv4_t {
            unsigned int                                : 1;
            unsigned int tlb39                          : MP1_SMNIF_TLV4_TLB39_SIZE;
            unsigned int                                : 1;
            unsigned int tlb38                          : MP1_SMNIF_TLV4_TLB38_SIZE;
            unsigned int                                : 1;
            unsigned int tlb37                          : MP1_SMNIF_TLV4_TLB37_SIZE;
            unsigned int                                : 1;
            unsigned int tlb36                          : MP1_SMNIF_TLV4_TLB36_SIZE;
            unsigned int                                : 1;
            unsigned int tlb35                          : MP1_SMNIF_TLV4_TLB35_SIZE;
            unsigned int                                : 1;
            unsigned int tlb34                          : MP1_SMNIF_TLV4_TLB34_SIZE;
            unsigned int                                : 1;
            unsigned int tlb33                          : MP1_SMNIF_TLV4_TLB33_SIZE;
            unsigned int                                : 1;
            unsigned int tlb32                          : MP1_SMNIF_TLV4_TLB32_SIZE;
      } mp1_smnif_tlv4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlv4_t f;
} mp1_smnif_tlv4_u;


/*
 * MP1_SMNIF_TLV5 struct
 */

#define MP1_SMNIF_TLV5_REG_SIZE         32
#define MP1_SMNIF_TLV5_TLB40_SIZE  3
#define MP1_SMNIF_TLV5_TLB41_SIZE  3
#define MP1_SMNIF_TLV5_TLB42_SIZE  3
#define MP1_SMNIF_TLV5_TLB43_SIZE  3
#define MP1_SMNIF_TLV5_TLB44_SIZE  3
#define MP1_SMNIF_TLV5_TLB45_SIZE  3
#define MP1_SMNIF_TLV5_TLB46_SIZE  3
#define MP1_SMNIF_TLV5_TLB47_SIZE  3

#define MP1_SMNIF_TLV5_TLB40_SHIFT  0
#define MP1_SMNIF_TLV5_TLB41_SHIFT  4
#define MP1_SMNIF_TLV5_TLB42_SHIFT  8
#define MP1_SMNIF_TLV5_TLB43_SHIFT  12
#define MP1_SMNIF_TLV5_TLB44_SHIFT  16
#define MP1_SMNIF_TLV5_TLB45_SHIFT  20
#define MP1_SMNIF_TLV5_TLB46_SHIFT  24
#define MP1_SMNIF_TLV5_TLB47_SHIFT  28

#define MP1_SMNIF_TLV5_TLB40_MASK       0x00000007
#define MP1_SMNIF_TLV5_TLB41_MASK       0x00000070
#define MP1_SMNIF_TLV5_TLB42_MASK       0x00000700
#define MP1_SMNIF_TLV5_TLB43_MASK       0x00007000
#define MP1_SMNIF_TLV5_TLB44_MASK       0x00070000
#define MP1_SMNIF_TLV5_TLB45_MASK       0x00700000
#define MP1_SMNIF_TLV5_TLB46_MASK       0x07000000
#define MP1_SMNIF_TLV5_TLB47_MASK       0x70000000

#define MP1_SMNIF_TLV5_MASK \
      (MP1_SMNIF_TLV5_TLB40_MASK | \
      MP1_SMNIF_TLV5_TLB41_MASK | \
      MP1_SMNIF_TLV5_TLB42_MASK | \
      MP1_SMNIF_TLV5_TLB43_MASK | \
      MP1_SMNIF_TLV5_TLB44_MASK | \
      MP1_SMNIF_TLV5_TLB45_MASK | \
      MP1_SMNIF_TLV5_TLB46_MASK | \
      MP1_SMNIF_TLV5_TLB47_MASK)

#define MP1_SMNIF_TLV5_DEFAULT         0x00000000

#define MP1_SMNIF_TLV5_GET_TLB40(mp1_smnif_tlv5) \
      ((mp1_smnif_tlv5 & MP1_SMNIF_TLV5_TLB40_MASK) >> MP1_SMNIF_TLV5_TLB40_SHIFT)
#define MP1_SMNIF_TLV5_GET_TLB41(mp1_smnif_tlv5) \
      ((mp1_smnif_tlv5 & MP1_SMNIF_TLV5_TLB41_MASK) >> MP1_SMNIF_TLV5_TLB41_SHIFT)
#define MP1_SMNIF_TLV5_GET_TLB42(mp1_smnif_tlv5) \
      ((mp1_smnif_tlv5 & MP1_SMNIF_TLV5_TLB42_MASK) >> MP1_SMNIF_TLV5_TLB42_SHIFT)
#define MP1_SMNIF_TLV5_GET_TLB43(mp1_smnif_tlv5) \
      ((mp1_smnif_tlv5 & MP1_SMNIF_TLV5_TLB43_MASK) >> MP1_SMNIF_TLV5_TLB43_SHIFT)
#define MP1_SMNIF_TLV5_GET_TLB44(mp1_smnif_tlv5) \
      ((mp1_smnif_tlv5 & MP1_SMNIF_TLV5_TLB44_MASK) >> MP1_SMNIF_TLV5_TLB44_SHIFT)
#define MP1_SMNIF_TLV5_GET_TLB45(mp1_smnif_tlv5) \
      ((mp1_smnif_tlv5 & MP1_SMNIF_TLV5_TLB45_MASK) >> MP1_SMNIF_TLV5_TLB45_SHIFT)
#define MP1_SMNIF_TLV5_GET_TLB46(mp1_smnif_tlv5) \
      ((mp1_smnif_tlv5 & MP1_SMNIF_TLV5_TLB46_MASK) >> MP1_SMNIF_TLV5_TLB46_SHIFT)
#define MP1_SMNIF_TLV5_GET_TLB47(mp1_smnif_tlv5) \
      ((mp1_smnif_tlv5 & MP1_SMNIF_TLV5_TLB47_MASK) >> MP1_SMNIF_TLV5_TLB47_SHIFT)

#define MP1_SMNIF_TLV5_SET_TLB40(mp1_smnif_tlv5_reg, tlb40) \
      mp1_smnif_tlv5_reg = (mp1_smnif_tlv5_reg & ~MP1_SMNIF_TLV5_TLB40_MASK) | (tlb40 << MP1_SMNIF_TLV5_TLB40_SHIFT)
#define MP1_SMNIF_TLV5_SET_TLB41(mp1_smnif_tlv5_reg, tlb41) \
      mp1_smnif_tlv5_reg = (mp1_smnif_tlv5_reg & ~MP1_SMNIF_TLV5_TLB41_MASK) | (tlb41 << MP1_SMNIF_TLV5_TLB41_SHIFT)
#define MP1_SMNIF_TLV5_SET_TLB42(mp1_smnif_tlv5_reg, tlb42) \
      mp1_smnif_tlv5_reg = (mp1_smnif_tlv5_reg & ~MP1_SMNIF_TLV5_TLB42_MASK) | (tlb42 << MP1_SMNIF_TLV5_TLB42_SHIFT)
#define MP1_SMNIF_TLV5_SET_TLB43(mp1_smnif_tlv5_reg, tlb43) \
      mp1_smnif_tlv5_reg = (mp1_smnif_tlv5_reg & ~MP1_SMNIF_TLV5_TLB43_MASK) | (tlb43 << MP1_SMNIF_TLV5_TLB43_SHIFT)
#define MP1_SMNIF_TLV5_SET_TLB44(mp1_smnif_tlv5_reg, tlb44) \
      mp1_smnif_tlv5_reg = (mp1_smnif_tlv5_reg & ~MP1_SMNIF_TLV5_TLB44_MASK) | (tlb44 << MP1_SMNIF_TLV5_TLB44_SHIFT)
#define MP1_SMNIF_TLV5_SET_TLB45(mp1_smnif_tlv5_reg, tlb45) \
      mp1_smnif_tlv5_reg = (mp1_smnif_tlv5_reg & ~MP1_SMNIF_TLV5_TLB45_MASK) | (tlb45 << MP1_SMNIF_TLV5_TLB45_SHIFT)
#define MP1_SMNIF_TLV5_SET_TLB46(mp1_smnif_tlv5_reg, tlb46) \
      mp1_smnif_tlv5_reg = (mp1_smnif_tlv5_reg & ~MP1_SMNIF_TLV5_TLB46_MASK) | (tlb46 << MP1_SMNIF_TLV5_TLB46_SHIFT)
#define MP1_SMNIF_TLV5_SET_TLB47(mp1_smnif_tlv5_reg, tlb47) \
      mp1_smnif_tlv5_reg = (mp1_smnif_tlv5_reg & ~MP1_SMNIF_TLV5_TLB47_MASK) | (tlb47 << MP1_SMNIF_TLV5_TLB47_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlv5_t {
            unsigned int tlb40                          : MP1_SMNIF_TLV5_TLB40_SIZE;
            unsigned int                                : 1;
            unsigned int tlb41                          : MP1_SMNIF_TLV5_TLB41_SIZE;
            unsigned int                                : 1;
            unsigned int tlb42                          : MP1_SMNIF_TLV5_TLB42_SIZE;
            unsigned int                                : 1;
            unsigned int tlb43                          : MP1_SMNIF_TLV5_TLB43_SIZE;
            unsigned int                                : 1;
            unsigned int tlb44                          : MP1_SMNIF_TLV5_TLB44_SIZE;
            unsigned int                                : 1;
            unsigned int tlb45                          : MP1_SMNIF_TLV5_TLB45_SIZE;
            unsigned int                                : 1;
            unsigned int tlb46                          : MP1_SMNIF_TLV5_TLB46_SIZE;
            unsigned int                                : 1;
            unsigned int tlb47                          : MP1_SMNIF_TLV5_TLB47_SIZE;
            unsigned int                                : 1;
      } mp1_smnif_tlv5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlv5_t {
            unsigned int                                : 1;
            unsigned int tlb47                          : MP1_SMNIF_TLV5_TLB47_SIZE;
            unsigned int                                : 1;
            unsigned int tlb46                          : MP1_SMNIF_TLV5_TLB46_SIZE;
            unsigned int                                : 1;
            unsigned int tlb45                          : MP1_SMNIF_TLV5_TLB45_SIZE;
            unsigned int                                : 1;
            unsigned int tlb44                          : MP1_SMNIF_TLV5_TLB44_SIZE;
            unsigned int                                : 1;
            unsigned int tlb43                          : MP1_SMNIF_TLV5_TLB43_SIZE;
            unsigned int                                : 1;
            unsigned int tlb42                          : MP1_SMNIF_TLV5_TLB42_SIZE;
            unsigned int                                : 1;
            unsigned int tlb41                          : MP1_SMNIF_TLV5_TLB41_SIZE;
            unsigned int                                : 1;
            unsigned int tlb40                          : MP1_SMNIF_TLV5_TLB40_SIZE;
      } mp1_smnif_tlv5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlv5_t f;
} mp1_smnif_tlv5_u;


/*
 * MP1_SMNIF_TLV6 struct
 */

#define MP1_SMNIF_TLV6_REG_SIZE         32
#define MP1_SMNIF_TLV6_TLB48_SIZE  3
#define MP1_SMNIF_TLV6_TLB49_SIZE  3
#define MP1_SMNIF_TLV6_TLB50_SIZE  3
#define MP1_SMNIF_TLV6_TLB51_SIZE  3
#define MP1_SMNIF_TLV6_TLB52_SIZE  3
#define MP1_SMNIF_TLV6_TLB53_SIZE  3
#define MP1_SMNIF_TLV6_TLB54_SIZE  3
#define MP1_SMNIF_TLV6_TLB55_SIZE  3

#define MP1_SMNIF_TLV6_TLB48_SHIFT  0
#define MP1_SMNIF_TLV6_TLB49_SHIFT  4
#define MP1_SMNIF_TLV6_TLB50_SHIFT  8
#define MP1_SMNIF_TLV6_TLB51_SHIFT  12
#define MP1_SMNIF_TLV6_TLB52_SHIFT  16
#define MP1_SMNIF_TLV6_TLB53_SHIFT  20
#define MP1_SMNIF_TLV6_TLB54_SHIFT  24
#define MP1_SMNIF_TLV6_TLB55_SHIFT  28

#define MP1_SMNIF_TLV6_TLB48_MASK       0x00000007
#define MP1_SMNIF_TLV6_TLB49_MASK       0x00000070
#define MP1_SMNIF_TLV6_TLB50_MASK       0x00000700
#define MP1_SMNIF_TLV6_TLB51_MASK       0x00007000
#define MP1_SMNIF_TLV6_TLB52_MASK       0x00070000
#define MP1_SMNIF_TLV6_TLB53_MASK       0x00700000
#define MP1_SMNIF_TLV6_TLB54_MASK       0x07000000
#define MP1_SMNIF_TLV6_TLB55_MASK       0x70000000

#define MP1_SMNIF_TLV6_MASK \
      (MP1_SMNIF_TLV6_TLB48_MASK | \
      MP1_SMNIF_TLV6_TLB49_MASK | \
      MP1_SMNIF_TLV6_TLB50_MASK | \
      MP1_SMNIF_TLV6_TLB51_MASK | \
      MP1_SMNIF_TLV6_TLB52_MASK | \
      MP1_SMNIF_TLV6_TLB53_MASK | \
      MP1_SMNIF_TLV6_TLB54_MASK | \
      MP1_SMNIF_TLV6_TLB55_MASK)

#define MP1_SMNIF_TLV6_DEFAULT         0x00000000

#define MP1_SMNIF_TLV6_GET_TLB48(mp1_smnif_tlv6) \
      ((mp1_smnif_tlv6 & MP1_SMNIF_TLV6_TLB48_MASK) >> MP1_SMNIF_TLV6_TLB48_SHIFT)
#define MP1_SMNIF_TLV6_GET_TLB49(mp1_smnif_tlv6) \
      ((mp1_smnif_tlv6 & MP1_SMNIF_TLV6_TLB49_MASK) >> MP1_SMNIF_TLV6_TLB49_SHIFT)
#define MP1_SMNIF_TLV6_GET_TLB50(mp1_smnif_tlv6) \
      ((mp1_smnif_tlv6 & MP1_SMNIF_TLV6_TLB50_MASK) >> MP1_SMNIF_TLV6_TLB50_SHIFT)
#define MP1_SMNIF_TLV6_GET_TLB51(mp1_smnif_tlv6) \
      ((mp1_smnif_tlv6 & MP1_SMNIF_TLV6_TLB51_MASK) >> MP1_SMNIF_TLV6_TLB51_SHIFT)
#define MP1_SMNIF_TLV6_GET_TLB52(mp1_smnif_tlv6) \
      ((mp1_smnif_tlv6 & MP1_SMNIF_TLV6_TLB52_MASK) >> MP1_SMNIF_TLV6_TLB52_SHIFT)
#define MP1_SMNIF_TLV6_GET_TLB53(mp1_smnif_tlv6) \
      ((mp1_smnif_tlv6 & MP1_SMNIF_TLV6_TLB53_MASK) >> MP1_SMNIF_TLV6_TLB53_SHIFT)
#define MP1_SMNIF_TLV6_GET_TLB54(mp1_smnif_tlv6) \
      ((mp1_smnif_tlv6 & MP1_SMNIF_TLV6_TLB54_MASK) >> MP1_SMNIF_TLV6_TLB54_SHIFT)
#define MP1_SMNIF_TLV6_GET_TLB55(mp1_smnif_tlv6) \
      ((mp1_smnif_tlv6 & MP1_SMNIF_TLV6_TLB55_MASK) >> MP1_SMNIF_TLV6_TLB55_SHIFT)

#define MP1_SMNIF_TLV6_SET_TLB48(mp1_smnif_tlv6_reg, tlb48) \
      mp1_smnif_tlv6_reg = (mp1_smnif_tlv6_reg & ~MP1_SMNIF_TLV6_TLB48_MASK) | (tlb48 << MP1_SMNIF_TLV6_TLB48_SHIFT)
#define MP1_SMNIF_TLV6_SET_TLB49(mp1_smnif_tlv6_reg, tlb49) \
      mp1_smnif_tlv6_reg = (mp1_smnif_tlv6_reg & ~MP1_SMNIF_TLV6_TLB49_MASK) | (tlb49 << MP1_SMNIF_TLV6_TLB49_SHIFT)
#define MP1_SMNIF_TLV6_SET_TLB50(mp1_smnif_tlv6_reg, tlb50) \
      mp1_smnif_tlv6_reg = (mp1_smnif_tlv6_reg & ~MP1_SMNIF_TLV6_TLB50_MASK) | (tlb50 << MP1_SMNIF_TLV6_TLB50_SHIFT)
#define MP1_SMNIF_TLV6_SET_TLB51(mp1_smnif_tlv6_reg, tlb51) \
      mp1_smnif_tlv6_reg = (mp1_smnif_tlv6_reg & ~MP1_SMNIF_TLV6_TLB51_MASK) | (tlb51 << MP1_SMNIF_TLV6_TLB51_SHIFT)
#define MP1_SMNIF_TLV6_SET_TLB52(mp1_smnif_tlv6_reg, tlb52) \
      mp1_smnif_tlv6_reg = (mp1_smnif_tlv6_reg & ~MP1_SMNIF_TLV6_TLB52_MASK) | (tlb52 << MP1_SMNIF_TLV6_TLB52_SHIFT)
#define MP1_SMNIF_TLV6_SET_TLB53(mp1_smnif_tlv6_reg, tlb53) \
      mp1_smnif_tlv6_reg = (mp1_smnif_tlv6_reg & ~MP1_SMNIF_TLV6_TLB53_MASK) | (tlb53 << MP1_SMNIF_TLV6_TLB53_SHIFT)
#define MP1_SMNIF_TLV6_SET_TLB54(mp1_smnif_tlv6_reg, tlb54) \
      mp1_smnif_tlv6_reg = (mp1_smnif_tlv6_reg & ~MP1_SMNIF_TLV6_TLB54_MASK) | (tlb54 << MP1_SMNIF_TLV6_TLB54_SHIFT)
#define MP1_SMNIF_TLV6_SET_TLB55(mp1_smnif_tlv6_reg, tlb55) \
      mp1_smnif_tlv6_reg = (mp1_smnif_tlv6_reg & ~MP1_SMNIF_TLV6_TLB55_MASK) | (tlb55 << MP1_SMNIF_TLV6_TLB55_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlv6_t {
            unsigned int tlb48                          : MP1_SMNIF_TLV6_TLB48_SIZE;
            unsigned int                                : 1;
            unsigned int tlb49                          : MP1_SMNIF_TLV6_TLB49_SIZE;
            unsigned int                                : 1;
            unsigned int tlb50                          : MP1_SMNIF_TLV6_TLB50_SIZE;
            unsigned int                                : 1;
            unsigned int tlb51                          : MP1_SMNIF_TLV6_TLB51_SIZE;
            unsigned int                                : 1;
            unsigned int tlb52                          : MP1_SMNIF_TLV6_TLB52_SIZE;
            unsigned int                                : 1;
            unsigned int tlb53                          : MP1_SMNIF_TLV6_TLB53_SIZE;
            unsigned int                                : 1;
            unsigned int tlb54                          : MP1_SMNIF_TLV6_TLB54_SIZE;
            unsigned int                                : 1;
            unsigned int tlb55                          : MP1_SMNIF_TLV6_TLB55_SIZE;
            unsigned int                                : 1;
      } mp1_smnif_tlv6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlv6_t {
            unsigned int                                : 1;
            unsigned int tlb55                          : MP1_SMNIF_TLV6_TLB55_SIZE;
            unsigned int                                : 1;
            unsigned int tlb54                          : MP1_SMNIF_TLV6_TLB54_SIZE;
            unsigned int                                : 1;
            unsigned int tlb53                          : MP1_SMNIF_TLV6_TLB53_SIZE;
            unsigned int                                : 1;
            unsigned int tlb52                          : MP1_SMNIF_TLV6_TLB52_SIZE;
            unsigned int                                : 1;
            unsigned int tlb51                          : MP1_SMNIF_TLV6_TLB51_SIZE;
            unsigned int                                : 1;
            unsigned int tlb50                          : MP1_SMNIF_TLV6_TLB50_SIZE;
            unsigned int                                : 1;
            unsigned int tlb49                          : MP1_SMNIF_TLV6_TLB49_SIZE;
            unsigned int                                : 1;
            unsigned int tlb48                          : MP1_SMNIF_TLV6_TLB48_SIZE;
      } mp1_smnif_tlv6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlv6_t f;
} mp1_smnif_tlv6_u;


/*
 * MP1_SMNIF_TLV7 struct
 */

#define MP1_SMNIF_TLV7_REG_SIZE         32
#define MP1_SMNIF_TLV7_TLB56_SIZE  3
#define MP1_SMNIF_TLV7_TLB57_SIZE  3
#define MP1_SMNIF_TLV7_TLB58_SIZE  3
#define MP1_SMNIF_TLV7_TLB59_SIZE  3
#define MP1_SMNIF_TLV7_TLB60_SIZE  3
#define MP1_SMNIF_TLV7_TLB61_SIZE  3
#define MP1_SMNIF_TLV7_TLB62_SIZE  3
#define MP1_SMNIF_TLV7_TLB63_SIZE  3

#define MP1_SMNIF_TLV7_TLB56_SHIFT  0
#define MP1_SMNIF_TLV7_TLB57_SHIFT  4
#define MP1_SMNIF_TLV7_TLB58_SHIFT  8
#define MP1_SMNIF_TLV7_TLB59_SHIFT  12
#define MP1_SMNIF_TLV7_TLB60_SHIFT  16
#define MP1_SMNIF_TLV7_TLB61_SHIFT  20
#define MP1_SMNIF_TLV7_TLB62_SHIFT  24
#define MP1_SMNIF_TLV7_TLB63_SHIFT  28

#define MP1_SMNIF_TLV7_TLB56_MASK       0x00000007
#define MP1_SMNIF_TLV7_TLB57_MASK       0x00000070
#define MP1_SMNIF_TLV7_TLB58_MASK       0x00000700
#define MP1_SMNIF_TLV7_TLB59_MASK       0x00007000
#define MP1_SMNIF_TLV7_TLB60_MASK       0x00070000
#define MP1_SMNIF_TLV7_TLB61_MASK       0x00700000
#define MP1_SMNIF_TLV7_TLB62_MASK       0x07000000
#define MP1_SMNIF_TLV7_TLB63_MASK       0x70000000

#define MP1_SMNIF_TLV7_MASK \
      (MP1_SMNIF_TLV7_TLB56_MASK | \
      MP1_SMNIF_TLV7_TLB57_MASK | \
      MP1_SMNIF_TLV7_TLB58_MASK | \
      MP1_SMNIF_TLV7_TLB59_MASK | \
      MP1_SMNIF_TLV7_TLB60_MASK | \
      MP1_SMNIF_TLV7_TLB61_MASK | \
      MP1_SMNIF_TLV7_TLB62_MASK | \
      MP1_SMNIF_TLV7_TLB63_MASK)

#define MP1_SMNIF_TLV7_DEFAULT         0x00000000

#define MP1_SMNIF_TLV7_GET_TLB56(mp1_smnif_tlv7) \
      ((mp1_smnif_tlv7 & MP1_SMNIF_TLV7_TLB56_MASK) >> MP1_SMNIF_TLV7_TLB56_SHIFT)
#define MP1_SMNIF_TLV7_GET_TLB57(mp1_smnif_tlv7) \
      ((mp1_smnif_tlv7 & MP1_SMNIF_TLV7_TLB57_MASK) >> MP1_SMNIF_TLV7_TLB57_SHIFT)
#define MP1_SMNIF_TLV7_GET_TLB58(mp1_smnif_tlv7) \
      ((mp1_smnif_tlv7 & MP1_SMNIF_TLV7_TLB58_MASK) >> MP1_SMNIF_TLV7_TLB58_SHIFT)
#define MP1_SMNIF_TLV7_GET_TLB59(mp1_smnif_tlv7) \
      ((mp1_smnif_tlv7 & MP1_SMNIF_TLV7_TLB59_MASK) >> MP1_SMNIF_TLV7_TLB59_SHIFT)
#define MP1_SMNIF_TLV7_GET_TLB60(mp1_smnif_tlv7) \
      ((mp1_smnif_tlv7 & MP1_SMNIF_TLV7_TLB60_MASK) >> MP1_SMNIF_TLV7_TLB60_SHIFT)
#define MP1_SMNIF_TLV7_GET_TLB61(mp1_smnif_tlv7) \
      ((mp1_smnif_tlv7 & MP1_SMNIF_TLV7_TLB61_MASK) >> MP1_SMNIF_TLV7_TLB61_SHIFT)
#define MP1_SMNIF_TLV7_GET_TLB62(mp1_smnif_tlv7) \
      ((mp1_smnif_tlv7 & MP1_SMNIF_TLV7_TLB62_MASK) >> MP1_SMNIF_TLV7_TLB62_SHIFT)
#define MP1_SMNIF_TLV7_GET_TLB63(mp1_smnif_tlv7) \
      ((mp1_smnif_tlv7 & MP1_SMNIF_TLV7_TLB63_MASK) >> MP1_SMNIF_TLV7_TLB63_SHIFT)

#define MP1_SMNIF_TLV7_SET_TLB56(mp1_smnif_tlv7_reg, tlb56) \
      mp1_smnif_tlv7_reg = (mp1_smnif_tlv7_reg & ~MP1_SMNIF_TLV7_TLB56_MASK) | (tlb56 << MP1_SMNIF_TLV7_TLB56_SHIFT)
#define MP1_SMNIF_TLV7_SET_TLB57(mp1_smnif_tlv7_reg, tlb57) \
      mp1_smnif_tlv7_reg = (mp1_smnif_tlv7_reg & ~MP1_SMNIF_TLV7_TLB57_MASK) | (tlb57 << MP1_SMNIF_TLV7_TLB57_SHIFT)
#define MP1_SMNIF_TLV7_SET_TLB58(mp1_smnif_tlv7_reg, tlb58) \
      mp1_smnif_tlv7_reg = (mp1_smnif_tlv7_reg & ~MP1_SMNIF_TLV7_TLB58_MASK) | (tlb58 << MP1_SMNIF_TLV7_TLB58_SHIFT)
#define MP1_SMNIF_TLV7_SET_TLB59(mp1_smnif_tlv7_reg, tlb59) \
      mp1_smnif_tlv7_reg = (mp1_smnif_tlv7_reg & ~MP1_SMNIF_TLV7_TLB59_MASK) | (tlb59 << MP1_SMNIF_TLV7_TLB59_SHIFT)
#define MP1_SMNIF_TLV7_SET_TLB60(mp1_smnif_tlv7_reg, tlb60) \
      mp1_smnif_tlv7_reg = (mp1_smnif_tlv7_reg & ~MP1_SMNIF_TLV7_TLB60_MASK) | (tlb60 << MP1_SMNIF_TLV7_TLB60_SHIFT)
#define MP1_SMNIF_TLV7_SET_TLB61(mp1_smnif_tlv7_reg, tlb61) \
      mp1_smnif_tlv7_reg = (mp1_smnif_tlv7_reg & ~MP1_SMNIF_TLV7_TLB61_MASK) | (tlb61 << MP1_SMNIF_TLV7_TLB61_SHIFT)
#define MP1_SMNIF_TLV7_SET_TLB62(mp1_smnif_tlv7_reg, tlb62) \
      mp1_smnif_tlv7_reg = (mp1_smnif_tlv7_reg & ~MP1_SMNIF_TLV7_TLB62_MASK) | (tlb62 << MP1_SMNIF_TLV7_TLB62_SHIFT)
#define MP1_SMNIF_TLV7_SET_TLB63(mp1_smnif_tlv7_reg, tlb63) \
      mp1_smnif_tlv7_reg = (mp1_smnif_tlv7_reg & ~MP1_SMNIF_TLV7_TLB63_MASK) | (tlb63 << MP1_SMNIF_TLV7_TLB63_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlv7_t {
            unsigned int tlb56                          : MP1_SMNIF_TLV7_TLB56_SIZE;
            unsigned int                                : 1;
            unsigned int tlb57                          : MP1_SMNIF_TLV7_TLB57_SIZE;
            unsigned int                                : 1;
            unsigned int tlb58                          : MP1_SMNIF_TLV7_TLB58_SIZE;
            unsigned int                                : 1;
            unsigned int tlb59                          : MP1_SMNIF_TLV7_TLB59_SIZE;
            unsigned int                                : 1;
            unsigned int tlb60                          : MP1_SMNIF_TLV7_TLB60_SIZE;
            unsigned int                                : 1;
            unsigned int tlb61                          : MP1_SMNIF_TLV7_TLB61_SIZE;
            unsigned int                                : 1;
            unsigned int tlb62                          : MP1_SMNIF_TLV7_TLB62_SIZE;
            unsigned int                                : 1;
            unsigned int tlb63                          : MP1_SMNIF_TLV7_TLB63_SIZE;
            unsigned int                                : 1;
      } mp1_smnif_tlv7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlv7_t {
            unsigned int                                : 1;
            unsigned int tlb63                          : MP1_SMNIF_TLV7_TLB63_SIZE;
            unsigned int                                : 1;
            unsigned int tlb62                          : MP1_SMNIF_TLV7_TLB62_SIZE;
            unsigned int                                : 1;
            unsigned int tlb61                          : MP1_SMNIF_TLV7_TLB61_SIZE;
            unsigned int                                : 1;
            unsigned int tlb60                          : MP1_SMNIF_TLV7_TLB60_SIZE;
            unsigned int                                : 1;
            unsigned int tlb59                          : MP1_SMNIF_TLV7_TLB59_SIZE;
            unsigned int                                : 1;
            unsigned int tlb58                          : MP1_SMNIF_TLV7_TLB58_SIZE;
            unsigned int                                : 1;
            unsigned int tlb57                          : MP1_SMNIF_TLV7_TLB57_SIZE;
            unsigned int                                : 1;
            unsigned int tlb56                          : MP1_SMNIF_TLV7_TLB56_SIZE;
      } mp1_smnif_tlv7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlv7_t f;
} mp1_smnif_tlv7_u;


/*
 * MP1_SMNIF_TLB_VF0 struct
 */

#define MP1_SMNIF_TLB_VF0_REG_SIZE         32
#define MP1_SMNIF_TLB_VF0_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF0_VF_SIZE  1
#define MP1_SMNIF_TLB_VF0_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF0_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF0_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF0_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF0_VFID_MASK     0x0000003f
#define MP1_SMNIF_TLB_VF0_VF_MASK       0x00000040
#define MP1_SMNIF_TLB_VF0_VALID_MASK    0x00000080

#define MP1_SMNIF_TLB_VF0_MASK \
      (MP1_SMNIF_TLB_VF0_VFID_MASK | \
      MP1_SMNIF_TLB_VF0_VF_MASK | \
      MP1_SMNIF_TLB_VF0_VALID_MASK)

#define MP1_SMNIF_TLB_VF0_DEFAULT      0x00000000

#define MP1_SMNIF_TLB_VF0_GET_VFID(mp1_smnif_tlb_vf0) \
      ((mp1_smnif_tlb_vf0 & MP1_SMNIF_TLB_VF0_VFID_MASK) >> MP1_SMNIF_TLB_VF0_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF0_GET_VF(mp1_smnif_tlb_vf0) \
      ((mp1_smnif_tlb_vf0 & MP1_SMNIF_TLB_VF0_VF_MASK) >> MP1_SMNIF_TLB_VF0_VF_SHIFT)
#define MP1_SMNIF_TLB_VF0_GET_VALID(mp1_smnif_tlb_vf0) \
      ((mp1_smnif_tlb_vf0 & MP1_SMNIF_TLB_VF0_VALID_MASK) >> MP1_SMNIF_TLB_VF0_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF0_SET_VFID(mp1_smnif_tlb_vf0_reg, vfid) \
      mp1_smnif_tlb_vf0_reg = (mp1_smnif_tlb_vf0_reg & ~MP1_SMNIF_TLB_VF0_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF0_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF0_SET_VF(mp1_smnif_tlb_vf0_reg, vf) \
      mp1_smnif_tlb_vf0_reg = (mp1_smnif_tlb_vf0_reg & ~MP1_SMNIF_TLB_VF0_VF_MASK) | (vf << MP1_SMNIF_TLB_VF0_VF_SHIFT)
#define MP1_SMNIF_TLB_VF0_SET_VALID(mp1_smnif_tlb_vf0_reg, valid) \
      mp1_smnif_tlb_vf0_reg = (mp1_smnif_tlb_vf0_reg & ~MP1_SMNIF_TLB_VF0_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF0_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf0_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF0_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF0_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF0_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf0_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF0_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF0_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF0_VFID_SIZE;
      } mp1_smnif_tlb_vf0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf0_t f;
} mp1_smnif_tlb_vf0_u;


/*
 * MP1_SMNIF_TLB_VF1 struct
 */

#define MP1_SMNIF_TLB_VF1_REG_SIZE         32
#define MP1_SMNIF_TLB_VF1_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF1_VF_SIZE  1
#define MP1_SMNIF_TLB_VF1_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF1_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF1_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF1_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF1_VFID_MASK     0x0000003f
#define MP1_SMNIF_TLB_VF1_VF_MASK       0x00000040
#define MP1_SMNIF_TLB_VF1_VALID_MASK    0x00000080

#define MP1_SMNIF_TLB_VF1_MASK \
      (MP1_SMNIF_TLB_VF1_VFID_MASK | \
      MP1_SMNIF_TLB_VF1_VF_MASK | \
      MP1_SMNIF_TLB_VF1_VALID_MASK)

#define MP1_SMNIF_TLB_VF1_DEFAULT      0x00000000

#define MP1_SMNIF_TLB_VF1_GET_VFID(mp1_smnif_tlb_vf1) \
      ((mp1_smnif_tlb_vf1 & MP1_SMNIF_TLB_VF1_VFID_MASK) >> MP1_SMNIF_TLB_VF1_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF1_GET_VF(mp1_smnif_tlb_vf1) \
      ((mp1_smnif_tlb_vf1 & MP1_SMNIF_TLB_VF1_VF_MASK) >> MP1_SMNIF_TLB_VF1_VF_SHIFT)
#define MP1_SMNIF_TLB_VF1_GET_VALID(mp1_smnif_tlb_vf1) \
      ((mp1_smnif_tlb_vf1 & MP1_SMNIF_TLB_VF1_VALID_MASK) >> MP1_SMNIF_TLB_VF1_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF1_SET_VFID(mp1_smnif_tlb_vf1_reg, vfid) \
      mp1_smnif_tlb_vf1_reg = (mp1_smnif_tlb_vf1_reg & ~MP1_SMNIF_TLB_VF1_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF1_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF1_SET_VF(mp1_smnif_tlb_vf1_reg, vf) \
      mp1_smnif_tlb_vf1_reg = (mp1_smnif_tlb_vf1_reg & ~MP1_SMNIF_TLB_VF1_VF_MASK) | (vf << MP1_SMNIF_TLB_VF1_VF_SHIFT)
#define MP1_SMNIF_TLB_VF1_SET_VALID(mp1_smnif_tlb_vf1_reg, valid) \
      mp1_smnif_tlb_vf1_reg = (mp1_smnif_tlb_vf1_reg & ~MP1_SMNIF_TLB_VF1_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF1_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf1_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF1_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF1_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF1_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf1_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF1_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF1_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF1_VFID_SIZE;
      } mp1_smnif_tlb_vf1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf1_t f;
} mp1_smnif_tlb_vf1_u;


/*
 * MP1_SMNIF_TLB_VF2 struct
 */

#define MP1_SMNIF_TLB_VF2_REG_SIZE         32
#define MP1_SMNIF_TLB_VF2_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF2_VF_SIZE  1
#define MP1_SMNIF_TLB_VF2_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF2_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF2_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF2_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF2_VFID_MASK     0x0000003f
#define MP1_SMNIF_TLB_VF2_VF_MASK       0x00000040
#define MP1_SMNIF_TLB_VF2_VALID_MASK    0x00000080

#define MP1_SMNIF_TLB_VF2_MASK \
      (MP1_SMNIF_TLB_VF2_VFID_MASK | \
      MP1_SMNIF_TLB_VF2_VF_MASK | \
      MP1_SMNIF_TLB_VF2_VALID_MASK)

#define MP1_SMNIF_TLB_VF2_DEFAULT      0x00000000

#define MP1_SMNIF_TLB_VF2_GET_VFID(mp1_smnif_tlb_vf2) \
      ((mp1_smnif_tlb_vf2 & MP1_SMNIF_TLB_VF2_VFID_MASK) >> MP1_SMNIF_TLB_VF2_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF2_GET_VF(mp1_smnif_tlb_vf2) \
      ((mp1_smnif_tlb_vf2 & MP1_SMNIF_TLB_VF2_VF_MASK) >> MP1_SMNIF_TLB_VF2_VF_SHIFT)
#define MP1_SMNIF_TLB_VF2_GET_VALID(mp1_smnif_tlb_vf2) \
      ((mp1_smnif_tlb_vf2 & MP1_SMNIF_TLB_VF2_VALID_MASK) >> MP1_SMNIF_TLB_VF2_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF2_SET_VFID(mp1_smnif_tlb_vf2_reg, vfid) \
      mp1_smnif_tlb_vf2_reg = (mp1_smnif_tlb_vf2_reg & ~MP1_SMNIF_TLB_VF2_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF2_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF2_SET_VF(mp1_smnif_tlb_vf2_reg, vf) \
      mp1_smnif_tlb_vf2_reg = (mp1_smnif_tlb_vf2_reg & ~MP1_SMNIF_TLB_VF2_VF_MASK) | (vf << MP1_SMNIF_TLB_VF2_VF_SHIFT)
#define MP1_SMNIF_TLB_VF2_SET_VALID(mp1_smnif_tlb_vf2_reg, valid) \
      mp1_smnif_tlb_vf2_reg = (mp1_smnif_tlb_vf2_reg & ~MP1_SMNIF_TLB_VF2_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF2_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf2_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF2_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF2_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF2_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf2_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF2_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF2_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF2_VFID_SIZE;
      } mp1_smnif_tlb_vf2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf2_t f;
} mp1_smnif_tlb_vf2_u;


/*
 * MP1_SMNIF_TLB_VF3 struct
 */

#define MP1_SMNIF_TLB_VF3_REG_SIZE         32
#define MP1_SMNIF_TLB_VF3_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF3_VF_SIZE  1
#define MP1_SMNIF_TLB_VF3_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF3_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF3_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF3_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF3_VFID_MASK     0x0000003f
#define MP1_SMNIF_TLB_VF3_VF_MASK       0x00000040
#define MP1_SMNIF_TLB_VF3_VALID_MASK    0x00000080

#define MP1_SMNIF_TLB_VF3_MASK \
      (MP1_SMNIF_TLB_VF3_VFID_MASK | \
      MP1_SMNIF_TLB_VF3_VF_MASK | \
      MP1_SMNIF_TLB_VF3_VALID_MASK)

#define MP1_SMNIF_TLB_VF3_DEFAULT      0x00000000

#define MP1_SMNIF_TLB_VF3_GET_VFID(mp1_smnif_tlb_vf3) \
      ((mp1_smnif_tlb_vf3 & MP1_SMNIF_TLB_VF3_VFID_MASK) >> MP1_SMNIF_TLB_VF3_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF3_GET_VF(mp1_smnif_tlb_vf3) \
      ((mp1_smnif_tlb_vf3 & MP1_SMNIF_TLB_VF3_VF_MASK) >> MP1_SMNIF_TLB_VF3_VF_SHIFT)
#define MP1_SMNIF_TLB_VF3_GET_VALID(mp1_smnif_tlb_vf3) \
      ((mp1_smnif_tlb_vf3 & MP1_SMNIF_TLB_VF3_VALID_MASK) >> MP1_SMNIF_TLB_VF3_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF3_SET_VFID(mp1_smnif_tlb_vf3_reg, vfid) \
      mp1_smnif_tlb_vf3_reg = (mp1_smnif_tlb_vf3_reg & ~MP1_SMNIF_TLB_VF3_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF3_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF3_SET_VF(mp1_smnif_tlb_vf3_reg, vf) \
      mp1_smnif_tlb_vf3_reg = (mp1_smnif_tlb_vf3_reg & ~MP1_SMNIF_TLB_VF3_VF_MASK) | (vf << MP1_SMNIF_TLB_VF3_VF_SHIFT)
#define MP1_SMNIF_TLB_VF3_SET_VALID(mp1_smnif_tlb_vf3_reg, valid) \
      mp1_smnif_tlb_vf3_reg = (mp1_smnif_tlb_vf3_reg & ~MP1_SMNIF_TLB_VF3_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF3_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf3_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF3_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF3_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF3_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf3_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF3_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF3_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF3_VFID_SIZE;
      } mp1_smnif_tlb_vf3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf3_t f;
} mp1_smnif_tlb_vf3_u;


/*
 * MP1_SMNIF_TLB_VF4 struct
 */

#define MP1_SMNIF_TLB_VF4_REG_SIZE         32
#define MP1_SMNIF_TLB_VF4_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF4_VF_SIZE  1
#define MP1_SMNIF_TLB_VF4_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF4_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF4_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF4_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF4_VFID_MASK     0x0000003f
#define MP1_SMNIF_TLB_VF4_VF_MASK       0x00000040
#define MP1_SMNIF_TLB_VF4_VALID_MASK    0x00000080

#define MP1_SMNIF_TLB_VF4_MASK \
      (MP1_SMNIF_TLB_VF4_VFID_MASK | \
      MP1_SMNIF_TLB_VF4_VF_MASK | \
      MP1_SMNIF_TLB_VF4_VALID_MASK)

#define MP1_SMNIF_TLB_VF4_DEFAULT      0x00000000

#define MP1_SMNIF_TLB_VF4_GET_VFID(mp1_smnif_tlb_vf4) \
      ((mp1_smnif_tlb_vf4 & MP1_SMNIF_TLB_VF4_VFID_MASK) >> MP1_SMNIF_TLB_VF4_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF4_GET_VF(mp1_smnif_tlb_vf4) \
      ((mp1_smnif_tlb_vf4 & MP1_SMNIF_TLB_VF4_VF_MASK) >> MP1_SMNIF_TLB_VF4_VF_SHIFT)
#define MP1_SMNIF_TLB_VF4_GET_VALID(mp1_smnif_tlb_vf4) \
      ((mp1_smnif_tlb_vf4 & MP1_SMNIF_TLB_VF4_VALID_MASK) >> MP1_SMNIF_TLB_VF4_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF4_SET_VFID(mp1_smnif_tlb_vf4_reg, vfid) \
      mp1_smnif_tlb_vf4_reg = (mp1_smnif_tlb_vf4_reg & ~MP1_SMNIF_TLB_VF4_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF4_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF4_SET_VF(mp1_smnif_tlb_vf4_reg, vf) \
      mp1_smnif_tlb_vf4_reg = (mp1_smnif_tlb_vf4_reg & ~MP1_SMNIF_TLB_VF4_VF_MASK) | (vf << MP1_SMNIF_TLB_VF4_VF_SHIFT)
#define MP1_SMNIF_TLB_VF4_SET_VALID(mp1_smnif_tlb_vf4_reg, valid) \
      mp1_smnif_tlb_vf4_reg = (mp1_smnif_tlb_vf4_reg & ~MP1_SMNIF_TLB_VF4_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF4_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf4_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF4_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF4_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF4_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf4_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF4_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF4_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF4_VFID_SIZE;
      } mp1_smnif_tlb_vf4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf4_t f;
} mp1_smnif_tlb_vf4_u;


/*
 * MP1_SMNIF_TLB_VF5 struct
 */

#define MP1_SMNIF_TLB_VF5_REG_SIZE         32
#define MP1_SMNIF_TLB_VF5_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF5_VF_SIZE  1
#define MP1_SMNIF_TLB_VF5_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF5_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF5_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF5_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF5_VFID_MASK     0x0000003f
#define MP1_SMNIF_TLB_VF5_VF_MASK       0x00000040
#define MP1_SMNIF_TLB_VF5_VALID_MASK    0x00000080

#define MP1_SMNIF_TLB_VF5_MASK \
      (MP1_SMNIF_TLB_VF5_VFID_MASK | \
      MP1_SMNIF_TLB_VF5_VF_MASK | \
      MP1_SMNIF_TLB_VF5_VALID_MASK)

#define MP1_SMNIF_TLB_VF5_DEFAULT      0x00000000

#define MP1_SMNIF_TLB_VF5_GET_VFID(mp1_smnif_tlb_vf5) \
      ((mp1_smnif_tlb_vf5 & MP1_SMNIF_TLB_VF5_VFID_MASK) >> MP1_SMNIF_TLB_VF5_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF5_GET_VF(mp1_smnif_tlb_vf5) \
      ((mp1_smnif_tlb_vf5 & MP1_SMNIF_TLB_VF5_VF_MASK) >> MP1_SMNIF_TLB_VF5_VF_SHIFT)
#define MP1_SMNIF_TLB_VF5_GET_VALID(mp1_smnif_tlb_vf5) \
      ((mp1_smnif_tlb_vf5 & MP1_SMNIF_TLB_VF5_VALID_MASK) >> MP1_SMNIF_TLB_VF5_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF5_SET_VFID(mp1_smnif_tlb_vf5_reg, vfid) \
      mp1_smnif_tlb_vf5_reg = (mp1_smnif_tlb_vf5_reg & ~MP1_SMNIF_TLB_VF5_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF5_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF5_SET_VF(mp1_smnif_tlb_vf5_reg, vf) \
      mp1_smnif_tlb_vf5_reg = (mp1_smnif_tlb_vf5_reg & ~MP1_SMNIF_TLB_VF5_VF_MASK) | (vf << MP1_SMNIF_TLB_VF5_VF_SHIFT)
#define MP1_SMNIF_TLB_VF5_SET_VALID(mp1_smnif_tlb_vf5_reg, valid) \
      mp1_smnif_tlb_vf5_reg = (mp1_smnif_tlb_vf5_reg & ~MP1_SMNIF_TLB_VF5_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF5_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf5_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF5_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF5_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF5_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf5_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF5_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF5_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF5_VFID_SIZE;
      } mp1_smnif_tlb_vf5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf5_t f;
} mp1_smnif_tlb_vf5_u;


/*
 * MP1_SMNIF_TLB_VF6 struct
 */

#define MP1_SMNIF_TLB_VF6_REG_SIZE         32
#define MP1_SMNIF_TLB_VF6_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF6_VF_SIZE  1
#define MP1_SMNIF_TLB_VF6_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF6_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF6_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF6_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF6_VFID_MASK     0x0000003f
#define MP1_SMNIF_TLB_VF6_VF_MASK       0x00000040
#define MP1_SMNIF_TLB_VF6_VALID_MASK    0x00000080

#define MP1_SMNIF_TLB_VF6_MASK \
      (MP1_SMNIF_TLB_VF6_VFID_MASK | \
      MP1_SMNIF_TLB_VF6_VF_MASK | \
      MP1_SMNIF_TLB_VF6_VALID_MASK)

#define MP1_SMNIF_TLB_VF6_DEFAULT      0x00000000

#define MP1_SMNIF_TLB_VF6_GET_VFID(mp1_smnif_tlb_vf6) \
      ((mp1_smnif_tlb_vf6 & MP1_SMNIF_TLB_VF6_VFID_MASK) >> MP1_SMNIF_TLB_VF6_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF6_GET_VF(mp1_smnif_tlb_vf6) \
      ((mp1_smnif_tlb_vf6 & MP1_SMNIF_TLB_VF6_VF_MASK) >> MP1_SMNIF_TLB_VF6_VF_SHIFT)
#define MP1_SMNIF_TLB_VF6_GET_VALID(mp1_smnif_tlb_vf6) \
      ((mp1_smnif_tlb_vf6 & MP1_SMNIF_TLB_VF6_VALID_MASK) >> MP1_SMNIF_TLB_VF6_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF6_SET_VFID(mp1_smnif_tlb_vf6_reg, vfid) \
      mp1_smnif_tlb_vf6_reg = (mp1_smnif_tlb_vf6_reg & ~MP1_SMNIF_TLB_VF6_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF6_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF6_SET_VF(mp1_smnif_tlb_vf6_reg, vf) \
      mp1_smnif_tlb_vf6_reg = (mp1_smnif_tlb_vf6_reg & ~MP1_SMNIF_TLB_VF6_VF_MASK) | (vf << MP1_SMNIF_TLB_VF6_VF_SHIFT)
#define MP1_SMNIF_TLB_VF6_SET_VALID(mp1_smnif_tlb_vf6_reg, valid) \
      mp1_smnif_tlb_vf6_reg = (mp1_smnif_tlb_vf6_reg & ~MP1_SMNIF_TLB_VF6_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF6_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf6_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF6_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF6_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF6_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf6_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF6_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF6_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF6_VFID_SIZE;
      } mp1_smnif_tlb_vf6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf6_t f;
} mp1_smnif_tlb_vf6_u;


/*
 * MP1_SMNIF_TLB_VF7 struct
 */

#define MP1_SMNIF_TLB_VF7_REG_SIZE         32
#define MP1_SMNIF_TLB_VF7_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF7_VF_SIZE  1
#define MP1_SMNIF_TLB_VF7_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF7_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF7_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF7_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF7_VFID_MASK     0x0000003f
#define MP1_SMNIF_TLB_VF7_VF_MASK       0x00000040
#define MP1_SMNIF_TLB_VF7_VALID_MASK    0x00000080

#define MP1_SMNIF_TLB_VF7_MASK \
      (MP1_SMNIF_TLB_VF7_VFID_MASK | \
      MP1_SMNIF_TLB_VF7_VF_MASK | \
      MP1_SMNIF_TLB_VF7_VALID_MASK)

#define MP1_SMNIF_TLB_VF7_DEFAULT      0x00000000

#define MP1_SMNIF_TLB_VF7_GET_VFID(mp1_smnif_tlb_vf7) \
      ((mp1_smnif_tlb_vf7 & MP1_SMNIF_TLB_VF7_VFID_MASK) >> MP1_SMNIF_TLB_VF7_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF7_GET_VF(mp1_smnif_tlb_vf7) \
      ((mp1_smnif_tlb_vf7 & MP1_SMNIF_TLB_VF7_VF_MASK) >> MP1_SMNIF_TLB_VF7_VF_SHIFT)
#define MP1_SMNIF_TLB_VF7_GET_VALID(mp1_smnif_tlb_vf7) \
      ((mp1_smnif_tlb_vf7 & MP1_SMNIF_TLB_VF7_VALID_MASK) >> MP1_SMNIF_TLB_VF7_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF7_SET_VFID(mp1_smnif_tlb_vf7_reg, vfid) \
      mp1_smnif_tlb_vf7_reg = (mp1_smnif_tlb_vf7_reg & ~MP1_SMNIF_TLB_VF7_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF7_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF7_SET_VF(mp1_smnif_tlb_vf7_reg, vf) \
      mp1_smnif_tlb_vf7_reg = (mp1_smnif_tlb_vf7_reg & ~MP1_SMNIF_TLB_VF7_VF_MASK) | (vf << MP1_SMNIF_TLB_VF7_VF_SHIFT)
#define MP1_SMNIF_TLB_VF7_SET_VALID(mp1_smnif_tlb_vf7_reg, valid) \
      mp1_smnif_tlb_vf7_reg = (mp1_smnif_tlb_vf7_reg & ~MP1_SMNIF_TLB_VF7_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF7_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf7_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF7_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF7_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF7_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf7_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF7_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF7_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF7_VFID_SIZE;
      } mp1_smnif_tlb_vf7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf7_t f;
} mp1_smnif_tlb_vf7_u;


/*
 * MP1_SMNIF_TLB_VF8 struct
 */

#define MP1_SMNIF_TLB_VF8_REG_SIZE         32
#define MP1_SMNIF_TLB_VF8_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF8_VF_SIZE  1
#define MP1_SMNIF_TLB_VF8_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF8_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF8_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF8_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF8_VFID_MASK     0x0000003f
#define MP1_SMNIF_TLB_VF8_VF_MASK       0x00000040
#define MP1_SMNIF_TLB_VF8_VALID_MASK    0x00000080

#define MP1_SMNIF_TLB_VF8_MASK \
      (MP1_SMNIF_TLB_VF8_VFID_MASK | \
      MP1_SMNIF_TLB_VF8_VF_MASK | \
      MP1_SMNIF_TLB_VF8_VALID_MASK)

#define MP1_SMNIF_TLB_VF8_DEFAULT      0x00000000

#define MP1_SMNIF_TLB_VF8_GET_VFID(mp1_smnif_tlb_vf8) \
      ((mp1_smnif_tlb_vf8 & MP1_SMNIF_TLB_VF8_VFID_MASK) >> MP1_SMNIF_TLB_VF8_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF8_GET_VF(mp1_smnif_tlb_vf8) \
      ((mp1_smnif_tlb_vf8 & MP1_SMNIF_TLB_VF8_VF_MASK) >> MP1_SMNIF_TLB_VF8_VF_SHIFT)
#define MP1_SMNIF_TLB_VF8_GET_VALID(mp1_smnif_tlb_vf8) \
      ((mp1_smnif_tlb_vf8 & MP1_SMNIF_TLB_VF8_VALID_MASK) >> MP1_SMNIF_TLB_VF8_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF8_SET_VFID(mp1_smnif_tlb_vf8_reg, vfid) \
      mp1_smnif_tlb_vf8_reg = (mp1_smnif_tlb_vf8_reg & ~MP1_SMNIF_TLB_VF8_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF8_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF8_SET_VF(mp1_smnif_tlb_vf8_reg, vf) \
      mp1_smnif_tlb_vf8_reg = (mp1_smnif_tlb_vf8_reg & ~MP1_SMNIF_TLB_VF8_VF_MASK) | (vf << MP1_SMNIF_TLB_VF8_VF_SHIFT)
#define MP1_SMNIF_TLB_VF8_SET_VALID(mp1_smnif_tlb_vf8_reg, valid) \
      mp1_smnif_tlb_vf8_reg = (mp1_smnif_tlb_vf8_reg & ~MP1_SMNIF_TLB_VF8_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF8_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf8_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF8_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF8_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF8_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf8_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF8_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF8_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF8_VFID_SIZE;
      } mp1_smnif_tlb_vf8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf8_t f;
} mp1_smnif_tlb_vf8_u;


/*
 * MP1_SMNIF_TLB_VF9 struct
 */

#define MP1_SMNIF_TLB_VF9_REG_SIZE         32
#define MP1_SMNIF_TLB_VF9_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF9_VF_SIZE  1
#define MP1_SMNIF_TLB_VF9_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF9_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF9_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF9_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF9_VFID_MASK     0x0000003f
#define MP1_SMNIF_TLB_VF9_VF_MASK       0x00000040
#define MP1_SMNIF_TLB_VF9_VALID_MASK    0x00000080

#define MP1_SMNIF_TLB_VF9_MASK \
      (MP1_SMNIF_TLB_VF9_VFID_MASK | \
      MP1_SMNIF_TLB_VF9_VF_MASK | \
      MP1_SMNIF_TLB_VF9_VALID_MASK)

#define MP1_SMNIF_TLB_VF9_DEFAULT      0x00000000

#define MP1_SMNIF_TLB_VF9_GET_VFID(mp1_smnif_tlb_vf9) \
      ((mp1_smnif_tlb_vf9 & MP1_SMNIF_TLB_VF9_VFID_MASK) >> MP1_SMNIF_TLB_VF9_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF9_GET_VF(mp1_smnif_tlb_vf9) \
      ((mp1_smnif_tlb_vf9 & MP1_SMNIF_TLB_VF9_VF_MASK) >> MP1_SMNIF_TLB_VF9_VF_SHIFT)
#define MP1_SMNIF_TLB_VF9_GET_VALID(mp1_smnif_tlb_vf9) \
      ((mp1_smnif_tlb_vf9 & MP1_SMNIF_TLB_VF9_VALID_MASK) >> MP1_SMNIF_TLB_VF9_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF9_SET_VFID(mp1_smnif_tlb_vf9_reg, vfid) \
      mp1_smnif_tlb_vf9_reg = (mp1_smnif_tlb_vf9_reg & ~MP1_SMNIF_TLB_VF9_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF9_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF9_SET_VF(mp1_smnif_tlb_vf9_reg, vf) \
      mp1_smnif_tlb_vf9_reg = (mp1_smnif_tlb_vf9_reg & ~MP1_SMNIF_TLB_VF9_VF_MASK) | (vf << MP1_SMNIF_TLB_VF9_VF_SHIFT)
#define MP1_SMNIF_TLB_VF9_SET_VALID(mp1_smnif_tlb_vf9_reg, valid) \
      mp1_smnif_tlb_vf9_reg = (mp1_smnif_tlb_vf9_reg & ~MP1_SMNIF_TLB_VF9_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF9_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf9_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF9_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF9_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF9_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf9_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF9_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF9_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF9_VFID_SIZE;
      } mp1_smnif_tlb_vf9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf9_t f;
} mp1_smnif_tlb_vf9_u;


/*
 * MP1_SMNIF_TLB_VF10 struct
 */

#define MP1_SMNIF_TLB_VF10_REG_SIZE         32
#define MP1_SMNIF_TLB_VF10_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF10_VF_SIZE  1
#define MP1_SMNIF_TLB_VF10_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF10_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF10_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF10_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF10_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF10_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF10_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF10_MASK \
      (MP1_SMNIF_TLB_VF10_VFID_MASK | \
      MP1_SMNIF_TLB_VF10_VF_MASK | \
      MP1_SMNIF_TLB_VF10_VALID_MASK)

#define MP1_SMNIF_TLB_VF10_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF10_GET_VFID(mp1_smnif_tlb_vf10) \
      ((mp1_smnif_tlb_vf10 & MP1_SMNIF_TLB_VF10_VFID_MASK) >> MP1_SMNIF_TLB_VF10_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF10_GET_VF(mp1_smnif_tlb_vf10) \
      ((mp1_smnif_tlb_vf10 & MP1_SMNIF_TLB_VF10_VF_MASK) >> MP1_SMNIF_TLB_VF10_VF_SHIFT)
#define MP1_SMNIF_TLB_VF10_GET_VALID(mp1_smnif_tlb_vf10) \
      ((mp1_smnif_tlb_vf10 & MP1_SMNIF_TLB_VF10_VALID_MASK) >> MP1_SMNIF_TLB_VF10_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF10_SET_VFID(mp1_smnif_tlb_vf10_reg, vfid) \
      mp1_smnif_tlb_vf10_reg = (mp1_smnif_tlb_vf10_reg & ~MP1_SMNIF_TLB_VF10_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF10_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF10_SET_VF(mp1_smnif_tlb_vf10_reg, vf) \
      mp1_smnif_tlb_vf10_reg = (mp1_smnif_tlb_vf10_reg & ~MP1_SMNIF_TLB_VF10_VF_MASK) | (vf << MP1_SMNIF_TLB_VF10_VF_SHIFT)
#define MP1_SMNIF_TLB_VF10_SET_VALID(mp1_smnif_tlb_vf10_reg, valid) \
      mp1_smnif_tlb_vf10_reg = (mp1_smnif_tlb_vf10_reg & ~MP1_SMNIF_TLB_VF10_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF10_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf10_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF10_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF10_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF10_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf10_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF10_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF10_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF10_VFID_SIZE;
      } mp1_smnif_tlb_vf10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf10_t f;
} mp1_smnif_tlb_vf10_u;


/*
 * MP1_SMNIF_TLB_VF11 struct
 */

#define MP1_SMNIF_TLB_VF11_REG_SIZE         32
#define MP1_SMNIF_TLB_VF11_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF11_VF_SIZE  1
#define MP1_SMNIF_TLB_VF11_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF11_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF11_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF11_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF11_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF11_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF11_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF11_MASK \
      (MP1_SMNIF_TLB_VF11_VFID_MASK | \
      MP1_SMNIF_TLB_VF11_VF_MASK | \
      MP1_SMNIF_TLB_VF11_VALID_MASK)

#define MP1_SMNIF_TLB_VF11_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF11_GET_VFID(mp1_smnif_tlb_vf11) \
      ((mp1_smnif_tlb_vf11 & MP1_SMNIF_TLB_VF11_VFID_MASK) >> MP1_SMNIF_TLB_VF11_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF11_GET_VF(mp1_smnif_tlb_vf11) \
      ((mp1_smnif_tlb_vf11 & MP1_SMNIF_TLB_VF11_VF_MASK) >> MP1_SMNIF_TLB_VF11_VF_SHIFT)
#define MP1_SMNIF_TLB_VF11_GET_VALID(mp1_smnif_tlb_vf11) \
      ((mp1_smnif_tlb_vf11 & MP1_SMNIF_TLB_VF11_VALID_MASK) >> MP1_SMNIF_TLB_VF11_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF11_SET_VFID(mp1_smnif_tlb_vf11_reg, vfid) \
      mp1_smnif_tlb_vf11_reg = (mp1_smnif_tlb_vf11_reg & ~MP1_SMNIF_TLB_VF11_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF11_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF11_SET_VF(mp1_smnif_tlb_vf11_reg, vf) \
      mp1_smnif_tlb_vf11_reg = (mp1_smnif_tlb_vf11_reg & ~MP1_SMNIF_TLB_VF11_VF_MASK) | (vf << MP1_SMNIF_TLB_VF11_VF_SHIFT)
#define MP1_SMNIF_TLB_VF11_SET_VALID(mp1_smnif_tlb_vf11_reg, valid) \
      mp1_smnif_tlb_vf11_reg = (mp1_smnif_tlb_vf11_reg & ~MP1_SMNIF_TLB_VF11_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF11_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf11_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF11_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF11_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF11_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf11_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF11_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF11_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF11_VFID_SIZE;
      } mp1_smnif_tlb_vf11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf11_t f;
} mp1_smnif_tlb_vf11_u;


/*
 * MP1_SMNIF_TLB_VF12 struct
 */

#define MP1_SMNIF_TLB_VF12_REG_SIZE         32
#define MP1_SMNIF_TLB_VF12_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF12_VF_SIZE  1
#define MP1_SMNIF_TLB_VF12_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF12_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF12_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF12_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF12_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF12_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF12_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF12_MASK \
      (MP1_SMNIF_TLB_VF12_VFID_MASK | \
      MP1_SMNIF_TLB_VF12_VF_MASK | \
      MP1_SMNIF_TLB_VF12_VALID_MASK)

#define MP1_SMNIF_TLB_VF12_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF12_GET_VFID(mp1_smnif_tlb_vf12) \
      ((mp1_smnif_tlb_vf12 & MP1_SMNIF_TLB_VF12_VFID_MASK) >> MP1_SMNIF_TLB_VF12_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF12_GET_VF(mp1_smnif_tlb_vf12) \
      ((mp1_smnif_tlb_vf12 & MP1_SMNIF_TLB_VF12_VF_MASK) >> MP1_SMNIF_TLB_VF12_VF_SHIFT)
#define MP1_SMNIF_TLB_VF12_GET_VALID(mp1_smnif_tlb_vf12) \
      ((mp1_smnif_tlb_vf12 & MP1_SMNIF_TLB_VF12_VALID_MASK) >> MP1_SMNIF_TLB_VF12_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF12_SET_VFID(mp1_smnif_tlb_vf12_reg, vfid) \
      mp1_smnif_tlb_vf12_reg = (mp1_smnif_tlb_vf12_reg & ~MP1_SMNIF_TLB_VF12_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF12_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF12_SET_VF(mp1_smnif_tlb_vf12_reg, vf) \
      mp1_smnif_tlb_vf12_reg = (mp1_smnif_tlb_vf12_reg & ~MP1_SMNIF_TLB_VF12_VF_MASK) | (vf << MP1_SMNIF_TLB_VF12_VF_SHIFT)
#define MP1_SMNIF_TLB_VF12_SET_VALID(mp1_smnif_tlb_vf12_reg, valid) \
      mp1_smnif_tlb_vf12_reg = (mp1_smnif_tlb_vf12_reg & ~MP1_SMNIF_TLB_VF12_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF12_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf12_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF12_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF12_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF12_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf12_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF12_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF12_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF12_VFID_SIZE;
      } mp1_smnif_tlb_vf12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf12_t f;
} mp1_smnif_tlb_vf12_u;


/*
 * MP1_SMNIF_TLB_VF13 struct
 */

#define MP1_SMNIF_TLB_VF13_REG_SIZE         32
#define MP1_SMNIF_TLB_VF13_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF13_VF_SIZE  1
#define MP1_SMNIF_TLB_VF13_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF13_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF13_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF13_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF13_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF13_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF13_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF13_MASK \
      (MP1_SMNIF_TLB_VF13_VFID_MASK | \
      MP1_SMNIF_TLB_VF13_VF_MASK | \
      MP1_SMNIF_TLB_VF13_VALID_MASK)

#define MP1_SMNIF_TLB_VF13_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF13_GET_VFID(mp1_smnif_tlb_vf13) \
      ((mp1_smnif_tlb_vf13 & MP1_SMNIF_TLB_VF13_VFID_MASK) >> MP1_SMNIF_TLB_VF13_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF13_GET_VF(mp1_smnif_tlb_vf13) \
      ((mp1_smnif_tlb_vf13 & MP1_SMNIF_TLB_VF13_VF_MASK) >> MP1_SMNIF_TLB_VF13_VF_SHIFT)
#define MP1_SMNIF_TLB_VF13_GET_VALID(mp1_smnif_tlb_vf13) \
      ((mp1_smnif_tlb_vf13 & MP1_SMNIF_TLB_VF13_VALID_MASK) >> MP1_SMNIF_TLB_VF13_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF13_SET_VFID(mp1_smnif_tlb_vf13_reg, vfid) \
      mp1_smnif_tlb_vf13_reg = (mp1_smnif_tlb_vf13_reg & ~MP1_SMNIF_TLB_VF13_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF13_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF13_SET_VF(mp1_smnif_tlb_vf13_reg, vf) \
      mp1_smnif_tlb_vf13_reg = (mp1_smnif_tlb_vf13_reg & ~MP1_SMNIF_TLB_VF13_VF_MASK) | (vf << MP1_SMNIF_TLB_VF13_VF_SHIFT)
#define MP1_SMNIF_TLB_VF13_SET_VALID(mp1_smnif_tlb_vf13_reg, valid) \
      mp1_smnif_tlb_vf13_reg = (mp1_smnif_tlb_vf13_reg & ~MP1_SMNIF_TLB_VF13_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF13_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf13_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF13_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF13_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF13_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf13_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF13_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF13_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF13_VFID_SIZE;
      } mp1_smnif_tlb_vf13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf13_t f;
} mp1_smnif_tlb_vf13_u;


/*
 * MP1_SMNIF_TLB_VF14 struct
 */

#define MP1_SMNIF_TLB_VF14_REG_SIZE         32
#define MP1_SMNIF_TLB_VF14_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF14_VF_SIZE  1
#define MP1_SMNIF_TLB_VF14_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF14_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF14_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF14_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF14_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF14_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF14_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF14_MASK \
      (MP1_SMNIF_TLB_VF14_VFID_MASK | \
      MP1_SMNIF_TLB_VF14_VF_MASK | \
      MP1_SMNIF_TLB_VF14_VALID_MASK)

#define MP1_SMNIF_TLB_VF14_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF14_GET_VFID(mp1_smnif_tlb_vf14) \
      ((mp1_smnif_tlb_vf14 & MP1_SMNIF_TLB_VF14_VFID_MASK) >> MP1_SMNIF_TLB_VF14_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF14_GET_VF(mp1_smnif_tlb_vf14) \
      ((mp1_smnif_tlb_vf14 & MP1_SMNIF_TLB_VF14_VF_MASK) >> MP1_SMNIF_TLB_VF14_VF_SHIFT)
#define MP1_SMNIF_TLB_VF14_GET_VALID(mp1_smnif_tlb_vf14) \
      ((mp1_smnif_tlb_vf14 & MP1_SMNIF_TLB_VF14_VALID_MASK) >> MP1_SMNIF_TLB_VF14_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF14_SET_VFID(mp1_smnif_tlb_vf14_reg, vfid) \
      mp1_smnif_tlb_vf14_reg = (mp1_smnif_tlb_vf14_reg & ~MP1_SMNIF_TLB_VF14_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF14_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF14_SET_VF(mp1_smnif_tlb_vf14_reg, vf) \
      mp1_smnif_tlb_vf14_reg = (mp1_smnif_tlb_vf14_reg & ~MP1_SMNIF_TLB_VF14_VF_MASK) | (vf << MP1_SMNIF_TLB_VF14_VF_SHIFT)
#define MP1_SMNIF_TLB_VF14_SET_VALID(mp1_smnif_tlb_vf14_reg, valid) \
      mp1_smnif_tlb_vf14_reg = (mp1_smnif_tlb_vf14_reg & ~MP1_SMNIF_TLB_VF14_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF14_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf14_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF14_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF14_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF14_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf14_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF14_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF14_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF14_VFID_SIZE;
      } mp1_smnif_tlb_vf14_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf14_t f;
} mp1_smnif_tlb_vf14_u;


/*
 * MP1_SMNIF_TLB_VF15 struct
 */

#define MP1_SMNIF_TLB_VF15_REG_SIZE         32
#define MP1_SMNIF_TLB_VF15_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF15_VF_SIZE  1
#define MP1_SMNIF_TLB_VF15_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF15_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF15_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF15_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF15_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF15_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF15_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF15_MASK \
      (MP1_SMNIF_TLB_VF15_VFID_MASK | \
      MP1_SMNIF_TLB_VF15_VF_MASK | \
      MP1_SMNIF_TLB_VF15_VALID_MASK)

#define MP1_SMNIF_TLB_VF15_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF15_GET_VFID(mp1_smnif_tlb_vf15) \
      ((mp1_smnif_tlb_vf15 & MP1_SMNIF_TLB_VF15_VFID_MASK) >> MP1_SMNIF_TLB_VF15_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF15_GET_VF(mp1_smnif_tlb_vf15) \
      ((mp1_smnif_tlb_vf15 & MP1_SMNIF_TLB_VF15_VF_MASK) >> MP1_SMNIF_TLB_VF15_VF_SHIFT)
#define MP1_SMNIF_TLB_VF15_GET_VALID(mp1_smnif_tlb_vf15) \
      ((mp1_smnif_tlb_vf15 & MP1_SMNIF_TLB_VF15_VALID_MASK) >> MP1_SMNIF_TLB_VF15_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF15_SET_VFID(mp1_smnif_tlb_vf15_reg, vfid) \
      mp1_smnif_tlb_vf15_reg = (mp1_smnif_tlb_vf15_reg & ~MP1_SMNIF_TLB_VF15_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF15_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF15_SET_VF(mp1_smnif_tlb_vf15_reg, vf) \
      mp1_smnif_tlb_vf15_reg = (mp1_smnif_tlb_vf15_reg & ~MP1_SMNIF_TLB_VF15_VF_MASK) | (vf << MP1_SMNIF_TLB_VF15_VF_SHIFT)
#define MP1_SMNIF_TLB_VF15_SET_VALID(mp1_smnif_tlb_vf15_reg, valid) \
      mp1_smnif_tlb_vf15_reg = (mp1_smnif_tlb_vf15_reg & ~MP1_SMNIF_TLB_VF15_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF15_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf15_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF15_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF15_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF15_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf15_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF15_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF15_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF15_VFID_SIZE;
      } mp1_smnif_tlb_vf15_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf15_t f;
} mp1_smnif_tlb_vf15_u;


/*
 * MP1_SMNIF_TLB_VF16 struct
 */

#define MP1_SMNIF_TLB_VF16_REG_SIZE         32
#define MP1_SMNIF_TLB_VF16_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF16_VF_SIZE  1
#define MP1_SMNIF_TLB_VF16_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF16_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF16_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF16_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF16_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF16_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF16_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF16_MASK \
      (MP1_SMNIF_TLB_VF16_VFID_MASK | \
      MP1_SMNIF_TLB_VF16_VF_MASK | \
      MP1_SMNIF_TLB_VF16_VALID_MASK)

#define MP1_SMNIF_TLB_VF16_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF16_GET_VFID(mp1_smnif_tlb_vf16) \
      ((mp1_smnif_tlb_vf16 & MP1_SMNIF_TLB_VF16_VFID_MASK) >> MP1_SMNIF_TLB_VF16_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF16_GET_VF(mp1_smnif_tlb_vf16) \
      ((mp1_smnif_tlb_vf16 & MP1_SMNIF_TLB_VF16_VF_MASK) >> MP1_SMNIF_TLB_VF16_VF_SHIFT)
#define MP1_SMNIF_TLB_VF16_GET_VALID(mp1_smnif_tlb_vf16) \
      ((mp1_smnif_tlb_vf16 & MP1_SMNIF_TLB_VF16_VALID_MASK) >> MP1_SMNIF_TLB_VF16_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF16_SET_VFID(mp1_smnif_tlb_vf16_reg, vfid) \
      mp1_smnif_tlb_vf16_reg = (mp1_smnif_tlb_vf16_reg & ~MP1_SMNIF_TLB_VF16_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF16_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF16_SET_VF(mp1_smnif_tlb_vf16_reg, vf) \
      mp1_smnif_tlb_vf16_reg = (mp1_smnif_tlb_vf16_reg & ~MP1_SMNIF_TLB_VF16_VF_MASK) | (vf << MP1_SMNIF_TLB_VF16_VF_SHIFT)
#define MP1_SMNIF_TLB_VF16_SET_VALID(mp1_smnif_tlb_vf16_reg, valid) \
      mp1_smnif_tlb_vf16_reg = (mp1_smnif_tlb_vf16_reg & ~MP1_SMNIF_TLB_VF16_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF16_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf16_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF16_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF16_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF16_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf16_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf16_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF16_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF16_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF16_VFID_SIZE;
      } mp1_smnif_tlb_vf16_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf16_t f;
} mp1_smnif_tlb_vf16_u;


/*
 * MP1_SMNIF_TLB_VF17 struct
 */

#define MP1_SMNIF_TLB_VF17_REG_SIZE         32
#define MP1_SMNIF_TLB_VF17_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF17_VF_SIZE  1
#define MP1_SMNIF_TLB_VF17_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF17_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF17_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF17_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF17_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF17_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF17_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF17_MASK \
      (MP1_SMNIF_TLB_VF17_VFID_MASK | \
      MP1_SMNIF_TLB_VF17_VF_MASK | \
      MP1_SMNIF_TLB_VF17_VALID_MASK)

#define MP1_SMNIF_TLB_VF17_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF17_GET_VFID(mp1_smnif_tlb_vf17) \
      ((mp1_smnif_tlb_vf17 & MP1_SMNIF_TLB_VF17_VFID_MASK) >> MP1_SMNIF_TLB_VF17_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF17_GET_VF(mp1_smnif_tlb_vf17) \
      ((mp1_smnif_tlb_vf17 & MP1_SMNIF_TLB_VF17_VF_MASK) >> MP1_SMNIF_TLB_VF17_VF_SHIFT)
#define MP1_SMNIF_TLB_VF17_GET_VALID(mp1_smnif_tlb_vf17) \
      ((mp1_smnif_tlb_vf17 & MP1_SMNIF_TLB_VF17_VALID_MASK) >> MP1_SMNIF_TLB_VF17_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF17_SET_VFID(mp1_smnif_tlb_vf17_reg, vfid) \
      mp1_smnif_tlb_vf17_reg = (mp1_smnif_tlb_vf17_reg & ~MP1_SMNIF_TLB_VF17_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF17_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF17_SET_VF(mp1_smnif_tlb_vf17_reg, vf) \
      mp1_smnif_tlb_vf17_reg = (mp1_smnif_tlb_vf17_reg & ~MP1_SMNIF_TLB_VF17_VF_MASK) | (vf << MP1_SMNIF_TLB_VF17_VF_SHIFT)
#define MP1_SMNIF_TLB_VF17_SET_VALID(mp1_smnif_tlb_vf17_reg, valid) \
      mp1_smnif_tlb_vf17_reg = (mp1_smnif_tlb_vf17_reg & ~MP1_SMNIF_TLB_VF17_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF17_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf17_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF17_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF17_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF17_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf17_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf17_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF17_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF17_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF17_VFID_SIZE;
      } mp1_smnif_tlb_vf17_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf17_t f;
} mp1_smnif_tlb_vf17_u;


/*
 * MP1_SMNIF_TLB_VF18 struct
 */

#define MP1_SMNIF_TLB_VF18_REG_SIZE         32
#define MP1_SMNIF_TLB_VF18_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF18_VF_SIZE  1
#define MP1_SMNIF_TLB_VF18_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF18_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF18_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF18_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF18_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF18_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF18_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF18_MASK \
      (MP1_SMNIF_TLB_VF18_VFID_MASK | \
      MP1_SMNIF_TLB_VF18_VF_MASK | \
      MP1_SMNIF_TLB_VF18_VALID_MASK)

#define MP1_SMNIF_TLB_VF18_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF18_GET_VFID(mp1_smnif_tlb_vf18) \
      ((mp1_smnif_tlb_vf18 & MP1_SMNIF_TLB_VF18_VFID_MASK) >> MP1_SMNIF_TLB_VF18_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF18_GET_VF(mp1_smnif_tlb_vf18) \
      ((mp1_smnif_tlb_vf18 & MP1_SMNIF_TLB_VF18_VF_MASK) >> MP1_SMNIF_TLB_VF18_VF_SHIFT)
#define MP1_SMNIF_TLB_VF18_GET_VALID(mp1_smnif_tlb_vf18) \
      ((mp1_smnif_tlb_vf18 & MP1_SMNIF_TLB_VF18_VALID_MASK) >> MP1_SMNIF_TLB_VF18_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF18_SET_VFID(mp1_smnif_tlb_vf18_reg, vfid) \
      mp1_smnif_tlb_vf18_reg = (mp1_smnif_tlb_vf18_reg & ~MP1_SMNIF_TLB_VF18_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF18_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF18_SET_VF(mp1_smnif_tlb_vf18_reg, vf) \
      mp1_smnif_tlb_vf18_reg = (mp1_smnif_tlb_vf18_reg & ~MP1_SMNIF_TLB_VF18_VF_MASK) | (vf << MP1_SMNIF_TLB_VF18_VF_SHIFT)
#define MP1_SMNIF_TLB_VF18_SET_VALID(mp1_smnif_tlb_vf18_reg, valid) \
      mp1_smnif_tlb_vf18_reg = (mp1_smnif_tlb_vf18_reg & ~MP1_SMNIF_TLB_VF18_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF18_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf18_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF18_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF18_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF18_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf18_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf18_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF18_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF18_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF18_VFID_SIZE;
      } mp1_smnif_tlb_vf18_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf18_t f;
} mp1_smnif_tlb_vf18_u;


/*
 * MP1_SMNIF_TLB_VF19 struct
 */

#define MP1_SMNIF_TLB_VF19_REG_SIZE         32
#define MP1_SMNIF_TLB_VF19_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF19_VF_SIZE  1
#define MP1_SMNIF_TLB_VF19_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF19_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF19_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF19_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF19_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF19_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF19_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF19_MASK \
      (MP1_SMNIF_TLB_VF19_VFID_MASK | \
      MP1_SMNIF_TLB_VF19_VF_MASK | \
      MP1_SMNIF_TLB_VF19_VALID_MASK)

#define MP1_SMNIF_TLB_VF19_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF19_GET_VFID(mp1_smnif_tlb_vf19) \
      ((mp1_smnif_tlb_vf19 & MP1_SMNIF_TLB_VF19_VFID_MASK) >> MP1_SMNIF_TLB_VF19_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF19_GET_VF(mp1_smnif_tlb_vf19) \
      ((mp1_smnif_tlb_vf19 & MP1_SMNIF_TLB_VF19_VF_MASK) >> MP1_SMNIF_TLB_VF19_VF_SHIFT)
#define MP1_SMNIF_TLB_VF19_GET_VALID(mp1_smnif_tlb_vf19) \
      ((mp1_smnif_tlb_vf19 & MP1_SMNIF_TLB_VF19_VALID_MASK) >> MP1_SMNIF_TLB_VF19_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF19_SET_VFID(mp1_smnif_tlb_vf19_reg, vfid) \
      mp1_smnif_tlb_vf19_reg = (mp1_smnif_tlb_vf19_reg & ~MP1_SMNIF_TLB_VF19_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF19_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF19_SET_VF(mp1_smnif_tlb_vf19_reg, vf) \
      mp1_smnif_tlb_vf19_reg = (mp1_smnif_tlb_vf19_reg & ~MP1_SMNIF_TLB_VF19_VF_MASK) | (vf << MP1_SMNIF_TLB_VF19_VF_SHIFT)
#define MP1_SMNIF_TLB_VF19_SET_VALID(mp1_smnif_tlb_vf19_reg, valid) \
      mp1_smnif_tlb_vf19_reg = (mp1_smnif_tlb_vf19_reg & ~MP1_SMNIF_TLB_VF19_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF19_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf19_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF19_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF19_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF19_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf19_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf19_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF19_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF19_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF19_VFID_SIZE;
      } mp1_smnif_tlb_vf19_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf19_t f;
} mp1_smnif_tlb_vf19_u;


/*
 * MP1_SMNIF_TLB_VF20 struct
 */

#define MP1_SMNIF_TLB_VF20_REG_SIZE         32
#define MP1_SMNIF_TLB_VF20_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF20_VF_SIZE  1
#define MP1_SMNIF_TLB_VF20_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF20_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF20_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF20_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF20_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF20_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF20_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF20_MASK \
      (MP1_SMNIF_TLB_VF20_VFID_MASK | \
      MP1_SMNIF_TLB_VF20_VF_MASK | \
      MP1_SMNIF_TLB_VF20_VALID_MASK)

#define MP1_SMNIF_TLB_VF20_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF20_GET_VFID(mp1_smnif_tlb_vf20) \
      ((mp1_smnif_tlb_vf20 & MP1_SMNIF_TLB_VF20_VFID_MASK) >> MP1_SMNIF_TLB_VF20_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF20_GET_VF(mp1_smnif_tlb_vf20) \
      ((mp1_smnif_tlb_vf20 & MP1_SMNIF_TLB_VF20_VF_MASK) >> MP1_SMNIF_TLB_VF20_VF_SHIFT)
#define MP1_SMNIF_TLB_VF20_GET_VALID(mp1_smnif_tlb_vf20) \
      ((mp1_smnif_tlb_vf20 & MP1_SMNIF_TLB_VF20_VALID_MASK) >> MP1_SMNIF_TLB_VF20_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF20_SET_VFID(mp1_smnif_tlb_vf20_reg, vfid) \
      mp1_smnif_tlb_vf20_reg = (mp1_smnif_tlb_vf20_reg & ~MP1_SMNIF_TLB_VF20_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF20_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF20_SET_VF(mp1_smnif_tlb_vf20_reg, vf) \
      mp1_smnif_tlb_vf20_reg = (mp1_smnif_tlb_vf20_reg & ~MP1_SMNIF_TLB_VF20_VF_MASK) | (vf << MP1_SMNIF_TLB_VF20_VF_SHIFT)
#define MP1_SMNIF_TLB_VF20_SET_VALID(mp1_smnif_tlb_vf20_reg, valid) \
      mp1_smnif_tlb_vf20_reg = (mp1_smnif_tlb_vf20_reg & ~MP1_SMNIF_TLB_VF20_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF20_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf20_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF20_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF20_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF20_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf20_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf20_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF20_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF20_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF20_VFID_SIZE;
      } mp1_smnif_tlb_vf20_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf20_t f;
} mp1_smnif_tlb_vf20_u;


/*
 * MP1_SMNIF_TLB_VF21 struct
 */

#define MP1_SMNIF_TLB_VF21_REG_SIZE         32
#define MP1_SMNIF_TLB_VF21_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF21_VF_SIZE  1
#define MP1_SMNIF_TLB_VF21_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF21_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF21_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF21_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF21_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF21_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF21_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF21_MASK \
      (MP1_SMNIF_TLB_VF21_VFID_MASK | \
      MP1_SMNIF_TLB_VF21_VF_MASK | \
      MP1_SMNIF_TLB_VF21_VALID_MASK)

#define MP1_SMNIF_TLB_VF21_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF21_GET_VFID(mp1_smnif_tlb_vf21) \
      ((mp1_smnif_tlb_vf21 & MP1_SMNIF_TLB_VF21_VFID_MASK) >> MP1_SMNIF_TLB_VF21_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF21_GET_VF(mp1_smnif_tlb_vf21) \
      ((mp1_smnif_tlb_vf21 & MP1_SMNIF_TLB_VF21_VF_MASK) >> MP1_SMNIF_TLB_VF21_VF_SHIFT)
#define MP1_SMNIF_TLB_VF21_GET_VALID(mp1_smnif_tlb_vf21) \
      ((mp1_smnif_tlb_vf21 & MP1_SMNIF_TLB_VF21_VALID_MASK) >> MP1_SMNIF_TLB_VF21_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF21_SET_VFID(mp1_smnif_tlb_vf21_reg, vfid) \
      mp1_smnif_tlb_vf21_reg = (mp1_smnif_tlb_vf21_reg & ~MP1_SMNIF_TLB_VF21_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF21_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF21_SET_VF(mp1_smnif_tlb_vf21_reg, vf) \
      mp1_smnif_tlb_vf21_reg = (mp1_smnif_tlb_vf21_reg & ~MP1_SMNIF_TLB_VF21_VF_MASK) | (vf << MP1_SMNIF_TLB_VF21_VF_SHIFT)
#define MP1_SMNIF_TLB_VF21_SET_VALID(mp1_smnif_tlb_vf21_reg, valid) \
      mp1_smnif_tlb_vf21_reg = (mp1_smnif_tlb_vf21_reg & ~MP1_SMNIF_TLB_VF21_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF21_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf21_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF21_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF21_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF21_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf21_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf21_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF21_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF21_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF21_VFID_SIZE;
      } mp1_smnif_tlb_vf21_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf21_t f;
} mp1_smnif_tlb_vf21_u;


/*
 * MP1_SMNIF_TLB_VF22 struct
 */

#define MP1_SMNIF_TLB_VF22_REG_SIZE         32
#define MP1_SMNIF_TLB_VF22_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF22_VF_SIZE  1
#define MP1_SMNIF_TLB_VF22_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF22_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF22_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF22_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF22_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF22_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF22_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF22_MASK \
      (MP1_SMNIF_TLB_VF22_VFID_MASK | \
      MP1_SMNIF_TLB_VF22_VF_MASK | \
      MP1_SMNIF_TLB_VF22_VALID_MASK)

#define MP1_SMNIF_TLB_VF22_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF22_GET_VFID(mp1_smnif_tlb_vf22) \
      ((mp1_smnif_tlb_vf22 & MP1_SMNIF_TLB_VF22_VFID_MASK) >> MP1_SMNIF_TLB_VF22_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF22_GET_VF(mp1_smnif_tlb_vf22) \
      ((mp1_smnif_tlb_vf22 & MP1_SMNIF_TLB_VF22_VF_MASK) >> MP1_SMNIF_TLB_VF22_VF_SHIFT)
#define MP1_SMNIF_TLB_VF22_GET_VALID(mp1_smnif_tlb_vf22) \
      ((mp1_smnif_tlb_vf22 & MP1_SMNIF_TLB_VF22_VALID_MASK) >> MP1_SMNIF_TLB_VF22_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF22_SET_VFID(mp1_smnif_tlb_vf22_reg, vfid) \
      mp1_smnif_tlb_vf22_reg = (mp1_smnif_tlb_vf22_reg & ~MP1_SMNIF_TLB_VF22_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF22_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF22_SET_VF(mp1_smnif_tlb_vf22_reg, vf) \
      mp1_smnif_tlb_vf22_reg = (mp1_smnif_tlb_vf22_reg & ~MP1_SMNIF_TLB_VF22_VF_MASK) | (vf << MP1_SMNIF_TLB_VF22_VF_SHIFT)
#define MP1_SMNIF_TLB_VF22_SET_VALID(mp1_smnif_tlb_vf22_reg, valid) \
      mp1_smnif_tlb_vf22_reg = (mp1_smnif_tlb_vf22_reg & ~MP1_SMNIF_TLB_VF22_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF22_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf22_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF22_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF22_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF22_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf22_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf22_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF22_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF22_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF22_VFID_SIZE;
      } mp1_smnif_tlb_vf22_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf22_t f;
} mp1_smnif_tlb_vf22_u;


/*
 * MP1_SMNIF_TLB_VF23 struct
 */

#define MP1_SMNIF_TLB_VF23_REG_SIZE         32
#define MP1_SMNIF_TLB_VF23_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF23_VF_SIZE  1
#define MP1_SMNIF_TLB_VF23_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF23_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF23_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF23_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF23_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF23_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF23_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF23_MASK \
      (MP1_SMNIF_TLB_VF23_VFID_MASK | \
      MP1_SMNIF_TLB_VF23_VF_MASK | \
      MP1_SMNIF_TLB_VF23_VALID_MASK)

#define MP1_SMNIF_TLB_VF23_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF23_GET_VFID(mp1_smnif_tlb_vf23) \
      ((mp1_smnif_tlb_vf23 & MP1_SMNIF_TLB_VF23_VFID_MASK) >> MP1_SMNIF_TLB_VF23_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF23_GET_VF(mp1_smnif_tlb_vf23) \
      ((mp1_smnif_tlb_vf23 & MP1_SMNIF_TLB_VF23_VF_MASK) >> MP1_SMNIF_TLB_VF23_VF_SHIFT)
#define MP1_SMNIF_TLB_VF23_GET_VALID(mp1_smnif_tlb_vf23) \
      ((mp1_smnif_tlb_vf23 & MP1_SMNIF_TLB_VF23_VALID_MASK) >> MP1_SMNIF_TLB_VF23_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF23_SET_VFID(mp1_smnif_tlb_vf23_reg, vfid) \
      mp1_smnif_tlb_vf23_reg = (mp1_smnif_tlb_vf23_reg & ~MP1_SMNIF_TLB_VF23_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF23_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF23_SET_VF(mp1_smnif_tlb_vf23_reg, vf) \
      mp1_smnif_tlb_vf23_reg = (mp1_smnif_tlb_vf23_reg & ~MP1_SMNIF_TLB_VF23_VF_MASK) | (vf << MP1_SMNIF_TLB_VF23_VF_SHIFT)
#define MP1_SMNIF_TLB_VF23_SET_VALID(mp1_smnif_tlb_vf23_reg, valid) \
      mp1_smnif_tlb_vf23_reg = (mp1_smnif_tlb_vf23_reg & ~MP1_SMNIF_TLB_VF23_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF23_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf23_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF23_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF23_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF23_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf23_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf23_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF23_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF23_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF23_VFID_SIZE;
      } mp1_smnif_tlb_vf23_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf23_t f;
} mp1_smnif_tlb_vf23_u;


/*
 * MP1_SMNIF_TLB_VF24 struct
 */

#define MP1_SMNIF_TLB_VF24_REG_SIZE         32
#define MP1_SMNIF_TLB_VF24_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF24_VF_SIZE  1
#define MP1_SMNIF_TLB_VF24_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF24_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF24_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF24_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF24_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF24_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF24_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF24_MASK \
      (MP1_SMNIF_TLB_VF24_VFID_MASK | \
      MP1_SMNIF_TLB_VF24_VF_MASK | \
      MP1_SMNIF_TLB_VF24_VALID_MASK)

#define MP1_SMNIF_TLB_VF24_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF24_GET_VFID(mp1_smnif_tlb_vf24) \
      ((mp1_smnif_tlb_vf24 & MP1_SMNIF_TLB_VF24_VFID_MASK) >> MP1_SMNIF_TLB_VF24_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF24_GET_VF(mp1_smnif_tlb_vf24) \
      ((mp1_smnif_tlb_vf24 & MP1_SMNIF_TLB_VF24_VF_MASK) >> MP1_SMNIF_TLB_VF24_VF_SHIFT)
#define MP1_SMNIF_TLB_VF24_GET_VALID(mp1_smnif_tlb_vf24) \
      ((mp1_smnif_tlb_vf24 & MP1_SMNIF_TLB_VF24_VALID_MASK) >> MP1_SMNIF_TLB_VF24_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF24_SET_VFID(mp1_smnif_tlb_vf24_reg, vfid) \
      mp1_smnif_tlb_vf24_reg = (mp1_smnif_tlb_vf24_reg & ~MP1_SMNIF_TLB_VF24_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF24_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF24_SET_VF(mp1_smnif_tlb_vf24_reg, vf) \
      mp1_smnif_tlb_vf24_reg = (mp1_smnif_tlb_vf24_reg & ~MP1_SMNIF_TLB_VF24_VF_MASK) | (vf << MP1_SMNIF_TLB_VF24_VF_SHIFT)
#define MP1_SMNIF_TLB_VF24_SET_VALID(mp1_smnif_tlb_vf24_reg, valid) \
      mp1_smnif_tlb_vf24_reg = (mp1_smnif_tlb_vf24_reg & ~MP1_SMNIF_TLB_VF24_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF24_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf24_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF24_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF24_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF24_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf24_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf24_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF24_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF24_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF24_VFID_SIZE;
      } mp1_smnif_tlb_vf24_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf24_t f;
} mp1_smnif_tlb_vf24_u;


/*
 * MP1_SMNIF_TLB_VF25 struct
 */

#define MP1_SMNIF_TLB_VF25_REG_SIZE         32
#define MP1_SMNIF_TLB_VF25_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF25_VF_SIZE  1
#define MP1_SMNIF_TLB_VF25_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF25_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF25_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF25_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF25_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF25_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF25_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF25_MASK \
      (MP1_SMNIF_TLB_VF25_VFID_MASK | \
      MP1_SMNIF_TLB_VF25_VF_MASK | \
      MP1_SMNIF_TLB_VF25_VALID_MASK)

#define MP1_SMNIF_TLB_VF25_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF25_GET_VFID(mp1_smnif_tlb_vf25) \
      ((mp1_smnif_tlb_vf25 & MP1_SMNIF_TLB_VF25_VFID_MASK) >> MP1_SMNIF_TLB_VF25_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF25_GET_VF(mp1_smnif_tlb_vf25) \
      ((mp1_smnif_tlb_vf25 & MP1_SMNIF_TLB_VF25_VF_MASK) >> MP1_SMNIF_TLB_VF25_VF_SHIFT)
#define MP1_SMNIF_TLB_VF25_GET_VALID(mp1_smnif_tlb_vf25) \
      ((mp1_smnif_tlb_vf25 & MP1_SMNIF_TLB_VF25_VALID_MASK) >> MP1_SMNIF_TLB_VF25_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF25_SET_VFID(mp1_smnif_tlb_vf25_reg, vfid) \
      mp1_smnif_tlb_vf25_reg = (mp1_smnif_tlb_vf25_reg & ~MP1_SMNIF_TLB_VF25_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF25_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF25_SET_VF(mp1_smnif_tlb_vf25_reg, vf) \
      mp1_smnif_tlb_vf25_reg = (mp1_smnif_tlb_vf25_reg & ~MP1_SMNIF_TLB_VF25_VF_MASK) | (vf << MP1_SMNIF_TLB_VF25_VF_SHIFT)
#define MP1_SMNIF_TLB_VF25_SET_VALID(mp1_smnif_tlb_vf25_reg, valid) \
      mp1_smnif_tlb_vf25_reg = (mp1_smnif_tlb_vf25_reg & ~MP1_SMNIF_TLB_VF25_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF25_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf25_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF25_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF25_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF25_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf25_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf25_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF25_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF25_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF25_VFID_SIZE;
      } mp1_smnif_tlb_vf25_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf25_t f;
} mp1_smnif_tlb_vf25_u;


/*
 * MP1_SMNIF_TLB_VF26 struct
 */

#define MP1_SMNIF_TLB_VF26_REG_SIZE         32
#define MP1_SMNIF_TLB_VF26_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF26_VF_SIZE  1
#define MP1_SMNIF_TLB_VF26_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF26_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF26_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF26_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF26_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF26_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF26_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF26_MASK \
      (MP1_SMNIF_TLB_VF26_VFID_MASK | \
      MP1_SMNIF_TLB_VF26_VF_MASK | \
      MP1_SMNIF_TLB_VF26_VALID_MASK)

#define MP1_SMNIF_TLB_VF26_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF26_GET_VFID(mp1_smnif_tlb_vf26) \
      ((mp1_smnif_tlb_vf26 & MP1_SMNIF_TLB_VF26_VFID_MASK) >> MP1_SMNIF_TLB_VF26_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF26_GET_VF(mp1_smnif_tlb_vf26) \
      ((mp1_smnif_tlb_vf26 & MP1_SMNIF_TLB_VF26_VF_MASK) >> MP1_SMNIF_TLB_VF26_VF_SHIFT)
#define MP1_SMNIF_TLB_VF26_GET_VALID(mp1_smnif_tlb_vf26) \
      ((mp1_smnif_tlb_vf26 & MP1_SMNIF_TLB_VF26_VALID_MASK) >> MP1_SMNIF_TLB_VF26_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF26_SET_VFID(mp1_smnif_tlb_vf26_reg, vfid) \
      mp1_smnif_tlb_vf26_reg = (mp1_smnif_tlb_vf26_reg & ~MP1_SMNIF_TLB_VF26_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF26_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF26_SET_VF(mp1_smnif_tlb_vf26_reg, vf) \
      mp1_smnif_tlb_vf26_reg = (mp1_smnif_tlb_vf26_reg & ~MP1_SMNIF_TLB_VF26_VF_MASK) | (vf << MP1_SMNIF_TLB_VF26_VF_SHIFT)
#define MP1_SMNIF_TLB_VF26_SET_VALID(mp1_smnif_tlb_vf26_reg, valid) \
      mp1_smnif_tlb_vf26_reg = (mp1_smnif_tlb_vf26_reg & ~MP1_SMNIF_TLB_VF26_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF26_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf26_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF26_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF26_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF26_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf26_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf26_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF26_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF26_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF26_VFID_SIZE;
      } mp1_smnif_tlb_vf26_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf26_t f;
} mp1_smnif_tlb_vf26_u;


/*
 * MP1_SMNIF_TLB_VF27 struct
 */

#define MP1_SMNIF_TLB_VF27_REG_SIZE         32
#define MP1_SMNIF_TLB_VF27_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF27_VF_SIZE  1
#define MP1_SMNIF_TLB_VF27_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF27_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF27_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF27_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF27_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF27_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF27_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF27_MASK \
      (MP1_SMNIF_TLB_VF27_VFID_MASK | \
      MP1_SMNIF_TLB_VF27_VF_MASK | \
      MP1_SMNIF_TLB_VF27_VALID_MASK)

#define MP1_SMNIF_TLB_VF27_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF27_GET_VFID(mp1_smnif_tlb_vf27) \
      ((mp1_smnif_tlb_vf27 & MP1_SMNIF_TLB_VF27_VFID_MASK) >> MP1_SMNIF_TLB_VF27_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF27_GET_VF(mp1_smnif_tlb_vf27) \
      ((mp1_smnif_tlb_vf27 & MP1_SMNIF_TLB_VF27_VF_MASK) >> MP1_SMNIF_TLB_VF27_VF_SHIFT)
#define MP1_SMNIF_TLB_VF27_GET_VALID(mp1_smnif_tlb_vf27) \
      ((mp1_smnif_tlb_vf27 & MP1_SMNIF_TLB_VF27_VALID_MASK) >> MP1_SMNIF_TLB_VF27_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF27_SET_VFID(mp1_smnif_tlb_vf27_reg, vfid) \
      mp1_smnif_tlb_vf27_reg = (mp1_smnif_tlb_vf27_reg & ~MP1_SMNIF_TLB_VF27_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF27_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF27_SET_VF(mp1_smnif_tlb_vf27_reg, vf) \
      mp1_smnif_tlb_vf27_reg = (mp1_smnif_tlb_vf27_reg & ~MP1_SMNIF_TLB_VF27_VF_MASK) | (vf << MP1_SMNIF_TLB_VF27_VF_SHIFT)
#define MP1_SMNIF_TLB_VF27_SET_VALID(mp1_smnif_tlb_vf27_reg, valid) \
      mp1_smnif_tlb_vf27_reg = (mp1_smnif_tlb_vf27_reg & ~MP1_SMNIF_TLB_VF27_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF27_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf27_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF27_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF27_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF27_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf27_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf27_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF27_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF27_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF27_VFID_SIZE;
      } mp1_smnif_tlb_vf27_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf27_t f;
} mp1_smnif_tlb_vf27_u;


/*
 * MP1_SMNIF_TLB_VF28 struct
 */

#define MP1_SMNIF_TLB_VF28_REG_SIZE         32
#define MP1_SMNIF_TLB_VF28_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF28_VF_SIZE  1
#define MP1_SMNIF_TLB_VF28_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF28_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF28_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF28_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF28_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF28_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF28_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF28_MASK \
      (MP1_SMNIF_TLB_VF28_VFID_MASK | \
      MP1_SMNIF_TLB_VF28_VF_MASK | \
      MP1_SMNIF_TLB_VF28_VALID_MASK)

#define MP1_SMNIF_TLB_VF28_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF28_GET_VFID(mp1_smnif_tlb_vf28) \
      ((mp1_smnif_tlb_vf28 & MP1_SMNIF_TLB_VF28_VFID_MASK) >> MP1_SMNIF_TLB_VF28_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF28_GET_VF(mp1_smnif_tlb_vf28) \
      ((mp1_smnif_tlb_vf28 & MP1_SMNIF_TLB_VF28_VF_MASK) >> MP1_SMNIF_TLB_VF28_VF_SHIFT)
#define MP1_SMNIF_TLB_VF28_GET_VALID(mp1_smnif_tlb_vf28) \
      ((mp1_smnif_tlb_vf28 & MP1_SMNIF_TLB_VF28_VALID_MASK) >> MP1_SMNIF_TLB_VF28_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF28_SET_VFID(mp1_smnif_tlb_vf28_reg, vfid) \
      mp1_smnif_tlb_vf28_reg = (mp1_smnif_tlb_vf28_reg & ~MP1_SMNIF_TLB_VF28_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF28_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF28_SET_VF(mp1_smnif_tlb_vf28_reg, vf) \
      mp1_smnif_tlb_vf28_reg = (mp1_smnif_tlb_vf28_reg & ~MP1_SMNIF_TLB_VF28_VF_MASK) | (vf << MP1_SMNIF_TLB_VF28_VF_SHIFT)
#define MP1_SMNIF_TLB_VF28_SET_VALID(mp1_smnif_tlb_vf28_reg, valid) \
      mp1_smnif_tlb_vf28_reg = (mp1_smnif_tlb_vf28_reg & ~MP1_SMNIF_TLB_VF28_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF28_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf28_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF28_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF28_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF28_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf28_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf28_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF28_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF28_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF28_VFID_SIZE;
      } mp1_smnif_tlb_vf28_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf28_t f;
} mp1_smnif_tlb_vf28_u;


/*
 * MP1_SMNIF_TLB_VF29 struct
 */

#define MP1_SMNIF_TLB_VF29_REG_SIZE         32
#define MP1_SMNIF_TLB_VF29_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF29_VF_SIZE  1
#define MP1_SMNIF_TLB_VF29_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF29_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF29_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF29_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF29_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF29_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF29_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF29_MASK \
      (MP1_SMNIF_TLB_VF29_VFID_MASK | \
      MP1_SMNIF_TLB_VF29_VF_MASK | \
      MP1_SMNIF_TLB_VF29_VALID_MASK)

#define MP1_SMNIF_TLB_VF29_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF29_GET_VFID(mp1_smnif_tlb_vf29) \
      ((mp1_smnif_tlb_vf29 & MP1_SMNIF_TLB_VF29_VFID_MASK) >> MP1_SMNIF_TLB_VF29_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF29_GET_VF(mp1_smnif_tlb_vf29) \
      ((mp1_smnif_tlb_vf29 & MP1_SMNIF_TLB_VF29_VF_MASK) >> MP1_SMNIF_TLB_VF29_VF_SHIFT)
#define MP1_SMNIF_TLB_VF29_GET_VALID(mp1_smnif_tlb_vf29) \
      ((mp1_smnif_tlb_vf29 & MP1_SMNIF_TLB_VF29_VALID_MASK) >> MP1_SMNIF_TLB_VF29_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF29_SET_VFID(mp1_smnif_tlb_vf29_reg, vfid) \
      mp1_smnif_tlb_vf29_reg = (mp1_smnif_tlb_vf29_reg & ~MP1_SMNIF_TLB_VF29_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF29_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF29_SET_VF(mp1_smnif_tlb_vf29_reg, vf) \
      mp1_smnif_tlb_vf29_reg = (mp1_smnif_tlb_vf29_reg & ~MP1_SMNIF_TLB_VF29_VF_MASK) | (vf << MP1_SMNIF_TLB_VF29_VF_SHIFT)
#define MP1_SMNIF_TLB_VF29_SET_VALID(mp1_smnif_tlb_vf29_reg, valid) \
      mp1_smnif_tlb_vf29_reg = (mp1_smnif_tlb_vf29_reg & ~MP1_SMNIF_TLB_VF29_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF29_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf29_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF29_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF29_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF29_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf29_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf29_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF29_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF29_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF29_VFID_SIZE;
      } mp1_smnif_tlb_vf29_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf29_t f;
} mp1_smnif_tlb_vf29_u;


/*
 * MP1_SMNIF_TLB_VF30 struct
 */

#define MP1_SMNIF_TLB_VF30_REG_SIZE         32
#define MP1_SMNIF_TLB_VF30_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF30_VF_SIZE  1
#define MP1_SMNIF_TLB_VF30_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF30_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF30_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF30_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF30_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF30_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF30_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF30_MASK \
      (MP1_SMNIF_TLB_VF30_VFID_MASK | \
      MP1_SMNIF_TLB_VF30_VF_MASK | \
      MP1_SMNIF_TLB_VF30_VALID_MASK)

#define MP1_SMNIF_TLB_VF30_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF30_GET_VFID(mp1_smnif_tlb_vf30) \
      ((mp1_smnif_tlb_vf30 & MP1_SMNIF_TLB_VF30_VFID_MASK) >> MP1_SMNIF_TLB_VF30_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF30_GET_VF(mp1_smnif_tlb_vf30) \
      ((mp1_smnif_tlb_vf30 & MP1_SMNIF_TLB_VF30_VF_MASK) >> MP1_SMNIF_TLB_VF30_VF_SHIFT)
#define MP1_SMNIF_TLB_VF30_GET_VALID(mp1_smnif_tlb_vf30) \
      ((mp1_smnif_tlb_vf30 & MP1_SMNIF_TLB_VF30_VALID_MASK) >> MP1_SMNIF_TLB_VF30_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF30_SET_VFID(mp1_smnif_tlb_vf30_reg, vfid) \
      mp1_smnif_tlb_vf30_reg = (mp1_smnif_tlb_vf30_reg & ~MP1_SMNIF_TLB_VF30_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF30_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF30_SET_VF(mp1_smnif_tlb_vf30_reg, vf) \
      mp1_smnif_tlb_vf30_reg = (mp1_smnif_tlb_vf30_reg & ~MP1_SMNIF_TLB_VF30_VF_MASK) | (vf << MP1_SMNIF_TLB_VF30_VF_SHIFT)
#define MP1_SMNIF_TLB_VF30_SET_VALID(mp1_smnif_tlb_vf30_reg, valid) \
      mp1_smnif_tlb_vf30_reg = (mp1_smnif_tlb_vf30_reg & ~MP1_SMNIF_TLB_VF30_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF30_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf30_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF30_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF30_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF30_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf30_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf30_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF30_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF30_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF30_VFID_SIZE;
      } mp1_smnif_tlb_vf30_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf30_t f;
} mp1_smnif_tlb_vf30_u;


/*
 * MP1_SMNIF_TLB_VF31 struct
 */

#define MP1_SMNIF_TLB_VF31_REG_SIZE         32
#define MP1_SMNIF_TLB_VF31_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF31_VF_SIZE  1
#define MP1_SMNIF_TLB_VF31_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF31_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF31_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF31_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF31_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF31_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF31_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF31_MASK \
      (MP1_SMNIF_TLB_VF31_VFID_MASK | \
      MP1_SMNIF_TLB_VF31_VF_MASK | \
      MP1_SMNIF_TLB_VF31_VALID_MASK)

#define MP1_SMNIF_TLB_VF31_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF31_GET_VFID(mp1_smnif_tlb_vf31) \
      ((mp1_smnif_tlb_vf31 & MP1_SMNIF_TLB_VF31_VFID_MASK) >> MP1_SMNIF_TLB_VF31_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF31_GET_VF(mp1_smnif_tlb_vf31) \
      ((mp1_smnif_tlb_vf31 & MP1_SMNIF_TLB_VF31_VF_MASK) >> MP1_SMNIF_TLB_VF31_VF_SHIFT)
#define MP1_SMNIF_TLB_VF31_GET_VALID(mp1_smnif_tlb_vf31) \
      ((mp1_smnif_tlb_vf31 & MP1_SMNIF_TLB_VF31_VALID_MASK) >> MP1_SMNIF_TLB_VF31_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF31_SET_VFID(mp1_smnif_tlb_vf31_reg, vfid) \
      mp1_smnif_tlb_vf31_reg = (mp1_smnif_tlb_vf31_reg & ~MP1_SMNIF_TLB_VF31_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF31_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF31_SET_VF(mp1_smnif_tlb_vf31_reg, vf) \
      mp1_smnif_tlb_vf31_reg = (mp1_smnif_tlb_vf31_reg & ~MP1_SMNIF_TLB_VF31_VF_MASK) | (vf << MP1_SMNIF_TLB_VF31_VF_SHIFT)
#define MP1_SMNIF_TLB_VF31_SET_VALID(mp1_smnif_tlb_vf31_reg, valid) \
      mp1_smnif_tlb_vf31_reg = (mp1_smnif_tlb_vf31_reg & ~MP1_SMNIF_TLB_VF31_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF31_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf31_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF31_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF31_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF31_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf31_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf31_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF31_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF31_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF31_VFID_SIZE;
      } mp1_smnif_tlb_vf31_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf31_t f;
} mp1_smnif_tlb_vf31_u;


/*
 * MP1_SMNIF_TLB_VF32 struct
 */

#define MP1_SMNIF_TLB_VF32_REG_SIZE         32
#define MP1_SMNIF_TLB_VF32_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF32_VF_SIZE  1
#define MP1_SMNIF_TLB_VF32_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF32_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF32_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF32_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF32_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF32_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF32_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF32_MASK \
      (MP1_SMNIF_TLB_VF32_VFID_MASK | \
      MP1_SMNIF_TLB_VF32_VF_MASK | \
      MP1_SMNIF_TLB_VF32_VALID_MASK)

#define MP1_SMNIF_TLB_VF32_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF32_GET_VFID(mp1_smnif_tlb_vf32) \
      ((mp1_smnif_tlb_vf32 & MP1_SMNIF_TLB_VF32_VFID_MASK) >> MP1_SMNIF_TLB_VF32_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF32_GET_VF(mp1_smnif_tlb_vf32) \
      ((mp1_smnif_tlb_vf32 & MP1_SMNIF_TLB_VF32_VF_MASK) >> MP1_SMNIF_TLB_VF32_VF_SHIFT)
#define MP1_SMNIF_TLB_VF32_GET_VALID(mp1_smnif_tlb_vf32) \
      ((mp1_smnif_tlb_vf32 & MP1_SMNIF_TLB_VF32_VALID_MASK) >> MP1_SMNIF_TLB_VF32_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF32_SET_VFID(mp1_smnif_tlb_vf32_reg, vfid) \
      mp1_smnif_tlb_vf32_reg = (mp1_smnif_tlb_vf32_reg & ~MP1_SMNIF_TLB_VF32_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF32_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF32_SET_VF(mp1_smnif_tlb_vf32_reg, vf) \
      mp1_smnif_tlb_vf32_reg = (mp1_smnif_tlb_vf32_reg & ~MP1_SMNIF_TLB_VF32_VF_MASK) | (vf << MP1_SMNIF_TLB_VF32_VF_SHIFT)
#define MP1_SMNIF_TLB_VF32_SET_VALID(mp1_smnif_tlb_vf32_reg, valid) \
      mp1_smnif_tlb_vf32_reg = (mp1_smnif_tlb_vf32_reg & ~MP1_SMNIF_TLB_VF32_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF32_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf32_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF32_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF32_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF32_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf32_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf32_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF32_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF32_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF32_VFID_SIZE;
      } mp1_smnif_tlb_vf32_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf32_t f;
} mp1_smnif_tlb_vf32_u;


/*
 * MP1_SMNIF_TLB_VF33 struct
 */

#define MP1_SMNIF_TLB_VF33_REG_SIZE         32
#define MP1_SMNIF_TLB_VF33_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF33_VF_SIZE  1
#define MP1_SMNIF_TLB_VF33_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF33_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF33_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF33_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF33_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF33_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF33_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF33_MASK \
      (MP1_SMNIF_TLB_VF33_VFID_MASK | \
      MP1_SMNIF_TLB_VF33_VF_MASK | \
      MP1_SMNIF_TLB_VF33_VALID_MASK)

#define MP1_SMNIF_TLB_VF33_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF33_GET_VFID(mp1_smnif_tlb_vf33) \
      ((mp1_smnif_tlb_vf33 & MP1_SMNIF_TLB_VF33_VFID_MASK) >> MP1_SMNIF_TLB_VF33_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF33_GET_VF(mp1_smnif_tlb_vf33) \
      ((mp1_smnif_tlb_vf33 & MP1_SMNIF_TLB_VF33_VF_MASK) >> MP1_SMNIF_TLB_VF33_VF_SHIFT)
#define MP1_SMNIF_TLB_VF33_GET_VALID(mp1_smnif_tlb_vf33) \
      ((mp1_smnif_tlb_vf33 & MP1_SMNIF_TLB_VF33_VALID_MASK) >> MP1_SMNIF_TLB_VF33_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF33_SET_VFID(mp1_smnif_tlb_vf33_reg, vfid) \
      mp1_smnif_tlb_vf33_reg = (mp1_smnif_tlb_vf33_reg & ~MP1_SMNIF_TLB_VF33_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF33_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF33_SET_VF(mp1_smnif_tlb_vf33_reg, vf) \
      mp1_smnif_tlb_vf33_reg = (mp1_smnif_tlb_vf33_reg & ~MP1_SMNIF_TLB_VF33_VF_MASK) | (vf << MP1_SMNIF_TLB_VF33_VF_SHIFT)
#define MP1_SMNIF_TLB_VF33_SET_VALID(mp1_smnif_tlb_vf33_reg, valid) \
      mp1_smnif_tlb_vf33_reg = (mp1_smnif_tlb_vf33_reg & ~MP1_SMNIF_TLB_VF33_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF33_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf33_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF33_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF33_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF33_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf33_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf33_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF33_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF33_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF33_VFID_SIZE;
      } mp1_smnif_tlb_vf33_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf33_t f;
} mp1_smnif_tlb_vf33_u;


/*
 * MP1_SMNIF_TLB_VF34 struct
 */

#define MP1_SMNIF_TLB_VF34_REG_SIZE         32
#define MP1_SMNIF_TLB_VF34_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF34_VF_SIZE  1
#define MP1_SMNIF_TLB_VF34_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF34_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF34_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF34_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF34_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF34_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF34_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF34_MASK \
      (MP1_SMNIF_TLB_VF34_VFID_MASK | \
      MP1_SMNIF_TLB_VF34_VF_MASK | \
      MP1_SMNIF_TLB_VF34_VALID_MASK)

#define MP1_SMNIF_TLB_VF34_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF34_GET_VFID(mp1_smnif_tlb_vf34) \
      ((mp1_smnif_tlb_vf34 & MP1_SMNIF_TLB_VF34_VFID_MASK) >> MP1_SMNIF_TLB_VF34_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF34_GET_VF(mp1_smnif_tlb_vf34) \
      ((mp1_smnif_tlb_vf34 & MP1_SMNIF_TLB_VF34_VF_MASK) >> MP1_SMNIF_TLB_VF34_VF_SHIFT)
#define MP1_SMNIF_TLB_VF34_GET_VALID(mp1_smnif_tlb_vf34) \
      ((mp1_smnif_tlb_vf34 & MP1_SMNIF_TLB_VF34_VALID_MASK) >> MP1_SMNIF_TLB_VF34_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF34_SET_VFID(mp1_smnif_tlb_vf34_reg, vfid) \
      mp1_smnif_tlb_vf34_reg = (mp1_smnif_tlb_vf34_reg & ~MP1_SMNIF_TLB_VF34_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF34_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF34_SET_VF(mp1_smnif_tlb_vf34_reg, vf) \
      mp1_smnif_tlb_vf34_reg = (mp1_smnif_tlb_vf34_reg & ~MP1_SMNIF_TLB_VF34_VF_MASK) | (vf << MP1_SMNIF_TLB_VF34_VF_SHIFT)
#define MP1_SMNIF_TLB_VF34_SET_VALID(mp1_smnif_tlb_vf34_reg, valid) \
      mp1_smnif_tlb_vf34_reg = (mp1_smnif_tlb_vf34_reg & ~MP1_SMNIF_TLB_VF34_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF34_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf34_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF34_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF34_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF34_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf34_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf34_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF34_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF34_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF34_VFID_SIZE;
      } mp1_smnif_tlb_vf34_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf34_t f;
} mp1_smnif_tlb_vf34_u;


/*
 * MP1_SMNIF_TLB_VF35 struct
 */

#define MP1_SMNIF_TLB_VF35_REG_SIZE         32
#define MP1_SMNIF_TLB_VF35_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF35_VF_SIZE  1
#define MP1_SMNIF_TLB_VF35_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF35_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF35_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF35_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF35_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF35_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF35_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF35_MASK \
      (MP1_SMNIF_TLB_VF35_VFID_MASK | \
      MP1_SMNIF_TLB_VF35_VF_MASK | \
      MP1_SMNIF_TLB_VF35_VALID_MASK)

#define MP1_SMNIF_TLB_VF35_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF35_GET_VFID(mp1_smnif_tlb_vf35) \
      ((mp1_smnif_tlb_vf35 & MP1_SMNIF_TLB_VF35_VFID_MASK) >> MP1_SMNIF_TLB_VF35_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF35_GET_VF(mp1_smnif_tlb_vf35) \
      ((mp1_smnif_tlb_vf35 & MP1_SMNIF_TLB_VF35_VF_MASK) >> MP1_SMNIF_TLB_VF35_VF_SHIFT)
#define MP1_SMNIF_TLB_VF35_GET_VALID(mp1_smnif_tlb_vf35) \
      ((mp1_smnif_tlb_vf35 & MP1_SMNIF_TLB_VF35_VALID_MASK) >> MP1_SMNIF_TLB_VF35_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF35_SET_VFID(mp1_smnif_tlb_vf35_reg, vfid) \
      mp1_smnif_tlb_vf35_reg = (mp1_smnif_tlb_vf35_reg & ~MP1_SMNIF_TLB_VF35_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF35_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF35_SET_VF(mp1_smnif_tlb_vf35_reg, vf) \
      mp1_smnif_tlb_vf35_reg = (mp1_smnif_tlb_vf35_reg & ~MP1_SMNIF_TLB_VF35_VF_MASK) | (vf << MP1_SMNIF_TLB_VF35_VF_SHIFT)
#define MP1_SMNIF_TLB_VF35_SET_VALID(mp1_smnif_tlb_vf35_reg, valid) \
      mp1_smnif_tlb_vf35_reg = (mp1_smnif_tlb_vf35_reg & ~MP1_SMNIF_TLB_VF35_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF35_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf35_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF35_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF35_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF35_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf35_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf35_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF35_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF35_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF35_VFID_SIZE;
      } mp1_smnif_tlb_vf35_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf35_t f;
} mp1_smnif_tlb_vf35_u;


/*
 * MP1_SMNIF_TLB_VF36 struct
 */

#define MP1_SMNIF_TLB_VF36_REG_SIZE         32
#define MP1_SMNIF_TLB_VF36_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF36_VF_SIZE  1
#define MP1_SMNIF_TLB_VF36_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF36_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF36_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF36_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF36_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF36_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF36_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF36_MASK \
      (MP1_SMNIF_TLB_VF36_VFID_MASK | \
      MP1_SMNIF_TLB_VF36_VF_MASK | \
      MP1_SMNIF_TLB_VF36_VALID_MASK)

#define MP1_SMNIF_TLB_VF36_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF36_GET_VFID(mp1_smnif_tlb_vf36) \
      ((mp1_smnif_tlb_vf36 & MP1_SMNIF_TLB_VF36_VFID_MASK) >> MP1_SMNIF_TLB_VF36_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF36_GET_VF(mp1_smnif_tlb_vf36) \
      ((mp1_smnif_tlb_vf36 & MP1_SMNIF_TLB_VF36_VF_MASK) >> MP1_SMNIF_TLB_VF36_VF_SHIFT)
#define MP1_SMNIF_TLB_VF36_GET_VALID(mp1_smnif_tlb_vf36) \
      ((mp1_smnif_tlb_vf36 & MP1_SMNIF_TLB_VF36_VALID_MASK) >> MP1_SMNIF_TLB_VF36_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF36_SET_VFID(mp1_smnif_tlb_vf36_reg, vfid) \
      mp1_smnif_tlb_vf36_reg = (mp1_smnif_tlb_vf36_reg & ~MP1_SMNIF_TLB_VF36_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF36_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF36_SET_VF(mp1_smnif_tlb_vf36_reg, vf) \
      mp1_smnif_tlb_vf36_reg = (mp1_smnif_tlb_vf36_reg & ~MP1_SMNIF_TLB_VF36_VF_MASK) | (vf << MP1_SMNIF_TLB_VF36_VF_SHIFT)
#define MP1_SMNIF_TLB_VF36_SET_VALID(mp1_smnif_tlb_vf36_reg, valid) \
      mp1_smnif_tlb_vf36_reg = (mp1_smnif_tlb_vf36_reg & ~MP1_SMNIF_TLB_VF36_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF36_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf36_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF36_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF36_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF36_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf36_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf36_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF36_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF36_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF36_VFID_SIZE;
      } mp1_smnif_tlb_vf36_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf36_t f;
} mp1_smnif_tlb_vf36_u;


/*
 * MP1_SMNIF_TLB_VF37 struct
 */

#define MP1_SMNIF_TLB_VF37_REG_SIZE         32
#define MP1_SMNIF_TLB_VF37_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF37_VF_SIZE  1
#define MP1_SMNIF_TLB_VF37_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF37_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF37_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF37_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF37_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF37_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF37_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF37_MASK \
      (MP1_SMNIF_TLB_VF37_VFID_MASK | \
      MP1_SMNIF_TLB_VF37_VF_MASK | \
      MP1_SMNIF_TLB_VF37_VALID_MASK)

#define MP1_SMNIF_TLB_VF37_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF37_GET_VFID(mp1_smnif_tlb_vf37) \
      ((mp1_smnif_tlb_vf37 & MP1_SMNIF_TLB_VF37_VFID_MASK) >> MP1_SMNIF_TLB_VF37_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF37_GET_VF(mp1_smnif_tlb_vf37) \
      ((mp1_smnif_tlb_vf37 & MP1_SMNIF_TLB_VF37_VF_MASK) >> MP1_SMNIF_TLB_VF37_VF_SHIFT)
#define MP1_SMNIF_TLB_VF37_GET_VALID(mp1_smnif_tlb_vf37) \
      ((mp1_smnif_tlb_vf37 & MP1_SMNIF_TLB_VF37_VALID_MASK) >> MP1_SMNIF_TLB_VF37_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF37_SET_VFID(mp1_smnif_tlb_vf37_reg, vfid) \
      mp1_smnif_tlb_vf37_reg = (mp1_smnif_tlb_vf37_reg & ~MP1_SMNIF_TLB_VF37_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF37_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF37_SET_VF(mp1_smnif_tlb_vf37_reg, vf) \
      mp1_smnif_tlb_vf37_reg = (mp1_smnif_tlb_vf37_reg & ~MP1_SMNIF_TLB_VF37_VF_MASK) | (vf << MP1_SMNIF_TLB_VF37_VF_SHIFT)
#define MP1_SMNIF_TLB_VF37_SET_VALID(mp1_smnif_tlb_vf37_reg, valid) \
      mp1_smnif_tlb_vf37_reg = (mp1_smnif_tlb_vf37_reg & ~MP1_SMNIF_TLB_VF37_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF37_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf37_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF37_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF37_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF37_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf37_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf37_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF37_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF37_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF37_VFID_SIZE;
      } mp1_smnif_tlb_vf37_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf37_t f;
} mp1_smnif_tlb_vf37_u;


/*
 * MP1_SMNIF_TLB_VF38 struct
 */

#define MP1_SMNIF_TLB_VF38_REG_SIZE         32
#define MP1_SMNIF_TLB_VF38_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF38_VF_SIZE  1
#define MP1_SMNIF_TLB_VF38_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF38_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF38_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF38_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF38_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF38_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF38_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF38_MASK \
      (MP1_SMNIF_TLB_VF38_VFID_MASK | \
      MP1_SMNIF_TLB_VF38_VF_MASK | \
      MP1_SMNIF_TLB_VF38_VALID_MASK)

#define MP1_SMNIF_TLB_VF38_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF38_GET_VFID(mp1_smnif_tlb_vf38) \
      ((mp1_smnif_tlb_vf38 & MP1_SMNIF_TLB_VF38_VFID_MASK) >> MP1_SMNIF_TLB_VF38_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF38_GET_VF(mp1_smnif_tlb_vf38) \
      ((mp1_smnif_tlb_vf38 & MP1_SMNIF_TLB_VF38_VF_MASK) >> MP1_SMNIF_TLB_VF38_VF_SHIFT)
#define MP1_SMNIF_TLB_VF38_GET_VALID(mp1_smnif_tlb_vf38) \
      ((mp1_smnif_tlb_vf38 & MP1_SMNIF_TLB_VF38_VALID_MASK) >> MP1_SMNIF_TLB_VF38_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF38_SET_VFID(mp1_smnif_tlb_vf38_reg, vfid) \
      mp1_smnif_tlb_vf38_reg = (mp1_smnif_tlb_vf38_reg & ~MP1_SMNIF_TLB_VF38_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF38_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF38_SET_VF(mp1_smnif_tlb_vf38_reg, vf) \
      mp1_smnif_tlb_vf38_reg = (mp1_smnif_tlb_vf38_reg & ~MP1_SMNIF_TLB_VF38_VF_MASK) | (vf << MP1_SMNIF_TLB_VF38_VF_SHIFT)
#define MP1_SMNIF_TLB_VF38_SET_VALID(mp1_smnif_tlb_vf38_reg, valid) \
      mp1_smnif_tlb_vf38_reg = (mp1_smnif_tlb_vf38_reg & ~MP1_SMNIF_TLB_VF38_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF38_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf38_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF38_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF38_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF38_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf38_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf38_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF38_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF38_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF38_VFID_SIZE;
      } mp1_smnif_tlb_vf38_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf38_t f;
} mp1_smnif_tlb_vf38_u;


/*
 * MP1_SMNIF_TLB_VF39 struct
 */

#define MP1_SMNIF_TLB_VF39_REG_SIZE         32
#define MP1_SMNIF_TLB_VF39_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF39_VF_SIZE  1
#define MP1_SMNIF_TLB_VF39_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF39_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF39_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF39_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF39_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF39_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF39_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF39_MASK \
      (MP1_SMNIF_TLB_VF39_VFID_MASK | \
      MP1_SMNIF_TLB_VF39_VF_MASK | \
      MP1_SMNIF_TLB_VF39_VALID_MASK)

#define MP1_SMNIF_TLB_VF39_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF39_GET_VFID(mp1_smnif_tlb_vf39) \
      ((mp1_smnif_tlb_vf39 & MP1_SMNIF_TLB_VF39_VFID_MASK) >> MP1_SMNIF_TLB_VF39_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF39_GET_VF(mp1_smnif_tlb_vf39) \
      ((mp1_smnif_tlb_vf39 & MP1_SMNIF_TLB_VF39_VF_MASK) >> MP1_SMNIF_TLB_VF39_VF_SHIFT)
#define MP1_SMNIF_TLB_VF39_GET_VALID(mp1_smnif_tlb_vf39) \
      ((mp1_smnif_tlb_vf39 & MP1_SMNIF_TLB_VF39_VALID_MASK) >> MP1_SMNIF_TLB_VF39_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF39_SET_VFID(mp1_smnif_tlb_vf39_reg, vfid) \
      mp1_smnif_tlb_vf39_reg = (mp1_smnif_tlb_vf39_reg & ~MP1_SMNIF_TLB_VF39_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF39_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF39_SET_VF(mp1_smnif_tlb_vf39_reg, vf) \
      mp1_smnif_tlb_vf39_reg = (mp1_smnif_tlb_vf39_reg & ~MP1_SMNIF_TLB_VF39_VF_MASK) | (vf << MP1_SMNIF_TLB_VF39_VF_SHIFT)
#define MP1_SMNIF_TLB_VF39_SET_VALID(mp1_smnif_tlb_vf39_reg, valid) \
      mp1_smnif_tlb_vf39_reg = (mp1_smnif_tlb_vf39_reg & ~MP1_SMNIF_TLB_VF39_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF39_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf39_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF39_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF39_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF39_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf39_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf39_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF39_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF39_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF39_VFID_SIZE;
      } mp1_smnif_tlb_vf39_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf39_t f;
} mp1_smnif_tlb_vf39_u;


/*
 * MP1_SMNIF_TLB_VF40 struct
 */

#define MP1_SMNIF_TLB_VF40_REG_SIZE         32
#define MP1_SMNIF_TLB_VF40_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF40_VF_SIZE  1
#define MP1_SMNIF_TLB_VF40_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF40_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF40_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF40_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF40_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF40_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF40_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF40_MASK \
      (MP1_SMNIF_TLB_VF40_VFID_MASK | \
      MP1_SMNIF_TLB_VF40_VF_MASK | \
      MP1_SMNIF_TLB_VF40_VALID_MASK)

#define MP1_SMNIF_TLB_VF40_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF40_GET_VFID(mp1_smnif_tlb_vf40) \
      ((mp1_smnif_tlb_vf40 & MP1_SMNIF_TLB_VF40_VFID_MASK) >> MP1_SMNIF_TLB_VF40_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF40_GET_VF(mp1_smnif_tlb_vf40) \
      ((mp1_smnif_tlb_vf40 & MP1_SMNIF_TLB_VF40_VF_MASK) >> MP1_SMNIF_TLB_VF40_VF_SHIFT)
#define MP1_SMNIF_TLB_VF40_GET_VALID(mp1_smnif_tlb_vf40) \
      ((mp1_smnif_tlb_vf40 & MP1_SMNIF_TLB_VF40_VALID_MASK) >> MP1_SMNIF_TLB_VF40_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF40_SET_VFID(mp1_smnif_tlb_vf40_reg, vfid) \
      mp1_smnif_tlb_vf40_reg = (mp1_smnif_tlb_vf40_reg & ~MP1_SMNIF_TLB_VF40_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF40_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF40_SET_VF(mp1_smnif_tlb_vf40_reg, vf) \
      mp1_smnif_tlb_vf40_reg = (mp1_smnif_tlb_vf40_reg & ~MP1_SMNIF_TLB_VF40_VF_MASK) | (vf << MP1_SMNIF_TLB_VF40_VF_SHIFT)
#define MP1_SMNIF_TLB_VF40_SET_VALID(mp1_smnif_tlb_vf40_reg, valid) \
      mp1_smnif_tlb_vf40_reg = (mp1_smnif_tlb_vf40_reg & ~MP1_SMNIF_TLB_VF40_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF40_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf40_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF40_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF40_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF40_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf40_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf40_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF40_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF40_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF40_VFID_SIZE;
      } mp1_smnif_tlb_vf40_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf40_t f;
} mp1_smnif_tlb_vf40_u;


/*
 * MP1_SMNIF_TLB_VF41 struct
 */

#define MP1_SMNIF_TLB_VF41_REG_SIZE         32
#define MP1_SMNIF_TLB_VF41_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF41_VF_SIZE  1
#define MP1_SMNIF_TLB_VF41_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF41_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF41_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF41_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF41_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF41_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF41_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF41_MASK \
      (MP1_SMNIF_TLB_VF41_VFID_MASK | \
      MP1_SMNIF_TLB_VF41_VF_MASK | \
      MP1_SMNIF_TLB_VF41_VALID_MASK)

#define MP1_SMNIF_TLB_VF41_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF41_GET_VFID(mp1_smnif_tlb_vf41) \
      ((mp1_smnif_tlb_vf41 & MP1_SMNIF_TLB_VF41_VFID_MASK) >> MP1_SMNIF_TLB_VF41_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF41_GET_VF(mp1_smnif_tlb_vf41) \
      ((mp1_smnif_tlb_vf41 & MP1_SMNIF_TLB_VF41_VF_MASK) >> MP1_SMNIF_TLB_VF41_VF_SHIFT)
#define MP1_SMNIF_TLB_VF41_GET_VALID(mp1_smnif_tlb_vf41) \
      ((mp1_smnif_tlb_vf41 & MP1_SMNIF_TLB_VF41_VALID_MASK) >> MP1_SMNIF_TLB_VF41_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF41_SET_VFID(mp1_smnif_tlb_vf41_reg, vfid) \
      mp1_smnif_tlb_vf41_reg = (mp1_smnif_tlb_vf41_reg & ~MP1_SMNIF_TLB_VF41_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF41_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF41_SET_VF(mp1_smnif_tlb_vf41_reg, vf) \
      mp1_smnif_tlb_vf41_reg = (mp1_smnif_tlb_vf41_reg & ~MP1_SMNIF_TLB_VF41_VF_MASK) | (vf << MP1_SMNIF_TLB_VF41_VF_SHIFT)
#define MP1_SMNIF_TLB_VF41_SET_VALID(mp1_smnif_tlb_vf41_reg, valid) \
      mp1_smnif_tlb_vf41_reg = (mp1_smnif_tlb_vf41_reg & ~MP1_SMNIF_TLB_VF41_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF41_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf41_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF41_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF41_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF41_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf41_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf41_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF41_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF41_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF41_VFID_SIZE;
      } mp1_smnif_tlb_vf41_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf41_t f;
} mp1_smnif_tlb_vf41_u;


/*
 * MP1_SMNIF_TLB_VF42 struct
 */

#define MP1_SMNIF_TLB_VF42_REG_SIZE         32
#define MP1_SMNIF_TLB_VF42_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF42_VF_SIZE  1
#define MP1_SMNIF_TLB_VF42_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF42_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF42_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF42_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF42_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF42_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF42_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF42_MASK \
      (MP1_SMNIF_TLB_VF42_VFID_MASK | \
      MP1_SMNIF_TLB_VF42_VF_MASK | \
      MP1_SMNIF_TLB_VF42_VALID_MASK)

#define MP1_SMNIF_TLB_VF42_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF42_GET_VFID(mp1_smnif_tlb_vf42) \
      ((mp1_smnif_tlb_vf42 & MP1_SMNIF_TLB_VF42_VFID_MASK) >> MP1_SMNIF_TLB_VF42_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF42_GET_VF(mp1_smnif_tlb_vf42) \
      ((mp1_smnif_tlb_vf42 & MP1_SMNIF_TLB_VF42_VF_MASK) >> MP1_SMNIF_TLB_VF42_VF_SHIFT)
#define MP1_SMNIF_TLB_VF42_GET_VALID(mp1_smnif_tlb_vf42) \
      ((mp1_smnif_tlb_vf42 & MP1_SMNIF_TLB_VF42_VALID_MASK) >> MP1_SMNIF_TLB_VF42_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF42_SET_VFID(mp1_smnif_tlb_vf42_reg, vfid) \
      mp1_smnif_tlb_vf42_reg = (mp1_smnif_tlb_vf42_reg & ~MP1_SMNIF_TLB_VF42_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF42_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF42_SET_VF(mp1_smnif_tlb_vf42_reg, vf) \
      mp1_smnif_tlb_vf42_reg = (mp1_smnif_tlb_vf42_reg & ~MP1_SMNIF_TLB_VF42_VF_MASK) | (vf << MP1_SMNIF_TLB_VF42_VF_SHIFT)
#define MP1_SMNIF_TLB_VF42_SET_VALID(mp1_smnif_tlb_vf42_reg, valid) \
      mp1_smnif_tlb_vf42_reg = (mp1_smnif_tlb_vf42_reg & ~MP1_SMNIF_TLB_VF42_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF42_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf42_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF42_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF42_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF42_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf42_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf42_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF42_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF42_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF42_VFID_SIZE;
      } mp1_smnif_tlb_vf42_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf42_t f;
} mp1_smnif_tlb_vf42_u;


/*
 * MP1_SMNIF_TLB_VF43 struct
 */

#define MP1_SMNIF_TLB_VF43_REG_SIZE         32
#define MP1_SMNIF_TLB_VF43_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF43_VF_SIZE  1
#define MP1_SMNIF_TLB_VF43_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF43_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF43_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF43_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF43_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF43_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF43_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF43_MASK \
      (MP1_SMNIF_TLB_VF43_VFID_MASK | \
      MP1_SMNIF_TLB_VF43_VF_MASK | \
      MP1_SMNIF_TLB_VF43_VALID_MASK)

#define MP1_SMNIF_TLB_VF43_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF43_GET_VFID(mp1_smnif_tlb_vf43) \
      ((mp1_smnif_tlb_vf43 & MP1_SMNIF_TLB_VF43_VFID_MASK) >> MP1_SMNIF_TLB_VF43_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF43_GET_VF(mp1_smnif_tlb_vf43) \
      ((mp1_smnif_tlb_vf43 & MP1_SMNIF_TLB_VF43_VF_MASK) >> MP1_SMNIF_TLB_VF43_VF_SHIFT)
#define MP1_SMNIF_TLB_VF43_GET_VALID(mp1_smnif_tlb_vf43) \
      ((mp1_smnif_tlb_vf43 & MP1_SMNIF_TLB_VF43_VALID_MASK) >> MP1_SMNIF_TLB_VF43_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF43_SET_VFID(mp1_smnif_tlb_vf43_reg, vfid) \
      mp1_smnif_tlb_vf43_reg = (mp1_smnif_tlb_vf43_reg & ~MP1_SMNIF_TLB_VF43_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF43_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF43_SET_VF(mp1_smnif_tlb_vf43_reg, vf) \
      mp1_smnif_tlb_vf43_reg = (mp1_smnif_tlb_vf43_reg & ~MP1_SMNIF_TLB_VF43_VF_MASK) | (vf << MP1_SMNIF_TLB_VF43_VF_SHIFT)
#define MP1_SMNIF_TLB_VF43_SET_VALID(mp1_smnif_tlb_vf43_reg, valid) \
      mp1_smnif_tlb_vf43_reg = (mp1_smnif_tlb_vf43_reg & ~MP1_SMNIF_TLB_VF43_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF43_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf43_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF43_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF43_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF43_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf43_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf43_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF43_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF43_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF43_VFID_SIZE;
      } mp1_smnif_tlb_vf43_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf43_t f;
} mp1_smnif_tlb_vf43_u;


/*
 * MP1_SMNIF_TLB_VF44 struct
 */

#define MP1_SMNIF_TLB_VF44_REG_SIZE         32
#define MP1_SMNIF_TLB_VF44_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF44_VF_SIZE  1
#define MP1_SMNIF_TLB_VF44_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF44_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF44_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF44_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF44_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF44_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF44_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF44_MASK \
      (MP1_SMNIF_TLB_VF44_VFID_MASK | \
      MP1_SMNIF_TLB_VF44_VF_MASK | \
      MP1_SMNIF_TLB_VF44_VALID_MASK)

#define MP1_SMNIF_TLB_VF44_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF44_GET_VFID(mp1_smnif_tlb_vf44) \
      ((mp1_smnif_tlb_vf44 & MP1_SMNIF_TLB_VF44_VFID_MASK) >> MP1_SMNIF_TLB_VF44_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF44_GET_VF(mp1_smnif_tlb_vf44) \
      ((mp1_smnif_tlb_vf44 & MP1_SMNIF_TLB_VF44_VF_MASK) >> MP1_SMNIF_TLB_VF44_VF_SHIFT)
#define MP1_SMNIF_TLB_VF44_GET_VALID(mp1_smnif_tlb_vf44) \
      ((mp1_smnif_tlb_vf44 & MP1_SMNIF_TLB_VF44_VALID_MASK) >> MP1_SMNIF_TLB_VF44_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF44_SET_VFID(mp1_smnif_tlb_vf44_reg, vfid) \
      mp1_smnif_tlb_vf44_reg = (mp1_smnif_tlb_vf44_reg & ~MP1_SMNIF_TLB_VF44_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF44_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF44_SET_VF(mp1_smnif_tlb_vf44_reg, vf) \
      mp1_smnif_tlb_vf44_reg = (mp1_smnif_tlb_vf44_reg & ~MP1_SMNIF_TLB_VF44_VF_MASK) | (vf << MP1_SMNIF_TLB_VF44_VF_SHIFT)
#define MP1_SMNIF_TLB_VF44_SET_VALID(mp1_smnif_tlb_vf44_reg, valid) \
      mp1_smnif_tlb_vf44_reg = (mp1_smnif_tlb_vf44_reg & ~MP1_SMNIF_TLB_VF44_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF44_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf44_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF44_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF44_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF44_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf44_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf44_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF44_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF44_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF44_VFID_SIZE;
      } mp1_smnif_tlb_vf44_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf44_t f;
} mp1_smnif_tlb_vf44_u;


/*
 * MP1_SMNIF_TLB_VF45 struct
 */

#define MP1_SMNIF_TLB_VF45_REG_SIZE         32
#define MP1_SMNIF_TLB_VF45_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF45_VF_SIZE  1
#define MP1_SMNIF_TLB_VF45_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF45_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF45_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF45_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF45_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF45_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF45_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF45_MASK \
      (MP1_SMNIF_TLB_VF45_VFID_MASK | \
      MP1_SMNIF_TLB_VF45_VF_MASK | \
      MP1_SMNIF_TLB_VF45_VALID_MASK)

#define MP1_SMNIF_TLB_VF45_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF45_GET_VFID(mp1_smnif_tlb_vf45) \
      ((mp1_smnif_tlb_vf45 & MP1_SMNIF_TLB_VF45_VFID_MASK) >> MP1_SMNIF_TLB_VF45_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF45_GET_VF(mp1_smnif_tlb_vf45) \
      ((mp1_smnif_tlb_vf45 & MP1_SMNIF_TLB_VF45_VF_MASK) >> MP1_SMNIF_TLB_VF45_VF_SHIFT)
#define MP1_SMNIF_TLB_VF45_GET_VALID(mp1_smnif_tlb_vf45) \
      ((mp1_smnif_tlb_vf45 & MP1_SMNIF_TLB_VF45_VALID_MASK) >> MP1_SMNIF_TLB_VF45_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF45_SET_VFID(mp1_smnif_tlb_vf45_reg, vfid) \
      mp1_smnif_tlb_vf45_reg = (mp1_smnif_tlb_vf45_reg & ~MP1_SMNIF_TLB_VF45_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF45_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF45_SET_VF(mp1_smnif_tlb_vf45_reg, vf) \
      mp1_smnif_tlb_vf45_reg = (mp1_smnif_tlb_vf45_reg & ~MP1_SMNIF_TLB_VF45_VF_MASK) | (vf << MP1_SMNIF_TLB_VF45_VF_SHIFT)
#define MP1_SMNIF_TLB_VF45_SET_VALID(mp1_smnif_tlb_vf45_reg, valid) \
      mp1_smnif_tlb_vf45_reg = (mp1_smnif_tlb_vf45_reg & ~MP1_SMNIF_TLB_VF45_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF45_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf45_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF45_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF45_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF45_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf45_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf45_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF45_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF45_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF45_VFID_SIZE;
      } mp1_smnif_tlb_vf45_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf45_t f;
} mp1_smnif_tlb_vf45_u;


/*
 * MP1_SMNIF_TLB_VF46 struct
 */

#define MP1_SMNIF_TLB_VF46_REG_SIZE         32
#define MP1_SMNIF_TLB_VF46_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF46_VF_SIZE  1
#define MP1_SMNIF_TLB_VF46_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF46_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF46_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF46_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF46_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF46_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF46_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF46_MASK \
      (MP1_SMNIF_TLB_VF46_VFID_MASK | \
      MP1_SMNIF_TLB_VF46_VF_MASK | \
      MP1_SMNIF_TLB_VF46_VALID_MASK)

#define MP1_SMNIF_TLB_VF46_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF46_GET_VFID(mp1_smnif_tlb_vf46) \
      ((mp1_smnif_tlb_vf46 & MP1_SMNIF_TLB_VF46_VFID_MASK) >> MP1_SMNIF_TLB_VF46_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF46_GET_VF(mp1_smnif_tlb_vf46) \
      ((mp1_smnif_tlb_vf46 & MP1_SMNIF_TLB_VF46_VF_MASK) >> MP1_SMNIF_TLB_VF46_VF_SHIFT)
#define MP1_SMNIF_TLB_VF46_GET_VALID(mp1_smnif_tlb_vf46) \
      ((mp1_smnif_tlb_vf46 & MP1_SMNIF_TLB_VF46_VALID_MASK) >> MP1_SMNIF_TLB_VF46_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF46_SET_VFID(mp1_smnif_tlb_vf46_reg, vfid) \
      mp1_smnif_tlb_vf46_reg = (mp1_smnif_tlb_vf46_reg & ~MP1_SMNIF_TLB_VF46_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF46_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF46_SET_VF(mp1_smnif_tlb_vf46_reg, vf) \
      mp1_smnif_tlb_vf46_reg = (mp1_smnif_tlb_vf46_reg & ~MP1_SMNIF_TLB_VF46_VF_MASK) | (vf << MP1_SMNIF_TLB_VF46_VF_SHIFT)
#define MP1_SMNIF_TLB_VF46_SET_VALID(mp1_smnif_tlb_vf46_reg, valid) \
      mp1_smnif_tlb_vf46_reg = (mp1_smnif_tlb_vf46_reg & ~MP1_SMNIF_TLB_VF46_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF46_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf46_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF46_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF46_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF46_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf46_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf46_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF46_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF46_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF46_VFID_SIZE;
      } mp1_smnif_tlb_vf46_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf46_t f;
} mp1_smnif_tlb_vf46_u;


/*
 * MP1_SMNIF_TLB_VF47 struct
 */

#define MP1_SMNIF_TLB_VF47_REG_SIZE         32
#define MP1_SMNIF_TLB_VF47_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF47_VF_SIZE  1
#define MP1_SMNIF_TLB_VF47_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF47_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF47_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF47_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF47_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF47_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF47_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF47_MASK \
      (MP1_SMNIF_TLB_VF47_VFID_MASK | \
      MP1_SMNIF_TLB_VF47_VF_MASK | \
      MP1_SMNIF_TLB_VF47_VALID_MASK)

#define MP1_SMNIF_TLB_VF47_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF47_GET_VFID(mp1_smnif_tlb_vf47) \
      ((mp1_smnif_tlb_vf47 & MP1_SMNIF_TLB_VF47_VFID_MASK) >> MP1_SMNIF_TLB_VF47_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF47_GET_VF(mp1_smnif_tlb_vf47) \
      ((mp1_smnif_tlb_vf47 & MP1_SMNIF_TLB_VF47_VF_MASK) >> MP1_SMNIF_TLB_VF47_VF_SHIFT)
#define MP1_SMNIF_TLB_VF47_GET_VALID(mp1_smnif_tlb_vf47) \
      ((mp1_smnif_tlb_vf47 & MP1_SMNIF_TLB_VF47_VALID_MASK) >> MP1_SMNIF_TLB_VF47_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF47_SET_VFID(mp1_smnif_tlb_vf47_reg, vfid) \
      mp1_smnif_tlb_vf47_reg = (mp1_smnif_tlb_vf47_reg & ~MP1_SMNIF_TLB_VF47_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF47_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF47_SET_VF(mp1_smnif_tlb_vf47_reg, vf) \
      mp1_smnif_tlb_vf47_reg = (mp1_smnif_tlb_vf47_reg & ~MP1_SMNIF_TLB_VF47_VF_MASK) | (vf << MP1_SMNIF_TLB_VF47_VF_SHIFT)
#define MP1_SMNIF_TLB_VF47_SET_VALID(mp1_smnif_tlb_vf47_reg, valid) \
      mp1_smnif_tlb_vf47_reg = (mp1_smnif_tlb_vf47_reg & ~MP1_SMNIF_TLB_VF47_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF47_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf47_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF47_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF47_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF47_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf47_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf47_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF47_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF47_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF47_VFID_SIZE;
      } mp1_smnif_tlb_vf47_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf47_t f;
} mp1_smnif_tlb_vf47_u;


/*
 * MP1_SMNIF_TLB_VF48 struct
 */

#define MP1_SMNIF_TLB_VF48_REG_SIZE         32
#define MP1_SMNIF_TLB_VF48_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF48_VF_SIZE  1
#define MP1_SMNIF_TLB_VF48_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF48_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF48_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF48_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF48_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF48_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF48_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF48_MASK \
      (MP1_SMNIF_TLB_VF48_VFID_MASK | \
      MP1_SMNIF_TLB_VF48_VF_MASK | \
      MP1_SMNIF_TLB_VF48_VALID_MASK)

#define MP1_SMNIF_TLB_VF48_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF48_GET_VFID(mp1_smnif_tlb_vf48) \
      ((mp1_smnif_tlb_vf48 & MP1_SMNIF_TLB_VF48_VFID_MASK) >> MP1_SMNIF_TLB_VF48_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF48_GET_VF(mp1_smnif_tlb_vf48) \
      ((mp1_smnif_tlb_vf48 & MP1_SMNIF_TLB_VF48_VF_MASK) >> MP1_SMNIF_TLB_VF48_VF_SHIFT)
#define MP1_SMNIF_TLB_VF48_GET_VALID(mp1_smnif_tlb_vf48) \
      ((mp1_smnif_tlb_vf48 & MP1_SMNIF_TLB_VF48_VALID_MASK) >> MP1_SMNIF_TLB_VF48_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF48_SET_VFID(mp1_smnif_tlb_vf48_reg, vfid) \
      mp1_smnif_tlb_vf48_reg = (mp1_smnif_tlb_vf48_reg & ~MP1_SMNIF_TLB_VF48_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF48_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF48_SET_VF(mp1_smnif_tlb_vf48_reg, vf) \
      mp1_smnif_tlb_vf48_reg = (mp1_smnif_tlb_vf48_reg & ~MP1_SMNIF_TLB_VF48_VF_MASK) | (vf << MP1_SMNIF_TLB_VF48_VF_SHIFT)
#define MP1_SMNIF_TLB_VF48_SET_VALID(mp1_smnif_tlb_vf48_reg, valid) \
      mp1_smnif_tlb_vf48_reg = (mp1_smnif_tlb_vf48_reg & ~MP1_SMNIF_TLB_VF48_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF48_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf48_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF48_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF48_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF48_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf48_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf48_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF48_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF48_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF48_VFID_SIZE;
      } mp1_smnif_tlb_vf48_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf48_t f;
} mp1_smnif_tlb_vf48_u;


/*
 * MP1_SMNIF_TLB_VF49 struct
 */

#define MP1_SMNIF_TLB_VF49_REG_SIZE         32
#define MP1_SMNIF_TLB_VF49_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF49_VF_SIZE  1
#define MP1_SMNIF_TLB_VF49_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF49_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF49_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF49_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF49_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF49_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF49_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF49_MASK \
      (MP1_SMNIF_TLB_VF49_VFID_MASK | \
      MP1_SMNIF_TLB_VF49_VF_MASK | \
      MP1_SMNIF_TLB_VF49_VALID_MASK)

#define MP1_SMNIF_TLB_VF49_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF49_GET_VFID(mp1_smnif_tlb_vf49) \
      ((mp1_smnif_tlb_vf49 & MP1_SMNIF_TLB_VF49_VFID_MASK) >> MP1_SMNIF_TLB_VF49_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF49_GET_VF(mp1_smnif_tlb_vf49) \
      ((mp1_smnif_tlb_vf49 & MP1_SMNIF_TLB_VF49_VF_MASK) >> MP1_SMNIF_TLB_VF49_VF_SHIFT)
#define MP1_SMNIF_TLB_VF49_GET_VALID(mp1_smnif_tlb_vf49) \
      ((mp1_smnif_tlb_vf49 & MP1_SMNIF_TLB_VF49_VALID_MASK) >> MP1_SMNIF_TLB_VF49_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF49_SET_VFID(mp1_smnif_tlb_vf49_reg, vfid) \
      mp1_smnif_tlb_vf49_reg = (mp1_smnif_tlb_vf49_reg & ~MP1_SMNIF_TLB_VF49_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF49_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF49_SET_VF(mp1_smnif_tlb_vf49_reg, vf) \
      mp1_smnif_tlb_vf49_reg = (mp1_smnif_tlb_vf49_reg & ~MP1_SMNIF_TLB_VF49_VF_MASK) | (vf << MP1_SMNIF_TLB_VF49_VF_SHIFT)
#define MP1_SMNIF_TLB_VF49_SET_VALID(mp1_smnif_tlb_vf49_reg, valid) \
      mp1_smnif_tlb_vf49_reg = (mp1_smnif_tlb_vf49_reg & ~MP1_SMNIF_TLB_VF49_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF49_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf49_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF49_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF49_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF49_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf49_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf49_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF49_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF49_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF49_VFID_SIZE;
      } mp1_smnif_tlb_vf49_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf49_t f;
} mp1_smnif_tlb_vf49_u;


/*
 * MP1_SMNIF_TLB_VF50 struct
 */

#define MP1_SMNIF_TLB_VF50_REG_SIZE         32
#define MP1_SMNIF_TLB_VF50_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF50_VF_SIZE  1
#define MP1_SMNIF_TLB_VF50_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF50_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF50_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF50_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF50_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF50_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF50_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF50_MASK \
      (MP1_SMNIF_TLB_VF50_VFID_MASK | \
      MP1_SMNIF_TLB_VF50_VF_MASK | \
      MP1_SMNIF_TLB_VF50_VALID_MASK)

#define MP1_SMNIF_TLB_VF50_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF50_GET_VFID(mp1_smnif_tlb_vf50) \
      ((mp1_smnif_tlb_vf50 & MP1_SMNIF_TLB_VF50_VFID_MASK) >> MP1_SMNIF_TLB_VF50_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF50_GET_VF(mp1_smnif_tlb_vf50) \
      ((mp1_smnif_tlb_vf50 & MP1_SMNIF_TLB_VF50_VF_MASK) >> MP1_SMNIF_TLB_VF50_VF_SHIFT)
#define MP1_SMNIF_TLB_VF50_GET_VALID(mp1_smnif_tlb_vf50) \
      ((mp1_smnif_tlb_vf50 & MP1_SMNIF_TLB_VF50_VALID_MASK) >> MP1_SMNIF_TLB_VF50_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF50_SET_VFID(mp1_smnif_tlb_vf50_reg, vfid) \
      mp1_smnif_tlb_vf50_reg = (mp1_smnif_tlb_vf50_reg & ~MP1_SMNIF_TLB_VF50_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF50_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF50_SET_VF(mp1_smnif_tlb_vf50_reg, vf) \
      mp1_smnif_tlb_vf50_reg = (mp1_smnif_tlb_vf50_reg & ~MP1_SMNIF_TLB_VF50_VF_MASK) | (vf << MP1_SMNIF_TLB_VF50_VF_SHIFT)
#define MP1_SMNIF_TLB_VF50_SET_VALID(mp1_smnif_tlb_vf50_reg, valid) \
      mp1_smnif_tlb_vf50_reg = (mp1_smnif_tlb_vf50_reg & ~MP1_SMNIF_TLB_VF50_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF50_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf50_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF50_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF50_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF50_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf50_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf50_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF50_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF50_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF50_VFID_SIZE;
      } mp1_smnif_tlb_vf50_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf50_t f;
} mp1_smnif_tlb_vf50_u;


/*
 * MP1_SMNIF_TLB_VF51 struct
 */

#define MP1_SMNIF_TLB_VF51_REG_SIZE         32
#define MP1_SMNIF_TLB_VF51_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF51_VF_SIZE  1
#define MP1_SMNIF_TLB_VF51_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF51_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF51_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF51_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF51_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF51_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF51_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF51_MASK \
      (MP1_SMNIF_TLB_VF51_VFID_MASK | \
      MP1_SMNIF_TLB_VF51_VF_MASK | \
      MP1_SMNIF_TLB_VF51_VALID_MASK)

#define MP1_SMNIF_TLB_VF51_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF51_GET_VFID(mp1_smnif_tlb_vf51) \
      ((mp1_smnif_tlb_vf51 & MP1_SMNIF_TLB_VF51_VFID_MASK) >> MP1_SMNIF_TLB_VF51_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF51_GET_VF(mp1_smnif_tlb_vf51) \
      ((mp1_smnif_tlb_vf51 & MP1_SMNIF_TLB_VF51_VF_MASK) >> MP1_SMNIF_TLB_VF51_VF_SHIFT)
#define MP1_SMNIF_TLB_VF51_GET_VALID(mp1_smnif_tlb_vf51) \
      ((mp1_smnif_tlb_vf51 & MP1_SMNIF_TLB_VF51_VALID_MASK) >> MP1_SMNIF_TLB_VF51_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF51_SET_VFID(mp1_smnif_tlb_vf51_reg, vfid) \
      mp1_smnif_tlb_vf51_reg = (mp1_smnif_tlb_vf51_reg & ~MP1_SMNIF_TLB_VF51_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF51_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF51_SET_VF(mp1_smnif_tlb_vf51_reg, vf) \
      mp1_smnif_tlb_vf51_reg = (mp1_smnif_tlb_vf51_reg & ~MP1_SMNIF_TLB_VF51_VF_MASK) | (vf << MP1_SMNIF_TLB_VF51_VF_SHIFT)
#define MP1_SMNIF_TLB_VF51_SET_VALID(mp1_smnif_tlb_vf51_reg, valid) \
      mp1_smnif_tlb_vf51_reg = (mp1_smnif_tlb_vf51_reg & ~MP1_SMNIF_TLB_VF51_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF51_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf51_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF51_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF51_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF51_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf51_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf51_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF51_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF51_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF51_VFID_SIZE;
      } mp1_smnif_tlb_vf51_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf51_t f;
} mp1_smnif_tlb_vf51_u;


/*
 * MP1_SMNIF_TLB_VF52 struct
 */

#define MP1_SMNIF_TLB_VF52_REG_SIZE         32
#define MP1_SMNIF_TLB_VF52_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF52_VF_SIZE  1
#define MP1_SMNIF_TLB_VF52_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF52_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF52_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF52_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF52_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF52_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF52_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF52_MASK \
      (MP1_SMNIF_TLB_VF52_VFID_MASK | \
      MP1_SMNIF_TLB_VF52_VF_MASK | \
      MP1_SMNIF_TLB_VF52_VALID_MASK)

#define MP1_SMNIF_TLB_VF52_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF52_GET_VFID(mp1_smnif_tlb_vf52) \
      ((mp1_smnif_tlb_vf52 & MP1_SMNIF_TLB_VF52_VFID_MASK) >> MP1_SMNIF_TLB_VF52_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF52_GET_VF(mp1_smnif_tlb_vf52) \
      ((mp1_smnif_tlb_vf52 & MP1_SMNIF_TLB_VF52_VF_MASK) >> MP1_SMNIF_TLB_VF52_VF_SHIFT)
#define MP1_SMNIF_TLB_VF52_GET_VALID(mp1_smnif_tlb_vf52) \
      ((mp1_smnif_tlb_vf52 & MP1_SMNIF_TLB_VF52_VALID_MASK) >> MP1_SMNIF_TLB_VF52_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF52_SET_VFID(mp1_smnif_tlb_vf52_reg, vfid) \
      mp1_smnif_tlb_vf52_reg = (mp1_smnif_tlb_vf52_reg & ~MP1_SMNIF_TLB_VF52_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF52_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF52_SET_VF(mp1_smnif_tlb_vf52_reg, vf) \
      mp1_smnif_tlb_vf52_reg = (mp1_smnif_tlb_vf52_reg & ~MP1_SMNIF_TLB_VF52_VF_MASK) | (vf << MP1_SMNIF_TLB_VF52_VF_SHIFT)
#define MP1_SMNIF_TLB_VF52_SET_VALID(mp1_smnif_tlb_vf52_reg, valid) \
      mp1_smnif_tlb_vf52_reg = (mp1_smnif_tlb_vf52_reg & ~MP1_SMNIF_TLB_VF52_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF52_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf52_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF52_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF52_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF52_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf52_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf52_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF52_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF52_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF52_VFID_SIZE;
      } mp1_smnif_tlb_vf52_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf52_t f;
} mp1_smnif_tlb_vf52_u;


/*
 * MP1_SMNIF_TLB_VF53 struct
 */

#define MP1_SMNIF_TLB_VF53_REG_SIZE         32
#define MP1_SMNIF_TLB_VF53_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF53_VF_SIZE  1
#define MP1_SMNIF_TLB_VF53_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF53_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF53_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF53_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF53_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF53_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF53_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF53_MASK \
      (MP1_SMNIF_TLB_VF53_VFID_MASK | \
      MP1_SMNIF_TLB_VF53_VF_MASK | \
      MP1_SMNIF_TLB_VF53_VALID_MASK)

#define MP1_SMNIF_TLB_VF53_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF53_GET_VFID(mp1_smnif_tlb_vf53) \
      ((mp1_smnif_tlb_vf53 & MP1_SMNIF_TLB_VF53_VFID_MASK) >> MP1_SMNIF_TLB_VF53_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF53_GET_VF(mp1_smnif_tlb_vf53) \
      ((mp1_smnif_tlb_vf53 & MP1_SMNIF_TLB_VF53_VF_MASK) >> MP1_SMNIF_TLB_VF53_VF_SHIFT)
#define MP1_SMNIF_TLB_VF53_GET_VALID(mp1_smnif_tlb_vf53) \
      ((mp1_smnif_tlb_vf53 & MP1_SMNIF_TLB_VF53_VALID_MASK) >> MP1_SMNIF_TLB_VF53_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF53_SET_VFID(mp1_smnif_tlb_vf53_reg, vfid) \
      mp1_smnif_tlb_vf53_reg = (mp1_smnif_tlb_vf53_reg & ~MP1_SMNIF_TLB_VF53_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF53_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF53_SET_VF(mp1_smnif_tlb_vf53_reg, vf) \
      mp1_smnif_tlb_vf53_reg = (mp1_smnif_tlb_vf53_reg & ~MP1_SMNIF_TLB_VF53_VF_MASK) | (vf << MP1_SMNIF_TLB_VF53_VF_SHIFT)
#define MP1_SMNIF_TLB_VF53_SET_VALID(mp1_smnif_tlb_vf53_reg, valid) \
      mp1_smnif_tlb_vf53_reg = (mp1_smnif_tlb_vf53_reg & ~MP1_SMNIF_TLB_VF53_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF53_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf53_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF53_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF53_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF53_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf53_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf53_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF53_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF53_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF53_VFID_SIZE;
      } mp1_smnif_tlb_vf53_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf53_t f;
} mp1_smnif_tlb_vf53_u;


/*
 * MP1_SMNIF_TLB_VF54 struct
 */

#define MP1_SMNIF_TLB_VF54_REG_SIZE         32
#define MP1_SMNIF_TLB_VF54_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF54_VF_SIZE  1
#define MP1_SMNIF_TLB_VF54_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF54_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF54_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF54_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF54_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF54_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF54_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF54_MASK \
      (MP1_SMNIF_TLB_VF54_VFID_MASK | \
      MP1_SMNIF_TLB_VF54_VF_MASK | \
      MP1_SMNIF_TLB_VF54_VALID_MASK)

#define MP1_SMNIF_TLB_VF54_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF54_GET_VFID(mp1_smnif_tlb_vf54) \
      ((mp1_smnif_tlb_vf54 & MP1_SMNIF_TLB_VF54_VFID_MASK) >> MP1_SMNIF_TLB_VF54_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF54_GET_VF(mp1_smnif_tlb_vf54) \
      ((mp1_smnif_tlb_vf54 & MP1_SMNIF_TLB_VF54_VF_MASK) >> MP1_SMNIF_TLB_VF54_VF_SHIFT)
#define MP1_SMNIF_TLB_VF54_GET_VALID(mp1_smnif_tlb_vf54) \
      ((mp1_smnif_tlb_vf54 & MP1_SMNIF_TLB_VF54_VALID_MASK) >> MP1_SMNIF_TLB_VF54_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF54_SET_VFID(mp1_smnif_tlb_vf54_reg, vfid) \
      mp1_smnif_tlb_vf54_reg = (mp1_smnif_tlb_vf54_reg & ~MP1_SMNIF_TLB_VF54_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF54_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF54_SET_VF(mp1_smnif_tlb_vf54_reg, vf) \
      mp1_smnif_tlb_vf54_reg = (mp1_smnif_tlb_vf54_reg & ~MP1_SMNIF_TLB_VF54_VF_MASK) | (vf << MP1_SMNIF_TLB_VF54_VF_SHIFT)
#define MP1_SMNIF_TLB_VF54_SET_VALID(mp1_smnif_tlb_vf54_reg, valid) \
      mp1_smnif_tlb_vf54_reg = (mp1_smnif_tlb_vf54_reg & ~MP1_SMNIF_TLB_VF54_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF54_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf54_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF54_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF54_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF54_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf54_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf54_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF54_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF54_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF54_VFID_SIZE;
      } mp1_smnif_tlb_vf54_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf54_t f;
} mp1_smnif_tlb_vf54_u;


/*
 * MP1_SMNIF_TLB_VF55 struct
 */

#define MP1_SMNIF_TLB_VF55_REG_SIZE         32
#define MP1_SMNIF_TLB_VF55_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF55_VF_SIZE  1
#define MP1_SMNIF_TLB_VF55_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF55_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF55_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF55_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF55_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF55_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF55_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF55_MASK \
      (MP1_SMNIF_TLB_VF55_VFID_MASK | \
      MP1_SMNIF_TLB_VF55_VF_MASK | \
      MP1_SMNIF_TLB_VF55_VALID_MASK)

#define MP1_SMNIF_TLB_VF55_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF55_GET_VFID(mp1_smnif_tlb_vf55) \
      ((mp1_smnif_tlb_vf55 & MP1_SMNIF_TLB_VF55_VFID_MASK) >> MP1_SMNIF_TLB_VF55_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF55_GET_VF(mp1_smnif_tlb_vf55) \
      ((mp1_smnif_tlb_vf55 & MP1_SMNIF_TLB_VF55_VF_MASK) >> MP1_SMNIF_TLB_VF55_VF_SHIFT)
#define MP1_SMNIF_TLB_VF55_GET_VALID(mp1_smnif_tlb_vf55) \
      ((mp1_smnif_tlb_vf55 & MP1_SMNIF_TLB_VF55_VALID_MASK) >> MP1_SMNIF_TLB_VF55_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF55_SET_VFID(mp1_smnif_tlb_vf55_reg, vfid) \
      mp1_smnif_tlb_vf55_reg = (mp1_smnif_tlb_vf55_reg & ~MP1_SMNIF_TLB_VF55_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF55_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF55_SET_VF(mp1_smnif_tlb_vf55_reg, vf) \
      mp1_smnif_tlb_vf55_reg = (mp1_smnif_tlb_vf55_reg & ~MP1_SMNIF_TLB_VF55_VF_MASK) | (vf << MP1_SMNIF_TLB_VF55_VF_SHIFT)
#define MP1_SMNIF_TLB_VF55_SET_VALID(mp1_smnif_tlb_vf55_reg, valid) \
      mp1_smnif_tlb_vf55_reg = (mp1_smnif_tlb_vf55_reg & ~MP1_SMNIF_TLB_VF55_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF55_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf55_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF55_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF55_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF55_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf55_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf55_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF55_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF55_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF55_VFID_SIZE;
      } mp1_smnif_tlb_vf55_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf55_t f;
} mp1_smnif_tlb_vf55_u;


/*
 * MP1_SMNIF_TLB_VF56 struct
 */

#define MP1_SMNIF_TLB_VF56_REG_SIZE         32
#define MP1_SMNIF_TLB_VF56_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF56_VF_SIZE  1
#define MP1_SMNIF_TLB_VF56_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF56_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF56_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF56_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF56_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF56_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF56_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF56_MASK \
      (MP1_SMNIF_TLB_VF56_VFID_MASK | \
      MP1_SMNIF_TLB_VF56_VF_MASK | \
      MP1_SMNIF_TLB_VF56_VALID_MASK)

#define MP1_SMNIF_TLB_VF56_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF56_GET_VFID(mp1_smnif_tlb_vf56) \
      ((mp1_smnif_tlb_vf56 & MP1_SMNIF_TLB_VF56_VFID_MASK) >> MP1_SMNIF_TLB_VF56_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF56_GET_VF(mp1_smnif_tlb_vf56) \
      ((mp1_smnif_tlb_vf56 & MP1_SMNIF_TLB_VF56_VF_MASK) >> MP1_SMNIF_TLB_VF56_VF_SHIFT)
#define MP1_SMNIF_TLB_VF56_GET_VALID(mp1_smnif_tlb_vf56) \
      ((mp1_smnif_tlb_vf56 & MP1_SMNIF_TLB_VF56_VALID_MASK) >> MP1_SMNIF_TLB_VF56_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF56_SET_VFID(mp1_smnif_tlb_vf56_reg, vfid) \
      mp1_smnif_tlb_vf56_reg = (mp1_smnif_tlb_vf56_reg & ~MP1_SMNIF_TLB_VF56_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF56_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF56_SET_VF(mp1_smnif_tlb_vf56_reg, vf) \
      mp1_smnif_tlb_vf56_reg = (mp1_smnif_tlb_vf56_reg & ~MP1_SMNIF_TLB_VF56_VF_MASK) | (vf << MP1_SMNIF_TLB_VF56_VF_SHIFT)
#define MP1_SMNIF_TLB_VF56_SET_VALID(mp1_smnif_tlb_vf56_reg, valid) \
      mp1_smnif_tlb_vf56_reg = (mp1_smnif_tlb_vf56_reg & ~MP1_SMNIF_TLB_VF56_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF56_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf56_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF56_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF56_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF56_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf56_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf56_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF56_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF56_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF56_VFID_SIZE;
      } mp1_smnif_tlb_vf56_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf56_t f;
} mp1_smnif_tlb_vf56_u;


/*
 * MP1_SMNIF_TLB_VF57 struct
 */

#define MP1_SMNIF_TLB_VF57_REG_SIZE         32
#define MP1_SMNIF_TLB_VF57_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF57_VF_SIZE  1
#define MP1_SMNIF_TLB_VF57_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF57_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF57_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF57_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF57_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF57_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF57_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF57_MASK \
      (MP1_SMNIF_TLB_VF57_VFID_MASK | \
      MP1_SMNIF_TLB_VF57_VF_MASK | \
      MP1_SMNIF_TLB_VF57_VALID_MASK)

#define MP1_SMNIF_TLB_VF57_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF57_GET_VFID(mp1_smnif_tlb_vf57) \
      ((mp1_smnif_tlb_vf57 & MP1_SMNIF_TLB_VF57_VFID_MASK) >> MP1_SMNIF_TLB_VF57_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF57_GET_VF(mp1_smnif_tlb_vf57) \
      ((mp1_smnif_tlb_vf57 & MP1_SMNIF_TLB_VF57_VF_MASK) >> MP1_SMNIF_TLB_VF57_VF_SHIFT)
#define MP1_SMNIF_TLB_VF57_GET_VALID(mp1_smnif_tlb_vf57) \
      ((mp1_smnif_tlb_vf57 & MP1_SMNIF_TLB_VF57_VALID_MASK) >> MP1_SMNIF_TLB_VF57_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF57_SET_VFID(mp1_smnif_tlb_vf57_reg, vfid) \
      mp1_smnif_tlb_vf57_reg = (mp1_smnif_tlb_vf57_reg & ~MP1_SMNIF_TLB_VF57_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF57_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF57_SET_VF(mp1_smnif_tlb_vf57_reg, vf) \
      mp1_smnif_tlb_vf57_reg = (mp1_smnif_tlb_vf57_reg & ~MP1_SMNIF_TLB_VF57_VF_MASK) | (vf << MP1_SMNIF_TLB_VF57_VF_SHIFT)
#define MP1_SMNIF_TLB_VF57_SET_VALID(mp1_smnif_tlb_vf57_reg, valid) \
      mp1_smnif_tlb_vf57_reg = (mp1_smnif_tlb_vf57_reg & ~MP1_SMNIF_TLB_VF57_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF57_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf57_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF57_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF57_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF57_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf57_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf57_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF57_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF57_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF57_VFID_SIZE;
      } mp1_smnif_tlb_vf57_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf57_t f;
} mp1_smnif_tlb_vf57_u;


/*
 * MP1_SMNIF_TLB_VF58 struct
 */

#define MP1_SMNIF_TLB_VF58_REG_SIZE         32
#define MP1_SMNIF_TLB_VF58_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF58_VF_SIZE  1
#define MP1_SMNIF_TLB_VF58_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF58_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF58_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF58_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF58_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF58_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF58_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF58_MASK \
      (MP1_SMNIF_TLB_VF58_VFID_MASK | \
      MP1_SMNIF_TLB_VF58_VF_MASK | \
      MP1_SMNIF_TLB_VF58_VALID_MASK)

#define MP1_SMNIF_TLB_VF58_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF58_GET_VFID(mp1_smnif_tlb_vf58) \
      ((mp1_smnif_tlb_vf58 & MP1_SMNIF_TLB_VF58_VFID_MASK) >> MP1_SMNIF_TLB_VF58_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF58_GET_VF(mp1_smnif_tlb_vf58) \
      ((mp1_smnif_tlb_vf58 & MP1_SMNIF_TLB_VF58_VF_MASK) >> MP1_SMNIF_TLB_VF58_VF_SHIFT)
#define MP1_SMNIF_TLB_VF58_GET_VALID(mp1_smnif_tlb_vf58) \
      ((mp1_smnif_tlb_vf58 & MP1_SMNIF_TLB_VF58_VALID_MASK) >> MP1_SMNIF_TLB_VF58_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF58_SET_VFID(mp1_smnif_tlb_vf58_reg, vfid) \
      mp1_smnif_tlb_vf58_reg = (mp1_smnif_tlb_vf58_reg & ~MP1_SMNIF_TLB_VF58_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF58_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF58_SET_VF(mp1_smnif_tlb_vf58_reg, vf) \
      mp1_smnif_tlb_vf58_reg = (mp1_smnif_tlb_vf58_reg & ~MP1_SMNIF_TLB_VF58_VF_MASK) | (vf << MP1_SMNIF_TLB_VF58_VF_SHIFT)
#define MP1_SMNIF_TLB_VF58_SET_VALID(mp1_smnif_tlb_vf58_reg, valid) \
      mp1_smnif_tlb_vf58_reg = (mp1_smnif_tlb_vf58_reg & ~MP1_SMNIF_TLB_VF58_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF58_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf58_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF58_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF58_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF58_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf58_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf58_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF58_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF58_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF58_VFID_SIZE;
      } mp1_smnif_tlb_vf58_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf58_t f;
} mp1_smnif_tlb_vf58_u;


/*
 * MP1_SMNIF_TLB_VF59 struct
 */

#define MP1_SMNIF_TLB_VF59_REG_SIZE         32
#define MP1_SMNIF_TLB_VF59_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF59_VF_SIZE  1
#define MP1_SMNIF_TLB_VF59_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF59_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF59_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF59_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF59_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF59_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF59_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF59_MASK \
      (MP1_SMNIF_TLB_VF59_VFID_MASK | \
      MP1_SMNIF_TLB_VF59_VF_MASK | \
      MP1_SMNIF_TLB_VF59_VALID_MASK)

#define MP1_SMNIF_TLB_VF59_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF59_GET_VFID(mp1_smnif_tlb_vf59) \
      ((mp1_smnif_tlb_vf59 & MP1_SMNIF_TLB_VF59_VFID_MASK) >> MP1_SMNIF_TLB_VF59_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF59_GET_VF(mp1_smnif_tlb_vf59) \
      ((mp1_smnif_tlb_vf59 & MP1_SMNIF_TLB_VF59_VF_MASK) >> MP1_SMNIF_TLB_VF59_VF_SHIFT)
#define MP1_SMNIF_TLB_VF59_GET_VALID(mp1_smnif_tlb_vf59) \
      ((mp1_smnif_tlb_vf59 & MP1_SMNIF_TLB_VF59_VALID_MASK) >> MP1_SMNIF_TLB_VF59_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF59_SET_VFID(mp1_smnif_tlb_vf59_reg, vfid) \
      mp1_smnif_tlb_vf59_reg = (mp1_smnif_tlb_vf59_reg & ~MP1_SMNIF_TLB_VF59_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF59_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF59_SET_VF(mp1_smnif_tlb_vf59_reg, vf) \
      mp1_smnif_tlb_vf59_reg = (mp1_smnif_tlb_vf59_reg & ~MP1_SMNIF_TLB_VF59_VF_MASK) | (vf << MP1_SMNIF_TLB_VF59_VF_SHIFT)
#define MP1_SMNIF_TLB_VF59_SET_VALID(mp1_smnif_tlb_vf59_reg, valid) \
      mp1_smnif_tlb_vf59_reg = (mp1_smnif_tlb_vf59_reg & ~MP1_SMNIF_TLB_VF59_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF59_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf59_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF59_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF59_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF59_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf59_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf59_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF59_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF59_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF59_VFID_SIZE;
      } mp1_smnif_tlb_vf59_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf59_t f;
} mp1_smnif_tlb_vf59_u;


/*
 * MP1_SMNIF_TLB_VF60 struct
 */

#define MP1_SMNIF_TLB_VF60_REG_SIZE         32
#define MP1_SMNIF_TLB_VF60_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF60_VF_SIZE  1
#define MP1_SMNIF_TLB_VF60_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF60_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF60_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF60_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF60_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF60_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF60_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF60_MASK \
      (MP1_SMNIF_TLB_VF60_VFID_MASK | \
      MP1_SMNIF_TLB_VF60_VF_MASK | \
      MP1_SMNIF_TLB_VF60_VALID_MASK)

#define MP1_SMNIF_TLB_VF60_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF60_GET_VFID(mp1_smnif_tlb_vf60) \
      ((mp1_smnif_tlb_vf60 & MP1_SMNIF_TLB_VF60_VFID_MASK) >> MP1_SMNIF_TLB_VF60_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF60_GET_VF(mp1_smnif_tlb_vf60) \
      ((mp1_smnif_tlb_vf60 & MP1_SMNIF_TLB_VF60_VF_MASK) >> MP1_SMNIF_TLB_VF60_VF_SHIFT)
#define MP1_SMNIF_TLB_VF60_GET_VALID(mp1_smnif_tlb_vf60) \
      ((mp1_smnif_tlb_vf60 & MP1_SMNIF_TLB_VF60_VALID_MASK) >> MP1_SMNIF_TLB_VF60_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF60_SET_VFID(mp1_smnif_tlb_vf60_reg, vfid) \
      mp1_smnif_tlb_vf60_reg = (mp1_smnif_tlb_vf60_reg & ~MP1_SMNIF_TLB_VF60_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF60_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF60_SET_VF(mp1_smnif_tlb_vf60_reg, vf) \
      mp1_smnif_tlb_vf60_reg = (mp1_smnif_tlb_vf60_reg & ~MP1_SMNIF_TLB_VF60_VF_MASK) | (vf << MP1_SMNIF_TLB_VF60_VF_SHIFT)
#define MP1_SMNIF_TLB_VF60_SET_VALID(mp1_smnif_tlb_vf60_reg, valid) \
      mp1_smnif_tlb_vf60_reg = (mp1_smnif_tlb_vf60_reg & ~MP1_SMNIF_TLB_VF60_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF60_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf60_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF60_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF60_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF60_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf60_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf60_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF60_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF60_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF60_VFID_SIZE;
      } mp1_smnif_tlb_vf60_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf60_t f;
} mp1_smnif_tlb_vf60_u;


/*
 * MP1_SMNIF_TLB_VF61 struct
 */

#define MP1_SMNIF_TLB_VF61_REG_SIZE         32
#define MP1_SMNIF_TLB_VF61_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF61_VF_SIZE  1
#define MP1_SMNIF_TLB_VF61_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF61_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF61_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF61_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF61_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF61_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF61_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF61_MASK \
      (MP1_SMNIF_TLB_VF61_VFID_MASK | \
      MP1_SMNIF_TLB_VF61_VF_MASK | \
      MP1_SMNIF_TLB_VF61_VALID_MASK)

#define MP1_SMNIF_TLB_VF61_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF61_GET_VFID(mp1_smnif_tlb_vf61) \
      ((mp1_smnif_tlb_vf61 & MP1_SMNIF_TLB_VF61_VFID_MASK) >> MP1_SMNIF_TLB_VF61_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF61_GET_VF(mp1_smnif_tlb_vf61) \
      ((mp1_smnif_tlb_vf61 & MP1_SMNIF_TLB_VF61_VF_MASK) >> MP1_SMNIF_TLB_VF61_VF_SHIFT)
#define MP1_SMNIF_TLB_VF61_GET_VALID(mp1_smnif_tlb_vf61) \
      ((mp1_smnif_tlb_vf61 & MP1_SMNIF_TLB_VF61_VALID_MASK) >> MP1_SMNIF_TLB_VF61_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF61_SET_VFID(mp1_smnif_tlb_vf61_reg, vfid) \
      mp1_smnif_tlb_vf61_reg = (mp1_smnif_tlb_vf61_reg & ~MP1_SMNIF_TLB_VF61_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF61_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF61_SET_VF(mp1_smnif_tlb_vf61_reg, vf) \
      mp1_smnif_tlb_vf61_reg = (mp1_smnif_tlb_vf61_reg & ~MP1_SMNIF_TLB_VF61_VF_MASK) | (vf << MP1_SMNIF_TLB_VF61_VF_SHIFT)
#define MP1_SMNIF_TLB_VF61_SET_VALID(mp1_smnif_tlb_vf61_reg, valid) \
      mp1_smnif_tlb_vf61_reg = (mp1_smnif_tlb_vf61_reg & ~MP1_SMNIF_TLB_VF61_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF61_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf61_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF61_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF61_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF61_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf61_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf61_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF61_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF61_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF61_VFID_SIZE;
      } mp1_smnif_tlb_vf61_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf61_t f;
} mp1_smnif_tlb_vf61_u;


/*
 * MP1_SMNIF_TLB_VF62 struct
 */

#define MP1_SMNIF_TLB_VF62_REG_SIZE         32
#define MP1_SMNIF_TLB_VF62_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF62_VF_SIZE  1
#define MP1_SMNIF_TLB_VF62_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF62_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF62_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF62_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF62_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF62_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF62_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF62_MASK \
      (MP1_SMNIF_TLB_VF62_VFID_MASK | \
      MP1_SMNIF_TLB_VF62_VF_MASK | \
      MP1_SMNIF_TLB_VF62_VALID_MASK)

#define MP1_SMNIF_TLB_VF62_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF62_GET_VFID(mp1_smnif_tlb_vf62) \
      ((mp1_smnif_tlb_vf62 & MP1_SMNIF_TLB_VF62_VFID_MASK) >> MP1_SMNIF_TLB_VF62_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF62_GET_VF(mp1_smnif_tlb_vf62) \
      ((mp1_smnif_tlb_vf62 & MP1_SMNIF_TLB_VF62_VF_MASK) >> MP1_SMNIF_TLB_VF62_VF_SHIFT)
#define MP1_SMNIF_TLB_VF62_GET_VALID(mp1_smnif_tlb_vf62) \
      ((mp1_smnif_tlb_vf62 & MP1_SMNIF_TLB_VF62_VALID_MASK) >> MP1_SMNIF_TLB_VF62_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF62_SET_VFID(mp1_smnif_tlb_vf62_reg, vfid) \
      mp1_smnif_tlb_vf62_reg = (mp1_smnif_tlb_vf62_reg & ~MP1_SMNIF_TLB_VF62_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF62_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF62_SET_VF(mp1_smnif_tlb_vf62_reg, vf) \
      mp1_smnif_tlb_vf62_reg = (mp1_smnif_tlb_vf62_reg & ~MP1_SMNIF_TLB_VF62_VF_MASK) | (vf << MP1_SMNIF_TLB_VF62_VF_SHIFT)
#define MP1_SMNIF_TLB_VF62_SET_VALID(mp1_smnif_tlb_vf62_reg, valid) \
      mp1_smnif_tlb_vf62_reg = (mp1_smnif_tlb_vf62_reg & ~MP1_SMNIF_TLB_VF62_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF62_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf62_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF62_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF62_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF62_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf62_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf62_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF62_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF62_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF62_VFID_SIZE;
      } mp1_smnif_tlb_vf62_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf62_t f;
} mp1_smnif_tlb_vf62_u;


/*
 * MP1_SMNIF_TLB_VF63 struct
 */

#define MP1_SMNIF_TLB_VF63_REG_SIZE         32
#define MP1_SMNIF_TLB_VF63_VFID_SIZE  6
#define MP1_SMNIF_TLB_VF63_VF_SIZE  1
#define MP1_SMNIF_TLB_VF63_VALID_SIZE  1

#define MP1_SMNIF_TLB_VF63_VFID_SHIFT  0
#define MP1_SMNIF_TLB_VF63_VF_SHIFT  6
#define MP1_SMNIF_TLB_VF63_VALID_SHIFT  7

#define MP1_SMNIF_TLB_VF63_VFID_MASK    0x0000003f
#define MP1_SMNIF_TLB_VF63_VF_MASK      0x00000040
#define MP1_SMNIF_TLB_VF63_VALID_MASK   0x00000080

#define MP1_SMNIF_TLB_VF63_MASK \
      (MP1_SMNIF_TLB_VF63_VFID_MASK | \
      MP1_SMNIF_TLB_VF63_VF_MASK | \
      MP1_SMNIF_TLB_VF63_VALID_MASK)

#define MP1_SMNIF_TLB_VF63_DEFAULT     0x00000000

#define MP1_SMNIF_TLB_VF63_GET_VFID(mp1_smnif_tlb_vf63) \
      ((mp1_smnif_tlb_vf63 & MP1_SMNIF_TLB_VF63_VFID_MASK) >> MP1_SMNIF_TLB_VF63_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF63_GET_VF(mp1_smnif_tlb_vf63) \
      ((mp1_smnif_tlb_vf63 & MP1_SMNIF_TLB_VF63_VF_MASK) >> MP1_SMNIF_TLB_VF63_VF_SHIFT)
#define MP1_SMNIF_TLB_VF63_GET_VALID(mp1_smnif_tlb_vf63) \
      ((mp1_smnif_tlb_vf63 & MP1_SMNIF_TLB_VF63_VALID_MASK) >> MP1_SMNIF_TLB_VF63_VALID_SHIFT)

#define MP1_SMNIF_TLB_VF63_SET_VFID(mp1_smnif_tlb_vf63_reg, vfid) \
      mp1_smnif_tlb_vf63_reg = (mp1_smnif_tlb_vf63_reg & ~MP1_SMNIF_TLB_VF63_VFID_MASK) | (vfid << MP1_SMNIF_TLB_VF63_VFID_SHIFT)
#define MP1_SMNIF_TLB_VF63_SET_VF(mp1_smnif_tlb_vf63_reg, vf) \
      mp1_smnif_tlb_vf63_reg = (mp1_smnif_tlb_vf63_reg & ~MP1_SMNIF_TLB_VF63_VF_MASK) | (vf << MP1_SMNIF_TLB_VF63_VF_SHIFT)
#define MP1_SMNIF_TLB_VF63_SET_VALID(mp1_smnif_tlb_vf63_reg, valid) \
      mp1_smnif_tlb_vf63_reg = (mp1_smnif_tlb_vf63_reg & ~MP1_SMNIF_TLB_VF63_VALID_MASK) | (valid << MP1_SMNIF_TLB_VF63_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf63_t {
            unsigned int vfid                           : MP1_SMNIF_TLB_VF63_VFID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF63_VF_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLB_VF63_VALID_SIZE;
            unsigned int                                : 24;
      } mp1_smnif_tlb_vf63_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_vf63_t {
            unsigned int                                : 24;
            unsigned int valid                          : MP1_SMNIF_TLB_VF63_VALID_SIZE;
            unsigned int vf                             : MP1_SMNIF_TLB_VF63_VF_SIZE;
            unsigned int vfid                           : MP1_SMNIF_TLB_VF63_VFID_SIZE;
      } mp1_smnif_tlb_vf63_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_vf63_t f;
} mp1_smnif_tlb_vf63_u;


/*
 * MP1_SMNIF_TLB_QOS struct
 */

#define MP1_SMNIF_TLB_QOS_REG_SIZE         32
#define MP1_SMNIF_TLB_QOS_TLB_QOS_SIZE  32

#define MP1_SMNIF_TLB_QOS_TLB_QOS_SHIFT  0

#define MP1_SMNIF_TLB_QOS_TLB_QOS_MASK  0xffffffff

#define MP1_SMNIF_TLB_QOS_MASK \
      (MP1_SMNIF_TLB_QOS_TLB_QOS_MASK)

#define MP1_SMNIF_TLB_QOS_DEFAULT      0xffffffff

#define MP1_SMNIF_TLB_QOS_GET_TLB_QOS(mp1_smnif_tlb_qos) \
      ((mp1_smnif_tlb_qos & MP1_SMNIF_TLB_QOS_TLB_QOS_MASK) >> MP1_SMNIF_TLB_QOS_TLB_QOS_SHIFT)

#define MP1_SMNIF_TLB_QOS_SET_TLB_QOS(mp1_smnif_tlb_qos_reg, tlb_qos) \
      mp1_smnif_tlb_qos_reg = (mp1_smnif_tlb_qos_reg & ~MP1_SMNIF_TLB_QOS_TLB_QOS_MASK) | (tlb_qos << MP1_SMNIF_TLB_QOS_TLB_QOS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_qos_t {
            unsigned int tlb_qos                        : MP1_SMNIF_TLB_QOS_TLB_QOS_SIZE;
      } mp1_smnif_tlb_qos_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_qos_t {
            unsigned int tlb_qos                        : MP1_SMNIF_TLB_QOS_TLB_QOS_SIZE;
      } mp1_smnif_tlb_qos_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_qos_t f;
} mp1_smnif_tlb_qos_u;


/*
 * MP1_SMNIF_TLB_QOS1 struct
 */

#define MP1_SMNIF_TLB_QOS1_REG_SIZE         32
#define MP1_SMNIF_TLB_QOS1_TLB_QOS1_SIZE  32

#define MP1_SMNIF_TLB_QOS1_TLB_QOS1_SHIFT  0

#define MP1_SMNIF_TLB_QOS1_TLB_QOS1_MASK  0xffffffff

#define MP1_SMNIF_TLB_QOS1_MASK \
      (MP1_SMNIF_TLB_QOS1_TLB_QOS1_MASK)

#define MP1_SMNIF_TLB_QOS1_DEFAULT     0xffffffff

#define MP1_SMNIF_TLB_QOS1_GET_TLB_QOS1(mp1_smnif_tlb_qos1) \
      ((mp1_smnif_tlb_qos1 & MP1_SMNIF_TLB_QOS1_TLB_QOS1_MASK) >> MP1_SMNIF_TLB_QOS1_TLB_QOS1_SHIFT)

#define MP1_SMNIF_TLB_QOS1_SET_TLB_QOS1(mp1_smnif_tlb_qos1_reg, tlb_qos1) \
      mp1_smnif_tlb_qos1_reg = (mp1_smnif_tlb_qos1_reg & ~MP1_SMNIF_TLB_QOS1_TLB_QOS1_MASK) | (tlb_qos1 << MP1_SMNIF_TLB_QOS1_TLB_QOS1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_qos1_t {
            unsigned int tlb_qos1                       : MP1_SMNIF_TLB_QOS1_TLB_QOS1_SIZE;
      } mp1_smnif_tlb_qos1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_qos1_t {
            unsigned int tlb_qos1                       : MP1_SMNIF_TLB_QOS1_TLB_QOS1_SIZE;
      } mp1_smnif_tlb_qos1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_qos1_t f;
} mp1_smnif_tlb_qos1_u;


/*
 * MP1_SMNIF_ACC_VIOLATION_LOG_ADDR struct
 */

#define MP1_SMNIF_ACC_VIOLATION_LOG_ADDR_REG_SIZE         32
#define MP1_SMNIF_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SIZE  32

#define MP1_SMNIF_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SHIFT  0

#define MP1_SMNIF_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK  0xffffffff

#define MP1_SMNIF_ACC_VIOLATION_LOG_ADDR_MASK \
      (MP1_SMNIF_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK)

#define MP1_SMNIF_ACC_VIOLATION_LOG_ADDR_DEFAULT 0x00000000

#define MP1_SMNIF_ACC_VIOLATION_LOG_ADDR_GET_AXI_ADDR(mp1_smnif_acc_violation_log_addr) \
      ((mp1_smnif_acc_violation_log_addr & MP1_SMNIF_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK) >> MP1_SMNIF_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SHIFT)

#define MP1_SMNIF_ACC_VIOLATION_LOG_ADDR_SET_AXI_ADDR(mp1_smnif_acc_violation_log_addr_reg, axi_addr) \
      mp1_smnif_acc_violation_log_addr_reg = (mp1_smnif_acc_violation_log_addr_reg & ~MP1_SMNIF_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK) | (axi_addr << MP1_SMNIF_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_acc_violation_log_addr_t {
            unsigned int axi_addr                       : MP1_SMNIF_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SIZE;
      } mp1_smnif_acc_violation_log_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_acc_violation_log_addr_t {
            unsigned int axi_addr                       : MP1_SMNIF_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SIZE;
      } mp1_smnif_acc_violation_log_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_acc_violation_log_addr_t f;
} mp1_smnif_acc_violation_log_addr_u;


/*
 * MP1_SMNIF_ACC_VIOLATION_LOG_STATUS struct
 */

#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_REG_SIZE         32
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE  1
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE  2
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE  1
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_ID_SIZE  21
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_PROT_SIZE  3

#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT  0
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT  1
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT  3
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_ID_SHIFT  8
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_PROT_SHIFT  29

#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK  0x00000001
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK  0x00000006
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK  0x00000008
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK  0x1fffff00
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_PROT_MASK  0xe0000000

#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_MASK \
      (MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK | \
      MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK | \
      MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK | \
      MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK | \
      MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_PROT_MASK)

#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_DEFAULT 0x00000000

#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_DETECTED(mp1_smnif_acc_violation_log_status) \
      ((mp1_smnif_acc_violation_log_status & MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) >> MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_TYPE(mp1_smnif_acc_violation_log_status) \
      ((mp1_smnif_acc_violation_log_status & MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) >> MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_LOG_CLEAR(mp1_smnif_acc_violation_log_status) \
      ((mp1_smnif_acc_violation_log_status & MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) >> MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_GET_AXI_ID(mp1_smnif_acc_violation_log_status) \
      ((mp1_smnif_acc_violation_log_status & MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK) >> MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_ID_SHIFT)
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_GET_AXI_PROT(mp1_smnif_acc_violation_log_status) \
      ((mp1_smnif_acc_violation_log_status & MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_PROT_MASK) >> MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_PROT_SHIFT)

#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_DETECTED(mp1_smnif_acc_violation_log_status_reg, acc_violation_detected) \
      mp1_smnif_acc_violation_log_status_reg = (mp1_smnif_acc_violation_log_status_reg & ~MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) | (acc_violation_detected << MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_TYPE(mp1_smnif_acc_violation_log_status_reg, acc_violation_type) \
      mp1_smnif_acc_violation_log_status_reg = (mp1_smnif_acc_violation_log_status_reg & ~MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) | (acc_violation_type << MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_LOG_CLEAR(mp1_smnif_acc_violation_log_status_reg, acc_violation_log_clear) \
      mp1_smnif_acc_violation_log_status_reg = (mp1_smnif_acc_violation_log_status_reg & ~MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) | (acc_violation_log_clear << MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_SET_AXI_ID(mp1_smnif_acc_violation_log_status_reg, axi_id) \
      mp1_smnif_acc_violation_log_status_reg = (mp1_smnif_acc_violation_log_status_reg & ~MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK) | (axi_id << MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_ID_SHIFT)
#define MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_SET_AXI_PROT(mp1_smnif_acc_violation_log_status_reg, axi_prot) \
      mp1_smnif_acc_violation_log_status_reg = (mp1_smnif_acc_violation_log_status_reg & ~MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_PROT_MASK) | (axi_prot << MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_PROT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_acc_violation_log_status_t {
            unsigned int acc_violation_detected         : MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
            unsigned int acc_violation_type             : MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
            unsigned int acc_violation_log_clear        : MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
            unsigned int                                : 4;
            unsigned int axi_id                         : MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_ID_SIZE;
            unsigned int axi_prot                       : MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_PROT_SIZE;
      } mp1_smnif_acc_violation_log_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_acc_violation_log_status_t {
            unsigned int axi_prot                       : MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_PROT_SIZE;
            unsigned int axi_id                         : MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_AXI_ID_SIZE;
            unsigned int                                : 4;
            unsigned int acc_violation_log_clear        : MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
            unsigned int acc_violation_type             : MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
            unsigned int acc_violation_detected         : MP1_SMNIF_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
      } mp1_smnif_acc_violation_log_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_acc_violation_log_status_t f;
} mp1_smnif_acc_violation_log_status_u;


/*
 * MP1_SMNIF_LPBK_WR_VIOL_ADDR struct
 */

#define MP1_SMNIF_LPBK_WR_VIOL_ADDR_REG_SIZE         32
#define MP1_SMNIF_LPBK_WR_VIOL_ADDR_AXI_ADDR_SIZE  32

#define MP1_SMNIF_LPBK_WR_VIOL_ADDR_AXI_ADDR_SHIFT  0

#define MP1_SMNIF_LPBK_WR_VIOL_ADDR_AXI_ADDR_MASK  0xffffffff

#define MP1_SMNIF_LPBK_WR_VIOL_ADDR_MASK \
      (MP1_SMNIF_LPBK_WR_VIOL_ADDR_AXI_ADDR_MASK)

#define MP1_SMNIF_LPBK_WR_VIOL_ADDR_DEFAULT 0x00000000

#define MP1_SMNIF_LPBK_WR_VIOL_ADDR_GET_AXI_ADDR(mp1_smnif_lpbk_wr_viol_addr) \
      ((mp1_smnif_lpbk_wr_viol_addr & MP1_SMNIF_LPBK_WR_VIOL_ADDR_AXI_ADDR_MASK) >> MP1_SMNIF_LPBK_WR_VIOL_ADDR_AXI_ADDR_SHIFT)

#define MP1_SMNIF_LPBK_WR_VIOL_ADDR_SET_AXI_ADDR(mp1_smnif_lpbk_wr_viol_addr_reg, axi_addr) \
      mp1_smnif_lpbk_wr_viol_addr_reg = (mp1_smnif_lpbk_wr_viol_addr_reg & ~MP1_SMNIF_LPBK_WR_VIOL_ADDR_AXI_ADDR_MASK) | (axi_addr << MP1_SMNIF_LPBK_WR_VIOL_ADDR_AXI_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_lpbk_wr_viol_addr_t {
            unsigned int axi_addr                       : MP1_SMNIF_LPBK_WR_VIOL_ADDR_AXI_ADDR_SIZE;
      } mp1_smnif_lpbk_wr_viol_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_lpbk_wr_viol_addr_t {
            unsigned int axi_addr                       : MP1_SMNIF_LPBK_WR_VIOL_ADDR_AXI_ADDR_SIZE;
      } mp1_smnif_lpbk_wr_viol_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_lpbk_wr_viol_addr_t f;
} mp1_smnif_lpbk_wr_viol_addr_u;


/*
 * MP1_SMNIF_LPBK_WR_VIOL_STATUS struct
 */

#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_REG_SIZE         32
#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_DET_SIZE  1
#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_CLEAR_SIZE  1
#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_AXI_ID_SIZE  21
#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_AXI_PROT_SIZE  3

#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_DET_SHIFT  0
#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_CLEAR_SHIFT  3
#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_AXI_ID_SHIFT  8
#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_AXI_PROT_SHIFT  29

#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_DET_MASK  0x00000001
#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_CLEAR_MASK  0x00000008
#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_AXI_ID_MASK  0x1fffff00
#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_AXI_PROT_MASK  0xe0000000

#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_MASK \
      (MP1_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_DET_MASK | \
      MP1_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_CLEAR_MASK | \
      MP1_SMNIF_LPBK_WR_VIOL_STATUS_AXI_ID_MASK | \
      MP1_SMNIF_LPBK_WR_VIOL_STATUS_AXI_PROT_MASK)

#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_DEFAULT 0x00000000

#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_GET_VIOL_DET(mp1_smnif_lpbk_wr_viol_status) \
      ((mp1_smnif_lpbk_wr_viol_status & MP1_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_DET_MASK) >> MP1_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_DET_SHIFT)
#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_GET_VIOL_CLEAR(mp1_smnif_lpbk_wr_viol_status) \
      ((mp1_smnif_lpbk_wr_viol_status & MP1_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_CLEAR_MASK) >> MP1_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_CLEAR_SHIFT)
#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_GET_AXI_ID(mp1_smnif_lpbk_wr_viol_status) \
      ((mp1_smnif_lpbk_wr_viol_status & MP1_SMNIF_LPBK_WR_VIOL_STATUS_AXI_ID_MASK) >> MP1_SMNIF_LPBK_WR_VIOL_STATUS_AXI_ID_SHIFT)
#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_GET_AXI_PROT(mp1_smnif_lpbk_wr_viol_status) \
      ((mp1_smnif_lpbk_wr_viol_status & MP1_SMNIF_LPBK_WR_VIOL_STATUS_AXI_PROT_MASK) >> MP1_SMNIF_LPBK_WR_VIOL_STATUS_AXI_PROT_SHIFT)

#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_SET_VIOL_DET(mp1_smnif_lpbk_wr_viol_status_reg, viol_det) \
      mp1_smnif_lpbk_wr_viol_status_reg = (mp1_smnif_lpbk_wr_viol_status_reg & ~MP1_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_DET_MASK) | (viol_det << MP1_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_DET_SHIFT)
#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_SET_VIOL_CLEAR(mp1_smnif_lpbk_wr_viol_status_reg, viol_clear) \
      mp1_smnif_lpbk_wr_viol_status_reg = (mp1_smnif_lpbk_wr_viol_status_reg & ~MP1_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_CLEAR_MASK) | (viol_clear << MP1_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_CLEAR_SHIFT)
#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_SET_AXI_ID(mp1_smnif_lpbk_wr_viol_status_reg, axi_id) \
      mp1_smnif_lpbk_wr_viol_status_reg = (mp1_smnif_lpbk_wr_viol_status_reg & ~MP1_SMNIF_LPBK_WR_VIOL_STATUS_AXI_ID_MASK) | (axi_id << MP1_SMNIF_LPBK_WR_VIOL_STATUS_AXI_ID_SHIFT)
#define MP1_SMNIF_LPBK_WR_VIOL_STATUS_SET_AXI_PROT(mp1_smnif_lpbk_wr_viol_status_reg, axi_prot) \
      mp1_smnif_lpbk_wr_viol_status_reg = (mp1_smnif_lpbk_wr_viol_status_reg & ~MP1_SMNIF_LPBK_WR_VIOL_STATUS_AXI_PROT_MASK) | (axi_prot << MP1_SMNIF_LPBK_WR_VIOL_STATUS_AXI_PROT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_lpbk_wr_viol_status_t {
            unsigned int viol_det                       : MP1_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_DET_SIZE;
            unsigned int                                : 2;
            unsigned int viol_clear                     : MP1_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_CLEAR_SIZE;
            unsigned int                                : 4;
            unsigned int axi_id                         : MP1_SMNIF_LPBK_WR_VIOL_STATUS_AXI_ID_SIZE;
            unsigned int axi_prot                       : MP1_SMNIF_LPBK_WR_VIOL_STATUS_AXI_PROT_SIZE;
      } mp1_smnif_lpbk_wr_viol_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_lpbk_wr_viol_status_t {
            unsigned int axi_prot                       : MP1_SMNIF_LPBK_WR_VIOL_STATUS_AXI_PROT_SIZE;
            unsigned int axi_id                         : MP1_SMNIF_LPBK_WR_VIOL_STATUS_AXI_ID_SIZE;
            unsigned int                                : 4;
            unsigned int viol_clear                     : MP1_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_CLEAR_SIZE;
            unsigned int                                : 2;
            unsigned int viol_det                       : MP1_SMNIF_LPBK_WR_VIOL_STATUS_VIOL_DET_SIZE;
      } mp1_smnif_lpbk_wr_viol_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_lpbk_wr_viol_status_t f;
} mp1_smnif_lpbk_wr_viol_status_u;


/*
 * MP1_SMNIF_LPBK_RD_VIOL_ADDR struct
 */

#define MP1_SMNIF_LPBK_RD_VIOL_ADDR_REG_SIZE         32
#define MP1_SMNIF_LPBK_RD_VIOL_ADDR_AXI_ADDR_SIZE  32

#define MP1_SMNIF_LPBK_RD_VIOL_ADDR_AXI_ADDR_SHIFT  0

#define MP1_SMNIF_LPBK_RD_VIOL_ADDR_AXI_ADDR_MASK  0xffffffff

#define MP1_SMNIF_LPBK_RD_VIOL_ADDR_MASK \
      (MP1_SMNIF_LPBK_RD_VIOL_ADDR_AXI_ADDR_MASK)

#define MP1_SMNIF_LPBK_RD_VIOL_ADDR_DEFAULT 0x00000000

#define MP1_SMNIF_LPBK_RD_VIOL_ADDR_GET_AXI_ADDR(mp1_smnif_lpbk_rd_viol_addr) \
      ((mp1_smnif_lpbk_rd_viol_addr & MP1_SMNIF_LPBK_RD_VIOL_ADDR_AXI_ADDR_MASK) >> MP1_SMNIF_LPBK_RD_VIOL_ADDR_AXI_ADDR_SHIFT)

#define MP1_SMNIF_LPBK_RD_VIOL_ADDR_SET_AXI_ADDR(mp1_smnif_lpbk_rd_viol_addr_reg, axi_addr) \
      mp1_smnif_lpbk_rd_viol_addr_reg = (mp1_smnif_lpbk_rd_viol_addr_reg & ~MP1_SMNIF_LPBK_RD_VIOL_ADDR_AXI_ADDR_MASK) | (axi_addr << MP1_SMNIF_LPBK_RD_VIOL_ADDR_AXI_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_lpbk_rd_viol_addr_t {
            unsigned int axi_addr                       : MP1_SMNIF_LPBK_RD_VIOL_ADDR_AXI_ADDR_SIZE;
      } mp1_smnif_lpbk_rd_viol_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_lpbk_rd_viol_addr_t {
            unsigned int axi_addr                       : MP1_SMNIF_LPBK_RD_VIOL_ADDR_AXI_ADDR_SIZE;
      } mp1_smnif_lpbk_rd_viol_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_lpbk_rd_viol_addr_t f;
} mp1_smnif_lpbk_rd_viol_addr_u;


/*
 * MP1_SMNIF_LPBK_RD_VIOL_STATUS struct
 */

#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_REG_SIZE         32
#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_DET_SIZE  1
#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_CLEAR_SIZE  1
#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_AXI_ID_SIZE  21
#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_AXI_PROT_SIZE  3

#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_DET_SHIFT  0
#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_CLEAR_SHIFT  3
#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_AXI_ID_SHIFT  8
#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_AXI_PROT_SHIFT  29

#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_DET_MASK  0x00000001
#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_CLEAR_MASK  0x00000008
#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_AXI_ID_MASK  0x1fffff00
#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_AXI_PROT_MASK  0xe0000000

#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_MASK \
      (MP1_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_DET_MASK | \
      MP1_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_CLEAR_MASK | \
      MP1_SMNIF_LPBK_RD_VIOL_STATUS_AXI_ID_MASK | \
      MP1_SMNIF_LPBK_RD_VIOL_STATUS_AXI_PROT_MASK)

#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_DEFAULT 0x00000000

#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_GET_VIOL_DET(mp1_smnif_lpbk_rd_viol_status) \
      ((mp1_smnif_lpbk_rd_viol_status & MP1_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_DET_MASK) >> MP1_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_DET_SHIFT)
#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_GET_VIOL_CLEAR(mp1_smnif_lpbk_rd_viol_status) \
      ((mp1_smnif_lpbk_rd_viol_status & MP1_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_CLEAR_MASK) >> MP1_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_CLEAR_SHIFT)
#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_GET_AXI_ID(mp1_smnif_lpbk_rd_viol_status) \
      ((mp1_smnif_lpbk_rd_viol_status & MP1_SMNIF_LPBK_RD_VIOL_STATUS_AXI_ID_MASK) >> MP1_SMNIF_LPBK_RD_VIOL_STATUS_AXI_ID_SHIFT)
#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_GET_AXI_PROT(mp1_smnif_lpbk_rd_viol_status) \
      ((mp1_smnif_lpbk_rd_viol_status & MP1_SMNIF_LPBK_RD_VIOL_STATUS_AXI_PROT_MASK) >> MP1_SMNIF_LPBK_RD_VIOL_STATUS_AXI_PROT_SHIFT)

#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_SET_VIOL_DET(mp1_smnif_lpbk_rd_viol_status_reg, viol_det) \
      mp1_smnif_lpbk_rd_viol_status_reg = (mp1_smnif_lpbk_rd_viol_status_reg & ~MP1_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_DET_MASK) | (viol_det << MP1_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_DET_SHIFT)
#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_SET_VIOL_CLEAR(mp1_smnif_lpbk_rd_viol_status_reg, viol_clear) \
      mp1_smnif_lpbk_rd_viol_status_reg = (mp1_smnif_lpbk_rd_viol_status_reg & ~MP1_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_CLEAR_MASK) | (viol_clear << MP1_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_CLEAR_SHIFT)
#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_SET_AXI_ID(mp1_smnif_lpbk_rd_viol_status_reg, axi_id) \
      mp1_smnif_lpbk_rd_viol_status_reg = (mp1_smnif_lpbk_rd_viol_status_reg & ~MP1_SMNIF_LPBK_RD_VIOL_STATUS_AXI_ID_MASK) | (axi_id << MP1_SMNIF_LPBK_RD_VIOL_STATUS_AXI_ID_SHIFT)
#define MP1_SMNIF_LPBK_RD_VIOL_STATUS_SET_AXI_PROT(mp1_smnif_lpbk_rd_viol_status_reg, axi_prot) \
      mp1_smnif_lpbk_rd_viol_status_reg = (mp1_smnif_lpbk_rd_viol_status_reg & ~MP1_SMNIF_LPBK_RD_VIOL_STATUS_AXI_PROT_MASK) | (axi_prot << MP1_SMNIF_LPBK_RD_VIOL_STATUS_AXI_PROT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_lpbk_rd_viol_status_t {
            unsigned int viol_det                       : MP1_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_DET_SIZE;
            unsigned int                                : 2;
            unsigned int viol_clear                     : MP1_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_CLEAR_SIZE;
            unsigned int                                : 4;
            unsigned int axi_id                         : MP1_SMNIF_LPBK_RD_VIOL_STATUS_AXI_ID_SIZE;
            unsigned int axi_prot                       : MP1_SMNIF_LPBK_RD_VIOL_STATUS_AXI_PROT_SIZE;
      } mp1_smnif_lpbk_rd_viol_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_lpbk_rd_viol_status_t {
            unsigned int axi_prot                       : MP1_SMNIF_LPBK_RD_VIOL_STATUS_AXI_PROT_SIZE;
            unsigned int axi_id                         : MP1_SMNIF_LPBK_RD_VIOL_STATUS_AXI_ID_SIZE;
            unsigned int                                : 4;
            unsigned int viol_clear                     : MP1_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_CLEAR_SIZE;
            unsigned int                                : 2;
            unsigned int viol_det                       : MP1_SMNIF_LPBK_RD_VIOL_STATUS_VIOL_DET_SIZE;
      } mp1_smnif_lpbk_rd_viol_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_lpbk_rd_viol_status_t f;
} mp1_smnif_lpbk_rd_viol_status_u;


/*
 * MP1_SMNIF_MISC_CTRL struct
 */

#define MP1_SMNIF_MISC_CTRL_REG_SIZE         32
#define MP1_SMNIF_MISC_CTRL_CLK_GATE_EN_SIZE  1
#define MP1_SMNIF_MISC_CTRL_POSTED_WRITE_ENABLE_SIZE  1
#define MP1_SMNIF_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SIZE  1
#define MP1_SMNIF_MISC_CTRL_WRITE_REQ_CNT_EN_SIZE  1
#define MP1_SMNIF_MISC_CTRL_READ_REQ_CNT_EN_SIZE  1

#define MP1_SMNIF_MISC_CTRL_CLK_GATE_EN_SHIFT  0
#define MP1_SMNIF_MISC_CTRL_POSTED_WRITE_ENABLE_SHIFT  16
#define MP1_SMNIF_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SHIFT  17
#define MP1_SMNIF_MISC_CTRL_WRITE_REQ_CNT_EN_SHIFT  18
#define MP1_SMNIF_MISC_CTRL_READ_REQ_CNT_EN_SHIFT  19

#define MP1_SMNIF_MISC_CTRL_CLK_GATE_EN_MASK  0x00000001
#define MP1_SMNIF_MISC_CTRL_POSTED_WRITE_ENABLE_MASK  0x00010000
#define MP1_SMNIF_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK  0x00020000
#define MP1_SMNIF_MISC_CTRL_WRITE_REQ_CNT_EN_MASK  0x00040000
#define MP1_SMNIF_MISC_CTRL_READ_REQ_CNT_EN_MASK  0x00080000

#define MP1_SMNIF_MISC_CTRL_MASK \
      (MP1_SMNIF_MISC_CTRL_CLK_GATE_EN_MASK | \
      MP1_SMNIF_MISC_CTRL_POSTED_WRITE_ENABLE_MASK | \
      MP1_SMNIF_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK | \
      MP1_SMNIF_MISC_CTRL_WRITE_REQ_CNT_EN_MASK | \
      MP1_SMNIF_MISC_CTRL_READ_REQ_CNT_EN_MASK)

#define MP1_SMNIF_MISC_CTRL_DEFAULT    0x00020001

#define MP1_SMNIF_MISC_CTRL_GET_CLK_GATE_EN(mp1_smnif_misc_ctrl) \
      ((mp1_smnif_misc_ctrl & MP1_SMNIF_MISC_CTRL_CLK_GATE_EN_MASK) >> MP1_SMNIF_MISC_CTRL_CLK_GATE_EN_SHIFT)
#define MP1_SMNIF_MISC_CTRL_GET_POSTED_WRITE_ENABLE(mp1_smnif_misc_ctrl) \
      ((mp1_smnif_misc_ctrl & MP1_SMNIF_MISC_CTRL_POSTED_WRITE_ENABLE_MASK) >> MP1_SMNIF_MISC_CTRL_POSTED_WRITE_ENABLE_SHIFT)
#define MP1_SMNIF_MISC_CTRL_GET_ALLOW_NON_PRIV_REG_ACC(mp1_smnif_misc_ctrl) \
      ((mp1_smnif_misc_ctrl & MP1_SMNIF_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK) >> MP1_SMNIF_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SHIFT)
#define MP1_SMNIF_MISC_CTRL_GET_WRITE_REQ_CNT_EN(mp1_smnif_misc_ctrl) \
      ((mp1_smnif_misc_ctrl & MP1_SMNIF_MISC_CTRL_WRITE_REQ_CNT_EN_MASK) >> MP1_SMNIF_MISC_CTRL_WRITE_REQ_CNT_EN_SHIFT)
#define MP1_SMNIF_MISC_CTRL_GET_READ_REQ_CNT_EN(mp1_smnif_misc_ctrl) \
      ((mp1_smnif_misc_ctrl & MP1_SMNIF_MISC_CTRL_READ_REQ_CNT_EN_MASK) >> MP1_SMNIF_MISC_CTRL_READ_REQ_CNT_EN_SHIFT)

#define MP1_SMNIF_MISC_CTRL_SET_CLK_GATE_EN(mp1_smnif_misc_ctrl_reg, clk_gate_en) \
      mp1_smnif_misc_ctrl_reg = (mp1_smnif_misc_ctrl_reg & ~MP1_SMNIF_MISC_CTRL_CLK_GATE_EN_MASK) | (clk_gate_en << MP1_SMNIF_MISC_CTRL_CLK_GATE_EN_SHIFT)
#define MP1_SMNIF_MISC_CTRL_SET_POSTED_WRITE_ENABLE(mp1_smnif_misc_ctrl_reg, posted_write_enable) \
      mp1_smnif_misc_ctrl_reg = (mp1_smnif_misc_ctrl_reg & ~MP1_SMNIF_MISC_CTRL_POSTED_WRITE_ENABLE_MASK) | (posted_write_enable << MP1_SMNIF_MISC_CTRL_POSTED_WRITE_ENABLE_SHIFT)
#define MP1_SMNIF_MISC_CTRL_SET_ALLOW_NON_PRIV_REG_ACC(mp1_smnif_misc_ctrl_reg, allow_non_priv_reg_acc) \
      mp1_smnif_misc_ctrl_reg = (mp1_smnif_misc_ctrl_reg & ~MP1_SMNIF_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK) | (allow_non_priv_reg_acc << MP1_SMNIF_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SHIFT)
#define MP1_SMNIF_MISC_CTRL_SET_WRITE_REQ_CNT_EN(mp1_smnif_misc_ctrl_reg, write_req_cnt_en) \
      mp1_smnif_misc_ctrl_reg = (mp1_smnif_misc_ctrl_reg & ~MP1_SMNIF_MISC_CTRL_WRITE_REQ_CNT_EN_MASK) | (write_req_cnt_en << MP1_SMNIF_MISC_CTRL_WRITE_REQ_CNT_EN_SHIFT)
#define MP1_SMNIF_MISC_CTRL_SET_READ_REQ_CNT_EN(mp1_smnif_misc_ctrl_reg, read_req_cnt_en) \
      mp1_smnif_misc_ctrl_reg = (mp1_smnif_misc_ctrl_reg & ~MP1_SMNIF_MISC_CTRL_READ_REQ_CNT_EN_MASK) | (read_req_cnt_en << MP1_SMNIF_MISC_CTRL_READ_REQ_CNT_EN_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_misc_ctrl_t {
            unsigned int clk_gate_en                    : MP1_SMNIF_MISC_CTRL_CLK_GATE_EN_SIZE;
            unsigned int                                : 15;
            unsigned int posted_write_enable            : MP1_SMNIF_MISC_CTRL_POSTED_WRITE_ENABLE_SIZE;
            unsigned int allow_non_priv_reg_acc         : MP1_SMNIF_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SIZE;
            unsigned int write_req_cnt_en               : MP1_SMNIF_MISC_CTRL_WRITE_REQ_CNT_EN_SIZE;
            unsigned int read_req_cnt_en                : MP1_SMNIF_MISC_CTRL_READ_REQ_CNT_EN_SIZE;
            unsigned int                                : 12;
      } mp1_smnif_misc_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_misc_ctrl_t {
            unsigned int                                : 12;
            unsigned int read_req_cnt_en                : MP1_SMNIF_MISC_CTRL_READ_REQ_CNT_EN_SIZE;
            unsigned int write_req_cnt_en               : MP1_SMNIF_MISC_CTRL_WRITE_REQ_CNT_EN_SIZE;
            unsigned int allow_non_priv_reg_acc         : MP1_SMNIF_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SIZE;
            unsigned int posted_write_enable            : MP1_SMNIF_MISC_CTRL_POSTED_WRITE_ENABLE_SIZE;
            unsigned int                                : 15;
            unsigned int clk_gate_en                    : MP1_SMNIF_MISC_CTRL_CLK_GATE_EN_SIZE;
      } mp1_smnif_misc_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_misc_ctrl_t f;
} mp1_smnif_misc_ctrl_u;


/*
 * MP1_SMNIF_REQ_CNT struct
 */

#define MP1_SMNIF_REQ_CNT_REG_SIZE         32
#define MP1_SMNIF_REQ_CNT_WRITE_REQ_CNT_SIZE  8
#define MP1_SMNIF_REQ_CNT_READ_REQ_CNT_SIZE  8

#define MP1_SMNIF_REQ_CNT_WRITE_REQ_CNT_SHIFT  0
#define MP1_SMNIF_REQ_CNT_READ_REQ_CNT_SHIFT  8

#define MP1_SMNIF_REQ_CNT_WRITE_REQ_CNT_MASK  0x000000ff
#define MP1_SMNIF_REQ_CNT_READ_REQ_CNT_MASK  0x0000ff00

#define MP1_SMNIF_REQ_CNT_MASK \
      (MP1_SMNIF_REQ_CNT_WRITE_REQ_CNT_MASK | \
      MP1_SMNIF_REQ_CNT_READ_REQ_CNT_MASK)

#define MP1_SMNIF_REQ_CNT_DEFAULT      0x00000000

#define MP1_SMNIF_REQ_CNT_GET_WRITE_REQ_CNT(mp1_smnif_req_cnt) \
      ((mp1_smnif_req_cnt & MP1_SMNIF_REQ_CNT_WRITE_REQ_CNT_MASK) >> MP1_SMNIF_REQ_CNT_WRITE_REQ_CNT_SHIFT)
#define MP1_SMNIF_REQ_CNT_GET_READ_REQ_CNT(mp1_smnif_req_cnt) \
      ((mp1_smnif_req_cnt & MP1_SMNIF_REQ_CNT_READ_REQ_CNT_MASK) >> MP1_SMNIF_REQ_CNT_READ_REQ_CNT_SHIFT)

#define MP1_SMNIF_REQ_CNT_SET_WRITE_REQ_CNT(mp1_smnif_req_cnt_reg, write_req_cnt) \
      mp1_smnif_req_cnt_reg = (mp1_smnif_req_cnt_reg & ~MP1_SMNIF_REQ_CNT_WRITE_REQ_CNT_MASK) | (write_req_cnt << MP1_SMNIF_REQ_CNT_WRITE_REQ_CNT_SHIFT)
#define MP1_SMNIF_REQ_CNT_SET_READ_REQ_CNT(mp1_smnif_req_cnt_reg, read_req_cnt) \
      mp1_smnif_req_cnt_reg = (mp1_smnif_req_cnt_reg & ~MP1_SMNIF_REQ_CNT_READ_REQ_CNT_MASK) | (read_req_cnt << MP1_SMNIF_REQ_CNT_READ_REQ_CNT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_req_cnt_t {
            unsigned int write_req_cnt                  : MP1_SMNIF_REQ_CNT_WRITE_REQ_CNT_SIZE;
            unsigned int read_req_cnt                   : MP1_SMNIF_REQ_CNT_READ_REQ_CNT_SIZE;
            unsigned int                                : 16;
      } mp1_smnif_req_cnt_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_req_cnt_t {
            unsigned int                                : 16;
            unsigned int read_req_cnt                   : MP1_SMNIF_REQ_CNT_READ_REQ_CNT_SIZE;
            unsigned int write_req_cnt                  : MP1_SMNIF_REQ_CNT_WRITE_REQ_CNT_SIZE;
      } mp1_smnif_req_cnt_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_req_cnt_t f;
} mp1_smnif_req_cnt_u;


/*
 * MP1_SMNIF_SCRATCH0 struct
 */

#define MP1_SMNIF_SCRATCH0_REG_SIZE         32
#define MP1_SMNIF_SCRATCH0_DATA_SIZE  32

#define MP1_SMNIF_SCRATCH0_DATA_SHIFT  0

#define MP1_SMNIF_SCRATCH0_DATA_MASK    0xffffffff

#define MP1_SMNIF_SCRATCH0_MASK \
      (MP1_SMNIF_SCRATCH0_DATA_MASK)

#define MP1_SMNIF_SCRATCH0_DEFAULT     0x00000000

#define MP1_SMNIF_SCRATCH0_GET_DATA(mp1_smnif_scratch0) \
      ((mp1_smnif_scratch0 & MP1_SMNIF_SCRATCH0_DATA_MASK) >> MP1_SMNIF_SCRATCH0_DATA_SHIFT)

#define MP1_SMNIF_SCRATCH0_SET_DATA(mp1_smnif_scratch0_reg, data) \
      mp1_smnif_scratch0_reg = (mp1_smnif_scratch0_reg & ~MP1_SMNIF_SCRATCH0_DATA_MASK) | (data << MP1_SMNIF_SCRATCH0_DATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_scratch0_t {
            unsigned int data                           : MP1_SMNIF_SCRATCH0_DATA_SIZE;
      } mp1_smnif_scratch0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_scratch0_t {
            unsigned int data                           : MP1_SMNIF_SCRATCH0_DATA_SIZE;
      } mp1_smnif_scratch0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_scratch0_t f;
} mp1_smnif_scratch0_u;


/*
 * MP1_SMNIF_SCRATCH1 struct
 */

#define MP1_SMNIF_SCRATCH1_REG_SIZE         32
#define MP1_SMNIF_SCRATCH1_DATA_SIZE  32

#define MP1_SMNIF_SCRATCH1_DATA_SHIFT  0

#define MP1_SMNIF_SCRATCH1_DATA_MASK    0xffffffff

#define MP1_SMNIF_SCRATCH1_MASK \
      (MP1_SMNIF_SCRATCH1_DATA_MASK)

#define MP1_SMNIF_SCRATCH1_DEFAULT     0x00000000

#define MP1_SMNIF_SCRATCH1_GET_DATA(mp1_smnif_scratch1) \
      ((mp1_smnif_scratch1 & MP1_SMNIF_SCRATCH1_DATA_MASK) >> MP1_SMNIF_SCRATCH1_DATA_SHIFT)

#define MP1_SMNIF_SCRATCH1_SET_DATA(mp1_smnif_scratch1_reg, data) \
      mp1_smnif_scratch1_reg = (mp1_smnif_scratch1_reg & ~MP1_SMNIF_SCRATCH1_DATA_MASK) | (data << MP1_SMNIF_SCRATCH1_DATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_scratch1_t {
            unsigned int data                           : MP1_SMNIF_SCRATCH1_DATA_SIZE;
      } mp1_smnif_scratch1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_scratch1_t {
            unsigned int data                           : MP1_SMNIF_SCRATCH1_DATA_SIZE;
      } mp1_smnif_scratch1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_scratch1_t f;
} mp1_smnif_scratch1_u;


/*
 * MP1_SMNIF_SCRATCH2 struct
 */

#define MP1_SMNIF_SCRATCH2_REG_SIZE         32
#define MP1_SMNIF_SCRATCH2_DATA_SIZE  32

#define MP1_SMNIF_SCRATCH2_DATA_SHIFT  0

#define MP1_SMNIF_SCRATCH2_DATA_MASK    0xffffffff

#define MP1_SMNIF_SCRATCH2_MASK \
      (MP1_SMNIF_SCRATCH2_DATA_MASK)

#define MP1_SMNIF_SCRATCH2_DEFAULT     0x00000000

#define MP1_SMNIF_SCRATCH2_GET_DATA(mp1_smnif_scratch2) \
      ((mp1_smnif_scratch2 & MP1_SMNIF_SCRATCH2_DATA_MASK) >> MP1_SMNIF_SCRATCH2_DATA_SHIFT)

#define MP1_SMNIF_SCRATCH2_SET_DATA(mp1_smnif_scratch2_reg, data) \
      mp1_smnif_scratch2_reg = (mp1_smnif_scratch2_reg & ~MP1_SMNIF_SCRATCH2_DATA_MASK) | (data << MP1_SMNIF_SCRATCH2_DATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_scratch2_t {
            unsigned int data                           : MP1_SMNIF_SCRATCH2_DATA_SIZE;
      } mp1_smnif_scratch2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_scratch2_t {
            unsigned int data                           : MP1_SMNIF_SCRATCH2_DATA_SIZE;
      } mp1_smnif_scratch2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_scratch2_t f;
} mp1_smnif_scratch2_u;


/*
 * MP1_SMNIF_SCRATCH3 struct
 */

#define MP1_SMNIF_SCRATCH3_REG_SIZE         32
#define MP1_SMNIF_SCRATCH3_DATA_SIZE  32

#define MP1_SMNIF_SCRATCH3_DATA_SHIFT  0

#define MP1_SMNIF_SCRATCH3_DATA_MASK    0xffffffff

#define MP1_SMNIF_SCRATCH3_MASK \
      (MP1_SMNIF_SCRATCH3_DATA_MASK)

#define MP1_SMNIF_SCRATCH3_DEFAULT     0x00000000

#define MP1_SMNIF_SCRATCH3_GET_DATA(mp1_smnif_scratch3) \
      ((mp1_smnif_scratch3 & MP1_SMNIF_SCRATCH3_DATA_MASK) >> MP1_SMNIF_SCRATCH3_DATA_SHIFT)

#define MP1_SMNIF_SCRATCH3_SET_DATA(mp1_smnif_scratch3_reg, data) \
      mp1_smnif_scratch3_reg = (mp1_smnif_scratch3_reg & ~MP1_SMNIF_SCRATCH3_DATA_MASK) | (data << MP1_SMNIF_SCRATCH3_DATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_scratch3_t {
            unsigned int data                           : MP1_SMNIF_SCRATCH3_DATA_SIZE;
      } mp1_smnif_scratch3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_scratch3_t {
            unsigned int data                           : MP1_SMNIF_SCRATCH3_DATA_SIZE;
      } mp1_smnif_scratch3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_scratch3_t f;
} mp1_smnif_scratch3_u;


/*
 * MP1_SMNIF_AXI_RESP_MASK struct
 */

#define MP1_SMNIF_AXI_RESP_MASK_REG_SIZE         32
#define MP1_SMNIF_AXI_RESP_MASK_MASK_RRESP_ERROR_SIZE  1
#define MP1_SMNIF_AXI_RESP_MASK_MASK_BRESP_ERROR_SIZE  1

#define MP1_SMNIF_AXI_RESP_MASK_MASK_RRESP_ERROR_SHIFT  0
#define MP1_SMNIF_AXI_RESP_MASK_MASK_BRESP_ERROR_SHIFT  1

#define MP1_SMNIF_AXI_RESP_MASK_MASK_RRESP_ERROR_MASK  0x00000001
#define MP1_SMNIF_AXI_RESP_MASK_MASK_BRESP_ERROR_MASK  0x00000002

#define MP1_SMNIF_AXI_RESP_MASK_MASK \
      (MP1_SMNIF_AXI_RESP_MASK_MASK_RRESP_ERROR_MASK | \
      MP1_SMNIF_AXI_RESP_MASK_MASK_BRESP_ERROR_MASK)

#define MP1_SMNIF_AXI_RESP_MASK_DEFAULT 0x00000000

#define MP1_SMNIF_AXI_RESP_MASK_GET_MASK_RRESP_ERROR(mp1_smnif_axi_resp_mask) \
      ((mp1_smnif_axi_resp_mask & MP1_SMNIF_AXI_RESP_MASK_MASK_RRESP_ERROR_MASK) >> MP1_SMNIF_AXI_RESP_MASK_MASK_RRESP_ERROR_SHIFT)
#define MP1_SMNIF_AXI_RESP_MASK_GET_MASK_BRESP_ERROR(mp1_smnif_axi_resp_mask) \
      ((mp1_smnif_axi_resp_mask & MP1_SMNIF_AXI_RESP_MASK_MASK_BRESP_ERROR_MASK) >> MP1_SMNIF_AXI_RESP_MASK_MASK_BRESP_ERROR_SHIFT)

#define MP1_SMNIF_AXI_RESP_MASK_SET_MASK_RRESP_ERROR(mp1_smnif_axi_resp_mask_reg, mask_rresp_error) \
      mp1_smnif_axi_resp_mask_reg = (mp1_smnif_axi_resp_mask_reg & ~MP1_SMNIF_AXI_RESP_MASK_MASK_RRESP_ERROR_MASK) | (mask_rresp_error << MP1_SMNIF_AXI_RESP_MASK_MASK_RRESP_ERROR_SHIFT)
#define MP1_SMNIF_AXI_RESP_MASK_SET_MASK_BRESP_ERROR(mp1_smnif_axi_resp_mask_reg, mask_bresp_error) \
      mp1_smnif_axi_resp_mask_reg = (mp1_smnif_axi_resp_mask_reg & ~MP1_SMNIF_AXI_RESP_MASK_MASK_BRESP_ERROR_MASK) | (mask_bresp_error << MP1_SMNIF_AXI_RESP_MASK_MASK_BRESP_ERROR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_axi_resp_mask_t {
            unsigned int mask_rresp_error               : MP1_SMNIF_AXI_RESP_MASK_MASK_RRESP_ERROR_SIZE;
            unsigned int mask_bresp_error               : MP1_SMNIF_AXI_RESP_MASK_MASK_BRESP_ERROR_SIZE;
            unsigned int                                : 30;
      } mp1_smnif_axi_resp_mask_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_axi_resp_mask_t {
            unsigned int                                : 30;
            unsigned int mask_bresp_error               : MP1_SMNIF_AXI_RESP_MASK_MASK_BRESP_ERROR_SIZE;
            unsigned int mask_rresp_error               : MP1_SMNIF_AXI_RESP_MASK_MASK_RRESP_ERROR_SIZE;
      } mp1_smnif_axi_resp_mask_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_axi_resp_mask_t f;
} mp1_smnif_axi_resp_mask_u;


/*
 * MP1_SMNIF_AXI_WRITE_ERROR_COUNTER struct
 */

#define MP1_SMNIF_AXI_WRITE_ERROR_COUNTER_REG_SIZE         32
#define MP1_SMNIF_AXI_WRITE_ERROR_COUNTER_SMNIF_AXI_WRITE_ERROR_COUNTER_SIZE  32

#define MP1_SMNIF_AXI_WRITE_ERROR_COUNTER_SMNIF_AXI_WRITE_ERROR_COUNTER_SHIFT  0

#define MP1_SMNIF_AXI_WRITE_ERROR_COUNTER_SMNIF_AXI_WRITE_ERROR_COUNTER_MASK  0xffffffff

#define MP1_SMNIF_AXI_WRITE_ERROR_COUNTER_MASK \
      (MP1_SMNIF_AXI_WRITE_ERROR_COUNTER_SMNIF_AXI_WRITE_ERROR_COUNTER_MASK)

#define MP1_SMNIF_AXI_WRITE_ERROR_COUNTER_DEFAULT 0x00000000

#define MP1_SMNIF_AXI_WRITE_ERROR_COUNTER_GET_SMNIF_AXI_WRITE_ERROR_COUNTER(mp1_smnif_axi_write_error_counter) \
      ((mp1_smnif_axi_write_error_counter & MP1_SMNIF_AXI_WRITE_ERROR_COUNTER_SMNIF_AXI_WRITE_ERROR_COUNTER_MASK) >> MP1_SMNIF_AXI_WRITE_ERROR_COUNTER_SMNIF_AXI_WRITE_ERROR_COUNTER_SHIFT)

#define MP1_SMNIF_AXI_WRITE_ERROR_COUNTER_SET_SMNIF_AXI_WRITE_ERROR_COUNTER(mp1_smnif_axi_write_error_counter_reg, smnif_axi_write_error_counter) \
      mp1_smnif_axi_write_error_counter_reg = (mp1_smnif_axi_write_error_counter_reg & ~MP1_SMNIF_AXI_WRITE_ERROR_COUNTER_SMNIF_AXI_WRITE_ERROR_COUNTER_MASK) | (smnif_axi_write_error_counter << MP1_SMNIF_AXI_WRITE_ERROR_COUNTER_SMNIF_AXI_WRITE_ERROR_COUNTER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_axi_write_error_counter_t {
            unsigned int smnif_axi_write_error_counter  : MP1_SMNIF_AXI_WRITE_ERROR_COUNTER_SMNIF_AXI_WRITE_ERROR_COUNTER_SIZE;
      } mp1_smnif_axi_write_error_counter_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_axi_write_error_counter_t {
            unsigned int smnif_axi_write_error_counter  : MP1_SMNIF_AXI_WRITE_ERROR_COUNTER_SMNIF_AXI_WRITE_ERROR_COUNTER_SIZE;
      } mp1_smnif_axi_write_error_counter_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_axi_write_error_counter_t f;
} mp1_smnif_axi_write_error_counter_u;


/*
 * MP1_SMNIF_AXI_READ_ERROR_COUNTER struct
 */

#define MP1_SMNIF_AXI_READ_ERROR_COUNTER_REG_SIZE         32
#define MP1_SMNIF_AXI_READ_ERROR_COUNTER_SMNIF_AXI_READ_ERROR_COUNTER_SIZE  32

#define MP1_SMNIF_AXI_READ_ERROR_COUNTER_SMNIF_AXI_READ_ERROR_COUNTER_SHIFT  0

#define MP1_SMNIF_AXI_READ_ERROR_COUNTER_SMNIF_AXI_READ_ERROR_COUNTER_MASK  0xffffffff

#define MP1_SMNIF_AXI_READ_ERROR_COUNTER_MASK \
      (MP1_SMNIF_AXI_READ_ERROR_COUNTER_SMNIF_AXI_READ_ERROR_COUNTER_MASK)

#define MP1_SMNIF_AXI_READ_ERROR_COUNTER_DEFAULT 0x00000000

#define MP1_SMNIF_AXI_READ_ERROR_COUNTER_GET_SMNIF_AXI_READ_ERROR_COUNTER(mp1_smnif_axi_read_error_counter) \
      ((mp1_smnif_axi_read_error_counter & MP1_SMNIF_AXI_READ_ERROR_COUNTER_SMNIF_AXI_READ_ERROR_COUNTER_MASK) >> MP1_SMNIF_AXI_READ_ERROR_COUNTER_SMNIF_AXI_READ_ERROR_COUNTER_SHIFT)

#define MP1_SMNIF_AXI_READ_ERROR_COUNTER_SET_SMNIF_AXI_READ_ERROR_COUNTER(mp1_smnif_axi_read_error_counter_reg, smnif_axi_read_error_counter) \
      mp1_smnif_axi_read_error_counter_reg = (mp1_smnif_axi_read_error_counter_reg & ~MP1_SMNIF_AXI_READ_ERROR_COUNTER_SMNIF_AXI_READ_ERROR_COUNTER_MASK) | (smnif_axi_read_error_counter << MP1_SMNIF_AXI_READ_ERROR_COUNTER_SMNIF_AXI_READ_ERROR_COUNTER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_axi_read_error_counter_t {
            unsigned int smnif_axi_read_error_counter   : MP1_SMNIF_AXI_READ_ERROR_COUNTER_SMNIF_AXI_READ_ERROR_COUNTER_SIZE;
      } mp1_smnif_axi_read_error_counter_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_axi_read_error_counter_t {
            unsigned int smnif_axi_read_error_counter   : MP1_SMNIF_AXI_READ_ERROR_COUNTER_SMNIF_AXI_READ_ERROR_COUNTER_SIZE;
      } mp1_smnif_axi_read_error_counter_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_axi_read_error_counter_t f;
} mp1_smnif_axi_read_error_counter_u;


/*
 * MP1_SMNIF_TLB_AWCACHE struct
 */

#define MP1_SMNIF_TLB_AWCACHE_REG_SIZE         32
#define MP1_SMNIF_TLB_AWCACHE_AWCACHE_SIZE  32

#define MP1_SMNIF_TLB_AWCACHE_AWCACHE_SHIFT  0

#define MP1_SMNIF_TLB_AWCACHE_AWCACHE_MASK  0xffffffff

#define MP1_SMNIF_TLB_AWCACHE_MASK \
      (MP1_SMNIF_TLB_AWCACHE_AWCACHE_MASK)

#define MP1_SMNIF_TLB_AWCACHE_DEFAULT  0xffffffff

#define MP1_SMNIF_TLB_AWCACHE_GET_AWCACHE(mp1_smnif_tlb_awcache) \
      ((mp1_smnif_tlb_awcache & MP1_SMNIF_TLB_AWCACHE_AWCACHE_MASK) >> MP1_SMNIF_TLB_AWCACHE_AWCACHE_SHIFT)

#define MP1_SMNIF_TLB_AWCACHE_SET_AWCACHE(mp1_smnif_tlb_awcache_reg, awcache) \
      mp1_smnif_tlb_awcache_reg = (mp1_smnif_tlb_awcache_reg & ~MP1_SMNIF_TLB_AWCACHE_AWCACHE_MASK) | (awcache << MP1_SMNIF_TLB_AWCACHE_AWCACHE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_awcache_t {
            unsigned int awcache                        : MP1_SMNIF_TLB_AWCACHE_AWCACHE_SIZE;
      } mp1_smnif_tlb_awcache_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_awcache_t {
            unsigned int awcache                        : MP1_SMNIF_TLB_AWCACHE_AWCACHE_SIZE;
      } mp1_smnif_tlb_awcache_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_awcache_t f;
} mp1_smnif_tlb_awcache_u;


/*
 * MP1_SMNIF_TLB_AWCACHE1 struct
 */

#define MP1_SMNIF_TLB_AWCACHE1_REG_SIZE         32
#define MP1_SMNIF_TLB_AWCACHE1_AWCACHE1_SIZE  32

#define MP1_SMNIF_TLB_AWCACHE1_AWCACHE1_SHIFT  0

#define MP1_SMNIF_TLB_AWCACHE1_AWCACHE1_MASK  0xffffffff

#define MP1_SMNIF_TLB_AWCACHE1_MASK \
      (MP1_SMNIF_TLB_AWCACHE1_AWCACHE1_MASK)

#define MP1_SMNIF_TLB_AWCACHE1_DEFAULT 0xffffffff

#define MP1_SMNIF_TLB_AWCACHE1_GET_AWCACHE1(mp1_smnif_tlb_awcache1) \
      ((mp1_smnif_tlb_awcache1 & MP1_SMNIF_TLB_AWCACHE1_AWCACHE1_MASK) >> MP1_SMNIF_TLB_AWCACHE1_AWCACHE1_SHIFT)

#define MP1_SMNIF_TLB_AWCACHE1_SET_AWCACHE1(mp1_smnif_tlb_awcache1_reg, awcache1) \
      mp1_smnif_tlb_awcache1_reg = (mp1_smnif_tlb_awcache1_reg & ~MP1_SMNIF_TLB_AWCACHE1_AWCACHE1_MASK) | (awcache1 << MP1_SMNIF_TLB_AWCACHE1_AWCACHE1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlb_awcache1_t {
            unsigned int awcache1                       : MP1_SMNIF_TLB_AWCACHE1_AWCACHE1_SIZE;
      } mp1_smnif_tlb_awcache1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlb_awcache1_t {
            unsigned int awcache1                       : MP1_SMNIF_TLB_AWCACHE1_AWCACHE1_SIZE;
      } mp1_smnif_tlb_awcache1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlb_awcache1_t f;
} mp1_smnif_tlb_awcache1_u;


/*
 * MP1_SMNIF_SECURE_CTRL struct
 */

#define MP1_SMNIF_SECURE_CTRL_REG_SIZE         32
#define MP1_SMNIF_SECURE_CTRL_ALLOW_NONMP_SRAM_ACCESS_SIZE  1
#define MP1_SMNIF_SECURE_CTRL_BLOCK_SRAM_SPACE_SIZE  1
#define MP1_SMNIF_SECURE_CTRL_BLOCK_PRIV_SPACE_SIZE  1
#define MP1_SMNIF_SECURE_CTRL_ALLOW_RAM0_INITID_ACCESS_SIZE  1
#define MP1_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_SIZE  1
#define MP1_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_STATUS_SIZE  1
#define MP1_SMNIF_SECURE_CTRL_BLOCK_OUTBOUND_ACCESS_SIZE  1
#define MP1_SMNIF_SECURE_CTRL_ALLOW_INBOUND_LIVMIN_ACCESS_SIZE  1

#define MP1_SMNIF_SECURE_CTRL_ALLOW_NONMP_SRAM_ACCESS_SHIFT  0
#define MP1_SMNIF_SECURE_CTRL_BLOCK_SRAM_SPACE_SHIFT  1
#define MP1_SMNIF_SECURE_CTRL_BLOCK_PRIV_SPACE_SHIFT  2
#define MP1_SMNIF_SECURE_CTRL_ALLOW_RAM0_INITID_ACCESS_SHIFT  6
#define MP1_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_SHIFT  15
#define MP1_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_STATUS_SHIFT  16
#define MP1_SMNIF_SECURE_CTRL_BLOCK_OUTBOUND_ACCESS_SHIFT  24
#define MP1_SMNIF_SECURE_CTRL_ALLOW_INBOUND_LIVMIN_ACCESS_SHIFT  31

#define MP1_SMNIF_SECURE_CTRL_ALLOW_NONMP_SRAM_ACCESS_MASK  0x00000001
#define MP1_SMNIF_SECURE_CTRL_BLOCK_SRAM_SPACE_MASK  0x00000002
#define MP1_SMNIF_SECURE_CTRL_BLOCK_PRIV_SPACE_MASK  0x00000004
#define MP1_SMNIF_SECURE_CTRL_ALLOW_RAM0_INITID_ACCESS_MASK  0x00000040
#define MP1_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_MASK  0x00008000
#define MP1_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_STATUS_MASK  0x00010000
#define MP1_SMNIF_SECURE_CTRL_BLOCK_OUTBOUND_ACCESS_MASK  0x01000000
#define MP1_SMNIF_SECURE_CTRL_ALLOW_INBOUND_LIVMIN_ACCESS_MASK  0x80000000

#define MP1_SMNIF_SECURE_CTRL_MASK \
      (MP1_SMNIF_SECURE_CTRL_ALLOW_NONMP_SRAM_ACCESS_MASK | \
      MP1_SMNIF_SECURE_CTRL_BLOCK_SRAM_SPACE_MASK | \
      MP1_SMNIF_SECURE_CTRL_BLOCK_PRIV_SPACE_MASK | \
      MP1_SMNIF_SECURE_CTRL_ALLOW_RAM0_INITID_ACCESS_MASK | \
      MP1_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_MASK | \
      MP1_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_STATUS_MASK | \
      MP1_SMNIF_SECURE_CTRL_BLOCK_OUTBOUND_ACCESS_MASK | \
      MP1_SMNIF_SECURE_CTRL_ALLOW_INBOUND_LIVMIN_ACCESS_MASK)

#define MP1_SMNIF_SECURE_CTRL_DEFAULT  0x00000000

#define MP1_SMNIF_SECURE_CTRL_GET_ALLOW_NONMP_SRAM_ACCESS(mp1_smnif_secure_ctrl) \
      ((mp1_smnif_secure_ctrl & MP1_SMNIF_SECURE_CTRL_ALLOW_NONMP_SRAM_ACCESS_MASK) >> MP1_SMNIF_SECURE_CTRL_ALLOW_NONMP_SRAM_ACCESS_SHIFT)
#define MP1_SMNIF_SECURE_CTRL_GET_BLOCK_SRAM_SPACE(mp1_smnif_secure_ctrl) \
      ((mp1_smnif_secure_ctrl & MP1_SMNIF_SECURE_CTRL_BLOCK_SRAM_SPACE_MASK) >> MP1_SMNIF_SECURE_CTRL_BLOCK_SRAM_SPACE_SHIFT)
#define MP1_SMNIF_SECURE_CTRL_GET_BLOCK_PRIV_SPACE(mp1_smnif_secure_ctrl) \
      ((mp1_smnif_secure_ctrl & MP1_SMNIF_SECURE_CTRL_BLOCK_PRIV_SPACE_MASK) >> MP1_SMNIF_SECURE_CTRL_BLOCK_PRIV_SPACE_SHIFT)
#define MP1_SMNIF_SECURE_CTRL_GET_ALLOW_RAM0_INITID_ACCESS(mp1_smnif_secure_ctrl) \
      ((mp1_smnif_secure_ctrl & MP1_SMNIF_SECURE_CTRL_ALLOW_RAM0_INITID_ACCESS_MASK) >> MP1_SMNIF_SECURE_CTRL_ALLOW_RAM0_INITID_ACCESS_SHIFT)
#define MP1_SMNIF_SECURE_CTRL_GET_LOCK_SMNIF_FENCE(mp1_smnif_secure_ctrl) \
      ((mp1_smnif_secure_ctrl & MP1_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_MASK) >> MP1_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_SHIFT)
#define MP1_SMNIF_SECURE_CTRL_GET_LOCK_SMNIF_FENCE_STATUS(mp1_smnif_secure_ctrl) \
      ((mp1_smnif_secure_ctrl & MP1_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_STATUS_MASK) >> MP1_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_STATUS_SHIFT)
#define MP1_SMNIF_SECURE_CTRL_GET_BLOCK_OUTBOUND_ACCESS(mp1_smnif_secure_ctrl) \
      ((mp1_smnif_secure_ctrl & MP1_SMNIF_SECURE_CTRL_BLOCK_OUTBOUND_ACCESS_MASK) >> MP1_SMNIF_SECURE_CTRL_BLOCK_OUTBOUND_ACCESS_SHIFT)
#define MP1_SMNIF_SECURE_CTRL_GET_ALLOW_INBOUND_LIVMIN_ACCESS(mp1_smnif_secure_ctrl) \
      ((mp1_smnif_secure_ctrl & MP1_SMNIF_SECURE_CTRL_ALLOW_INBOUND_LIVMIN_ACCESS_MASK) >> MP1_SMNIF_SECURE_CTRL_ALLOW_INBOUND_LIVMIN_ACCESS_SHIFT)

#define MP1_SMNIF_SECURE_CTRL_SET_ALLOW_NONMP_SRAM_ACCESS(mp1_smnif_secure_ctrl_reg, allow_nonmp_sram_access) \
      mp1_smnif_secure_ctrl_reg = (mp1_smnif_secure_ctrl_reg & ~MP1_SMNIF_SECURE_CTRL_ALLOW_NONMP_SRAM_ACCESS_MASK) | (allow_nonmp_sram_access << MP1_SMNIF_SECURE_CTRL_ALLOW_NONMP_SRAM_ACCESS_SHIFT)
#define MP1_SMNIF_SECURE_CTRL_SET_BLOCK_SRAM_SPACE(mp1_smnif_secure_ctrl_reg, block_sram_space) \
      mp1_smnif_secure_ctrl_reg = (mp1_smnif_secure_ctrl_reg & ~MP1_SMNIF_SECURE_CTRL_BLOCK_SRAM_SPACE_MASK) | (block_sram_space << MP1_SMNIF_SECURE_CTRL_BLOCK_SRAM_SPACE_SHIFT)
#define MP1_SMNIF_SECURE_CTRL_SET_BLOCK_PRIV_SPACE(mp1_smnif_secure_ctrl_reg, block_priv_space) \
      mp1_smnif_secure_ctrl_reg = (mp1_smnif_secure_ctrl_reg & ~MP1_SMNIF_SECURE_CTRL_BLOCK_PRIV_SPACE_MASK) | (block_priv_space << MP1_SMNIF_SECURE_CTRL_BLOCK_PRIV_SPACE_SHIFT)
#define MP1_SMNIF_SECURE_CTRL_SET_ALLOW_RAM0_INITID_ACCESS(mp1_smnif_secure_ctrl_reg, allow_ram0_initid_access) \
      mp1_smnif_secure_ctrl_reg = (mp1_smnif_secure_ctrl_reg & ~MP1_SMNIF_SECURE_CTRL_ALLOW_RAM0_INITID_ACCESS_MASK) | (allow_ram0_initid_access << MP1_SMNIF_SECURE_CTRL_ALLOW_RAM0_INITID_ACCESS_SHIFT)
#define MP1_SMNIF_SECURE_CTRL_SET_LOCK_SMNIF_FENCE(mp1_smnif_secure_ctrl_reg, lock_smnif_fence) \
      mp1_smnif_secure_ctrl_reg = (mp1_smnif_secure_ctrl_reg & ~MP1_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_MASK) | (lock_smnif_fence << MP1_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_SHIFT)
#define MP1_SMNIF_SECURE_CTRL_SET_LOCK_SMNIF_FENCE_STATUS(mp1_smnif_secure_ctrl_reg, lock_smnif_fence_status) \
      mp1_smnif_secure_ctrl_reg = (mp1_smnif_secure_ctrl_reg & ~MP1_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_STATUS_MASK) | (lock_smnif_fence_status << MP1_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_STATUS_SHIFT)
#define MP1_SMNIF_SECURE_CTRL_SET_BLOCK_OUTBOUND_ACCESS(mp1_smnif_secure_ctrl_reg, block_outbound_access) \
      mp1_smnif_secure_ctrl_reg = (mp1_smnif_secure_ctrl_reg & ~MP1_SMNIF_SECURE_CTRL_BLOCK_OUTBOUND_ACCESS_MASK) | (block_outbound_access << MP1_SMNIF_SECURE_CTRL_BLOCK_OUTBOUND_ACCESS_SHIFT)
#define MP1_SMNIF_SECURE_CTRL_SET_ALLOW_INBOUND_LIVMIN_ACCESS(mp1_smnif_secure_ctrl_reg, allow_inbound_livmin_access) \
      mp1_smnif_secure_ctrl_reg = (mp1_smnif_secure_ctrl_reg & ~MP1_SMNIF_SECURE_CTRL_ALLOW_INBOUND_LIVMIN_ACCESS_MASK) | (allow_inbound_livmin_access << MP1_SMNIF_SECURE_CTRL_ALLOW_INBOUND_LIVMIN_ACCESS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_secure_ctrl_t {
            unsigned int allow_nonmp_sram_access        : MP1_SMNIF_SECURE_CTRL_ALLOW_NONMP_SRAM_ACCESS_SIZE;
            unsigned int block_sram_space               : MP1_SMNIF_SECURE_CTRL_BLOCK_SRAM_SPACE_SIZE;
            unsigned int block_priv_space               : MP1_SMNIF_SECURE_CTRL_BLOCK_PRIV_SPACE_SIZE;
            unsigned int                                : 3;
            unsigned int allow_ram0_initid_access       : MP1_SMNIF_SECURE_CTRL_ALLOW_RAM0_INITID_ACCESS_SIZE;
            unsigned int                                : 8;
            unsigned int lock_smnif_fence               : MP1_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_SIZE;
            unsigned int lock_smnif_fence_status        : MP1_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_STATUS_SIZE;
            unsigned int                                : 7;
            unsigned int block_outbound_access          : MP1_SMNIF_SECURE_CTRL_BLOCK_OUTBOUND_ACCESS_SIZE;
            unsigned int                                : 6;
            unsigned int allow_inbound_livmin_access    : MP1_SMNIF_SECURE_CTRL_ALLOW_INBOUND_LIVMIN_ACCESS_SIZE;
      } mp1_smnif_secure_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_secure_ctrl_t {
            unsigned int allow_inbound_livmin_access    : MP1_SMNIF_SECURE_CTRL_ALLOW_INBOUND_LIVMIN_ACCESS_SIZE;
            unsigned int                                : 6;
            unsigned int block_outbound_access          : MP1_SMNIF_SECURE_CTRL_BLOCK_OUTBOUND_ACCESS_SIZE;
            unsigned int                                : 7;
            unsigned int lock_smnif_fence_status        : MP1_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_STATUS_SIZE;
            unsigned int lock_smnif_fence               : MP1_SMNIF_SECURE_CTRL_LOCK_SMNIF_FENCE_SIZE;
            unsigned int                                : 8;
            unsigned int allow_ram0_initid_access       : MP1_SMNIF_SECURE_CTRL_ALLOW_RAM0_INITID_ACCESS_SIZE;
            unsigned int                                : 3;
            unsigned int block_priv_space               : MP1_SMNIF_SECURE_CTRL_BLOCK_PRIV_SPACE_SIZE;
            unsigned int block_sram_space               : MP1_SMNIF_SECURE_CTRL_BLOCK_SRAM_SPACE_SIZE;
            unsigned int allow_nonmp_sram_access        : MP1_SMNIF_SECURE_CTRL_ALLOW_NONMP_SRAM_ACCESS_SIZE;
      } mp1_smnif_secure_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_secure_ctrl_t f;
} mp1_smnif_secure_ctrl_u;


/*
 * MP1_SMNIF_TLVMASK_SECURE struct
 */

#define MP1_SMNIF_TLVMASK_SECURE_REG_SIZE         32
#define MP1_SMNIF_TLVMASK_SECURE_TLV0_MASK_SIZE  3
#define MP1_SMNIF_TLVMASK_SECURE_TLV1_MASK_SIZE  3
#define MP1_SMNIF_TLVMASK_SECURE_TLV2_MASK_SIZE  3
#define MP1_SMNIF_TLVMASK_SECURE_TLV3_MASK_SIZE  3
#define MP1_SMNIF_TLVMASK_SECURE_TLV4_MASK_SIZE  3
#define MP1_SMNIF_TLVMASK_SECURE_TLV5_MASK_SIZE  3
#define MP1_SMNIF_TLVMASK_SECURE_TLV6_MASK_SIZE  3
#define MP1_SMNIF_TLVMASK_SECURE_TLV7_MASK_SIZE  3

#define MP1_SMNIF_TLVMASK_SECURE_TLV0_MASK_SHIFT  0
#define MP1_SMNIF_TLVMASK_SECURE_TLV1_MASK_SHIFT  4
#define MP1_SMNIF_TLVMASK_SECURE_TLV2_MASK_SHIFT  8
#define MP1_SMNIF_TLVMASK_SECURE_TLV3_MASK_SHIFT  12
#define MP1_SMNIF_TLVMASK_SECURE_TLV4_MASK_SHIFT  16
#define MP1_SMNIF_TLVMASK_SECURE_TLV5_MASK_SHIFT  20
#define MP1_SMNIF_TLVMASK_SECURE_TLV6_MASK_SHIFT  24
#define MP1_SMNIF_TLVMASK_SECURE_TLV7_MASK_SHIFT  28

#define MP1_SMNIF_TLVMASK_SECURE_TLV0_MASK_MASK  0x00000007
#define MP1_SMNIF_TLVMASK_SECURE_TLV1_MASK_MASK  0x00000070
#define MP1_SMNIF_TLVMASK_SECURE_TLV2_MASK_MASK  0x00000700
#define MP1_SMNIF_TLVMASK_SECURE_TLV3_MASK_MASK  0x00007000
#define MP1_SMNIF_TLVMASK_SECURE_TLV4_MASK_MASK  0x00070000
#define MP1_SMNIF_TLVMASK_SECURE_TLV5_MASK_MASK  0x00700000
#define MP1_SMNIF_TLVMASK_SECURE_TLV6_MASK_MASK  0x07000000
#define MP1_SMNIF_TLVMASK_SECURE_TLV7_MASK_MASK  0x70000000

#define MP1_SMNIF_TLVMASK_SECURE_MASK \
      (MP1_SMNIF_TLVMASK_SECURE_TLV0_MASK_MASK | \
      MP1_SMNIF_TLVMASK_SECURE_TLV1_MASK_MASK | \
      MP1_SMNIF_TLVMASK_SECURE_TLV2_MASK_MASK | \
      MP1_SMNIF_TLVMASK_SECURE_TLV3_MASK_MASK | \
      MP1_SMNIF_TLVMASK_SECURE_TLV4_MASK_MASK | \
      MP1_SMNIF_TLVMASK_SECURE_TLV5_MASK_MASK | \
      MP1_SMNIF_TLVMASK_SECURE_TLV6_MASK_MASK | \
      MP1_SMNIF_TLVMASK_SECURE_TLV7_MASK_MASK)

#define MP1_SMNIF_TLVMASK_SECURE_DEFAULT 0x00000000

#define MP1_SMNIF_TLVMASK_SECURE_GET_TLV0_MASK(mp1_smnif_tlvmask_secure) \
      ((mp1_smnif_tlvmask_secure & MP1_SMNIF_TLVMASK_SECURE_TLV0_MASK_MASK) >> MP1_SMNIF_TLVMASK_SECURE_TLV0_MASK_SHIFT)
#define MP1_SMNIF_TLVMASK_SECURE_GET_TLV1_MASK(mp1_smnif_tlvmask_secure) \
      ((mp1_smnif_tlvmask_secure & MP1_SMNIF_TLVMASK_SECURE_TLV1_MASK_MASK) >> MP1_SMNIF_TLVMASK_SECURE_TLV1_MASK_SHIFT)
#define MP1_SMNIF_TLVMASK_SECURE_GET_TLV2_MASK(mp1_smnif_tlvmask_secure) \
      ((mp1_smnif_tlvmask_secure & MP1_SMNIF_TLVMASK_SECURE_TLV2_MASK_MASK) >> MP1_SMNIF_TLVMASK_SECURE_TLV2_MASK_SHIFT)
#define MP1_SMNIF_TLVMASK_SECURE_GET_TLV3_MASK(mp1_smnif_tlvmask_secure) \
      ((mp1_smnif_tlvmask_secure & MP1_SMNIF_TLVMASK_SECURE_TLV3_MASK_MASK) >> MP1_SMNIF_TLVMASK_SECURE_TLV3_MASK_SHIFT)
#define MP1_SMNIF_TLVMASK_SECURE_GET_TLV4_MASK(mp1_smnif_tlvmask_secure) \
      ((mp1_smnif_tlvmask_secure & MP1_SMNIF_TLVMASK_SECURE_TLV4_MASK_MASK) >> MP1_SMNIF_TLVMASK_SECURE_TLV4_MASK_SHIFT)
#define MP1_SMNIF_TLVMASK_SECURE_GET_TLV5_MASK(mp1_smnif_tlvmask_secure) \
      ((mp1_smnif_tlvmask_secure & MP1_SMNIF_TLVMASK_SECURE_TLV5_MASK_MASK) >> MP1_SMNIF_TLVMASK_SECURE_TLV5_MASK_SHIFT)
#define MP1_SMNIF_TLVMASK_SECURE_GET_TLV6_MASK(mp1_smnif_tlvmask_secure) \
      ((mp1_smnif_tlvmask_secure & MP1_SMNIF_TLVMASK_SECURE_TLV6_MASK_MASK) >> MP1_SMNIF_TLVMASK_SECURE_TLV6_MASK_SHIFT)
#define MP1_SMNIF_TLVMASK_SECURE_GET_TLV7_MASK(mp1_smnif_tlvmask_secure) \
      ((mp1_smnif_tlvmask_secure & MP1_SMNIF_TLVMASK_SECURE_TLV7_MASK_MASK) >> MP1_SMNIF_TLVMASK_SECURE_TLV7_MASK_SHIFT)

#define MP1_SMNIF_TLVMASK_SECURE_SET_TLV0_MASK(mp1_smnif_tlvmask_secure_reg, tlv0_mask) \
      mp1_smnif_tlvmask_secure_reg = (mp1_smnif_tlvmask_secure_reg & ~MP1_SMNIF_TLVMASK_SECURE_TLV0_MASK_MASK) | (tlv0_mask << MP1_SMNIF_TLVMASK_SECURE_TLV0_MASK_SHIFT)
#define MP1_SMNIF_TLVMASK_SECURE_SET_TLV1_MASK(mp1_smnif_tlvmask_secure_reg, tlv1_mask) \
      mp1_smnif_tlvmask_secure_reg = (mp1_smnif_tlvmask_secure_reg & ~MP1_SMNIF_TLVMASK_SECURE_TLV1_MASK_MASK) | (tlv1_mask << MP1_SMNIF_TLVMASK_SECURE_TLV1_MASK_SHIFT)
#define MP1_SMNIF_TLVMASK_SECURE_SET_TLV2_MASK(mp1_smnif_tlvmask_secure_reg, tlv2_mask) \
      mp1_smnif_tlvmask_secure_reg = (mp1_smnif_tlvmask_secure_reg & ~MP1_SMNIF_TLVMASK_SECURE_TLV2_MASK_MASK) | (tlv2_mask << MP1_SMNIF_TLVMASK_SECURE_TLV2_MASK_SHIFT)
#define MP1_SMNIF_TLVMASK_SECURE_SET_TLV3_MASK(mp1_smnif_tlvmask_secure_reg, tlv3_mask) \
      mp1_smnif_tlvmask_secure_reg = (mp1_smnif_tlvmask_secure_reg & ~MP1_SMNIF_TLVMASK_SECURE_TLV3_MASK_MASK) | (tlv3_mask << MP1_SMNIF_TLVMASK_SECURE_TLV3_MASK_SHIFT)
#define MP1_SMNIF_TLVMASK_SECURE_SET_TLV4_MASK(mp1_smnif_tlvmask_secure_reg, tlv4_mask) \
      mp1_smnif_tlvmask_secure_reg = (mp1_smnif_tlvmask_secure_reg & ~MP1_SMNIF_TLVMASK_SECURE_TLV4_MASK_MASK) | (tlv4_mask << MP1_SMNIF_TLVMASK_SECURE_TLV4_MASK_SHIFT)
#define MP1_SMNIF_TLVMASK_SECURE_SET_TLV5_MASK(mp1_smnif_tlvmask_secure_reg, tlv5_mask) \
      mp1_smnif_tlvmask_secure_reg = (mp1_smnif_tlvmask_secure_reg & ~MP1_SMNIF_TLVMASK_SECURE_TLV5_MASK_MASK) | (tlv5_mask << MP1_SMNIF_TLVMASK_SECURE_TLV5_MASK_SHIFT)
#define MP1_SMNIF_TLVMASK_SECURE_SET_TLV6_MASK(mp1_smnif_tlvmask_secure_reg, tlv6_mask) \
      mp1_smnif_tlvmask_secure_reg = (mp1_smnif_tlvmask_secure_reg & ~MP1_SMNIF_TLVMASK_SECURE_TLV6_MASK_MASK) | (tlv6_mask << MP1_SMNIF_TLVMASK_SECURE_TLV6_MASK_SHIFT)
#define MP1_SMNIF_TLVMASK_SECURE_SET_TLV7_MASK(mp1_smnif_tlvmask_secure_reg, tlv7_mask) \
      mp1_smnif_tlvmask_secure_reg = (mp1_smnif_tlvmask_secure_reg & ~MP1_SMNIF_TLVMASK_SECURE_TLV7_MASK_MASK) | (tlv7_mask << MP1_SMNIF_TLVMASK_SECURE_TLV7_MASK_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlvmask_secure_t {
            unsigned int tlv0_mask                      : MP1_SMNIF_TLVMASK_SECURE_TLV0_MASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv1_mask                      : MP1_SMNIF_TLVMASK_SECURE_TLV1_MASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv2_mask                      : MP1_SMNIF_TLVMASK_SECURE_TLV2_MASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv3_mask                      : MP1_SMNIF_TLVMASK_SECURE_TLV3_MASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv4_mask                      : MP1_SMNIF_TLVMASK_SECURE_TLV4_MASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv5_mask                      : MP1_SMNIF_TLVMASK_SECURE_TLV5_MASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv6_mask                      : MP1_SMNIF_TLVMASK_SECURE_TLV6_MASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv7_mask                      : MP1_SMNIF_TLVMASK_SECURE_TLV7_MASK_SIZE;
            unsigned int                                : 1;
      } mp1_smnif_tlvmask_secure_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlvmask_secure_t {
            unsigned int                                : 1;
            unsigned int tlv7_mask                      : MP1_SMNIF_TLVMASK_SECURE_TLV7_MASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv6_mask                      : MP1_SMNIF_TLVMASK_SECURE_TLV6_MASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv5_mask                      : MP1_SMNIF_TLVMASK_SECURE_TLV5_MASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv4_mask                      : MP1_SMNIF_TLVMASK_SECURE_TLV4_MASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv3_mask                      : MP1_SMNIF_TLVMASK_SECURE_TLV3_MASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv2_mask                      : MP1_SMNIF_TLVMASK_SECURE_TLV2_MASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv1_mask                      : MP1_SMNIF_TLVMASK_SECURE_TLV1_MASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv0_mask                      : MP1_SMNIF_TLVMASK_SECURE_TLV0_MASK_SIZE;
      } mp1_smnif_tlvmask_secure_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlvmask_secure_t f;
} mp1_smnif_tlvmask_secure_u;


/*
 * MP1_SMNIF_TLVMASK_NONSECURE struct
 */

#define MP1_SMNIF_TLVMASK_NONSECURE_REG_SIZE         32
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV0_NSMASK_SIZE  3
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV1_NSMASK_SIZE  3
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV2_NSMASK_SIZE  3
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV3_NSMASK_SIZE  3
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV4_NSMASK_SIZE  3
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV5_NSMASK_SIZE  3
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV6_NSMASK_SIZE  3
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV7_NSMASK_SIZE  3

#define MP1_SMNIF_TLVMASK_NONSECURE_TLV0_NSMASK_SHIFT  0
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV1_NSMASK_SHIFT  4
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV2_NSMASK_SHIFT  8
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV3_NSMASK_SHIFT  12
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV4_NSMASK_SHIFT  16
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV5_NSMASK_SHIFT  20
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV6_NSMASK_SHIFT  24
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV7_NSMASK_SHIFT  28

#define MP1_SMNIF_TLVMASK_NONSECURE_TLV0_NSMASK_MASK  0x00000007
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV1_NSMASK_MASK  0x00000070
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV2_NSMASK_MASK  0x00000700
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV3_NSMASK_MASK  0x00007000
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV4_NSMASK_MASK  0x00070000
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV5_NSMASK_MASK  0x00700000
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV6_NSMASK_MASK  0x07000000
#define MP1_SMNIF_TLVMASK_NONSECURE_TLV7_NSMASK_MASK  0x70000000

#define MP1_SMNIF_TLVMASK_NONSECURE_MASK \
      (MP1_SMNIF_TLVMASK_NONSECURE_TLV0_NSMASK_MASK | \
      MP1_SMNIF_TLVMASK_NONSECURE_TLV1_NSMASK_MASK | \
      MP1_SMNIF_TLVMASK_NONSECURE_TLV2_NSMASK_MASK | \
      MP1_SMNIF_TLVMASK_NONSECURE_TLV3_NSMASK_MASK | \
      MP1_SMNIF_TLVMASK_NONSECURE_TLV4_NSMASK_MASK | \
      MP1_SMNIF_TLVMASK_NONSECURE_TLV5_NSMASK_MASK | \
      MP1_SMNIF_TLVMASK_NONSECURE_TLV6_NSMASK_MASK | \
      MP1_SMNIF_TLVMASK_NONSECURE_TLV7_NSMASK_MASK)

#define MP1_SMNIF_TLVMASK_NONSECURE_DEFAULT 0x77777777

#define MP1_SMNIF_TLVMASK_NONSECURE_GET_TLV0_NSMASK(mp1_smnif_tlvmask_nonsecure) \
      ((mp1_smnif_tlvmask_nonsecure & MP1_SMNIF_TLVMASK_NONSECURE_TLV0_NSMASK_MASK) >> MP1_SMNIF_TLVMASK_NONSECURE_TLV0_NSMASK_SHIFT)
#define MP1_SMNIF_TLVMASK_NONSECURE_GET_TLV1_NSMASK(mp1_smnif_tlvmask_nonsecure) \
      ((mp1_smnif_tlvmask_nonsecure & MP1_SMNIF_TLVMASK_NONSECURE_TLV1_NSMASK_MASK) >> MP1_SMNIF_TLVMASK_NONSECURE_TLV1_NSMASK_SHIFT)
#define MP1_SMNIF_TLVMASK_NONSECURE_GET_TLV2_NSMASK(mp1_smnif_tlvmask_nonsecure) \
      ((mp1_smnif_tlvmask_nonsecure & MP1_SMNIF_TLVMASK_NONSECURE_TLV2_NSMASK_MASK) >> MP1_SMNIF_TLVMASK_NONSECURE_TLV2_NSMASK_SHIFT)
#define MP1_SMNIF_TLVMASK_NONSECURE_GET_TLV3_NSMASK(mp1_smnif_tlvmask_nonsecure) \
      ((mp1_smnif_tlvmask_nonsecure & MP1_SMNIF_TLVMASK_NONSECURE_TLV3_NSMASK_MASK) >> MP1_SMNIF_TLVMASK_NONSECURE_TLV3_NSMASK_SHIFT)
#define MP1_SMNIF_TLVMASK_NONSECURE_GET_TLV4_NSMASK(mp1_smnif_tlvmask_nonsecure) \
      ((mp1_smnif_tlvmask_nonsecure & MP1_SMNIF_TLVMASK_NONSECURE_TLV4_NSMASK_MASK) >> MP1_SMNIF_TLVMASK_NONSECURE_TLV4_NSMASK_SHIFT)
#define MP1_SMNIF_TLVMASK_NONSECURE_GET_TLV5_NSMASK(mp1_smnif_tlvmask_nonsecure) \
      ((mp1_smnif_tlvmask_nonsecure & MP1_SMNIF_TLVMASK_NONSECURE_TLV5_NSMASK_MASK) >> MP1_SMNIF_TLVMASK_NONSECURE_TLV5_NSMASK_SHIFT)
#define MP1_SMNIF_TLVMASK_NONSECURE_GET_TLV6_NSMASK(mp1_smnif_tlvmask_nonsecure) \
      ((mp1_smnif_tlvmask_nonsecure & MP1_SMNIF_TLVMASK_NONSECURE_TLV6_NSMASK_MASK) >> MP1_SMNIF_TLVMASK_NONSECURE_TLV6_NSMASK_SHIFT)
#define MP1_SMNIF_TLVMASK_NONSECURE_GET_TLV7_NSMASK(mp1_smnif_tlvmask_nonsecure) \
      ((mp1_smnif_tlvmask_nonsecure & MP1_SMNIF_TLVMASK_NONSECURE_TLV7_NSMASK_MASK) >> MP1_SMNIF_TLVMASK_NONSECURE_TLV7_NSMASK_SHIFT)

#define MP1_SMNIF_TLVMASK_NONSECURE_SET_TLV0_NSMASK(mp1_smnif_tlvmask_nonsecure_reg, tlv0_nsmask) \
      mp1_smnif_tlvmask_nonsecure_reg = (mp1_smnif_tlvmask_nonsecure_reg & ~MP1_SMNIF_TLVMASK_NONSECURE_TLV0_NSMASK_MASK) | (tlv0_nsmask << MP1_SMNIF_TLVMASK_NONSECURE_TLV0_NSMASK_SHIFT)
#define MP1_SMNIF_TLVMASK_NONSECURE_SET_TLV1_NSMASK(mp1_smnif_tlvmask_nonsecure_reg, tlv1_nsmask) \
      mp1_smnif_tlvmask_nonsecure_reg = (mp1_smnif_tlvmask_nonsecure_reg & ~MP1_SMNIF_TLVMASK_NONSECURE_TLV1_NSMASK_MASK) | (tlv1_nsmask << MP1_SMNIF_TLVMASK_NONSECURE_TLV1_NSMASK_SHIFT)
#define MP1_SMNIF_TLVMASK_NONSECURE_SET_TLV2_NSMASK(mp1_smnif_tlvmask_nonsecure_reg, tlv2_nsmask) \
      mp1_smnif_tlvmask_nonsecure_reg = (mp1_smnif_tlvmask_nonsecure_reg & ~MP1_SMNIF_TLVMASK_NONSECURE_TLV2_NSMASK_MASK) | (tlv2_nsmask << MP1_SMNIF_TLVMASK_NONSECURE_TLV2_NSMASK_SHIFT)
#define MP1_SMNIF_TLVMASK_NONSECURE_SET_TLV3_NSMASK(mp1_smnif_tlvmask_nonsecure_reg, tlv3_nsmask) \
      mp1_smnif_tlvmask_nonsecure_reg = (mp1_smnif_tlvmask_nonsecure_reg & ~MP1_SMNIF_TLVMASK_NONSECURE_TLV3_NSMASK_MASK) | (tlv3_nsmask << MP1_SMNIF_TLVMASK_NONSECURE_TLV3_NSMASK_SHIFT)
#define MP1_SMNIF_TLVMASK_NONSECURE_SET_TLV4_NSMASK(mp1_smnif_tlvmask_nonsecure_reg, tlv4_nsmask) \
      mp1_smnif_tlvmask_nonsecure_reg = (mp1_smnif_tlvmask_nonsecure_reg & ~MP1_SMNIF_TLVMASK_NONSECURE_TLV4_NSMASK_MASK) | (tlv4_nsmask << MP1_SMNIF_TLVMASK_NONSECURE_TLV4_NSMASK_SHIFT)
#define MP1_SMNIF_TLVMASK_NONSECURE_SET_TLV5_NSMASK(mp1_smnif_tlvmask_nonsecure_reg, tlv5_nsmask) \
      mp1_smnif_tlvmask_nonsecure_reg = (mp1_smnif_tlvmask_nonsecure_reg & ~MP1_SMNIF_TLVMASK_NONSECURE_TLV5_NSMASK_MASK) | (tlv5_nsmask << MP1_SMNIF_TLVMASK_NONSECURE_TLV5_NSMASK_SHIFT)
#define MP1_SMNIF_TLVMASK_NONSECURE_SET_TLV6_NSMASK(mp1_smnif_tlvmask_nonsecure_reg, tlv6_nsmask) \
      mp1_smnif_tlvmask_nonsecure_reg = (mp1_smnif_tlvmask_nonsecure_reg & ~MP1_SMNIF_TLVMASK_NONSECURE_TLV6_NSMASK_MASK) | (tlv6_nsmask << MP1_SMNIF_TLVMASK_NONSECURE_TLV6_NSMASK_SHIFT)
#define MP1_SMNIF_TLVMASK_NONSECURE_SET_TLV7_NSMASK(mp1_smnif_tlvmask_nonsecure_reg, tlv7_nsmask) \
      mp1_smnif_tlvmask_nonsecure_reg = (mp1_smnif_tlvmask_nonsecure_reg & ~MP1_SMNIF_TLVMASK_NONSECURE_TLV7_NSMASK_MASK) | (tlv7_nsmask << MP1_SMNIF_TLVMASK_NONSECURE_TLV7_NSMASK_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlvmask_nonsecure_t {
            unsigned int tlv0_nsmask                    : MP1_SMNIF_TLVMASK_NONSECURE_TLV0_NSMASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv1_nsmask                    : MP1_SMNIF_TLVMASK_NONSECURE_TLV1_NSMASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv2_nsmask                    : MP1_SMNIF_TLVMASK_NONSECURE_TLV2_NSMASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv3_nsmask                    : MP1_SMNIF_TLVMASK_NONSECURE_TLV3_NSMASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv4_nsmask                    : MP1_SMNIF_TLVMASK_NONSECURE_TLV4_NSMASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv5_nsmask                    : MP1_SMNIF_TLVMASK_NONSECURE_TLV5_NSMASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv6_nsmask                    : MP1_SMNIF_TLVMASK_NONSECURE_TLV6_NSMASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv7_nsmask                    : MP1_SMNIF_TLVMASK_NONSECURE_TLV7_NSMASK_SIZE;
            unsigned int                                : 1;
      } mp1_smnif_tlvmask_nonsecure_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlvmask_nonsecure_t {
            unsigned int                                : 1;
            unsigned int tlv7_nsmask                    : MP1_SMNIF_TLVMASK_NONSECURE_TLV7_NSMASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv6_nsmask                    : MP1_SMNIF_TLVMASK_NONSECURE_TLV6_NSMASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv5_nsmask                    : MP1_SMNIF_TLVMASK_NONSECURE_TLV5_NSMASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv4_nsmask                    : MP1_SMNIF_TLVMASK_NONSECURE_TLV4_NSMASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv3_nsmask                    : MP1_SMNIF_TLVMASK_NONSECURE_TLV3_NSMASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv2_nsmask                    : MP1_SMNIF_TLVMASK_NONSECURE_TLV2_NSMASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv1_nsmask                    : MP1_SMNIF_TLVMASK_NONSECURE_TLV1_NSMASK_SIZE;
            unsigned int                                : 1;
            unsigned int tlv0_nsmask                    : MP1_SMNIF_TLVMASK_NONSECURE_TLV0_NSMASK_SIZE;
      } mp1_smnif_tlvmask_nonsecure_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlvmask_nonsecure_t f;
} mp1_smnif_tlvmask_nonsecure_u;


/*
 * MP1_SMNIF_TLR_0 struct
 */

#define MP1_SMNIF_TLR_0_REG_SIZE         32
#define MP1_SMNIF_TLR_0_MASK_SIZE  8
#define MP1_SMNIF_TLR_0_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_0_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_0_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_0_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_0_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_0_VALID_SIZE  1

#define MP1_SMNIF_TLR_0_MASK_SHIFT  0
#define MP1_SMNIF_TLR_0_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_0_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_0_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_0_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_0_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_0_VALID_SHIFT  16

#define MP1_SMNIF_TLR_0_MASK_MASK       0x000000ff
#define MP1_SMNIF_TLR_0_RD_ACC_MASK     0x00000100
#define MP1_SMNIF_TLR_0_WR_ACC_MASK     0x00000200
#define MP1_SMNIF_TLR_0_SLV_ADDR_MASK   0x00003c00
#define MP1_SMNIF_TLR_0_VF_ACC_MASK     0x00004000
#define MP1_SMNIF_TLR_0_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_0_VALID_MASK      0x00010000

#define MP1_SMNIF_TLR_0_MASK \
      (MP1_SMNIF_TLR_0_MASK_MASK | \
      MP1_SMNIF_TLR_0_RD_ACC_MASK | \
      MP1_SMNIF_TLR_0_WR_ACC_MASK | \
      MP1_SMNIF_TLR_0_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_0_VF_ACC_MASK | \
      MP1_SMNIF_TLR_0_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_0_VALID_MASK)

#define MP1_SMNIF_TLR_0_DEFAULT        0x000103ff

#define MP1_SMNIF_TLR_0_GET_MASK(mp1_smnif_tlr_0) \
      ((mp1_smnif_tlr_0 & MP1_SMNIF_TLR_0_MASK_MASK) >> MP1_SMNIF_TLR_0_MASK_SHIFT)
#define MP1_SMNIF_TLR_0_GET_RD_ACC(mp1_smnif_tlr_0) \
      ((mp1_smnif_tlr_0 & MP1_SMNIF_TLR_0_RD_ACC_MASK) >> MP1_SMNIF_TLR_0_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_0_GET_WR_ACC(mp1_smnif_tlr_0) \
      ((mp1_smnif_tlr_0 & MP1_SMNIF_TLR_0_WR_ACC_MASK) >> MP1_SMNIF_TLR_0_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_0_GET_SLV_ADDR(mp1_smnif_tlr_0) \
      ((mp1_smnif_tlr_0 & MP1_SMNIF_TLR_0_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_0_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_0_GET_VF_ACC(mp1_smnif_tlr_0) \
      ((mp1_smnif_tlr_0 & MP1_SMNIF_TLR_0_VF_ACC_MASK) >> MP1_SMNIF_TLR_0_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_0_GET_VF_ACC_ENB(mp1_smnif_tlr_0) \
      ((mp1_smnif_tlr_0 & MP1_SMNIF_TLR_0_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_0_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_0_GET_VALID(mp1_smnif_tlr_0) \
      ((mp1_smnif_tlr_0 & MP1_SMNIF_TLR_0_VALID_MASK) >> MP1_SMNIF_TLR_0_VALID_SHIFT)

#define MP1_SMNIF_TLR_0_SET_MASK(mp1_smnif_tlr_0_reg, mask) \
      mp1_smnif_tlr_0_reg = (mp1_smnif_tlr_0_reg & ~MP1_SMNIF_TLR_0_MASK_MASK) | (mask << MP1_SMNIF_TLR_0_MASK_SHIFT)
#define MP1_SMNIF_TLR_0_SET_RD_ACC(mp1_smnif_tlr_0_reg, rd_acc) \
      mp1_smnif_tlr_0_reg = (mp1_smnif_tlr_0_reg & ~MP1_SMNIF_TLR_0_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_0_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_0_SET_WR_ACC(mp1_smnif_tlr_0_reg, wr_acc) \
      mp1_smnif_tlr_0_reg = (mp1_smnif_tlr_0_reg & ~MP1_SMNIF_TLR_0_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_0_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_0_SET_SLV_ADDR(mp1_smnif_tlr_0_reg, slv_addr) \
      mp1_smnif_tlr_0_reg = (mp1_smnif_tlr_0_reg & ~MP1_SMNIF_TLR_0_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_0_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_0_SET_VF_ACC(mp1_smnif_tlr_0_reg, vf_acc) \
      mp1_smnif_tlr_0_reg = (mp1_smnif_tlr_0_reg & ~MP1_SMNIF_TLR_0_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_0_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_0_SET_VF_ACC_ENB(mp1_smnif_tlr_0_reg, vf_acc_enb) \
      mp1_smnif_tlr_0_reg = (mp1_smnif_tlr_0_reg & ~MP1_SMNIF_TLR_0_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_0_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_0_SET_VALID(mp1_smnif_tlr_0_reg, valid) \
      mp1_smnif_tlr_0_reg = (mp1_smnif_tlr_0_reg & ~MP1_SMNIF_TLR_0_VALID_MASK) | (valid << MP1_SMNIF_TLR_0_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_0_t {
            unsigned int mask                           : MP1_SMNIF_TLR_0_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_0_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_0_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_0_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_0_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_0_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_0_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_0_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_0_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_0_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_0_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_0_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_0_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_0_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_0_MASK_SIZE;
      } mp1_smnif_tlr_0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_0_t f;
} mp1_smnif_tlr_0_u;


/*
 * MP1_SMNIF_TLR_ADDR_0 struct
 */

#define MP1_SMNIF_TLR_ADDR_0_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_0_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_0_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_0_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_0_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_0_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_0_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_0_MASK \
      (MP1_SMNIF_TLR_ADDR_0_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_0_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_0_DEFAULT   0xffff0000

#define MP1_SMNIF_TLR_ADDR_0_GET_START_ADDR(mp1_smnif_tlr_addr_0) \
      ((mp1_smnif_tlr_addr_0 & MP1_SMNIF_TLR_ADDR_0_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_0_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_0_GET_END_ADDR(mp1_smnif_tlr_addr_0) \
      ((mp1_smnif_tlr_addr_0 & MP1_SMNIF_TLR_ADDR_0_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_0_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_0_SET_START_ADDR(mp1_smnif_tlr_addr_0_reg, start_addr) \
      mp1_smnif_tlr_addr_0_reg = (mp1_smnif_tlr_addr_0_reg & ~MP1_SMNIF_TLR_ADDR_0_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_0_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_0_SET_END_ADDR(mp1_smnif_tlr_addr_0_reg, end_addr) \
      mp1_smnif_tlr_addr_0_reg = (mp1_smnif_tlr_addr_0_reg & ~MP1_SMNIF_TLR_ADDR_0_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_0_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_0_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_0_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_0_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_0_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_0_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_0_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_0_t f;
} mp1_smnif_tlr_addr_0_u;


/*
 * MP1_SMNIF_TLR_1 struct
 */

#define MP1_SMNIF_TLR_1_REG_SIZE         32
#define MP1_SMNIF_TLR_1_MASK_SIZE  8
#define MP1_SMNIF_TLR_1_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_1_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_1_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_1_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_1_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_1_VALID_SIZE  1

#define MP1_SMNIF_TLR_1_MASK_SHIFT  0
#define MP1_SMNIF_TLR_1_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_1_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_1_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_1_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_1_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_1_VALID_SHIFT  16

#define MP1_SMNIF_TLR_1_MASK_MASK       0x000000ff
#define MP1_SMNIF_TLR_1_RD_ACC_MASK     0x00000100
#define MP1_SMNIF_TLR_1_WR_ACC_MASK     0x00000200
#define MP1_SMNIF_TLR_1_SLV_ADDR_MASK   0x00003c00
#define MP1_SMNIF_TLR_1_VF_ACC_MASK     0x00004000
#define MP1_SMNIF_TLR_1_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_1_VALID_MASK      0x00010000

#define MP1_SMNIF_TLR_1_MASK \
      (MP1_SMNIF_TLR_1_MASK_MASK | \
      MP1_SMNIF_TLR_1_RD_ACC_MASK | \
      MP1_SMNIF_TLR_1_WR_ACC_MASK | \
      MP1_SMNIF_TLR_1_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_1_VF_ACC_MASK | \
      MP1_SMNIF_TLR_1_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_1_VALID_MASK)

#define MP1_SMNIF_TLR_1_DEFAULT        0x000107ff

#define MP1_SMNIF_TLR_1_GET_MASK(mp1_smnif_tlr_1) \
      ((mp1_smnif_tlr_1 & MP1_SMNIF_TLR_1_MASK_MASK) >> MP1_SMNIF_TLR_1_MASK_SHIFT)
#define MP1_SMNIF_TLR_1_GET_RD_ACC(mp1_smnif_tlr_1) \
      ((mp1_smnif_tlr_1 & MP1_SMNIF_TLR_1_RD_ACC_MASK) >> MP1_SMNIF_TLR_1_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_1_GET_WR_ACC(mp1_smnif_tlr_1) \
      ((mp1_smnif_tlr_1 & MP1_SMNIF_TLR_1_WR_ACC_MASK) >> MP1_SMNIF_TLR_1_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_1_GET_SLV_ADDR(mp1_smnif_tlr_1) \
      ((mp1_smnif_tlr_1 & MP1_SMNIF_TLR_1_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_1_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_1_GET_VF_ACC(mp1_smnif_tlr_1) \
      ((mp1_smnif_tlr_1 & MP1_SMNIF_TLR_1_VF_ACC_MASK) >> MP1_SMNIF_TLR_1_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_1_GET_VF_ACC_ENB(mp1_smnif_tlr_1) \
      ((mp1_smnif_tlr_1 & MP1_SMNIF_TLR_1_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_1_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_1_GET_VALID(mp1_smnif_tlr_1) \
      ((mp1_smnif_tlr_1 & MP1_SMNIF_TLR_1_VALID_MASK) >> MP1_SMNIF_TLR_1_VALID_SHIFT)

#define MP1_SMNIF_TLR_1_SET_MASK(mp1_smnif_tlr_1_reg, mask) \
      mp1_smnif_tlr_1_reg = (mp1_smnif_tlr_1_reg & ~MP1_SMNIF_TLR_1_MASK_MASK) | (mask << MP1_SMNIF_TLR_1_MASK_SHIFT)
#define MP1_SMNIF_TLR_1_SET_RD_ACC(mp1_smnif_tlr_1_reg, rd_acc) \
      mp1_smnif_tlr_1_reg = (mp1_smnif_tlr_1_reg & ~MP1_SMNIF_TLR_1_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_1_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_1_SET_WR_ACC(mp1_smnif_tlr_1_reg, wr_acc) \
      mp1_smnif_tlr_1_reg = (mp1_smnif_tlr_1_reg & ~MP1_SMNIF_TLR_1_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_1_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_1_SET_SLV_ADDR(mp1_smnif_tlr_1_reg, slv_addr) \
      mp1_smnif_tlr_1_reg = (mp1_smnif_tlr_1_reg & ~MP1_SMNIF_TLR_1_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_1_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_1_SET_VF_ACC(mp1_smnif_tlr_1_reg, vf_acc) \
      mp1_smnif_tlr_1_reg = (mp1_smnif_tlr_1_reg & ~MP1_SMNIF_TLR_1_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_1_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_1_SET_VF_ACC_ENB(mp1_smnif_tlr_1_reg, vf_acc_enb) \
      mp1_smnif_tlr_1_reg = (mp1_smnif_tlr_1_reg & ~MP1_SMNIF_TLR_1_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_1_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_1_SET_VALID(mp1_smnif_tlr_1_reg, valid) \
      mp1_smnif_tlr_1_reg = (mp1_smnif_tlr_1_reg & ~MP1_SMNIF_TLR_1_VALID_MASK) | (valid << MP1_SMNIF_TLR_1_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_1_t {
            unsigned int mask                           : MP1_SMNIF_TLR_1_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_1_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_1_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_1_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_1_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_1_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_1_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_1_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_1_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_1_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_1_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_1_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_1_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_1_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_1_MASK_SIZE;
      } mp1_smnif_tlr_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_1_t f;
} mp1_smnif_tlr_1_u;


/*
 * MP1_SMNIF_TLR_ADDR_1 struct
 */

#define MP1_SMNIF_TLR_ADDR_1_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_1_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_1_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_1_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_1_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_1_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_1_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_1_MASK \
      (MP1_SMNIF_TLR_ADDR_1_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_1_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_1_DEFAULT   0xffff0000

#define MP1_SMNIF_TLR_ADDR_1_GET_START_ADDR(mp1_smnif_tlr_addr_1) \
      ((mp1_smnif_tlr_addr_1 & MP1_SMNIF_TLR_ADDR_1_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_1_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_1_GET_END_ADDR(mp1_smnif_tlr_addr_1) \
      ((mp1_smnif_tlr_addr_1 & MP1_SMNIF_TLR_ADDR_1_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_1_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_1_SET_START_ADDR(mp1_smnif_tlr_addr_1_reg, start_addr) \
      mp1_smnif_tlr_addr_1_reg = (mp1_smnif_tlr_addr_1_reg & ~MP1_SMNIF_TLR_ADDR_1_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_1_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_1_SET_END_ADDR(mp1_smnif_tlr_addr_1_reg, end_addr) \
      mp1_smnif_tlr_addr_1_reg = (mp1_smnif_tlr_addr_1_reg & ~MP1_SMNIF_TLR_ADDR_1_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_1_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_1_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_1_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_1_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_1_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_1_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_1_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_1_t f;
} mp1_smnif_tlr_addr_1_u;


/*
 * MP1_SMNIF_TLR_2 struct
 */

#define MP1_SMNIF_TLR_2_REG_SIZE         32
#define MP1_SMNIF_TLR_2_MASK_SIZE  8
#define MP1_SMNIF_TLR_2_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_2_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_2_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_2_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_2_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_2_VALID_SIZE  1

#define MP1_SMNIF_TLR_2_MASK_SHIFT  0
#define MP1_SMNIF_TLR_2_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_2_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_2_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_2_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_2_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_2_VALID_SHIFT  16

#define MP1_SMNIF_TLR_2_MASK_MASK       0x000000ff
#define MP1_SMNIF_TLR_2_RD_ACC_MASK     0x00000100
#define MP1_SMNIF_TLR_2_WR_ACC_MASK     0x00000200
#define MP1_SMNIF_TLR_2_SLV_ADDR_MASK   0x00003c00
#define MP1_SMNIF_TLR_2_VF_ACC_MASK     0x00004000
#define MP1_SMNIF_TLR_2_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_2_VALID_MASK      0x00010000

#define MP1_SMNIF_TLR_2_MASK \
      (MP1_SMNIF_TLR_2_MASK_MASK | \
      MP1_SMNIF_TLR_2_RD_ACC_MASK | \
      MP1_SMNIF_TLR_2_WR_ACC_MASK | \
      MP1_SMNIF_TLR_2_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_2_VF_ACC_MASK | \
      MP1_SMNIF_TLR_2_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_2_VALID_MASK)

#define MP1_SMNIF_TLR_2_DEFAULT        0x00010bff

#define MP1_SMNIF_TLR_2_GET_MASK(mp1_smnif_tlr_2) \
      ((mp1_smnif_tlr_2 & MP1_SMNIF_TLR_2_MASK_MASK) >> MP1_SMNIF_TLR_2_MASK_SHIFT)
#define MP1_SMNIF_TLR_2_GET_RD_ACC(mp1_smnif_tlr_2) \
      ((mp1_smnif_tlr_2 & MP1_SMNIF_TLR_2_RD_ACC_MASK) >> MP1_SMNIF_TLR_2_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_2_GET_WR_ACC(mp1_smnif_tlr_2) \
      ((mp1_smnif_tlr_2 & MP1_SMNIF_TLR_2_WR_ACC_MASK) >> MP1_SMNIF_TLR_2_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_2_GET_SLV_ADDR(mp1_smnif_tlr_2) \
      ((mp1_smnif_tlr_2 & MP1_SMNIF_TLR_2_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_2_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_2_GET_VF_ACC(mp1_smnif_tlr_2) \
      ((mp1_smnif_tlr_2 & MP1_SMNIF_TLR_2_VF_ACC_MASK) >> MP1_SMNIF_TLR_2_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_2_GET_VF_ACC_ENB(mp1_smnif_tlr_2) \
      ((mp1_smnif_tlr_2 & MP1_SMNIF_TLR_2_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_2_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_2_GET_VALID(mp1_smnif_tlr_2) \
      ((mp1_smnif_tlr_2 & MP1_SMNIF_TLR_2_VALID_MASK) >> MP1_SMNIF_TLR_2_VALID_SHIFT)

#define MP1_SMNIF_TLR_2_SET_MASK(mp1_smnif_tlr_2_reg, mask) \
      mp1_smnif_tlr_2_reg = (mp1_smnif_tlr_2_reg & ~MP1_SMNIF_TLR_2_MASK_MASK) | (mask << MP1_SMNIF_TLR_2_MASK_SHIFT)
#define MP1_SMNIF_TLR_2_SET_RD_ACC(mp1_smnif_tlr_2_reg, rd_acc) \
      mp1_smnif_tlr_2_reg = (mp1_smnif_tlr_2_reg & ~MP1_SMNIF_TLR_2_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_2_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_2_SET_WR_ACC(mp1_smnif_tlr_2_reg, wr_acc) \
      mp1_smnif_tlr_2_reg = (mp1_smnif_tlr_2_reg & ~MP1_SMNIF_TLR_2_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_2_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_2_SET_SLV_ADDR(mp1_smnif_tlr_2_reg, slv_addr) \
      mp1_smnif_tlr_2_reg = (mp1_smnif_tlr_2_reg & ~MP1_SMNIF_TLR_2_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_2_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_2_SET_VF_ACC(mp1_smnif_tlr_2_reg, vf_acc) \
      mp1_smnif_tlr_2_reg = (mp1_smnif_tlr_2_reg & ~MP1_SMNIF_TLR_2_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_2_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_2_SET_VF_ACC_ENB(mp1_smnif_tlr_2_reg, vf_acc_enb) \
      mp1_smnif_tlr_2_reg = (mp1_smnif_tlr_2_reg & ~MP1_SMNIF_TLR_2_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_2_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_2_SET_VALID(mp1_smnif_tlr_2_reg, valid) \
      mp1_smnif_tlr_2_reg = (mp1_smnif_tlr_2_reg & ~MP1_SMNIF_TLR_2_VALID_MASK) | (valid << MP1_SMNIF_TLR_2_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_2_t {
            unsigned int mask                           : MP1_SMNIF_TLR_2_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_2_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_2_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_2_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_2_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_2_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_2_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_2_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_2_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_2_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_2_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_2_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_2_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_2_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_2_MASK_SIZE;
      } mp1_smnif_tlr_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_2_t f;
} mp1_smnif_tlr_2_u;


/*
 * MP1_SMNIF_TLR_ADDR_2 struct
 */

#define MP1_SMNIF_TLR_ADDR_2_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_2_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_2_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_2_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_2_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_2_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_2_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_2_MASK \
      (MP1_SMNIF_TLR_ADDR_2_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_2_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_2_DEFAULT   0xffff0000

#define MP1_SMNIF_TLR_ADDR_2_GET_START_ADDR(mp1_smnif_tlr_addr_2) \
      ((mp1_smnif_tlr_addr_2 & MP1_SMNIF_TLR_ADDR_2_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_2_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_2_GET_END_ADDR(mp1_smnif_tlr_addr_2) \
      ((mp1_smnif_tlr_addr_2 & MP1_SMNIF_TLR_ADDR_2_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_2_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_2_SET_START_ADDR(mp1_smnif_tlr_addr_2_reg, start_addr) \
      mp1_smnif_tlr_addr_2_reg = (mp1_smnif_tlr_addr_2_reg & ~MP1_SMNIF_TLR_ADDR_2_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_2_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_2_SET_END_ADDR(mp1_smnif_tlr_addr_2_reg, end_addr) \
      mp1_smnif_tlr_addr_2_reg = (mp1_smnif_tlr_addr_2_reg & ~MP1_SMNIF_TLR_ADDR_2_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_2_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_2_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_2_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_2_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_2_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_2_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_2_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_2_t f;
} mp1_smnif_tlr_addr_2_u;


/*
 * MP1_SMNIF_TLR_3 struct
 */

#define MP1_SMNIF_TLR_3_REG_SIZE         32
#define MP1_SMNIF_TLR_3_MASK_SIZE  8
#define MP1_SMNIF_TLR_3_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_3_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_3_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_3_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_3_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_3_VALID_SIZE  1

#define MP1_SMNIF_TLR_3_MASK_SHIFT  0
#define MP1_SMNIF_TLR_3_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_3_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_3_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_3_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_3_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_3_VALID_SHIFT  16

#define MP1_SMNIF_TLR_3_MASK_MASK       0x000000ff
#define MP1_SMNIF_TLR_3_RD_ACC_MASK     0x00000100
#define MP1_SMNIF_TLR_3_WR_ACC_MASK     0x00000200
#define MP1_SMNIF_TLR_3_SLV_ADDR_MASK   0x00003c00
#define MP1_SMNIF_TLR_3_VF_ACC_MASK     0x00004000
#define MP1_SMNIF_TLR_3_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_3_VALID_MASK      0x00010000

#define MP1_SMNIF_TLR_3_MASK \
      (MP1_SMNIF_TLR_3_MASK_MASK | \
      MP1_SMNIF_TLR_3_RD_ACC_MASK | \
      MP1_SMNIF_TLR_3_WR_ACC_MASK | \
      MP1_SMNIF_TLR_3_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_3_VF_ACC_MASK | \
      MP1_SMNIF_TLR_3_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_3_VALID_MASK)

#define MP1_SMNIF_TLR_3_DEFAULT        0x00010fff

#define MP1_SMNIF_TLR_3_GET_MASK(mp1_smnif_tlr_3) \
      ((mp1_smnif_tlr_3 & MP1_SMNIF_TLR_3_MASK_MASK) >> MP1_SMNIF_TLR_3_MASK_SHIFT)
#define MP1_SMNIF_TLR_3_GET_RD_ACC(mp1_smnif_tlr_3) \
      ((mp1_smnif_tlr_3 & MP1_SMNIF_TLR_3_RD_ACC_MASK) >> MP1_SMNIF_TLR_3_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_3_GET_WR_ACC(mp1_smnif_tlr_3) \
      ((mp1_smnif_tlr_3 & MP1_SMNIF_TLR_3_WR_ACC_MASK) >> MP1_SMNIF_TLR_3_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_3_GET_SLV_ADDR(mp1_smnif_tlr_3) \
      ((mp1_smnif_tlr_3 & MP1_SMNIF_TLR_3_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_3_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_3_GET_VF_ACC(mp1_smnif_tlr_3) \
      ((mp1_smnif_tlr_3 & MP1_SMNIF_TLR_3_VF_ACC_MASK) >> MP1_SMNIF_TLR_3_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_3_GET_VF_ACC_ENB(mp1_smnif_tlr_3) \
      ((mp1_smnif_tlr_3 & MP1_SMNIF_TLR_3_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_3_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_3_GET_VALID(mp1_smnif_tlr_3) \
      ((mp1_smnif_tlr_3 & MP1_SMNIF_TLR_3_VALID_MASK) >> MP1_SMNIF_TLR_3_VALID_SHIFT)

#define MP1_SMNIF_TLR_3_SET_MASK(mp1_smnif_tlr_3_reg, mask) \
      mp1_smnif_tlr_3_reg = (mp1_smnif_tlr_3_reg & ~MP1_SMNIF_TLR_3_MASK_MASK) | (mask << MP1_SMNIF_TLR_3_MASK_SHIFT)
#define MP1_SMNIF_TLR_3_SET_RD_ACC(mp1_smnif_tlr_3_reg, rd_acc) \
      mp1_smnif_tlr_3_reg = (mp1_smnif_tlr_3_reg & ~MP1_SMNIF_TLR_3_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_3_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_3_SET_WR_ACC(mp1_smnif_tlr_3_reg, wr_acc) \
      mp1_smnif_tlr_3_reg = (mp1_smnif_tlr_3_reg & ~MP1_SMNIF_TLR_3_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_3_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_3_SET_SLV_ADDR(mp1_smnif_tlr_3_reg, slv_addr) \
      mp1_smnif_tlr_3_reg = (mp1_smnif_tlr_3_reg & ~MP1_SMNIF_TLR_3_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_3_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_3_SET_VF_ACC(mp1_smnif_tlr_3_reg, vf_acc) \
      mp1_smnif_tlr_3_reg = (mp1_smnif_tlr_3_reg & ~MP1_SMNIF_TLR_3_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_3_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_3_SET_VF_ACC_ENB(mp1_smnif_tlr_3_reg, vf_acc_enb) \
      mp1_smnif_tlr_3_reg = (mp1_smnif_tlr_3_reg & ~MP1_SMNIF_TLR_3_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_3_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_3_SET_VALID(mp1_smnif_tlr_3_reg, valid) \
      mp1_smnif_tlr_3_reg = (mp1_smnif_tlr_3_reg & ~MP1_SMNIF_TLR_3_VALID_MASK) | (valid << MP1_SMNIF_TLR_3_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_3_t {
            unsigned int mask                           : MP1_SMNIF_TLR_3_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_3_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_3_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_3_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_3_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_3_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_3_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_3_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_3_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_3_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_3_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_3_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_3_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_3_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_3_MASK_SIZE;
      } mp1_smnif_tlr_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_3_t f;
} mp1_smnif_tlr_3_u;


/*
 * MP1_SMNIF_TLR_ADDR_3 struct
 */

#define MP1_SMNIF_TLR_ADDR_3_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_3_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_3_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_3_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_3_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_3_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_3_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_3_MASK \
      (MP1_SMNIF_TLR_ADDR_3_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_3_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_3_DEFAULT   0xffff0000

#define MP1_SMNIF_TLR_ADDR_3_GET_START_ADDR(mp1_smnif_tlr_addr_3) \
      ((mp1_smnif_tlr_addr_3 & MP1_SMNIF_TLR_ADDR_3_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_3_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_3_GET_END_ADDR(mp1_smnif_tlr_addr_3) \
      ((mp1_smnif_tlr_addr_3 & MP1_SMNIF_TLR_ADDR_3_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_3_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_3_SET_START_ADDR(mp1_smnif_tlr_addr_3_reg, start_addr) \
      mp1_smnif_tlr_addr_3_reg = (mp1_smnif_tlr_addr_3_reg & ~MP1_SMNIF_TLR_ADDR_3_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_3_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_3_SET_END_ADDR(mp1_smnif_tlr_addr_3_reg, end_addr) \
      mp1_smnif_tlr_addr_3_reg = (mp1_smnif_tlr_addr_3_reg & ~MP1_SMNIF_TLR_ADDR_3_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_3_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_3_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_3_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_3_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_3_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_3_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_3_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_3_t f;
} mp1_smnif_tlr_addr_3_u;


/*
 * MP1_SMNIF_TLR_4 struct
 */

#define MP1_SMNIF_TLR_4_REG_SIZE         32
#define MP1_SMNIF_TLR_4_MASK_SIZE  8
#define MP1_SMNIF_TLR_4_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_4_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_4_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_4_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_4_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_4_VALID_SIZE  1

#define MP1_SMNIF_TLR_4_MASK_SHIFT  0
#define MP1_SMNIF_TLR_4_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_4_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_4_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_4_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_4_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_4_VALID_SHIFT  16

#define MP1_SMNIF_TLR_4_MASK_MASK       0x000000ff
#define MP1_SMNIF_TLR_4_RD_ACC_MASK     0x00000100
#define MP1_SMNIF_TLR_4_WR_ACC_MASK     0x00000200
#define MP1_SMNIF_TLR_4_SLV_ADDR_MASK   0x00003c00
#define MP1_SMNIF_TLR_4_VF_ACC_MASK     0x00004000
#define MP1_SMNIF_TLR_4_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_4_VALID_MASK      0x00010000

#define MP1_SMNIF_TLR_4_MASK \
      (MP1_SMNIF_TLR_4_MASK_MASK | \
      MP1_SMNIF_TLR_4_RD_ACC_MASK | \
      MP1_SMNIF_TLR_4_WR_ACC_MASK | \
      MP1_SMNIF_TLR_4_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_4_VF_ACC_MASK | \
      MP1_SMNIF_TLR_4_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_4_VALID_MASK)

#define MP1_SMNIF_TLR_4_DEFAULT        0x000113ff

#define MP1_SMNIF_TLR_4_GET_MASK(mp1_smnif_tlr_4) \
      ((mp1_smnif_tlr_4 & MP1_SMNIF_TLR_4_MASK_MASK) >> MP1_SMNIF_TLR_4_MASK_SHIFT)
#define MP1_SMNIF_TLR_4_GET_RD_ACC(mp1_smnif_tlr_4) \
      ((mp1_smnif_tlr_4 & MP1_SMNIF_TLR_4_RD_ACC_MASK) >> MP1_SMNIF_TLR_4_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_4_GET_WR_ACC(mp1_smnif_tlr_4) \
      ((mp1_smnif_tlr_4 & MP1_SMNIF_TLR_4_WR_ACC_MASK) >> MP1_SMNIF_TLR_4_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_4_GET_SLV_ADDR(mp1_smnif_tlr_4) \
      ((mp1_smnif_tlr_4 & MP1_SMNIF_TLR_4_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_4_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_4_GET_VF_ACC(mp1_smnif_tlr_4) \
      ((mp1_smnif_tlr_4 & MP1_SMNIF_TLR_4_VF_ACC_MASK) >> MP1_SMNIF_TLR_4_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_4_GET_VF_ACC_ENB(mp1_smnif_tlr_4) \
      ((mp1_smnif_tlr_4 & MP1_SMNIF_TLR_4_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_4_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_4_GET_VALID(mp1_smnif_tlr_4) \
      ((mp1_smnif_tlr_4 & MP1_SMNIF_TLR_4_VALID_MASK) >> MP1_SMNIF_TLR_4_VALID_SHIFT)

#define MP1_SMNIF_TLR_4_SET_MASK(mp1_smnif_tlr_4_reg, mask) \
      mp1_smnif_tlr_4_reg = (mp1_smnif_tlr_4_reg & ~MP1_SMNIF_TLR_4_MASK_MASK) | (mask << MP1_SMNIF_TLR_4_MASK_SHIFT)
#define MP1_SMNIF_TLR_4_SET_RD_ACC(mp1_smnif_tlr_4_reg, rd_acc) \
      mp1_smnif_tlr_4_reg = (mp1_smnif_tlr_4_reg & ~MP1_SMNIF_TLR_4_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_4_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_4_SET_WR_ACC(mp1_smnif_tlr_4_reg, wr_acc) \
      mp1_smnif_tlr_4_reg = (mp1_smnif_tlr_4_reg & ~MP1_SMNIF_TLR_4_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_4_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_4_SET_SLV_ADDR(mp1_smnif_tlr_4_reg, slv_addr) \
      mp1_smnif_tlr_4_reg = (mp1_smnif_tlr_4_reg & ~MP1_SMNIF_TLR_4_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_4_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_4_SET_VF_ACC(mp1_smnif_tlr_4_reg, vf_acc) \
      mp1_smnif_tlr_4_reg = (mp1_smnif_tlr_4_reg & ~MP1_SMNIF_TLR_4_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_4_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_4_SET_VF_ACC_ENB(mp1_smnif_tlr_4_reg, vf_acc_enb) \
      mp1_smnif_tlr_4_reg = (mp1_smnif_tlr_4_reg & ~MP1_SMNIF_TLR_4_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_4_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_4_SET_VALID(mp1_smnif_tlr_4_reg, valid) \
      mp1_smnif_tlr_4_reg = (mp1_smnif_tlr_4_reg & ~MP1_SMNIF_TLR_4_VALID_MASK) | (valid << MP1_SMNIF_TLR_4_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_4_t {
            unsigned int mask                           : MP1_SMNIF_TLR_4_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_4_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_4_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_4_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_4_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_4_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_4_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_4_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_4_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_4_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_4_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_4_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_4_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_4_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_4_MASK_SIZE;
      } mp1_smnif_tlr_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_4_t f;
} mp1_smnif_tlr_4_u;


/*
 * MP1_SMNIF_TLR_ADDR_4 struct
 */

#define MP1_SMNIF_TLR_ADDR_4_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_4_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_4_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_4_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_4_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_4_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_4_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_4_MASK \
      (MP1_SMNIF_TLR_ADDR_4_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_4_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_4_DEFAULT   0xffff0000

#define MP1_SMNIF_TLR_ADDR_4_GET_START_ADDR(mp1_smnif_tlr_addr_4) \
      ((mp1_smnif_tlr_addr_4 & MP1_SMNIF_TLR_ADDR_4_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_4_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_4_GET_END_ADDR(mp1_smnif_tlr_addr_4) \
      ((mp1_smnif_tlr_addr_4 & MP1_SMNIF_TLR_ADDR_4_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_4_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_4_SET_START_ADDR(mp1_smnif_tlr_addr_4_reg, start_addr) \
      mp1_smnif_tlr_addr_4_reg = (mp1_smnif_tlr_addr_4_reg & ~MP1_SMNIF_TLR_ADDR_4_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_4_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_4_SET_END_ADDR(mp1_smnif_tlr_addr_4_reg, end_addr) \
      mp1_smnif_tlr_addr_4_reg = (mp1_smnif_tlr_addr_4_reg & ~MP1_SMNIF_TLR_ADDR_4_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_4_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_4_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_4_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_4_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_4_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_4_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_4_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_4_t f;
} mp1_smnif_tlr_addr_4_u;


/*
 * MP1_SMNIF_TLR_5 struct
 */

#define MP1_SMNIF_TLR_5_REG_SIZE         32
#define MP1_SMNIF_TLR_5_MASK_SIZE  8
#define MP1_SMNIF_TLR_5_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_5_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_5_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_5_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_5_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_5_VALID_SIZE  1

#define MP1_SMNIF_TLR_5_MASK_SHIFT  0
#define MP1_SMNIF_TLR_5_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_5_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_5_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_5_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_5_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_5_VALID_SHIFT  16

#define MP1_SMNIF_TLR_5_MASK_MASK       0x000000ff
#define MP1_SMNIF_TLR_5_RD_ACC_MASK     0x00000100
#define MP1_SMNIF_TLR_5_WR_ACC_MASK     0x00000200
#define MP1_SMNIF_TLR_5_SLV_ADDR_MASK   0x00003c00
#define MP1_SMNIF_TLR_5_VF_ACC_MASK     0x00004000
#define MP1_SMNIF_TLR_5_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_5_VALID_MASK      0x00010000

#define MP1_SMNIF_TLR_5_MASK \
      (MP1_SMNIF_TLR_5_MASK_MASK | \
      MP1_SMNIF_TLR_5_RD_ACC_MASK | \
      MP1_SMNIF_TLR_5_WR_ACC_MASK | \
      MP1_SMNIF_TLR_5_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_5_VF_ACC_MASK | \
      MP1_SMNIF_TLR_5_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_5_VALID_MASK)

#define MP1_SMNIF_TLR_5_DEFAULT        0x000117ff

#define MP1_SMNIF_TLR_5_GET_MASK(mp1_smnif_tlr_5) \
      ((mp1_smnif_tlr_5 & MP1_SMNIF_TLR_5_MASK_MASK) >> MP1_SMNIF_TLR_5_MASK_SHIFT)
#define MP1_SMNIF_TLR_5_GET_RD_ACC(mp1_smnif_tlr_5) \
      ((mp1_smnif_tlr_5 & MP1_SMNIF_TLR_5_RD_ACC_MASK) >> MP1_SMNIF_TLR_5_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_5_GET_WR_ACC(mp1_smnif_tlr_5) \
      ((mp1_smnif_tlr_5 & MP1_SMNIF_TLR_5_WR_ACC_MASK) >> MP1_SMNIF_TLR_5_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_5_GET_SLV_ADDR(mp1_smnif_tlr_5) \
      ((mp1_smnif_tlr_5 & MP1_SMNIF_TLR_5_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_5_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_5_GET_VF_ACC(mp1_smnif_tlr_5) \
      ((mp1_smnif_tlr_5 & MP1_SMNIF_TLR_5_VF_ACC_MASK) >> MP1_SMNIF_TLR_5_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_5_GET_VF_ACC_ENB(mp1_smnif_tlr_5) \
      ((mp1_smnif_tlr_5 & MP1_SMNIF_TLR_5_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_5_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_5_GET_VALID(mp1_smnif_tlr_5) \
      ((mp1_smnif_tlr_5 & MP1_SMNIF_TLR_5_VALID_MASK) >> MP1_SMNIF_TLR_5_VALID_SHIFT)

#define MP1_SMNIF_TLR_5_SET_MASK(mp1_smnif_tlr_5_reg, mask) \
      mp1_smnif_tlr_5_reg = (mp1_smnif_tlr_5_reg & ~MP1_SMNIF_TLR_5_MASK_MASK) | (mask << MP1_SMNIF_TLR_5_MASK_SHIFT)
#define MP1_SMNIF_TLR_5_SET_RD_ACC(mp1_smnif_tlr_5_reg, rd_acc) \
      mp1_smnif_tlr_5_reg = (mp1_smnif_tlr_5_reg & ~MP1_SMNIF_TLR_5_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_5_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_5_SET_WR_ACC(mp1_smnif_tlr_5_reg, wr_acc) \
      mp1_smnif_tlr_5_reg = (mp1_smnif_tlr_5_reg & ~MP1_SMNIF_TLR_5_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_5_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_5_SET_SLV_ADDR(mp1_smnif_tlr_5_reg, slv_addr) \
      mp1_smnif_tlr_5_reg = (mp1_smnif_tlr_5_reg & ~MP1_SMNIF_TLR_5_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_5_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_5_SET_VF_ACC(mp1_smnif_tlr_5_reg, vf_acc) \
      mp1_smnif_tlr_5_reg = (mp1_smnif_tlr_5_reg & ~MP1_SMNIF_TLR_5_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_5_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_5_SET_VF_ACC_ENB(mp1_smnif_tlr_5_reg, vf_acc_enb) \
      mp1_smnif_tlr_5_reg = (mp1_smnif_tlr_5_reg & ~MP1_SMNIF_TLR_5_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_5_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_5_SET_VALID(mp1_smnif_tlr_5_reg, valid) \
      mp1_smnif_tlr_5_reg = (mp1_smnif_tlr_5_reg & ~MP1_SMNIF_TLR_5_VALID_MASK) | (valid << MP1_SMNIF_TLR_5_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_5_t {
            unsigned int mask                           : MP1_SMNIF_TLR_5_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_5_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_5_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_5_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_5_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_5_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_5_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_5_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_5_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_5_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_5_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_5_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_5_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_5_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_5_MASK_SIZE;
      } mp1_smnif_tlr_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_5_t f;
} mp1_smnif_tlr_5_u;


/*
 * MP1_SMNIF_TLR_ADDR_5 struct
 */

#define MP1_SMNIF_TLR_ADDR_5_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_5_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_5_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_5_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_5_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_5_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_5_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_5_MASK \
      (MP1_SMNIF_TLR_ADDR_5_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_5_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_5_DEFAULT   0xffff0000

#define MP1_SMNIF_TLR_ADDR_5_GET_START_ADDR(mp1_smnif_tlr_addr_5) \
      ((mp1_smnif_tlr_addr_5 & MP1_SMNIF_TLR_ADDR_5_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_5_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_5_GET_END_ADDR(mp1_smnif_tlr_addr_5) \
      ((mp1_smnif_tlr_addr_5 & MP1_SMNIF_TLR_ADDR_5_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_5_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_5_SET_START_ADDR(mp1_smnif_tlr_addr_5_reg, start_addr) \
      mp1_smnif_tlr_addr_5_reg = (mp1_smnif_tlr_addr_5_reg & ~MP1_SMNIF_TLR_ADDR_5_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_5_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_5_SET_END_ADDR(mp1_smnif_tlr_addr_5_reg, end_addr) \
      mp1_smnif_tlr_addr_5_reg = (mp1_smnif_tlr_addr_5_reg & ~MP1_SMNIF_TLR_ADDR_5_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_5_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_5_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_5_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_5_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_5_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_5_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_5_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_5_t f;
} mp1_smnif_tlr_addr_5_u;


/*
 * MP1_SMNIF_TLR_6 struct
 */

#define MP1_SMNIF_TLR_6_REG_SIZE         32
#define MP1_SMNIF_TLR_6_MASK_SIZE  8
#define MP1_SMNIF_TLR_6_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_6_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_6_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_6_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_6_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_6_VALID_SIZE  1

#define MP1_SMNIF_TLR_6_MASK_SHIFT  0
#define MP1_SMNIF_TLR_6_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_6_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_6_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_6_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_6_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_6_VALID_SHIFT  16

#define MP1_SMNIF_TLR_6_MASK_MASK       0x000000ff
#define MP1_SMNIF_TLR_6_RD_ACC_MASK     0x00000100
#define MP1_SMNIF_TLR_6_WR_ACC_MASK     0x00000200
#define MP1_SMNIF_TLR_6_SLV_ADDR_MASK   0x00003c00
#define MP1_SMNIF_TLR_6_VF_ACC_MASK     0x00004000
#define MP1_SMNIF_TLR_6_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_6_VALID_MASK      0x00010000

#define MP1_SMNIF_TLR_6_MASK \
      (MP1_SMNIF_TLR_6_MASK_MASK | \
      MP1_SMNIF_TLR_6_RD_ACC_MASK | \
      MP1_SMNIF_TLR_6_WR_ACC_MASK | \
      MP1_SMNIF_TLR_6_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_6_VF_ACC_MASK | \
      MP1_SMNIF_TLR_6_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_6_VALID_MASK)

#define MP1_SMNIF_TLR_6_DEFAULT        0x00011bff

#define MP1_SMNIF_TLR_6_GET_MASK(mp1_smnif_tlr_6) \
      ((mp1_smnif_tlr_6 & MP1_SMNIF_TLR_6_MASK_MASK) >> MP1_SMNIF_TLR_6_MASK_SHIFT)
#define MP1_SMNIF_TLR_6_GET_RD_ACC(mp1_smnif_tlr_6) \
      ((mp1_smnif_tlr_6 & MP1_SMNIF_TLR_6_RD_ACC_MASK) >> MP1_SMNIF_TLR_6_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_6_GET_WR_ACC(mp1_smnif_tlr_6) \
      ((mp1_smnif_tlr_6 & MP1_SMNIF_TLR_6_WR_ACC_MASK) >> MP1_SMNIF_TLR_6_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_6_GET_SLV_ADDR(mp1_smnif_tlr_6) \
      ((mp1_smnif_tlr_6 & MP1_SMNIF_TLR_6_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_6_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_6_GET_VF_ACC(mp1_smnif_tlr_6) \
      ((mp1_smnif_tlr_6 & MP1_SMNIF_TLR_6_VF_ACC_MASK) >> MP1_SMNIF_TLR_6_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_6_GET_VF_ACC_ENB(mp1_smnif_tlr_6) \
      ((mp1_smnif_tlr_6 & MP1_SMNIF_TLR_6_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_6_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_6_GET_VALID(mp1_smnif_tlr_6) \
      ((mp1_smnif_tlr_6 & MP1_SMNIF_TLR_6_VALID_MASK) >> MP1_SMNIF_TLR_6_VALID_SHIFT)

#define MP1_SMNIF_TLR_6_SET_MASK(mp1_smnif_tlr_6_reg, mask) \
      mp1_smnif_tlr_6_reg = (mp1_smnif_tlr_6_reg & ~MP1_SMNIF_TLR_6_MASK_MASK) | (mask << MP1_SMNIF_TLR_6_MASK_SHIFT)
#define MP1_SMNIF_TLR_6_SET_RD_ACC(mp1_smnif_tlr_6_reg, rd_acc) \
      mp1_smnif_tlr_6_reg = (mp1_smnif_tlr_6_reg & ~MP1_SMNIF_TLR_6_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_6_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_6_SET_WR_ACC(mp1_smnif_tlr_6_reg, wr_acc) \
      mp1_smnif_tlr_6_reg = (mp1_smnif_tlr_6_reg & ~MP1_SMNIF_TLR_6_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_6_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_6_SET_SLV_ADDR(mp1_smnif_tlr_6_reg, slv_addr) \
      mp1_smnif_tlr_6_reg = (mp1_smnif_tlr_6_reg & ~MP1_SMNIF_TLR_6_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_6_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_6_SET_VF_ACC(mp1_smnif_tlr_6_reg, vf_acc) \
      mp1_smnif_tlr_6_reg = (mp1_smnif_tlr_6_reg & ~MP1_SMNIF_TLR_6_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_6_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_6_SET_VF_ACC_ENB(mp1_smnif_tlr_6_reg, vf_acc_enb) \
      mp1_smnif_tlr_6_reg = (mp1_smnif_tlr_6_reg & ~MP1_SMNIF_TLR_6_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_6_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_6_SET_VALID(mp1_smnif_tlr_6_reg, valid) \
      mp1_smnif_tlr_6_reg = (mp1_smnif_tlr_6_reg & ~MP1_SMNIF_TLR_6_VALID_MASK) | (valid << MP1_SMNIF_TLR_6_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_6_t {
            unsigned int mask                           : MP1_SMNIF_TLR_6_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_6_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_6_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_6_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_6_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_6_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_6_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_6_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_6_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_6_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_6_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_6_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_6_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_6_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_6_MASK_SIZE;
      } mp1_smnif_tlr_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_6_t f;
} mp1_smnif_tlr_6_u;


/*
 * MP1_SMNIF_TLR_ADDR_6 struct
 */

#define MP1_SMNIF_TLR_ADDR_6_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_6_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_6_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_6_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_6_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_6_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_6_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_6_MASK \
      (MP1_SMNIF_TLR_ADDR_6_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_6_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_6_DEFAULT   0xffff0000

#define MP1_SMNIF_TLR_ADDR_6_GET_START_ADDR(mp1_smnif_tlr_addr_6) \
      ((mp1_smnif_tlr_addr_6 & MP1_SMNIF_TLR_ADDR_6_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_6_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_6_GET_END_ADDR(mp1_smnif_tlr_addr_6) \
      ((mp1_smnif_tlr_addr_6 & MP1_SMNIF_TLR_ADDR_6_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_6_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_6_SET_START_ADDR(mp1_smnif_tlr_addr_6_reg, start_addr) \
      mp1_smnif_tlr_addr_6_reg = (mp1_smnif_tlr_addr_6_reg & ~MP1_SMNIF_TLR_ADDR_6_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_6_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_6_SET_END_ADDR(mp1_smnif_tlr_addr_6_reg, end_addr) \
      mp1_smnif_tlr_addr_6_reg = (mp1_smnif_tlr_addr_6_reg & ~MP1_SMNIF_TLR_ADDR_6_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_6_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_6_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_6_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_6_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_6_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_6_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_6_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_6_t f;
} mp1_smnif_tlr_addr_6_u;


/*
 * MP1_SMNIF_TLR_7 struct
 */

#define MP1_SMNIF_TLR_7_REG_SIZE         32
#define MP1_SMNIF_TLR_7_MASK_SIZE  8
#define MP1_SMNIF_TLR_7_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_7_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_7_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_7_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_7_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_7_VALID_SIZE  1

#define MP1_SMNIF_TLR_7_MASK_SHIFT  0
#define MP1_SMNIF_TLR_7_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_7_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_7_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_7_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_7_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_7_VALID_SHIFT  16

#define MP1_SMNIF_TLR_7_MASK_MASK       0x000000ff
#define MP1_SMNIF_TLR_7_RD_ACC_MASK     0x00000100
#define MP1_SMNIF_TLR_7_WR_ACC_MASK     0x00000200
#define MP1_SMNIF_TLR_7_SLV_ADDR_MASK   0x00003c00
#define MP1_SMNIF_TLR_7_VF_ACC_MASK     0x00004000
#define MP1_SMNIF_TLR_7_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_7_VALID_MASK      0x00010000

#define MP1_SMNIF_TLR_7_MASK \
      (MP1_SMNIF_TLR_7_MASK_MASK | \
      MP1_SMNIF_TLR_7_RD_ACC_MASK | \
      MP1_SMNIF_TLR_7_WR_ACC_MASK | \
      MP1_SMNIF_TLR_7_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_7_VF_ACC_MASK | \
      MP1_SMNIF_TLR_7_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_7_VALID_MASK)

#define MP1_SMNIF_TLR_7_DEFAULT        0x00011fff

#define MP1_SMNIF_TLR_7_GET_MASK(mp1_smnif_tlr_7) \
      ((mp1_smnif_tlr_7 & MP1_SMNIF_TLR_7_MASK_MASK) >> MP1_SMNIF_TLR_7_MASK_SHIFT)
#define MP1_SMNIF_TLR_7_GET_RD_ACC(mp1_smnif_tlr_7) \
      ((mp1_smnif_tlr_7 & MP1_SMNIF_TLR_7_RD_ACC_MASK) >> MP1_SMNIF_TLR_7_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_7_GET_WR_ACC(mp1_smnif_tlr_7) \
      ((mp1_smnif_tlr_7 & MP1_SMNIF_TLR_7_WR_ACC_MASK) >> MP1_SMNIF_TLR_7_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_7_GET_SLV_ADDR(mp1_smnif_tlr_7) \
      ((mp1_smnif_tlr_7 & MP1_SMNIF_TLR_7_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_7_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_7_GET_VF_ACC(mp1_smnif_tlr_7) \
      ((mp1_smnif_tlr_7 & MP1_SMNIF_TLR_7_VF_ACC_MASK) >> MP1_SMNIF_TLR_7_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_7_GET_VF_ACC_ENB(mp1_smnif_tlr_7) \
      ((mp1_smnif_tlr_7 & MP1_SMNIF_TLR_7_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_7_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_7_GET_VALID(mp1_smnif_tlr_7) \
      ((mp1_smnif_tlr_7 & MP1_SMNIF_TLR_7_VALID_MASK) >> MP1_SMNIF_TLR_7_VALID_SHIFT)

#define MP1_SMNIF_TLR_7_SET_MASK(mp1_smnif_tlr_7_reg, mask) \
      mp1_smnif_tlr_7_reg = (mp1_smnif_tlr_7_reg & ~MP1_SMNIF_TLR_7_MASK_MASK) | (mask << MP1_SMNIF_TLR_7_MASK_SHIFT)
#define MP1_SMNIF_TLR_7_SET_RD_ACC(mp1_smnif_tlr_7_reg, rd_acc) \
      mp1_smnif_tlr_7_reg = (mp1_smnif_tlr_7_reg & ~MP1_SMNIF_TLR_7_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_7_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_7_SET_WR_ACC(mp1_smnif_tlr_7_reg, wr_acc) \
      mp1_smnif_tlr_7_reg = (mp1_smnif_tlr_7_reg & ~MP1_SMNIF_TLR_7_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_7_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_7_SET_SLV_ADDR(mp1_smnif_tlr_7_reg, slv_addr) \
      mp1_smnif_tlr_7_reg = (mp1_smnif_tlr_7_reg & ~MP1_SMNIF_TLR_7_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_7_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_7_SET_VF_ACC(mp1_smnif_tlr_7_reg, vf_acc) \
      mp1_smnif_tlr_7_reg = (mp1_smnif_tlr_7_reg & ~MP1_SMNIF_TLR_7_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_7_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_7_SET_VF_ACC_ENB(mp1_smnif_tlr_7_reg, vf_acc_enb) \
      mp1_smnif_tlr_7_reg = (mp1_smnif_tlr_7_reg & ~MP1_SMNIF_TLR_7_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_7_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_7_SET_VALID(mp1_smnif_tlr_7_reg, valid) \
      mp1_smnif_tlr_7_reg = (mp1_smnif_tlr_7_reg & ~MP1_SMNIF_TLR_7_VALID_MASK) | (valid << MP1_SMNIF_TLR_7_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_7_t {
            unsigned int mask                           : MP1_SMNIF_TLR_7_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_7_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_7_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_7_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_7_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_7_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_7_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_7_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_7_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_7_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_7_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_7_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_7_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_7_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_7_MASK_SIZE;
      } mp1_smnif_tlr_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_7_t f;
} mp1_smnif_tlr_7_u;


/*
 * MP1_SMNIF_TLR_ADDR_7 struct
 */

#define MP1_SMNIF_TLR_ADDR_7_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_7_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_7_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_7_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_7_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_7_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_7_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_7_MASK \
      (MP1_SMNIF_TLR_ADDR_7_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_7_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_7_DEFAULT   0xffff0000

#define MP1_SMNIF_TLR_ADDR_7_GET_START_ADDR(mp1_smnif_tlr_addr_7) \
      ((mp1_smnif_tlr_addr_7 & MP1_SMNIF_TLR_ADDR_7_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_7_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_7_GET_END_ADDR(mp1_smnif_tlr_addr_7) \
      ((mp1_smnif_tlr_addr_7 & MP1_SMNIF_TLR_ADDR_7_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_7_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_7_SET_START_ADDR(mp1_smnif_tlr_addr_7_reg, start_addr) \
      mp1_smnif_tlr_addr_7_reg = (mp1_smnif_tlr_addr_7_reg & ~MP1_SMNIF_TLR_ADDR_7_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_7_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_7_SET_END_ADDR(mp1_smnif_tlr_addr_7_reg, end_addr) \
      mp1_smnif_tlr_addr_7_reg = (mp1_smnif_tlr_addr_7_reg & ~MP1_SMNIF_TLR_ADDR_7_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_7_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_7_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_7_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_7_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_7_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_7_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_7_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_7_t f;
} mp1_smnif_tlr_addr_7_u;


/*
 * MP1_SMNIF_TLR_8 struct
 */

#define MP1_SMNIF_TLR_8_REG_SIZE         32
#define MP1_SMNIF_TLR_8_MASK_SIZE  8
#define MP1_SMNIF_TLR_8_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_8_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_8_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_8_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_8_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_8_VALID_SIZE  1

#define MP1_SMNIF_TLR_8_MASK_SHIFT  0
#define MP1_SMNIF_TLR_8_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_8_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_8_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_8_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_8_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_8_VALID_SHIFT  16

#define MP1_SMNIF_TLR_8_MASK_MASK       0x000000ff
#define MP1_SMNIF_TLR_8_RD_ACC_MASK     0x00000100
#define MP1_SMNIF_TLR_8_WR_ACC_MASK     0x00000200
#define MP1_SMNIF_TLR_8_SLV_ADDR_MASK   0x00003c00
#define MP1_SMNIF_TLR_8_VF_ACC_MASK     0x00004000
#define MP1_SMNIF_TLR_8_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_8_VALID_MASK      0x00010000

#define MP1_SMNIF_TLR_8_MASK \
      (MP1_SMNIF_TLR_8_MASK_MASK | \
      MP1_SMNIF_TLR_8_RD_ACC_MASK | \
      MP1_SMNIF_TLR_8_WR_ACC_MASK | \
      MP1_SMNIF_TLR_8_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_8_VF_ACC_MASK | \
      MP1_SMNIF_TLR_8_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_8_VALID_MASK)

#define MP1_SMNIF_TLR_8_DEFAULT        0x000123ff

#define MP1_SMNIF_TLR_8_GET_MASK(mp1_smnif_tlr_8) \
      ((mp1_smnif_tlr_8 & MP1_SMNIF_TLR_8_MASK_MASK) >> MP1_SMNIF_TLR_8_MASK_SHIFT)
#define MP1_SMNIF_TLR_8_GET_RD_ACC(mp1_smnif_tlr_8) \
      ((mp1_smnif_tlr_8 & MP1_SMNIF_TLR_8_RD_ACC_MASK) >> MP1_SMNIF_TLR_8_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_8_GET_WR_ACC(mp1_smnif_tlr_8) \
      ((mp1_smnif_tlr_8 & MP1_SMNIF_TLR_8_WR_ACC_MASK) >> MP1_SMNIF_TLR_8_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_8_GET_SLV_ADDR(mp1_smnif_tlr_8) \
      ((mp1_smnif_tlr_8 & MP1_SMNIF_TLR_8_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_8_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_8_GET_VF_ACC(mp1_smnif_tlr_8) \
      ((mp1_smnif_tlr_8 & MP1_SMNIF_TLR_8_VF_ACC_MASK) >> MP1_SMNIF_TLR_8_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_8_GET_VF_ACC_ENB(mp1_smnif_tlr_8) \
      ((mp1_smnif_tlr_8 & MP1_SMNIF_TLR_8_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_8_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_8_GET_VALID(mp1_smnif_tlr_8) \
      ((mp1_smnif_tlr_8 & MP1_SMNIF_TLR_8_VALID_MASK) >> MP1_SMNIF_TLR_8_VALID_SHIFT)

#define MP1_SMNIF_TLR_8_SET_MASK(mp1_smnif_tlr_8_reg, mask) \
      mp1_smnif_tlr_8_reg = (mp1_smnif_tlr_8_reg & ~MP1_SMNIF_TLR_8_MASK_MASK) | (mask << MP1_SMNIF_TLR_8_MASK_SHIFT)
#define MP1_SMNIF_TLR_8_SET_RD_ACC(mp1_smnif_tlr_8_reg, rd_acc) \
      mp1_smnif_tlr_8_reg = (mp1_smnif_tlr_8_reg & ~MP1_SMNIF_TLR_8_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_8_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_8_SET_WR_ACC(mp1_smnif_tlr_8_reg, wr_acc) \
      mp1_smnif_tlr_8_reg = (mp1_smnif_tlr_8_reg & ~MP1_SMNIF_TLR_8_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_8_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_8_SET_SLV_ADDR(mp1_smnif_tlr_8_reg, slv_addr) \
      mp1_smnif_tlr_8_reg = (mp1_smnif_tlr_8_reg & ~MP1_SMNIF_TLR_8_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_8_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_8_SET_VF_ACC(mp1_smnif_tlr_8_reg, vf_acc) \
      mp1_smnif_tlr_8_reg = (mp1_smnif_tlr_8_reg & ~MP1_SMNIF_TLR_8_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_8_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_8_SET_VF_ACC_ENB(mp1_smnif_tlr_8_reg, vf_acc_enb) \
      mp1_smnif_tlr_8_reg = (mp1_smnif_tlr_8_reg & ~MP1_SMNIF_TLR_8_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_8_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_8_SET_VALID(mp1_smnif_tlr_8_reg, valid) \
      mp1_smnif_tlr_8_reg = (mp1_smnif_tlr_8_reg & ~MP1_SMNIF_TLR_8_VALID_MASK) | (valid << MP1_SMNIF_TLR_8_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_8_t {
            unsigned int mask                           : MP1_SMNIF_TLR_8_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_8_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_8_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_8_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_8_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_8_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_8_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_8_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_8_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_8_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_8_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_8_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_8_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_8_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_8_MASK_SIZE;
      } mp1_smnif_tlr_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_8_t f;
} mp1_smnif_tlr_8_u;


/*
 * MP1_SMNIF_TLR_ADDR_8 struct
 */

#define MP1_SMNIF_TLR_ADDR_8_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_8_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_8_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_8_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_8_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_8_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_8_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_8_MASK \
      (MP1_SMNIF_TLR_ADDR_8_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_8_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_8_DEFAULT   0xffff0000

#define MP1_SMNIF_TLR_ADDR_8_GET_START_ADDR(mp1_smnif_tlr_addr_8) \
      ((mp1_smnif_tlr_addr_8 & MP1_SMNIF_TLR_ADDR_8_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_8_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_8_GET_END_ADDR(mp1_smnif_tlr_addr_8) \
      ((mp1_smnif_tlr_addr_8 & MP1_SMNIF_TLR_ADDR_8_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_8_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_8_SET_START_ADDR(mp1_smnif_tlr_addr_8_reg, start_addr) \
      mp1_smnif_tlr_addr_8_reg = (mp1_smnif_tlr_addr_8_reg & ~MP1_SMNIF_TLR_ADDR_8_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_8_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_8_SET_END_ADDR(mp1_smnif_tlr_addr_8_reg, end_addr) \
      mp1_smnif_tlr_addr_8_reg = (mp1_smnif_tlr_addr_8_reg & ~MP1_SMNIF_TLR_ADDR_8_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_8_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_8_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_8_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_8_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_8_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_8_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_8_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_8_t f;
} mp1_smnif_tlr_addr_8_u;


/*
 * MP1_SMNIF_TLR_9 struct
 */

#define MP1_SMNIF_TLR_9_REG_SIZE         32
#define MP1_SMNIF_TLR_9_MASK_SIZE  8
#define MP1_SMNIF_TLR_9_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_9_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_9_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_9_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_9_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_9_VALID_SIZE  1

#define MP1_SMNIF_TLR_9_MASK_SHIFT  0
#define MP1_SMNIF_TLR_9_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_9_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_9_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_9_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_9_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_9_VALID_SHIFT  16

#define MP1_SMNIF_TLR_9_MASK_MASK       0x000000ff
#define MP1_SMNIF_TLR_9_RD_ACC_MASK     0x00000100
#define MP1_SMNIF_TLR_9_WR_ACC_MASK     0x00000200
#define MP1_SMNIF_TLR_9_SLV_ADDR_MASK   0x00003c00
#define MP1_SMNIF_TLR_9_VF_ACC_MASK     0x00004000
#define MP1_SMNIF_TLR_9_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_9_VALID_MASK      0x00010000

#define MP1_SMNIF_TLR_9_MASK \
      (MP1_SMNIF_TLR_9_MASK_MASK | \
      MP1_SMNIF_TLR_9_RD_ACC_MASK | \
      MP1_SMNIF_TLR_9_WR_ACC_MASK | \
      MP1_SMNIF_TLR_9_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_9_VF_ACC_MASK | \
      MP1_SMNIF_TLR_9_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_9_VALID_MASK)

#define MP1_SMNIF_TLR_9_DEFAULT        0x000127ff

#define MP1_SMNIF_TLR_9_GET_MASK(mp1_smnif_tlr_9) \
      ((mp1_smnif_tlr_9 & MP1_SMNIF_TLR_9_MASK_MASK) >> MP1_SMNIF_TLR_9_MASK_SHIFT)
#define MP1_SMNIF_TLR_9_GET_RD_ACC(mp1_smnif_tlr_9) \
      ((mp1_smnif_tlr_9 & MP1_SMNIF_TLR_9_RD_ACC_MASK) >> MP1_SMNIF_TLR_9_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_9_GET_WR_ACC(mp1_smnif_tlr_9) \
      ((mp1_smnif_tlr_9 & MP1_SMNIF_TLR_9_WR_ACC_MASK) >> MP1_SMNIF_TLR_9_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_9_GET_SLV_ADDR(mp1_smnif_tlr_9) \
      ((mp1_smnif_tlr_9 & MP1_SMNIF_TLR_9_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_9_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_9_GET_VF_ACC(mp1_smnif_tlr_9) \
      ((mp1_smnif_tlr_9 & MP1_SMNIF_TLR_9_VF_ACC_MASK) >> MP1_SMNIF_TLR_9_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_9_GET_VF_ACC_ENB(mp1_smnif_tlr_9) \
      ((mp1_smnif_tlr_9 & MP1_SMNIF_TLR_9_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_9_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_9_GET_VALID(mp1_smnif_tlr_9) \
      ((mp1_smnif_tlr_9 & MP1_SMNIF_TLR_9_VALID_MASK) >> MP1_SMNIF_TLR_9_VALID_SHIFT)

#define MP1_SMNIF_TLR_9_SET_MASK(mp1_smnif_tlr_9_reg, mask) \
      mp1_smnif_tlr_9_reg = (mp1_smnif_tlr_9_reg & ~MP1_SMNIF_TLR_9_MASK_MASK) | (mask << MP1_SMNIF_TLR_9_MASK_SHIFT)
#define MP1_SMNIF_TLR_9_SET_RD_ACC(mp1_smnif_tlr_9_reg, rd_acc) \
      mp1_smnif_tlr_9_reg = (mp1_smnif_tlr_9_reg & ~MP1_SMNIF_TLR_9_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_9_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_9_SET_WR_ACC(mp1_smnif_tlr_9_reg, wr_acc) \
      mp1_smnif_tlr_9_reg = (mp1_smnif_tlr_9_reg & ~MP1_SMNIF_TLR_9_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_9_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_9_SET_SLV_ADDR(mp1_smnif_tlr_9_reg, slv_addr) \
      mp1_smnif_tlr_9_reg = (mp1_smnif_tlr_9_reg & ~MP1_SMNIF_TLR_9_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_9_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_9_SET_VF_ACC(mp1_smnif_tlr_9_reg, vf_acc) \
      mp1_smnif_tlr_9_reg = (mp1_smnif_tlr_9_reg & ~MP1_SMNIF_TLR_9_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_9_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_9_SET_VF_ACC_ENB(mp1_smnif_tlr_9_reg, vf_acc_enb) \
      mp1_smnif_tlr_9_reg = (mp1_smnif_tlr_9_reg & ~MP1_SMNIF_TLR_9_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_9_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_9_SET_VALID(mp1_smnif_tlr_9_reg, valid) \
      mp1_smnif_tlr_9_reg = (mp1_smnif_tlr_9_reg & ~MP1_SMNIF_TLR_9_VALID_MASK) | (valid << MP1_SMNIF_TLR_9_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_9_t {
            unsigned int mask                           : MP1_SMNIF_TLR_9_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_9_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_9_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_9_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_9_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_9_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_9_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_9_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_9_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_9_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_9_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_9_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_9_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_9_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_9_MASK_SIZE;
      } mp1_smnif_tlr_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_9_t f;
} mp1_smnif_tlr_9_u;


/*
 * MP1_SMNIF_TLR_ADDR_9 struct
 */

#define MP1_SMNIF_TLR_ADDR_9_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_9_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_9_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_9_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_9_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_9_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_9_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_9_MASK \
      (MP1_SMNIF_TLR_ADDR_9_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_9_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_9_DEFAULT   0xffff0000

#define MP1_SMNIF_TLR_ADDR_9_GET_START_ADDR(mp1_smnif_tlr_addr_9) \
      ((mp1_smnif_tlr_addr_9 & MP1_SMNIF_TLR_ADDR_9_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_9_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_9_GET_END_ADDR(mp1_smnif_tlr_addr_9) \
      ((mp1_smnif_tlr_addr_9 & MP1_SMNIF_TLR_ADDR_9_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_9_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_9_SET_START_ADDR(mp1_smnif_tlr_addr_9_reg, start_addr) \
      mp1_smnif_tlr_addr_9_reg = (mp1_smnif_tlr_addr_9_reg & ~MP1_SMNIF_TLR_ADDR_9_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_9_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_9_SET_END_ADDR(mp1_smnif_tlr_addr_9_reg, end_addr) \
      mp1_smnif_tlr_addr_9_reg = (mp1_smnif_tlr_addr_9_reg & ~MP1_SMNIF_TLR_ADDR_9_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_9_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_9_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_9_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_9_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_9_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_9_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_9_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_9_t f;
} mp1_smnif_tlr_addr_9_u;


/*
 * MP1_SMNIF_TLR_10 struct
 */

#define MP1_SMNIF_TLR_10_REG_SIZE         32
#define MP1_SMNIF_TLR_10_MASK_SIZE  8
#define MP1_SMNIF_TLR_10_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_10_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_10_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_10_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_10_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_10_VALID_SIZE  1

#define MP1_SMNIF_TLR_10_MASK_SHIFT  0
#define MP1_SMNIF_TLR_10_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_10_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_10_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_10_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_10_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_10_VALID_SHIFT  16

#define MP1_SMNIF_TLR_10_MASK_MASK      0x000000ff
#define MP1_SMNIF_TLR_10_RD_ACC_MASK    0x00000100
#define MP1_SMNIF_TLR_10_WR_ACC_MASK    0x00000200
#define MP1_SMNIF_TLR_10_SLV_ADDR_MASK  0x00003c00
#define MP1_SMNIF_TLR_10_VF_ACC_MASK    0x00004000
#define MP1_SMNIF_TLR_10_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_10_VALID_MASK     0x00010000

#define MP1_SMNIF_TLR_10_MASK \
      (MP1_SMNIF_TLR_10_MASK_MASK | \
      MP1_SMNIF_TLR_10_RD_ACC_MASK | \
      MP1_SMNIF_TLR_10_WR_ACC_MASK | \
      MP1_SMNIF_TLR_10_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_10_VF_ACC_MASK | \
      MP1_SMNIF_TLR_10_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_10_VALID_MASK)

#define MP1_SMNIF_TLR_10_DEFAULT       0x00012bff

#define MP1_SMNIF_TLR_10_GET_MASK(mp1_smnif_tlr_10) \
      ((mp1_smnif_tlr_10 & MP1_SMNIF_TLR_10_MASK_MASK) >> MP1_SMNIF_TLR_10_MASK_SHIFT)
#define MP1_SMNIF_TLR_10_GET_RD_ACC(mp1_smnif_tlr_10) \
      ((mp1_smnif_tlr_10 & MP1_SMNIF_TLR_10_RD_ACC_MASK) >> MP1_SMNIF_TLR_10_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_10_GET_WR_ACC(mp1_smnif_tlr_10) \
      ((mp1_smnif_tlr_10 & MP1_SMNIF_TLR_10_WR_ACC_MASK) >> MP1_SMNIF_TLR_10_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_10_GET_SLV_ADDR(mp1_smnif_tlr_10) \
      ((mp1_smnif_tlr_10 & MP1_SMNIF_TLR_10_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_10_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_10_GET_VF_ACC(mp1_smnif_tlr_10) \
      ((mp1_smnif_tlr_10 & MP1_SMNIF_TLR_10_VF_ACC_MASK) >> MP1_SMNIF_TLR_10_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_10_GET_VF_ACC_ENB(mp1_smnif_tlr_10) \
      ((mp1_smnif_tlr_10 & MP1_SMNIF_TLR_10_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_10_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_10_GET_VALID(mp1_smnif_tlr_10) \
      ((mp1_smnif_tlr_10 & MP1_SMNIF_TLR_10_VALID_MASK) >> MP1_SMNIF_TLR_10_VALID_SHIFT)

#define MP1_SMNIF_TLR_10_SET_MASK(mp1_smnif_tlr_10_reg, mask) \
      mp1_smnif_tlr_10_reg = (mp1_smnif_tlr_10_reg & ~MP1_SMNIF_TLR_10_MASK_MASK) | (mask << MP1_SMNIF_TLR_10_MASK_SHIFT)
#define MP1_SMNIF_TLR_10_SET_RD_ACC(mp1_smnif_tlr_10_reg, rd_acc) \
      mp1_smnif_tlr_10_reg = (mp1_smnif_tlr_10_reg & ~MP1_SMNIF_TLR_10_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_10_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_10_SET_WR_ACC(mp1_smnif_tlr_10_reg, wr_acc) \
      mp1_smnif_tlr_10_reg = (mp1_smnif_tlr_10_reg & ~MP1_SMNIF_TLR_10_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_10_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_10_SET_SLV_ADDR(mp1_smnif_tlr_10_reg, slv_addr) \
      mp1_smnif_tlr_10_reg = (mp1_smnif_tlr_10_reg & ~MP1_SMNIF_TLR_10_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_10_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_10_SET_VF_ACC(mp1_smnif_tlr_10_reg, vf_acc) \
      mp1_smnif_tlr_10_reg = (mp1_smnif_tlr_10_reg & ~MP1_SMNIF_TLR_10_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_10_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_10_SET_VF_ACC_ENB(mp1_smnif_tlr_10_reg, vf_acc_enb) \
      mp1_smnif_tlr_10_reg = (mp1_smnif_tlr_10_reg & ~MP1_SMNIF_TLR_10_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_10_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_10_SET_VALID(mp1_smnif_tlr_10_reg, valid) \
      mp1_smnif_tlr_10_reg = (mp1_smnif_tlr_10_reg & ~MP1_SMNIF_TLR_10_VALID_MASK) | (valid << MP1_SMNIF_TLR_10_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_10_t {
            unsigned int mask                           : MP1_SMNIF_TLR_10_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_10_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_10_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_10_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_10_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_10_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_10_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_10_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_10_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_10_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_10_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_10_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_10_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_10_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_10_MASK_SIZE;
      } mp1_smnif_tlr_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_10_t f;
} mp1_smnif_tlr_10_u;


/*
 * MP1_SMNIF_TLR_ADDR_10 struct
 */

#define MP1_SMNIF_TLR_ADDR_10_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_10_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_10_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_10_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_10_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_10_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_10_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_10_MASK \
      (MP1_SMNIF_TLR_ADDR_10_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_10_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_10_DEFAULT  0xffff0000

#define MP1_SMNIF_TLR_ADDR_10_GET_START_ADDR(mp1_smnif_tlr_addr_10) \
      ((mp1_smnif_tlr_addr_10 & MP1_SMNIF_TLR_ADDR_10_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_10_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_10_GET_END_ADDR(mp1_smnif_tlr_addr_10) \
      ((mp1_smnif_tlr_addr_10 & MP1_SMNIF_TLR_ADDR_10_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_10_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_10_SET_START_ADDR(mp1_smnif_tlr_addr_10_reg, start_addr) \
      mp1_smnif_tlr_addr_10_reg = (mp1_smnif_tlr_addr_10_reg & ~MP1_SMNIF_TLR_ADDR_10_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_10_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_10_SET_END_ADDR(mp1_smnif_tlr_addr_10_reg, end_addr) \
      mp1_smnif_tlr_addr_10_reg = (mp1_smnif_tlr_addr_10_reg & ~MP1_SMNIF_TLR_ADDR_10_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_10_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_10_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_10_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_10_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_10_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_10_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_10_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_10_t f;
} mp1_smnif_tlr_addr_10_u;


/*
 * MP1_SMNIF_TLR_11 struct
 */

#define MP1_SMNIF_TLR_11_REG_SIZE         32
#define MP1_SMNIF_TLR_11_MASK_SIZE  8
#define MP1_SMNIF_TLR_11_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_11_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_11_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_11_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_11_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_11_VALID_SIZE  1

#define MP1_SMNIF_TLR_11_MASK_SHIFT  0
#define MP1_SMNIF_TLR_11_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_11_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_11_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_11_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_11_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_11_VALID_SHIFT  16

#define MP1_SMNIF_TLR_11_MASK_MASK      0x000000ff
#define MP1_SMNIF_TLR_11_RD_ACC_MASK    0x00000100
#define MP1_SMNIF_TLR_11_WR_ACC_MASK    0x00000200
#define MP1_SMNIF_TLR_11_SLV_ADDR_MASK  0x00003c00
#define MP1_SMNIF_TLR_11_VF_ACC_MASK    0x00004000
#define MP1_SMNIF_TLR_11_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_11_VALID_MASK     0x00010000

#define MP1_SMNIF_TLR_11_MASK \
      (MP1_SMNIF_TLR_11_MASK_MASK | \
      MP1_SMNIF_TLR_11_RD_ACC_MASK | \
      MP1_SMNIF_TLR_11_WR_ACC_MASK | \
      MP1_SMNIF_TLR_11_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_11_VF_ACC_MASK | \
      MP1_SMNIF_TLR_11_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_11_VALID_MASK)

#define MP1_SMNIF_TLR_11_DEFAULT       0x00012fff

#define MP1_SMNIF_TLR_11_GET_MASK(mp1_smnif_tlr_11) \
      ((mp1_smnif_tlr_11 & MP1_SMNIF_TLR_11_MASK_MASK) >> MP1_SMNIF_TLR_11_MASK_SHIFT)
#define MP1_SMNIF_TLR_11_GET_RD_ACC(mp1_smnif_tlr_11) \
      ((mp1_smnif_tlr_11 & MP1_SMNIF_TLR_11_RD_ACC_MASK) >> MP1_SMNIF_TLR_11_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_11_GET_WR_ACC(mp1_smnif_tlr_11) \
      ((mp1_smnif_tlr_11 & MP1_SMNIF_TLR_11_WR_ACC_MASK) >> MP1_SMNIF_TLR_11_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_11_GET_SLV_ADDR(mp1_smnif_tlr_11) \
      ((mp1_smnif_tlr_11 & MP1_SMNIF_TLR_11_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_11_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_11_GET_VF_ACC(mp1_smnif_tlr_11) \
      ((mp1_smnif_tlr_11 & MP1_SMNIF_TLR_11_VF_ACC_MASK) >> MP1_SMNIF_TLR_11_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_11_GET_VF_ACC_ENB(mp1_smnif_tlr_11) \
      ((mp1_smnif_tlr_11 & MP1_SMNIF_TLR_11_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_11_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_11_GET_VALID(mp1_smnif_tlr_11) \
      ((mp1_smnif_tlr_11 & MP1_SMNIF_TLR_11_VALID_MASK) >> MP1_SMNIF_TLR_11_VALID_SHIFT)

#define MP1_SMNIF_TLR_11_SET_MASK(mp1_smnif_tlr_11_reg, mask) \
      mp1_smnif_tlr_11_reg = (mp1_smnif_tlr_11_reg & ~MP1_SMNIF_TLR_11_MASK_MASK) | (mask << MP1_SMNIF_TLR_11_MASK_SHIFT)
#define MP1_SMNIF_TLR_11_SET_RD_ACC(mp1_smnif_tlr_11_reg, rd_acc) \
      mp1_smnif_tlr_11_reg = (mp1_smnif_tlr_11_reg & ~MP1_SMNIF_TLR_11_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_11_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_11_SET_WR_ACC(mp1_smnif_tlr_11_reg, wr_acc) \
      mp1_smnif_tlr_11_reg = (mp1_smnif_tlr_11_reg & ~MP1_SMNIF_TLR_11_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_11_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_11_SET_SLV_ADDR(mp1_smnif_tlr_11_reg, slv_addr) \
      mp1_smnif_tlr_11_reg = (mp1_smnif_tlr_11_reg & ~MP1_SMNIF_TLR_11_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_11_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_11_SET_VF_ACC(mp1_smnif_tlr_11_reg, vf_acc) \
      mp1_smnif_tlr_11_reg = (mp1_smnif_tlr_11_reg & ~MP1_SMNIF_TLR_11_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_11_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_11_SET_VF_ACC_ENB(mp1_smnif_tlr_11_reg, vf_acc_enb) \
      mp1_smnif_tlr_11_reg = (mp1_smnif_tlr_11_reg & ~MP1_SMNIF_TLR_11_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_11_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_11_SET_VALID(mp1_smnif_tlr_11_reg, valid) \
      mp1_smnif_tlr_11_reg = (mp1_smnif_tlr_11_reg & ~MP1_SMNIF_TLR_11_VALID_MASK) | (valid << MP1_SMNIF_TLR_11_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_11_t {
            unsigned int mask                           : MP1_SMNIF_TLR_11_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_11_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_11_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_11_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_11_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_11_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_11_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_11_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_11_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_11_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_11_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_11_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_11_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_11_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_11_MASK_SIZE;
      } mp1_smnif_tlr_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_11_t f;
} mp1_smnif_tlr_11_u;


/*
 * MP1_SMNIF_TLR_ADDR_11 struct
 */

#define MP1_SMNIF_TLR_ADDR_11_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_11_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_11_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_11_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_11_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_11_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_11_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_11_MASK \
      (MP1_SMNIF_TLR_ADDR_11_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_11_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_11_DEFAULT  0xffff0000

#define MP1_SMNIF_TLR_ADDR_11_GET_START_ADDR(mp1_smnif_tlr_addr_11) \
      ((mp1_smnif_tlr_addr_11 & MP1_SMNIF_TLR_ADDR_11_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_11_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_11_GET_END_ADDR(mp1_smnif_tlr_addr_11) \
      ((mp1_smnif_tlr_addr_11 & MP1_SMNIF_TLR_ADDR_11_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_11_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_11_SET_START_ADDR(mp1_smnif_tlr_addr_11_reg, start_addr) \
      mp1_smnif_tlr_addr_11_reg = (mp1_smnif_tlr_addr_11_reg & ~MP1_SMNIF_TLR_ADDR_11_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_11_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_11_SET_END_ADDR(mp1_smnif_tlr_addr_11_reg, end_addr) \
      mp1_smnif_tlr_addr_11_reg = (mp1_smnif_tlr_addr_11_reg & ~MP1_SMNIF_TLR_ADDR_11_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_11_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_11_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_11_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_11_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_11_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_11_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_11_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_11_t f;
} mp1_smnif_tlr_addr_11_u;


/*
 * MP1_SMNIF_TLR_12 struct
 */

#define MP1_SMNIF_TLR_12_REG_SIZE         32
#define MP1_SMNIF_TLR_12_MASK_SIZE  8
#define MP1_SMNIF_TLR_12_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_12_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_12_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_12_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_12_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_12_VALID_SIZE  1

#define MP1_SMNIF_TLR_12_MASK_SHIFT  0
#define MP1_SMNIF_TLR_12_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_12_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_12_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_12_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_12_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_12_VALID_SHIFT  16

#define MP1_SMNIF_TLR_12_MASK_MASK      0x000000ff
#define MP1_SMNIF_TLR_12_RD_ACC_MASK    0x00000100
#define MP1_SMNIF_TLR_12_WR_ACC_MASK    0x00000200
#define MP1_SMNIF_TLR_12_SLV_ADDR_MASK  0x00003c00
#define MP1_SMNIF_TLR_12_VF_ACC_MASK    0x00004000
#define MP1_SMNIF_TLR_12_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_12_VALID_MASK     0x00010000

#define MP1_SMNIF_TLR_12_MASK \
      (MP1_SMNIF_TLR_12_MASK_MASK | \
      MP1_SMNIF_TLR_12_RD_ACC_MASK | \
      MP1_SMNIF_TLR_12_WR_ACC_MASK | \
      MP1_SMNIF_TLR_12_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_12_VF_ACC_MASK | \
      MP1_SMNIF_TLR_12_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_12_VALID_MASK)

#define MP1_SMNIF_TLR_12_DEFAULT       0x000133ff

#define MP1_SMNIF_TLR_12_GET_MASK(mp1_smnif_tlr_12) \
      ((mp1_smnif_tlr_12 & MP1_SMNIF_TLR_12_MASK_MASK) >> MP1_SMNIF_TLR_12_MASK_SHIFT)
#define MP1_SMNIF_TLR_12_GET_RD_ACC(mp1_smnif_tlr_12) \
      ((mp1_smnif_tlr_12 & MP1_SMNIF_TLR_12_RD_ACC_MASK) >> MP1_SMNIF_TLR_12_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_12_GET_WR_ACC(mp1_smnif_tlr_12) \
      ((mp1_smnif_tlr_12 & MP1_SMNIF_TLR_12_WR_ACC_MASK) >> MP1_SMNIF_TLR_12_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_12_GET_SLV_ADDR(mp1_smnif_tlr_12) \
      ((mp1_smnif_tlr_12 & MP1_SMNIF_TLR_12_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_12_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_12_GET_VF_ACC(mp1_smnif_tlr_12) \
      ((mp1_smnif_tlr_12 & MP1_SMNIF_TLR_12_VF_ACC_MASK) >> MP1_SMNIF_TLR_12_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_12_GET_VF_ACC_ENB(mp1_smnif_tlr_12) \
      ((mp1_smnif_tlr_12 & MP1_SMNIF_TLR_12_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_12_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_12_GET_VALID(mp1_smnif_tlr_12) \
      ((mp1_smnif_tlr_12 & MP1_SMNIF_TLR_12_VALID_MASK) >> MP1_SMNIF_TLR_12_VALID_SHIFT)

#define MP1_SMNIF_TLR_12_SET_MASK(mp1_smnif_tlr_12_reg, mask) \
      mp1_smnif_tlr_12_reg = (mp1_smnif_tlr_12_reg & ~MP1_SMNIF_TLR_12_MASK_MASK) | (mask << MP1_SMNIF_TLR_12_MASK_SHIFT)
#define MP1_SMNIF_TLR_12_SET_RD_ACC(mp1_smnif_tlr_12_reg, rd_acc) \
      mp1_smnif_tlr_12_reg = (mp1_smnif_tlr_12_reg & ~MP1_SMNIF_TLR_12_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_12_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_12_SET_WR_ACC(mp1_smnif_tlr_12_reg, wr_acc) \
      mp1_smnif_tlr_12_reg = (mp1_smnif_tlr_12_reg & ~MP1_SMNIF_TLR_12_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_12_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_12_SET_SLV_ADDR(mp1_smnif_tlr_12_reg, slv_addr) \
      mp1_smnif_tlr_12_reg = (mp1_smnif_tlr_12_reg & ~MP1_SMNIF_TLR_12_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_12_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_12_SET_VF_ACC(mp1_smnif_tlr_12_reg, vf_acc) \
      mp1_smnif_tlr_12_reg = (mp1_smnif_tlr_12_reg & ~MP1_SMNIF_TLR_12_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_12_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_12_SET_VF_ACC_ENB(mp1_smnif_tlr_12_reg, vf_acc_enb) \
      mp1_smnif_tlr_12_reg = (mp1_smnif_tlr_12_reg & ~MP1_SMNIF_TLR_12_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_12_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_12_SET_VALID(mp1_smnif_tlr_12_reg, valid) \
      mp1_smnif_tlr_12_reg = (mp1_smnif_tlr_12_reg & ~MP1_SMNIF_TLR_12_VALID_MASK) | (valid << MP1_SMNIF_TLR_12_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_12_t {
            unsigned int mask                           : MP1_SMNIF_TLR_12_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_12_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_12_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_12_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_12_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_12_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_12_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_12_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_12_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_12_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_12_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_12_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_12_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_12_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_12_MASK_SIZE;
      } mp1_smnif_tlr_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_12_t f;
} mp1_smnif_tlr_12_u;


/*
 * MP1_SMNIF_TLR_ADDR_12 struct
 */

#define MP1_SMNIF_TLR_ADDR_12_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_12_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_12_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_12_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_12_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_12_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_12_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_12_MASK \
      (MP1_SMNIF_TLR_ADDR_12_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_12_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_12_DEFAULT  0xffff0000

#define MP1_SMNIF_TLR_ADDR_12_GET_START_ADDR(mp1_smnif_tlr_addr_12) \
      ((mp1_smnif_tlr_addr_12 & MP1_SMNIF_TLR_ADDR_12_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_12_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_12_GET_END_ADDR(mp1_smnif_tlr_addr_12) \
      ((mp1_smnif_tlr_addr_12 & MP1_SMNIF_TLR_ADDR_12_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_12_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_12_SET_START_ADDR(mp1_smnif_tlr_addr_12_reg, start_addr) \
      mp1_smnif_tlr_addr_12_reg = (mp1_smnif_tlr_addr_12_reg & ~MP1_SMNIF_TLR_ADDR_12_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_12_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_12_SET_END_ADDR(mp1_smnif_tlr_addr_12_reg, end_addr) \
      mp1_smnif_tlr_addr_12_reg = (mp1_smnif_tlr_addr_12_reg & ~MP1_SMNIF_TLR_ADDR_12_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_12_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_12_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_12_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_12_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_12_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_12_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_12_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_12_t f;
} mp1_smnif_tlr_addr_12_u;


/*
 * MP1_SMNIF_TLR_13 struct
 */

#define MP1_SMNIF_TLR_13_REG_SIZE         32
#define MP1_SMNIF_TLR_13_MASK_SIZE  8
#define MP1_SMNIF_TLR_13_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_13_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_13_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_13_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_13_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_13_VALID_SIZE  1

#define MP1_SMNIF_TLR_13_MASK_SHIFT  0
#define MP1_SMNIF_TLR_13_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_13_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_13_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_13_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_13_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_13_VALID_SHIFT  16

#define MP1_SMNIF_TLR_13_MASK_MASK      0x000000ff
#define MP1_SMNIF_TLR_13_RD_ACC_MASK    0x00000100
#define MP1_SMNIF_TLR_13_WR_ACC_MASK    0x00000200
#define MP1_SMNIF_TLR_13_SLV_ADDR_MASK  0x00003c00
#define MP1_SMNIF_TLR_13_VF_ACC_MASK    0x00004000
#define MP1_SMNIF_TLR_13_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_13_VALID_MASK     0x00010000

#define MP1_SMNIF_TLR_13_MASK \
      (MP1_SMNIF_TLR_13_MASK_MASK | \
      MP1_SMNIF_TLR_13_RD_ACC_MASK | \
      MP1_SMNIF_TLR_13_WR_ACC_MASK | \
      MP1_SMNIF_TLR_13_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_13_VF_ACC_MASK | \
      MP1_SMNIF_TLR_13_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_13_VALID_MASK)

#define MP1_SMNIF_TLR_13_DEFAULT       0x000137ff

#define MP1_SMNIF_TLR_13_GET_MASK(mp1_smnif_tlr_13) \
      ((mp1_smnif_tlr_13 & MP1_SMNIF_TLR_13_MASK_MASK) >> MP1_SMNIF_TLR_13_MASK_SHIFT)
#define MP1_SMNIF_TLR_13_GET_RD_ACC(mp1_smnif_tlr_13) \
      ((mp1_smnif_tlr_13 & MP1_SMNIF_TLR_13_RD_ACC_MASK) >> MP1_SMNIF_TLR_13_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_13_GET_WR_ACC(mp1_smnif_tlr_13) \
      ((mp1_smnif_tlr_13 & MP1_SMNIF_TLR_13_WR_ACC_MASK) >> MP1_SMNIF_TLR_13_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_13_GET_SLV_ADDR(mp1_smnif_tlr_13) \
      ((mp1_smnif_tlr_13 & MP1_SMNIF_TLR_13_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_13_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_13_GET_VF_ACC(mp1_smnif_tlr_13) \
      ((mp1_smnif_tlr_13 & MP1_SMNIF_TLR_13_VF_ACC_MASK) >> MP1_SMNIF_TLR_13_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_13_GET_VF_ACC_ENB(mp1_smnif_tlr_13) \
      ((mp1_smnif_tlr_13 & MP1_SMNIF_TLR_13_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_13_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_13_GET_VALID(mp1_smnif_tlr_13) \
      ((mp1_smnif_tlr_13 & MP1_SMNIF_TLR_13_VALID_MASK) >> MP1_SMNIF_TLR_13_VALID_SHIFT)

#define MP1_SMNIF_TLR_13_SET_MASK(mp1_smnif_tlr_13_reg, mask) \
      mp1_smnif_tlr_13_reg = (mp1_smnif_tlr_13_reg & ~MP1_SMNIF_TLR_13_MASK_MASK) | (mask << MP1_SMNIF_TLR_13_MASK_SHIFT)
#define MP1_SMNIF_TLR_13_SET_RD_ACC(mp1_smnif_tlr_13_reg, rd_acc) \
      mp1_smnif_tlr_13_reg = (mp1_smnif_tlr_13_reg & ~MP1_SMNIF_TLR_13_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_13_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_13_SET_WR_ACC(mp1_smnif_tlr_13_reg, wr_acc) \
      mp1_smnif_tlr_13_reg = (mp1_smnif_tlr_13_reg & ~MP1_SMNIF_TLR_13_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_13_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_13_SET_SLV_ADDR(mp1_smnif_tlr_13_reg, slv_addr) \
      mp1_smnif_tlr_13_reg = (mp1_smnif_tlr_13_reg & ~MP1_SMNIF_TLR_13_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_13_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_13_SET_VF_ACC(mp1_smnif_tlr_13_reg, vf_acc) \
      mp1_smnif_tlr_13_reg = (mp1_smnif_tlr_13_reg & ~MP1_SMNIF_TLR_13_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_13_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_13_SET_VF_ACC_ENB(mp1_smnif_tlr_13_reg, vf_acc_enb) \
      mp1_smnif_tlr_13_reg = (mp1_smnif_tlr_13_reg & ~MP1_SMNIF_TLR_13_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_13_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_13_SET_VALID(mp1_smnif_tlr_13_reg, valid) \
      mp1_smnif_tlr_13_reg = (mp1_smnif_tlr_13_reg & ~MP1_SMNIF_TLR_13_VALID_MASK) | (valid << MP1_SMNIF_TLR_13_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_13_t {
            unsigned int mask                           : MP1_SMNIF_TLR_13_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_13_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_13_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_13_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_13_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_13_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_13_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_13_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_13_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_13_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_13_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_13_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_13_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_13_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_13_MASK_SIZE;
      } mp1_smnif_tlr_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_13_t f;
} mp1_smnif_tlr_13_u;


/*
 * MP1_SMNIF_TLR_ADDR_13 struct
 */

#define MP1_SMNIF_TLR_ADDR_13_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_13_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_13_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_13_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_13_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_13_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_13_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_13_MASK \
      (MP1_SMNIF_TLR_ADDR_13_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_13_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_13_DEFAULT  0xffff0000

#define MP1_SMNIF_TLR_ADDR_13_GET_START_ADDR(mp1_smnif_tlr_addr_13) \
      ((mp1_smnif_tlr_addr_13 & MP1_SMNIF_TLR_ADDR_13_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_13_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_13_GET_END_ADDR(mp1_smnif_tlr_addr_13) \
      ((mp1_smnif_tlr_addr_13 & MP1_SMNIF_TLR_ADDR_13_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_13_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_13_SET_START_ADDR(mp1_smnif_tlr_addr_13_reg, start_addr) \
      mp1_smnif_tlr_addr_13_reg = (mp1_smnif_tlr_addr_13_reg & ~MP1_SMNIF_TLR_ADDR_13_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_13_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_13_SET_END_ADDR(mp1_smnif_tlr_addr_13_reg, end_addr) \
      mp1_smnif_tlr_addr_13_reg = (mp1_smnif_tlr_addr_13_reg & ~MP1_SMNIF_TLR_ADDR_13_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_13_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_13_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_13_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_13_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_13_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_13_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_13_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_13_t f;
} mp1_smnif_tlr_addr_13_u;


/*
 * MP1_SMNIF_TLR_14 struct
 */

#define MP1_SMNIF_TLR_14_REG_SIZE         32
#define MP1_SMNIF_TLR_14_MASK_SIZE  8
#define MP1_SMNIF_TLR_14_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_14_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_14_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_14_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_14_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_14_VALID_SIZE  1

#define MP1_SMNIF_TLR_14_MASK_SHIFT  0
#define MP1_SMNIF_TLR_14_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_14_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_14_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_14_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_14_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_14_VALID_SHIFT  16

#define MP1_SMNIF_TLR_14_MASK_MASK      0x000000ff
#define MP1_SMNIF_TLR_14_RD_ACC_MASK    0x00000100
#define MP1_SMNIF_TLR_14_WR_ACC_MASK    0x00000200
#define MP1_SMNIF_TLR_14_SLV_ADDR_MASK  0x00003c00
#define MP1_SMNIF_TLR_14_VF_ACC_MASK    0x00004000
#define MP1_SMNIF_TLR_14_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_14_VALID_MASK     0x00010000

#define MP1_SMNIF_TLR_14_MASK \
      (MP1_SMNIF_TLR_14_MASK_MASK | \
      MP1_SMNIF_TLR_14_RD_ACC_MASK | \
      MP1_SMNIF_TLR_14_WR_ACC_MASK | \
      MP1_SMNIF_TLR_14_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_14_VF_ACC_MASK | \
      MP1_SMNIF_TLR_14_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_14_VALID_MASK)

#define MP1_SMNIF_TLR_14_DEFAULT       0x00013bff

#define MP1_SMNIF_TLR_14_GET_MASK(mp1_smnif_tlr_14) \
      ((mp1_smnif_tlr_14 & MP1_SMNIF_TLR_14_MASK_MASK) >> MP1_SMNIF_TLR_14_MASK_SHIFT)
#define MP1_SMNIF_TLR_14_GET_RD_ACC(mp1_smnif_tlr_14) \
      ((mp1_smnif_tlr_14 & MP1_SMNIF_TLR_14_RD_ACC_MASK) >> MP1_SMNIF_TLR_14_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_14_GET_WR_ACC(mp1_smnif_tlr_14) \
      ((mp1_smnif_tlr_14 & MP1_SMNIF_TLR_14_WR_ACC_MASK) >> MP1_SMNIF_TLR_14_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_14_GET_SLV_ADDR(mp1_smnif_tlr_14) \
      ((mp1_smnif_tlr_14 & MP1_SMNIF_TLR_14_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_14_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_14_GET_VF_ACC(mp1_smnif_tlr_14) \
      ((mp1_smnif_tlr_14 & MP1_SMNIF_TLR_14_VF_ACC_MASK) >> MP1_SMNIF_TLR_14_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_14_GET_VF_ACC_ENB(mp1_smnif_tlr_14) \
      ((mp1_smnif_tlr_14 & MP1_SMNIF_TLR_14_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_14_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_14_GET_VALID(mp1_smnif_tlr_14) \
      ((mp1_smnif_tlr_14 & MP1_SMNIF_TLR_14_VALID_MASK) >> MP1_SMNIF_TLR_14_VALID_SHIFT)

#define MP1_SMNIF_TLR_14_SET_MASK(mp1_smnif_tlr_14_reg, mask) \
      mp1_smnif_tlr_14_reg = (mp1_smnif_tlr_14_reg & ~MP1_SMNIF_TLR_14_MASK_MASK) | (mask << MP1_SMNIF_TLR_14_MASK_SHIFT)
#define MP1_SMNIF_TLR_14_SET_RD_ACC(mp1_smnif_tlr_14_reg, rd_acc) \
      mp1_smnif_tlr_14_reg = (mp1_smnif_tlr_14_reg & ~MP1_SMNIF_TLR_14_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_14_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_14_SET_WR_ACC(mp1_smnif_tlr_14_reg, wr_acc) \
      mp1_smnif_tlr_14_reg = (mp1_smnif_tlr_14_reg & ~MP1_SMNIF_TLR_14_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_14_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_14_SET_SLV_ADDR(mp1_smnif_tlr_14_reg, slv_addr) \
      mp1_smnif_tlr_14_reg = (mp1_smnif_tlr_14_reg & ~MP1_SMNIF_TLR_14_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_14_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_14_SET_VF_ACC(mp1_smnif_tlr_14_reg, vf_acc) \
      mp1_smnif_tlr_14_reg = (mp1_smnif_tlr_14_reg & ~MP1_SMNIF_TLR_14_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_14_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_14_SET_VF_ACC_ENB(mp1_smnif_tlr_14_reg, vf_acc_enb) \
      mp1_smnif_tlr_14_reg = (mp1_smnif_tlr_14_reg & ~MP1_SMNIF_TLR_14_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_14_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_14_SET_VALID(mp1_smnif_tlr_14_reg, valid) \
      mp1_smnif_tlr_14_reg = (mp1_smnif_tlr_14_reg & ~MP1_SMNIF_TLR_14_VALID_MASK) | (valid << MP1_SMNIF_TLR_14_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_14_t {
            unsigned int mask                           : MP1_SMNIF_TLR_14_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_14_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_14_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_14_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_14_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_14_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_14_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_14_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_14_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_14_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_14_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_14_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_14_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_14_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_14_MASK_SIZE;
      } mp1_smnif_tlr_14_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_14_t f;
} mp1_smnif_tlr_14_u;


/*
 * MP1_SMNIF_TLR_ADDR_14 struct
 */

#define MP1_SMNIF_TLR_ADDR_14_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_14_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_14_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_14_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_14_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_14_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_14_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_14_MASK \
      (MP1_SMNIF_TLR_ADDR_14_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_14_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_14_DEFAULT  0xffff0000

#define MP1_SMNIF_TLR_ADDR_14_GET_START_ADDR(mp1_smnif_tlr_addr_14) \
      ((mp1_smnif_tlr_addr_14 & MP1_SMNIF_TLR_ADDR_14_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_14_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_14_GET_END_ADDR(mp1_smnif_tlr_addr_14) \
      ((mp1_smnif_tlr_addr_14 & MP1_SMNIF_TLR_ADDR_14_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_14_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_14_SET_START_ADDR(mp1_smnif_tlr_addr_14_reg, start_addr) \
      mp1_smnif_tlr_addr_14_reg = (mp1_smnif_tlr_addr_14_reg & ~MP1_SMNIF_TLR_ADDR_14_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_14_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_14_SET_END_ADDR(mp1_smnif_tlr_addr_14_reg, end_addr) \
      mp1_smnif_tlr_addr_14_reg = (mp1_smnif_tlr_addr_14_reg & ~MP1_SMNIF_TLR_ADDR_14_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_14_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_14_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_14_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_14_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_14_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_14_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_14_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_14_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_14_t f;
} mp1_smnif_tlr_addr_14_u;


/*
 * MP1_SMNIF_TLR_15 struct
 */

#define MP1_SMNIF_TLR_15_REG_SIZE         32
#define MP1_SMNIF_TLR_15_MASK_SIZE  8
#define MP1_SMNIF_TLR_15_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_15_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_15_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_15_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_15_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_15_VALID_SIZE  1

#define MP1_SMNIF_TLR_15_MASK_SHIFT  0
#define MP1_SMNIF_TLR_15_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_15_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_15_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_15_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_15_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_15_VALID_SHIFT  16

#define MP1_SMNIF_TLR_15_MASK_MASK      0x000000ff
#define MP1_SMNIF_TLR_15_RD_ACC_MASK    0x00000100
#define MP1_SMNIF_TLR_15_WR_ACC_MASK    0x00000200
#define MP1_SMNIF_TLR_15_SLV_ADDR_MASK  0x00003c00
#define MP1_SMNIF_TLR_15_VF_ACC_MASK    0x00004000
#define MP1_SMNIF_TLR_15_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_15_VALID_MASK     0x00010000

#define MP1_SMNIF_TLR_15_MASK \
      (MP1_SMNIF_TLR_15_MASK_MASK | \
      MP1_SMNIF_TLR_15_RD_ACC_MASK | \
      MP1_SMNIF_TLR_15_WR_ACC_MASK | \
      MP1_SMNIF_TLR_15_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_15_VF_ACC_MASK | \
      MP1_SMNIF_TLR_15_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_15_VALID_MASK)

#define MP1_SMNIF_TLR_15_DEFAULT       0x00013fff

#define MP1_SMNIF_TLR_15_GET_MASK(mp1_smnif_tlr_15) \
      ((mp1_smnif_tlr_15 & MP1_SMNIF_TLR_15_MASK_MASK) >> MP1_SMNIF_TLR_15_MASK_SHIFT)
#define MP1_SMNIF_TLR_15_GET_RD_ACC(mp1_smnif_tlr_15) \
      ((mp1_smnif_tlr_15 & MP1_SMNIF_TLR_15_RD_ACC_MASK) >> MP1_SMNIF_TLR_15_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_15_GET_WR_ACC(mp1_smnif_tlr_15) \
      ((mp1_smnif_tlr_15 & MP1_SMNIF_TLR_15_WR_ACC_MASK) >> MP1_SMNIF_TLR_15_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_15_GET_SLV_ADDR(mp1_smnif_tlr_15) \
      ((mp1_smnif_tlr_15 & MP1_SMNIF_TLR_15_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_15_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_15_GET_VF_ACC(mp1_smnif_tlr_15) \
      ((mp1_smnif_tlr_15 & MP1_SMNIF_TLR_15_VF_ACC_MASK) >> MP1_SMNIF_TLR_15_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_15_GET_VF_ACC_ENB(mp1_smnif_tlr_15) \
      ((mp1_smnif_tlr_15 & MP1_SMNIF_TLR_15_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_15_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_15_GET_VALID(mp1_smnif_tlr_15) \
      ((mp1_smnif_tlr_15 & MP1_SMNIF_TLR_15_VALID_MASK) >> MP1_SMNIF_TLR_15_VALID_SHIFT)

#define MP1_SMNIF_TLR_15_SET_MASK(mp1_smnif_tlr_15_reg, mask) \
      mp1_smnif_tlr_15_reg = (mp1_smnif_tlr_15_reg & ~MP1_SMNIF_TLR_15_MASK_MASK) | (mask << MP1_SMNIF_TLR_15_MASK_SHIFT)
#define MP1_SMNIF_TLR_15_SET_RD_ACC(mp1_smnif_tlr_15_reg, rd_acc) \
      mp1_smnif_tlr_15_reg = (mp1_smnif_tlr_15_reg & ~MP1_SMNIF_TLR_15_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_15_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_15_SET_WR_ACC(mp1_smnif_tlr_15_reg, wr_acc) \
      mp1_smnif_tlr_15_reg = (mp1_smnif_tlr_15_reg & ~MP1_SMNIF_TLR_15_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_15_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_15_SET_SLV_ADDR(mp1_smnif_tlr_15_reg, slv_addr) \
      mp1_smnif_tlr_15_reg = (mp1_smnif_tlr_15_reg & ~MP1_SMNIF_TLR_15_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_15_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_15_SET_VF_ACC(mp1_smnif_tlr_15_reg, vf_acc) \
      mp1_smnif_tlr_15_reg = (mp1_smnif_tlr_15_reg & ~MP1_SMNIF_TLR_15_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_15_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_15_SET_VF_ACC_ENB(mp1_smnif_tlr_15_reg, vf_acc_enb) \
      mp1_smnif_tlr_15_reg = (mp1_smnif_tlr_15_reg & ~MP1_SMNIF_TLR_15_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_15_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_15_SET_VALID(mp1_smnif_tlr_15_reg, valid) \
      mp1_smnif_tlr_15_reg = (mp1_smnif_tlr_15_reg & ~MP1_SMNIF_TLR_15_VALID_MASK) | (valid << MP1_SMNIF_TLR_15_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_15_t {
            unsigned int mask                           : MP1_SMNIF_TLR_15_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_15_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_15_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_15_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_15_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_15_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_15_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_15_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_15_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_15_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_15_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_15_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_15_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_15_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_15_MASK_SIZE;
      } mp1_smnif_tlr_15_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_15_t f;
} mp1_smnif_tlr_15_u;


/*
 * MP1_SMNIF_TLR_ADDR_15 struct
 */

#define MP1_SMNIF_TLR_ADDR_15_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_15_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_15_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_15_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_15_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_15_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_15_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_15_MASK \
      (MP1_SMNIF_TLR_ADDR_15_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_15_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_15_DEFAULT  0xffff0000

#define MP1_SMNIF_TLR_ADDR_15_GET_START_ADDR(mp1_smnif_tlr_addr_15) \
      ((mp1_smnif_tlr_addr_15 & MP1_SMNIF_TLR_ADDR_15_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_15_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_15_GET_END_ADDR(mp1_smnif_tlr_addr_15) \
      ((mp1_smnif_tlr_addr_15 & MP1_SMNIF_TLR_ADDR_15_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_15_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_15_SET_START_ADDR(mp1_smnif_tlr_addr_15_reg, start_addr) \
      mp1_smnif_tlr_addr_15_reg = (mp1_smnif_tlr_addr_15_reg & ~MP1_SMNIF_TLR_ADDR_15_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_15_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_15_SET_END_ADDR(mp1_smnif_tlr_addr_15_reg, end_addr) \
      mp1_smnif_tlr_addr_15_reg = (mp1_smnif_tlr_addr_15_reg & ~MP1_SMNIF_TLR_ADDR_15_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_15_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_15_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_15_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_15_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_15_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_15_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_15_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_15_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_15_t f;
} mp1_smnif_tlr_addr_15_u;


/*
 * MP1_SMNIF_TLR_16 struct
 */

#define MP1_SMNIF_TLR_16_REG_SIZE         32
#define MP1_SMNIF_TLR_16_MASK_SIZE  8
#define MP1_SMNIF_TLR_16_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_16_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_16_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_16_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_16_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_16_VALID_SIZE  1

#define MP1_SMNIF_TLR_16_MASK_SHIFT  0
#define MP1_SMNIF_TLR_16_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_16_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_16_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_16_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_16_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_16_VALID_SHIFT  16

#define MP1_SMNIF_TLR_16_MASK_MASK      0x000000ff
#define MP1_SMNIF_TLR_16_RD_ACC_MASK    0x00000100
#define MP1_SMNIF_TLR_16_WR_ACC_MASK    0x00000200
#define MP1_SMNIF_TLR_16_SLV_ADDR_MASK  0x00003c00
#define MP1_SMNIF_TLR_16_VF_ACC_MASK    0x00004000
#define MP1_SMNIF_TLR_16_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_16_VALID_MASK     0x00010000

#define MP1_SMNIF_TLR_16_MASK \
      (MP1_SMNIF_TLR_16_MASK_MASK | \
      MP1_SMNIF_TLR_16_RD_ACC_MASK | \
      MP1_SMNIF_TLR_16_WR_ACC_MASK | \
      MP1_SMNIF_TLR_16_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_16_VF_ACC_MASK | \
      MP1_SMNIF_TLR_16_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_16_VALID_MASK)

#define MP1_SMNIF_TLR_16_DEFAULT       0x00000000

#define MP1_SMNIF_TLR_16_GET_MASK(mp1_smnif_tlr_16) \
      ((mp1_smnif_tlr_16 & MP1_SMNIF_TLR_16_MASK_MASK) >> MP1_SMNIF_TLR_16_MASK_SHIFT)
#define MP1_SMNIF_TLR_16_GET_RD_ACC(mp1_smnif_tlr_16) \
      ((mp1_smnif_tlr_16 & MP1_SMNIF_TLR_16_RD_ACC_MASK) >> MP1_SMNIF_TLR_16_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_16_GET_WR_ACC(mp1_smnif_tlr_16) \
      ((mp1_smnif_tlr_16 & MP1_SMNIF_TLR_16_WR_ACC_MASK) >> MP1_SMNIF_TLR_16_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_16_GET_SLV_ADDR(mp1_smnif_tlr_16) \
      ((mp1_smnif_tlr_16 & MP1_SMNIF_TLR_16_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_16_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_16_GET_VF_ACC(mp1_smnif_tlr_16) \
      ((mp1_smnif_tlr_16 & MP1_SMNIF_TLR_16_VF_ACC_MASK) >> MP1_SMNIF_TLR_16_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_16_GET_VF_ACC_ENB(mp1_smnif_tlr_16) \
      ((mp1_smnif_tlr_16 & MP1_SMNIF_TLR_16_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_16_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_16_GET_VALID(mp1_smnif_tlr_16) \
      ((mp1_smnif_tlr_16 & MP1_SMNIF_TLR_16_VALID_MASK) >> MP1_SMNIF_TLR_16_VALID_SHIFT)

#define MP1_SMNIF_TLR_16_SET_MASK(mp1_smnif_tlr_16_reg, mask) \
      mp1_smnif_tlr_16_reg = (mp1_smnif_tlr_16_reg & ~MP1_SMNIF_TLR_16_MASK_MASK) | (mask << MP1_SMNIF_TLR_16_MASK_SHIFT)
#define MP1_SMNIF_TLR_16_SET_RD_ACC(mp1_smnif_tlr_16_reg, rd_acc) \
      mp1_smnif_tlr_16_reg = (mp1_smnif_tlr_16_reg & ~MP1_SMNIF_TLR_16_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_16_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_16_SET_WR_ACC(mp1_smnif_tlr_16_reg, wr_acc) \
      mp1_smnif_tlr_16_reg = (mp1_smnif_tlr_16_reg & ~MP1_SMNIF_TLR_16_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_16_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_16_SET_SLV_ADDR(mp1_smnif_tlr_16_reg, slv_addr) \
      mp1_smnif_tlr_16_reg = (mp1_smnif_tlr_16_reg & ~MP1_SMNIF_TLR_16_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_16_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_16_SET_VF_ACC(mp1_smnif_tlr_16_reg, vf_acc) \
      mp1_smnif_tlr_16_reg = (mp1_smnif_tlr_16_reg & ~MP1_SMNIF_TLR_16_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_16_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_16_SET_VF_ACC_ENB(mp1_smnif_tlr_16_reg, vf_acc_enb) \
      mp1_smnif_tlr_16_reg = (mp1_smnif_tlr_16_reg & ~MP1_SMNIF_TLR_16_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_16_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_16_SET_VALID(mp1_smnif_tlr_16_reg, valid) \
      mp1_smnif_tlr_16_reg = (mp1_smnif_tlr_16_reg & ~MP1_SMNIF_TLR_16_VALID_MASK) | (valid << MP1_SMNIF_TLR_16_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_16_t {
            unsigned int mask                           : MP1_SMNIF_TLR_16_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_16_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_16_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_16_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_16_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_16_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_16_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_16_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_16_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_16_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_16_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_16_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_16_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_16_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_16_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_16_MASK_SIZE;
      } mp1_smnif_tlr_16_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_16_t f;
} mp1_smnif_tlr_16_u;


/*
 * MP1_SMNIF_TLR_ADDR_16 struct
 */

#define MP1_SMNIF_TLR_ADDR_16_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_16_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_16_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_16_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_16_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_16_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_16_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_16_MASK \
      (MP1_SMNIF_TLR_ADDR_16_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_16_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_16_DEFAULT  0x00000000

#define MP1_SMNIF_TLR_ADDR_16_GET_START_ADDR(mp1_smnif_tlr_addr_16) \
      ((mp1_smnif_tlr_addr_16 & MP1_SMNIF_TLR_ADDR_16_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_16_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_16_GET_END_ADDR(mp1_smnif_tlr_addr_16) \
      ((mp1_smnif_tlr_addr_16 & MP1_SMNIF_TLR_ADDR_16_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_16_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_16_SET_START_ADDR(mp1_smnif_tlr_addr_16_reg, start_addr) \
      mp1_smnif_tlr_addr_16_reg = (mp1_smnif_tlr_addr_16_reg & ~MP1_SMNIF_TLR_ADDR_16_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_16_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_16_SET_END_ADDR(mp1_smnif_tlr_addr_16_reg, end_addr) \
      mp1_smnif_tlr_addr_16_reg = (mp1_smnif_tlr_addr_16_reg & ~MP1_SMNIF_TLR_ADDR_16_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_16_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_16_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_16_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_16_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_16_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_16_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_16_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_16_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_16_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_16_t f;
} mp1_smnif_tlr_addr_16_u;


/*
 * MP1_SMNIF_TLR_17 struct
 */

#define MP1_SMNIF_TLR_17_REG_SIZE         32
#define MP1_SMNIF_TLR_17_MASK_SIZE  8
#define MP1_SMNIF_TLR_17_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_17_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_17_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_17_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_17_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_17_VALID_SIZE  1

#define MP1_SMNIF_TLR_17_MASK_SHIFT  0
#define MP1_SMNIF_TLR_17_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_17_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_17_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_17_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_17_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_17_VALID_SHIFT  16

#define MP1_SMNIF_TLR_17_MASK_MASK      0x000000ff
#define MP1_SMNIF_TLR_17_RD_ACC_MASK    0x00000100
#define MP1_SMNIF_TLR_17_WR_ACC_MASK    0x00000200
#define MP1_SMNIF_TLR_17_SLV_ADDR_MASK  0x00003c00
#define MP1_SMNIF_TLR_17_VF_ACC_MASK    0x00004000
#define MP1_SMNIF_TLR_17_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_17_VALID_MASK     0x00010000

#define MP1_SMNIF_TLR_17_MASK \
      (MP1_SMNIF_TLR_17_MASK_MASK | \
      MP1_SMNIF_TLR_17_RD_ACC_MASK | \
      MP1_SMNIF_TLR_17_WR_ACC_MASK | \
      MP1_SMNIF_TLR_17_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_17_VF_ACC_MASK | \
      MP1_SMNIF_TLR_17_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_17_VALID_MASK)

#define MP1_SMNIF_TLR_17_DEFAULT       0x00000000

#define MP1_SMNIF_TLR_17_GET_MASK(mp1_smnif_tlr_17) \
      ((mp1_smnif_tlr_17 & MP1_SMNIF_TLR_17_MASK_MASK) >> MP1_SMNIF_TLR_17_MASK_SHIFT)
#define MP1_SMNIF_TLR_17_GET_RD_ACC(mp1_smnif_tlr_17) \
      ((mp1_smnif_tlr_17 & MP1_SMNIF_TLR_17_RD_ACC_MASK) >> MP1_SMNIF_TLR_17_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_17_GET_WR_ACC(mp1_smnif_tlr_17) \
      ((mp1_smnif_tlr_17 & MP1_SMNIF_TLR_17_WR_ACC_MASK) >> MP1_SMNIF_TLR_17_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_17_GET_SLV_ADDR(mp1_smnif_tlr_17) \
      ((mp1_smnif_tlr_17 & MP1_SMNIF_TLR_17_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_17_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_17_GET_VF_ACC(mp1_smnif_tlr_17) \
      ((mp1_smnif_tlr_17 & MP1_SMNIF_TLR_17_VF_ACC_MASK) >> MP1_SMNIF_TLR_17_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_17_GET_VF_ACC_ENB(mp1_smnif_tlr_17) \
      ((mp1_smnif_tlr_17 & MP1_SMNIF_TLR_17_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_17_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_17_GET_VALID(mp1_smnif_tlr_17) \
      ((mp1_smnif_tlr_17 & MP1_SMNIF_TLR_17_VALID_MASK) >> MP1_SMNIF_TLR_17_VALID_SHIFT)

#define MP1_SMNIF_TLR_17_SET_MASK(mp1_smnif_tlr_17_reg, mask) \
      mp1_smnif_tlr_17_reg = (mp1_smnif_tlr_17_reg & ~MP1_SMNIF_TLR_17_MASK_MASK) | (mask << MP1_SMNIF_TLR_17_MASK_SHIFT)
#define MP1_SMNIF_TLR_17_SET_RD_ACC(mp1_smnif_tlr_17_reg, rd_acc) \
      mp1_smnif_tlr_17_reg = (mp1_smnif_tlr_17_reg & ~MP1_SMNIF_TLR_17_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_17_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_17_SET_WR_ACC(mp1_smnif_tlr_17_reg, wr_acc) \
      mp1_smnif_tlr_17_reg = (mp1_smnif_tlr_17_reg & ~MP1_SMNIF_TLR_17_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_17_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_17_SET_SLV_ADDR(mp1_smnif_tlr_17_reg, slv_addr) \
      mp1_smnif_tlr_17_reg = (mp1_smnif_tlr_17_reg & ~MP1_SMNIF_TLR_17_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_17_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_17_SET_VF_ACC(mp1_smnif_tlr_17_reg, vf_acc) \
      mp1_smnif_tlr_17_reg = (mp1_smnif_tlr_17_reg & ~MP1_SMNIF_TLR_17_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_17_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_17_SET_VF_ACC_ENB(mp1_smnif_tlr_17_reg, vf_acc_enb) \
      mp1_smnif_tlr_17_reg = (mp1_smnif_tlr_17_reg & ~MP1_SMNIF_TLR_17_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_17_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_17_SET_VALID(mp1_smnif_tlr_17_reg, valid) \
      mp1_smnif_tlr_17_reg = (mp1_smnif_tlr_17_reg & ~MP1_SMNIF_TLR_17_VALID_MASK) | (valid << MP1_SMNIF_TLR_17_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_17_t {
            unsigned int mask                           : MP1_SMNIF_TLR_17_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_17_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_17_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_17_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_17_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_17_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_17_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_17_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_17_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_17_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_17_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_17_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_17_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_17_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_17_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_17_MASK_SIZE;
      } mp1_smnif_tlr_17_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_17_t f;
} mp1_smnif_tlr_17_u;


/*
 * MP1_SMNIF_TLR_ADDR_17 struct
 */

#define MP1_SMNIF_TLR_ADDR_17_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_17_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_17_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_17_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_17_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_17_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_17_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_17_MASK \
      (MP1_SMNIF_TLR_ADDR_17_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_17_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_17_DEFAULT  0x00000000

#define MP1_SMNIF_TLR_ADDR_17_GET_START_ADDR(mp1_smnif_tlr_addr_17) \
      ((mp1_smnif_tlr_addr_17 & MP1_SMNIF_TLR_ADDR_17_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_17_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_17_GET_END_ADDR(mp1_smnif_tlr_addr_17) \
      ((mp1_smnif_tlr_addr_17 & MP1_SMNIF_TLR_ADDR_17_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_17_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_17_SET_START_ADDR(mp1_smnif_tlr_addr_17_reg, start_addr) \
      mp1_smnif_tlr_addr_17_reg = (mp1_smnif_tlr_addr_17_reg & ~MP1_SMNIF_TLR_ADDR_17_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_17_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_17_SET_END_ADDR(mp1_smnif_tlr_addr_17_reg, end_addr) \
      mp1_smnif_tlr_addr_17_reg = (mp1_smnif_tlr_addr_17_reg & ~MP1_SMNIF_TLR_ADDR_17_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_17_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_17_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_17_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_17_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_17_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_17_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_17_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_17_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_17_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_17_t f;
} mp1_smnif_tlr_addr_17_u;


/*
 * MP1_SMNIF_TLR_18 struct
 */

#define MP1_SMNIF_TLR_18_REG_SIZE         32
#define MP1_SMNIF_TLR_18_MASK_SIZE  8
#define MP1_SMNIF_TLR_18_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_18_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_18_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_18_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_18_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_18_VALID_SIZE  1

#define MP1_SMNIF_TLR_18_MASK_SHIFT  0
#define MP1_SMNIF_TLR_18_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_18_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_18_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_18_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_18_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_18_VALID_SHIFT  16

#define MP1_SMNIF_TLR_18_MASK_MASK      0x000000ff
#define MP1_SMNIF_TLR_18_RD_ACC_MASK    0x00000100
#define MP1_SMNIF_TLR_18_WR_ACC_MASK    0x00000200
#define MP1_SMNIF_TLR_18_SLV_ADDR_MASK  0x00003c00
#define MP1_SMNIF_TLR_18_VF_ACC_MASK    0x00004000
#define MP1_SMNIF_TLR_18_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_18_VALID_MASK     0x00010000

#define MP1_SMNIF_TLR_18_MASK \
      (MP1_SMNIF_TLR_18_MASK_MASK | \
      MP1_SMNIF_TLR_18_RD_ACC_MASK | \
      MP1_SMNIF_TLR_18_WR_ACC_MASK | \
      MP1_SMNIF_TLR_18_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_18_VF_ACC_MASK | \
      MP1_SMNIF_TLR_18_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_18_VALID_MASK)

#define MP1_SMNIF_TLR_18_DEFAULT       0x00000000

#define MP1_SMNIF_TLR_18_GET_MASK(mp1_smnif_tlr_18) \
      ((mp1_smnif_tlr_18 & MP1_SMNIF_TLR_18_MASK_MASK) >> MP1_SMNIF_TLR_18_MASK_SHIFT)
#define MP1_SMNIF_TLR_18_GET_RD_ACC(mp1_smnif_tlr_18) \
      ((mp1_smnif_tlr_18 & MP1_SMNIF_TLR_18_RD_ACC_MASK) >> MP1_SMNIF_TLR_18_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_18_GET_WR_ACC(mp1_smnif_tlr_18) \
      ((mp1_smnif_tlr_18 & MP1_SMNIF_TLR_18_WR_ACC_MASK) >> MP1_SMNIF_TLR_18_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_18_GET_SLV_ADDR(mp1_smnif_tlr_18) \
      ((mp1_smnif_tlr_18 & MP1_SMNIF_TLR_18_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_18_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_18_GET_VF_ACC(mp1_smnif_tlr_18) \
      ((mp1_smnif_tlr_18 & MP1_SMNIF_TLR_18_VF_ACC_MASK) >> MP1_SMNIF_TLR_18_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_18_GET_VF_ACC_ENB(mp1_smnif_tlr_18) \
      ((mp1_smnif_tlr_18 & MP1_SMNIF_TLR_18_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_18_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_18_GET_VALID(mp1_smnif_tlr_18) \
      ((mp1_smnif_tlr_18 & MP1_SMNIF_TLR_18_VALID_MASK) >> MP1_SMNIF_TLR_18_VALID_SHIFT)

#define MP1_SMNIF_TLR_18_SET_MASK(mp1_smnif_tlr_18_reg, mask) \
      mp1_smnif_tlr_18_reg = (mp1_smnif_tlr_18_reg & ~MP1_SMNIF_TLR_18_MASK_MASK) | (mask << MP1_SMNIF_TLR_18_MASK_SHIFT)
#define MP1_SMNIF_TLR_18_SET_RD_ACC(mp1_smnif_tlr_18_reg, rd_acc) \
      mp1_smnif_tlr_18_reg = (mp1_smnif_tlr_18_reg & ~MP1_SMNIF_TLR_18_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_18_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_18_SET_WR_ACC(mp1_smnif_tlr_18_reg, wr_acc) \
      mp1_smnif_tlr_18_reg = (mp1_smnif_tlr_18_reg & ~MP1_SMNIF_TLR_18_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_18_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_18_SET_SLV_ADDR(mp1_smnif_tlr_18_reg, slv_addr) \
      mp1_smnif_tlr_18_reg = (mp1_smnif_tlr_18_reg & ~MP1_SMNIF_TLR_18_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_18_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_18_SET_VF_ACC(mp1_smnif_tlr_18_reg, vf_acc) \
      mp1_smnif_tlr_18_reg = (mp1_smnif_tlr_18_reg & ~MP1_SMNIF_TLR_18_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_18_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_18_SET_VF_ACC_ENB(mp1_smnif_tlr_18_reg, vf_acc_enb) \
      mp1_smnif_tlr_18_reg = (mp1_smnif_tlr_18_reg & ~MP1_SMNIF_TLR_18_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_18_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_18_SET_VALID(mp1_smnif_tlr_18_reg, valid) \
      mp1_smnif_tlr_18_reg = (mp1_smnif_tlr_18_reg & ~MP1_SMNIF_TLR_18_VALID_MASK) | (valid << MP1_SMNIF_TLR_18_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_18_t {
            unsigned int mask                           : MP1_SMNIF_TLR_18_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_18_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_18_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_18_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_18_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_18_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_18_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_18_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_18_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_18_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_18_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_18_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_18_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_18_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_18_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_18_MASK_SIZE;
      } mp1_smnif_tlr_18_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_18_t f;
} mp1_smnif_tlr_18_u;


/*
 * MP1_SMNIF_TLR_ADDR_18 struct
 */

#define MP1_SMNIF_TLR_ADDR_18_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_18_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_18_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_18_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_18_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_18_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_18_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_18_MASK \
      (MP1_SMNIF_TLR_ADDR_18_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_18_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_18_DEFAULT  0x00000000

#define MP1_SMNIF_TLR_ADDR_18_GET_START_ADDR(mp1_smnif_tlr_addr_18) \
      ((mp1_smnif_tlr_addr_18 & MP1_SMNIF_TLR_ADDR_18_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_18_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_18_GET_END_ADDR(mp1_smnif_tlr_addr_18) \
      ((mp1_smnif_tlr_addr_18 & MP1_SMNIF_TLR_ADDR_18_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_18_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_18_SET_START_ADDR(mp1_smnif_tlr_addr_18_reg, start_addr) \
      mp1_smnif_tlr_addr_18_reg = (mp1_smnif_tlr_addr_18_reg & ~MP1_SMNIF_TLR_ADDR_18_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_18_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_18_SET_END_ADDR(mp1_smnif_tlr_addr_18_reg, end_addr) \
      mp1_smnif_tlr_addr_18_reg = (mp1_smnif_tlr_addr_18_reg & ~MP1_SMNIF_TLR_ADDR_18_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_18_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_18_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_18_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_18_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_18_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_18_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_18_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_18_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_18_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_18_t f;
} mp1_smnif_tlr_addr_18_u;


/*
 * MP1_SMNIF_TLR_19 struct
 */

#define MP1_SMNIF_TLR_19_REG_SIZE         32
#define MP1_SMNIF_TLR_19_MASK_SIZE  8
#define MP1_SMNIF_TLR_19_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_19_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_19_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_19_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_19_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_19_VALID_SIZE  1

#define MP1_SMNIF_TLR_19_MASK_SHIFT  0
#define MP1_SMNIF_TLR_19_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_19_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_19_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_19_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_19_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_19_VALID_SHIFT  16

#define MP1_SMNIF_TLR_19_MASK_MASK      0x000000ff
#define MP1_SMNIF_TLR_19_RD_ACC_MASK    0x00000100
#define MP1_SMNIF_TLR_19_WR_ACC_MASK    0x00000200
#define MP1_SMNIF_TLR_19_SLV_ADDR_MASK  0x00003c00
#define MP1_SMNIF_TLR_19_VF_ACC_MASK    0x00004000
#define MP1_SMNIF_TLR_19_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_19_VALID_MASK     0x00010000

#define MP1_SMNIF_TLR_19_MASK \
      (MP1_SMNIF_TLR_19_MASK_MASK | \
      MP1_SMNIF_TLR_19_RD_ACC_MASK | \
      MP1_SMNIF_TLR_19_WR_ACC_MASK | \
      MP1_SMNIF_TLR_19_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_19_VF_ACC_MASK | \
      MP1_SMNIF_TLR_19_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_19_VALID_MASK)

#define MP1_SMNIF_TLR_19_DEFAULT       0x00000000

#define MP1_SMNIF_TLR_19_GET_MASK(mp1_smnif_tlr_19) \
      ((mp1_smnif_tlr_19 & MP1_SMNIF_TLR_19_MASK_MASK) >> MP1_SMNIF_TLR_19_MASK_SHIFT)
#define MP1_SMNIF_TLR_19_GET_RD_ACC(mp1_smnif_tlr_19) \
      ((mp1_smnif_tlr_19 & MP1_SMNIF_TLR_19_RD_ACC_MASK) >> MP1_SMNIF_TLR_19_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_19_GET_WR_ACC(mp1_smnif_tlr_19) \
      ((mp1_smnif_tlr_19 & MP1_SMNIF_TLR_19_WR_ACC_MASK) >> MP1_SMNIF_TLR_19_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_19_GET_SLV_ADDR(mp1_smnif_tlr_19) \
      ((mp1_smnif_tlr_19 & MP1_SMNIF_TLR_19_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_19_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_19_GET_VF_ACC(mp1_smnif_tlr_19) \
      ((mp1_smnif_tlr_19 & MP1_SMNIF_TLR_19_VF_ACC_MASK) >> MP1_SMNIF_TLR_19_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_19_GET_VF_ACC_ENB(mp1_smnif_tlr_19) \
      ((mp1_smnif_tlr_19 & MP1_SMNIF_TLR_19_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_19_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_19_GET_VALID(mp1_smnif_tlr_19) \
      ((mp1_smnif_tlr_19 & MP1_SMNIF_TLR_19_VALID_MASK) >> MP1_SMNIF_TLR_19_VALID_SHIFT)

#define MP1_SMNIF_TLR_19_SET_MASK(mp1_smnif_tlr_19_reg, mask) \
      mp1_smnif_tlr_19_reg = (mp1_smnif_tlr_19_reg & ~MP1_SMNIF_TLR_19_MASK_MASK) | (mask << MP1_SMNIF_TLR_19_MASK_SHIFT)
#define MP1_SMNIF_TLR_19_SET_RD_ACC(mp1_smnif_tlr_19_reg, rd_acc) \
      mp1_smnif_tlr_19_reg = (mp1_smnif_tlr_19_reg & ~MP1_SMNIF_TLR_19_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_19_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_19_SET_WR_ACC(mp1_smnif_tlr_19_reg, wr_acc) \
      mp1_smnif_tlr_19_reg = (mp1_smnif_tlr_19_reg & ~MP1_SMNIF_TLR_19_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_19_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_19_SET_SLV_ADDR(mp1_smnif_tlr_19_reg, slv_addr) \
      mp1_smnif_tlr_19_reg = (mp1_smnif_tlr_19_reg & ~MP1_SMNIF_TLR_19_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_19_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_19_SET_VF_ACC(mp1_smnif_tlr_19_reg, vf_acc) \
      mp1_smnif_tlr_19_reg = (mp1_smnif_tlr_19_reg & ~MP1_SMNIF_TLR_19_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_19_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_19_SET_VF_ACC_ENB(mp1_smnif_tlr_19_reg, vf_acc_enb) \
      mp1_smnif_tlr_19_reg = (mp1_smnif_tlr_19_reg & ~MP1_SMNIF_TLR_19_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_19_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_19_SET_VALID(mp1_smnif_tlr_19_reg, valid) \
      mp1_smnif_tlr_19_reg = (mp1_smnif_tlr_19_reg & ~MP1_SMNIF_TLR_19_VALID_MASK) | (valid << MP1_SMNIF_TLR_19_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_19_t {
            unsigned int mask                           : MP1_SMNIF_TLR_19_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_19_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_19_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_19_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_19_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_19_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_19_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_19_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_19_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_19_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_19_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_19_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_19_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_19_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_19_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_19_MASK_SIZE;
      } mp1_smnif_tlr_19_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_19_t f;
} mp1_smnif_tlr_19_u;


/*
 * MP1_SMNIF_TLR_ADDR_19 struct
 */

#define MP1_SMNIF_TLR_ADDR_19_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_19_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_19_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_19_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_19_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_19_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_19_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_19_MASK \
      (MP1_SMNIF_TLR_ADDR_19_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_19_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_19_DEFAULT  0x00000000

#define MP1_SMNIF_TLR_ADDR_19_GET_START_ADDR(mp1_smnif_tlr_addr_19) \
      ((mp1_smnif_tlr_addr_19 & MP1_SMNIF_TLR_ADDR_19_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_19_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_19_GET_END_ADDR(mp1_smnif_tlr_addr_19) \
      ((mp1_smnif_tlr_addr_19 & MP1_SMNIF_TLR_ADDR_19_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_19_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_19_SET_START_ADDR(mp1_smnif_tlr_addr_19_reg, start_addr) \
      mp1_smnif_tlr_addr_19_reg = (mp1_smnif_tlr_addr_19_reg & ~MP1_SMNIF_TLR_ADDR_19_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_19_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_19_SET_END_ADDR(mp1_smnif_tlr_addr_19_reg, end_addr) \
      mp1_smnif_tlr_addr_19_reg = (mp1_smnif_tlr_addr_19_reg & ~MP1_SMNIF_TLR_ADDR_19_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_19_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_19_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_19_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_19_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_19_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_19_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_19_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_19_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_19_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_19_t f;
} mp1_smnif_tlr_addr_19_u;


/*
 * MP1_SMNIF_TLR_20 struct
 */

#define MP1_SMNIF_TLR_20_REG_SIZE         32
#define MP1_SMNIF_TLR_20_MASK_SIZE  8
#define MP1_SMNIF_TLR_20_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_20_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_20_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_20_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_20_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_20_VALID_SIZE  1

#define MP1_SMNIF_TLR_20_MASK_SHIFT  0
#define MP1_SMNIF_TLR_20_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_20_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_20_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_20_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_20_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_20_VALID_SHIFT  16

#define MP1_SMNIF_TLR_20_MASK_MASK      0x000000ff
#define MP1_SMNIF_TLR_20_RD_ACC_MASK    0x00000100
#define MP1_SMNIF_TLR_20_WR_ACC_MASK    0x00000200
#define MP1_SMNIF_TLR_20_SLV_ADDR_MASK  0x00003c00
#define MP1_SMNIF_TLR_20_VF_ACC_MASK    0x00004000
#define MP1_SMNIF_TLR_20_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_20_VALID_MASK     0x00010000

#define MP1_SMNIF_TLR_20_MASK \
      (MP1_SMNIF_TLR_20_MASK_MASK | \
      MP1_SMNIF_TLR_20_RD_ACC_MASK | \
      MP1_SMNIF_TLR_20_WR_ACC_MASK | \
      MP1_SMNIF_TLR_20_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_20_VF_ACC_MASK | \
      MP1_SMNIF_TLR_20_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_20_VALID_MASK)

#define MP1_SMNIF_TLR_20_DEFAULT       0x00000000

#define MP1_SMNIF_TLR_20_GET_MASK(mp1_smnif_tlr_20) \
      ((mp1_smnif_tlr_20 & MP1_SMNIF_TLR_20_MASK_MASK) >> MP1_SMNIF_TLR_20_MASK_SHIFT)
#define MP1_SMNIF_TLR_20_GET_RD_ACC(mp1_smnif_tlr_20) \
      ((mp1_smnif_tlr_20 & MP1_SMNIF_TLR_20_RD_ACC_MASK) >> MP1_SMNIF_TLR_20_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_20_GET_WR_ACC(mp1_smnif_tlr_20) \
      ((mp1_smnif_tlr_20 & MP1_SMNIF_TLR_20_WR_ACC_MASK) >> MP1_SMNIF_TLR_20_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_20_GET_SLV_ADDR(mp1_smnif_tlr_20) \
      ((mp1_smnif_tlr_20 & MP1_SMNIF_TLR_20_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_20_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_20_GET_VF_ACC(mp1_smnif_tlr_20) \
      ((mp1_smnif_tlr_20 & MP1_SMNIF_TLR_20_VF_ACC_MASK) >> MP1_SMNIF_TLR_20_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_20_GET_VF_ACC_ENB(mp1_smnif_tlr_20) \
      ((mp1_smnif_tlr_20 & MP1_SMNIF_TLR_20_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_20_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_20_GET_VALID(mp1_smnif_tlr_20) \
      ((mp1_smnif_tlr_20 & MP1_SMNIF_TLR_20_VALID_MASK) >> MP1_SMNIF_TLR_20_VALID_SHIFT)

#define MP1_SMNIF_TLR_20_SET_MASK(mp1_smnif_tlr_20_reg, mask) \
      mp1_smnif_tlr_20_reg = (mp1_smnif_tlr_20_reg & ~MP1_SMNIF_TLR_20_MASK_MASK) | (mask << MP1_SMNIF_TLR_20_MASK_SHIFT)
#define MP1_SMNIF_TLR_20_SET_RD_ACC(mp1_smnif_tlr_20_reg, rd_acc) \
      mp1_smnif_tlr_20_reg = (mp1_smnif_tlr_20_reg & ~MP1_SMNIF_TLR_20_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_20_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_20_SET_WR_ACC(mp1_smnif_tlr_20_reg, wr_acc) \
      mp1_smnif_tlr_20_reg = (mp1_smnif_tlr_20_reg & ~MP1_SMNIF_TLR_20_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_20_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_20_SET_SLV_ADDR(mp1_smnif_tlr_20_reg, slv_addr) \
      mp1_smnif_tlr_20_reg = (mp1_smnif_tlr_20_reg & ~MP1_SMNIF_TLR_20_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_20_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_20_SET_VF_ACC(mp1_smnif_tlr_20_reg, vf_acc) \
      mp1_smnif_tlr_20_reg = (mp1_smnif_tlr_20_reg & ~MP1_SMNIF_TLR_20_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_20_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_20_SET_VF_ACC_ENB(mp1_smnif_tlr_20_reg, vf_acc_enb) \
      mp1_smnif_tlr_20_reg = (mp1_smnif_tlr_20_reg & ~MP1_SMNIF_TLR_20_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_20_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_20_SET_VALID(mp1_smnif_tlr_20_reg, valid) \
      mp1_smnif_tlr_20_reg = (mp1_smnif_tlr_20_reg & ~MP1_SMNIF_TLR_20_VALID_MASK) | (valid << MP1_SMNIF_TLR_20_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_20_t {
            unsigned int mask                           : MP1_SMNIF_TLR_20_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_20_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_20_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_20_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_20_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_20_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_20_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_20_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_20_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_20_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_20_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_20_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_20_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_20_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_20_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_20_MASK_SIZE;
      } mp1_smnif_tlr_20_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_20_t f;
} mp1_smnif_tlr_20_u;


/*
 * MP1_SMNIF_TLR_ADDR_20 struct
 */

#define MP1_SMNIF_TLR_ADDR_20_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_20_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_20_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_20_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_20_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_20_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_20_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_20_MASK \
      (MP1_SMNIF_TLR_ADDR_20_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_20_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_20_DEFAULT  0x00000000

#define MP1_SMNIF_TLR_ADDR_20_GET_START_ADDR(mp1_smnif_tlr_addr_20) \
      ((mp1_smnif_tlr_addr_20 & MP1_SMNIF_TLR_ADDR_20_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_20_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_20_GET_END_ADDR(mp1_smnif_tlr_addr_20) \
      ((mp1_smnif_tlr_addr_20 & MP1_SMNIF_TLR_ADDR_20_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_20_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_20_SET_START_ADDR(mp1_smnif_tlr_addr_20_reg, start_addr) \
      mp1_smnif_tlr_addr_20_reg = (mp1_smnif_tlr_addr_20_reg & ~MP1_SMNIF_TLR_ADDR_20_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_20_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_20_SET_END_ADDR(mp1_smnif_tlr_addr_20_reg, end_addr) \
      mp1_smnif_tlr_addr_20_reg = (mp1_smnif_tlr_addr_20_reg & ~MP1_SMNIF_TLR_ADDR_20_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_20_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_20_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_20_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_20_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_20_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_20_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_20_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_20_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_20_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_20_t f;
} mp1_smnif_tlr_addr_20_u;


/*
 * MP1_SMNIF_TLR_21 struct
 */

#define MP1_SMNIF_TLR_21_REG_SIZE         32
#define MP1_SMNIF_TLR_21_MASK_SIZE  8
#define MP1_SMNIF_TLR_21_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_21_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_21_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_21_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_21_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_21_VALID_SIZE  1

#define MP1_SMNIF_TLR_21_MASK_SHIFT  0
#define MP1_SMNIF_TLR_21_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_21_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_21_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_21_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_21_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_21_VALID_SHIFT  16

#define MP1_SMNIF_TLR_21_MASK_MASK      0x000000ff
#define MP1_SMNIF_TLR_21_RD_ACC_MASK    0x00000100
#define MP1_SMNIF_TLR_21_WR_ACC_MASK    0x00000200
#define MP1_SMNIF_TLR_21_SLV_ADDR_MASK  0x00003c00
#define MP1_SMNIF_TLR_21_VF_ACC_MASK    0x00004000
#define MP1_SMNIF_TLR_21_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_21_VALID_MASK     0x00010000

#define MP1_SMNIF_TLR_21_MASK \
      (MP1_SMNIF_TLR_21_MASK_MASK | \
      MP1_SMNIF_TLR_21_RD_ACC_MASK | \
      MP1_SMNIF_TLR_21_WR_ACC_MASK | \
      MP1_SMNIF_TLR_21_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_21_VF_ACC_MASK | \
      MP1_SMNIF_TLR_21_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_21_VALID_MASK)

#define MP1_SMNIF_TLR_21_DEFAULT       0x00000000

#define MP1_SMNIF_TLR_21_GET_MASK(mp1_smnif_tlr_21) \
      ((mp1_smnif_tlr_21 & MP1_SMNIF_TLR_21_MASK_MASK) >> MP1_SMNIF_TLR_21_MASK_SHIFT)
#define MP1_SMNIF_TLR_21_GET_RD_ACC(mp1_smnif_tlr_21) \
      ((mp1_smnif_tlr_21 & MP1_SMNIF_TLR_21_RD_ACC_MASK) >> MP1_SMNIF_TLR_21_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_21_GET_WR_ACC(mp1_smnif_tlr_21) \
      ((mp1_smnif_tlr_21 & MP1_SMNIF_TLR_21_WR_ACC_MASK) >> MP1_SMNIF_TLR_21_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_21_GET_SLV_ADDR(mp1_smnif_tlr_21) \
      ((mp1_smnif_tlr_21 & MP1_SMNIF_TLR_21_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_21_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_21_GET_VF_ACC(mp1_smnif_tlr_21) \
      ((mp1_smnif_tlr_21 & MP1_SMNIF_TLR_21_VF_ACC_MASK) >> MP1_SMNIF_TLR_21_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_21_GET_VF_ACC_ENB(mp1_smnif_tlr_21) \
      ((mp1_smnif_tlr_21 & MP1_SMNIF_TLR_21_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_21_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_21_GET_VALID(mp1_smnif_tlr_21) \
      ((mp1_smnif_tlr_21 & MP1_SMNIF_TLR_21_VALID_MASK) >> MP1_SMNIF_TLR_21_VALID_SHIFT)

#define MP1_SMNIF_TLR_21_SET_MASK(mp1_smnif_tlr_21_reg, mask) \
      mp1_smnif_tlr_21_reg = (mp1_smnif_tlr_21_reg & ~MP1_SMNIF_TLR_21_MASK_MASK) | (mask << MP1_SMNIF_TLR_21_MASK_SHIFT)
#define MP1_SMNIF_TLR_21_SET_RD_ACC(mp1_smnif_tlr_21_reg, rd_acc) \
      mp1_smnif_tlr_21_reg = (mp1_smnif_tlr_21_reg & ~MP1_SMNIF_TLR_21_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_21_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_21_SET_WR_ACC(mp1_smnif_tlr_21_reg, wr_acc) \
      mp1_smnif_tlr_21_reg = (mp1_smnif_tlr_21_reg & ~MP1_SMNIF_TLR_21_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_21_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_21_SET_SLV_ADDR(mp1_smnif_tlr_21_reg, slv_addr) \
      mp1_smnif_tlr_21_reg = (mp1_smnif_tlr_21_reg & ~MP1_SMNIF_TLR_21_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_21_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_21_SET_VF_ACC(mp1_smnif_tlr_21_reg, vf_acc) \
      mp1_smnif_tlr_21_reg = (mp1_smnif_tlr_21_reg & ~MP1_SMNIF_TLR_21_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_21_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_21_SET_VF_ACC_ENB(mp1_smnif_tlr_21_reg, vf_acc_enb) \
      mp1_smnif_tlr_21_reg = (mp1_smnif_tlr_21_reg & ~MP1_SMNIF_TLR_21_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_21_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_21_SET_VALID(mp1_smnif_tlr_21_reg, valid) \
      mp1_smnif_tlr_21_reg = (mp1_smnif_tlr_21_reg & ~MP1_SMNIF_TLR_21_VALID_MASK) | (valid << MP1_SMNIF_TLR_21_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_21_t {
            unsigned int mask                           : MP1_SMNIF_TLR_21_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_21_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_21_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_21_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_21_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_21_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_21_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_21_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_21_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_21_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_21_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_21_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_21_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_21_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_21_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_21_MASK_SIZE;
      } mp1_smnif_tlr_21_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_21_t f;
} mp1_smnif_tlr_21_u;


/*
 * MP1_SMNIF_TLR_ADDR_21 struct
 */

#define MP1_SMNIF_TLR_ADDR_21_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_21_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_21_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_21_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_21_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_21_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_21_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_21_MASK \
      (MP1_SMNIF_TLR_ADDR_21_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_21_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_21_DEFAULT  0x00000000

#define MP1_SMNIF_TLR_ADDR_21_GET_START_ADDR(mp1_smnif_tlr_addr_21) \
      ((mp1_smnif_tlr_addr_21 & MP1_SMNIF_TLR_ADDR_21_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_21_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_21_GET_END_ADDR(mp1_smnif_tlr_addr_21) \
      ((mp1_smnif_tlr_addr_21 & MP1_SMNIF_TLR_ADDR_21_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_21_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_21_SET_START_ADDR(mp1_smnif_tlr_addr_21_reg, start_addr) \
      mp1_smnif_tlr_addr_21_reg = (mp1_smnif_tlr_addr_21_reg & ~MP1_SMNIF_TLR_ADDR_21_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_21_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_21_SET_END_ADDR(mp1_smnif_tlr_addr_21_reg, end_addr) \
      mp1_smnif_tlr_addr_21_reg = (mp1_smnif_tlr_addr_21_reg & ~MP1_SMNIF_TLR_ADDR_21_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_21_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_21_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_21_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_21_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_21_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_21_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_21_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_21_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_21_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_21_t f;
} mp1_smnif_tlr_addr_21_u;


/*
 * MP1_SMNIF_TLR_22 struct
 */

#define MP1_SMNIF_TLR_22_REG_SIZE         32
#define MP1_SMNIF_TLR_22_MASK_SIZE  8
#define MP1_SMNIF_TLR_22_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_22_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_22_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_22_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_22_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_22_VALID_SIZE  1

#define MP1_SMNIF_TLR_22_MASK_SHIFT  0
#define MP1_SMNIF_TLR_22_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_22_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_22_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_22_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_22_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_22_VALID_SHIFT  16

#define MP1_SMNIF_TLR_22_MASK_MASK      0x000000ff
#define MP1_SMNIF_TLR_22_RD_ACC_MASK    0x00000100
#define MP1_SMNIF_TLR_22_WR_ACC_MASK    0x00000200
#define MP1_SMNIF_TLR_22_SLV_ADDR_MASK  0x00003c00
#define MP1_SMNIF_TLR_22_VF_ACC_MASK    0x00004000
#define MP1_SMNIF_TLR_22_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_22_VALID_MASK     0x00010000

#define MP1_SMNIF_TLR_22_MASK \
      (MP1_SMNIF_TLR_22_MASK_MASK | \
      MP1_SMNIF_TLR_22_RD_ACC_MASK | \
      MP1_SMNIF_TLR_22_WR_ACC_MASK | \
      MP1_SMNIF_TLR_22_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_22_VF_ACC_MASK | \
      MP1_SMNIF_TLR_22_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_22_VALID_MASK)

#define MP1_SMNIF_TLR_22_DEFAULT       0x00000000

#define MP1_SMNIF_TLR_22_GET_MASK(mp1_smnif_tlr_22) \
      ((mp1_smnif_tlr_22 & MP1_SMNIF_TLR_22_MASK_MASK) >> MP1_SMNIF_TLR_22_MASK_SHIFT)
#define MP1_SMNIF_TLR_22_GET_RD_ACC(mp1_smnif_tlr_22) \
      ((mp1_smnif_tlr_22 & MP1_SMNIF_TLR_22_RD_ACC_MASK) >> MP1_SMNIF_TLR_22_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_22_GET_WR_ACC(mp1_smnif_tlr_22) \
      ((mp1_smnif_tlr_22 & MP1_SMNIF_TLR_22_WR_ACC_MASK) >> MP1_SMNIF_TLR_22_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_22_GET_SLV_ADDR(mp1_smnif_tlr_22) \
      ((mp1_smnif_tlr_22 & MP1_SMNIF_TLR_22_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_22_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_22_GET_VF_ACC(mp1_smnif_tlr_22) \
      ((mp1_smnif_tlr_22 & MP1_SMNIF_TLR_22_VF_ACC_MASK) >> MP1_SMNIF_TLR_22_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_22_GET_VF_ACC_ENB(mp1_smnif_tlr_22) \
      ((mp1_smnif_tlr_22 & MP1_SMNIF_TLR_22_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_22_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_22_GET_VALID(mp1_smnif_tlr_22) \
      ((mp1_smnif_tlr_22 & MP1_SMNIF_TLR_22_VALID_MASK) >> MP1_SMNIF_TLR_22_VALID_SHIFT)

#define MP1_SMNIF_TLR_22_SET_MASK(mp1_smnif_tlr_22_reg, mask) \
      mp1_smnif_tlr_22_reg = (mp1_smnif_tlr_22_reg & ~MP1_SMNIF_TLR_22_MASK_MASK) | (mask << MP1_SMNIF_TLR_22_MASK_SHIFT)
#define MP1_SMNIF_TLR_22_SET_RD_ACC(mp1_smnif_tlr_22_reg, rd_acc) \
      mp1_smnif_tlr_22_reg = (mp1_smnif_tlr_22_reg & ~MP1_SMNIF_TLR_22_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_22_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_22_SET_WR_ACC(mp1_smnif_tlr_22_reg, wr_acc) \
      mp1_smnif_tlr_22_reg = (mp1_smnif_tlr_22_reg & ~MP1_SMNIF_TLR_22_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_22_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_22_SET_SLV_ADDR(mp1_smnif_tlr_22_reg, slv_addr) \
      mp1_smnif_tlr_22_reg = (mp1_smnif_tlr_22_reg & ~MP1_SMNIF_TLR_22_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_22_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_22_SET_VF_ACC(mp1_smnif_tlr_22_reg, vf_acc) \
      mp1_smnif_tlr_22_reg = (mp1_smnif_tlr_22_reg & ~MP1_SMNIF_TLR_22_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_22_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_22_SET_VF_ACC_ENB(mp1_smnif_tlr_22_reg, vf_acc_enb) \
      mp1_smnif_tlr_22_reg = (mp1_smnif_tlr_22_reg & ~MP1_SMNIF_TLR_22_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_22_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_22_SET_VALID(mp1_smnif_tlr_22_reg, valid) \
      mp1_smnif_tlr_22_reg = (mp1_smnif_tlr_22_reg & ~MP1_SMNIF_TLR_22_VALID_MASK) | (valid << MP1_SMNIF_TLR_22_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_22_t {
            unsigned int mask                           : MP1_SMNIF_TLR_22_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_22_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_22_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_22_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_22_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_22_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_22_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_22_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_22_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_22_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_22_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_22_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_22_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_22_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_22_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_22_MASK_SIZE;
      } mp1_smnif_tlr_22_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_22_t f;
} mp1_smnif_tlr_22_u;


/*
 * MP1_SMNIF_TLR_ADDR_22 struct
 */

#define MP1_SMNIF_TLR_ADDR_22_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_22_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_22_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_22_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_22_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_22_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_22_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_22_MASK \
      (MP1_SMNIF_TLR_ADDR_22_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_22_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_22_DEFAULT  0x00000000

#define MP1_SMNIF_TLR_ADDR_22_GET_START_ADDR(mp1_smnif_tlr_addr_22) \
      ((mp1_smnif_tlr_addr_22 & MP1_SMNIF_TLR_ADDR_22_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_22_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_22_GET_END_ADDR(mp1_smnif_tlr_addr_22) \
      ((mp1_smnif_tlr_addr_22 & MP1_SMNIF_TLR_ADDR_22_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_22_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_22_SET_START_ADDR(mp1_smnif_tlr_addr_22_reg, start_addr) \
      mp1_smnif_tlr_addr_22_reg = (mp1_smnif_tlr_addr_22_reg & ~MP1_SMNIF_TLR_ADDR_22_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_22_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_22_SET_END_ADDR(mp1_smnif_tlr_addr_22_reg, end_addr) \
      mp1_smnif_tlr_addr_22_reg = (mp1_smnif_tlr_addr_22_reg & ~MP1_SMNIF_TLR_ADDR_22_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_22_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_22_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_22_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_22_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_22_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_22_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_22_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_22_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_22_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_22_t f;
} mp1_smnif_tlr_addr_22_u;


/*
 * MP1_SMNIF_TLR_23 struct
 */

#define MP1_SMNIF_TLR_23_REG_SIZE         32
#define MP1_SMNIF_TLR_23_MASK_SIZE  8
#define MP1_SMNIF_TLR_23_RD_ACC_SIZE  1
#define MP1_SMNIF_TLR_23_WR_ACC_SIZE  1
#define MP1_SMNIF_TLR_23_SLV_ADDR_SIZE  4
#define MP1_SMNIF_TLR_23_VF_ACC_SIZE  1
#define MP1_SMNIF_TLR_23_VF_ACC_ENB_SIZE  1
#define MP1_SMNIF_TLR_23_VALID_SIZE  1

#define MP1_SMNIF_TLR_23_MASK_SHIFT  0
#define MP1_SMNIF_TLR_23_RD_ACC_SHIFT  8
#define MP1_SMNIF_TLR_23_WR_ACC_SHIFT  9
#define MP1_SMNIF_TLR_23_SLV_ADDR_SHIFT  10
#define MP1_SMNIF_TLR_23_VF_ACC_SHIFT  14
#define MP1_SMNIF_TLR_23_VF_ACC_ENB_SHIFT  15
#define MP1_SMNIF_TLR_23_VALID_SHIFT  16

#define MP1_SMNIF_TLR_23_MASK_MASK      0x000000ff
#define MP1_SMNIF_TLR_23_RD_ACC_MASK    0x00000100
#define MP1_SMNIF_TLR_23_WR_ACC_MASK    0x00000200
#define MP1_SMNIF_TLR_23_SLV_ADDR_MASK  0x00003c00
#define MP1_SMNIF_TLR_23_VF_ACC_MASK    0x00004000
#define MP1_SMNIF_TLR_23_VF_ACC_ENB_MASK  0x00008000
#define MP1_SMNIF_TLR_23_VALID_MASK     0x00010000

#define MP1_SMNIF_TLR_23_MASK \
      (MP1_SMNIF_TLR_23_MASK_MASK | \
      MP1_SMNIF_TLR_23_RD_ACC_MASK | \
      MP1_SMNIF_TLR_23_WR_ACC_MASK | \
      MP1_SMNIF_TLR_23_SLV_ADDR_MASK | \
      MP1_SMNIF_TLR_23_VF_ACC_MASK | \
      MP1_SMNIF_TLR_23_VF_ACC_ENB_MASK | \
      MP1_SMNIF_TLR_23_VALID_MASK)

#define MP1_SMNIF_TLR_23_DEFAULT       0x00000000

#define MP1_SMNIF_TLR_23_GET_MASK(mp1_smnif_tlr_23) \
      ((mp1_smnif_tlr_23 & MP1_SMNIF_TLR_23_MASK_MASK) >> MP1_SMNIF_TLR_23_MASK_SHIFT)
#define MP1_SMNIF_TLR_23_GET_RD_ACC(mp1_smnif_tlr_23) \
      ((mp1_smnif_tlr_23 & MP1_SMNIF_TLR_23_RD_ACC_MASK) >> MP1_SMNIF_TLR_23_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_23_GET_WR_ACC(mp1_smnif_tlr_23) \
      ((mp1_smnif_tlr_23 & MP1_SMNIF_TLR_23_WR_ACC_MASK) >> MP1_SMNIF_TLR_23_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_23_GET_SLV_ADDR(mp1_smnif_tlr_23) \
      ((mp1_smnif_tlr_23 & MP1_SMNIF_TLR_23_SLV_ADDR_MASK) >> MP1_SMNIF_TLR_23_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_23_GET_VF_ACC(mp1_smnif_tlr_23) \
      ((mp1_smnif_tlr_23 & MP1_SMNIF_TLR_23_VF_ACC_MASK) >> MP1_SMNIF_TLR_23_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_23_GET_VF_ACC_ENB(mp1_smnif_tlr_23) \
      ((mp1_smnif_tlr_23 & MP1_SMNIF_TLR_23_VF_ACC_ENB_MASK) >> MP1_SMNIF_TLR_23_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_23_GET_VALID(mp1_smnif_tlr_23) \
      ((mp1_smnif_tlr_23 & MP1_SMNIF_TLR_23_VALID_MASK) >> MP1_SMNIF_TLR_23_VALID_SHIFT)

#define MP1_SMNIF_TLR_23_SET_MASK(mp1_smnif_tlr_23_reg, mask) \
      mp1_smnif_tlr_23_reg = (mp1_smnif_tlr_23_reg & ~MP1_SMNIF_TLR_23_MASK_MASK) | (mask << MP1_SMNIF_TLR_23_MASK_SHIFT)
#define MP1_SMNIF_TLR_23_SET_RD_ACC(mp1_smnif_tlr_23_reg, rd_acc) \
      mp1_smnif_tlr_23_reg = (mp1_smnif_tlr_23_reg & ~MP1_SMNIF_TLR_23_RD_ACC_MASK) | (rd_acc << MP1_SMNIF_TLR_23_RD_ACC_SHIFT)
#define MP1_SMNIF_TLR_23_SET_WR_ACC(mp1_smnif_tlr_23_reg, wr_acc) \
      mp1_smnif_tlr_23_reg = (mp1_smnif_tlr_23_reg & ~MP1_SMNIF_TLR_23_WR_ACC_MASK) | (wr_acc << MP1_SMNIF_TLR_23_WR_ACC_SHIFT)
#define MP1_SMNIF_TLR_23_SET_SLV_ADDR(mp1_smnif_tlr_23_reg, slv_addr) \
      mp1_smnif_tlr_23_reg = (mp1_smnif_tlr_23_reg & ~MP1_SMNIF_TLR_23_SLV_ADDR_MASK) | (slv_addr << MP1_SMNIF_TLR_23_SLV_ADDR_SHIFT)
#define MP1_SMNIF_TLR_23_SET_VF_ACC(mp1_smnif_tlr_23_reg, vf_acc) \
      mp1_smnif_tlr_23_reg = (mp1_smnif_tlr_23_reg & ~MP1_SMNIF_TLR_23_VF_ACC_MASK) | (vf_acc << MP1_SMNIF_TLR_23_VF_ACC_SHIFT)
#define MP1_SMNIF_TLR_23_SET_VF_ACC_ENB(mp1_smnif_tlr_23_reg, vf_acc_enb) \
      mp1_smnif_tlr_23_reg = (mp1_smnif_tlr_23_reg & ~MP1_SMNIF_TLR_23_VF_ACC_ENB_MASK) | (vf_acc_enb << MP1_SMNIF_TLR_23_VF_ACC_ENB_SHIFT)
#define MP1_SMNIF_TLR_23_SET_VALID(mp1_smnif_tlr_23_reg, valid) \
      mp1_smnif_tlr_23_reg = (mp1_smnif_tlr_23_reg & ~MP1_SMNIF_TLR_23_VALID_MASK) | (valid << MP1_SMNIF_TLR_23_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_23_t {
            unsigned int mask                           : MP1_SMNIF_TLR_23_MASK_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_23_RD_ACC_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_23_WR_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_23_SLV_ADDR_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_23_VF_ACC_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_23_VF_ACC_ENB_SIZE;
            unsigned int valid                          : MP1_SMNIF_TLR_23_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_smnif_tlr_23_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_23_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_SMNIF_TLR_23_VALID_SIZE;
            unsigned int vf_acc_enb                     : MP1_SMNIF_TLR_23_VF_ACC_ENB_SIZE;
            unsigned int vf_acc                         : MP1_SMNIF_TLR_23_VF_ACC_SIZE;
            unsigned int slv_addr                       : MP1_SMNIF_TLR_23_SLV_ADDR_SIZE;
            unsigned int wr_acc                         : MP1_SMNIF_TLR_23_WR_ACC_SIZE;
            unsigned int rd_acc                         : MP1_SMNIF_TLR_23_RD_ACC_SIZE;
            unsigned int mask                           : MP1_SMNIF_TLR_23_MASK_SIZE;
      } mp1_smnif_tlr_23_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_23_t f;
} mp1_smnif_tlr_23_u;


/*
 * MP1_SMNIF_TLR_ADDR_23 struct
 */

#define MP1_SMNIF_TLR_ADDR_23_REG_SIZE         32
#define MP1_SMNIF_TLR_ADDR_23_START_ADDR_SIZE  16
#define MP1_SMNIF_TLR_ADDR_23_END_ADDR_SIZE  16

#define MP1_SMNIF_TLR_ADDR_23_START_ADDR_SHIFT  0
#define MP1_SMNIF_TLR_ADDR_23_END_ADDR_SHIFT  16

#define MP1_SMNIF_TLR_ADDR_23_START_ADDR_MASK  0x0000ffff
#define MP1_SMNIF_TLR_ADDR_23_END_ADDR_MASK  0xffff0000

#define MP1_SMNIF_TLR_ADDR_23_MASK \
      (MP1_SMNIF_TLR_ADDR_23_START_ADDR_MASK | \
      MP1_SMNIF_TLR_ADDR_23_END_ADDR_MASK)

#define MP1_SMNIF_TLR_ADDR_23_DEFAULT  0x00000000

#define MP1_SMNIF_TLR_ADDR_23_GET_START_ADDR(mp1_smnif_tlr_addr_23) \
      ((mp1_smnif_tlr_addr_23 & MP1_SMNIF_TLR_ADDR_23_START_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_23_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_23_GET_END_ADDR(mp1_smnif_tlr_addr_23) \
      ((mp1_smnif_tlr_addr_23 & MP1_SMNIF_TLR_ADDR_23_END_ADDR_MASK) >> MP1_SMNIF_TLR_ADDR_23_END_ADDR_SHIFT)

#define MP1_SMNIF_TLR_ADDR_23_SET_START_ADDR(mp1_smnif_tlr_addr_23_reg, start_addr) \
      mp1_smnif_tlr_addr_23_reg = (mp1_smnif_tlr_addr_23_reg & ~MP1_SMNIF_TLR_ADDR_23_START_ADDR_MASK) | (start_addr << MP1_SMNIF_TLR_ADDR_23_START_ADDR_SHIFT)
#define MP1_SMNIF_TLR_ADDR_23_SET_END_ADDR(mp1_smnif_tlr_addr_23_reg, end_addr) \
      mp1_smnif_tlr_addr_23_reg = (mp1_smnif_tlr_addr_23_reg & ~MP1_SMNIF_TLR_ADDR_23_END_ADDR_MASK) | (end_addr << MP1_SMNIF_TLR_ADDR_23_END_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_23_t {
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_23_START_ADDR_SIZE;
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_23_END_ADDR_SIZE;
      } mp1_smnif_tlr_addr_23_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlr_addr_23_t {
            unsigned int end_addr                       : MP1_SMNIF_TLR_ADDR_23_END_ADDR_SIZE;
            unsigned int start_addr                     : MP1_SMNIF_TLR_ADDR_23_START_ADDR_SIZE;
      } mp1_smnif_tlr_addr_23_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlr_addr_23_t f;
} mp1_smnif_tlr_addr_23_u;


/*
 * MP1_SMNIF_TLVV_WR_VIOL_ADDR struct
 */

#define MP1_SMNIF_TLVV_WR_VIOL_ADDR_REG_SIZE         32
#define MP1_SMNIF_TLVV_WR_VIOL_ADDR_AXI_ADDR_SIZE  32

#define MP1_SMNIF_TLVV_WR_VIOL_ADDR_AXI_ADDR_SHIFT  0

#define MP1_SMNIF_TLVV_WR_VIOL_ADDR_AXI_ADDR_MASK  0xffffffff

#define MP1_SMNIF_TLVV_WR_VIOL_ADDR_MASK \
      (MP1_SMNIF_TLVV_WR_VIOL_ADDR_AXI_ADDR_MASK)

#define MP1_SMNIF_TLVV_WR_VIOL_ADDR_DEFAULT 0x00000000

#define MP1_SMNIF_TLVV_WR_VIOL_ADDR_GET_AXI_ADDR(mp1_smnif_tlvv_wr_viol_addr) \
      ((mp1_smnif_tlvv_wr_viol_addr & MP1_SMNIF_TLVV_WR_VIOL_ADDR_AXI_ADDR_MASK) >> MP1_SMNIF_TLVV_WR_VIOL_ADDR_AXI_ADDR_SHIFT)

#define MP1_SMNIF_TLVV_WR_VIOL_ADDR_SET_AXI_ADDR(mp1_smnif_tlvv_wr_viol_addr_reg, axi_addr) \
      mp1_smnif_tlvv_wr_viol_addr_reg = (mp1_smnif_tlvv_wr_viol_addr_reg & ~MP1_SMNIF_TLVV_WR_VIOL_ADDR_AXI_ADDR_MASK) | (axi_addr << MP1_SMNIF_TLVV_WR_VIOL_ADDR_AXI_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlvv_wr_viol_addr_t {
            unsigned int axi_addr                       : MP1_SMNIF_TLVV_WR_VIOL_ADDR_AXI_ADDR_SIZE;
      } mp1_smnif_tlvv_wr_viol_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlvv_wr_viol_addr_t {
            unsigned int axi_addr                       : MP1_SMNIF_TLVV_WR_VIOL_ADDR_AXI_ADDR_SIZE;
      } mp1_smnif_tlvv_wr_viol_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlvv_wr_viol_addr_t f;
} mp1_smnif_tlvv_wr_viol_addr_u;


/*
 * MP1_SMNIF_TLVV_WR_VIOL_STATUS struct
 */

#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_REG_SIZE         32
#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_DET_SIZE  1
#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_CLEAR_SIZE  1
#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_AXI_ID_SIZE  21
#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_AXI_PROT_SIZE  3

#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_DET_SHIFT  0
#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_CLEAR_SHIFT  3
#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_AXI_ID_SHIFT  8
#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_AXI_PROT_SHIFT  29

#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_DET_MASK  0x00000001
#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_CLEAR_MASK  0x00000008
#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_AXI_ID_MASK  0x1fffff00
#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_AXI_PROT_MASK  0xe0000000

#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_MASK \
      (MP1_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_DET_MASK | \
      MP1_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_CLEAR_MASK | \
      MP1_SMNIF_TLVV_WR_VIOL_STATUS_AXI_ID_MASK | \
      MP1_SMNIF_TLVV_WR_VIOL_STATUS_AXI_PROT_MASK)

#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_DEFAULT 0x00000000

#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_GET_VIOL_DET(mp1_smnif_tlvv_wr_viol_status) \
      ((mp1_smnif_tlvv_wr_viol_status & MP1_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_DET_MASK) >> MP1_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_DET_SHIFT)
#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_GET_VIOL_CLEAR(mp1_smnif_tlvv_wr_viol_status) \
      ((mp1_smnif_tlvv_wr_viol_status & MP1_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_CLEAR_MASK) >> MP1_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_CLEAR_SHIFT)
#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_GET_AXI_ID(mp1_smnif_tlvv_wr_viol_status) \
      ((mp1_smnif_tlvv_wr_viol_status & MP1_SMNIF_TLVV_WR_VIOL_STATUS_AXI_ID_MASK) >> MP1_SMNIF_TLVV_WR_VIOL_STATUS_AXI_ID_SHIFT)
#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_GET_AXI_PROT(mp1_smnif_tlvv_wr_viol_status) \
      ((mp1_smnif_tlvv_wr_viol_status & MP1_SMNIF_TLVV_WR_VIOL_STATUS_AXI_PROT_MASK) >> MP1_SMNIF_TLVV_WR_VIOL_STATUS_AXI_PROT_SHIFT)

#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_SET_VIOL_DET(mp1_smnif_tlvv_wr_viol_status_reg, viol_det) \
      mp1_smnif_tlvv_wr_viol_status_reg = (mp1_smnif_tlvv_wr_viol_status_reg & ~MP1_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_DET_MASK) | (viol_det << MP1_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_DET_SHIFT)
#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_SET_VIOL_CLEAR(mp1_smnif_tlvv_wr_viol_status_reg, viol_clear) \
      mp1_smnif_tlvv_wr_viol_status_reg = (mp1_smnif_tlvv_wr_viol_status_reg & ~MP1_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_CLEAR_MASK) | (viol_clear << MP1_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_CLEAR_SHIFT)
#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_SET_AXI_ID(mp1_smnif_tlvv_wr_viol_status_reg, axi_id) \
      mp1_smnif_tlvv_wr_viol_status_reg = (mp1_smnif_tlvv_wr_viol_status_reg & ~MP1_SMNIF_TLVV_WR_VIOL_STATUS_AXI_ID_MASK) | (axi_id << MP1_SMNIF_TLVV_WR_VIOL_STATUS_AXI_ID_SHIFT)
#define MP1_SMNIF_TLVV_WR_VIOL_STATUS_SET_AXI_PROT(mp1_smnif_tlvv_wr_viol_status_reg, axi_prot) \
      mp1_smnif_tlvv_wr_viol_status_reg = (mp1_smnif_tlvv_wr_viol_status_reg & ~MP1_SMNIF_TLVV_WR_VIOL_STATUS_AXI_PROT_MASK) | (axi_prot << MP1_SMNIF_TLVV_WR_VIOL_STATUS_AXI_PROT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlvv_wr_viol_status_t {
            unsigned int viol_det                       : MP1_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_DET_SIZE;
            unsigned int                                : 2;
            unsigned int viol_clear                     : MP1_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_CLEAR_SIZE;
            unsigned int                                : 4;
            unsigned int axi_id                         : MP1_SMNIF_TLVV_WR_VIOL_STATUS_AXI_ID_SIZE;
            unsigned int axi_prot                       : MP1_SMNIF_TLVV_WR_VIOL_STATUS_AXI_PROT_SIZE;
      } mp1_smnif_tlvv_wr_viol_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlvv_wr_viol_status_t {
            unsigned int axi_prot                       : MP1_SMNIF_TLVV_WR_VIOL_STATUS_AXI_PROT_SIZE;
            unsigned int axi_id                         : MP1_SMNIF_TLVV_WR_VIOL_STATUS_AXI_ID_SIZE;
            unsigned int                                : 4;
            unsigned int viol_clear                     : MP1_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_CLEAR_SIZE;
            unsigned int                                : 2;
            unsigned int viol_det                       : MP1_SMNIF_TLVV_WR_VIOL_STATUS_VIOL_DET_SIZE;
      } mp1_smnif_tlvv_wr_viol_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlvv_wr_viol_status_t f;
} mp1_smnif_tlvv_wr_viol_status_u;


/*
 * MP1_SMNIF_TLVV_RD_VIOL_ADDR struct
 */

#define MP1_SMNIF_TLVV_RD_VIOL_ADDR_REG_SIZE         32
#define MP1_SMNIF_TLVV_RD_VIOL_ADDR_AXI_ADDR_SIZE  32

#define MP1_SMNIF_TLVV_RD_VIOL_ADDR_AXI_ADDR_SHIFT  0

#define MP1_SMNIF_TLVV_RD_VIOL_ADDR_AXI_ADDR_MASK  0xffffffff

#define MP1_SMNIF_TLVV_RD_VIOL_ADDR_MASK \
      (MP1_SMNIF_TLVV_RD_VIOL_ADDR_AXI_ADDR_MASK)

#define MP1_SMNIF_TLVV_RD_VIOL_ADDR_DEFAULT 0x00000000

#define MP1_SMNIF_TLVV_RD_VIOL_ADDR_GET_AXI_ADDR(mp1_smnif_tlvv_rd_viol_addr) \
      ((mp1_smnif_tlvv_rd_viol_addr & MP1_SMNIF_TLVV_RD_VIOL_ADDR_AXI_ADDR_MASK) >> MP1_SMNIF_TLVV_RD_VIOL_ADDR_AXI_ADDR_SHIFT)

#define MP1_SMNIF_TLVV_RD_VIOL_ADDR_SET_AXI_ADDR(mp1_smnif_tlvv_rd_viol_addr_reg, axi_addr) \
      mp1_smnif_tlvv_rd_viol_addr_reg = (mp1_smnif_tlvv_rd_viol_addr_reg & ~MP1_SMNIF_TLVV_RD_VIOL_ADDR_AXI_ADDR_MASK) | (axi_addr << MP1_SMNIF_TLVV_RD_VIOL_ADDR_AXI_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlvv_rd_viol_addr_t {
            unsigned int axi_addr                       : MP1_SMNIF_TLVV_RD_VIOL_ADDR_AXI_ADDR_SIZE;
      } mp1_smnif_tlvv_rd_viol_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlvv_rd_viol_addr_t {
            unsigned int axi_addr                       : MP1_SMNIF_TLVV_RD_VIOL_ADDR_AXI_ADDR_SIZE;
      } mp1_smnif_tlvv_rd_viol_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlvv_rd_viol_addr_t f;
} mp1_smnif_tlvv_rd_viol_addr_u;


/*
 * MP1_SMNIF_TLVV_RD_VIOL_STATUS struct
 */

#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_REG_SIZE         32
#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_DET_SIZE  1
#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_CLEAR_SIZE  1
#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_AXI_ID_SIZE  21
#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_AXI_PROT_SIZE  3

#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_DET_SHIFT  0
#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_CLEAR_SHIFT  3
#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_AXI_ID_SHIFT  8
#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_AXI_PROT_SHIFT  29

#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_DET_MASK  0x00000001
#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_CLEAR_MASK  0x00000008
#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_AXI_ID_MASK  0x1fffff00
#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_AXI_PROT_MASK  0xe0000000

#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_MASK \
      (MP1_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_DET_MASK | \
      MP1_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_CLEAR_MASK | \
      MP1_SMNIF_TLVV_RD_VIOL_STATUS_AXI_ID_MASK | \
      MP1_SMNIF_TLVV_RD_VIOL_STATUS_AXI_PROT_MASK)

#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_DEFAULT 0x00000000

#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_GET_VIOL_DET(mp1_smnif_tlvv_rd_viol_status) \
      ((mp1_smnif_tlvv_rd_viol_status & MP1_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_DET_MASK) >> MP1_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_DET_SHIFT)
#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_GET_VIOL_CLEAR(mp1_smnif_tlvv_rd_viol_status) \
      ((mp1_smnif_tlvv_rd_viol_status & MP1_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_CLEAR_MASK) >> MP1_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_CLEAR_SHIFT)
#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_GET_AXI_ID(mp1_smnif_tlvv_rd_viol_status) \
      ((mp1_smnif_tlvv_rd_viol_status & MP1_SMNIF_TLVV_RD_VIOL_STATUS_AXI_ID_MASK) >> MP1_SMNIF_TLVV_RD_VIOL_STATUS_AXI_ID_SHIFT)
#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_GET_AXI_PROT(mp1_smnif_tlvv_rd_viol_status) \
      ((mp1_smnif_tlvv_rd_viol_status & MP1_SMNIF_TLVV_RD_VIOL_STATUS_AXI_PROT_MASK) >> MP1_SMNIF_TLVV_RD_VIOL_STATUS_AXI_PROT_SHIFT)

#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_SET_VIOL_DET(mp1_smnif_tlvv_rd_viol_status_reg, viol_det) \
      mp1_smnif_tlvv_rd_viol_status_reg = (mp1_smnif_tlvv_rd_viol_status_reg & ~MP1_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_DET_MASK) | (viol_det << MP1_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_DET_SHIFT)
#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_SET_VIOL_CLEAR(mp1_smnif_tlvv_rd_viol_status_reg, viol_clear) \
      mp1_smnif_tlvv_rd_viol_status_reg = (mp1_smnif_tlvv_rd_viol_status_reg & ~MP1_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_CLEAR_MASK) | (viol_clear << MP1_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_CLEAR_SHIFT)
#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_SET_AXI_ID(mp1_smnif_tlvv_rd_viol_status_reg, axi_id) \
      mp1_smnif_tlvv_rd_viol_status_reg = (mp1_smnif_tlvv_rd_viol_status_reg & ~MP1_SMNIF_TLVV_RD_VIOL_STATUS_AXI_ID_MASK) | (axi_id << MP1_SMNIF_TLVV_RD_VIOL_STATUS_AXI_ID_SHIFT)
#define MP1_SMNIF_TLVV_RD_VIOL_STATUS_SET_AXI_PROT(mp1_smnif_tlvv_rd_viol_status_reg, axi_prot) \
      mp1_smnif_tlvv_rd_viol_status_reg = (mp1_smnif_tlvv_rd_viol_status_reg & ~MP1_SMNIF_TLVV_RD_VIOL_STATUS_AXI_PROT_MASK) | (axi_prot << MP1_SMNIF_TLVV_RD_VIOL_STATUS_AXI_PROT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_tlvv_rd_viol_status_t {
            unsigned int viol_det                       : MP1_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_DET_SIZE;
            unsigned int                                : 2;
            unsigned int viol_clear                     : MP1_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_CLEAR_SIZE;
            unsigned int                                : 4;
            unsigned int axi_id                         : MP1_SMNIF_TLVV_RD_VIOL_STATUS_AXI_ID_SIZE;
            unsigned int axi_prot                       : MP1_SMNIF_TLVV_RD_VIOL_STATUS_AXI_PROT_SIZE;
      } mp1_smnif_tlvv_rd_viol_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_tlvv_rd_viol_status_t {
            unsigned int axi_prot                       : MP1_SMNIF_TLVV_RD_VIOL_STATUS_AXI_PROT_SIZE;
            unsigned int axi_id                         : MP1_SMNIF_TLVV_RD_VIOL_STATUS_AXI_ID_SIZE;
            unsigned int                                : 4;
            unsigned int viol_clear                     : MP1_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_CLEAR_SIZE;
            unsigned int                                : 2;
            unsigned int viol_det                       : MP1_SMNIF_TLVV_RD_VIOL_STATUS_VIOL_DET_SIZE;
      } mp1_smnif_tlvv_rd_viol_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_tlvv_rd_viol_status_t f;
} mp1_smnif_tlvv_rd_viol_status_u;


/*
 * MP1_SMNIF_RAM0_READ_INITID_IP0 struct
 */

#define MP1_SMNIF_RAM0_READ_INITID_IP0_REG_SIZE         32
#define MP1_SMNIF_RAM0_READ_INITID_IP0_RD_INITID_0_SIZE  10

#define MP1_SMNIF_RAM0_READ_INITID_IP0_RD_INITID_0_SHIFT  0

#define MP1_SMNIF_RAM0_READ_INITID_IP0_RD_INITID_0_MASK  0x000003ff

#define MP1_SMNIF_RAM0_READ_INITID_IP0_MASK \
      (MP1_SMNIF_RAM0_READ_INITID_IP0_RD_INITID_0_MASK)

#define MP1_SMNIF_RAM0_READ_INITID_IP0_DEFAULT 0x00000000

#define MP1_SMNIF_RAM0_READ_INITID_IP0_GET_RD_INITID_0(mp1_smnif_ram0_read_initid_ip0) \
      ((mp1_smnif_ram0_read_initid_ip0 & MP1_SMNIF_RAM0_READ_INITID_IP0_RD_INITID_0_MASK) >> MP1_SMNIF_RAM0_READ_INITID_IP0_RD_INITID_0_SHIFT)

#define MP1_SMNIF_RAM0_READ_INITID_IP0_SET_RD_INITID_0(mp1_smnif_ram0_read_initid_ip0_reg, rd_initid_0) \
      mp1_smnif_ram0_read_initid_ip0_reg = (mp1_smnif_ram0_read_initid_ip0_reg & ~MP1_SMNIF_RAM0_READ_INITID_IP0_RD_INITID_0_MASK) | (rd_initid_0 << MP1_SMNIF_RAM0_READ_INITID_IP0_RD_INITID_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_ram0_read_initid_ip0_t {
            unsigned int rd_initid_0                    : MP1_SMNIF_RAM0_READ_INITID_IP0_RD_INITID_0_SIZE;
            unsigned int                                : 22;
      } mp1_smnif_ram0_read_initid_ip0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_ram0_read_initid_ip0_t {
            unsigned int                                : 22;
            unsigned int rd_initid_0                    : MP1_SMNIF_RAM0_READ_INITID_IP0_RD_INITID_0_SIZE;
      } mp1_smnif_ram0_read_initid_ip0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_ram0_read_initid_ip0_t f;
} mp1_smnif_ram0_read_initid_ip0_u;


/*
 * MP1_SMNIF_RAM0_READ_INITID_IP1 struct
 */

#define MP1_SMNIF_RAM0_READ_INITID_IP1_REG_SIZE         32
#define MP1_SMNIF_RAM0_READ_INITID_IP1_RD_INITID_1_SIZE  10

#define MP1_SMNIF_RAM0_READ_INITID_IP1_RD_INITID_1_SHIFT  0

#define MP1_SMNIF_RAM0_READ_INITID_IP1_RD_INITID_1_MASK  0x000003ff

#define MP1_SMNIF_RAM0_READ_INITID_IP1_MASK \
      (MP1_SMNIF_RAM0_READ_INITID_IP1_RD_INITID_1_MASK)

#define MP1_SMNIF_RAM0_READ_INITID_IP1_DEFAULT 0x00000000

#define MP1_SMNIF_RAM0_READ_INITID_IP1_GET_RD_INITID_1(mp1_smnif_ram0_read_initid_ip1) \
      ((mp1_smnif_ram0_read_initid_ip1 & MP1_SMNIF_RAM0_READ_INITID_IP1_RD_INITID_1_MASK) >> MP1_SMNIF_RAM0_READ_INITID_IP1_RD_INITID_1_SHIFT)

#define MP1_SMNIF_RAM0_READ_INITID_IP1_SET_RD_INITID_1(mp1_smnif_ram0_read_initid_ip1_reg, rd_initid_1) \
      mp1_smnif_ram0_read_initid_ip1_reg = (mp1_smnif_ram0_read_initid_ip1_reg & ~MP1_SMNIF_RAM0_READ_INITID_IP1_RD_INITID_1_MASK) | (rd_initid_1 << MP1_SMNIF_RAM0_READ_INITID_IP1_RD_INITID_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_ram0_read_initid_ip1_t {
            unsigned int rd_initid_1                    : MP1_SMNIF_RAM0_READ_INITID_IP1_RD_INITID_1_SIZE;
            unsigned int                                : 22;
      } mp1_smnif_ram0_read_initid_ip1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_ram0_read_initid_ip1_t {
            unsigned int                                : 22;
            unsigned int rd_initid_1                    : MP1_SMNIF_RAM0_READ_INITID_IP1_RD_INITID_1_SIZE;
      } mp1_smnif_ram0_read_initid_ip1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_ram0_read_initid_ip1_t f;
} mp1_smnif_ram0_read_initid_ip1_u;


/*
 * MP1_SMNIF_RAM0_READ_INITID_IP2 struct
 */

#define MP1_SMNIF_RAM0_READ_INITID_IP2_REG_SIZE         32
#define MP1_SMNIF_RAM0_READ_INITID_IP2_RD_INITID_2_SIZE  10

#define MP1_SMNIF_RAM0_READ_INITID_IP2_RD_INITID_2_SHIFT  0

#define MP1_SMNIF_RAM0_READ_INITID_IP2_RD_INITID_2_MASK  0x000003ff

#define MP1_SMNIF_RAM0_READ_INITID_IP2_MASK \
      (MP1_SMNIF_RAM0_READ_INITID_IP2_RD_INITID_2_MASK)

#define MP1_SMNIF_RAM0_READ_INITID_IP2_DEFAULT 0x00000000

#define MP1_SMNIF_RAM0_READ_INITID_IP2_GET_RD_INITID_2(mp1_smnif_ram0_read_initid_ip2) \
      ((mp1_smnif_ram0_read_initid_ip2 & MP1_SMNIF_RAM0_READ_INITID_IP2_RD_INITID_2_MASK) >> MP1_SMNIF_RAM0_READ_INITID_IP2_RD_INITID_2_SHIFT)

#define MP1_SMNIF_RAM0_READ_INITID_IP2_SET_RD_INITID_2(mp1_smnif_ram0_read_initid_ip2_reg, rd_initid_2) \
      mp1_smnif_ram0_read_initid_ip2_reg = (mp1_smnif_ram0_read_initid_ip2_reg & ~MP1_SMNIF_RAM0_READ_INITID_IP2_RD_INITID_2_MASK) | (rd_initid_2 << MP1_SMNIF_RAM0_READ_INITID_IP2_RD_INITID_2_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_ram0_read_initid_ip2_t {
            unsigned int rd_initid_2                    : MP1_SMNIF_RAM0_READ_INITID_IP2_RD_INITID_2_SIZE;
            unsigned int                                : 22;
      } mp1_smnif_ram0_read_initid_ip2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_ram0_read_initid_ip2_t {
            unsigned int                                : 22;
            unsigned int rd_initid_2                    : MP1_SMNIF_RAM0_READ_INITID_IP2_RD_INITID_2_SIZE;
      } mp1_smnif_ram0_read_initid_ip2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_ram0_read_initid_ip2_t f;
} mp1_smnif_ram0_read_initid_ip2_u;


/*
 * MP1_SMNIF_RAM0_READ_INITID_IP3 struct
 */

#define MP1_SMNIF_RAM0_READ_INITID_IP3_REG_SIZE         32
#define MP1_SMNIF_RAM0_READ_INITID_IP3_RD_INITID_3_SIZE  10

#define MP1_SMNIF_RAM0_READ_INITID_IP3_RD_INITID_3_SHIFT  0

#define MP1_SMNIF_RAM0_READ_INITID_IP3_RD_INITID_3_MASK  0x000003ff

#define MP1_SMNIF_RAM0_READ_INITID_IP3_MASK \
      (MP1_SMNIF_RAM0_READ_INITID_IP3_RD_INITID_3_MASK)

#define MP1_SMNIF_RAM0_READ_INITID_IP3_DEFAULT 0x00000000

#define MP1_SMNIF_RAM0_READ_INITID_IP3_GET_RD_INITID_3(mp1_smnif_ram0_read_initid_ip3) \
      ((mp1_smnif_ram0_read_initid_ip3 & MP1_SMNIF_RAM0_READ_INITID_IP3_RD_INITID_3_MASK) >> MP1_SMNIF_RAM0_READ_INITID_IP3_RD_INITID_3_SHIFT)

#define MP1_SMNIF_RAM0_READ_INITID_IP3_SET_RD_INITID_3(mp1_smnif_ram0_read_initid_ip3_reg, rd_initid_3) \
      mp1_smnif_ram0_read_initid_ip3_reg = (mp1_smnif_ram0_read_initid_ip3_reg & ~MP1_SMNIF_RAM0_READ_INITID_IP3_RD_INITID_3_MASK) | (rd_initid_3 << MP1_SMNIF_RAM0_READ_INITID_IP3_RD_INITID_3_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_ram0_read_initid_ip3_t {
            unsigned int rd_initid_3                    : MP1_SMNIF_RAM0_READ_INITID_IP3_RD_INITID_3_SIZE;
            unsigned int                                : 22;
      } mp1_smnif_ram0_read_initid_ip3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_ram0_read_initid_ip3_t {
            unsigned int                                : 22;
            unsigned int rd_initid_3                    : MP1_SMNIF_RAM0_READ_INITID_IP3_RD_INITID_3_SIZE;
      } mp1_smnif_ram0_read_initid_ip3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_ram0_read_initid_ip3_t f;
} mp1_smnif_ram0_read_initid_ip3_u;


/*
 * MP1_SMNIF_RAM0_WRITE_INITID_IP0 struct
 */

#define MP1_SMNIF_RAM0_WRITE_INITID_IP0_REG_SIZE         32
#define MP1_SMNIF_RAM0_WRITE_INITID_IP0_WR_INITID_0_SIZE  10

#define MP1_SMNIF_RAM0_WRITE_INITID_IP0_WR_INITID_0_SHIFT  0

#define MP1_SMNIF_RAM0_WRITE_INITID_IP0_WR_INITID_0_MASK  0x000003ff

#define MP1_SMNIF_RAM0_WRITE_INITID_IP0_MASK \
      (MP1_SMNIF_RAM0_WRITE_INITID_IP0_WR_INITID_0_MASK)

#define MP1_SMNIF_RAM0_WRITE_INITID_IP0_DEFAULT 0x00000000

#define MP1_SMNIF_RAM0_WRITE_INITID_IP0_GET_WR_INITID_0(mp1_smnif_ram0_write_initid_ip0) \
      ((mp1_smnif_ram0_write_initid_ip0 & MP1_SMNIF_RAM0_WRITE_INITID_IP0_WR_INITID_0_MASK) >> MP1_SMNIF_RAM0_WRITE_INITID_IP0_WR_INITID_0_SHIFT)

#define MP1_SMNIF_RAM0_WRITE_INITID_IP0_SET_WR_INITID_0(mp1_smnif_ram0_write_initid_ip0_reg, wr_initid_0) \
      mp1_smnif_ram0_write_initid_ip0_reg = (mp1_smnif_ram0_write_initid_ip0_reg & ~MP1_SMNIF_RAM0_WRITE_INITID_IP0_WR_INITID_0_MASK) | (wr_initid_0 << MP1_SMNIF_RAM0_WRITE_INITID_IP0_WR_INITID_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_ram0_write_initid_ip0_t {
            unsigned int wr_initid_0                    : MP1_SMNIF_RAM0_WRITE_INITID_IP0_WR_INITID_0_SIZE;
            unsigned int                                : 22;
      } mp1_smnif_ram0_write_initid_ip0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_ram0_write_initid_ip0_t {
            unsigned int                                : 22;
            unsigned int wr_initid_0                    : MP1_SMNIF_RAM0_WRITE_INITID_IP0_WR_INITID_0_SIZE;
      } mp1_smnif_ram0_write_initid_ip0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_ram0_write_initid_ip0_t f;
} mp1_smnif_ram0_write_initid_ip0_u;


/*
 * MP1_SMNIF_RAM0_WRITE_INITID_IP1 struct
 */

#define MP1_SMNIF_RAM0_WRITE_INITID_IP1_REG_SIZE         32
#define MP1_SMNIF_RAM0_WRITE_INITID_IP1_WR_INITID_1_SIZE  10

#define MP1_SMNIF_RAM0_WRITE_INITID_IP1_WR_INITID_1_SHIFT  0

#define MP1_SMNIF_RAM0_WRITE_INITID_IP1_WR_INITID_1_MASK  0x000003ff

#define MP1_SMNIF_RAM0_WRITE_INITID_IP1_MASK \
      (MP1_SMNIF_RAM0_WRITE_INITID_IP1_WR_INITID_1_MASK)

#define MP1_SMNIF_RAM0_WRITE_INITID_IP1_DEFAULT 0x00000000

#define MP1_SMNIF_RAM0_WRITE_INITID_IP1_GET_WR_INITID_1(mp1_smnif_ram0_write_initid_ip1) \
      ((mp1_smnif_ram0_write_initid_ip1 & MP1_SMNIF_RAM0_WRITE_INITID_IP1_WR_INITID_1_MASK) >> MP1_SMNIF_RAM0_WRITE_INITID_IP1_WR_INITID_1_SHIFT)

#define MP1_SMNIF_RAM0_WRITE_INITID_IP1_SET_WR_INITID_1(mp1_smnif_ram0_write_initid_ip1_reg, wr_initid_1) \
      mp1_smnif_ram0_write_initid_ip1_reg = (mp1_smnif_ram0_write_initid_ip1_reg & ~MP1_SMNIF_RAM0_WRITE_INITID_IP1_WR_INITID_1_MASK) | (wr_initid_1 << MP1_SMNIF_RAM0_WRITE_INITID_IP1_WR_INITID_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_ram0_write_initid_ip1_t {
            unsigned int wr_initid_1                    : MP1_SMNIF_RAM0_WRITE_INITID_IP1_WR_INITID_1_SIZE;
            unsigned int                                : 22;
      } mp1_smnif_ram0_write_initid_ip1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_ram0_write_initid_ip1_t {
            unsigned int                                : 22;
            unsigned int wr_initid_1                    : MP1_SMNIF_RAM0_WRITE_INITID_IP1_WR_INITID_1_SIZE;
      } mp1_smnif_ram0_write_initid_ip1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_ram0_write_initid_ip1_t f;
} mp1_smnif_ram0_write_initid_ip1_u;


/*
 * MP1_SMNIF_RAM0_WRITE_INITID_IP2 struct
 */

#define MP1_SMNIF_RAM0_WRITE_INITID_IP2_REG_SIZE         32
#define MP1_SMNIF_RAM0_WRITE_INITID_IP2_WR_INITID_2_SIZE  10

#define MP1_SMNIF_RAM0_WRITE_INITID_IP2_WR_INITID_2_SHIFT  0

#define MP1_SMNIF_RAM0_WRITE_INITID_IP2_WR_INITID_2_MASK  0x000003ff

#define MP1_SMNIF_RAM0_WRITE_INITID_IP2_MASK \
      (MP1_SMNIF_RAM0_WRITE_INITID_IP2_WR_INITID_2_MASK)

#define MP1_SMNIF_RAM0_WRITE_INITID_IP2_DEFAULT 0x00000000

#define MP1_SMNIF_RAM0_WRITE_INITID_IP2_GET_WR_INITID_2(mp1_smnif_ram0_write_initid_ip2) \
      ((mp1_smnif_ram0_write_initid_ip2 & MP1_SMNIF_RAM0_WRITE_INITID_IP2_WR_INITID_2_MASK) >> MP1_SMNIF_RAM0_WRITE_INITID_IP2_WR_INITID_2_SHIFT)

#define MP1_SMNIF_RAM0_WRITE_INITID_IP2_SET_WR_INITID_2(mp1_smnif_ram0_write_initid_ip2_reg, wr_initid_2) \
      mp1_smnif_ram0_write_initid_ip2_reg = (mp1_smnif_ram0_write_initid_ip2_reg & ~MP1_SMNIF_RAM0_WRITE_INITID_IP2_WR_INITID_2_MASK) | (wr_initid_2 << MP1_SMNIF_RAM0_WRITE_INITID_IP2_WR_INITID_2_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_ram0_write_initid_ip2_t {
            unsigned int wr_initid_2                    : MP1_SMNIF_RAM0_WRITE_INITID_IP2_WR_INITID_2_SIZE;
            unsigned int                                : 22;
      } mp1_smnif_ram0_write_initid_ip2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_ram0_write_initid_ip2_t {
            unsigned int                                : 22;
            unsigned int wr_initid_2                    : MP1_SMNIF_RAM0_WRITE_INITID_IP2_WR_INITID_2_SIZE;
      } mp1_smnif_ram0_write_initid_ip2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_ram0_write_initid_ip2_t f;
} mp1_smnif_ram0_write_initid_ip2_u;


/*
 * MP1_SMNIF_RAM0_WRITE_INITID_IP3 struct
 */

#define MP1_SMNIF_RAM0_WRITE_INITID_IP3_REG_SIZE         32
#define MP1_SMNIF_RAM0_WRITE_INITID_IP3_WR_INITID_3_SIZE  10

#define MP1_SMNIF_RAM0_WRITE_INITID_IP3_WR_INITID_3_SHIFT  0

#define MP1_SMNIF_RAM0_WRITE_INITID_IP3_WR_INITID_3_MASK  0x000003ff

#define MP1_SMNIF_RAM0_WRITE_INITID_IP3_MASK \
      (MP1_SMNIF_RAM0_WRITE_INITID_IP3_WR_INITID_3_MASK)

#define MP1_SMNIF_RAM0_WRITE_INITID_IP3_DEFAULT 0x00000000

#define MP1_SMNIF_RAM0_WRITE_INITID_IP3_GET_WR_INITID_3(mp1_smnif_ram0_write_initid_ip3) \
      ((mp1_smnif_ram0_write_initid_ip3 & MP1_SMNIF_RAM0_WRITE_INITID_IP3_WR_INITID_3_MASK) >> MP1_SMNIF_RAM0_WRITE_INITID_IP3_WR_INITID_3_SHIFT)

#define MP1_SMNIF_RAM0_WRITE_INITID_IP3_SET_WR_INITID_3(mp1_smnif_ram0_write_initid_ip3_reg, wr_initid_3) \
      mp1_smnif_ram0_write_initid_ip3_reg = (mp1_smnif_ram0_write_initid_ip3_reg & ~MP1_SMNIF_RAM0_WRITE_INITID_IP3_WR_INITID_3_MASK) | (wr_initid_3 << MP1_SMNIF_RAM0_WRITE_INITID_IP3_WR_INITID_3_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_smnif_ram0_write_initid_ip3_t {
            unsigned int wr_initid_3                    : MP1_SMNIF_RAM0_WRITE_INITID_IP3_WR_INITID_3_SIZE;
            unsigned int                                : 22;
      } mp1_smnif_ram0_write_initid_ip3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_smnif_ram0_write_initid_ip3_t {
            unsigned int                                : 22;
            unsigned int wr_initid_3                    : MP1_SMNIF_RAM0_WRITE_INITID_IP3_WR_INITID_3_SIZE;
      } mp1_smnif_ram0_write_initid_ip3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_smnif_ram0_write_initid_ip3_t f;
} mp1_smnif_ram0_write_initid_ip3_u;


#endif

