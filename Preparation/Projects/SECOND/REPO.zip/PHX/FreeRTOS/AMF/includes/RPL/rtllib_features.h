// Copyright (c) 2010 - 2019 Advanced Micro Devices, Inc. All rights reserved.
#ifndef __RTLLIB_FEATURES_H__
#define __RTLLIB_FEATURES_H__
// reference features

// imported features

// local features
#define RTLLIB__TECH tsmc6n
#define RTLLIB__TECH__TSMC6N 1
#define RTLLIB__FLAVOR dgpu
#define RTLLIB__FLAVOR__DGPU 1
#endif
