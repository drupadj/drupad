// Copyright (c) 1994 - 2021 Advanced Micro Devices, Inc. All rights reserved. 
 #if !defined (_MP1_MHUBIF_FIDDLE_H)
#define _MP1_MHUBIF_FIDDLE_H
 /*****************************************************************************************************************
 *
 *  mp1_mhubif_reg.h
 *
 *  Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif

 /*******************************************************
 * Values
 *******************************************************/

 /*******************************************************
 * Structures
 *******************************************************/

/*
 * MP1_MMHUB_SOC_TLB0_1 struct
 */

#define MP1_MMHUB_SOC_TLB0_1_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB0_1_SOC_ADDR_SIZE  22

#define MP1_MMHUB_SOC_TLB0_1_SOC_ADDR_SHIFT  0

#define MP1_MMHUB_SOC_TLB0_1_SOC_ADDR_MASK  0x003fffff

#define MP1_MMHUB_SOC_TLB0_1_MASK \
      (MP1_MMHUB_SOC_TLB0_1_SOC_ADDR_MASK)

#define MP1_MMHUB_SOC_TLB0_1_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB0_1_GET_SOC_ADDR(mp1_mmhub_soc_tlb0_1) \
      ((mp1_mmhub_soc_tlb0_1 & MP1_MMHUB_SOC_TLB0_1_SOC_ADDR_MASK) >> MP1_MMHUB_SOC_TLB0_1_SOC_ADDR_SHIFT)

#define MP1_MMHUB_SOC_TLB0_1_SET_SOC_ADDR(mp1_mmhub_soc_tlb0_1_reg, soc_addr) \
      mp1_mmhub_soc_tlb0_1_reg = (mp1_mmhub_soc_tlb0_1_reg & ~MP1_MMHUB_SOC_TLB0_1_SOC_ADDR_MASK) | (soc_addr << MP1_MMHUB_SOC_TLB0_1_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_1_t {
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_1_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp1_mmhub_soc_tlb0_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_1_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_1_SOC_ADDR_SIZE;
      } mp1_mmhub_soc_tlb0_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb0_1_t f;
} mp1_mmhub_soc_tlb0_1_u;


/*
 * MP1_MMHUB_SOC_TLB1_1 struct
 */

#define MP1_MMHUB_SOC_TLB1_1_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB1_1_COHERENCE_SIZE  1
#define MP1_MMHUB_SOC_TLB1_1_SEG_SIZE_SIZE  4
#define MP1_MMHUB_SOC_TLB1_1_SEG_OFFSET_SIZE  9

#define MP1_MMHUB_SOC_TLB1_1_COHERENCE_SHIFT  0
#define MP1_MMHUB_SOC_TLB1_1_SEG_SIZE_SHIFT  1
#define MP1_MMHUB_SOC_TLB1_1_SEG_OFFSET_SHIFT  5

#define MP1_MMHUB_SOC_TLB1_1_COHERENCE_MASK  0x00000001
#define MP1_MMHUB_SOC_TLB1_1_SEG_SIZE_MASK  0x0000001e
#define MP1_MMHUB_SOC_TLB1_1_SEG_OFFSET_MASK  0x00003fe0

#define MP1_MMHUB_SOC_TLB1_1_MASK \
      (MP1_MMHUB_SOC_TLB1_1_COHERENCE_MASK | \
      MP1_MMHUB_SOC_TLB1_1_SEG_SIZE_MASK | \
      MP1_MMHUB_SOC_TLB1_1_SEG_OFFSET_MASK)

#define MP1_MMHUB_SOC_TLB1_1_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB1_1_GET_COHERENCE(mp1_mmhub_soc_tlb1_1) \
      ((mp1_mmhub_soc_tlb1_1 & MP1_MMHUB_SOC_TLB1_1_COHERENCE_MASK) >> MP1_MMHUB_SOC_TLB1_1_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_1_GET_SEG_SIZE(mp1_mmhub_soc_tlb1_1) \
      ((mp1_mmhub_soc_tlb1_1 & MP1_MMHUB_SOC_TLB1_1_SEG_SIZE_MASK) >> MP1_MMHUB_SOC_TLB1_1_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_1_GET_SEG_OFFSET(mp1_mmhub_soc_tlb1_1) \
      ((mp1_mmhub_soc_tlb1_1 & MP1_MMHUB_SOC_TLB1_1_SEG_OFFSET_MASK) >> MP1_MMHUB_SOC_TLB1_1_SEG_OFFSET_SHIFT)

#define MP1_MMHUB_SOC_TLB1_1_SET_COHERENCE(mp1_mmhub_soc_tlb1_1_reg, coherence) \
      mp1_mmhub_soc_tlb1_1_reg = (mp1_mmhub_soc_tlb1_1_reg & ~MP1_MMHUB_SOC_TLB1_1_COHERENCE_MASK) | (coherence << MP1_MMHUB_SOC_TLB1_1_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_1_SET_SEG_SIZE(mp1_mmhub_soc_tlb1_1_reg, seg_size) \
      mp1_mmhub_soc_tlb1_1_reg = (mp1_mmhub_soc_tlb1_1_reg & ~MP1_MMHUB_SOC_TLB1_1_SEG_SIZE_MASK) | (seg_size << MP1_MMHUB_SOC_TLB1_1_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_1_SET_SEG_OFFSET(mp1_mmhub_soc_tlb1_1_reg, seg_offset) \
      mp1_mmhub_soc_tlb1_1_reg = (mp1_mmhub_soc_tlb1_1_reg & ~MP1_MMHUB_SOC_TLB1_1_SEG_OFFSET_MASK) | (seg_offset << MP1_MMHUB_SOC_TLB1_1_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_1_t {
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_1_COHERENCE_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_1_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_1_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp1_mmhub_soc_tlb1_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_1_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_1_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_1_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_1_COHERENCE_SIZE;
      } mp1_mmhub_soc_tlb1_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb1_1_t f;
} mp1_mmhub_soc_tlb1_1_u;


/*
 * MP1_MMHUB_SOC_TLB2_1 struct
 */

#define MP1_MMHUB_SOC_TLB2_1_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB2_1_AWUSER_SIZE  32

#define MP1_MMHUB_SOC_TLB2_1_AWUSER_SHIFT  0

#define MP1_MMHUB_SOC_TLB2_1_AWUSER_MASK  0xffffffff

#define MP1_MMHUB_SOC_TLB2_1_MASK \
      (MP1_MMHUB_SOC_TLB2_1_AWUSER_MASK)

#define MP1_MMHUB_SOC_TLB2_1_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB2_1_GET_AWUSER(mp1_mmhub_soc_tlb2_1) \
      ((mp1_mmhub_soc_tlb2_1 & MP1_MMHUB_SOC_TLB2_1_AWUSER_MASK) >> MP1_MMHUB_SOC_TLB2_1_AWUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB2_1_SET_AWUSER(mp1_mmhub_soc_tlb2_1_reg, awuser) \
      mp1_mmhub_soc_tlb2_1_reg = (mp1_mmhub_soc_tlb2_1_reg & ~MP1_MMHUB_SOC_TLB2_1_AWUSER_MASK) | (awuser << MP1_MMHUB_SOC_TLB2_1_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_1_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_1_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_1_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_1_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb2_1_t f;
} mp1_mmhub_soc_tlb2_1_u;


/*
 * MP1_MMHUB_SOC_TLB3_1 struct
 */

#define MP1_MMHUB_SOC_TLB3_1_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB3_1_ARUSER_SIZE  28
#define MP1_MMHUB_SOC_TLB3_1_WUSER_SIZE  3

#define MP1_MMHUB_SOC_TLB3_1_ARUSER_SHIFT  0
#define MP1_MMHUB_SOC_TLB3_1_WUSER_SHIFT  28

#define MP1_MMHUB_SOC_TLB3_1_ARUSER_MASK  0x0fffffff
#define MP1_MMHUB_SOC_TLB3_1_WUSER_MASK  0x70000000

#define MP1_MMHUB_SOC_TLB3_1_MASK \
      (MP1_MMHUB_SOC_TLB3_1_ARUSER_MASK | \
      MP1_MMHUB_SOC_TLB3_1_WUSER_MASK)

#define MP1_MMHUB_SOC_TLB3_1_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB3_1_GET_ARUSER(mp1_mmhub_soc_tlb3_1) \
      ((mp1_mmhub_soc_tlb3_1 & MP1_MMHUB_SOC_TLB3_1_ARUSER_MASK) >> MP1_MMHUB_SOC_TLB3_1_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_1_GET_WUSER(mp1_mmhub_soc_tlb3_1) \
      ((mp1_mmhub_soc_tlb3_1 & MP1_MMHUB_SOC_TLB3_1_WUSER_MASK) >> MP1_MMHUB_SOC_TLB3_1_WUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB3_1_SET_ARUSER(mp1_mmhub_soc_tlb3_1_reg, aruser) \
      mp1_mmhub_soc_tlb3_1_reg = (mp1_mmhub_soc_tlb3_1_reg & ~MP1_MMHUB_SOC_TLB3_1_ARUSER_MASK) | (aruser << MP1_MMHUB_SOC_TLB3_1_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_1_SET_WUSER(mp1_mmhub_soc_tlb3_1_reg, wuser) \
      mp1_mmhub_soc_tlb3_1_reg = (mp1_mmhub_soc_tlb3_1_reg & ~MP1_MMHUB_SOC_TLB3_1_WUSER_MASK) | (wuser << MP1_MMHUB_SOC_TLB3_1_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_1_t {
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_1_ARUSER_SIZE;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_1_WUSER_SIZE;
            unsigned int                                : 1;
      } mp1_mmhub_soc_tlb3_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_1_t {
            unsigned int                                : 1;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_1_WUSER_SIZE;
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_1_ARUSER_SIZE;
      } mp1_mmhub_soc_tlb3_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb3_1_t f;
} mp1_mmhub_soc_tlb3_1_u;


/*
 * MP1_MMHUB_SOC_TLB0_2 struct
 */

#define MP1_MMHUB_SOC_TLB0_2_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB0_2_SOC_ADDR_SIZE  22

#define MP1_MMHUB_SOC_TLB0_2_SOC_ADDR_SHIFT  0

#define MP1_MMHUB_SOC_TLB0_2_SOC_ADDR_MASK  0x003fffff

#define MP1_MMHUB_SOC_TLB0_2_MASK \
      (MP1_MMHUB_SOC_TLB0_2_SOC_ADDR_MASK)

#define MP1_MMHUB_SOC_TLB0_2_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB0_2_GET_SOC_ADDR(mp1_mmhub_soc_tlb0_2) \
      ((mp1_mmhub_soc_tlb0_2 & MP1_MMHUB_SOC_TLB0_2_SOC_ADDR_MASK) >> MP1_MMHUB_SOC_TLB0_2_SOC_ADDR_SHIFT)

#define MP1_MMHUB_SOC_TLB0_2_SET_SOC_ADDR(mp1_mmhub_soc_tlb0_2_reg, soc_addr) \
      mp1_mmhub_soc_tlb0_2_reg = (mp1_mmhub_soc_tlb0_2_reg & ~MP1_MMHUB_SOC_TLB0_2_SOC_ADDR_MASK) | (soc_addr << MP1_MMHUB_SOC_TLB0_2_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_2_t {
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_2_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp1_mmhub_soc_tlb0_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_2_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_2_SOC_ADDR_SIZE;
      } mp1_mmhub_soc_tlb0_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb0_2_t f;
} mp1_mmhub_soc_tlb0_2_u;


/*
 * MP1_MMHUB_SOC_TLB1_2 struct
 */

#define MP1_MMHUB_SOC_TLB1_2_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB1_2_COHERENCE_SIZE  1
#define MP1_MMHUB_SOC_TLB1_2_SEG_SIZE_SIZE  4
#define MP1_MMHUB_SOC_TLB1_2_SEG_OFFSET_SIZE  9

#define MP1_MMHUB_SOC_TLB1_2_COHERENCE_SHIFT  0
#define MP1_MMHUB_SOC_TLB1_2_SEG_SIZE_SHIFT  1
#define MP1_MMHUB_SOC_TLB1_2_SEG_OFFSET_SHIFT  5

#define MP1_MMHUB_SOC_TLB1_2_COHERENCE_MASK  0x00000001
#define MP1_MMHUB_SOC_TLB1_2_SEG_SIZE_MASK  0x0000001e
#define MP1_MMHUB_SOC_TLB1_2_SEG_OFFSET_MASK  0x00003fe0

#define MP1_MMHUB_SOC_TLB1_2_MASK \
      (MP1_MMHUB_SOC_TLB1_2_COHERENCE_MASK | \
      MP1_MMHUB_SOC_TLB1_2_SEG_SIZE_MASK | \
      MP1_MMHUB_SOC_TLB1_2_SEG_OFFSET_MASK)

#define MP1_MMHUB_SOC_TLB1_2_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB1_2_GET_COHERENCE(mp1_mmhub_soc_tlb1_2) \
      ((mp1_mmhub_soc_tlb1_2 & MP1_MMHUB_SOC_TLB1_2_COHERENCE_MASK) >> MP1_MMHUB_SOC_TLB1_2_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_2_GET_SEG_SIZE(mp1_mmhub_soc_tlb1_2) \
      ((mp1_mmhub_soc_tlb1_2 & MP1_MMHUB_SOC_TLB1_2_SEG_SIZE_MASK) >> MP1_MMHUB_SOC_TLB1_2_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_2_GET_SEG_OFFSET(mp1_mmhub_soc_tlb1_2) \
      ((mp1_mmhub_soc_tlb1_2 & MP1_MMHUB_SOC_TLB1_2_SEG_OFFSET_MASK) >> MP1_MMHUB_SOC_TLB1_2_SEG_OFFSET_SHIFT)

#define MP1_MMHUB_SOC_TLB1_2_SET_COHERENCE(mp1_mmhub_soc_tlb1_2_reg, coherence) \
      mp1_mmhub_soc_tlb1_2_reg = (mp1_mmhub_soc_tlb1_2_reg & ~MP1_MMHUB_SOC_TLB1_2_COHERENCE_MASK) | (coherence << MP1_MMHUB_SOC_TLB1_2_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_2_SET_SEG_SIZE(mp1_mmhub_soc_tlb1_2_reg, seg_size) \
      mp1_mmhub_soc_tlb1_2_reg = (mp1_mmhub_soc_tlb1_2_reg & ~MP1_MMHUB_SOC_TLB1_2_SEG_SIZE_MASK) | (seg_size << MP1_MMHUB_SOC_TLB1_2_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_2_SET_SEG_OFFSET(mp1_mmhub_soc_tlb1_2_reg, seg_offset) \
      mp1_mmhub_soc_tlb1_2_reg = (mp1_mmhub_soc_tlb1_2_reg & ~MP1_MMHUB_SOC_TLB1_2_SEG_OFFSET_MASK) | (seg_offset << MP1_MMHUB_SOC_TLB1_2_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_2_t {
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_2_COHERENCE_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_2_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_2_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp1_mmhub_soc_tlb1_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_2_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_2_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_2_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_2_COHERENCE_SIZE;
      } mp1_mmhub_soc_tlb1_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb1_2_t f;
} mp1_mmhub_soc_tlb1_2_u;


/*
 * MP1_MMHUB_SOC_TLB2_2 struct
 */

#define MP1_MMHUB_SOC_TLB2_2_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB2_2_AWUSER_SIZE  32

#define MP1_MMHUB_SOC_TLB2_2_AWUSER_SHIFT  0

#define MP1_MMHUB_SOC_TLB2_2_AWUSER_MASK  0xffffffff

#define MP1_MMHUB_SOC_TLB2_2_MASK \
      (MP1_MMHUB_SOC_TLB2_2_AWUSER_MASK)

#define MP1_MMHUB_SOC_TLB2_2_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB2_2_GET_AWUSER(mp1_mmhub_soc_tlb2_2) \
      ((mp1_mmhub_soc_tlb2_2 & MP1_MMHUB_SOC_TLB2_2_AWUSER_MASK) >> MP1_MMHUB_SOC_TLB2_2_AWUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB2_2_SET_AWUSER(mp1_mmhub_soc_tlb2_2_reg, awuser) \
      mp1_mmhub_soc_tlb2_2_reg = (mp1_mmhub_soc_tlb2_2_reg & ~MP1_MMHUB_SOC_TLB2_2_AWUSER_MASK) | (awuser << MP1_MMHUB_SOC_TLB2_2_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_2_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_2_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_2_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_2_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb2_2_t f;
} mp1_mmhub_soc_tlb2_2_u;


/*
 * MP1_MMHUB_SOC_TLB3_2 struct
 */

#define MP1_MMHUB_SOC_TLB3_2_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB3_2_ARUSER_SIZE  28
#define MP1_MMHUB_SOC_TLB3_2_WUSER_SIZE  3

#define MP1_MMHUB_SOC_TLB3_2_ARUSER_SHIFT  0
#define MP1_MMHUB_SOC_TLB3_2_WUSER_SHIFT  28

#define MP1_MMHUB_SOC_TLB3_2_ARUSER_MASK  0x0fffffff
#define MP1_MMHUB_SOC_TLB3_2_WUSER_MASK  0x70000000

#define MP1_MMHUB_SOC_TLB3_2_MASK \
      (MP1_MMHUB_SOC_TLB3_2_ARUSER_MASK | \
      MP1_MMHUB_SOC_TLB3_2_WUSER_MASK)

#define MP1_MMHUB_SOC_TLB3_2_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB3_2_GET_ARUSER(mp1_mmhub_soc_tlb3_2) \
      ((mp1_mmhub_soc_tlb3_2 & MP1_MMHUB_SOC_TLB3_2_ARUSER_MASK) >> MP1_MMHUB_SOC_TLB3_2_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_2_GET_WUSER(mp1_mmhub_soc_tlb3_2) \
      ((mp1_mmhub_soc_tlb3_2 & MP1_MMHUB_SOC_TLB3_2_WUSER_MASK) >> MP1_MMHUB_SOC_TLB3_2_WUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB3_2_SET_ARUSER(mp1_mmhub_soc_tlb3_2_reg, aruser) \
      mp1_mmhub_soc_tlb3_2_reg = (mp1_mmhub_soc_tlb3_2_reg & ~MP1_MMHUB_SOC_TLB3_2_ARUSER_MASK) | (aruser << MP1_MMHUB_SOC_TLB3_2_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_2_SET_WUSER(mp1_mmhub_soc_tlb3_2_reg, wuser) \
      mp1_mmhub_soc_tlb3_2_reg = (mp1_mmhub_soc_tlb3_2_reg & ~MP1_MMHUB_SOC_TLB3_2_WUSER_MASK) | (wuser << MP1_MMHUB_SOC_TLB3_2_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_2_t {
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_2_ARUSER_SIZE;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_2_WUSER_SIZE;
            unsigned int                                : 1;
      } mp1_mmhub_soc_tlb3_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_2_t {
            unsigned int                                : 1;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_2_WUSER_SIZE;
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_2_ARUSER_SIZE;
      } mp1_mmhub_soc_tlb3_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb3_2_t f;
} mp1_mmhub_soc_tlb3_2_u;


/*
 * MP1_MMHUB_SOC_TLB0_3 struct
 */

#define MP1_MMHUB_SOC_TLB0_3_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB0_3_SOC_ADDR_SIZE  22

#define MP1_MMHUB_SOC_TLB0_3_SOC_ADDR_SHIFT  0

#define MP1_MMHUB_SOC_TLB0_3_SOC_ADDR_MASK  0x003fffff

#define MP1_MMHUB_SOC_TLB0_3_MASK \
      (MP1_MMHUB_SOC_TLB0_3_SOC_ADDR_MASK)

#define MP1_MMHUB_SOC_TLB0_3_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB0_3_GET_SOC_ADDR(mp1_mmhub_soc_tlb0_3) \
      ((mp1_mmhub_soc_tlb0_3 & MP1_MMHUB_SOC_TLB0_3_SOC_ADDR_MASK) >> MP1_MMHUB_SOC_TLB0_3_SOC_ADDR_SHIFT)

#define MP1_MMHUB_SOC_TLB0_3_SET_SOC_ADDR(mp1_mmhub_soc_tlb0_3_reg, soc_addr) \
      mp1_mmhub_soc_tlb0_3_reg = (mp1_mmhub_soc_tlb0_3_reg & ~MP1_MMHUB_SOC_TLB0_3_SOC_ADDR_MASK) | (soc_addr << MP1_MMHUB_SOC_TLB0_3_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_3_t {
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_3_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp1_mmhub_soc_tlb0_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_3_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_3_SOC_ADDR_SIZE;
      } mp1_mmhub_soc_tlb0_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb0_3_t f;
} mp1_mmhub_soc_tlb0_3_u;


/*
 * MP1_MMHUB_SOC_TLB1_3 struct
 */

#define MP1_MMHUB_SOC_TLB1_3_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB1_3_COHERENCE_SIZE  1
#define MP1_MMHUB_SOC_TLB1_3_SEG_SIZE_SIZE  4
#define MP1_MMHUB_SOC_TLB1_3_SEG_OFFSET_SIZE  9

#define MP1_MMHUB_SOC_TLB1_3_COHERENCE_SHIFT  0
#define MP1_MMHUB_SOC_TLB1_3_SEG_SIZE_SHIFT  1
#define MP1_MMHUB_SOC_TLB1_3_SEG_OFFSET_SHIFT  5

#define MP1_MMHUB_SOC_TLB1_3_COHERENCE_MASK  0x00000001
#define MP1_MMHUB_SOC_TLB1_3_SEG_SIZE_MASK  0x0000001e
#define MP1_MMHUB_SOC_TLB1_3_SEG_OFFSET_MASK  0x00003fe0

#define MP1_MMHUB_SOC_TLB1_3_MASK \
      (MP1_MMHUB_SOC_TLB1_3_COHERENCE_MASK | \
      MP1_MMHUB_SOC_TLB1_3_SEG_SIZE_MASK | \
      MP1_MMHUB_SOC_TLB1_3_SEG_OFFSET_MASK)

#define MP1_MMHUB_SOC_TLB1_3_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB1_3_GET_COHERENCE(mp1_mmhub_soc_tlb1_3) \
      ((mp1_mmhub_soc_tlb1_3 & MP1_MMHUB_SOC_TLB1_3_COHERENCE_MASK) >> MP1_MMHUB_SOC_TLB1_3_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_3_GET_SEG_SIZE(mp1_mmhub_soc_tlb1_3) \
      ((mp1_mmhub_soc_tlb1_3 & MP1_MMHUB_SOC_TLB1_3_SEG_SIZE_MASK) >> MP1_MMHUB_SOC_TLB1_3_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_3_GET_SEG_OFFSET(mp1_mmhub_soc_tlb1_3) \
      ((mp1_mmhub_soc_tlb1_3 & MP1_MMHUB_SOC_TLB1_3_SEG_OFFSET_MASK) >> MP1_MMHUB_SOC_TLB1_3_SEG_OFFSET_SHIFT)

#define MP1_MMHUB_SOC_TLB1_3_SET_COHERENCE(mp1_mmhub_soc_tlb1_3_reg, coherence) \
      mp1_mmhub_soc_tlb1_3_reg = (mp1_mmhub_soc_tlb1_3_reg & ~MP1_MMHUB_SOC_TLB1_3_COHERENCE_MASK) | (coherence << MP1_MMHUB_SOC_TLB1_3_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_3_SET_SEG_SIZE(mp1_mmhub_soc_tlb1_3_reg, seg_size) \
      mp1_mmhub_soc_tlb1_3_reg = (mp1_mmhub_soc_tlb1_3_reg & ~MP1_MMHUB_SOC_TLB1_3_SEG_SIZE_MASK) | (seg_size << MP1_MMHUB_SOC_TLB1_3_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_3_SET_SEG_OFFSET(mp1_mmhub_soc_tlb1_3_reg, seg_offset) \
      mp1_mmhub_soc_tlb1_3_reg = (mp1_mmhub_soc_tlb1_3_reg & ~MP1_MMHUB_SOC_TLB1_3_SEG_OFFSET_MASK) | (seg_offset << MP1_MMHUB_SOC_TLB1_3_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_3_t {
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_3_COHERENCE_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_3_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_3_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp1_mmhub_soc_tlb1_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_3_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_3_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_3_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_3_COHERENCE_SIZE;
      } mp1_mmhub_soc_tlb1_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb1_3_t f;
} mp1_mmhub_soc_tlb1_3_u;


/*
 * MP1_MMHUB_SOC_TLB2_3 struct
 */

#define MP1_MMHUB_SOC_TLB2_3_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB2_3_AWUSER_SIZE  32

#define MP1_MMHUB_SOC_TLB2_3_AWUSER_SHIFT  0

#define MP1_MMHUB_SOC_TLB2_3_AWUSER_MASK  0xffffffff

#define MP1_MMHUB_SOC_TLB2_3_MASK \
      (MP1_MMHUB_SOC_TLB2_3_AWUSER_MASK)

#define MP1_MMHUB_SOC_TLB2_3_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB2_3_GET_AWUSER(mp1_mmhub_soc_tlb2_3) \
      ((mp1_mmhub_soc_tlb2_3 & MP1_MMHUB_SOC_TLB2_3_AWUSER_MASK) >> MP1_MMHUB_SOC_TLB2_3_AWUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB2_3_SET_AWUSER(mp1_mmhub_soc_tlb2_3_reg, awuser) \
      mp1_mmhub_soc_tlb2_3_reg = (mp1_mmhub_soc_tlb2_3_reg & ~MP1_MMHUB_SOC_TLB2_3_AWUSER_MASK) | (awuser << MP1_MMHUB_SOC_TLB2_3_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_3_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_3_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_3_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_3_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb2_3_t f;
} mp1_mmhub_soc_tlb2_3_u;


/*
 * MP1_MMHUB_SOC_TLB3_3 struct
 */

#define MP1_MMHUB_SOC_TLB3_3_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB3_3_ARUSER_SIZE  28
#define MP1_MMHUB_SOC_TLB3_3_WUSER_SIZE  3

#define MP1_MMHUB_SOC_TLB3_3_ARUSER_SHIFT  0
#define MP1_MMHUB_SOC_TLB3_3_WUSER_SHIFT  28

#define MP1_MMHUB_SOC_TLB3_3_ARUSER_MASK  0x0fffffff
#define MP1_MMHUB_SOC_TLB3_3_WUSER_MASK  0x70000000

#define MP1_MMHUB_SOC_TLB3_3_MASK \
      (MP1_MMHUB_SOC_TLB3_3_ARUSER_MASK | \
      MP1_MMHUB_SOC_TLB3_3_WUSER_MASK)

#define MP1_MMHUB_SOC_TLB3_3_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB3_3_GET_ARUSER(mp1_mmhub_soc_tlb3_3) \
      ((mp1_mmhub_soc_tlb3_3 & MP1_MMHUB_SOC_TLB3_3_ARUSER_MASK) >> MP1_MMHUB_SOC_TLB3_3_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_3_GET_WUSER(mp1_mmhub_soc_tlb3_3) \
      ((mp1_mmhub_soc_tlb3_3 & MP1_MMHUB_SOC_TLB3_3_WUSER_MASK) >> MP1_MMHUB_SOC_TLB3_3_WUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB3_3_SET_ARUSER(mp1_mmhub_soc_tlb3_3_reg, aruser) \
      mp1_mmhub_soc_tlb3_3_reg = (mp1_mmhub_soc_tlb3_3_reg & ~MP1_MMHUB_SOC_TLB3_3_ARUSER_MASK) | (aruser << MP1_MMHUB_SOC_TLB3_3_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_3_SET_WUSER(mp1_mmhub_soc_tlb3_3_reg, wuser) \
      mp1_mmhub_soc_tlb3_3_reg = (mp1_mmhub_soc_tlb3_3_reg & ~MP1_MMHUB_SOC_TLB3_3_WUSER_MASK) | (wuser << MP1_MMHUB_SOC_TLB3_3_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_3_t {
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_3_ARUSER_SIZE;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_3_WUSER_SIZE;
            unsigned int                                : 1;
      } mp1_mmhub_soc_tlb3_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_3_t {
            unsigned int                                : 1;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_3_WUSER_SIZE;
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_3_ARUSER_SIZE;
      } mp1_mmhub_soc_tlb3_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb3_3_t f;
} mp1_mmhub_soc_tlb3_3_u;


/*
 * MP1_MMHUB_SOC_TLB0_4 struct
 */

#define MP1_MMHUB_SOC_TLB0_4_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB0_4_SOC_ADDR_SIZE  22

#define MP1_MMHUB_SOC_TLB0_4_SOC_ADDR_SHIFT  0

#define MP1_MMHUB_SOC_TLB0_4_SOC_ADDR_MASK  0x003fffff

#define MP1_MMHUB_SOC_TLB0_4_MASK \
      (MP1_MMHUB_SOC_TLB0_4_SOC_ADDR_MASK)

#define MP1_MMHUB_SOC_TLB0_4_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB0_4_GET_SOC_ADDR(mp1_mmhub_soc_tlb0_4) \
      ((mp1_mmhub_soc_tlb0_4 & MP1_MMHUB_SOC_TLB0_4_SOC_ADDR_MASK) >> MP1_MMHUB_SOC_TLB0_4_SOC_ADDR_SHIFT)

#define MP1_MMHUB_SOC_TLB0_4_SET_SOC_ADDR(mp1_mmhub_soc_tlb0_4_reg, soc_addr) \
      mp1_mmhub_soc_tlb0_4_reg = (mp1_mmhub_soc_tlb0_4_reg & ~MP1_MMHUB_SOC_TLB0_4_SOC_ADDR_MASK) | (soc_addr << MP1_MMHUB_SOC_TLB0_4_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_4_t {
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_4_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp1_mmhub_soc_tlb0_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_4_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_4_SOC_ADDR_SIZE;
      } mp1_mmhub_soc_tlb0_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb0_4_t f;
} mp1_mmhub_soc_tlb0_4_u;


/*
 * MP1_MMHUB_SOC_TLB1_4 struct
 */

#define MP1_MMHUB_SOC_TLB1_4_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB1_4_COHERENCE_SIZE  1
#define MP1_MMHUB_SOC_TLB1_4_SEG_SIZE_SIZE  4
#define MP1_MMHUB_SOC_TLB1_4_SEG_OFFSET_SIZE  9

#define MP1_MMHUB_SOC_TLB1_4_COHERENCE_SHIFT  0
#define MP1_MMHUB_SOC_TLB1_4_SEG_SIZE_SHIFT  1
#define MP1_MMHUB_SOC_TLB1_4_SEG_OFFSET_SHIFT  5

#define MP1_MMHUB_SOC_TLB1_4_COHERENCE_MASK  0x00000001
#define MP1_MMHUB_SOC_TLB1_4_SEG_SIZE_MASK  0x0000001e
#define MP1_MMHUB_SOC_TLB1_4_SEG_OFFSET_MASK  0x00003fe0

#define MP1_MMHUB_SOC_TLB1_4_MASK \
      (MP1_MMHUB_SOC_TLB1_4_COHERENCE_MASK | \
      MP1_MMHUB_SOC_TLB1_4_SEG_SIZE_MASK | \
      MP1_MMHUB_SOC_TLB1_4_SEG_OFFSET_MASK)

#define MP1_MMHUB_SOC_TLB1_4_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB1_4_GET_COHERENCE(mp1_mmhub_soc_tlb1_4) \
      ((mp1_mmhub_soc_tlb1_4 & MP1_MMHUB_SOC_TLB1_4_COHERENCE_MASK) >> MP1_MMHUB_SOC_TLB1_4_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_4_GET_SEG_SIZE(mp1_mmhub_soc_tlb1_4) \
      ((mp1_mmhub_soc_tlb1_4 & MP1_MMHUB_SOC_TLB1_4_SEG_SIZE_MASK) >> MP1_MMHUB_SOC_TLB1_4_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_4_GET_SEG_OFFSET(mp1_mmhub_soc_tlb1_4) \
      ((mp1_mmhub_soc_tlb1_4 & MP1_MMHUB_SOC_TLB1_4_SEG_OFFSET_MASK) >> MP1_MMHUB_SOC_TLB1_4_SEG_OFFSET_SHIFT)

#define MP1_MMHUB_SOC_TLB1_4_SET_COHERENCE(mp1_mmhub_soc_tlb1_4_reg, coherence) \
      mp1_mmhub_soc_tlb1_4_reg = (mp1_mmhub_soc_tlb1_4_reg & ~MP1_MMHUB_SOC_TLB1_4_COHERENCE_MASK) | (coherence << MP1_MMHUB_SOC_TLB1_4_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_4_SET_SEG_SIZE(mp1_mmhub_soc_tlb1_4_reg, seg_size) \
      mp1_mmhub_soc_tlb1_4_reg = (mp1_mmhub_soc_tlb1_4_reg & ~MP1_MMHUB_SOC_TLB1_4_SEG_SIZE_MASK) | (seg_size << MP1_MMHUB_SOC_TLB1_4_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_4_SET_SEG_OFFSET(mp1_mmhub_soc_tlb1_4_reg, seg_offset) \
      mp1_mmhub_soc_tlb1_4_reg = (mp1_mmhub_soc_tlb1_4_reg & ~MP1_MMHUB_SOC_TLB1_4_SEG_OFFSET_MASK) | (seg_offset << MP1_MMHUB_SOC_TLB1_4_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_4_t {
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_4_COHERENCE_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_4_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_4_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp1_mmhub_soc_tlb1_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_4_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_4_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_4_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_4_COHERENCE_SIZE;
      } mp1_mmhub_soc_tlb1_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb1_4_t f;
} mp1_mmhub_soc_tlb1_4_u;


/*
 * MP1_MMHUB_SOC_TLB2_4 struct
 */

#define MP1_MMHUB_SOC_TLB2_4_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB2_4_AWUSER_SIZE  32

#define MP1_MMHUB_SOC_TLB2_4_AWUSER_SHIFT  0

#define MP1_MMHUB_SOC_TLB2_4_AWUSER_MASK  0xffffffff

#define MP1_MMHUB_SOC_TLB2_4_MASK \
      (MP1_MMHUB_SOC_TLB2_4_AWUSER_MASK)

#define MP1_MMHUB_SOC_TLB2_4_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB2_4_GET_AWUSER(mp1_mmhub_soc_tlb2_4) \
      ((mp1_mmhub_soc_tlb2_4 & MP1_MMHUB_SOC_TLB2_4_AWUSER_MASK) >> MP1_MMHUB_SOC_TLB2_4_AWUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB2_4_SET_AWUSER(mp1_mmhub_soc_tlb2_4_reg, awuser) \
      mp1_mmhub_soc_tlb2_4_reg = (mp1_mmhub_soc_tlb2_4_reg & ~MP1_MMHUB_SOC_TLB2_4_AWUSER_MASK) | (awuser << MP1_MMHUB_SOC_TLB2_4_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_4_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_4_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_4_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_4_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb2_4_t f;
} mp1_mmhub_soc_tlb2_4_u;


/*
 * MP1_MMHUB_SOC_TLB3_4 struct
 */

#define MP1_MMHUB_SOC_TLB3_4_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB3_4_ARUSER_SIZE  28
#define MP1_MMHUB_SOC_TLB3_4_WUSER_SIZE  3

#define MP1_MMHUB_SOC_TLB3_4_ARUSER_SHIFT  0
#define MP1_MMHUB_SOC_TLB3_4_WUSER_SHIFT  28

#define MP1_MMHUB_SOC_TLB3_4_ARUSER_MASK  0x0fffffff
#define MP1_MMHUB_SOC_TLB3_4_WUSER_MASK  0x70000000

#define MP1_MMHUB_SOC_TLB3_4_MASK \
      (MP1_MMHUB_SOC_TLB3_4_ARUSER_MASK | \
      MP1_MMHUB_SOC_TLB3_4_WUSER_MASK)

#define MP1_MMHUB_SOC_TLB3_4_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB3_4_GET_ARUSER(mp1_mmhub_soc_tlb3_4) \
      ((mp1_mmhub_soc_tlb3_4 & MP1_MMHUB_SOC_TLB3_4_ARUSER_MASK) >> MP1_MMHUB_SOC_TLB3_4_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_4_GET_WUSER(mp1_mmhub_soc_tlb3_4) \
      ((mp1_mmhub_soc_tlb3_4 & MP1_MMHUB_SOC_TLB3_4_WUSER_MASK) >> MP1_MMHUB_SOC_TLB3_4_WUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB3_4_SET_ARUSER(mp1_mmhub_soc_tlb3_4_reg, aruser) \
      mp1_mmhub_soc_tlb3_4_reg = (mp1_mmhub_soc_tlb3_4_reg & ~MP1_MMHUB_SOC_TLB3_4_ARUSER_MASK) | (aruser << MP1_MMHUB_SOC_TLB3_4_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_4_SET_WUSER(mp1_mmhub_soc_tlb3_4_reg, wuser) \
      mp1_mmhub_soc_tlb3_4_reg = (mp1_mmhub_soc_tlb3_4_reg & ~MP1_MMHUB_SOC_TLB3_4_WUSER_MASK) | (wuser << MP1_MMHUB_SOC_TLB3_4_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_4_t {
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_4_ARUSER_SIZE;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_4_WUSER_SIZE;
            unsigned int                                : 1;
      } mp1_mmhub_soc_tlb3_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_4_t {
            unsigned int                                : 1;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_4_WUSER_SIZE;
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_4_ARUSER_SIZE;
      } mp1_mmhub_soc_tlb3_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb3_4_t f;
} mp1_mmhub_soc_tlb3_4_u;


/*
 * MP1_MMHUB_SOC_TLB0_5 struct
 */

#define MP1_MMHUB_SOC_TLB0_5_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB0_5_SOC_ADDR_SIZE  22

#define MP1_MMHUB_SOC_TLB0_5_SOC_ADDR_SHIFT  0

#define MP1_MMHUB_SOC_TLB0_5_SOC_ADDR_MASK  0x003fffff

#define MP1_MMHUB_SOC_TLB0_5_MASK \
      (MP1_MMHUB_SOC_TLB0_5_SOC_ADDR_MASK)

#define MP1_MMHUB_SOC_TLB0_5_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB0_5_GET_SOC_ADDR(mp1_mmhub_soc_tlb0_5) \
      ((mp1_mmhub_soc_tlb0_5 & MP1_MMHUB_SOC_TLB0_5_SOC_ADDR_MASK) >> MP1_MMHUB_SOC_TLB0_5_SOC_ADDR_SHIFT)

#define MP1_MMHUB_SOC_TLB0_5_SET_SOC_ADDR(mp1_mmhub_soc_tlb0_5_reg, soc_addr) \
      mp1_mmhub_soc_tlb0_5_reg = (mp1_mmhub_soc_tlb0_5_reg & ~MP1_MMHUB_SOC_TLB0_5_SOC_ADDR_MASK) | (soc_addr << MP1_MMHUB_SOC_TLB0_5_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_5_t {
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_5_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp1_mmhub_soc_tlb0_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_5_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_5_SOC_ADDR_SIZE;
      } mp1_mmhub_soc_tlb0_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb0_5_t f;
} mp1_mmhub_soc_tlb0_5_u;


/*
 * MP1_MMHUB_SOC_TLB1_5 struct
 */

#define MP1_MMHUB_SOC_TLB1_5_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB1_5_COHERENCE_SIZE  1
#define MP1_MMHUB_SOC_TLB1_5_SEG_SIZE_SIZE  4
#define MP1_MMHUB_SOC_TLB1_5_SEG_OFFSET_SIZE  9

#define MP1_MMHUB_SOC_TLB1_5_COHERENCE_SHIFT  0
#define MP1_MMHUB_SOC_TLB1_5_SEG_SIZE_SHIFT  1
#define MP1_MMHUB_SOC_TLB1_5_SEG_OFFSET_SHIFT  5

#define MP1_MMHUB_SOC_TLB1_5_COHERENCE_MASK  0x00000001
#define MP1_MMHUB_SOC_TLB1_5_SEG_SIZE_MASK  0x0000001e
#define MP1_MMHUB_SOC_TLB1_5_SEG_OFFSET_MASK  0x00003fe0

#define MP1_MMHUB_SOC_TLB1_5_MASK \
      (MP1_MMHUB_SOC_TLB1_5_COHERENCE_MASK | \
      MP1_MMHUB_SOC_TLB1_5_SEG_SIZE_MASK | \
      MP1_MMHUB_SOC_TLB1_5_SEG_OFFSET_MASK)

#define MP1_MMHUB_SOC_TLB1_5_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB1_5_GET_COHERENCE(mp1_mmhub_soc_tlb1_5) \
      ((mp1_mmhub_soc_tlb1_5 & MP1_MMHUB_SOC_TLB1_5_COHERENCE_MASK) >> MP1_MMHUB_SOC_TLB1_5_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_5_GET_SEG_SIZE(mp1_mmhub_soc_tlb1_5) \
      ((mp1_mmhub_soc_tlb1_5 & MP1_MMHUB_SOC_TLB1_5_SEG_SIZE_MASK) >> MP1_MMHUB_SOC_TLB1_5_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_5_GET_SEG_OFFSET(mp1_mmhub_soc_tlb1_5) \
      ((mp1_mmhub_soc_tlb1_5 & MP1_MMHUB_SOC_TLB1_5_SEG_OFFSET_MASK) >> MP1_MMHUB_SOC_TLB1_5_SEG_OFFSET_SHIFT)

#define MP1_MMHUB_SOC_TLB1_5_SET_COHERENCE(mp1_mmhub_soc_tlb1_5_reg, coherence) \
      mp1_mmhub_soc_tlb1_5_reg = (mp1_mmhub_soc_tlb1_5_reg & ~MP1_MMHUB_SOC_TLB1_5_COHERENCE_MASK) | (coherence << MP1_MMHUB_SOC_TLB1_5_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_5_SET_SEG_SIZE(mp1_mmhub_soc_tlb1_5_reg, seg_size) \
      mp1_mmhub_soc_tlb1_5_reg = (mp1_mmhub_soc_tlb1_5_reg & ~MP1_MMHUB_SOC_TLB1_5_SEG_SIZE_MASK) | (seg_size << MP1_MMHUB_SOC_TLB1_5_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_5_SET_SEG_OFFSET(mp1_mmhub_soc_tlb1_5_reg, seg_offset) \
      mp1_mmhub_soc_tlb1_5_reg = (mp1_mmhub_soc_tlb1_5_reg & ~MP1_MMHUB_SOC_TLB1_5_SEG_OFFSET_MASK) | (seg_offset << MP1_MMHUB_SOC_TLB1_5_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_5_t {
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_5_COHERENCE_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_5_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_5_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp1_mmhub_soc_tlb1_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_5_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_5_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_5_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_5_COHERENCE_SIZE;
      } mp1_mmhub_soc_tlb1_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb1_5_t f;
} mp1_mmhub_soc_tlb1_5_u;


/*
 * MP1_MMHUB_SOC_TLB2_5 struct
 */

#define MP1_MMHUB_SOC_TLB2_5_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB2_5_AWUSER_SIZE  32

#define MP1_MMHUB_SOC_TLB2_5_AWUSER_SHIFT  0

#define MP1_MMHUB_SOC_TLB2_5_AWUSER_MASK  0xffffffff

#define MP1_MMHUB_SOC_TLB2_5_MASK \
      (MP1_MMHUB_SOC_TLB2_5_AWUSER_MASK)

#define MP1_MMHUB_SOC_TLB2_5_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB2_5_GET_AWUSER(mp1_mmhub_soc_tlb2_5) \
      ((mp1_mmhub_soc_tlb2_5 & MP1_MMHUB_SOC_TLB2_5_AWUSER_MASK) >> MP1_MMHUB_SOC_TLB2_5_AWUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB2_5_SET_AWUSER(mp1_mmhub_soc_tlb2_5_reg, awuser) \
      mp1_mmhub_soc_tlb2_5_reg = (mp1_mmhub_soc_tlb2_5_reg & ~MP1_MMHUB_SOC_TLB2_5_AWUSER_MASK) | (awuser << MP1_MMHUB_SOC_TLB2_5_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_5_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_5_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_5_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_5_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb2_5_t f;
} mp1_mmhub_soc_tlb2_5_u;


/*
 * MP1_MMHUB_SOC_TLB3_5 struct
 */

#define MP1_MMHUB_SOC_TLB3_5_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB3_5_ARUSER_SIZE  28
#define MP1_MMHUB_SOC_TLB3_5_WUSER_SIZE  3

#define MP1_MMHUB_SOC_TLB3_5_ARUSER_SHIFT  0
#define MP1_MMHUB_SOC_TLB3_5_WUSER_SHIFT  28

#define MP1_MMHUB_SOC_TLB3_5_ARUSER_MASK  0x0fffffff
#define MP1_MMHUB_SOC_TLB3_5_WUSER_MASK  0x70000000

#define MP1_MMHUB_SOC_TLB3_5_MASK \
      (MP1_MMHUB_SOC_TLB3_5_ARUSER_MASK | \
      MP1_MMHUB_SOC_TLB3_5_WUSER_MASK)

#define MP1_MMHUB_SOC_TLB3_5_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB3_5_GET_ARUSER(mp1_mmhub_soc_tlb3_5) \
      ((mp1_mmhub_soc_tlb3_5 & MP1_MMHUB_SOC_TLB3_5_ARUSER_MASK) >> MP1_MMHUB_SOC_TLB3_5_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_5_GET_WUSER(mp1_mmhub_soc_tlb3_5) \
      ((mp1_mmhub_soc_tlb3_5 & MP1_MMHUB_SOC_TLB3_5_WUSER_MASK) >> MP1_MMHUB_SOC_TLB3_5_WUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB3_5_SET_ARUSER(mp1_mmhub_soc_tlb3_5_reg, aruser) \
      mp1_mmhub_soc_tlb3_5_reg = (mp1_mmhub_soc_tlb3_5_reg & ~MP1_MMHUB_SOC_TLB3_5_ARUSER_MASK) | (aruser << MP1_MMHUB_SOC_TLB3_5_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_5_SET_WUSER(mp1_mmhub_soc_tlb3_5_reg, wuser) \
      mp1_mmhub_soc_tlb3_5_reg = (mp1_mmhub_soc_tlb3_5_reg & ~MP1_MMHUB_SOC_TLB3_5_WUSER_MASK) | (wuser << MP1_MMHUB_SOC_TLB3_5_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_5_t {
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_5_ARUSER_SIZE;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_5_WUSER_SIZE;
            unsigned int                                : 1;
      } mp1_mmhub_soc_tlb3_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_5_t {
            unsigned int                                : 1;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_5_WUSER_SIZE;
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_5_ARUSER_SIZE;
      } mp1_mmhub_soc_tlb3_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb3_5_t f;
} mp1_mmhub_soc_tlb3_5_u;


/*
 * MP1_MMHUB_SOC_TLB0_6 struct
 */

#define MP1_MMHUB_SOC_TLB0_6_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB0_6_SOC_ADDR_SIZE  22

#define MP1_MMHUB_SOC_TLB0_6_SOC_ADDR_SHIFT  0

#define MP1_MMHUB_SOC_TLB0_6_SOC_ADDR_MASK  0x003fffff

#define MP1_MMHUB_SOC_TLB0_6_MASK \
      (MP1_MMHUB_SOC_TLB0_6_SOC_ADDR_MASK)

#define MP1_MMHUB_SOC_TLB0_6_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB0_6_GET_SOC_ADDR(mp1_mmhub_soc_tlb0_6) \
      ((mp1_mmhub_soc_tlb0_6 & MP1_MMHUB_SOC_TLB0_6_SOC_ADDR_MASK) >> MP1_MMHUB_SOC_TLB0_6_SOC_ADDR_SHIFT)

#define MP1_MMHUB_SOC_TLB0_6_SET_SOC_ADDR(mp1_mmhub_soc_tlb0_6_reg, soc_addr) \
      mp1_mmhub_soc_tlb0_6_reg = (mp1_mmhub_soc_tlb0_6_reg & ~MP1_MMHUB_SOC_TLB0_6_SOC_ADDR_MASK) | (soc_addr << MP1_MMHUB_SOC_TLB0_6_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_6_t {
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_6_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp1_mmhub_soc_tlb0_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_6_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_6_SOC_ADDR_SIZE;
      } mp1_mmhub_soc_tlb0_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb0_6_t f;
} mp1_mmhub_soc_tlb0_6_u;


/*
 * MP1_MMHUB_SOC_TLB1_6 struct
 */

#define MP1_MMHUB_SOC_TLB1_6_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB1_6_COHERENCE_SIZE  1
#define MP1_MMHUB_SOC_TLB1_6_SEG_SIZE_SIZE  4
#define MP1_MMHUB_SOC_TLB1_6_SEG_OFFSET_SIZE  9

#define MP1_MMHUB_SOC_TLB1_6_COHERENCE_SHIFT  0
#define MP1_MMHUB_SOC_TLB1_6_SEG_SIZE_SHIFT  1
#define MP1_MMHUB_SOC_TLB1_6_SEG_OFFSET_SHIFT  5

#define MP1_MMHUB_SOC_TLB1_6_COHERENCE_MASK  0x00000001
#define MP1_MMHUB_SOC_TLB1_6_SEG_SIZE_MASK  0x0000001e
#define MP1_MMHUB_SOC_TLB1_6_SEG_OFFSET_MASK  0x00003fe0

#define MP1_MMHUB_SOC_TLB1_6_MASK \
      (MP1_MMHUB_SOC_TLB1_6_COHERENCE_MASK | \
      MP1_MMHUB_SOC_TLB1_6_SEG_SIZE_MASK | \
      MP1_MMHUB_SOC_TLB1_6_SEG_OFFSET_MASK)

#define MP1_MMHUB_SOC_TLB1_6_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB1_6_GET_COHERENCE(mp1_mmhub_soc_tlb1_6) \
      ((mp1_mmhub_soc_tlb1_6 & MP1_MMHUB_SOC_TLB1_6_COHERENCE_MASK) >> MP1_MMHUB_SOC_TLB1_6_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_6_GET_SEG_SIZE(mp1_mmhub_soc_tlb1_6) \
      ((mp1_mmhub_soc_tlb1_6 & MP1_MMHUB_SOC_TLB1_6_SEG_SIZE_MASK) >> MP1_MMHUB_SOC_TLB1_6_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_6_GET_SEG_OFFSET(mp1_mmhub_soc_tlb1_6) \
      ((mp1_mmhub_soc_tlb1_6 & MP1_MMHUB_SOC_TLB1_6_SEG_OFFSET_MASK) >> MP1_MMHUB_SOC_TLB1_6_SEG_OFFSET_SHIFT)

#define MP1_MMHUB_SOC_TLB1_6_SET_COHERENCE(mp1_mmhub_soc_tlb1_6_reg, coherence) \
      mp1_mmhub_soc_tlb1_6_reg = (mp1_mmhub_soc_tlb1_6_reg & ~MP1_MMHUB_SOC_TLB1_6_COHERENCE_MASK) | (coherence << MP1_MMHUB_SOC_TLB1_6_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_6_SET_SEG_SIZE(mp1_mmhub_soc_tlb1_6_reg, seg_size) \
      mp1_mmhub_soc_tlb1_6_reg = (mp1_mmhub_soc_tlb1_6_reg & ~MP1_MMHUB_SOC_TLB1_6_SEG_SIZE_MASK) | (seg_size << MP1_MMHUB_SOC_TLB1_6_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_6_SET_SEG_OFFSET(mp1_mmhub_soc_tlb1_6_reg, seg_offset) \
      mp1_mmhub_soc_tlb1_6_reg = (mp1_mmhub_soc_tlb1_6_reg & ~MP1_MMHUB_SOC_TLB1_6_SEG_OFFSET_MASK) | (seg_offset << MP1_MMHUB_SOC_TLB1_6_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_6_t {
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_6_COHERENCE_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_6_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_6_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp1_mmhub_soc_tlb1_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_6_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_6_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_6_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_6_COHERENCE_SIZE;
      } mp1_mmhub_soc_tlb1_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb1_6_t f;
} mp1_mmhub_soc_tlb1_6_u;


/*
 * MP1_MMHUB_SOC_TLB2_6 struct
 */

#define MP1_MMHUB_SOC_TLB2_6_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB2_6_AWUSER_SIZE  32

#define MP1_MMHUB_SOC_TLB2_6_AWUSER_SHIFT  0

#define MP1_MMHUB_SOC_TLB2_6_AWUSER_MASK  0xffffffff

#define MP1_MMHUB_SOC_TLB2_6_MASK \
      (MP1_MMHUB_SOC_TLB2_6_AWUSER_MASK)

#define MP1_MMHUB_SOC_TLB2_6_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB2_6_GET_AWUSER(mp1_mmhub_soc_tlb2_6) \
      ((mp1_mmhub_soc_tlb2_6 & MP1_MMHUB_SOC_TLB2_6_AWUSER_MASK) >> MP1_MMHUB_SOC_TLB2_6_AWUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB2_6_SET_AWUSER(mp1_mmhub_soc_tlb2_6_reg, awuser) \
      mp1_mmhub_soc_tlb2_6_reg = (mp1_mmhub_soc_tlb2_6_reg & ~MP1_MMHUB_SOC_TLB2_6_AWUSER_MASK) | (awuser << MP1_MMHUB_SOC_TLB2_6_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_6_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_6_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_6_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_6_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb2_6_t f;
} mp1_mmhub_soc_tlb2_6_u;


/*
 * MP1_MMHUB_SOC_TLB3_6 struct
 */

#define MP1_MMHUB_SOC_TLB3_6_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB3_6_ARUSER_SIZE  28
#define MP1_MMHUB_SOC_TLB3_6_WUSER_SIZE  3

#define MP1_MMHUB_SOC_TLB3_6_ARUSER_SHIFT  0
#define MP1_MMHUB_SOC_TLB3_6_WUSER_SHIFT  28

#define MP1_MMHUB_SOC_TLB3_6_ARUSER_MASK  0x0fffffff
#define MP1_MMHUB_SOC_TLB3_6_WUSER_MASK  0x70000000

#define MP1_MMHUB_SOC_TLB3_6_MASK \
      (MP1_MMHUB_SOC_TLB3_6_ARUSER_MASK | \
      MP1_MMHUB_SOC_TLB3_6_WUSER_MASK)

#define MP1_MMHUB_SOC_TLB3_6_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB3_6_GET_ARUSER(mp1_mmhub_soc_tlb3_6) \
      ((mp1_mmhub_soc_tlb3_6 & MP1_MMHUB_SOC_TLB3_6_ARUSER_MASK) >> MP1_MMHUB_SOC_TLB3_6_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_6_GET_WUSER(mp1_mmhub_soc_tlb3_6) \
      ((mp1_mmhub_soc_tlb3_6 & MP1_MMHUB_SOC_TLB3_6_WUSER_MASK) >> MP1_MMHUB_SOC_TLB3_6_WUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB3_6_SET_ARUSER(mp1_mmhub_soc_tlb3_6_reg, aruser) \
      mp1_mmhub_soc_tlb3_6_reg = (mp1_mmhub_soc_tlb3_6_reg & ~MP1_MMHUB_SOC_TLB3_6_ARUSER_MASK) | (aruser << MP1_MMHUB_SOC_TLB3_6_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_6_SET_WUSER(mp1_mmhub_soc_tlb3_6_reg, wuser) \
      mp1_mmhub_soc_tlb3_6_reg = (mp1_mmhub_soc_tlb3_6_reg & ~MP1_MMHUB_SOC_TLB3_6_WUSER_MASK) | (wuser << MP1_MMHUB_SOC_TLB3_6_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_6_t {
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_6_ARUSER_SIZE;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_6_WUSER_SIZE;
            unsigned int                                : 1;
      } mp1_mmhub_soc_tlb3_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_6_t {
            unsigned int                                : 1;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_6_WUSER_SIZE;
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_6_ARUSER_SIZE;
      } mp1_mmhub_soc_tlb3_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb3_6_t f;
} mp1_mmhub_soc_tlb3_6_u;


/*
 * MP1_MMHUB_SOC_TLB0_7 struct
 */

#define MP1_MMHUB_SOC_TLB0_7_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB0_7_SOC_ADDR_SIZE  22

#define MP1_MMHUB_SOC_TLB0_7_SOC_ADDR_SHIFT  0

#define MP1_MMHUB_SOC_TLB0_7_SOC_ADDR_MASK  0x003fffff

#define MP1_MMHUB_SOC_TLB0_7_MASK \
      (MP1_MMHUB_SOC_TLB0_7_SOC_ADDR_MASK)

#define MP1_MMHUB_SOC_TLB0_7_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB0_7_GET_SOC_ADDR(mp1_mmhub_soc_tlb0_7) \
      ((mp1_mmhub_soc_tlb0_7 & MP1_MMHUB_SOC_TLB0_7_SOC_ADDR_MASK) >> MP1_MMHUB_SOC_TLB0_7_SOC_ADDR_SHIFT)

#define MP1_MMHUB_SOC_TLB0_7_SET_SOC_ADDR(mp1_mmhub_soc_tlb0_7_reg, soc_addr) \
      mp1_mmhub_soc_tlb0_7_reg = (mp1_mmhub_soc_tlb0_7_reg & ~MP1_MMHUB_SOC_TLB0_7_SOC_ADDR_MASK) | (soc_addr << MP1_MMHUB_SOC_TLB0_7_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_7_t {
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_7_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp1_mmhub_soc_tlb0_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_7_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_7_SOC_ADDR_SIZE;
      } mp1_mmhub_soc_tlb0_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb0_7_t f;
} mp1_mmhub_soc_tlb0_7_u;


/*
 * MP1_MMHUB_SOC_TLB1_7 struct
 */

#define MP1_MMHUB_SOC_TLB1_7_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB1_7_COHERENCE_SIZE  1
#define MP1_MMHUB_SOC_TLB1_7_SEG_SIZE_SIZE  4
#define MP1_MMHUB_SOC_TLB1_7_SEG_OFFSET_SIZE  9

#define MP1_MMHUB_SOC_TLB1_7_COHERENCE_SHIFT  0
#define MP1_MMHUB_SOC_TLB1_7_SEG_SIZE_SHIFT  1
#define MP1_MMHUB_SOC_TLB1_7_SEG_OFFSET_SHIFT  5

#define MP1_MMHUB_SOC_TLB1_7_COHERENCE_MASK  0x00000001
#define MP1_MMHUB_SOC_TLB1_7_SEG_SIZE_MASK  0x0000001e
#define MP1_MMHUB_SOC_TLB1_7_SEG_OFFSET_MASK  0x00003fe0

#define MP1_MMHUB_SOC_TLB1_7_MASK \
      (MP1_MMHUB_SOC_TLB1_7_COHERENCE_MASK | \
      MP1_MMHUB_SOC_TLB1_7_SEG_SIZE_MASK | \
      MP1_MMHUB_SOC_TLB1_7_SEG_OFFSET_MASK)

#define MP1_MMHUB_SOC_TLB1_7_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB1_7_GET_COHERENCE(mp1_mmhub_soc_tlb1_7) \
      ((mp1_mmhub_soc_tlb1_7 & MP1_MMHUB_SOC_TLB1_7_COHERENCE_MASK) >> MP1_MMHUB_SOC_TLB1_7_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_7_GET_SEG_SIZE(mp1_mmhub_soc_tlb1_7) \
      ((mp1_mmhub_soc_tlb1_7 & MP1_MMHUB_SOC_TLB1_7_SEG_SIZE_MASK) >> MP1_MMHUB_SOC_TLB1_7_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_7_GET_SEG_OFFSET(mp1_mmhub_soc_tlb1_7) \
      ((mp1_mmhub_soc_tlb1_7 & MP1_MMHUB_SOC_TLB1_7_SEG_OFFSET_MASK) >> MP1_MMHUB_SOC_TLB1_7_SEG_OFFSET_SHIFT)

#define MP1_MMHUB_SOC_TLB1_7_SET_COHERENCE(mp1_mmhub_soc_tlb1_7_reg, coherence) \
      mp1_mmhub_soc_tlb1_7_reg = (mp1_mmhub_soc_tlb1_7_reg & ~MP1_MMHUB_SOC_TLB1_7_COHERENCE_MASK) | (coherence << MP1_MMHUB_SOC_TLB1_7_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_7_SET_SEG_SIZE(mp1_mmhub_soc_tlb1_7_reg, seg_size) \
      mp1_mmhub_soc_tlb1_7_reg = (mp1_mmhub_soc_tlb1_7_reg & ~MP1_MMHUB_SOC_TLB1_7_SEG_SIZE_MASK) | (seg_size << MP1_MMHUB_SOC_TLB1_7_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_7_SET_SEG_OFFSET(mp1_mmhub_soc_tlb1_7_reg, seg_offset) \
      mp1_mmhub_soc_tlb1_7_reg = (mp1_mmhub_soc_tlb1_7_reg & ~MP1_MMHUB_SOC_TLB1_7_SEG_OFFSET_MASK) | (seg_offset << MP1_MMHUB_SOC_TLB1_7_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_7_t {
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_7_COHERENCE_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_7_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_7_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp1_mmhub_soc_tlb1_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_7_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_7_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_7_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_7_COHERENCE_SIZE;
      } mp1_mmhub_soc_tlb1_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb1_7_t f;
} mp1_mmhub_soc_tlb1_7_u;


/*
 * MP1_MMHUB_SOC_TLB2_7 struct
 */

#define MP1_MMHUB_SOC_TLB2_7_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB2_7_AWUSER_SIZE  32

#define MP1_MMHUB_SOC_TLB2_7_AWUSER_SHIFT  0

#define MP1_MMHUB_SOC_TLB2_7_AWUSER_MASK  0xffffffff

#define MP1_MMHUB_SOC_TLB2_7_MASK \
      (MP1_MMHUB_SOC_TLB2_7_AWUSER_MASK)

#define MP1_MMHUB_SOC_TLB2_7_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB2_7_GET_AWUSER(mp1_mmhub_soc_tlb2_7) \
      ((mp1_mmhub_soc_tlb2_7 & MP1_MMHUB_SOC_TLB2_7_AWUSER_MASK) >> MP1_MMHUB_SOC_TLB2_7_AWUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB2_7_SET_AWUSER(mp1_mmhub_soc_tlb2_7_reg, awuser) \
      mp1_mmhub_soc_tlb2_7_reg = (mp1_mmhub_soc_tlb2_7_reg & ~MP1_MMHUB_SOC_TLB2_7_AWUSER_MASK) | (awuser << MP1_MMHUB_SOC_TLB2_7_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_7_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_7_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_7_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_7_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb2_7_t f;
} mp1_mmhub_soc_tlb2_7_u;


/*
 * MP1_MMHUB_SOC_TLB3_7 struct
 */

#define MP1_MMHUB_SOC_TLB3_7_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB3_7_ARUSER_SIZE  28
#define MP1_MMHUB_SOC_TLB3_7_WUSER_SIZE  3

#define MP1_MMHUB_SOC_TLB3_7_ARUSER_SHIFT  0
#define MP1_MMHUB_SOC_TLB3_7_WUSER_SHIFT  28

#define MP1_MMHUB_SOC_TLB3_7_ARUSER_MASK  0x0fffffff
#define MP1_MMHUB_SOC_TLB3_7_WUSER_MASK  0x70000000

#define MP1_MMHUB_SOC_TLB3_7_MASK \
      (MP1_MMHUB_SOC_TLB3_7_ARUSER_MASK | \
      MP1_MMHUB_SOC_TLB3_7_WUSER_MASK)

#define MP1_MMHUB_SOC_TLB3_7_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB3_7_GET_ARUSER(mp1_mmhub_soc_tlb3_7) \
      ((mp1_mmhub_soc_tlb3_7 & MP1_MMHUB_SOC_TLB3_7_ARUSER_MASK) >> MP1_MMHUB_SOC_TLB3_7_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_7_GET_WUSER(mp1_mmhub_soc_tlb3_7) \
      ((mp1_mmhub_soc_tlb3_7 & MP1_MMHUB_SOC_TLB3_7_WUSER_MASK) >> MP1_MMHUB_SOC_TLB3_7_WUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB3_7_SET_ARUSER(mp1_mmhub_soc_tlb3_7_reg, aruser) \
      mp1_mmhub_soc_tlb3_7_reg = (mp1_mmhub_soc_tlb3_7_reg & ~MP1_MMHUB_SOC_TLB3_7_ARUSER_MASK) | (aruser << MP1_MMHUB_SOC_TLB3_7_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_7_SET_WUSER(mp1_mmhub_soc_tlb3_7_reg, wuser) \
      mp1_mmhub_soc_tlb3_7_reg = (mp1_mmhub_soc_tlb3_7_reg & ~MP1_MMHUB_SOC_TLB3_7_WUSER_MASK) | (wuser << MP1_MMHUB_SOC_TLB3_7_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_7_t {
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_7_ARUSER_SIZE;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_7_WUSER_SIZE;
            unsigned int                                : 1;
      } mp1_mmhub_soc_tlb3_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_7_t {
            unsigned int                                : 1;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_7_WUSER_SIZE;
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_7_ARUSER_SIZE;
      } mp1_mmhub_soc_tlb3_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb3_7_t f;
} mp1_mmhub_soc_tlb3_7_u;


/*
 * MP1_MMHUB_SOC_TLB0_8 struct
 */

#define MP1_MMHUB_SOC_TLB0_8_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB0_8_SOC_ADDR_SIZE  22

#define MP1_MMHUB_SOC_TLB0_8_SOC_ADDR_SHIFT  0

#define MP1_MMHUB_SOC_TLB0_8_SOC_ADDR_MASK  0x003fffff

#define MP1_MMHUB_SOC_TLB0_8_MASK \
      (MP1_MMHUB_SOC_TLB0_8_SOC_ADDR_MASK)

#define MP1_MMHUB_SOC_TLB0_8_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB0_8_GET_SOC_ADDR(mp1_mmhub_soc_tlb0_8) \
      ((mp1_mmhub_soc_tlb0_8 & MP1_MMHUB_SOC_TLB0_8_SOC_ADDR_MASK) >> MP1_MMHUB_SOC_TLB0_8_SOC_ADDR_SHIFT)

#define MP1_MMHUB_SOC_TLB0_8_SET_SOC_ADDR(mp1_mmhub_soc_tlb0_8_reg, soc_addr) \
      mp1_mmhub_soc_tlb0_8_reg = (mp1_mmhub_soc_tlb0_8_reg & ~MP1_MMHUB_SOC_TLB0_8_SOC_ADDR_MASK) | (soc_addr << MP1_MMHUB_SOC_TLB0_8_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_8_t {
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_8_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp1_mmhub_soc_tlb0_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_8_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_8_SOC_ADDR_SIZE;
      } mp1_mmhub_soc_tlb0_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb0_8_t f;
} mp1_mmhub_soc_tlb0_8_u;


/*
 * MP1_MMHUB_SOC_TLB1_8 struct
 */

#define MP1_MMHUB_SOC_TLB1_8_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB1_8_COHERENCE_SIZE  1
#define MP1_MMHUB_SOC_TLB1_8_SEG_SIZE_SIZE  4
#define MP1_MMHUB_SOC_TLB1_8_SEG_OFFSET_SIZE  9

#define MP1_MMHUB_SOC_TLB1_8_COHERENCE_SHIFT  0
#define MP1_MMHUB_SOC_TLB1_8_SEG_SIZE_SHIFT  1
#define MP1_MMHUB_SOC_TLB1_8_SEG_OFFSET_SHIFT  5

#define MP1_MMHUB_SOC_TLB1_8_COHERENCE_MASK  0x00000001
#define MP1_MMHUB_SOC_TLB1_8_SEG_SIZE_MASK  0x0000001e
#define MP1_MMHUB_SOC_TLB1_8_SEG_OFFSET_MASK  0x00003fe0

#define MP1_MMHUB_SOC_TLB1_8_MASK \
      (MP1_MMHUB_SOC_TLB1_8_COHERENCE_MASK | \
      MP1_MMHUB_SOC_TLB1_8_SEG_SIZE_MASK | \
      MP1_MMHUB_SOC_TLB1_8_SEG_OFFSET_MASK)

#define MP1_MMHUB_SOC_TLB1_8_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB1_8_GET_COHERENCE(mp1_mmhub_soc_tlb1_8) \
      ((mp1_mmhub_soc_tlb1_8 & MP1_MMHUB_SOC_TLB1_8_COHERENCE_MASK) >> MP1_MMHUB_SOC_TLB1_8_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_8_GET_SEG_SIZE(mp1_mmhub_soc_tlb1_8) \
      ((mp1_mmhub_soc_tlb1_8 & MP1_MMHUB_SOC_TLB1_8_SEG_SIZE_MASK) >> MP1_MMHUB_SOC_TLB1_8_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_8_GET_SEG_OFFSET(mp1_mmhub_soc_tlb1_8) \
      ((mp1_mmhub_soc_tlb1_8 & MP1_MMHUB_SOC_TLB1_8_SEG_OFFSET_MASK) >> MP1_MMHUB_SOC_TLB1_8_SEG_OFFSET_SHIFT)

#define MP1_MMHUB_SOC_TLB1_8_SET_COHERENCE(mp1_mmhub_soc_tlb1_8_reg, coherence) \
      mp1_mmhub_soc_tlb1_8_reg = (mp1_mmhub_soc_tlb1_8_reg & ~MP1_MMHUB_SOC_TLB1_8_COHERENCE_MASK) | (coherence << MP1_MMHUB_SOC_TLB1_8_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_8_SET_SEG_SIZE(mp1_mmhub_soc_tlb1_8_reg, seg_size) \
      mp1_mmhub_soc_tlb1_8_reg = (mp1_mmhub_soc_tlb1_8_reg & ~MP1_MMHUB_SOC_TLB1_8_SEG_SIZE_MASK) | (seg_size << MP1_MMHUB_SOC_TLB1_8_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_8_SET_SEG_OFFSET(mp1_mmhub_soc_tlb1_8_reg, seg_offset) \
      mp1_mmhub_soc_tlb1_8_reg = (mp1_mmhub_soc_tlb1_8_reg & ~MP1_MMHUB_SOC_TLB1_8_SEG_OFFSET_MASK) | (seg_offset << MP1_MMHUB_SOC_TLB1_8_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_8_t {
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_8_COHERENCE_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_8_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_8_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp1_mmhub_soc_tlb1_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_8_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_8_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_8_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_8_COHERENCE_SIZE;
      } mp1_mmhub_soc_tlb1_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb1_8_t f;
} mp1_mmhub_soc_tlb1_8_u;


/*
 * MP1_MMHUB_SOC_TLB2_8 struct
 */

#define MP1_MMHUB_SOC_TLB2_8_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB2_8_AWUSER_SIZE  32

#define MP1_MMHUB_SOC_TLB2_8_AWUSER_SHIFT  0

#define MP1_MMHUB_SOC_TLB2_8_AWUSER_MASK  0xffffffff

#define MP1_MMHUB_SOC_TLB2_8_MASK \
      (MP1_MMHUB_SOC_TLB2_8_AWUSER_MASK)

#define MP1_MMHUB_SOC_TLB2_8_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB2_8_GET_AWUSER(mp1_mmhub_soc_tlb2_8) \
      ((mp1_mmhub_soc_tlb2_8 & MP1_MMHUB_SOC_TLB2_8_AWUSER_MASK) >> MP1_MMHUB_SOC_TLB2_8_AWUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB2_8_SET_AWUSER(mp1_mmhub_soc_tlb2_8_reg, awuser) \
      mp1_mmhub_soc_tlb2_8_reg = (mp1_mmhub_soc_tlb2_8_reg & ~MP1_MMHUB_SOC_TLB2_8_AWUSER_MASK) | (awuser << MP1_MMHUB_SOC_TLB2_8_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_8_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_8_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_8_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_8_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb2_8_t f;
} mp1_mmhub_soc_tlb2_8_u;


/*
 * MP1_MMHUB_SOC_TLB3_8 struct
 */

#define MP1_MMHUB_SOC_TLB3_8_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB3_8_ARUSER_SIZE  28
#define MP1_MMHUB_SOC_TLB3_8_WUSER_SIZE  3

#define MP1_MMHUB_SOC_TLB3_8_ARUSER_SHIFT  0
#define MP1_MMHUB_SOC_TLB3_8_WUSER_SHIFT  28

#define MP1_MMHUB_SOC_TLB3_8_ARUSER_MASK  0x0fffffff
#define MP1_MMHUB_SOC_TLB3_8_WUSER_MASK  0x70000000

#define MP1_MMHUB_SOC_TLB3_8_MASK \
      (MP1_MMHUB_SOC_TLB3_8_ARUSER_MASK | \
      MP1_MMHUB_SOC_TLB3_8_WUSER_MASK)

#define MP1_MMHUB_SOC_TLB3_8_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB3_8_GET_ARUSER(mp1_mmhub_soc_tlb3_8) \
      ((mp1_mmhub_soc_tlb3_8 & MP1_MMHUB_SOC_TLB3_8_ARUSER_MASK) >> MP1_MMHUB_SOC_TLB3_8_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_8_GET_WUSER(mp1_mmhub_soc_tlb3_8) \
      ((mp1_mmhub_soc_tlb3_8 & MP1_MMHUB_SOC_TLB3_8_WUSER_MASK) >> MP1_MMHUB_SOC_TLB3_8_WUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB3_8_SET_ARUSER(mp1_mmhub_soc_tlb3_8_reg, aruser) \
      mp1_mmhub_soc_tlb3_8_reg = (mp1_mmhub_soc_tlb3_8_reg & ~MP1_MMHUB_SOC_TLB3_8_ARUSER_MASK) | (aruser << MP1_MMHUB_SOC_TLB3_8_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_8_SET_WUSER(mp1_mmhub_soc_tlb3_8_reg, wuser) \
      mp1_mmhub_soc_tlb3_8_reg = (mp1_mmhub_soc_tlb3_8_reg & ~MP1_MMHUB_SOC_TLB3_8_WUSER_MASK) | (wuser << MP1_MMHUB_SOC_TLB3_8_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_8_t {
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_8_ARUSER_SIZE;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_8_WUSER_SIZE;
            unsigned int                                : 1;
      } mp1_mmhub_soc_tlb3_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_8_t {
            unsigned int                                : 1;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_8_WUSER_SIZE;
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_8_ARUSER_SIZE;
      } mp1_mmhub_soc_tlb3_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb3_8_t f;
} mp1_mmhub_soc_tlb3_8_u;


/*
 * MP1_MMHUB_SOC_TLB0_9 struct
 */

#define MP1_MMHUB_SOC_TLB0_9_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB0_9_SOC_ADDR_SIZE  22

#define MP1_MMHUB_SOC_TLB0_9_SOC_ADDR_SHIFT  0

#define MP1_MMHUB_SOC_TLB0_9_SOC_ADDR_MASK  0x003fffff

#define MP1_MMHUB_SOC_TLB0_9_MASK \
      (MP1_MMHUB_SOC_TLB0_9_SOC_ADDR_MASK)

#define MP1_MMHUB_SOC_TLB0_9_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB0_9_GET_SOC_ADDR(mp1_mmhub_soc_tlb0_9) \
      ((mp1_mmhub_soc_tlb0_9 & MP1_MMHUB_SOC_TLB0_9_SOC_ADDR_MASK) >> MP1_MMHUB_SOC_TLB0_9_SOC_ADDR_SHIFT)

#define MP1_MMHUB_SOC_TLB0_9_SET_SOC_ADDR(mp1_mmhub_soc_tlb0_9_reg, soc_addr) \
      mp1_mmhub_soc_tlb0_9_reg = (mp1_mmhub_soc_tlb0_9_reg & ~MP1_MMHUB_SOC_TLB0_9_SOC_ADDR_MASK) | (soc_addr << MP1_MMHUB_SOC_TLB0_9_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_9_t {
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_9_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp1_mmhub_soc_tlb0_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_9_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_9_SOC_ADDR_SIZE;
      } mp1_mmhub_soc_tlb0_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb0_9_t f;
} mp1_mmhub_soc_tlb0_9_u;


/*
 * MP1_MMHUB_SOC_TLB1_9 struct
 */

#define MP1_MMHUB_SOC_TLB1_9_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB1_9_COHERENCE_SIZE  1
#define MP1_MMHUB_SOC_TLB1_9_SEG_SIZE_SIZE  4
#define MP1_MMHUB_SOC_TLB1_9_SEG_OFFSET_SIZE  9

#define MP1_MMHUB_SOC_TLB1_9_COHERENCE_SHIFT  0
#define MP1_MMHUB_SOC_TLB1_9_SEG_SIZE_SHIFT  1
#define MP1_MMHUB_SOC_TLB1_9_SEG_OFFSET_SHIFT  5

#define MP1_MMHUB_SOC_TLB1_9_COHERENCE_MASK  0x00000001
#define MP1_MMHUB_SOC_TLB1_9_SEG_SIZE_MASK  0x0000001e
#define MP1_MMHUB_SOC_TLB1_9_SEG_OFFSET_MASK  0x00003fe0

#define MP1_MMHUB_SOC_TLB1_9_MASK \
      (MP1_MMHUB_SOC_TLB1_9_COHERENCE_MASK | \
      MP1_MMHUB_SOC_TLB1_9_SEG_SIZE_MASK | \
      MP1_MMHUB_SOC_TLB1_9_SEG_OFFSET_MASK)

#define MP1_MMHUB_SOC_TLB1_9_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB1_9_GET_COHERENCE(mp1_mmhub_soc_tlb1_9) \
      ((mp1_mmhub_soc_tlb1_9 & MP1_MMHUB_SOC_TLB1_9_COHERENCE_MASK) >> MP1_MMHUB_SOC_TLB1_9_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_9_GET_SEG_SIZE(mp1_mmhub_soc_tlb1_9) \
      ((mp1_mmhub_soc_tlb1_9 & MP1_MMHUB_SOC_TLB1_9_SEG_SIZE_MASK) >> MP1_MMHUB_SOC_TLB1_9_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_9_GET_SEG_OFFSET(mp1_mmhub_soc_tlb1_9) \
      ((mp1_mmhub_soc_tlb1_9 & MP1_MMHUB_SOC_TLB1_9_SEG_OFFSET_MASK) >> MP1_MMHUB_SOC_TLB1_9_SEG_OFFSET_SHIFT)

#define MP1_MMHUB_SOC_TLB1_9_SET_COHERENCE(mp1_mmhub_soc_tlb1_9_reg, coherence) \
      mp1_mmhub_soc_tlb1_9_reg = (mp1_mmhub_soc_tlb1_9_reg & ~MP1_MMHUB_SOC_TLB1_9_COHERENCE_MASK) | (coherence << MP1_MMHUB_SOC_TLB1_9_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_9_SET_SEG_SIZE(mp1_mmhub_soc_tlb1_9_reg, seg_size) \
      mp1_mmhub_soc_tlb1_9_reg = (mp1_mmhub_soc_tlb1_9_reg & ~MP1_MMHUB_SOC_TLB1_9_SEG_SIZE_MASK) | (seg_size << MP1_MMHUB_SOC_TLB1_9_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_9_SET_SEG_OFFSET(mp1_mmhub_soc_tlb1_9_reg, seg_offset) \
      mp1_mmhub_soc_tlb1_9_reg = (mp1_mmhub_soc_tlb1_9_reg & ~MP1_MMHUB_SOC_TLB1_9_SEG_OFFSET_MASK) | (seg_offset << MP1_MMHUB_SOC_TLB1_9_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_9_t {
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_9_COHERENCE_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_9_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_9_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp1_mmhub_soc_tlb1_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_9_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_9_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_9_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_9_COHERENCE_SIZE;
      } mp1_mmhub_soc_tlb1_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb1_9_t f;
} mp1_mmhub_soc_tlb1_9_u;


/*
 * MP1_MMHUB_SOC_TLB2_9 struct
 */

#define MP1_MMHUB_SOC_TLB2_9_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB2_9_AWUSER_SIZE  32

#define MP1_MMHUB_SOC_TLB2_9_AWUSER_SHIFT  0

#define MP1_MMHUB_SOC_TLB2_9_AWUSER_MASK  0xffffffff

#define MP1_MMHUB_SOC_TLB2_9_MASK \
      (MP1_MMHUB_SOC_TLB2_9_AWUSER_MASK)

#define MP1_MMHUB_SOC_TLB2_9_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB2_9_GET_AWUSER(mp1_mmhub_soc_tlb2_9) \
      ((mp1_mmhub_soc_tlb2_9 & MP1_MMHUB_SOC_TLB2_9_AWUSER_MASK) >> MP1_MMHUB_SOC_TLB2_9_AWUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB2_9_SET_AWUSER(mp1_mmhub_soc_tlb2_9_reg, awuser) \
      mp1_mmhub_soc_tlb2_9_reg = (mp1_mmhub_soc_tlb2_9_reg & ~MP1_MMHUB_SOC_TLB2_9_AWUSER_MASK) | (awuser << MP1_MMHUB_SOC_TLB2_9_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_9_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_9_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_9_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_9_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb2_9_t f;
} mp1_mmhub_soc_tlb2_9_u;


/*
 * MP1_MMHUB_SOC_TLB3_9 struct
 */

#define MP1_MMHUB_SOC_TLB3_9_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB3_9_ARUSER_SIZE  28
#define MP1_MMHUB_SOC_TLB3_9_WUSER_SIZE  3

#define MP1_MMHUB_SOC_TLB3_9_ARUSER_SHIFT  0
#define MP1_MMHUB_SOC_TLB3_9_WUSER_SHIFT  28

#define MP1_MMHUB_SOC_TLB3_9_ARUSER_MASK  0x0fffffff
#define MP1_MMHUB_SOC_TLB3_9_WUSER_MASK  0x70000000

#define MP1_MMHUB_SOC_TLB3_9_MASK \
      (MP1_MMHUB_SOC_TLB3_9_ARUSER_MASK | \
      MP1_MMHUB_SOC_TLB3_9_WUSER_MASK)

#define MP1_MMHUB_SOC_TLB3_9_DEFAULT   0x00000000

#define MP1_MMHUB_SOC_TLB3_9_GET_ARUSER(mp1_mmhub_soc_tlb3_9) \
      ((mp1_mmhub_soc_tlb3_9 & MP1_MMHUB_SOC_TLB3_9_ARUSER_MASK) >> MP1_MMHUB_SOC_TLB3_9_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_9_GET_WUSER(mp1_mmhub_soc_tlb3_9) \
      ((mp1_mmhub_soc_tlb3_9 & MP1_MMHUB_SOC_TLB3_9_WUSER_MASK) >> MP1_MMHUB_SOC_TLB3_9_WUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB3_9_SET_ARUSER(mp1_mmhub_soc_tlb3_9_reg, aruser) \
      mp1_mmhub_soc_tlb3_9_reg = (mp1_mmhub_soc_tlb3_9_reg & ~MP1_MMHUB_SOC_TLB3_9_ARUSER_MASK) | (aruser << MP1_MMHUB_SOC_TLB3_9_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_9_SET_WUSER(mp1_mmhub_soc_tlb3_9_reg, wuser) \
      mp1_mmhub_soc_tlb3_9_reg = (mp1_mmhub_soc_tlb3_9_reg & ~MP1_MMHUB_SOC_TLB3_9_WUSER_MASK) | (wuser << MP1_MMHUB_SOC_TLB3_9_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_9_t {
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_9_ARUSER_SIZE;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_9_WUSER_SIZE;
            unsigned int                                : 1;
      } mp1_mmhub_soc_tlb3_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_9_t {
            unsigned int                                : 1;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_9_WUSER_SIZE;
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_9_ARUSER_SIZE;
      } mp1_mmhub_soc_tlb3_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb3_9_t f;
} mp1_mmhub_soc_tlb3_9_u;


/*
 * MP1_MMHUB_SOC_TLB0_10 struct
 */

#define MP1_MMHUB_SOC_TLB0_10_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB0_10_SOC_ADDR_SIZE  22

#define MP1_MMHUB_SOC_TLB0_10_SOC_ADDR_SHIFT  0

#define MP1_MMHUB_SOC_TLB0_10_SOC_ADDR_MASK  0x003fffff

#define MP1_MMHUB_SOC_TLB0_10_MASK \
      (MP1_MMHUB_SOC_TLB0_10_SOC_ADDR_MASK)

#define MP1_MMHUB_SOC_TLB0_10_DEFAULT  0x00000000

#define MP1_MMHUB_SOC_TLB0_10_GET_SOC_ADDR(mp1_mmhub_soc_tlb0_10) \
      ((mp1_mmhub_soc_tlb0_10 & MP1_MMHUB_SOC_TLB0_10_SOC_ADDR_MASK) >> MP1_MMHUB_SOC_TLB0_10_SOC_ADDR_SHIFT)

#define MP1_MMHUB_SOC_TLB0_10_SET_SOC_ADDR(mp1_mmhub_soc_tlb0_10_reg, soc_addr) \
      mp1_mmhub_soc_tlb0_10_reg = (mp1_mmhub_soc_tlb0_10_reg & ~MP1_MMHUB_SOC_TLB0_10_SOC_ADDR_MASK) | (soc_addr << MP1_MMHUB_SOC_TLB0_10_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_10_t {
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_10_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp1_mmhub_soc_tlb0_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_10_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_10_SOC_ADDR_SIZE;
      } mp1_mmhub_soc_tlb0_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb0_10_t f;
} mp1_mmhub_soc_tlb0_10_u;


/*
 * MP1_MMHUB_SOC_TLB1_10 struct
 */

#define MP1_MMHUB_SOC_TLB1_10_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB1_10_COHERENCE_SIZE  1
#define MP1_MMHUB_SOC_TLB1_10_SEG_SIZE_SIZE  4
#define MP1_MMHUB_SOC_TLB1_10_SEG_OFFSET_SIZE  9

#define MP1_MMHUB_SOC_TLB1_10_COHERENCE_SHIFT  0
#define MP1_MMHUB_SOC_TLB1_10_SEG_SIZE_SHIFT  1
#define MP1_MMHUB_SOC_TLB1_10_SEG_OFFSET_SHIFT  5

#define MP1_MMHUB_SOC_TLB1_10_COHERENCE_MASK  0x00000001
#define MP1_MMHUB_SOC_TLB1_10_SEG_SIZE_MASK  0x0000001e
#define MP1_MMHUB_SOC_TLB1_10_SEG_OFFSET_MASK  0x00003fe0

#define MP1_MMHUB_SOC_TLB1_10_MASK \
      (MP1_MMHUB_SOC_TLB1_10_COHERENCE_MASK | \
      MP1_MMHUB_SOC_TLB1_10_SEG_SIZE_MASK | \
      MP1_MMHUB_SOC_TLB1_10_SEG_OFFSET_MASK)

#define MP1_MMHUB_SOC_TLB1_10_DEFAULT  0x00000000

#define MP1_MMHUB_SOC_TLB1_10_GET_COHERENCE(mp1_mmhub_soc_tlb1_10) \
      ((mp1_mmhub_soc_tlb1_10 & MP1_MMHUB_SOC_TLB1_10_COHERENCE_MASK) >> MP1_MMHUB_SOC_TLB1_10_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_10_GET_SEG_SIZE(mp1_mmhub_soc_tlb1_10) \
      ((mp1_mmhub_soc_tlb1_10 & MP1_MMHUB_SOC_TLB1_10_SEG_SIZE_MASK) >> MP1_MMHUB_SOC_TLB1_10_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_10_GET_SEG_OFFSET(mp1_mmhub_soc_tlb1_10) \
      ((mp1_mmhub_soc_tlb1_10 & MP1_MMHUB_SOC_TLB1_10_SEG_OFFSET_MASK) >> MP1_MMHUB_SOC_TLB1_10_SEG_OFFSET_SHIFT)

#define MP1_MMHUB_SOC_TLB1_10_SET_COHERENCE(mp1_mmhub_soc_tlb1_10_reg, coherence) \
      mp1_mmhub_soc_tlb1_10_reg = (mp1_mmhub_soc_tlb1_10_reg & ~MP1_MMHUB_SOC_TLB1_10_COHERENCE_MASK) | (coherence << MP1_MMHUB_SOC_TLB1_10_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_10_SET_SEG_SIZE(mp1_mmhub_soc_tlb1_10_reg, seg_size) \
      mp1_mmhub_soc_tlb1_10_reg = (mp1_mmhub_soc_tlb1_10_reg & ~MP1_MMHUB_SOC_TLB1_10_SEG_SIZE_MASK) | (seg_size << MP1_MMHUB_SOC_TLB1_10_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_10_SET_SEG_OFFSET(mp1_mmhub_soc_tlb1_10_reg, seg_offset) \
      mp1_mmhub_soc_tlb1_10_reg = (mp1_mmhub_soc_tlb1_10_reg & ~MP1_MMHUB_SOC_TLB1_10_SEG_OFFSET_MASK) | (seg_offset << MP1_MMHUB_SOC_TLB1_10_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_10_t {
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_10_COHERENCE_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_10_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_10_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp1_mmhub_soc_tlb1_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_10_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_10_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_10_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_10_COHERENCE_SIZE;
      } mp1_mmhub_soc_tlb1_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb1_10_t f;
} mp1_mmhub_soc_tlb1_10_u;


/*
 * MP1_MMHUB_SOC_TLB2_10 struct
 */

#define MP1_MMHUB_SOC_TLB2_10_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB2_10_AWUSER_SIZE  32

#define MP1_MMHUB_SOC_TLB2_10_AWUSER_SHIFT  0

#define MP1_MMHUB_SOC_TLB2_10_AWUSER_MASK  0xffffffff

#define MP1_MMHUB_SOC_TLB2_10_MASK \
      (MP1_MMHUB_SOC_TLB2_10_AWUSER_MASK)

#define MP1_MMHUB_SOC_TLB2_10_DEFAULT  0x00000000

#define MP1_MMHUB_SOC_TLB2_10_GET_AWUSER(mp1_mmhub_soc_tlb2_10) \
      ((mp1_mmhub_soc_tlb2_10 & MP1_MMHUB_SOC_TLB2_10_AWUSER_MASK) >> MP1_MMHUB_SOC_TLB2_10_AWUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB2_10_SET_AWUSER(mp1_mmhub_soc_tlb2_10_reg, awuser) \
      mp1_mmhub_soc_tlb2_10_reg = (mp1_mmhub_soc_tlb2_10_reg & ~MP1_MMHUB_SOC_TLB2_10_AWUSER_MASK) | (awuser << MP1_MMHUB_SOC_TLB2_10_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_10_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_10_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_10_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_10_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb2_10_t f;
} mp1_mmhub_soc_tlb2_10_u;


/*
 * MP1_MMHUB_SOC_TLB3_10 struct
 */

#define MP1_MMHUB_SOC_TLB3_10_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB3_10_ARUSER_SIZE  28
#define MP1_MMHUB_SOC_TLB3_10_WUSER_SIZE  3

#define MP1_MMHUB_SOC_TLB3_10_ARUSER_SHIFT  0
#define MP1_MMHUB_SOC_TLB3_10_WUSER_SHIFT  28

#define MP1_MMHUB_SOC_TLB3_10_ARUSER_MASK  0x0fffffff
#define MP1_MMHUB_SOC_TLB3_10_WUSER_MASK  0x70000000

#define MP1_MMHUB_SOC_TLB3_10_MASK \
      (MP1_MMHUB_SOC_TLB3_10_ARUSER_MASK | \
      MP1_MMHUB_SOC_TLB3_10_WUSER_MASK)

#define MP1_MMHUB_SOC_TLB3_10_DEFAULT  0x00000000

#define MP1_MMHUB_SOC_TLB3_10_GET_ARUSER(mp1_mmhub_soc_tlb3_10) \
      ((mp1_mmhub_soc_tlb3_10 & MP1_MMHUB_SOC_TLB3_10_ARUSER_MASK) >> MP1_MMHUB_SOC_TLB3_10_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_10_GET_WUSER(mp1_mmhub_soc_tlb3_10) \
      ((mp1_mmhub_soc_tlb3_10 & MP1_MMHUB_SOC_TLB3_10_WUSER_MASK) >> MP1_MMHUB_SOC_TLB3_10_WUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB3_10_SET_ARUSER(mp1_mmhub_soc_tlb3_10_reg, aruser) \
      mp1_mmhub_soc_tlb3_10_reg = (mp1_mmhub_soc_tlb3_10_reg & ~MP1_MMHUB_SOC_TLB3_10_ARUSER_MASK) | (aruser << MP1_MMHUB_SOC_TLB3_10_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_10_SET_WUSER(mp1_mmhub_soc_tlb3_10_reg, wuser) \
      mp1_mmhub_soc_tlb3_10_reg = (mp1_mmhub_soc_tlb3_10_reg & ~MP1_MMHUB_SOC_TLB3_10_WUSER_MASK) | (wuser << MP1_MMHUB_SOC_TLB3_10_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_10_t {
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_10_ARUSER_SIZE;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_10_WUSER_SIZE;
            unsigned int                                : 1;
      } mp1_mmhub_soc_tlb3_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_10_t {
            unsigned int                                : 1;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_10_WUSER_SIZE;
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_10_ARUSER_SIZE;
      } mp1_mmhub_soc_tlb3_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb3_10_t f;
} mp1_mmhub_soc_tlb3_10_u;


/*
 * MP1_MMHUB_SOC_TLB0_11 struct
 */

#define MP1_MMHUB_SOC_TLB0_11_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB0_11_SOC_ADDR_SIZE  22

#define MP1_MMHUB_SOC_TLB0_11_SOC_ADDR_SHIFT  0

#define MP1_MMHUB_SOC_TLB0_11_SOC_ADDR_MASK  0x003fffff

#define MP1_MMHUB_SOC_TLB0_11_MASK \
      (MP1_MMHUB_SOC_TLB0_11_SOC_ADDR_MASK)

#define MP1_MMHUB_SOC_TLB0_11_DEFAULT  0x00000000

#define MP1_MMHUB_SOC_TLB0_11_GET_SOC_ADDR(mp1_mmhub_soc_tlb0_11) \
      ((mp1_mmhub_soc_tlb0_11 & MP1_MMHUB_SOC_TLB0_11_SOC_ADDR_MASK) >> MP1_MMHUB_SOC_TLB0_11_SOC_ADDR_SHIFT)

#define MP1_MMHUB_SOC_TLB0_11_SET_SOC_ADDR(mp1_mmhub_soc_tlb0_11_reg, soc_addr) \
      mp1_mmhub_soc_tlb0_11_reg = (mp1_mmhub_soc_tlb0_11_reg & ~MP1_MMHUB_SOC_TLB0_11_SOC_ADDR_MASK) | (soc_addr << MP1_MMHUB_SOC_TLB0_11_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_11_t {
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_11_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp1_mmhub_soc_tlb0_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_11_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_11_SOC_ADDR_SIZE;
      } mp1_mmhub_soc_tlb0_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb0_11_t f;
} mp1_mmhub_soc_tlb0_11_u;


/*
 * MP1_MMHUB_SOC_TLB1_11 struct
 */

#define MP1_MMHUB_SOC_TLB1_11_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB1_11_COHERENCE_SIZE  1
#define MP1_MMHUB_SOC_TLB1_11_SEG_SIZE_SIZE  4
#define MP1_MMHUB_SOC_TLB1_11_SEG_OFFSET_SIZE  9

#define MP1_MMHUB_SOC_TLB1_11_COHERENCE_SHIFT  0
#define MP1_MMHUB_SOC_TLB1_11_SEG_SIZE_SHIFT  1
#define MP1_MMHUB_SOC_TLB1_11_SEG_OFFSET_SHIFT  5

#define MP1_MMHUB_SOC_TLB1_11_COHERENCE_MASK  0x00000001
#define MP1_MMHUB_SOC_TLB1_11_SEG_SIZE_MASK  0x0000001e
#define MP1_MMHUB_SOC_TLB1_11_SEG_OFFSET_MASK  0x00003fe0

#define MP1_MMHUB_SOC_TLB1_11_MASK \
      (MP1_MMHUB_SOC_TLB1_11_COHERENCE_MASK | \
      MP1_MMHUB_SOC_TLB1_11_SEG_SIZE_MASK | \
      MP1_MMHUB_SOC_TLB1_11_SEG_OFFSET_MASK)

#define MP1_MMHUB_SOC_TLB1_11_DEFAULT  0x00000000

#define MP1_MMHUB_SOC_TLB1_11_GET_COHERENCE(mp1_mmhub_soc_tlb1_11) \
      ((mp1_mmhub_soc_tlb1_11 & MP1_MMHUB_SOC_TLB1_11_COHERENCE_MASK) >> MP1_MMHUB_SOC_TLB1_11_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_11_GET_SEG_SIZE(mp1_mmhub_soc_tlb1_11) \
      ((mp1_mmhub_soc_tlb1_11 & MP1_MMHUB_SOC_TLB1_11_SEG_SIZE_MASK) >> MP1_MMHUB_SOC_TLB1_11_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_11_GET_SEG_OFFSET(mp1_mmhub_soc_tlb1_11) \
      ((mp1_mmhub_soc_tlb1_11 & MP1_MMHUB_SOC_TLB1_11_SEG_OFFSET_MASK) >> MP1_MMHUB_SOC_TLB1_11_SEG_OFFSET_SHIFT)

#define MP1_MMHUB_SOC_TLB1_11_SET_COHERENCE(mp1_mmhub_soc_tlb1_11_reg, coherence) \
      mp1_mmhub_soc_tlb1_11_reg = (mp1_mmhub_soc_tlb1_11_reg & ~MP1_MMHUB_SOC_TLB1_11_COHERENCE_MASK) | (coherence << MP1_MMHUB_SOC_TLB1_11_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_11_SET_SEG_SIZE(mp1_mmhub_soc_tlb1_11_reg, seg_size) \
      mp1_mmhub_soc_tlb1_11_reg = (mp1_mmhub_soc_tlb1_11_reg & ~MP1_MMHUB_SOC_TLB1_11_SEG_SIZE_MASK) | (seg_size << MP1_MMHUB_SOC_TLB1_11_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_11_SET_SEG_OFFSET(mp1_mmhub_soc_tlb1_11_reg, seg_offset) \
      mp1_mmhub_soc_tlb1_11_reg = (mp1_mmhub_soc_tlb1_11_reg & ~MP1_MMHUB_SOC_TLB1_11_SEG_OFFSET_MASK) | (seg_offset << MP1_MMHUB_SOC_TLB1_11_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_11_t {
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_11_COHERENCE_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_11_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_11_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp1_mmhub_soc_tlb1_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_11_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_11_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_11_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_11_COHERENCE_SIZE;
      } mp1_mmhub_soc_tlb1_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb1_11_t f;
} mp1_mmhub_soc_tlb1_11_u;


/*
 * MP1_MMHUB_SOC_TLB2_11 struct
 */

#define MP1_MMHUB_SOC_TLB2_11_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB2_11_AWUSER_SIZE  32

#define MP1_MMHUB_SOC_TLB2_11_AWUSER_SHIFT  0

#define MP1_MMHUB_SOC_TLB2_11_AWUSER_MASK  0xffffffff

#define MP1_MMHUB_SOC_TLB2_11_MASK \
      (MP1_MMHUB_SOC_TLB2_11_AWUSER_MASK)

#define MP1_MMHUB_SOC_TLB2_11_DEFAULT  0x00000000

#define MP1_MMHUB_SOC_TLB2_11_GET_AWUSER(mp1_mmhub_soc_tlb2_11) \
      ((mp1_mmhub_soc_tlb2_11 & MP1_MMHUB_SOC_TLB2_11_AWUSER_MASK) >> MP1_MMHUB_SOC_TLB2_11_AWUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB2_11_SET_AWUSER(mp1_mmhub_soc_tlb2_11_reg, awuser) \
      mp1_mmhub_soc_tlb2_11_reg = (mp1_mmhub_soc_tlb2_11_reg & ~MP1_MMHUB_SOC_TLB2_11_AWUSER_MASK) | (awuser << MP1_MMHUB_SOC_TLB2_11_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_11_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_11_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_11_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_11_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb2_11_t f;
} mp1_mmhub_soc_tlb2_11_u;


/*
 * MP1_MMHUB_SOC_TLB3_11 struct
 */

#define MP1_MMHUB_SOC_TLB3_11_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB3_11_ARUSER_SIZE  28
#define MP1_MMHUB_SOC_TLB3_11_WUSER_SIZE  3

#define MP1_MMHUB_SOC_TLB3_11_ARUSER_SHIFT  0
#define MP1_MMHUB_SOC_TLB3_11_WUSER_SHIFT  28

#define MP1_MMHUB_SOC_TLB3_11_ARUSER_MASK  0x0fffffff
#define MP1_MMHUB_SOC_TLB3_11_WUSER_MASK  0x70000000

#define MP1_MMHUB_SOC_TLB3_11_MASK \
      (MP1_MMHUB_SOC_TLB3_11_ARUSER_MASK | \
      MP1_MMHUB_SOC_TLB3_11_WUSER_MASK)

#define MP1_MMHUB_SOC_TLB3_11_DEFAULT  0x00000000

#define MP1_MMHUB_SOC_TLB3_11_GET_ARUSER(mp1_mmhub_soc_tlb3_11) \
      ((mp1_mmhub_soc_tlb3_11 & MP1_MMHUB_SOC_TLB3_11_ARUSER_MASK) >> MP1_MMHUB_SOC_TLB3_11_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_11_GET_WUSER(mp1_mmhub_soc_tlb3_11) \
      ((mp1_mmhub_soc_tlb3_11 & MP1_MMHUB_SOC_TLB3_11_WUSER_MASK) >> MP1_MMHUB_SOC_TLB3_11_WUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB3_11_SET_ARUSER(mp1_mmhub_soc_tlb3_11_reg, aruser) \
      mp1_mmhub_soc_tlb3_11_reg = (mp1_mmhub_soc_tlb3_11_reg & ~MP1_MMHUB_SOC_TLB3_11_ARUSER_MASK) | (aruser << MP1_MMHUB_SOC_TLB3_11_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_11_SET_WUSER(mp1_mmhub_soc_tlb3_11_reg, wuser) \
      mp1_mmhub_soc_tlb3_11_reg = (mp1_mmhub_soc_tlb3_11_reg & ~MP1_MMHUB_SOC_TLB3_11_WUSER_MASK) | (wuser << MP1_MMHUB_SOC_TLB3_11_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_11_t {
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_11_ARUSER_SIZE;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_11_WUSER_SIZE;
            unsigned int                                : 1;
      } mp1_mmhub_soc_tlb3_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_11_t {
            unsigned int                                : 1;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_11_WUSER_SIZE;
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_11_ARUSER_SIZE;
      } mp1_mmhub_soc_tlb3_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb3_11_t f;
} mp1_mmhub_soc_tlb3_11_u;


/*
 * MP1_MMHUB_SOC_TLB0_12 struct
 */

#define MP1_MMHUB_SOC_TLB0_12_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB0_12_SOC_ADDR_SIZE  22

#define MP1_MMHUB_SOC_TLB0_12_SOC_ADDR_SHIFT  0

#define MP1_MMHUB_SOC_TLB0_12_SOC_ADDR_MASK  0x003fffff

#define MP1_MMHUB_SOC_TLB0_12_MASK \
      (MP1_MMHUB_SOC_TLB0_12_SOC_ADDR_MASK)

#define MP1_MMHUB_SOC_TLB0_12_DEFAULT  0x00000000

#define MP1_MMHUB_SOC_TLB0_12_GET_SOC_ADDR(mp1_mmhub_soc_tlb0_12) \
      ((mp1_mmhub_soc_tlb0_12 & MP1_MMHUB_SOC_TLB0_12_SOC_ADDR_MASK) >> MP1_MMHUB_SOC_TLB0_12_SOC_ADDR_SHIFT)

#define MP1_MMHUB_SOC_TLB0_12_SET_SOC_ADDR(mp1_mmhub_soc_tlb0_12_reg, soc_addr) \
      mp1_mmhub_soc_tlb0_12_reg = (mp1_mmhub_soc_tlb0_12_reg & ~MP1_MMHUB_SOC_TLB0_12_SOC_ADDR_MASK) | (soc_addr << MP1_MMHUB_SOC_TLB0_12_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_12_t {
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_12_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp1_mmhub_soc_tlb0_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_12_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_12_SOC_ADDR_SIZE;
      } mp1_mmhub_soc_tlb0_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb0_12_t f;
} mp1_mmhub_soc_tlb0_12_u;


/*
 * MP1_MMHUB_SOC_TLB1_12 struct
 */

#define MP1_MMHUB_SOC_TLB1_12_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB1_12_COHERENCE_SIZE  1
#define MP1_MMHUB_SOC_TLB1_12_SEG_SIZE_SIZE  4
#define MP1_MMHUB_SOC_TLB1_12_SEG_OFFSET_SIZE  9

#define MP1_MMHUB_SOC_TLB1_12_COHERENCE_SHIFT  0
#define MP1_MMHUB_SOC_TLB1_12_SEG_SIZE_SHIFT  1
#define MP1_MMHUB_SOC_TLB1_12_SEG_OFFSET_SHIFT  5

#define MP1_MMHUB_SOC_TLB1_12_COHERENCE_MASK  0x00000001
#define MP1_MMHUB_SOC_TLB1_12_SEG_SIZE_MASK  0x0000001e
#define MP1_MMHUB_SOC_TLB1_12_SEG_OFFSET_MASK  0x00003fe0

#define MP1_MMHUB_SOC_TLB1_12_MASK \
      (MP1_MMHUB_SOC_TLB1_12_COHERENCE_MASK | \
      MP1_MMHUB_SOC_TLB1_12_SEG_SIZE_MASK | \
      MP1_MMHUB_SOC_TLB1_12_SEG_OFFSET_MASK)

#define MP1_MMHUB_SOC_TLB1_12_DEFAULT  0x00000000

#define MP1_MMHUB_SOC_TLB1_12_GET_COHERENCE(mp1_mmhub_soc_tlb1_12) \
      ((mp1_mmhub_soc_tlb1_12 & MP1_MMHUB_SOC_TLB1_12_COHERENCE_MASK) >> MP1_MMHUB_SOC_TLB1_12_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_12_GET_SEG_SIZE(mp1_mmhub_soc_tlb1_12) \
      ((mp1_mmhub_soc_tlb1_12 & MP1_MMHUB_SOC_TLB1_12_SEG_SIZE_MASK) >> MP1_MMHUB_SOC_TLB1_12_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_12_GET_SEG_OFFSET(mp1_mmhub_soc_tlb1_12) \
      ((mp1_mmhub_soc_tlb1_12 & MP1_MMHUB_SOC_TLB1_12_SEG_OFFSET_MASK) >> MP1_MMHUB_SOC_TLB1_12_SEG_OFFSET_SHIFT)

#define MP1_MMHUB_SOC_TLB1_12_SET_COHERENCE(mp1_mmhub_soc_tlb1_12_reg, coherence) \
      mp1_mmhub_soc_tlb1_12_reg = (mp1_mmhub_soc_tlb1_12_reg & ~MP1_MMHUB_SOC_TLB1_12_COHERENCE_MASK) | (coherence << MP1_MMHUB_SOC_TLB1_12_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_12_SET_SEG_SIZE(mp1_mmhub_soc_tlb1_12_reg, seg_size) \
      mp1_mmhub_soc_tlb1_12_reg = (mp1_mmhub_soc_tlb1_12_reg & ~MP1_MMHUB_SOC_TLB1_12_SEG_SIZE_MASK) | (seg_size << MP1_MMHUB_SOC_TLB1_12_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_12_SET_SEG_OFFSET(mp1_mmhub_soc_tlb1_12_reg, seg_offset) \
      mp1_mmhub_soc_tlb1_12_reg = (mp1_mmhub_soc_tlb1_12_reg & ~MP1_MMHUB_SOC_TLB1_12_SEG_OFFSET_MASK) | (seg_offset << MP1_MMHUB_SOC_TLB1_12_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_12_t {
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_12_COHERENCE_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_12_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_12_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp1_mmhub_soc_tlb1_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_12_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_12_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_12_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_12_COHERENCE_SIZE;
      } mp1_mmhub_soc_tlb1_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb1_12_t f;
} mp1_mmhub_soc_tlb1_12_u;


/*
 * MP1_MMHUB_SOC_TLB2_12 struct
 */

#define MP1_MMHUB_SOC_TLB2_12_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB2_12_AWUSER_SIZE  32

#define MP1_MMHUB_SOC_TLB2_12_AWUSER_SHIFT  0

#define MP1_MMHUB_SOC_TLB2_12_AWUSER_MASK  0xffffffff

#define MP1_MMHUB_SOC_TLB2_12_MASK \
      (MP1_MMHUB_SOC_TLB2_12_AWUSER_MASK)

#define MP1_MMHUB_SOC_TLB2_12_DEFAULT  0x00000000

#define MP1_MMHUB_SOC_TLB2_12_GET_AWUSER(mp1_mmhub_soc_tlb2_12) \
      ((mp1_mmhub_soc_tlb2_12 & MP1_MMHUB_SOC_TLB2_12_AWUSER_MASK) >> MP1_MMHUB_SOC_TLB2_12_AWUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB2_12_SET_AWUSER(mp1_mmhub_soc_tlb2_12_reg, awuser) \
      mp1_mmhub_soc_tlb2_12_reg = (mp1_mmhub_soc_tlb2_12_reg & ~MP1_MMHUB_SOC_TLB2_12_AWUSER_MASK) | (awuser << MP1_MMHUB_SOC_TLB2_12_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_12_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_12_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_12_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_12_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb2_12_t f;
} mp1_mmhub_soc_tlb2_12_u;


/*
 * MP1_MMHUB_SOC_TLB3_12 struct
 */

#define MP1_MMHUB_SOC_TLB3_12_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB3_12_ARUSER_SIZE  28
#define MP1_MMHUB_SOC_TLB3_12_WUSER_SIZE  3

#define MP1_MMHUB_SOC_TLB3_12_ARUSER_SHIFT  0
#define MP1_MMHUB_SOC_TLB3_12_WUSER_SHIFT  28

#define MP1_MMHUB_SOC_TLB3_12_ARUSER_MASK  0x0fffffff
#define MP1_MMHUB_SOC_TLB3_12_WUSER_MASK  0x70000000

#define MP1_MMHUB_SOC_TLB3_12_MASK \
      (MP1_MMHUB_SOC_TLB3_12_ARUSER_MASK | \
      MP1_MMHUB_SOC_TLB3_12_WUSER_MASK)

#define MP1_MMHUB_SOC_TLB3_12_DEFAULT  0x00000000

#define MP1_MMHUB_SOC_TLB3_12_GET_ARUSER(mp1_mmhub_soc_tlb3_12) \
      ((mp1_mmhub_soc_tlb3_12 & MP1_MMHUB_SOC_TLB3_12_ARUSER_MASK) >> MP1_MMHUB_SOC_TLB3_12_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_12_GET_WUSER(mp1_mmhub_soc_tlb3_12) \
      ((mp1_mmhub_soc_tlb3_12 & MP1_MMHUB_SOC_TLB3_12_WUSER_MASK) >> MP1_MMHUB_SOC_TLB3_12_WUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB3_12_SET_ARUSER(mp1_mmhub_soc_tlb3_12_reg, aruser) \
      mp1_mmhub_soc_tlb3_12_reg = (mp1_mmhub_soc_tlb3_12_reg & ~MP1_MMHUB_SOC_TLB3_12_ARUSER_MASK) | (aruser << MP1_MMHUB_SOC_TLB3_12_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_12_SET_WUSER(mp1_mmhub_soc_tlb3_12_reg, wuser) \
      mp1_mmhub_soc_tlb3_12_reg = (mp1_mmhub_soc_tlb3_12_reg & ~MP1_MMHUB_SOC_TLB3_12_WUSER_MASK) | (wuser << MP1_MMHUB_SOC_TLB3_12_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_12_t {
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_12_ARUSER_SIZE;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_12_WUSER_SIZE;
            unsigned int                                : 1;
      } mp1_mmhub_soc_tlb3_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_12_t {
            unsigned int                                : 1;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_12_WUSER_SIZE;
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_12_ARUSER_SIZE;
      } mp1_mmhub_soc_tlb3_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb3_12_t f;
} mp1_mmhub_soc_tlb3_12_u;


/*
 * MP1_MMHUB_SOC_TLB0_13 struct
 */

#define MP1_MMHUB_SOC_TLB0_13_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB0_13_SOC_ADDR_SIZE  22

#define MP1_MMHUB_SOC_TLB0_13_SOC_ADDR_SHIFT  0

#define MP1_MMHUB_SOC_TLB0_13_SOC_ADDR_MASK  0x003fffff

#define MP1_MMHUB_SOC_TLB0_13_MASK \
      (MP1_MMHUB_SOC_TLB0_13_SOC_ADDR_MASK)

#define MP1_MMHUB_SOC_TLB0_13_DEFAULT  0x00000000

#define MP1_MMHUB_SOC_TLB0_13_GET_SOC_ADDR(mp1_mmhub_soc_tlb0_13) \
      ((mp1_mmhub_soc_tlb0_13 & MP1_MMHUB_SOC_TLB0_13_SOC_ADDR_MASK) >> MP1_MMHUB_SOC_TLB0_13_SOC_ADDR_SHIFT)

#define MP1_MMHUB_SOC_TLB0_13_SET_SOC_ADDR(mp1_mmhub_soc_tlb0_13_reg, soc_addr) \
      mp1_mmhub_soc_tlb0_13_reg = (mp1_mmhub_soc_tlb0_13_reg & ~MP1_MMHUB_SOC_TLB0_13_SOC_ADDR_MASK) | (soc_addr << MP1_MMHUB_SOC_TLB0_13_SOC_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_13_t {
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_13_SOC_ADDR_SIZE;
            unsigned int                                : 10;
      } mp1_mmhub_soc_tlb0_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb0_13_t {
            unsigned int                                : 10;
            unsigned int soc_addr                       : MP1_MMHUB_SOC_TLB0_13_SOC_ADDR_SIZE;
      } mp1_mmhub_soc_tlb0_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb0_13_t f;
} mp1_mmhub_soc_tlb0_13_u;


/*
 * MP1_MMHUB_SOC_TLB1_13 struct
 */

#define MP1_MMHUB_SOC_TLB1_13_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB1_13_COHERENCE_SIZE  1
#define MP1_MMHUB_SOC_TLB1_13_SEG_SIZE_SIZE  4
#define MP1_MMHUB_SOC_TLB1_13_SEG_OFFSET_SIZE  9

#define MP1_MMHUB_SOC_TLB1_13_COHERENCE_SHIFT  0
#define MP1_MMHUB_SOC_TLB1_13_SEG_SIZE_SHIFT  1
#define MP1_MMHUB_SOC_TLB1_13_SEG_OFFSET_SHIFT  5

#define MP1_MMHUB_SOC_TLB1_13_COHERENCE_MASK  0x00000001
#define MP1_MMHUB_SOC_TLB1_13_SEG_SIZE_MASK  0x0000001e
#define MP1_MMHUB_SOC_TLB1_13_SEG_OFFSET_MASK  0x00003fe0

#define MP1_MMHUB_SOC_TLB1_13_MASK \
      (MP1_MMHUB_SOC_TLB1_13_COHERENCE_MASK | \
      MP1_MMHUB_SOC_TLB1_13_SEG_SIZE_MASK | \
      MP1_MMHUB_SOC_TLB1_13_SEG_OFFSET_MASK)

#define MP1_MMHUB_SOC_TLB1_13_DEFAULT  0x00000000

#define MP1_MMHUB_SOC_TLB1_13_GET_COHERENCE(mp1_mmhub_soc_tlb1_13) \
      ((mp1_mmhub_soc_tlb1_13 & MP1_MMHUB_SOC_TLB1_13_COHERENCE_MASK) >> MP1_MMHUB_SOC_TLB1_13_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_13_GET_SEG_SIZE(mp1_mmhub_soc_tlb1_13) \
      ((mp1_mmhub_soc_tlb1_13 & MP1_MMHUB_SOC_TLB1_13_SEG_SIZE_MASK) >> MP1_MMHUB_SOC_TLB1_13_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_13_GET_SEG_OFFSET(mp1_mmhub_soc_tlb1_13) \
      ((mp1_mmhub_soc_tlb1_13 & MP1_MMHUB_SOC_TLB1_13_SEG_OFFSET_MASK) >> MP1_MMHUB_SOC_TLB1_13_SEG_OFFSET_SHIFT)

#define MP1_MMHUB_SOC_TLB1_13_SET_COHERENCE(mp1_mmhub_soc_tlb1_13_reg, coherence) \
      mp1_mmhub_soc_tlb1_13_reg = (mp1_mmhub_soc_tlb1_13_reg & ~MP1_MMHUB_SOC_TLB1_13_COHERENCE_MASK) | (coherence << MP1_MMHUB_SOC_TLB1_13_COHERENCE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_13_SET_SEG_SIZE(mp1_mmhub_soc_tlb1_13_reg, seg_size) \
      mp1_mmhub_soc_tlb1_13_reg = (mp1_mmhub_soc_tlb1_13_reg & ~MP1_MMHUB_SOC_TLB1_13_SEG_SIZE_MASK) | (seg_size << MP1_MMHUB_SOC_TLB1_13_SEG_SIZE_SHIFT)
#define MP1_MMHUB_SOC_TLB1_13_SET_SEG_OFFSET(mp1_mmhub_soc_tlb1_13_reg, seg_offset) \
      mp1_mmhub_soc_tlb1_13_reg = (mp1_mmhub_soc_tlb1_13_reg & ~MP1_MMHUB_SOC_TLB1_13_SEG_OFFSET_MASK) | (seg_offset << MP1_MMHUB_SOC_TLB1_13_SEG_OFFSET_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_13_t {
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_13_COHERENCE_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_13_SEG_SIZE_SIZE;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_13_SEG_OFFSET_SIZE;
            unsigned int                                : 18;
      } mp1_mmhub_soc_tlb1_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb1_13_t {
            unsigned int                                : 18;
            unsigned int seg_offset                     : MP1_MMHUB_SOC_TLB1_13_SEG_OFFSET_SIZE;
            unsigned int seg_size                       : MP1_MMHUB_SOC_TLB1_13_SEG_SIZE_SIZE;
            unsigned int coherence                      : MP1_MMHUB_SOC_TLB1_13_COHERENCE_SIZE;
      } mp1_mmhub_soc_tlb1_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb1_13_t f;
} mp1_mmhub_soc_tlb1_13_u;


/*
 * MP1_MMHUB_SOC_TLB2_13 struct
 */

#define MP1_MMHUB_SOC_TLB2_13_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB2_13_AWUSER_SIZE  32

#define MP1_MMHUB_SOC_TLB2_13_AWUSER_SHIFT  0

#define MP1_MMHUB_SOC_TLB2_13_AWUSER_MASK  0xffffffff

#define MP1_MMHUB_SOC_TLB2_13_MASK \
      (MP1_MMHUB_SOC_TLB2_13_AWUSER_MASK)

#define MP1_MMHUB_SOC_TLB2_13_DEFAULT  0x00000000

#define MP1_MMHUB_SOC_TLB2_13_GET_AWUSER(mp1_mmhub_soc_tlb2_13) \
      ((mp1_mmhub_soc_tlb2_13 & MP1_MMHUB_SOC_TLB2_13_AWUSER_MASK) >> MP1_MMHUB_SOC_TLB2_13_AWUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB2_13_SET_AWUSER(mp1_mmhub_soc_tlb2_13_reg, awuser) \
      mp1_mmhub_soc_tlb2_13_reg = (mp1_mmhub_soc_tlb2_13_reg & ~MP1_MMHUB_SOC_TLB2_13_AWUSER_MASK) | (awuser << MP1_MMHUB_SOC_TLB2_13_AWUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_13_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_13_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb2_13_t {
            unsigned int awuser                         : MP1_MMHUB_SOC_TLB2_13_AWUSER_SIZE;
      } mp1_mmhub_soc_tlb2_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb2_13_t f;
} mp1_mmhub_soc_tlb2_13_u;


/*
 * MP1_MMHUB_SOC_TLB3_13 struct
 */

#define MP1_MMHUB_SOC_TLB3_13_REG_SIZE         32
#define MP1_MMHUB_SOC_TLB3_13_ARUSER_SIZE  28
#define MP1_MMHUB_SOC_TLB3_13_WUSER_SIZE  3

#define MP1_MMHUB_SOC_TLB3_13_ARUSER_SHIFT  0
#define MP1_MMHUB_SOC_TLB3_13_WUSER_SHIFT  28

#define MP1_MMHUB_SOC_TLB3_13_ARUSER_MASK  0x0fffffff
#define MP1_MMHUB_SOC_TLB3_13_WUSER_MASK  0x70000000

#define MP1_MMHUB_SOC_TLB3_13_MASK \
      (MP1_MMHUB_SOC_TLB3_13_ARUSER_MASK | \
      MP1_MMHUB_SOC_TLB3_13_WUSER_MASK)

#define MP1_MMHUB_SOC_TLB3_13_DEFAULT  0x00000000

#define MP1_MMHUB_SOC_TLB3_13_GET_ARUSER(mp1_mmhub_soc_tlb3_13) \
      ((mp1_mmhub_soc_tlb3_13 & MP1_MMHUB_SOC_TLB3_13_ARUSER_MASK) >> MP1_MMHUB_SOC_TLB3_13_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_13_GET_WUSER(mp1_mmhub_soc_tlb3_13) \
      ((mp1_mmhub_soc_tlb3_13 & MP1_MMHUB_SOC_TLB3_13_WUSER_MASK) >> MP1_MMHUB_SOC_TLB3_13_WUSER_SHIFT)

#define MP1_MMHUB_SOC_TLB3_13_SET_ARUSER(mp1_mmhub_soc_tlb3_13_reg, aruser) \
      mp1_mmhub_soc_tlb3_13_reg = (mp1_mmhub_soc_tlb3_13_reg & ~MP1_MMHUB_SOC_TLB3_13_ARUSER_MASK) | (aruser << MP1_MMHUB_SOC_TLB3_13_ARUSER_SHIFT)
#define MP1_MMHUB_SOC_TLB3_13_SET_WUSER(mp1_mmhub_soc_tlb3_13_reg, wuser) \
      mp1_mmhub_soc_tlb3_13_reg = (mp1_mmhub_soc_tlb3_13_reg & ~MP1_MMHUB_SOC_TLB3_13_WUSER_MASK) | (wuser << MP1_MMHUB_SOC_TLB3_13_WUSER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_13_t {
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_13_ARUSER_SIZE;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_13_WUSER_SIZE;
            unsigned int                                : 1;
      } mp1_mmhub_soc_tlb3_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_soc_tlb3_13_t {
            unsigned int                                : 1;
            unsigned int wuser                          : MP1_MMHUB_SOC_TLB3_13_WUSER_SIZE;
            unsigned int aruser                         : MP1_MMHUB_SOC_TLB3_13_ARUSER_SIZE;
      } mp1_mmhub_soc_tlb3_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_soc_tlb3_13_t f;
} mp1_mmhub_soc_tlb3_13_u;


/*
 * MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1 struct
 */

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_REG_SIZE         32
#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_SIZE  32

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_SHIFT  0

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_MASK  0xffffffff

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_MASK \
      (MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_MASK)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_GET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_1) \
      ((mp1_mmhub_tlb_sub_page_attribute_rw_1 & MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_MASK) >> MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_SHIFT)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_SET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_1_reg, rw_attrib) \
      mp1_mmhub_tlb_sub_page_attribute_rw_1_reg = (mp1_mmhub_tlb_sub_page_attribute_rw_1_reg & ~MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_MASK) | (rw_attrib << MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_1_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_1_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_1_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_sub_page_attribute_rw_1_t f;
} mp1_mmhub_tlb_sub_page_attribute_rw_1_u;


/*
 * MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2 struct
 */

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_REG_SIZE         32
#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_SIZE  32

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_SHIFT  0

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_MASK  0xffffffff

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_MASK \
      (MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_MASK)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_GET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_2) \
      ((mp1_mmhub_tlb_sub_page_attribute_rw_2 & MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_MASK) >> MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_SHIFT)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_SET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_2_reg, rw_attrib) \
      mp1_mmhub_tlb_sub_page_attribute_rw_2_reg = (mp1_mmhub_tlb_sub_page_attribute_rw_2_reg & ~MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_MASK) | (rw_attrib << MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_2_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_2_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_2_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_sub_page_attribute_rw_2_t f;
} mp1_mmhub_tlb_sub_page_attribute_rw_2_u;


/*
 * MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3 struct
 */

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_REG_SIZE         32
#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_SIZE  32

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_SHIFT  0

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_MASK  0xffffffff

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_MASK \
      (MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_MASK)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_GET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_3) \
      ((mp1_mmhub_tlb_sub_page_attribute_rw_3 & MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_MASK) >> MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_SHIFT)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_SET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_3_reg, rw_attrib) \
      mp1_mmhub_tlb_sub_page_attribute_rw_3_reg = (mp1_mmhub_tlb_sub_page_attribute_rw_3_reg & ~MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_MASK) | (rw_attrib << MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_3_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_3_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_3_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_sub_page_attribute_rw_3_t f;
} mp1_mmhub_tlb_sub_page_attribute_rw_3_u;


/*
 * MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4 struct
 */

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_REG_SIZE         32
#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_SIZE  32

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_SHIFT  0

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_MASK  0xffffffff

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_MASK \
      (MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_MASK)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_GET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_4) \
      ((mp1_mmhub_tlb_sub_page_attribute_rw_4 & MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_MASK) >> MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_SHIFT)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_SET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_4_reg, rw_attrib) \
      mp1_mmhub_tlb_sub_page_attribute_rw_4_reg = (mp1_mmhub_tlb_sub_page_attribute_rw_4_reg & ~MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_MASK) | (rw_attrib << MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_4_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_4_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_4_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_sub_page_attribute_rw_4_t f;
} mp1_mmhub_tlb_sub_page_attribute_rw_4_u;


/*
 * MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5 struct
 */

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_REG_SIZE         32
#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_SIZE  32

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_SHIFT  0

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_MASK  0xffffffff

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_MASK \
      (MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_MASK)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_GET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_5) \
      ((mp1_mmhub_tlb_sub_page_attribute_rw_5 & MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_MASK) >> MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_SHIFT)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_SET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_5_reg, rw_attrib) \
      mp1_mmhub_tlb_sub_page_attribute_rw_5_reg = (mp1_mmhub_tlb_sub_page_attribute_rw_5_reg & ~MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_MASK) | (rw_attrib << MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_5_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_5_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_5_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_sub_page_attribute_rw_5_t f;
} mp1_mmhub_tlb_sub_page_attribute_rw_5_u;


/*
 * MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6 struct
 */

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_REG_SIZE         32
#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_SIZE  32

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_SHIFT  0

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_MASK  0xffffffff

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_MASK \
      (MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_MASK)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_GET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_6) \
      ((mp1_mmhub_tlb_sub_page_attribute_rw_6 & MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_MASK) >> MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_SHIFT)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_SET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_6_reg, rw_attrib) \
      mp1_mmhub_tlb_sub_page_attribute_rw_6_reg = (mp1_mmhub_tlb_sub_page_attribute_rw_6_reg & ~MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_MASK) | (rw_attrib << MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_6_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_6_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_6_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_sub_page_attribute_rw_6_t f;
} mp1_mmhub_tlb_sub_page_attribute_rw_6_u;


/*
 * MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7 struct
 */

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_REG_SIZE         32
#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_SIZE  32

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_SHIFT  0

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_MASK  0xffffffff

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_MASK \
      (MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_MASK)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_GET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_7) \
      ((mp1_mmhub_tlb_sub_page_attribute_rw_7 & MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_MASK) >> MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_SHIFT)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_SET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_7_reg, rw_attrib) \
      mp1_mmhub_tlb_sub_page_attribute_rw_7_reg = (mp1_mmhub_tlb_sub_page_attribute_rw_7_reg & ~MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_MASK) | (rw_attrib << MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_7_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_7_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_7_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_sub_page_attribute_rw_7_t f;
} mp1_mmhub_tlb_sub_page_attribute_rw_7_u;


/*
 * MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8 struct
 */

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_REG_SIZE         32
#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_SIZE  32

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_SHIFT  0

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_MASK  0xffffffff

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_MASK \
      (MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_MASK)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_GET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_8) \
      ((mp1_mmhub_tlb_sub_page_attribute_rw_8 & MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_MASK) >> MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_SHIFT)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_SET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_8_reg, rw_attrib) \
      mp1_mmhub_tlb_sub_page_attribute_rw_8_reg = (mp1_mmhub_tlb_sub_page_attribute_rw_8_reg & ~MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_MASK) | (rw_attrib << MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_8_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_8_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_8_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_sub_page_attribute_rw_8_t f;
} mp1_mmhub_tlb_sub_page_attribute_rw_8_u;


/*
 * MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9 struct
 */

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_REG_SIZE         32
#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_SIZE  32

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_SHIFT  0

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_MASK  0xffffffff

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_MASK \
      (MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_MASK)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_GET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_9) \
      ((mp1_mmhub_tlb_sub_page_attribute_rw_9 & MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_MASK) >> MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_SHIFT)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_SET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_9_reg, rw_attrib) \
      mp1_mmhub_tlb_sub_page_attribute_rw_9_reg = (mp1_mmhub_tlb_sub_page_attribute_rw_9_reg & ~MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_MASK) | (rw_attrib << MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_9_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_9_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_9_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_sub_page_attribute_rw_9_t f;
} mp1_mmhub_tlb_sub_page_attribute_rw_9_u;


/*
 * MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10 struct
 */

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_REG_SIZE         32
#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_SIZE  32

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_SHIFT  0

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_MASK  0xffffffff

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_MASK \
      (MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_MASK)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_GET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_10) \
      ((mp1_mmhub_tlb_sub_page_attribute_rw_10 & MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_MASK) >> MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_SHIFT)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_SET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_10_reg, rw_attrib) \
      mp1_mmhub_tlb_sub_page_attribute_rw_10_reg = (mp1_mmhub_tlb_sub_page_attribute_rw_10_reg & ~MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_MASK) | (rw_attrib << MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_10_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_10_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_10_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_sub_page_attribute_rw_10_t f;
} mp1_mmhub_tlb_sub_page_attribute_rw_10_u;


/*
 * MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11 struct
 */

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_REG_SIZE         32
#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_SIZE  32

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_SHIFT  0

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_MASK  0xffffffff

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_MASK \
      (MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_MASK)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_GET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_11) \
      ((mp1_mmhub_tlb_sub_page_attribute_rw_11 & MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_MASK) >> MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_SHIFT)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_SET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_11_reg, rw_attrib) \
      mp1_mmhub_tlb_sub_page_attribute_rw_11_reg = (mp1_mmhub_tlb_sub_page_attribute_rw_11_reg & ~MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_MASK) | (rw_attrib << MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_11_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_11_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_11_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_sub_page_attribute_rw_11_t f;
} mp1_mmhub_tlb_sub_page_attribute_rw_11_u;


/*
 * MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12 struct
 */

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_REG_SIZE         32
#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_SIZE  32

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_SHIFT  0

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_MASK  0xffffffff

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_MASK \
      (MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_MASK)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_GET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_12) \
      ((mp1_mmhub_tlb_sub_page_attribute_rw_12 & MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_MASK) >> MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_SHIFT)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_SET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_12_reg, rw_attrib) \
      mp1_mmhub_tlb_sub_page_attribute_rw_12_reg = (mp1_mmhub_tlb_sub_page_attribute_rw_12_reg & ~MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_MASK) | (rw_attrib << MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_12_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_12_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_12_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_sub_page_attribute_rw_12_t f;
} mp1_mmhub_tlb_sub_page_attribute_rw_12_u;


/*
 * MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13 struct
 */

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_REG_SIZE         32
#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_SIZE  32

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_SHIFT  0

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_MASK  0xffffffff

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_MASK \
      (MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_MASK)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_GET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_13) \
      ((mp1_mmhub_tlb_sub_page_attribute_rw_13 & MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_MASK) >> MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_SHIFT)

#define MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_SET_RW_ATTRIB(mp1_mmhub_tlb_sub_page_attribute_rw_13_reg, rw_attrib) \
      mp1_mmhub_tlb_sub_page_attribute_rw_13_reg = (mp1_mmhub_tlb_sub_page_attribute_rw_13_reg & ~MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_MASK) | (rw_attrib << MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_13_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_sub_page_attribute_rw_13_t {
            unsigned int rw_attrib                      : MP1_MMHUB_TLB_SUB_PAGE_ATTRIBUTE_RW_13_RW_ATTRIB_SIZE;
      } mp1_mmhub_tlb_sub_page_attribute_rw_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_sub_page_attribute_rw_13_t f;
} mp1_mmhub_tlb_sub_page_attribute_rw_13_u;


/*
 * MP1_MMHUB_TLB_ATTRIBUTE_1 struct
 */

#define MP1_MMHUB_TLB_ATTRIBUTE_1_REG_SIZE         32
#define MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_DMA_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_SIZE  1

#define MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_SHIFT  0
#define MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_SHIFT  1
#define MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_DMA_SHIFT  24
#define MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_SHIFT  30
#define MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_SHIFT  31

#define MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_DMA_MASK  0x01000000
#define MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_MASK  0x40000000
#define MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_MASK  0x80000000

#define MP1_MMHUB_TLB_ATTRIBUTE_1_MASK \
      (MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_DMA_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_MASK)

#define MP1_MMHUB_TLB_ATTRIBUTE_1_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_ATTRIBUTE_1_GET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_1) \
      ((mp1_mmhub_tlb_attribute_1 & MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_1_GET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_1) \
      ((mp1_mmhub_tlb_attribute_1 & MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_1_GET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_1) \
      ((mp1_mmhub_tlb_attribute_1 & MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_DMA_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_1_GET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_1) \
      ((mp1_mmhub_tlb_attribute_1 & MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_1_GET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_1) \
      ((mp1_mmhub_tlb_attribute_1 & MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_SHIFT)

#define MP1_MMHUB_TLB_ATTRIBUTE_1_SET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_1_reg, ma_psp_arprot_1) \
      mp1_mmhub_tlb_attribute_1_reg = (mp1_mmhub_tlb_attribute_1_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_1_SET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_1_reg, ma_psp_awprot_1) \
      mp1_mmhub_tlb_attribute_1_reg = (mp1_mmhub_tlb_attribute_1_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_1_SET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_1_reg, ma_psp_dma) \
      mp1_mmhub_tlb_attribute_1_reg = (mp1_mmhub_tlb_attribute_1_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_DMA_MASK) | (ma_psp_dma << MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_1_SET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_1_reg, ma_psp_pub) \
      mp1_mmhub_tlb_attribute_1_reg = (mp1_mmhub_tlb_attribute_1_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_MASK) | (ma_psp_pub << MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_1_SET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_1_reg, ma_psp_priv) \
      mp1_mmhub_tlb_attribute_1_reg = (mp1_mmhub_tlb_attribute_1_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_1_t {
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_SIZE;
      } mp1_mmhub_tlb_attribute_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_1_t {
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_1_MA_PSP_ARPROT_1_SIZE;
      } mp1_mmhub_tlb_attribute_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_attribute_1_t f;
} mp1_mmhub_tlb_attribute_1_u;


/*
 * MP1_MMHUB_TLB_ATTRIBUTE_2 struct
 */

#define MP1_MMHUB_TLB_ATTRIBUTE_2_REG_SIZE         32
#define MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_DMA_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_SIZE  1

#define MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_SHIFT  0
#define MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_SHIFT  1
#define MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_DMA_SHIFT  24
#define MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_SHIFT  30
#define MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_SHIFT  31

#define MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_DMA_MASK  0x01000000
#define MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_MASK  0x40000000
#define MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_MASK  0x80000000

#define MP1_MMHUB_TLB_ATTRIBUTE_2_MASK \
      (MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_DMA_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_MASK)

#define MP1_MMHUB_TLB_ATTRIBUTE_2_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_ATTRIBUTE_2_GET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_2) \
      ((mp1_mmhub_tlb_attribute_2 & MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_2_GET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_2) \
      ((mp1_mmhub_tlb_attribute_2 & MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_2_GET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_2) \
      ((mp1_mmhub_tlb_attribute_2 & MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_DMA_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_2_GET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_2) \
      ((mp1_mmhub_tlb_attribute_2 & MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_2_GET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_2) \
      ((mp1_mmhub_tlb_attribute_2 & MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_SHIFT)

#define MP1_MMHUB_TLB_ATTRIBUTE_2_SET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_2_reg, ma_psp_arprot_1) \
      mp1_mmhub_tlb_attribute_2_reg = (mp1_mmhub_tlb_attribute_2_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_2_SET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_2_reg, ma_psp_awprot_1) \
      mp1_mmhub_tlb_attribute_2_reg = (mp1_mmhub_tlb_attribute_2_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_2_SET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_2_reg, ma_psp_dma) \
      mp1_mmhub_tlb_attribute_2_reg = (mp1_mmhub_tlb_attribute_2_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_DMA_MASK) | (ma_psp_dma << MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_2_SET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_2_reg, ma_psp_pub) \
      mp1_mmhub_tlb_attribute_2_reg = (mp1_mmhub_tlb_attribute_2_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_MASK) | (ma_psp_pub << MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_2_SET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_2_reg, ma_psp_priv) \
      mp1_mmhub_tlb_attribute_2_reg = (mp1_mmhub_tlb_attribute_2_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_2_t {
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_SIZE;
      } mp1_mmhub_tlb_attribute_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_2_t {
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_2_MA_PSP_ARPROT_1_SIZE;
      } mp1_mmhub_tlb_attribute_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_attribute_2_t f;
} mp1_mmhub_tlb_attribute_2_u;


/*
 * MP1_MMHUB_TLB_ATTRIBUTE_3 struct
 */

#define MP1_MMHUB_TLB_ATTRIBUTE_3_REG_SIZE         32
#define MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_DMA_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_SIZE  1

#define MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_SHIFT  0
#define MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_SHIFT  1
#define MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_DMA_SHIFT  24
#define MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_SHIFT  30
#define MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_SHIFT  31

#define MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_DMA_MASK  0x01000000
#define MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_MASK  0x40000000
#define MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_MASK  0x80000000

#define MP1_MMHUB_TLB_ATTRIBUTE_3_MASK \
      (MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_DMA_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_MASK)

#define MP1_MMHUB_TLB_ATTRIBUTE_3_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_ATTRIBUTE_3_GET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_3) \
      ((mp1_mmhub_tlb_attribute_3 & MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_3_GET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_3) \
      ((mp1_mmhub_tlb_attribute_3 & MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_3_GET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_3) \
      ((mp1_mmhub_tlb_attribute_3 & MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_DMA_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_3_GET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_3) \
      ((mp1_mmhub_tlb_attribute_3 & MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_3_GET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_3) \
      ((mp1_mmhub_tlb_attribute_3 & MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_SHIFT)

#define MP1_MMHUB_TLB_ATTRIBUTE_3_SET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_3_reg, ma_psp_arprot_1) \
      mp1_mmhub_tlb_attribute_3_reg = (mp1_mmhub_tlb_attribute_3_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_3_SET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_3_reg, ma_psp_awprot_1) \
      mp1_mmhub_tlb_attribute_3_reg = (mp1_mmhub_tlb_attribute_3_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_3_SET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_3_reg, ma_psp_dma) \
      mp1_mmhub_tlb_attribute_3_reg = (mp1_mmhub_tlb_attribute_3_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_DMA_MASK) | (ma_psp_dma << MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_3_SET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_3_reg, ma_psp_pub) \
      mp1_mmhub_tlb_attribute_3_reg = (mp1_mmhub_tlb_attribute_3_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_MASK) | (ma_psp_pub << MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_3_SET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_3_reg, ma_psp_priv) \
      mp1_mmhub_tlb_attribute_3_reg = (mp1_mmhub_tlb_attribute_3_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_3_t {
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_SIZE;
      } mp1_mmhub_tlb_attribute_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_3_t {
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_3_MA_PSP_ARPROT_1_SIZE;
      } mp1_mmhub_tlb_attribute_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_attribute_3_t f;
} mp1_mmhub_tlb_attribute_3_u;


/*
 * MP1_MMHUB_TLB_ATTRIBUTE_4 struct
 */

#define MP1_MMHUB_TLB_ATTRIBUTE_4_REG_SIZE         32
#define MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_DMA_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_SIZE  1

#define MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_SHIFT  0
#define MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_SHIFT  1
#define MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_DMA_SHIFT  24
#define MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_SHIFT  30
#define MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_SHIFT  31

#define MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_DMA_MASK  0x01000000
#define MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_MASK  0x40000000
#define MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_MASK  0x80000000

#define MP1_MMHUB_TLB_ATTRIBUTE_4_MASK \
      (MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_DMA_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_MASK)

#define MP1_MMHUB_TLB_ATTRIBUTE_4_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_ATTRIBUTE_4_GET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_4) \
      ((mp1_mmhub_tlb_attribute_4 & MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_4_GET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_4) \
      ((mp1_mmhub_tlb_attribute_4 & MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_4_GET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_4) \
      ((mp1_mmhub_tlb_attribute_4 & MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_DMA_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_4_GET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_4) \
      ((mp1_mmhub_tlb_attribute_4 & MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_4_GET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_4) \
      ((mp1_mmhub_tlb_attribute_4 & MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_SHIFT)

#define MP1_MMHUB_TLB_ATTRIBUTE_4_SET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_4_reg, ma_psp_arprot_1) \
      mp1_mmhub_tlb_attribute_4_reg = (mp1_mmhub_tlb_attribute_4_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_4_SET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_4_reg, ma_psp_awprot_1) \
      mp1_mmhub_tlb_attribute_4_reg = (mp1_mmhub_tlb_attribute_4_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_4_SET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_4_reg, ma_psp_dma) \
      mp1_mmhub_tlb_attribute_4_reg = (mp1_mmhub_tlb_attribute_4_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_DMA_MASK) | (ma_psp_dma << MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_4_SET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_4_reg, ma_psp_pub) \
      mp1_mmhub_tlb_attribute_4_reg = (mp1_mmhub_tlb_attribute_4_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_MASK) | (ma_psp_pub << MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_4_SET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_4_reg, ma_psp_priv) \
      mp1_mmhub_tlb_attribute_4_reg = (mp1_mmhub_tlb_attribute_4_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_4_t {
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_SIZE;
      } mp1_mmhub_tlb_attribute_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_4_t {
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_4_MA_PSP_ARPROT_1_SIZE;
      } mp1_mmhub_tlb_attribute_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_attribute_4_t f;
} mp1_mmhub_tlb_attribute_4_u;


/*
 * MP1_MMHUB_TLB_ATTRIBUTE_5 struct
 */

#define MP1_MMHUB_TLB_ATTRIBUTE_5_REG_SIZE         32
#define MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_DMA_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_SIZE  1

#define MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_SHIFT  0
#define MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_SHIFT  1
#define MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_DMA_SHIFT  24
#define MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_SHIFT  30
#define MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_SHIFT  31

#define MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_DMA_MASK  0x01000000
#define MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_MASK  0x40000000
#define MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_MASK  0x80000000

#define MP1_MMHUB_TLB_ATTRIBUTE_5_MASK \
      (MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_DMA_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_MASK)

#define MP1_MMHUB_TLB_ATTRIBUTE_5_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_ATTRIBUTE_5_GET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_5) \
      ((mp1_mmhub_tlb_attribute_5 & MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_5_GET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_5) \
      ((mp1_mmhub_tlb_attribute_5 & MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_5_GET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_5) \
      ((mp1_mmhub_tlb_attribute_5 & MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_DMA_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_5_GET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_5) \
      ((mp1_mmhub_tlb_attribute_5 & MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_5_GET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_5) \
      ((mp1_mmhub_tlb_attribute_5 & MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_SHIFT)

#define MP1_MMHUB_TLB_ATTRIBUTE_5_SET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_5_reg, ma_psp_arprot_1) \
      mp1_mmhub_tlb_attribute_5_reg = (mp1_mmhub_tlb_attribute_5_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_5_SET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_5_reg, ma_psp_awprot_1) \
      mp1_mmhub_tlb_attribute_5_reg = (mp1_mmhub_tlb_attribute_5_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_5_SET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_5_reg, ma_psp_dma) \
      mp1_mmhub_tlb_attribute_5_reg = (mp1_mmhub_tlb_attribute_5_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_DMA_MASK) | (ma_psp_dma << MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_5_SET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_5_reg, ma_psp_pub) \
      mp1_mmhub_tlb_attribute_5_reg = (mp1_mmhub_tlb_attribute_5_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_MASK) | (ma_psp_pub << MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_5_SET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_5_reg, ma_psp_priv) \
      mp1_mmhub_tlb_attribute_5_reg = (mp1_mmhub_tlb_attribute_5_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_5_t {
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_SIZE;
      } mp1_mmhub_tlb_attribute_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_5_t {
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_5_MA_PSP_ARPROT_1_SIZE;
      } mp1_mmhub_tlb_attribute_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_attribute_5_t f;
} mp1_mmhub_tlb_attribute_5_u;


/*
 * MP1_MMHUB_TLB_ATTRIBUTE_6 struct
 */

#define MP1_MMHUB_TLB_ATTRIBUTE_6_REG_SIZE         32
#define MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_DMA_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_SIZE  1

#define MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_SHIFT  0
#define MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_SHIFT  1
#define MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_DMA_SHIFT  24
#define MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_SHIFT  30
#define MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_SHIFT  31

#define MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_DMA_MASK  0x01000000
#define MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_MASK  0x40000000
#define MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_MASK  0x80000000

#define MP1_MMHUB_TLB_ATTRIBUTE_6_MASK \
      (MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_DMA_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_MASK)

#define MP1_MMHUB_TLB_ATTRIBUTE_6_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_ATTRIBUTE_6_GET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_6) \
      ((mp1_mmhub_tlb_attribute_6 & MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_6_GET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_6) \
      ((mp1_mmhub_tlb_attribute_6 & MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_6_GET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_6) \
      ((mp1_mmhub_tlb_attribute_6 & MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_DMA_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_6_GET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_6) \
      ((mp1_mmhub_tlb_attribute_6 & MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_6_GET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_6) \
      ((mp1_mmhub_tlb_attribute_6 & MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_SHIFT)

#define MP1_MMHUB_TLB_ATTRIBUTE_6_SET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_6_reg, ma_psp_arprot_1) \
      mp1_mmhub_tlb_attribute_6_reg = (mp1_mmhub_tlb_attribute_6_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_6_SET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_6_reg, ma_psp_awprot_1) \
      mp1_mmhub_tlb_attribute_6_reg = (mp1_mmhub_tlb_attribute_6_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_6_SET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_6_reg, ma_psp_dma) \
      mp1_mmhub_tlb_attribute_6_reg = (mp1_mmhub_tlb_attribute_6_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_DMA_MASK) | (ma_psp_dma << MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_6_SET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_6_reg, ma_psp_pub) \
      mp1_mmhub_tlb_attribute_6_reg = (mp1_mmhub_tlb_attribute_6_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_MASK) | (ma_psp_pub << MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_6_SET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_6_reg, ma_psp_priv) \
      mp1_mmhub_tlb_attribute_6_reg = (mp1_mmhub_tlb_attribute_6_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_6_t {
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_SIZE;
      } mp1_mmhub_tlb_attribute_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_6_t {
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_6_MA_PSP_ARPROT_1_SIZE;
      } mp1_mmhub_tlb_attribute_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_attribute_6_t f;
} mp1_mmhub_tlb_attribute_6_u;


/*
 * MP1_MMHUB_TLB_ATTRIBUTE_7 struct
 */

#define MP1_MMHUB_TLB_ATTRIBUTE_7_REG_SIZE         32
#define MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_DMA_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_SIZE  1

#define MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_SHIFT  0
#define MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_SHIFT  1
#define MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_DMA_SHIFT  24
#define MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_SHIFT  30
#define MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_SHIFT  31

#define MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_DMA_MASK  0x01000000
#define MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_MASK  0x40000000
#define MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_MASK  0x80000000

#define MP1_MMHUB_TLB_ATTRIBUTE_7_MASK \
      (MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_DMA_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_MASK)

#define MP1_MMHUB_TLB_ATTRIBUTE_7_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_ATTRIBUTE_7_GET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_7) \
      ((mp1_mmhub_tlb_attribute_7 & MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_7_GET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_7) \
      ((mp1_mmhub_tlb_attribute_7 & MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_7_GET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_7) \
      ((mp1_mmhub_tlb_attribute_7 & MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_DMA_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_7_GET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_7) \
      ((mp1_mmhub_tlb_attribute_7 & MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_7_GET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_7) \
      ((mp1_mmhub_tlb_attribute_7 & MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_SHIFT)

#define MP1_MMHUB_TLB_ATTRIBUTE_7_SET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_7_reg, ma_psp_arprot_1) \
      mp1_mmhub_tlb_attribute_7_reg = (mp1_mmhub_tlb_attribute_7_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_7_SET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_7_reg, ma_psp_awprot_1) \
      mp1_mmhub_tlb_attribute_7_reg = (mp1_mmhub_tlb_attribute_7_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_7_SET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_7_reg, ma_psp_dma) \
      mp1_mmhub_tlb_attribute_7_reg = (mp1_mmhub_tlb_attribute_7_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_DMA_MASK) | (ma_psp_dma << MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_7_SET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_7_reg, ma_psp_pub) \
      mp1_mmhub_tlb_attribute_7_reg = (mp1_mmhub_tlb_attribute_7_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_MASK) | (ma_psp_pub << MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_7_SET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_7_reg, ma_psp_priv) \
      mp1_mmhub_tlb_attribute_7_reg = (mp1_mmhub_tlb_attribute_7_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_7_t {
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_SIZE;
      } mp1_mmhub_tlb_attribute_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_7_t {
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_7_MA_PSP_ARPROT_1_SIZE;
      } mp1_mmhub_tlb_attribute_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_attribute_7_t f;
} mp1_mmhub_tlb_attribute_7_u;


/*
 * MP1_MMHUB_TLB_ATTRIBUTE_8 struct
 */

#define MP1_MMHUB_TLB_ATTRIBUTE_8_REG_SIZE         32
#define MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_DMA_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_SIZE  1

#define MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_SHIFT  0
#define MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_SHIFT  1
#define MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_DMA_SHIFT  24
#define MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_SHIFT  30
#define MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_SHIFT  31

#define MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_DMA_MASK  0x01000000
#define MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_MASK  0x40000000
#define MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_MASK  0x80000000

#define MP1_MMHUB_TLB_ATTRIBUTE_8_MASK \
      (MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_DMA_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_MASK)

#define MP1_MMHUB_TLB_ATTRIBUTE_8_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_ATTRIBUTE_8_GET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_8) \
      ((mp1_mmhub_tlb_attribute_8 & MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_8_GET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_8) \
      ((mp1_mmhub_tlb_attribute_8 & MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_8_GET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_8) \
      ((mp1_mmhub_tlb_attribute_8 & MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_DMA_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_8_GET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_8) \
      ((mp1_mmhub_tlb_attribute_8 & MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_8_GET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_8) \
      ((mp1_mmhub_tlb_attribute_8 & MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_SHIFT)

#define MP1_MMHUB_TLB_ATTRIBUTE_8_SET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_8_reg, ma_psp_arprot_1) \
      mp1_mmhub_tlb_attribute_8_reg = (mp1_mmhub_tlb_attribute_8_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_8_SET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_8_reg, ma_psp_awprot_1) \
      mp1_mmhub_tlb_attribute_8_reg = (mp1_mmhub_tlb_attribute_8_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_8_SET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_8_reg, ma_psp_dma) \
      mp1_mmhub_tlb_attribute_8_reg = (mp1_mmhub_tlb_attribute_8_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_DMA_MASK) | (ma_psp_dma << MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_8_SET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_8_reg, ma_psp_pub) \
      mp1_mmhub_tlb_attribute_8_reg = (mp1_mmhub_tlb_attribute_8_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_MASK) | (ma_psp_pub << MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_8_SET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_8_reg, ma_psp_priv) \
      mp1_mmhub_tlb_attribute_8_reg = (mp1_mmhub_tlb_attribute_8_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_8_t {
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_SIZE;
      } mp1_mmhub_tlb_attribute_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_8_t {
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_8_MA_PSP_ARPROT_1_SIZE;
      } mp1_mmhub_tlb_attribute_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_attribute_8_t f;
} mp1_mmhub_tlb_attribute_8_u;


/*
 * MP1_MMHUB_TLB_ATTRIBUTE_9 struct
 */

#define MP1_MMHUB_TLB_ATTRIBUTE_9_REG_SIZE         32
#define MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_DMA_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_SIZE  1

#define MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_SHIFT  0
#define MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_SHIFT  1
#define MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_DMA_SHIFT  24
#define MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_SHIFT  30
#define MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_SHIFT  31

#define MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_DMA_MASK  0x01000000
#define MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_MASK  0x40000000
#define MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_MASK  0x80000000

#define MP1_MMHUB_TLB_ATTRIBUTE_9_MASK \
      (MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_DMA_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_MASK)

#define MP1_MMHUB_TLB_ATTRIBUTE_9_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_ATTRIBUTE_9_GET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_9) \
      ((mp1_mmhub_tlb_attribute_9 & MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_9_GET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_9) \
      ((mp1_mmhub_tlb_attribute_9 & MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_9_GET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_9) \
      ((mp1_mmhub_tlb_attribute_9 & MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_DMA_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_9_GET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_9) \
      ((mp1_mmhub_tlb_attribute_9 & MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_9_GET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_9) \
      ((mp1_mmhub_tlb_attribute_9 & MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_SHIFT)

#define MP1_MMHUB_TLB_ATTRIBUTE_9_SET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_9_reg, ma_psp_arprot_1) \
      mp1_mmhub_tlb_attribute_9_reg = (mp1_mmhub_tlb_attribute_9_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_9_SET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_9_reg, ma_psp_awprot_1) \
      mp1_mmhub_tlb_attribute_9_reg = (mp1_mmhub_tlb_attribute_9_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_9_SET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_9_reg, ma_psp_dma) \
      mp1_mmhub_tlb_attribute_9_reg = (mp1_mmhub_tlb_attribute_9_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_DMA_MASK) | (ma_psp_dma << MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_9_SET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_9_reg, ma_psp_pub) \
      mp1_mmhub_tlb_attribute_9_reg = (mp1_mmhub_tlb_attribute_9_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_MASK) | (ma_psp_pub << MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_9_SET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_9_reg, ma_psp_priv) \
      mp1_mmhub_tlb_attribute_9_reg = (mp1_mmhub_tlb_attribute_9_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_9_t {
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_SIZE;
      } mp1_mmhub_tlb_attribute_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_9_t {
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_9_MA_PSP_ARPROT_1_SIZE;
      } mp1_mmhub_tlb_attribute_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_attribute_9_t f;
} mp1_mmhub_tlb_attribute_9_u;


/*
 * MP1_MMHUB_TLB_ATTRIBUTE_10 struct
 */

#define MP1_MMHUB_TLB_ATTRIBUTE_10_REG_SIZE         32
#define MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_DMA_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_SIZE  1

#define MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_SHIFT  0
#define MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_SHIFT  1
#define MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_DMA_SHIFT  24
#define MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_SHIFT  30
#define MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_SHIFT  31

#define MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_DMA_MASK  0x01000000
#define MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_MASK  0x40000000
#define MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_MASK  0x80000000

#define MP1_MMHUB_TLB_ATTRIBUTE_10_MASK \
      (MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_DMA_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_MASK)

#define MP1_MMHUB_TLB_ATTRIBUTE_10_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_ATTRIBUTE_10_GET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_10) \
      ((mp1_mmhub_tlb_attribute_10 & MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_10_GET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_10) \
      ((mp1_mmhub_tlb_attribute_10 & MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_10_GET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_10) \
      ((mp1_mmhub_tlb_attribute_10 & MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_DMA_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_10_GET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_10) \
      ((mp1_mmhub_tlb_attribute_10 & MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_10_GET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_10) \
      ((mp1_mmhub_tlb_attribute_10 & MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_SHIFT)

#define MP1_MMHUB_TLB_ATTRIBUTE_10_SET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_10_reg, ma_psp_arprot_1) \
      mp1_mmhub_tlb_attribute_10_reg = (mp1_mmhub_tlb_attribute_10_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_10_SET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_10_reg, ma_psp_awprot_1) \
      mp1_mmhub_tlb_attribute_10_reg = (mp1_mmhub_tlb_attribute_10_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_10_SET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_10_reg, ma_psp_dma) \
      mp1_mmhub_tlb_attribute_10_reg = (mp1_mmhub_tlb_attribute_10_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_DMA_MASK) | (ma_psp_dma << MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_10_SET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_10_reg, ma_psp_pub) \
      mp1_mmhub_tlb_attribute_10_reg = (mp1_mmhub_tlb_attribute_10_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_MASK) | (ma_psp_pub << MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_10_SET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_10_reg, ma_psp_priv) \
      mp1_mmhub_tlb_attribute_10_reg = (mp1_mmhub_tlb_attribute_10_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_10_t {
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_SIZE;
      } mp1_mmhub_tlb_attribute_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_10_t {
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_10_MA_PSP_ARPROT_1_SIZE;
      } mp1_mmhub_tlb_attribute_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_attribute_10_t f;
} mp1_mmhub_tlb_attribute_10_u;


/*
 * MP1_MMHUB_TLB_ATTRIBUTE_11 struct
 */

#define MP1_MMHUB_TLB_ATTRIBUTE_11_REG_SIZE         32
#define MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_DMA_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_SIZE  1

#define MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_SHIFT  0
#define MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_SHIFT  1
#define MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_DMA_SHIFT  24
#define MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_SHIFT  30
#define MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_SHIFT  31

#define MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_DMA_MASK  0x01000000
#define MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_MASK  0x40000000
#define MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_MASK  0x80000000

#define MP1_MMHUB_TLB_ATTRIBUTE_11_MASK \
      (MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_DMA_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_MASK)

#define MP1_MMHUB_TLB_ATTRIBUTE_11_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_ATTRIBUTE_11_GET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_11) \
      ((mp1_mmhub_tlb_attribute_11 & MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_11_GET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_11) \
      ((mp1_mmhub_tlb_attribute_11 & MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_11_GET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_11) \
      ((mp1_mmhub_tlb_attribute_11 & MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_DMA_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_11_GET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_11) \
      ((mp1_mmhub_tlb_attribute_11 & MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_11_GET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_11) \
      ((mp1_mmhub_tlb_attribute_11 & MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_SHIFT)

#define MP1_MMHUB_TLB_ATTRIBUTE_11_SET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_11_reg, ma_psp_arprot_1) \
      mp1_mmhub_tlb_attribute_11_reg = (mp1_mmhub_tlb_attribute_11_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_11_SET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_11_reg, ma_psp_awprot_1) \
      mp1_mmhub_tlb_attribute_11_reg = (mp1_mmhub_tlb_attribute_11_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_11_SET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_11_reg, ma_psp_dma) \
      mp1_mmhub_tlb_attribute_11_reg = (mp1_mmhub_tlb_attribute_11_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_DMA_MASK) | (ma_psp_dma << MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_11_SET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_11_reg, ma_psp_pub) \
      mp1_mmhub_tlb_attribute_11_reg = (mp1_mmhub_tlb_attribute_11_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_MASK) | (ma_psp_pub << MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_11_SET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_11_reg, ma_psp_priv) \
      mp1_mmhub_tlb_attribute_11_reg = (mp1_mmhub_tlb_attribute_11_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_11_t {
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_SIZE;
      } mp1_mmhub_tlb_attribute_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_11_t {
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_11_MA_PSP_ARPROT_1_SIZE;
      } mp1_mmhub_tlb_attribute_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_attribute_11_t f;
} mp1_mmhub_tlb_attribute_11_u;


/*
 * MP1_MMHUB_TLB_ATTRIBUTE_12 struct
 */

#define MP1_MMHUB_TLB_ATTRIBUTE_12_REG_SIZE         32
#define MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_DMA_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_SIZE  1

#define MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_SHIFT  0
#define MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_SHIFT  1
#define MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_DMA_SHIFT  24
#define MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_SHIFT  30
#define MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_SHIFT  31

#define MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_DMA_MASK  0x01000000
#define MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_MASK  0x40000000
#define MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_MASK  0x80000000

#define MP1_MMHUB_TLB_ATTRIBUTE_12_MASK \
      (MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_DMA_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_MASK)

#define MP1_MMHUB_TLB_ATTRIBUTE_12_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_ATTRIBUTE_12_GET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_12) \
      ((mp1_mmhub_tlb_attribute_12 & MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_12_GET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_12) \
      ((mp1_mmhub_tlb_attribute_12 & MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_12_GET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_12) \
      ((mp1_mmhub_tlb_attribute_12 & MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_DMA_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_12_GET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_12) \
      ((mp1_mmhub_tlb_attribute_12 & MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_12_GET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_12) \
      ((mp1_mmhub_tlb_attribute_12 & MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_SHIFT)

#define MP1_MMHUB_TLB_ATTRIBUTE_12_SET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_12_reg, ma_psp_arprot_1) \
      mp1_mmhub_tlb_attribute_12_reg = (mp1_mmhub_tlb_attribute_12_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_12_SET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_12_reg, ma_psp_awprot_1) \
      mp1_mmhub_tlb_attribute_12_reg = (mp1_mmhub_tlb_attribute_12_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_12_SET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_12_reg, ma_psp_dma) \
      mp1_mmhub_tlb_attribute_12_reg = (mp1_mmhub_tlb_attribute_12_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_DMA_MASK) | (ma_psp_dma << MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_12_SET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_12_reg, ma_psp_pub) \
      mp1_mmhub_tlb_attribute_12_reg = (mp1_mmhub_tlb_attribute_12_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_MASK) | (ma_psp_pub << MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_12_SET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_12_reg, ma_psp_priv) \
      mp1_mmhub_tlb_attribute_12_reg = (mp1_mmhub_tlb_attribute_12_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_12_t {
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_SIZE;
      } mp1_mmhub_tlb_attribute_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_12_t {
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_12_MA_PSP_ARPROT_1_SIZE;
      } mp1_mmhub_tlb_attribute_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_attribute_12_t f;
} mp1_mmhub_tlb_attribute_12_u;


/*
 * MP1_MMHUB_TLB_ATTRIBUTE_13 struct
 */

#define MP1_MMHUB_TLB_ATTRIBUTE_13_REG_SIZE         32
#define MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_DMA_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_SIZE  1
#define MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_SIZE  1

#define MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_SHIFT  0
#define MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_SHIFT  1
#define MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_DMA_SHIFT  24
#define MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_SHIFT  30
#define MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_SHIFT  31

#define MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_MASK  0x00000001
#define MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_MASK  0x00000002
#define MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_DMA_MASK  0x01000000
#define MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_MASK  0x40000000
#define MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_MASK  0x80000000

#define MP1_MMHUB_TLB_ATTRIBUTE_13_MASK \
      (MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_DMA_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_MASK | \
      MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_MASK)

#define MP1_MMHUB_TLB_ATTRIBUTE_13_DEFAULT 0x00000000

#define MP1_MMHUB_TLB_ATTRIBUTE_13_GET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_13) \
      ((mp1_mmhub_tlb_attribute_13 & MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_13_GET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_13) \
      ((mp1_mmhub_tlb_attribute_13 & MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_13_GET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_13) \
      ((mp1_mmhub_tlb_attribute_13 & MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_DMA_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_13_GET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_13) \
      ((mp1_mmhub_tlb_attribute_13 & MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_13_GET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_13) \
      ((mp1_mmhub_tlb_attribute_13 & MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_MASK) >> MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_SHIFT)

#define MP1_MMHUB_TLB_ATTRIBUTE_13_SET_MA_PSP_ARPROT_1(mp1_mmhub_tlb_attribute_13_reg, ma_psp_arprot_1) \
      mp1_mmhub_tlb_attribute_13_reg = (mp1_mmhub_tlb_attribute_13_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_MASK) | (ma_psp_arprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_13_SET_MA_PSP_AWPROT_1(mp1_mmhub_tlb_attribute_13_reg, ma_psp_awprot_1) \
      mp1_mmhub_tlb_attribute_13_reg = (mp1_mmhub_tlb_attribute_13_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_MASK) | (ma_psp_awprot_1 << MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_13_SET_MA_PSP_DMA(mp1_mmhub_tlb_attribute_13_reg, ma_psp_dma) \
      mp1_mmhub_tlb_attribute_13_reg = (mp1_mmhub_tlb_attribute_13_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_DMA_MASK) | (ma_psp_dma << MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_DMA_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_13_SET_MA_PSP_PUB(mp1_mmhub_tlb_attribute_13_reg, ma_psp_pub) \
      mp1_mmhub_tlb_attribute_13_reg = (mp1_mmhub_tlb_attribute_13_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_MASK) | (ma_psp_pub << MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_SHIFT)
#define MP1_MMHUB_TLB_ATTRIBUTE_13_SET_MA_PSP_PRIV(mp1_mmhub_tlb_attribute_13_reg, ma_psp_priv) \
      mp1_mmhub_tlb_attribute_13_reg = (mp1_mmhub_tlb_attribute_13_reg & ~MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_MASK) | (ma_psp_priv << MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_13_t {
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_SIZE;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_DMA_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_SIZE;
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_SIZE;
      } mp1_mmhub_tlb_attribute_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_tlb_attribute_13_t {
            unsigned int ma_psp_priv                    : MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_PRIV_SIZE;
            unsigned int ma_psp_pub                     : MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_PUB_SIZE;
            unsigned int                                : 5;
            unsigned int ma_psp_dma                     : MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_DMA_SIZE;
            unsigned int                                : 22;
            unsigned int ma_psp_awprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_AWPROT_1_SIZE;
            unsigned int ma_psp_arprot_1                : MP1_MMHUB_TLB_ATTRIBUTE_13_MA_PSP_ARPROT_1_SIZE;
      } mp1_mmhub_tlb_attribute_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_tlb_attribute_13_t f;
} mp1_mmhub_tlb_attribute_13_u;


/*
 * MP1_MMHUB_INT_STATUS struct
 */

#define MP1_MMHUB_INT_STATUS_REG_SIZE         32
#define MP1_MMHUB_INT_STATUS_RD_ERROR_SIZE  1
#define MP1_MMHUB_INT_STATUS_WR_ERROR_SIZE  1
#define MP1_MMHUB_INT_STATUS_REG_ERROR_SIZE  1

#define MP1_MMHUB_INT_STATUS_RD_ERROR_SHIFT  0
#define MP1_MMHUB_INT_STATUS_WR_ERROR_SHIFT  1
#define MP1_MMHUB_INT_STATUS_REG_ERROR_SHIFT  2

#define MP1_MMHUB_INT_STATUS_RD_ERROR_MASK  0x00000001
#define MP1_MMHUB_INT_STATUS_WR_ERROR_MASK  0x00000002
#define MP1_MMHUB_INT_STATUS_REG_ERROR_MASK  0x00000004

#define MP1_MMHUB_INT_STATUS_MASK \
      (MP1_MMHUB_INT_STATUS_RD_ERROR_MASK | \
      MP1_MMHUB_INT_STATUS_WR_ERROR_MASK | \
      MP1_MMHUB_INT_STATUS_REG_ERROR_MASK)

#define MP1_MMHUB_INT_STATUS_DEFAULT   0x00000000

#define MP1_MMHUB_INT_STATUS_GET_RD_ERROR(mp1_mmhub_int_status) \
      ((mp1_mmhub_int_status & MP1_MMHUB_INT_STATUS_RD_ERROR_MASK) >> MP1_MMHUB_INT_STATUS_RD_ERROR_SHIFT)
#define MP1_MMHUB_INT_STATUS_GET_WR_ERROR(mp1_mmhub_int_status) \
      ((mp1_mmhub_int_status & MP1_MMHUB_INT_STATUS_WR_ERROR_MASK) >> MP1_MMHUB_INT_STATUS_WR_ERROR_SHIFT)
#define MP1_MMHUB_INT_STATUS_GET_REG_ERROR(mp1_mmhub_int_status) \
      ((mp1_mmhub_int_status & MP1_MMHUB_INT_STATUS_REG_ERROR_MASK) >> MP1_MMHUB_INT_STATUS_REG_ERROR_SHIFT)

#define MP1_MMHUB_INT_STATUS_SET_RD_ERROR(mp1_mmhub_int_status_reg, rd_error) \
      mp1_mmhub_int_status_reg = (mp1_mmhub_int_status_reg & ~MP1_MMHUB_INT_STATUS_RD_ERROR_MASK) | (rd_error << MP1_MMHUB_INT_STATUS_RD_ERROR_SHIFT)
#define MP1_MMHUB_INT_STATUS_SET_WR_ERROR(mp1_mmhub_int_status_reg, wr_error) \
      mp1_mmhub_int_status_reg = (mp1_mmhub_int_status_reg & ~MP1_MMHUB_INT_STATUS_WR_ERROR_MASK) | (wr_error << MP1_MMHUB_INT_STATUS_WR_ERROR_SHIFT)
#define MP1_MMHUB_INT_STATUS_SET_REG_ERROR(mp1_mmhub_int_status_reg, reg_error) \
      mp1_mmhub_int_status_reg = (mp1_mmhub_int_status_reg & ~MP1_MMHUB_INT_STATUS_REG_ERROR_MASK) | (reg_error << MP1_MMHUB_INT_STATUS_REG_ERROR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_int_status_t {
            unsigned int rd_error                       : MP1_MMHUB_INT_STATUS_RD_ERROR_SIZE;
            unsigned int wr_error                       : MP1_MMHUB_INT_STATUS_WR_ERROR_SIZE;
            unsigned int reg_error                      : MP1_MMHUB_INT_STATUS_REG_ERROR_SIZE;
            unsigned int                                : 29;
      } mp1_mmhub_int_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_int_status_t {
            unsigned int                                : 29;
            unsigned int reg_error                      : MP1_MMHUB_INT_STATUS_REG_ERROR_SIZE;
            unsigned int wr_error                       : MP1_MMHUB_INT_STATUS_WR_ERROR_SIZE;
            unsigned int rd_error                       : MP1_MMHUB_INT_STATUS_RD_ERROR_SIZE;
      } mp1_mmhub_int_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_int_status_t f;
} mp1_mmhub_int_status_u;


/*
 * MP1_MMHUB_WR_INT_ADDR struct
 */

#define MP1_MMHUB_WR_INT_ADDR_REG_SIZE         32
#define MP1_MMHUB_WR_INT_ADDR_ADDR_SIZE  32

#define MP1_MMHUB_WR_INT_ADDR_ADDR_SHIFT  0

#define MP1_MMHUB_WR_INT_ADDR_ADDR_MASK  0xffffffff

#define MP1_MMHUB_WR_INT_ADDR_MASK \
      (MP1_MMHUB_WR_INT_ADDR_ADDR_MASK)

#define MP1_MMHUB_WR_INT_ADDR_DEFAULT  0x00000000

#define MP1_MMHUB_WR_INT_ADDR_GET_ADDR(mp1_mmhub_wr_int_addr) \
      ((mp1_mmhub_wr_int_addr & MP1_MMHUB_WR_INT_ADDR_ADDR_MASK) >> MP1_MMHUB_WR_INT_ADDR_ADDR_SHIFT)

#define MP1_MMHUB_WR_INT_ADDR_SET_ADDR(mp1_mmhub_wr_int_addr_reg, addr) \
      mp1_mmhub_wr_int_addr_reg = (mp1_mmhub_wr_int_addr_reg & ~MP1_MMHUB_WR_INT_ADDR_ADDR_MASK) | (addr << MP1_MMHUB_WR_INT_ADDR_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_wr_int_addr_t {
            unsigned int addr                           : MP1_MMHUB_WR_INT_ADDR_ADDR_SIZE;
      } mp1_mmhub_wr_int_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_wr_int_addr_t {
            unsigned int addr                           : MP1_MMHUB_WR_INT_ADDR_ADDR_SIZE;
      } mp1_mmhub_wr_int_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_wr_int_addr_t f;
} mp1_mmhub_wr_int_addr_u;


/*
 * MP1_MMHUB_WR_INT_ID struct
 */

#define MP1_MMHUB_WR_INT_ID_REG_SIZE         32
#define MP1_MMHUB_WR_INT_ID_AXI_ID_SIZE  21

#define MP1_MMHUB_WR_INT_ID_AXI_ID_SHIFT  0

#define MP1_MMHUB_WR_INT_ID_AXI_ID_MASK  0x001fffff

#define MP1_MMHUB_WR_INT_ID_MASK \
      (MP1_MMHUB_WR_INT_ID_AXI_ID_MASK)

#define MP1_MMHUB_WR_INT_ID_DEFAULT    0x00000000

#define MP1_MMHUB_WR_INT_ID_GET_AXI_ID(mp1_mmhub_wr_int_id) \
      ((mp1_mmhub_wr_int_id & MP1_MMHUB_WR_INT_ID_AXI_ID_MASK) >> MP1_MMHUB_WR_INT_ID_AXI_ID_SHIFT)

#define MP1_MMHUB_WR_INT_ID_SET_AXI_ID(mp1_mmhub_wr_int_id_reg, axi_id) \
      mp1_mmhub_wr_int_id_reg = (mp1_mmhub_wr_int_id_reg & ~MP1_MMHUB_WR_INT_ID_AXI_ID_MASK) | (axi_id << MP1_MMHUB_WR_INT_ID_AXI_ID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_wr_int_id_t {
            unsigned int axi_id                         : MP1_MMHUB_WR_INT_ID_AXI_ID_SIZE;
            unsigned int                                : 11;
      } mp1_mmhub_wr_int_id_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_wr_int_id_t {
            unsigned int                                : 11;
            unsigned int axi_id                         : MP1_MMHUB_WR_INT_ID_AXI_ID_SIZE;
      } mp1_mmhub_wr_int_id_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_wr_int_id_t f;
} mp1_mmhub_wr_int_id_u;


/*
 * MP1_MMHUB_MISC_CTRL struct
 */

#define MP1_MMHUB_MISC_CTRL_REG_SIZE         32
#define MP1_MMHUB_MISC_CTRL_CLK_GATE_EN_SIZE  1
#define MP1_MMHUB_MISC_CTRL_REG_CLK_STS_SIZE  1

#define MP1_MMHUB_MISC_CTRL_CLK_GATE_EN_SHIFT  0
#define MP1_MMHUB_MISC_CTRL_REG_CLK_STS_SHIFT  8

#define MP1_MMHUB_MISC_CTRL_CLK_GATE_EN_MASK  0x00000001
#define MP1_MMHUB_MISC_CTRL_REG_CLK_STS_MASK  0x00000100

#define MP1_MMHUB_MISC_CTRL_MASK \
      (MP1_MMHUB_MISC_CTRL_CLK_GATE_EN_MASK | \
      MP1_MMHUB_MISC_CTRL_REG_CLK_STS_MASK)

#define MP1_MMHUB_MISC_CTRL_DEFAULT    0x00000101

#define MP1_MMHUB_MISC_CTRL_GET_CLK_GATE_EN(mp1_mmhub_misc_ctrl) \
      ((mp1_mmhub_misc_ctrl & MP1_MMHUB_MISC_CTRL_CLK_GATE_EN_MASK) >> MP1_MMHUB_MISC_CTRL_CLK_GATE_EN_SHIFT)
#define MP1_MMHUB_MISC_CTRL_GET_REG_CLK_STS(mp1_mmhub_misc_ctrl) \
      ((mp1_mmhub_misc_ctrl & MP1_MMHUB_MISC_CTRL_REG_CLK_STS_MASK) >> MP1_MMHUB_MISC_CTRL_REG_CLK_STS_SHIFT)

#define MP1_MMHUB_MISC_CTRL_SET_CLK_GATE_EN(mp1_mmhub_misc_ctrl_reg, clk_gate_en) \
      mp1_mmhub_misc_ctrl_reg = (mp1_mmhub_misc_ctrl_reg & ~MP1_MMHUB_MISC_CTRL_CLK_GATE_EN_MASK) | (clk_gate_en << MP1_MMHUB_MISC_CTRL_CLK_GATE_EN_SHIFT)
#define MP1_MMHUB_MISC_CTRL_SET_REG_CLK_STS(mp1_mmhub_misc_ctrl_reg, reg_clk_sts) \
      mp1_mmhub_misc_ctrl_reg = (mp1_mmhub_misc_ctrl_reg & ~MP1_MMHUB_MISC_CTRL_REG_CLK_STS_MASK) | (reg_clk_sts << MP1_MMHUB_MISC_CTRL_REG_CLK_STS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_misc_ctrl_t {
            unsigned int clk_gate_en                    : MP1_MMHUB_MISC_CTRL_CLK_GATE_EN_SIZE;
            unsigned int                                : 7;
            unsigned int reg_clk_sts                    : MP1_MMHUB_MISC_CTRL_REG_CLK_STS_SIZE;
            unsigned int                                : 23;
      } mp1_mmhub_misc_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_misc_ctrl_t {
            unsigned int                                : 23;
            unsigned int reg_clk_sts                    : MP1_MMHUB_MISC_CTRL_REG_CLK_STS_SIZE;
            unsigned int                                : 7;
            unsigned int clk_gate_en                    : MP1_MMHUB_MISC_CTRL_CLK_GATE_EN_SIZE;
      } mp1_mmhub_misc_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_misc_ctrl_t f;
} mp1_mmhub_misc_ctrl_u;


/*
 * MP1_MMHUB_WR_INT_OTHER struct
 */

#define MP1_MMHUB_WR_INT_OTHER_REG_SIZE         32
#define MP1_MMHUB_WR_INT_OTHER_ERROR_TLB_SIZE  1
#define MP1_MMHUB_WR_INT_OTHER_ERROR_PAGE_SIZE  1
#define MP1_MMHUB_WR_INT_OTHER_ERROR_ATTRIB_SIZE  1
#define MP1_MMHUB_WR_INT_OTHER_ERROR_PROT_SIZE  1
#define MP1_MMHUB_WR_INT_OTHER_ERROR_MST_SIZE  1
#define MP1_MMHUB_WR_INT_OTHER_INT_CLEAR_SIZE  1

#define MP1_MMHUB_WR_INT_OTHER_ERROR_TLB_SHIFT  0
#define MP1_MMHUB_WR_INT_OTHER_ERROR_PAGE_SHIFT  1
#define MP1_MMHUB_WR_INT_OTHER_ERROR_ATTRIB_SHIFT  2
#define MP1_MMHUB_WR_INT_OTHER_ERROR_PROT_SHIFT  3
#define MP1_MMHUB_WR_INT_OTHER_ERROR_MST_SHIFT  4
#define MP1_MMHUB_WR_INT_OTHER_INT_CLEAR_SHIFT  31

#define MP1_MMHUB_WR_INT_OTHER_ERROR_TLB_MASK  0x00000001
#define MP1_MMHUB_WR_INT_OTHER_ERROR_PAGE_MASK  0x00000002
#define MP1_MMHUB_WR_INT_OTHER_ERROR_ATTRIB_MASK  0x00000004
#define MP1_MMHUB_WR_INT_OTHER_ERROR_PROT_MASK  0x00000008
#define MP1_MMHUB_WR_INT_OTHER_ERROR_MST_MASK  0x00000010
#define MP1_MMHUB_WR_INT_OTHER_INT_CLEAR_MASK  0x80000000

#define MP1_MMHUB_WR_INT_OTHER_MASK \
      (MP1_MMHUB_WR_INT_OTHER_ERROR_TLB_MASK | \
      MP1_MMHUB_WR_INT_OTHER_ERROR_PAGE_MASK | \
      MP1_MMHUB_WR_INT_OTHER_ERROR_ATTRIB_MASK | \
      MP1_MMHUB_WR_INT_OTHER_ERROR_PROT_MASK | \
      MP1_MMHUB_WR_INT_OTHER_ERROR_MST_MASK | \
      MP1_MMHUB_WR_INT_OTHER_INT_CLEAR_MASK)

#define MP1_MMHUB_WR_INT_OTHER_DEFAULT 0x00000000

#define MP1_MMHUB_WR_INT_OTHER_GET_ERROR_TLB(mp1_mmhub_wr_int_other) \
      ((mp1_mmhub_wr_int_other & MP1_MMHUB_WR_INT_OTHER_ERROR_TLB_MASK) >> MP1_MMHUB_WR_INT_OTHER_ERROR_TLB_SHIFT)
#define MP1_MMHUB_WR_INT_OTHER_GET_ERROR_PAGE(mp1_mmhub_wr_int_other) \
      ((mp1_mmhub_wr_int_other & MP1_MMHUB_WR_INT_OTHER_ERROR_PAGE_MASK) >> MP1_MMHUB_WR_INT_OTHER_ERROR_PAGE_SHIFT)
#define MP1_MMHUB_WR_INT_OTHER_GET_ERROR_ATTRIB(mp1_mmhub_wr_int_other) \
      ((mp1_mmhub_wr_int_other & MP1_MMHUB_WR_INT_OTHER_ERROR_ATTRIB_MASK) >> MP1_MMHUB_WR_INT_OTHER_ERROR_ATTRIB_SHIFT)
#define MP1_MMHUB_WR_INT_OTHER_GET_ERROR_PROT(mp1_mmhub_wr_int_other) \
      ((mp1_mmhub_wr_int_other & MP1_MMHUB_WR_INT_OTHER_ERROR_PROT_MASK) >> MP1_MMHUB_WR_INT_OTHER_ERROR_PROT_SHIFT)
#define MP1_MMHUB_WR_INT_OTHER_GET_ERROR_MST(mp1_mmhub_wr_int_other) \
      ((mp1_mmhub_wr_int_other & MP1_MMHUB_WR_INT_OTHER_ERROR_MST_MASK) >> MP1_MMHUB_WR_INT_OTHER_ERROR_MST_SHIFT)
#define MP1_MMHUB_WR_INT_OTHER_GET_INT_CLEAR(mp1_mmhub_wr_int_other) \
      ((mp1_mmhub_wr_int_other & MP1_MMHUB_WR_INT_OTHER_INT_CLEAR_MASK) >> MP1_MMHUB_WR_INT_OTHER_INT_CLEAR_SHIFT)

#define MP1_MMHUB_WR_INT_OTHER_SET_ERROR_TLB(mp1_mmhub_wr_int_other_reg, error_tlb) \
      mp1_mmhub_wr_int_other_reg = (mp1_mmhub_wr_int_other_reg & ~MP1_MMHUB_WR_INT_OTHER_ERROR_TLB_MASK) | (error_tlb << MP1_MMHUB_WR_INT_OTHER_ERROR_TLB_SHIFT)
#define MP1_MMHUB_WR_INT_OTHER_SET_ERROR_PAGE(mp1_mmhub_wr_int_other_reg, error_page) \
      mp1_mmhub_wr_int_other_reg = (mp1_mmhub_wr_int_other_reg & ~MP1_MMHUB_WR_INT_OTHER_ERROR_PAGE_MASK) | (error_page << MP1_MMHUB_WR_INT_OTHER_ERROR_PAGE_SHIFT)
#define MP1_MMHUB_WR_INT_OTHER_SET_ERROR_ATTRIB(mp1_mmhub_wr_int_other_reg, error_attrib) \
      mp1_mmhub_wr_int_other_reg = (mp1_mmhub_wr_int_other_reg & ~MP1_MMHUB_WR_INT_OTHER_ERROR_ATTRIB_MASK) | (error_attrib << MP1_MMHUB_WR_INT_OTHER_ERROR_ATTRIB_SHIFT)
#define MP1_MMHUB_WR_INT_OTHER_SET_ERROR_PROT(mp1_mmhub_wr_int_other_reg, error_prot) \
      mp1_mmhub_wr_int_other_reg = (mp1_mmhub_wr_int_other_reg & ~MP1_MMHUB_WR_INT_OTHER_ERROR_PROT_MASK) | (error_prot << MP1_MMHUB_WR_INT_OTHER_ERROR_PROT_SHIFT)
#define MP1_MMHUB_WR_INT_OTHER_SET_ERROR_MST(mp1_mmhub_wr_int_other_reg, error_mst) \
      mp1_mmhub_wr_int_other_reg = (mp1_mmhub_wr_int_other_reg & ~MP1_MMHUB_WR_INT_OTHER_ERROR_MST_MASK) | (error_mst << MP1_MMHUB_WR_INT_OTHER_ERROR_MST_SHIFT)
#define MP1_MMHUB_WR_INT_OTHER_SET_INT_CLEAR(mp1_mmhub_wr_int_other_reg, int_clear) \
      mp1_mmhub_wr_int_other_reg = (mp1_mmhub_wr_int_other_reg & ~MP1_MMHUB_WR_INT_OTHER_INT_CLEAR_MASK) | (int_clear << MP1_MMHUB_WR_INT_OTHER_INT_CLEAR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_wr_int_other_t {
            unsigned int error_tlb                      : MP1_MMHUB_WR_INT_OTHER_ERROR_TLB_SIZE;
            unsigned int error_page                     : MP1_MMHUB_WR_INT_OTHER_ERROR_PAGE_SIZE;
            unsigned int error_attrib                   : MP1_MMHUB_WR_INT_OTHER_ERROR_ATTRIB_SIZE;
            unsigned int error_prot                     : MP1_MMHUB_WR_INT_OTHER_ERROR_PROT_SIZE;
            unsigned int error_mst                      : MP1_MMHUB_WR_INT_OTHER_ERROR_MST_SIZE;
            unsigned int                                : 26;
            unsigned int int_clear                      : MP1_MMHUB_WR_INT_OTHER_INT_CLEAR_SIZE;
      } mp1_mmhub_wr_int_other_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_wr_int_other_t {
            unsigned int int_clear                      : MP1_MMHUB_WR_INT_OTHER_INT_CLEAR_SIZE;
            unsigned int                                : 26;
            unsigned int error_mst                      : MP1_MMHUB_WR_INT_OTHER_ERROR_MST_SIZE;
            unsigned int error_prot                     : MP1_MMHUB_WR_INT_OTHER_ERROR_PROT_SIZE;
            unsigned int error_attrib                   : MP1_MMHUB_WR_INT_OTHER_ERROR_ATTRIB_SIZE;
            unsigned int error_page                     : MP1_MMHUB_WR_INT_OTHER_ERROR_PAGE_SIZE;
            unsigned int error_tlb                      : MP1_MMHUB_WR_INT_OTHER_ERROR_TLB_SIZE;
      } mp1_mmhub_wr_int_other_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_wr_int_other_t f;
} mp1_mmhub_wr_int_other_u;


/*
 * MP1_MMHUB_RD_INT_ADDR struct
 */

#define MP1_MMHUB_RD_INT_ADDR_REG_SIZE         32
#define MP1_MMHUB_RD_INT_ADDR_ADDR_SIZE  32

#define MP1_MMHUB_RD_INT_ADDR_ADDR_SHIFT  0

#define MP1_MMHUB_RD_INT_ADDR_ADDR_MASK  0xffffffff

#define MP1_MMHUB_RD_INT_ADDR_MASK \
      (MP1_MMHUB_RD_INT_ADDR_ADDR_MASK)

#define MP1_MMHUB_RD_INT_ADDR_DEFAULT  0x00000000

#define MP1_MMHUB_RD_INT_ADDR_GET_ADDR(mp1_mmhub_rd_int_addr) \
      ((mp1_mmhub_rd_int_addr & MP1_MMHUB_RD_INT_ADDR_ADDR_MASK) >> MP1_MMHUB_RD_INT_ADDR_ADDR_SHIFT)

#define MP1_MMHUB_RD_INT_ADDR_SET_ADDR(mp1_mmhub_rd_int_addr_reg, addr) \
      mp1_mmhub_rd_int_addr_reg = (mp1_mmhub_rd_int_addr_reg & ~MP1_MMHUB_RD_INT_ADDR_ADDR_MASK) | (addr << MP1_MMHUB_RD_INT_ADDR_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_rd_int_addr_t {
            unsigned int addr                           : MP1_MMHUB_RD_INT_ADDR_ADDR_SIZE;
      } mp1_mmhub_rd_int_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_rd_int_addr_t {
            unsigned int addr                           : MP1_MMHUB_RD_INT_ADDR_ADDR_SIZE;
      } mp1_mmhub_rd_int_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_rd_int_addr_t f;
} mp1_mmhub_rd_int_addr_u;


/*
 * MP1_MMHUB_RD_INT_ID struct
 */

#define MP1_MMHUB_RD_INT_ID_REG_SIZE         32
#define MP1_MMHUB_RD_INT_ID_AXI_ID_SIZE  21

#define MP1_MMHUB_RD_INT_ID_AXI_ID_SHIFT  0

#define MP1_MMHUB_RD_INT_ID_AXI_ID_MASK  0x001fffff

#define MP1_MMHUB_RD_INT_ID_MASK \
      (MP1_MMHUB_RD_INT_ID_AXI_ID_MASK)

#define MP1_MMHUB_RD_INT_ID_DEFAULT    0x00000000

#define MP1_MMHUB_RD_INT_ID_GET_AXI_ID(mp1_mmhub_rd_int_id) \
      ((mp1_mmhub_rd_int_id & MP1_MMHUB_RD_INT_ID_AXI_ID_MASK) >> MP1_MMHUB_RD_INT_ID_AXI_ID_SHIFT)

#define MP1_MMHUB_RD_INT_ID_SET_AXI_ID(mp1_mmhub_rd_int_id_reg, axi_id) \
      mp1_mmhub_rd_int_id_reg = (mp1_mmhub_rd_int_id_reg & ~MP1_MMHUB_RD_INT_ID_AXI_ID_MASK) | (axi_id << MP1_MMHUB_RD_INT_ID_AXI_ID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_rd_int_id_t {
            unsigned int axi_id                         : MP1_MMHUB_RD_INT_ID_AXI_ID_SIZE;
            unsigned int                                : 11;
      } mp1_mmhub_rd_int_id_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_rd_int_id_t {
            unsigned int                                : 11;
            unsigned int axi_id                         : MP1_MMHUB_RD_INT_ID_AXI_ID_SIZE;
      } mp1_mmhub_rd_int_id_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_rd_int_id_t f;
} mp1_mmhub_rd_int_id_u;


/*
 * MP1_MMHUB_RD_INT_OTHER struct
 */

#define MP1_MMHUB_RD_INT_OTHER_REG_SIZE         32
#define MP1_MMHUB_RD_INT_OTHER_ERROR_TLB_SIZE  1
#define MP1_MMHUB_RD_INT_OTHER_ERROR_PAGE_SIZE  1
#define MP1_MMHUB_RD_INT_OTHER_ERROR_ATTRIB_SIZE  1
#define MP1_MMHUB_RD_INT_OTHER_ERROR_PROT_SIZE  1
#define MP1_MMHUB_RD_INT_OTHER_ERROR_MST_SIZE  1
#define MP1_MMHUB_RD_INT_OTHER_ERROR_LENGTH_SIZE  1
#define MP1_MMHUB_RD_INT_OTHER_INT_CLEAR_SIZE  1

#define MP1_MMHUB_RD_INT_OTHER_ERROR_TLB_SHIFT  0
#define MP1_MMHUB_RD_INT_OTHER_ERROR_PAGE_SHIFT  1
#define MP1_MMHUB_RD_INT_OTHER_ERROR_ATTRIB_SHIFT  2
#define MP1_MMHUB_RD_INT_OTHER_ERROR_PROT_SHIFT  3
#define MP1_MMHUB_RD_INT_OTHER_ERROR_MST_SHIFT  4
#define MP1_MMHUB_RD_INT_OTHER_ERROR_LENGTH_SHIFT  6
#define MP1_MMHUB_RD_INT_OTHER_INT_CLEAR_SHIFT  31

#define MP1_MMHUB_RD_INT_OTHER_ERROR_TLB_MASK  0x00000001
#define MP1_MMHUB_RD_INT_OTHER_ERROR_PAGE_MASK  0x00000002
#define MP1_MMHUB_RD_INT_OTHER_ERROR_ATTRIB_MASK  0x00000004
#define MP1_MMHUB_RD_INT_OTHER_ERROR_PROT_MASK  0x00000008
#define MP1_MMHUB_RD_INT_OTHER_ERROR_MST_MASK  0x00000010
#define MP1_MMHUB_RD_INT_OTHER_ERROR_LENGTH_MASK  0x00000040
#define MP1_MMHUB_RD_INT_OTHER_INT_CLEAR_MASK  0x80000000

#define MP1_MMHUB_RD_INT_OTHER_MASK \
      (MP1_MMHUB_RD_INT_OTHER_ERROR_TLB_MASK | \
      MP1_MMHUB_RD_INT_OTHER_ERROR_PAGE_MASK | \
      MP1_MMHUB_RD_INT_OTHER_ERROR_ATTRIB_MASK | \
      MP1_MMHUB_RD_INT_OTHER_ERROR_PROT_MASK | \
      MP1_MMHUB_RD_INT_OTHER_ERROR_MST_MASK | \
      MP1_MMHUB_RD_INT_OTHER_ERROR_LENGTH_MASK | \
      MP1_MMHUB_RD_INT_OTHER_INT_CLEAR_MASK)

#define MP1_MMHUB_RD_INT_OTHER_DEFAULT 0x00000000

#define MP1_MMHUB_RD_INT_OTHER_GET_ERROR_TLB(mp1_mmhub_rd_int_other) \
      ((mp1_mmhub_rd_int_other & MP1_MMHUB_RD_INT_OTHER_ERROR_TLB_MASK) >> MP1_MMHUB_RD_INT_OTHER_ERROR_TLB_SHIFT)
#define MP1_MMHUB_RD_INT_OTHER_GET_ERROR_PAGE(mp1_mmhub_rd_int_other) \
      ((mp1_mmhub_rd_int_other & MP1_MMHUB_RD_INT_OTHER_ERROR_PAGE_MASK) >> MP1_MMHUB_RD_INT_OTHER_ERROR_PAGE_SHIFT)
#define MP1_MMHUB_RD_INT_OTHER_GET_ERROR_ATTRIB(mp1_mmhub_rd_int_other) \
      ((mp1_mmhub_rd_int_other & MP1_MMHUB_RD_INT_OTHER_ERROR_ATTRIB_MASK) >> MP1_MMHUB_RD_INT_OTHER_ERROR_ATTRIB_SHIFT)
#define MP1_MMHUB_RD_INT_OTHER_GET_ERROR_PROT(mp1_mmhub_rd_int_other) \
      ((mp1_mmhub_rd_int_other & MP1_MMHUB_RD_INT_OTHER_ERROR_PROT_MASK) >> MP1_MMHUB_RD_INT_OTHER_ERROR_PROT_SHIFT)
#define MP1_MMHUB_RD_INT_OTHER_GET_ERROR_MST(mp1_mmhub_rd_int_other) \
      ((mp1_mmhub_rd_int_other & MP1_MMHUB_RD_INT_OTHER_ERROR_MST_MASK) >> MP1_MMHUB_RD_INT_OTHER_ERROR_MST_SHIFT)
#define MP1_MMHUB_RD_INT_OTHER_GET_ERROR_LENGTH(mp1_mmhub_rd_int_other) \
      ((mp1_mmhub_rd_int_other & MP1_MMHUB_RD_INT_OTHER_ERROR_LENGTH_MASK) >> MP1_MMHUB_RD_INT_OTHER_ERROR_LENGTH_SHIFT)
#define MP1_MMHUB_RD_INT_OTHER_GET_INT_CLEAR(mp1_mmhub_rd_int_other) \
      ((mp1_mmhub_rd_int_other & MP1_MMHUB_RD_INT_OTHER_INT_CLEAR_MASK) >> MP1_MMHUB_RD_INT_OTHER_INT_CLEAR_SHIFT)

#define MP1_MMHUB_RD_INT_OTHER_SET_ERROR_TLB(mp1_mmhub_rd_int_other_reg, error_tlb) \
      mp1_mmhub_rd_int_other_reg = (mp1_mmhub_rd_int_other_reg & ~MP1_MMHUB_RD_INT_OTHER_ERROR_TLB_MASK) | (error_tlb << MP1_MMHUB_RD_INT_OTHER_ERROR_TLB_SHIFT)
#define MP1_MMHUB_RD_INT_OTHER_SET_ERROR_PAGE(mp1_mmhub_rd_int_other_reg, error_page) \
      mp1_mmhub_rd_int_other_reg = (mp1_mmhub_rd_int_other_reg & ~MP1_MMHUB_RD_INT_OTHER_ERROR_PAGE_MASK) | (error_page << MP1_MMHUB_RD_INT_OTHER_ERROR_PAGE_SHIFT)
#define MP1_MMHUB_RD_INT_OTHER_SET_ERROR_ATTRIB(mp1_mmhub_rd_int_other_reg, error_attrib) \
      mp1_mmhub_rd_int_other_reg = (mp1_mmhub_rd_int_other_reg & ~MP1_MMHUB_RD_INT_OTHER_ERROR_ATTRIB_MASK) | (error_attrib << MP1_MMHUB_RD_INT_OTHER_ERROR_ATTRIB_SHIFT)
#define MP1_MMHUB_RD_INT_OTHER_SET_ERROR_PROT(mp1_mmhub_rd_int_other_reg, error_prot) \
      mp1_mmhub_rd_int_other_reg = (mp1_mmhub_rd_int_other_reg & ~MP1_MMHUB_RD_INT_OTHER_ERROR_PROT_MASK) | (error_prot << MP1_MMHUB_RD_INT_OTHER_ERROR_PROT_SHIFT)
#define MP1_MMHUB_RD_INT_OTHER_SET_ERROR_MST(mp1_mmhub_rd_int_other_reg, error_mst) \
      mp1_mmhub_rd_int_other_reg = (mp1_mmhub_rd_int_other_reg & ~MP1_MMHUB_RD_INT_OTHER_ERROR_MST_MASK) | (error_mst << MP1_MMHUB_RD_INT_OTHER_ERROR_MST_SHIFT)
#define MP1_MMHUB_RD_INT_OTHER_SET_ERROR_LENGTH(mp1_mmhub_rd_int_other_reg, error_length) \
      mp1_mmhub_rd_int_other_reg = (mp1_mmhub_rd_int_other_reg & ~MP1_MMHUB_RD_INT_OTHER_ERROR_LENGTH_MASK) | (error_length << MP1_MMHUB_RD_INT_OTHER_ERROR_LENGTH_SHIFT)
#define MP1_MMHUB_RD_INT_OTHER_SET_INT_CLEAR(mp1_mmhub_rd_int_other_reg, int_clear) \
      mp1_mmhub_rd_int_other_reg = (mp1_mmhub_rd_int_other_reg & ~MP1_MMHUB_RD_INT_OTHER_INT_CLEAR_MASK) | (int_clear << MP1_MMHUB_RD_INT_OTHER_INT_CLEAR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_rd_int_other_t {
            unsigned int error_tlb                      : MP1_MMHUB_RD_INT_OTHER_ERROR_TLB_SIZE;
            unsigned int error_page                     : MP1_MMHUB_RD_INT_OTHER_ERROR_PAGE_SIZE;
            unsigned int error_attrib                   : MP1_MMHUB_RD_INT_OTHER_ERROR_ATTRIB_SIZE;
            unsigned int error_prot                     : MP1_MMHUB_RD_INT_OTHER_ERROR_PROT_SIZE;
            unsigned int error_mst                      : MP1_MMHUB_RD_INT_OTHER_ERROR_MST_SIZE;
            unsigned int                                : 1;
            unsigned int error_length                   : MP1_MMHUB_RD_INT_OTHER_ERROR_LENGTH_SIZE;
            unsigned int                                : 24;
            unsigned int int_clear                      : MP1_MMHUB_RD_INT_OTHER_INT_CLEAR_SIZE;
      } mp1_mmhub_rd_int_other_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_rd_int_other_t {
            unsigned int int_clear                      : MP1_MMHUB_RD_INT_OTHER_INT_CLEAR_SIZE;
            unsigned int                                : 24;
            unsigned int error_length                   : MP1_MMHUB_RD_INT_OTHER_ERROR_LENGTH_SIZE;
            unsigned int                                : 1;
            unsigned int error_mst                      : MP1_MMHUB_RD_INT_OTHER_ERROR_MST_SIZE;
            unsigned int error_prot                     : MP1_MMHUB_RD_INT_OTHER_ERROR_PROT_SIZE;
            unsigned int error_attrib                   : MP1_MMHUB_RD_INT_OTHER_ERROR_ATTRIB_SIZE;
            unsigned int error_page                     : MP1_MMHUB_RD_INT_OTHER_ERROR_PAGE_SIZE;
            unsigned int error_tlb                      : MP1_MMHUB_RD_INT_OTHER_ERROR_TLB_SIZE;
      } mp1_mmhub_rd_int_other_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_rd_int_other_t f;
} mp1_mmhub_rd_int_other_u;


/*
 * MP1_MMHUB_REG_INT_ADDR struct
 */

#define MP1_MMHUB_REG_INT_ADDR_REG_SIZE         32
#define MP1_MMHUB_REG_INT_ADDR_ADDR_SIZE  16

#define MP1_MMHUB_REG_INT_ADDR_ADDR_SHIFT  0

#define MP1_MMHUB_REG_INT_ADDR_ADDR_MASK  0x0000ffff

#define MP1_MMHUB_REG_INT_ADDR_MASK \
      (MP1_MMHUB_REG_INT_ADDR_ADDR_MASK)

#define MP1_MMHUB_REG_INT_ADDR_DEFAULT 0x00000000

#define MP1_MMHUB_REG_INT_ADDR_GET_ADDR(mp1_mmhub_reg_int_addr) \
      ((mp1_mmhub_reg_int_addr & MP1_MMHUB_REG_INT_ADDR_ADDR_MASK) >> MP1_MMHUB_REG_INT_ADDR_ADDR_SHIFT)

#define MP1_MMHUB_REG_INT_ADDR_SET_ADDR(mp1_mmhub_reg_int_addr_reg, addr) \
      mp1_mmhub_reg_int_addr_reg = (mp1_mmhub_reg_int_addr_reg & ~MP1_MMHUB_REG_INT_ADDR_ADDR_MASK) | (addr << MP1_MMHUB_REG_INT_ADDR_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_reg_int_addr_t {
            unsigned int addr                           : MP1_MMHUB_REG_INT_ADDR_ADDR_SIZE;
            unsigned int                                : 16;
      } mp1_mmhub_reg_int_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_reg_int_addr_t {
            unsigned int                                : 16;
            unsigned int addr                           : MP1_MMHUB_REG_INT_ADDR_ADDR_SIZE;
      } mp1_mmhub_reg_int_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_reg_int_addr_t f;
} mp1_mmhub_reg_int_addr_u;


/*
 * MP1_MMHUB_REG_INT_ID struct
 */

#define MP1_MMHUB_REG_INT_ID_REG_SIZE         32
#define MP1_MMHUB_REG_INT_ID_AXI_ID_SIZE  21

#define MP1_MMHUB_REG_INT_ID_AXI_ID_SHIFT  0

#define MP1_MMHUB_REG_INT_ID_AXI_ID_MASK  0x001fffff

#define MP1_MMHUB_REG_INT_ID_MASK \
      (MP1_MMHUB_REG_INT_ID_AXI_ID_MASK)

#define MP1_MMHUB_REG_INT_ID_DEFAULT   0x00000000

#define MP1_MMHUB_REG_INT_ID_GET_AXI_ID(mp1_mmhub_reg_int_id) \
      ((mp1_mmhub_reg_int_id & MP1_MMHUB_REG_INT_ID_AXI_ID_MASK) >> MP1_MMHUB_REG_INT_ID_AXI_ID_SHIFT)

#define MP1_MMHUB_REG_INT_ID_SET_AXI_ID(mp1_mmhub_reg_int_id_reg, axi_id) \
      mp1_mmhub_reg_int_id_reg = (mp1_mmhub_reg_int_id_reg & ~MP1_MMHUB_REG_INT_ID_AXI_ID_MASK) | (axi_id << MP1_MMHUB_REG_INT_ID_AXI_ID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_reg_int_id_t {
            unsigned int axi_id                         : MP1_MMHUB_REG_INT_ID_AXI_ID_SIZE;
            unsigned int                                : 11;
      } mp1_mmhub_reg_int_id_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_reg_int_id_t {
            unsigned int                                : 11;
            unsigned int axi_id                         : MP1_MMHUB_REG_INT_ID_AXI_ID_SIZE;
      } mp1_mmhub_reg_int_id_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_reg_int_id_t f;
} mp1_mmhub_reg_int_id_u;


/*
 * MP1_MMHUB_REG_INT_OTHER struct
 */

#define MP1_MMHUB_REG_INT_OTHER_REG_SIZE         32
#define MP1_MMHUB_REG_INT_OTHER_ERROR_MST_SIZE  1
#define MP1_MMHUB_REG_INT_OTHER_ERROR_ADDR_SIZE  1
#define MP1_MMHUB_REG_INT_OTHER_ERROR_PROT_SIZE  1
#define MP1_MMHUB_REG_INT_OTHER_ERROR_GPU_VA_SIZE  1
#define MP1_MMHUB_REG_INT_OTHER_ERROR_BYPASS_SIZE  1
#define MP1_MMHUB_REG_INT_OTHER_ERROR_REQIO_SIZE  1
#define MP1_MMHUB_REG_INT_OTHER_INT_CLEAR_SIZE  1

#define MP1_MMHUB_REG_INT_OTHER_ERROR_MST_SHIFT  1
#define MP1_MMHUB_REG_INT_OTHER_ERROR_ADDR_SHIFT  2
#define MP1_MMHUB_REG_INT_OTHER_ERROR_PROT_SHIFT  3
#define MP1_MMHUB_REG_INT_OTHER_ERROR_GPU_VA_SHIFT  5
#define MP1_MMHUB_REG_INT_OTHER_ERROR_BYPASS_SHIFT  6
#define MP1_MMHUB_REG_INT_OTHER_ERROR_REQIO_SHIFT  7
#define MP1_MMHUB_REG_INT_OTHER_INT_CLEAR_SHIFT  31

#define MP1_MMHUB_REG_INT_OTHER_ERROR_MST_MASK  0x00000002
#define MP1_MMHUB_REG_INT_OTHER_ERROR_ADDR_MASK  0x00000004
#define MP1_MMHUB_REG_INT_OTHER_ERROR_PROT_MASK  0x00000008
#define MP1_MMHUB_REG_INT_OTHER_ERROR_GPU_VA_MASK  0x00000020
#define MP1_MMHUB_REG_INT_OTHER_ERROR_BYPASS_MASK  0x00000040
#define MP1_MMHUB_REG_INT_OTHER_ERROR_REQIO_MASK  0x00000080
#define MP1_MMHUB_REG_INT_OTHER_INT_CLEAR_MASK  0x80000000

#define MP1_MMHUB_REG_INT_OTHER_MASK \
      (MP1_MMHUB_REG_INT_OTHER_ERROR_MST_MASK | \
      MP1_MMHUB_REG_INT_OTHER_ERROR_ADDR_MASK | \
      MP1_MMHUB_REG_INT_OTHER_ERROR_PROT_MASK | \
      MP1_MMHUB_REG_INT_OTHER_ERROR_GPU_VA_MASK | \
      MP1_MMHUB_REG_INT_OTHER_ERROR_BYPASS_MASK | \
      MP1_MMHUB_REG_INT_OTHER_ERROR_REQIO_MASK | \
      MP1_MMHUB_REG_INT_OTHER_INT_CLEAR_MASK)

#define MP1_MMHUB_REG_INT_OTHER_DEFAULT 0x00000000

#define MP1_MMHUB_REG_INT_OTHER_GET_ERROR_MST(mp1_mmhub_reg_int_other) \
      ((mp1_mmhub_reg_int_other & MP1_MMHUB_REG_INT_OTHER_ERROR_MST_MASK) >> MP1_MMHUB_REG_INT_OTHER_ERROR_MST_SHIFT)
#define MP1_MMHUB_REG_INT_OTHER_GET_ERROR_ADDR(mp1_mmhub_reg_int_other) \
      ((mp1_mmhub_reg_int_other & MP1_MMHUB_REG_INT_OTHER_ERROR_ADDR_MASK) >> MP1_MMHUB_REG_INT_OTHER_ERROR_ADDR_SHIFT)
#define MP1_MMHUB_REG_INT_OTHER_GET_ERROR_PROT(mp1_mmhub_reg_int_other) \
      ((mp1_mmhub_reg_int_other & MP1_MMHUB_REG_INT_OTHER_ERROR_PROT_MASK) >> MP1_MMHUB_REG_INT_OTHER_ERROR_PROT_SHIFT)
#define MP1_MMHUB_REG_INT_OTHER_GET_ERROR_GPU_VA(mp1_mmhub_reg_int_other) \
      ((mp1_mmhub_reg_int_other & MP1_MMHUB_REG_INT_OTHER_ERROR_GPU_VA_MASK) >> MP1_MMHUB_REG_INT_OTHER_ERROR_GPU_VA_SHIFT)
#define MP1_MMHUB_REG_INT_OTHER_GET_ERROR_BYPASS(mp1_mmhub_reg_int_other) \
      ((mp1_mmhub_reg_int_other & MP1_MMHUB_REG_INT_OTHER_ERROR_BYPASS_MASK) >> MP1_MMHUB_REG_INT_OTHER_ERROR_BYPASS_SHIFT)
#define MP1_MMHUB_REG_INT_OTHER_GET_ERROR_REQIO(mp1_mmhub_reg_int_other) \
      ((mp1_mmhub_reg_int_other & MP1_MMHUB_REG_INT_OTHER_ERROR_REQIO_MASK) >> MP1_MMHUB_REG_INT_OTHER_ERROR_REQIO_SHIFT)
#define MP1_MMHUB_REG_INT_OTHER_GET_INT_CLEAR(mp1_mmhub_reg_int_other) \
      ((mp1_mmhub_reg_int_other & MP1_MMHUB_REG_INT_OTHER_INT_CLEAR_MASK) >> MP1_MMHUB_REG_INT_OTHER_INT_CLEAR_SHIFT)

#define MP1_MMHUB_REG_INT_OTHER_SET_ERROR_MST(mp1_mmhub_reg_int_other_reg, error_mst) \
      mp1_mmhub_reg_int_other_reg = (mp1_mmhub_reg_int_other_reg & ~MP1_MMHUB_REG_INT_OTHER_ERROR_MST_MASK) | (error_mst << MP1_MMHUB_REG_INT_OTHER_ERROR_MST_SHIFT)
#define MP1_MMHUB_REG_INT_OTHER_SET_ERROR_ADDR(mp1_mmhub_reg_int_other_reg, error_addr) \
      mp1_mmhub_reg_int_other_reg = (mp1_mmhub_reg_int_other_reg & ~MP1_MMHUB_REG_INT_OTHER_ERROR_ADDR_MASK) | (error_addr << MP1_MMHUB_REG_INT_OTHER_ERROR_ADDR_SHIFT)
#define MP1_MMHUB_REG_INT_OTHER_SET_ERROR_PROT(mp1_mmhub_reg_int_other_reg, error_prot) \
      mp1_mmhub_reg_int_other_reg = (mp1_mmhub_reg_int_other_reg & ~MP1_MMHUB_REG_INT_OTHER_ERROR_PROT_MASK) | (error_prot << MP1_MMHUB_REG_INT_OTHER_ERROR_PROT_SHIFT)
#define MP1_MMHUB_REG_INT_OTHER_SET_ERROR_GPU_VA(mp1_mmhub_reg_int_other_reg, error_gpu_va) \
      mp1_mmhub_reg_int_other_reg = (mp1_mmhub_reg_int_other_reg & ~MP1_MMHUB_REG_INT_OTHER_ERROR_GPU_VA_MASK) | (error_gpu_va << MP1_MMHUB_REG_INT_OTHER_ERROR_GPU_VA_SHIFT)
#define MP1_MMHUB_REG_INT_OTHER_SET_ERROR_BYPASS(mp1_mmhub_reg_int_other_reg, error_bypass) \
      mp1_mmhub_reg_int_other_reg = (mp1_mmhub_reg_int_other_reg & ~MP1_MMHUB_REG_INT_OTHER_ERROR_BYPASS_MASK) | (error_bypass << MP1_MMHUB_REG_INT_OTHER_ERROR_BYPASS_SHIFT)
#define MP1_MMHUB_REG_INT_OTHER_SET_ERROR_REQIO(mp1_mmhub_reg_int_other_reg, error_reqio) \
      mp1_mmhub_reg_int_other_reg = (mp1_mmhub_reg_int_other_reg & ~MP1_MMHUB_REG_INT_OTHER_ERROR_REQIO_MASK) | (error_reqio << MP1_MMHUB_REG_INT_OTHER_ERROR_REQIO_SHIFT)
#define MP1_MMHUB_REG_INT_OTHER_SET_INT_CLEAR(mp1_mmhub_reg_int_other_reg, int_clear) \
      mp1_mmhub_reg_int_other_reg = (mp1_mmhub_reg_int_other_reg & ~MP1_MMHUB_REG_INT_OTHER_INT_CLEAR_MASK) | (int_clear << MP1_MMHUB_REG_INT_OTHER_INT_CLEAR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_reg_int_other_t {
            unsigned int                                : 1;
            unsigned int error_mst                      : MP1_MMHUB_REG_INT_OTHER_ERROR_MST_SIZE;
            unsigned int error_addr                     : MP1_MMHUB_REG_INT_OTHER_ERROR_ADDR_SIZE;
            unsigned int error_prot                     : MP1_MMHUB_REG_INT_OTHER_ERROR_PROT_SIZE;
            unsigned int                                : 1;
            unsigned int error_gpu_va                   : MP1_MMHUB_REG_INT_OTHER_ERROR_GPU_VA_SIZE;
            unsigned int error_bypass                   : MP1_MMHUB_REG_INT_OTHER_ERROR_BYPASS_SIZE;
            unsigned int error_reqio                    : MP1_MMHUB_REG_INT_OTHER_ERROR_REQIO_SIZE;
            unsigned int                                : 23;
            unsigned int int_clear                      : MP1_MMHUB_REG_INT_OTHER_INT_CLEAR_SIZE;
      } mp1_mmhub_reg_int_other_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_reg_int_other_t {
            unsigned int int_clear                      : MP1_MMHUB_REG_INT_OTHER_INT_CLEAR_SIZE;
            unsigned int                                : 23;
            unsigned int error_reqio                    : MP1_MMHUB_REG_INT_OTHER_ERROR_REQIO_SIZE;
            unsigned int error_bypass                   : MP1_MMHUB_REG_INT_OTHER_ERROR_BYPASS_SIZE;
            unsigned int error_gpu_va                   : MP1_MMHUB_REG_INT_OTHER_ERROR_GPU_VA_SIZE;
            unsigned int                                : 1;
            unsigned int error_prot                     : MP1_MMHUB_REG_INT_OTHER_ERROR_PROT_SIZE;
            unsigned int error_addr                     : MP1_MMHUB_REG_INT_OTHER_ERROR_ADDR_SIZE;
            unsigned int error_mst                      : MP1_MMHUB_REG_INT_OTHER_ERROR_MST_SIZE;
            unsigned int                                : 1;
      } mp1_mmhub_reg_int_other_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_reg_int_other_t f;
} mp1_mmhub_reg_int_other_u;


/*
 * MP1_MMHUB_AXCACHE_CFG struct
 */

#define MP1_MMHUB_AXCACHE_CFG_REG_SIZE         32
#define MP1_MMHUB_AXCACHE_CFG_ARCACHE_NONCOH_SIZE  4
#define MP1_MMHUB_AXCACHE_CFG_ARCACHE_COH_SIZE  4
#define MP1_MMHUB_AXCACHE_CFG_AWCACHE_NONCOH_SIZE  4
#define MP1_MMHUB_AXCACHE_CFG_AWCACHE_COH_SIZE  4
#define MP1_MMHUB_AXCACHE_CFG_QOSW_SIZE  4
#define MP1_MMHUB_AXCACHE_CFG_QOSR_SIZE  4

#define MP1_MMHUB_AXCACHE_CFG_ARCACHE_NONCOH_SHIFT  0
#define MP1_MMHUB_AXCACHE_CFG_ARCACHE_COH_SHIFT  4
#define MP1_MMHUB_AXCACHE_CFG_AWCACHE_NONCOH_SHIFT  8
#define MP1_MMHUB_AXCACHE_CFG_AWCACHE_COH_SHIFT  12
#define MP1_MMHUB_AXCACHE_CFG_QOSW_SHIFT  16
#define MP1_MMHUB_AXCACHE_CFG_QOSR_SHIFT  20

#define MP1_MMHUB_AXCACHE_CFG_ARCACHE_NONCOH_MASK  0x0000000f
#define MP1_MMHUB_AXCACHE_CFG_ARCACHE_COH_MASK  0x000000f0
#define MP1_MMHUB_AXCACHE_CFG_AWCACHE_NONCOH_MASK  0x00000f00
#define MP1_MMHUB_AXCACHE_CFG_AWCACHE_COH_MASK  0x0000f000
#define MP1_MMHUB_AXCACHE_CFG_QOSW_MASK  0x000f0000
#define MP1_MMHUB_AXCACHE_CFG_QOSR_MASK  0x00f00000

#define MP1_MMHUB_AXCACHE_CFG_MASK \
      (MP1_MMHUB_AXCACHE_CFG_ARCACHE_NONCOH_MASK | \
      MP1_MMHUB_AXCACHE_CFG_ARCACHE_COH_MASK | \
      MP1_MMHUB_AXCACHE_CFG_AWCACHE_NONCOH_MASK | \
      MP1_MMHUB_AXCACHE_CFG_AWCACHE_COH_MASK | \
      MP1_MMHUB_AXCACHE_CFG_QOSW_MASK | \
      MP1_MMHUB_AXCACHE_CFG_QOSR_MASK)

#define MP1_MMHUB_AXCACHE_CFG_DEFAULT  0x000073b3

#define MP1_MMHUB_AXCACHE_CFG_GET_ARCACHE_NONCOH(mp1_mmhub_axcache_cfg) \
      ((mp1_mmhub_axcache_cfg & MP1_MMHUB_AXCACHE_CFG_ARCACHE_NONCOH_MASK) >> MP1_MMHUB_AXCACHE_CFG_ARCACHE_NONCOH_SHIFT)
#define MP1_MMHUB_AXCACHE_CFG_GET_ARCACHE_COH(mp1_mmhub_axcache_cfg) \
      ((mp1_mmhub_axcache_cfg & MP1_MMHUB_AXCACHE_CFG_ARCACHE_COH_MASK) >> MP1_MMHUB_AXCACHE_CFG_ARCACHE_COH_SHIFT)
#define MP1_MMHUB_AXCACHE_CFG_GET_AWCACHE_NONCOH(mp1_mmhub_axcache_cfg) \
      ((mp1_mmhub_axcache_cfg & MP1_MMHUB_AXCACHE_CFG_AWCACHE_NONCOH_MASK) >> MP1_MMHUB_AXCACHE_CFG_AWCACHE_NONCOH_SHIFT)
#define MP1_MMHUB_AXCACHE_CFG_GET_AWCACHE_COH(mp1_mmhub_axcache_cfg) \
      ((mp1_mmhub_axcache_cfg & MP1_MMHUB_AXCACHE_CFG_AWCACHE_COH_MASK) >> MP1_MMHUB_AXCACHE_CFG_AWCACHE_COH_SHIFT)
#define MP1_MMHUB_AXCACHE_CFG_GET_QOSW(mp1_mmhub_axcache_cfg) \
      ((mp1_mmhub_axcache_cfg & MP1_MMHUB_AXCACHE_CFG_QOSW_MASK) >> MP1_MMHUB_AXCACHE_CFG_QOSW_SHIFT)
#define MP1_MMHUB_AXCACHE_CFG_GET_QOSR(mp1_mmhub_axcache_cfg) \
      ((mp1_mmhub_axcache_cfg & MP1_MMHUB_AXCACHE_CFG_QOSR_MASK) >> MP1_MMHUB_AXCACHE_CFG_QOSR_SHIFT)

#define MP1_MMHUB_AXCACHE_CFG_SET_ARCACHE_NONCOH(mp1_mmhub_axcache_cfg_reg, arcache_noncoh) \
      mp1_mmhub_axcache_cfg_reg = (mp1_mmhub_axcache_cfg_reg & ~MP1_MMHUB_AXCACHE_CFG_ARCACHE_NONCOH_MASK) | (arcache_noncoh << MP1_MMHUB_AXCACHE_CFG_ARCACHE_NONCOH_SHIFT)
#define MP1_MMHUB_AXCACHE_CFG_SET_ARCACHE_COH(mp1_mmhub_axcache_cfg_reg, arcache_coh) \
      mp1_mmhub_axcache_cfg_reg = (mp1_mmhub_axcache_cfg_reg & ~MP1_MMHUB_AXCACHE_CFG_ARCACHE_COH_MASK) | (arcache_coh << MP1_MMHUB_AXCACHE_CFG_ARCACHE_COH_SHIFT)
#define MP1_MMHUB_AXCACHE_CFG_SET_AWCACHE_NONCOH(mp1_mmhub_axcache_cfg_reg, awcache_noncoh) \
      mp1_mmhub_axcache_cfg_reg = (mp1_mmhub_axcache_cfg_reg & ~MP1_MMHUB_AXCACHE_CFG_AWCACHE_NONCOH_MASK) | (awcache_noncoh << MP1_MMHUB_AXCACHE_CFG_AWCACHE_NONCOH_SHIFT)
#define MP1_MMHUB_AXCACHE_CFG_SET_AWCACHE_COH(mp1_mmhub_axcache_cfg_reg, awcache_coh) \
      mp1_mmhub_axcache_cfg_reg = (mp1_mmhub_axcache_cfg_reg & ~MP1_MMHUB_AXCACHE_CFG_AWCACHE_COH_MASK) | (awcache_coh << MP1_MMHUB_AXCACHE_CFG_AWCACHE_COH_SHIFT)
#define MP1_MMHUB_AXCACHE_CFG_SET_QOSW(mp1_mmhub_axcache_cfg_reg, qosw) \
      mp1_mmhub_axcache_cfg_reg = (mp1_mmhub_axcache_cfg_reg & ~MP1_MMHUB_AXCACHE_CFG_QOSW_MASK) | (qosw << MP1_MMHUB_AXCACHE_CFG_QOSW_SHIFT)
#define MP1_MMHUB_AXCACHE_CFG_SET_QOSR(mp1_mmhub_axcache_cfg_reg, qosr) \
      mp1_mmhub_axcache_cfg_reg = (mp1_mmhub_axcache_cfg_reg & ~MP1_MMHUB_AXCACHE_CFG_QOSR_MASK) | (qosr << MP1_MMHUB_AXCACHE_CFG_QOSR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_axcache_cfg_t {
            unsigned int arcache_noncoh                 : MP1_MMHUB_AXCACHE_CFG_ARCACHE_NONCOH_SIZE;
            unsigned int arcache_coh                    : MP1_MMHUB_AXCACHE_CFG_ARCACHE_COH_SIZE;
            unsigned int awcache_noncoh                 : MP1_MMHUB_AXCACHE_CFG_AWCACHE_NONCOH_SIZE;
            unsigned int awcache_coh                    : MP1_MMHUB_AXCACHE_CFG_AWCACHE_COH_SIZE;
            unsigned int qosw                           : MP1_MMHUB_AXCACHE_CFG_QOSW_SIZE;
            unsigned int qosr                           : MP1_MMHUB_AXCACHE_CFG_QOSR_SIZE;
            unsigned int                                : 8;
      } mp1_mmhub_axcache_cfg_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_axcache_cfg_t {
            unsigned int                                : 8;
            unsigned int qosr                           : MP1_MMHUB_AXCACHE_CFG_QOSR_SIZE;
            unsigned int qosw                           : MP1_MMHUB_AXCACHE_CFG_QOSW_SIZE;
            unsigned int awcache_coh                    : MP1_MMHUB_AXCACHE_CFG_AWCACHE_COH_SIZE;
            unsigned int awcache_noncoh                 : MP1_MMHUB_AXCACHE_CFG_AWCACHE_NONCOH_SIZE;
            unsigned int arcache_coh                    : MP1_MMHUB_AXCACHE_CFG_ARCACHE_COH_SIZE;
            unsigned int arcache_noncoh                 : MP1_MMHUB_AXCACHE_CFG_ARCACHE_NONCOH_SIZE;
      } mp1_mmhub_axcache_cfg_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_axcache_cfg_t f;
} mp1_mmhub_axcache_cfg_u;


/*
 * MP1_MMHUB_OUTSTANDING_WR struct
 */

#define MP1_MMHUB_OUTSTANDING_WR_REG_SIZE         32
#define MP1_MMHUB_OUTSTANDING_WR_PENDING_WR_SIZE  32

#define MP1_MMHUB_OUTSTANDING_WR_PENDING_WR_SHIFT  0

#define MP1_MMHUB_OUTSTANDING_WR_PENDING_WR_MASK  0xffffffff

#define MP1_MMHUB_OUTSTANDING_WR_MASK \
      (MP1_MMHUB_OUTSTANDING_WR_PENDING_WR_MASK)

#define MP1_MMHUB_OUTSTANDING_WR_DEFAULT 0x00000000

#define MP1_MMHUB_OUTSTANDING_WR_GET_PENDING_WR(mp1_mmhub_outstanding_wr) \
      ((mp1_mmhub_outstanding_wr & MP1_MMHUB_OUTSTANDING_WR_PENDING_WR_MASK) >> MP1_MMHUB_OUTSTANDING_WR_PENDING_WR_SHIFT)

#define MP1_MMHUB_OUTSTANDING_WR_SET_PENDING_WR(mp1_mmhub_outstanding_wr_reg, pending_wr) \
      mp1_mmhub_outstanding_wr_reg = (mp1_mmhub_outstanding_wr_reg & ~MP1_MMHUB_OUTSTANDING_WR_PENDING_WR_MASK) | (pending_wr << MP1_MMHUB_OUTSTANDING_WR_PENDING_WR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_outstanding_wr_t {
            unsigned int pending_wr                     : MP1_MMHUB_OUTSTANDING_WR_PENDING_WR_SIZE;
      } mp1_mmhub_outstanding_wr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_outstanding_wr_t {
            unsigned int pending_wr                     : MP1_MMHUB_OUTSTANDING_WR_PENDING_WR_SIZE;
      } mp1_mmhub_outstanding_wr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_outstanding_wr_t f;
} mp1_mmhub_outstanding_wr_u;


/*
 * MP1_MMHUB_OUTSTANDING_RD struct
 */

#define MP1_MMHUB_OUTSTANDING_RD_REG_SIZE         32
#define MP1_MMHUB_OUTSTANDING_RD_PENDING_RD_SIZE  32

#define MP1_MMHUB_OUTSTANDING_RD_PENDING_RD_SHIFT  0

#define MP1_MMHUB_OUTSTANDING_RD_PENDING_RD_MASK  0xffffffff

#define MP1_MMHUB_OUTSTANDING_RD_MASK \
      (MP1_MMHUB_OUTSTANDING_RD_PENDING_RD_MASK)

#define MP1_MMHUB_OUTSTANDING_RD_DEFAULT 0x00000000

#define MP1_MMHUB_OUTSTANDING_RD_GET_PENDING_RD(mp1_mmhub_outstanding_rd) \
      ((mp1_mmhub_outstanding_rd & MP1_MMHUB_OUTSTANDING_RD_PENDING_RD_MASK) >> MP1_MMHUB_OUTSTANDING_RD_PENDING_RD_SHIFT)

#define MP1_MMHUB_OUTSTANDING_RD_SET_PENDING_RD(mp1_mmhub_outstanding_rd_reg, pending_rd) \
      mp1_mmhub_outstanding_rd_reg = (mp1_mmhub_outstanding_rd_reg & ~MP1_MMHUB_OUTSTANDING_RD_PENDING_RD_MASK) | (pending_rd << MP1_MMHUB_OUTSTANDING_RD_PENDING_RD_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_outstanding_rd_t {
            unsigned int pending_rd                     : MP1_MMHUB_OUTSTANDING_RD_PENDING_RD_SIZE;
      } mp1_mmhub_outstanding_rd_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_outstanding_rd_t {
            unsigned int pending_rd                     : MP1_MMHUB_OUTSTANDING_RD_PENDING_RD_SIZE;
      } mp1_mmhub_outstanding_rd_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_outstanding_rd_t f;
} mp1_mmhub_outstanding_rd_u;


/*
 * MP1_MMHUB_AWUSER_MASK struct
 */

#define MP1_MMHUB_AWUSER_MASK_REG_SIZE         32
#define MP1_MMHUB_AWUSER_MASK_AWUSER_MASK_SIZE  32

#define MP1_MMHUB_AWUSER_MASK_AWUSER_MASK_SHIFT  0

#define MP1_MMHUB_AWUSER_MASK_AWUSER_MASK_MASK  0xffffffff

#define MP1_MMHUB_AWUSER_MASK_MASK \
      (MP1_MMHUB_AWUSER_MASK_AWUSER_MASK_MASK)

#define MP1_MMHUB_AWUSER_MASK_DEFAULT  0x00000000

#define MP1_MMHUB_AWUSER_MASK_GET_AWUSER_MASK(mp1_mmhub_awuser_mask) \
      ((mp1_mmhub_awuser_mask & MP1_MMHUB_AWUSER_MASK_AWUSER_MASK_MASK) >> MP1_MMHUB_AWUSER_MASK_AWUSER_MASK_SHIFT)

#define MP1_MMHUB_AWUSER_MASK_SET_AWUSER_MASK(mp1_mmhub_awuser_mask_reg, awuser_mask) \
      mp1_mmhub_awuser_mask_reg = (mp1_mmhub_awuser_mask_reg & ~MP1_MMHUB_AWUSER_MASK_AWUSER_MASK_MASK) | (awuser_mask << MP1_MMHUB_AWUSER_MASK_AWUSER_MASK_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_awuser_mask_t {
            unsigned int awuser_mask                    : MP1_MMHUB_AWUSER_MASK_AWUSER_MASK_SIZE;
      } mp1_mmhub_awuser_mask_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_awuser_mask_t {
            unsigned int awuser_mask                    : MP1_MMHUB_AWUSER_MASK_AWUSER_MASK_SIZE;
      } mp1_mmhub_awuser_mask_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_awuser_mask_t f;
} mp1_mmhub_awuser_mask_u;


/*
 * MP1_MMHUB_AWUSER_VALUE struct
 */

#define MP1_MMHUB_AWUSER_VALUE_REG_SIZE         32
#define MP1_MMHUB_AWUSER_VALUE_AWUSER_VALUE_SIZE  32

#define MP1_MMHUB_AWUSER_VALUE_AWUSER_VALUE_SHIFT  0

#define MP1_MMHUB_AWUSER_VALUE_AWUSER_VALUE_MASK  0xffffffff

#define MP1_MMHUB_AWUSER_VALUE_MASK \
      (MP1_MMHUB_AWUSER_VALUE_AWUSER_VALUE_MASK)

#define MP1_MMHUB_AWUSER_VALUE_DEFAULT 0x00000000

#define MP1_MMHUB_AWUSER_VALUE_GET_AWUSER_VALUE(mp1_mmhub_awuser_value) \
      ((mp1_mmhub_awuser_value & MP1_MMHUB_AWUSER_VALUE_AWUSER_VALUE_MASK) >> MP1_MMHUB_AWUSER_VALUE_AWUSER_VALUE_SHIFT)

#define MP1_MMHUB_AWUSER_VALUE_SET_AWUSER_VALUE(mp1_mmhub_awuser_value_reg, awuser_value) \
      mp1_mmhub_awuser_value_reg = (mp1_mmhub_awuser_value_reg & ~MP1_MMHUB_AWUSER_VALUE_AWUSER_VALUE_MASK) | (awuser_value << MP1_MMHUB_AWUSER_VALUE_AWUSER_VALUE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_awuser_value_t {
            unsigned int awuser_value                   : MP1_MMHUB_AWUSER_VALUE_AWUSER_VALUE_SIZE;
      } mp1_mmhub_awuser_value_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_awuser_value_t {
            unsigned int awuser_value                   : MP1_MMHUB_AWUSER_VALUE_AWUSER_VALUE_SIZE;
      } mp1_mmhub_awuser_value_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_awuser_value_t f;
} mp1_mmhub_awuser_value_u;


/*
 * MP1_MMHUB_ARUSER_MASK struct
 */

#define MP1_MMHUB_ARUSER_MASK_REG_SIZE         32
#define MP1_MMHUB_ARUSER_MASK_ARUSER_MASK_SIZE  32

#define MP1_MMHUB_ARUSER_MASK_ARUSER_MASK_SHIFT  0

#define MP1_MMHUB_ARUSER_MASK_ARUSER_MASK_MASK  0xffffffff

#define MP1_MMHUB_ARUSER_MASK_MASK \
      (MP1_MMHUB_ARUSER_MASK_ARUSER_MASK_MASK)

#define MP1_MMHUB_ARUSER_MASK_DEFAULT  0x00000000

#define MP1_MMHUB_ARUSER_MASK_GET_ARUSER_MASK(mp1_mmhub_aruser_mask) \
      ((mp1_mmhub_aruser_mask & MP1_MMHUB_ARUSER_MASK_ARUSER_MASK_MASK) >> MP1_MMHUB_ARUSER_MASK_ARUSER_MASK_SHIFT)

#define MP1_MMHUB_ARUSER_MASK_SET_ARUSER_MASK(mp1_mmhub_aruser_mask_reg, aruser_mask) \
      mp1_mmhub_aruser_mask_reg = (mp1_mmhub_aruser_mask_reg & ~MP1_MMHUB_ARUSER_MASK_ARUSER_MASK_MASK) | (aruser_mask << MP1_MMHUB_ARUSER_MASK_ARUSER_MASK_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_aruser_mask_t {
            unsigned int aruser_mask                    : MP1_MMHUB_ARUSER_MASK_ARUSER_MASK_SIZE;
      } mp1_mmhub_aruser_mask_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_aruser_mask_t {
            unsigned int aruser_mask                    : MP1_MMHUB_ARUSER_MASK_ARUSER_MASK_SIZE;
      } mp1_mmhub_aruser_mask_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_aruser_mask_t f;
} mp1_mmhub_aruser_mask_u;


/*
 * MP1_MMHUB_ARUSER_VALUE struct
 */

#define MP1_MMHUB_ARUSER_VALUE_REG_SIZE         32
#define MP1_MMHUB_ARUSER_VALUE_ARUSER_VALUE_SIZE  32

#define MP1_MMHUB_ARUSER_VALUE_ARUSER_VALUE_SHIFT  0

#define MP1_MMHUB_ARUSER_VALUE_ARUSER_VALUE_MASK  0xffffffff

#define MP1_MMHUB_ARUSER_VALUE_MASK \
      (MP1_MMHUB_ARUSER_VALUE_ARUSER_VALUE_MASK)

#define MP1_MMHUB_ARUSER_VALUE_DEFAULT 0x00000000

#define MP1_MMHUB_ARUSER_VALUE_GET_ARUSER_VALUE(mp1_mmhub_aruser_value) \
      ((mp1_mmhub_aruser_value & MP1_MMHUB_ARUSER_VALUE_ARUSER_VALUE_MASK) >> MP1_MMHUB_ARUSER_VALUE_ARUSER_VALUE_SHIFT)

#define MP1_MMHUB_ARUSER_VALUE_SET_ARUSER_VALUE(mp1_mmhub_aruser_value_reg, aruser_value) \
      mp1_mmhub_aruser_value_reg = (mp1_mmhub_aruser_value_reg & ~MP1_MMHUB_ARUSER_VALUE_ARUSER_VALUE_MASK) | (aruser_value << MP1_MMHUB_ARUSER_VALUE_ARUSER_VALUE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_aruser_value_t {
            unsigned int aruser_value                   : MP1_MMHUB_ARUSER_VALUE_ARUSER_VALUE_SIZE;
      } mp1_mmhub_aruser_value_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_aruser_value_t {
            unsigned int aruser_value                   : MP1_MMHUB_ARUSER_VALUE_ARUSER_VALUE_SIZE;
      } mp1_mmhub_aruser_value_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_aruser_value_t f;
} mp1_mmhub_aruser_value_u;


/*
 * MP1_MMHUB_BRESP_MASK_CTRL struct
 */

#define MP1_MMHUB_BRESP_MASK_CTRL_REG_SIZE         32
#define MP1_MMHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_SIZE  2
#define MP1_MMHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_SIZE  1
#define MP1_MMHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_SIZE  1

#define MP1_MMHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_SHIFT  0
#define MP1_MMHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_SHIFT  2
#define MP1_MMHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_SHIFT  3

#define MP1_MMHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_MASK  0x00000003
#define MP1_MMHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_MASK  0x00000004
#define MP1_MMHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_MASK  0x00000008

#define MP1_MMHUB_BRESP_MASK_CTRL_MASK \
      (MP1_MMHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_MASK | \
      MP1_MMHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_MASK | \
      MP1_MMHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_MASK)

#define MP1_MMHUB_BRESP_MASK_CTRL_DEFAULT 0x00000000

#define MP1_MMHUB_BRESP_MASK_CTRL_GET_MASK_BRESP_ERROR(mp1_mmhub_bresp_mask_ctrl) \
      ((mp1_mmhub_bresp_mask_ctrl & MP1_MMHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_MASK) >> MP1_MMHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_SHIFT)
#define MP1_MMHUB_BRESP_MASK_CTRL_GET_WR_RESP_INT_TRIG_EN(mp1_mmhub_bresp_mask_ctrl) \
      ((mp1_mmhub_bresp_mask_ctrl & MP1_MMHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_MASK) >> MP1_MMHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_SHIFT)
#define MP1_MMHUB_BRESP_MASK_CTRL_GET_CLR_AXI_WR_ERR_CNT(mp1_mmhub_bresp_mask_ctrl) \
      ((mp1_mmhub_bresp_mask_ctrl & MP1_MMHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_MASK) >> MP1_MMHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_SHIFT)

#define MP1_MMHUB_BRESP_MASK_CTRL_SET_MASK_BRESP_ERROR(mp1_mmhub_bresp_mask_ctrl_reg, mask_bresp_error) \
      mp1_mmhub_bresp_mask_ctrl_reg = (mp1_mmhub_bresp_mask_ctrl_reg & ~MP1_MMHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_MASK) | (mask_bresp_error << MP1_MMHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_SHIFT)
#define MP1_MMHUB_BRESP_MASK_CTRL_SET_WR_RESP_INT_TRIG_EN(mp1_mmhub_bresp_mask_ctrl_reg, wr_resp_int_trig_en) \
      mp1_mmhub_bresp_mask_ctrl_reg = (mp1_mmhub_bresp_mask_ctrl_reg & ~MP1_MMHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_MASK) | (wr_resp_int_trig_en << MP1_MMHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_SHIFT)
#define MP1_MMHUB_BRESP_MASK_CTRL_SET_CLR_AXI_WR_ERR_CNT(mp1_mmhub_bresp_mask_ctrl_reg, clr_axi_wr_err_cnt) \
      mp1_mmhub_bresp_mask_ctrl_reg = (mp1_mmhub_bresp_mask_ctrl_reg & ~MP1_MMHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_MASK) | (clr_axi_wr_err_cnt << MP1_MMHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_bresp_mask_ctrl_t {
            unsigned int mask_bresp_error               : MP1_MMHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_SIZE;
            unsigned int wr_resp_int_trig_en            : MP1_MMHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_SIZE;
            unsigned int clr_axi_wr_err_cnt             : MP1_MMHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_SIZE;
            unsigned int                                : 28;
      } mp1_mmhub_bresp_mask_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_bresp_mask_ctrl_t {
            unsigned int                                : 28;
            unsigned int clr_axi_wr_err_cnt             : MP1_MMHUB_BRESP_MASK_CTRL_CLR_AXI_WR_ERR_CNT_SIZE;
            unsigned int wr_resp_int_trig_en            : MP1_MMHUB_BRESP_MASK_CTRL_WR_RESP_INT_TRIG_EN_SIZE;
            unsigned int mask_bresp_error               : MP1_MMHUB_BRESP_MASK_CTRL_MASK_BRESP_ERROR_SIZE;
      } mp1_mmhub_bresp_mask_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_bresp_mask_ctrl_t f;
} mp1_mmhub_bresp_mask_ctrl_u;


/*
 * MP1_MMHUB_AXI_WR_ERR_CNT struct
 */

#define MP1_MMHUB_AXI_WR_ERR_CNT_REG_SIZE         32
#define MP1_MMHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_SIZE  32

#define MP1_MMHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_SHIFT  0

#define MP1_MMHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_MASK  0xffffffff

#define MP1_MMHUB_AXI_WR_ERR_CNT_MASK \
      (MP1_MMHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_MASK)

#define MP1_MMHUB_AXI_WR_ERR_CNT_DEFAULT 0x00000000

#define MP1_MMHUB_AXI_WR_ERR_CNT_GET_AXI_WR_ERR_CNT(mp1_mmhub_axi_wr_err_cnt) \
      ((mp1_mmhub_axi_wr_err_cnt & MP1_MMHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_MASK) >> MP1_MMHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_SHIFT)

#define MP1_MMHUB_AXI_WR_ERR_CNT_SET_AXI_WR_ERR_CNT(mp1_mmhub_axi_wr_err_cnt_reg, axi_wr_err_cnt) \
      mp1_mmhub_axi_wr_err_cnt_reg = (mp1_mmhub_axi_wr_err_cnt_reg & ~MP1_MMHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_MASK) | (axi_wr_err_cnt << MP1_MMHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_axi_wr_err_cnt_t {
            unsigned int axi_wr_err_cnt                 : MP1_MMHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_SIZE;
      } mp1_mmhub_axi_wr_err_cnt_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_axi_wr_err_cnt_t {
            unsigned int axi_wr_err_cnt                 : MP1_MMHUB_AXI_WR_ERR_CNT_AXI_WR_ERR_CNT_SIZE;
      } mp1_mmhub_axi_wr_err_cnt_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_axi_wr_err_cnt_t f;
} mp1_mmhub_axi_wr_err_cnt_u;


/*
 * MP1_MMHUB_RRESP_MASK_CTRL struct
 */

#define MP1_MMHUB_RRESP_MASK_CTRL_REG_SIZE         32
#define MP1_MMHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_SIZE  2
#define MP1_MMHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_SIZE  1
#define MP1_MMHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_SIZE  1

#define MP1_MMHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_SHIFT  0
#define MP1_MMHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_SHIFT  2
#define MP1_MMHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_SHIFT  3

#define MP1_MMHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_MASK  0x00000003
#define MP1_MMHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_MASK  0x00000004
#define MP1_MMHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_MASK  0x00000008

#define MP1_MMHUB_RRESP_MASK_CTRL_MASK \
      (MP1_MMHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_MASK | \
      MP1_MMHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_MASK | \
      MP1_MMHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_MASK)

#define MP1_MMHUB_RRESP_MASK_CTRL_DEFAULT 0x00000000

#define MP1_MMHUB_RRESP_MASK_CTRL_GET_MASK_RRESP_ERROR(mp1_mmhub_rresp_mask_ctrl) \
      ((mp1_mmhub_rresp_mask_ctrl & MP1_MMHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_MASK) >> MP1_MMHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_SHIFT)
#define MP1_MMHUB_RRESP_MASK_CTRL_GET_RD_RESP_INT_TRIG_EN(mp1_mmhub_rresp_mask_ctrl) \
      ((mp1_mmhub_rresp_mask_ctrl & MP1_MMHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_MASK) >> MP1_MMHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_SHIFT)
#define MP1_MMHUB_RRESP_MASK_CTRL_GET_CLR_AXI_RD_ERR_CNT(mp1_mmhub_rresp_mask_ctrl) \
      ((mp1_mmhub_rresp_mask_ctrl & MP1_MMHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_MASK) >> MP1_MMHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_SHIFT)

#define MP1_MMHUB_RRESP_MASK_CTRL_SET_MASK_RRESP_ERROR(mp1_mmhub_rresp_mask_ctrl_reg, mask_rresp_error) \
      mp1_mmhub_rresp_mask_ctrl_reg = (mp1_mmhub_rresp_mask_ctrl_reg & ~MP1_MMHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_MASK) | (mask_rresp_error << MP1_MMHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_SHIFT)
#define MP1_MMHUB_RRESP_MASK_CTRL_SET_RD_RESP_INT_TRIG_EN(mp1_mmhub_rresp_mask_ctrl_reg, rd_resp_int_trig_en) \
      mp1_mmhub_rresp_mask_ctrl_reg = (mp1_mmhub_rresp_mask_ctrl_reg & ~MP1_MMHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_MASK) | (rd_resp_int_trig_en << MP1_MMHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_SHIFT)
#define MP1_MMHUB_RRESP_MASK_CTRL_SET_CLR_AXI_RD_ERR_CNT(mp1_mmhub_rresp_mask_ctrl_reg, clr_axi_rd_err_cnt) \
      mp1_mmhub_rresp_mask_ctrl_reg = (mp1_mmhub_rresp_mask_ctrl_reg & ~MP1_MMHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_MASK) | (clr_axi_rd_err_cnt << MP1_MMHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_rresp_mask_ctrl_t {
            unsigned int mask_rresp_error               : MP1_MMHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_SIZE;
            unsigned int rd_resp_int_trig_en            : MP1_MMHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_SIZE;
            unsigned int clr_axi_rd_err_cnt             : MP1_MMHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_SIZE;
            unsigned int                                : 28;
      } mp1_mmhub_rresp_mask_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_rresp_mask_ctrl_t {
            unsigned int                                : 28;
            unsigned int clr_axi_rd_err_cnt             : MP1_MMHUB_RRESP_MASK_CTRL_CLR_AXI_RD_ERR_CNT_SIZE;
            unsigned int rd_resp_int_trig_en            : MP1_MMHUB_RRESP_MASK_CTRL_RD_RESP_INT_TRIG_EN_SIZE;
            unsigned int mask_rresp_error               : MP1_MMHUB_RRESP_MASK_CTRL_MASK_RRESP_ERROR_SIZE;
      } mp1_mmhub_rresp_mask_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_rresp_mask_ctrl_t f;
} mp1_mmhub_rresp_mask_ctrl_u;


/*
 * MP1_MMHUB_AXI_RD_ERR_CNT struct
 */

#define MP1_MMHUB_AXI_RD_ERR_CNT_REG_SIZE         32
#define MP1_MMHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_SIZE  32

#define MP1_MMHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_SHIFT  0

#define MP1_MMHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_MASK  0xffffffff

#define MP1_MMHUB_AXI_RD_ERR_CNT_MASK \
      (MP1_MMHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_MASK)

#define MP1_MMHUB_AXI_RD_ERR_CNT_DEFAULT 0x00000000

#define MP1_MMHUB_AXI_RD_ERR_CNT_GET_AXI_RD_ERR_CNT(mp1_mmhub_axi_rd_err_cnt) \
      ((mp1_mmhub_axi_rd_err_cnt & MP1_MMHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_MASK) >> MP1_MMHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_SHIFT)

#define MP1_MMHUB_AXI_RD_ERR_CNT_SET_AXI_RD_ERR_CNT(mp1_mmhub_axi_rd_err_cnt_reg, axi_rd_err_cnt) \
      mp1_mmhub_axi_rd_err_cnt_reg = (mp1_mmhub_axi_rd_err_cnt_reg & ~MP1_MMHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_MASK) | (axi_rd_err_cnt << MP1_MMHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmhub_axi_rd_err_cnt_t {
            unsigned int axi_rd_err_cnt                 : MP1_MMHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_SIZE;
      } mp1_mmhub_axi_rd_err_cnt_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmhub_axi_rd_err_cnt_t {
            unsigned int axi_rd_err_cnt                 : MP1_MMHUB_AXI_RD_ERR_CNT_AXI_RD_ERR_CNT_SIZE;
      } mp1_mmhub_axi_rd_err_cnt_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmhub_axi_rd_err_cnt_t f;
} mp1_mmhub_axi_rd_err_cnt_u;


#endif

