// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MP2_I2C_FIDDLE_H)
#define _MP2_I2C_FIDDLE_H

/*****************************************************************************************************************
 *
 *	mp2_i2c_reg.h
 *
 *	Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif


/*******************************************************
 * Values
 *******************************************************/


/*******************************************************
 * Structures
 *******************************************************/

/*
 * MP2_I2C0_IC_CON struct
 */

#define MP2_I2C0_IC_CON_REG_SIZE       32
#define MP2_I2C0_IC_CON_MASTER_MODE_SIZE 1
#define MP2_I2C0_IC_CON_SPEED_SIZE     2
#define MP2_I2C0_IC_CON_IC_10BITADDR_SLAVE_SIZE 1
#define MP2_I2C0_IC_CON_IC_10BITADDR_MASTER_SIZE 1
#define MP2_I2C0_IC_CON_IC_RESTART_EN_SIZE 1
#define MP2_I2C0_IC_CON_IC_SLAVE_DISABLE_SIZE 1
#define MP2_I2C0_IC_CON_STOP_DET_IFADDRESSED_SIZE 1
#define MP2_I2C0_IC_CON_TX_EMPTY_CTRL_SIZE 1
#define MP2_I2C0_IC_CON_RX_FIFO_FULL_HLD_CTRL_SIZE 1
#define MP2_I2C0_IC_CON_STOP_DET_IF_MASTER_ACTIVE_SIZE 1

#define MP2_I2C0_IC_CON_MASTER_MODE_SHIFT 0
#define MP2_I2C0_IC_CON_SPEED_SHIFT    1
#define MP2_I2C0_IC_CON_IC_10BITADDR_SLAVE_SHIFT 3
#define MP2_I2C0_IC_CON_IC_10BITADDR_MASTER_SHIFT 4
#define MP2_I2C0_IC_CON_IC_RESTART_EN_SHIFT 5
#define MP2_I2C0_IC_CON_IC_SLAVE_DISABLE_SHIFT 6
#define MP2_I2C0_IC_CON_STOP_DET_IFADDRESSED_SHIFT 7
#define MP2_I2C0_IC_CON_TX_EMPTY_CTRL_SHIFT 8
#define MP2_I2C0_IC_CON_RX_FIFO_FULL_HLD_CTRL_SHIFT 9
#define MP2_I2C0_IC_CON_STOP_DET_IF_MASTER_ACTIVE_SHIFT 10

#define MP2_I2C0_IC_CON_MASTER_MODE_MASK 0x1
#define MP2_I2C0_IC_CON_SPEED_MASK     0x6
#define MP2_I2C0_IC_CON_IC_10BITADDR_SLAVE_MASK 0x8
#define MP2_I2C0_IC_CON_IC_10BITADDR_MASTER_MASK 0x10
#define MP2_I2C0_IC_CON_IC_RESTART_EN_MASK 0x20
#define MP2_I2C0_IC_CON_IC_SLAVE_DISABLE_MASK 0x40
#define MP2_I2C0_IC_CON_STOP_DET_IFADDRESSED_MASK 0x80
#define MP2_I2C0_IC_CON_TX_EMPTY_CTRL_MASK 0x100
#define MP2_I2C0_IC_CON_RX_FIFO_FULL_HLD_CTRL_MASK 0x200
#define MP2_I2C0_IC_CON_STOP_DET_IF_MASTER_ACTIVE_MASK 0x400

#define MP2_I2C0_IC_CON_MASK \
     (MP2_I2C0_IC_CON_MASTER_MODE_MASK | \
      MP2_I2C0_IC_CON_SPEED_MASK | \
      MP2_I2C0_IC_CON_IC_10BITADDR_SLAVE_MASK | \
      MP2_I2C0_IC_CON_IC_10BITADDR_MASTER_MASK | \
      MP2_I2C0_IC_CON_IC_RESTART_EN_MASK | \
      MP2_I2C0_IC_CON_IC_SLAVE_DISABLE_MASK | \
      MP2_I2C0_IC_CON_STOP_DET_IFADDRESSED_MASK | \
      MP2_I2C0_IC_CON_TX_EMPTY_CTRL_MASK | \
      MP2_I2C0_IC_CON_RX_FIFO_FULL_HLD_CTRL_MASK | \
      MP2_I2C0_IC_CON_STOP_DET_IF_MASTER_ACTIVE_MASK)

#define MP2_I2C0_IC_CON_DEFAULT        0x00000000

#define MP2_I2C0_IC_CON_GET_MASTER_MODE(mp2_i2c0_ic_con) \
     ((mp2_i2c0_ic_con & MP2_I2C0_IC_CON_MASTER_MODE_MASK) >> MP2_I2C0_IC_CON_MASTER_MODE_SHIFT)
#define MP2_I2C0_IC_CON_GET_SPEED(mp2_i2c0_ic_con) \
     ((mp2_i2c0_ic_con & MP2_I2C0_IC_CON_SPEED_MASK) >> MP2_I2C0_IC_CON_SPEED_SHIFT)
#define MP2_I2C0_IC_CON_GET_IC_10BITADDR_SLAVE(mp2_i2c0_ic_con) \
     ((mp2_i2c0_ic_con & MP2_I2C0_IC_CON_IC_10BITADDR_SLAVE_MASK) >> MP2_I2C0_IC_CON_IC_10BITADDR_SLAVE_SHIFT)
#define MP2_I2C0_IC_CON_GET_IC_10BITADDR_MASTER(mp2_i2c0_ic_con) \
     ((mp2_i2c0_ic_con & MP2_I2C0_IC_CON_IC_10BITADDR_MASTER_MASK) >> MP2_I2C0_IC_CON_IC_10BITADDR_MASTER_SHIFT)
#define MP2_I2C0_IC_CON_GET_IC_RESTART_EN(mp2_i2c0_ic_con) \
     ((mp2_i2c0_ic_con & MP2_I2C0_IC_CON_IC_RESTART_EN_MASK) >> MP2_I2C0_IC_CON_IC_RESTART_EN_SHIFT)
#define MP2_I2C0_IC_CON_GET_IC_SLAVE_DISABLE(mp2_i2c0_ic_con) \
     ((mp2_i2c0_ic_con & MP2_I2C0_IC_CON_IC_SLAVE_DISABLE_MASK) >> MP2_I2C0_IC_CON_IC_SLAVE_DISABLE_SHIFT)
#define MP2_I2C0_IC_CON_GET_STOP_DET_IFADDRESSED(mp2_i2c0_ic_con) \
     ((mp2_i2c0_ic_con & MP2_I2C0_IC_CON_STOP_DET_IFADDRESSED_MASK) >> MP2_I2C0_IC_CON_STOP_DET_IFADDRESSED_SHIFT)
#define MP2_I2C0_IC_CON_GET_TX_EMPTY_CTRL(mp2_i2c0_ic_con) \
     ((mp2_i2c0_ic_con & MP2_I2C0_IC_CON_TX_EMPTY_CTRL_MASK) >> MP2_I2C0_IC_CON_TX_EMPTY_CTRL_SHIFT)
#define MP2_I2C0_IC_CON_GET_RX_FIFO_FULL_HLD_CTRL(mp2_i2c0_ic_con) \
     ((mp2_i2c0_ic_con & MP2_I2C0_IC_CON_RX_FIFO_FULL_HLD_CTRL_MASK) >> MP2_I2C0_IC_CON_RX_FIFO_FULL_HLD_CTRL_SHIFT)
#define MP2_I2C0_IC_CON_GET_STOP_DET_IF_MASTER_ACTIVE(mp2_i2c0_ic_con) \
     ((mp2_i2c0_ic_con & MP2_I2C0_IC_CON_STOP_DET_IF_MASTER_ACTIVE_MASK) >> MP2_I2C0_IC_CON_STOP_DET_IF_MASTER_ACTIVE_SHIFT)

#define MP2_I2C0_IC_CON_SET_MASTER_MODE(mp2_i2c0_ic_con_reg, master_mode) \
     mp2_i2c0_ic_con_reg = (mp2_i2c0_ic_con_reg & ~MP2_I2C0_IC_CON_MASTER_MODE_MASK) | (master_mode << MP2_I2C0_IC_CON_MASTER_MODE_SHIFT)
#define MP2_I2C0_IC_CON_SET_SPEED(mp2_i2c0_ic_con_reg, speed) \
     mp2_i2c0_ic_con_reg = (mp2_i2c0_ic_con_reg & ~MP2_I2C0_IC_CON_SPEED_MASK) | (speed << MP2_I2C0_IC_CON_SPEED_SHIFT)
#define MP2_I2C0_IC_CON_SET_IC_10BITADDR_SLAVE(mp2_i2c0_ic_con_reg, ic_10bitaddr_slave) \
     mp2_i2c0_ic_con_reg = (mp2_i2c0_ic_con_reg & ~MP2_I2C0_IC_CON_IC_10BITADDR_SLAVE_MASK) | (ic_10bitaddr_slave << MP2_I2C0_IC_CON_IC_10BITADDR_SLAVE_SHIFT)
#define MP2_I2C0_IC_CON_SET_IC_10BITADDR_MASTER(mp2_i2c0_ic_con_reg, ic_10bitaddr_master) \
     mp2_i2c0_ic_con_reg = (mp2_i2c0_ic_con_reg & ~MP2_I2C0_IC_CON_IC_10BITADDR_MASTER_MASK) | (ic_10bitaddr_master << MP2_I2C0_IC_CON_IC_10BITADDR_MASTER_SHIFT)
#define MP2_I2C0_IC_CON_SET_IC_RESTART_EN(mp2_i2c0_ic_con_reg, ic_restart_en) \
     mp2_i2c0_ic_con_reg = (mp2_i2c0_ic_con_reg & ~MP2_I2C0_IC_CON_IC_RESTART_EN_MASK) | (ic_restart_en << MP2_I2C0_IC_CON_IC_RESTART_EN_SHIFT)
#define MP2_I2C0_IC_CON_SET_IC_SLAVE_DISABLE(mp2_i2c0_ic_con_reg, ic_slave_disable) \
     mp2_i2c0_ic_con_reg = (mp2_i2c0_ic_con_reg & ~MP2_I2C0_IC_CON_IC_SLAVE_DISABLE_MASK) | (ic_slave_disable << MP2_I2C0_IC_CON_IC_SLAVE_DISABLE_SHIFT)
#define MP2_I2C0_IC_CON_SET_STOP_DET_IFADDRESSED(mp2_i2c0_ic_con_reg, stop_det_ifaddressed) \
     mp2_i2c0_ic_con_reg = (mp2_i2c0_ic_con_reg & ~MP2_I2C0_IC_CON_STOP_DET_IFADDRESSED_MASK) | (stop_det_ifaddressed << MP2_I2C0_IC_CON_STOP_DET_IFADDRESSED_SHIFT)
#define MP2_I2C0_IC_CON_SET_TX_EMPTY_CTRL(mp2_i2c0_ic_con_reg, tx_empty_ctrl) \
     mp2_i2c0_ic_con_reg = (mp2_i2c0_ic_con_reg & ~MP2_I2C0_IC_CON_TX_EMPTY_CTRL_MASK) | (tx_empty_ctrl << MP2_I2C0_IC_CON_TX_EMPTY_CTRL_SHIFT)
#define MP2_I2C0_IC_CON_SET_RX_FIFO_FULL_HLD_CTRL(mp2_i2c0_ic_con_reg, rx_fifo_full_hld_ctrl) \
     mp2_i2c0_ic_con_reg = (mp2_i2c0_ic_con_reg & ~MP2_I2C0_IC_CON_RX_FIFO_FULL_HLD_CTRL_MASK) | (rx_fifo_full_hld_ctrl << MP2_I2C0_IC_CON_RX_FIFO_FULL_HLD_CTRL_SHIFT)
#define MP2_I2C0_IC_CON_SET_STOP_DET_IF_MASTER_ACTIVE(mp2_i2c0_ic_con_reg, stop_det_if_master_active) \
     mp2_i2c0_ic_con_reg = (mp2_i2c0_ic_con_reg & ~MP2_I2C0_IC_CON_STOP_DET_IF_MASTER_ACTIVE_MASK) | (stop_det_if_master_active << MP2_I2C0_IC_CON_STOP_DET_IF_MASTER_ACTIVE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_con_t {
          unsigned int master_mode                    : MP2_I2C0_IC_CON_MASTER_MODE_SIZE;
          unsigned int speed                          : MP2_I2C0_IC_CON_SPEED_SIZE;
          unsigned int ic_10bitaddr_slave             : MP2_I2C0_IC_CON_IC_10BITADDR_SLAVE_SIZE;
          unsigned int ic_10bitaddr_master            : MP2_I2C0_IC_CON_IC_10BITADDR_MASTER_SIZE;
          unsigned int ic_restart_en                  : MP2_I2C0_IC_CON_IC_RESTART_EN_SIZE;
          unsigned int ic_slave_disable               : MP2_I2C0_IC_CON_IC_SLAVE_DISABLE_SIZE;
          unsigned int stop_det_ifaddressed           : MP2_I2C0_IC_CON_STOP_DET_IFADDRESSED_SIZE;
          unsigned int tx_empty_ctrl                  : MP2_I2C0_IC_CON_TX_EMPTY_CTRL_SIZE;
          unsigned int rx_fifo_full_hld_ctrl          : MP2_I2C0_IC_CON_RX_FIFO_FULL_HLD_CTRL_SIZE;
          unsigned int stop_det_if_master_active      : MP2_I2C0_IC_CON_STOP_DET_IF_MASTER_ACTIVE_SIZE;
          unsigned int                                : 21;
     } mp2_i2c0_ic_con_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_con_t {
          unsigned int                                : 21;
          unsigned int stop_det_if_master_active      : MP2_I2C0_IC_CON_STOP_DET_IF_MASTER_ACTIVE_SIZE;
          unsigned int rx_fifo_full_hld_ctrl          : MP2_I2C0_IC_CON_RX_FIFO_FULL_HLD_CTRL_SIZE;
          unsigned int tx_empty_ctrl                  : MP2_I2C0_IC_CON_TX_EMPTY_CTRL_SIZE;
          unsigned int stop_det_ifaddressed           : MP2_I2C0_IC_CON_STOP_DET_IFADDRESSED_SIZE;
          unsigned int ic_slave_disable               : MP2_I2C0_IC_CON_IC_SLAVE_DISABLE_SIZE;
          unsigned int ic_restart_en                  : MP2_I2C0_IC_CON_IC_RESTART_EN_SIZE;
          unsigned int ic_10bitaddr_master            : MP2_I2C0_IC_CON_IC_10BITADDR_MASTER_SIZE;
          unsigned int ic_10bitaddr_slave             : MP2_I2C0_IC_CON_IC_10BITADDR_SLAVE_SIZE;
          unsigned int speed                          : MP2_I2C0_IC_CON_SPEED_SIZE;
          unsigned int master_mode                    : MP2_I2C0_IC_CON_MASTER_MODE_SIZE;
     } mp2_i2c0_ic_con_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_con_t f;
} mp2_i2c0_ic_con_u;


/*
 * MP2_I2C0_IC_TAR struct
 */

#define MP2_I2C0_IC_TAR_REG_SIZE       32
#define MP2_I2C0_IC_TAR_IC_TAR_SIZE    10
#define MP2_I2C0_IC_TAR_GC_OR_START_SIZE 1
#define MP2_I2C0_IC_TAR_SPECIAL_SIZE   1
#define MP2_I2C0_IC_TAR_IC_10BITADDR_MASTER_SIZE 1

#define MP2_I2C0_IC_TAR_IC_TAR_SHIFT   0
#define MP2_I2C0_IC_TAR_GC_OR_START_SHIFT 10
#define MP2_I2C0_IC_TAR_SPECIAL_SHIFT  11
#define MP2_I2C0_IC_TAR_IC_10BITADDR_MASTER_SHIFT 12

#define MP2_I2C0_IC_TAR_IC_TAR_MASK    0x3ff
#define MP2_I2C0_IC_TAR_GC_OR_START_MASK 0x400
#define MP2_I2C0_IC_TAR_SPECIAL_MASK   0x800
#define MP2_I2C0_IC_TAR_IC_10BITADDR_MASTER_MASK 0x1000

#define MP2_I2C0_IC_TAR_MASK \
     (MP2_I2C0_IC_TAR_IC_TAR_MASK | \
      MP2_I2C0_IC_TAR_GC_OR_START_MASK | \
      MP2_I2C0_IC_TAR_SPECIAL_MASK | \
      MP2_I2C0_IC_TAR_IC_10BITADDR_MASTER_MASK)

#define MP2_I2C0_IC_TAR_DEFAULT        0x00000000

#define MP2_I2C0_IC_TAR_GET_IC_TAR(mp2_i2c0_ic_tar) \
     ((mp2_i2c0_ic_tar & MP2_I2C0_IC_TAR_IC_TAR_MASK) >> MP2_I2C0_IC_TAR_IC_TAR_SHIFT)
#define MP2_I2C0_IC_TAR_GET_GC_OR_START(mp2_i2c0_ic_tar) \
     ((mp2_i2c0_ic_tar & MP2_I2C0_IC_TAR_GC_OR_START_MASK) >> MP2_I2C0_IC_TAR_GC_OR_START_SHIFT)
#define MP2_I2C0_IC_TAR_GET_SPECIAL(mp2_i2c0_ic_tar) \
     ((mp2_i2c0_ic_tar & MP2_I2C0_IC_TAR_SPECIAL_MASK) >> MP2_I2C0_IC_TAR_SPECIAL_SHIFT)
#define MP2_I2C0_IC_TAR_GET_IC_10BITADDR_MASTER(mp2_i2c0_ic_tar) \
     ((mp2_i2c0_ic_tar & MP2_I2C0_IC_TAR_IC_10BITADDR_MASTER_MASK) >> MP2_I2C0_IC_TAR_IC_10BITADDR_MASTER_SHIFT)

#define MP2_I2C0_IC_TAR_SET_IC_TAR(mp2_i2c0_ic_tar_reg, ic_tar) \
     mp2_i2c0_ic_tar_reg = (mp2_i2c0_ic_tar_reg & ~MP2_I2C0_IC_TAR_IC_TAR_MASK) | (ic_tar << MP2_I2C0_IC_TAR_IC_TAR_SHIFT)
#define MP2_I2C0_IC_TAR_SET_GC_OR_START(mp2_i2c0_ic_tar_reg, gc_or_start) \
     mp2_i2c0_ic_tar_reg = (mp2_i2c0_ic_tar_reg & ~MP2_I2C0_IC_TAR_GC_OR_START_MASK) | (gc_or_start << MP2_I2C0_IC_TAR_GC_OR_START_SHIFT)
#define MP2_I2C0_IC_TAR_SET_SPECIAL(mp2_i2c0_ic_tar_reg, special) \
     mp2_i2c0_ic_tar_reg = (mp2_i2c0_ic_tar_reg & ~MP2_I2C0_IC_TAR_SPECIAL_MASK) | (special << MP2_I2C0_IC_TAR_SPECIAL_SHIFT)
#define MP2_I2C0_IC_TAR_SET_IC_10BITADDR_MASTER(mp2_i2c0_ic_tar_reg, ic_10bitaddr_master) \
     mp2_i2c0_ic_tar_reg = (mp2_i2c0_ic_tar_reg & ~MP2_I2C0_IC_TAR_IC_10BITADDR_MASTER_MASK) | (ic_10bitaddr_master << MP2_I2C0_IC_TAR_IC_10BITADDR_MASTER_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_tar_t {
          unsigned int ic_tar                         : MP2_I2C0_IC_TAR_IC_TAR_SIZE;
          unsigned int gc_or_start                    : MP2_I2C0_IC_TAR_GC_OR_START_SIZE;
          unsigned int special                        : MP2_I2C0_IC_TAR_SPECIAL_SIZE;
          unsigned int ic_10bitaddr_master            : MP2_I2C0_IC_TAR_IC_10BITADDR_MASTER_SIZE;
          unsigned int                                : 19;
     } mp2_i2c0_ic_tar_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_tar_t {
          unsigned int                                : 19;
          unsigned int ic_10bitaddr_master            : MP2_I2C0_IC_TAR_IC_10BITADDR_MASTER_SIZE;
          unsigned int special                        : MP2_I2C0_IC_TAR_SPECIAL_SIZE;
          unsigned int gc_or_start                    : MP2_I2C0_IC_TAR_GC_OR_START_SIZE;
          unsigned int ic_tar                         : MP2_I2C0_IC_TAR_IC_TAR_SIZE;
     } mp2_i2c0_ic_tar_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_tar_t f;
} mp2_i2c0_ic_tar_u;


/*
 * MP2_I2C0_IC_SAR struct
 */

#define MP2_I2C0_IC_SAR_REG_SIZE       32
#define MP2_I2C0_IC_SAR_IC_SAR_SIZE    10

#define MP2_I2C0_IC_SAR_IC_SAR_SHIFT   0

#define MP2_I2C0_IC_SAR_IC_SAR_MASK    0x3ff

#define MP2_I2C0_IC_SAR_MASK \
     (MP2_I2C0_IC_SAR_IC_SAR_MASK)

#define MP2_I2C0_IC_SAR_DEFAULT        0x00000000

#define MP2_I2C0_IC_SAR_GET_IC_SAR(mp2_i2c0_ic_sar) \
     ((mp2_i2c0_ic_sar & MP2_I2C0_IC_SAR_IC_SAR_MASK) >> MP2_I2C0_IC_SAR_IC_SAR_SHIFT)

#define MP2_I2C0_IC_SAR_SET_IC_SAR(mp2_i2c0_ic_sar_reg, ic_sar) \
     mp2_i2c0_ic_sar_reg = (mp2_i2c0_ic_sar_reg & ~MP2_I2C0_IC_SAR_IC_SAR_MASK) | (ic_sar << MP2_I2C0_IC_SAR_IC_SAR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_sar_t {
          unsigned int ic_sar                         : MP2_I2C0_IC_SAR_IC_SAR_SIZE;
          unsigned int                                : 22;
     } mp2_i2c0_ic_sar_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_sar_t {
          unsigned int                                : 22;
          unsigned int ic_sar                         : MP2_I2C0_IC_SAR_IC_SAR_SIZE;
     } mp2_i2c0_ic_sar_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_sar_t f;
} mp2_i2c0_ic_sar_u;


/*
 * MP2_I2C0_IC_HS_MADDR struct
 */

#define MP2_I2C0_IC_HS_MADDR_REG_SIZE  32
#define MP2_I2C0_IC_HS_MADDR_IC_HS_MAR_SIZE 3

#define MP2_I2C0_IC_HS_MADDR_IC_HS_MAR_SHIFT 0

#define MP2_I2C0_IC_HS_MADDR_IC_HS_MAR_MASK 0x7

#define MP2_I2C0_IC_HS_MADDR_MASK \
     (MP2_I2C0_IC_HS_MADDR_IC_HS_MAR_MASK)

#define MP2_I2C0_IC_HS_MADDR_DEFAULT   0x00000000

#define MP2_I2C0_IC_HS_MADDR_GET_IC_HS_MAR(mp2_i2c0_ic_hs_maddr) \
     ((mp2_i2c0_ic_hs_maddr & MP2_I2C0_IC_HS_MADDR_IC_HS_MAR_MASK) >> MP2_I2C0_IC_HS_MADDR_IC_HS_MAR_SHIFT)

#define MP2_I2C0_IC_HS_MADDR_SET_IC_HS_MAR(mp2_i2c0_ic_hs_maddr_reg, ic_hs_mar) \
     mp2_i2c0_ic_hs_maddr_reg = (mp2_i2c0_ic_hs_maddr_reg & ~MP2_I2C0_IC_HS_MADDR_IC_HS_MAR_MASK) | (ic_hs_mar << MP2_I2C0_IC_HS_MADDR_IC_HS_MAR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_hs_maddr_t {
          unsigned int ic_hs_mar                      : MP2_I2C0_IC_HS_MADDR_IC_HS_MAR_SIZE;
          unsigned int                                : 29;
     } mp2_i2c0_ic_hs_maddr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_hs_maddr_t {
          unsigned int                                : 29;
          unsigned int ic_hs_mar                      : MP2_I2C0_IC_HS_MADDR_IC_HS_MAR_SIZE;
     } mp2_i2c0_ic_hs_maddr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_hs_maddr_t f;
} mp2_i2c0_ic_hs_maddr_u;


/*
 * MP2_I2C0_IC_DATA_CMD struct
 */

#define MP2_I2C0_IC_DATA_CMD_REG_SIZE  32
#define MP2_I2C0_IC_DATA_CMD_DAT_SIZE  8
#define MP2_I2C0_IC_DATA_CMD_CMD_SIZE  1
#define MP2_I2C0_IC_DATA_CMD_STOP_SIZE 1
#define MP2_I2C0_IC_DATA_CMD_RESTART_SIZE 1
#define MP2_I2C0_IC_DATA_CMD_FIRST_DATA_BYTE_SIZE 1

#define MP2_I2C0_IC_DATA_CMD_DAT_SHIFT 0
#define MP2_I2C0_IC_DATA_CMD_CMD_SHIFT 8
#define MP2_I2C0_IC_DATA_CMD_STOP_SHIFT 9
#define MP2_I2C0_IC_DATA_CMD_RESTART_SHIFT 10
#define MP2_I2C0_IC_DATA_CMD_FIRST_DATA_BYTE_SHIFT 11

#define MP2_I2C0_IC_DATA_CMD_DAT_MASK  0xff
#define MP2_I2C0_IC_DATA_CMD_CMD_MASK  0x100
#define MP2_I2C0_IC_DATA_CMD_STOP_MASK 0x200
#define MP2_I2C0_IC_DATA_CMD_RESTART_MASK 0x400
#define MP2_I2C0_IC_DATA_CMD_FIRST_DATA_BYTE_MASK 0x800

#define MP2_I2C0_IC_DATA_CMD_MASK \
     (MP2_I2C0_IC_DATA_CMD_DAT_MASK | \
      MP2_I2C0_IC_DATA_CMD_CMD_MASK | \
      MP2_I2C0_IC_DATA_CMD_STOP_MASK | \
      MP2_I2C0_IC_DATA_CMD_RESTART_MASK | \
      MP2_I2C0_IC_DATA_CMD_FIRST_DATA_BYTE_MASK)

#define MP2_I2C0_IC_DATA_CMD_DEFAULT   0x00000000

#define MP2_I2C0_IC_DATA_CMD_GET_DAT(mp2_i2c0_ic_data_cmd) \
     ((mp2_i2c0_ic_data_cmd & MP2_I2C0_IC_DATA_CMD_DAT_MASK) >> MP2_I2C0_IC_DATA_CMD_DAT_SHIFT)
#define MP2_I2C0_IC_DATA_CMD_GET_CMD(mp2_i2c0_ic_data_cmd) \
     ((mp2_i2c0_ic_data_cmd & MP2_I2C0_IC_DATA_CMD_CMD_MASK) >> MP2_I2C0_IC_DATA_CMD_CMD_SHIFT)
#define MP2_I2C0_IC_DATA_CMD_GET_STOP(mp2_i2c0_ic_data_cmd) \
     ((mp2_i2c0_ic_data_cmd & MP2_I2C0_IC_DATA_CMD_STOP_MASK) >> MP2_I2C0_IC_DATA_CMD_STOP_SHIFT)
#define MP2_I2C0_IC_DATA_CMD_GET_RESTART(mp2_i2c0_ic_data_cmd) \
     ((mp2_i2c0_ic_data_cmd & MP2_I2C0_IC_DATA_CMD_RESTART_MASK) >> MP2_I2C0_IC_DATA_CMD_RESTART_SHIFT)
#define MP2_I2C0_IC_DATA_CMD_GET_FIRST_DATA_BYTE(mp2_i2c0_ic_data_cmd) \
     ((mp2_i2c0_ic_data_cmd & MP2_I2C0_IC_DATA_CMD_FIRST_DATA_BYTE_MASK) >> MP2_I2C0_IC_DATA_CMD_FIRST_DATA_BYTE_SHIFT)

#define MP2_I2C0_IC_DATA_CMD_SET_DAT(mp2_i2c0_ic_data_cmd_reg, dat) \
     mp2_i2c0_ic_data_cmd_reg = (mp2_i2c0_ic_data_cmd_reg & ~MP2_I2C0_IC_DATA_CMD_DAT_MASK) | (dat << MP2_I2C0_IC_DATA_CMD_DAT_SHIFT)
#define MP2_I2C0_IC_DATA_CMD_SET_CMD(mp2_i2c0_ic_data_cmd_reg, cmd) \
     mp2_i2c0_ic_data_cmd_reg = (mp2_i2c0_ic_data_cmd_reg & ~MP2_I2C0_IC_DATA_CMD_CMD_MASK) | (cmd << MP2_I2C0_IC_DATA_CMD_CMD_SHIFT)
#define MP2_I2C0_IC_DATA_CMD_SET_STOP(mp2_i2c0_ic_data_cmd_reg, stop) \
     mp2_i2c0_ic_data_cmd_reg = (mp2_i2c0_ic_data_cmd_reg & ~MP2_I2C0_IC_DATA_CMD_STOP_MASK) | (stop << MP2_I2C0_IC_DATA_CMD_STOP_SHIFT)
#define MP2_I2C0_IC_DATA_CMD_SET_RESTART(mp2_i2c0_ic_data_cmd_reg, restart) \
     mp2_i2c0_ic_data_cmd_reg = (mp2_i2c0_ic_data_cmd_reg & ~MP2_I2C0_IC_DATA_CMD_RESTART_MASK) | (restart << MP2_I2C0_IC_DATA_CMD_RESTART_SHIFT)
#define MP2_I2C0_IC_DATA_CMD_SET_FIRST_DATA_BYTE(mp2_i2c0_ic_data_cmd_reg, first_data_byte) \
     mp2_i2c0_ic_data_cmd_reg = (mp2_i2c0_ic_data_cmd_reg & ~MP2_I2C0_IC_DATA_CMD_FIRST_DATA_BYTE_MASK) | (first_data_byte << MP2_I2C0_IC_DATA_CMD_FIRST_DATA_BYTE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_data_cmd_t {
          unsigned int dat                            : MP2_I2C0_IC_DATA_CMD_DAT_SIZE;
          unsigned int cmd                            : MP2_I2C0_IC_DATA_CMD_CMD_SIZE;
          unsigned int stop                           : MP2_I2C0_IC_DATA_CMD_STOP_SIZE;
          unsigned int restart                        : MP2_I2C0_IC_DATA_CMD_RESTART_SIZE;
          unsigned int first_data_byte                : MP2_I2C0_IC_DATA_CMD_FIRST_DATA_BYTE_SIZE;
          unsigned int                                : 20;
     } mp2_i2c0_ic_data_cmd_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_data_cmd_t {
          unsigned int                                : 20;
          unsigned int first_data_byte                : MP2_I2C0_IC_DATA_CMD_FIRST_DATA_BYTE_SIZE;
          unsigned int restart                        : MP2_I2C0_IC_DATA_CMD_RESTART_SIZE;
          unsigned int stop                           : MP2_I2C0_IC_DATA_CMD_STOP_SIZE;
          unsigned int cmd                            : MP2_I2C0_IC_DATA_CMD_CMD_SIZE;
          unsigned int dat                            : MP2_I2C0_IC_DATA_CMD_DAT_SIZE;
     } mp2_i2c0_ic_data_cmd_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_data_cmd_t f;
} mp2_i2c0_ic_data_cmd_u;


/*
 * MP2_I2C0_IC_SS_SCL_HCNT struct
 */

#define MP2_I2C0_IC_SS_SCL_HCNT_REG_SIZE 32
#define MP2_I2C0_IC_SS_SCL_HCNT_IC_SS_SCL_HCNT_SIZE 16

#define MP2_I2C0_IC_SS_SCL_HCNT_IC_SS_SCL_HCNT_SHIFT 0

#define MP2_I2C0_IC_SS_SCL_HCNT_IC_SS_SCL_HCNT_MASK 0xffff

#define MP2_I2C0_IC_SS_SCL_HCNT_MASK \
     (MP2_I2C0_IC_SS_SCL_HCNT_IC_SS_SCL_HCNT_MASK)

#define MP2_I2C0_IC_SS_SCL_HCNT_DEFAULT 0x00000000

#define MP2_I2C0_IC_SS_SCL_HCNT_GET_IC_SS_SCL_HCNT(mp2_i2c0_ic_ss_scl_hcnt) \
     ((mp2_i2c0_ic_ss_scl_hcnt & MP2_I2C0_IC_SS_SCL_HCNT_IC_SS_SCL_HCNT_MASK) >> MP2_I2C0_IC_SS_SCL_HCNT_IC_SS_SCL_HCNT_SHIFT)

#define MP2_I2C0_IC_SS_SCL_HCNT_SET_IC_SS_SCL_HCNT(mp2_i2c0_ic_ss_scl_hcnt_reg, ic_ss_scl_hcnt) \
     mp2_i2c0_ic_ss_scl_hcnt_reg = (mp2_i2c0_ic_ss_scl_hcnt_reg & ~MP2_I2C0_IC_SS_SCL_HCNT_IC_SS_SCL_HCNT_MASK) | (ic_ss_scl_hcnt << MP2_I2C0_IC_SS_SCL_HCNT_IC_SS_SCL_HCNT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_ss_scl_hcnt_t {
          unsigned int ic_ss_scl_hcnt                 : MP2_I2C0_IC_SS_SCL_HCNT_IC_SS_SCL_HCNT_SIZE;
          unsigned int                                : 16;
     } mp2_i2c0_ic_ss_scl_hcnt_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_ss_scl_hcnt_t {
          unsigned int                                : 16;
          unsigned int ic_ss_scl_hcnt                 : MP2_I2C0_IC_SS_SCL_HCNT_IC_SS_SCL_HCNT_SIZE;
     } mp2_i2c0_ic_ss_scl_hcnt_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_ss_scl_hcnt_t f;
} mp2_i2c0_ic_ss_scl_hcnt_u;


/*
 * MP2_I2C0_IC_SS_SCL_LCNT struct
 */

#define MP2_I2C0_IC_SS_SCL_LCNT_REG_SIZE 32
#define MP2_I2C0_IC_SS_SCL_LCNT_IC_SS_SCL_LCNT_SIZE 16

#define MP2_I2C0_IC_SS_SCL_LCNT_IC_SS_SCL_LCNT_SHIFT 0

#define MP2_I2C0_IC_SS_SCL_LCNT_IC_SS_SCL_LCNT_MASK 0xffff

#define MP2_I2C0_IC_SS_SCL_LCNT_MASK \
     (MP2_I2C0_IC_SS_SCL_LCNT_IC_SS_SCL_LCNT_MASK)

#define MP2_I2C0_IC_SS_SCL_LCNT_DEFAULT 0x00000000

#define MP2_I2C0_IC_SS_SCL_LCNT_GET_IC_SS_SCL_LCNT(mp2_i2c0_ic_ss_scl_lcnt) \
     ((mp2_i2c0_ic_ss_scl_lcnt & MP2_I2C0_IC_SS_SCL_LCNT_IC_SS_SCL_LCNT_MASK) >> MP2_I2C0_IC_SS_SCL_LCNT_IC_SS_SCL_LCNT_SHIFT)

#define MP2_I2C0_IC_SS_SCL_LCNT_SET_IC_SS_SCL_LCNT(mp2_i2c0_ic_ss_scl_lcnt_reg, ic_ss_scl_lcnt) \
     mp2_i2c0_ic_ss_scl_lcnt_reg = (mp2_i2c0_ic_ss_scl_lcnt_reg & ~MP2_I2C0_IC_SS_SCL_LCNT_IC_SS_SCL_LCNT_MASK) | (ic_ss_scl_lcnt << MP2_I2C0_IC_SS_SCL_LCNT_IC_SS_SCL_LCNT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_ss_scl_lcnt_t {
          unsigned int ic_ss_scl_lcnt                 : MP2_I2C0_IC_SS_SCL_LCNT_IC_SS_SCL_LCNT_SIZE;
          unsigned int                                : 16;
     } mp2_i2c0_ic_ss_scl_lcnt_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_ss_scl_lcnt_t {
          unsigned int                                : 16;
          unsigned int ic_ss_scl_lcnt                 : MP2_I2C0_IC_SS_SCL_LCNT_IC_SS_SCL_LCNT_SIZE;
     } mp2_i2c0_ic_ss_scl_lcnt_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_ss_scl_lcnt_t f;
} mp2_i2c0_ic_ss_scl_lcnt_u;


/*
 * MP2_I2C0_IC_FS_SCL_HCNT struct
 */

#define MP2_I2C0_IC_FS_SCL_HCNT_REG_SIZE 32
#define MP2_I2C0_IC_FS_SCL_HCNT_IC_FS_SCL_HCNT_SIZE 16

#define MP2_I2C0_IC_FS_SCL_HCNT_IC_FS_SCL_HCNT_SHIFT 0

#define MP2_I2C0_IC_FS_SCL_HCNT_IC_FS_SCL_HCNT_MASK 0xffff

#define MP2_I2C0_IC_FS_SCL_HCNT_MASK \
     (MP2_I2C0_IC_FS_SCL_HCNT_IC_FS_SCL_HCNT_MASK)

#define MP2_I2C0_IC_FS_SCL_HCNT_DEFAULT 0x00000000

#define MP2_I2C0_IC_FS_SCL_HCNT_GET_IC_FS_SCL_HCNT(mp2_i2c0_ic_fs_scl_hcnt) \
     ((mp2_i2c0_ic_fs_scl_hcnt & MP2_I2C0_IC_FS_SCL_HCNT_IC_FS_SCL_HCNT_MASK) >> MP2_I2C0_IC_FS_SCL_HCNT_IC_FS_SCL_HCNT_SHIFT)

#define MP2_I2C0_IC_FS_SCL_HCNT_SET_IC_FS_SCL_HCNT(mp2_i2c0_ic_fs_scl_hcnt_reg, ic_fs_scl_hcnt) \
     mp2_i2c0_ic_fs_scl_hcnt_reg = (mp2_i2c0_ic_fs_scl_hcnt_reg & ~MP2_I2C0_IC_FS_SCL_HCNT_IC_FS_SCL_HCNT_MASK) | (ic_fs_scl_hcnt << MP2_I2C0_IC_FS_SCL_HCNT_IC_FS_SCL_HCNT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_fs_scl_hcnt_t {
          unsigned int ic_fs_scl_hcnt                 : MP2_I2C0_IC_FS_SCL_HCNT_IC_FS_SCL_HCNT_SIZE;
          unsigned int                                : 16;
     } mp2_i2c0_ic_fs_scl_hcnt_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_fs_scl_hcnt_t {
          unsigned int                                : 16;
          unsigned int ic_fs_scl_hcnt                 : MP2_I2C0_IC_FS_SCL_HCNT_IC_FS_SCL_HCNT_SIZE;
     } mp2_i2c0_ic_fs_scl_hcnt_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_fs_scl_hcnt_t f;
} mp2_i2c0_ic_fs_scl_hcnt_u;


/*
 * MP2_I2C0_IC_FS_SCL_LCNT struct
 */

#define MP2_I2C0_IC_FS_SCL_LCNT_REG_SIZE 32
#define MP2_I2C0_IC_FS_SCL_LCNT_IC_FS_SCL_LCNT_SIZE 16

#define MP2_I2C0_IC_FS_SCL_LCNT_IC_FS_SCL_LCNT_SHIFT 0

#define MP2_I2C0_IC_FS_SCL_LCNT_IC_FS_SCL_LCNT_MASK 0xffff

#define MP2_I2C0_IC_FS_SCL_LCNT_MASK \
     (MP2_I2C0_IC_FS_SCL_LCNT_IC_FS_SCL_LCNT_MASK)

#define MP2_I2C0_IC_FS_SCL_LCNT_DEFAULT 0x00000000

#define MP2_I2C0_IC_FS_SCL_LCNT_GET_IC_FS_SCL_LCNT(mp2_i2c0_ic_fs_scl_lcnt) \
     ((mp2_i2c0_ic_fs_scl_lcnt & MP2_I2C0_IC_FS_SCL_LCNT_IC_FS_SCL_LCNT_MASK) >> MP2_I2C0_IC_FS_SCL_LCNT_IC_FS_SCL_LCNT_SHIFT)

#define MP2_I2C0_IC_FS_SCL_LCNT_SET_IC_FS_SCL_LCNT(mp2_i2c0_ic_fs_scl_lcnt_reg, ic_fs_scl_lcnt) \
     mp2_i2c0_ic_fs_scl_lcnt_reg = (mp2_i2c0_ic_fs_scl_lcnt_reg & ~MP2_I2C0_IC_FS_SCL_LCNT_IC_FS_SCL_LCNT_MASK) | (ic_fs_scl_lcnt << MP2_I2C0_IC_FS_SCL_LCNT_IC_FS_SCL_LCNT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_fs_scl_lcnt_t {
          unsigned int ic_fs_scl_lcnt                 : MP2_I2C0_IC_FS_SCL_LCNT_IC_FS_SCL_LCNT_SIZE;
          unsigned int                                : 16;
     } mp2_i2c0_ic_fs_scl_lcnt_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_fs_scl_lcnt_t {
          unsigned int                                : 16;
          unsigned int ic_fs_scl_lcnt                 : MP2_I2C0_IC_FS_SCL_LCNT_IC_FS_SCL_LCNT_SIZE;
     } mp2_i2c0_ic_fs_scl_lcnt_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_fs_scl_lcnt_t f;
} mp2_i2c0_ic_fs_scl_lcnt_u;


/*
 * MP2_I2C0_IC_HS_SCL_HCNT struct
 */

#define MP2_I2C0_IC_HS_SCL_HCNT_REG_SIZE 32
#define MP2_I2C0_IC_HS_SCL_HCNT_IC_HS_SCL_HCNT_SIZE 16

#define MP2_I2C0_IC_HS_SCL_HCNT_IC_HS_SCL_HCNT_SHIFT 0

#define MP2_I2C0_IC_HS_SCL_HCNT_IC_HS_SCL_HCNT_MASK 0xffff

#define MP2_I2C0_IC_HS_SCL_HCNT_MASK \
     (MP2_I2C0_IC_HS_SCL_HCNT_IC_HS_SCL_HCNT_MASK)

#define MP2_I2C0_IC_HS_SCL_HCNT_DEFAULT 0x00000000

#define MP2_I2C0_IC_HS_SCL_HCNT_GET_IC_HS_SCL_HCNT(mp2_i2c0_ic_hs_scl_hcnt) \
     ((mp2_i2c0_ic_hs_scl_hcnt & MP2_I2C0_IC_HS_SCL_HCNT_IC_HS_SCL_HCNT_MASK) >> MP2_I2C0_IC_HS_SCL_HCNT_IC_HS_SCL_HCNT_SHIFT)

#define MP2_I2C0_IC_HS_SCL_HCNT_SET_IC_HS_SCL_HCNT(mp2_i2c0_ic_hs_scl_hcnt_reg, ic_hs_scl_hcnt) \
     mp2_i2c0_ic_hs_scl_hcnt_reg = (mp2_i2c0_ic_hs_scl_hcnt_reg & ~MP2_I2C0_IC_HS_SCL_HCNT_IC_HS_SCL_HCNT_MASK) | (ic_hs_scl_hcnt << MP2_I2C0_IC_HS_SCL_HCNT_IC_HS_SCL_HCNT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_hs_scl_hcnt_t {
          unsigned int ic_hs_scl_hcnt                 : MP2_I2C0_IC_HS_SCL_HCNT_IC_HS_SCL_HCNT_SIZE;
          unsigned int                                : 16;
     } mp2_i2c0_ic_hs_scl_hcnt_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_hs_scl_hcnt_t {
          unsigned int                                : 16;
          unsigned int ic_hs_scl_hcnt                 : MP2_I2C0_IC_HS_SCL_HCNT_IC_HS_SCL_HCNT_SIZE;
     } mp2_i2c0_ic_hs_scl_hcnt_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_hs_scl_hcnt_t f;
} mp2_i2c0_ic_hs_scl_hcnt_u;


/*
 * MP2_I2C0_IC_HS_SCL_LCNT struct
 */

#define MP2_I2C0_IC_HS_SCL_LCNT_REG_SIZE 32
#define MP2_I2C0_IC_HS_SCL_LCNT_IC_HS_SCL_LCNT_SIZE 16

#define MP2_I2C0_IC_HS_SCL_LCNT_IC_HS_SCL_LCNT_SHIFT 0

#define MP2_I2C0_IC_HS_SCL_LCNT_IC_HS_SCL_LCNT_MASK 0xffff

#define MP2_I2C0_IC_HS_SCL_LCNT_MASK \
     (MP2_I2C0_IC_HS_SCL_LCNT_IC_HS_SCL_LCNT_MASK)

#define MP2_I2C0_IC_HS_SCL_LCNT_DEFAULT 0x00000000

#define MP2_I2C0_IC_HS_SCL_LCNT_GET_IC_HS_SCL_LCNT(mp2_i2c0_ic_hs_scl_lcnt) \
     ((mp2_i2c0_ic_hs_scl_lcnt & MP2_I2C0_IC_HS_SCL_LCNT_IC_HS_SCL_LCNT_MASK) >> MP2_I2C0_IC_HS_SCL_LCNT_IC_HS_SCL_LCNT_SHIFT)

#define MP2_I2C0_IC_HS_SCL_LCNT_SET_IC_HS_SCL_LCNT(mp2_i2c0_ic_hs_scl_lcnt_reg, ic_hs_scl_lcnt) \
     mp2_i2c0_ic_hs_scl_lcnt_reg = (mp2_i2c0_ic_hs_scl_lcnt_reg & ~MP2_I2C0_IC_HS_SCL_LCNT_IC_HS_SCL_LCNT_MASK) | (ic_hs_scl_lcnt << MP2_I2C0_IC_HS_SCL_LCNT_IC_HS_SCL_LCNT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_hs_scl_lcnt_t {
          unsigned int ic_hs_scl_lcnt                 : MP2_I2C0_IC_HS_SCL_LCNT_IC_HS_SCL_LCNT_SIZE;
          unsigned int                                : 16;
     } mp2_i2c0_ic_hs_scl_lcnt_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_hs_scl_lcnt_t {
          unsigned int                                : 16;
          unsigned int ic_hs_scl_lcnt                 : MP2_I2C0_IC_HS_SCL_LCNT_IC_HS_SCL_LCNT_SIZE;
     } mp2_i2c0_ic_hs_scl_lcnt_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_hs_scl_lcnt_t f;
} mp2_i2c0_ic_hs_scl_lcnt_u;


/*
 * MP2_I2C0_IC_INTR_STAT struct
 */

#define MP2_I2C0_IC_INTR_STAT_REG_SIZE 32
#define MP2_I2C0_IC_INTR_STAT_R_RX_UNDER_SIZE 1
#define MP2_I2C0_IC_INTR_STAT_R_RX_OVER_SIZE 1
#define MP2_I2C0_IC_INTR_STAT_R_RX_FULL_SIZE 1
#define MP2_I2C0_IC_INTR_STAT_R_TX_OVER_SIZE 1
#define MP2_I2C0_IC_INTR_STAT_R_TX_EMPTY_SIZE 1
#define MP2_I2C0_IC_INTR_STAT_R_RD_REQ_SIZE 1
#define MP2_I2C0_IC_INTR_STAT_R_TX_ABRT_SIZE 1
#define MP2_I2C0_IC_INTR_STAT_R_RX_DONE_SIZE 1
#define MP2_I2C0_IC_INTR_STAT_R_ACTIVITY_SIZE 1
#define MP2_I2C0_IC_INTR_STAT_R_STOP_DET_SIZE 1
#define MP2_I2C0_IC_INTR_STAT_R_START_DET_SIZE 1
#define MP2_I2C0_IC_INTR_STAT_R_GEN_CALL_SIZE 1
#define MP2_I2C0_IC_INTR_STAT_R_RESTART_DET_SIZE 1
#define MP2_I2C0_IC_INTR_STAT_R_MST_ON_HOLD_SIZE 1

#define MP2_I2C0_IC_INTR_STAT_R_RX_UNDER_SHIFT 0
#define MP2_I2C0_IC_INTR_STAT_R_RX_OVER_SHIFT 1
#define MP2_I2C0_IC_INTR_STAT_R_RX_FULL_SHIFT 2
#define MP2_I2C0_IC_INTR_STAT_R_TX_OVER_SHIFT 3
#define MP2_I2C0_IC_INTR_STAT_R_TX_EMPTY_SHIFT 4
#define MP2_I2C0_IC_INTR_STAT_R_RD_REQ_SHIFT 5
#define MP2_I2C0_IC_INTR_STAT_R_TX_ABRT_SHIFT 6
#define MP2_I2C0_IC_INTR_STAT_R_RX_DONE_SHIFT 7
#define MP2_I2C0_IC_INTR_STAT_R_ACTIVITY_SHIFT 8
#define MP2_I2C0_IC_INTR_STAT_R_STOP_DET_SHIFT 9
#define MP2_I2C0_IC_INTR_STAT_R_START_DET_SHIFT 10
#define MP2_I2C0_IC_INTR_STAT_R_GEN_CALL_SHIFT 11
#define MP2_I2C0_IC_INTR_STAT_R_RESTART_DET_SHIFT 12
#define MP2_I2C0_IC_INTR_STAT_R_MST_ON_HOLD_SHIFT 13

#define MP2_I2C0_IC_INTR_STAT_R_RX_UNDER_MASK 0x1
#define MP2_I2C0_IC_INTR_STAT_R_RX_OVER_MASK 0x2
#define MP2_I2C0_IC_INTR_STAT_R_RX_FULL_MASK 0x4
#define MP2_I2C0_IC_INTR_STAT_R_TX_OVER_MASK 0x8
#define MP2_I2C0_IC_INTR_STAT_R_TX_EMPTY_MASK 0x10
#define MP2_I2C0_IC_INTR_STAT_R_RD_REQ_MASK 0x20
#define MP2_I2C0_IC_INTR_STAT_R_TX_ABRT_MASK 0x40
#define MP2_I2C0_IC_INTR_STAT_R_RX_DONE_MASK 0x80
#define MP2_I2C0_IC_INTR_STAT_R_ACTIVITY_MASK 0x100
#define MP2_I2C0_IC_INTR_STAT_R_STOP_DET_MASK 0x200
#define MP2_I2C0_IC_INTR_STAT_R_START_DET_MASK 0x400
#define MP2_I2C0_IC_INTR_STAT_R_GEN_CALL_MASK 0x800
#define MP2_I2C0_IC_INTR_STAT_R_RESTART_DET_MASK 0x1000
#define MP2_I2C0_IC_INTR_STAT_R_MST_ON_HOLD_MASK 0x2000

#define MP2_I2C0_IC_INTR_STAT_MASK \
     (MP2_I2C0_IC_INTR_STAT_R_RX_UNDER_MASK | \
      MP2_I2C0_IC_INTR_STAT_R_RX_OVER_MASK | \
      MP2_I2C0_IC_INTR_STAT_R_RX_FULL_MASK | \
      MP2_I2C0_IC_INTR_STAT_R_TX_OVER_MASK | \
      MP2_I2C0_IC_INTR_STAT_R_TX_EMPTY_MASK | \
      MP2_I2C0_IC_INTR_STAT_R_RD_REQ_MASK | \
      MP2_I2C0_IC_INTR_STAT_R_TX_ABRT_MASK | \
      MP2_I2C0_IC_INTR_STAT_R_RX_DONE_MASK | \
      MP2_I2C0_IC_INTR_STAT_R_ACTIVITY_MASK | \
      MP2_I2C0_IC_INTR_STAT_R_STOP_DET_MASK | \
      MP2_I2C0_IC_INTR_STAT_R_START_DET_MASK | \
      MP2_I2C0_IC_INTR_STAT_R_GEN_CALL_MASK | \
      MP2_I2C0_IC_INTR_STAT_R_RESTART_DET_MASK | \
      MP2_I2C0_IC_INTR_STAT_R_MST_ON_HOLD_MASK)

#define MP2_I2C0_IC_INTR_STAT_DEFAULT  0x00000000

#define MP2_I2C0_IC_INTR_STAT_GET_R_RX_UNDER(mp2_i2c0_ic_intr_stat) \
     ((mp2_i2c0_ic_intr_stat & MP2_I2C0_IC_INTR_STAT_R_RX_UNDER_MASK) >> MP2_I2C0_IC_INTR_STAT_R_RX_UNDER_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_GET_R_RX_OVER(mp2_i2c0_ic_intr_stat) \
     ((mp2_i2c0_ic_intr_stat & MP2_I2C0_IC_INTR_STAT_R_RX_OVER_MASK) >> MP2_I2C0_IC_INTR_STAT_R_RX_OVER_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_GET_R_RX_FULL(mp2_i2c0_ic_intr_stat) \
     ((mp2_i2c0_ic_intr_stat & MP2_I2C0_IC_INTR_STAT_R_RX_FULL_MASK) >> MP2_I2C0_IC_INTR_STAT_R_RX_FULL_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_GET_R_TX_OVER(mp2_i2c0_ic_intr_stat) \
     ((mp2_i2c0_ic_intr_stat & MP2_I2C0_IC_INTR_STAT_R_TX_OVER_MASK) >> MP2_I2C0_IC_INTR_STAT_R_TX_OVER_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_GET_R_TX_EMPTY(mp2_i2c0_ic_intr_stat) \
     ((mp2_i2c0_ic_intr_stat & MP2_I2C0_IC_INTR_STAT_R_TX_EMPTY_MASK) >> MP2_I2C0_IC_INTR_STAT_R_TX_EMPTY_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_GET_R_RD_REQ(mp2_i2c0_ic_intr_stat) \
     ((mp2_i2c0_ic_intr_stat & MP2_I2C0_IC_INTR_STAT_R_RD_REQ_MASK) >> MP2_I2C0_IC_INTR_STAT_R_RD_REQ_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_GET_R_TX_ABRT(mp2_i2c0_ic_intr_stat) \
     ((mp2_i2c0_ic_intr_stat & MP2_I2C0_IC_INTR_STAT_R_TX_ABRT_MASK) >> MP2_I2C0_IC_INTR_STAT_R_TX_ABRT_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_GET_R_RX_DONE(mp2_i2c0_ic_intr_stat) \
     ((mp2_i2c0_ic_intr_stat & MP2_I2C0_IC_INTR_STAT_R_RX_DONE_MASK) >> MP2_I2C0_IC_INTR_STAT_R_RX_DONE_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_GET_R_ACTIVITY(mp2_i2c0_ic_intr_stat) \
     ((mp2_i2c0_ic_intr_stat & MP2_I2C0_IC_INTR_STAT_R_ACTIVITY_MASK) >> MP2_I2C0_IC_INTR_STAT_R_ACTIVITY_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_GET_R_STOP_DET(mp2_i2c0_ic_intr_stat) \
     ((mp2_i2c0_ic_intr_stat & MP2_I2C0_IC_INTR_STAT_R_STOP_DET_MASK) >> MP2_I2C0_IC_INTR_STAT_R_STOP_DET_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_GET_R_START_DET(mp2_i2c0_ic_intr_stat) \
     ((mp2_i2c0_ic_intr_stat & MP2_I2C0_IC_INTR_STAT_R_START_DET_MASK) >> MP2_I2C0_IC_INTR_STAT_R_START_DET_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_GET_R_GEN_CALL(mp2_i2c0_ic_intr_stat) \
     ((mp2_i2c0_ic_intr_stat & MP2_I2C0_IC_INTR_STAT_R_GEN_CALL_MASK) >> MP2_I2C0_IC_INTR_STAT_R_GEN_CALL_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_GET_R_RESTART_DET(mp2_i2c0_ic_intr_stat) \
     ((mp2_i2c0_ic_intr_stat & MP2_I2C0_IC_INTR_STAT_R_RESTART_DET_MASK) >> MP2_I2C0_IC_INTR_STAT_R_RESTART_DET_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_GET_R_MST_ON_HOLD(mp2_i2c0_ic_intr_stat) \
     ((mp2_i2c0_ic_intr_stat & MP2_I2C0_IC_INTR_STAT_R_MST_ON_HOLD_MASK) >> MP2_I2C0_IC_INTR_STAT_R_MST_ON_HOLD_SHIFT)

#define MP2_I2C0_IC_INTR_STAT_SET_R_RX_UNDER(mp2_i2c0_ic_intr_stat_reg, r_rx_under) \
     mp2_i2c0_ic_intr_stat_reg = (mp2_i2c0_ic_intr_stat_reg & ~MP2_I2C0_IC_INTR_STAT_R_RX_UNDER_MASK) | (r_rx_under << MP2_I2C0_IC_INTR_STAT_R_RX_UNDER_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_SET_R_RX_OVER(mp2_i2c0_ic_intr_stat_reg, r_rx_over) \
     mp2_i2c0_ic_intr_stat_reg = (mp2_i2c0_ic_intr_stat_reg & ~MP2_I2C0_IC_INTR_STAT_R_RX_OVER_MASK) | (r_rx_over << MP2_I2C0_IC_INTR_STAT_R_RX_OVER_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_SET_R_RX_FULL(mp2_i2c0_ic_intr_stat_reg, r_rx_full) \
     mp2_i2c0_ic_intr_stat_reg = (mp2_i2c0_ic_intr_stat_reg & ~MP2_I2C0_IC_INTR_STAT_R_RX_FULL_MASK) | (r_rx_full << MP2_I2C0_IC_INTR_STAT_R_RX_FULL_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_SET_R_TX_OVER(mp2_i2c0_ic_intr_stat_reg, r_tx_over) \
     mp2_i2c0_ic_intr_stat_reg = (mp2_i2c0_ic_intr_stat_reg & ~MP2_I2C0_IC_INTR_STAT_R_TX_OVER_MASK) | (r_tx_over << MP2_I2C0_IC_INTR_STAT_R_TX_OVER_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_SET_R_TX_EMPTY(mp2_i2c0_ic_intr_stat_reg, r_tx_empty) \
     mp2_i2c0_ic_intr_stat_reg = (mp2_i2c0_ic_intr_stat_reg & ~MP2_I2C0_IC_INTR_STAT_R_TX_EMPTY_MASK) | (r_tx_empty << MP2_I2C0_IC_INTR_STAT_R_TX_EMPTY_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_SET_R_RD_REQ(mp2_i2c0_ic_intr_stat_reg, r_rd_req) \
     mp2_i2c0_ic_intr_stat_reg = (mp2_i2c0_ic_intr_stat_reg & ~MP2_I2C0_IC_INTR_STAT_R_RD_REQ_MASK) | (r_rd_req << MP2_I2C0_IC_INTR_STAT_R_RD_REQ_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_SET_R_TX_ABRT(mp2_i2c0_ic_intr_stat_reg, r_tx_abrt) \
     mp2_i2c0_ic_intr_stat_reg = (mp2_i2c0_ic_intr_stat_reg & ~MP2_I2C0_IC_INTR_STAT_R_TX_ABRT_MASK) | (r_tx_abrt << MP2_I2C0_IC_INTR_STAT_R_TX_ABRT_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_SET_R_RX_DONE(mp2_i2c0_ic_intr_stat_reg, r_rx_done) \
     mp2_i2c0_ic_intr_stat_reg = (mp2_i2c0_ic_intr_stat_reg & ~MP2_I2C0_IC_INTR_STAT_R_RX_DONE_MASK) | (r_rx_done << MP2_I2C0_IC_INTR_STAT_R_RX_DONE_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_SET_R_ACTIVITY(mp2_i2c0_ic_intr_stat_reg, r_activity) \
     mp2_i2c0_ic_intr_stat_reg = (mp2_i2c0_ic_intr_stat_reg & ~MP2_I2C0_IC_INTR_STAT_R_ACTIVITY_MASK) | (r_activity << MP2_I2C0_IC_INTR_STAT_R_ACTIVITY_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_SET_R_STOP_DET(mp2_i2c0_ic_intr_stat_reg, r_stop_det) \
     mp2_i2c0_ic_intr_stat_reg = (mp2_i2c0_ic_intr_stat_reg & ~MP2_I2C0_IC_INTR_STAT_R_STOP_DET_MASK) | (r_stop_det << MP2_I2C0_IC_INTR_STAT_R_STOP_DET_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_SET_R_START_DET(mp2_i2c0_ic_intr_stat_reg, r_start_det) \
     mp2_i2c0_ic_intr_stat_reg = (mp2_i2c0_ic_intr_stat_reg & ~MP2_I2C0_IC_INTR_STAT_R_START_DET_MASK) | (r_start_det << MP2_I2C0_IC_INTR_STAT_R_START_DET_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_SET_R_GEN_CALL(mp2_i2c0_ic_intr_stat_reg, r_gen_call) \
     mp2_i2c0_ic_intr_stat_reg = (mp2_i2c0_ic_intr_stat_reg & ~MP2_I2C0_IC_INTR_STAT_R_GEN_CALL_MASK) | (r_gen_call << MP2_I2C0_IC_INTR_STAT_R_GEN_CALL_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_SET_R_RESTART_DET(mp2_i2c0_ic_intr_stat_reg, r_restart_det) \
     mp2_i2c0_ic_intr_stat_reg = (mp2_i2c0_ic_intr_stat_reg & ~MP2_I2C0_IC_INTR_STAT_R_RESTART_DET_MASK) | (r_restart_det << MP2_I2C0_IC_INTR_STAT_R_RESTART_DET_SHIFT)
#define MP2_I2C0_IC_INTR_STAT_SET_R_MST_ON_HOLD(mp2_i2c0_ic_intr_stat_reg, r_mst_on_hold) \
     mp2_i2c0_ic_intr_stat_reg = (mp2_i2c0_ic_intr_stat_reg & ~MP2_I2C0_IC_INTR_STAT_R_MST_ON_HOLD_MASK) | (r_mst_on_hold << MP2_I2C0_IC_INTR_STAT_R_MST_ON_HOLD_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_intr_stat_t {
          unsigned int r_rx_under                     : MP2_I2C0_IC_INTR_STAT_R_RX_UNDER_SIZE;
          unsigned int r_rx_over                      : MP2_I2C0_IC_INTR_STAT_R_RX_OVER_SIZE;
          unsigned int r_rx_full                      : MP2_I2C0_IC_INTR_STAT_R_RX_FULL_SIZE;
          unsigned int r_tx_over                      : MP2_I2C0_IC_INTR_STAT_R_TX_OVER_SIZE;
          unsigned int r_tx_empty                     : MP2_I2C0_IC_INTR_STAT_R_TX_EMPTY_SIZE;
          unsigned int r_rd_req                       : MP2_I2C0_IC_INTR_STAT_R_RD_REQ_SIZE;
          unsigned int r_tx_abrt                      : MP2_I2C0_IC_INTR_STAT_R_TX_ABRT_SIZE;
          unsigned int r_rx_done                      : MP2_I2C0_IC_INTR_STAT_R_RX_DONE_SIZE;
          unsigned int r_activity                     : MP2_I2C0_IC_INTR_STAT_R_ACTIVITY_SIZE;
          unsigned int r_stop_det                     : MP2_I2C0_IC_INTR_STAT_R_STOP_DET_SIZE;
          unsigned int r_start_det                    : MP2_I2C0_IC_INTR_STAT_R_START_DET_SIZE;
          unsigned int r_gen_call                     : MP2_I2C0_IC_INTR_STAT_R_GEN_CALL_SIZE;
          unsigned int r_restart_det                  : MP2_I2C0_IC_INTR_STAT_R_RESTART_DET_SIZE;
          unsigned int r_mst_on_hold                  : MP2_I2C0_IC_INTR_STAT_R_MST_ON_HOLD_SIZE;
          unsigned int                                : 18;
     } mp2_i2c0_ic_intr_stat_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_intr_stat_t {
          unsigned int                                : 18;
          unsigned int r_mst_on_hold                  : MP2_I2C0_IC_INTR_STAT_R_MST_ON_HOLD_SIZE;
          unsigned int r_restart_det                  : MP2_I2C0_IC_INTR_STAT_R_RESTART_DET_SIZE;
          unsigned int r_gen_call                     : MP2_I2C0_IC_INTR_STAT_R_GEN_CALL_SIZE;
          unsigned int r_start_det                    : MP2_I2C0_IC_INTR_STAT_R_START_DET_SIZE;
          unsigned int r_stop_det                     : MP2_I2C0_IC_INTR_STAT_R_STOP_DET_SIZE;
          unsigned int r_activity                     : MP2_I2C0_IC_INTR_STAT_R_ACTIVITY_SIZE;
          unsigned int r_rx_done                      : MP2_I2C0_IC_INTR_STAT_R_RX_DONE_SIZE;
          unsigned int r_tx_abrt                      : MP2_I2C0_IC_INTR_STAT_R_TX_ABRT_SIZE;
          unsigned int r_rd_req                       : MP2_I2C0_IC_INTR_STAT_R_RD_REQ_SIZE;
          unsigned int r_tx_empty                     : MP2_I2C0_IC_INTR_STAT_R_TX_EMPTY_SIZE;
          unsigned int r_tx_over                      : MP2_I2C0_IC_INTR_STAT_R_TX_OVER_SIZE;
          unsigned int r_rx_full                      : MP2_I2C0_IC_INTR_STAT_R_RX_FULL_SIZE;
          unsigned int r_rx_over                      : MP2_I2C0_IC_INTR_STAT_R_RX_OVER_SIZE;
          unsigned int r_rx_under                     : MP2_I2C0_IC_INTR_STAT_R_RX_UNDER_SIZE;
     } mp2_i2c0_ic_intr_stat_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_intr_stat_t f;
} mp2_i2c0_ic_intr_stat_u;


/*
 * MP2_I2C0_IC_INTR_MASK struct
 */

#define MP2_I2C0_IC_INTR_MASK_REG_SIZE 32
#define MP2_I2C0_IC_INTR_MASK_M_RX_UNDER_SIZE 1
#define MP2_I2C0_IC_INTR_MASK_M_RX_OVER_SIZE 1
#define MP2_I2C0_IC_INTR_MASK_M_RX_FULL_SIZE 1
#define MP2_I2C0_IC_INTR_MASK_M_TX_OVER_SIZE 1
#define MP2_I2C0_IC_INTR_MASK_M_TX_EMPTY_SIZE 1
#define MP2_I2C0_IC_INTR_MASK_M_RD_REQ_SIZE 1
#define MP2_I2C0_IC_INTR_MASK_M_TX_ABRT_SIZE 1
#define MP2_I2C0_IC_INTR_MASK_M_RX_DONE_SIZE 1
#define MP2_I2C0_IC_INTR_MASK_M_ACTIVITY_SIZE 1
#define MP2_I2C0_IC_INTR_MASK_M_STOP_DET_SIZE 1
#define MP2_I2C0_IC_INTR_MASK_M_START_DET_SIZE 1
#define MP2_I2C0_IC_INTR_MASK_M_GEN_CALL_SIZE 1
#define MP2_I2C0_IC_INTR_MASK_M_RESTART_DET_SIZE 1
#define MP2_I2C0_IC_INTR_MASK_M_MST_ON_HOLD_SIZE 1

#define MP2_I2C0_IC_INTR_MASK_M_RX_UNDER_SHIFT 0
#define MP2_I2C0_IC_INTR_MASK_M_RX_OVER_SHIFT 1
#define MP2_I2C0_IC_INTR_MASK_M_RX_FULL_SHIFT 2
#define MP2_I2C0_IC_INTR_MASK_M_TX_OVER_SHIFT 3
#define MP2_I2C0_IC_INTR_MASK_M_TX_EMPTY_SHIFT 4
#define MP2_I2C0_IC_INTR_MASK_M_RD_REQ_SHIFT 5
#define MP2_I2C0_IC_INTR_MASK_M_TX_ABRT_SHIFT 6
#define MP2_I2C0_IC_INTR_MASK_M_RX_DONE_SHIFT 7
#define MP2_I2C0_IC_INTR_MASK_M_ACTIVITY_SHIFT 8
#define MP2_I2C0_IC_INTR_MASK_M_STOP_DET_SHIFT 9
#define MP2_I2C0_IC_INTR_MASK_M_START_DET_SHIFT 10
#define MP2_I2C0_IC_INTR_MASK_M_GEN_CALL_SHIFT 11
#define MP2_I2C0_IC_INTR_MASK_M_RESTART_DET_SHIFT 12
#define MP2_I2C0_IC_INTR_MASK_M_MST_ON_HOLD_SHIFT 13

#define MP2_I2C0_IC_INTR_MASK_M_RX_UNDER_MASK 0x1
#define MP2_I2C0_IC_INTR_MASK_M_RX_OVER_MASK 0x2
#define MP2_I2C0_IC_INTR_MASK_M_RX_FULL_MASK 0x4
#define MP2_I2C0_IC_INTR_MASK_M_TX_OVER_MASK 0x8
#define MP2_I2C0_IC_INTR_MASK_M_TX_EMPTY_MASK 0x10
#define MP2_I2C0_IC_INTR_MASK_M_RD_REQ_MASK 0x20
#define MP2_I2C0_IC_INTR_MASK_M_TX_ABRT_MASK 0x40
#define MP2_I2C0_IC_INTR_MASK_M_RX_DONE_MASK 0x80
#define MP2_I2C0_IC_INTR_MASK_M_ACTIVITY_MASK 0x100
#define MP2_I2C0_IC_INTR_MASK_M_STOP_DET_MASK 0x200
#define MP2_I2C0_IC_INTR_MASK_M_START_DET_MASK 0x400
#define MP2_I2C0_IC_INTR_MASK_M_GEN_CALL_MASK 0x800
#define MP2_I2C0_IC_INTR_MASK_M_RESTART_DET_MASK 0x1000
#define MP2_I2C0_IC_INTR_MASK_M_MST_ON_HOLD_MASK 0x2000

#define MP2_I2C0_IC_INTR_MASK_MASK \
     (MP2_I2C0_IC_INTR_MASK_M_RX_UNDER_MASK | \
      MP2_I2C0_IC_INTR_MASK_M_RX_OVER_MASK | \
      MP2_I2C0_IC_INTR_MASK_M_RX_FULL_MASK | \
      MP2_I2C0_IC_INTR_MASK_M_TX_OVER_MASK | \
      MP2_I2C0_IC_INTR_MASK_M_TX_EMPTY_MASK | \
      MP2_I2C0_IC_INTR_MASK_M_RD_REQ_MASK | \
      MP2_I2C0_IC_INTR_MASK_M_TX_ABRT_MASK | \
      MP2_I2C0_IC_INTR_MASK_M_RX_DONE_MASK | \
      MP2_I2C0_IC_INTR_MASK_M_ACTIVITY_MASK | \
      MP2_I2C0_IC_INTR_MASK_M_STOP_DET_MASK | \
      MP2_I2C0_IC_INTR_MASK_M_START_DET_MASK | \
      MP2_I2C0_IC_INTR_MASK_M_GEN_CALL_MASK | \
      MP2_I2C0_IC_INTR_MASK_M_RESTART_DET_MASK | \
      MP2_I2C0_IC_INTR_MASK_M_MST_ON_HOLD_MASK)

#define MP2_I2C0_IC_INTR_MASK_DEFAULT  0x00000000

#define MP2_I2C0_IC_INTR_MASK_GET_M_RX_UNDER(mp2_i2c0_ic_intr_mask) \
     ((mp2_i2c0_ic_intr_mask & MP2_I2C0_IC_INTR_MASK_M_RX_UNDER_MASK) >> MP2_I2C0_IC_INTR_MASK_M_RX_UNDER_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_GET_M_RX_OVER(mp2_i2c0_ic_intr_mask) \
     ((mp2_i2c0_ic_intr_mask & MP2_I2C0_IC_INTR_MASK_M_RX_OVER_MASK) >> MP2_I2C0_IC_INTR_MASK_M_RX_OVER_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_GET_M_RX_FULL(mp2_i2c0_ic_intr_mask) \
     ((mp2_i2c0_ic_intr_mask & MP2_I2C0_IC_INTR_MASK_M_RX_FULL_MASK) >> MP2_I2C0_IC_INTR_MASK_M_RX_FULL_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_GET_M_TX_OVER(mp2_i2c0_ic_intr_mask) \
     ((mp2_i2c0_ic_intr_mask & MP2_I2C0_IC_INTR_MASK_M_TX_OVER_MASK) >> MP2_I2C0_IC_INTR_MASK_M_TX_OVER_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_GET_M_TX_EMPTY(mp2_i2c0_ic_intr_mask) \
     ((mp2_i2c0_ic_intr_mask & MP2_I2C0_IC_INTR_MASK_M_TX_EMPTY_MASK) >> MP2_I2C0_IC_INTR_MASK_M_TX_EMPTY_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_GET_M_RD_REQ(mp2_i2c0_ic_intr_mask) \
     ((mp2_i2c0_ic_intr_mask & MP2_I2C0_IC_INTR_MASK_M_RD_REQ_MASK) >> MP2_I2C0_IC_INTR_MASK_M_RD_REQ_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_GET_M_TX_ABRT(mp2_i2c0_ic_intr_mask) \
     ((mp2_i2c0_ic_intr_mask & MP2_I2C0_IC_INTR_MASK_M_TX_ABRT_MASK) >> MP2_I2C0_IC_INTR_MASK_M_TX_ABRT_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_GET_M_RX_DONE(mp2_i2c0_ic_intr_mask) \
     ((mp2_i2c0_ic_intr_mask & MP2_I2C0_IC_INTR_MASK_M_RX_DONE_MASK) >> MP2_I2C0_IC_INTR_MASK_M_RX_DONE_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_GET_M_ACTIVITY(mp2_i2c0_ic_intr_mask) \
     ((mp2_i2c0_ic_intr_mask & MP2_I2C0_IC_INTR_MASK_M_ACTIVITY_MASK) >> MP2_I2C0_IC_INTR_MASK_M_ACTIVITY_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_GET_M_STOP_DET(mp2_i2c0_ic_intr_mask) \
     ((mp2_i2c0_ic_intr_mask & MP2_I2C0_IC_INTR_MASK_M_STOP_DET_MASK) >> MP2_I2C0_IC_INTR_MASK_M_STOP_DET_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_GET_M_START_DET(mp2_i2c0_ic_intr_mask) \
     ((mp2_i2c0_ic_intr_mask & MP2_I2C0_IC_INTR_MASK_M_START_DET_MASK) >> MP2_I2C0_IC_INTR_MASK_M_START_DET_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_GET_M_GEN_CALL(mp2_i2c0_ic_intr_mask) \
     ((mp2_i2c0_ic_intr_mask & MP2_I2C0_IC_INTR_MASK_M_GEN_CALL_MASK) >> MP2_I2C0_IC_INTR_MASK_M_GEN_CALL_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_GET_M_RESTART_DET(mp2_i2c0_ic_intr_mask) \
     ((mp2_i2c0_ic_intr_mask & MP2_I2C0_IC_INTR_MASK_M_RESTART_DET_MASK) >> MP2_I2C0_IC_INTR_MASK_M_RESTART_DET_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_GET_M_MST_ON_HOLD(mp2_i2c0_ic_intr_mask) \
     ((mp2_i2c0_ic_intr_mask & MP2_I2C0_IC_INTR_MASK_M_MST_ON_HOLD_MASK) >> MP2_I2C0_IC_INTR_MASK_M_MST_ON_HOLD_SHIFT)

#define MP2_I2C0_IC_INTR_MASK_SET_M_RX_UNDER(mp2_i2c0_ic_intr_mask_reg, m_rx_under) \
     mp2_i2c0_ic_intr_mask_reg = (mp2_i2c0_ic_intr_mask_reg & ~MP2_I2C0_IC_INTR_MASK_M_RX_UNDER_MASK) | (m_rx_under << MP2_I2C0_IC_INTR_MASK_M_RX_UNDER_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_SET_M_RX_OVER(mp2_i2c0_ic_intr_mask_reg, m_rx_over) \
     mp2_i2c0_ic_intr_mask_reg = (mp2_i2c0_ic_intr_mask_reg & ~MP2_I2C0_IC_INTR_MASK_M_RX_OVER_MASK) | (m_rx_over << MP2_I2C0_IC_INTR_MASK_M_RX_OVER_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_SET_M_RX_FULL(mp2_i2c0_ic_intr_mask_reg, m_rx_full) \
     mp2_i2c0_ic_intr_mask_reg = (mp2_i2c0_ic_intr_mask_reg & ~MP2_I2C0_IC_INTR_MASK_M_RX_FULL_MASK) | (m_rx_full << MP2_I2C0_IC_INTR_MASK_M_RX_FULL_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_SET_M_TX_OVER(mp2_i2c0_ic_intr_mask_reg, m_tx_over) \
     mp2_i2c0_ic_intr_mask_reg = (mp2_i2c0_ic_intr_mask_reg & ~MP2_I2C0_IC_INTR_MASK_M_TX_OVER_MASK) | (m_tx_over << MP2_I2C0_IC_INTR_MASK_M_TX_OVER_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_SET_M_TX_EMPTY(mp2_i2c0_ic_intr_mask_reg, m_tx_empty) \
     mp2_i2c0_ic_intr_mask_reg = (mp2_i2c0_ic_intr_mask_reg & ~MP2_I2C0_IC_INTR_MASK_M_TX_EMPTY_MASK) | (m_tx_empty << MP2_I2C0_IC_INTR_MASK_M_TX_EMPTY_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_SET_M_RD_REQ(mp2_i2c0_ic_intr_mask_reg, m_rd_req) \
     mp2_i2c0_ic_intr_mask_reg = (mp2_i2c0_ic_intr_mask_reg & ~MP2_I2C0_IC_INTR_MASK_M_RD_REQ_MASK) | (m_rd_req << MP2_I2C0_IC_INTR_MASK_M_RD_REQ_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_SET_M_TX_ABRT(mp2_i2c0_ic_intr_mask_reg, m_tx_abrt) \
     mp2_i2c0_ic_intr_mask_reg = (mp2_i2c0_ic_intr_mask_reg & ~MP2_I2C0_IC_INTR_MASK_M_TX_ABRT_MASK) | (m_tx_abrt << MP2_I2C0_IC_INTR_MASK_M_TX_ABRT_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_SET_M_RX_DONE(mp2_i2c0_ic_intr_mask_reg, m_rx_done) \
     mp2_i2c0_ic_intr_mask_reg = (mp2_i2c0_ic_intr_mask_reg & ~MP2_I2C0_IC_INTR_MASK_M_RX_DONE_MASK) | (m_rx_done << MP2_I2C0_IC_INTR_MASK_M_RX_DONE_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_SET_M_ACTIVITY(mp2_i2c0_ic_intr_mask_reg, m_activity) \
     mp2_i2c0_ic_intr_mask_reg = (mp2_i2c0_ic_intr_mask_reg & ~MP2_I2C0_IC_INTR_MASK_M_ACTIVITY_MASK) | (m_activity << MP2_I2C0_IC_INTR_MASK_M_ACTIVITY_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_SET_M_STOP_DET(mp2_i2c0_ic_intr_mask_reg, m_stop_det) \
     mp2_i2c0_ic_intr_mask_reg = (mp2_i2c0_ic_intr_mask_reg & ~MP2_I2C0_IC_INTR_MASK_M_STOP_DET_MASK) | (m_stop_det << MP2_I2C0_IC_INTR_MASK_M_STOP_DET_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_SET_M_START_DET(mp2_i2c0_ic_intr_mask_reg, m_start_det) \
     mp2_i2c0_ic_intr_mask_reg = (mp2_i2c0_ic_intr_mask_reg & ~MP2_I2C0_IC_INTR_MASK_M_START_DET_MASK) | (m_start_det << MP2_I2C0_IC_INTR_MASK_M_START_DET_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_SET_M_GEN_CALL(mp2_i2c0_ic_intr_mask_reg, m_gen_call) \
     mp2_i2c0_ic_intr_mask_reg = (mp2_i2c0_ic_intr_mask_reg & ~MP2_I2C0_IC_INTR_MASK_M_GEN_CALL_MASK) | (m_gen_call << MP2_I2C0_IC_INTR_MASK_M_GEN_CALL_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_SET_M_RESTART_DET(mp2_i2c0_ic_intr_mask_reg, m_restart_det) \
     mp2_i2c0_ic_intr_mask_reg = (mp2_i2c0_ic_intr_mask_reg & ~MP2_I2C0_IC_INTR_MASK_M_RESTART_DET_MASK) | (m_restart_det << MP2_I2C0_IC_INTR_MASK_M_RESTART_DET_SHIFT)
#define MP2_I2C0_IC_INTR_MASK_SET_M_MST_ON_HOLD(mp2_i2c0_ic_intr_mask_reg, m_mst_on_hold) \
     mp2_i2c0_ic_intr_mask_reg = (mp2_i2c0_ic_intr_mask_reg & ~MP2_I2C0_IC_INTR_MASK_M_MST_ON_HOLD_MASK) | (m_mst_on_hold << MP2_I2C0_IC_INTR_MASK_M_MST_ON_HOLD_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_intr_mask_t {
          unsigned int m_rx_under                     : MP2_I2C0_IC_INTR_MASK_M_RX_UNDER_SIZE;
          unsigned int m_rx_over                      : MP2_I2C0_IC_INTR_MASK_M_RX_OVER_SIZE;
          unsigned int m_rx_full                      : MP2_I2C0_IC_INTR_MASK_M_RX_FULL_SIZE;
          unsigned int m_tx_over                      : MP2_I2C0_IC_INTR_MASK_M_TX_OVER_SIZE;
          unsigned int m_tx_empty                     : MP2_I2C0_IC_INTR_MASK_M_TX_EMPTY_SIZE;
          unsigned int m_rd_req                       : MP2_I2C0_IC_INTR_MASK_M_RD_REQ_SIZE;
          unsigned int m_tx_abrt                      : MP2_I2C0_IC_INTR_MASK_M_TX_ABRT_SIZE;
          unsigned int m_rx_done                      : MP2_I2C0_IC_INTR_MASK_M_RX_DONE_SIZE;
          unsigned int m_activity                     : MP2_I2C0_IC_INTR_MASK_M_ACTIVITY_SIZE;
          unsigned int m_stop_det                     : MP2_I2C0_IC_INTR_MASK_M_STOP_DET_SIZE;
          unsigned int m_start_det                    : MP2_I2C0_IC_INTR_MASK_M_START_DET_SIZE;
          unsigned int m_gen_call                     : MP2_I2C0_IC_INTR_MASK_M_GEN_CALL_SIZE;
          unsigned int m_restart_det                  : MP2_I2C0_IC_INTR_MASK_M_RESTART_DET_SIZE;
          unsigned int m_mst_on_hold                  : MP2_I2C0_IC_INTR_MASK_M_MST_ON_HOLD_SIZE;
          unsigned int                                : 18;
     } mp2_i2c0_ic_intr_mask_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_intr_mask_t {
          unsigned int                                : 18;
          unsigned int m_mst_on_hold                  : MP2_I2C0_IC_INTR_MASK_M_MST_ON_HOLD_SIZE;
          unsigned int m_restart_det                  : MP2_I2C0_IC_INTR_MASK_M_RESTART_DET_SIZE;
          unsigned int m_gen_call                     : MP2_I2C0_IC_INTR_MASK_M_GEN_CALL_SIZE;
          unsigned int m_start_det                    : MP2_I2C0_IC_INTR_MASK_M_START_DET_SIZE;
          unsigned int m_stop_det                     : MP2_I2C0_IC_INTR_MASK_M_STOP_DET_SIZE;
          unsigned int m_activity                     : MP2_I2C0_IC_INTR_MASK_M_ACTIVITY_SIZE;
          unsigned int m_rx_done                      : MP2_I2C0_IC_INTR_MASK_M_RX_DONE_SIZE;
          unsigned int m_tx_abrt                      : MP2_I2C0_IC_INTR_MASK_M_TX_ABRT_SIZE;
          unsigned int m_rd_req                       : MP2_I2C0_IC_INTR_MASK_M_RD_REQ_SIZE;
          unsigned int m_tx_empty                     : MP2_I2C0_IC_INTR_MASK_M_TX_EMPTY_SIZE;
          unsigned int m_tx_over                      : MP2_I2C0_IC_INTR_MASK_M_TX_OVER_SIZE;
          unsigned int m_rx_full                      : MP2_I2C0_IC_INTR_MASK_M_RX_FULL_SIZE;
          unsigned int m_rx_over                      : MP2_I2C0_IC_INTR_MASK_M_RX_OVER_SIZE;
          unsigned int m_rx_under                     : MP2_I2C0_IC_INTR_MASK_M_RX_UNDER_SIZE;
     } mp2_i2c0_ic_intr_mask_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_intr_mask_t f;
} mp2_i2c0_ic_intr_mask_u;


/*
 * MP2_I2C0_IC_RAW_INTR_STAT struct
 */

#define MP2_I2C0_IC_RAW_INTR_STAT_REG_SIZE 32
#define MP2_I2C0_IC_RAW_INTR_STAT_RX_UNDER_SIZE 1
#define MP2_I2C0_IC_RAW_INTR_STAT_RX_OVER_SIZE 1
#define MP2_I2C0_IC_RAW_INTR_STAT_RX_FULL_SIZE 1
#define MP2_I2C0_IC_RAW_INTR_STAT_TX_OVER_SIZE 1
#define MP2_I2C0_IC_RAW_INTR_STAT_TX_EMPTY_SIZE 1
#define MP2_I2C0_IC_RAW_INTR_STAT_RD_REQ_SIZE 1
#define MP2_I2C0_IC_RAW_INTR_STAT_TX_ABRT_SIZE 1
#define MP2_I2C0_IC_RAW_INTR_STAT_RX_DONE_SIZE 1
#define MP2_I2C0_IC_RAW_INTR_STAT_ACTIVITY_SIZE 1
#define MP2_I2C0_IC_RAW_INTR_STAT_STOP_DET_SIZE 1
#define MP2_I2C0_IC_RAW_INTR_STAT_START_DET_SIZE 1
#define MP2_I2C0_IC_RAW_INTR_STAT_GEN_CALL_SIZE 1
#define MP2_I2C0_IC_RAW_INTR_STAT_RESTART_DET_SIZE 1
#define MP2_I2C0_IC_RAW_INTR_STAT_MST_ON_HOLD_SIZE 1

#define MP2_I2C0_IC_RAW_INTR_STAT_RX_UNDER_SHIFT 0
#define MP2_I2C0_IC_RAW_INTR_STAT_RX_OVER_SHIFT 1
#define MP2_I2C0_IC_RAW_INTR_STAT_RX_FULL_SHIFT 2
#define MP2_I2C0_IC_RAW_INTR_STAT_TX_OVER_SHIFT 3
#define MP2_I2C0_IC_RAW_INTR_STAT_TX_EMPTY_SHIFT 4
#define MP2_I2C0_IC_RAW_INTR_STAT_RD_REQ_SHIFT 5
#define MP2_I2C0_IC_RAW_INTR_STAT_TX_ABRT_SHIFT 6
#define MP2_I2C0_IC_RAW_INTR_STAT_RX_DONE_SHIFT 7
#define MP2_I2C0_IC_RAW_INTR_STAT_ACTIVITY_SHIFT 8
#define MP2_I2C0_IC_RAW_INTR_STAT_STOP_DET_SHIFT 9
#define MP2_I2C0_IC_RAW_INTR_STAT_START_DET_SHIFT 10
#define MP2_I2C0_IC_RAW_INTR_STAT_GEN_CALL_SHIFT 11
#define MP2_I2C0_IC_RAW_INTR_STAT_RESTART_DET_SHIFT 12
#define MP2_I2C0_IC_RAW_INTR_STAT_MST_ON_HOLD_SHIFT 13

#define MP2_I2C0_IC_RAW_INTR_STAT_RX_UNDER_MASK 0x1
#define MP2_I2C0_IC_RAW_INTR_STAT_RX_OVER_MASK 0x2
#define MP2_I2C0_IC_RAW_INTR_STAT_RX_FULL_MASK 0x4
#define MP2_I2C0_IC_RAW_INTR_STAT_TX_OVER_MASK 0x8
#define MP2_I2C0_IC_RAW_INTR_STAT_TX_EMPTY_MASK 0x10
#define MP2_I2C0_IC_RAW_INTR_STAT_RD_REQ_MASK 0x20
#define MP2_I2C0_IC_RAW_INTR_STAT_TX_ABRT_MASK 0x40
#define MP2_I2C0_IC_RAW_INTR_STAT_RX_DONE_MASK 0x80
#define MP2_I2C0_IC_RAW_INTR_STAT_ACTIVITY_MASK 0x100
#define MP2_I2C0_IC_RAW_INTR_STAT_STOP_DET_MASK 0x200
#define MP2_I2C0_IC_RAW_INTR_STAT_START_DET_MASK 0x400
#define MP2_I2C0_IC_RAW_INTR_STAT_GEN_CALL_MASK 0x800
#define MP2_I2C0_IC_RAW_INTR_STAT_RESTART_DET_MASK 0x1000
#define MP2_I2C0_IC_RAW_INTR_STAT_MST_ON_HOLD_MASK 0x2000

#define MP2_I2C0_IC_RAW_INTR_STAT_MASK \
     (MP2_I2C0_IC_RAW_INTR_STAT_RX_UNDER_MASK | \
      MP2_I2C0_IC_RAW_INTR_STAT_RX_OVER_MASK | \
      MP2_I2C0_IC_RAW_INTR_STAT_RX_FULL_MASK | \
      MP2_I2C0_IC_RAW_INTR_STAT_TX_OVER_MASK | \
      MP2_I2C0_IC_RAW_INTR_STAT_TX_EMPTY_MASK | \
      MP2_I2C0_IC_RAW_INTR_STAT_RD_REQ_MASK | \
      MP2_I2C0_IC_RAW_INTR_STAT_TX_ABRT_MASK | \
      MP2_I2C0_IC_RAW_INTR_STAT_RX_DONE_MASK | \
      MP2_I2C0_IC_RAW_INTR_STAT_ACTIVITY_MASK | \
      MP2_I2C0_IC_RAW_INTR_STAT_STOP_DET_MASK | \
      MP2_I2C0_IC_RAW_INTR_STAT_START_DET_MASK | \
      MP2_I2C0_IC_RAW_INTR_STAT_GEN_CALL_MASK | \
      MP2_I2C0_IC_RAW_INTR_STAT_RESTART_DET_MASK | \
      MP2_I2C0_IC_RAW_INTR_STAT_MST_ON_HOLD_MASK)

#define MP2_I2C0_IC_RAW_INTR_STAT_DEFAULT 0x00000000

#define MP2_I2C0_IC_RAW_INTR_STAT_GET_RX_UNDER(mp2_i2c0_ic_raw_intr_stat) \
     ((mp2_i2c0_ic_raw_intr_stat & MP2_I2C0_IC_RAW_INTR_STAT_RX_UNDER_MASK) >> MP2_I2C0_IC_RAW_INTR_STAT_RX_UNDER_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_GET_RX_OVER(mp2_i2c0_ic_raw_intr_stat) \
     ((mp2_i2c0_ic_raw_intr_stat & MP2_I2C0_IC_RAW_INTR_STAT_RX_OVER_MASK) >> MP2_I2C0_IC_RAW_INTR_STAT_RX_OVER_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_GET_RX_FULL(mp2_i2c0_ic_raw_intr_stat) \
     ((mp2_i2c0_ic_raw_intr_stat & MP2_I2C0_IC_RAW_INTR_STAT_RX_FULL_MASK) >> MP2_I2C0_IC_RAW_INTR_STAT_RX_FULL_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_GET_TX_OVER(mp2_i2c0_ic_raw_intr_stat) \
     ((mp2_i2c0_ic_raw_intr_stat & MP2_I2C0_IC_RAW_INTR_STAT_TX_OVER_MASK) >> MP2_I2C0_IC_RAW_INTR_STAT_TX_OVER_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_GET_TX_EMPTY(mp2_i2c0_ic_raw_intr_stat) \
     ((mp2_i2c0_ic_raw_intr_stat & MP2_I2C0_IC_RAW_INTR_STAT_TX_EMPTY_MASK) >> MP2_I2C0_IC_RAW_INTR_STAT_TX_EMPTY_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_GET_RD_REQ(mp2_i2c0_ic_raw_intr_stat) \
     ((mp2_i2c0_ic_raw_intr_stat & MP2_I2C0_IC_RAW_INTR_STAT_RD_REQ_MASK) >> MP2_I2C0_IC_RAW_INTR_STAT_RD_REQ_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_GET_TX_ABRT(mp2_i2c0_ic_raw_intr_stat) \
     ((mp2_i2c0_ic_raw_intr_stat & MP2_I2C0_IC_RAW_INTR_STAT_TX_ABRT_MASK) >> MP2_I2C0_IC_RAW_INTR_STAT_TX_ABRT_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_GET_RX_DONE(mp2_i2c0_ic_raw_intr_stat) \
     ((mp2_i2c0_ic_raw_intr_stat & MP2_I2C0_IC_RAW_INTR_STAT_RX_DONE_MASK) >> MP2_I2C0_IC_RAW_INTR_STAT_RX_DONE_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_GET_ACTIVITY(mp2_i2c0_ic_raw_intr_stat) \
     ((mp2_i2c0_ic_raw_intr_stat & MP2_I2C0_IC_RAW_INTR_STAT_ACTIVITY_MASK) >> MP2_I2C0_IC_RAW_INTR_STAT_ACTIVITY_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_GET_STOP_DET(mp2_i2c0_ic_raw_intr_stat) \
     ((mp2_i2c0_ic_raw_intr_stat & MP2_I2C0_IC_RAW_INTR_STAT_STOP_DET_MASK) >> MP2_I2C0_IC_RAW_INTR_STAT_STOP_DET_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_GET_START_DET(mp2_i2c0_ic_raw_intr_stat) \
     ((mp2_i2c0_ic_raw_intr_stat & MP2_I2C0_IC_RAW_INTR_STAT_START_DET_MASK) >> MP2_I2C0_IC_RAW_INTR_STAT_START_DET_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_GET_GEN_CALL(mp2_i2c0_ic_raw_intr_stat) \
     ((mp2_i2c0_ic_raw_intr_stat & MP2_I2C0_IC_RAW_INTR_STAT_GEN_CALL_MASK) >> MP2_I2C0_IC_RAW_INTR_STAT_GEN_CALL_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_GET_RESTART_DET(mp2_i2c0_ic_raw_intr_stat) \
     ((mp2_i2c0_ic_raw_intr_stat & MP2_I2C0_IC_RAW_INTR_STAT_RESTART_DET_MASK) >> MP2_I2C0_IC_RAW_INTR_STAT_RESTART_DET_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_GET_MST_ON_HOLD(mp2_i2c0_ic_raw_intr_stat) \
     ((mp2_i2c0_ic_raw_intr_stat & MP2_I2C0_IC_RAW_INTR_STAT_MST_ON_HOLD_MASK) >> MP2_I2C0_IC_RAW_INTR_STAT_MST_ON_HOLD_SHIFT)

#define MP2_I2C0_IC_RAW_INTR_STAT_SET_RX_UNDER(mp2_i2c0_ic_raw_intr_stat_reg, rx_under) \
     mp2_i2c0_ic_raw_intr_stat_reg = (mp2_i2c0_ic_raw_intr_stat_reg & ~MP2_I2C0_IC_RAW_INTR_STAT_RX_UNDER_MASK) | (rx_under << MP2_I2C0_IC_RAW_INTR_STAT_RX_UNDER_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_SET_RX_OVER(mp2_i2c0_ic_raw_intr_stat_reg, rx_over) \
     mp2_i2c0_ic_raw_intr_stat_reg = (mp2_i2c0_ic_raw_intr_stat_reg & ~MP2_I2C0_IC_RAW_INTR_STAT_RX_OVER_MASK) | (rx_over << MP2_I2C0_IC_RAW_INTR_STAT_RX_OVER_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_SET_RX_FULL(mp2_i2c0_ic_raw_intr_stat_reg, rx_full) \
     mp2_i2c0_ic_raw_intr_stat_reg = (mp2_i2c0_ic_raw_intr_stat_reg & ~MP2_I2C0_IC_RAW_INTR_STAT_RX_FULL_MASK) | (rx_full << MP2_I2C0_IC_RAW_INTR_STAT_RX_FULL_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_SET_TX_OVER(mp2_i2c0_ic_raw_intr_stat_reg, tx_over) \
     mp2_i2c0_ic_raw_intr_stat_reg = (mp2_i2c0_ic_raw_intr_stat_reg & ~MP2_I2C0_IC_RAW_INTR_STAT_TX_OVER_MASK) | (tx_over << MP2_I2C0_IC_RAW_INTR_STAT_TX_OVER_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_SET_TX_EMPTY(mp2_i2c0_ic_raw_intr_stat_reg, tx_empty) \
     mp2_i2c0_ic_raw_intr_stat_reg = (mp2_i2c0_ic_raw_intr_stat_reg & ~MP2_I2C0_IC_RAW_INTR_STAT_TX_EMPTY_MASK) | (tx_empty << MP2_I2C0_IC_RAW_INTR_STAT_TX_EMPTY_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_SET_RD_REQ(mp2_i2c0_ic_raw_intr_stat_reg, rd_req) \
     mp2_i2c0_ic_raw_intr_stat_reg = (mp2_i2c0_ic_raw_intr_stat_reg & ~MP2_I2C0_IC_RAW_INTR_STAT_RD_REQ_MASK) | (rd_req << MP2_I2C0_IC_RAW_INTR_STAT_RD_REQ_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_SET_TX_ABRT(mp2_i2c0_ic_raw_intr_stat_reg, tx_abrt) \
     mp2_i2c0_ic_raw_intr_stat_reg = (mp2_i2c0_ic_raw_intr_stat_reg & ~MP2_I2C0_IC_RAW_INTR_STAT_TX_ABRT_MASK) | (tx_abrt << MP2_I2C0_IC_RAW_INTR_STAT_TX_ABRT_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_SET_RX_DONE(mp2_i2c0_ic_raw_intr_stat_reg, rx_done) \
     mp2_i2c0_ic_raw_intr_stat_reg = (mp2_i2c0_ic_raw_intr_stat_reg & ~MP2_I2C0_IC_RAW_INTR_STAT_RX_DONE_MASK) | (rx_done << MP2_I2C0_IC_RAW_INTR_STAT_RX_DONE_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_SET_ACTIVITY(mp2_i2c0_ic_raw_intr_stat_reg, activity) \
     mp2_i2c0_ic_raw_intr_stat_reg = (mp2_i2c0_ic_raw_intr_stat_reg & ~MP2_I2C0_IC_RAW_INTR_STAT_ACTIVITY_MASK) | (activity << MP2_I2C0_IC_RAW_INTR_STAT_ACTIVITY_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_SET_STOP_DET(mp2_i2c0_ic_raw_intr_stat_reg, stop_det) \
     mp2_i2c0_ic_raw_intr_stat_reg = (mp2_i2c0_ic_raw_intr_stat_reg & ~MP2_I2C0_IC_RAW_INTR_STAT_STOP_DET_MASK) | (stop_det << MP2_I2C0_IC_RAW_INTR_STAT_STOP_DET_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_SET_START_DET(mp2_i2c0_ic_raw_intr_stat_reg, start_det) \
     mp2_i2c0_ic_raw_intr_stat_reg = (mp2_i2c0_ic_raw_intr_stat_reg & ~MP2_I2C0_IC_RAW_INTR_STAT_START_DET_MASK) | (start_det << MP2_I2C0_IC_RAW_INTR_STAT_START_DET_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_SET_GEN_CALL(mp2_i2c0_ic_raw_intr_stat_reg, gen_call) \
     mp2_i2c0_ic_raw_intr_stat_reg = (mp2_i2c0_ic_raw_intr_stat_reg & ~MP2_I2C0_IC_RAW_INTR_STAT_GEN_CALL_MASK) | (gen_call << MP2_I2C0_IC_RAW_INTR_STAT_GEN_CALL_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_SET_RESTART_DET(mp2_i2c0_ic_raw_intr_stat_reg, restart_det) \
     mp2_i2c0_ic_raw_intr_stat_reg = (mp2_i2c0_ic_raw_intr_stat_reg & ~MP2_I2C0_IC_RAW_INTR_STAT_RESTART_DET_MASK) | (restart_det << MP2_I2C0_IC_RAW_INTR_STAT_RESTART_DET_SHIFT)
#define MP2_I2C0_IC_RAW_INTR_STAT_SET_MST_ON_HOLD(mp2_i2c0_ic_raw_intr_stat_reg, mst_on_hold) \
     mp2_i2c0_ic_raw_intr_stat_reg = (mp2_i2c0_ic_raw_intr_stat_reg & ~MP2_I2C0_IC_RAW_INTR_STAT_MST_ON_HOLD_MASK) | (mst_on_hold << MP2_I2C0_IC_RAW_INTR_STAT_MST_ON_HOLD_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_raw_intr_stat_t {
          unsigned int rx_under                       : MP2_I2C0_IC_RAW_INTR_STAT_RX_UNDER_SIZE;
          unsigned int rx_over                        : MP2_I2C0_IC_RAW_INTR_STAT_RX_OVER_SIZE;
          unsigned int rx_full                        : MP2_I2C0_IC_RAW_INTR_STAT_RX_FULL_SIZE;
          unsigned int tx_over                        : MP2_I2C0_IC_RAW_INTR_STAT_TX_OVER_SIZE;
          unsigned int tx_empty                       : MP2_I2C0_IC_RAW_INTR_STAT_TX_EMPTY_SIZE;
          unsigned int rd_req                         : MP2_I2C0_IC_RAW_INTR_STAT_RD_REQ_SIZE;
          unsigned int tx_abrt                        : MP2_I2C0_IC_RAW_INTR_STAT_TX_ABRT_SIZE;
          unsigned int rx_done                        : MP2_I2C0_IC_RAW_INTR_STAT_RX_DONE_SIZE;
          unsigned int activity                       : MP2_I2C0_IC_RAW_INTR_STAT_ACTIVITY_SIZE;
          unsigned int stop_det                       : MP2_I2C0_IC_RAW_INTR_STAT_STOP_DET_SIZE;
          unsigned int start_det                      : MP2_I2C0_IC_RAW_INTR_STAT_START_DET_SIZE;
          unsigned int gen_call                       : MP2_I2C0_IC_RAW_INTR_STAT_GEN_CALL_SIZE;
          unsigned int restart_det                    : MP2_I2C0_IC_RAW_INTR_STAT_RESTART_DET_SIZE;
          unsigned int mst_on_hold                    : MP2_I2C0_IC_RAW_INTR_STAT_MST_ON_HOLD_SIZE;
          unsigned int                                : 18;
     } mp2_i2c0_ic_raw_intr_stat_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_raw_intr_stat_t {
          unsigned int                                : 18;
          unsigned int mst_on_hold                    : MP2_I2C0_IC_RAW_INTR_STAT_MST_ON_HOLD_SIZE;
          unsigned int restart_det                    : MP2_I2C0_IC_RAW_INTR_STAT_RESTART_DET_SIZE;
          unsigned int gen_call                       : MP2_I2C0_IC_RAW_INTR_STAT_GEN_CALL_SIZE;
          unsigned int start_det                      : MP2_I2C0_IC_RAW_INTR_STAT_START_DET_SIZE;
          unsigned int stop_det                       : MP2_I2C0_IC_RAW_INTR_STAT_STOP_DET_SIZE;
          unsigned int activity                       : MP2_I2C0_IC_RAW_INTR_STAT_ACTIVITY_SIZE;
          unsigned int rx_done                        : MP2_I2C0_IC_RAW_INTR_STAT_RX_DONE_SIZE;
          unsigned int tx_abrt                        : MP2_I2C0_IC_RAW_INTR_STAT_TX_ABRT_SIZE;
          unsigned int rd_req                         : MP2_I2C0_IC_RAW_INTR_STAT_RD_REQ_SIZE;
          unsigned int tx_empty                       : MP2_I2C0_IC_RAW_INTR_STAT_TX_EMPTY_SIZE;
          unsigned int tx_over                        : MP2_I2C0_IC_RAW_INTR_STAT_TX_OVER_SIZE;
          unsigned int rx_full                        : MP2_I2C0_IC_RAW_INTR_STAT_RX_FULL_SIZE;
          unsigned int rx_over                        : MP2_I2C0_IC_RAW_INTR_STAT_RX_OVER_SIZE;
          unsigned int rx_under                       : MP2_I2C0_IC_RAW_INTR_STAT_RX_UNDER_SIZE;
     } mp2_i2c0_ic_raw_intr_stat_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_raw_intr_stat_t f;
} mp2_i2c0_ic_raw_intr_stat_u;


/*
 * MP2_I2C0_IC_RX_TL struct
 */

#define MP2_I2C0_IC_RX_TL_REG_SIZE     32
#define MP2_I2C0_IC_RX_TL_RX_TL_SIZE   8

#define MP2_I2C0_IC_RX_TL_RX_TL_SHIFT  0

#define MP2_I2C0_IC_RX_TL_RX_TL_MASK   0xff

#define MP2_I2C0_IC_RX_TL_MASK \
     (MP2_I2C0_IC_RX_TL_RX_TL_MASK)

#define MP2_I2C0_IC_RX_TL_DEFAULT      0x00000000

#define MP2_I2C0_IC_RX_TL_GET_RX_TL(mp2_i2c0_ic_rx_tl) \
     ((mp2_i2c0_ic_rx_tl & MP2_I2C0_IC_RX_TL_RX_TL_MASK) >> MP2_I2C0_IC_RX_TL_RX_TL_SHIFT)

#define MP2_I2C0_IC_RX_TL_SET_RX_TL(mp2_i2c0_ic_rx_tl_reg, rx_tl) \
     mp2_i2c0_ic_rx_tl_reg = (mp2_i2c0_ic_rx_tl_reg & ~MP2_I2C0_IC_RX_TL_RX_TL_MASK) | (rx_tl << MP2_I2C0_IC_RX_TL_RX_TL_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_rx_tl_t {
          unsigned int rx_tl                          : MP2_I2C0_IC_RX_TL_RX_TL_SIZE;
          unsigned int                                : 24;
     } mp2_i2c0_ic_rx_tl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_rx_tl_t {
          unsigned int                                : 24;
          unsigned int rx_tl                          : MP2_I2C0_IC_RX_TL_RX_TL_SIZE;
     } mp2_i2c0_ic_rx_tl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_rx_tl_t f;
} mp2_i2c0_ic_rx_tl_u;


/*
 * MP2_I2C0_IC_TX_TL struct
 */

#define MP2_I2C0_IC_TX_TL_REG_SIZE     32
#define MP2_I2C0_IC_TX_TL_TX_TL_SIZE   8

#define MP2_I2C0_IC_TX_TL_TX_TL_SHIFT  0

#define MP2_I2C0_IC_TX_TL_TX_TL_MASK   0xff

#define MP2_I2C0_IC_TX_TL_MASK \
     (MP2_I2C0_IC_TX_TL_TX_TL_MASK)

#define MP2_I2C0_IC_TX_TL_DEFAULT      0x00000000

#define MP2_I2C0_IC_TX_TL_GET_TX_TL(mp2_i2c0_ic_tx_tl) \
     ((mp2_i2c0_ic_tx_tl & MP2_I2C0_IC_TX_TL_TX_TL_MASK) >> MP2_I2C0_IC_TX_TL_TX_TL_SHIFT)

#define MP2_I2C0_IC_TX_TL_SET_TX_TL(mp2_i2c0_ic_tx_tl_reg, tx_tl) \
     mp2_i2c0_ic_tx_tl_reg = (mp2_i2c0_ic_tx_tl_reg & ~MP2_I2C0_IC_TX_TL_TX_TL_MASK) | (tx_tl << MP2_I2C0_IC_TX_TL_TX_TL_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_tx_tl_t {
          unsigned int tx_tl                          : MP2_I2C0_IC_TX_TL_TX_TL_SIZE;
          unsigned int                                : 24;
     } mp2_i2c0_ic_tx_tl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_tx_tl_t {
          unsigned int                                : 24;
          unsigned int tx_tl                          : MP2_I2C0_IC_TX_TL_TX_TL_SIZE;
     } mp2_i2c0_ic_tx_tl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_tx_tl_t f;
} mp2_i2c0_ic_tx_tl_u;


/*
 * MP2_I2C0_IC_CLR_INTR struct
 */

#define MP2_I2C0_IC_CLR_INTR_REG_SIZE  32
#define MP2_I2C0_IC_CLR_INTR_CLR_INTR_SIZE 1

#define MP2_I2C0_IC_CLR_INTR_CLR_INTR_SHIFT 0

#define MP2_I2C0_IC_CLR_INTR_CLR_INTR_MASK 0x1

#define MP2_I2C0_IC_CLR_INTR_MASK \
     (MP2_I2C0_IC_CLR_INTR_CLR_INTR_MASK)

#define MP2_I2C0_IC_CLR_INTR_DEFAULT   0x00000000

#define MP2_I2C0_IC_CLR_INTR_GET_CLR_INTR(mp2_i2c0_ic_clr_intr) \
     ((mp2_i2c0_ic_clr_intr & MP2_I2C0_IC_CLR_INTR_CLR_INTR_MASK) >> MP2_I2C0_IC_CLR_INTR_CLR_INTR_SHIFT)

#define MP2_I2C0_IC_CLR_INTR_SET_CLR_INTR(mp2_i2c0_ic_clr_intr_reg, clr_intr) \
     mp2_i2c0_ic_clr_intr_reg = (mp2_i2c0_ic_clr_intr_reg & ~MP2_I2C0_IC_CLR_INTR_CLR_INTR_MASK) | (clr_intr << MP2_I2C0_IC_CLR_INTR_CLR_INTR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_intr_t {
          unsigned int clr_intr                       : MP2_I2C0_IC_CLR_INTR_CLR_INTR_SIZE;
          unsigned int                                : 31;
     } mp2_i2c0_ic_clr_intr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_intr_t {
          unsigned int                                : 31;
          unsigned int clr_intr                       : MP2_I2C0_IC_CLR_INTR_CLR_INTR_SIZE;
     } mp2_i2c0_ic_clr_intr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_clr_intr_t f;
} mp2_i2c0_ic_clr_intr_u;


/*
 * MP2_I2C0_IC_CLR_RX_UNDER struct
 */

#define MP2_I2C0_IC_CLR_RX_UNDER_REG_SIZE 32
#define MP2_I2C0_IC_CLR_RX_UNDER_CLR_RX_UNDER_SIZE 1

#define MP2_I2C0_IC_CLR_RX_UNDER_CLR_RX_UNDER_SHIFT 0

#define MP2_I2C0_IC_CLR_RX_UNDER_CLR_RX_UNDER_MASK 0x1

#define MP2_I2C0_IC_CLR_RX_UNDER_MASK \
     (MP2_I2C0_IC_CLR_RX_UNDER_CLR_RX_UNDER_MASK)

#define MP2_I2C0_IC_CLR_RX_UNDER_DEFAULT 0x00000000

#define MP2_I2C0_IC_CLR_RX_UNDER_GET_CLR_RX_UNDER(mp2_i2c0_ic_clr_rx_under) \
     ((mp2_i2c0_ic_clr_rx_under & MP2_I2C0_IC_CLR_RX_UNDER_CLR_RX_UNDER_MASK) >> MP2_I2C0_IC_CLR_RX_UNDER_CLR_RX_UNDER_SHIFT)

#define MP2_I2C0_IC_CLR_RX_UNDER_SET_CLR_RX_UNDER(mp2_i2c0_ic_clr_rx_under_reg, clr_rx_under) \
     mp2_i2c0_ic_clr_rx_under_reg = (mp2_i2c0_ic_clr_rx_under_reg & ~MP2_I2C0_IC_CLR_RX_UNDER_CLR_RX_UNDER_MASK) | (clr_rx_under << MP2_I2C0_IC_CLR_RX_UNDER_CLR_RX_UNDER_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_rx_under_t {
          unsigned int clr_rx_under                   : MP2_I2C0_IC_CLR_RX_UNDER_CLR_RX_UNDER_SIZE;
          unsigned int                                : 31;
     } mp2_i2c0_ic_clr_rx_under_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_rx_under_t {
          unsigned int                                : 31;
          unsigned int clr_rx_under                   : MP2_I2C0_IC_CLR_RX_UNDER_CLR_RX_UNDER_SIZE;
     } mp2_i2c0_ic_clr_rx_under_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_clr_rx_under_t f;
} mp2_i2c0_ic_clr_rx_under_u;


/*
 * MP2_I2C0_IC_CLR_RX_OVER struct
 */

#define MP2_I2C0_IC_CLR_RX_OVER_REG_SIZE 32
#define MP2_I2C0_IC_CLR_RX_OVER_CLR_RX_OVER_SIZE 1

#define MP2_I2C0_IC_CLR_RX_OVER_CLR_RX_OVER_SHIFT 0

#define MP2_I2C0_IC_CLR_RX_OVER_CLR_RX_OVER_MASK 0x1

#define MP2_I2C0_IC_CLR_RX_OVER_MASK \
     (MP2_I2C0_IC_CLR_RX_OVER_CLR_RX_OVER_MASK)

#define MP2_I2C0_IC_CLR_RX_OVER_DEFAULT 0x00000000

#define MP2_I2C0_IC_CLR_RX_OVER_GET_CLR_RX_OVER(mp2_i2c0_ic_clr_rx_over) \
     ((mp2_i2c0_ic_clr_rx_over & MP2_I2C0_IC_CLR_RX_OVER_CLR_RX_OVER_MASK) >> MP2_I2C0_IC_CLR_RX_OVER_CLR_RX_OVER_SHIFT)

#define MP2_I2C0_IC_CLR_RX_OVER_SET_CLR_RX_OVER(mp2_i2c0_ic_clr_rx_over_reg, clr_rx_over) \
     mp2_i2c0_ic_clr_rx_over_reg = (mp2_i2c0_ic_clr_rx_over_reg & ~MP2_I2C0_IC_CLR_RX_OVER_CLR_RX_OVER_MASK) | (clr_rx_over << MP2_I2C0_IC_CLR_RX_OVER_CLR_RX_OVER_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_rx_over_t {
          unsigned int clr_rx_over                    : MP2_I2C0_IC_CLR_RX_OVER_CLR_RX_OVER_SIZE;
          unsigned int                                : 31;
     } mp2_i2c0_ic_clr_rx_over_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_rx_over_t {
          unsigned int                                : 31;
          unsigned int clr_rx_over                    : MP2_I2C0_IC_CLR_RX_OVER_CLR_RX_OVER_SIZE;
     } mp2_i2c0_ic_clr_rx_over_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_clr_rx_over_t f;
} mp2_i2c0_ic_clr_rx_over_u;


/*
 * MP2_I2C0_IC_CLR_TX_OVER struct
 */

#define MP2_I2C0_IC_CLR_TX_OVER_REG_SIZE 32
#define MP2_I2C0_IC_CLR_TX_OVER_CLR_TX_OVER_SIZE 1

#define MP2_I2C0_IC_CLR_TX_OVER_CLR_TX_OVER_SHIFT 0

#define MP2_I2C0_IC_CLR_TX_OVER_CLR_TX_OVER_MASK 0x1

#define MP2_I2C0_IC_CLR_TX_OVER_MASK \
     (MP2_I2C0_IC_CLR_TX_OVER_CLR_TX_OVER_MASK)

#define MP2_I2C0_IC_CLR_TX_OVER_DEFAULT 0x00000000

#define MP2_I2C0_IC_CLR_TX_OVER_GET_CLR_TX_OVER(mp2_i2c0_ic_clr_tx_over) \
     ((mp2_i2c0_ic_clr_tx_over & MP2_I2C0_IC_CLR_TX_OVER_CLR_TX_OVER_MASK) >> MP2_I2C0_IC_CLR_TX_OVER_CLR_TX_OVER_SHIFT)

#define MP2_I2C0_IC_CLR_TX_OVER_SET_CLR_TX_OVER(mp2_i2c0_ic_clr_tx_over_reg, clr_tx_over) \
     mp2_i2c0_ic_clr_tx_over_reg = (mp2_i2c0_ic_clr_tx_over_reg & ~MP2_I2C0_IC_CLR_TX_OVER_CLR_TX_OVER_MASK) | (clr_tx_over << MP2_I2C0_IC_CLR_TX_OVER_CLR_TX_OVER_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_tx_over_t {
          unsigned int clr_tx_over                    : MP2_I2C0_IC_CLR_TX_OVER_CLR_TX_OVER_SIZE;
          unsigned int                                : 31;
     } mp2_i2c0_ic_clr_tx_over_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_tx_over_t {
          unsigned int                                : 31;
          unsigned int clr_tx_over                    : MP2_I2C0_IC_CLR_TX_OVER_CLR_TX_OVER_SIZE;
     } mp2_i2c0_ic_clr_tx_over_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_clr_tx_over_t f;
} mp2_i2c0_ic_clr_tx_over_u;


/*
 * MP2_I2C0_IC_CLR_RD_REQ struct
 */

#define MP2_I2C0_IC_CLR_RD_REQ_REG_SIZE 32
#define MP2_I2C0_IC_CLR_RD_REQ_CLR_RD_REQ_SIZE 1

#define MP2_I2C0_IC_CLR_RD_REQ_CLR_RD_REQ_SHIFT 0

#define MP2_I2C0_IC_CLR_RD_REQ_CLR_RD_REQ_MASK 0x1

#define MP2_I2C0_IC_CLR_RD_REQ_MASK \
     (MP2_I2C0_IC_CLR_RD_REQ_CLR_RD_REQ_MASK)

#define MP2_I2C0_IC_CLR_RD_REQ_DEFAULT 0x00000000

#define MP2_I2C0_IC_CLR_RD_REQ_GET_CLR_RD_REQ(mp2_i2c0_ic_clr_rd_req) \
     ((mp2_i2c0_ic_clr_rd_req & MP2_I2C0_IC_CLR_RD_REQ_CLR_RD_REQ_MASK) >> MP2_I2C0_IC_CLR_RD_REQ_CLR_RD_REQ_SHIFT)

#define MP2_I2C0_IC_CLR_RD_REQ_SET_CLR_RD_REQ(mp2_i2c0_ic_clr_rd_req_reg, clr_rd_req) \
     mp2_i2c0_ic_clr_rd_req_reg = (mp2_i2c0_ic_clr_rd_req_reg & ~MP2_I2C0_IC_CLR_RD_REQ_CLR_RD_REQ_MASK) | (clr_rd_req << MP2_I2C0_IC_CLR_RD_REQ_CLR_RD_REQ_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_rd_req_t {
          unsigned int clr_rd_req                     : MP2_I2C0_IC_CLR_RD_REQ_CLR_RD_REQ_SIZE;
          unsigned int                                : 31;
     } mp2_i2c0_ic_clr_rd_req_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_rd_req_t {
          unsigned int                                : 31;
          unsigned int clr_rd_req                     : MP2_I2C0_IC_CLR_RD_REQ_CLR_RD_REQ_SIZE;
     } mp2_i2c0_ic_clr_rd_req_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_clr_rd_req_t f;
} mp2_i2c0_ic_clr_rd_req_u;


/*
 * MP2_I2C0_IC_CLR_TX_ABRT struct
 */

#define MP2_I2C0_IC_CLR_TX_ABRT_REG_SIZE 32
#define MP2_I2C0_IC_CLR_TX_ABRT_CLR_TX_ABRT_SIZE 1

#define MP2_I2C0_IC_CLR_TX_ABRT_CLR_TX_ABRT_SHIFT 0

#define MP2_I2C0_IC_CLR_TX_ABRT_CLR_TX_ABRT_MASK 0x1

#define MP2_I2C0_IC_CLR_TX_ABRT_MASK \
     (MP2_I2C0_IC_CLR_TX_ABRT_CLR_TX_ABRT_MASK)

#define MP2_I2C0_IC_CLR_TX_ABRT_DEFAULT 0x00000000

#define MP2_I2C0_IC_CLR_TX_ABRT_GET_CLR_TX_ABRT(mp2_i2c0_ic_clr_tx_abrt) \
     ((mp2_i2c0_ic_clr_tx_abrt & MP2_I2C0_IC_CLR_TX_ABRT_CLR_TX_ABRT_MASK) >> MP2_I2C0_IC_CLR_TX_ABRT_CLR_TX_ABRT_SHIFT)

#define MP2_I2C0_IC_CLR_TX_ABRT_SET_CLR_TX_ABRT(mp2_i2c0_ic_clr_tx_abrt_reg, clr_tx_abrt) \
     mp2_i2c0_ic_clr_tx_abrt_reg = (mp2_i2c0_ic_clr_tx_abrt_reg & ~MP2_I2C0_IC_CLR_TX_ABRT_CLR_TX_ABRT_MASK) | (clr_tx_abrt << MP2_I2C0_IC_CLR_TX_ABRT_CLR_TX_ABRT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_tx_abrt_t {
          unsigned int clr_tx_abrt                    : MP2_I2C0_IC_CLR_TX_ABRT_CLR_TX_ABRT_SIZE;
          unsigned int                                : 31;
     } mp2_i2c0_ic_clr_tx_abrt_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_tx_abrt_t {
          unsigned int                                : 31;
          unsigned int clr_tx_abrt                    : MP2_I2C0_IC_CLR_TX_ABRT_CLR_TX_ABRT_SIZE;
     } mp2_i2c0_ic_clr_tx_abrt_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_clr_tx_abrt_t f;
} mp2_i2c0_ic_clr_tx_abrt_u;


/*
 * MP2_I2C0_IC_CLR_RX_DONE struct
 */

#define MP2_I2C0_IC_CLR_RX_DONE_REG_SIZE 32
#define MP2_I2C0_IC_CLR_RX_DONE_CLR_RX_DONE_SIZE 1

#define MP2_I2C0_IC_CLR_RX_DONE_CLR_RX_DONE_SHIFT 0

#define MP2_I2C0_IC_CLR_RX_DONE_CLR_RX_DONE_MASK 0x1

#define MP2_I2C0_IC_CLR_RX_DONE_MASK \
     (MP2_I2C0_IC_CLR_RX_DONE_CLR_RX_DONE_MASK)

#define MP2_I2C0_IC_CLR_RX_DONE_DEFAULT 0x00000000

#define MP2_I2C0_IC_CLR_RX_DONE_GET_CLR_RX_DONE(mp2_i2c0_ic_clr_rx_done) \
     ((mp2_i2c0_ic_clr_rx_done & MP2_I2C0_IC_CLR_RX_DONE_CLR_RX_DONE_MASK) >> MP2_I2C0_IC_CLR_RX_DONE_CLR_RX_DONE_SHIFT)

#define MP2_I2C0_IC_CLR_RX_DONE_SET_CLR_RX_DONE(mp2_i2c0_ic_clr_rx_done_reg, clr_rx_done) \
     mp2_i2c0_ic_clr_rx_done_reg = (mp2_i2c0_ic_clr_rx_done_reg & ~MP2_I2C0_IC_CLR_RX_DONE_CLR_RX_DONE_MASK) | (clr_rx_done << MP2_I2C0_IC_CLR_RX_DONE_CLR_RX_DONE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_rx_done_t {
          unsigned int clr_rx_done                    : MP2_I2C0_IC_CLR_RX_DONE_CLR_RX_DONE_SIZE;
          unsigned int                                : 31;
     } mp2_i2c0_ic_clr_rx_done_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_rx_done_t {
          unsigned int                                : 31;
          unsigned int clr_rx_done                    : MP2_I2C0_IC_CLR_RX_DONE_CLR_RX_DONE_SIZE;
     } mp2_i2c0_ic_clr_rx_done_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_clr_rx_done_t f;
} mp2_i2c0_ic_clr_rx_done_u;


/*
 * MP2_I2C0_IC_CLR_ACTIVITY struct
 */

#define MP2_I2C0_IC_CLR_ACTIVITY_REG_SIZE 32
#define MP2_I2C0_IC_CLR_ACTIVITY_CLR_ACTIVITY_SIZE 1

#define MP2_I2C0_IC_CLR_ACTIVITY_CLR_ACTIVITY_SHIFT 0

#define MP2_I2C0_IC_CLR_ACTIVITY_CLR_ACTIVITY_MASK 0x1

#define MP2_I2C0_IC_CLR_ACTIVITY_MASK \
     (MP2_I2C0_IC_CLR_ACTIVITY_CLR_ACTIVITY_MASK)

#define MP2_I2C0_IC_CLR_ACTIVITY_DEFAULT 0x00000000

#define MP2_I2C0_IC_CLR_ACTIVITY_GET_CLR_ACTIVITY(mp2_i2c0_ic_clr_activity) \
     ((mp2_i2c0_ic_clr_activity & MP2_I2C0_IC_CLR_ACTIVITY_CLR_ACTIVITY_MASK) >> MP2_I2C0_IC_CLR_ACTIVITY_CLR_ACTIVITY_SHIFT)

#define MP2_I2C0_IC_CLR_ACTIVITY_SET_CLR_ACTIVITY(mp2_i2c0_ic_clr_activity_reg, clr_activity) \
     mp2_i2c0_ic_clr_activity_reg = (mp2_i2c0_ic_clr_activity_reg & ~MP2_I2C0_IC_CLR_ACTIVITY_CLR_ACTIVITY_MASK) | (clr_activity << MP2_I2C0_IC_CLR_ACTIVITY_CLR_ACTIVITY_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_activity_t {
          unsigned int clr_activity                   : MP2_I2C0_IC_CLR_ACTIVITY_CLR_ACTIVITY_SIZE;
          unsigned int                                : 31;
     } mp2_i2c0_ic_clr_activity_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_activity_t {
          unsigned int                                : 31;
          unsigned int clr_activity                   : MP2_I2C0_IC_CLR_ACTIVITY_CLR_ACTIVITY_SIZE;
     } mp2_i2c0_ic_clr_activity_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_clr_activity_t f;
} mp2_i2c0_ic_clr_activity_u;


/*
 * MP2_I2C0_IC_CLR_STOP_DET struct
 */

#define MP2_I2C0_IC_CLR_STOP_DET_REG_SIZE 32
#define MP2_I2C0_IC_CLR_STOP_DET_CLR_STOP_DET_SIZE 1

#define MP2_I2C0_IC_CLR_STOP_DET_CLR_STOP_DET_SHIFT 0

#define MP2_I2C0_IC_CLR_STOP_DET_CLR_STOP_DET_MASK 0x1

#define MP2_I2C0_IC_CLR_STOP_DET_MASK \
     (MP2_I2C0_IC_CLR_STOP_DET_CLR_STOP_DET_MASK)

#define MP2_I2C0_IC_CLR_STOP_DET_DEFAULT 0x00000000

#define MP2_I2C0_IC_CLR_STOP_DET_GET_CLR_STOP_DET(mp2_i2c0_ic_clr_stop_det) \
     ((mp2_i2c0_ic_clr_stop_det & MP2_I2C0_IC_CLR_STOP_DET_CLR_STOP_DET_MASK) >> MP2_I2C0_IC_CLR_STOP_DET_CLR_STOP_DET_SHIFT)

#define MP2_I2C0_IC_CLR_STOP_DET_SET_CLR_STOP_DET(mp2_i2c0_ic_clr_stop_det_reg, clr_stop_det) \
     mp2_i2c0_ic_clr_stop_det_reg = (mp2_i2c0_ic_clr_stop_det_reg & ~MP2_I2C0_IC_CLR_STOP_DET_CLR_STOP_DET_MASK) | (clr_stop_det << MP2_I2C0_IC_CLR_STOP_DET_CLR_STOP_DET_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_stop_det_t {
          unsigned int clr_stop_det                   : MP2_I2C0_IC_CLR_STOP_DET_CLR_STOP_DET_SIZE;
          unsigned int                                : 31;
     } mp2_i2c0_ic_clr_stop_det_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_stop_det_t {
          unsigned int                                : 31;
          unsigned int clr_stop_det                   : MP2_I2C0_IC_CLR_STOP_DET_CLR_STOP_DET_SIZE;
     } mp2_i2c0_ic_clr_stop_det_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_clr_stop_det_t f;
} mp2_i2c0_ic_clr_stop_det_u;


/*
 * MP2_I2C0_IC_CLR_START_DET struct
 */

#define MP2_I2C0_IC_CLR_START_DET_REG_SIZE 32
#define MP2_I2C0_IC_CLR_START_DET_CLR_START_DET_SIZE 1

#define MP2_I2C0_IC_CLR_START_DET_CLR_START_DET_SHIFT 0

#define MP2_I2C0_IC_CLR_START_DET_CLR_START_DET_MASK 0x1

#define MP2_I2C0_IC_CLR_START_DET_MASK \
     (MP2_I2C0_IC_CLR_START_DET_CLR_START_DET_MASK)

#define MP2_I2C0_IC_CLR_START_DET_DEFAULT 0x00000000

#define MP2_I2C0_IC_CLR_START_DET_GET_CLR_START_DET(mp2_i2c0_ic_clr_start_det) \
     ((mp2_i2c0_ic_clr_start_det & MP2_I2C0_IC_CLR_START_DET_CLR_START_DET_MASK) >> MP2_I2C0_IC_CLR_START_DET_CLR_START_DET_SHIFT)

#define MP2_I2C0_IC_CLR_START_DET_SET_CLR_START_DET(mp2_i2c0_ic_clr_start_det_reg, clr_start_det) \
     mp2_i2c0_ic_clr_start_det_reg = (mp2_i2c0_ic_clr_start_det_reg & ~MP2_I2C0_IC_CLR_START_DET_CLR_START_DET_MASK) | (clr_start_det << MP2_I2C0_IC_CLR_START_DET_CLR_START_DET_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_start_det_t {
          unsigned int clr_start_det                  : MP2_I2C0_IC_CLR_START_DET_CLR_START_DET_SIZE;
          unsigned int                                : 31;
     } mp2_i2c0_ic_clr_start_det_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_start_det_t {
          unsigned int                                : 31;
          unsigned int clr_start_det                  : MP2_I2C0_IC_CLR_START_DET_CLR_START_DET_SIZE;
     } mp2_i2c0_ic_clr_start_det_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_clr_start_det_t f;
} mp2_i2c0_ic_clr_start_det_u;


/*
 * MP2_I2C0_IC_CLR_GEN_CALL struct
 */

#define MP2_I2C0_IC_CLR_GEN_CALL_REG_SIZE 32
#define MP2_I2C0_IC_CLR_GEN_CALL_CLR_GEN_CALL_SIZE 1

#define MP2_I2C0_IC_CLR_GEN_CALL_CLR_GEN_CALL_SHIFT 0

#define MP2_I2C0_IC_CLR_GEN_CALL_CLR_GEN_CALL_MASK 0x1

#define MP2_I2C0_IC_CLR_GEN_CALL_MASK \
     (MP2_I2C0_IC_CLR_GEN_CALL_CLR_GEN_CALL_MASK)

#define MP2_I2C0_IC_CLR_GEN_CALL_DEFAULT 0x00000000

#define MP2_I2C0_IC_CLR_GEN_CALL_GET_CLR_GEN_CALL(mp2_i2c0_ic_clr_gen_call) \
     ((mp2_i2c0_ic_clr_gen_call & MP2_I2C0_IC_CLR_GEN_CALL_CLR_GEN_CALL_MASK) >> MP2_I2C0_IC_CLR_GEN_CALL_CLR_GEN_CALL_SHIFT)

#define MP2_I2C0_IC_CLR_GEN_CALL_SET_CLR_GEN_CALL(mp2_i2c0_ic_clr_gen_call_reg, clr_gen_call) \
     mp2_i2c0_ic_clr_gen_call_reg = (mp2_i2c0_ic_clr_gen_call_reg & ~MP2_I2C0_IC_CLR_GEN_CALL_CLR_GEN_CALL_MASK) | (clr_gen_call << MP2_I2C0_IC_CLR_GEN_CALL_CLR_GEN_CALL_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_gen_call_t {
          unsigned int clr_gen_call                   : MP2_I2C0_IC_CLR_GEN_CALL_CLR_GEN_CALL_SIZE;
          unsigned int                                : 31;
     } mp2_i2c0_ic_clr_gen_call_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_gen_call_t {
          unsigned int                                : 31;
          unsigned int clr_gen_call                   : MP2_I2C0_IC_CLR_GEN_CALL_CLR_GEN_CALL_SIZE;
     } mp2_i2c0_ic_clr_gen_call_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_clr_gen_call_t f;
} mp2_i2c0_ic_clr_gen_call_u;


/*
 * MP2_I2C0_IC_ENABLE struct
 */

#define MP2_I2C0_IC_ENABLE_REG_SIZE    32
#define MP2_I2C0_IC_ENABLE_ENABLE_SIZE 1
#define MP2_I2C0_IC_ENABLE_ABORT_SIZE  1
#define MP2_I2C0_IC_ENABLE_TX_CMD_BLOCK_SIZE 1

#define MP2_I2C0_IC_ENABLE_ENABLE_SHIFT 0
#define MP2_I2C0_IC_ENABLE_ABORT_SHIFT 1
#define MP2_I2C0_IC_ENABLE_TX_CMD_BLOCK_SHIFT 2

#define MP2_I2C0_IC_ENABLE_ENABLE_MASK 0x1
#define MP2_I2C0_IC_ENABLE_ABORT_MASK  0x2
#define MP2_I2C0_IC_ENABLE_TX_CMD_BLOCK_MASK 0x4

#define MP2_I2C0_IC_ENABLE_MASK \
     (MP2_I2C0_IC_ENABLE_ENABLE_MASK | \
      MP2_I2C0_IC_ENABLE_ABORT_MASK | \
      MP2_I2C0_IC_ENABLE_TX_CMD_BLOCK_MASK)

#define MP2_I2C0_IC_ENABLE_DEFAULT     0x00000000

#define MP2_I2C0_IC_ENABLE_GET_ENABLE(mp2_i2c0_ic_enable) \
     ((mp2_i2c0_ic_enable & MP2_I2C0_IC_ENABLE_ENABLE_MASK) >> MP2_I2C0_IC_ENABLE_ENABLE_SHIFT)
#define MP2_I2C0_IC_ENABLE_GET_ABORT(mp2_i2c0_ic_enable) \
     ((mp2_i2c0_ic_enable & MP2_I2C0_IC_ENABLE_ABORT_MASK) >> MP2_I2C0_IC_ENABLE_ABORT_SHIFT)
#define MP2_I2C0_IC_ENABLE_GET_TX_CMD_BLOCK(mp2_i2c0_ic_enable) \
     ((mp2_i2c0_ic_enable & MP2_I2C0_IC_ENABLE_TX_CMD_BLOCK_MASK) >> MP2_I2C0_IC_ENABLE_TX_CMD_BLOCK_SHIFT)

#define MP2_I2C0_IC_ENABLE_SET_ENABLE(mp2_i2c0_ic_enable_reg, enable) \
     mp2_i2c0_ic_enable_reg = (mp2_i2c0_ic_enable_reg & ~MP2_I2C0_IC_ENABLE_ENABLE_MASK) | (enable << MP2_I2C0_IC_ENABLE_ENABLE_SHIFT)
#define MP2_I2C0_IC_ENABLE_SET_ABORT(mp2_i2c0_ic_enable_reg, abort) \
     mp2_i2c0_ic_enable_reg = (mp2_i2c0_ic_enable_reg & ~MP2_I2C0_IC_ENABLE_ABORT_MASK) | (abort << MP2_I2C0_IC_ENABLE_ABORT_SHIFT)
#define MP2_I2C0_IC_ENABLE_SET_TX_CMD_BLOCK(mp2_i2c0_ic_enable_reg, tx_cmd_block) \
     mp2_i2c0_ic_enable_reg = (mp2_i2c0_ic_enable_reg & ~MP2_I2C0_IC_ENABLE_TX_CMD_BLOCK_MASK) | (tx_cmd_block << MP2_I2C0_IC_ENABLE_TX_CMD_BLOCK_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_enable_t {
          unsigned int enable                         : MP2_I2C0_IC_ENABLE_ENABLE_SIZE;
          unsigned int abort                          : MP2_I2C0_IC_ENABLE_ABORT_SIZE;
          unsigned int tx_cmd_block                   : MP2_I2C0_IC_ENABLE_TX_CMD_BLOCK_SIZE;
          unsigned int                                : 29;
     } mp2_i2c0_ic_enable_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_enable_t {
          unsigned int                                : 29;
          unsigned int tx_cmd_block                   : MP2_I2C0_IC_ENABLE_TX_CMD_BLOCK_SIZE;
          unsigned int abort                          : MP2_I2C0_IC_ENABLE_ABORT_SIZE;
          unsigned int enable                         : MP2_I2C0_IC_ENABLE_ENABLE_SIZE;
     } mp2_i2c0_ic_enable_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_enable_t f;
} mp2_i2c0_ic_enable_u;


/*
 * MP2_I2C0_IC_STATUS struct
 */

#define MP2_I2C0_IC_STATUS_REG_SIZE    32
#define MP2_I2C0_IC_STATUS_ACTIVITY_SIZE 1
#define MP2_I2C0_IC_STATUS_TFNF_SIZE   1
#define MP2_I2C0_IC_STATUS_TFE_SIZE    1
#define MP2_I2C0_IC_STATUS_RFNE_SIZE   1
#define MP2_I2C0_IC_STATUS_RFF_SIZE    1
#define MP2_I2C0_IC_STATUS_MST_ACTIVITY_SIZE 1
#define MP2_I2C0_IC_STATUS_SLV_ACTIVITY_SIZE 1
#define MP2_I2C0_IC_STATUS_MST_HOLD_TX_FIFO_EMPTY_SIZE 1
#define MP2_I2C0_IC_STATUS_MST_HOLD_RX_FIFO_FULL_SIZE 1
#define MP2_I2C0_IC_STATUS_SLV_HOLD_TX_FIFO_EMPTY_SIZE 1
#define MP2_I2C0_IC_STATUS_SLV_HOLD_RX_FIFO_FULL_SIZE 1

#define MP2_I2C0_IC_STATUS_ACTIVITY_SHIFT 0
#define MP2_I2C0_IC_STATUS_TFNF_SHIFT  1
#define MP2_I2C0_IC_STATUS_TFE_SHIFT   2
#define MP2_I2C0_IC_STATUS_RFNE_SHIFT  3
#define MP2_I2C0_IC_STATUS_RFF_SHIFT   4
#define MP2_I2C0_IC_STATUS_MST_ACTIVITY_SHIFT 5
#define MP2_I2C0_IC_STATUS_SLV_ACTIVITY_SHIFT 6
#define MP2_I2C0_IC_STATUS_MST_HOLD_TX_FIFO_EMPTY_SHIFT 7
#define MP2_I2C0_IC_STATUS_MST_HOLD_RX_FIFO_FULL_SHIFT 8
#define MP2_I2C0_IC_STATUS_SLV_HOLD_TX_FIFO_EMPTY_SHIFT 9
#define MP2_I2C0_IC_STATUS_SLV_HOLD_RX_FIFO_FULL_SHIFT 10

#define MP2_I2C0_IC_STATUS_ACTIVITY_MASK 0x1
#define MP2_I2C0_IC_STATUS_TFNF_MASK   0x2
#define MP2_I2C0_IC_STATUS_TFE_MASK    0x4
#define MP2_I2C0_IC_STATUS_RFNE_MASK   0x8
#define MP2_I2C0_IC_STATUS_RFF_MASK    0x10
#define MP2_I2C0_IC_STATUS_MST_ACTIVITY_MASK 0x20
#define MP2_I2C0_IC_STATUS_SLV_ACTIVITY_MASK 0x40
#define MP2_I2C0_IC_STATUS_MST_HOLD_TX_FIFO_EMPTY_MASK 0x80
#define MP2_I2C0_IC_STATUS_MST_HOLD_RX_FIFO_FULL_MASK 0x100
#define MP2_I2C0_IC_STATUS_SLV_HOLD_TX_FIFO_EMPTY_MASK 0x200
#define MP2_I2C0_IC_STATUS_SLV_HOLD_RX_FIFO_FULL_MASK 0x400

#define MP2_I2C0_IC_STATUS_MASK \
     (MP2_I2C0_IC_STATUS_ACTIVITY_MASK | \
      MP2_I2C0_IC_STATUS_TFNF_MASK | \
      MP2_I2C0_IC_STATUS_TFE_MASK | \
      MP2_I2C0_IC_STATUS_RFNE_MASK | \
      MP2_I2C0_IC_STATUS_RFF_MASK | \
      MP2_I2C0_IC_STATUS_MST_ACTIVITY_MASK | \
      MP2_I2C0_IC_STATUS_SLV_ACTIVITY_MASK | \
      MP2_I2C0_IC_STATUS_MST_HOLD_TX_FIFO_EMPTY_MASK | \
      MP2_I2C0_IC_STATUS_MST_HOLD_RX_FIFO_FULL_MASK | \
      MP2_I2C0_IC_STATUS_SLV_HOLD_TX_FIFO_EMPTY_MASK | \
      MP2_I2C0_IC_STATUS_SLV_HOLD_RX_FIFO_FULL_MASK)

#define MP2_I2C0_IC_STATUS_DEFAULT     0x00000000

#define MP2_I2C0_IC_STATUS_GET_ACTIVITY(mp2_i2c0_ic_status) \
     ((mp2_i2c0_ic_status & MP2_I2C0_IC_STATUS_ACTIVITY_MASK) >> MP2_I2C0_IC_STATUS_ACTIVITY_SHIFT)
#define MP2_I2C0_IC_STATUS_GET_TFNF(mp2_i2c0_ic_status) \
     ((mp2_i2c0_ic_status & MP2_I2C0_IC_STATUS_TFNF_MASK) >> MP2_I2C0_IC_STATUS_TFNF_SHIFT)
#define MP2_I2C0_IC_STATUS_GET_TFE(mp2_i2c0_ic_status) \
     ((mp2_i2c0_ic_status & MP2_I2C0_IC_STATUS_TFE_MASK) >> MP2_I2C0_IC_STATUS_TFE_SHIFT)
#define MP2_I2C0_IC_STATUS_GET_RFNE(mp2_i2c0_ic_status) \
     ((mp2_i2c0_ic_status & MP2_I2C0_IC_STATUS_RFNE_MASK) >> MP2_I2C0_IC_STATUS_RFNE_SHIFT)
#define MP2_I2C0_IC_STATUS_GET_RFF(mp2_i2c0_ic_status) \
     ((mp2_i2c0_ic_status & MP2_I2C0_IC_STATUS_RFF_MASK) >> MP2_I2C0_IC_STATUS_RFF_SHIFT)
#define MP2_I2C0_IC_STATUS_GET_MST_ACTIVITY(mp2_i2c0_ic_status) \
     ((mp2_i2c0_ic_status & MP2_I2C0_IC_STATUS_MST_ACTIVITY_MASK) >> MP2_I2C0_IC_STATUS_MST_ACTIVITY_SHIFT)
#define MP2_I2C0_IC_STATUS_GET_SLV_ACTIVITY(mp2_i2c0_ic_status) \
     ((mp2_i2c0_ic_status & MP2_I2C0_IC_STATUS_SLV_ACTIVITY_MASK) >> MP2_I2C0_IC_STATUS_SLV_ACTIVITY_SHIFT)
#define MP2_I2C0_IC_STATUS_GET_MST_HOLD_TX_FIFO_EMPTY(mp2_i2c0_ic_status) \
     ((mp2_i2c0_ic_status & MP2_I2C0_IC_STATUS_MST_HOLD_TX_FIFO_EMPTY_MASK) >> MP2_I2C0_IC_STATUS_MST_HOLD_TX_FIFO_EMPTY_SHIFT)
#define MP2_I2C0_IC_STATUS_GET_MST_HOLD_RX_FIFO_FULL(mp2_i2c0_ic_status) \
     ((mp2_i2c0_ic_status & MP2_I2C0_IC_STATUS_MST_HOLD_RX_FIFO_FULL_MASK) >> MP2_I2C0_IC_STATUS_MST_HOLD_RX_FIFO_FULL_SHIFT)
#define MP2_I2C0_IC_STATUS_GET_SLV_HOLD_TX_FIFO_EMPTY(mp2_i2c0_ic_status) \
     ((mp2_i2c0_ic_status & MP2_I2C0_IC_STATUS_SLV_HOLD_TX_FIFO_EMPTY_MASK) >> MP2_I2C0_IC_STATUS_SLV_HOLD_TX_FIFO_EMPTY_SHIFT)
#define MP2_I2C0_IC_STATUS_GET_SLV_HOLD_RX_FIFO_FULL(mp2_i2c0_ic_status) \
     ((mp2_i2c0_ic_status & MP2_I2C0_IC_STATUS_SLV_HOLD_RX_FIFO_FULL_MASK) >> MP2_I2C0_IC_STATUS_SLV_HOLD_RX_FIFO_FULL_SHIFT)

#define MP2_I2C0_IC_STATUS_SET_ACTIVITY(mp2_i2c0_ic_status_reg, activity) \
     mp2_i2c0_ic_status_reg = (mp2_i2c0_ic_status_reg & ~MP2_I2C0_IC_STATUS_ACTIVITY_MASK) | (activity << MP2_I2C0_IC_STATUS_ACTIVITY_SHIFT)
#define MP2_I2C0_IC_STATUS_SET_TFNF(mp2_i2c0_ic_status_reg, tfnf) \
     mp2_i2c0_ic_status_reg = (mp2_i2c0_ic_status_reg & ~MP2_I2C0_IC_STATUS_TFNF_MASK) | (tfnf << MP2_I2C0_IC_STATUS_TFNF_SHIFT)
#define MP2_I2C0_IC_STATUS_SET_TFE(mp2_i2c0_ic_status_reg, tfe) \
     mp2_i2c0_ic_status_reg = (mp2_i2c0_ic_status_reg & ~MP2_I2C0_IC_STATUS_TFE_MASK) | (tfe << MP2_I2C0_IC_STATUS_TFE_SHIFT)
#define MP2_I2C0_IC_STATUS_SET_RFNE(mp2_i2c0_ic_status_reg, rfne) \
     mp2_i2c0_ic_status_reg = (mp2_i2c0_ic_status_reg & ~MP2_I2C0_IC_STATUS_RFNE_MASK) | (rfne << MP2_I2C0_IC_STATUS_RFNE_SHIFT)
#define MP2_I2C0_IC_STATUS_SET_RFF(mp2_i2c0_ic_status_reg, rff) \
     mp2_i2c0_ic_status_reg = (mp2_i2c0_ic_status_reg & ~MP2_I2C0_IC_STATUS_RFF_MASK) | (rff << MP2_I2C0_IC_STATUS_RFF_SHIFT)
#define MP2_I2C0_IC_STATUS_SET_MST_ACTIVITY(mp2_i2c0_ic_status_reg, mst_activity) \
     mp2_i2c0_ic_status_reg = (mp2_i2c0_ic_status_reg & ~MP2_I2C0_IC_STATUS_MST_ACTIVITY_MASK) | (mst_activity << MP2_I2C0_IC_STATUS_MST_ACTIVITY_SHIFT)
#define MP2_I2C0_IC_STATUS_SET_SLV_ACTIVITY(mp2_i2c0_ic_status_reg, slv_activity) \
     mp2_i2c0_ic_status_reg = (mp2_i2c0_ic_status_reg & ~MP2_I2C0_IC_STATUS_SLV_ACTIVITY_MASK) | (slv_activity << MP2_I2C0_IC_STATUS_SLV_ACTIVITY_SHIFT)
#define MP2_I2C0_IC_STATUS_SET_MST_HOLD_TX_FIFO_EMPTY(mp2_i2c0_ic_status_reg, mst_hold_tx_fifo_empty) \
     mp2_i2c0_ic_status_reg = (mp2_i2c0_ic_status_reg & ~MP2_I2C0_IC_STATUS_MST_HOLD_TX_FIFO_EMPTY_MASK) | (mst_hold_tx_fifo_empty << MP2_I2C0_IC_STATUS_MST_HOLD_TX_FIFO_EMPTY_SHIFT)
#define MP2_I2C0_IC_STATUS_SET_MST_HOLD_RX_FIFO_FULL(mp2_i2c0_ic_status_reg, mst_hold_rx_fifo_full) \
     mp2_i2c0_ic_status_reg = (mp2_i2c0_ic_status_reg & ~MP2_I2C0_IC_STATUS_MST_HOLD_RX_FIFO_FULL_MASK) | (mst_hold_rx_fifo_full << MP2_I2C0_IC_STATUS_MST_HOLD_RX_FIFO_FULL_SHIFT)
#define MP2_I2C0_IC_STATUS_SET_SLV_HOLD_TX_FIFO_EMPTY(mp2_i2c0_ic_status_reg, slv_hold_tx_fifo_empty) \
     mp2_i2c0_ic_status_reg = (mp2_i2c0_ic_status_reg & ~MP2_I2C0_IC_STATUS_SLV_HOLD_TX_FIFO_EMPTY_MASK) | (slv_hold_tx_fifo_empty << MP2_I2C0_IC_STATUS_SLV_HOLD_TX_FIFO_EMPTY_SHIFT)
#define MP2_I2C0_IC_STATUS_SET_SLV_HOLD_RX_FIFO_FULL(mp2_i2c0_ic_status_reg, slv_hold_rx_fifo_full) \
     mp2_i2c0_ic_status_reg = (mp2_i2c0_ic_status_reg & ~MP2_I2C0_IC_STATUS_SLV_HOLD_RX_FIFO_FULL_MASK) | (slv_hold_rx_fifo_full << MP2_I2C0_IC_STATUS_SLV_HOLD_RX_FIFO_FULL_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_status_t {
          unsigned int activity                       : MP2_I2C0_IC_STATUS_ACTIVITY_SIZE;
          unsigned int tfnf                           : MP2_I2C0_IC_STATUS_TFNF_SIZE;
          unsigned int tfe                            : MP2_I2C0_IC_STATUS_TFE_SIZE;
          unsigned int rfne                           : MP2_I2C0_IC_STATUS_RFNE_SIZE;
          unsigned int rff                            : MP2_I2C0_IC_STATUS_RFF_SIZE;
          unsigned int mst_activity                   : MP2_I2C0_IC_STATUS_MST_ACTIVITY_SIZE;
          unsigned int slv_activity                   : MP2_I2C0_IC_STATUS_SLV_ACTIVITY_SIZE;
          unsigned int mst_hold_tx_fifo_empty         : MP2_I2C0_IC_STATUS_MST_HOLD_TX_FIFO_EMPTY_SIZE;
          unsigned int mst_hold_rx_fifo_full          : MP2_I2C0_IC_STATUS_MST_HOLD_RX_FIFO_FULL_SIZE;
          unsigned int slv_hold_tx_fifo_empty         : MP2_I2C0_IC_STATUS_SLV_HOLD_TX_FIFO_EMPTY_SIZE;
          unsigned int slv_hold_rx_fifo_full          : MP2_I2C0_IC_STATUS_SLV_HOLD_RX_FIFO_FULL_SIZE;
          unsigned int                                : 21;
     } mp2_i2c0_ic_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_status_t {
          unsigned int                                : 21;
          unsigned int slv_hold_rx_fifo_full          : MP2_I2C0_IC_STATUS_SLV_HOLD_RX_FIFO_FULL_SIZE;
          unsigned int slv_hold_tx_fifo_empty         : MP2_I2C0_IC_STATUS_SLV_HOLD_TX_FIFO_EMPTY_SIZE;
          unsigned int mst_hold_rx_fifo_full          : MP2_I2C0_IC_STATUS_MST_HOLD_RX_FIFO_FULL_SIZE;
          unsigned int mst_hold_tx_fifo_empty         : MP2_I2C0_IC_STATUS_MST_HOLD_TX_FIFO_EMPTY_SIZE;
          unsigned int slv_activity                   : MP2_I2C0_IC_STATUS_SLV_ACTIVITY_SIZE;
          unsigned int mst_activity                   : MP2_I2C0_IC_STATUS_MST_ACTIVITY_SIZE;
          unsigned int rff                            : MP2_I2C0_IC_STATUS_RFF_SIZE;
          unsigned int rfne                           : MP2_I2C0_IC_STATUS_RFNE_SIZE;
          unsigned int tfe                            : MP2_I2C0_IC_STATUS_TFE_SIZE;
          unsigned int tfnf                           : MP2_I2C0_IC_STATUS_TFNF_SIZE;
          unsigned int activity                       : MP2_I2C0_IC_STATUS_ACTIVITY_SIZE;
     } mp2_i2c0_ic_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_status_t f;
} mp2_i2c0_ic_status_u;


/*
 * MP2_I2C0_IC_TXFLR struct
 */

#define MP2_I2C0_IC_TXFLR_REG_SIZE     32
#define MP2_I2C0_IC_TXFLR_TXFLR_SIZE   32

#define MP2_I2C0_IC_TXFLR_TXFLR_SHIFT  0

#define MP2_I2C0_IC_TXFLR_TXFLR_MASK   0xffffffff

#define MP2_I2C0_IC_TXFLR_MASK \
     (MP2_I2C0_IC_TXFLR_TXFLR_MASK)

#define MP2_I2C0_IC_TXFLR_DEFAULT      0x00000000

#define MP2_I2C0_IC_TXFLR_GET_TXFLR(mp2_i2c0_ic_txflr) \
     ((mp2_i2c0_ic_txflr & MP2_I2C0_IC_TXFLR_TXFLR_MASK) >> MP2_I2C0_IC_TXFLR_TXFLR_SHIFT)

#define MP2_I2C0_IC_TXFLR_SET_TXFLR(mp2_i2c0_ic_txflr_reg, txflr) \
     mp2_i2c0_ic_txflr_reg = (mp2_i2c0_ic_txflr_reg & ~MP2_I2C0_IC_TXFLR_TXFLR_MASK) | (txflr << MP2_I2C0_IC_TXFLR_TXFLR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_txflr_t {
          unsigned int txflr                          : MP2_I2C0_IC_TXFLR_TXFLR_SIZE;
     } mp2_i2c0_ic_txflr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_txflr_t {
          unsigned int txflr                          : MP2_I2C0_IC_TXFLR_TXFLR_SIZE;
     } mp2_i2c0_ic_txflr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_txflr_t f;
} mp2_i2c0_ic_txflr_u;


/*
 * MP2_I2C0_IC_RXFLR struct
 */

#define MP2_I2C0_IC_RXFLR_REG_SIZE     32
#define MP2_I2C0_IC_RXFLR_RXFLR_SIZE   32

#define MP2_I2C0_IC_RXFLR_RXFLR_SHIFT  0

#define MP2_I2C0_IC_RXFLR_RXFLR_MASK   0xffffffff

#define MP2_I2C0_IC_RXFLR_MASK \
     (MP2_I2C0_IC_RXFLR_RXFLR_MASK)

#define MP2_I2C0_IC_RXFLR_DEFAULT      0x00000000

#define MP2_I2C0_IC_RXFLR_GET_RXFLR(mp2_i2c0_ic_rxflr) \
     ((mp2_i2c0_ic_rxflr & MP2_I2C0_IC_RXFLR_RXFLR_MASK) >> MP2_I2C0_IC_RXFLR_RXFLR_SHIFT)

#define MP2_I2C0_IC_RXFLR_SET_RXFLR(mp2_i2c0_ic_rxflr_reg, rxflr) \
     mp2_i2c0_ic_rxflr_reg = (mp2_i2c0_ic_rxflr_reg & ~MP2_I2C0_IC_RXFLR_RXFLR_MASK) | (rxflr << MP2_I2C0_IC_RXFLR_RXFLR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_rxflr_t {
          unsigned int rxflr                          : MP2_I2C0_IC_RXFLR_RXFLR_SIZE;
     } mp2_i2c0_ic_rxflr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_rxflr_t {
          unsigned int rxflr                          : MP2_I2C0_IC_RXFLR_RXFLR_SIZE;
     } mp2_i2c0_ic_rxflr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_rxflr_t f;
} mp2_i2c0_ic_rxflr_u;


/*
 * MP2_I2C0_IC_SDA_HOLD struct
 */

#define MP2_I2C0_IC_SDA_HOLD_REG_SIZE  32
#define MP2_I2C0_IC_SDA_HOLD_IC_SDA_TX_HOLD_SIZE 16
#define MP2_I2C0_IC_SDA_HOLD_IC_SDA_RX_HOLD_SIZE 8

#define MP2_I2C0_IC_SDA_HOLD_IC_SDA_TX_HOLD_SHIFT 0
#define MP2_I2C0_IC_SDA_HOLD_IC_SDA_RX_HOLD_SHIFT 16

#define MP2_I2C0_IC_SDA_HOLD_IC_SDA_TX_HOLD_MASK 0xffff
#define MP2_I2C0_IC_SDA_HOLD_IC_SDA_RX_HOLD_MASK 0xff0000

#define MP2_I2C0_IC_SDA_HOLD_MASK \
     (MP2_I2C0_IC_SDA_HOLD_IC_SDA_TX_HOLD_MASK | \
      MP2_I2C0_IC_SDA_HOLD_IC_SDA_RX_HOLD_MASK)

#define MP2_I2C0_IC_SDA_HOLD_DEFAULT   0x00000000

#define MP2_I2C0_IC_SDA_HOLD_GET_IC_SDA_TX_HOLD(mp2_i2c0_ic_sda_hold) \
     ((mp2_i2c0_ic_sda_hold & MP2_I2C0_IC_SDA_HOLD_IC_SDA_TX_HOLD_MASK) >> MP2_I2C0_IC_SDA_HOLD_IC_SDA_TX_HOLD_SHIFT)
#define MP2_I2C0_IC_SDA_HOLD_GET_IC_SDA_RX_HOLD(mp2_i2c0_ic_sda_hold) \
     ((mp2_i2c0_ic_sda_hold & MP2_I2C0_IC_SDA_HOLD_IC_SDA_RX_HOLD_MASK) >> MP2_I2C0_IC_SDA_HOLD_IC_SDA_RX_HOLD_SHIFT)

#define MP2_I2C0_IC_SDA_HOLD_SET_IC_SDA_TX_HOLD(mp2_i2c0_ic_sda_hold_reg, ic_sda_tx_hold) \
     mp2_i2c0_ic_sda_hold_reg = (mp2_i2c0_ic_sda_hold_reg & ~MP2_I2C0_IC_SDA_HOLD_IC_SDA_TX_HOLD_MASK) | (ic_sda_tx_hold << MP2_I2C0_IC_SDA_HOLD_IC_SDA_TX_HOLD_SHIFT)
#define MP2_I2C0_IC_SDA_HOLD_SET_IC_SDA_RX_HOLD(mp2_i2c0_ic_sda_hold_reg, ic_sda_rx_hold) \
     mp2_i2c0_ic_sda_hold_reg = (mp2_i2c0_ic_sda_hold_reg & ~MP2_I2C0_IC_SDA_HOLD_IC_SDA_RX_HOLD_MASK) | (ic_sda_rx_hold << MP2_I2C0_IC_SDA_HOLD_IC_SDA_RX_HOLD_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_sda_hold_t {
          unsigned int ic_sda_tx_hold                 : MP2_I2C0_IC_SDA_HOLD_IC_SDA_TX_HOLD_SIZE;
          unsigned int ic_sda_rx_hold                 : MP2_I2C0_IC_SDA_HOLD_IC_SDA_RX_HOLD_SIZE;
          unsigned int                                : 8;
     } mp2_i2c0_ic_sda_hold_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_sda_hold_t {
          unsigned int                                : 8;
          unsigned int ic_sda_rx_hold                 : MP2_I2C0_IC_SDA_HOLD_IC_SDA_RX_HOLD_SIZE;
          unsigned int ic_sda_tx_hold                 : MP2_I2C0_IC_SDA_HOLD_IC_SDA_TX_HOLD_SIZE;
     } mp2_i2c0_ic_sda_hold_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_sda_hold_t f;
} mp2_i2c0_ic_sda_hold_u;


/*
 * MP2_I2C0_IC_TX_ABRT_SOURSE struct
 */

#define MP2_I2C0_IC_TX_ABRT_SOURSE_REG_SIZE 32
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_7B_ADDR_NOACK_SIZE 1
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10ADDR1_NOACK_SIZE 1
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10ADDR2_NOACK_SIZE 1
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_TXDATA_NOACK_SIZE 1
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_GCALL_NOACK_SIZE 1
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_GCALL_READ_SIZE 1
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_HS_ACKDET_SIZE 1
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SBYTE_ACKDED_SIZE 1
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_HS_NORSTRT_SIZE 1
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SBYTE_NORSTRT_SIZE 1
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10B_RD_NORSTRT_SIZE 1
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_MASTER_DIS_SIZE 1
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ARB_LOST_SIZE 1
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLVFLUSH_TXFIFO_SIZE 1
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLV_ARBLOST_SIZE 1
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLVRD_INTX_SIZE 1
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_USER_ABRT_SIZE 1
#define MP2_I2C0_IC_TX_ABRT_SOURSE_TX_FLUSH_CNT_SIZE 9

#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_7B_ADDR_NOACK_SHIFT 0
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10ADDR1_NOACK_SHIFT 1
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10ADDR2_NOACK_SHIFT 2
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_TXDATA_NOACK_SHIFT 3
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_GCALL_NOACK_SHIFT 4
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_GCALL_READ_SHIFT 5
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_HS_ACKDET_SHIFT 6
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SBYTE_ACKDED_SHIFT 7
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_HS_NORSTRT_SHIFT 8
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SBYTE_NORSTRT_SHIFT 9
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10B_RD_NORSTRT_SHIFT 10
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_MASTER_DIS_SHIFT 11
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ARB_LOST_SHIFT 12
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLVFLUSH_TXFIFO_SHIFT 13
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLV_ARBLOST_SHIFT 14
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLVRD_INTX_SHIFT 15
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_USER_ABRT_SHIFT 16
#define MP2_I2C0_IC_TX_ABRT_SOURSE_TX_FLUSH_CNT_SHIFT 23

#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_7B_ADDR_NOACK_MASK 0x1
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10ADDR1_NOACK_MASK 0x2
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10ADDR2_NOACK_MASK 0x4
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_TXDATA_NOACK_MASK 0x8
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_GCALL_NOACK_MASK 0x10
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_GCALL_READ_MASK 0x20
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_HS_ACKDET_MASK 0x40
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SBYTE_ACKDED_MASK 0x80
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_HS_NORSTRT_MASK 0x100
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SBYTE_NORSTRT_MASK 0x200
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10B_RD_NORSTRT_MASK 0x400
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_MASTER_DIS_MASK 0x800
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ARB_LOST_MASK 0x1000
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLVFLUSH_TXFIFO_MASK 0x2000
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLV_ARBLOST_MASK 0x4000
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLVRD_INTX_MASK 0x8000
#define MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_USER_ABRT_MASK 0x10000
#define MP2_I2C0_IC_TX_ABRT_SOURSE_TX_FLUSH_CNT_MASK 0xff800000

#define MP2_I2C0_IC_TX_ABRT_SOURSE_MASK \
     (MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_7B_ADDR_NOACK_MASK | \
      MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10ADDR1_NOACK_MASK | \
      MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10ADDR2_NOACK_MASK | \
      MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_TXDATA_NOACK_MASK | \
      MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_GCALL_NOACK_MASK | \
      MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_GCALL_READ_MASK | \
      MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_HS_ACKDET_MASK | \
      MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SBYTE_ACKDED_MASK | \
      MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_HS_NORSTRT_MASK | \
      MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SBYTE_NORSTRT_MASK | \
      MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10B_RD_NORSTRT_MASK | \
      MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_MASTER_DIS_MASK | \
      MP2_I2C0_IC_TX_ABRT_SOURSE_ARB_LOST_MASK | \
      MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLVFLUSH_TXFIFO_MASK | \
      MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLV_ARBLOST_MASK | \
      MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLVRD_INTX_MASK | \
      MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_USER_ABRT_MASK | \
      MP2_I2C0_IC_TX_ABRT_SOURSE_TX_FLUSH_CNT_MASK)

#define MP2_I2C0_IC_TX_ABRT_SOURSE_DEFAULT 0x00000000

#define MP2_I2C0_IC_TX_ABRT_SOURSE_GET_ABRT_7B_ADDR_NOACK(mp2_i2c0_ic_tx_abrt_sourse) \
     ((mp2_i2c0_ic_tx_abrt_sourse & MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_7B_ADDR_NOACK_MASK) >> MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_7B_ADDR_NOACK_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_GET_ABRT_10ADDR1_NOACK(mp2_i2c0_ic_tx_abrt_sourse) \
     ((mp2_i2c0_ic_tx_abrt_sourse & MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10ADDR1_NOACK_MASK) >> MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10ADDR1_NOACK_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_GET_ABRT_10ADDR2_NOACK(mp2_i2c0_ic_tx_abrt_sourse) \
     ((mp2_i2c0_ic_tx_abrt_sourse & MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10ADDR2_NOACK_MASK) >> MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10ADDR2_NOACK_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_GET_ABRT_TXDATA_NOACK(mp2_i2c0_ic_tx_abrt_sourse) \
     ((mp2_i2c0_ic_tx_abrt_sourse & MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_TXDATA_NOACK_MASK) >> MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_TXDATA_NOACK_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_GET_ABRT_GCALL_NOACK(mp2_i2c0_ic_tx_abrt_sourse) \
     ((mp2_i2c0_ic_tx_abrt_sourse & MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_GCALL_NOACK_MASK) >> MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_GCALL_NOACK_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_GET_ABRT_GCALL_READ(mp2_i2c0_ic_tx_abrt_sourse) \
     ((mp2_i2c0_ic_tx_abrt_sourse & MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_GCALL_READ_MASK) >> MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_GCALL_READ_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_GET_ABRT_HS_ACKDET(mp2_i2c0_ic_tx_abrt_sourse) \
     ((mp2_i2c0_ic_tx_abrt_sourse & MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_HS_ACKDET_MASK) >> MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_HS_ACKDET_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_GET_ABRT_SBYTE_ACKDED(mp2_i2c0_ic_tx_abrt_sourse) \
     ((mp2_i2c0_ic_tx_abrt_sourse & MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SBYTE_ACKDED_MASK) >> MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SBYTE_ACKDED_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_GET_ABRT_HS_NORSTRT(mp2_i2c0_ic_tx_abrt_sourse) \
     ((mp2_i2c0_ic_tx_abrt_sourse & MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_HS_NORSTRT_MASK) >> MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_HS_NORSTRT_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_GET_ABRT_SBYTE_NORSTRT(mp2_i2c0_ic_tx_abrt_sourse) \
     ((mp2_i2c0_ic_tx_abrt_sourse & MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SBYTE_NORSTRT_MASK) >> MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SBYTE_NORSTRT_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_GET_ABRT_10B_RD_NORSTRT(mp2_i2c0_ic_tx_abrt_sourse) \
     ((mp2_i2c0_ic_tx_abrt_sourse & MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10B_RD_NORSTRT_MASK) >> MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10B_RD_NORSTRT_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_GET_ABRT_MASTER_DIS(mp2_i2c0_ic_tx_abrt_sourse) \
     ((mp2_i2c0_ic_tx_abrt_sourse & MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_MASTER_DIS_MASK) >> MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_MASTER_DIS_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_GET_ARB_LOST(mp2_i2c0_ic_tx_abrt_sourse) \
     ((mp2_i2c0_ic_tx_abrt_sourse & MP2_I2C0_IC_TX_ABRT_SOURSE_ARB_LOST_MASK) >> MP2_I2C0_IC_TX_ABRT_SOURSE_ARB_LOST_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_GET_ABRT_SLVFLUSH_TXFIFO(mp2_i2c0_ic_tx_abrt_sourse) \
     ((mp2_i2c0_ic_tx_abrt_sourse & MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLVFLUSH_TXFIFO_MASK) >> MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLVFLUSH_TXFIFO_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_GET_ABRT_SLV_ARBLOST(mp2_i2c0_ic_tx_abrt_sourse) \
     ((mp2_i2c0_ic_tx_abrt_sourse & MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLV_ARBLOST_MASK) >> MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLV_ARBLOST_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_GET_ABRT_SLVRD_INTX(mp2_i2c0_ic_tx_abrt_sourse) \
     ((mp2_i2c0_ic_tx_abrt_sourse & MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLVRD_INTX_MASK) >> MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLVRD_INTX_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_GET_ABRT_USER_ABRT(mp2_i2c0_ic_tx_abrt_sourse) \
     ((mp2_i2c0_ic_tx_abrt_sourse & MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_USER_ABRT_MASK) >> MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_USER_ABRT_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_GET_TX_FLUSH_CNT(mp2_i2c0_ic_tx_abrt_sourse) \
     ((mp2_i2c0_ic_tx_abrt_sourse & MP2_I2C0_IC_TX_ABRT_SOURSE_TX_FLUSH_CNT_MASK) >> MP2_I2C0_IC_TX_ABRT_SOURSE_TX_FLUSH_CNT_SHIFT)

#define MP2_I2C0_IC_TX_ABRT_SOURSE_SET_ABRT_7B_ADDR_NOACK(mp2_i2c0_ic_tx_abrt_sourse_reg, abrt_7b_addr_noack) \
     mp2_i2c0_ic_tx_abrt_sourse_reg = (mp2_i2c0_ic_tx_abrt_sourse_reg & ~MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_7B_ADDR_NOACK_MASK) | (abrt_7b_addr_noack << MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_7B_ADDR_NOACK_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_SET_ABRT_10ADDR1_NOACK(mp2_i2c0_ic_tx_abrt_sourse_reg, abrt_10addr1_noack) \
     mp2_i2c0_ic_tx_abrt_sourse_reg = (mp2_i2c0_ic_tx_abrt_sourse_reg & ~MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10ADDR1_NOACK_MASK) | (abrt_10addr1_noack << MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10ADDR1_NOACK_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_SET_ABRT_10ADDR2_NOACK(mp2_i2c0_ic_tx_abrt_sourse_reg, abrt_10addr2_noack) \
     mp2_i2c0_ic_tx_abrt_sourse_reg = (mp2_i2c0_ic_tx_abrt_sourse_reg & ~MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10ADDR2_NOACK_MASK) | (abrt_10addr2_noack << MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10ADDR2_NOACK_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_SET_ABRT_TXDATA_NOACK(mp2_i2c0_ic_tx_abrt_sourse_reg, abrt_txdata_noack) \
     mp2_i2c0_ic_tx_abrt_sourse_reg = (mp2_i2c0_ic_tx_abrt_sourse_reg & ~MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_TXDATA_NOACK_MASK) | (abrt_txdata_noack << MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_TXDATA_NOACK_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_SET_ABRT_GCALL_NOACK(mp2_i2c0_ic_tx_abrt_sourse_reg, abrt_gcall_noack) \
     mp2_i2c0_ic_tx_abrt_sourse_reg = (mp2_i2c0_ic_tx_abrt_sourse_reg & ~MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_GCALL_NOACK_MASK) | (abrt_gcall_noack << MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_GCALL_NOACK_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_SET_ABRT_GCALL_READ(mp2_i2c0_ic_tx_abrt_sourse_reg, abrt_gcall_read) \
     mp2_i2c0_ic_tx_abrt_sourse_reg = (mp2_i2c0_ic_tx_abrt_sourse_reg & ~MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_GCALL_READ_MASK) | (abrt_gcall_read << MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_GCALL_READ_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_SET_ABRT_HS_ACKDET(mp2_i2c0_ic_tx_abrt_sourse_reg, abrt_hs_ackdet) \
     mp2_i2c0_ic_tx_abrt_sourse_reg = (mp2_i2c0_ic_tx_abrt_sourse_reg & ~MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_HS_ACKDET_MASK) | (abrt_hs_ackdet << MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_HS_ACKDET_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_SET_ABRT_SBYTE_ACKDED(mp2_i2c0_ic_tx_abrt_sourse_reg, abrt_sbyte_ackded) \
     mp2_i2c0_ic_tx_abrt_sourse_reg = (mp2_i2c0_ic_tx_abrt_sourse_reg & ~MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SBYTE_ACKDED_MASK) | (abrt_sbyte_ackded << MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SBYTE_ACKDED_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_SET_ABRT_HS_NORSTRT(mp2_i2c0_ic_tx_abrt_sourse_reg, abrt_hs_norstrt) \
     mp2_i2c0_ic_tx_abrt_sourse_reg = (mp2_i2c0_ic_tx_abrt_sourse_reg & ~MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_HS_NORSTRT_MASK) | (abrt_hs_norstrt << MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_HS_NORSTRT_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_SET_ABRT_SBYTE_NORSTRT(mp2_i2c0_ic_tx_abrt_sourse_reg, abrt_sbyte_norstrt) \
     mp2_i2c0_ic_tx_abrt_sourse_reg = (mp2_i2c0_ic_tx_abrt_sourse_reg & ~MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SBYTE_NORSTRT_MASK) | (abrt_sbyte_norstrt << MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SBYTE_NORSTRT_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_SET_ABRT_10B_RD_NORSTRT(mp2_i2c0_ic_tx_abrt_sourse_reg, abrt_10b_rd_norstrt) \
     mp2_i2c0_ic_tx_abrt_sourse_reg = (mp2_i2c0_ic_tx_abrt_sourse_reg & ~MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10B_RD_NORSTRT_MASK) | (abrt_10b_rd_norstrt << MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10B_RD_NORSTRT_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_SET_ABRT_MASTER_DIS(mp2_i2c0_ic_tx_abrt_sourse_reg, abrt_master_dis) \
     mp2_i2c0_ic_tx_abrt_sourse_reg = (mp2_i2c0_ic_tx_abrt_sourse_reg & ~MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_MASTER_DIS_MASK) | (abrt_master_dis << MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_MASTER_DIS_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_SET_ARB_LOST(mp2_i2c0_ic_tx_abrt_sourse_reg, arb_lost) \
     mp2_i2c0_ic_tx_abrt_sourse_reg = (mp2_i2c0_ic_tx_abrt_sourse_reg & ~MP2_I2C0_IC_TX_ABRT_SOURSE_ARB_LOST_MASK) | (arb_lost << MP2_I2C0_IC_TX_ABRT_SOURSE_ARB_LOST_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_SET_ABRT_SLVFLUSH_TXFIFO(mp2_i2c0_ic_tx_abrt_sourse_reg, abrt_slvflush_txfifo) \
     mp2_i2c0_ic_tx_abrt_sourse_reg = (mp2_i2c0_ic_tx_abrt_sourse_reg & ~MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLVFLUSH_TXFIFO_MASK) | (abrt_slvflush_txfifo << MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLVFLUSH_TXFIFO_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_SET_ABRT_SLV_ARBLOST(mp2_i2c0_ic_tx_abrt_sourse_reg, abrt_slv_arblost) \
     mp2_i2c0_ic_tx_abrt_sourse_reg = (mp2_i2c0_ic_tx_abrt_sourse_reg & ~MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLV_ARBLOST_MASK) | (abrt_slv_arblost << MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLV_ARBLOST_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_SET_ABRT_SLVRD_INTX(mp2_i2c0_ic_tx_abrt_sourse_reg, abrt_slvrd_intx) \
     mp2_i2c0_ic_tx_abrt_sourse_reg = (mp2_i2c0_ic_tx_abrt_sourse_reg & ~MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLVRD_INTX_MASK) | (abrt_slvrd_intx << MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLVRD_INTX_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_SET_ABRT_USER_ABRT(mp2_i2c0_ic_tx_abrt_sourse_reg, abrt_user_abrt) \
     mp2_i2c0_ic_tx_abrt_sourse_reg = (mp2_i2c0_ic_tx_abrt_sourse_reg & ~MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_USER_ABRT_MASK) | (abrt_user_abrt << MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_USER_ABRT_SHIFT)
#define MP2_I2C0_IC_TX_ABRT_SOURSE_SET_TX_FLUSH_CNT(mp2_i2c0_ic_tx_abrt_sourse_reg, tx_flush_cnt) \
     mp2_i2c0_ic_tx_abrt_sourse_reg = (mp2_i2c0_ic_tx_abrt_sourse_reg & ~MP2_I2C0_IC_TX_ABRT_SOURSE_TX_FLUSH_CNT_MASK) | (tx_flush_cnt << MP2_I2C0_IC_TX_ABRT_SOURSE_TX_FLUSH_CNT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_tx_abrt_sourse_t {
          unsigned int abrt_7b_addr_noack             : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_7B_ADDR_NOACK_SIZE;
          unsigned int abrt_10addr1_noack             : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10ADDR1_NOACK_SIZE;
          unsigned int abrt_10addr2_noack             : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10ADDR2_NOACK_SIZE;
          unsigned int abrt_txdata_noack              : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_TXDATA_NOACK_SIZE;
          unsigned int abrt_gcall_noack               : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_GCALL_NOACK_SIZE;
          unsigned int abrt_gcall_read                : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_GCALL_READ_SIZE;
          unsigned int abrt_hs_ackdet                 : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_HS_ACKDET_SIZE;
          unsigned int abrt_sbyte_ackded              : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SBYTE_ACKDED_SIZE;
          unsigned int abrt_hs_norstrt                : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_HS_NORSTRT_SIZE;
          unsigned int abrt_sbyte_norstrt             : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SBYTE_NORSTRT_SIZE;
          unsigned int abrt_10b_rd_norstrt            : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10B_RD_NORSTRT_SIZE;
          unsigned int abrt_master_dis                : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_MASTER_DIS_SIZE;
          unsigned int arb_lost                       : MP2_I2C0_IC_TX_ABRT_SOURSE_ARB_LOST_SIZE;
          unsigned int abrt_slvflush_txfifo           : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLVFLUSH_TXFIFO_SIZE;
          unsigned int abrt_slv_arblost               : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLV_ARBLOST_SIZE;
          unsigned int abrt_slvrd_intx                : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLVRD_INTX_SIZE;
          unsigned int abrt_user_abrt                 : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_USER_ABRT_SIZE;
          unsigned int                                : 6;
          unsigned int tx_flush_cnt                   : MP2_I2C0_IC_TX_ABRT_SOURSE_TX_FLUSH_CNT_SIZE;
     } mp2_i2c0_ic_tx_abrt_sourse_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_tx_abrt_sourse_t {
          unsigned int tx_flush_cnt                   : MP2_I2C0_IC_TX_ABRT_SOURSE_TX_FLUSH_CNT_SIZE;
          unsigned int                                : 6;
          unsigned int abrt_user_abrt                 : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_USER_ABRT_SIZE;
          unsigned int abrt_slvrd_intx                : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLVRD_INTX_SIZE;
          unsigned int abrt_slv_arblost               : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLV_ARBLOST_SIZE;
          unsigned int abrt_slvflush_txfifo           : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SLVFLUSH_TXFIFO_SIZE;
          unsigned int arb_lost                       : MP2_I2C0_IC_TX_ABRT_SOURSE_ARB_LOST_SIZE;
          unsigned int abrt_master_dis                : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_MASTER_DIS_SIZE;
          unsigned int abrt_10b_rd_norstrt            : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10B_RD_NORSTRT_SIZE;
          unsigned int abrt_sbyte_norstrt             : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SBYTE_NORSTRT_SIZE;
          unsigned int abrt_hs_norstrt                : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_HS_NORSTRT_SIZE;
          unsigned int abrt_sbyte_ackded              : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_SBYTE_ACKDED_SIZE;
          unsigned int abrt_hs_ackdet                 : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_HS_ACKDET_SIZE;
          unsigned int abrt_gcall_read                : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_GCALL_READ_SIZE;
          unsigned int abrt_gcall_noack               : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_GCALL_NOACK_SIZE;
          unsigned int abrt_txdata_noack              : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_TXDATA_NOACK_SIZE;
          unsigned int abrt_10addr2_noack             : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10ADDR2_NOACK_SIZE;
          unsigned int abrt_10addr1_noack             : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_10ADDR1_NOACK_SIZE;
          unsigned int abrt_7b_addr_noack             : MP2_I2C0_IC_TX_ABRT_SOURSE_ABRT_7B_ADDR_NOACK_SIZE;
     } mp2_i2c0_ic_tx_abrt_sourse_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_tx_abrt_sourse_t f;
} mp2_i2c0_ic_tx_abrt_sourse_u;


/*
 * MP2_I2C0_IC_SLV_DATA_NACK_ONLY struct
 */

#define MP2_I2C0_IC_SLV_DATA_NACK_ONLY_REG_SIZE 32
#define MP2_I2C0_IC_SLV_DATA_NACK_ONLY_NACK_SIZE 1

#define MP2_I2C0_IC_SLV_DATA_NACK_ONLY_NACK_SHIFT 0

#define MP2_I2C0_IC_SLV_DATA_NACK_ONLY_NACK_MASK 0x1

#define MP2_I2C0_IC_SLV_DATA_NACK_ONLY_MASK \
     (MP2_I2C0_IC_SLV_DATA_NACK_ONLY_NACK_MASK)

#define MP2_I2C0_IC_SLV_DATA_NACK_ONLY_DEFAULT 0x00000000

#define MP2_I2C0_IC_SLV_DATA_NACK_ONLY_GET_NACK(mp2_i2c0_ic_slv_data_nack_only) \
     ((mp2_i2c0_ic_slv_data_nack_only & MP2_I2C0_IC_SLV_DATA_NACK_ONLY_NACK_MASK) >> MP2_I2C0_IC_SLV_DATA_NACK_ONLY_NACK_SHIFT)

#define MP2_I2C0_IC_SLV_DATA_NACK_ONLY_SET_NACK(mp2_i2c0_ic_slv_data_nack_only_reg, nack) \
     mp2_i2c0_ic_slv_data_nack_only_reg = (mp2_i2c0_ic_slv_data_nack_only_reg & ~MP2_I2C0_IC_SLV_DATA_NACK_ONLY_NACK_MASK) | (nack << MP2_I2C0_IC_SLV_DATA_NACK_ONLY_NACK_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_slv_data_nack_only_t {
          unsigned int nack                           : MP2_I2C0_IC_SLV_DATA_NACK_ONLY_NACK_SIZE;
          unsigned int                                : 31;
     } mp2_i2c0_ic_slv_data_nack_only_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_slv_data_nack_only_t {
          unsigned int                                : 31;
          unsigned int nack                           : MP2_I2C0_IC_SLV_DATA_NACK_ONLY_NACK_SIZE;
     } mp2_i2c0_ic_slv_data_nack_only_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_slv_data_nack_only_t f;
} mp2_i2c0_ic_slv_data_nack_only_u;


/*
 * MP2_I2C0_IC_DMA_CR struct
 */

#define MP2_I2C0_IC_DMA_CR_REG_SIZE    32
#define MP2_I2C0_IC_DMA_CR_RDMAE_SIZE  1
#define MP2_I2C0_IC_DMA_CR_TDMAE_SIZE  1

#define MP2_I2C0_IC_DMA_CR_RDMAE_SHIFT 0
#define MP2_I2C0_IC_DMA_CR_TDMAE_SHIFT 1

#define MP2_I2C0_IC_DMA_CR_RDMAE_MASK  0x1
#define MP2_I2C0_IC_DMA_CR_TDMAE_MASK  0x2

#define MP2_I2C0_IC_DMA_CR_MASK \
     (MP2_I2C0_IC_DMA_CR_RDMAE_MASK | \
      MP2_I2C0_IC_DMA_CR_TDMAE_MASK)

#define MP2_I2C0_IC_DMA_CR_DEFAULT     0x00000000

#define MP2_I2C0_IC_DMA_CR_GET_RDMAE(mp2_i2c0_ic_dma_cr) \
     ((mp2_i2c0_ic_dma_cr & MP2_I2C0_IC_DMA_CR_RDMAE_MASK) >> MP2_I2C0_IC_DMA_CR_RDMAE_SHIFT)
#define MP2_I2C0_IC_DMA_CR_GET_TDMAE(mp2_i2c0_ic_dma_cr) \
     ((mp2_i2c0_ic_dma_cr & MP2_I2C0_IC_DMA_CR_TDMAE_MASK) >> MP2_I2C0_IC_DMA_CR_TDMAE_SHIFT)

#define MP2_I2C0_IC_DMA_CR_SET_RDMAE(mp2_i2c0_ic_dma_cr_reg, rdmae) \
     mp2_i2c0_ic_dma_cr_reg = (mp2_i2c0_ic_dma_cr_reg & ~MP2_I2C0_IC_DMA_CR_RDMAE_MASK) | (rdmae << MP2_I2C0_IC_DMA_CR_RDMAE_SHIFT)
#define MP2_I2C0_IC_DMA_CR_SET_TDMAE(mp2_i2c0_ic_dma_cr_reg, tdmae) \
     mp2_i2c0_ic_dma_cr_reg = (mp2_i2c0_ic_dma_cr_reg & ~MP2_I2C0_IC_DMA_CR_TDMAE_MASK) | (tdmae << MP2_I2C0_IC_DMA_CR_TDMAE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_dma_cr_t {
          unsigned int rdmae                          : MP2_I2C0_IC_DMA_CR_RDMAE_SIZE;
          unsigned int tdmae                          : MP2_I2C0_IC_DMA_CR_TDMAE_SIZE;
          unsigned int                                : 30;
     } mp2_i2c0_ic_dma_cr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_dma_cr_t {
          unsigned int                                : 30;
          unsigned int tdmae                          : MP2_I2C0_IC_DMA_CR_TDMAE_SIZE;
          unsigned int rdmae                          : MP2_I2C0_IC_DMA_CR_RDMAE_SIZE;
     } mp2_i2c0_ic_dma_cr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_dma_cr_t f;
} mp2_i2c0_ic_dma_cr_u;


/*
 * MP2_I2C0_IC_DMA_TDLR struct
 */

#define MP2_I2C0_IC_DMA_TDLR_REG_SIZE  32
#define MP2_I2C0_IC_DMA_TDLR_DMATDL_SIZE 32

#define MP2_I2C0_IC_DMA_TDLR_DMATDL_SHIFT 0

#define MP2_I2C0_IC_DMA_TDLR_DMATDL_MASK 0xffffffff

#define MP2_I2C0_IC_DMA_TDLR_MASK \
     (MP2_I2C0_IC_DMA_TDLR_DMATDL_MASK)

#define MP2_I2C0_IC_DMA_TDLR_DEFAULT   0x00000000

#define MP2_I2C0_IC_DMA_TDLR_GET_DMATDL(mp2_i2c0_ic_dma_tdlr) \
     ((mp2_i2c0_ic_dma_tdlr & MP2_I2C0_IC_DMA_TDLR_DMATDL_MASK) >> MP2_I2C0_IC_DMA_TDLR_DMATDL_SHIFT)

#define MP2_I2C0_IC_DMA_TDLR_SET_DMATDL(mp2_i2c0_ic_dma_tdlr_reg, dmatdl) \
     mp2_i2c0_ic_dma_tdlr_reg = (mp2_i2c0_ic_dma_tdlr_reg & ~MP2_I2C0_IC_DMA_TDLR_DMATDL_MASK) | (dmatdl << MP2_I2C0_IC_DMA_TDLR_DMATDL_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_dma_tdlr_t {
          unsigned int dmatdl                         : MP2_I2C0_IC_DMA_TDLR_DMATDL_SIZE;
     } mp2_i2c0_ic_dma_tdlr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_dma_tdlr_t {
          unsigned int dmatdl                         : MP2_I2C0_IC_DMA_TDLR_DMATDL_SIZE;
     } mp2_i2c0_ic_dma_tdlr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_dma_tdlr_t f;
} mp2_i2c0_ic_dma_tdlr_u;


/*
 * MP2_I2C0_IC_DMA_RDLR struct
 */

#define MP2_I2C0_IC_DMA_RDLR_REG_SIZE  32
#define MP2_I2C0_IC_DMA_RDLR_DMARDL_SIZE 32

#define MP2_I2C0_IC_DMA_RDLR_DMARDL_SHIFT 0

#define MP2_I2C0_IC_DMA_RDLR_DMARDL_MASK 0xffffffff

#define MP2_I2C0_IC_DMA_RDLR_MASK \
     (MP2_I2C0_IC_DMA_RDLR_DMARDL_MASK)

#define MP2_I2C0_IC_DMA_RDLR_DEFAULT   0x00000000

#define MP2_I2C0_IC_DMA_RDLR_GET_DMARDL(mp2_i2c0_ic_dma_rdlr) \
     ((mp2_i2c0_ic_dma_rdlr & MP2_I2C0_IC_DMA_RDLR_DMARDL_MASK) >> MP2_I2C0_IC_DMA_RDLR_DMARDL_SHIFT)

#define MP2_I2C0_IC_DMA_RDLR_SET_DMARDL(mp2_i2c0_ic_dma_rdlr_reg, dmardl) \
     mp2_i2c0_ic_dma_rdlr_reg = (mp2_i2c0_ic_dma_rdlr_reg & ~MP2_I2C0_IC_DMA_RDLR_DMARDL_MASK) | (dmardl << MP2_I2C0_IC_DMA_RDLR_DMARDL_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_dma_rdlr_t {
          unsigned int dmardl                         : MP2_I2C0_IC_DMA_RDLR_DMARDL_SIZE;
     } mp2_i2c0_ic_dma_rdlr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_dma_rdlr_t {
          unsigned int dmardl                         : MP2_I2C0_IC_DMA_RDLR_DMARDL_SIZE;
     } mp2_i2c0_ic_dma_rdlr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_dma_rdlr_t f;
} mp2_i2c0_ic_dma_rdlr_u;


/*
 * MP2_I2C0_IC_SDA_SETUP struct
 */

#define MP2_I2C0_IC_SDA_SETUP_REG_SIZE 32
#define MP2_I2C0_IC_SDA_SETUP_SDA_SETUP_SIZE 8

#define MP2_I2C0_IC_SDA_SETUP_SDA_SETUP_SHIFT 0

#define MP2_I2C0_IC_SDA_SETUP_SDA_SETUP_MASK 0xff

#define MP2_I2C0_IC_SDA_SETUP_MASK \
     (MP2_I2C0_IC_SDA_SETUP_SDA_SETUP_MASK)

#define MP2_I2C0_IC_SDA_SETUP_DEFAULT  0x00000000

#define MP2_I2C0_IC_SDA_SETUP_GET_SDA_SETUP(mp2_i2c0_ic_sda_setup) \
     ((mp2_i2c0_ic_sda_setup & MP2_I2C0_IC_SDA_SETUP_SDA_SETUP_MASK) >> MP2_I2C0_IC_SDA_SETUP_SDA_SETUP_SHIFT)

#define MP2_I2C0_IC_SDA_SETUP_SET_SDA_SETUP(mp2_i2c0_ic_sda_setup_reg, sda_setup) \
     mp2_i2c0_ic_sda_setup_reg = (mp2_i2c0_ic_sda_setup_reg & ~MP2_I2C0_IC_SDA_SETUP_SDA_SETUP_MASK) | (sda_setup << MP2_I2C0_IC_SDA_SETUP_SDA_SETUP_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_sda_setup_t {
          unsigned int sda_setup                      : MP2_I2C0_IC_SDA_SETUP_SDA_SETUP_SIZE;
          unsigned int                                : 24;
     } mp2_i2c0_ic_sda_setup_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_sda_setup_t {
          unsigned int                                : 24;
          unsigned int sda_setup                      : MP2_I2C0_IC_SDA_SETUP_SDA_SETUP_SIZE;
     } mp2_i2c0_ic_sda_setup_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_sda_setup_t f;
} mp2_i2c0_ic_sda_setup_u;


/*
 * MP2_I2C0_IC_ACK_GENERAL_CALL struct
 */

#define MP2_I2C0_IC_ACK_GENERAL_CALL_REG_SIZE 32
#define MP2_I2C0_IC_ACK_GENERAL_CALL_ACK_GEN_CALL_SIZE 1

#define MP2_I2C0_IC_ACK_GENERAL_CALL_ACK_GEN_CALL_SHIFT 0

#define MP2_I2C0_IC_ACK_GENERAL_CALL_ACK_GEN_CALL_MASK 0x1

#define MP2_I2C0_IC_ACK_GENERAL_CALL_MASK \
     (MP2_I2C0_IC_ACK_GENERAL_CALL_ACK_GEN_CALL_MASK)

#define MP2_I2C0_IC_ACK_GENERAL_CALL_DEFAULT 0x00000000

#define MP2_I2C0_IC_ACK_GENERAL_CALL_GET_ACK_GEN_CALL(mp2_i2c0_ic_ack_general_call) \
     ((mp2_i2c0_ic_ack_general_call & MP2_I2C0_IC_ACK_GENERAL_CALL_ACK_GEN_CALL_MASK) >> MP2_I2C0_IC_ACK_GENERAL_CALL_ACK_GEN_CALL_SHIFT)

#define MP2_I2C0_IC_ACK_GENERAL_CALL_SET_ACK_GEN_CALL(mp2_i2c0_ic_ack_general_call_reg, ack_gen_call) \
     mp2_i2c0_ic_ack_general_call_reg = (mp2_i2c0_ic_ack_general_call_reg & ~MP2_I2C0_IC_ACK_GENERAL_CALL_ACK_GEN_CALL_MASK) | (ack_gen_call << MP2_I2C0_IC_ACK_GENERAL_CALL_ACK_GEN_CALL_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_ack_general_call_t {
          unsigned int ack_gen_call                   : MP2_I2C0_IC_ACK_GENERAL_CALL_ACK_GEN_CALL_SIZE;
          unsigned int                                : 31;
     } mp2_i2c0_ic_ack_general_call_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_ack_general_call_t {
          unsigned int                                : 31;
          unsigned int ack_gen_call                   : MP2_I2C0_IC_ACK_GENERAL_CALL_ACK_GEN_CALL_SIZE;
     } mp2_i2c0_ic_ack_general_call_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_ack_general_call_t f;
} mp2_i2c0_ic_ack_general_call_u;


/*
 * MP2_I2C0_IC_ENABLE_STATUS struct
 */

#define MP2_I2C0_IC_ENABLE_STATUS_REG_SIZE 32
#define MP2_I2C0_IC_ENABLE_STATUS_IC_EN_SIZE 1
#define MP2_I2C0_IC_ENABLE_STATUS_SLV_DISABLED_WHILE_BUSY_SIZE 1
#define MP2_I2C0_IC_ENABLE_STATUS_SLV_RX_DATA_LOST_SIZE 1

#define MP2_I2C0_IC_ENABLE_STATUS_IC_EN_SHIFT 0
#define MP2_I2C0_IC_ENABLE_STATUS_SLV_DISABLED_WHILE_BUSY_SHIFT 1
#define MP2_I2C0_IC_ENABLE_STATUS_SLV_RX_DATA_LOST_SHIFT 2

#define MP2_I2C0_IC_ENABLE_STATUS_IC_EN_MASK 0x1
#define MP2_I2C0_IC_ENABLE_STATUS_SLV_DISABLED_WHILE_BUSY_MASK 0x2
#define MP2_I2C0_IC_ENABLE_STATUS_SLV_RX_DATA_LOST_MASK 0x4

#define MP2_I2C0_IC_ENABLE_STATUS_MASK \
     (MP2_I2C0_IC_ENABLE_STATUS_IC_EN_MASK | \
      MP2_I2C0_IC_ENABLE_STATUS_SLV_DISABLED_WHILE_BUSY_MASK | \
      MP2_I2C0_IC_ENABLE_STATUS_SLV_RX_DATA_LOST_MASK)

#define MP2_I2C0_IC_ENABLE_STATUS_DEFAULT 0x00000000

#define MP2_I2C0_IC_ENABLE_STATUS_GET_IC_EN(mp2_i2c0_ic_enable_status) \
     ((mp2_i2c0_ic_enable_status & MP2_I2C0_IC_ENABLE_STATUS_IC_EN_MASK) >> MP2_I2C0_IC_ENABLE_STATUS_IC_EN_SHIFT)
#define MP2_I2C0_IC_ENABLE_STATUS_GET_SLV_DISABLED_WHILE_BUSY(mp2_i2c0_ic_enable_status) \
     ((mp2_i2c0_ic_enable_status & MP2_I2C0_IC_ENABLE_STATUS_SLV_DISABLED_WHILE_BUSY_MASK) >> MP2_I2C0_IC_ENABLE_STATUS_SLV_DISABLED_WHILE_BUSY_SHIFT)
#define MP2_I2C0_IC_ENABLE_STATUS_GET_SLV_RX_DATA_LOST(mp2_i2c0_ic_enable_status) \
     ((mp2_i2c0_ic_enable_status & MP2_I2C0_IC_ENABLE_STATUS_SLV_RX_DATA_LOST_MASK) >> MP2_I2C0_IC_ENABLE_STATUS_SLV_RX_DATA_LOST_SHIFT)

#define MP2_I2C0_IC_ENABLE_STATUS_SET_IC_EN(mp2_i2c0_ic_enable_status_reg, ic_en) \
     mp2_i2c0_ic_enable_status_reg = (mp2_i2c0_ic_enable_status_reg & ~MP2_I2C0_IC_ENABLE_STATUS_IC_EN_MASK) | (ic_en << MP2_I2C0_IC_ENABLE_STATUS_IC_EN_SHIFT)
#define MP2_I2C0_IC_ENABLE_STATUS_SET_SLV_DISABLED_WHILE_BUSY(mp2_i2c0_ic_enable_status_reg, slv_disabled_while_busy) \
     mp2_i2c0_ic_enable_status_reg = (mp2_i2c0_ic_enable_status_reg & ~MP2_I2C0_IC_ENABLE_STATUS_SLV_DISABLED_WHILE_BUSY_MASK) | (slv_disabled_while_busy << MP2_I2C0_IC_ENABLE_STATUS_SLV_DISABLED_WHILE_BUSY_SHIFT)
#define MP2_I2C0_IC_ENABLE_STATUS_SET_SLV_RX_DATA_LOST(mp2_i2c0_ic_enable_status_reg, slv_rx_data_lost) \
     mp2_i2c0_ic_enable_status_reg = (mp2_i2c0_ic_enable_status_reg & ~MP2_I2C0_IC_ENABLE_STATUS_SLV_RX_DATA_LOST_MASK) | (slv_rx_data_lost << MP2_I2C0_IC_ENABLE_STATUS_SLV_RX_DATA_LOST_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_enable_status_t {
          unsigned int ic_en                          : MP2_I2C0_IC_ENABLE_STATUS_IC_EN_SIZE;
          unsigned int slv_disabled_while_busy        : MP2_I2C0_IC_ENABLE_STATUS_SLV_DISABLED_WHILE_BUSY_SIZE;
          unsigned int slv_rx_data_lost               : MP2_I2C0_IC_ENABLE_STATUS_SLV_RX_DATA_LOST_SIZE;
          unsigned int                                : 29;
     } mp2_i2c0_ic_enable_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_enable_status_t {
          unsigned int                                : 29;
          unsigned int slv_rx_data_lost               : MP2_I2C0_IC_ENABLE_STATUS_SLV_RX_DATA_LOST_SIZE;
          unsigned int slv_disabled_while_busy        : MP2_I2C0_IC_ENABLE_STATUS_SLV_DISABLED_WHILE_BUSY_SIZE;
          unsigned int ic_en                          : MP2_I2C0_IC_ENABLE_STATUS_IC_EN_SIZE;
     } mp2_i2c0_ic_enable_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_enable_status_t f;
} mp2_i2c0_ic_enable_status_u;


/*
 * MP2_I2C0_IC_FS_SPKLEN struct
 */

#define MP2_I2C0_IC_FS_SPKLEN_REG_SIZE 32
#define MP2_I2C0_IC_FS_SPKLEN_IC_FS_SPKLEN_SIZE 8

#define MP2_I2C0_IC_FS_SPKLEN_IC_FS_SPKLEN_SHIFT 0

#define MP2_I2C0_IC_FS_SPKLEN_IC_FS_SPKLEN_MASK 0xff

#define MP2_I2C0_IC_FS_SPKLEN_MASK \
     (MP2_I2C0_IC_FS_SPKLEN_IC_FS_SPKLEN_MASK)

#define MP2_I2C0_IC_FS_SPKLEN_DEFAULT  0x00000000

#define MP2_I2C0_IC_FS_SPKLEN_GET_IC_FS_SPKLEN(mp2_i2c0_ic_fs_spklen) \
     ((mp2_i2c0_ic_fs_spklen & MP2_I2C0_IC_FS_SPKLEN_IC_FS_SPKLEN_MASK) >> MP2_I2C0_IC_FS_SPKLEN_IC_FS_SPKLEN_SHIFT)

#define MP2_I2C0_IC_FS_SPKLEN_SET_IC_FS_SPKLEN(mp2_i2c0_ic_fs_spklen_reg, ic_fs_spklen) \
     mp2_i2c0_ic_fs_spklen_reg = (mp2_i2c0_ic_fs_spklen_reg & ~MP2_I2C0_IC_FS_SPKLEN_IC_FS_SPKLEN_MASK) | (ic_fs_spklen << MP2_I2C0_IC_FS_SPKLEN_IC_FS_SPKLEN_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_fs_spklen_t {
          unsigned int ic_fs_spklen                   : MP2_I2C0_IC_FS_SPKLEN_IC_FS_SPKLEN_SIZE;
          unsigned int                                : 24;
     } mp2_i2c0_ic_fs_spklen_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_fs_spklen_t {
          unsigned int                                : 24;
          unsigned int ic_fs_spklen                   : MP2_I2C0_IC_FS_SPKLEN_IC_FS_SPKLEN_SIZE;
     } mp2_i2c0_ic_fs_spklen_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_fs_spklen_t f;
} mp2_i2c0_ic_fs_spklen_u;


/*
 * MP2_I2C0_IC_HS_SPKLEN struct
 */

#define MP2_I2C0_IC_HS_SPKLEN_REG_SIZE 32
#define MP2_I2C0_IC_HS_SPKLEN_IC_HS_SPKLEN_SIZE 8

#define MP2_I2C0_IC_HS_SPKLEN_IC_HS_SPKLEN_SHIFT 0

#define MP2_I2C0_IC_HS_SPKLEN_IC_HS_SPKLEN_MASK 0xff

#define MP2_I2C0_IC_HS_SPKLEN_MASK \
     (MP2_I2C0_IC_HS_SPKLEN_IC_HS_SPKLEN_MASK)

#define MP2_I2C0_IC_HS_SPKLEN_DEFAULT  0x00000000

#define MP2_I2C0_IC_HS_SPKLEN_GET_IC_HS_SPKLEN(mp2_i2c0_ic_hs_spklen) \
     ((mp2_i2c0_ic_hs_spklen & MP2_I2C0_IC_HS_SPKLEN_IC_HS_SPKLEN_MASK) >> MP2_I2C0_IC_HS_SPKLEN_IC_HS_SPKLEN_SHIFT)

#define MP2_I2C0_IC_HS_SPKLEN_SET_IC_HS_SPKLEN(mp2_i2c0_ic_hs_spklen_reg, ic_hs_spklen) \
     mp2_i2c0_ic_hs_spklen_reg = (mp2_i2c0_ic_hs_spklen_reg & ~MP2_I2C0_IC_HS_SPKLEN_IC_HS_SPKLEN_MASK) | (ic_hs_spklen << MP2_I2C0_IC_HS_SPKLEN_IC_HS_SPKLEN_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_hs_spklen_t {
          unsigned int ic_hs_spklen                   : MP2_I2C0_IC_HS_SPKLEN_IC_HS_SPKLEN_SIZE;
          unsigned int                                : 24;
     } mp2_i2c0_ic_hs_spklen_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_hs_spklen_t {
          unsigned int                                : 24;
          unsigned int ic_hs_spklen                   : MP2_I2C0_IC_HS_SPKLEN_IC_HS_SPKLEN_SIZE;
     } mp2_i2c0_ic_hs_spklen_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_hs_spklen_t f;
} mp2_i2c0_ic_hs_spklen_u;


/*
 * MP2_I2C0_IC_CLR_RESTART_DET struct
 */

#define MP2_I2C0_IC_CLR_RESTART_DET_REG_SIZE 32
#define MP2_I2C0_IC_CLR_RESTART_DET_CLR_RESTART_DET_SIZE 1

#define MP2_I2C0_IC_CLR_RESTART_DET_CLR_RESTART_DET_SHIFT 0

#define MP2_I2C0_IC_CLR_RESTART_DET_CLR_RESTART_DET_MASK 0x1

#define MP2_I2C0_IC_CLR_RESTART_DET_MASK \
     (MP2_I2C0_IC_CLR_RESTART_DET_CLR_RESTART_DET_MASK)

#define MP2_I2C0_IC_CLR_RESTART_DET_DEFAULT 0x00000000

#define MP2_I2C0_IC_CLR_RESTART_DET_GET_CLR_RESTART_DET(mp2_i2c0_ic_clr_restart_det) \
     ((mp2_i2c0_ic_clr_restart_det & MP2_I2C0_IC_CLR_RESTART_DET_CLR_RESTART_DET_MASK) >> MP2_I2C0_IC_CLR_RESTART_DET_CLR_RESTART_DET_SHIFT)

#define MP2_I2C0_IC_CLR_RESTART_DET_SET_CLR_RESTART_DET(mp2_i2c0_ic_clr_restart_det_reg, clr_restart_det) \
     mp2_i2c0_ic_clr_restart_det_reg = (mp2_i2c0_ic_clr_restart_det_reg & ~MP2_I2C0_IC_CLR_RESTART_DET_CLR_RESTART_DET_MASK) | (clr_restart_det << MP2_I2C0_IC_CLR_RESTART_DET_CLR_RESTART_DET_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_restart_det_t {
          unsigned int clr_restart_det                : MP2_I2C0_IC_CLR_RESTART_DET_CLR_RESTART_DET_SIZE;
          unsigned int                                : 31;
     } mp2_i2c0_ic_clr_restart_det_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_clr_restart_det_t {
          unsigned int                                : 31;
          unsigned int clr_restart_det                : MP2_I2C0_IC_CLR_RESTART_DET_CLR_RESTART_DET_SIZE;
     } mp2_i2c0_ic_clr_restart_det_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_clr_restart_det_t f;
} mp2_i2c0_ic_clr_restart_det_u;


/*
 * MP2_I2C0_IC_COMP_PARAM_1 struct
 */

#define MP2_I2C0_IC_COMP_PARAM_1_REG_SIZE 32
#define MP2_I2C0_IC_COMP_PARAM_1_APB_DATA_WIDTH_SIZE 2
#define MP2_I2C0_IC_COMP_PARAM_1_MAX_SPEED_MODE_SIZE 2
#define MP2_I2C0_IC_COMP_PARAM_1_HC_COUNT_VALUES_SIZE 1
#define MP2_I2C0_IC_COMP_PARAM_1_INTR_IO_SIZE 1
#define MP2_I2C0_IC_COMP_PARAM_1_HAS_DMA_SIZE 1
#define MP2_I2C0_IC_COMP_PARAM_1_ADD_ENCODED_PARAMS_SIZE 1
#define MP2_I2C0_IC_COMP_PARAM_1_RX_BUFFER_DEPTH_SIZE 8
#define MP2_I2C0_IC_COMP_PARAM_1_TX_BUFFER_DEPTH_SIZE 8

#define MP2_I2C0_IC_COMP_PARAM_1_APB_DATA_WIDTH_SHIFT 0
#define MP2_I2C0_IC_COMP_PARAM_1_MAX_SPEED_MODE_SHIFT 2
#define MP2_I2C0_IC_COMP_PARAM_1_HC_COUNT_VALUES_SHIFT 4
#define MP2_I2C0_IC_COMP_PARAM_1_INTR_IO_SHIFT 5
#define MP2_I2C0_IC_COMP_PARAM_1_HAS_DMA_SHIFT 6
#define MP2_I2C0_IC_COMP_PARAM_1_ADD_ENCODED_PARAMS_SHIFT 7
#define MP2_I2C0_IC_COMP_PARAM_1_RX_BUFFER_DEPTH_SHIFT 8
#define MP2_I2C0_IC_COMP_PARAM_1_TX_BUFFER_DEPTH_SHIFT 16

#define MP2_I2C0_IC_COMP_PARAM_1_APB_DATA_WIDTH_MASK 0x3
#define MP2_I2C0_IC_COMP_PARAM_1_MAX_SPEED_MODE_MASK 0xc
#define MP2_I2C0_IC_COMP_PARAM_1_HC_COUNT_VALUES_MASK 0x10
#define MP2_I2C0_IC_COMP_PARAM_1_INTR_IO_MASK 0x20
#define MP2_I2C0_IC_COMP_PARAM_1_HAS_DMA_MASK 0x40
#define MP2_I2C0_IC_COMP_PARAM_1_ADD_ENCODED_PARAMS_MASK 0x80
#define MP2_I2C0_IC_COMP_PARAM_1_RX_BUFFER_DEPTH_MASK 0xff00
#define MP2_I2C0_IC_COMP_PARAM_1_TX_BUFFER_DEPTH_MASK 0xff0000

#define MP2_I2C0_IC_COMP_PARAM_1_MASK \
     (MP2_I2C0_IC_COMP_PARAM_1_APB_DATA_WIDTH_MASK | \
      MP2_I2C0_IC_COMP_PARAM_1_MAX_SPEED_MODE_MASK | \
      MP2_I2C0_IC_COMP_PARAM_1_HC_COUNT_VALUES_MASK | \
      MP2_I2C0_IC_COMP_PARAM_1_INTR_IO_MASK | \
      MP2_I2C0_IC_COMP_PARAM_1_HAS_DMA_MASK | \
      MP2_I2C0_IC_COMP_PARAM_1_ADD_ENCODED_PARAMS_MASK | \
      MP2_I2C0_IC_COMP_PARAM_1_RX_BUFFER_DEPTH_MASK | \
      MP2_I2C0_IC_COMP_PARAM_1_TX_BUFFER_DEPTH_MASK)

#define MP2_I2C0_IC_COMP_PARAM_1_DEFAULT 0x00000000

#define MP2_I2C0_IC_COMP_PARAM_1_GET_APB_DATA_WIDTH(mp2_i2c0_ic_comp_param_1) \
     ((mp2_i2c0_ic_comp_param_1 & MP2_I2C0_IC_COMP_PARAM_1_APB_DATA_WIDTH_MASK) >> MP2_I2C0_IC_COMP_PARAM_1_APB_DATA_WIDTH_SHIFT)
#define MP2_I2C0_IC_COMP_PARAM_1_GET_MAX_SPEED_MODE(mp2_i2c0_ic_comp_param_1) \
     ((mp2_i2c0_ic_comp_param_1 & MP2_I2C0_IC_COMP_PARAM_1_MAX_SPEED_MODE_MASK) >> MP2_I2C0_IC_COMP_PARAM_1_MAX_SPEED_MODE_SHIFT)
#define MP2_I2C0_IC_COMP_PARAM_1_GET_HC_COUNT_VALUES(mp2_i2c0_ic_comp_param_1) \
     ((mp2_i2c0_ic_comp_param_1 & MP2_I2C0_IC_COMP_PARAM_1_HC_COUNT_VALUES_MASK) >> MP2_I2C0_IC_COMP_PARAM_1_HC_COUNT_VALUES_SHIFT)
#define MP2_I2C0_IC_COMP_PARAM_1_GET_INTR_IO(mp2_i2c0_ic_comp_param_1) \
     ((mp2_i2c0_ic_comp_param_1 & MP2_I2C0_IC_COMP_PARAM_1_INTR_IO_MASK) >> MP2_I2C0_IC_COMP_PARAM_1_INTR_IO_SHIFT)
#define MP2_I2C0_IC_COMP_PARAM_1_GET_HAS_DMA(mp2_i2c0_ic_comp_param_1) \
     ((mp2_i2c0_ic_comp_param_1 & MP2_I2C0_IC_COMP_PARAM_1_HAS_DMA_MASK) >> MP2_I2C0_IC_COMP_PARAM_1_HAS_DMA_SHIFT)
#define MP2_I2C0_IC_COMP_PARAM_1_GET_ADD_ENCODED_PARAMS(mp2_i2c0_ic_comp_param_1) \
     ((mp2_i2c0_ic_comp_param_1 & MP2_I2C0_IC_COMP_PARAM_1_ADD_ENCODED_PARAMS_MASK) >> MP2_I2C0_IC_COMP_PARAM_1_ADD_ENCODED_PARAMS_SHIFT)
#define MP2_I2C0_IC_COMP_PARAM_1_GET_RX_BUFFER_DEPTH(mp2_i2c0_ic_comp_param_1) \
     ((mp2_i2c0_ic_comp_param_1 & MP2_I2C0_IC_COMP_PARAM_1_RX_BUFFER_DEPTH_MASK) >> MP2_I2C0_IC_COMP_PARAM_1_RX_BUFFER_DEPTH_SHIFT)
#define MP2_I2C0_IC_COMP_PARAM_1_GET_TX_BUFFER_DEPTH(mp2_i2c0_ic_comp_param_1) \
     ((mp2_i2c0_ic_comp_param_1 & MP2_I2C0_IC_COMP_PARAM_1_TX_BUFFER_DEPTH_MASK) >> MP2_I2C0_IC_COMP_PARAM_1_TX_BUFFER_DEPTH_SHIFT)

#define MP2_I2C0_IC_COMP_PARAM_1_SET_APB_DATA_WIDTH(mp2_i2c0_ic_comp_param_1_reg, apb_data_width) \
     mp2_i2c0_ic_comp_param_1_reg = (mp2_i2c0_ic_comp_param_1_reg & ~MP2_I2C0_IC_COMP_PARAM_1_APB_DATA_WIDTH_MASK) | (apb_data_width << MP2_I2C0_IC_COMP_PARAM_1_APB_DATA_WIDTH_SHIFT)
#define MP2_I2C0_IC_COMP_PARAM_1_SET_MAX_SPEED_MODE(mp2_i2c0_ic_comp_param_1_reg, max_speed_mode) \
     mp2_i2c0_ic_comp_param_1_reg = (mp2_i2c0_ic_comp_param_1_reg & ~MP2_I2C0_IC_COMP_PARAM_1_MAX_SPEED_MODE_MASK) | (max_speed_mode << MP2_I2C0_IC_COMP_PARAM_1_MAX_SPEED_MODE_SHIFT)
#define MP2_I2C0_IC_COMP_PARAM_1_SET_HC_COUNT_VALUES(mp2_i2c0_ic_comp_param_1_reg, hc_count_values) \
     mp2_i2c0_ic_comp_param_1_reg = (mp2_i2c0_ic_comp_param_1_reg & ~MP2_I2C0_IC_COMP_PARAM_1_HC_COUNT_VALUES_MASK) | (hc_count_values << MP2_I2C0_IC_COMP_PARAM_1_HC_COUNT_VALUES_SHIFT)
#define MP2_I2C0_IC_COMP_PARAM_1_SET_INTR_IO(mp2_i2c0_ic_comp_param_1_reg, intr_io) \
     mp2_i2c0_ic_comp_param_1_reg = (mp2_i2c0_ic_comp_param_1_reg & ~MP2_I2C0_IC_COMP_PARAM_1_INTR_IO_MASK) | (intr_io << MP2_I2C0_IC_COMP_PARAM_1_INTR_IO_SHIFT)
#define MP2_I2C0_IC_COMP_PARAM_1_SET_HAS_DMA(mp2_i2c0_ic_comp_param_1_reg, has_dma) \
     mp2_i2c0_ic_comp_param_1_reg = (mp2_i2c0_ic_comp_param_1_reg & ~MP2_I2C0_IC_COMP_PARAM_1_HAS_DMA_MASK) | (has_dma << MP2_I2C0_IC_COMP_PARAM_1_HAS_DMA_SHIFT)
#define MP2_I2C0_IC_COMP_PARAM_1_SET_ADD_ENCODED_PARAMS(mp2_i2c0_ic_comp_param_1_reg, add_encoded_params) \
     mp2_i2c0_ic_comp_param_1_reg = (mp2_i2c0_ic_comp_param_1_reg & ~MP2_I2C0_IC_COMP_PARAM_1_ADD_ENCODED_PARAMS_MASK) | (add_encoded_params << MP2_I2C0_IC_COMP_PARAM_1_ADD_ENCODED_PARAMS_SHIFT)
#define MP2_I2C0_IC_COMP_PARAM_1_SET_RX_BUFFER_DEPTH(mp2_i2c0_ic_comp_param_1_reg, rx_buffer_depth) \
     mp2_i2c0_ic_comp_param_1_reg = (mp2_i2c0_ic_comp_param_1_reg & ~MP2_I2C0_IC_COMP_PARAM_1_RX_BUFFER_DEPTH_MASK) | (rx_buffer_depth << MP2_I2C0_IC_COMP_PARAM_1_RX_BUFFER_DEPTH_SHIFT)
#define MP2_I2C0_IC_COMP_PARAM_1_SET_TX_BUFFER_DEPTH(mp2_i2c0_ic_comp_param_1_reg, tx_buffer_depth) \
     mp2_i2c0_ic_comp_param_1_reg = (mp2_i2c0_ic_comp_param_1_reg & ~MP2_I2C0_IC_COMP_PARAM_1_TX_BUFFER_DEPTH_MASK) | (tx_buffer_depth << MP2_I2C0_IC_COMP_PARAM_1_TX_BUFFER_DEPTH_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_comp_param_1_t {
          unsigned int apb_data_width                 : MP2_I2C0_IC_COMP_PARAM_1_APB_DATA_WIDTH_SIZE;
          unsigned int max_speed_mode                 : MP2_I2C0_IC_COMP_PARAM_1_MAX_SPEED_MODE_SIZE;
          unsigned int hc_count_values                : MP2_I2C0_IC_COMP_PARAM_1_HC_COUNT_VALUES_SIZE;
          unsigned int intr_io                        : MP2_I2C0_IC_COMP_PARAM_1_INTR_IO_SIZE;
          unsigned int has_dma                        : MP2_I2C0_IC_COMP_PARAM_1_HAS_DMA_SIZE;
          unsigned int add_encoded_params             : MP2_I2C0_IC_COMP_PARAM_1_ADD_ENCODED_PARAMS_SIZE;
          unsigned int rx_buffer_depth                : MP2_I2C0_IC_COMP_PARAM_1_RX_BUFFER_DEPTH_SIZE;
          unsigned int tx_buffer_depth                : MP2_I2C0_IC_COMP_PARAM_1_TX_BUFFER_DEPTH_SIZE;
          unsigned int                                : 8;
     } mp2_i2c0_ic_comp_param_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_comp_param_1_t {
          unsigned int                                : 8;
          unsigned int tx_buffer_depth                : MP2_I2C0_IC_COMP_PARAM_1_TX_BUFFER_DEPTH_SIZE;
          unsigned int rx_buffer_depth                : MP2_I2C0_IC_COMP_PARAM_1_RX_BUFFER_DEPTH_SIZE;
          unsigned int add_encoded_params             : MP2_I2C0_IC_COMP_PARAM_1_ADD_ENCODED_PARAMS_SIZE;
          unsigned int has_dma                        : MP2_I2C0_IC_COMP_PARAM_1_HAS_DMA_SIZE;
          unsigned int intr_io                        : MP2_I2C0_IC_COMP_PARAM_1_INTR_IO_SIZE;
          unsigned int hc_count_values                : MP2_I2C0_IC_COMP_PARAM_1_HC_COUNT_VALUES_SIZE;
          unsigned int max_speed_mode                 : MP2_I2C0_IC_COMP_PARAM_1_MAX_SPEED_MODE_SIZE;
          unsigned int apb_data_width                 : MP2_I2C0_IC_COMP_PARAM_1_APB_DATA_WIDTH_SIZE;
     } mp2_i2c0_ic_comp_param_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_comp_param_1_t f;
} mp2_i2c0_ic_comp_param_1_u;


/*
 * MP2_I2C0_IC_COMP_VERSION struct
 */

#define MP2_I2C0_IC_COMP_VERSION_REG_SIZE 32
#define MP2_I2C0_IC_COMP_VERSION_IC_COMP_VERSION_SIZE 32

#define MP2_I2C0_IC_COMP_VERSION_IC_COMP_VERSION_SHIFT 0

#define MP2_I2C0_IC_COMP_VERSION_IC_COMP_VERSION_MASK 0xffffffff

#define MP2_I2C0_IC_COMP_VERSION_MASK \
     (MP2_I2C0_IC_COMP_VERSION_IC_COMP_VERSION_MASK)

#define MP2_I2C0_IC_COMP_VERSION_DEFAULT 0x00000000

#define MP2_I2C0_IC_COMP_VERSION_GET_IC_COMP_VERSION(mp2_i2c0_ic_comp_version) \
     ((mp2_i2c0_ic_comp_version & MP2_I2C0_IC_COMP_VERSION_IC_COMP_VERSION_MASK) >> MP2_I2C0_IC_COMP_VERSION_IC_COMP_VERSION_SHIFT)

#define MP2_I2C0_IC_COMP_VERSION_SET_IC_COMP_VERSION(mp2_i2c0_ic_comp_version_reg, ic_comp_version) \
     mp2_i2c0_ic_comp_version_reg = (mp2_i2c0_ic_comp_version_reg & ~MP2_I2C0_IC_COMP_VERSION_IC_COMP_VERSION_MASK) | (ic_comp_version << MP2_I2C0_IC_COMP_VERSION_IC_COMP_VERSION_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_comp_version_t {
          unsigned int ic_comp_version                : MP2_I2C0_IC_COMP_VERSION_IC_COMP_VERSION_SIZE;
     } mp2_i2c0_ic_comp_version_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_comp_version_t {
          unsigned int ic_comp_version                : MP2_I2C0_IC_COMP_VERSION_IC_COMP_VERSION_SIZE;
     } mp2_i2c0_ic_comp_version_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_comp_version_t f;
} mp2_i2c0_ic_comp_version_u;


/*
 * MP2_I2C0_IC_COMP_TYPE struct
 */

#define MP2_I2C0_IC_COMP_TYPE_REG_SIZE 32
#define MP2_I2C0_IC_COMP_TYPE_IC_COMP_TYPE_SIZE 32

#define MP2_I2C0_IC_COMP_TYPE_IC_COMP_TYPE_SHIFT 0

#define MP2_I2C0_IC_COMP_TYPE_IC_COMP_TYPE_MASK 0xffffffff

#define MP2_I2C0_IC_COMP_TYPE_MASK \
     (MP2_I2C0_IC_COMP_TYPE_IC_COMP_TYPE_MASK)

#define MP2_I2C0_IC_COMP_TYPE_DEFAULT  0x00000000

#define MP2_I2C0_IC_COMP_TYPE_GET_IC_COMP_TYPE(mp2_i2c0_ic_comp_type) \
     ((mp2_i2c0_ic_comp_type & MP2_I2C0_IC_COMP_TYPE_IC_COMP_TYPE_MASK) >> MP2_I2C0_IC_COMP_TYPE_IC_COMP_TYPE_SHIFT)

#define MP2_I2C0_IC_COMP_TYPE_SET_IC_COMP_TYPE(mp2_i2c0_ic_comp_type_reg, ic_comp_type) \
     mp2_i2c0_ic_comp_type_reg = (mp2_i2c0_ic_comp_type_reg & ~MP2_I2C0_IC_COMP_TYPE_IC_COMP_TYPE_MASK) | (ic_comp_type << MP2_I2C0_IC_COMP_TYPE_IC_COMP_TYPE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_comp_type_t {
          unsigned int ic_comp_type                   : MP2_I2C0_IC_COMP_TYPE_IC_COMP_TYPE_SIZE;
     } mp2_i2c0_ic_comp_type_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_ic_comp_type_t {
          unsigned int ic_comp_type                   : MP2_I2C0_IC_COMP_TYPE_IC_COMP_TYPE_SIZE;
     } mp2_i2c0_ic_comp_type_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_ic_comp_type_t f;
} mp2_i2c0_ic_comp_type_u;


/*
 * MP2_I3C0_HCI_VERSION struct
 */

#define MP2_I3C0_HCI_VERSION_REG_SIZE  32
#define MP2_I3C0_HCI_VERSION_VERSION_SIZE 32

#define MP2_I3C0_HCI_VERSION_VERSION_SHIFT 0

#define MP2_I3C0_HCI_VERSION_VERSION_MASK 0xffffffff

#define MP2_I3C0_HCI_VERSION_MASK \
     (MP2_I3C0_HCI_VERSION_VERSION_MASK)

#define MP2_I3C0_HCI_VERSION_DEFAULT   0x00000100

#define MP2_I3C0_HCI_VERSION_GET_VERSION(mp2_i3c0_hci_version) \
     ((mp2_i3c0_hci_version & MP2_I3C0_HCI_VERSION_VERSION_MASK) >> MP2_I3C0_HCI_VERSION_VERSION_SHIFT)

#define MP2_I3C0_HCI_VERSION_SET_VERSION(mp2_i3c0_hci_version_reg, version) \
     mp2_i3c0_hci_version_reg = (mp2_i3c0_hci_version_reg & ~MP2_I3C0_HCI_VERSION_VERSION_MASK) | (version << MP2_I3C0_HCI_VERSION_VERSION_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_hci_version_t {
          unsigned int version                        : MP2_I3C0_HCI_VERSION_VERSION_SIZE;
     } mp2_i3c0_hci_version_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_hci_version_t {
          unsigned int version                        : MP2_I3C0_HCI_VERSION_VERSION_SIZE;
     } mp2_i3c0_hci_version_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_hci_version_t f;
} mp2_i3c0_hci_version_u;


/*
 * MP2_I3C0_HC_CONTROL struct
 */

#define MP2_I3C0_HC_CONTROL_REG_SIZE   32
#define MP2_I3C0_HC_CONTROL_IBA_INCLUDE_SIZE 1
#define MP2_I3C0_HC_CONTROL_RESERVED1_SIZE 6
#define MP2_I3C0_HC_CONTROL_I2C_SLAVE_PRESENT_SIZE 1
#define MP2_I3C0_HC_CONTROL_HOT_JOIN_CTRL_SIZE 1
#define MP2_I3C0_HC_CONTROL_RESERVED0_SIZE 20
#define MP2_I3C0_HC_CONTROL_ABORT_SIZE 1
#define MP2_I3C0_HC_CONTROL_RESUME_SIZE 1
#define MP2_I3C0_HC_CONTROL_BUS_ENABLE_SIZE 1

#define MP2_I3C0_HC_CONTROL_IBA_INCLUDE_SHIFT 0
#define MP2_I3C0_HC_CONTROL_RESERVED1_SHIFT 1
#define MP2_I3C0_HC_CONTROL_I2C_SLAVE_PRESENT_SHIFT 7
#define MP2_I3C0_HC_CONTROL_HOT_JOIN_CTRL_SHIFT 8
#define MP2_I3C0_HC_CONTROL_RESERVED0_SHIFT 9
#define MP2_I3C0_HC_CONTROL_ABORT_SHIFT 29
#define MP2_I3C0_HC_CONTROL_RESUME_SHIFT 30
#define MP2_I3C0_HC_CONTROL_BUS_ENABLE_SHIFT 31

#define MP2_I3C0_HC_CONTROL_IBA_INCLUDE_MASK 0x1
#define MP2_I3C0_HC_CONTROL_RESERVED1_MASK 0x7e
#define MP2_I3C0_HC_CONTROL_I2C_SLAVE_PRESENT_MASK 0x80
#define MP2_I3C0_HC_CONTROL_HOT_JOIN_CTRL_MASK 0x100
#define MP2_I3C0_HC_CONTROL_RESERVED0_MASK 0x1ffffe00
#define MP2_I3C0_HC_CONTROL_ABORT_MASK 0x20000000
#define MP2_I3C0_HC_CONTROL_RESUME_MASK 0x40000000
#define MP2_I3C0_HC_CONTROL_BUS_ENABLE_MASK 0x80000000

#define MP2_I3C0_HC_CONTROL_MASK \
     (MP2_I3C0_HC_CONTROL_IBA_INCLUDE_MASK | \
      MP2_I3C0_HC_CONTROL_RESERVED1_MASK | \
      MP2_I3C0_HC_CONTROL_I2C_SLAVE_PRESENT_MASK | \
      MP2_I3C0_HC_CONTROL_HOT_JOIN_CTRL_MASK | \
      MP2_I3C0_HC_CONTROL_RESERVED0_MASK | \
      MP2_I3C0_HC_CONTROL_ABORT_MASK | \
      MP2_I3C0_HC_CONTROL_RESUME_MASK | \
      MP2_I3C0_HC_CONTROL_BUS_ENABLE_MASK)

#define MP2_I3C0_HC_CONTROL_DEFAULT    0x00000000

#define MP2_I3C0_HC_CONTROL_GET_IBA_INCLUDE(mp2_i3c0_hc_control) \
     ((mp2_i3c0_hc_control & MP2_I3C0_HC_CONTROL_IBA_INCLUDE_MASK) >> MP2_I3C0_HC_CONTROL_IBA_INCLUDE_SHIFT)
#define MP2_I3C0_HC_CONTROL_GET_RESERVED1(mp2_i3c0_hc_control) \
     ((mp2_i3c0_hc_control & MP2_I3C0_HC_CONTROL_RESERVED1_MASK) >> MP2_I3C0_HC_CONTROL_RESERVED1_SHIFT)
#define MP2_I3C0_HC_CONTROL_GET_I2C_SLAVE_PRESENT(mp2_i3c0_hc_control) \
     ((mp2_i3c0_hc_control & MP2_I3C0_HC_CONTROL_I2C_SLAVE_PRESENT_MASK) >> MP2_I3C0_HC_CONTROL_I2C_SLAVE_PRESENT_SHIFT)
#define MP2_I3C0_HC_CONTROL_GET_HOT_JOIN_CTRL(mp2_i3c0_hc_control) \
     ((mp2_i3c0_hc_control & MP2_I3C0_HC_CONTROL_HOT_JOIN_CTRL_MASK) >> MP2_I3C0_HC_CONTROL_HOT_JOIN_CTRL_SHIFT)
#define MP2_I3C0_HC_CONTROL_GET_RESERVED0(mp2_i3c0_hc_control) \
     ((mp2_i3c0_hc_control & MP2_I3C0_HC_CONTROL_RESERVED0_MASK) >> MP2_I3C0_HC_CONTROL_RESERVED0_SHIFT)
#define MP2_I3C0_HC_CONTROL_GET_ABORT(mp2_i3c0_hc_control) \
     ((mp2_i3c0_hc_control & MP2_I3C0_HC_CONTROL_ABORT_MASK) >> MP2_I3C0_HC_CONTROL_ABORT_SHIFT)
#define MP2_I3C0_HC_CONTROL_GET_RESUME(mp2_i3c0_hc_control) \
     ((mp2_i3c0_hc_control & MP2_I3C0_HC_CONTROL_RESUME_MASK) >> MP2_I3C0_HC_CONTROL_RESUME_SHIFT)
#define MP2_I3C0_HC_CONTROL_GET_BUS_ENABLE(mp2_i3c0_hc_control) \
     ((mp2_i3c0_hc_control & MP2_I3C0_HC_CONTROL_BUS_ENABLE_MASK) >> MP2_I3C0_HC_CONTROL_BUS_ENABLE_SHIFT)

#define MP2_I3C0_HC_CONTROL_SET_IBA_INCLUDE(mp2_i3c0_hc_control_reg, iba_include) \
     mp2_i3c0_hc_control_reg = (mp2_i3c0_hc_control_reg & ~MP2_I3C0_HC_CONTROL_IBA_INCLUDE_MASK) | (iba_include << MP2_I3C0_HC_CONTROL_IBA_INCLUDE_SHIFT)
#define MP2_I3C0_HC_CONTROL_SET_RESERVED1(mp2_i3c0_hc_control_reg, reserved1) \
     mp2_i3c0_hc_control_reg = (mp2_i3c0_hc_control_reg & ~MP2_I3C0_HC_CONTROL_RESERVED1_MASK) | (reserved1 << MP2_I3C0_HC_CONTROL_RESERVED1_SHIFT)
#define MP2_I3C0_HC_CONTROL_SET_I2C_SLAVE_PRESENT(mp2_i3c0_hc_control_reg, i2c_slave_present) \
     mp2_i3c0_hc_control_reg = (mp2_i3c0_hc_control_reg & ~MP2_I3C0_HC_CONTROL_I2C_SLAVE_PRESENT_MASK) | (i2c_slave_present << MP2_I3C0_HC_CONTROL_I2C_SLAVE_PRESENT_SHIFT)
#define MP2_I3C0_HC_CONTROL_SET_HOT_JOIN_CTRL(mp2_i3c0_hc_control_reg, hot_join_ctrl) \
     mp2_i3c0_hc_control_reg = (mp2_i3c0_hc_control_reg & ~MP2_I3C0_HC_CONTROL_HOT_JOIN_CTRL_MASK) | (hot_join_ctrl << MP2_I3C0_HC_CONTROL_HOT_JOIN_CTRL_SHIFT)
#define MP2_I3C0_HC_CONTROL_SET_RESERVED0(mp2_i3c0_hc_control_reg, reserved0) \
     mp2_i3c0_hc_control_reg = (mp2_i3c0_hc_control_reg & ~MP2_I3C0_HC_CONTROL_RESERVED0_MASK) | (reserved0 << MP2_I3C0_HC_CONTROL_RESERVED0_SHIFT)
#define MP2_I3C0_HC_CONTROL_SET_ABORT(mp2_i3c0_hc_control_reg, abort) \
     mp2_i3c0_hc_control_reg = (mp2_i3c0_hc_control_reg & ~MP2_I3C0_HC_CONTROL_ABORT_MASK) | (abort << MP2_I3C0_HC_CONTROL_ABORT_SHIFT)
#define MP2_I3C0_HC_CONTROL_SET_RESUME(mp2_i3c0_hc_control_reg, resume) \
     mp2_i3c0_hc_control_reg = (mp2_i3c0_hc_control_reg & ~MP2_I3C0_HC_CONTROL_RESUME_MASK) | (resume << MP2_I3C0_HC_CONTROL_RESUME_SHIFT)
#define MP2_I3C0_HC_CONTROL_SET_BUS_ENABLE(mp2_i3c0_hc_control_reg, bus_enable) \
     mp2_i3c0_hc_control_reg = (mp2_i3c0_hc_control_reg & ~MP2_I3C0_HC_CONTROL_BUS_ENABLE_MASK) | (bus_enable << MP2_I3C0_HC_CONTROL_BUS_ENABLE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_hc_control_t {
          unsigned int iba_include                    : MP2_I3C0_HC_CONTROL_IBA_INCLUDE_SIZE;
          unsigned int reserved1                      : MP2_I3C0_HC_CONTROL_RESERVED1_SIZE;
          unsigned int i2c_slave_present              : MP2_I3C0_HC_CONTROL_I2C_SLAVE_PRESENT_SIZE;
          unsigned int hot_join_ctrl                  : MP2_I3C0_HC_CONTROL_HOT_JOIN_CTRL_SIZE;
          unsigned int reserved0                      : MP2_I3C0_HC_CONTROL_RESERVED0_SIZE;
          unsigned int abort                          : MP2_I3C0_HC_CONTROL_ABORT_SIZE;
          unsigned int resume                         : MP2_I3C0_HC_CONTROL_RESUME_SIZE;
          unsigned int bus_enable                     : MP2_I3C0_HC_CONTROL_BUS_ENABLE_SIZE;
     } mp2_i3c0_hc_control_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_hc_control_t {
          unsigned int bus_enable                     : MP2_I3C0_HC_CONTROL_BUS_ENABLE_SIZE;
          unsigned int resume                         : MP2_I3C0_HC_CONTROL_RESUME_SIZE;
          unsigned int abort                          : MP2_I3C0_HC_CONTROL_ABORT_SIZE;
          unsigned int reserved0                      : MP2_I3C0_HC_CONTROL_RESERVED0_SIZE;
          unsigned int hot_join_ctrl                  : MP2_I3C0_HC_CONTROL_HOT_JOIN_CTRL_SIZE;
          unsigned int i2c_slave_present              : MP2_I3C0_HC_CONTROL_I2C_SLAVE_PRESENT_SIZE;
          unsigned int reserved1                      : MP2_I3C0_HC_CONTROL_RESERVED1_SIZE;
          unsigned int iba_include                    : MP2_I3C0_HC_CONTROL_IBA_INCLUDE_SIZE;
     } mp2_i3c0_hc_control_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_hc_control_t f;
} mp2_i3c0_hc_control_u;


/*
 * MP2_I3C0_MASTER_DEVICE_ADDR struct
 */

#define MP2_I3C0_MASTER_DEVICE_ADDR_REG_SIZE 32
#define MP2_I3C0_MASTER_DEVICE_ADDR_RESERVED1_SIZE 16
#define MP2_I3C0_MASTER_DEVICE_ADDR_DYNAMIC_ADDR_SIZE 7
#define MP2_I3C0_MASTER_DEVICE_ADDR_RESERVED0_SIZE 8
#define MP2_I3C0_MASTER_DEVICE_ADDR_DYNAMIC_ADDR_VALID_SIZE 1

#define MP2_I3C0_MASTER_DEVICE_ADDR_RESERVED1_SHIFT 0
#define MP2_I3C0_MASTER_DEVICE_ADDR_DYNAMIC_ADDR_SHIFT 16
#define MP2_I3C0_MASTER_DEVICE_ADDR_RESERVED0_SHIFT 23
#define MP2_I3C0_MASTER_DEVICE_ADDR_DYNAMIC_ADDR_VALID_SHIFT 31

#define MP2_I3C0_MASTER_DEVICE_ADDR_RESERVED1_MASK 0xffff
#define MP2_I3C0_MASTER_DEVICE_ADDR_DYNAMIC_ADDR_MASK 0x7f0000
#define MP2_I3C0_MASTER_DEVICE_ADDR_RESERVED0_MASK 0x7f800000
#define MP2_I3C0_MASTER_DEVICE_ADDR_DYNAMIC_ADDR_VALID_MASK 0x80000000

#define MP2_I3C0_MASTER_DEVICE_ADDR_MASK \
     (MP2_I3C0_MASTER_DEVICE_ADDR_RESERVED1_MASK | \
      MP2_I3C0_MASTER_DEVICE_ADDR_DYNAMIC_ADDR_MASK | \
      MP2_I3C0_MASTER_DEVICE_ADDR_RESERVED0_MASK | \
      MP2_I3C0_MASTER_DEVICE_ADDR_DYNAMIC_ADDR_VALID_MASK)

#define MP2_I3C0_MASTER_DEVICE_ADDR_DEFAULT 0x80000000

#define MP2_I3C0_MASTER_DEVICE_ADDR_GET_RESERVED1(mp2_i3c0_master_device_addr) \
     ((mp2_i3c0_master_device_addr & MP2_I3C0_MASTER_DEVICE_ADDR_RESERVED1_MASK) >> MP2_I3C0_MASTER_DEVICE_ADDR_RESERVED1_SHIFT)
#define MP2_I3C0_MASTER_DEVICE_ADDR_GET_DYNAMIC_ADDR(mp2_i3c0_master_device_addr) \
     ((mp2_i3c0_master_device_addr & MP2_I3C0_MASTER_DEVICE_ADDR_DYNAMIC_ADDR_MASK) >> MP2_I3C0_MASTER_DEVICE_ADDR_DYNAMIC_ADDR_SHIFT)
#define MP2_I3C0_MASTER_DEVICE_ADDR_GET_RESERVED0(mp2_i3c0_master_device_addr) \
     ((mp2_i3c0_master_device_addr & MP2_I3C0_MASTER_DEVICE_ADDR_RESERVED0_MASK) >> MP2_I3C0_MASTER_DEVICE_ADDR_RESERVED0_SHIFT)
#define MP2_I3C0_MASTER_DEVICE_ADDR_GET_DYNAMIC_ADDR_VALID(mp2_i3c0_master_device_addr) \
     ((mp2_i3c0_master_device_addr & MP2_I3C0_MASTER_DEVICE_ADDR_DYNAMIC_ADDR_VALID_MASK) >> MP2_I3C0_MASTER_DEVICE_ADDR_DYNAMIC_ADDR_VALID_SHIFT)

#define MP2_I3C0_MASTER_DEVICE_ADDR_SET_RESERVED1(mp2_i3c0_master_device_addr_reg, reserved1) \
     mp2_i3c0_master_device_addr_reg = (mp2_i3c0_master_device_addr_reg & ~MP2_I3C0_MASTER_DEVICE_ADDR_RESERVED1_MASK) | (reserved1 << MP2_I3C0_MASTER_DEVICE_ADDR_RESERVED1_SHIFT)
#define MP2_I3C0_MASTER_DEVICE_ADDR_SET_DYNAMIC_ADDR(mp2_i3c0_master_device_addr_reg, dynamic_addr) \
     mp2_i3c0_master_device_addr_reg = (mp2_i3c0_master_device_addr_reg & ~MP2_I3C0_MASTER_DEVICE_ADDR_DYNAMIC_ADDR_MASK) | (dynamic_addr << MP2_I3C0_MASTER_DEVICE_ADDR_DYNAMIC_ADDR_SHIFT)
#define MP2_I3C0_MASTER_DEVICE_ADDR_SET_RESERVED0(mp2_i3c0_master_device_addr_reg, reserved0) \
     mp2_i3c0_master_device_addr_reg = (mp2_i3c0_master_device_addr_reg & ~MP2_I3C0_MASTER_DEVICE_ADDR_RESERVED0_MASK) | (reserved0 << MP2_I3C0_MASTER_DEVICE_ADDR_RESERVED0_SHIFT)
#define MP2_I3C0_MASTER_DEVICE_ADDR_SET_DYNAMIC_ADDR_VALID(mp2_i3c0_master_device_addr_reg, dynamic_addr_valid) \
     mp2_i3c0_master_device_addr_reg = (mp2_i3c0_master_device_addr_reg & ~MP2_I3C0_MASTER_DEVICE_ADDR_DYNAMIC_ADDR_VALID_MASK) | (dynamic_addr_valid << MP2_I3C0_MASTER_DEVICE_ADDR_DYNAMIC_ADDR_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_master_device_addr_t {
          unsigned int reserved1                      : MP2_I3C0_MASTER_DEVICE_ADDR_RESERVED1_SIZE;
          unsigned int dynamic_addr                   : MP2_I3C0_MASTER_DEVICE_ADDR_DYNAMIC_ADDR_SIZE;
          unsigned int reserved0                      : MP2_I3C0_MASTER_DEVICE_ADDR_RESERVED0_SIZE;
          unsigned int dynamic_addr_valid             : MP2_I3C0_MASTER_DEVICE_ADDR_DYNAMIC_ADDR_VALID_SIZE;
     } mp2_i3c0_master_device_addr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_master_device_addr_t {
          unsigned int dynamic_addr_valid             : MP2_I3C0_MASTER_DEVICE_ADDR_DYNAMIC_ADDR_VALID_SIZE;
          unsigned int reserved0                      : MP2_I3C0_MASTER_DEVICE_ADDR_RESERVED0_SIZE;
          unsigned int dynamic_addr                   : MP2_I3C0_MASTER_DEVICE_ADDR_DYNAMIC_ADDR_SIZE;
          unsigned int reserved1                      : MP2_I3C0_MASTER_DEVICE_ADDR_RESERVED1_SIZE;
     } mp2_i3c0_master_device_addr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_master_device_addr_t f;
} mp2_i3c0_master_device_addr_u;


/*
 * MP2_I3C0_HC_CAPABILITIES struct
 */

#define MP2_I3C0_HC_CAPABILITIES_REG_SIZE 32
#define MP2_I3C0_HC_CAPABILITIES_RESERVED2_SIZE 2
#define MP2_I3C0_HC_CAPABILITIES_COMBO_COMMAND_SIZE 1
#define MP2_I3C0_HC_CAPABILITIES_AUTO_COMMAND_SIZE 1
#define MP2_I3C0_HC_CAPABILITIES_RESERVED1_SIZE 1
#define MP2_I3C0_HC_CAPABILITIES_NON_CURRENT_MASTER_CAP_SIZE 1
#define MP2_I3C0_HC_CAPABILITIES_HDR_DDR_EN_SIZE 1
#define MP2_I3C0_HC_CAPABILITIES_HDR_TS_EN_SIZE 1
#define MP2_I3C0_HC_CAPABILITIES_RESERVED0_SIZE 24

#define MP2_I3C0_HC_CAPABILITIES_RESERVED2_SHIFT 0
#define MP2_I3C0_HC_CAPABILITIES_COMBO_COMMAND_SHIFT 2
#define MP2_I3C0_HC_CAPABILITIES_AUTO_COMMAND_SHIFT 3
#define MP2_I3C0_HC_CAPABILITIES_RESERVED1_SHIFT 4
#define MP2_I3C0_HC_CAPABILITIES_NON_CURRENT_MASTER_CAP_SHIFT 5
#define MP2_I3C0_HC_CAPABILITIES_HDR_DDR_EN_SHIFT 6
#define MP2_I3C0_HC_CAPABILITIES_HDR_TS_EN_SHIFT 7
#define MP2_I3C0_HC_CAPABILITIES_RESERVED0_SHIFT 8

#define MP2_I3C0_HC_CAPABILITIES_RESERVED2_MASK 0x3
#define MP2_I3C0_HC_CAPABILITIES_COMBO_COMMAND_MASK 0x4
#define MP2_I3C0_HC_CAPABILITIES_AUTO_COMMAND_MASK 0x8
#define MP2_I3C0_HC_CAPABILITIES_RESERVED1_MASK 0x10
#define MP2_I3C0_HC_CAPABILITIES_NON_CURRENT_MASTER_CAP_MASK 0x20
#define MP2_I3C0_HC_CAPABILITIES_HDR_DDR_EN_MASK 0x40
#define MP2_I3C0_HC_CAPABILITIES_HDR_TS_EN_MASK 0x80
#define MP2_I3C0_HC_CAPABILITIES_RESERVED0_MASK 0xffffff00

#define MP2_I3C0_HC_CAPABILITIES_MASK \
     (MP2_I3C0_HC_CAPABILITIES_RESERVED2_MASK | \
      MP2_I3C0_HC_CAPABILITIES_COMBO_COMMAND_MASK | \
      MP2_I3C0_HC_CAPABILITIES_AUTO_COMMAND_MASK | \
      MP2_I3C0_HC_CAPABILITIES_RESERVED1_MASK | \
      MP2_I3C0_HC_CAPABILITIES_NON_CURRENT_MASTER_CAP_MASK | \
      MP2_I3C0_HC_CAPABILITIES_HDR_DDR_EN_MASK | \
      MP2_I3C0_HC_CAPABILITIES_HDR_TS_EN_MASK | \
      MP2_I3C0_HC_CAPABILITIES_RESERVED0_MASK)

#define MP2_I3C0_HC_CAPABILITIES_DEFAULT 0x000000cc

#define MP2_I3C0_HC_CAPABILITIES_GET_RESERVED2(mp2_i3c0_hc_capabilities) \
     ((mp2_i3c0_hc_capabilities & MP2_I3C0_HC_CAPABILITIES_RESERVED2_MASK) >> MP2_I3C0_HC_CAPABILITIES_RESERVED2_SHIFT)
#define MP2_I3C0_HC_CAPABILITIES_GET_COMBO_COMMAND(mp2_i3c0_hc_capabilities) \
     ((mp2_i3c0_hc_capabilities & MP2_I3C0_HC_CAPABILITIES_COMBO_COMMAND_MASK) >> MP2_I3C0_HC_CAPABILITIES_COMBO_COMMAND_SHIFT)
#define MP2_I3C0_HC_CAPABILITIES_GET_AUTO_COMMAND(mp2_i3c0_hc_capabilities) \
     ((mp2_i3c0_hc_capabilities & MP2_I3C0_HC_CAPABILITIES_AUTO_COMMAND_MASK) >> MP2_I3C0_HC_CAPABILITIES_AUTO_COMMAND_SHIFT)
#define MP2_I3C0_HC_CAPABILITIES_GET_RESERVED1(mp2_i3c0_hc_capabilities) \
     ((mp2_i3c0_hc_capabilities & MP2_I3C0_HC_CAPABILITIES_RESERVED1_MASK) >> MP2_I3C0_HC_CAPABILITIES_RESERVED1_SHIFT)
#define MP2_I3C0_HC_CAPABILITIES_GET_NON_CURRENT_MASTER_CAP(mp2_i3c0_hc_capabilities) \
     ((mp2_i3c0_hc_capabilities & MP2_I3C0_HC_CAPABILITIES_NON_CURRENT_MASTER_CAP_MASK) >> MP2_I3C0_HC_CAPABILITIES_NON_CURRENT_MASTER_CAP_SHIFT)
#define MP2_I3C0_HC_CAPABILITIES_GET_HDR_DDR_EN(mp2_i3c0_hc_capabilities) \
     ((mp2_i3c0_hc_capabilities & MP2_I3C0_HC_CAPABILITIES_HDR_DDR_EN_MASK) >> MP2_I3C0_HC_CAPABILITIES_HDR_DDR_EN_SHIFT)
#define MP2_I3C0_HC_CAPABILITIES_GET_HDR_TS_EN(mp2_i3c0_hc_capabilities) \
     ((mp2_i3c0_hc_capabilities & MP2_I3C0_HC_CAPABILITIES_HDR_TS_EN_MASK) >> MP2_I3C0_HC_CAPABILITIES_HDR_TS_EN_SHIFT)
#define MP2_I3C0_HC_CAPABILITIES_GET_RESERVED0(mp2_i3c0_hc_capabilities) \
     ((mp2_i3c0_hc_capabilities & MP2_I3C0_HC_CAPABILITIES_RESERVED0_MASK) >> MP2_I3C0_HC_CAPABILITIES_RESERVED0_SHIFT)

#define MP2_I3C0_HC_CAPABILITIES_SET_RESERVED2(mp2_i3c0_hc_capabilities_reg, reserved2) \
     mp2_i3c0_hc_capabilities_reg = (mp2_i3c0_hc_capabilities_reg & ~MP2_I3C0_HC_CAPABILITIES_RESERVED2_MASK) | (reserved2 << MP2_I3C0_HC_CAPABILITIES_RESERVED2_SHIFT)
#define MP2_I3C0_HC_CAPABILITIES_SET_COMBO_COMMAND(mp2_i3c0_hc_capabilities_reg, combo_command) \
     mp2_i3c0_hc_capabilities_reg = (mp2_i3c0_hc_capabilities_reg & ~MP2_I3C0_HC_CAPABILITIES_COMBO_COMMAND_MASK) | (combo_command << MP2_I3C0_HC_CAPABILITIES_COMBO_COMMAND_SHIFT)
#define MP2_I3C0_HC_CAPABILITIES_SET_AUTO_COMMAND(mp2_i3c0_hc_capabilities_reg, auto_command) \
     mp2_i3c0_hc_capabilities_reg = (mp2_i3c0_hc_capabilities_reg & ~MP2_I3C0_HC_CAPABILITIES_AUTO_COMMAND_MASK) | (auto_command << MP2_I3C0_HC_CAPABILITIES_AUTO_COMMAND_SHIFT)
#define MP2_I3C0_HC_CAPABILITIES_SET_RESERVED1(mp2_i3c0_hc_capabilities_reg, reserved1) \
     mp2_i3c0_hc_capabilities_reg = (mp2_i3c0_hc_capabilities_reg & ~MP2_I3C0_HC_CAPABILITIES_RESERVED1_MASK) | (reserved1 << MP2_I3C0_HC_CAPABILITIES_RESERVED1_SHIFT)
#define MP2_I3C0_HC_CAPABILITIES_SET_NON_CURRENT_MASTER_CAP(mp2_i3c0_hc_capabilities_reg, non_current_master_cap) \
     mp2_i3c0_hc_capabilities_reg = (mp2_i3c0_hc_capabilities_reg & ~MP2_I3C0_HC_CAPABILITIES_NON_CURRENT_MASTER_CAP_MASK) | (non_current_master_cap << MP2_I3C0_HC_CAPABILITIES_NON_CURRENT_MASTER_CAP_SHIFT)
#define MP2_I3C0_HC_CAPABILITIES_SET_HDR_DDR_EN(mp2_i3c0_hc_capabilities_reg, hdr_ddr_en) \
     mp2_i3c0_hc_capabilities_reg = (mp2_i3c0_hc_capabilities_reg & ~MP2_I3C0_HC_CAPABILITIES_HDR_DDR_EN_MASK) | (hdr_ddr_en << MP2_I3C0_HC_CAPABILITIES_HDR_DDR_EN_SHIFT)
#define MP2_I3C0_HC_CAPABILITIES_SET_HDR_TS_EN(mp2_i3c0_hc_capabilities_reg, hdr_ts_en) \
     mp2_i3c0_hc_capabilities_reg = (mp2_i3c0_hc_capabilities_reg & ~MP2_I3C0_HC_CAPABILITIES_HDR_TS_EN_MASK) | (hdr_ts_en << MP2_I3C0_HC_CAPABILITIES_HDR_TS_EN_SHIFT)
#define MP2_I3C0_HC_CAPABILITIES_SET_RESERVED0(mp2_i3c0_hc_capabilities_reg, reserved0) \
     mp2_i3c0_hc_capabilities_reg = (mp2_i3c0_hc_capabilities_reg & ~MP2_I3C0_HC_CAPABILITIES_RESERVED0_MASK) | (reserved0 << MP2_I3C0_HC_CAPABILITIES_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_hc_capabilities_t {
          unsigned int reserved2                      : MP2_I3C0_HC_CAPABILITIES_RESERVED2_SIZE;
          unsigned int combo_command                  : MP2_I3C0_HC_CAPABILITIES_COMBO_COMMAND_SIZE;
          unsigned int auto_command                   : MP2_I3C0_HC_CAPABILITIES_AUTO_COMMAND_SIZE;
          unsigned int reserved1                      : MP2_I3C0_HC_CAPABILITIES_RESERVED1_SIZE;
          unsigned int non_current_master_cap         : MP2_I3C0_HC_CAPABILITIES_NON_CURRENT_MASTER_CAP_SIZE;
          unsigned int hdr_ddr_en                     : MP2_I3C0_HC_CAPABILITIES_HDR_DDR_EN_SIZE;
          unsigned int hdr_ts_en                      : MP2_I3C0_HC_CAPABILITIES_HDR_TS_EN_SIZE;
          unsigned int reserved0                      : MP2_I3C0_HC_CAPABILITIES_RESERVED0_SIZE;
     } mp2_i3c0_hc_capabilities_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_hc_capabilities_t {
          unsigned int reserved0                      : MP2_I3C0_HC_CAPABILITIES_RESERVED0_SIZE;
          unsigned int hdr_ts_en                      : MP2_I3C0_HC_CAPABILITIES_HDR_TS_EN_SIZE;
          unsigned int hdr_ddr_en                     : MP2_I3C0_HC_CAPABILITIES_HDR_DDR_EN_SIZE;
          unsigned int non_current_master_cap         : MP2_I3C0_HC_CAPABILITIES_NON_CURRENT_MASTER_CAP_SIZE;
          unsigned int reserved1                      : MP2_I3C0_HC_CAPABILITIES_RESERVED1_SIZE;
          unsigned int auto_command                   : MP2_I3C0_HC_CAPABILITIES_AUTO_COMMAND_SIZE;
          unsigned int combo_command                  : MP2_I3C0_HC_CAPABILITIES_COMBO_COMMAND_SIZE;
          unsigned int reserved2                      : MP2_I3C0_HC_CAPABILITIES_RESERVED2_SIZE;
     } mp2_i3c0_hc_capabilities_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_hc_capabilities_t f;
} mp2_i3c0_hc_capabilities_u;


/*
 * MP2_I3C0_RESET_CONTROL struct
 */

#define MP2_I3C0_RESET_CONTROL_REG_SIZE 32
#define MP2_I3C0_RESET_CONTROL_SOFT_RST_SIZE 1
#define MP2_I3C0_RESET_CONTROL_CMD_QUEUE_RST_SIZE 1
#define MP2_I3C0_RESET_CONTROL_RESP_QUEUE_RST_SIZE 1
#define MP2_I3C0_RESET_CONTROL_TX_FIFO_RST_SIZE 1
#define MP2_I3C0_RESET_CONTROL_RX_FIFO_RST_SIZE 1
#define MP2_I3C0_RESET_CONTROL_IBI_QUEUE_RST_SIZE 1
#define MP2_I3C0_RESET_CONTROL_RESERVED0_SIZE 26

#define MP2_I3C0_RESET_CONTROL_SOFT_RST_SHIFT 0
#define MP2_I3C0_RESET_CONTROL_CMD_QUEUE_RST_SHIFT 1
#define MP2_I3C0_RESET_CONTROL_RESP_QUEUE_RST_SHIFT 2
#define MP2_I3C0_RESET_CONTROL_TX_FIFO_RST_SHIFT 3
#define MP2_I3C0_RESET_CONTROL_RX_FIFO_RST_SHIFT 4
#define MP2_I3C0_RESET_CONTROL_IBI_QUEUE_RST_SHIFT 5
#define MP2_I3C0_RESET_CONTROL_RESERVED0_SHIFT 6

#define MP2_I3C0_RESET_CONTROL_SOFT_RST_MASK 0x1
#define MP2_I3C0_RESET_CONTROL_CMD_QUEUE_RST_MASK 0x2
#define MP2_I3C0_RESET_CONTROL_RESP_QUEUE_RST_MASK 0x4
#define MP2_I3C0_RESET_CONTROL_TX_FIFO_RST_MASK 0x8
#define MP2_I3C0_RESET_CONTROL_RX_FIFO_RST_MASK 0x10
#define MP2_I3C0_RESET_CONTROL_IBI_QUEUE_RST_MASK 0x20
#define MP2_I3C0_RESET_CONTROL_RESERVED0_MASK 0xffffffc0

#define MP2_I3C0_RESET_CONTROL_MASK \
     (MP2_I3C0_RESET_CONTROL_SOFT_RST_MASK | \
      MP2_I3C0_RESET_CONTROL_CMD_QUEUE_RST_MASK | \
      MP2_I3C0_RESET_CONTROL_RESP_QUEUE_RST_MASK | \
      MP2_I3C0_RESET_CONTROL_TX_FIFO_RST_MASK | \
      MP2_I3C0_RESET_CONTROL_RX_FIFO_RST_MASK | \
      MP2_I3C0_RESET_CONTROL_IBI_QUEUE_RST_MASK | \
      MP2_I3C0_RESET_CONTROL_RESERVED0_MASK)

#define MP2_I3C0_RESET_CONTROL_DEFAULT 0x00000000

#define MP2_I3C0_RESET_CONTROL_GET_SOFT_RST(mp2_i3c0_reset_control) \
     ((mp2_i3c0_reset_control & MP2_I3C0_RESET_CONTROL_SOFT_RST_MASK) >> MP2_I3C0_RESET_CONTROL_SOFT_RST_SHIFT)
#define MP2_I3C0_RESET_CONTROL_GET_CMD_QUEUE_RST(mp2_i3c0_reset_control) \
     ((mp2_i3c0_reset_control & MP2_I3C0_RESET_CONTROL_CMD_QUEUE_RST_MASK) >> MP2_I3C0_RESET_CONTROL_CMD_QUEUE_RST_SHIFT)
#define MP2_I3C0_RESET_CONTROL_GET_RESP_QUEUE_RST(mp2_i3c0_reset_control) \
     ((mp2_i3c0_reset_control & MP2_I3C0_RESET_CONTROL_RESP_QUEUE_RST_MASK) >> MP2_I3C0_RESET_CONTROL_RESP_QUEUE_RST_SHIFT)
#define MP2_I3C0_RESET_CONTROL_GET_TX_FIFO_RST(mp2_i3c0_reset_control) \
     ((mp2_i3c0_reset_control & MP2_I3C0_RESET_CONTROL_TX_FIFO_RST_MASK) >> MP2_I3C0_RESET_CONTROL_TX_FIFO_RST_SHIFT)
#define MP2_I3C0_RESET_CONTROL_GET_RX_FIFO_RST(mp2_i3c0_reset_control) \
     ((mp2_i3c0_reset_control & MP2_I3C0_RESET_CONTROL_RX_FIFO_RST_MASK) >> MP2_I3C0_RESET_CONTROL_RX_FIFO_RST_SHIFT)
#define MP2_I3C0_RESET_CONTROL_GET_IBI_QUEUE_RST(mp2_i3c0_reset_control) \
     ((mp2_i3c0_reset_control & MP2_I3C0_RESET_CONTROL_IBI_QUEUE_RST_MASK) >> MP2_I3C0_RESET_CONTROL_IBI_QUEUE_RST_SHIFT)
#define MP2_I3C0_RESET_CONTROL_GET_RESERVED0(mp2_i3c0_reset_control) \
     ((mp2_i3c0_reset_control & MP2_I3C0_RESET_CONTROL_RESERVED0_MASK) >> MP2_I3C0_RESET_CONTROL_RESERVED0_SHIFT)

#define MP2_I3C0_RESET_CONTROL_SET_SOFT_RST(mp2_i3c0_reset_control_reg, soft_rst) \
     mp2_i3c0_reset_control_reg = (mp2_i3c0_reset_control_reg & ~MP2_I3C0_RESET_CONTROL_SOFT_RST_MASK) | (soft_rst << MP2_I3C0_RESET_CONTROL_SOFT_RST_SHIFT)
#define MP2_I3C0_RESET_CONTROL_SET_CMD_QUEUE_RST(mp2_i3c0_reset_control_reg, cmd_queue_rst) \
     mp2_i3c0_reset_control_reg = (mp2_i3c0_reset_control_reg & ~MP2_I3C0_RESET_CONTROL_CMD_QUEUE_RST_MASK) | (cmd_queue_rst << MP2_I3C0_RESET_CONTROL_CMD_QUEUE_RST_SHIFT)
#define MP2_I3C0_RESET_CONTROL_SET_RESP_QUEUE_RST(mp2_i3c0_reset_control_reg, resp_queue_rst) \
     mp2_i3c0_reset_control_reg = (mp2_i3c0_reset_control_reg & ~MP2_I3C0_RESET_CONTROL_RESP_QUEUE_RST_MASK) | (resp_queue_rst << MP2_I3C0_RESET_CONTROL_RESP_QUEUE_RST_SHIFT)
#define MP2_I3C0_RESET_CONTROL_SET_TX_FIFO_RST(mp2_i3c0_reset_control_reg, tx_fifo_rst) \
     mp2_i3c0_reset_control_reg = (mp2_i3c0_reset_control_reg & ~MP2_I3C0_RESET_CONTROL_TX_FIFO_RST_MASK) | (tx_fifo_rst << MP2_I3C0_RESET_CONTROL_TX_FIFO_RST_SHIFT)
#define MP2_I3C0_RESET_CONTROL_SET_RX_FIFO_RST(mp2_i3c0_reset_control_reg, rx_fifo_rst) \
     mp2_i3c0_reset_control_reg = (mp2_i3c0_reset_control_reg & ~MP2_I3C0_RESET_CONTROL_RX_FIFO_RST_MASK) | (rx_fifo_rst << MP2_I3C0_RESET_CONTROL_RX_FIFO_RST_SHIFT)
#define MP2_I3C0_RESET_CONTROL_SET_IBI_QUEUE_RST(mp2_i3c0_reset_control_reg, ibi_queue_rst) \
     mp2_i3c0_reset_control_reg = (mp2_i3c0_reset_control_reg & ~MP2_I3C0_RESET_CONTROL_IBI_QUEUE_RST_MASK) | (ibi_queue_rst << MP2_I3C0_RESET_CONTROL_IBI_QUEUE_RST_SHIFT)
#define MP2_I3C0_RESET_CONTROL_SET_RESERVED0(mp2_i3c0_reset_control_reg, reserved0) \
     mp2_i3c0_reset_control_reg = (mp2_i3c0_reset_control_reg & ~MP2_I3C0_RESET_CONTROL_RESERVED0_MASK) | (reserved0 << MP2_I3C0_RESET_CONTROL_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_reset_control_t {
          unsigned int soft_rst                       : MP2_I3C0_RESET_CONTROL_SOFT_RST_SIZE;
          unsigned int cmd_queue_rst                  : MP2_I3C0_RESET_CONTROL_CMD_QUEUE_RST_SIZE;
          unsigned int resp_queue_rst                 : MP2_I3C0_RESET_CONTROL_RESP_QUEUE_RST_SIZE;
          unsigned int tx_fifo_rst                    : MP2_I3C0_RESET_CONTROL_TX_FIFO_RST_SIZE;
          unsigned int rx_fifo_rst                    : MP2_I3C0_RESET_CONTROL_RX_FIFO_RST_SIZE;
          unsigned int ibi_queue_rst                  : MP2_I3C0_RESET_CONTROL_IBI_QUEUE_RST_SIZE;
          unsigned int reserved0                      : MP2_I3C0_RESET_CONTROL_RESERVED0_SIZE;
     } mp2_i3c0_reset_control_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_reset_control_t {
          unsigned int reserved0                      : MP2_I3C0_RESET_CONTROL_RESERVED0_SIZE;
          unsigned int ibi_queue_rst                  : MP2_I3C0_RESET_CONTROL_IBI_QUEUE_RST_SIZE;
          unsigned int rx_fifo_rst                    : MP2_I3C0_RESET_CONTROL_RX_FIFO_RST_SIZE;
          unsigned int tx_fifo_rst                    : MP2_I3C0_RESET_CONTROL_TX_FIFO_RST_SIZE;
          unsigned int resp_queue_rst                 : MP2_I3C0_RESET_CONTROL_RESP_QUEUE_RST_SIZE;
          unsigned int cmd_queue_rst                  : MP2_I3C0_RESET_CONTROL_CMD_QUEUE_RST_SIZE;
          unsigned int soft_rst                       : MP2_I3C0_RESET_CONTROL_SOFT_RST_SIZE;
     } mp2_i3c0_reset_control_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_reset_control_t f;
} mp2_i3c0_reset_control_u;


/*
 * MP2_I3C0_PRESENT_STATE struct
 */

#define MP2_I3C0_PRESENT_STATE_REG_SIZE 32
#define MP2_I3C0_PRESENT_STATE_RESERVED1_SIZE 2
#define MP2_I3C0_PRESENT_STATE_CURRENT_MASTER_SIZE 1
#define MP2_I3C0_PRESENT_STATE_RESERVED0_SIZE 29

#define MP2_I3C0_PRESENT_STATE_RESERVED1_SHIFT 0
#define MP2_I3C0_PRESENT_STATE_CURRENT_MASTER_SHIFT 2
#define MP2_I3C0_PRESENT_STATE_RESERVED0_SHIFT 3

#define MP2_I3C0_PRESENT_STATE_RESERVED1_MASK 0x3
#define MP2_I3C0_PRESENT_STATE_CURRENT_MASTER_MASK 0x4
#define MP2_I3C0_PRESENT_STATE_RESERVED0_MASK 0xfffffff8

#define MP2_I3C0_PRESENT_STATE_MASK \
     (MP2_I3C0_PRESENT_STATE_RESERVED1_MASK | \
      MP2_I3C0_PRESENT_STATE_CURRENT_MASTER_MASK | \
      MP2_I3C0_PRESENT_STATE_RESERVED0_MASK)

#define MP2_I3C0_PRESENT_STATE_DEFAULT 0x00000000

#define MP2_I3C0_PRESENT_STATE_GET_RESERVED1(mp2_i3c0_present_state) \
     ((mp2_i3c0_present_state & MP2_I3C0_PRESENT_STATE_RESERVED1_MASK) >> MP2_I3C0_PRESENT_STATE_RESERVED1_SHIFT)
#define MP2_I3C0_PRESENT_STATE_GET_CURRENT_MASTER(mp2_i3c0_present_state) \
     ((mp2_i3c0_present_state & MP2_I3C0_PRESENT_STATE_CURRENT_MASTER_MASK) >> MP2_I3C0_PRESENT_STATE_CURRENT_MASTER_SHIFT)
#define MP2_I3C0_PRESENT_STATE_GET_RESERVED0(mp2_i3c0_present_state) \
     ((mp2_i3c0_present_state & MP2_I3C0_PRESENT_STATE_RESERVED0_MASK) >> MP2_I3C0_PRESENT_STATE_RESERVED0_SHIFT)

#define MP2_I3C0_PRESENT_STATE_SET_RESERVED1(mp2_i3c0_present_state_reg, reserved1) \
     mp2_i3c0_present_state_reg = (mp2_i3c0_present_state_reg & ~MP2_I3C0_PRESENT_STATE_RESERVED1_MASK) | (reserved1 << MP2_I3C0_PRESENT_STATE_RESERVED1_SHIFT)
#define MP2_I3C0_PRESENT_STATE_SET_CURRENT_MASTER(mp2_i3c0_present_state_reg, current_master) \
     mp2_i3c0_present_state_reg = (mp2_i3c0_present_state_reg & ~MP2_I3C0_PRESENT_STATE_CURRENT_MASTER_MASK) | (current_master << MP2_I3C0_PRESENT_STATE_CURRENT_MASTER_SHIFT)
#define MP2_I3C0_PRESENT_STATE_SET_RESERVED0(mp2_i3c0_present_state_reg, reserved0) \
     mp2_i3c0_present_state_reg = (mp2_i3c0_present_state_reg & ~MP2_I3C0_PRESENT_STATE_RESERVED0_MASK) | (reserved0 << MP2_I3C0_PRESENT_STATE_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_present_state_t {
          unsigned int reserved1                      : MP2_I3C0_PRESENT_STATE_RESERVED1_SIZE;
          unsigned int current_master                 : MP2_I3C0_PRESENT_STATE_CURRENT_MASTER_SIZE;
          unsigned int reserved0                      : MP2_I3C0_PRESENT_STATE_RESERVED0_SIZE;
     } mp2_i3c0_present_state_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_present_state_t {
          unsigned int reserved0                      : MP2_I3C0_PRESENT_STATE_RESERVED0_SIZE;
          unsigned int current_master                 : MP2_I3C0_PRESENT_STATE_CURRENT_MASTER_SIZE;
          unsigned int reserved1                      : MP2_I3C0_PRESENT_STATE_RESERVED1_SIZE;
     } mp2_i3c0_present_state_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_present_state_t f;
} mp2_i3c0_present_state_u;


/*
 * MP2_I3C0_INTR_STATUS struct
 */

#define MP2_I3C0_INTR_STATUS_REG_SIZE  32
#define MP2_I3C0_INTR_STATUS_RESERVED1_SIZE 10
#define MP2_I3C0_INTR_STATUS_HC_INTERNAL_ERR_STAT_SIZE 1
#define MP2_I3C0_INTR_STATUS_RESERVED0_SIZE 21

#define MP2_I3C0_INTR_STATUS_RESERVED1_SHIFT 0
#define MP2_I3C0_INTR_STATUS_HC_INTERNAL_ERR_STAT_SHIFT 10
#define MP2_I3C0_INTR_STATUS_RESERVED0_SHIFT 11

#define MP2_I3C0_INTR_STATUS_RESERVED1_MASK 0x3ff
#define MP2_I3C0_INTR_STATUS_HC_INTERNAL_ERR_STAT_MASK 0x400
#define MP2_I3C0_INTR_STATUS_RESERVED0_MASK 0xfffff800

#define MP2_I3C0_INTR_STATUS_MASK \
     (MP2_I3C0_INTR_STATUS_RESERVED1_MASK | \
      MP2_I3C0_INTR_STATUS_HC_INTERNAL_ERR_STAT_MASK | \
      MP2_I3C0_INTR_STATUS_RESERVED0_MASK)

#define MP2_I3C0_INTR_STATUS_DEFAULT   0x00000000

#define MP2_I3C0_INTR_STATUS_GET_RESERVED1(mp2_i3c0_intr_status) \
     ((mp2_i3c0_intr_status & MP2_I3C0_INTR_STATUS_RESERVED1_MASK) >> MP2_I3C0_INTR_STATUS_RESERVED1_SHIFT)
#define MP2_I3C0_INTR_STATUS_GET_HC_INTERNAL_ERR_STAT(mp2_i3c0_intr_status) \
     ((mp2_i3c0_intr_status & MP2_I3C0_INTR_STATUS_HC_INTERNAL_ERR_STAT_MASK) >> MP2_I3C0_INTR_STATUS_HC_INTERNAL_ERR_STAT_SHIFT)
#define MP2_I3C0_INTR_STATUS_GET_RESERVED0(mp2_i3c0_intr_status) \
     ((mp2_i3c0_intr_status & MP2_I3C0_INTR_STATUS_RESERVED0_MASK) >> MP2_I3C0_INTR_STATUS_RESERVED0_SHIFT)

#define MP2_I3C0_INTR_STATUS_SET_RESERVED1(mp2_i3c0_intr_status_reg, reserved1) \
     mp2_i3c0_intr_status_reg = (mp2_i3c0_intr_status_reg & ~MP2_I3C0_INTR_STATUS_RESERVED1_MASK) | (reserved1 << MP2_I3C0_INTR_STATUS_RESERVED1_SHIFT)
#define MP2_I3C0_INTR_STATUS_SET_HC_INTERNAL_ERR_STAT(mp2_i3c0_intr_status_reg, hc_internal_err_stat) \
     mp2_i3c0_intr_status_reg = (mp2_i3c0_intr_status_reg & ~MP2_I3C0_INTR_STATUS_HC_INTERNAL_ERR_STAT_MASK) | (hc_internal_err_stat << MP2_I3C0_INTR_STATUS_HC_INTERNAL_ERR_STAT_SHIFT)
#define MP2_I3C0_INTR_STATUS_SET_RESERVED0(mp2_i3c0_intr_status_reg, reserved0) \
     mp2_i3c0_intr_status_reg = (mp2_i3c0_intr_status_reg & ~MP2_I3C0_INTR_STATUS_RESERVED0_MASK) | (reserved0 << MP2_I3C0_INTR_STATUS_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_intr_status_t {
          unsigned int reserved1                      : MP2_I3C0_INTR_STATUS_RESERVED1_SIZE;
          unsigned int hc_internal_err_stat           : MP2_I3C0_INTR_STATUS_HC_INTERNAL_ERR_STAT_SIZE;
          unsigned int reserved0                      : MP2_I3C0_INTR_STATUS_RESERVED0_SIZE;
     } mp2_i3c0_intr_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_intr_status_t {
          unsigned int reserved0                      : MP2_I3C0_INTR_STATUS_RESERVED0_SIZE;
          unsigned int hc_internal_err_stat           : MP2_I3C0_INTR_STATUS_HC_INTERNAL_ERR_STAT_SIZE;
          unsigned int reserved1                      : MP2_I3C0_INTR_STATUS_RESERVED1_SIZE;
     } mp2_i3c0_intr_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_intr_status_t f;
} mp2_i3c0_intr_status_u;


/*
 * MP2_I3C0_INTR_STATUS_ENABLE struct
 */

#define MP2_I3C0_INTR_STATUS_ENABLE_REG_SIZE 32
#define MP2_I3C0_INTR_STATUS_ENABLE_RESERVED1_SIZE 10
#define MP2_I3C0_INTR_STATUS_ENABLE_HC_INTERNAL_ERR_STAT_EN_SIZE 1
#define MP2_I3C0_INTR_STATUS_ENABLE_RESERVED0_SIZE 21

#define MP2_I3C0_INTR_STATUS_ENABLE_RESERVED1_SHIFT 0
#define MP2_I3C0_INTR_STATUS_ENABLE_HC_INTERNAL_ERR_STAT_EN_SHIFT 10
#define MP2_I3C0_INTR_STATUS_ENABLE_RESERVED0_SHIFT 11

#define MP2_I3C0_INTR_STATUS_ENABLE_RESERVED1_MASK 0x3ff
#define MP2_I3C0_INTR_STATUS_ENABLE_HC_INTERNAL_ERR_STAT_EN_MASK 0x400
#define MP2_I3C0_INTR_STATUS_ENABLE_RESERVED0_MASK 0xfffff800

#define MP2_I3C0_INTR_STATUS_ENABLE_MASK \
     (MP2_I3C0_INTR_STATUS_ENABLE_RESERVED1_MASK | \
      MP2_I3C0_INTR_STATUS_ENABLE_HC_INTERNAL_ERR_STAT_EN_MASK | \
      MP2_I3C0_INTR_STATUS_ENABLE_RESERVED0_MASK)

#define MP2_I3C0_INTR_STATUS_ENABLE_DEFAULT 0x00000000

#define MP2_I3C0_INTR_STATUS_ENABLE_GET_RESERVED1(mp2_i3c0_intr_status_enable) \
     ((mp2_i3c0_intr_status_enable & MP2_I3C0_INTR_STATUS_ENABLE_RESERVED1_MASK) >> MP2_I3C0_INTR_STATUS_ENABLE_RESERVED1_SHIFT)
#define MP2_I3C0_INTR_STATUS_ENABLE_GET_HC_INTERNAL_ERR_STAT_EN(mp2_i3c0_intr_status_enable) \
     ((mp2_i3c0_intr_status_enable & MP2_I3C0_INTR_STATUS_ENABLE_HC_INTERNAL_ERR_STAT_EN_MASK) >> MP2_I3C0_INTR_STATUS_ENABLE_HC_INTERNAL_ERR_STAT_EN_SHIFT)
#define MP2_I3C0_INTR_STATUS_ENABLE_GET_RESERVED0(mp2_i3c0_intr_status_enable) \
     ((mp2_i3c0_intr_status_enable & MP2_I3C0_INTR_STATUS_ENABLE_RESERVED0_MASK) >> MP2_I3C0_INTR_STATUS_ENABLE_RESERVED0_SHIFT)

#define MP2_I3C0_INTR_STATUS_ENABLE_SET_RESERVED1(mp2_i3c0_intr_status_enable_reg, reserved1) \
     mp2_i3c0_intr_status_enable_reg = (mp2_i3c0_intr_status_enable_reg & ~MP2_I3C0_INTR_STATUS_ENABLE_RESERVED1_MASK) | (reserved1 << MP2_I3C0_INTR_STATUS_ENABLE_RESERVED1_SHIFT)
#define MP2_I3C0_INTR_STATUS_ENABLE_SET_HC_INTERNAL_ERR_STAT_EN(mp2_i3c0_intr_status_enable_reg, hc_internal_err_stat_en) \
     mp2_i3c0_intr_status_enable_reg = (mp2_i3c0_intr_status_enable_reg & ~MP2_I3C0_INTR_STATUS_ENABLE_HC_INTERNAL_ERR_STAT_EN_MASK) | (hc_internal_err_stat_en << MP2_I3C0_INTR_STATUS_ENABLE_HC_INTERNAL_ERR_STAT_EN_SHIFT)
#define MP2_I3C0_INTR_STATUS_ENABLE_SET_RESERVED0(mp2_i3c0_intr_status_enable_reg, reserved0) \
     mp2_i3c0_intr_status_enable_reg = (mp2_i3c0_intr_status_enable_reg & ~MP2_I3C0_INTR_STATUS_ENABLE_RESERVED0_MASK) | (reserved0 << MP2_I3C0_INTR_STATUS_ENABLE_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_intr_status_enable_t {
          unsigned int reserved1                      : MP2_I3C0_INTR_STATUS_ENABLE_RESERVED1_SIZE;
          unsigned int hc_internal_err_stat_en        : MP2_I3C0_INTR_STATUS_ENABLE_HC_INTERNAL_ERR_STAT_EN_SIZE;
          unsigned int reserved0                      : MP2_I3C0_INTR_STATUS_ENABLE_RESERVED0_SIZE;
     } mp2_i3c0_intr_status_enable_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_intr_status_enable_t {
          unsigned int reserved0                      : MP2_I3C0_INTR_STATUS_ENABLE_RESERVED0_SIZE;
          unsigned int hc_internal_err_stat_en        : MP2_I3C0_INTR_STATUS_ENABLE_HC_INTERNAL_ERR_STAT_EN_SIZE;
          unsigned int reserved1                      : MP2_I3C0_INTR_STATUS_ENABLE_RESERVED1_SIZE;
     } mp2_i3c0_intr_status_enable_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_intr_status_enable_t f;
} mp2_i3c0_intr_status_enable_u;


/*
 * MP2_I3C0_INTR_SIGNAL_ENABLE struct
 */

#define MP2_I3C0_INTR_SIGNAL_ENABLE_REG_SIZE 32
#define MP2_I3C0_INTR_SIGNAL_ENABLE_RESERVED1_SIZE 10
#define MP2_I3C0_INTR_SIGNAL_ENABLE_HC_INTERNAL_ERR_SIGNAL_EN_SIZE 1
#define MP2_I3C0_INTR_SIGNAL_ENABLE_RESERVED0_SIZE 21

#define MP2_I3C0_INTR_SIGNAL_ENABLE_RESERVED1_SHIFT 0
#define MP2_I3C0_INTR_SIGNAL_ENABLE_HC_INTERNAL_ERR_SIGNAL_EN_SHIFT 10
#define MP2_I3C0_INTR_SIGNAL_ENABLE_RESERVED0_SHIFT 11

#define MP2_I3C0_INTR_SIGNAL_ENABLE_RESERVED1_MASK 0x3ff
#define MP2_I3C0_INTR_SIGNAL_ENABLE_HC_INTERNAL_ERR_SIGNAL_EN_MASK 0x400
#define MP2_I3C0_INTR_SIGNAL_ENABLE_RESERVED0_MASK 0xfffff800

#define MP2_I3C0_INTR_SIGNAL_ENABLE_MASK \
     (MP2_I3C0_INTR_SIGNAL_ENABLE_RESERVED1_MASK | \
      MP2_I3C0_INTR_SIGNAL_ENABLE_HC_INTERNAL_ERR_SIGNAL_EN_MASK | \
      MP2_I3C0_INTR_SIGNAL_ENABLE_RESERVED0_MASK)

#define MP2_I3C0_INTR_SIGNAL_ENABLE_DEFAULT 0x00000000

#define MP2_I3C0_INTR_SIGNAL_ENABLE_GET_RESERVED1(mp2_i3c0_intr_signal_enable) \
     ((mp2_i3c0_intr_signal_enable & MP2_I3C0_INTR_SIGNAL_ENABLE_RESERVED1_MASK) >> MP2_I3C0_INTR_SIGNAL_ENABLE_RESERVED1_SHIFT)
#define MP2_I3C0_INTR_SIGNAL_ENABLE_GET_HC_INTERNAL_ERR_SIGNAL_EN(mp2_i3c0_intr_signal_enable) \
     ((mp2_i3c0_intr_signal_enable & MP2_I3C0_INTR_SIGNAL_ENABLE_HC_INTERNAL_ERR_SIGNAL_EN_MASK) >> MP2_I3C0_INTR_SIGNAL_ENABLE_HC_INTERNAL_ERR_SIGNAL_EN_SHIFT)
#define MP2_I3C0_INTR_SIGNAL_ENABLE_GET_RESERVED0(mp2_i3c0_intr_signal_enable) \
     ((mp2_i3c0_intr_signal_enable & MP2_I3C0_INTR_SIGNAL_ENABLE_RESERVED0_MASK) >> MP2_I3C0_INTR_SIGNAL_ENABLE_RESERVED0_SHIFT)

#define MP2_I3C0_INTR_SIGNAL_ENABLE_SET_RESERVED1(mp2_i3c0_intr_signal_enable_reg, reserved1) \
     mp2_i3c0_intr_signal_enable_reg = (mp2_i3c0_intr_signal_enable_reg & ~MP2_I3C0_INTR_SIGNAL_ENABLE_RESERVED1_MASK) | (reserved1 << MP2_I3C0_INTR_SIGNAL_ENABLE_RESERVED1_SHIFT)
#define MP2_I3C0_INTR_SIGNAL_ENABLE_SET_HC_INTERNAL_ERR_SIGNAL_EN(mp2_i3c0_intr_signal_enable_reg, hc_internal_err_signal_en) \
     mp2_i3c0_intr_signal_enable_reg = (mp2_i3c0_intr_signal_enable_reg & ~MP2_I3C0_INTR_SIGNAL_ENABLE_HC_INTERNAL_ERR_SIGNAL_EN_MASK) | (hc_internal_err_signal_en << MP2_I3C0_INTR_SIGNAL_ENABLE_HC_INTERNAL_ERR_SIGNAL_EN_SHIFT)
#define MP2_I3C0_INTR_SIGNAL_ENABLE_SET_RESERVED0(mp2_i3c0_intr_signal_enable_reg, reserved0) \
     mp2_i3c0_intr_signal_enable_reg = (mp2_i3c0_intr_signal_enable_reg & ~MP2_I3C0_INTR_SIGNAL_ENABLE_RESERVED0_MASK) | (reserved0 << MP2_I3C0_INTR_SIGNAL_ENABLE_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_intr_signal_enable_t {
          unsigned int reserved1                      : MP2_I3C0_INTR_SIGNAL_ENABLE_RESERVED1_SIZE;
          unsigned int hc_internal_err_signal_en      : MP2_I3C0_INTR_SIGNAL_ENABLE_HC_INTERNAL_ERR_SIGNAL_EN_SIZE;
          unsigned int reserved0                      : MP2_I3C0_INTR_SIGNAL_ENABLE_RESERVED0_SIZE;
     } mp2_i3c0_intr_signal_enable_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_intr_signal_enable_t {
          unsigned int reserved0                      : MP2_I3C0_INTR_SIGNAL_ENABLE_RESERVED0_SIZE;
          unsigned int hc_internal_err_signal_en      : MP2_I3C0_INTR_SIGNAL_ENABLE_HC_INTERNAL_ERR_SIGNAL_EN_SIZE;
          unsigned int reserved1                      : MP2_I3C0_INTR_SIGNAL_ENABLE_RESERVED1_SIZE;
     } mp2_i3c0_intr_signal_enable_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_intr_signal_enable_t f;
} mp2_i3c0_intr_signal_enable_u;


/*
 * MP2_I3C0_INTR_FORCE struct
 */

#define MP2_I3C0_INTR_FORCE_REG_SIZE   32
#define MP2_I3C0_INTR_FORCE_RESERVED1_SIZE 10
#define MP2_I3C0_INTR_FORCE_HC_INTERNAL_ERR_FORCE_SIZE 1
#define MP2_I3C0_INTR_FORCE_RESERVED0_SIZE 21

#define MP2_I3C0_INTR_FORCE_RESERVED1_SHIFT 0
#define MP2_I3C0_INTR_FORCE_HC_INTERNAL_ERR_FORCE_SHIFT 10
#define MP2_I3C0_INTR_FORCE_RESERVED0_SHIFT 11

#define MP2_I3C0_INTR_FORCE_RESERVED1_MASK 0x3ff
#define MP2_I3C0_INTR_FORCE_HC_INTERNAL_ERR_FORCE_MASK 0x400
#define MP2_I3C0_INTR_FORCE_RESERVED0_MASK 0xfffff800

#define MP2_I3C0_INTR_FORCE_MASK \
     (MP2_I3C0_INTR_FORCE_RESERVED1_MASK | \
      MP2_I3C0_INTR_FORCE_HC_INTERNAL_ERR_FORCE_MASK | \
      MP2_I3C0_INTR_FORCE_RESERVED0_MASK)

#define MP2_I3C0_INTR_FORCE_DEFAULT    0x00000000

#define MP2_I3C0_INTR_FORCE_GET_RESERVED1(mp2_i3c0_intr_force) \
     ((mp2_i3c0_intr_force & MP2_I3C0_INTR_FORCE_RESERVED1_MASK) >> MP2_I3C0_INTR_FORCE_RESERVED1_SHIFT)
#define MP2_I3C0_INTR_FORCE_GET_HC_INTERNAL_ERR_FORCE(mp2_i3c0_intr_force) \
     ((mp2_i3c0_intr_force & MP2_I3C0_INTR_FORCE_HC_INTERNAL_ERR_FORCE_MASK) >> MP2_I3C0_INTR_FORCE_HC_INTERNAL_ERR_FORCE_SHIFT)
#define MP2_I3C0_INTR_FORCE_GET_RESERVED0(mp2_i3c0_intr_force) \
     ((mp2_i3c0_intr_force & MP2_I3C0_INTR_FORCE_RESERVED0_MASK) >> MP2_I3C0_INTR_FORCE_RESERVED0_SHIFT)

#define MP2_I3C0_INTR_FORCE_SET_RESERVED1(mp2_i3c0_intr_force_reg, reserved1) \
     mp2_i3c0_intr_force_reg = (mp2_i3c0_intr_force_reg & ~MP2_I3C0_INTR_FORCE_RESERVED1_MASK) | (reserved1 << MP2_I3C0_INTR_FORCE_RESERVED1_SHIFT)
#define MP2_I3C0_INTR_FORCE_SET_HC_INTERNAL_ERR_FORCE(mp2_i3c0_intr_force_reg, hc_internal_err_force) \
     mp2_i3c0_intr_force_reg = (mp2_i3c0_intr_force_reg & ~MP2_I3C0_INTR_FORCE_HC_INTERNAL_ERR_FORCE_MASK) | (hc_internal_err_force << MP2_I3C0_INTR_FORCE_HC_INTERNAL_ERR_FORCE_SHIFT)
#define MP2_I3C0_INTR_FORCE_SET_RESERVED0(mp2_i3c0_intr_force_reg, reserved0) \
     mp2_i3c0_intr_force_reg = (mp2_i3c0_intr_force_reg & ~MP2_I3C0_INTR_FORCE_RESERVED0_MASK) | (reserved0 << MP2_I3C0_INTR_FORCE_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_intr_force_t {
          unsigned int reserved1                      : MP2_I3C0_INTR_FORCE_RESERVED1_SIZE;
          unsigned int hc_internal_err_force          : MP2_I3C0_INTR_FORCE_HC_INTERNAL_ERR_FORCE_SIZE;
          unsigned int reserved0                      : MP2_I3C0_INTR_FORCE_RESERVED0_SIZE;
     } mp2_i3c0_intr_force_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_intr_force_t {
          unsigned int reserved0                      : MP2_I3C0_INTR_FORCE_RESERVED0_SIZE;
          unsigned int hc_internal_err_force          : MP2_I3C0_INTR_FORCE_HC_INTERNAL_ERR_FORCE_SIZE;
          unsigned int reserved1                      : MP2_I3C0_INTR_FORCE_RESERVED1_SIZE;
     } mp2_i3c0_intr_force_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_intr_force_t f;
} mp2_i3c0_intr_force_u;


/*
 * MP2_I3C0_DAT_SECTION_OFFSET struct
 */

#define MP2_I3C0_DAT_SECTION_OFFSET_REG_SIZE 32
#define MP2_I3C0_DAT_SECTION_OFFSET_TABLE_OFFSET_SIZE 12
#define MP2_I3C0_DAT_SECTION_OFFSET_TABLE_SIZE_SIZE 6
#define MP2_I3C0_DAT_SECTION_OFFSET_RESERVED0_SIZE 14

#define MP2_I3C0_DAT_SECTION_OFFSET_TABLE_OFFSET_SHIFT 0
#define MP2_I3C0_DAT_SECTION_OFFSET_TABLE_SIZE_SHIFT 12
#define MP2_I3C0_DAT_SECTION_OFFSET_RESERVED0_SHIFT 18

#define MP2_I3C0_DAT_SECTION_OFFSET_TABLE_OFFSET_MASK 0xfff
#define MP2_I3C0_DAT_SECTION_OFFSET_TABLE_SIZE_MASK 0x3f000
#define MP2_I3C0_DAT_SECTION_OFFSET_RESERVED0_MASK 0xfffc0000

#define MP2_I3C0_DAT_SECTION_OFFSET_MASK \
     (MP2_I3C0_DAT_SECTION_OFFSET_TABLE_OFFSET_MASK | \
      MP2_I3C0_DAT_SECTION_OFFSET_TABLE_SIZE_MASK | \
      MP2_I3C0_DAT_SECTION_OFFSET_RESERVED0_MASK)

#define MP2_I3C0_DAT_SECTION_OFFSET_DEFAULT 0x00016400

#define MP2_I3C0_DAT_SECTION_OFFSET_GET_TABLE_OFFSET(mp2_i3c0_dat_section_offset) \
     ((mp2_i3c0_dat_section_offset & MP2_I3C0_DAT_SECTION_OFFSET_TABLE_OFFSET_MASK) >> MP2_I3C0_DAT_SECTION_OFFSET_TABLE_OFFSET_SHIFT)
#define MP2_I3C0_DAT_SECTION_OFFSET_GET_TABLE_SIZE(mp2_i3c0_dat_section_offset) \
     ((mp2_i3c0_dat_section_offset & MP2_I3C0_DAT_SECTION_OFFSET_TABLE_SIZE_MASK) >> MP2_I3C0_DAT_SECTION_OFFSET_TABLE_SIZE_SHIFT)
#define MP2_I3C0_DAT_SECTION_OFFSET_GET_RESERVED0(mp2_i3c0_dat_section_offset) \
     ((mp2_i3c0_dat_section_offset & MP2_I3C0_DAT_SECTION_OFFSET_RESERVED0_MASK) >> MP2_I3C0_DAT_SECTION_OFFSET_RESERVED0_SHIFT)

#define MP2_I3C0_DAT_SECTION_OFFSET_SET_TABLE_OFFSET(mp2_i3c0_dat_section_offset_reg, table_offset) \
     mp2_i3c0_dat_section_offset_reg = (mp2_i3c0_dat_section_offset_reg & ~MP2_I3C0_DAT_SECTION_OFFSET_TABLE_OFFSET_MASK) | (table_offset << MP2_I3C0_DAT_SECTION_OFFSET_TABLE_OFFSET_SHIFT)
#define MP2_I3C0_DAT_SECTION_OFFSET_SET_TABLE_SIZE(mp2_i3c0_dat_section_offset_reg, table_size) \
     mp2_i3c0_dat_section_offset_reg = (mp2_i3c0_dat_section_offset_reg & ~MP2_I3C0_DAT_SECTION_OFFSET_TABLE_SIZE_MASK) | (table_size << MP2_I3C0_DAT_SECTION_OFFSET_TABLE_SIZE_SHIFT)
#define MP2_I3C0_DAT_SECTION_OFFSET_SET_RESERVED0(mp2_i3c0_dat_section_offset_reg, reserved0) \
     mp2_i3c0_dat_section_offset_reg = (mp2_i3c0_dat_section_offset_reg & ~MP2_I3C0_DAT_SECTION_OFFSET_RESERVED0_MASK) | (reserved0 << MP2_I3C0_DAT_SECTION_OFFSET_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_dat_section_offset_t {
          unsigned int table_offset                   : MP2_I3C0_DAT_SECTION_OFFSET_TABLE_OFFSET_SIZE;
          unsigned int table_size                     : MP2_I3C0_DAT_SECTION_OFFSET_TABLE_SIZE_SIZE;
          unsigned int reserved0                      : MP2_I3C0_DAT_SECTION_OFFSET_RESERVED0_SIZE;
     } mp2_i3c0_dat_section_offset_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_dat_section_offset_t {
          unsigned int reserved0                      : MP2_I3C0_DAT_SECTION_OFFSET_RESERVED0_SIZE;
          unsigned int table_size                     : MP2_I3C0_DAT_SECTION_OFFSET_TABLE_SIZE_SIZE;
          unsigned int table_offset                   : MP2_I3C0_DAT_SECTION_OFFSET_TABLE_OFFSET_SIZE;
     } mp2_i3c0_dat_section_offset_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_dat_section_offset_t f;
} mp2_i3c0_dat_section_offset_u;


/*
 * MP2_I3C0_DCT_SECTION_OFFSET struct
 */

#define MP2_I3C0_DCT_SECTION_OFFSET_REG_SIZE 32
#define MP2_I3C0_DCT_SECTION_OFFSET_TABLE_OFFSET_SIZE 12
#define MP2_I3C0_DCT_SECTION_OFFSET_TABLE_SIZE_SIZE 7
#define MP2_I3C0_DCT_SECTION_OFFSET_TABLE_INDEX_SIZE 4
#define MP2_I3C0_DCT_SECTION_OFFSET_RESERVED0_SIZE 9

#define MP2_I3C0_DCT_SECTION_OFFSET_TABLE_OFFSET_SHIFT 0
#define MP2_I3C0_DCT_SECTION_OFFSET_TABLE_SIZE_SHIFT 12
#define MP2_I3C0_DCT_SECTION_OFFSET_TABLE_INDEX_SHIFT 19
#define MP2_I3C0_DCT_SECTION_OFFSET_RESERVED0_SHIFT 23

#define MP2_I3C0_DCT_SECTION_OFFSET_TABLE_OFFSET_MASK 0xfff
#define MP2_I3C0_DCT_SECTION_OFFSET_TABLE_SIZE_MASK 0x7f000
#define MP2_I3C0_DCT_SECTION_OFFSET_TABLE_INDEX_MASK 0x780000
#define MP2_I3C0_DCT_SECTION_OFFSET_RESERVED0_MASK 0xff800000

#define MP2_I3C0_DCT_SECTION_OFFSET_MASK \
     (MP2_I3C0_DCT_SECTION_OFFSET_TABLE_OFFSET_MASK | \
      MP2_I3C0_DCT_SECTION_OFFSET_TABLE_SIZE_MASK | \
      MP2_I3C0_DCT_SECTION_OFFSET_TABLE_INDEX_MASK | \
      MP2_I3C0_DCT_SECTION_OFFSET_RESERVED0_MASK)

#define MP2_I3C0_DCT_SECTION_OFFSET_DEFAULT 0x0002c600

#define MP2_I3C0_DCT_SECTION_OFFSET_GET_TABLE_OFFSET(mp2_i3c0_dct_section_offset) \
     ((mp2_i3c0_dct_section_offset & MP2_I3C0_DCT_SECTION_OFFSET_TABLE_OFFSET_MASK) >> MP2_I3C0_DCT_SECTION_OFFSET_TABLE_OFFSET_SHIFT)
#define MP2_I3C0_DCT_SECTION_OFFSET_GET_TABLE_SIZE(mp2_i3c0_dct_section_offset) \
     ((mp2_i3c0_dct_section_offset & MP2_I3C0_DCT_SECTION_OFFSET_TABLE_SIZE_MASK) >> MP2_I3C0_DCT_SECTION_OFFSET_TABLE_SIZE_SHIFT)
#define MP2_I3C0_DCT_SECTION_OFFSET_GET_TABLE_INDEX(mp2_i3c0_dct_section_offset) \
     ((mp2_i3c0_dct_section_offset & MP2_I3C0_DCT_SECTION_OFFSET_TABLE_INDEX_MASK) >> MP2_I3C0_DCT_SECTION_OFFSET_TABLE_INDEX_SHIFT)
#define MP2_I3C0_DCT_SECTION_OFFSET_GET_RESERVED0(mp2_i3c0_dct_section_offset) \
     ((mp2_i3c0_dct_section_offset & MP2_I3C0_DCT_SECTION_OFFSET_RESERVED0_MASK) >> MP2_I3C0_DCT_SECTION_OFFSET_RESERVED0_SHIFT)

#define MP2_I3C0_DCT_SECTION_OFFSET_SET_TABLE_OFFSET(mp2_i3c0_dct_section_offset_reg, table_offset) \
     mp2_i3c0_dct_section_offset_reg = (mp2_i3c0_dct_section_offset_reg & ~MP2_I3C0_DCT_SECTION_OFFSET_TABLE_OFFSET_MASK) | (table_offset << MP2_I3C0_DCT_SECTION_OFFSET_TABLE_OFFSET_SHIFT)
#define MP2_I3C0_DCT_SECTION_OFFSET_SET_TABLE_SIZE(mp2_i3c0_dct_section_offset_reg, table_size) \
     mp2_i3c0_dct_section_offset_reg = (mp2_i3c0_dct_section_offset_reg & ~MP2_I3C0_DCT_SECTION_OFFSET_TABLE_SIZE_MASK) | (table_size << MP2_I3C0_DCT_SECTION_OFFSET_TABLE_SIZE_SHIFT)
#define MP2_I3C0_DCT_SECTION_OFFSET_SET_TABLE_INDEX(mp2_i3c0_dct_section_offset_reg, table_index) \
     mp2_i3c0_dct_section_offset_reg = (mp2_i3c0_dct_section_offset_reg & ~MP2_I3C0_DCT_SECTION_OFFSET_TABLE_INDEX_MASK) | (table_index << MP2_I3C0_DCT_SECTION_OFFSET_TABLE_INDEX_SHIFT)
#define MP2_I3C0_DCT_SECTION_OFFSET_SET_RESERVED0(mp2_i3c0_dct_section_offset_reg, reserved0) \
     mp2_i3c0_dct_section_offset_reg = (mp2_i3c0_dct_section_offset_reg & ~MP2_I3C0_DCT_SECTION_OFFSET_RESERVED0_MASK) | (reserved0 << MP2_I3C0_DCT_SECTION_OFFSET_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_dct_section_offset_t {
          unsigned int table_offset                   : MP2_I3C0_DCT_SECTION_OFFSET_TABLE_OFFSET_SIZE;
          unsigned int table_size                     : MP2_I3C0_DCT_SECTION_OFFSET_TABLE_SIZE_SIZE;
          unsigned int table_index                    : MP2_I3C0_DCT_SECTION_OFFSET_TABLE_INDEX_SIZE;
          unsigned int reserved0                      : MP2_I3C0_DCT_SECTION_OFFSET_RESERVED0_SIZE;
     } mp2_i3c0_dct_section_offset_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_dct_section_offset_t {
          unsigned int reserved0                      : MP2_I3C0_DCT_SECTION_OFFSET_RESERVED0_SIZE;
          unsigned int table_index                    : MP2_I3C0_DCT_SECTION_OFFSET_TABLE_INDEX_SIZE;
          unsigned int table_size                     : MP2_I3C0_DCT_SECTION_OFFSET_TABLE_SIZE_SIZE;
          unsigned int table_offset                   : MP2_I3C0_DCT_SECTION_OFFSET_TABLE_OFFSET_SIZE;
     } mp2_i3c0_dct_section_offset_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_dct_section_offset_t f;
} mp2_i3c0_dct_section_offset_u;


/*
 * MP2_I3C0_RING_HEADERS_SECTION_OFFSET struct
 */

#define MP2_I3C0_RING_HEADERS_SECTION_OFFSET_REG_SIZE 32
#define MP2_I3C0_RING_HEADERS_SECTION_OFFSET_SECTION_OFFSET_SIZE 16
#define MP2_I3C0_RING_HEADERS_SECTION_OFFSET_RESERVED0_SIZE 16

#define MP2_I3C0_RING_HEADERS_SECTION_OFFSET_SECTION_OFFSET_SHIFT 0
#define MP2_I3C0_RING_HEADERS_SECTION_OFFSET_RESERVED0_SHIFT 16

#define MP2_I3C0_RING_HEADERS_SECTION_OFFSET_SECTION_OFFSET_MASK 0xffff
#define MP2_I3C0_RING_HEADERS_SECTION_OFFSET_RESERVED0_MASK 0xffff0000

#define MP2_I3C0_RING_HEADERS_SECTION_OFFSET_MASK \
     (MP2_I3C0_RING_HEADERS_SECTION_OFFSET_SECTION_OFFSET_MASK | \
      MP2_I3C0_RING_HEADERS_SECTION_OFFSET_RESERVED0_MASK)

#define MP2_I3C0_RING_HEADERS_SECTION_OFFSET_DEFAULT 0x00000200

#define MP2_I3C0_RING_HEADERS_SECTION_OFFSET_GET_SECTION_OFFSET(mp2_i3c0_ring_headers_section_offset) \
     ((mp2_i3c0_ring_headers_section_offset & MP2_I3C0_RING_HEADERS_SECTION_OFFSET_SECTION_OFFSET_MASK) >> MP2_I3C0_RING_HEADERS_SECTION_OFFSET_SECTION_OFFSET_SHIFT)
#define MP2_I3C0_RING_HEADERS_SECTION_OFFSET_GET_RESERVED0(mp2_i3c0_ring_headers_section_offset) \
     ((mp2_i3c0_ring_headers_section_offset & MP2_I3C0_RING_HEADERS_SECTION_OFFSET_RESERVED0_MASK) >> MP2_I3C0_RING_HEADERS_SECTION_OFFSET_RESERVED0_SHIFT)

#define MP2_I3C0_RING_HEADERS_SECTION_OFFSET_SET_SECTION_OFFSET(mp2_i3c0_ring_headers_section_offset_reg, section_offset) \
     mp2_i3c0_ring_headers_section_offset_reg = (mp2_i3c0_ring_headers_section_offset_reg & ~MP2_I3C0_RING_HEADERS_SECTION_OFFSET_SECTION_OFFSET_MASK) | (section_offset << MP2_I3C0_RING_HEADERS_SECTION_OFFSET_SECTION_OFFSET_SHIFT)
#define MP2_I3C0_RING_HEADERS_SECTION_OFFSET_SET_RESERVED0(mp2_i3c0_ring_headers_section_offset_reg, reserved0) \
     mp2_i3c0_ring_headers_section_offset_reg = (mp2_i3c0_ring_headers_section_offset_reg & ~MP2_I3C0_RING_HEADERS_SECTION_OFFSET_RESERVED0_MASK) | (reserved0 << MP2_I3C0_RING_HEADERS_SECTION_OFFSET_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_ring_headers_section_offset_t {
          unsigned int section_offset                 : MP2_I3C0_RING_HEADERS_SECTION_OFFSET_SECTION_OFFSET_SIZE;
          unsigned int reserved0                      : MP2_I3C0_RING_HEADERS_SECTION_OFFSET_RESERVED0_SIZE;
     } mp2_i3c0_ring_headers_section_offset_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_ring_headers_section_offset_t {
          unsigned int reserved0                      : MP2_I3C0_RING_HEADERS_SECTION_OFFSET_RESERVED0_SIZE;
          unsigned int section_offset                 : MP2_I3C0_RING_HEADERS_SECTION_OFFSET_SECTION_OFFSET_SIZE;
     } mp2_i3c0_ring_headers_section_offset_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_ring_headers_section_offset_t f;
} mp2_i3c0_ring_headers_section_offset_u;


/*
 * MP2_I3C0_PIO_SECTION_OFFSET struct
 */

#define MP2_I3C0_PIO_SECTION_OFFSET_REG_SIZE 32
#define MP2_I3C0_PIO_SECTION_OFFSET_SECTION_OFFSET_SIZE 16
#define MP2_I3C0_PIO_SECTION_OFFSET_RESERVED0_SIZE 16

#define MP2_I3C0_PIO_SECTION_OFFSET_SECTION_OFFSET_SHIFT 0
#define MP2_I3C0_PIO_SECTION_OFFSET_RESERVED0_SHIFT 16

#define MP2_I3C0_PIO_SECTION_OFFSET_SECTION_OFFSET_MASK 0xffff
#define MP2_I3C0_PIO_SECTION_OFFSET_RESERVED0_MASK 0xffff0000

#define MP2_I3C0_PIO_SECTION_OFFSET_MASK \
     (MP2_I3C0_PIO_SECTION_OFFSET_SECTION_OFFSET_MASK | \
      MP2_I3C0_PIO_SECTION_OFFSET_RESERVED0_MASK)

#define MP2_I3C0_PIO_SECTION_OFFSET_DEFAULT 0x00000300

#define MP2_I3C0_PIO_SECTION_OFFSET_GET_SECTION_OFFSET(mp2_i3c0_pio_section_offset) \
     ((mp2_i3c0_pio_section_offset & MP2_I3C0_PIO_SECTION_OFFSET_SECTION_OFFSET_MASK) >> MP2_I3C0_PIO_SECTION_OFFSET_SECTION_OFFSET_SHIFT)
#define MP2_I3C0_PIO_SECTION_OFFSET_GET_RESERVED0(mp2_i3c0_pio_section_offset) \
     ((mp2_i3c0_pio_section_offset & MP2_I3C0_PIO_SECTION_OFFSET_RESERVED0_MASK) >> MP2_I3C0_PIO_SECTION_OFFSET_RESERVED0_SHIFT)

#define MP2_I3C0_PIO_SECTION_OFFSET_SET_SECTION_OFFSET(mp2_i3c0_pio_section_offset_reg, section_offset) \
     mp2_i3c0_pio_section_offset_reg = (mp2_i3c0_pio_section_offset_reg & ~MP2_I3C0_PIO_SECTION_OFFSET_SECTION_OFFSET_MASK) | (section_offset << MP2_I3C0_PIO_SECTION_OFFSET_SECTION_OFFSET_SHIFT)
#define MP2_I3C0_PIO_SECTION_OFFSET_SET_RESERVED0(mp2_i3c0_pio_section_offset_reg, reserved0) \
     mp2_i3c0_pio_section_offset_reg = (mp2_i3c0_pio_section_offset_reg & ~MP2_I3C0_PIO_SECTION_OFFSET_RESERVED0_MASK) | (reserved0 << MP2_I3C0_PIO_SECTION_OFFSET_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_pio_section_offset_t {
          unsigned int section_offset                 : MP2_I3C0_PIO_SECTION_OFFSET_SECTION_OFFSET_SIZE;
          unsigned int reserved0                      : MP2_I3C0_PIO_SECTION_OFFSET_RESERVED0_SIZE;
     } mp2_i3c0_pio_section_offset_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_pio_section_offset_t {
          unsigned int reserved0                      : MP2_I3C0_PIO_SECTION_OFFSET_RESERVED0_SIZE;
          unsigned int section_offset                 : MP2_I3C0_PIO_SECTION_OFFSET_SECTION_OFFSET_SIZE;
     } mp2_i3c0_pio_section_offset_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_pio_section_offset_t f;
} mp2_i3c0_pio_section_offset_u;


/*
 * MP2_I3C0_EXTCAPS_SECTION_OFFSET struct
 */

#define MP2_I3C0_EXTCAPS_SECTION_OFFSET_REG_SIZE 32
#define MP2_I3C0_EXTCAPS_SECTION_OFFSET_SECTION_OFFSET_SIZE 16
#define MP2_I3C0_EXTCAPS_SECTION_OFFSET_RESERVED0_SIZE 16

#define MP2_I3C0_EXTCAPS_SECTION_OFFSET_SECTION_OFFSET_SHIFT 0
#define MP2_I3C0_EXTCAPS_SECTION_OFFSET_RESERVED0_SHIFT 16

#define MP2_I3C0_EXTCAPS_SECTION_OFFSET_SECTION_OFFSET_MASK 0xffff
#define MP2_I3C0_EXTCAPS_SECTION_OFFSET_RESERVED0_MASK 0xffff0000

#define MP2_I3C0_EXTCAPS_SECTION_OFFSET_MASK \
     (MP2_I3C0_EXTCAPS_SECTION_OFFSET_SECTION_OFFSET_MASK | \
      MP2_I3C0_EXTCAPS_SECTION_OFFSET_RESERVED0_MASK)

#define MP2_I3C0_EXTCAPS_SECTION_OFFSET_DEFAULT 0x00000100

#define MP2_I3C0_EXTCAPS_SECTION_OFFSET_GET_SECTION_OFFSET(mp2_i3c0_extcaps_section_offset) \
     ((mp2_i3c0_extcaps_section_offset & MP2_I3C0_EXTCAPS_SECTION_OFFSET_SECTION_OFFSET_MASK) >> MP2_I3C0_EXTCAPS_SECTION_OFFSET_SECTION_OFFSET_SHIFT)
#define MP2_I3C0_EXTCAPS_SECTION_OFFSET_GET_RESERVED0(mp2_i3c0_extcaps_section_offset) \
     ((mp2_i3c0_extcaps_section_offset & MP2_I3C0_EXTCAPS_SECTION_OFFSET_RESERVED0_MASK) >> MP2_I3C0_EXTCAPS_SECTION_OFFSET_RESERVED0_SHIFT)

#define MP2_I3C0_EXTCAPS_SECTION_OFFSET_SET_SECTION_OFFSET(mp2_i3c0_extcaps_section_offset_reg, section_offset) \
     mp2_i3c0_extcaps_section_offset_reg = (mp2_i3c0_extcaps_section_offset_reg & ~MP2_I3C0_EXTCAPS_SECTION_OFFSET_SECTION_OFFSET_MASK) | (section_offset << MP2_I3C0_EXTCAPS_SECTION_OFFSET_SECTION_OFFSET_SHIFT)
#define MP2_I3C0_EXTCAPS_SECTION_OFFSET_SET_RESERVED0(mp2_i3c0_extcaps_section_offset_reg, reserved0) \
     mp2_i3c0_extcaps_section_offset_reg = (mp2_i3c0_extcaps_section_offset_reg & ~MP2_I3C0_EXTCAPS_SECTION_OFFSET_RESERVED0_MASK) | (reserved0 << MP2_I3C0_EXTCAPS_SECTION_OFFSET_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_extcaps_section_offset_t {
          unsigned int section_offset                 : MP2_I3C0_EXTCAPS_SECTION_OFFSET_SECTION_OFFSET_SIZE;
          unsigned int reserved0                      : MP2_I3C0_EXTCAPS_SECTION_OFFSET_RESERVED0_SIZE;
     } mp2_i3c0_extcaps_section_offset_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_extcaps_section_offset_t {
          unsigned int reserved0                      : MP2_I3C0_EXTCAPS_SECTION_OFFSET_RESERVED0_SIZE;
          unsigned int section_offset                 : MP2_I3C0_EXTCAPS_SECTION_OFFSET_SECTION_OFFSET_SIZE;
     } mp2_i3c0_extcaps_section_offset_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_extcaps_section_offset_t f;
} mp2_i3c0_extcaps_section_offset_u;


/*
 * MP2_I3C0_IBI_NOTIFY_CTRL struct
 */

#define MP2_I3C0_IBI_NOTIFY_CTRL_REG_SIZE 32
#define MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_HJ_REJECTED_SIZE 1
#define MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_MR_REJECTED_SIZE 1
#define MP2_I3C0_IBI_NOTIFY_CTRL_RESERVED1_SIZE 1
#define MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_SIR_REJECTED_SIZE 1
#define MP2_I3C0_IBI_NOTIFY_CTRL_RESERVED0_SIZE 28

#define MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_HJ_REJECTED_SHIFT 0
#define MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_MR_REJECTED_SHIFT 1
#define MP2_I3C0_IBI_NOTIFY_CTRL_RESERVED1_SHIFT 2
#define MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_SIR_REJECTED_SHIFT 3
#define MP2_I3C0_IBI_NOTIFY_CTRL_RESERVED0_SHIFT 4

#define MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_HJ_REJECTED_MASK 0x1
#define MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_MR_REJECTED_MASK 0x2
#define MP2_I3C0_IBI_NOTIFY_CTRL_RESERVED1_MASK 0x4
#define MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_SIR_REJECTED_MASK 0x8
#define MP2_I3C0_IBI_NOTIFY_CTRL_RESERVED0_MASK 0xfffffff0

#define MP2_I3C0_IBI_NOTIFY_CTRL_MASK \
     (MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_HJ_REJECTED_MASK | \
      MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_MR_REJECTED_MASK | \
      MP2_I3C0_IBI_NOTIFY_CTRL_RESERVED1_MASK | \
      MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_SIR_REJECTED_MASK | \
      MP2_I3C0_IBI_NOTIFY_CTRL_RESERVED0_MASK)

#define MP2_I3C0_IBI_NOTIFY_CTRL_DEFAULT 0x00000000

#define MP2_I3C0_IBI_NOTIFY_CTRL_GET_NOTIFY_HJ_REJECTED(mp2_i3c0_ibi_notify_ctrl) \
     ((mp2_i3c0_ibi_notify_ctrl & MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_HJ_REJECTED_MASK) >> MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_HJ_REJECTED_SHIFT)
#define MP2_I3C0_IBI_NOTIFY_CTRL_GET_NOTIFY_MR_REJECTED(mp2_i3c0_ibi_notify_ctrl) \
     ((mp2_i3c0_ibi_notify_ctrl & MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_MR_REJECTED_MASK) >> MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_MR_REJECTED_SHIFT)
#define MP2_I3C0_IBI_NOTIFY_CTRL_GET_RESERVED1(mp2_i3c0_ibi_notify_ctrl) \
     ((mp2_i3c0_ibi_notify_ctrl & MP2_I3C0_IBI_NOTIFY_CTRL_RESERVED1_MASK) >> MP2_I3C0_IBI_NOTIFY_CTRL_RESERVED1_SHIFT)
#define MP2_I3C0_IBI_NOTIFY_CTRL_GET_NOTIFY_SIR_REJECTED(mp2_i3c0_ibi_notify_ctrl) \
     ((mp2_i3c0_ibi_notify_ctrl & MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_SIR_REJECTED_MASK) >> MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_SIR_REJECTED_SHIFT)
#define MP2_I3C0_IBI_NOTIFY_CTRL_GET_RESERVED0(mp2_i3c0_ibi_notify_ctrl) \
     ((mp2_i3c0_ibi_notify_ctrl & MP2_I3C0_IBI_NOTIFY_CTRL_RESERVED0_MASK) >> MP2_I3C0_IBI_NOTIFY_CTRL_RESERVED0_SHIFT)

#define MP2_I3C0_IBI_NOTIFY_CTRL_SET_NOTIFY_HJ_REJECTED(mp2_i3c0_ibi_notify_ctrl_reg, notify_hj_rejected) \
     mp2_i3c0_ibi_notify_ctrl_reg = (mp2_i3c0_ibi_notify_ctrl_reg & ~MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_HJ_REJECTED_MASK) | (notify_hj_rejected << MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_HJ_REJECTED_SHIFT)
#define MP2_I3C0_IBI_NOTIFY_CTRL_SET_NOTIFY_MR_REJECTED(mp2_i3c0_ibi_notify_ctrl_reg, notify_mr_rejected) \
     mp2_i3c0_ibi_notify_ctrl_reg = (mp2_i3c0_ibi_notify_ctrl_reg & ~MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_MR_REJECTED_MASK) | (notify_mr_rejected << MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_MR_REJECTED_SHIFT)
#define MP2_I3C0_IBI_NOTIFY_CTRL_SET_RESERVED1(mp2_i3c0_ibi_notify_ctrl_reg, reserved1) \
     mp2_i3c0_ibi_notify_ctrl_reg = (mp2_i3c0_ibi_notify_ctrl_reg & ~MP2_I3C0_IBI_NOTIFY_CTRL_RESERVED1_MASK) | (reserved1 << MP2_I3C0_IBI_NOTIFY_CTRL_RESERVED1_SHIFT)
#define MP2_I3C0_IBI_NOTIFY_CTRL_SET_NOTIFY_SIR_REJECTED(mp2_i3c0_ibi_notify_ctrl_reg, notify_sir_rejected) \
     mp2_i3c0_ibi_notify_ctrl_reg = (mp2_i3c0_ibi_notify_ctrl_reg & ~MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_SIR_REJECTED_MASK) | (notify_sir_rejected << MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_SIR_REJECTED_SHIFT)
#define MP2_I3C0_IBI_NOTIFY_CTRL_SET_RESERVED0(mp2_i3c0_ibi_notify_ctrl_reg, reserved0) \
     mp2_i3c0_ibi_notify_ctrl_reg = (mp2_i3c0_ibi_notify_ctrl_reg & ~MP2_I3C0_IBI_NOTIFY_CTRL_RESERVED0_MASK) | (reserved0 << MP2_I3C0_IBI_NOTIFY_CTRL_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_ibi_notify_ctrl_t {
          unsigned int notify_hj_rejected             : MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_HJ_REJECTED_SIZE;
          unsigned int notify_mr_rejected             : MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_MR_REJECTED_SIZE;
          unsigned int reserved1                      : MP2_I3C0_IBI_NOTIFY_CTRL_RESERVED1_SIZE;
          unsigned int notify_sir_rejected            : MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_SIR_REJECTED_SIZE;
          unsigned int reserved0                      : MP2_I3C0_IBI_NOTIFY_CTRL_RESERVED0_SIZE;
     } mp2_i3c0_ibi_notify_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_ibi_notify_ctrl_t {
          unsigned int reserved0                      : MP2_I3C0_IBI_NOTIFY_CTRL_RESERVED0_SIZE;
          unsigned int notify_sir_rejected            : MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_SIR_REJECTED_SIZE;
          unsigned int reserved1                      : MP2_I3C0_IBI_NOTIFY_CTRL_RESERVED1_SIZE;
          unsigned int notify_mr_rejected             : MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_MR_REJECTED_SIZE;
          unsigned int notify_hj_rejected             : MP2_I3C0_IBI_NOTIFY_CTRL_NOTIFY_HJ_REJECTED_SIZE;
     } mp2_i3c0_ibi_notify_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_ibi_notify_ctrl_t f;
} mp2_i3c0_ibi_notify_ctrl_u;


/*
 * MP2_I3C0_DEV_CTX_BASE_LO struct
 */

#define MP2_I3C0_DEV_CTX_BASE_LO_REG_SIZE 32
#define MP2_I3C0_DEV_CTX_BASE_LO_BASE_LO_SIZE 32

#define MP2_I3C0_DEV_CTX_BASE_LO_BASE_LO_SHIFT 0

#define MP2_I3C0_DEV_CTX_BASE_LO_BASE_LO_MASK 0xffffffff

#define MP2_I3C0_DEV_CTX_BASE_LO_MASK \
     (MP2_I3C0_DEV_CTX_BASE_LO_BASE_LO_MASK)

#define MP2_I3C0_DEV_CTX_BASE_LO_DEFAULT 0x00000000

#define MP2_I3C0_DEV_CTX_BASE_LO_GET_BASE_LO(mp2_i3c0_dev_ctx_base_lo) \
     ((mp2_i3c0_dev_ctx_base_lo & MP2_I3C0_DEV_CTX_BASE_LO_BASE_LO_MASK) >> MP2_I3C0_DEV_CTX_BASE_LO_BASE_LO_SHIFT)

#define MP2_I3C0_DEV_CTX_BASE_LO_SET_BASE_LO(mp2_i3c0_dev_ctx_base_lo_reg, base_lo) \
     mp2_i3c0_dev_ctx_base_lo_reg = (mp2_i3c0_dev_ctx_base_lo_reg & ~MP2_I3C0_DEV_CTX_BASE_LO_BASE_LO_MASK) | (base_lo << MP2_I3C0_DEV_CTX_BASE_LO_BASE_LO_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_dev_ctx_base_lo_t {
          unsigned int base_lo                        : MP2_I3C0_DEV_CTX_BASE_LO_BASE_LO_SIZE;
     } mp2_i3c0_dev_ctx_base_lo_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_dev_ctx_base_lo_t {
          unsigned int base_lo                        : MP2_I3C0_DEV_CTX_BASE_LO_BASE_LO_SIZE;
     } mp2_i3c0_dev_ctx_base_lo_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_dev_ctx_base_lo_t f;
} mp2_i3c0_dev_ctx_base_lo_u;


/*
 * MP2_I3C0_DEV_CTX_BASE_HI struct
 */

#define MP2_I3C0_DEV_CTX_BASE_HI_REG_SIZE 32
#define MP2_I3C0_DEV_CTX_BASE_HI_BASE_HI_SIZE 32

#define MP2_I3C0_DEV_CTX_BASE_HI_BASE_HI_SHIFT 0

#define MP2_I3C0_DEV_CTX_BASE_HI_BASE_HI_MASK 0xffffffff

#define MP2_I3C0_DEV_CTX_BASE_HI_MASK \
     (MP2_I3C0_DEV_CTX_BASE_HI_BASE_HI_MASK)

#define MP2_I3C0_DEV_CTX_BASE_HI_DEFAULT 0x00000000

#define MP2_I3C0_DEV_CTX_BASE_HI_GET_BASE_HI(mp2_i3c0_dev_ctx_base_hi) \
     ((mp2_i3c0_dev_ctx_base_hi & MP2_I3C0_DEV_CTX_BASE_HI_BASE_HI_MASK) >> MP2_I3C0_DEV_CTX_BASE_HI_BASE_HI_SHIFT)

#define MP2_I3C0_DEV_CTX_BASE_HI_SET_BASE_HI(mp2_i3c0_dev_ctx_base_hi_reg, base_hi) \
     mp2_i3c0_dev_ctx_base_hi_reg = (mp2_i3c0_dev_ctx_base_hi_reg & ~MP2_I3C0_DEV_CTX_BASE_HI_BASE_HI_MASK) | (base_hi << MP2_I3C0_DEV_CTX_BASE_HI_BASE_HI_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_dev_ctx_base_hi_t {
          unsigned int base_hi                        : MP2_I3C0_DEV_CTX_BASE_HI_BASE_HI_SIZE;
     } mp2_i3c0_dev_ctx_base_hi_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_dev_ctx_base_hi_t {
          unsigned int base_hi                        : MP2_I3C0_DEV_CTX_BASE_HI_BASE_HI_SIZE;
     } mp2_i3c0_dev_ctx_base_hi_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_dev_ctx_base_hi_t f;
} mp2_i3c0_dev_ctx_base_hi_u;


/*
 * MP2_I3C0_HW_IDENTIFICATION_HEADER struct
 */

#define MP2_I3C0_HW_IDENTIFICATION_HEADER_REG_SIZE 32
#define MP2_I3C0_HW_IDENTIFICATION_HEADER_CAP_ID_SIZE 8
#define MP2_I3C0_HW_IDENTIFICATION_HEADER_CAP_LEN_SIZE 16
#define MP2_I3C0_HW_IDENTIFICATION_HEADER_RESERVED0_SIZE 8

#define MP2_I3C0_HW_IDENTIFICATION_HEADER_CAP_ID_SHIFT 0
#define MP2_I3C0_HW_IDENTIFICATION_HEADER_CAP_LEN_SHIFT 8
#define MP2_I3C0_HW_IDENTIFICATION_HEADER_RESERVED0_SHIFT 24

#define MP2_I3C0_HW_IDENTIFICATION_HEADER_CAP_ID_MASK 0xff
#define MP2_I3C0_HW_IDENTIFICATION_HEADER_CAP_LEN_MASK 0xffff00
#define MP2_I3C0_HW_IDENTIFICATION_HEADER_RESERVED0_MASK 0xff000000

#define MP2_I3C0_HW_IDENTIFICATION_HEADER_MASK \
     (MP2_I3C0_HW_IDENTIFICATION_HEADER_CAP_ID_MASK | \
      MP2_I3C0_HW_IDENTIFICATION_HEADER_CAP_LEN_MASK | \
      MP2_I3C0_HW_IDENTIFICATION_HEADER_RESERVED0_MASK)

#define MP2_I3C0_HW_IDENTIFICATION_HEADER_DEFAULT 0x00000401

#define MP2_I3C0_HW_IDENTIFICATION_HEADER_GET_CAP_ID(mp2_i3c0_hw_identification_header) \
     ((mp2_i3c0_hw_identification_header & MP2_I3C0_HW_IDENTIFICATION_HEADER_CAP_ID_MASK) >> MP2_I3C0_HW_IDENTIFICATION_HEADER_CAP_ID_SHIFT)
#define MP2_I3C0_HW_IDENTIFICATION_HEADER_GET_CAP_LEN(mp2_i3c0_hw_identification_header) \
     ((mp2_i3c0_hw_identification_header & MP2_I3C0_HW_IDENTIFICATION_HEADER_CAP_LEN_MASK) >> MP2_I3C0_HW_IDENTIFICATION_HEADER_CAP_LEN_SHIFT)
#define MP2_I3C0_HW_IDENTIFICATION_HEADER_GET_RESERVED0(mp2_i3c0_hw_identification_header) \
     ((mp2_i3c0_hw_identification_header & MP2_I3C0_HW_IDENTIFICATION_HEADER_RESERVED0_MASK) >> MP2_I3C0_HW_IDENTIFICATION_HEADER_RESERVED0_SHIFT)

#define MP2_I3C0_HW_IDENTIFICATION_HEADER_SET_CAP_ID(mp2_i3c0_hw_identification_header_reg, cap_id) \
     mp2_i3c0_hw_identification_header_reg = (mp2_i3c0_hw_identification_header_reg & ~MP2_I3C0_HW_IDENTIFICATION_HEADER_CAP_ID_MASK) | (cap_id << MP2_I3C0_HW_IDENTIFICATION_HEADER_CAP_ID_SHIFT)
#define MP2_I3C0_HW_IDENTIFICATION_HEADER_SET_CAP_LEN(mp2_i3c0_hw_identification_header_reg, cap_len) \
     mp2_i3c0_hw_identification_header_reg = (mp2_i3c0_hw_identification_header_reg & ~MP2_I3C0_HW_IDENTIFICATION_HEADER_CAP_LEN_MASK) | (cap_len << MP2_I3C0_HW_IDENTIFICATION_HEADER_CAP_LEN_SHIFT)
#define MP2_I3C0_HW_IDENTIFICATION_HEADER_SET_RESERVED0(mp2_i3c0_hw_identification_header_reg, reserved0) \
     mp2_i3c0_hw_identification_header_reg = (mp2_i3c0_hw_identification_header_reg & ~MP2_I3C0_HW_IDENTIFICATION_HEADER_RESERVED0_MASK) | (reserved0 << MP2_I3C0_HW_IDENTIFICATION_HEADER_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_hw_identification_header_t {
          unsigned int cap_id                         : MP2_I3C0_HW_IDENTIFICATION_HEADER_CAP_ID_SIZE;
          unsigned int cap_len                        : MP2_I3C0_HW_IDENTIFICATION_HEADER_CAP_LEN_SIZE;
          unsigned int reserved0                      : MP2_I3C0_HW_IDENTIFICATION_HEADER_RESERVED0_SIZE;
     } mp2_i3c0_hw_identification_header_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_hw_identification_header_t {
          unsigned int reserved0                      : MP2_I3C0_HW_IDENTIFICATION_HEADER_RESERVED0_SIZE;
          unsigned int cap_len                        : MP2_I3C0_HW_IDENTIFICATION_HEADER_CAP_LEN_SIZE;
          unsigned int cap_id                         : MP2_I3C0_HW_IDENTIFICATION_HEADER_CAP_ID_SIZE;
     } mp2_i3c0_hw_identification_header_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_hw_identification_header_t f;
} mp2_i3c0_hw_identification_header_u;


/*
 * MP2_I3C0_COMP_MANUFACTURER struct
 */

#define MP2_I3C0_COMP_MANUFACTURER_REG_SIZE 32
#define MP2_I3C0_COMP_MANUFACTURER_MIPI_VENDOR_ID_SIZE 32

#define MP2_I3C0_COMP_MANUFACTURER_MIPI_VENDOR_ID_SHIFT 0

#define MP2_I3C0_COMP_MANUFACTURER_MIPI_VENDOR_ID_MASK 0xffffffff

#define MP2_I3C0_COMP_MANUFACTURER_MASK \
     (MP2_I3C0_COMP_MANUFACTURER_MIPI_VENDOR_ID_MASK)

#define MP2_I3C0_COMP_MANUFACTURER_DEFAULT 0x00000000

#define MP2_I3C0_COMP_MANUFACTURER_GET_MIPI_VENDOR_ID(mp2_i3c0_comp_manufacturer) \
     ((mp2_i3c0_comp_manufacturer & MP2_I3C0_COMP_MANUFACTURER_MIPI_VENDOR_ID_MASK) >> MP2_I3C0_COMP_MANUFACTURER_MIPI_VENDOR_ID_SHIFT)

#define MP2_I3C0_COMP_MANUFACTURER_SET_MIPI_VENDOR_ID(mp2_i3c0_comp_manufacturer_reg, mipi_vendor_id) \
     mp2_i3c0_comp_manufacturer_reg = (mp2_i3c0_comp_manufacturer_reg & ~MP2_I3C0_COMP_MANUFACTURER_MIPI_VENDOR_ID_MASK) | (mipi_vendor_id << MP2_I3C0_COMP_MANUFACTURER_MIPI_VENDOR_ID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_comp_manufacturer_t {
          unsigned int mipi_vendor_id                 : MP2_I3C0_COMP_MANUFACTURER_MIPI_VENDOR_ID_SIZE;
     } mp2_i3c0_comp_manufacturer_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_comp_manufacturer_t {
          unsigned int mipi_vendor_id                 : MP2_I3C0_COMP_MANUFACTURER_MIPI_VENDOR_ID_SIZE;
     } mp2_i3c0_comp_manufacturer_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_comp_manufacturer_t f;
} mp2_i3c0_comp_manufacturer_u;


/*
 * MP2_I3C0_COMP_VERSION struct
 */

#define MP2_I3C0_COMP_VERSION_REG_SIZE 32
#define MP2_I3C0_COMP_VERSION_I3C_VER_ID_SIZE 32

#define MP2_I3C0_COMP_VERSION_I3C_VER_ID_SHIFT 0

#define MP2_I3C0_COMP_VERSION_I3C_VER_ID_MASK 0xffffffff

#define MP2_I3C0_COMP_VERSION_MASK \
     (MP2_I3C0_COMP_VERSION_I3C_VER_ID_MASK)

#define MP2_I3C0_COMP_VERSION_DEFAULT  0x3130302a

#define MP2_I3C0_COMP_VERSION_GET_I3C_VER_ID(mp2_i3c0_comp_version) \
     ((mp2_i3c0_comp_version & MP2_I3C0_COMP_VERSION_I3C_VER_ID_MASK) >> MP2_I3C0_COMP_VERSION_I3C_VER_ID_SHIFT)

#define MP2_I3C0_COMP_VERSION_SET_I3C_VER_ID(mp2_i3c0_comp_version_reg, i3c_ver_id) \
     mp2_i3c0_comp_version_reg = (mp2_i3c0_comp_version_reg & ~MP2_I3C0_COMP_VERSION_I3C_VER_ID_MASK) | (i3c_ver_id << MP2_I3C0_COMP_VERSION_I3C_VER_ID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_comp_version_t {
          unsigned int i3c_ver_id                     : MP2_I3C0_COMP_VERSION_I3C_VER_ID_SIZE;
     } mp2_i3c0_comp_version_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_comp_version_t {
          unsigned int i3c_ver_id                     : MP2_I3C0_COMP_VERSION_I3C_VER_ID_SIZE;
     } mp2_i3c0_comp_version_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_comp_version_t f;
} mp2_i3c0_comp_version_u;


/*
 * MP2_I3C0_COMP_TYPE struct
 */

#define MP2_I3C0_COMP_TYPE_REG_SIZE    32
#define MP2_I3C0_COMP_TYPE_I3C_VER_TYPE_SIZE 32

#define MP2_I3C0_COMP_TYPE_I3C_VER_TYPE_SHIFT 0

#define MP2_I3C0_COMP_TYPE_I3C_VER_TYPE_MASK 0xffffffff

#define MP2_I3C0_COMP_TYPE_MASK \
     (MP2_I3C0_COMP_TYPE_I3C_VER_TYPE_MASK)

#define MP2_I3C0_COMP_TYPE_DEFAULT     0x6c633033

#define MP2_I3C0_COMP_TYPE_GET_I3C_VER_TYPE(mp2_i3c0_comp_type) \
     ((mp2_i3c0_comp_type & MP2_I3C0_COMP_TYPE_I3C_VER_TYPE_MASK) >> MP2_I3C0_COMP_TYPE_I3C_VER_TYPE_SHIFT)

#define MP2_I3C0_COMP_TYPE_SET_I3C_VER_TYPE(mp2_i3c0_comp_type_reg, i3c_ver_type) \
     mp2_i3c0_comp_type_reg = (mp2_i3c0_comp_type_reg & ~MP2_I3C0_COMP_TYPE_I3C_VER_TYPE_MASK) | (i3c_ver_type << MP2_I3C0_COMP_TYPE_I3C_VER_TYPE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_comp_type_t {
          unsigned int i3c_ver_type                   : MP2_I3C0_COMP_TYPE_I3C_VER_TYPE_SIZE;
     } mp2_i3c0_comp_type_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_comp_type_t {
          unsigned int i3c_ver_type                   : MP2_I3C0_COMP_TYPE_I3C_VER_TYPE_SIZE;
     } mp2_i3c0_comp_type_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_comp_type_t f;
} mp2_i3c0_comp_type_u;


/*
 * MP2_I3C0_BUS_TIMING_HEADER struct
 */

#define MP2_I3C0_BUS_TIMING_HEADER_REG_SIZE 32
#define MP2_I3C0_BUS_TIMING_HEADER_CAP_ID_SIZE 8
#define MP2_I3C0_BUS_TIMING_HEADER_CAP_LEN_SIZE 16
#define MP2_I3C0_BUS_TIMING_HEADER_RESERVED0_SIZE 8

#define MP2_I3C0_BUS_TIMING_HEADER_CAP_ID_SHIFT 0
#define MP2_I3C0_BUS_TIMING_HEADER_CAP_LEN_SHIFT 8
#define MP2_I3C0_BUS_TIMING_HEADER_RESERVED0_SHIFT 24

#define MP2_I3C0_BUS_TIMING_HEADER_CAP_ID_MASK 0xff
#define MP2_I3C0_BUS_TIMING_HEADER_CAP_LEN_MASK 0xffff00
#define MP2_I3C0_BUS_TIMING_HEADER_RESERVED0_MASK 0xff000000

#define MP2_I3C0_BUS_TIMING_HEADER_MASK \
     (MP2_I3C0_BUS_TIMING_HEADER_CAP_ID_MASK | \
      MP2_I3C0_BUS_TIMING_HEADER_CAP_LEN_MASK | \
      MP2_I3C0_BUS_TIMING_HEADER_RESERVED0_MASK)

#define MP2_I3C0_BUS_TIMING_HEADER_DEFAULT 0x00000cc0

#define MP2_I3C0_BUS_TIMING_HEADER_GET_CAP_ID(mp2_i3c0_bus_timing_header) \
     ((mp2_i3c0_bus_timing_header & MP2_I3C0_BUS_TIMING_HEADER_CAP_ID_MASK) >> MP2_I3C0_BUS_TIMING_HEADER_CAP_ID_SHIFT)
#define MP2_I3C0_BUS_TIMING_HEADER_GET_CAP_LEN(mp2_i3c0_bus_timing_header) \
     ((mp2_i3c0_bus_timing_header & MP2_I3C0_BUS_TIMING_HEADER_CAP_LEN_MASK) >> MP2_I3C0_BUS_TIMING_HEADER_CAP_LEN_SHIFT)
#define MP2_I3C0_BUS_TIMING_HEADER_GET_RESERVED0(mp2_i3c0_bus_timing_header) \
     ((mp2_i3c0_bus_timing_header & MP2_I3C0_BUS_TIMING_HEADER_RESERVED0_MASK) >> MP2_I3C0_BUS_TIMING_HEADER_RESERVED0_SHIFT)

#define MP2_I3C0_BUS_TIMING_HEADER_SET_CAP_ID(mp2_i3c0_bus_timing_header_reg, cap_id) \
     mp2_i3c0_bus_timing_header_reg = (mp2_i3c0_bus_timing_header_reg & ~MP2_I3C0_BUS_TIMING_HEADER_CAP_ID_MASK) | (cap_id << MP2_I3C0_BUS_TIMING_HEADER_CAP_ID_SHIFT)
#define MP2_I3C0_BUS_TIMING_HEADER_SET_CAP_LEN(mp2_i3c0_bus_timing_header_reg, cap_len) \
     mp2_i3c0_bus_timing_header_reg = (mp2_i3c0_bus_timing_header_reg & ~MP2_I3C0_BUS_TIMING_HEADER_CAP_LEN_MASK) | (cap_len << MP2_I3C0_BUS_TIMING_HEADER_CAP_LEN_SHIFT)
#define MP2_I3C0_BUS_TIMING_HEADER_SET_RESERVED0(mp2_i3c0_bus_timing_header_reg, reserved0) \
     mp2_i3c0_bus_timing_header_reg = (mp2_i3c0_bus_timing_header_reg & ~MP2_I3C0_BUS_TIMING_HEADER_RESERVED0_MASK) | (reserved0 << MP2_I3C0_BUS_TIMING_HEADER_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_bus_timing_header_t {
          unsigned int cap_id                         : MP2_I3C0_BUS_TIMING_HEADER_CAP_ID_SIZE;
          unsigned int cap_len                        : MP2_I3C0_BUS_TIMING_HEADER_CAP_LEN_SIZE;
          unsigned int reserved0                      : MP2_I3C0_BUS_TIMING_HEADER_RESERVED0_SIZE;
     } mp2_i3c0_bus_timing_header_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_bus_timing_header_t {
          unsigned int reserved0                      : MP2_I3C0_BUS_TIMING_HEADER_RESERVED0_SIZE;
          unsigned int cap_len                        : MP2_I3C0_BUS_TIMING_HEADER_CAP_LEN_SIZE;
          unsigned int cap_id                         : MP2_I3C0_BUS_TIMING_HEADER_CAP_ID_SIZE;
     } mp2_i3c0_bus_timing_header_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_bus_timing_header_t f;
} mp2_i3c0_bus_timing_header_u;


/*
 * MP2_I3C0_SCL_I3C_OD_TIMING struct
 */

#define MP2_I3C0_SCL_I3C_OD_TIMING_REG_SIZE 32
#define MP2_I3C0_SCL_I3C_OD_TIMING_I3C_OD_LCNT_SIZE 8
#define MP2_I3C0_SCL_I3C_OD_TIMING_RESERVED1_SIZE 8
#define MP2_I3C0_SCL_I3C_OD_TIMING_I3C_OD_HCNT_SIZE 8
#define MP2_I3C0_SCL_I3C_OD_TIMING_RESERVED0_SIZE 8

#define MP2_I3C0_SCL_I3C_OD_TIMING_I3C_OD_LCNT_SHIFT 0
#define MP2_I3C0_SCL_I3C_OD_TIMING_RESERVED1_SHIFT 8
#define MP2_I3C0_SCL_I3C_OD_TIMING_I3C_OD_HCNT_SHIFT 16
#define MP2_I3C0_SCL_I3C_OD_TIMING_RESERVED0_SHIFT 24

#define MP2_I3C0_SCL_I3C_OD_TIMING_I3C_OD_LCNT_MASK 0xff
#define MP2_I3C0_SCL_I3C_OD_TIMING_RESERVED1_MASK 0xff00
#define MP2_I3C0_SCL_I3C_OD_TIMING_I3C_OD_HCNT_MASK 0xff0000
#define MP2_I3C0_SCL_I3C_OD_TIMING_RESERVED0_MASK 0xff000000

#define MP2_I3C0_SCL_I3C_OD_TIMING_MASK \
     (MP2_I3C0_SCL_I3C_OD_TIMING_I3C_OD_LCNT_MASK | \
      MP2_I3C0_SCL_I3C_OD_TIMING_RESERVED1_MASK | \
      MP2_I3C0_SCL_I3C_OD_TIMING_I3C_OD_HCNT_MASK | \
      MP2_I3C0_SCL_I3C_OD_TIMING_RESERVED0_MASK)

#define MP2_I3C0_SCL_I3C_OD_TIMING_DEFAULT 0x000a0010

#define MP2_I3C0_SCL_I3C_OD_TIMING_GET_I3C_OD_LCNT(mp2_i3c0_scl_i3c_od_timing) \
     ((mp2_i3c0_scl_i3c_od_timing & MP2_I3C0_SCL_I3C_OD_TIMING_I3C_OD_LCNT_MASK) >> MP2_I3C0_SCL_I3C_OD_TIMING_I3C_OD_LCNT_SHIFT)
#define MP2_I3C0_SCL_I3C_OD_TIMING_GET_RESERVED1(mp2_i3c0_scl_i3c_od_timing) \
     ((mp2_i3c0_scl_i3c_od_timing & MP2_I3C0_SCL_I3C_OD_TIMING_RESERVED1_MASK) >> MP2_I3C0_SCL_I3C_OD_TIMING_RESERVED1_SHIFT)
#define MP2_I3C0_SCL_I3C_OD_TIMING_GET_I3C_OD_HCNT(mp2_i3c0_scl_i3c_od_timing) \
     ((mp2_i3c0_scl_i3c_od_timing & MP2_I3C0_SCL_I3C_OD_TIMING_I3C_OD_HCNT_MASK) >> MP2_I3C0_SCL_I3C_OD_TIMING_I3C_OD_HCNT_SHIFT)
#define MP2_I3C0_SCL_I3C_OD_TIMING_GET_RESERVED0(mp2_i3c0_scl_i3c_od_timing) \
     ((mp2_i3c0_scl_i3c_od_timing & MP2_I3C0_SCL_I3C_OD_TIMING_RESERVED0_MASK) >> MP2_I3C0_SCL_I3C_OD_TIMING_RESERVED0_SHIFT)

#define MP2_I3C0_SCL_I3C_OD_TIMING_SET_I3C_OD_LCNT(mp2_i3c0_scl_i3c_od_timing_reg, i3c_od_lcnt) \
     mp2_i3c0_scl_i3c_od_timing_reg = (mp2_i3c0_scl_i3c_od_timing_reg & ~MP2_I3C0_SCL_I3C_OD_TIMING_I3C_OD_LCNT_MASK) | (i3c_od_lcnt << MP2_I3C0_SCL_I3C_OD_TIMING_I3C_OD_LCNT_SHIFT)
#define MP2_I3C0_SCL_I3C_OD_TIMING_SET_RESERVED1(mp2_i3c0_scl_i3c_od_timing_reg, reserved1) \
     mp2_i3c0_scl_i3c_od_timing_reg = (mp2_i3c0_scl_i3c_od_timing_reg & ~MP2_I3C0_SCL_I3C_OD_TIMING_RESERVED1_MASK) | (reserved1 << MP2_I3C0_SCL_I3C_OD_TIMING_RESERVED1_SHIFT)
#define MP2_I3C0_SCL_I3C_OD_TIMING_SET_I3C_OD_HCNT(mp2_i3c0_scl_i3c_od_timing_reg, i3c_od_hcnt) \
     mp2_i3c0_scl_i3c_od_timing_reg = (mp2_i3c0_scl_i3c_od_timing_reg & ~MP2_I3C0_SCL_I3C_OD_TIMING_I3C_OD_HCNT_MASK) | (i3c_od_hcnt << MP2_I3C0_SCL_I3C_OD_TIMING_I3C_OD_HCNT_SHIFT)
#define MP2_I3C0_SCL_I3C_OD_TIMING_SET_RESERVED0(mp2_i3c0_scl_i3c_od_timing_reg, reserved0) \
     mp2_i3c0_scl_i3c_od_timing_reg = (mp2_i3c0_scl_i3c_od_timing_reg & ~MP2_I3C0_SCL_I3C_OD_TIMING_RESERVED0_MASK) | (reserved0 << MP2_I3C0_SCL_I3C_OD_TIMING_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_scl_i3c_od_timing_t {
          unsigned int i3c_od_lcnt                    : MP2_I3C0_SCL_I3C_OD_TIMING_I3C_OD_LCNT_SIZE;
          unsigned int reserved1                      : MP2_I3C0_SCL_I3C_OD_TIMING_RESERVED1_SIZE;
          unsigned int i3c_od_hcnt                    : MP2_I3C0_SCL_I3C_OD_TIMING_I3C_OD_HCNT_SIZE;
          unsigned int reserved0                      : MP2_I3C0_SCL_I3C_OD_TIMING_RESERVED0_SIZE;
     } mp2_i3c0_scl_i3c_od_timing_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_scl_i3c_od_timing_t {
          unsigned int reserved0                      : MP2_I3C0_SCL_I3C_OD_TIMING_RESERVED0_SIZE;
          unsigned int i3c_od_hcnt                    : MP2_I3C0_SCL_I3C_OD_TIMING_I3C_OD_HCNT_SIZE;
          unsigned int reserved1                      : MP2_I3C0_SCL_I3C_OD_TIMING_RESERVED1_SIZE;
          unsigned int i3c_od_lcnt                    : MP2_I3C0_SCL_I3C_OD_TIMING_I3C_OD_LCNT_SIZE;
     } mp2_i3c0_scl_i3c_od_timing_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_scl_i3c_od_timing_t f;
} mp2_i3c0_scl_i3c_od_timing_u;


/*
 * MP2_I3C0_SCL_I3C_PP_TIMING struct
 */

#define MP2_I3C0_SCL_I3C_PP_TIMING_REG_SIZE 32
#define MP2_I3C0_SCL_I3C_PP_TIMING_I3C_PP_LCNT_SIZE 8
#define MP2_I3C0_SCL_I3C_PP_TIMING_RESERVED1_SIZE 8
#define MP2_I3C0_SCL_I3C_PP_TIMING_I3C_PP_HCNT_SIZE 8
#define MP2_I3C0_SCL_I3C_PP_TIMING_RESERVED0_SIZE 8

#define MP2_I3C0_SCL_I3C_PP_TIMING_I3C_PP_LCNT_SHIFT 0
#define MP2_I3C0_SCL_I3C_PP_TIMING_RESERVED1_SHIFT 8
#define MP2_I3C0_SCL_I3C_PP_TIMING_I3C_PP_HCNT_SHIFT 16
#define MP2_I3C0_SCL_I3C_PP_TIMING_RESERVED0_SHIFT 24

#define MP2_I3C0_SCL_I3C_PP_TIMING_I3C_PP_LCNT_MASK 0xff
#define MP2_I3C0_SCL_I3C_PP_TIMING_RESERVED1_MASK 0xff00
#define MP2_I3C0_SCL_I3C_PP_TIMING_I3C_PP_HCNT_MASK 0xff0000
#define MP2_I3C0_SCL_I3C_PP_TIMING_RESERVED0_MASK 0xff000000

#define MP2_I3C0_SCL_I3C_PP_TIMING_MASK \
     (MP2_I3C0_SCL_I3C_PP_TIMING_I3C_PP_LCNT_MASK | \
      MP2_I3C0_SCL_I3C_PP_TIMING_RESERVED1_MASK | \
      MP2_I3C0_SCL_I3C_PP_TIMING_I3C_PP_HCNT_MASK | \
      MP2_I3C0_SCL_I3C_PP_TIMING_RESERVED0_MASK)

#define MP2_I3C0_SCL_I3C_PP_TIMING_DEFAULT 0x000a000a

#define MP2_I3C0_SCL_I3C_PP_TIMING_GET_I3C_PP_LCNT(mp2_i3c0_scl_i3c_pp_timing) \
     ((mp2_i3c0_scl_i3c_pp_timing & MP2_I3C0_SCL_I3C_PP_TIMING_I3C_PP_LCNT_MASK) >> MP2_I3C0_SCL_I3C_PP_TIMING_I3C_PP_LCNT_SHIFT)
#define MP2_I3C0_SCL_I3C_PP_TIMING_GET_RESERVED1(mp2_i3c0_scl_i3c_pp_timing) \
     ((mp2_i3c0_scl_i3c_pp_timing & MP2_I3C0_SCL_I3C_PP_TIMING_RESERVED1_MASK) >> MP2_I3C0_SCL_I3C_PP_TIMING_RESERVED1_SHIFT)
#define MP2_I3C0_SCL_I3C_PP_TIMING_GET_I3C_PP_HCNT(mp2_i3c0_scl_i3c_pp_timing) \
     ((mp2_i3c0_scl_i3c_pp_timing & MP2_I3C0_SCL_I3C_PP_TIMING_I3C_PP_HCNT_MASK) >> MP2_I3C0_SCL_I3C_PP_TIMING_I3C_PP_HCNT_SHIFT)
#define MP2_I3C0_SCL_I3C_PP_TIMING_GET_RESERVED0(mp2_i3c0_scl_i3c_pp_timing) \
     ((mp2_i3c0_scl_i3c_pp_timing & MP2_I3C0_SCL_I3C_PP_TIMING_RESERVED0_MASK) >> MP2_I3C0_SCL_I3C_PP_TIMING_RESERVED0_SHIFT)

#define MP2_I3C0_SCL_I3C_PP_TIMING_SET_I3C_PP_LCNT(mp2_i3c0_scl_i3c_pp_timing_reg, i3c_pp_lcnt) \
     mp2_i3c0_scl_i3c_pp_timing_reg = (mp2_i3c0_scl_i3c_pp_timing_reg & ~MP2_I3C0_SCL_I3C_PP_TIMING_I3C_PP_LCNT_MASK) | (i3c_pp_lcnt << MP2_I3C0_SCL_I3C_PP_TIMING_I3C_PP_LCNT_SHIFT)
#define MP2_I3C0_SCL_I3C_PP_TIMING_SET_RESERVED1(mp2_i3c0_scl_i3c_pp_timing_reg, reserved1) \
     mp2_i3c0_scl_i3c_pp_timing_reg = (mp2_i3c0_scl_i3c_pp_timing_reg & ~MP2_I3C0_SCL_I3C_PP_TIMING_RESERVED1_MASK) | (reserved1 << MP2_I3C0_SCL_I3C_PP_TIMING_RESERVED1_SHIFT)
#define MP2_I3C0_SCL_I3C_PP_TIMING_SET_I3C_PP_HCNT(mp2_i3c0_scl_i3c_pp_timing_reg, i3c_pp_hcnt) \
     mp2_i3c0_scl_i3c_pp_timing_reg = (mp2_i3c0_scl_i3c_pp_timing_reg & ~MP2_I3C0_SCL_I3C_PP_TIMING_I3C_PP_HCNT_MASK) | (i3c_pp_hcnt << MP2_I3C0_SCL_I3C_PP_TIMING_I3C_PP_HCNT_SHIFT)
#define MP2_I3C0_SCL_I3C_PP_TIMING_SET_RESERVED0(mp2_i3c0_scl_i3c_pp_timing_reg, reserved0) \
     mp2_i3c0_scl_i3c_pp_timing_reg = (mp2_i3c0_scl_i3c_pp_timing_reg & ~MP2_I3C0_SCL_I3C_PP_TIMING_RESERVED0_MASK) | (reserved0 << MP2_I3C0_SCL_I3C_PP_TIMING_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_scl_i3c_pp_timing_t {
          unsigned int i3c_pp_lcnt                    : MP2_I3C0_SCL_I3C_PP_TIMING_I3C_PP_LCNT_SIZE;
          unsigned int reserved1                      : MP2_I3C0_SCL_I3C_PP_TIMING_RESERVED1_SIZE;
          unsigned int i3c_pp_hcnt                    : MP2_I3C0_SCL_I3C_PP_TIMING_I3C_PP_HCNT_SIZE;
          unsigned int reserved0                      : MP2_I3C0_SCL_I3C_PP_TIMING_RESERVED0_SIZE;
     } mp2_i3c0_scl_i3c_pp_timing_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_scl_i3c_pp_timing_t {
          unsigned int reserved0                      : MP2_I3C0_SCL_I3C_PP_TIMING_RESERVED0_SIZE;
          unsigned int i3c_pp_hcnt                    : MP2_I3C0_SCL_I3C_PP_TIMING_I3C_PP_HCNT_SIZE;
          unsigned int reserved1                      : MP2_I3C0_SCL_I3C_PP_TIMING_RESERVED1_SIZE;
          unsigned int i3c_pp_lcnt                    : MP2_I3C0_SCL_I3C_PP_TIMING_I3C_PP_LCNT_SIZE;
     } mp2_i3c0_scl_i3c_pp_timing_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_scl_i3c_pp_timing_t f;
} mp2_i3c0_scl_i3c_pp_timing_u;


/*
 * MP2_I3C0_SCL_I2C_FM_TIMING struct
 */

#define MP2_I3C0_SCL_I2C_FM_TIMING_REG_SIZE 32
#define MP2_I3C0_SCL_I2C_FM_TIMING_I2C_FM_LCNT_SIZE 16
#define MP2_I3C0_SCL_I2C_FM_TIMING_I2C_FM_HCNT_SIZE 8
#define MP2_I3C0_SCL_I2C_FM_TIMING_RESERVED0_SIZE 8

#define MP2_I3C0_SCL_I2C_FM_TIMING_I2C_FM_LCNT_SHIFT 0
#define MP2_I3C0_SCL_I2C_FM_TIMING_I2C_FM_HCNT_SHIFT 16
#define MP2_I3C0_SCL_I2C_FM_TIMING_RESERVED0_SHIFT 24

#define MP2_I3C0_SCL_I2C_FM_TIMING_I2C_FM_LCNT_MASK 0xffff
#define MP2_I3C0_SCL_I2C_FM_TIMING_I2C_FM_HCNT_MASK 0xff0000
#define MP2_I3C0_SCL_I2C_FM_TIMING_RESERVED0_MASK 0xff000000

#define MP2_I3C0_SCL_I2C_FM_TIMING_MASK \
     (MP2_I3C0_SCL_I2C_FM_TIMING_I2C_FM_LCNT_MASK | \
      MP2_I3C0_SCL_I2C_FM_TIMING_I2C_FM_HCNT_MASK | \
      MP2_I3C0_SCL_I2C_FM_TIMING_RESERVED0_MASK)

#define MP2_I3C0_SCL_I2C_FM_TIMING_DEFAULT 0x00100010

#define MP2_I3C0_SCL_I2C_FM_TIMING_GET_I2C_FM_LCNT(mp2_i3c0_scl_i2c_fm_timing) \
     ((mp2_i3c0_scl_i2c_fm_timing & MP2_I3C0_SCL_I2C_FM_TIMING_I2C_FM_LCNT_MASK) >> MP2_I3C0_SCL_I2C_FM_TIMING_I2C_FM_LCNT_SHIFT)
#define MP2_I3C0_SCL_I2C_FM_TIMING_GET_I2C_FM_HCNT(mp2_i3c0_scl_i2c_fm_timing) \
     ((mp2_i3c0_scl_i2c_fm_timing & MP2_I3C0_SCL_I2C_FM_TIMING_I2C_FM_HCNT_MASK) >> MP2_I3C0_SCL_I2C_FM_TIMING_I2C_FM_HCNT_SHIFT)
#define MP2_I3C0_SCL_I2C_FM_TIMING_GET_RESERVED0(mp2_i3c0_scl_i2c_fm_timing) \
     ((mp2_i3c0_scl_i2c_fm_timing & MP2_I3C0_SCL_I2C_FM_TIMING_RESERVED0_MASK) >> MP2_I3C0_SCL_I2C_FM_TIMING_RESERVED0_SHIFT)

#define MP2_I3C0_SCL_I2C_FM_TIMING_SET_I2C_FM_LCNT(mp2_i3c0_scl_i2c_fm_timing_reg, i2c_fm_lcnt) \
     mp2_i3c0_scl_i2c_fm_timing_reg = (mp2_i3c0_scl_i2c_fm_timing_reg & ~MP2_I3C0_SCL_I2C_FM_TIMING_I2C_FM_LCNT_MASK) | (i2c_fm_lcnt << MP2_I3C0_SCL_I2C_FM_TIMING_I2C_FM_LCNT_SHIFT)
#define MP2_I3C0_SCL_I2C_FM_TIMING_SET_I2C_FM_HCNT(mp2_i3c0_scl_i2c_fm_timing_reg, i2c_fm_hcnt) \
     mp2_i3c0_scl_i2c_fm_timing_reg = (mp2_i3c0_scl_i2c_fm_timing_reg & ~MP2_I3C0_SCL_I2C_FM_TIMING_I2C_FM_HCNT_MASK) | (i2c_fm_hcnt << MP2_I3C0_SCL_I2C_FM_TIMING_I2C_FM_HCNT_SHIFT)
#define MP2_I3C0_SCL_I2C_FM_TIMING_SET_RESERVED0(mp2_i3c0_scl_i2c_fm_timing_reg, reserved0) \
     mp2_i3c0_scl_i2c_fm_timing_reg = (mp2_i3c0_scl_i2c_fm_timing_reg & ~MP2_I3C0_SCL_I2C_FM_TIMING_RESERVED0_MASK) | (reserved0 << MP2_I3C0_SCL_I2C_FM_TIMING_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_scl_i2c_fm_timing_t {
          unsigned int i2c_fm_lcnt                    : MP2_I3C0_SCL_I2C_FM_TIMING_I2C_FM_LCNT_SIZE;
          unsigned int i2c_fm_hcnt                    : MP2_I3C0_SCL_I2C_FM_TIMING_I2C_FM_HCNT_SIZE;
          unsigned int reserved0                      : MP2_I3C0_SCL_I2C_FM_TIMING_RESERVED0_SIZE;
     } mp2_i3c0_scl_i2c_fm_timing_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_scl_i2c_fm_timing_t {
          unsigned int reserved0                      : MP2_I3C0_SCL_I2C_FM_TIMING_RESERVED0_SIZE;
          unsigned int i2c_fm_hcnt                    : MP2_I3C0_SCL_I2C_FM_TIMING_I2C_FM_HCNT_SIZE;
          unsigned int i2c_fm_lcnt                    : MP2_I3C0_SCL_I2C_FM_TIMING_I2C_FM_LCNT_SIZE;
     } mp2_i3c0_scl_i2c_fm_timing_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_scl_i2c_fm_timing_t f;
} mp2_i3c0_scl_i2c_fm_timing_u;


/*
 * MP2_I3C0_SCL_I2C_FMP_TIMING struct
 */

#define MP2_I3C0_SCL_I2C_FMP_TIMING_REG_SIZE 32
#define MP2_I3C0_SCL_I2C_FMP_TIMING_I2C_FMP_LCNT_SIZE 8
#define MP2_I3C0_SCL_I2C_FMP_TIMING_RESERVED1_SIZE 8
#define MP2_I3C0_SCL_I2C_FMP_TIMING_I2C_FMP_HCNT_SIZE 8
#define MP2_I3C0_SCL_I2C_FMP_TIMING_RESERVED0_SIZE 8

#define MP2_I3C0_SCL_I2C_FMP_TIMING_I2C_FMP_LCNT_SHIFT 0
#define MP2_I3C0_SCL_I2C_FMP_TIMING_RESERVED1_SHIFT 8
#define MP2_I3C0_SCL_I2C_FMP_TIMING_I2C_FMP_HCNT_SHIFT 16
#define MP2_I3C0_SCL_I2C_FMP_TIMING_RESERVED0_SHIFT 24

#define MP2_I3C0_SCL_I2C_FMP_TIMING_I2C_FMP_LCNT_MASK 0xff
#define MP2_I3C0_SCL_I2C_FMP_TIMING_RESERVED1_MASK 0xff00
#define MP2_I3C0_SCL_I2C_FMP_TIMING_I2C_FMP_HCNT_MASK 0xff0000
#define MP2_I3C0_SCL_I2C_FMP_TIMING_RESERVED0_MASK 0xff000000

#define MP2_I3C0_SCL_I2C_FMP_TIMING_MASK \
     (MP2_I3C0_SCL_I2C_FMP_TIMING_I2C_FMP_LCNT_MASK | \
      MP2_I3C0_SCL_I2C_FMP_TIMING_RESERVED1_MASK | \
      MP2_I3C0_SCL_I2C_FMP_TIMING_I2C_FMP_HCNT_MASK | \
      MP2_I3C0_SCL_I2C_FMP_TIMING_RESERVED0_MASK)

#define MP2_I3C0_SCL_I2C_FMP_TIMING_DEFAULT 0x00100010

#define MP2_I3C0_SCL_I2C_FMP_TIMING_GET_I2C_FMP_LCNT(mp2_i3c0_scl_i2c_fmp_timing) \
     ((mp2_i3c0_scl_i2c_fmp_timing & MP2_I3C0_SCL_I2C_FMP_TIMING_I2C_FMP_LCNT_MASK) >> MP2_I3C0_SCL_I2C_FMP_TIMING_I2C_FMP_LCNT_SHIFT)
#define MP2_I3C0_SCL_I2C_FMP_TIMING_GET_RESERVED1(mp2_i3c0_scl_i2c_fmp_timing) \
     ((mp2_i3c0_scl_i2c_fmp_timing & MP2_I3C0_SCL_I2C_FMP_TIMING_RESERVED1_MASK) >> MP2_I3C0_SCL_I2C_FMP_TIMING_RESERVED1_SHIFT)
#define MP2_I3C0_SCL_I2C_FMP_TIMING_GET_I2C_FMP_HCNT(mp2_i3c0_scl_i2c_fmp_timing) \
     ((mp2_i3c0_scl_i2c_fmp_timing & MP2_I3C0_SCL_I2C_FMP_TIMING_I2C_FMP_HCNT_MASK) >> MP2_I3C0_SCL_I2C_FMP_TIMING_I2C_FMP_HCNT_SHIFT)
#define MP2_I3C0_SCL_I2C_FMP_TIMING_GET_RESERVED0(mp2_i3c0_scl_i2c_fmp_timing) \
     ((mp2_i3c0_scl_i2c_fmp_timing & MP2_I3C0_SCL_I2C_FMP_TIMING_RESERVED0_MASK) >> MP2_I3C0_SCL_I2C_FMP_TIMING_RESERVED0_SHIFT)

#define MP2_I3C0_SCL_I2C_FMP_TIMING_SET_I2C_FMP_LCNT(mp2_i3c0_scl_i2c_fmp_timing_reg, i2c_fmp_lcnt) \
     mp2_i3c0_scl_i2c_fmp_timing_reg = (mp2_i3c0_scl_i2c_fmp_timing_reg & ~MP2_I3C0_SCL_I2C_FMP_TIMING_I2C_FMP_LCNT_MASK) | (i2c_fmp_lcnt << MP2_I3C0_SCL_I2C_FMP_TIMING_I2C_FMP_LCNT_SHIFT)
#define MP2_I3C0_SCL_I2C_FMP_TIMING_SET_RESERVED1(mp2_i3c0_scl_i2c_fmp_timing_reg, reserved1) \
     mp2_i3c0_scl_i2c_fmp_timing_reg = (mp2_i3c0_scl_i2c_fmp_timing_reg & ~MP2_I3C0_SCL_I2C_FMP_TIMING_RESERVED1_MASK) | (reserved1 << MP2_I3C0_SCL_I2C_FMP_TIMING_RESERVED1_SHIFT)
#define MP2_I3C0_SCL_I2C_FMP_TIMING_SET_I2C_FMP_HCNT(mp2_i3c0_scl_i2c_fmp_timing_reg, i2c_fmp_hcnt) \
     mp2_i3c0_scl_i2c_fmp_timing_reg = (mp2_i3c0_scl_i2c_fmp_timing_reg & ~MP2_I3C0_SCL_I2C_FMP_TIMING_I2C_FMP_HCNT_MASK) | (i2c_fmp_hcnt << MP2_I3C0_SCL_I2C_FMP_TIMING_I2C_FMP_HCNT_SHIFT)
#define MP2_I3C0_SCL_I2C_FMP_TIMING_SET_RESERVED0(mp2_i3c0_scl_i2c_fmp_timing_reg, reserved0) \
     mp2_i3c0_scl_i2c_fmp_timing_reg = (mp2_i3c0_scl_i2c_fmp_timing_reg & ~MP2_I3C0_SCL_I2C_FMP_TIMING_RESERVED0_MASK) | (reserved0 << MP2_I3C0_SCL_I2C_FMP_TIMING_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_scl_i2c_fmp_timing_t {
          unsigned int i2c_fmp_lcnt                   : MP2_I3C0_SCL_I2C_FMP_TIMING_I2C_FMP_LCNT_SIZE;
          unsigned int reserved1                      : MP2_I3C0_SCL_I2C_FMP_TIMING_RESERVED1_SIZE;
          unsigned int i2c_fmp_hcnt                   : MP2_I3C0_SCL_I2C_FMP_TIMING_I2C_FMP_HCNT_SIZE;
          unsigned int reserved0                      : MP2_I3C0_SCL_I2C_FMP_TIMING_RESERVED0_SIZE;
     } mp2_i3c0_scl_i2c_fmp_timing_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_scl_i2c_fmp_timing_t {
          unsigned int reserved0                      : MP2_I3C0_SCL_I2C_FMP_TIMING_RESERVED0_SIZE;
          unsigned int i2c_fmp_hcnt                   : MP2_I3C0_SCL_I2C_FMP_TIMING_I2C_FMP_HCNT_SIZE;
          unsigned int reserved1                      : MP2_I3C0_SCL_I2C_FMP_TIMING_RESERVED1_SIZE;
          unsigned int i2c_fmp_lcnt                   : MP2_I3C0_SCL_I2C_FMP_TIMING_I2C_FMP_LCNT_SIZE;
     } mp2_i3c0_scl_i2c_fmp_timing_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_scl_i2c_fmp_timing_t f;
} mp2_i3c0_scl_i2c_fmp_timing_u;


/*
 * MP2_I3C0_SCL_I2C_SS_TIMING struct
 */

#define MP2_I3C0_SCL_I2C_SS_TIMING_REG_SIZE 32
#define MP2_I3C0_SCL_I2C_SS_TIMING_I2C_SS_LCNT_SIZE 16
#define MP2_I3C0_SCL_I2C_SS_TIMING_I2C_SS_HCNT_SIZE 16

#define MP2_I3C0_SCL_I2C_SS_TIMING_I2C_SS_LCNT_SHIFT 0
#define MP2_I3C0_SCL_I2C_SS_TIMING_I2C_SS_HCNT_SHIFT 16

#define MP2_I3C0_SCL_I2C_SS_TIMING_I2C_SS_LCNT_MASK 0xffff
#define MP2_I3C0_SCL_I2C_SS_TIMING_I2C_SS_HCNT_MASK 0xffff0000

#define MP2_I3C0_SCL_I2C_SS_TIMING_MASK \
     (MP2_I3C0_SCL_I2C_SS_TIMING_I2C_SS_LCNT_MASK | \
      MP2_I3C0_SCL_I2C_SS_TIMING_I2C_SS_HCNT_MASK)

#define MP2_I3C0_SCL_I2C_SS_TIMING_DEFAULT 0x00100010

#define MP2_I3C0_SCL_I2C_SS_TIMING_GET_I2C_SS_LCNT(mp2_i3c0_scl_i2c_ss_timing) \
     ((mp2_i3c0_scl_i2c_ss_timing & MP2_I3C0_SCL_I2C_SS_TIMING_I2C_SS_LCNT_MASK) >> MP2_I3C0_SCL_I2C_SS_TIMING_I2C_SS_LCNT_SHIFT)
#define MP2_I3C0_SCL_I2C_SS_TIMING_GET_I2C_SS_HCNT(mp2_i3c0_scl_i2c_ss_timing) \
     ((mp2_i3c0_scl_i2c_ss_timing & MP2_I3C0_SCL_I2C_SS_TIMING_I2C_SS_HCNT_MASK) >> MP2_I3C0_SCL_I2C_SS_TIMING_I2C_SS_HCNT_SHIFT)

#define MP2_I3C0_SCL_I2C_SS_TIMING_SET_I2C_SS_LCNT(mp2_i3c0_scl_i2c_ss_timing_reg, i2c_ss_lcnt) \
     mp2_i3c0_scl_i2c_ss_timing_reg = (mp2_i3c0_scl_i2c_ss_timing_reg & ~MP2_I3C0_SCL_I2C_SS_TIMING_I2C_SS_LCNT_MASK) | (i2c_ss_lcnt << MP2_I3C0_SCL_I2C_SS_TIMING_I2C_SS_LCNT_SHIFT)
#define MP2_I3C0_SCL_I2C_SS_TIMING_SET_I2C_SS_HCNT(mp2_i3c0_scl_i2c_ss_timing_reg, i2c_ss_hcnt) \
     mp2_i3c0_scl_i2c_ss_timing_reg = (mp2_i3c0_scl_i2c_ss_timing_reg & ~MP2_I3C0_SCL_I2C_SS_TIMING_I2C_SS_HCNT_MASK) | (i2c_ss_hcnt << MP2_I3C0_SCL_I2C_SS_TIMING_I2C_SS_HCNT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_scl_i2c_ss_timing_t {
          unsigned int i2c_ss_lcnt                    : MP2_I3C0_SCL_I2C_SS_TIMING_I2C_SS_LCNT_SIZE;
          unsigned int i2c_ss_hcnt                    : MP2_I3C0_SCL_I2C_SS_TIMING_I2C_SS_HCNT_SIZE;
     } mp2_i3c0_scl_i2c_ss_timing_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_scl_i2c_ss_timing_t {
          unsigned int i2c_ss_hcnt                    : MP2_I3C0_SCL_I2C_SS_TIMING_I2C_SS_HCNT_SIZE;
          unsigned int i2c_ss_lcnt                    : MP2_I3C0_SCL_I2C_SS_TIMING_I2C_SS_LCNT_SIZE;
     } mp2_i3c0_scl_i2c_ss_timing_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_scl_i2c_ss_timing_t f;
} mp2_i3c0_scl_i2c_ss_timing_u;


/*
 * MP2_I3C0_SCL_EXT_LCNT_TIMING struct
 */

#define MP2_I3C0_SCL_EXT_LCNT_TIMING_REG_SIZE 32
#define MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_1_SIZE 8
#define MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_2_SIZE 8
#define MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_3_SIZE 8
#define MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_4_SIZE 8

#define MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_1_SHIFT 0
#define MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_2_SHIFT 8
#define MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_3_SHIFT 16
#define MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_4_SHIFT 24

#define MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_1_MASK 0xff
#define MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_2_MASK 0xff00
#define MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_3_MASK 0xff0000
#define MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_4_MASK 0xff000000

#define MP2_I3C0_SCL_EXT_LCNT_TIMING_MASK \
     (MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_1_MASK | \
      MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_2_MASK | \
      MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_3_MASK | \
      MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_4_MASK)

#define MP2_I3C0_SCL_EXT_LCNT_TIMING_DEFAULT 0x20202020

#define MP2_I3C0_SCL_EXT_LCNT_TIMING_GET_I3C_EXT_LCNT_1(mp2_i3c0_scl_ext_lcnt_timing) \
     ((mp2_i3c0_scl_ext_lcnt_timing & MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_1_MASK) >> MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_1_SHIFT)
#define MP2_I3C0_SCL_EXT_LCNT_TIMING_GET_I3C_EXT_LCNT_2(mp2_i3c0_scl_ext_lcnt_timing) \
     ((mp2_i3c0_scl_ext_lcnt_timing & MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_2_MASK) >> MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_2_SHIFT)
#define MP2_I3C0_SCL_EXT_LCNT_TIMING_GET_I3C_EXT_LCNT_3(mp2_i3c0_scl_ext_lcnt_timing) \
     ((mp2_i3c0_scl_ext_lcnt_timing & MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_3_MASK) >> MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_3_SHIFT)
#define MP2_I3C0_SCL_EXT_LCNT_TIMING_GET_I3C_EXT_LCNT_4(mp2_i3c0_scl_ext_lcnt_timing) \
     ((mp2_i3c0_scl_ext_lcnt_timing & MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_4_MASK) >> MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_4_SHIFT)

#define MP2_I3C0_SCL_EXT_LCNT_TIMING_SET_I3C_EXT_LCNT_1(mp2_i3c0_scl_ext_lcnt_timing_reg, i3c_ext_lcnt_1) \
     mp2_i3c0_scl_ext_lcnt_timing_reg = (mp2_i3c0_scl_ext_lcnt_timing_reg & ~MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_1_MASK) | (i3c_ext_lcnt_1 << MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_1_SHIFT)
#define MP2_I3C0_SCL_EXT_LCNT_TIMING_SET_I3C_EXT_LCNT_2(mp2_i3c0_scl_ext_lcnt_timing_reg, i3c_ext_lcnt_2) \
     mp2_i3c0_scl_ext_lcnt_timing_reg = (mp2_i3c0_scl_ext_lcnt_timing_reg & ~MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_2_MASK) | (i3c_ext_lcnt_2 << MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_2_SHIFT)
#define MP2_I3C0_SCL_EXT_LCNT_TIMING_SET_I3C_EXT_LCNT_3(mp2_i3c0_scl_ext_lcnt_timing_reg, i3c_ext_lcnt_3) \
     mp2_i3c0_scl_ext_lcnt_timing_reg = (mp2_i3c0_scl_ext_lcnt_timing_reg & ~MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_3_MASK) | (i3c_ext_lcnt_3 << MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_3_SHIFT)
#define MP2_I3C0_SCL_EXT_LCNT_TIMING_SET_I3C_EXT_LCNT_4(mp2_i3c0_scl_ext_lcnt_timing_reg, i3c_ext_lcnt_4) \
     mp2_i3c0_scl_ext_lcnt_timing_reg = (mp2_i3c0_scl_ext_lcnt_timing_reg & ~MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_4_MASK) | (i3c_ext_lcnt_4 << MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_4_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_scl_ext_lcnt_timing_t {
          unsigned int i3c_ext_lcnt_1                 : MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_1_SIZE;
          unsigned int i3c_ext_lcnt_2                 : MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_2_SIZE;
          unsigned int i3c_ext_lcnt_3                 : MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_3_SIZE;
          unsigned int i3c_ext_lcnt_4                 : MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_4_SIZE;
     } mp2_i3c0_scl_ext_lcnt_timing_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_scl_ext_lcnt_timing_t {
          unsigned int i3c_ext_lcnt_4                 : MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_4_SIZE;
          unsigned int i3c_ext_lcnt_3                 : MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_3_SIZE;
          unsigned int i3c_ext_lcnt_2                 : MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_2_SIZE;
          unsigned int i3c_ext_lcnt_1                 : MP2_I3C0_SCL_EXT_LCNT_TIMING_I3C_EXT_LCNT_1_SIZE;
     } mp2_i3c0_scl_ext_lcnt_timing_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_scl_ext_lcnt_timing_t f;
} mp2_i3c0_scl_ext_lcnt_timing_u;


/*
 * MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING struct
 */

#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_REG_SIZE 32
#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_I3C_EXT_TERMN_LCNT_SIZE 4
#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_RESERVED1_SIZE 12
#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_I3C_TS_SKEW_CNT_SIZE 4
#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_RESERVED0_SIZE 12

#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_I3C_EXT_TERMN_LCNT_SHIFT 0
#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_RESERVED1_SHIFT 4
#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_I3C_TS_SKEW_CNT_SHIFT 16
#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_RESERVED0_SHIFT 20

#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_I3C_EXT_TERMN_LCNT_MASK 0xf
#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_RESERVED1_MASK 0xfff0
#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_I3C_TS_SKEW_CNT_MASK 0xf0000
#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_RESERVED0_MASK 0xfff00000

#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_MASK \
     (MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_I3C_EXT_TERMN_LCNT_MASK | \
      MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_RESERVED1_MASK | \
      MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_I3C_TS_SKEW_CNT_MASK | \
      MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_RESERVED0_MASK)

#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_DEFAULT 0x00030000

#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_GET_I3C_EXT_TERMN_LCNT(mp2_i3c0_scl_ext_termn_lcnt_timing) \
     ((mp2_i3c0_scl_ext_termn_lcnt_timing & MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_I3C_EXT_TERMN_LCNT_MASK) >> MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_I3C_EXT_TERMN_LCNT_SHIFT)
#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_GET_RESERVED1(mp2_i3c0_scl_ext_termn_lcnt_timing) \
     ((mp2_i3c0_scl_ext_termn_lcnt_timing & MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_RESERVED1_MASK) >> MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_RESERVED1_SHIFT)
#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_GET_I3C_TS_SKEW_CNT(mp2_i3c0_scl_ext_termn_lcnt_timing) \
     ((mp2_i3c0_scl_ext_termn_lcnt_timing & MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_I3C_TS_SKEW_CNT_MASK) >> MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_I3C_TS_SKEW_CNT_SHIFT)
#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_GET_RESERVED0(mp2_i3c0_scl_ext_termn_lcnt_timing) \
     ((mp2_i3c0_scl_ext_termn_lcnt_timing & MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_RESERVED0_MASK) >> MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_RESERVED0_SHIFT)

#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_SET_I3C_EXT_TERMN_LCNT(mp2_i3c0_scl_ext_termn_lcnt_timing_reg, i3c_ext_termn_lcnt) \
     mp2_i3c0_scl_ext_termn_lcnt_timing_reg = (mp2_i3c0_scl_ext_termn_lcnt_timing_reg & ~MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_I3C_EXT_TERMN_LCNT_MASK) | (i3c_ext_termn_lcnt << MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_I3C_EXT_TERMN_LCNT_SHIFT)
#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_SET_RESERVED1(mp2_i3c0_scl_ext_termn_lcnt_timing_reg, reserved1) \
     mp2_i3c0_scl_ext_termn_lcnt_timing_reg = (mp2_i3c0_scl_ext_termn_lcnt_timing_reg & ~MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_RESERVED1_MASK) | (reserved1 << MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_RESERVED1_SHIFT)
#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_SET_I3C_TS_SKEW_CNT(mp2_i3c0_scl_ext_termn_lcnt_timing_reg, i3c_ts_skew_cnt) \
     mp2_i3c0_scl_ext_termn_lcnt_timing_reg = (mp2_i3c0_scl_ext_termn_lcnt_timing_reg & ~MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_I3C_TS_SKEW_CNT_MASK) | (i3c_ts_skew_cnt << MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_I3C_TS_SKEW_CNT_SHIFT)
#define MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_SET_RESERVED0(mp2_i3c0_scl_ext_termn_lcnt_timing_reg, reserved0) \
     mp2_i3c0_scl_ext_termn_lcnt_timing_reg = (mp2_i3c0_scl_ext_termn_lcnt_timing_reg & ~MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_RESERVED0_MASK) | (reserved0 << MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_scl_ext_termn_lcnt_timing_t {
          unsigned int i3c_ext_termn_lcnt             : MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_I3C_EXT_TERMN_LCNT_SIZE;
          unsigned int reserved1                      : MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_RESERVED1_SIZE;
          unsigned int i3c_ts_skew_cnt                : MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_I3C_TS_SKEW_CNT_SIZE;
          unsigned int reserved0                      : MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_RESERVED0_SIZE;
     } mp2_i3c0_scl_ext_termn_lcnt_timing_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_scl_ext_termn_lcnt_timing_t {
          unsigned int reserved0                      : MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_RESERVED0_SIZE;
          unsigned int i3c_ts_skew_cnt                : MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_I3C_TS_SKEW_CNT_SIZE;
          unsigned int reserved1                      : MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_RESERVED1_SIZE;
          unsigned int i3c_ext_termn_lcnt             : MP2_I3C0_SCL_EXT_TERMN_LCNT_TIMING_I3C_EXT_TERMN_LCNT_SIZE;
     } mp2_i3c0_scl_ext_termn_lcnt_timing_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_scl_ext_termn_lcnt_timing_t f;
} mp2_i3c0_scl_ext_termn_lcnt_timing_u;


/*
 * MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING struct
 */

#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_REG_SIZE 32
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_OD_PP_SWITCH_DLY_SIZE 3
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED2_SIZE 5
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_PP_OD_SWITCH_DLY_SIZE 3
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED1_SIZE 5
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_TX_HOLD_SIZE 3
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED0_SIZE 13

#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_OD_PP_SWITCH_DLY_SHIFT 0
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED2_SHIFT 3
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_PP_OD_SWITCH_DLY_SHIFT 8
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED1_SHIFT 11
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_TX_HOLD_SHIFT 16
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED0_SHIFT 19

#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_OD_PP_SWITCH_DLY_MASK 0x7
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED2_MASK 0xf8
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_PP_OD_SWITCH_DLY_MASK 0x700
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED1_MASK 0xf800
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_TX_HOLD_MASK 0x70000
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED0_MASK 0xfff80000

#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_MASK \
     (MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_OD_PP_SWITCH_DLY_MASK | \
      MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED2_MASK | \
      MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_PP_OD_SWITCH_DLY_MASK | \
      MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED1_MASK | \
      MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_TX_HOLD_MASK | \
      MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED0_MASK)

#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_DEFAULT 0x00010000

#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_GET_SDA_OD_PP_SWITCH_DLY(mp2_i3c0_sda_hold_switch_dly_timing) \
     ((mp2_i3c0_sda_hold_switch_dly_timing & MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_OD_PP_SWITCH_DLY_MASK) >> MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_OD_PP_SWITCH_DLY_SHIFT)
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_GET_RESERVED2(mp2_i3c0_sda_hold_switch_dly_timing) \
     ((mp2_i3c0_sda_hold_switch_dly_timing & MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED2_MASK) >> MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED2_SHIFT)
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_GET_SDA_PP_OD_SWITCH_DLY(mp2_i3c0_sda_hold_switch_dly_timing) \
     ((mp2_i3c0_sda_hold_switch_dly_timing & MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_PP_OD_SWITCH_DLY_MASK) >> MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_PP_OD_SWITCH_DLY_SHIFT)
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_GET_RESERVED1(mp2_i3c0_sda_hold_switch_dly_timing) \
     ((mp2_i3c0_sda_hold_switch_dly_timing & MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED1_MASK) >> MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED1_SHIFT)
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_GET_SDA_TX_HOLD(mp2_i3c0_sda_hold_switch_dly_timing) \
     ((mp2_i3c0_sda_hold_switch_dly_timing & MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_TX_HOLD_MASK) >> MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_TX_HOLD_SHIFT)
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_GET_RESERVED0(mp2_i3c0_sda_hold_switch_dly_timing) \
     ((mp2_i3c0_sda_hold_switch_dly_timing & MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED0_MASK) >> MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED0_SHIFT)

#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SET_SDA_OD_PP_SWITCH_DLY(mp2_i3c0_sda_hold_switch_dly_timing_reg, sda_od_pp_switch_dly) \
     mp2_i3c0_sda_hold_switch_dly_timing_reg = (mp2_i3c0_sda_hold_switch_dly_timing_reg & ~MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_OD_PP_SWITCH_DLY_MASK) | (sda_od_pp_switch_dly << MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_OD_PP_SWITCH_DLY_SHIFT)
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SET_RESERVED2(mp2_i3c0_sda_hold_switch_dly_timing_reg, reserved2) \
     mp2_i3c0_sda_hold_switch_dly_timing_reg = (mp2_i3c0_sda_hold_switch_dly_timing_reg & ~MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED2_MASK) | (reserved2 << MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED2_SHIFT)
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SET_SDA_PP_OD_SWITCH_DLY(mp2_i3c0_sda_hold_switch_dly_timing_reg, sda_pp_od_switch_dly) \
     mp2_i3c0_sda_hold_switch_dly_timing_reg = (mp2_i3c0_sda_hold_switch_dly_timing_reg & ~MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_PP_OD_SWITCH_DLY_MASK) | (sda_pp_od_switch_dly << MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_PP_OD_SWITCH_DLY_SHIFT)
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SET_RESERVED1(mp2_i3c0_sda_hold_switch_dly_timing_reg, reserved1) \
     mp2_i3c0_sda_hold_switch_dly_timing_reg = (mp2_i3c0_sda_hold_switch_dly_timing_reg & ~MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED1_MASK) | (reserved1 << MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED1_SHIFT)
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SET_SDA_TX_HOLD(mp2_i3c0_sda_hold_switch_dly_timing_reg, sda_tx_hold) \
     mp2_i3c0_sda_hold_switch_dly_timing_reg = (mp2_i3c0_sda_hold_switch_dly_timing_reg & ~MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_TX_HOLD_MASK) | (sda_tx_hold << MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_TX_HOLD_SHIFT)
#define MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SET_RESERVED0(mp2_i3c0_sda_hold_switch_dly_timing_reg, reserved0) \
     mp2_i3c0_sda_hold_switch_dly_timing_reg = (mp2_i3c0_sda_hold_switch_dly_timing_reg & ~MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED0_MASK) | (reserved0 << MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_sda_hold_switch_dly_timing_t {
          unsigned int sda_od_pp_switch_dly           : MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_OD_PP_SWITCH_DLY_SIZE;
          unsigned int reserved2                      : MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED2_SIZE;
          unsigned int sda_pp_od_switch_dly           : MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_PP_OD_SWITCH_DLY_SIZE;
          unsigned int reserved1                      : MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED1_SIZE;
          unsigned int sda_tx_hold                    : MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_TX_HOLD_SIZE;
          unsigned int reserved0                      : MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED0_SIZE;
     } mp2_i3c0_sda_hold_switch_dly_timing_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_sda_hold_switch_dly_timing_t {
          unsigned int reserved0                      : MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED0_SIZE;
          unsigned int sda_tx_hold                    : MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_TX_HOLD_SIZE;
          unsigned int reserved1                      : MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED1_SIZE;
          unsigned int sda_pp_od_switch_dly           : MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_PP_OD_SWITCH_DLY_SIZE;
          unsigned int reserved2                      : MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_RESERVED2_SIZE;
          unsigned int sda_od_pp_switch_dly           : MP2_I3C0_SDA_HOLD_SWITCH_DLY_TIMING_SDA_OD_PP_SWITCH_DLY_SIZE;
     } mp2_i3c0_sda_hold_switch_dly_timing_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_sda_hold_switch_dly_timing_t f;
} mp2_i3c0_sda_hold_switch_dly_timing_u;


/*
 * MP2_I3C0_BUS_FREE_TIMING struct
 */

#define MP2_I3C0_BUS_FREE_TIMING_REG_SIZE 32
#define MP2_I3C0_BUS_FREE_TIMING_I3C_MST_FREE_SIZE 16
#define MP2_I3C0_BUS_FREE_TIMING_RESERVED0_SIZE 16

#define MP2_I3C0_BUS_FREE_TIMING_I3C_MST_FREE_SHIFT 0
#define MP2_I3C0_BUS_FREE_TIMING_RESERVED0_SHIFT 16

#define MP2_I3C0_BUS_FREE_TIMING_I3C_MST_FREE_MASK 0xffff
#define MP2_I3C0_BUS_FREE_TIMING_RESERVED0_MASK 0xffff0000

#define MP2_I3C0_BUS_FREE_TIMING_MASK \
     (MP2_I3C0_BUS_FREE_TIMING_I3C_MST_FREE_MASK | \
      MP2_I3C0_BUS_FREE_TIMING_RESERVED0_MASK)

#define MP2_I3C0_BUS_FREE_TIMING_DEFAULT 0x00000020

#define MP2_I3C0_BUS_FREE_TIMING_GET_I3C_MST_FREE(mp2_i3c0_bus_free_timing) \
     ((mp2_i3c0_bus_free_timing & MP2_I3C0_BUS_FREE_TIMING_I3C_MST_FREE_MASK) >> MP2_I3C0_BUS_FREE_TIMING_I3C_MST_FREE_SHIFT)
#define MP2_I3C0_BUS_FREE_TIMING_GET_RESERVED0(mp2_i3c0_bus_free_timing) \
     ((mp2_i3c0_bus_free_timing & MP2_I3C0_BUS_FREE_TIMING_RESERVED0_MASK) >> MP2_I3C0_BUS_FREE_TIMING_RESERVED0_SHIFT)

#define MP2_I3C0_BUS_FREE_TIMING_SET_I3C_MST_FREE(mp2_i3c0_bus_free_timing_reg, i3c_mst_free) \
     mp2_i3c0_bus_free_timing_reg = (mp2_i3c0_bus_free_timing_reg & ~MP2_I3C0_BUS_FREE_TIMING_I3C_MST_FREE_MASK) | (i3c_mst_free << MP2_I3C0_BUS_FREE_TIMING_I3C_MST_FREE_SHIFT)
#define MP2_I3C0_BUS_FREE_TIMING_SET_RESERVED0(mp2_i3c0_bus_free_timing_reg, reserved0) \
     mp2_i3c0_bus_free_timing_reg = (mp2_i3c0_bus_free_timing_reg & ~MP2_I3C0_BUS_FREE_TIMING_RESERVED0_MASK) | (reserved0 << MP2_I3C0_BUS_FREE_TIMING_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_bus_free_timing_t {
          unsigned int i3c_mst_free                   : MP2_I3C0_BUS_FREE_TIMING_I3C_MST_FREE_SIZE;
          unsigned int reserved0                      : MP2_I3C0_BUS_FREE_TIMING_RESERVED0_SIZE;
     } mp2_i3c0_bus_free_timing_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_bus_free_timing_t {
          unsigned int reserved0                      : MP2_I3C0_BUS_FREE_TIMING_RESERVED0_SIZE;
          unsigned int i3c_mst_free                   : MP2_I3C0_BUS_FREE_TIMING_I3C_MST_FREE_SIZE;
     } mp2_i3c0_bus_free_timing_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_bus_free_timing_t f;
} mp2_i3c0_bus_free_timing_u;


/*
 * MP2_I3C0_DS_EXTCAP_HEADER struct
 */

#define MP2_I3C0_DS_EXTCAP_HEADER_REG_SIZE 32
#define MP2_I3C0_DS_EXTCAP_HEADER_CAP_ID_SIZE 8
#define MP2_I3C0_DS_EXTCAP_HEADER_CAP_LEN_SIZE 16
#define MP2_I3C0_DS_EXTCAP_HEADER_RESERVED0_SIZE 8

#define MP2_I3C0_DS_EXTCAP_HEADER_CAP_ID_SHIFT 0
#define MP2_I3C0_DS_EXTCAP_HEADER_CAP_LEN_SHIFT 8
#define MP2_I3C0_DS_EXTCAP_HEADER_RESERVED0_SHIFT 24

#define MP2_I3C0_DS_EXTCAP_HEADER_CAP_ID_MASK 0xff
#define MP2_I3C0_DS_EXTCAP_HEADER_CAP_LEN_MASK 0xffff00
#define MP2_I3C0_DS_EXTCAP_HEADER_RESERVED0_MASK 0xff000000

#define MP2_I3C0_DS_EXTCAP_HEADER_MASK \
     (MP2_I3C0_DS_EXTCAP_HEADER_CAP_ID_MASK | \
      MP2_I3C0_DS_EXTCAP_HEADER_CAP_LEN_MASK | \
      MP2_I3C0_DS_EXTCAP_HEADER_RESERVED0_MASK)

#define MP2_I3C0_DS_EXTCAP_HEADER_DEFAULT 0x0000050c

#define MP2_I3C0_DS_EXTCAP_HEADER_GET_CAP_ID(mp2_i3c0_ds_extcap_header) \
     ((mp2_i3c0_ds_extcap_header & MP2_I3C0_DS_EXTCAP_HEADER_CAP_ID_MASK) >> MP2_I3C0_DS_EXTCAP_HEADER_CAP_ID_SHIFT)
#define MP2_I3C0_DS_EXTCAP_HEADER_GET_CAP_LEN(mp2_i3c0_ds_extcap_header) \
     ((mp2_i3c0_ds_extcap_header & MP2_I3C0_DS_EXTCAP_HEADER_CAP_LEN_MASK) >> MP2_I3C0_DS_EXTCAP_HEADER_CAP_LEN_SHIFT)
#define MP2_I3C0_DS_EXTCAP_HEADER_GET_RESERVED0(mp2_i3c0_ds_extcap_header) \
     ((mp2_i3c0_ds_extcap_header & MP2_I3C0_DS_EXTCAP_HEADER_RESERVED0_MASK) >> MP2_I3C0_DS_EXTCAP_HEADER_RESERVED0_SHIFT)

#define MP2_I3C0_DS_EXTCAP_HEADER_SET_CAP_ID(mp2_i3c0_ds_extcap_header_reg, cap_id) \
     mp2_i3c0_ds_extcap_header_reg = (mp2_i3c0_ds_extcap_header_reg & ~MP2_I3C0_DS_EXTCAP_HEADER_CAP_ID_MASK) | (cap_id << MP2_I3C0_DS_EXTCAP_HEADER_CAP_ID_SHIFT)
#define MP2_I3C0_DS_EXTCAP_HEADER_SET_CAP_LEN(mp2_i3c0_ds_extcap_header_reg, cap_len) \
     mp2_i3c0_ds_extcap_header_reg = (mp2_i3c0_ds_extcap_header_reg & ~MP2_I3C0_DS_EXTCAP_HEADER_CAP_LEN_MASK) | (cap_len << MP2_I3C0_DS_EXTCAP_HEADER_CAP_LEN_SHIFT)
#define MP2_I3C0_DS_EXTCAP_HEADER_SET_RESERVED0(mp2_i3c0_ds_extcap_header_reg, reserved0) \
     mp2_i3c0_ds_extcap_header_reg = (mp2_i3c0_ds_extcap_header_reg & ~MP2_I3C0_DS_EXTCAP_HEADER_RESERVED0_MASK) | (reserved0 << MP2_I3C0_DS_EXTCAP_HEADER_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_ds_extcap_header_t {
          unsigned int cap_id                         : MP2_I3C0_DS_EXTCAP_HEADER_CAP_ID_SIZE;
          unsigned int cap_len                        : MP2_I3C0_DS_EXTCAP_HEADER_CAP_LEN_SIZE;
          unsigned int reserved0                      : MP2_I3C0_DS_EXTCAP_HEADER_RESERVED0_SIZE;
     } mp2_i3c0_ds_extcap_header_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_ds_extcap_header_t {
          unsigned int reserved0                      : MP2_I3C0_DS_EXTCAP_HEADER_RESERVED0_SIZE;
          unsigned int cap_len                        : MP2_I3C0_DS_EXTCAP_HEADER_CAP_LEN_SIZE;
          unsigned int cap_id                         : MP2_I3C0_DS_EXTCAP_HEADER_CAP_ID_SIZE;
     } mp2_i3c0_ds_extcap_header_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_ds_extcap_header_t f;
} mp2_i3c0_ds_extcap_header_u;


/*
 * MP2_I3C0_QUEUE_STATUS_LEVEL struct
 */

#define MP2_I3C0_QUEUE_STATUS_LEVEL_REG_SIZE 32
#define MP2_I3C0_QUEUE_STATUS_LEVEL_CMD_QUEUE_FREE_LVL_SIZE 8
#define MP2_I3C0_QUEUE_STATUS_LEVEL_RESP_BUF_BLR_SIZE 8
#define MP2_I3C0_QUEUE_STATUS_LEVEL_IBI_BUF_BLR_SIZE 8
#define MP2_I3C0_QUEUE_STATUS_LEVEL_IBI_STATUS_CNT_SIZE 5
#define MP2_I3C0_QUEUE_STATUS_LEVEL_RESERVED0_SIZE 3

#define MP2_I3C0_QUEUE_STATUS_LEVEL_CMD_QUEUE_FREE_LVL_SHIFT 0
#define MP2_I3C0_QUEUE_STATUS_LEVEL_RESP_BUF_BLR_SHIFT 8
#define MP2_I3C0_QUEUE_STATUS_LEVEL_IBI_BUF_BLR_SHIFT 16
#define MP2_I3C0_QUEUE_STATUS_LEVEL_IBI_STATUS_CNT_SHIFT 24
#define MP2_I3C0_QUEUE_STATUS_LEVEL_RESERVED0_SHIFT 29

#define MP2_I3C0_QUEUE_STATUS_LEVEL_CMD_QUEUE_FREE_LVL_MASK 0xff
#define MP2_I3C0_QUEUE_STATUS_LEVEL_RESP_BUF_BLR_MASK 0xff00
#define MP2_I3C0_QUEUE_STATUS_LEVEL_IBI_BUF_BLR_MASK 0xff0000
#define MP2_I3C0_QUEUE_STATUS_LEVEL_IBI_STATUS_CNT_MASK 0x1f000000
#define MP2_I3C0_QUEUE_STATUS_LEVEL_RESERVED0_MASK 0xe0000000

#define MP2_I3C0_QUEUE_STATUS_LEVEL_MASK \
     (MP2_I3C0_QUEUE_STATUS_LEVEL_CMD_QUEUE_FREE_LVL_MASK | \
      MP2_I3C0_QUEUE_STATUS_LEVEL_RESP_BUF_BLR_MASK | \
      MP2_I3C0_QUEUE_STATUS_LEVEL_IBI_BUF_BLR_MASK | \
      MP2_I3C0_QUEUE_STATUS_LEVEL_IBI_STATUS_CNT_MASK | \
      MP2_I3C0_QUEUE_STATUS_LEVEL_RESERVED0_MASK)

#define MP2_I3C0_QUEUE_STATUS_LEVEL_DEFAULT 0x00000010

#define MP2_I3C0_QUEUE_STATUS_LEVEL_GET_CMD_QUEUE_FREE_LVL(mp2_i3c0_queue_status_level) \
     ((mp2_i3c0_queue_status_level & MP2_I3C0_QUEUE_STATUS_LEVEL_CMD_QUEUE_FREE_LVL_MASK) >> MP2_I3C0_QUEUE_STATUS_LEVEL_CMD_QUEUE_FREE_LVL_SHIFT)
#define MP2_I3C0_QUEUE_STATUS_LEVEL_GET_RESP_BUF_BLR(mp2_i3c0_queue_status_level) \
     ((mp2_i3c0_queue_status_level & MP2_I3C0_QUEUE_STATUS_LEVEL_RESP_BUF_BLR_MASK) >> MP2_I3C0_QUEUE_STATUS_LEVEL_RESP_BUF_BLR_SHIFT)
#define MP2_I3C0_QUEUE_STATUS_LEVEL_GET_IBI_BUF_BLR(mp2_i3c0_queue_status_level) \
     ((mp2_i3c0_queue_status_level & MP2_I3C0_QUEUE_STATUS_LEVEL_IBI_BUF_BLR_MASK) >> MP2_I3C0_QUEUE_STATUS_LEVEL_IBI_BUF_BLR_SHIFT)
#define MP2_I3C0_QUEUE_STATUS_LEVEL_GET_IBI_STATUS_CNT(mp2_i3c0_queue_status_level) \
     ((mp2_i3c0_queue_status_level & MP2_I3C0_QUEUE_STATUS_LEVEL_IBI_STATUS_CNT_MASK) >> MP2_I3C0_QUEUE_STATUS_LEVEL_IBI_STATUS_CNT_SHIFT)
#define MP2_I3C0_QUEUE_STATUS_LEVEL_GET_RESERVED0(mp2_i3c0_queue_status_level) \
     ((mp2_i3c0_queue_status_level & MP2_I3C0_QUEUE_STATUS_LEVEL_RESERVED0_MASK) >> MP2_I3C0_QUEUE_STATUS_LEVEL_RESERVED0_SHIFT)

#define MP2_I3C0_QUEUE_STATUS_LEVEL_SET_CMD_QUEUE_FREE_LVL(mp2_i3c0_queue_status_level_reg, cmd_queue_free_lvl) \
     mp2_i3c0_queue_status_level_reg = (mp2_i3c0_queue_status_level_reg & ~MP2_I3C0_QUEUE_STATUS_LEVEL_CMD_QUEUE_FREE_LVL_MASK) | (cmd_queue_free_lvl << MP2_I3C0_QUEUE_STATUS_LEVEL_CMD_QUEUE_FREE_LVL_SHIFT)
#define MP2_I3C0_QUEUE_STATUS_LEVEL_SET_RESP_BUF_BLR(mp2_i3c0_queue_status_level_reg, resp_buf_blr) \
     mp2_i3c0_queue_status_level_reg = (mp2_i3c0_queue_status_level_reg & ~MP2_I3C0_QUEUE_STATUS_LEVEL_RESP_BUF_BLR_MASK) | (resp_buf_blr << MP2_I3C0_QUEUE_STATUS_LEVEL_RESP_BUF_BLR_SHIFT)
#define MP2_I3C0_QUEUE_STATUS_LEVEL_SET_IBI_BUF_BLR(mp2_i3c0_queue_status_level_reg, ibi_buf_blr) \
     mp2_i3c0_queue_status_level_reg = (mp2_i3c0_queue_status_level_reg & ~MP2_I3C0_QUEUE_STATUS_LEVEL_IBI_BUF_BLR_MASK) | (ibi_buf_blr << MP2_I3C0_QUEUE_STATUS_LEVEL_IBI_BUF_BLR_SHIFT)
#define MP2_I3C0_QUEUE_STATUS_LEVEL_SET_IBI_STATUS_CNT(mp2_i3c0_queue_status_level_reg, ibi_status_cnt) \
     mp2_i3c0_queue_status_level_reg = (mp2_i3c0_queue_status_level_reg & ~MP2_I3C0_QUEUE_STATUS_LEVEL_IBI_STATUS_CNT_MASK) | (ibi_status_cnt << MP2_I3C0_QUEUE_STATUS_LEVEL_IBI_STATUS_CNT_SHIFT)
#define MP2_I3C0_QUEUE_STATUS_LEVEL_SET_RESERVED0(mp2_i3c0_queue_status_level_reg, reserved0) \
     mp2_i3c0_queue_status_level_reg = (mp2_i3c0_queue_status_level_reg & ~MP2_I3C0_QUEUE_STATUS_LEVEL_RESERVED0_MASK) | (reserved0 << MP2_I3C0_QUEUE_STATUS_LEVEL_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_queue_status_level_t {
          unsigned int cmd_queue_free_lvl             : MP2_I3C0_QUEUE_STATUS_LEVEL_CMD_QUEUE_FREE_LVL_SIZE;
          unsigned int resp_buf_blr                   : MP2_I3C0_QUEUE_STATUS_LEVEL_RESP_BUF_BLR_SIZE;
          unsigned int ibi_buf_blr                    : MP2_I3C0_QUEUE_STATUS_LEVEL_IBI_BUF_BLR_SIZE;
          unsigned int ibi_status_cnt                 : MP2_I3C0_QUEUE_STATUS_LEVEL_IBI_STATUS_CNT_SIZE;
          unsigned int reserved0                      : MP2_I3C0_QUEUE_STATUS_LEVEL_RESERVED0_SIZE;
     } mp2_i3c0_queue_status_level_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_queue_status_level_t {
          unsigned int reserved0                      : MP2_I3C0_QUEUE_STATUS_LEVEL_RESERVED0_SIZE;
          unsigned int ibi_status_cnt                 : MP2_I3C0_QUEUE_STATUS_LEVEL_IBI_STATUS_CNT_SIZE;
          unsigned int ibi_buf_blr                    : MP2_I3C0_QUEUE_STATUS_LEVEL_IBI_BUF_BLR_SIZE;
          unsigned int resp_buf_blr                   : MP2_I3C0_QUEUE_STATUS_LEVEL_RESP_BUF_BLR_SIZE;
          unsigned int cmd_queue_free_lvl             : MP2_I3C0_QUEUE_STATUS_LEVEL_CMD_QUEUE_FREE_LVL_SIZE;
     } mp2_i3c0_queue_status_level_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_queue_status_level_t f;
} mp2_i3c0_queue_status_level_u;


/*
 * MP2_I3C0_DATA_BUFFER_STATUS_LEVEL struct
 */

#define MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_REG_SIZE 32
#define MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_TX_BUF_FREE_LVL_SIZE 8
#define MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_RX_BUF_LVL_SIZE 8
#define MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_RESERVED0_SIZE 16

#define MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_TX_BUF_FREE_LVL_SHIFT 0
#define MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_RX_BUF_LVL_SHIFT 8
#define MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_RESERVED0_SHIFT 16

#define MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_TX_BUF_FREE_LVL_MASK 0xff
#define MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_RX_BUF_LVL_MASK 0xff00
#define MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_RESERVED0_MASK 0xffff0000

#define MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_MASK \
     (MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_TX_BUF_FREE_LVL_MASK | \
      MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_RX_BUF_LVL_MASK | \
      MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_RESERVED0_MASK)

#define MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_DEFAULT 0x00000040

#define MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_GET_TX_BUF_FREE_LVL(mp2_i3c0_data_buffer_status_level) \
     ((mp2_i3c0_data_buffer_status_level & MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_TX_BUF_FREE_LVL_MASK) >> MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_TX_BUF_FREE_LVL_SHIFT)
#define MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_GET_RX_BUF_LVL(mp2_i3c0_data_buffer_status_level) \
     ((mp2_i3c0_data_buffer_status_level & MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_RX_BUF_LVL_MASK) >> MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_RX_BUF_LVL_SHIFT)
#define MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_GET_RESERVED0(mp2_i3c0_data_buffer_status_level) \
     ((mp2_i3c0_data_buffer_status_level & MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_RESERVED0_MASK) >> MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_RESERVED0_SHIFT)

#define MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_SET_TX_BUF_FREE_LVL(mp2_i3c0_data_buffer_status_level_reg, tx_buf_free_lvl) \
     mp2_i3c0_data_buffer_status_level_reg = (mp2_i3c0_data_buffer_status_level_reg & ~MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_TX_BUF_FREE_LVL_MASK) | (tx_buf_free_lvl << MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_TX_BUF_FREE_LVL_SHIFT)
#define MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_SET_RX_BUF_LVL(mp2_i3c0_data_buffer_status_level_reg, rx_buf_lvl) \
     mp2_i3c0_data_buffer_status_level_reg = (mp2_i3c0_data_buffer_status_level_reg & ~MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_RX_BUF_LVL_MASK) | (rx_buf_lvl << MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_RX_BUF_LVL_SHIFT)
#define MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_SET_RESERVED0(mp2_i3c0_data_buffer_status_level_reg, reserved0) \
     mp2_i3c0_data_buffer_status_level_reg = (mp2_i3c0_data_buffer_status_level_reg & ~MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_RESERVED0_MASK) | (reserved0 << MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_data_buffer_status_level_t {
          unsigned int tx_buf_free_lvl                : MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_TX_BUF_FREE_LVL_SIZE;
          unsigned int rx_buf_lvl                     : MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_RX_BUF_LVL_SIZE;
          unsigned int reserved0                      : MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_RESERVED0_SIZE;
     } mp2_i3c0_data_buffer_status_level_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_data_buffer_status_level_t {
          unsigned int reserved0                      : MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_RESERVED0_SIZE;
          unsigned int rx_buf_lvl                     : MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_RX_BUF_LVL_SIZE;
          unsigned int tx_buf_free_lvl                : MP2_I3C0_DATA_BUFFER_STATUS_LEVEL_TX_BUF_FREE_LVL_SIZE;
     } mp2_i3c0_data_buffer_status_level_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_data_buffer_status_level_t f;
} mp2_i3c0_data_buffer_status_level_u;


/*
 * MP2_I3C0_PRESENT_STATE_DEBUG struct
 */

#define MP2_I3C0_PRESENT_STATE_DEBUG_REG_SIZE 32
#define MP2_I3C0_PRESENT_STATE_DEBUG_SCL_LINE_SIGNAL_LEVEL_SIZE 1
#define MP2_I3C0_PRESENT_STATE_DEBUG_SDA_LINE_SIGNAL_LEVEL_SIZE 1
#define MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED3_SIZE 6
#define MP2_I3C0_PRESENT_STATE_DEBUG_CM_TFR_STATUS_SIZE 6
#define MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED2_SIZE 2
#define MP2_I3C0_PRESENT_STATE_DEBUG_CM_TFR_ST_STATUS_SIZE 6
#define MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED1_SIZE 2
#define MP2_I3C0_PRESENT_STATE_DEBUG_CMD_TID_SIZE 4
#define MP2_I3C0_PRESENT_STATE_DEBUG_MASTER_IDLE_SIZE 1
#define MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED0_SIZE 3

#define MP2_I3C0_PRESENT_STATE_DEBUG_SCL_LINE_SIGNAL_LEVEL_SHIFT 0
#define MP2_I3C0_PRESENT_STATE_DEBUG_SDA_LINE_SIGNAL_LEVEL_SHIFT 1
#define MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED3_SHIFT 2
#define MP2_I3C0_PRESENT_STATE_DEBUG_CM_TFR_STATUS_SHIFT 8
#define MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED2_SHIFT 14
#define MP2_I3C0_PRESENT_STATE_DEBUG_CM_TFR_ST_STATUS_SHIFT 16
#define MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED1_SHIFT 22
#define MP2_I3C0_PRESENT_STATE_DEBUG_CMD_TID_SHIFT 24
#define MP2_I3C0_PRESENT_STATE_DEBUG_MASTER_IDLE_SHIFT 28
#define MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED0_SHIFT 29

#define MP2_I3C0_PRESENT_STATE_DEBUG_SCL_LINE_SIGNAL_LEVEL_MASK 0x1
#define MP2_I3C0_PRESENT_STATE_DEBUG_SDA_LINE_SIGNAL_LEVEL_MASK 0x2
#define MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED3_MASK 0xfc
#define MP2_I3C0_PRESENT_STATE_DEBUG_CM_TFR_STATUS_MASK 0x3f00
#define MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED2_MASK 0xc000
#define MP2_I3C0_PRESENT_STATE_DEBUG_CM_TFR_ST_STATUS_MASK 0x3f0000
#define MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED1_MASK 0xc00000
#define MP2_I3C0_PRESENT_STATE_DEBUG_CMD_TID_MASK 0xf000000
#define MP2_I3C0_PRESENT_STATE_DEBUG_MASTER_IDLE_MASK 0x10000000
#define MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED0_MASK 0xe0000000

#define MP2_I3C0_PRESENT_STATE_DEBUG_MASK \
     (MP2_I3C0_PRESENT_STATE_DEBUG_SCL_LINE_SIGNAL_LEVEL_MASK | \
      MP2_I3C0_PRESENT_STATE_DEBUG_SDA_LINE_SIGNAL_LEVEL_MASK | \
      MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED3_MASK | \
      MP2_I3C0_PRESENT_STATE_DEBUG_CM_TFR_STATUS_MASK | \
      MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED2_MASK | \
      MP2_I3C0_PRESENT_STATE_DEBUG_CM_TFR_ST_STATUS_MASK | \
      MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED1_MASK | \
      MP2_I3C0_PRESENT_STATE_DEBUG_CMD_TID_MASK | \
      MP2_I3C0_PRESENT_STATE_DEBUG_MASTER_IDLE_MASK | \
      MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED0_MASK)

#define MP2_I3C0_PRESENT_STATE_DEBUG_DEFAULT 0x10000003

#define MP2_I3C0_PRESENT_STATE_DEBUG_GET_SCL_LINE_SIGNAL_LEVEL(mp2_i3c0_present_state_debug) \
     ((mp2_i3c0_present_state_debug & MP2_I3C0_PRESENT_STATE_DEBUG_SCL_LINE_SIGNAL_LEVEL_MASK) >> MP2_I3C0_PRESENT_STATE_DEBUG_SCL_LINE_SIGNAL_LEVEL_SHIFT)
#define MP2_I3C0_PRESENT_STATE_DEBUG_GET_SDA_LINE_SIGNAL_LEVEL(mp2_i3c0_present_state_debug) \
     ((mp2_i3c0_present_state_debug & MP2_I3C0_PRESENT_STATE_DEBUG_SDA_LINE_SIGNAL_LEVEL_MASK) >> MP2_I3C0_PRESENT_STATE_DEBUG_SDA_LINE_SIGNAL_LEVEL_SHIFT)
#define MP2_I3C0_PRESENT_STATE_DEBUG_GET_RESERVED3(mp2_i3c0_present_state_debug) \
     ((mp2_i3c0_present_state_debug & MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED3_MASK) >> MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED3_SHIFT)
#define MP2_I3C0_PRESENT_STATE_DEBUG_GET_CM_TFR_STATUS(mp2_i3c0_present_state_debug) \
     ((mp2_i3c0_present_state_debug & MP2_I3C0_PRESENT_STATE_DEBUG_CM_TFR_STATUS_MASK) >> MP2_I3C0_PRESENT_STATE_DEBUG_CM_TFR_STATUS_SHIFT)
#define MP2_I3C0_PRESENT_STATE_DEBUG_GET_RESERVED2(mp2_i3c0_present_state_debug) \
     ((mp2_i3c0_present_state_debug & MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED2_MASK) >> MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED2_SHIFT)
#define MP2_I3C0_PRESENT_STATE_DEBUG_GET_CM_TFR_ST_STATUS(mp2_i3c0_present_state_debug) \
     ((mp2_i3c0_present_state_debug & MP2_I3C0_PRESENT_STATE_DEBUG_CM_TFR_ST_STATUS_MASK) >> MP2_I3C0_PRESENT_STATE_DEBUG_CM_TFR_ST_STATUS_SHIFT)
#define MP2_I3C0_PRESENT_STATE_DEBUG_GET_RESERVED1(mp2_i3c0_present_state_debug) \
     ((mp2_i3c0_present_state_debug & MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED1_MASK) >> MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED1_SHIFT)
#define MP2_I3C0_PRESENT_STATE_DEBUG_GET_CMD_TID(mp2_i3c0_present_state_debug) \
     ((mp2_i3c0_present_state_debug & MP2_I3C0_PRESENT_STATE_DEBUG_CMD_TID_MASK) >> MP2_I3C0_PRESENT_STATE_DEBUG_CMD_TID_SHIFT)
#define MP2_I3C0_PRESENT_STATE_DEBUG_GET_MASTER_IDLE(mp2_i3c0_present_state_debug) \
     ((mp2_i3c0_present_state_debug & MP2_I3C0_PRESENT_STATE_DEBUG_MASTER_IDLE_MASK) >> MP2_I3C0_PRESENT_STATE_DEBUG_MASTER_IDLE_SHIFT)
#define MP2_I3C0_PRESENT_STATE_DEBUG_GET_RESERVED0(mp2_i3c0_present_state_debug) \
     ((mp2_i3c0_present_state_debug & MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED0_MASK) >> MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED0_SHIFT)

#define MP2_I3C0_PRESENT_STATE_DEBUG_SET_SCL_LINE_SIGNAL_LEVEL(mp2_i3c0_present_state_debug_reg, scl_line_signal_level) \
     mp2_i3c0_present_state_debug_reg = (mp2_i3c0_present_state_debug_reg & ~MP2_I3C0_PRESENT_STATE_DEBUG_SCL_LINE_SIGNAL_LEVEL_MASK) | (scl_line_signal_level << MP2_I3C0_PRESENT_STATE_DEBUG_SCL_LINE_SIGNAL_LEVEL_SHIFT)
#define MP2_I3C0_PRESENT_STATE_DEBUG_SET_SDA_LINE_SIGNAL_LEVEL(mp2_i3c0_present_state_debug_reg, sda_line_signal_level) \
     mp2_i3c0_present_state_debug_reg = (mp2_i3c0_present_state_debug_reg & ~MP2_I3C0_PRESENT_STATE_DEBUG_SDA_LINE_SIGNAL_LEVEL_MASK) | (sda_line_signal_level << MP2_I3C0_PRESENT_STATE_DEBUG_SDA_LINE_SIGNAL_LEVEL_SHIFT)
#define MP2_I3C0_PRESENT_STATE_DEBUG_SET_RESERVED3(mp2_i3c0_present_state_debug_reg, reserved3) \
     mp2_i3c0_present_state_debug_reg = (mp2_i3c0_present_state_debug_reg & ~MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED3_MASK) | (reserved3 << MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED3_SHIFT)
#define MP2_I3C0_PRESENT_STATE_DEBUG_SET_CM_TFR_STATUS(mp2_i3c0_present_state_debug_reg, cm_tfr_status) \
     mp2_i3c0_present_state_debug_reg = (mp2_i3c0_present_state_debug_reg & ~MP2_I3C0_PRESENT_STATE_DEBUG_CM_TFR_STATUS_MASK) | (cm_tfr_status << MP2_I3C0_PRESENT_STATE_DEBUG_CM_TFR_STATUS_SHIFT)
#define MP2_I3C0_PRESENT_STATE_DEBUG_SET_RESERVED2(mp2_i3c0_present_state_debug_reg, reserved2) \
     mp2_i3c0_present_state_debug_reg = (mp2_i3c0_present_state_debug_reg & ~MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED2_MASK) | (reserved2 << MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED2_SHIFT)
#define MP2_I3C0_PRESENT_STATE_DEBUG_SET_CM_TFR_ST_STATUS(mp2_i3c0_present_state_debug_reg, cm_tfr_st_status) \
     mp2_i3c0_present_state_debug_reg = (mp2_i3c0_present_state_debug_reg & ~MP2_I3C0_PRESENT_STATE_DEBUG_CM_TFR_ST_STATUS_MASK) | (cm_tfr_st_status << MP2_I3C0_PRESENT_STATE_DEBUG_CM_TFR_ST_STATUS_SHIFT)
#define MP2_I3C0_PRESENT_STATE_DEBUG_SET_RESERVED1(mp2_i3c0_present_state_debug_reg, reserved1) \
     mp2_i3c0_present_state_debug_reg = (mp2_i3c0_present_state_debug_reg & ~MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED1_MASK) | (reserved1 << MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED1_SHIFT)
#define MP2_I3C0_PRESENT_STATE_DEBUG_SET_CMD_TID(mp2_i3c0_present_state_debug_reg, cmd_tid) \
     mp2_i3c0_present_state_debug_reg = (mp2_i3c0_present_state_debug_reg & ~MP2_I3C0_PRESENT_STATE_DEBUG_CMD_TID_MASK) | (cmd_tid << MP2_I3C0_PRESENT_STATE_DEBUG_CMD_TID_SHIFT)
#define MP2_I3C0_PRESENT_STATE_DEBUG_SET_MASTER_IDLE(mp2_i3c0_present_state_debug_reg, master_idle) \
     mp2_i3c0_present_state_debug_reg = (mp2_i3c0_present_state_debug_reg & ~MP2_I3C0_PRESENT_STATE_DEBUG_MASTER_IDLE_MASK) | (master_idle << MP2_I3C0_PRESENT_STATE_DEBUG_MASTER_IDLE_SHIFT)
#define MP2_I3C0_PRESENT_STATE_DEBUG_SET_RESERVED0(mp2_i3c0_present_state_debug_reg, reserved0) \
     mp2_i3c0_present_state_debug_reg = (mp2_i3c0_present_state_debug_reg & ~MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED0_MASK) | (reserved0 << MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_present_state_debug_t {
          unsigned int scl_line_signal_level          : MP2_I3C0_PRESENT_STATE_DEBUG_SCL_LINE_SIGNAL_LEVEL_SIZE;
          unsigned int sda_line_signal_level          : MP2_I3C0_PRESENT_STATE_DEBUG_SDA_LINE_SIGNAL_LEVEL_SIZE;
          unsigned int reserved3                      : MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED3_SIZE;
          unsigned int cm_tfr_status                  : MP2_I3C0_PRESENT_STATE_DEBUG_CM_TFR_STATUS_SIZE;
          unsigned int reserved2                      : MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED2_SIZE;
          unsigned int cm_tfr_st_status               : MP2_I3C0_PRESENT_STATE_DEBUG_CM_TFR_ST_STATUS_SIZE;
          unsigned int reserved1                      : MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED1_SIZE;
          unsigned int cmd_tid                        : MP2_I3C0_PRESENT_STATE_DEBUG_CMD_TID_SIZE;
          unsigned int master_idle                    : MP2_I3C0_PRESENT_STATE_DEBUG_MASTER_IDLE_SIZE;
          unsigned int reserved0                      : MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED0_SIZE;
     } mp2_i3c0_present_state_debug_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_present_state_debug_t {
          unsigned int reserved0                      : MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED0_SIZE;
          unsigned int master_idle                    : MP2_I3C0_PRESENT_STATE_DEBUG_MASTER_IDLE_SIZE;
          unsigned int cmd_tid                        : MP2_I3C0_PRESENT_STATE_DEBUG_CMD_TID_SIZE;
          unsigned int reserved1                      : MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED1_SIZE;
          unsigned int cm_tfr_st_status               : MP2_I3C0_PRESENT_STATE_DEBUG_CM_TFR_ST_STATUS_SIZE;
          unsigned int reserved2                      : MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED2_SIZE;
          unsigned int cm_tfr_status                  : MP2_I3C0_PRESENT_STATE_DEBUG_CM_TFR_STATUS_SIZE;
          unsigned int reserved3                      : MP2_I3C0_PRESENT_STATE_DEBUG_RESERVED3_SIZE;
          unsigned int sda_line_signal_level          : MP2_I3C0_PRESENT_STATE_DEBUG_SDA_LINE_SIGNAL_LEVEL_SIZE;
          unsigned int scl_line_signal_level          : MP2_I3C0_PRESENT_STATE_DEBUG_SCL_LINE_SIGNAL_LEVEL_SIZE;
     } mp2_i3c0_present_state_debug_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_present_state_debug_t f;
} mp2_i3c0_present_state_debug_u;


/*
 * MP2_I3C0_MASTER_EXT_HEADER struct
 */

#define MP2_I3C0_MASTER_EXT_HEADER_REG_SIZE 32
#define MP2_I3C0_MASTER_EXT_HEADER_CAP_ID_SIZE 8
#define MP2_I3C0_MASTER_EXT_HEADER_CAP_LEN_SIZE 16
#define MP2_I3C0_MASTER_EXT_HEADER_RESERVED0_SIZE 8

#define MP2_I3C0_MASTER_EXT_HEADER_CAP_ID_SHIFT 0
#define MP2_I3C0_MASTER_EXT_HEADER_CAP_LEN_SHIFT 8
#define MP2_I3C0_MASTER_EXT_HEADER_RESERVED0_SHIFT 24

#define MP2_I3C0_MASTER_EXT_HEADER_CAP_ID_MASK 0xff
#define MP2_I3C0_MASTER_EXT_HEADER_CAP_LEN_MASK 0xffff00
#define MP2_I3C0_MASTER_EXT_HEADER_RESERVED0_MASK 0xff000000

#define MP2_I3C0_MASTER_EXT_HEADER_MASK \
     (MP2_I3C0_MASTER_EXT_HEADER_CAP_ID_MASK | \
      MP2_I3C0_MASTER_EXT_HEADER_CAP_LEN_MASK | \
      MP2_I3C0_MASTER_EXT_HEADER_RESERVED0_MASK)

#define MP2_I3C0_MASTER_EXT_HEADER_DEFAULT 0x00001002

#define MP2_I3C0_MASTER_EXT_HEADER_GET_CAP_ID(mp2_i3c0_master_ext_header) \
     ((mp2_i3c0_master_ext_header & MP2_I3C0_MASTER_EXT_HEADER_CAP_ID_MASK) >> MP2_I3C0_MASTER_EXT_HEADER_CAP_ID_SHIFT)
#define MP2_I3C0_MASTER_EXT_HEADER_GET_CAP_LEN(mp2_i3c0_master_ext_header) \
     ((mp2_i3c0_master_ext_header & MP2_I3C0_MASTER_EXT_HEADER_CAP_LEN_MASK) >> MP2_I3C0_MASTER_EXT_HEADER_CAP_LEN_SHIFT)
#define MP2_I3C0_MASTER_EXT_HEADER_GET_RESERVED0(mp2_i3c0_master_ext_header) \
     ((mp2_i3c0_master_ext_header & MP2_I3C0_MASTER_EXT_HEADER_RESERVED0_MASK) >> MP2_I3C0_MASTER_EXT_HEADER_RESERVED0_SHIFT)

#define MP2_I3C0_MASTER_EXT_HEADER_SET_CAP_ID(mp2_i3c0_master_ext_header_reg, cap_id) \
     mp2_i3c0_master_ext_header_reg = (mp2_i3c0_master_ext_header_reg & ~MP2_I3C0_MASTER_EXT_HEADER_CAP_ID_MASK) | (cap_id << MP2_I3C0_MASTER_EXT_HEADER_CAP_ID_SHIFT)
#define MP2_I3C0_MASTER_EXT_HEADER_SET_CAP_LEN(mp2_i3c0_master_ext_header_reg, cap_len) \
     mp2_i3c0_master_ext_header_reg = (mp2_i3c0_master_ext_header_reg & ~MP2_I3C0_MASTER_EXT_HEADER_CAP_LEN_MASK) | (cap_len << MP2_I3C0_MASTER_EXT_HEADER_CAP_LEN_SHIFT)
#define MP2_I3C0_MASTER_EXT_HEADER_SET_RESERVED0(mp2_i3c0_master_ext_header_reg, reserved0) \
     mp2_i3c0_master_ext_header_reg = (mp2_i3c0_master_ext_header_reg & ~MP2_I3C0_MASTER_EXT_HEADER_RESERVED0_MASK) | (reserved0 << MP2_I3C0_MASTER_EXT_HEADER_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_master_ext_header_t {
          unsigned int cap_id                         : MP2_I3C0_MASTER_EXT_HEADER_CAP_ID_SIZE;
          unsigned int cap_len                        : MP2_I3C0_MASTER_EXT_HEADER_CAP_LEN_SIZE;
          unsigned int reserved0                      : MP2_I3C0_MASTER_EXT_HEADER_RESERVED0_SIZE;
     } mp2_i3c0_master_ext_header_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_master_ext_header_t {
          unsigned int reserved0                      : MP2_I3C0_MASTER_EXT_HEADER_RESERVED0_SIZE;
          unsigned int cap_len                        : MP2_I3C0_MASTER_EXT_HEADER_CAP_LEN_SIZE;
          unsigned int cap_id                         : MP2_I3C0_MASTER_EXT_HEADER_CAP_ID_SIZE;
     } mp2_i3c0_master_ext_header_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_master_ext_header_t f;
} mp2_i3c0_master_ext_header_u;


/*
 * MP2_I3C0_MASTER_CONFIG struct
 */

#define MP2_I3C0_MASTER_CONFIG_REG_SIZE 32
#define MP2_I3C0_MASTER_CONFIG_APP_IF_MODE_SIZE 2
#define MP2_I3C0_MASTER_CONFIG_APP_IF_DATA_WIDTH_SIZE 2
#define MP2_I3C0_MASTER_CONFIG_OPERATION_MODE_SIZE 2
#define MP2_I3C0_MASTER_CONFIG_RESERVED0_SIZE 26

#define MP2_I3C0_MASTER_CONFIG_APP_IF_MODE_SHIFT 0
#define MP2_I3C0_MASTER_CONFIG_APP_IF_DATA_WIDTH_SHIFT 2
#define MP2_I3C0_MASTER_CONFIG_OPERATION_MODE_SHIFT 4
#define MP2_I3C0_MASTER_CONFIG_RESERVED0_SHIFT 6

#define MP2_I3C0_MASTER_CONFIG_APP_IF_MODE_MASK 0x3
#define MP2_I3C0_MASTER_CONFIG_APP_IF_DATA_WIDTH_MASK 0xc
#define MP2_I3C0_MASTER_CONFIG_OPERATION_MODE_MASK 0x30
#define MP2_I3C0_MASTER_CONFIG_RESERVED0_MASK 0xffffffc0

#define MP2_I3C0_MASTER_CONFIG_MASK \
     (MP2_I3C0_MASTER_CONFIG_APP_IF_MODE_MASK | \
      MP2_I3C0_MASTER_CONFIG_APP_IF_DATA_WIDTH_MASK | \
      MP2_I3C0_MASTER_CONFIG_OPERATION_MODE_MASK | \
      MP2_I3C0_MASTER_CONFIG_RESERVED0_MASK)

#define MP2_I3C0_MASTER_CONFIG_DEFAULT 0x00000039

#define MP2_I3C0_MASTER_CONFIG_GET_APP_IF_MODE(mp2_i3c0_master_config) \
     ((mp2_i3c0_master_config & MP2_I3C0_MASTER_CONFIG_APP_IF_MODE_MASK) >> MP2_I3C0_MASTER_CONFIG_APP_IF_MODE_SHIFT)
#define MP2_I3C0_MASTER_CONFIG_GET_APP_IF_DATA_WIDTH(mp2_i3c0_master_config) \
     ((mp2_i3c0_master_config & MP2_I3C0_MASTER_CONFIG_APP_IF_DATA_WIDTH_MASK) >> MP2_I3C0_MASTER_CONFIG_APP_IF_DATA_WIDTH_SHIFT)
#define MP2_I3C0_MASTER_CONFIG_GET_OPERATION_MODE(mp2_i3c0_master_config) \
     ((mp2_i3c0_master_config & MP2_I3C0_MASTER_CONFIG_OPERATION_MODE_MASK) >> MP2_I3C0_MASTER_CONFIG_OPERATION_MODE_SHIFT)
#define MP2_I3C0_MASTER_CONFIG_GET_RESERVED0(mp2_i3c0_master_config) \
     ((mp2_i3c0_master_config & MP2_I3C0_MASTER_CONFIG_RESERVED0_MASK) >> MP2_I3C0_MASTER_CONFIG_RESERVED0_SHIFT)

#define MP2_I3C0_MASTER_CONFIG_SET_APP_IF_MODE(mp2_i3c0_master_config_reg, app_if_mode) \
     mp2_i3c0_master_config_reg = (mp2_i3c0_master_config_reg & ~MP2_I3C0_MASTER_CONFIG_APP_IF_MODE_MASK) | (app_if_mode << MP2_I3C0_MASTER_CONFIG_APP_IF_MODE_SHIFT)
#define MP2_I3C0_MASTER_CONFIG_SET_APP_IF_DATA_WIDTH(mp2_i3c0_master_config_reg, app_if_data_width) \
     mp2_i3c0_master_config_reg = (mp2_i3c0_master_config_reg & ~MP2_I3C0_MASTER_CONFIG_APP_IF_DATA_WIDTH_MASK) | (app_if_data_width << MP2_I3C0_MASTER_CONFIG_APP_IF_DATA_WIDTH_SHIFT)
#define MP2_I3C0_MASTER_CONFIG_SET_OPERATION_MODE(mp2_i3c0_master_config_reg, operation_mode) \
     mp2_i3c0_master_config_reg = (mp2_i3c0_master_config_reg & ~MP2_I3C0_MASTER_CONFIG_OPERATION_MODE_MASK) | (operation_mode << MP2_I3C0_MASTER_CONFIG_OPERATION_MODE_SHIFT)
#define MP2_I3C0_MASTER_CONFIG_SET_RESERVED0(mp2_i3c0_master_config_reg, reserved0) \
     mp2_i3c0_master_config_reg = (mp2_i3c0_master_config_reg & ~MP2_I3C0_MASTER_CONFIG_RESERVED0_MASK) | (reserved0 << MP2_I3C0_MASTER_CONFIG_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_master_config_t {
          unsigned int app_if_mode                    : MP2_I3C0_MASTER_CONFIG_APP_IF_MODE_SIZE;
          unsigned int app_if_data_width              : MP2_I3C0_MASTER_CONFIG_APP_IF_DATA_WIDTH_SIZE;
          unsigned int operation_mode                 : MP2_I3C0_MASTER_CONFIG_OPERATION_MODE_SIZE;
          unsigned int reserved0                      : MP2_I3C0_MASTER_CONFIG_RESERVED0_SIZE;
     } mp2_i3c0_master_config_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_master_config_t {
          unsigned int reserved0                      : MP2_I3C0_MASTER_CONFIG_RESERVED0_SIZE;
          unsigned int operation_mode                 : MP2_I3C0_MASTER_CONFIG_OPERATION_MODE_SIZE;
          unsigned int app_if_data_width              : MP2_I3C0_MASTER_CONFIG_APP_IF_DATA_WIDTH_SIZE;
          unsigned int app_if_mode                    : MP2_I3C0_MASTER_CONFIG_APP_IF_MODE_SIZE;
     } mp2_i3c0_master_config_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_master_config_t f;
} mp2_i3c0_master_config_u;


/*
 * MP2_I3C0_COMMAND_QUEUE_PORT struct
 */

#define MP2_I3C0_COMMAND_QUEUE_PORT_REG_SIZE 32
#define MP2_I3C0_COMMAND_QUEUE_PORT_COMMAND_SIZE 32

#define MP2_I3C0_COMMAND_QUEUE_PORT_COMMAND_SHIFT 0

#define MP2_I3C0_COMMAND_QUEUE_PORT_COMMAND_MASK 0xffffffff

#define MP2_I3C0_COMMAND_QUEUE_PORT_MASK \
     (MP2_I3C0_COMMAND_QUEUE_PORT_COMMAND_MASK)

#define MP2_I3C0_COMMAND_QUEUE_PORT_DEFAULT 0x00000000

#define MP2_I3C0_COMMAND_QUEUE_PORT_GET_COMMAND(mp2_i3c0_command_queue_port) \
     ((mp2_i3c0_command_queue_port & MP2_I3C0_COMMAND_QUEUE_PORT_COMMAND_MASK) >> MP2_I3C0_COMMAND_QUEUE_PORT_COMMAND_SHIFT)

#define MP2_I3C0_COMMAND_QUEUE_PORT_SET_COMMAND(mp2_i3c0_command_queue_port_reg, command) \
     mp2_i3c0_command_queue_port_reg = (mp2_i3c0_command_queue_port_reg & ~MP2_I3C0_COMMAND_QUEUE_PORT_COMMAND_MASK) | (command << MP2_I3C0_COMMAND_QUEUE_PORT_COMMAND_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_command_queue_port_t {
          unsigned int command                        : MP2_I3C0_COMMAND_QUEUE_PORT_COMMAND_SIZE;
     } mp2_i3c0_command_queue_port_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_command_queue_port_t {
          unsigned int command                        : MP2_I3C0_COMMAND_QUEUE_PORT_COMMAND_SIZE;
     } mp2_i3c0_command_queue_port_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_command_queue_port_t f;
} mp2_i3c0_command_queue_port_u;


/*
 * MP2_I3C0_RESPONSE_QUEUE_PORT struct
 */

#define MP2_I3C0_RESPONSE_QUEUE_PORT_REG_SIZE 32
#define MP2_I3C0_RESPONSE_QUEUE_PORT_DATA_LENGTH_SIZE 16
#define MP2_I3C0_RESPONSE_QUEUE_PORT_RESERVED0_SIZE 8
#define MP2_I3C0_RESPONSE_QUEUE_PORT_TID_SIZE 4
#define MP2_I3C0_RESPONSE_QUEUE_PORT_ERR_STATUS_SIZE 4

#define MP2_I3C0_RESPONSE_QUEUE_PORT_DATA_LENGTH_SHIFT 0
#define MP2_I3C0_RESPONSE_QUEUE_PORT_RESERVED0_SHIFT 16
#define MP2_I3C0_RESPONSE_QUEUE_PORT_TID_SHIFT 24
#define MP2_I3C0_RESPONSE_QUEUE_PORT_ERR_STATUS_SHIFT 28

#define MP2_I3C0_RESPONSE_QUEUE_PORT_DATA_LENGTH_MASK 0xffff
#define MP2_I3C0_RESPONSE_QUEUE_PORT_RESERVED0_MASK 0xff0000
#define MP2_I3C0_RESPONSE_QUEUE_PORT_TID_MASK 0xf000000
#define MP2_I3C0_RESPONSE_QUEUE_PORT_ERR_STATUS_MASK 0xf0000000

#define MP2_I3C0_RESPONSE_QUEUE_PORT_MASK \
     (MP2_I3C0_RESPONSE_QUEUE_PORT_DATA_LENGTH_MASK | \
      MP2_I3C0_RESPONSE_QUEUE_PORT_RESERVED0_MASK | \
      MP2_I3C0_RESPONSE_QUEUE_PORT_TID_MASK | \
      MP2_I3C0_RESPONSE_QUEUE_PORT_ERR_STATUS_MASK)

#define MP2_I3C0_RESPONSE_QUEUE_PORT_DEFAULT 0x00000000

#define MP2_I3C0_RESPONSE_QUEUE_PORT_GET_DATA_LENGTH(mp2_i3c0_response_queue_port) \
     ((mp2_i3c0_response_queue_port & MP2_I3C0_RESPONSE_QUEUE_PORT_DATA_LENGTH_MASK) >> MP2_I3C0_RESPONSE_QUEUE_PORT_DATA_LENGTH_SHIFT)
#define MP2_I3C0_RESPONSE_QUEUE_PORT_GET_RESERVED0(mp2_i3c0_response_queue_port) \
     ((mp2_i3c0_response_queue_port & MP2_I3C0_RESPONSE_QUEUE_PORT_RESERVED0_MASK) >> MP2_I3C0_RESPONSE_QUEUE_PORT_RESERVED0_SHIFT)
#define MP2_I3C0_RESPONSE_QUEUE_PORT_GET_TID(mp2_i3c0_response_queue_port) \
     ((mp2_i3c0_response_queue_port & MP2_I3C0_RESPONSE_QUEUE_PORT_TID_MASK) >> MP2_I3C0_RESPONSE_QUEUE_PORT_TID_SHIFT)
#define MP2_I3C0_RESPONSE_QUEUE_PORT_GET_ERR_STATUS(mp2_i3c0_response_queue_port) \
     ((mp2_i3c0_response_queue_port & MP2_I3C0_RESPONSE_QUEUE_PORT_ERR_STATUS_MASK) >> MP2_I3C0_RESPONSE_QUEUE_PORT_ERR_STATUS_SHIFT)

#define MP2_I3C0_RESPONSE_QUEUE_PORT_SET_DATA_LENGTH(mp2_i3c0_response_queue_port_reg, data_length) \
     mp2_i3c0_response_queue_port_reg = (mp2_i3c0_response_queue_port_reg & ~MP2_I3C0_RESPONSE_QUEUE_PORT_DATA_LENGTH_MASK) | (data_length << MP2_I3C0_RESPONSE_QUEUE_PORT_DATA_LENGTH_SHIFT)
#define MP2_I3C0_RESPONSE_QUEUE_PORT_SET_RESERVED0(mp2_i3c0_response_queue_port_reg, reserved0) \
     mp2_i3c0_response_queue_port_reg = (mp2_i3c0_response_queue_port_reg & ~MP2_I3C0_RESPONSE_QUEUE_PORT_RESERVED0_MASK) | (reserved0 << MP2_I3C0_RESPONSE_QUEUE_PORT_RESERVED0_SHIFT)
#define MP2_I3C0_RESPONSE_QUEUE_PORT_SET_TID(mp2_i3c0_response_queue_port_reg, tid) \
     mp2_i3c0_response_queue_port_reg = (mp2_i3c0_response_queue_port_reg & ~MP2_I3C0_RESPONSE_QUEUE_PORT_TID_MASK) | (tid << MP2_I3C0_RESPONSE_QUEUE_PORT_TID_SHIFT)
#define MP2_I3C0_RESPONSE_QUEUE_PORT_SET_ERR_STATUS(mp2_i3c0_response_queue_port_reg, err_status) \
     mp2_i3c0_response_queue_port_reg = (mp2_i3c0_response_queue_port_reg & ~MP2_I3C0_RESPONSE_QUEUE_PORT_ERR_STATUS_MASK) | (err_status << MP2_I3C0_RESPONSE_QUEUE_PORT_ERR_STATUS_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_response_queue_port_t {
          unsigned int data_length                    : MP2_I3C0_RESPONSE_QUEUE_PORT_DATA_LENGTH_SIZE;
          unsigned int reserved0                      : MP2_I3C0_RESPONSE_QUEUE_PORT_RESERVED0_SIZE;
          unsigned int tid                            : MP2_I3C0_RESPONSE_QUEUE_PORT_TID_SIZE;
          unsigned int err_status                     : MP2_I3C0_RESPONSE_QUEUE_PORT_ERR_STATUS_SIZE;
     } mp2_i3c0_response_queue_port_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_response_queue_port_t {
          unsigned int err_status                     : MP2_I3C0_RESPONSE_QUEUE_PORT_ERR_STATUS_SIZE;
          unsigned int tid                            : MP2_I3C0_RESPONSE_QUEUE_PORT_TID_SIZE;
          unsigned int reserved0                      : MP2_I3C0_RESPONSE_QUEUE_PORT_RESERVED0_SIZE;
          unsigned int data_length                    : MP2_I3C0_RESPONSE_QUEUE_PORT_DATA_LENGTH_SIZE;
     } mp2_i3c0_response_queue_port_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_response_queue_port_t f;
} mp2_i3c0_response_queue_port_u;


/*
 * MP2_I3C0_RX_DATA_PORT struct
 */

#define MP2_I3C0_RX_DATA_PORT_REG_SIZE 32
#define MP2_I3C0_RX_DATA_PORT_RX_DATA_PORT_SIZE 32

#define MP2_I3C0_RX_DATA_PORT_RX_DATA_PORT_SHIFT 0

#define MP2_I3C0_RX_DATA_PORT_RX_DATA_PORT_MASK 0xffffffff

#define MP2_I3C0_RX_DATA_PORT_MASK \
     (MP2_I3C0_RX_DATA_PORT_RX_DATA_PORT_MASK)

#define MP2_I3C0_RX_DATA_PORT_DEFAULT  0x00000000

#define MP2_I3C0_RX_DATA_PORT_GET_RX_DATA_PORT(mp2_i3c0_rx_data_port) \
     ((mp2_i3c0_rx_data_port & MP2_I3C0_RX_DATA_PORT_RX_DATA_PORT_MASK) >> MP2_I3C0_RX_DATA_PORT_RX_DATA_PORT_SHIFT)

#define MP2_I3C0_RX_DATA_PORT_SET_RX_DATA_PORT(mp2_i3c0_rx_data_port_reg, rx_data_port) \
     mp2_i3c0_rx_data_port_reg = (mp2_i3c0_rx_data_port_reg & ~MP2_I3C0_RX_DATA_PORT_RX_DATA_PORT_MASK) | (rx_data_port << MP2_I3C0_RX_DATA_PORT_RX_DATA_PORT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_rx_data_port_t {
          unsigned int rx_data_port                   : MP2_I3C0_RX_DATA_PORT_RX_DATA_PORT_SIZE;
     } mp2_i3c0_rx_data_port_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_rx_data_port_t {
          unsigned int rx_data_port                   : MP2_I3C0_RX_DATA_PORT_RX_DATA_PORT_SIZE;
     } mp2_i3c0_rx_data_port_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_rx_data_port_t f;
} mp2_i3c0_rx_data_port_u;


/*
 * MP2_I3C0_TX_DATA_PORT struct
 */

#define MP2_I3C0_TX_DATA_PORT_REG_SIZE 32
#define MP2_I3C0_TX_DATA_PORT_TX_DATA_PORT_SIZE 32

#define MP2_I3C0_TX_DATA_PORT_TX_DATA_PORT_SHIFT 0

#define MP2_I3C0_TX_DATA_PORT_TX_DATA_PORT_MASK 0xffffffff

#define MP2_I3C0_TX_DATA_PORT_MASK \
     (MP2_I3C0_TX_DATA_PORT_TX_DATA_PORT_MASK)

#define MP2_I3C0_TX_DATA_PORT_DEFAULT  0x00000000

#define MP2_I3C0_TX_DATA_PORT_GET_TX_DATA_PORT(mp2_i3c0_tx_data_port) \
     ((mp2_i3c0_tx_data_port & MP2_I3C0_TX_DATA_PORT_TX_DATA_PORT_MASK) >> MP2_I3C0_TX_DATA_PORT_TX_DATA_PORT_SHIFT)

#define MP2_I3C0_TX_DATA_PORT_SET_TX_DATA_PORT(mp2_i3c0_tx_data_port_reg, tx_data_port) \
     mp2_i3c0_tx_data_port_reg = (mp2_i3c0_tx_data_port_reg & ~MP2_I3C0_TX_DATA_PORT_TX_DATA_PORT_MASK) | (tx_data_port << MP2_I3C0_TX_DATA_PORT_TX_DATA_PORT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_tx_data_port_t {
          unsigned int tx_data_port                   : MP2_I3C0_TX_DATA_PORT_TX_DATA_PORT_SIZE;
     } mp2_i3c0_tx_data_port_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_tx_data_port_t {
          unsigned int tx_data_port                   : MP2_I3C0_TX_DATA_PORT_TX_DATA_PORT_SIZE;
     } mp2_i3c0_tx_data_port_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_tx_data_port_t f;
} mp2_i3c0_tx_data_port_u;


/*
 * MP2_I3C0_IBI_PORT struct
 */

#define MP2_I3C0_IBI_PORT_REG_SIZE     32
#define MP2_I3C0_IBI_PORT_IBI_DATA_SIZE 32

#define MP2_I3C0_IBI_PORT_IBI_DATA_SHIFT 0

#define MP2_I3C0_IBI_PORT_IBI_DATA_MASK 0xffffffff

#define MP2_I3C0_IBI_PORT_MASK \
     (MP2_I3C0_IBI_PORT_IBI_DATA_MASK)

#define MP2_I3C0_IBI_PORT_DEFAULT      0x00000000

#define MP2_I3C0_IBI_PORT_GET_IBI_DATA(mp2_i3c0_ibi_port) \
     ((mp2_i3c0_ibi_port & MP2_I3C0_IBI_PORT_IBI_DATA_MASK) >> MP2_I3C0_IBI_PORT_IBI_DATA_SHIFT)

#define MP2_I3C0_IBI_PORT_SET_IBI_DATA(mp2_i3c0_ibi_port_reg, ibi_data) \
     mp2_i3c0_ibi_port_reg = (mp2_i3c0_ibi_port_reg & ~MP2_I3C0_IBI_PORT_IBI_DATA_MASK) | (ibi_data << MP2_I3C0_IBI_PORT_IBI_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_ibi_port_t {
          unsigned int ibi_data                       : MP2_I3C0_IBI_PORT_IBI_DATA_SIZE;
     } mp2_i3c0_ibi_port_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_ibi_port_t {
          unsigned int ibi_data                       : MP2_I3C0_IBI_PORT_IBI_DATA_SIZE;
     } mp2_i3c0_ibi_port_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_ibi_port_t f;
} mp2_i3c0_ibi_port_u;


/*
 * MP2_I3C0_QUEUE_THLD_CTRL struct
 */

#define MP2_I3C0_QUEUE_THLD_CTRL_REG_SIZE 32
#define MP2_I3C0_QUEUE_THLD_CTRL_CMD_EMPTY_BUF_THLD_SIZE 8
#define MP2_I3C0_QUEUE_THLD_CTRL_RESP_BUF_THLD_SIZE 8
#define MP2_I3C0_QUEUE_THLD_CTRL_IBI_DATA_THLD_SIZE 8
#define MP2_I3C0_QUEUE_THLD_CTRL_IBI_STATUS_THLD_SIZE 8

#define MP2_I3C0_QUEUE_THLD_CTRL_CMD_EMPTY_BUF_THLD_SHIFT 0
#define MP2_I3C0_QUEUE_THLD_CTRL_RESP_BUF_THLD_SHIFT 8
#define MP2_I3C0_QUEUE_THLD_CTRL_IBI_DATA_THLD_SHIFT 16
#define MP2_I3C0_QUEUE_THLD_CTRL_IBI_STATUS_THLD_SHIFT 24

#define MP2_I3C0_QUEUE_THLD_CTRL_CMD_EMPTY_BUF_THLD_MASK 0xff
#define MP2_I3C0_QUEUE_THLD_CTRL_RESP_BUF_THLD_MASK 0xff00
#define MP2_I3C0_QUEUE_THLD_CTRL_IBI_DATA_THLD_MASK 0xff0000
#define MP2_I3C0_QUEUE_THLD_CTRL_IBI_STATUS_THLD_MASK 0xff000000

#define MP2_I3C0_QUEUE_THLD_CTRL_MASK \
     (MP2_I3C0_QUEUE_THLD_CTRL_CMD_EMPTY_BUF_THLD_MASK | \
      MP2_I3C0_QUEUE_THLD_CTRL_RESP_BUF_THLD_MASK | \
      MP2_I3C0_QUEUE_THLD_CTRL_IBI_DATA_THLD_MASK | \
      MP2_I3C0_QUEUE_THLD_CTRL_IBI_STATUS_THLD_MASK)

#define MP2_I3C0_QUEUE_THLD_CTRL_DEFAULT 0x01000101

#define MP2_I3C0_QUEUE_THLD_CTRL_GET_CMD_EMPTY_BUF_THLD(mp2_i3c0_queue_thld_ctrl) \
     ((mp2_i3c0_queue_thld_ctrl & MP2_I3C0_QUEUE_THLD_CTRL_CMD_EMPTY_BUF_THLD_MASK) >> MP2_I3C0_QUEUE_THLD_CTRL_CMD_EMPTY_BUF_THLD_SHIFT)
#define MP2_I3C0_QUEUE_THLD_CTRL_GET_RESP_BUF_THLD(mp2_i3c0_queue_thld_ctrl) \
     ((mp2_i3c0_queue_thld_ctrl & MP2_I3C0_QUEUE_THLD_CTRL_RESP_BUF_THLD_MASK) >> MP2_I3C0_QUEUE_THLD_CTRL_RESP_BUF_THLD_SHIFT)
#define MP2_I3C0_QUEUE_THLD_CTRL_GET_IBI_DATA_THLD(mp2_i3c0_queue_thld_ctrl) \
     ((mp2_i3c0_queue_thld_ctrl & MP2_I3C0_QUEUE_THLD_CTRL_IBI_DATA_THLD_MASK) >> MP2_I3C0_QUEUE_THLD_CTRL_IBI_DATA_THLD_SHIFT)
#define MP2_I3C0_QUEUE_THLD_CTRL_GET_IBI_STATUS_THLD(mp2_i3c0_queue_thld_ctrl) \
     ((mp2_i3c0_queue_thld_ctrl & MP2_I3C0_QUEUE_THLD_CTRL_IBI_STATUS_THLD_MASK) >> MP2_I3C0_QUEUE_THLD_CTRL_IBI_STATUS_THLD_SHIFT)

#define MP2_I3C0_QUEUE_THLD_CTRL_SET_CMD_EMPTY_BUF_THLD(mp2_i3c0_queue_thld_ctrl_reg, cmd_empty_buf_thld) \
     mp2_i3c0_queue_thld_ctrl_reg = (mp2_i3c0_queue_thld_ctrl_reg & ~MP2_I3C0_QUEUE_THLD_CTRL_CMD_EMPTY_BUF_THLD_MASK) | (cmd_empty_buf_thld << MP2_I3C0_QUEUE_THLD_CTRL_CMD_EMPTY_BUF_THLD_SHIFT)
#define MP2_I3C0_QUEUE_THLD_CTRL_SET_RESP_BUF_THLD(mp2_i3c0_queue_thld_ctrl_reg, resp_buf_thld) \
     mp2_i3c0_queue_thld_ctrl_reg = (mp2_i3c0_queue_thld_ctrl_reg & ~MP2_I3C0_QUEUE_THLD_CTRL_RESP_BUF_THLD_MASK) | (resp_buf_thld << MP2_I3C0_QUEUE_THLD_CTRL_RESP_BUF_THLD_SHIFT)
#define MP2_I3C0_QUEUE_THLD_CTRL_SET_IBI_DATA_THLD(mp2_i3c0_queue_thld_ctrl_reg, ibi_data_thld) \
     mp2_i3c0_queue_thld_ctrl_reg = (mp2_i3c0_queue_thld_ctrl_reg & ~MP2_I3C0_QUEUE_THLD_CTRL_IBI_DATA_THLD_MASK) | (ibi_data_thld << MP2_I3C0_QUEUE_THLD_CTRL_IBI_DATA_THLD_SHIFT)
#define MP2_I3C0_QUEUE_THLD_CTRL_SET_IBI_STATUS_THLD(mp2_i3c0_queue_thld_ctrl_reg, ibi_status_thld) \
     mp2_i3c0_queue_thld_ctrl_reg = (mp2_i3c0_queue_thld_ctrl_reg & ~MP2_I3C0_QUEUE_THLD_CTRL_IBI_STATUS_THLD_MASK) | (ibi_status_thld << MP2_I3C0_QUEUE_THLD_CTRL_IBI_STATUS_THLD_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_queue_thld_ctrl_t {
          unsigned int cmd_empty_buf_thld             : MP2_I3C0_QUEUE_THLD_CTRL_CMD_EMPTY_BUF_THLD_SIZE;
          unsigned int resp_buf_thld                  : MP2_I3C0_QUEUE_THLD_CTRL_RESP_BUF_THLD_SIZE;
          unsigned int ibi_data_thld                  : MP2_I3C0_QUEUE_THLD_CTRL_IBI_DATA_THLD_SIZE;
          unsigned int ibi_status_thld                : MP2_I3C0_QUEUE_THLD_CTRL_IBI_STATUS_THLD_SIZE;
     } mp2_i3c0_queue_thld_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_queue_thld_ctrl_t {
          unsigned int ibi_status_thld                : MP2_I3C0_QUEUE_THLD_CTRL_IBI_STATUS_THLD_SIZE;
          unsigned int ibi_data_thld                  : MP2_I3C0_QUEUE_THLD_CTRL_IBI_DATA_THLD_SIZE;
          unsigned int resp_buf_thld                  : MP2_I3C0_QUEUE_THLD_CTRL_RESP_BUF_THLD_SIZE;
          unsigned int cmd_empty_buf_thld             : MP2_I3C0_QUEUE_THLD_CTRL_CMD_EMPTY_BUF_THLD_SIZE;
     } mp2_i3c0_queue_thld_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_queue_thld_ctrl_t f;
} mp2_i3c0_queue_thld_ctrl_u;


/*
 * MP2_I3C0_DATA_BUFFER_THLD_CTRL struct
 */

#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_REG_SIZE 32
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_TX_BUF_THLD_SIZE 3
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED3_SIZE 5
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_RX_BUF_THLD_SIZE 3
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED2_SIZE 5
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_TX_START_THLD_SIZE 3
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED1_SIZE 5
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_RX_START_THLD_SIZE 3
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED0_SIZE 5

#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_TX_BUF_THLD_SHIFT 0
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED3_SHIFT 3
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_RX_BUF_THLD_SHIFT 8
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED2_SHIFT 11
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_TX_START_THLD_SHIFT 16
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED1_SHIFT 19
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_RX_START_THLD_SHIFT 24
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED0_SHIFT 27

#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_TX_BUF_THLD_MASK 0x7
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED3_MASK 0xf8
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_RX_BUF_THLD_MASK 0x700
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED2_MASK 0xf800
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_TX_START_THLD_MASK 0x70000
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED1_MASK 0xf80000
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_RX_START_THLD_MASK 0x7000000
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED0_MASK 0xf8000000

#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_MASK \
     (MP2_I3C0_DATA_BUFFER_THLD_CTRL_TX_BUF_THLD_MASK | \
      MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED3_MASK | \
      MP2_I3C0_DATA_BUFFER_THLD_CTRL_RX_BUF_THLD_MASK | \
      MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED2_MASK | \
      MP2_I3C0_DATA_BUFFER_THLD_CTRL_TX_START_THLD_MASK | \
      MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED1_MASK | \
      MP2_I3C0_DATA_BUFFER_THLD_CTRL_RX_START_THLD_MASK | \
      MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED0_MASK)

#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_DEFAULT 0x01010101

#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_GET_TX_BUF_THLD(mp2_i3c0_data_buffer_thld_ctrl) \
     ((mp2_i3c0_data_buffer_thld_ctrl & MP2_I3C0_DATA_BUFFER_THLD_CTRL_TX_BUF_THLD_MASK) >> MP2_I3C0_DATA_BUFFER_THLD_CTRL_TX_BUF_THLD_SHIFT)
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_GET_RESERVED3(mp2_i3c0_data_buffer_thld_ctrl) \
     ((mp2_i3c0_data_buffer_thld_ctrl & MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED3_MASK) >> MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED3_SHIFT)
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_GET_RX_BUF_THLD(mp2_i3c0_data_buffer_thld_ctrl) \
     ((mp2_i3c0_data_buffer_thld_ctrl & MP2_I3C0_DATA_BUFFER_THLD_CTRL_RX_BUF_THLD_MASK) >> MP2_I3C0_DATA_BUFFER_THLD_CTRL_RX_BUF_THLD_SHIFT)
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_GET_RESERVED2(mp2_i3c0_data_buffer_thld_ctrl) \
     ((mp2_i3c0_data_buffer_thld_ctrl & MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED2_MASK) >> MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED2_SHIFT)
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_GET_TX_START_THLD(mp2_i3c0_data_buffer_thld_ctrl) \
     ((mp2_i3c0_data_buffer_thld_ctrl & MP2_I3C0_DATA_BUFFER_THLD_CTRL_TX_START_THLD_MASK) >> MP2_I3C0_DATA_BUFFER_THLD_CTRL_TX_START_THLD_SHIFT)
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_GET_RESERVED1(mp2_i3c0_data_buffer_thld_ctrl) \
     ((mp2_i3c0_data_buffer_thld_ctrl & MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED1_MASK) >> MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED1_SHIFT)
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_GET_RX_START_THLD(mp2_i3c0_data_buffer_thld_ctrl) \
     ((mp2_i3c0_data_buffer_thld_ctrl & MP2_I3C0_DATA_BUFFER_THLD_CTRL_RX_START_THLD_MASK) >> MP2_I3C0_DATA_BUFFER_THLD_CTRL_RX_START_THLD_SHIFT)
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_GET_RESERVED0(mp2_i3c0_data_buffer_thld_ctrl) \
     ((mp2_i3c0_data_buffer_thld_ctrl & MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED0_MASK) >> MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED0_SHIFT)

#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_SET_TX_BUF_THLD(mp2_i3c0_data_buffer_thld_ctrl_reg, tx_buf_thld) \
     mp2_i3c0_data_buffer_thld_ctrl_reg = (mp2_i3c0_data_buffer_thld_ctrl_reg & ~MP2_I3C0_DATA_BUFFER_THLD_CTRL_TX_BUF_THLD_MASK) | (tx_buf_thld << MP2_I3C0_DATA_BUFFER_THLD_CTRL_TX_BUF_THLD_SHIFT)
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_SET_RESERVED3(mp2_i3c0_data_buffer_thld_ctrl_reg, reserved3) \
     mp2_i3c0_data_buffer_thld_ctrl_reg = (mp2_i3c0_data_buffer_thld_ctrl_reg & ~MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED3_MASK) | (reserved3 << MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED3_SHIFT)
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_SET_RX_BUF_THLD(mp2_i3c0_data_buffer_thld_ctrl_reg, rx_buf_thld) \
     mp2_i3c0_data_buffer_thld_ctrl_reg = (mp2_i3c0_data_buffer_thld_ctrl_reg & ~MP2_I3C0_DATA_BUFFER_THLD_CTRL_RX_BUF_THLD_MASK) | (rx_buf_thld << MP2_I3C0_DATA_BUFFER_THLD_CTRL_RX_BUF_THLD_SHIFT)
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_SET_RESERVED2(mp2_i3c0_data_buffer_thld_ctrl_reg, reserved2) \
     mp2_i3c0_data_buffer_thld_ctrl_reg = (mp2_i3c0_data_buffer_thld_ctrl_reg & ~MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED2_MASK) | (reserved2 << MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED2_SHIFT)
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_SET_TX_START_THLD(mp2_i3c0_data_buffer_thld_ctrl_reg, tx_start_thld) \
     mp2_i3c0_data_buffer_thld_ctrl_reg = (mp2_i3c0_data_buffer_thld_ctrl_reg & ~MP2_I3C0_DATA_BUFFER_THLD_CTRL_TX_START_THLD_MASK) | (tx_start_thld << MP2_I3C0_DATA_BUFFER_THLD_CTRL_TX_START_THLD_SHIFT)
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_SET_RESERVED1(mp2_i3c0_data_buffer_thld_ctrl_reg, reserved1) \
     mp2_i3c0_data_buffer_thld_ctrl_reg = (mp2_i3c0_data_buffer_thld_ctrl_reg & ~MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED1_MASK) | (reserved1 << MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED1_SHIFT)
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_SET_RX_START_THLD(mp2_i3c0_data_buffer_thld_ctrl_reg, rx_start_thld) \
     mp2_i3c0_data_buffer_thld_ctrl_reg = (mp2_i3c0_data_buffer_thld_ctrl_reg & ~MP2_I3C0_DATA_BUFFER_THLD_CTRL_RX_START_THLD_MASK) | (rx_start_thld << MP2_I3C0_DATA_BUFFER_THLD_CTRL_RX_START_THLD_SHIFT)
#define MP2_I3C0_DATA_BUFFER_THLD_CTRL_SET_RESERVED0(mp2_i3c0_data_buffer_thld_ctrl_reg, reserved0) \
     mp2_i3c0_data_buffer_thld_ctrl_reg = (mp2_i3c0_data_buffer_thld_ctrl_reg & ~MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED0_MASK) | (reserved0 << MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_data_buffer_thld_ctrl_t {
          unsigned int tx_buf_thld                    : MP2_I3C0_DATA_BUFFER_THLD_CTRL_TX_BUF_THLD_SIZE;
          unsigned int reserved3                      : MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED3_SIZE;
          unsigned int rx_buf_thld                    : MP2_I3C0_DATA_BUFFER_THLD_CTRL_RX_BUF_THLD_SIZE;
          unsigned int reserved2                      : MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED2_SIZE;
          unsigned int tx_start_thld                  : MP2_I3C0_DATA_BUFFER_THLD_CTRL_TX_START_THLD_SIZE;
          unsigned int reserved1                      : MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED1_SIZE;
          unsigned int rx_start_thld                  : MP2_I3C0_DATA_BUFFER_THLD_CTRL_RX_START_THLD_SIZE;
          unsigned int reserved0                      : MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED0_SIZE;
     } mp2_i3c0_data_buffer_thld_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_data_buffer_thld_ctrl_t {
          unsigned int reserved0                      : MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED0_SIZE;
          unsigned int rx_start_thld                  : MP2_I3C0_DATA_BUFFER_THLD_CTRL_RX_START_THLD_SIZE;
          unsigned int reserved1                      : MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED1_SIZE;
          unsigned int tx_start_thld                  : MP2_I3C0_DATA_BUFFER_THLD_CTRL_TX_START_THLD_SIZE;
          unsigned int reserved2                      : MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED2_SIZE;
          unsigned int rx_buf_thld                    : MP2_I3C0_DATA_BUFFER_THLD_CTRL_RX_BUF_THLD_SIZE;
          unsigned int reserved3                      : MP2_I3C0_DATA_BUFFER_THLD_CTRL_RESERVED3_SIZE;
          unsigned int tx_buf_thld                    : MP2_I3C0_DATA_BUFFER_THLD_CTRL_TX_BUF_THLD_SIZE;
     } mp2_i3c0_data_buffer_thld_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_data_buffer_thld_ctrl_t f;
} mp2_i3c0_data_buffer_thld_ctrl_u;


/*
 * MP2_I3C0_QUEUE_SIZE_CTRL struct
 */

#define MP2_I3C0_QUEUE_SIZE_CTRL_REG_SIZE 32
#define MP2_I3C0_QUEUE_SIZE_CTRL_CR_QUEUE_SIZE_SIZE 8
#define MP2_I3C0_QUEUE_SIZE_CTRL_IBI_STATUS_SIZE_SIZE 8
#define MP2_I3C0_QUEUE_SIZE_CTRL_RX_DATA_BUFFER_SIZE_SIZE 8
#define MP2_I3C0_QUEUE_SIZE_CTRL_TX_DATA_BUFFER_SIZE_SIZE 8

#define MP2_I3C0_QUEUE_SIZE_CTRL_CR_QUEUE_SIZE_SHIFT 0
#define MP2_I3C0_QUEUE_SIZE_CTRL_IBI_STATUS_SIZE_SHIFT 8
#define MP2_I3C0_QUEUE_SIZE_CTRL_RX_DATA_BUFFER_SIZE_SHIFT 16
#define MP2_I3C0_QUEUE_SIZE_CTRL_TX_DATA_BUFFER_SIZE_SHIFT 24

#define MP2_I3C0_QUEUE_SIZE_CTRL_CR_QUEUE_SIZE_MASK 0xff
#define MP2_I3C0_QUEUE_SIZE_CTRL_IBI_STATUS_SIZE_MASK 0xff00
#define MP2_I3C0_QUEUE_SIZE_CTRL_RX_DATA_BUFFER_SIZE_MASK 0xff0000
#define MP2_I3C0_QUEUE_SIZE_CTRL_TX_DATA_BUFFER_SIZE_MASK 0xff000000

#define MP2_I3C0_QUEUE_SIZE_CTRL_MASK \
     (MP2_I3C0_QUEUE_SIZE_CTRL_CR_QUEUE_SIZE_MASK | \
      MP2_I3C0_QUEUE_SIZE_CTRL_IBI_STATUS_SIZE_MASK | \
      MP2_I3C0_QUEUE_SIZE_CTRL_RX_DATA_BUFFER_SIZE_MASK | \
      MP2_I3C0_QUEUE_SIZE_CTRL_TX_DATA_BUFFER_SIZE_MASK)

#define MP2_I3C0_QUEUE_SIZE_CTRL_DEFAULT 0x05051010

#define MP2_I3C0_QUEUE_SIZE_CTRL_GET_CR_QUEUE_SIZE(mp2_i3c0_queue_size_ctrl) \
     ((mp2_i3c0_queue_size_ctrl & MP2_I3C0_QUEUE_SIZE_CTRL_CR_QUEUE_SIZE_MASK) >> MP2_I3C0_QUEUE_SIZE_CTRL_CR_QUEUE_SIZE_SHIFT)
#define MP2_I3C0_QUEUE_SIZE_CTRL_GET_IBI_STATUS_SIZE(mp2_i3c0_queue_size_ctrl) \
     ((mp2_i3c0_queue_size_ctrl & MP2_I3C0_QUEUE_SIZE_CTRL_IBI_STATUS_SIZE_MASK) >> MP2_I3C0_QUEUE_SIZE_CTRL_IBI_STATUS_SIZE_SHIFT)
#define MP2_I3C0_QUEUE_SIZE_CTRL_GET_RX_DATA_BUFFER_SIZE(mp2_i3c0_queue_size_ctrl) \
     ((mp2_i3c0_queue_size_ctrl & MP2_I3C0_QUEUE_SIZE_CTRL_RX_DATA_BUFFER_SIZE_MASK) >> MP2_I3C0_QUEUE_SIZE_CTRL_RX_DATA_BUFFER_SIZE_SHIFT)
#define MP2_I3C0_QUEUE_SIZE_CTRL_GET_TX_DATA_BUFFER_SIZE(mp2_i3c0_queue_size_ctrl) \
     ((mp2_i3c0_queue_size_ctrl & MP2_I3C0_QUEUE_SIZE_CTRL_TX_DATA_BUFFER_SIZE_MASK) >> MP2_I3C0_QUEUE_SIZE_CTRL_TX_DATA_BUFFER_SIZE_SHIFT)

#define MP2_I3C0_QUEUE_SIZE_CTRL_SET_CR_QUEUE_SIZE(mp2_i3c0_queue_size_ctrl_reg, cr_queue_size) \
     mp2_i3c0_queue_size_ctrl_reg = (mp2_i3c0_queue_size_ctrl_reg & ~MP2_I3C0_QUEUE_SIZE_CTRL_CR_QUEUE_SIZE_MASK) | (cr_queue_size << MP2_I3C0_QUEUE_SIZE_CTRL_CR_QUEUE_SIZE_SHIFT)
#define MP2_I3C0_QUEUE_SIZE_CTRL_SET_IBI_STATUS_SIZE(mp2_i3c0_queue_size_ctrl_reg, ibi_status_size) \
     mp2_i3c0_queue_size_ctrl_reg = (mp2_i3c0_queue_size_ctrl_reg & ~MP2_I3C0_QUEUE_SIZE_CTRL_IBI_STATUS_SIZE_MASK) | (ibi_status_size << MP2_I3C0_QUEUE_SIZE_CTRL_IBI_STATUS_SIZE_SHIFT)
#define MP2_I3C0_QUEUE_SIZE_CTRL_SET_RX_DATA_BUFFER_SIZE(mp2_i3c0_queue_size_ctrl_reg, rx_data_buffer_size) \
     mp2_i3c0_queue_size_ctrl_reg = (mp2_i3c0_queue_size_ctrl_reg & ~MP2_I3C0_QUEUE_SIZE_CTRL_RX_DATA_BUFFER_SIZE_MASK) | (rx_data_buffer_size << MP2_I3C0_QUEUE_SIZE_CTRL_RX_DATA_BUFFER_SIZE_SHIFT)
#define MP2_I3C0_QUEUE_SIZE_CTRL_SET_TX_DATA_BUFFER_SIZE(mp2_i3c0_queue_size_ctrl_reg, tx_data_buffer_size) \
     mp2_i3c0_queue_size_ctrl_reg = (mp2_i3c0_queue_size_ctrl_reg & ~MP2_I3C0_QUEUE_SIZE_CTRL_TX_DATA_BUFFER_SIZE_MASK) | (tx_data_buffer_size << MP2_I3C0_QUEUE_SIZE_CTRL_TX_DATA_BUFFER_SIZE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_queue_size_ctrl_t {
          unsigned int cr_queue_size                  : MP2_I3C0_QUEUE_SIZE_CTRL_CR_QUEUE_SIZE_SIZE;
          unsigned int ibi_status_size                : MP2_I3C0_QUEUE_SIZE_CTRL_IBI_STATUS_SIZE_SIZE;
          unsigned int rx_data_buffer_size            : MP2_I3C0_QUEUE_SIZE_CTRL_RX_DATA_BUFFER_SIZE_SIZE;
          unsigned int tx_data_buffer_size            : MP2_I3C0_QUEUE_SIZE_CTRL_TX_DATA_BUFFER_SIZE_SIZE;
     } mp2_i3c0_queue_size_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_queue_size_ctrl_t {
          unsigned int tx_data_buffer_size            : MP2_I3C0_QUEUE_SIZE_CTRL_TX_DATA_BUFFER_SIZE_SIZE;
          unsigned int rx_data_buffer_size            : MP2_I3C0_QUEUE_SIZE_CTRL_RX_DATA_BUFFER_SIZE_SIZE;
          unsigned int ibi_status_size                : MP2_I3C0_QUEUE_SIZE_CTRL_IBI_STATUS_SIZE_SIZE;
          unsigned int cr_queue_size                  : MP2_I3C0_QUEUE_SIZE_CTRL_CR_QUEUE_SIZE_SIZE;
     } mp2_i3c0_queue_size_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_queue_size_ctrl_t f;
} mp2_i3c0_queue_size_ctrl_u;


/*
 * MP2_I3C0_PIO_INTR_STATUS struct
 */

#define MP2_I3C0_PIO_INTR_STATUS_REG_SIZE 32
#define MP2_I3C0_PIO_INTR_STATUS_TX_THLD_STAT_SIZE 1
#define MP2_I3C0_PIO_INTR_STATUS_RX_THLD_STAT_SIZE 1
#define MP2_I3C0_PIO_INTR_STATUS_IBI_STATUS_THLD_STAT_SIZE 1
#define MP2_I3C0_PIO_INTR_STATUS_CMD_QUEUE_READY_STAT_SIZE 1
#define MP2_I3C0_PIO_INTR_STATUS_RESP_READY_STAT_SIZE 1
#define MP2_I3C0_PIO_INTR_STATUS_TRANSFER_ABORT_STAT_SIZE 1
#define MP2_I3C0_PIO_INTR_STATUS_RESERVED1_SIZE 3
#define MP2_I3C0_PIO_INTR_STATUS_TRANSFER_ERR_STAT_SIZE 1
#define MP2_I3C0_PIO_INTR_STATUS_RESERVED0_SIZE 22

#define MP2_I3C0_PIO_INTR_STATUS_TX_THLD_STAT_SHIFT 0
#define MP2_I3C0_PIO_INTR_STATUS_RX_THLD_STAT_SHIFT 1
#define MP2_I3C0_PIO_INTR_STATUS_IBI_STATUS_THLD_STAT_SHIFT 2
#define MP2_I3C0_PIO_INTR_STATUS_CMD_QUEUE_READY_STAT_SHIFT 3
#define MP2_I3C0_PIO_INTR_STATUS_RESP_READY_STAT_SHIFT 4
#define MP2_I3C0_PIO_INTR_STATUS_TRANSFER_ABORT_STAT_SHIFT 5
#define MP2_I3C0_PIO_INTR_STATUS_RESERVED1_SHIFT 6
#define MP2_I3C0_PIO_INTR_STATUS_TRANSFER_ERR_STAT_SHIFT 9
#define MP2_I3C0_PIO_INTR_STATUS_RESERVED0_SHIFT 10

#define MP2_I3C0_PIO_INTR_STATUS_TX_THLD_STAT_MASK 0x1
#define MP2_I3C0_PIO_INTR_STATUS_RX_THLD_STAT_MASK 0x2
#define MP2_I3C0_PIO_INTR_STATUS_IBI_STATUS_THLD_STAT_MASK 0x4
#define MP2_I3C0_PIO_INTR_STATUS_CMD_QUEUE_READY_STAT_MASK 0x8
#define MP2_I3C0_PIO_INTR_STATUS_RESP_READY_STAT_MASK 0x10
#define MP2_I3C0_PIO_INTR_STATUS_TRANSFER_ABORT_STAT_MASK 0x20
#define MP2_I3C0_PIO_INTR_STATUS_RESERVED1_MASK 0x1c0
#define MP2_I3C0_PIO_INTR_STATUS_TRANSFER_ERR_STAT_MASK 0x200
#define MP2_I3C0_PIO_INTR_STATUS_RESERVED0_MASK 0xfffffc00

#define MP2_I3C0_PIO_INTR_STATUS_MASK \
     (MP2_I3C0_PIO_INTR_STATUS_TX_THLD_STAT_MASK | \
      MP2_I3C0_PIO_INTR_STATUS_RX_THLD_STAT_MASK | \
      MP2_I3C0_PIO_INTR_STATUS_IBI_STATUS_THLD_STAT_MASK | \
      MP2_I3C0_PIO_INTR_STATUS_CMD_QUEUE_READY_STAT_MASK | \
      MP2_I3C0_PIO_INTR_STATUS_RESP_READY_STAT_MASK | \
      MP2_I3C0_PIO_INTR_STATUS_TRANSFER_ABORT_STAT_MASK | \
      MP2_I3C0_PIO_INTR_STATUS_RESERVED1_MASK | \
      MP2_I3C0_PIO_INTR_STATUS_TRANSFER_ERR_STAT_MASK | \
      MP2_I3C0_PIO_INTR_STATUS_RESERVED0_MASK)

#define MP2_I3C0_PIO_INTR_STATUS_DEFAULT 0x00000000

#define MP2_I3C0_PIO_INTR_STATUS_GET_TX_THLD_STAT(mp2_i3c0_pio_intr_status) \
     ((mp2_i3c0_pio_intr_status & MP2_I3C0_PIO_INTR_STATUS_TX_THLD_STAT_MASK) >> MP2_I3C0_PIO_INTR_STATUS_TX_THLD_STAT_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_GET_RX_THLD_STAT(mp2_i3c0_pio_intr_status) \
     ((mp2_i3c0_pio_intr_status & MP2_I3C0_PIO_INTR_STATUS_RX_THLD_STAT_MASK) >> MP2_I3C0_PIO_INTR_STATUS_RX_THLD_STAT_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_GET_IBI_STATUS_THLD_STAT(mp2_i3c0_pio_intr_status) \
     ((mp2_i3c0_pio_intr_status & MP2_I3C0_PIO_INTR_STATUS_IBI_STATUS_THLD_STAT_MASK) >> MP2_I3C0_PIO_INTR_STATUS_IBI_STATUS_THLD_STAT_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_GET_CMD_QUEUE_READY_STAT(mp2_i3c0_pio_intr_status) \
     ((mp2_i3c0_pio_intr_status & MP2_I3C0_PIO_INTR_STATUS_CMD_QUEUE_READY_STAT_MASK) >> MP2_I3C0_PIO_INTR_STATUS_CMD_QUEUE_READY_STAT_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_GET_RESP_READY_STAT(mp2_i3c0_pio_intr_status) \
     ((mp2_i3c0_pio_intr_status & MP2_I3C0_PIO_INTR_STATUS_RESP_READY_STAT_MASK) >> MP2_I3C0_PIO_INTR_STATUS_RESP_READY_STAT_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_GET_TRANSFER_ABORT_STAT(mp2_i3c0_pio_intr_status) \
     ((mp2_i3c0_pio_intr_status & MP2_I3C0_PIO_INTR_STATUS_TRANSFER_ABORT_STAT_MASK) >> MP2_I3C0_PIO_INTR_STATUS_TRANSFER_ABORT_STAT_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_GET_RESERVED1(mp2_i3c0_pio_intr_status) \
     ((mp2_i3c0_pio_intr_status & MP2_I3C0_PIO_INTR_STATUS_RESERVED1_MASK) >> MP2_I3C0_PIO_INTR_STATUS_RESERVED1_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_GET_TRANSFER_ERR_STAT(mp2_i3c0_pio_intr_status) \
     ((mp2_i3c0_pio_intr_status & MP2_I3C0_PIO_INTR_STATUS_TRANSFER_ERR_STAT_MASK) >> MP2_I3C0_PIO_INTR_STATUS_TRANSFER_ERR_STAT_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_GET_RESERVED0(mp2_i3c0_pio_intr_status) \
     ((mp2_i3c0_pio_intr_status & MP2_I3C0_PIO_INTR_STATUS_RESERVED0_MASK) >> MP2_I3C0_PIO_INTR_STATUS_RESERVED0_SHIFT)

#define MP2_I3C0_PIO_INTR_STATUS_SET_TX_THLD_STAT(mp2_i3c0_pio_intr_status_reg, tx_thld_stat) \
     mp2_i3c0_pio_intr_status_reg = (mp2_i3c0_pio_intr_status_reg & ~MP2_I3C0_PIO_INTR_STATUS_TX_THLD_STAT_MASK) | (tx_thld_stat << MP2_I3C0_PIO_INTR_STATUS_TX_THLD_STAT_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_SET_RX_THLD_STAT(mp2_i3c0_pio_intr_status_reg, rx_thld_stat) \
     mp2_i3c0_pio_intr_status_reg = (mp2_i3c0_pio_intr_status_reg & ~MP2_I3C0_PIO_INTR_STATUS_RX_THLD_STAT_MASK) | (rx_thld_stat << MP2_I3C0_PIO_INTR_STATUS_RX_THLD_STAT_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_SET_IBI_STATUS_THLD_STAT(mp2_i3c0_pio_intr_status_reg, ibi_status_thld_stat) \
     mp2_i3c0_pio_intr_status_reg = (mp2_i3c0_pio_intr_status_reg & ~MP2_I3C0_PIO_INTR_STATUS_IBI_STATUS_THLD_STAT_MASK) | (ibi_status_thld_stat << MP2_I3C0_PIO_INTR_STATUS_IBI_STATUS_THLD_STAT_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_SET_CMD_QUEUE_READY_STAT(mp2_i3c0_pio_intr_status_reg, cmd_queue_ready_stat) \
     mp2_i3c0_pio_intr_status_reg = (mp2_i3c0_pio_intr_status_reg & ~MP2_I3C0_PIO_INTR_STATUS_CMD_QUEUE_READY_STAT_MASK) | (cmd_queue_ready_stat << MP2_I3C0_PIO_INTR_STATUS_CMD_QUEUE_READY_STAT_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_SET_RESP_READY_STAT(mp2_i3c0_pio_intr_status_reg, resp_ready_stat) \
     mp2_i3c0_pio_intr_status_reg = (mp2_i3c0_pio_intr_status_reg & ~MP2_I3C0_PIO_INTR_STATUS_RESP_READY_STAT_MASK) | (resp_ready_stat << MP2_I3C0_PIO_INTR_STATUS_RESP_READY_STAT_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_SET_TRANSFER_ABORT_STAT(mp2_i3c0_pio_intr_status_reg, transfer_abort_stat) \
     mp2_i3c0_pio_intr_status_reg = (mp2_i3c0_pio_intr_status_reg & ~MP2_I3C0_PIO_INTR_STATUS_TRANSFER_ABORT_STAT_MASK) | (transfer_abort_stat << MP2_I3C0_PIO_INTR_STATUS_TRANSFER_ABORT_STAT_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_SET_RESERVED1(mp2_i3c0_pio_intr_status_reg, reserved1) \
     mp2_i3c0_pio_intr_status_reg = (mp2_i3c0_pio_intr_status_reg & ~MP2_I3C0_PIO_INTR_STATUS_RESERVED1_MASK) | (reserved1 << MP2_I3C0_PIO_INTR_STATUS_RESERVED1_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_SET_TRANSFER_ERR_STAT(mp2_i3c0_pio_intr_status_reg, transfer_err_stat) \
     mp2_i3c0_pio_intr_status_reg = (mp2_i3c0_pio_intr_status_reg & ~MP2_I3C0_PIO_INTR_STATUS_TRANSFER_ERR_STAT_MASK) | (transfer_err_stat << MP2_I3C0_PIO_INTR_STATUS_TRANSFER_ERR_STAT_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_SET_RESERVED0(mp2_i3c0_pio_intr_status_reg, reserved0) \
     mp2_i3c0_pio_intr_status_reg = (mp2_i3c0_pio_intr_status_reg & ~MP2_I3C0_PIO_INTR_STATUS_RESERVED0_MASK) | (reserved0 << MP2_I3C0_PIO_INTR_STATUS_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_pio_intr_status_t {
          unsigned int tx_thld_stat                   : MP2_I3C0_PIO_INTR_STATUS_TX_THLD_STAT_SIZE;
          unsigned int rx_thld_stat                   : MP2_I3C0_PIO_INTR_STATUS_RX_THLD_STAT_SIZE;
          unsigned int ibi_status_thld_stat           : MP2_I3C0_PIO_INTR_STATUS_IBI_STATUS_THLD_STAT_SIZE;
          unsigned int cmd_queue_ready_stat           : MP2_I3C0_PIO_INTR_STATUS_CMD_QUEUE_READY_STAT_SIZE;
          unsigned int resp_ready_stat                : MP2_I3C0_PIO_INTR_STATUS_RESP_READY_STAT_SIZE;
          unsigned int transfer_abort_stat            : MP2_I3C0_PIO_INTR_STATUS_TRANSFER_ABORT_STAT_SIZE;
          unsigned int reserved1                      : MP2_I3C0_PIO_INTR_STATUS_RESERVED1_SIZE;
          unsigned int transfer_err_stat              : MP2_I3C0_PIO_INTR_STATUS_TRANSFER_ERR_STAT_SIZE;
          unsigned int reserved0                      : MP2_I3C0_PIO_INTR_STATUS_RESERVED0_SIZE;
     } mp2_i3c0_pio_intr_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_pio_intr_status_t {
          unsigned int reserved0                      : MP2_I3C0_PIO_INTR_STATUS_RESERVED0_SIZE;
          unsigned int transfer_err_stat              : MP2_I3C0_PIO_INTR_STATUS_TRANSFER_ERR_STAT_SIZE;
          unsigned int reserved1                      : MP2_I3C0_PIO_INTR_STATUS_RESERVED1_SIZE;
          unsigned int transfer_abort_stat            : MP2_I3C0_PIO_INTR_STATUS_TRANSFER_ABORT_STAT_SIZE;
          unsigned int resp_ready_stat                : MP2_I3C0_PIO_INTR_STATUS_RESP_READY_STAT_SIZE;
          unsigned int cmd_queue_ready_stat           : MP2_I3C0_PIO_INTR_STATUS_CMD_QUEUE_READY_STAT_SIZE;
          unsigned int ibi_status_thld_stat           : MP2_I3C0_PIO_INTR_STATUS_IBI_STATUS_THLD_STAT_SIZE;
          unsigned int rx_thld_stat                   : MP2_I3C0_PIO_INTR_STATUS_RX_THLD_STAT_SIZE;
          unsigned int tx_thld_stat                   : MP2_I3C0_PIO_INTR_STATUS_TX_THLD_STAT_SIZE;
     } mp2_i3c0_pio_intr_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_pio_intr_status_t f;
} mp2_i3c0_pio_intr_status_u;


/*
 * MP2_I3C0_PIO_INTR_STATUS_ENABLE struct
 */

#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_REG_SIZE 32
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_TX_THLD_STAT_EN_SIZE 1
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_RX_THLD_STAT_EN_SIZE 1
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_IBI_THLD_STAT_EN_SIZE 1
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_CMD_QUEUE_READY_STAT_EN_SIZE 1
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESP_READY_STAT_INTR_EN_SIZE 1
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_TRANSFER_ABORT_STAT_EN_SIZE 1
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESERVED1_SIZE 3
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_TRANSFER_ERR_STAT_EN_SIZE 1
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESERVED0_SIZE 22

#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_TX_THLD_STAT_EN_SHIFT 0
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_RX_THLD_STAT_EN_SHIFT 1
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_IBI_THLD_STAT_EN_SHIFT 2
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_CMD_QUEUE_READY_STAT_EN_SHIFT 3
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESP_READY_STAT_INTR_EN_SHIFT 4
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_TRANSFER_ABORT_STAT_EN_SHIFT 5
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESERVED1_SHIFT 6
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_TRANSFER_ERR_STAT_EN_SHIFT 9
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESERVED0_SHIFT 10

#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_TX_THLD_STAT_EN_MASK 0x1
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_RX_THLD_STAT_EN_MASK 0x2
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_IBI_THLD_STAT_EN_MASK 0x4
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_CMD_QUEUE_READY_STAT_EN_MASK 0x8
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESP_READY_STAT_INTR_EN_MASK 0x10
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_TRANSFER_ABORT_STAT_EN_MASK 0x20
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESERVED1_MASK 0x1c0
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_TRANSFER_ERR_STAT_EN_MASK 0x200
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESERVED0_MASK 0xfffffc00

#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_MASK \
     (MP2_I3C0_PIO_INTR_STATUS_ENABLE_TX_THLD_STAT_EN_MASK | \
      MP2_I3C0_PIO_INTR_STATUS_ENABLE_RX_THLD_STAT_EN_MASK | \
      MP2_I3C0_PIO_INTR_STATUS_ENABLE_IBI_THLD_STAT_EN_MASK | \
      MP2_I3C0_PIO_INTR_STATUS_ENABLE_CMD_QUEUE_READY_STAT_EN_MASK | \
      MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESP_READY_STAT_INTR_EN_MASK | \
      MP2_I3C0_PIO_INTR_STATUS_ENABLE_TRANSFER_ABORT_STAT_EN_MASK | \
      MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESERVED1_MASK | \
      MP2_I3C0_PIO_INTR_STATUS_ENABLE_TRANSFER_ERR_STAT_EN_MASK | \
      MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESERVED0_MASK)

#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_DEFAULT 0x00000000

#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_GET_TX_THLD_STAT_EN(mp2_i3c0_pio_intr_status_enable) \
     ((mp2_i3c0_pio_intr_status_enable & MP2_I3C0_PIO_INTR_STATUS_ENABLE_TX_THLD_STAT_EN_MASK) >> MP2_I3C0_PIO_INTR_STATUS_ENABLE_TX_THLD_STAT_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_GET_RX_THLD_STAT_EN(mp2_i3c0_pio_intr_status_enable) \
     ((mp2_i3c0_pio_intr_status_enable & MP2_I3C0_PIO_INTR_STATUS_ENABLE_RX_THLD_STAT_EN_MASK) >> MP2_I3C0_PIO_INTR_STATUS_ENABLE_RX_THLD_STAT_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_GET_IBI_THLD_STAT_EN(mp2_i3c0_pio_intr_status_enable) \
     ((mp2_i3c0_pio_intr_status_enable & MP2_I3C0_PIO_INTR_STATUS_ENABLE_IBI_THLD_STAT_EN_MASK) >> MP2_I3C0_PIO_INTR_STATUS_ENABLE_IBI_THLD_STAT_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_GET_CMD_QUEUE_READY_STAT_EN(mp2_i3c0_pio_intr_status_enable) \
     ((mp2_i3c0_pio_intr_status_enable & MP2_I3C0_PIO_INTR_STATUS_ENABLE_CMD_QUEUE_READY_STAT_EN_MASK) >> MP2_I3C0_PIO_INTR_STATUS_ENABLE_CMD_QUEUE_READY_STAT_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_GET_RESP_READY_STAT_INTR_EN(mp2_i3c0_pio_intr_status_enable) \
     ((mp2_i3c0_pio_intr_status_enable & MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESP_READY_STAT_INTR_EN_MASK) >> MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESP_READY_STAT_INTR_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_GET_TRANSFER_ABORT_STAT_EN(mp2_i3c0_pio_intr_status_enable) \
     ((mp2_i3c0_pio_intr_status_enable & MP2_I3C0_PIO_INTR_STATUS_ENABLE_TRANSFER_ABORT_STAT_EN_MASK) >> MP2_I3C0_PIO_INTR_STATUS_ENABLE_TRANSFER_ABORT_STAT_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_GET_RESERVED1(mp2_i3c0_pio_intr_status_enable) \
     ((mp2_i3c0_pio_intr_status_enable & MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESERVED1_MASK) >> MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESERVED1_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_GET_TRANSFER_ERR_STAT_EN(mp2_i3c0_pio_intr_status_enable) \
     ((mp2_i3c0_pio_intr_status_enable & MP2_I3C0_PIO_INTR_STATUS_ENABLE_TRANSFER_ERR_STAT_EN_MASK) >> MP2_I3C0_PIO_INTR_STATUS_ENABLE_TRANSFER_ERR_STAT_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_GET_RESERVED0(mp2_i3c0_pio_intr_status_enable) \
     ((mp2_i3c0_pio_intr_status_enable & MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESERVED0_MASK) >> MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESERVED0_SHIFT)

#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_SET_TX_THLD_STAT_EN(mp2_i3c0_pio_intr_status_enable_reg, tx_thld_stat_en) \
     mp2_i3c0_pio_intr_status_enable_reg = (mp2_i3c0_pio_intr_status_enable_reg & ~MP2_I3C0_PIO_INTR_STATUS_ENABLE_TX_THLD_STAT_EN_MASK) | (tx_thld_stat_en << MP2_I3C0_PIO_INTR_STATUS_ENABLE_TX_THLD_STAT_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_SET_RX_THLD_STAT_EN(mp2_i3c0_pio_intr_status_enable_reg, rx_thld_stat_en) \
     mp2_i3c0_pio_intr_status_enable_reg = (mp2_i3c0_pio_intr_status_enable_reg & ~MP2_I3C0_PIO_INTR_STATUS_ENABLE_RX_THLD_STAT_EN_MASK) | (rx_thld_stat_en << MP2_I3C0_PIO_INTR_STATUS_ENABLE_RX_THLD_STAT_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_SET_IBI_THLD_STAT_EN(mp2_i3c0_pio_intr_status_enable_reg, ibi_thld_stat_en) \
     mp2_i3c0_pio_intr_status_enable_reg = (mp2_i3c0_pio_intr_status_enable_reg & ~MP2_I3C0_PIO_INTR_STATUS_ENABLE_IBI_THLD_STAT_EN_MASK) | (ibi_thld_stat_en << MP2_I3C0_PIO_INTR_STATUS_ENABLE_IBI_THLD_STAT_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_SET_CMD_QUEUE_READY_STAT_EN(mp2_i3c0_pio_intr_status_enable_reg, cmd_queue_ready_stat_en) \
     mp2_i3c0_pio_intr_status_enable_reg = (mp2_i3c0_pio_intr_status_enable_reg & ~MP2_I3C0_PIO_INTR_STATUS_ENABLE_CMD_QUEUE_READY_STAT_EN_MASK) | (cmd_queue_ready_stat_en << MP2_I3C0_PIO_INTR_STATUS_ENABLE_CMD_QUEUE_READY_STAT_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_SET_RESP_READY_STAT_INTR_EN(mp2_i3c0_pio_intr_status_enable_reg, resp_ready_stat_intr_en) \
     mp2_i3c0_pio_intr_status_enable_reg = (mp2_i3c0_pio_intr_status_enable_reg & ~MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESP_READY_STAT_INTR_EN_MASK) | (resp_ready_stat_intr_en << MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESP_READY_STAT_INTR_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_SET_TRANSFER_ABORT_STAT_EN(mp2_i3c0_pio_intr_status_enable_reg, transfer_abort_stat_en) \
     mp2_i3c0_pio_intr_status_enable_reg = (mp2_i3c0_pio_intr_status_enable_reg & ~MP2_I3C0_PIO_INTR_STATUS_ENABLE_TRANSFER_ABORT_STAT_EN_MASK) | (transfer_abort_stat_en << MP2_I3C0_PIO_INTR_STATUS_ENABLE_TRANSFER_ABORT_STAT_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_SET_RESERVED1(mp2_i3c0_pio_intr_status_enable_reg, reserved1) \
     mp2_i3c0_pio_intr_status_enable_reg = (mp2_i3c0_pio_intr_status_enable_reg & ~MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESERVED1_MASK) | (reserved1 << MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESERVED1_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_SET_TRANSFER_ERR_STAT_EN(mp2_i3c0_pio_intr_status_enable_reg, transfer_err_stat_en) \
     mp2_i3c0_pio_intr_status_enable_reg = (mp2_i3c0_pio_intr_status_enable_reg & ~MP2_I3C0_PIO_INTR_STATUS_ENABLE_TRANSFER_ERR_STAT_EN_MASK) | (transfer_err_stat_en << MP2_I3C0_PIO_INTR_STATUS_ENABLE_TRANSFER_ERR_STAT_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_STATUS_ENABLE_SET_RESERVED0(mp2_i3c0_pio_intr_status_enable_reg, reserved0) \
     mp2_i3c0_pio_intr_status_enable_reg = (mp2_i3c0_pio_intr_status_enable_reg & ~MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESERVED0_MASK) | (reserved0 << MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_pio_intr_status_enable_t {
          unsigned int tx_thld_stat_en                : MP2_I3C0_PIO_INTR_STATUS_ENABLE_TX_THLD_STAT_EN_SIZE;
          unsigned int rx_thld_stat_en                : MP2_I3C0_PIO_INTR_STATUS_ENABLE_RX_THLD_STAT_EN_SIZE;
          unsigned int ibi_thld_stat_en               : MP2_I3C0_PIO_INTR_STATUS_ENABLE_IBI_THLD_STAT_EN_SIZE;
          unsigned int cmd_queue_ready_stat_en        : MP2_I3C0_PIO_INTR_STATUS_ENABLE_CMD_QUEUE_READY_STAT_EN_SIZE;
          unsigned int resp_ready_stat_intr_en        : MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESP_READY_STAT_INTR_EN_SIZE;
          unsigned int transfer_abort_stat_en         : MP2_I3C0_PIO_INTR_STATUS_ENABLE_TRANSFER_ABORT_STAT_EN_SIZE;
          unsigned int reserved1                      : MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESERVED1_SIZE;
          unsigned int transfer_err_stat_en           : MP2_I3C0_PIO_INTR_STATUS_ENABLE_TRANSFER_ERR_STAT_EN_SIZE;
          unsigned int reserved0                      : MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESERVED0_SIZE;
     } mp2_i3c0_pio_intr_status_enable_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_pio_intr_status_enable_t {
          unsigned int reserved0                      : MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESERVED0_SIZE;
          unsigned int transfer_err_stat_en           : MP2_I3C0_PIO_INTR_STATUS_ENABLE_TRANSFER_ERR_STAT_EN_SIZE;
          unsigned int reserved1                      : MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESERVED1_SIZE;
          unsigned int transfer_abort_stat_en         : MP2_I3C0_PIO_INTR_STATUS_ENABLE_TRANSFER_ABORT_STAT_EN_SIZE;
          unsigned int resp_ready_stat_intr_en        : MP2_I3C0_PIO_INTR_STATUS_ENABLE_RESP_READY_STAT_INTR_EN_SIZE;
          unsigned int cmd_queue_ready_stat_en        : MP2_I3C0_PIO_INTR_STATUS_ENABLE_CMD_QUEUE_READY_STAT_EN_SIZE;
          unsigned int ibi_thld_stat_en               : MP2_I3C0_PIO_INTR_STATUS_ENABLE_IBI_THLD_STAT_EN_SIZE;
          unsigned int rx_thld_stat_en                : MP2_I3C0_PIO_INTR_STATUS_ENABLE_RX_THLD_STAT_EN_SIZE;
          unsigned int tx_thld_stat_en                : MP2_I3C0_PIO_INTR_STATUS_ENABLE_TX_THLD_STAT_EN_SIZE;
     } mp2_i3c0_pio_intr_status_enable_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_pio_intr_status_enable_t f;
} mp2_i3c0_pio_intr_status_enable_u;


/*
 * MP2_I3C0_PIO_INTR_SIGNAL_ENABLE struct
 */

#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_REG_SIZE 32
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TX_THLD_SIGNAL_EN_SIZE 1
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RX_THLD_SIGNAL_EN_SIZE 1
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_IBI_THLD_SIGNAL_EN_SIZE 1
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_CMD_QUEUE_READY_SIGNAL_EN_SIZE 1
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESP_READY_SIGNAL_EN_SIZE 1
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TRANSFER_ABORT_SIGNAL_EN_SIZE 1
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESERVED1_SIZE 3
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TRANSFER_ERR_SIGNAL_EN_SIZE 1
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESERVED0_SIZE 22

#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TX_THLD_SIGNAL_EN_SHIFT 0
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RX_THLD_SIGNAL_EN_SHIFT 1
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_IBI_THLD_SIGNAL_EN_SHIFT 2
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_CMD_QUEUE_READY_SIGNAL_EN_SHIFT 3
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESP_READY_SIGNAL_EN_SHIFT 4
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TRANSFER_ABORT_SIGNAL_EN_SHIFT 5
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESERVED1_SHIFT 6
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TRANSFER_ERR_SIGNAL_EN_SHIFT 9
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESERVED0_SHIFT 10

#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TX_THLD_SIGNAL_EN_MASK 0x1
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RX_THLD_SIGNAL_EN_MASK 0x2
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_IBI_THLD_SIGNAL_EN_MASK 0x4
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_CMD_QUEUE_READY_SIGNAL_EN_MASK 0x8
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESP_READY_SIGNAL_EN_MASK 0x10
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TRANSFER_ABORT_SIGNAL_EN_MASK 0x20
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESERVED1_MASK 0x1c0
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TRANSFER_ERR_SIGNAL_EN_MASK 0x200
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESERVED0_MASK 0xfffffc00

#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_MASK \
     (MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TX_THLD_SIGNAL_EN_MASK | \
      MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RX_THLD_SIGNAL_EN_MASK | \
      MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_IBI_THLD_SIGNAL_EN_MASK | \
      MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_CMD_QUEUE_READY_SIGNAL_EN_MASK | \
      MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESP_READY_SIGNAL_EN_MASK | \
      MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TRANSFER_ABORT_SIGNAL_EN_MASK | \
      MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESERVED1_MASK | \
      MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TRANSFER_ERR_SIGNAL_EN_MASK | \
      MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESERVED0_MASK)

#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_DEFAULT 0x00000000

#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_GET_TX_THLD_SIGNAL_EN(mp2_i3c0_pio_intr_signal_enable) \
     ((mp2_i3c0_pio_intr_signal_enable & MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TX_THLD_SIGNAL_EN_MASK) >> MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TX_THLD_SIGNAL_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_GET_RX_THLD_SIGNAL_EN(mp2_i3c0_pio_intr_signal_enable) \
     ((mp2_i3c0_pio_intr_signal_enable & MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RX_THLD_SIGNAL_EN_MASK) >> MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RX_THLD_SIGNAL_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_GET_IBI_THLD_SIGNAL_EN(mp2_i3c0_pio_intr_signal_enable) \
     ((mp2_i3c0_pio_intr_signal_enable & MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_IBI_THLD_SIGNAL_EN_MASK) >> MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_IBI_THLD_SIGNAL_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_GET_CMD_QUEUE_READY_SIGNAL_EN(mp2_i3c0_pio_intr_signal_enable) \
     ((mp2_i3c0_pio_intr_signal_enable & MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_CMD_QUEUE_READY_SIGNAL_EN_MASK) >> MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_CMD_QUEUE_READY_SIGNAL_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_GET_RESP_READY_SIGNAL_EN(mp2_i3c0_pio_intr_signal_enable) \
     ((mp2_i3c0_pio_intr_signal_enable & MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESP_READY_SIGNAL_EN_MASK) >> MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESP_READY_SIGNAL_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_GET_TRANSFER_ABORT_SIGNAL_EN(mp2_i3c0_pio_intr_signal_enable) \
     ((mp2_i3c0_pio_intr_signal_enable & MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TRANSFER_ABORT_SIGNAL_EN_MASK) >> MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TRANSFER_ABORT_SIGNAL_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_GET_RESERVED1(mp2_i3c0_pio_intr_signal_enable) \
     ((mp2_i3c0_pio_intr_signal_enable & MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESERVED1_MASK) >> MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESERVED1_SHIFT)
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_GET_TRANSFER_ERR_SIGNAL_EN(mp2_i3c0_pio_intr_signal_enable) \
     ((mp2_i3c0_pio_intr_signal_enable & MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TRANSFER_ERR_SIGNAL_EN_MASK) >> MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TRANSFER_ERR_SIGNAL_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_GET_RESERVED0(mp2_i3c0_pio_intr_signal_enable) \
     ((mp2_i3c0_pio_intr_signal_enable & MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESERVED0_MASK) >> MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESERVED0_SHIFT)

#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_SET_TX_THLD_SIGNAL_EN(mp2_i3c0_pio_intr_signal_enable_reg, tx_thld_signal_en) \
     mp2_i3c0_pio_intr_signal_enable_reg = (mp2_i3c0_pio_intr_signal_enable_reg & ~MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TX_THLD_SIGNAL_EN_MASK) | (tx_thld_signal_en << MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TX_THLD_SIGNAL_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_SET_RX_THLD_SIGNAL_EN(mp2_i3c0_pio_intr_signal_enable_reg, rx_thld_signal_en) \
     mp2_i3c0_pio_intr_signal_enable_reg = (mp2_i3c0_pio_intr_signal_enable_reg & ~MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RX_THLD_SIGNAL_EN_MASK) | (rx_thld_signal_en << MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RX_THLD_SIGNAL_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_SET_IBI_THLD_SIGNAL_EN(mp2_i3c0_pio_intr_signal_enable_reg, ibi_thld_signal_en) \
     mp2_i3c0_pio_intr_signal_enable_reg = (mp2_i3c0_pio_intr_signal_enable_reg & ~MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_IBI_THLD_SIGNAL_EN_MASK) | (ibi_thld_signal_en << MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_IBI_THLD_SIGNAL_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_SET_CMD_QUEUE_READY_SIGNAL_EN(mp2_i3c0_pio_intr_signal_enable_reg, cmd_queue_ready_signal_en) \
     mp2_i3c0_pio_intr_signal_enable_reg = (mp2_i3c0_pio_intr_signal_enable_reg & ~MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_CMD_QUEUE_READY_SIGNAL_EN_MASK) | (cmd_queue_ready_signal_en << MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_CMD_QUEUE_READY_SIGNAL_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_SET_RESP_READY_SIGNAL_EN(mp2_i3c0_pio_intr_signal_enable_reg, resp_ready_signal_en) \
     mp2_i3c0_pio_intr_signal_enable_reg = (mp2_i3c0_pio_intr_signal_enable_reg & ~MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESP_READY_SIGNAL_EN_MASK) | (resp_ready_signal_en << MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESP_READY_SIGNAL_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_SET_TRANSFER_ABORT_SIGNAL_EN(mp2_i3c0_pio_intr_signal_enable_reg, transfer_abort_signal_en) \
     mp2_i3c0_pio_intr_signal_enable_reg = (mp2_i3c0_pio_intr_signal_enable_reg & ~MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TRANSFER_ABORT_SIGNAL_EN_MASK) | (transfer_abort_signal_en << MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TRANSFER_ABORT_SIGNAL_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_SET_RESERVED1(mp2_i3c0_pio_intr_signal_enable_reg, reserved1) \
     mp2_i3c0_pio_intr_signal_enable_reg = (mp2_i3c0_pio_intr_signal_enable_reg & ~MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESERVED1_MASK) | (reserved1 << MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESERVED1_SHIFT)
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_SET_TRANSFER_ERR_SIGNAL_EN(mp2_i3c0_pio_intr_signal_enable_reg, transfer_err_signal_en) \
     mp2_i3c0_pio_intr_signal_enable_reg = (mp2_i3c0_pio_intr_signal_enable_reg & ~MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TRANSFER_ERR_SIGNAL_EN_MASK) | (transfer_err_signal_en << MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TRANSFER_ERR_SIGNAL_EN_SHIFT)
#define MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_SET_RESERVED0(mp2_i3c0_pio_intr_signal_enable_reg, reserved0) \
     mp2_i3c0_pio_intr_signal_enable_reg = (mp2_i3c0_pio_intr_signal_enable_reg & ~MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESERVED0_MASK) | (reserved0 << MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_pio_intr_signal_enable_t {
          unsigned int tx_thld_signal_en              : MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TX_THLD_SIGNAL_EN_SIZE;
          unsigned int rx_thld_signal_en              : MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RX_THLD_SIGNAL_EN_SIZE;
          unsigned int ibi_thld_signal_en             : MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_IBI_THLD_SIGNAL_EN_SIZE;
          unsigned int cmd_queue_ready_signal_en      : MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_CMD_QUEUE_READY_SIGNAL_EN_SIZE;
          unsigned int resp_ready_signal_en           : MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESP_READY_SIGNAL_EN_SIZE;
          unsigned int transfer_abort_signal_en       : MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TRANSFER_ABORT_SIGNAL_EN_SIZE;
          unsigned int reserved1                      : MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESERVED1_SIZE;
          unsigned int transfer_err_signal_en         : MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TRANSFER_ERR_SIGNAL_EN_SIZE;
          unsigned int reserved0                      : MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESERVED0_SIZE;
     } mp2_i3c0_pio_intr_signal_enable_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_pio_intr_signal_enable_t {
          unsigned int reserved0                      : MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESERVED0_SIZE;
          unsigned int transfer_err_signal_en         : MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TRANSFER_ERR_SIGNAL_EN_SIZE;
          unsigned int reserved1                      : MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESERVED1_SIZE;
          unsigned int transfer_abort_signal_en       : MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TRANSFER_ABORT_SIGNAL_EN_SIZE;
          unsigned int resp_ready_signal_en           : MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RESP_READY_SIGNAL_EN_SIZE;
          unsigned int cmd_queue_ready_signal_en      : MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_CMD_QUEUE_READY_SIGNAL_EN_SIZE;
          unsigned int ibi_thld_signal_en             : MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_IBI_THLD_SIGNAL_EN_SIZE;
          unsigned int rx_thld_signal_en              : MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_RX_THLD_SIGNAL_EN_SIZE;
          unsigned int tx_thld_signal_en              : MP2_I3C0_PIO_INTR_SIGNAL_ENABLE_TX_THLD_SIGNAL_EN_SIZE;
     } mp2_i3c0_pio_intr_signal_enable_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_pio_intr_signal_enable_t f;
} mp2_i3c0_pio_intr_signal_enable_u;


/*
 * MP2_I3C0_PIO_INTR_FORCE struct
 */

#define MP2_I3C0_PIO_INTR_FORCE_REG_SIZE 32
#define MP2_I3C0_PIO_INTR_FORCE_TX_THLD_FORCE_SIZE 1
#define MP2_I3C0_PIO_INTR_FORCE_RX_THLD_FORCE_SIZE 1
#define MP2_I3C0_PIO_INTR_FORCE_IBI_THLD_FORCE_SIZE 1
#define MP2_I3C0_PIO_INTR_FORCE_CMD_QUEUE_READY_FORCE_SIZE 1
#define MP2_I3C0_PIO_INTR_FORCE_RESP_READY_FORCE_SIZE 1
#define MP2_I3C0_PIO_INTR_FORCE_TRANSFER_ABORT_FORCE_SIZE 1
#define MP2_I3C0_PIO_INTR_FORCE_RESERVED1_SIZE 3
#define MP2_I3C0_PIO_INTR_FORCE_TRANSFER_ERR_FORCE_SIZE 1
#define MP2_I3C0_PIO_INTR_FORCE_RESERVED0_SIZE 22

#define MP2_I3C0_PIO_INTR_FORCE_TX_THLD_FORCE_SHIFT 0
#define MP2_I3C0_PIO_INTR_FORCE_RX_THLD_FORCE_SHIFT 1
#define MP2_I3C0_PIO_INTR_FORCE_IBI_THLD_FORCE_SHIFT 2
#define MP2_I3C0_PIO_INTR_FORCE_CMD_QUEUE_READY_FORCE_SHIFT 3
#define MP2_I3C0_PIO_INTR_FORCE_RESP_READY_FORCE_SHIFT 4
#define MP2_I3C0_PIO_INTR_FORCE_TRANSFER_ABORT_FORCE_SHIFT 5
#define MP2_I3C0_PIO_INTR_FORCE_RESERVED1_SHIFT 6
#define MP2_I3C0_PIO_INTR_FORCE_TRANSFER_ERR_FORCE_SHIFT 9
#define MP2_I3C0_PIO_INTR_FORCE_RESERVED0_SHIFT 10

#define MP2_I3C0_PIO_INTR_FORCE_TX_THLD_FORCE_MASK 0x1
#define MP2_I3C0_PIO_INTR_FORCE_RX_THLD_FORCE_MASK 0x2
#define MP2_I3C0_PIO_INTR_FORCE_IBI_THLD_FORCE_MASK 0x4
#define MP2_I3C0_PIO_INTR_FORCE_CMD_QUEUE_READY_FORCE_MASK 0x8
#define MP2_I3C0_PIO_INTR_FORCE_RESP_READY_FORCE_MASK 0x10
#define MP2_I3C0_PIO_INTR_FORCE_TRANSFER_ABORT_FORCE_MASK 0x20
#define MP2_I3C0_PIO_INTR_FORCE_RESERVED1_MASK 0x1c0
#define MP2_I3C0_PIO_INTR_FORCE_TRANSFER_ERR_FORCE_MASK 0x200
#define MP2_I3C0_PIO_INTR_FORCE_RESERVED0_MASK 0xfffffc00

#define MP2_I3C0_PIO_INTR_FORCE_MASK \
     (MP2_I3C0_PIO_INTR_FORCE_TX_THLD_FORCE_MASK | \
      MP2_I3C0_PIO_INTR_FORCE_RX_THLD_FORCE_MASK | \
      MP2_I3C0_PIO_INTR_FORCE_IBI_THLD_FORCE_MASK | \
      MP2_I3C0_PIO_INTR_FORCE_CMD_QUEUE_READY_FORCE_MASK | \
      MP2_I3C0_PIO_INTR_FORCE_RESP_READY_FORCE_MASK | \
      MP2_I3C0_PIO_INTR_FORCE_TRANSFER_ABORT_FORCE_MASK | \
      MP2_I3C0_PIO_INTR_FORCE_RESERVED1_MASK | \
      MP2_I3C0_PIO_INTR_FORCE_TRANSFER_ERR_FORCE_MASK | \
      MP2_I3C0_PIO_INTR_FORCE_RESERVED0_MASK)

#define MP2_I3C0_PIO_INTR_FORCE_DEFAULT 0x00000000

#define MP2_I3C0_PIO_INTR_FORCE_GET_TX_THLD_FORCE(mp2_i3c0_pio_intr_force) \
     ((mp2_i3c0_pio_intr_force & MP2_I3C0_PIO_INTR_FORCE_TX_THLD_FORCE_MASK) >> MP2_I3C0_PIO_INTR_FORCE_TX_THLD_FORCE_SHIFT)
#define MP2_I3C0_PIO_INTR_FORCE_GET_RX_THLD_FORCE(mp2_i3c0_pio_intr_force) \
     ((mp2_i3c0_pio_intr_force & MP2_I3C0_PIO_INTR_FORCE_RX_THLD_FORCE_MASK) >> MP2_I3C0_PIO_INTR_FORCE_RX_THLD_FORCE_SHIFT)
#define MP2_I3C0_PIO_INTR_FORCE_GET_IBI_THLD_FORCE(mp2_i3c0_pio_intr_force) \
     ((mp2_i3c0_pio_intr_force & MP2_I3C0_PIO_INTR_FORCE_IBI_THLD_FORCE_MASK) >> MP2_I3C0_PIO_INTR_FORCE_IBI_THLD_FORCE_SHIFT)
#define MP2_I3C0_PIO_INTR_FORCE_GET_CMD_QUEUE_READY_FORCE(mp2_i3c0_pio_intr_force) \
     ((mp2_i3c0_pio_intr_force & MP2_I3C0_PIO_INTR_FORCE_CMD_QUEUE_READY_FORCE_MASK) >> MP2_I3C0_PIO_INTR_FORCE_CMD_QUEUE_READY_FORCE_SHIFT)
#define MP2_I3C0_PIO_INTR_FORCE_GET_RESP_READY_FORCE(mp2_i3c0_pio_intr_force) \
     ((mp2_i3c0_pio_intr_force & MP2_I3C0_PIO_INTR_FORCE_RESP_READY_FORCE_MASK) >> MP2_I3C0_PIO_INTR_FORCE_RESP_READY_FORCE_SHIFT)
#define MP2_I3C0_PIO_INTR_FORCE_GET_TRANSFER_ABORT_FORCE(mp2_i3c0_pio_intr_force) \
     ((mp2_i3c0_pio_intr_force & MP2_I3C0_PIO_INTR_FORCE_TRANSFER_ABORT_FORCE_MASK) >> MP2_I3C0_PIO_INTR_FORCE_TRANSFER_ABORT_FORCE_SHIFT)
#define MP2_I3C0_PIO_INTR_FORCE_GET_RESERVED1(mp2_i3c0_pio_intr_force) \
     ((mp2_i3c0_pio_intr_force & MP2_I3C0_PIO_INTR_FORCE_RESERVED1_MASK) >> MP2_I3C0_PIO_INTR_FORCE_RESERVED1_SHIFT)
#define MP2_I3C0_PIO_INTR_FORCE_GET_TRANSFER_ERR_FORCE(mp2_i3c0_pio_intr_force) \
     ((mp2_i3c0_pio_intr_force & MP2_I3C0_PIO_INTR_FORCE_TRANSFER_ERR_FORCE_MASK) >> MP2_I3C0_PIO_INTR_FORCE_TRANSFER_ERR_FORCE_SHIFT)
#define MP2_I3C0_PIO_INTR_FORCE_GET_RESERVED0(mp2_i3c0_pio_intr_force) \
     ((mp2_i3c0_pio_intr_force & MP2_I3C0_PIO_INTR_FORCE_RESERVED0_MASK) >> MP2_I3C0_PIO_INTR_FORCE_RESERVED0_SHIFT)

#define MP2_I3C0_PIO_INTR_FORCE_SET_TX_THLD_FORCE(mp2_i3c0_pio_intr_force_reg, tx_thld_force) \
     mp2_i3c0_pio_intr_force_reg = (mp2_i3c0_pio_intr_force_reg & ~MP2_I3C0_PIO_INTR_FORCE_TX_THLD_FORCE_MASK) | (tx_thld_force << MP2_I3C0_PIO_INTR_FORCE_TX_THLD_FORCE_SHIFT)
#define MP2_I3C0_PIO_INTR_FORCE_SET_RX_THLD_FORCE(mp2_i3c0_pio_intr_force_reg, rx_thld_force) \
     mp2_i3c0_pio_intr_force_reg = (mp2_i3c0_pio_intr_force_reg & ~MP2_I3C0_PIO_INTR_FORCE_RX_THLD_FORCE_MASK) | (rx_thld_force << MP2_I3C0_PIO_INTR_FORCE_RX_THLD_FORCE_SHIFT)
#define MP2_I3C0_PIO_INTR_FORCE_SET_IBI_THLD_FORCE(mp2_i3c0_pio_intr_force_reg, ibi_thld_force) \
     mp2_i3c0_pio_intr_force_reg = (mp2_i3c0_pio_intr_force_reg & ~MP2_I3C0_PIO_INTR_FORCE_IBI_THLD_FORCE_MASK) | (ibi_thld_force << MP2_I3C0_PIO_INTR_FORCE_IBI_THLD_FORCE_SHIFT)
#define MP2_I3C0_PIO_INTR_FORCE_SET_CMD_QUEUE_READY_FORCE(mp2_i3c0_pio_intr_force_reg, cmd_queue_ready_force) \
     mp2_i3c0_pio_intr_force_reg = (mp2_i3c0_pio_intr_force_reg & ~MP2_I3C0_PIO_INTR_FORCE_CMD_QUEUE_READY_FORCE_MASK) | (cmd_queue_ready_force << MP2_I3C0_PIO_INTR_FORCE_CMD_QUEUE_READY_FORCE_SHIFT)
#define MP2_I3C0_PIO_INTR_FORCE_SET_RESP_READY_FORCE(mp2_i3c0_pio_intr_force_reg, resp_ready_force) \
     mp2_i3c0_pio_intr_force_reg = (mp2_i3c0_pio_intr_force_reg & ~MP2_I3C0_PIO_INTR_FORCE_RESP_READY_FORCE_MASK) | (resp_ready_force << MP2_I3C0_PIO_INTR_FORCE_RESP_READY_FORCE_SHIFT)
#define MP2_I3C0_PIO_INTR_FORCE_SET_TRANSFER_ABORT_FORCE(mp2_i3c0_pio_intr_force_reg, transfer_abort_force) \
     mp2_i3c0_pio_intr_force_reg = (mp2_i3c0_pio_intr_force_reg & ~MP2_I3C0_PIO_INTR_FORCE_TRANSFER_ABORT_FORCE_MASK) | (transfer_abort_force << MP2_I3C0_PIO_INTR_FORCE_TRANSFER_ABORT_FORCE_SHIFT)
#define MP2_I3C0_PIO_INTR_FORCE_SET_RESERVED1(mp2_i3c0_pio_intr_force_reg, reserved1) \
     mp2_i3c0_pio_intr_force_reg = (mp2_i3c0_pio_intr_force_reg & ~MP2_I3C0_PIO_INTR_FORCE_RESERVED1_MASK) | (reserved1 << MP2_I3C0_PIO_INTR_FORCE_RESERVED1_SHIFT)
#define MP2_I3C0_PIO_INTR_FORCE_SET_TRANSFER_ERR_FORCE(mp2_i3c0_pio_intr_force_reg, transfer_err_force) \
     mp2_i3c0_pio_intr_force_reg = (mp2_i3c0_pio_intr_force_reg & ~MP2_I3C0_PIO_INTR_FORCE_TRANSFER_ERR_FORCE_MASK) | (transfer_err_force << MP2_I3C0_PIO_INTR_FORCE_TRANSFER_ERR_FORCE_SHIFT)
#define MP2_I3C0_PIO_INTR_FORCE_SET_RESERVED0(mp2_i3c0_pio_intr_force_reg, reserved0) \
     mp2_i3c0_pio_intr_force_reg = (mp2_i3c0_pio_intr_force_reg & ~MP2_I3C0_PIO_INTR_FORCE_RESERVED0_MASK) | (reserved0 << MP2_I3C0_PIO_INTR_FORCE_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_pio_intr_force_t {
          unsigned int tx_thld_force                  : MP2_I3C0_PIO_INTR_FORCE_TX_THLD_FORCE_SIZE;
          unsigned int rx_thld_force                  : MP2_I3C0_PIO_INTR_FORCE_RX_THLD_FORCE_SIZE;
          unsigned int ibi_thld_force                 : MP2_I3C0_PIO_INTR_FORCE_IBI_THLD_FORCE_SIZE;
          unsigned int cmd_queue_ready_force          : MP2_I3C0_PIO_INTR_FORCE_CMD_QUEUE_READY_FORCE_SIZE;
          unsigned int resp_ready_force               : MP2_I3C0_PIO_INTR_FORCE_RESP_READY_FORCE_SIZE;
          unsigned int transfer_abort_force           : MP2_I3C0_PIO_INTR_FORCE_TRANSFER_ABORT_FORCE_SIZE;
          unsigned int reserved1                      : MP2_I3C0_PIO_INTR_FORCE_RESERVED1_SIZE;
          unsigned int transfer_err_force             : MP2_I3C0_PIO_INTR_FORCE_TRANSFER_ERR_FORCE_SIZE;
          unsigned int reserved0                      : MP2_I3C0_PIO_INTR_FORCE_RESERVED0_SIZE;
     } mp2_i3c0_pio_intr_force_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_pio_intr_force_t {
          unsigned int reserved0                      : MP2_I3C0_PIO_INTR_FORCE_RESERVED0_SIZE;
          unsigned int transfer_err_force             : MP2_I3C0_PIO_INTR_FORCE_TRANSFER_ERR_FORCE_SIZE;
          unsigned int reserved1                      : MP2_I3C0_PIO_INTR_FORCE_RESERVED1_SIZE;
          unsigned int transfer_abort_force           : MP2_I3C0_PIO_INTR_FORCE_TRANSFER_ABORT_FORCE_SIZE;
          unsigned int resp_ready_force               : MP2_I3C0_PIO_INTR_FORCE_RESP_READY_FORCE_SIZE;
          unsigned int cmd_queue_ready_force          : MP2_I3C0_PIO_INTR_FORCE_CMD_QUEUE_READY_FORCE_SIZE;
          unsigned int ibi_thld_force                 : MP2_I3C0_PIO_INTR_FORCE_IBI_THLD_FORCE_SIZE;
          unsigned int rx_thld_force                  : MP2_I3C0_PIO_INTR_FORCE_RX_THLD_FORCE_SIZE;
          unsigned int tx_thld_force                  : MP2_I3C0_PIO_INTR_FORCE_TX_THLD_FORCE_SIZE;
     } mp2_i3c0_pio_intr_force_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_pio_intr_force_t f;
} mp2_i3c0_pio_intr_force_u;


/*
 * MP2_I3C0_DEV_ADDR_TABLE1_LOC1 struct
 */

#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_REG_SIZE 32
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_STATIC_ADDRESS_SIZE 7
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED2_SIZE 5
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_IBI_WITH_DATA_SIZE 1
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SIR_REJECT_SIZE 1
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_MR_REJECT_SIZE 1
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED1_SIZE 1
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEV_DYNAMIC_ADDR_SIZE 8
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED0_SIZE 2
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RING_ID_SIZE 3
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEV_NACK_RETRY_CNT_SIZE 2
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEVICE_SIZE 1

#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_STATIC_ADDRESS_SHIFT 0
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED2_SHIFT 7
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_IBI_WITH_DATA_SHIFT 12
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SIR_REJECT_SHIFT 13
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_MR_REJECT_SHIFT 14
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED1_SHIFT 15
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEV_DYNAMIC_ADDR_SHIFT 16
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED0_SHIFT 24
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RING_ID_SHIFT 26
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEV_NACK_RETRY_CNT_SHIFT 29
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEVICE_SHIFT 31

#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_STATIC_ADDRESS_MASK 0x7f
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED2_MASK 0xf80
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_IBI_WITH_DATA_MASK 0x1000
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SIR_REJECT_MASK 0x2000
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_MR_REJECT_MASK 0x4000
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED1_MASK 0x8000
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEV_DYNAMIC_ADDR_MASK 0xff0000
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED0_MASK 0x3000000
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RING_ID_MASK 0x1c000000
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEV_NACK_RETRY_CNT_MASK 0x60000000
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEVICE_MASK 0x80000000

#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_MASK \
     (MP2_I3C0_DEV_ADDR_TABLE1_LOC1_STATIC_ADDRESS_MASK | \
      MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED2_MASK | \
      MP2_I3C0_DEV_ADDR_TABLE1_LOC1_IBI_WITH_DATA_MASK | \
      MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SIR_REJECT_MASK | \
      MP2_I3C0_DEV_ADDR_TABLE1_LOC1_MR_REJECT_MASK | \
      MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED1_MASK | \
      MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEV_DYNAMIC_ADDR_MASK | \
      MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED0_MASK | \
      MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RING_ID_MASK | \
      MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEV_NACK_RETRY_CNT_MASK | \
      MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEVICE_MASK)

#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEFAULT 0x00000000

#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_GET_STATIC_ADDRESS(mp2_i3c0_dev_addr_table1_loc1) \
     ((mp2_i3c0_dev_addr_table1_loc1 & MP2_I3C0_DEV_ADDR_TABLE1_LOC1_STATIC_ADDRESS_MASK) >> MP2_I3C0_DEV_ADDR_TABLE1_LOC1_STATIC_ADDRESS_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_GET_RESERVED2(mp2_i3c0_dev_addr_table1_loc1) \
     ((mp2_i3c0_dev_addr_table1_loc1 & MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED2_MASK) >> MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED2_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_GET_IBI_WITH_DATA(mp2_i3c0_dev_addr_table1_loc1) \
     ((mp2_i3c0_dev_addr_table1_loc1 & MP2_I3C0_DEV_ADDR_TABLE1_LOC1_IBI_WITH_DATA_MASK) >> MP2_I3C0_DEV_ADDR_TABLE1_LOC1_IBI_WITH_DATA_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_GET_SIR_REJECT(mp2_i3c0_dev_addr_table1_loc1) \
     ((mp2_i3c0_dev_addr_table1_loc1 & MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SIR_REJECT_MASK) >> MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SIR_REJECT_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_GET_MR_REJECT(mp2_i3c0_dev_addr_table1_loc1) \
     ((mp2_i3c0_dev_addr_table1_loc1 & MP2_I3C0_DEV_ADDR_TABLE1_LOC1_MR_REJECT_MASK) >> MP2_I3C0_DEV_ADDR_TABLE1_LOC1_MR_REJECT_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_GET_RESERVED1(mp2_i3c0_dev_addr_table1_loc1) \
     ((mp2_i3c0_dev_addr_table1_loc1 & MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED1_MASK) >> MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED1_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_GET_DEV_DYNAMIC_ADDR(mp2_i3c0_dev_addr_table1_loc1) \
     ((mp2_i3c0_dev_addr_table1_loc1 & MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEV_DYNAMIC_ADDR_MASK) >> MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEV_DYNAMIC_ADDR_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_GET_RESERVED0(mp2_i3c0_dev_addr_table1_loc1) \
     ((mp2_i3c0_dev_addr_table1_loc1 & MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED0_MASK) >> MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED0_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_GET_RING_ID(mp2_i3c0_dev_addr_table1_loc1) \
     ((mp2_i3c0_dev_addr_table1_loc1 & MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RING_ID_MASK) >> MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RING_ID_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_GET_DEV_NACK_RETRY_CNT(mp2_i3c0_dev_addr_table1_loc1) \
     ((mp2_i3c0_dev_addr_table1_loc1 & MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEV_NACK_RETRY_CNT_MASK) >> MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEV_NACK_RETRY_CNT_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_GET_DEVICE(mp2_i3c0_dev_addr_table1_loc1) \
     ((mp2_i3c0_dev_addr_table1_loc1 & MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEVICE_MASK) >> MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEVICE_SHIFT)

#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SET_STATIC_ADDRESS(mp2_i3c0_dev_addr_table1_loc1_reg, static_address) \
     mp2_i3c0_dev_addr_table1_loc1_reg = (mp2_i3c0_dev_addr_table1_loc1_reg & ~MP2_I3C0_DEV_ADDR_TABLE1_LOC1_STATIC_ADDRESS_MASK) | (static_address << MP2_I3C0_DEV_ADDR_TABLE1_LOC1_STATIC_ADDRESS_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SET_RESERVED2(mp2_i3c0_dev_addr_table1_loc1_reg, reserved2) \
     mp2_i3c0_dev_addr_table1_loc1_reg = (mp2_i3c0_dev_addr_table1_loc1_reg & ~MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED2_MASK) | (reserved2 << MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED2_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SET_IBI_WITH_DATA(mp2_i3c0_dev_addr_table1_loc1_reg, ibi_with_data) \
     mp2_i3c0_dev_addr_table1_loc1_reg = (mp2_i3c0_dev_addr_table1_loc1_reg & ~MP2_I3C0_DEV_ADDR_TABLE1_LOC1_IBI_WITH_DATA_MASK) | (ibi_with_data << MP2_I3C0_DEV_ADDR_TABLE1_LOC1_IBI_WITH_DATA_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SET_SIR_REJECT(mp2_i3c0_dev_addr_table1_loc1_reg, sir_reject) \
     mp2_i3c0_dev_addr_table1_loc1_reg = (mp2_i3c0_dev_addr_table1_loc1_reg & ~MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SIR_REJECT_MASK) | (sir_reject << MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SIR_REJECT_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SET_MR_REJECT(mp2_i3c0_dev_addr_table1_loc1_reg, mr_reject) \
     mp2_i3c0_dev_addr_table1_loc1_reg = (mp2_i3c0_dev_addr_table1_loc1_reg & ~MP2_I3C0_DEV_ADDR_TABLE1_LOC1_MR_REJECT_MASK) | (mr_reject << MP2_I3C0_DEV_ADDR_TABLE1_LOC1_MR_REJECT_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SET_RESERVED1(mp2_i3c0_dev_addr_table1_loc1_reg, reserved1) \
     mp2_i3c0_dev_addr_table1_loc1_reg = (mp2_i3c0_dev_addr_table1_loc1_reg & ~MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED1_MASK) | (reserved1 << MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED1_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SET_DEV_DYNAMIC_ADDR(mp2_i3c0_dev_addr_table1_loc1_reg, dev_dynamic_addr) \
     mp2_i3c0_dev_addr_table1_loc1_reg = (mp2_i3c0_dev_addr_table1_loc1_reg & ~MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEV_DYNAMIC_ADDR_MASK) | (dev_dynamic_addr << MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEV_DYNAMIC_ADDR_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SET_RESERVED0(mp2_i3c0_dev_addr_table1_loc1_reg, reserved0) \
     mp2_i3c0_dev_addr_table1_loc1_reg = (mp2_i3c0_dev_addr_table1_loc1_reg & ~MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED0_MASK) | (reserved0 << MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED0_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SET_RING_ID(mp2_i3c0_dev_addr_table1_loc1_reg, ring_id) \
     mp2_i3c0_dev_addr_table1_loc1_reg = (mp2_i3c0_dev_addr_table1_loc1_reg & ~MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RING_ID_MASK) | (ring_id << MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RING_ID_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SET_DEV_NACK_RETRY_CNT(mp2_i3c0_dev_addr_table1_loc1_reg, dev_nack_retry_cnt) \
     mp2_i3c0_dev_addr_table1_loc1_reg = (mp2_i3c0_dev_addr_table1_loc1_reg & ~MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEV_NACK_RETRY_CNT_MASK) | (dev_nack_retry_cnt << MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEV_NACK_RETRY_CNT_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SET_DEVICE(mp2_i3c0_dev_addr_table1_loc1_reg, device) \
     mp2_i3c0_dev_addr_table1_loc1_reg = (mp2_i3c0_dev_addr_table1_loc1_reg & ~MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEVICE_MASK) | (device << MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEVICE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_dev_addr_table1_loc1_t {
          unsigned int static_address                 : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_STATIC_ADDRESS_SIZE;
          unsigned int reserved2                      : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED2_SIZE;
          unsigned int ibi_with_data                  : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_IBI_WITH_DATA_SIZE;
          unsigned int sir_reject                     : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SIR_REJECT_SIZE;
          unsigned int mr_reject                      : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_MR_REJECT_SIZE;
          unsigned int reserved1                      : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED1_SIZE;
          unsigned int dev_dynamic_addr               : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEV_DYNAMIC_ADDR_SIZE;
          unsigned int reserved0                      : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED0_SIZE;
          unsigned int ring_id                        : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RING_ID_SIZE;
          unsigned int dev_nack_retry_cnt             : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEV_NACK_RETRY_CNT_SIZE;
          unsigned int device                         : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEVICE_SIZE;
     } mp2_i3c0_dev_addr_table1_loc1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_dev_addr_table1_loc1_t {
          unsigned int device                         : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEVICE_SIZE;
          unsigned int dev_nack_retry_cnt             : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEV_NACK_RETRY_CNT_SIZE;
          unsigned int ring_id                        : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RING_ID_SIZE;
          unsigned int reserved0                      : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED0_SIZE;
          unsigned int dev_dynamic_addr               : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_DEV_DYNAMIC_ADDR_SIZE;
          unsigned int reserved1                      : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED1_SIZE;
          unsigned int mr_reject                      : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_MR_REJECT_SIZE;
          unsigned int sir_reject                     : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_SIR_REJECT_SIZE;
          unsigned int ibi_with_data                  : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_IBI_WITH_DATA_SIZE;
          unsigned int reserved2                      : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_RESERVED2_SIZE;
          unsigned int static_address                 : MP2_I3C0_DEV_ADDR_TABLE1_LOC1_STATIC_ADDRESS_SIZE;
     } mp2_i3c0_dev_addr_table1_loc1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_dev_addr_table1_loc1_t f;
} mp2_i3c0_dev_addr_table1_loc1_u;


/*
 * MP2_I3C0_DEV_ADDR_TABLE1_LOC2 struct
 */

#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_REG_SIZE 32
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_MASK_SIZE 8
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_VALUE_SIZE 8
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_MODE_SIZE 3
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_HDR_CODE_SIZE 8
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_RESERVED0_SIZE 5

#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_MASK_SHIFT 0
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_VALUE_SHIFT 8
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_MODE_SHIFT 16
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_HDR_CODE_SHIFT 19
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_RESERVED0_SHIFT 27

#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_MASK_MASK 0xff
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_VALUE_MASK 0xff00
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_MODE_MASK 0x70000
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_HDR_CODE_MASK 0x7f80000
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_RESERVED0_MASK 0xf8000000

#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_MASK \
     (MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_MASK_MASK | \
      MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_VALUE_MASK | \
      MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_MODE_MASK | \
      MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_HDR_CODE_MASK | \
      MP2_I3C0_DEV_ADDR_TABLE1_LOC2_RESERVED0_MASK)

#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_DEFAULT 0x00000000

#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_GET_AUTOCMD_MASK(mp2_i3c0_dev_addr_table1_loc2) \
     ((mp2_i3c0_dev_addr_table1_loc2 & MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_MASK_MASK) >> MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_MASK_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_GET_AUTOCMD_VALUE(mp2_i3c0_dev_addr_table1_loc2) \
     ((mp2_i3c0_dev_addr_table1_loc2 & MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_VALUE_MASK) >> MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_VALUE_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_GET_AUTOCMD_MODE(mp2_i3c0_dev_addr_table1_loc2) \
     ((mp2_i3c0_dev_addr_table1_loc2 & MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_MODE_MASK) >> MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_MODE_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_GET_AUTOCMD_HDR_CODE(mp2_i3c0_dev_addr_table1_loc2) \
     ((mp2_i3c0_dev_addr_table1_loc2 & MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_HDR_CODE_MASK) >> MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_HDR_CODE_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_GET_RESERVED0(mp2_i3c0_dev_addr_table1_loc2) \
     ((mp2_i3c0_dev_addr_table1_loc2 & MP2_I3C0_DEV_ADDR_TABLE1_LOC2_RESERVED0_MASK) >> MP2_I3C0_DEV_ADDR_TABLE1_LOC2_RESERVED0_SHIFT)

#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_SET_AUTOCMD_MASK(mp2_i3c0_dev_addr_table1_loc2_reg, autocmd_mask) \
     mp2_i3c0_dev_addr_table1_loc2_reg = (mp2_i3c0_dev_addr_table1_loc2_reg & ~MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_MASK_MASK) | (autocmd_mask << MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_MASK_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_SET_AUTOCMD_VALUE(mp2_i3c0_dev_addr_table1_loc2_reg, autocmd_value) \
     mp2_i3c0_dev_addr_table1_loc2_reg = (mp2_i3c0_dev_addr_table1_loc2_reg & ~MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_VALUE_MASK) | (autocmd_value << MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_VALUE_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_SET_AUTOCMD_MODE(mp2_i3c0_dev_addr_table1_loc2_reg, autocmd_mode) \
     mp2_i3c0_dev_addr_table1_loc2_reg = (mp2_i3c0_dev_addr_table1_loc2_reg & ~MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_MODE_MASK) | (autocmd_mode << MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_MODE_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_SET_AUTOCMD_HDR_CODE(mp2_i3c0_dev_addr_table1_loc2_reg, autocmd_hdr_code) \
     mp2_i3c0_dev_addr_table1_loc2_reg = (mp2_i3c0_dev_addr_table1_loc2_reg & ~MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_HDR_CODE_MASK) | (autocmd_hdr_code << MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_HDR_CODE_SHIFT)
#define MP2_I3C0_DEV_ADDR_TABLE1_LOC2_SET_RESERVED0(mp2_i3c0_dev_addr_table1_loc2_reg, reserved0) \
     mp2_i3c0_dev_addr_table1_loc2_reg = (mp2_i3c0_dev_addr_table1_loc2_reg & ~MP2_I3C0_DEV_ADDR_TABLE1_LOC2_RESERVED0_MASK) | (reserved0 << MP2_I3C0_DEV_ADDR_TABLE1_LOC2_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_dev_addr_table1_loc2_t {
          unsigned int autocmd_mask                   : MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_MASK_SIZE;
          unsigned int autocmd_value                  : MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_VALUE_SIZE;
          unsigned int autocmd_mode                   : MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_MODE_SIZE;
          unsigned int autocmd_hdr_code               : MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_HDR_CODE_SIZE;
          unsigned int reserved0                      : MP2_I3C0_DEV_ADDR_TABLE1_LOC2_RESERVED0_SIZE;
     } mp2_i3c0_dev_addr_table1_loc2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_dev_addr_table1_loc2_t {
          unsigned int reserved0                      : MP2_I3C0_DEV_ADDR_TABLE1_LOC2_RESERVED0_SIZE;
          unsigned int autocmd_hdr_code               : MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_HDR_CODE_SIZE;
          unsigned int autocmd_mode                   : MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_MODE_SIZE;
          unsigned int autocmd_value                  : MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_VALUE_SIZE;
          unsigned int autocmd_mask                   : MP2_I3C0_DEV_ADDR_TABLE1_LOC2_AUTOCMD_MASK_SIZE;
     } mp2_i3c0_dev_addr_table1_loc2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_dev_addr_table1_loc2_t f;
} mp2_i3c0_dev_addr_table1_loc2_u;


/*
 * MP2_I3C0_DEV_CHAR_TABLE1_LOC1 struct
 */

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC1_REG_SIZE 32
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC1_MSB_PROVISIONAL_ID_SIZE 32

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC1_MSB_PROVISIONAL_ID_SHIFT 0

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC1_MSB_PROVISIONAL_ID_MASK 0xffffffff

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC1_MASK \
     (MP2_I3C0_DEV_CHAR_TABLE1_LOC1_MSB_PROVISIONAL_ID_MASK)

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC1_DEFAULT 0x00000000

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC1_GET_MSB_PROVISIONAL_ID(mp2_i3c0_dev_char_table1_loc1) \
     ((mp2_i3c0_dev_char_table1_loc1 & MP2_I3C0_DEV_CHAR_TABLE1_LOC1_MSB_PROVISIONAL_ID_MASK) >> MP2_I3C0_DEV_CHAR_TABLE1_LOC1_MSB_PROVISIONAL_ID_SHIFT)

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC1_SET_MSB_PROVISIONAL_ID(mp2_i3c0_dev_char_table1_loc1_reg, msb_provisional_id) \
     mp2_i3c0_dev_char_table1_loc1_reg = (mp2_i3c0_dev_char_table1_loc1_reg & ~MP2_I3C0_DEV_CHAR_TABLE1_LOC1_MSB_PROVISIONAL_ID_MASK) | (msb_provisional_id << MP2_I3C0_DEV_CHAR_TABLE1_LOC1_MSB_PROVISIONAL_ID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_dev_char_table1_loc1_t {
          unsigned int msb_provisional_id             : MP2_I3C0_DEV_CHAR_TABLE1_LOC1_MSB_PROVISIONAL_ID_SIZE;
     } mp2_i3c0_dev_char_table1_loc1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_dev_char_table1_loc1_t {
          unsigned int msb_provisional_id             : MP2_I3C0_DEV_CHAR_TABLE1_LOC1_MSB_PROVISIONAL_ID_SIZE;
     } mp2_i3c0_dev_char_table1_loc1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_dev_char_table1_loc1_t f;
} mp2_i3c0_dev_char_table1_loc1_u;


/*
 * MP2_I3C0_DEV_CHAR_TABLE1_LOC2 struct
 */

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC2_REG_SIZE 32
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC2_LSB_PROVISIONAL_ID_SIZE 16
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC2_RESERVED0_SIZE 16

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC2_LSB_PROVISIONAL_ID_SHIFT 0
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC2_RESERVED0_SHIFT 16

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC2_LSB_PROVISIONAL_ID_MASK 0xffff
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC2_RESERVED0_MASK 0xffff0000

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC2_MASK \
     (MP2_I3C0_DEV_CHAR_TABLE1_LOC2_LSB_PROVISIONAL_ID_MASK | \
      MP2_I3C0_DEV_CHAR_TABLE1_LOC2_RESERVED0_MASK)

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC2_DEFAULT 0x00000000

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC2_GET_LSB_PROVISIONAL_ID(mp2_i3c0_dev_char_table1_loc2) \
     ((mp2_i3c0_dev_char_table1_loc2 & MP2_I3C0_DEV_CHAR_TABLE1_LOC2_LSB_PROVISIONAL_ID_MASK) >> MP2_I3C0_DEV_CHAR_TABLE1_LOC2_LSB_PROVISIONAL_ID_SHIFT)
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC2_GET_RESERVED0(mp2_i3c0_dev_char_table1_loc2) \
     ((mp2_i3c0_dev_char_table1_loc2 & MP2_I3C0_DEV_CHAR_TABLE1_LOC2_RESERVED0_MASK) >> MP2_I3C0_DEV_CHAR_TABLE1_LOC2_RESERVED0_SHIFT)

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC2_SET_LSB_PROVISIONAL_ID(mp2_i3c0_dev_char_table1_loc2_reg, lsb_provisional_id) \
     mp2_i3c0_dev_char_table1_loc2_reg = (mp2_i3c0_dev_char_table1_loc2_reg & ~MP2_I3C0_DEV_CHAR_TABLE1_LOC2_LSB_PROVISIONAL_ID_MASK) | (lsb_provisional_id << MP2_I3C0_DEV_CHAR_TABLE1_LOC2_LSB_PROVISIONAL_ID_SHIFT)
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC2_SET_RESERVED0(mp2_i3c0_dev_char_table1_loc2_reg, reserved0) \
     mp2_i3c0_dev_char_table1_loc2_reg = (mp2_i3c0_dev_char_table1_loc2_reg & ~MP2_I3C0_DEV_CHAR_TABLE1_LOC2_RESERVED0_MASK) | (reserved0 << MP2_I3C0_DEV_CHAR_TABLE1_LOC2_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_dev_char_table1_loc2_t {
          unsigned int lsb_provisional_id             : MP2_I3C0_DEV_CHAR_TABLE1_LOC2_LSB_PROVISIONAL_ID_SIZE;
          unsigned int reserved0                      : MP2_I3C0_DEV_CHAR_TABLE1_LOC2_RESERVED0_SIZE;
     } mp2_i3c0_dev_char_table1_loc2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_dev_char_table1_loc2_t {
          unsigned int reserved0                      : MP2_I3C0_DEV_CHAR_TABLE1_LOC2_RESERVED0_SIZE;
          unsigned int lsb_provisional_id             : MP2_I3C0_DEV_CHAR_TABLE1_LOC2_LSB_PROVISIONAL_ID_SIZE;
     } mp2_i3c0_dev_char_table1_loc2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_dev_char_table1_loc2_t f;
} mp2_i3c0_dev_char_table1_loc2_u;


/*
 * MP2_I3C0_DEV_CHAR_TABLE1_LOC3 struct
 */

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC3_REG_SIZE 32
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC3_DCR_SIZE 8
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC3_BCR_SIZE 8
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC3_RESERVED0_SIZE 16

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC3_DCR_SHIFT 0
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC3_BCR_SHIFT 8
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC3_RESERVED0_SHIFT 16

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC3_DCR_MASK 0xff
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC3_BCR_MASK 0xff00
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC3_RESERVED0_MASK 0xffff0000

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC3_MASK \
     (MP2_I3C0_DEV_CHAR_TABLE1_LOC3_DCR_MASK | \
      MP2_I3C0_DEV_CHAR_TABLE1_LOC3_BCR_MASK | \
      MP2_I3C0_DEV_CHAR_TABLE1_LOC3_RESERVED0_MASK)

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC3_DEFAULT 0x00000000

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC3_GET_DCR(mp2_i3c0_dev_char_table1_loc3) \
     ((mp2_i3c0_dev_char_table1_loc3 & MP2_I3C0_DEV_CHAR_TABLE1_LOC3_DCR_MASK) >> MP2_I3C0_DEV_CHAR_TABLE1_LOC3_DCR_SHIFT)
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC3_GET_BCR(mp2_i3c0_dev_char_table1_loc3) \
     ((mp2_i3c0_dev_char_table1_loc3 & MP2_I3C0_DEV_CHAR_TABLE1_LOC3_BCR_MASK) >> MP2_I3C0_DEV_CHAR_TABLE1_LOC3_BCR_SHIFT)
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC3_GET_RESERVED0(mp2_i3c0_dev_char_table1_loc3) \
     ((mp2_i3c0_dev_char_table1_loc3 & MP2_I3C0_DEV_CHAR_TABLE1_LOC3_RESERVED0_MASK) >> MP2_I3C0_DEV_CHAR_TABLE1_LOC3_RESERVED0_SHIFT)

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC3_SET_DCR(mp2_i3c0_dev_char_table1_loc3_reg, dcr) \
     mp2_i3c0_dev_char_table1_loc3_reg = (mp2_i3c0_dev_char_table1_loc3_reg & ~MP2_I3C0_DEV_CHAR_TABLE1_LOC3_DCR_MASK) | (dcr << MP2_I3C0_DEV_CHAR_TABLE1_LOC3_DCR_SHIFT)
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC3_SET_BCR(mp2_i3c0_dev_char_table1_loc3_reg, bcr) \
     mp2_i3c0_dev_char_table1_loc3_reg = (mp2_i3c0_dev_char_table1_loc3_reg & ~MP2_I3C0_DEV_CHAR_TABLE1_LOC3_BCR_MASK) | (bcr << MP2_I3C0_DEV_CHAR_TABLE1_LOC3_BCR_SHIFT)
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC3_SET_RESERVED0(mp2_i3c0_dev_char_table1_loc3_reg, reserved0) \
     mp2_i3c0_dev_char_table1_loc3_reg = (mp2_i3c0_dev_char_table1_loc3_reg & ~MP2_I3C0_DEV_CHAR_TABLE1_LOC3_RESERVED0_MASK) | (reserved0 << MP2_I3C0_DEV_CHAR_TABLE1_LOC3_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_dev_char_table1_loc3_t {
          unsigned int dcr                            : MP2_I3C0_DEV_CHAR_TABLE1_LOC3_DCR_SIZE;
          unsigned int bcr                            : MP2_I3C0_DEV_CHAR_TABLE1_LOC3_BCR_SIZE;
          unsigned int reserved0                      : MP2_I3C0_DEV_CHAR_TABLE1_LOC3_RESERVED0_SIZE;
     } mp2_i3c0_dev_char_table1_loc3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_dev_char_table1_loc3_t {
          unsigned int reserved0                      : MP2_I3C0_DEV_CHAR_TABLE1_LOC3_RESERVED0_SIZE;
          unsigned int bcr                            : MP2_I3C0_DEV_CHAR_TABLE1_LOC3_BCR_SIZE;
          unsigned int dcr                            : MP2_I3C0_DEV_CHAR_TABLE1_LOC3_DCR_SIZE;
     } mp2_i3c0_dev_char_table1_loc3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_dev_char_table1_loc3_t f;
} mp2_i3c0_dev_char_table1_loc3_u;


/*
 * MP2_I3C0_DEV_CHAR_TABLE1_LOC4 struct
 */

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC4_REG_SIZE 32
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC4_DEV_DYNAMIC_ADDR_SIZE 8
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC4_RESERVED0_SIZE 24

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC4_DEV_DYNAMIC_ADDR_SHIFT 0
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC4_RESERVED0_SHIFT 8

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC4_DEV_DYNAMIC_ADDR_MASK 0xff
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC4_RESERVED0_MASK 0xffffff00

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC4_MASK \
     (MP2_I3C0_DEV_CHAR_TABLE1_LOC4_DEV_DYNAMIC_ADDR_MASK | \
      MP2_I3C0_DEV_CHAR_TABLE1_LOC4_RESERVED0_MASK)

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC4_DEFAULT 0x00000000

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC4_GET_DEV_DYNAMIC_ADDR(mp2_i3c0_dev_char_table1_loc4) \
     ((mp2_i3c0_dev_char_table1_loc4 & MP2_I3C0_DEV_CHAR_TABLE1_LOC4_DEV_DYNAMIC_ADDR_MASK) >> MP2_I3C0_DEV_CHAR_TABLE1_LOC4_DEV_DYNAMIC_ADDR_SHIFT)
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC4_GET_RESERVED0(mp2_i3c0_dev_char_table1_loc4) \
     ((mp2_i3c0_dev_char_table1_loc4 & MP2_I3C0_DEV_CHAR_TABLE1_LOC4_RESERVED0_MASK) >> MP2_I3C0_DEV_CHAR_TABLE1_LOC4_RESERVED0_SHIFT)

#define MP2_I3C0_DEV_CHAR_TABLE1_LOC4_SET_DEV_DYNAMIC_ADDR(mp2_i3c0_dev_char_table1_loc4_reg, dev_dynamic_addr) \
     mp2_i3c0_dev_char_table1_loc4_reg = (mp2_i3c0_dev_char_table1_loc4_reg & ~MP2_I3C0_DEV_CHAR_TABLE1_LOC4_DEV_DYNAMIC_ADDR_MASK) | (dev_dynamic_addr << MP2_I3C0_DEV_CHAR_TABLE1_LOC4_DEV_DYNAMIC_ADDR_SHIFT)
#define MP2_I3C0_DEV_CHAR_TABLE1_LOC4_SET_RESERVED0(mp2_i3c0_dev_char_table1_loc4_reg, reserved0) \
     mp2_i3c0_dev_char_table1_loc4_reg = (mp2_i3c0_dev_char_table1_loc4_reg & ~MP2_I3C0_DEV_CHAR_TABLE1_LOC4_RESERVED0_MASK) | (reserved0 << MP2_I3C0_DEV_CHAR_TABLE1_LOC4_RESERVED0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i3c0_dev_char_table1_loc4_t {
          unsigned int dev_dynamic_addr               : MP2_I3C0_DEV_CHAR_TABLE1_LOC4_DEV_DYNAMIC_ADDR_SIZE;
          unsigned int reserved0                      : MP2_I3C0_DEV_CHAR_TABLE1_LOC4_RESERVED0_SIZE;
     } mp2_i3c0_dev_char_table1_loc4_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i3c0_dev_char_table1_loc4_t {
          unsigned int reserved0                      : MP2_I3C0_DEV_CHAR_TABLE1_LOC4_RESERVED0_SIZE;
          unsigned int dev_dynamic_addr               : MP2_I3C0_DEV_CHAR_TABLE1_LOC4_DEV_DYNAMIC_ADDR_SIZE;
     } mp2_i3c0_dev_char_table1_loc4_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i3c0_dev_char_table1_loc4_t f;
} mp2_i3c0_dev_char_table1_loc4_u;


/*
 * MP2_GPIO_SCRATCH0 struct
 */

#define MP2_GPIO_SCRATCH0_REG_SIZE     32
#define MP2_GPIO_SCRATCH0_MP_GPIO_SCRATCH0_DATA_SIZE 32

#define MP2_GPIO_SCRATCH0_MP_GPIO_SCRATCH0_DATA_SHIFT 0

#define MP2_GPIO_SCRATCH0_MP_GPIO_SCRATCH0_DATA_MASK 0xffffffff

#define MP2_GPIO_SCRATCH0_MASK \
     (MP2_GPIO_SCRATCH0_MP_GPIO_SCRATCH0_DATA_MASK)

#define MP2_GPIO_SCRATCH0_DEFAULT      0x00000000

#define MP2_GPIO_SCRATCH0_GET_MP_GPIO_SCRATCH0_DATA(mp2_gpio_scratch0) \
     ((mp2_gpio_scratch0 & MP2_GPIO_SCRATCH0_MP_GPIO_SCRATCH0_DATA_MASK) >> MP2_GPIO_SCRATCH0_MP_GPIO_SCRATCH0_DATA_SHIFT)

#define MP2_GPIO_SCRATCH0_SET_MP_GPIO_SCRATCH0_DATA(mp2_gpio_scratch0_reg, mp_gpio_scratch0_data) \
     mp2_gpio_scratch0_reg = (mp2_gpio_scratch0_reg & ~MP2_GPIO_SCRATCH0_MP_GPIO_SCRATCH0_DATA_MASK) | (mp_gpio_scratch0_data << MP2_GPIO_SCRATCH0_MP_GPIO_SCRATCH0_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio_scratch0_t {
          unsigned int mp_gpio_scratch0_data          : MP2_GPIO_SCRATCH0_MP_GPIO_SCRATCH0_DATA_SIZE;
     } mp2_gpio_scratch0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio_scratch0_t {
          unsigned int mp_gpio_scratch0_data          : MP2_GPIO_SCRATCH0_MP_GPIO_SCRATCH0_DATA_SIZE;
     } mp2_gpio_scratch0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio_scratch0_t f;
} mp2_gpio_scratch0_u;


/*
 * MP2_GPIO_SCRATCH1 struct
 */

#define MP2_GPIO_SCRATCH1_REG_SIZE     32
#define MP2_GPIO_SCRATCH1_MP_GPIO_SCRATCH1_DATA_SIZE 32

#define MP2_GPIO_SCRATCH1_MP_GPIO_SCRATCH1_DATA_SHIFT 0

#define MP2_GPIO_SCRATCH1_MP_GPIO_SCRATCH1_DATA_MASK 0xffffffff

#define MP2_GPIO_SCRATCH1_MASK \
     (MP2_GPIO_SCRATCH1_MP_GPIO_SCRATCH1_DATA_MASK)

#define MP2_GPIO_SCRATCH1_DEFAULT      0x00000000

#define MP2_GPIO_SCRATCH1_GET_MP_GPIO_SCRATCH1_DATA(mp2_gpio_scratch1) \
     ((mp2_gpio_scratch1 & MP2_GPIO_SCRATCH1_MP_GPIO_SCRATCH1_DATA_MASK) >> MP2_GPIO_SCRATCH1_MP_GPIO_SCRATCH1_DATA_SHIFT)

#define MP2_GPIO_SCRATCH1_SET_MP_GPIO_SCRATCH1_DATA(mp2_gpio_scratch1_reg, mp_gpio_scratch1_data) \
     mp2_gpio_scratch1_reg = (mp2_gpio_scratch1_reg & ~MP2_GPIO_SCRATCH1_MP_GPIO_SCRATCH1_DATA_MASK) | (mp_gpio_scratch1_data << MP2_GPIO_SCRATCH1_MP_GPIO_SCRATCH1_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio_scratch1_t {
          unsigned int mp_gpio_scratch1_data          : MP2_GPIO_SCRATCH1_MP_GPIO_SCRATCH1_DATA_SIZE;
     } mp2_gpio_scratch1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio_scratch1_t {
          unsigned int mp_gpio_scratch1_data          : MP2_GPIO_SCRATCH1_MP_GPIO_SCRATCH1_DATA_SIZE;
     } mp2_gpio_scratch1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio_scratch1_t f;
} mp2_gpio_scratch1_u;


/*
 * MP2_GPIO_SCRATCH2 struct
 */

#define MP2_GPIO_SCRATCH2_REG_SIZE     32
#define MP2_GPIO_SCRATCH2_MP_GPIO_SCRATCH2_DATA_SIZE 32

#define MP2_GPIO_SCRATCH2_MP_GPIO_SCRATCH2_DATA_SHIFT 0

#define MP2_GPIO_SCRATCH2_MP_GPIO_SCRATCH2_DATA_MASK 0xffffffff

#define MP2_GPIO_SCRATCH2_MASK \
     (MP2_GPIO_SCRATCH2_MP_GPIO_SCRATCH2_DATA_MASK)

#define MP2_GPIO_SCRATCH2_DEFAULT      0x00000000

#define MP2_GPIO_SCRATCH2_GET_MP_GPIO_SCRATCH2_DATA(mp2_gpio_scratch2) \
     ((mp2_gpio_scratch2 & MP2_GPIO_SCRATCH2_MP_GPIO_SCRATCH2_DATA_MASK) >> MP2_GPIO_SCRATCH2_MP_GPIO_SCRATCH2_DATA_SHIFT)

#define MP2_GPIO_SCRATCH2_SET_MP_GPIO_SCRATCH2_DATA(mp2_gpio_scratch2_reg, mp_gpio_scratch2_data) \
     mp2_gpio_scratch2_reg = (mp2_gpio_scratch2_reg & ~MP2_GPIO_SCRATCH2_MP_GPIO_SCRATCH2_DATA_MASK) | (mp_gpio_scratch2_data << MP2_GPIO_SCRATCH2_MP_GPIO_SCRATCH2_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio_scratch2_t {
          unsigned int mp_gpio_scratch2_data          : MP2_GPIO_SCRATCH2_MP_GPIO_SCRATCH2_DATA_SIZE;
     } mp2_gpio_scratch2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio_scratch2_t {
          unsigned int mp_gpio_scratch2_data          : MP2_GPIO_SCRATCH2_MP_GPIO_SCRATCH2_DATA_SIZE;
     } mp2_gpio_scratch2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio_scratch2_t f;
} mp2_gpio_scratch2_u;


/*
 * MP2_GPIO_SCRATCH3 struct
 */

#define MP2_GPIO_SCRATCH3_REG_SIZE     32
#define MP2_GPIO_SCRATCH3_MP_GPIO_SCRATCH3_DATA_SIZE 32

#define MP2_GPIO_SCRATCH3_MP_GPIO_SCRATCH3_DATA_SHIFT 0

#define MP2_GPIO_SCRATCH3_MP_GPIO_SCRATCH3_DATA_MASK 0xffffffff

#define MP2_GPIO_SCRATCH3_MASK \
     (MP2_GPIO_SCRATCH3_MP_GPIO_SCRATCH3_DATA_MASK)

#define MP2_GPIO_SCRATCH3_DEFAULT      0x00000000

#define MP2_GPIO_SCRATCH3_GET_MP_GPIO_SCRATCH3_DATA(mp2_gpio_scratch3) \
     ((mp2_gpio_scratch3 & MP2_GPIO_SCRATCH3_MP_GPIO_SCRATCH3_DATA_MASK) >> MP2_GPIO_SCRATCH3_MP_GPIO_SCRATCH3_DATA_SHIFT)

#define MP2_GPIO_SCRATCH3_SET_MP_GPIO_SCRATCH3_DATA(mp2_gpio_scratch3_reg, mp_gpio_scratch3_data) \
     mp2_gpio_scratch3_reg = (mp2_gpio_scratch3_reg & ~MP2_GPIO_SCRATCH3_MP_GPIO_SCRATCH3_DATA_MASK) | (mp_gpio_scratch3_data << MP2_GPIO_SCRATCH3_MP_GPIO_SCRATCH3_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio_scratch3_t {
          unsigned int mp_gpio_scratch3_data          : MP2_GPIO_SCRATCH3_MP_GPIO_SCRATCH3_DATA_SIZE;
     } mp2_gpio_scratch3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio_scratch3_t {
          unsigned int mp_gpio_scratch3_data          : MP2_GPIO_SCRATCH3_MP_GPIO_SCRATCH3_DATA_SIZE;
     } mp2_gpio_scratch3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio_scratch3_t f;
} mp2_gpio_scratch3_u;


/*
 * MP2_GPIO0_CTRL struct
 */

#define MP2_GPIO0_CTRL_REG_SIZE        32
#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_PD_SIZE 1
#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_PU_SIZE 1
#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_S0_SIZE 1
#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_S1_SIZE 1
#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_SCHMEN_SIZE 1
#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_OE_SIZE 1
#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_A_SIZE 1

#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_PD_SHIFT 1
#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_PU_SHIFT 2
#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_S0_SHIFT 3
#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_S1_SHIFT 4
#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_SCHMEN_SHIFT 5
#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_OE_SHIFT 6
#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_A_SHIFT 7

#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_PD_MASK 0x2
#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_PU_MASK 0x4
#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_S0_MASK 0x8
#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_S1_MASK 0x10
#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_SCHMEN_MASK 0x20
#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_OE_MASK 0x40
#define MP2_GPIO0_CTRL_MP_GPIO0_CTRL_A_MASK 0x80

#define MP2_GPIO0_CTRL_MASK \
     (MP2_GPIO0_CTRL_MP_GPIO0_CTRL_PD_MASK | \
      MP2_GPIO0_CTRL_MP_GPIO0_CTRL_PU_MASK | \
      MP2_GPIO0_CTRL_MP_GPIO0_CTRL_S0_MASK | \
      MP2_GPIO0_CTRL_MP_GPIO0_CTRL_S1_MASK | \
      MP2_GPIO0_CTRL_MP_GPIO0_CTRL_SCHMEN_MASK | \
      MP2_GPIO0_CTRL_MP_GPIO0_CTRL_OE_MASK | \
      MP2_GPIO0_CTRL_MP_GPIO0_CTRL_A_MASK)

#define MP2_GPIO0_CTRL_DEFAULT         0x00000038

#define MP2_GPIO0_CTRL_GET_MP_GPIO0_CTRL_PD(mp2_gpio0_ctrl) \
     ((mp2_gpio0_ctrl & MP2_GPIO0_CTRL_MP_GPIO0_CTRL_PD_MASK) >> MP2_GPIO0_CTRL_MP_GPIO0_CTRL_PD_SHIFT)
#define MP2_GPIO0_CTRL_GET_MP_GPIO0_CTRL_PU(mp2_gpio0_ctrl) \
     ((mp2_gpio0_ctrl & MP2_GPIO0_CTRL_MP_GPIO0_CTRL_PU_MASK) >> MP2_GPIO0_CTRL_MP_GPIO0_CTRL_PU_SHIFT)
#define MP2_GPIO0_CTRL_GET_MP_GPIO0_CTRL_S0(mp2_gpio0_ctrl) \
     ((mp2_gpio0_ctrl & MP2_GPIO0_CTRL_MP_GPIO0_CTRL_S0_MASK) >> MP2_GPIO0_CTRL_MP_GPIO0_CTRL_S0_SHIFT)
#define MP2_GPIO0_CTRL_GET_MP_GPIO0_CTRL_S1(mp2_gpio0_ctrl) \
     ((mp2_gpio0_ctrl & MP2_GPIO0_CTRL_MP_GPIO0_CTRL_S1_MASK) >> MP2_GPIO0_CTRL_MP_GPIO0_CTRL_S1_SHIFT)
#define MP2_GPIO0_CTRL_GET_MP_GPIO0_CTRL_SCHMEN(mp2_gpio0_ctrl) \
     ((mp2_gpio0_ctrl & MP2_GPIO0_CTRL_MP_GPIO0_CTRL_SCHMEN_MASK) >> MP2_GPIO0_CTRL_MP_GPIO0_CTRL_SCHMEN_SHIFT)
#define MP2_GPIO0_CTRL_GET_MP_GPIO0_CTRL_OE(mp2_gpio0_ctrl) \
     ((mp2_gpio0_ctrl & MP2_GPIO0_CTRL_MP_GPIO0_CTRL_OE_MASK) >> MP2_GPIO0_CTRL_MP_GPIO0_CTRL_OE_SHIFT)
#define MP2_GPIO0_CTRL_GET_MP_GPIO0_CTRL_A(mp2_gpio0_ctrl) \
     ((mp2_gpio0_ctrl & MP2_GPIO0_CTRL_MP_GPIO0_CTRL_A_MASK) >> MP2_GPIO0_CTRL_MP_GPIO0_CTRL_A_SHIFT)

#define MP2_GPIO0_CTRL_SET_MP_GPIO0_CTRL_PD(mp2_gpio0_ctrl_reg, mp_gpio0_ctrl_pd) \
     mp2_gpio0_ctrl_reg = (mp2_gpio0_ctrl_reg & ~MP2_GPIO0_CTRL_MP_GPIO0_CTRL_PD_MASK) | (mp_gpio0_ctrl_pd << MP2_GPIO0_CTRL_MP_GPIO0_CTRL_PD_SHIFT)
#define MP2_GPIO0_CTRL_SET_MP_GPIO0_CTRL_PU(mp2_gpio0_ctrl_reg, mp_gpio0_ctrl_pu) \
     mp2_gpio0_ctrl_reg = (mp2_gpio0_ctrl_reg & ~MP2_GPIO0_CTRL_MP_GPIO0_CTRL_PU_MASK) | (mp_gpio0_ctrl_pu << MP2_GPIO0_CTRL_MP_GPIO0_CTRL_PU_SHIFT)
#define MP2_GPIO0_CTRL_SET_MP_GPIO0_CTRL_S0(mp2_gpio0_ctrl_reg, mp_gpio0_ctrl_s0) \
     mp2_gpio0_ctrl_reg = (mp2_gpio0_ctrl_reg & ~MP2_GPIO0_CTRL_MP_GPIO0_CTRL_S0_MASK) | (mp_gpio0_ctrl_s0 << MP2_GPIO0_CTRL_MP_GPIO0_CTRL_S0_SHIFT)
#define MP2_GPIO0_CTRL_SET_MP_GPIO0_CTRL_S1(mp2_gpio0_ctrl_reg, mp_gpio0_ctrl_s1) \
     mp2_gpio0_ctrl_reg = (mp2_gpio0_ctrl_reg & ~MP2_GPIO0_CTRL_MP_GPIO0_CTRL_S1_MASK) | (mp_gpio0_ctrl_s1 << MP2_GPIO0_CTRL_MP_GPIO0_CTRL_S1_SHIFT)
#define MP2_GPIO0_CTRL_SET_MP_GPIO0_CTRL_SCHMEN(mp2_gpio0_ctrl_reg, mp_gpio0_ctrl_schmen) \
     mp2_gpio0_ctrl_reg = (mp2_gpio0_ctrl_reg & ~MP2_GPIO0_CTRL_MP_GPIO0_CTRL_SCHMEN_MASK) | (mp_gpio0_ctrl_schmen << MP2_GPIO0_CTRL_MP_GPIO0_CTRL_SCHMEN_SHIFT)
#define MP2_GPIO0_CTRL_SET_MP_GPIO0_CTRL_OE(mp2_gpio0_ctrl_reg, mp_gpio0_ctrl_oe) \
     mp2_gpio0_ctrl_reg = (mp2_gpio0_ctrl_reg & ~MP2_GPIO0_CTRL_MP_GPIO0_CTRL_OE_MASK) | (mp_gpio0_ctrl_oe << MP2_GPIO0_CTRL_MP_GPIO0_CTRL_OE_SHIFT)
#define MP2_GPIO0_CTRL_SET_MP_GPIO0_CTRL_A(mp2_gpio0_ctrl_reg, mp_gpio0_ctrl_a) \
     mp2_gpio0_ctrl_reg = (mp2_gpio0_ctrl_reg & ~MP2_GPIO0_CTRL_MP_GPIO0_CTRL_A_MASK) | (mp_gpio0_ctrl_a << MP2_GPIO0_CTRL_MP_GPIO0_CTRL_A_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio0_ctrl_t {
          unsigned int                                : 1;
          unsigned int mp_gpio0_ctrl_pd               : MP2_GPIO0_CTRL_MP_GPIO0_CTRL_PD_SIZE;
          unsigned int mp_gpio0_ctrl_pu               : MP2_GPIO0_CTRL_MP_GPIO0_CTRL_PU_SIZE;
          unsigned int mp_gpio0_ctrl_s0               : MP2_GPIO0_CTRL_MP_GPIO0_CTRL_S0_SIZE;
          unsigned int mp_gpio0_ctrl_s1               : MP2_GPIO0_CTRL_MP_GPIO0_CTRL_S1_SIZE;
          unsigned int mp_gpio0_ctrl_schmen           : MP2_GPIO0_CTRL_MP_GPIO0_CTRL_SCHMEN_SIZE;
          unsigned int mp_gpio0_ctrl_oe               : MP2_GPIO0_CTRL_MP_GPIO0_CTRL_OE_SIZE;
          unsigned int mp_gpio0_ctrl_a                : MP2_GPIO0_CTRL_MP_GPIO0_CTRL_A_SIZE;
          unsigned int                                : 24;
     } mp2_gpio0_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio0_ctrl_t {
          unsigned int                                : 24;
          unsigned int mp_gpio0_ctrl_a                : MP2_GPIO0_CTRL_MP_GPIO0_CTRL_A_SIZE;
          unsigned int mp_gpio0_ctrl_oe               : MP2_GPIO0_CTRL_MP_GPIO0_CTRL_OE_SIZE;
          unsigned int mp_gpio0_ctrl_schmen           : MP2_GPIO0_CTRL_MP_GPIO0_CTRL_SCHMEN_SIZE;
          unsigned int mp_gpio0_ctrl_s1               : MP2_GPIO0_CTRL_MP_GPIO0_CTRL_S1_SIZE;
          unsigned int mp_gpio0_ctrl_s0               : MP2_GPIO0_CTRL_MP_GPIO0_CTRL_S0_SIZE;
          unsigned int mp_gpio0_ctrl_pu               : MP2_GPIO0_CTRL_MP_GPIO0_CTRL_PU_SIZE;
          unsigned int mp_gpio0_ctrl_pd               : MP2_GPIO0_CTRL_MP_GPIO0_CTRL_PD_SIZE;
          unsigned int                                : 1;
     } mp2_gpio0_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio0_ctrl_t f;
} mp2_gpio0_ctrl_u;


/*
 * MP2_GPIO0_FCH_INT_OVERRIDE struct
 */

#define MP2_GPIO0_FCH_INT_OVERRIDE_REG_SIZE 32
#define MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_EN_SIZE 1
#define MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_OUTPUT_SIZE 1
#define MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_STAT_SIZE 1

#define MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_EN_SHIFT 0
#define MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_OUTPUT_SHIFT 1
#define MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_STAT_SHIFT 2

#define MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_EN_MASK 0x1
#define MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_OUTPUT_MASK 0x2
#define MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_STAT_MASK 0x4

#define MP2_GPIO0_FCH_INT_OVERRIDE_MASK \
     (MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_EN_MASK | \
      MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_OUTPUT_MASK | \
      MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_STAT_MASK)

#define MP2_GPIO0_FCH_INT_OVERRIDE_DEFAULT 0x00000000

#define MP2_GPIO0_FCH_INT_OVERRIDE_GET_MP_FCH_INT_OVERRIDE_GPIO0_EN(mp2_gpio0_fch_int_override) \
     ((mp2_gpio0_fch_int_override & MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_EN_MASK) >> MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_EN_SHIFT)
#define MP2_GPIO0_FCH_INT_OVERRIDE_GET_MP_FCH_INT_OVERRIDE_GPIO0_OUTPUT(mp2_gpio0_fch_int_override) \
     ((mp2_gpio0_fch_int_override & MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_OUTPUT_MASK) >> MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_OUTPUT_SHIFT)
#define MP2_GPIO0_FCH_INT_OVERRIDE_GET_MP_FCH_INT_OVERRIDE_GPIO0_STAT(mp2_gpio0_fch_int_override) \
     ((mp2_gpio0_fch_int_override & MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_STAT_MASK) >> MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_STAT_SHIFT)

#define MP2_GPIO0_FCH_INT_OVERRIDE_SET_MP_FCH_INT_OVERRIDE_GPIO0_EN(mp2_gpio0_fch_int_override_reg, mp_fch_int_override_gpio0_en) \
     mp2_gpio0_fch_int_override_reg = (mp2_gpio0_fch_int_override_reg & ~MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_EN_MASK) | (mp_fch_int_override_gpio0_en << MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_EN_SHIFT)
#define MP2_GPIO0_FCH_INT_OVERRIDE_SET_MP_FCH_INT_OVERRIDE_GPIO0_OUTPUT(mp2_gpio0_fch_int_override_reg, mp_fch_int_override_gpio0_output) \
     mp2_gpio0_fch_int_override_reg = (mp2_gpio0_fch_int_override_reg & ~MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_OUTPUT_MASK) | (mp_fch_int_override_gpio0_output << MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_OUTPUT_SHIFT)
#define MP2_GPIO0_FCH_INT_OVERRIDE_SET_MP_FCH_INT_OVERRIDE_GPIO0_STAT(mp2_gpio0_fch_int_override_reg, mp_fch_int_override_gpio0_stat) \
     mp2_gpio0_fch_int_override_reg = (mp2_gpio0_fch_int_override_reg & ~MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_STAT_MASK) | (mp_fch_int_override_gpio0_stat << MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio0_fch_int_override_t {
          unsigned int mp_fch_int_override_gpio0_en   : MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_EN_SIZE;
          unsigned int mp_fch_int_override_gpio0_output : MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_OUTPUT_SIZE;
          unsigned int mp_fch_int_override_gpio0_stat : MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_gpio0_fch_int_override_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio0_fch_int_override_t {
          unsigned int                                : 29;
          unsigned int mp_fch_int_override_gpio0_stat : MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_STAT_SIZE;
          unsigned int mp_fch_int_override_gpio0_output : MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_OUTPUT_SIZE;
          unsigned int mp_fch_int_override_gpio0_en   : MP2_GPIO0_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO0_EN_SIZE;
     } mp2_gpio0_fch_int_override_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio0_fch_int_override_t f;
} mp2_gpio0_fch_int_override_u;


/*
 * MP2_GPIO0_MP_INT struct
 */

#define MP2_GPIO0_MP_INT_REG_SIZE      32
#define MP2_GPIO0_MP_INT_MP2_GPIO0_MP_INT_EN_SIZE 2
#define MP2_GPIO0_MP_INT_MP2_GPIO0_MP_INT_STAT_SIZE 1

#define MP2_GPIO0_MP_INT_MP2_GPIO0_MP_INT_EN_SHIFT 0
#define MP2_GPIO0_MP_INT_MP2_GPIO0_MP_INT_STAT_SHIFT 2

#define MP2_GPIO0_MP_INT_MP2_GPIO0_MP_INT_EN_MASK 0x3
#define MP2_GPIO0_MP_INT_MP2_GPIO0_MP_INT_STAT_MASK 0x4

#define MP2_GPIO0_MP_INT_MASK \
     (MP2_GPIO0_MP_INT_MP2_GPIO0_MP_INT_EN_MASK | \
      MP2_GPIO0_MP_INT_MP2_GPIO0_MP_INT_STAT_MASK)

#define MP2_GPIO0_MP_INT_DEFAULT       0x00000000

#define MP2_GPIO0_MP_INT_GET_MP2_GPIO0_MP_INT_EN(mp2_gpio0_mp_int) \
     ((mp2_gpio0_mp_int & MP2_GPIO0_MP_INT_MP2_GPIO0_MP_INT_EN_MASK) >> MP2_GPIO0_MP_INT_MP2_GPIO0_MP_INT_EN_SHIFT)
#define MP2_GPIO0_MP_INT_GET_MP2_GPIO0_MP_INT_STAT(mp2_gpio0_mp_int) \
     ((mp2_gpio0_mp_int & MP2_GPIO0_MP_INT_MP2_GPIO0_MP_INT_STAT_MASK) >> MP2_GPIO0_MP_INT_MP2_GPIO0_MP_INT_STAT_SHIFT)

#define MP2_GPIO0_MP_INT_SET_MP2_GPIO0_MP_INT_EN(mp2_gpio0_mp_int_reg, mp2_gpio0_mp_int_en) \
     mp2_gpio0_mp_int_reg = (mp2_gpio0_mp_int_reg & ~MP2_GPIO0_MP_INT_MP2_GPIO0_MP_INT_EN_MASK) | (mp2_gpio0_mp_int_en << MP2_GPIO0_MP_INT_MP2_GPIO0_MP_INT_EN_SHIFT)
#define MP2_GPIO0_MP_INT_SET_MP2_GPIO0_MP_INT_STAT(mp2_gpio0_mp_int_reg, mp2_gpio0_mp_int_stat) \
     mp2_gpio0_mp_int_reg = (mp2_gpio0_mp_int_reg & ~MP2_GPIO0_MP_INT_MP2_GPIO0_MP_INT_STAT_MASK) | (mp2_gpio0_mp_int_stat << MP2_GPIO0_MP_INT_MP2_GPIO0_MP_INT_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio0_mp_int_t {
          unsigned int mp2_gpio0_mp_int_en            : MP2_GPIO0_MP_INT_MP2_GPIO0_MP_INT_EN_SIZE;
          unsigned int mp2_gpio0_mp_int_stat          : MP2_GPIO0_MP_INT_MP2_GPIO0_MP_INT_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_gpio0_mp_int_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio0_mp_int_t {
          unsigned int                                : 29;
          unsigned int mp2_gpio0_mp_int_stat          : MP2_GPIO0_MP_INT_MP2_GPIO0_MP_INT_STAT_SIZE;
          unsigned int mp2_gpio0_mp_int_en            : MP2_GPIO0_MP_INT_MP2_GPIO0_MP_INT_EN_SIZE;
     } mp2_gpio0_mp_int_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio0_mp_int_t f;
} mp2_gpio0_mp_int_u;


/*
 * MP2_GPIO0_FCH_INT struct
 */

#define MP2_GPIO0_FCH_INT_REG_SIZE     32
#define MP2_GPIO0_FCH_INT_MP2_GPIO0_FCH_INT_EN_SIZE 2
#define MP2_GPIO0_FCH_INT_MP2_GPIO0_FCH_INT_STAT_SIZE 1

#define MP2_GPIO0_FCH_INT_MP2_GPIO0_FCH_INT_EN_SHIFT 0
#define MP2_GPIO0_FCH_INT_MP2_GPIO0_FCH_INT_STAT_SHIFT 2

#define MP2_GPIO0_FCH_INT_MP2_GPIO0_FCH_INT_EN_MASK 0x3
#define MP2_GPIO0_FCH_INT_MP2_GPIO0_FCH_INT_STAT_MASK 0x4

#define MP2_GPIO0_FCH_INT_MASK \
     (MP2_GPIO0_FCH_INT_MP2_GPIO0_FCH_INT_EN_MASK | \
      MP2_GPIO0_FCH_INT_MP2_GPIO0_FCH_INT_STAT_MASK)

#define MP2_GPIO0_FCH_INT_DEFAULT      0x00000000

#define MP2_GPIO0_FCH_INT_GET_MP2_GPIO0_FCH_INT_EN(mp2_gpio0_fch_int) \
     ((mp2_gpio0_fch_int & MP2_GPIO0_FCH_INT_MP2_GPIO0_FCH_INT_EN_MASK) >> MP2_GPIO0_FCH_INT_MP2_GPIO0_FCH_INT_EN_SHIFT)
#define MP2_GPIO0_FCH_INT_GET_MP2_GPIO0_FCH_INT_STAT(mp2_gpio0_fch_int) \
     ((mp2_gpio0_fch_int & MP2_GPIO0_FCH_INT_MP2_GPIO0_FCH_INT_STAT_MASK) >> MP2_GPIO0_FCH_INT_MP2_GPIO0_FCH_INT_STAT_SHIFT)

#define MP2_GPIO0_FCH_INT_SET_MP2_GPIO0_FCH_INT_EN(mp2_gpio0_fch_int_reg, mp2_gpio0_fch_int_en) \
     mp2_gpio0_fch_int_reg = (mp2_gpio0_fch_int_reg & ~MP2_GPIO0_FCH_INT_MP2_GPIO0_FCH_INT_EN_MASK) | (mp2_gpio0_fch_int_en << MP2_GPIO0_FCH_INT_MP2_GPIO0_FCH_INT_EN_SHIFT)
#define MP2_GPIO0_FCH_INT_SET_MP2_GPIO0_FCH_INT_STAT(mp2_gpio0_fch_int_reg, mp2_gpio0_fch_int_stat) \
     mp2_gpio0_fch_int_reg = (mp2_gpio0_fch_int_reg & ~MP2_GPIO0_FCH_INT_MP2_GPIO0_FCH_INT_STAT_MASK) | (mp2_gpio0_fch_int_stat << MP2_GPIO0_FCH_INT_MP2_GPIO0_FCH_INT_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio0_fch_int_t {
          unsigned int mp2_gpio0_fch_int_en           : MP2_GPIO0_FCH_INT_MP2_GPIO0_FCH_INT_EN_SIZE;
          unsigned int mp2_gpio0_fch_int_stat         : MP2_GPIO0_FCH_INT_MP2_GPIO0_FCH_INT_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_gpio0_fch_int_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio0_fch_int_t {
          unsigned int                                : 29;
          unsigned int mp2_gpio0_fch_int_stat         : MP2_GPIO0_FCH_INT_MP2_GPIO0_FCH_INT_STAT_SIZE;
          unsigned int mp2_gpio0_fch_int_en           : MP2_GPIO0_FCH_INT_MP2_GPIO0_FCH_INT_EN_SIZE;
     } mp2_gpio0_fch_int_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio0_fch_int_t f;
} mp2_gpio0_fch_int_u;


/*
 * MP2_GPIO0_IO_STATUS struct
 */

#define MP2_GPIO0_IO_STATUS_REG_SIZE   32
#define MP2_GPIO0_IO_STATUS_MP_GPIO_INPUT_GPIO0_SIZE 1
#define MP2_GPIO0_IO_STATUS_MP_GPIO_OUTPUT_GPIO0_SIZE 1

#define MP2_GPIO0_IO_STATUS_MP_GPIO_INPUT_GPIO0_SHIFT 0
#define MP2_GPIO0_IO_STATUS_MP_GPIO_OUTPUT_GPIO0_SHIFT 1

#define MP2_GPIO0_IO_STATUS_MP_GPIO_INPUT_GPIO0_MASK 0x1
#define MP2_GPIO0_IO_STATUS_MP_GPIO_OUTPUT_GPIO0_MASK 0x2

#define MP2_GPIO0_IO_STATUS_MASK \
     (MP2_GPIO0_IO_STATUS_MP_GPIO_INPUT_GPIO0_MASK | \
      MP2_GPIO0_IO_STATUS_MP_GPIO_OUTPUT_GPIO0_MASK)

#define MP2_GPIO0_IO_STATUS_DEFAULT    0x00000000

#define MP2_GPIO0_IO_STATUS_GET_MP_GPIO_INPUT_GPIO0(mp2_gpio0_io_status) \
     ((mp2_gpio0_io_status & MP2_GPIO0_IO_STATUS_MP_GPIO_INPUT_GPIO0_MASK) >> MP2_GPIO0_IO_STATUS_MP_GPIO_INPUT_GPIO0_SHIFT)
#define MP2_GPIO0_IO_STATUS_GET_MP_GPIO_OUTPUT_GPIO0(mp2_gpio0_io_status) \
     ((mp2_gpio0_io_status & MP2_GPIO0_IO_STATUS_MP_GPIO_OUTPUT_GPIO0_MASK) >> MP2_GPIO0_IO_STATUS_MP_GPIO_OUTPUT_GPIO0_SHIFT)

#define MP2_GPIO0_IO_STATUS_SET_MP_GPIO_INPUT_GPIO0(mp2_gpio0_io_status_reg, mp_gpio_input_gpio0) \
     mp2_gpio0_io_status_reg = (mp2_gpio0_io_status_reg & ~MP2_GPIO0_IO_STATUS_MP_GPIO_INPUT_GPIO0_MASK) | (mp_gpio_input_gpio0 << MP2_GPIO0_IO_STATUS_MP_GPIO_INPUT_GPIO0_SHIFT)
#define MP2_GPIO0_IO_STATUS_SET_MP_GPIO_OUTPUT_GPIO0(mp2_gpio0_io_status_reg, mp_gpio_output_gpio0) \
     mp2_gpio0_io_status_reg = (mp2_gpio0_io_status_reg & ~MP2_GPIO0_IO_STATUS_MP_GPIO_OUTPUT_GPIO0_MASK) | (mp_gpio_output_gpio0 << MP2_GPIO0_IO_STATUS_MP_GPIO_OUTPUT_GPIO0_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio0_io_status_t {
          unsigned int mp_gpio_input_gpio0            : MP2_GPIO0_IO_STATUS_MP_GPIO_INPUT_GPIO0_SIZE;
          unsigned int mp_gpio_output_gpio0           : MP2_GPIO0_IO_STATUS_MP_GPIO_OUTPUT_GPIO0_SIZE;
          unsigned int                                : 30;
     } mp2_gpio0_io_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio0_io_status_t {
          unsigned int                                : 30;
          unsigned int mp_gpio_output_gpio0           : MP2_GPIO0_IO_STATUS_MP_GPIO_OUTPUT_GPIO0_SIZE;
          unsigned int mp_gpio_input_gpio0            : MP2_GPIO0_IO_STATUS_MP_GPIO_INPUT_GPIO0_SIZE;
     } mp2_gpio0_io_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio0_io_status_t f;
} mp2_gpio0_io_status_u;


/*
 * MP2_GPIO1_CTRL struct
 */

#define MP2_GPIO1_CTRL_REG_SIZE        32
#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_PD_SIZE 1
#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_PU_SIZE 1
#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_S0_SIZE 1
#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_S1_SIZE 1
#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_SCHMEN_SIZE 1
#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_OE_SIZE 1
#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_A_SIZE 1

#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_PD_SHIFT 1
#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_PU_SHIFT 2
#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_S0_SHIFT 3
#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_S1_SHIFT 4
#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_SCHMEN_SHIFT 5
#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_OE_SHIFT 6
#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_A_SHIFT 7

#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_PD_MASK 0x2
#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_PU_MASK 0x4
#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_S0_MASK 0x8
#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_S1_MASK 0x10
#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_SCHMEN_MASK 0x20
#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_OE_MASK 0x40
#define MP2_GPIO1_CTRL_MP_GPIO1_CTRL_A_MASK 0x80

#define MP2_GPIO1_CTRL_MASK \
     (MP2_GPIO1_CTRL_MP_GPIO1_CTRL_PD_MASK | \
      MP2_GPIO1_CTRL_MP_GPIO1_CTRL_PU_MASK | \
      MP2_GPIO1_CTRL_MP_GPIO1_CTRL_S0_MASK | \
      MP2_GPIO1_CTRL_MP_GPIO1_CTRL_S1_MASK | \
      MP2_GPIO1_CTRL_MP_GPIO1_CTRL_SCHMEN_MASK | \
      MP2_GPIO1_CTRL_MP_GPIO1_CTRL_OE_MASK | \
      MP2_GPIO1_CTRL_MP_GPIO1_CTRL_A_MASK)

#define MP2_GPIO1_CTRL_DEFAULT         0x00000038

#define MP2_GPIO1_CTRL_GET_MP_GPIO1_CTRL_PD(mp2_gpio1_ctrl) \
     ((mp2_gpio1_ctrl & MP2_GPIO1_CTRL_MP_GPIO1_CTRL_PD_MASK) >> MP2_GPIO1_CTRL_MP_GPIO1_CTRL_PD_SHIFT)
#define MP2_GPIO1_CTRL_GET_MP_GPIO1_CTRL_PU(mp2_gpio1_ctrl) \
     ((mp2_gpio1_ctrl & MP2_GPIO1_CTRL_MP_GPIO1_CTRL_PU_MASK) >> MP2_GPIO1_CTRL_MP_GPIO1_CTRL_PU_SHIFT)
#define MP2_GPIO1_CTRL_GET_MP_GPIO1_CTRL_S0(mp2_gpio1_ctrl) \
     ((mp2_gpio1_ctrl & MP2_GPIO1_CTRL_MP_GPIO1_CTRL_S0_MASK) >> MP2_GPIO1_CTRL_MP_GPIO1_CTRL_S0_SHIFT)
#define MP2_GPIO1_CTRL_GET_MP_GPIO1_CTRL_S1(mp2_gpio1_ctrl) \
     ((mp2_gpio1_ctrl & MP2_GPIO1_CTRL_MP_GPIO1_CTRL_S1_MASK) >> MP2_GPIO1_CTRL_MP_GPIO1_CTRL_S1_SHIFT)
#define MP2_GPIO1_CTRL_GET_MP_GPIO1_CTRL_SCHMEN(mp2_gpio1_ctrl) \
     ((mp2_gpio1_ctrl & MP2_GPIO1_CTRL_MP_GPIO1_CTRL_SCHMEN_MASK) >> MP2_GPIO1_CTRL_MP_GPIO1_CTRL_SCHMEN_SHIFT)
#define MP2_GPIO1_CTRL_GET_MP_GPIO1_CTRL_OE(mp2_gpio1_ctrl) \
     ((mp2_gpio1_ctrl & MP2_GPIO1_CTRL_MP_GPIO1_CTRL_OE_MASK) >> MP2_GPIO1_CTRL_MP_GPIO1_CTRL_OE_SHIFT)
#define MP2_GPIO1_CTRL_GET_MP_GPIO1_CTRL_A(mp2_gpio1_ctrl) \
     ((mp2_gpio1_ctrl & MP2_GPIO1_CTRL_MP_GPIO1_CTRL_A_MASK) >> MP2_GPIO1_CTRL_MP_GPIO1_CTRL_A_SHIFT)

#define MP2_GPIO1_CTRL_SET_MP_GPIO1_CTRL_PD(mp2_gpio1_ctrl_reg, mp_gpio1_ctrl_pd) \
     mp2_gpio1_ctrl_reg = (mp2_gpio1_ctrl_reg & ~MP2_GPIO1_CTRL_MP_GPIO1_CTRL_PD_MASK) | (mp_gpio1_ctrl_pd << MP2_GPIO1_CTRL_MP_GPIO1_CTRL_PD_SHIFT)
#define MP2_GPIO1_CTRL_SET_MP_GPIO1_CTRL_PU(mp2_gpio1_ctrl_reg, mp_gpio1_ctrl_pu) \
     mp2_gpio1_ctrl_reg = (mp2_gpio1_ctrl_reg & ~MP2_GPIO1_CTRL_MP_GPIO1_CTRL_PU_MASK) | (mp_gpio1_ctrl_pu << MP2_GPIO1_CTRL_MP_GPIO1_CTRL_PU_SHIFT)
#define MP2_GPIO1_CTRL_SET_MP_GPIO1_CTRL_S0(mp2_gpio1_ctrl_reg, mp_gpio1_ctrl_s0) \
     mp2_gpio1_ctrl_reg = (mp2_gpio1_ctrl_reg & ~MP2_GPIO1_CTRL_MP_GPIO1_CTRL_S0_MASK) | (mp_gpio1_ctrl_s0 << MP2_GPIO1_CTRL_MP_GPIO1_CTRL_S0_SHIFT)
#define MP2_GPIO1_CTRL_SET_MP_GPIO1_CTRL_S1(mp2_gpio1_ctrl_reg, mp_gpio1_ctrl_s1) \
     mp2_gpio1_ctrl_reg = (mp2_gpio1_ctrl_reg & ~MP2_GPIO1_CTRL_MP_GPIO1_CTRL_S1_MASK) | (mp_gpio1_ctrl_s1 << MP2_GPIO1_CTRL_MP_GPIO1_CTRL_S1_SHIFT)
#define MP2_GPIO1_CTRL_SET_MP_GPIO1_CTRL_SCHMEN(mp2_gpio1_ctrl_reg, mp_gpio1_ctrl_schmen) \
     mp2_gpio1_ctrl_reg = (mp2_gpio1_ctrl_reg & ~MP2_GPIO1_CTRL_MP_GPIO1_CTRL_SCHMEN_MASK) | (mp_gpio1_ctrl_schmen << MP2_GPIO1_CTRL_MP_GPIO1_CTRL_SCHMEN_SHIFT)
#define MP2_GPIO1_CTRL_SET_MP_GPIO1_CTRL_OE(mp2_gpio1_ctrl_reg, mp_gpio1_ctrl_oe) \
     mp2_gpio1_ctrl_reg = (mp2_gpio1_ctrl_reg & ~MP2_GPIO1_CTRL_MP_GPIO1_CTRL_OE_MASK) | (mp_gpio1_ctrl_oe << MP2_GPIO1_CTRL_MP_GPIO1_CTRL_OE_SHIFT)
#define MP2_GPIO1_CTRL_SET_MP_GPIO1_CTRL_A(mp2_gpio1_ctrl_reg, mp_gpio1_ctrl_a) \
     mp2_gpio1_ctrl_reg = (mp2_gpio1_ctrl_reg & ~MP2_GPIO1_CTRL_MP_GPIO1_CTRL_A_MASK) | (mp_gpio1_ctrl_a << MP2_GPIO1_CTRL_MP_GPIO1_CTRL_A_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio1_ctrl_t {
          unsigned int                                : 1;
          unsigned int mp_gpio1_ctrl_pd               : MP2_GPIO1_CTRL_MP_GPIO1_CTRL_PD_SIZE;
          unsigned int mp_gpio1_ctrl_pu               : MP2_GPIO1_CTRL_MP_GPIO1_CTRL_PU_SIZE;
          unsigned int mp_gpio1_ctrl_s0               : MP2_GPIO1_CTRL_MP_GPIO1_CTRL_S0_SIZE;
          unsigned int mp_gpio1_ctrl_s1               : MP2_GPIO1_CTRL_MP_GPIO1_CTRL_S1_SIZE;
          unsigned int mp_gpio1_ctrl_schmen           : MP2_GPIO1_CTRL_MP_GPIO1_CTRL_SCHMEN_SIZE;
          unsigned int mp_gpio1_ctrl_oe               : MP2_GPIO1_CTRL_MP_GPIO1_CTRL_OE_SIZE;
          unsigned int mp_gpio1_ctrl_a                : MP2_GPIO1_CTRL_MP_GPIO1_CTRL_A_SIZE;
          unsigned int                                : 24;
     } mp2_gpio1_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio1_ctrl_t {
          unsigned int                                : 24;
          unsigned int mp_gpio1_ctrl_a                : MP2_GPIO1_CTRL_MP_GPIO1_CTRL_A_SIZE;
          unsigned int mp_gpio1_ctrl_oe               : MP2_GPIO1_CTRL_MP_GPIO1_CTRL_OE_SIZE;
          unsigned int mp_gpio1_ctrl_schmen           : MP2_GPIO1_CTRL_MP_GPIO1_CTRL_SCHMEN_SIZE;
          unsigned int mp_gpio1_ctrl_s1               : MP2_GPIO1_CTRL_MP_GPIO1_CTRL_S1_SIZE;
          unsigned int mp_gpio1_ctrl_s0               : MP2_GPIO1_CTRL_MP_GPIO1_CTRL_S0_SIZE;
          unsigned int mp_gpio1_ctrl_pu               : MP2_GPIO1_CTRL_MP_GPIO1_CTRL_PU_SIZE;
          unsigned int mp_gpio1_ctrl_pd               : MP2_GPIO1_CTRL_MP_GPIO1_CTRL_PD_SIZE;
          unsigned int                                : 1;
     } mp2_gpio1_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio1_ctrl_t f;
} mp2_gpio1_ctrl_u;


/*
 * MP2_GPIO1_FCH_INT_OVERRIDE struct
 */

#define MP2_GPIO1_FCH_INT_OVERRIDE_REG_SIZE 32
#define MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_EN_SIZE 1
#define MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_OUTPUT_SIZE 1
#define MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_STAT_SIZE 1

#define MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_EN_SHIFT 0
#define MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_OUTPUT_SHIFT 1
#define MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_STAT_SHIFT 2

#define MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_EN_MASK 0x1
#define MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_OUTPUT_MASK 0x2
#define MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_STAT_MASK 0x4

#define MP2_GPIO1_FCH_INT_OVERRIDE_MASK \
     (MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_EN_MASK | \
      MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_OUTPUT_MASK | \
      MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_STAT_MASK)

#define MP2_GPIO1_FCH_INT_OVERRIDE_DEFAULT 0x00000000

#define MP2_GPIO1_FCH_INT_OVERRIDE_GET_MP_FCH_INT_OVERRIDE_GPIO1_EN(mp2_gpio1_fch_int_override) \
     ((mp2_gpio1_fch_int_override & MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_EN_MASK) >> MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_EN_SHIFT)
#define MP2_GPIO1_FCH_INT_OVERRIDE_GET_MP_FCH_INT_OVERRIDE_GPIO1_OUTPUT(mp2_gpio1_fch_int_override) \
     ((mp2_gpio1_fch_int_override & MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_OUTPUT_MASK) >> MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_OUTPUT_SHIFT)
#define MP2_GPIO1_FCH_INT_OVERRIDE_GET_MP_FCH_INT_OVERRIDE_GPIO1_STAT(mp2_gpio1_fch_int_override) \
     ((mp2_gpio1_fch_int_override & MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_STAT_MASK) >> MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_STAT_SHIFT)

#define MP2_GPIO1_FCH_INT_OVERRIDE_SET_MP_FCH_INT_OVERRIDE_GPIO1_EN(mp2_gpio1_fch_int_override_reg, mp_fch_int_override_gpio1_en) \
     mp2_gpio1_fch_int_override_reg = (mp2_gpio1_fch_int_override_reg & ~MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_EN_MASK) | (mp_fch_int_override_gpio1_en << MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_EN_SHIFT)
#define MP2_GPIO1_FCH_INT_OVERRIDE_SET_MP_FCH_INT_OVERRIDE_GPIO1_OUTPUT(mp2_gpio1_fch_int_override_reg, mp_fch_int_override_gpio1_output) \
     mp2_gpio1_fch_int_override_reg = (mp2_gpio1_fch_int_override_reg & ~MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_OUTPUT_MASK) | (mp_fch_int_override_gpio1_output << MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_OUTPUT_SHIFT)
#define MP2_GPIO1_FCH_INT_OVERRIDE_SET_MP_FCH_INT_OVERRIDE_GPIO1_STAT(mp2_gpio1_fch_int_override_reg, mp_fch_int_override_gpio1_stat) \
     mp2_gpio1_fch_int_override_reg = (mp2_gpio1_fch_int_override_reg & ~MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_STAT_MASK) | (mp_fch_int_override_gpio1_stat << MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio1_fch_int_override_t {
          unsigned int mp_fch_int_override_gpio1_en   : MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_EN_SIZE;
          unsigned int mp_fch_int_override_gpio1_output : MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_OUTPUT_SIZE;
          unsigned int mp_fch_int_override_gpio1_stat : MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_gpio1_fch_int_override_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio1_fch_int_override_t {
          unsigned int                                : 29;
          unsigned int mp_fch_int_override_gpio1_stat : MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_STAT_SIZE;
          unsigned int mp_fch_int_override_gpio1_output : MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_OUTPUT_SIZE;
          unsigned int mp_fch_int_override_gpio1_en   : MP2_GPIO1_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO1_EN_SIZE;
     } mp2_gpio1_fch_int_override_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio1_fch_int_override_t f;
} mp2_gpio1_fch_int_override_u;


/*
 * MP2_GPIO1_MP_INT struct
 */

#define MP2_GPIO1_MP_INT_REG_SIZE      32
#define MP2_GPIO1_MP_INT_MP2_GPIO1_MP_INT_EN_SIZE 2
#define MP2_GPIO1_MP_INT_MP2_GPIO1_MP_INT_STAT_SIZE 1

#define MP2_GPIO1_MP_INT_MP2_GPIO1_MP_INT_EN_SHIFT 0
#define MP2_GPIO1_MP_INT_MP2_GPIO1_MP_INT_STAT_SHIFT 2

#define MP2_GPIO1_MP_INT_MP2_GPIO1_MP_INT_EN_MASK 0x3
#define MP2_GPIO1_MP_INT_MP2_GPIO1_MP_INT_STAT_MASK 0x4

#define MP2_GPIO1_MP_INT_MASK \
     (MP2_GPIO1_MP_INT_MP2_GPIO1_MP_INT_EN_MASK | \
      MP2_GPIO1_MP_INT_MP2_GPIO1_MP_INT_STAT_MASK)

#define MP2_GPIO1_MP_INT_DEFAULT       0x00000000

#define MP2_GPIO1_MP_INT_GET_MP2_GPIO1_MP_INT_EN(mp2_gpio1_mp_int) \
     ((mp2_gpio1_mp_int & MP2_GPIO1_MP_INT_MP2_GPIO1_MP_INT_EN_MASK) >> MP2_GPIO1_MP_INT_MP2_GPIO1_MP_INT_EN_SHIFT)
#define MP2_GPIO1_MP_INT_GET_MP2_GPIO1_MP_INT_STAT(mp2_gpio1_mp_int) \
     ((mp2_gpio1_mp_int & MP2_GPIO1_MP_INT_MP2_GPIO1_MP_INT_STAT_MASK) >> MP2_GPIO1_MP_INT_MP2_GPIO1_MP_INT_STAT_SHIFT)

#define MP2_GPIO1_MP_INT_SET_MP2_GPIO1_MP_INT_EN(mp2_gpio1_mp_int_reg, mp2_gpio1_mp_int_en) \
     mp2_gpio1_mp_int_reg = (mp2_gpio1_mp_int_reg & ~MP2_GPIO1_MP_INT_MP2_GPIO1_MP_INT_EN_MASK) | (mp2_gpio1_mp_int_en << MP2_GPIO1_MP_INT_MP2_GPIO1_MP_INT_EN_SHIFT)
#define MP2_GPIO1_MP_INT_SET_MP2_GPIO1_MP_INT_STAT(mp2_gpio1_mp_int_reg, mp2_gpio1_mp_int_stat) \
     mp2_gpio1_mp_int_reg = (mp2_gpio1_mp_int_reg & ~MP2_GPIO1_MP_INT_MP2_GPIO1_MP_INT_STAT_MASK) | (mp2_gpio1_mp_int_stat << MP2_GPIO1_MP_INT_MP2_GPIO1_MP_INT_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio1_mp_int_t {
          unsigned int mp2_gpio1_mp_int_en            : MP2_GPIO1_MP_INT_MP2_GPIO1_MP_INT_EN_SIZE;
          unsigned int mp2_gpio1_mp_int_stat          : MP2_GPIO1_MP_INT_MP2_GPIO1_MP_INT_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_gpio1_mp_int_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio1_mp_int_t {
          unsigned int                                : 29;
          unsigned int mp2_gpio1_mp_int_stat          : MP2_GPIO1_MP_INT_MP2_GPIO1_MP_INT_STAT_SIZE;
          unsigned int mp2_gpio1_mp_int_en            : MP2_GPIO1_MP_INT_MP2_GPIO1_MP_INT_EN_SIZE;
     } mp2_gpio1_mp_int_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio1_mp_int_t f;
} mp2_gpio1_mp_int_u;


/*
 * MP2_GPIO1_FCH_INT struct
 */

#define MP2_GPIO1_FCH_INT_REG_SIZE     32
#define MP2_GPIO1_FCH_INT_MP2_GPIO1_FCH_INT_EN_SIZE 2
#define MP2_GPIO1_FCH_INT_MP2_GPIO1_FCH_INT_STAT_SIZE 1

#define MP2_GPIO1_FCH_INT_MP2_GPIO1_FCH_INT_EN_SHIFT 0
#define MP2_GPIO1_FCH_INT_MP2_GPIO1_FCH_INT_STAT_SHIFT 2

#define MP2_GPIO1_FCH_INT_MP2_GPIO1_FCH_INT_EN_MASK 0x3
#define MP2_GPIO1_FCH_INT_MP2_GPIO1_FCH_INT_STAT_MASK 0x4

#define MP2_GPIO1_FCH_INT_MASK \
     (MP2_GPIO1_FCH_INT_MP2_GPIO1_FCH_INT_EN_MASK | \
      MP2_GPIO1_FCH_INT_MP2_GPIO1_FCH_INT_STAT_MASK)

#define MP2_GPIO1_FCH_INT_DEFAULT      0x00000000

#define MP2_GPIO1_FCH_INT_GET_MP2_GPIO1_FCH_INT_EN(mp2_gpio1_fch_int) \
     ((mp2_gpio1_fch_int & MP2_GPIO1_FCH_INT_MP2_GPIO1_FCH_INT_EN_MASK) >> MP2_GPIO1_FCH_INT_MP2_GPIO1_FCH_INT_EN_SHIFT)
#define MP2_GPIO1_FCH_INT_GET_MP2_GPIO1_FCH_INT_STAT(mp2_gpio1_fch_int) \
     ((mp2_gpio1_fch_int & MP2_GPIO1_FCH_INT_MP2_GPIO1_FCH_INT_STAT_MASK) >> MP2_GPIO1_FCH_INT_MP2_GPIO1_FCH_INT_STAT_SHIFT)

#define MP2_GPIO1_FCH_INT_SET_MP2_GPIO1_FCH_INT_EN(mp2_gpio1_fch_int_reg, mp2_gpio1_fch_int_en) \
     mp2_gpio1_fch_int_reg = (mp2_gpio1_fch_int_reg & ~MP2_GPIO1_FCH_INT_MP2_GPIO1_FCH_INT_EN_MASK) | (mp2_gpio1_fch_int_en << MP2_GPIO1_FCH_INT_MP2_GPIO1_FCH_INT_EN_SHIFT)
#define MP2_GPIO1_FCH_INT_SET_MP2_GPIO1_FCH_INT_STAT(mp2_gpio1_fch_int_reg, mp2_gpio1_fch_int_stat) \
     mp2_gpio1_fch_int_reg = (mp2_gpio1_fch_int_reg & ~MP2_GPIO1_FCH_INT_MP2_GPIO1_FCH_INT_STAT_MASK) | (mp2_gpio1_fch_int_stat << MP2_GPIO1_FCH_INT_MP2_GPIO1_FCH_INT_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio1_fch_int_t {
          unsigned int mp2_gpio1_fch_int_en           : MP2_GPIO1_FCH_INT_MP2_GPIO1_FCH_INT_EN_SIZE;
          unsigned int mp2_gpio1_fch_int_stat         : MP2_GPIO1_FCH_INT_MP2_GPIO1_FCH_INT_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_gpio1_fch_int_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio1_fch_int_t {
          unsigned int                                : 29;
          unsigned int mp2_gpio1_fch_int_stat         : MP2_GPIO1_FCH_INT_MP2_GPIO1_FCH_INT_STAT_SIZE;
          unsigned int mp2_gpio1_fch_int_en           : MP2_GPIO1_FCH_INT_MP2_GPIO1_FCH_INT_EN_SIZE;
     } mp2_gpio1_fch_int_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio1_fch_int_t f;
} mp2_gpio1_fch_int_u;


/*
 * MP2_GPIO1_IO_STATUS struct
 */

#define MP2_GPIO1_IO_STATUS_REG_SIZE   32
#define MP2_GPIO1_IO_STATUS_MP_GPIO_INPUT_GPIO1_SIZE 1
#define MP2_GPIO1_IO_STATUS_MP_GPIO_OUTPUT_GPIO1_SIZE 1

#define MP2_GPIO1_IO_STATUS_MP_GPIO_INPUT_GPIO1_SHIFT 0
#define MP2_GPIO1_IO_STATUS_MP_GPIO_OUTPUT_GPIO1_SHIFT 1

#define MP2_GPIO1_IO_STATUS_MP_GPIO_INPUT_GPIO1_MASK 0x1
#define MP2_GPIO1_IO_STATUS_MP_GPIO_OUTPUT_GPIO1_MASK 0x2

#define MP2_GPIO1_IO_STATUS_MASK \
     (MP2_GPIO1_IO_STATUS_MP_GPIO_INPUT_GPIO1_MASK | \
      MP2_GPIO1_IO_STATUS_MP_GPIO_OUTPUT_GPIO1_MASK)

#define MP2_GPIO1_IO_STATUS_DEFAULT    0x00000000

#define MP2_GPIO1_IO_STATUS_GET_MP_GPIO_INPUT_GPIO1(mp2_gpio1_io_status) \
     ((mp2_gpio1_io_status & MP2_GPIO1_IO_STATUS_MP_GPIO_INPUT_GPIO1_MASK) >> MP2_GPIO1_IO_STATUS_MP_GPIO_INPUT_GPIO1_SHIFT)
#define MP2_GPIO1_IO_STATUS_GET_MP_GPIO_OUTPUT_GPIO1(mp2_gpio1_io_status) \
     ((mp2_gpio1_io_status & MP2_GPIO1_IO_STATUS_MP_GPIO_OUTPUT_GPIO1_MASK) >> MP2_GPIO1_IO_STATUS_MP_GPIO_OUTPUT_GPIO1_SHIFT)

#define MP2_GPIO1_IO_STATUS_SET_MP_GPIO_INPUT_GPIO1(mp2_gpio1_io_status_reg, mp_gpio_input_gpio1) \
     mp2_gpio1_io_status_reg = (mp2_gpio1_io_status_reg & ~MP2_GPIO1_IO_STATUS_MP_GPIO_INPUT_GPIO1_MASK) | (mp_gpio_input_gpio1 << MP2_GPIO1_IO_STATUS_MP_GPIO_INPUT_GPIO1_SHIFT)
#define MP2_GPIO1_IO_STATUS_SET_MP_GPIO_OUTPUT_GPIO1(mp2_gpio1_io_status_reg, mp_gpio_output_gpio1) \
     mp2_gpio1_io_status_reg = (mp2_gpio1_io_status_reg & ~MP2_GPIO1_IO_STATUS_MP_GPIO_OUTPUT_GPIO1_MASK) | (mp_gpio_output_gpio1 << MP2_GPIO1_IO_STATUS_MP_GPIO_OUTPUT_GPIO1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio1_io_status_t {
          unsigned int mp_gpio_input_gpio1            : MP2_GPIO1_IO_STATUS_MP_GPIO_INPUT_GPIO1_SIZE;
          unsigned int mp_gpio_output_gpio1           : MP2_GPIO1_IO_STATUS_MP_GPIO_OUTPUT_GPIO1_SIZE;
          unsigned int                                : 30;
     } mp2_gpio1_io_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio1_io_status_t {
          unsigned int                                : 30;
          unsigned int mp_gpio_output_gpio1           : MP2_GPIO1_IO_STATUS_MP_GPIO_OUTPUT_GPIO1_SIZE;
          unsigned int mp_gpio_input_gpio1            : MP2_GPIO1_IO_STATUS_MP_GPIO_INPUT_GPIO1_SIZE;
     } mp2_gpio1_io_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio1_io_status_t f;
} mp2_gpio1_io_status_u;


/*
 * MP2_GPIO2_CTRL struct
 */

#define MP2_GPIO2_CTRL_REG_SIZE        32
#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_PD_SIZE 1
#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_PU_SIZE 1
#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_S0_SIZE 1
#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_S1_SIZE 1
#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_SCHMEN_SIZE 1
#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_OE_SIZE 1
#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_A_SIZE 1

#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_PD_SHIFT 1
#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_PU_SHIFT 2
#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_S0_SHIFT 3
#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_S1_SHIFT 4
#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_SCHMEN_SHIFT 5
#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_OE_SHIFT 6
#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_A_SHIFT 7

#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_PD_MASK 0x2
#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_PU_MASK 0x4
#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_S0_MASK 0x8
#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_S1_MASK 0x10
#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_SCHMEN_MASK 0x20
#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_OE_MASK 0x40
#define MP2_GPIO2_CTRL_MP_GPIO2_CTRL_A_MASK 0x80

#define MP2_GPIO2_CTRL_MASK \
     (MP2_GPIO2_CTRL_MP_GPIO2_CTRL_PD_MASK | \
      MP2_GPIO2_CTRL_MP_GPIO2_CTRL_PU_MASK | \
      MP2_GPIO2_CTRL_MP_GPIO2_CTRL_S0_MASK | \
      MP2_GPIO2_CTRL_MP_GPIO2_CTRL_S1_MASK | \
      MP2_GPIO2_CTRL_MP_GPIO2_CTRL_SCHMEN_MASK | \
      MP2_GPIO2_CTRL_MP_GPIO2_CTRL_OE_MASK | \
      MP2_GPIO2_CTRL_MP_GPIO2_CTRL_A_MASK)

#define MP2_GPIO2_CTRL_DEFAULT         0x00000038

#define MP2_GPIO2_CTRL_GET_MP_GPIO2_CTRL_PD(mp2_gpio2_ctrl) \
     ((mp2_gpio2_ctrl & MP2_GPIO2_CTRL_MP_GPIO2_CTRL_PD_MASK) >> MP2_GPIO2_CTRL_MP_GPIO2_CTRL_PD_SHIFT)
#define MP2_GPIO2_CTRL_GET_MP_GPIO2_CTRL_PU(mp2_gpio2_ctrl) \
     ((mp2_gpio2_ctrl & MP2_GPIO2_CTRL_MP_GPIO2_CTRL_PU_MASK) >> MP2_GPIO2_CTRL_MP_GPIO2_CTRL_PU_SHIFT)
#define MP2_GPIO2_CTRL_GET_MP_GPIO2_CTRL_S0(mp2_gpio2_ctrl) \
     ((mp2_gpio2_ctrl & MP2_GPIO2_CTRL_MP_GPIO2_CTRL_S0_MASK) >> MP2_GPIO2_CTRL_MP_GPIO2_CTRL_S0_SHIFT)
#define MP2_GPIO2_CTRL_GET_MP_GPIO2_CTRL_S1(mp2_gpio2_ctrl) \
     ((mp2_gpio2_ctrl & MP2_GPIO2_CTRL_MP_GPIO2_CTRL_S1_MASK) >> MP2_GPIO2_CTRL_MP_GPIO2_CTRL_S1_SHIFT)
#define MP2_GPIO2_CTRL_GET_MP_GPIO2_CTRL_SCHMEN(mp2_gpio2_ctrl) \
     ((mp2_gpio2_ctrl & MP2_GPIO2_CTRL_MP_GPIO2_CTRL_SCHMEN_MASK) >> MP2_GPIO2_CTRL_MP_GPIO2_CTRL_SCHMEN_SHIFT)
#define MP2_GPIO2_CTRL_GET_MP_GPIO2_CTRL_OE(mp2_gpio2_ctrl) \
     ((mp2_gpio2_ctrl & MP2_GPIO2_CTRL_MP_GPIO2_CTRL_OE_MASK) >> MP2_GPIO2_CTRL_MP_GPIO2_CTRL_OE_SHIFT)
#define MP2_GPIO2_CTRL_GET_MP_GPIO2_CTRL_A(mp2_gpio2_ctrl) \
     ((mp2_gpio2_ctrl & MP2_GPIO2_CTRL_MP_GPIO2_CTRL_A_MASK) >> MP2_GPIO2_CTRL_MP_GPIO2_CTRL_A_SHIFT)

#define MP2_GPIO2_CTRL_SET_MP_GPIO2_CTRL_PD(mp2_gpio2_ctrl_reg, mp_gpio2_ctrl_pd) \
     mp2_gpio2_ctrl_reg = (mp2_gpio2_ctrl_reg & ~MP2_GPIO2_CTRL_MP_GPIO2_CTRL_PD_MASK) | (mp_gpio2_ctrl_pd << MP2_GPIO2_CTRL_MP_GPIO2_CTRL_PD_SHIFT)
#define MP2_GPIO2_CTRL_SET_MP_GPIO2_CTRL_PU(mp2_gpio2_ctrl_reg, mp_gpio2_ctrl_pu) \
     mp2_gpio2_ctrl_reg = (mp2_gpio2_ctrl_reg & ~MP2_GPIO2_CTRL_MP_GPIO2_CTRL_PU_MASK) | (mp_gpio2_ctrl_pu << MP2_GPIO2_CTRL_MP_GPIO2_CTRL_PU_SHIFT)
#define MP2_GPIO2_CTRL_SET_MP_GPIO2_CTRL_S0(mp2_gpio2_ctrl_reg, mp_gpio2_ctrl_s0) \
     mp2_gpio2_ctrl_reg = (mp2_gpio2_ctrl_reg & ~MP2_GPIO2_CTRL_MP_GPIO2_CTRL_S0_MASK) | (mp_gpio2_ctrl_s0 << MP2_GPIO2_CTRL_MP_GPIO2_CTRL_S0_SHIFT)
#define MP2_GPIO2_CTRL_SET_MP_GPIO2_CTRL_S1(mp2_gpio2_ctrl_reg, mp_gpio2_ctrl_s1) \
     mp2_gpio2_ctrl_reg = (mp2_gpio2_ctrl_reg & ~MP2_GPIO2_CTRL_MP_GPIO2_CTRL_S1_MASK) | (mp_gpio2_ctrl_s1 << MP2_GPIO2_CTRL_MP_GPIO2_CTRL_S1_SHIFT)
#define MP2_GPIO2_CTRL_SET_MP_GPIO2_CTRL_SCHMEN(mp2_gpio2_ctrl_reg, mp_gpio2_ctrl_schmen) \
     mp2_gpio2_ctrl_reg = (mp2_gpio2_ctrl_reg & ~MP2_GPIO2_CTRL_MP_GPIO2_CTRL_SCHMEN_MASK) | (mp_gpio2_ctrl_schmen << MP2_GPIO2_CTRL_MP_GPIO2_CTRL_SCHMEN_SHIFT)
#define MP2_GPIO2_CTRL_SET_MP_GPIO2_CTRL_OE(mp2_gpio2_ctrl_reg, mp_gpio2_ctrl_oe) \
     mp2_gpio2_ctrl_reg = (mp2_gpio2_ctrl_reg & ~MP2_GPIO2_CTRL_MP_GPIO2_CTRL_OE_MASK) | (mp_gpio2_ctrl_oe << MP2_GPIO2_CTRL_MP_GPIO2_CTRL_OE_SHIFT)
#define MP2_GPIO2_CTRL_SET_MP_GPIO2_CTRL_A(mp2_gpio2_ctrl_reg, mp_gpio2_ctrl_a) \
     mp2_gpio2_ctrl_reg = (mp2_gpio2_ctrl_reg & ~MP2_GPIO2_CTRL_MP_GPIO2_CTRL_A_MASK) | (mp_gpio2_ctrl_a << MP2_GPIO2_CTRL_MP_GPIO2_CTRL_A_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio2_ctrl_t {
          unsigned int                                : 1;
          unsigned int mp_gpio2_ctrl_pd               : MP2_GPIO2_CTRL_MP_GPIO2_CTRL_PD_SIZE;
          unsigned int mp_gpio2_ctrl_pu               : MP2_GPIO2_CTRL_MP_GPIO2_CTRL_PU_SIZE;
          unsigned int mp_gpio2_ctrl_s0               : MP2_GPIO2_CTRL_MP_GPIO2_CTRL_S0_SIZE;
          unsigned int mp_gpio2_ctrl_s1               : MP2_GPIO2_CTRL_MP_GPIO2_CTRL_S1_SIZE;
          unsigned int mp_gpio2_ctrl_schmen           : MP2_GPIO2_CTRL_MP_GPIO2_CTRL_SCHMEN_SIZE;
          unsigned int mp_gpio2_ctrl_oe               : MP2_GPIO2_CTRL_MP_GPIO2_CTRL_OE_SIZE;
          unsigned int mp_gpio2_ctrl_a                : MP2_GPIO2_CTRL_MP_GPIO2_CTRL_A_SIZE;
          unsigned int                                : 24;
     } mp2_gpio2_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio2_ctrl_t {
          unsigned int                                : 24;
          unsigned int mp_gpio2_ctrl_a                : MP2_GPIO2_CTRL_MP_GPIO2_CTRL_A_SIZE;
          unsigned int mp_gpio2_ctrl_oe               : MP2_GPIO2_CTRL_MP_GPIO2_CTRL_OE_SIZE;
          unsigned int mp_gpio2_ctrl_schmen           : MP2_GPIO2_CTRL_MP_GPIO2_CTRL_SCHMEN_SIZE;
          unsigned int mp_gpio2_ctrl_s1               : MP2_GPIO2_CTRL_MP_GPIO2_CTRL_S1_SIZE;
          unsigned int mp_gpio2_ctrl_s0               : MP2_GPIO2_CTRL_MP_GPIO2_CTRL_S0_SIZE;
          unsigned int mp_gpio2_ctrl_pu               : MP2_GPIO2_CTRL_MP_GPIO2_CTRL_PU_SIZE;
          unsigned int mp_gpio2_ctrl_pd               : MP2_GPIO2_CTRL_MP_GPIO2_CTRL_PD_SIZE;
          unsigned int                                : 1;
     } mp2_gpio2_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio2_ctrl_t f;
} mp2_gpio2_ctrl_u;


/*
 * MP2_GPIO2_FCH_INT_OVERRIDE struct
 */

#define MP2_GPIO2_FCH_INT_OVERRIDE_REG_SIZE 32
#define MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_EN_SIZE 1
#define MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_OUTPUT_SIZE 1
#define MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_STAT_SIZE 1

#define MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_EN_SHIFT 0
#define MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_OUTPUT_SHIFT 1
#define MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_STAT_SHIFT 2

#define MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_EN_MASK 0x1
#define MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_OUTPUT_MASK 0x2
#define MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_STAT_MASK 0x4

#define MP2_GPIO2_FCH_INT_OVERRIDE_MASK \
     (MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_EN_MASK | \
      MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_OUTPUT_MASK | \
      MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_STAT_MASK)

#define MP2_GPIO2_FCH_INT_OVERRIDE_DEFAULT 0x00000000

#define MP2_GPIO2_FCH_INT_OVERRIDE_GET_MP_FCH_INT_OVERRIDE_GPIO2_EN(mp2_gpio2_fch_int_override) \
     ((mp2_gpio2_fch_int_override & MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_EN_MASK) >> MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_EN_SHIFT)
#define MP2_GPIO2_FCH_INT_OVERRIDE_GET_MP_FCH_INT_OVERRIDE_GPIO2_OUTPUT(mp2_gpio2_fch_int_override) \
     ((mp2_gpio2_fch_int_override & MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_OUTPUT_MASK) >> MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_OUTPUT_SHIFT)
#define MP2_GPIO2_FCH_INT_OVERRIDE_GET_MP_FCH_INT_OVERRIDE_GPIO2_STAT(mp2_gpio2_fch_int_override) \
     ((mp2_gpio2_fch_int_override & MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_STAT_MASK) >> MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_STAT_SHIFT)

#define MP2_GPIO2_FCH_INT_OVERRIDE_SET_MP_FCH_INT_OVERRIDE_GPIO2_EN(mp2_gpio2_fch_int_override_reg, mp_fch_int_override_gpio2_en) \
     mp2_gpio2_fch_int_override_reg = (mp2_gpio2_fch_int_override_reg & ~MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_EN_MASK) | (mp_fch_int_override_gpio2_en << MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_EN_SHIFT)
#define MP2_GPIO2_FCH_INT_OVERRIDE_SET_MP_FCH_INT_OVERRIDE_GPIO2_OUTPUT(mp2_gpio2_fch_int_override_reg, mp_fch_int_override_gpio2_output) \
     mp2_gpio2_fch_int_override_reg = (mp2_gpio2_fch_int_override_reg & ~MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_OUTPUT_MASK) | (mp_fch_int_override_gpio2_output << MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_OUTPUT_SHIFT)
#define MP2_GPIO2_FCH_INT_OVERRIDE_SET_MP_FCH_INT_OVERRIDE_GPIO2_STAT(mp2_gpio2_fch_int_override_reg, mp_fch_int_override_gpio2_stat) \
     mp2_gpio2_fch_int_override_reg = (mp2_gpio2_fch_int_override_reg & ~MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_STAT_MASK) | (mp_fch_int_override_gpio2_stat << MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio2_fch_int_override_t {
          unsigned int mp_fch_int_override_gpio2_en   : MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_EN_SIZE;
          unsigned int mp_fch_int_override_gpio2_output : MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_OUTPUT_SIZE;
          unsigned int mp_fch_int_override_gpio2_stat : MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_gpio2_fch_int_override_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio2_fch_int_override_t {
          unsigned int                                : 29;
          unsigned int mp_fch_int_override_gpio2_stat : MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_STAT_SIZE;
          unsigned int mp_fch_int_override_gpio2_output : MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_OUTPUT_SIZE;
          unsigned int mp_fch_int_override_gpio2_en   : MP2_GPIO2_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO2_EN_SIZE;
     } mp2_gpio2_fch_int_override_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio2_fch_int_override_t f;
} mp2_gpio2_fch_int_override_u;


/*
 * MP2_GPIO2_MP_INT struct
 */

#define MP2_GPIO2_MP_INT_REG_SIZE      32
#define MP2_GPIO2_MP_INT_MP2_GPIO2_MP_INT_EN_SIZE 2
#define MP2_GPIO2_MP_INT_MP2_GPIO2_MP_INT_STAT_SIZE 1

#define MP2_GPIO2_MP_INT_MP2_GPIO2_MP_INT_EN_SHIFT 0
#define MP2_GPIO2_MP_INT_MP2_GPIO2_MP_INT_STAT_SHIFT 2

#define MP2_GPIO2_MP_INT_MP2_GPIO2_MP_INT_EN_MASK 0x3
#define MP2_GPIO2_MP_INT_MP2_GPIO2_MP_INT_STAT_MASK 0x4

#define MP2_GPIO2_MP_INT_MASK \
     (MP2_GPIO2_MP_INT_MP2_GPIO2_MP_INT_EN_MASK | \
      MP2_GPIO2_MP_INT_MP2_GPIO2_MP_INT_STAT_MASK)

#define MP2_GPIO2_MP_INT_DEFAULT       0x00000000

#define MP2_GPIO2_MP_INT_GET_MP2_GPIO2_MP_INT_EN(mp2_gpio2_mp_int) \
     ((mp2_gpio2_mp_int & MP2_GPIO2_MP_INT_MP2_GPIO2_MP_INT_EN_MASK) >> MP2_GPIO2_MP_INT_MP2_GPIO2_MP_INT_EN_SHIFT)
#define MP2_GPIO2_MP_INT_GET_MP2_GPIO2_MP_INT_STAT(mp2_gpio2_mp_int) \
     ((mp2_gpio2_mp_int & MP2_GPIO2_MP_INT_MP2_GPIO2_MP_INT_STAT_MASK) >> MP2_GPIO2_MP_INT_MP2_GPIO2_MP_INT_STAT_SHIFT)

#define MP2_GPIO2_MP_INT_SET_MP2_GPIO2_MP_INT_EN(mp2_gpio2_mp_int_reg, mp2_gpio2_mp_int_en) \
     mp2_gpio2_mp_int_reg = (mp2_gpio2_mp_int_reg & ~MP2_GPIO2_MP_INT_MP2_GPIO2_MP_INT_EN_MASK) | (mp2_gpio2_mp_int_en << MP2_GPIO2_MP_INT_MP2_GPIO2_MP_INT_EN_SHIFT)
#define MP2_GPIO2_MP_INT_SET_MP2_GPIO2_MP_INT_STAT(mp2_gpio2_mp_int_reg, mp2_gpio2_mp_int_stat) \
     mp2_gpio2_mp_int_reg = (mp2_gpio2_mp_int_reg & ~MP2_GPIO2_MP_INT_MP2_GPIO2_MP_INT_STAT_MASK) | (mp2_gpio2_mp_int_stat << MP2_GPIO2_MP_INT_MP2_GPIO2_MP_INT_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio2_mp_int_t {
          unsigned int mp2_gpio2_mp_int_en            : MP2_GPIO2_MP_INT_MP2_GPIO2_MP_INT_EN_SIZE;
          unsigned int mp2_gpio2_mp_int_stat          : MP2_GPIO2_MP_INT_MP2_GPIO2_MP_INT_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_gpio2_mp_int_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio2_mp_int_t {
          unsigned int                                : 29;
          unsigned int mp2_gpio2_mp_int_stat          : MP2_GPIO2_MP_INT_MP2_GPIO2_MP_INT_STAT_SIZE;
          unsigned int mp2_gpio2_mp_int_en            : MP2_GPIO2_MP_INT_MP2_GPIO2_MP_INT_EN_SIZE;
     } mp2_gpio2_mp_int_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio2_mp_int_t f;
} mp2_gpio2_mp_int_u;


/*
 * MP2_GPIO2_FCH_INT struct
 */

#define MP2_GPIO2_FCH_INT_REG_SIZE     32
#define MP2_GPIO2_FCH_INT_MP2_GPIO2_FCH_INT_EN_SIZE 2
#define MP2_GPIO2_FCH_INT_MP2_GPIO2_FCH_INT_STAT_SIZE 1

#define MP2_GPIO2_FCH_INT_MP2_GPIO2_FCH_INT_EN_SHIFT 0
#define MP2_GPIO2_FCH_INT_MP2_GPIO2_FCH_INT_STAT_SHIFT 2

#define MP2_GPIO2_FCH_INT_MP2_GPIO2_FCH_INT_EN_MASK 0x3
#define MP2_GPIO2_FCH_INT_MP2_GPIO2_FCH_INT_STAT_MASK 0x4

#define MP2_GPIO2_FCH_INT_MASK \
     (MP2_GPIO2_FCH_INT_MP2_GPIO2_FCH_INT_EN_MASK | \
      MP2_GPIO2_FCH_INT_MP2_GPIO2_FCH_INT_STAT_MASK)

#define MP2_GPIO2_FCH_INT_DEFAULT      0x00000000

#define MP2_GPIO2_FCH_INT_GET_MP2_GPIO2_FCH_INT_EN(mp2_gpio2_fch_int) \
     ((mp2_gpio2_fch_int & MP2_GPIO2_FCH_INT_MP2_GPIO2_FCH_INT_EN_MASK) >> MP2_GPIO2_FCH_INT_MP2_GPIO2_FCH_INT_EN_SHIFT)
#define MP2_GPIO2_FCH_INT_GET_MP2_GPIO2_FCH_INT_STAT(mp2_gpio2_fch_int) \
     ((mp2_gpio2_fch_int & MP2_GPIO2_FCH_INT_MP2_GPIO2_FCH_INT_STAT_MASK) >> MP2_GPIO2_FCH_INT_MP2_GPIO2_FCH_INT_STAT_SHIFT)

#define MP2_GPIO2_FCH_INT_SET_MP2_GPIO2_FCH_INT_EN(mp2_gpio2_fch_int_reg, mp2_gpio2_fch_int_en) \
     mp2_gpio2_fch_int_reg = (mp2_gpio2_fch_int_reg & ~MP2_GPIO2_FCH_INT_MP2_GPIO2_FCH_INT_EN_MASK) | (mp2_gpio2_fch_int_en << MP2_GPIO2_FCH_INT_MP2_GPIO2_FCH_INT_EN_SHIFT)
#define MP2_GPIO2_FCH_INT_SET_MP2_GPIO2_FCH_INT_STAT(mp2_gpio2_fch_int_reg, mp2_gpio2_fch_int_stat) \
     mp2_gpio2_fch_int_reg = (mp2_gpio2_fch_int_reg & ~MP2_GPIO2_FCH_INT_MP2_GPIO2_FCH_INT_STAT_MASK) | (mp2_gpio2_fch_int_stat << MP2_GPIO2_FCH_INT_MP2_GPIO2_FCH_INT_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio2_fch_int_t {
          unsigned int mp2_gpio2_fch_int_en           : MP2_GPIO2_FCH_INT_MP2_GPIO2_FCH_INT_EN_SIZE;
          unsigned int mp2_gpio2_fch_int_stat         : MP2_GPIO2_FCH_INT_MP2_GPIO2_FCH_INT_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_gpio2_fch_int_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio2_fch_int_t {
          unsigned int                                : 29;
          unsigned int mp2_gpio2_fch_int_stat         : MP2_GPIO2_FCH_INT_MP2_GPIO2_FCH_INT_STAT_SIZE;
          unsigned int mp2_gpio2_fch_int_en           : MP2_GPIO2_FCH_INT_MP2_GPIO2_FCH_INT_EN_SIZE;
     } mp2_gpio2_fch_int_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio2_fch_int_t f;
} mp2_gpio2_fch_int_u;


/*
 * MP2_GPIO2_IO_STATUS struct
 */

#define MP2_GPIO2_IO_STATUS_REG_SIZE   32
#define MP2_GPIO2_IO_STATUS_MP_GPIO_INPUT_GPIO2_SIZE 1
#define MP2_GPIO2_IO_STATUS_MP_GPIO_OUTPUT_GPIO2_SIZE 1

#define MP2_GPIO2_IO_STATUS_MP_GPIO_INPUT_GPIO2_SHIFT 0
#define MP2_GPIO2_IO_STATUS_MP_GPIO_OUTPUT_GPIO2_SHIFT 1

#define MP2_GPIO2_IO_STATUS_MP_GPIO_INPUT_GPIO2_MASK 0x1
#define MP2_GPIO2_IO_STATUS_MP_GPIO_OUTPUT_GPIO2_MASK 0x2

#define MP2_GPIO2_IO_STATUS_MASK \
     (MP2_GPIO2_IO_STATUS_MP_GPIO_INPUT_GPIO2_MASK | \
      MP2_GPIO2_IO_STATUS_MP_GPIO_OUTPUT_GPIO2_MASK)

#define MP2_GPIO2_IO_STATUS_DEFAULT    0x00000000

#define MP2_GPIO2_IO_STATUS_GET_MP_GPIO_INPUT_GPIO2(mp2_gpio2_io_status) \
     ((mp2_gpio2_io_status & MP2_GPIO2_IO_STATUS_MP_GPIO_INPUT_GPIO2_MASK) >> MP2_GPIO2_IO_STATUS_MP_GPIO_INPUT_GPIO2_SHIFT)
#define MP2_GPIO2_IO_STATUS_GET_MP_GPIO_OUTPUT_GPIO2(mp2_gpio2_io_status) \
     ((mp2_gpio2_io_status & MP2_GPIO2_IO_STATUS_MP_GPIO_OUTPUT_GPIO2_MASK) >> MP2_GPIO2_IO_STATUS_MP_GPIO_OUTPUT_GPIO2_SHIFT)

#define MP2_GPIO2_IO_STATUS_SET_MP_GPIO_INPUT_GPIO2(mp2_gpio2_io_status_reg, mp_gpio_input_gpio2) \
     mp2_gpio2_io_status_reg = (mp2_gpio2_io_status_reg & ~MP2_GPIO2_IO_STATUS_MP_GPIO_INPUT_GPIO2_MASK) | (mp_gpio_input_gpio2 << MP2_GPIO2_IO_STATUS_MP_GPIO_INPUT_GPIO2_SHIFT)
#define MP2_GPIO2_IO_STATUS_SET_MP_GPIO_OUTPUT_GPIO2(mp2_gpio2_io_status_reg, mp_gpio_output_gpio2) \
     mp2_gpio2_io_status_reg = (mp2_gpio2_io_status_reg & ~MP2_GPIO2_IO_STATUS_MP_GPIO_OUTPUT_GPIO2_MASK) | (mp_gpio_output_gpio2 << MP2_GPIO2_IO_STATUS_MP_GPIO_OUTPUT_GPIO2_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio2_io_status_t {
          unsigned int mp_gpio_input_gpio2            : MP2_GPIO2_IO_STATUS_MP_GPIO_INPUT_GPIO2_SIZE;
          unsigned int mp_gpio_output_gpio2           : MP2_GPIO2_IO_STATUS_MP_GPIO_OUTPUT_GPIO2_SIZE;
          unsigned int                                : 30;
     } mp2_gpio2_io_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio2_io_status_t {
          unsigned int                                : 30;
          unsigned int mp_gpio_output_gpio2           : MP2_GPIO2_IO_STATUS_MP_GPIO_OUTPUT_GPIO2_SIZE;
          unsigned int mp_gpio_input_gpio2            : MP2_GPIO2_IO_STATUS_MP_GPIO_INPUT_GPIO2_SIZE;
     } mp2_gpio2_io_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio2_io_status_t f;
} mp2_gpio2_io_status_u;


/*
 * MP2_GPIO3_CTRL struct
 */

#define MP2_GPIO3_CTRL_REG_SIZE        32
#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_PD_SIZE 1
#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_PU_SIZE 1
#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_S0_SIZE 1
#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_S1_SIZE 1
#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_SCHMEN_SIZE 1
#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_OE_SIZE 1
#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_A_SIZE 1

#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_PD_SHIFT 1
#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_PU_SHIFT 2
#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_S0_SHIFT 3
#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_S1_SHIFT 4
#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_SCHMEN_SHIFT 5
#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_OE_SHIFT 6
#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_A_SHIFT 7

#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_PD_MASK 0x2
#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_PU_MASK 0x4
#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_S0_MASK 0x8
#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_S1_MASK 0x10
#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_SCHMEN_MASK 0x20
#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_OE_MASK 0x40
#define MP2_GPIO3_CTRL_MP_GPIO3_CTRL_A_MASK 0x80

#define MP2_GPIO3_CTRL_MASK \
     (MP2_GPIO3_CTRL_MP_GPIO3_CTRL_PD_MASK | \
      MP2_GPIO3_CTRL_MP_GPIO3_CTRL_PU_MASK | \
      MP2_GPIO3_CTRL_MP_GPIO3_CTRL_S0_MASK | \
      MP2_GPIO3_CTRL_MP_GPIO3_CTRL_S1_MASK | \
      MP2_GPIO3_CTRL_MP_GPIO3_CTRL_SCHMEN_MASK | \
      MP2_GPIO3_CTRL_MP_GPIO3_CTRL_OE_MASK | \
      MP2_GPIO3_CTRL_MP_GPIO3_CTRL_A_MASK)

#define MP2_GPIO3_CTRL_DEFAULT         0x00000038

#define MP2_GPIO3_CTRL_GET_MP_GPIO3_CTRL_PD(mp2_gpio3_ctrl) \
     ((mp2_gpio3_ctrl & MP2_GPIO3_CTRL_MP_GPIO3_CTRL_PD_MASK) >> MP2_GPIO3_CTRL_MP_GPIO3_CTRL_PD_SHIFT)
#define MP2_GPIO3_CTRL_GET_MP_GPIO3_CTRL_PU(mp2_gpio3_ctrl) \
     ((mp2_gpio3_ctrl & MP2_GPIO3_CTRL_MP_GPIO3_CTRL_PU_MASK) >> MP2_GPIO3_CTRL_MP_GPIO3_CTRL_PU_SHIFT)
#define MP2_GPIO3_CTRL_GET_MP_GPIO3_CTRL_S0(mp2_gpio3_ctrl) \
     ((mp2_gpio3_ctrl & MP2_GPIO3_CTRL_MP_GPIO3_CTRL_S0_MASK) >> MP2_GPIO3_CTRL_MP_GPIO3_CTRL_S0_SHIFT)
#define MP2_GPIO3_CTRL_GET_MP_GPIO3_CTRL_S1(mp2_gpio3_ctrl) \
     ((mp2_gpio3_ctrl & MP2_GPIO3_CTRL_MP_GPIO3_CTRL_S1_MASK) >> MP2_GPIO3_CTRL_MP_GPIO3_CTRL_S1_SHIFT)
#define MP2_GPIO3_CTRL_GET_MP_GPIO3_CTRL_SCHMEN(mp2_gpio3_ctrl) \
     ((mp2_gpio3_ctrl & MP2_GPIO3_CTRL_MP_GPIO3_CTRL_SCHMEN_MASK) >> MP2_GPIO3_CTRL_MP_GPIO3_CTRL_SCHMEN_SHIFT)
#define MP2_GPIO3_CTRL_GET_MP_GPIO3_CTRL_OE(mp2_gpio3_ctrl) \
     ((mp2_gpio3_ctrl & MP2_GPIO3_CTRL_MP_GPIO3_CTRL_OE_MASK) >> MP2_GPIO3_CTRL_MP_GPIO3_CTRL_OE_SHIFT)
#define MP2_GPIO3_CTRL_GET_MP_GPIO3_CTRL_A(mp2_gpio3_ctrl) \
     ((mp2_gpio3_ctrl & MP2_GPIO3_CTRL_MP_GPIO3_CTRL_A_MASK) >> MP2_GPIO3_CTRL_MP_GPIO3_CTRL_A_SHIFT)

#define MP2_GPIO3_CTRL_SET_MP_GPIO3_CTRL_PD(mp2_gpio3_ctrl_reg, mp_gpio3_ctrl_pd) \
     mp2_gpio3_ctrl_reg = (mp2_gpio3_ctrl_reg & ~MP2_GPIO3_CTRL_MP_GPIO3_CTRL_PD_MASK) | (mp_gpio3_ctrl_pd << MP2_GPIO3_CTRL_MP_GPIO3_CTRL_PD_SHIFT)
#define MP2_GPIO3_CTRL_SET_MP_GPIO3_CTRL_PU(mp2_gpio3_ctrl_reg, mp_gpio3_ctrl_pu) \
     mp2_gpio3_ctrl_reg = (mp2_gpio3_ctrl_reg & ~MP2_GPIO3_CTRL_MP_GPIO3_CTRL_PU_MASK) | (mp_gpio3_ctrl_pu << MP2_GPIO3_CTRL_MP_GPIO3_CTRL_PU_SHIFT)
#define MP2_GPIO3_CTRL_SET_MP_GPIO3_CTRL_S0(mp2_gpio3_ctrl_reg, mp_gpio3_ctrl_s0) \
     mp2_gpio3_ctrl_reg = (mp2_gpio3_ctrl_reg & ~MP2_GPIO3_CTRL_MP_GPIO3_CTRL_S0_MASK) | (mp_gpio3_ctrl_s0 << MP2_GPIO3_CTRL_MP_GPIO3_CTRL_S0_SHIFT)
#define MP2_GPIO3_CTRL_SET_MP_GPIO3_CTRL_S1(mp2_gpio3_ctrl_reg, mp_gpio3_ctrl_s1) \
     mp2_gpio3_ctrl_reg = (mp2_gpio3_ctrl_reg & ~MP2_GPIO3_CTRL_MP_GPIO3_CTRL_S1_MASK) | (mp_gpio3_ctrl_s1 << MP2_GPIO3_CTRL_MP_GPIO3_CTRL_S1_SHIFT)
#define MP2_GPIO3_CTRL_SET_MP_GPIO3_CTRL_SCHMEN(mp2_gpio3_ctrl_reg, mp_gpio3_ctrl_schmen) \
     mp2_gpio3_ctrl_reg = (mp2_gpio3_ctrl_reg & ~MP2_GPIO3_CTRL_MP_GPIO3_CTRL_SCHMEN_MASK) | (mp_gpio3_ctrl_schmen << MP2_GPIO3_CTRL_MP_GPIO3_CTRL_SCHMEN_SHIFT)
#define MP2_GPIO3_CTRL_SET_MP_GPIO3_CTRL_OE(mp2_gpio3_ctrl_reg, mp_gpio3_ctrl_oe) \
     mp2_gpio3_ctrl_reg = (mp2_gpio3_ctrl_reg & ~MP2_GPIO3_CTRL_MP_GPIO3_CTRL_OE_MASK) | (mp_gpio3_ctrl_oe << MP2_GPIO3_CTRL_MP_GPIO3_CTRL_OE_SHIFT)
#define MP2_GPIO3_CTRL_SET_MP_GPIO3_CTRL_A(mp2_gpio3_ctrl_reg, mp_gpio3_ctrl_a) \
     mp2_gpio3_ctrl_reg = (mp2_gpio3_ctrl_reg & ~MP2_GPIO3_CTRL_MP_GPIO3_CTRL_A_MASK) | (mp_gpio3_ctrl_a << MP2_GPIO3_CTRL_MP_GPIO3_CTRL_A_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio3_ctrl_t {
          unsigned int                                : 1;
          unsigned int mp_gpio3_ctrl_pd               : MP2_GPIO3_CTRL_MP_GPIO3_CTRL_PD_SIZE;
          unsigned int mp_gpio3_ctrl_pu               : MP2_GPIO3_CTRL_MP_GPIO3_CTRL_PU_SIZE;
          unsigned int mp_gpio3_ctrl_s0               : MP2_GPIO3_CTRL_MP_GPIO3_CTRL_S0_SIZE;
          unsigned int mp_gpio3_ctrl_s1               : MP2_GPIO3_CTRL_MP_GPIO3_CTRL_S1_SIZE;
          unsigned int mp_gpio3_ctrl_schmen           : MP2_GPIO3_CTRL_MP_GPIO3_CTRL_SCHMEN_SIZE;
          unsigned int mp_gpio3_ctrl_oe               : MP2_GPIO3_CTRL_MP_GPIO3_CTRL_OE_SIZE;
          unsigned int mp_gpio3_ctrl_a                : MP2_GPIO3_CTRL_MP_GPIO3_CTRL_A_SIZE;
          unsigned int                                : 24;
     } mp2_gpio3_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio3_ctrl_t {
          unsigned int                                : 24;
          unsigned int mp_gpio3_ctrl_a                : MP2_GPIO3_CTRL_MP_GPIO3_CTRL_A_SIZE;
          unsigned int mp_gpio3_ctrl_oe               : MP2_GPIO3_CTRL_MP_GPIO3_CTRL_OE_SIZE;
          unsigned int mp_gpio3_ctrl_schmen           : MP2_GPIO3_CTRL_MP_GPIO3_CTRL_SCHMEN_SIZE;
          unsigned int mp_gpio3_ctrl_s1               : MP2_GPIO3_CTRL_MP_GPIO3_CTRL_S1_SIZE;
          unsigned int mp_gpio3_ctrl_s0               : MP2_GPIO3_CTRL_MP_GPIO3_CTRL_S0_SIZE;
          unsigned int mp_gpio3_ctrl_pu               : MP2_GPIO3_CTRL_MP_GPIO3_CTRL_PU_SIZE;
          unsigned int mp_gpio3_ctrl_pd               : MP2_GPIO3_CTRL_MP_GPIO3_CTRL_PD_SIZE;
          unsigned int                                : 1;
     } mp2_gpio3_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio3_ctrl_t f;
} mp2_gpio3_ctrl_u;


/*
 * MP2_GPIO3_FCH_INT_OVERRIDE struct
 */

#define MP2_GPIO3_FCH_INT_OVERRIDE_REG_SIZE 32
#define MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_EN_SIZE 1
#define MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_OUTPUT_SIZE 1
#define MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_STAT_SIZE 1

#define MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_EN_SHIFT 0
#define MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_OUTPUT_SHIFT 1
#define MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_STAT_SHIFT 2

#define MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_EN_MASK 0x1
#define MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_OUTPUT_MASK 0x2
#define MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_STAT_MASK 0x4

#define MP2_GPIO3_FCH_INT_OVERRIDE_MASK \
     (MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_EN_MASK | \
      MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_OUTPUT_MASK | \
      MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_STAT_MASK)

#define MP2_GPIO3_FCH_INT_OVERRIDE_DEFAULT 0x00000000

#define MP2_GPIO3_FCH_INT_OVERRIDE_GET_MP_FCH_INT_OVERRIDE_GPIO3_EN(mp2_gpio3_fch_int_override) \
     ((mp2_gpio3_fch_int_override & MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_EN_MASK) >> MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_EN_SHIFT)
#define MP2_GPIO3_FCH_INT_OVERRIDE_GET_MP_FCH_INT_OVERRIDE_GPIO3_OUTPUT(mp2_gpio3_fch_int_override) \
     ((mp2_gpio3_fch_int_override & MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_OUTPUT_MASK) >> MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_OUTPUT_SHIFT)
#define MP2_GPIO3_FCH_INT_OVERRIDE_GET_MP_FCH_INT_OVERRIDE_GPIO3_STAT(mp2_gpio3_fch_int_override) \
     ((mp2_gpio3_fch_int_override & MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_STAT_MASK) >> MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_STAT_SHIFT)

#define MP2_GPIO3_FCH_INT_OVERRIDE_SET_MP_FCH_INT_OVERRIDE_GPIO3_EN(mp2_gpio3_fch_int_override_reg, mp_fch_int_override_gpio3_en) \
     mp2_gpio3_fch_int_override_reg = (mp2_gpio3_fch_int_override_reg & ~MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_EN_MASK) | (mp_fch_int_override_gpio3_en << MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_EN_SHIFT)
#define MP2_GPIO3_FCH_INT_OVERRIDE_SET_MP_FCH_INT_OVERRIDE_GPIO3_OUTPUT(mp2_gpio3_fch_int_override_reg, mp_fch_int_override_gpio3_output) \
     mp2_gpio3_fch_int_override_reg = (mp2_gpio3_fch_int_override_reg & ~MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_OUTPUT_MASK) | (mp_fch_int_override_gpio3_output << MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_OUTPUT_SHIFT)
#define MP2_GPIO3_FCH_INT_OVERRIDE_SET_MP_FCH_INT_OVERRIDE_GPIO3_STAT(mp2_gpio3_fch_int_override_reg, mp_fch_int_override_gpio3_stat) \
     mp2_gpio3_fch_int_override_reg = (mp2_gpio3_fch_int_override_reg & ~MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_STAT_MASK) | (mp_fch_int_override_gpio3_stat << MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio3_fch_int_override_t {
          unsigned int mp_fch_int_override_gpio3_en   : MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_EN_SIZE;
          unsigned int mp_fch_int_override_gpio3_output : MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_OUTPUT_SIZE;
          unsigned int mp_fch_int_override_gpio3_stat : MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_gpio3_fch_int_override_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio3_fch_int_override_t {
          unsigned int                                : 29;
          unsigned int mp_fch_int_override_gpio3_stat : MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_STAT_SIZE;
          unsigned int mp_fch_int_override_gpio3_output : MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_OUTPUT_SIZE;
          unsigned int mp_fch_int_override_gpio3_en   : MP2_GPIO3_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO3_EN_SIZE;
     } mp2_gpio3_fch_int_override_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio3_fch_int_override_t f;
} mp2_gpio3_fch_int_override_u;


/*
 * MP2_GPIO3_MP_INT struct
 */

#define MP2_GPIO3_MP_INT_REG_SIZE      32
#define MP2_GPIO3_MP_INT_MP2_GPIO3_MP_INT_EN_SIZE 2
#define MP2_GPIO3_MP_INT_MP2_GPIO3_MP_INT_STAT_SIZE 1

#define MP2_GPIO3_MP_INT_MP2_GPIO3_MP_INT_EN_SHIFT 0
#define MP2_GPIO3_MP_INT_MP2_GPIO3_MP_INT_STAT_SHIFT 2

#define MP2_GPIO3_MP_INT_MP2_GPIO3_MP_INT_EN_MASK 0x3
#define MP2_GPIO3_MP_INT_MP2_GPIO3_MP_INT_STAT_MASK 0x4

#define MP2_GPIO3_MP_INT_MASK \
     (MP2_GPIO3_MP_INT_MP2_GPIO3_MP_INT_EN_MASK | \
      MP2_GPIO3_MP_INT_MP2_GPIO3_MP_INT_STAT_MASK)

#define MP2_GPIO3_MP_INT_DEFAULT       0x00000000

#define MP2_GPIO3_MP_INT_GET_MP2_GPIO3_MP_INT_EN(mp2_gpio3_mp_int) \
     ((mp2_gpio3_mp_int & MP2_GPIO3_MP_INT_MP2_GPIO3_MP_INT_EN_MASK) >> MP2_GPIO3_MP_INT_MP2_GPIO3_MP_INT_EN_SHIFT)
#define MP2_GPIO3_MP_INT_GET_MP2_GPIO3_MP_INT_STAT(mp2_gpio3_mp_int) \
     ((mp2_gpio3_mp_int & MP2_GPIO3_MP_INT_MP2_GPIO3_MP_INT_STAT_MASK) >> MP2_GPIO3_MP_INT_MP2_GPIO3_MP_INT_STAT_SHIFT)

#define MP2_GPIO3_MP_INT_SET_MP2_GPIO3_MP_INT_EN(mp2_gpio3_mp_int_reg, mp2_gpio3_mp_int_en) \
     mp2_gpio3_mp_int_reg = (mp2_gpio3_mp_int_reg & ~MP2_GPIO3_MP_INT_MP2_GPIO3_MP_INT_EN_MASK) | (mp2_gpio3_mp_int_en << MP2_GPIO3_MP_INT_MP2_GPIO3_MP_INT_EN_SHIFT)
#define MP2_GPIO3_MP_INT_SET_MP2_GPIO3_MP_INT_STAT(mp2_gpio3_mp_int_reg, mp2_gpio3_mp_int_stat) \
     mp2_gpio3_mp_int_reg = (mp2_gpio3_mp_int_reg & ~MP2_GPIO3_MP_INT_MP2_GPIO3_MP_INT_STAT_MASK) | (mp2_gpio3_mp_int_stat << MP2_GPIO3_MP_INT_MP2_GPIO3_MP_INT_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio3_mp_int_t {
          unsigned int mp2_gpio3_mp_int_en            : MP2_GPIO3_MP_INT_MP2_GPIO3_MP_INT_EN_SIZE;
          unsigned int mp2_gpio3_mp_int_stat          : MP2_GPIO3_MP_INT_MP2_GPIO3_MP_INT_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_gpio3_mp_int_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio3_mp_int_t {
          unsigned int                                : 29;
          unsigned int mp2_gpio3_mp_int_stat          : MP2_GPIO3_MP_INT_MP2_GPIO3_MP_INT_STAT_SIZE;
          unsigned int mp2_gpio3_mp_int_en            : MP2_GPIO3_MP_INT_MP2_GPIO3_MP_INT_EN_SIZE;
     } mp2_gpio3_mp_int_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio3_mp_int_t f;
} mp2_gpio3_mp_int_u;


/*
 * MP2_GPIO3_FCH_INT struct
 */

#define MP2_GPIO3_FCH_INT_REG_SIZE     32
#define MP2_GPIO3_FCH_INT_MP2_GPIO3_FCH_INT_EN_SIZE 2
#define MP2_GPIO3_FCH_INT_MP2_GPIO3_FCH_INT_STAT_SIZE 1

#define MP2_GPIO3_FCH_INT_MP2_GPIO3_FCH_INT_EN_SHIFT 0
#define MP2_GPIO3_FCH_INT_MP2_GPIO3_FCH_INT_STAT_SHIFT 2

#define MP2_GPIO3_FCH_INT_MP2_GPIO3_FCH_INT_EN_MASK 0x3
#define MP2_GPIO3_FCH_INT_MP2_GPIO3_FCH_INT_STAT_MASK 0x4

#define MP2_GPIO3_FCH_INT_MASK \
     (MP2_GPIO3_FCH_INT_MP2_GPIO3_FCH_INT_EN_MASK | \
      MP2_GPIO3_FCH_INT_MP2_GPIO3_FCH_INT_STAT_MASK)

#define MP2_GPIO3_FCH_INT_DEFAULT      0x00000000

#define MP2_GPIO3_FCH_INT_GET_MP2_GPIO3_FCH_INT_EN(mp2_gpio3_fch_int) \
     ((mp2_gpio3_fch_int & MP2_GPIO3_FCH_INT_MP2_GPIO3_FCH_INT_EN_MASK) >> MP2_GPIO3_FCH_INT_MP2_GPIO3_FCH_INT_EN_SHIFT)
#define MP2_GPIO3_FCH_INT_GET_MP2_GPIO3_FCH_INT_STAT(mp2_gpio3_fch_int) \
     ((mp2_gpio3_fch_int & MP2_GPIO3_FCH_INT_MP2_GPIO3_FCH_INT_STAT_MASK) >> MP2_GPIO3_FCH_INT_MP2_GPIO3_FCH_INT_STAT_SHIFT)

#define MP2_GPIO3_FCH_INT_SET_MP2_GPIO3_FCH_INT_EN(mp2_gpio3_fch_int_reg, mp2_gpio3_fch_int_en) \
     mp2_gpio3_fch_int_reg = (mp2_gpio3_fch_int_reg & ~MP2_GPIO3_FCH_INT_MP2_GPIO3_FCH_INT_EN_MASK) | (mp2_gpio3_fch_int_en << MP2_GPIO3_FCH_INT_MP2_GPIO3_FCH_INT_EN_SHIFT)
#define MP2_GPIO3_FCH_INT_SET_MP2_GPIO3_FCH_INT_STAT(mp2_gpio3_fch_int_reg, mp2_gpio3_fch_int_stat) \
     mp2_gpio3_fch_int_reg = (mp2_gpio3_fch_int_reg & ~MP2_GPIO3_FCH_INT_MP2_GPIO3_FCH_INT_STAT_MASK) | (mp2_gpio3_fch_int_stat << MP2_GPIO3_FCH_INT_MP2_GPIO3_FCH_INT_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio3_fch_int_t {
          unsigned int mp2_gpio3_fch_int_en           : MP2_GPIO3_FCH_INT_MP2_GPIO3_FCH_INT_EN_SIZE;
          unsigned int mp2_gpio3_fch_int_stat         : MP2_GPIO3_FCH_INT_MP2_GPIO3_FCH_INT_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_gpio3_fch_int_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio3_fch_int_t {
          unsigned int                                : 29;
          unsigned int mp2_gpio3_fch_int_stat         : MP2_GPIO3_FCH_INT_MP2_GPIO3_FCH_INT_STAT_SIZE;
          unsigned int mp2_gpio3_fch_int_en           : MP2_GPIO3_FCH_INT_MP2_GPIO3_FCH_INT_EN_SIZE;
     } mp2_gpio3_fch_int_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio3_fch_int_t f;
} mp2_gpio3_fch_int_u;


/*
 * MP2_GPIO3_IO_STATUS struct
 */

#define MP2_GPIO3_IO_STATUS_REG_SIZE   32
#define MP2_GPIO3_IO_STATUS_MP_GPIO_INPUT_GPIO3_SIZE 1
#define MP2_GPIO3_IO_STATUS_MP_GPIO_OUTPUT_GPIO3_SIZE 1

#define MP2_GPIO3_IO_STATUS_MP_GPIO_INPUT_GPIO3_SHIFT 0
#define MP2_GPIO3_IO_STATUS_MP_GPIO_OUTPUT_GPIO3_SHIFT 1

#define MP2_GPIO3_IO_STATUS_MP_GPIO_INPUT_GPIO3_MASK 0x1
#define MP2_GPIO3_IO_STATUS_MP_GPIO_OUTPUT_GPIO3_MASK 0x2

#define MP2_GPIO3_IO_STATUS_MASK \
     (MP2_GPIO3_IO_STATUS_MP_GPIO_INPUT_GPIO3_MASK | \
      MP2_GPIO3_IO_STATUS_MP_GPIO_OUTPUT_GPIO3_MASK)

#define MP2_GPIO3_IO_STATUS_DEFAULT    0x00000000

#define MP2_GPIO3_IO_STATUS_GET_MP_GPIO_INPUT_GPIO3(mp2_gpio3_io_status) \
     ((mp2_gpio3_io_status & MP2_GPIO3_IO_STATUS_MP_GPIO_INPUT_GPIO3_MASK) >> MP2_GPIO3_IO_STATUS_MP_GPIO_INPUT_GPIO3_SHIFT)
#define MP2_GPIO3_IO_STATUS_GET_MP_GPIO_OUTPUT_GPIO3(mp2_gpio3_io_status) \
     ((mp2_gpio3_io_status & MP2_GPIO3_IO_STATUS_MP_GPIO_OUTPUT_GPIO3_MASK) >> MP2_GPIO3_IO_STATUS_MP_GPIO_OUTPUT_GPIO3_SHIFT)

#define MP2_GPIO3_IO_STATUS_SET_MP_GPIO_INPUT_GPIO3(mp2_gpio3_io_status_reg, mp_gpio_input_gpio3) \
     mp2_gpio3_io_status_reg = (mp2_gpio3_io_status_reg & ~MP2_GPIO3_IO_STATUS_MP_GPIO_INPUT_GPIO3_MASK) | (mp_gpio_input_gpio3 << MP2_GPIO3_IO_STATUS_MP_GPIO_INPUT_GPIO3_SHIFT)
#define MP2_GPIO3_IO_STATUS_SET_MP_GPIO_OUTPUT_GPIO3(mp2_gpio3_io_status_reg, mp_gpio_output_gpio3) \
     mp2_gpio3_io_status_reg = (mp2_gpio3_io_status_reg & ~MP2_GPIO3_IO_STATUS_MP_GPIO_OUTPUT_GPIO3_MASK) | (mp_gpio_output_gpio3 << MP2_GPIO3_IO_STATUS_MP_GPIO_OUTPUT_GPIO3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio3_io_status_t {
          unsigned int mp_gpio_input_gpio3            : MP2_GPIO3_IO_STATUS_MP_GPIO_INPUT_GPIO3_SIZE;
          unsigned int mp_gpio_output_gpio3           : MP2_GPIO3_IO_STATUS_MP_GPIO_OUTPUT_GPIO3_SIZE;
          unsigned int                                : 30;
     } mp2_gpio3_io_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio3_io_status_t {
          unsigned int                                : 30;
          unsigned int mp_gpio_output_gpio3           : MP2_GPIO3_IO_STATUS_MP_GPIO_OUTPUT_GPIO3_SIZE;
          unsigned int mp_gpio_input_gpio3            : MP2_GPIO3_IO_STATUS_MP_GPIO_INPUT_GPIO3_SIZE;
     } mp2_gpio3_io_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio3_io_status_t f;
} mp2_gpio3_io_status_u;


/*
 * MP2_GPIO4_CTRL struct
 */

#define MP2_GPIO4_CTRL_REG_SIZE        32
#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_PD_SIZE 1
#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_PU_SIZE 1
#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_S0_SIZE 1
#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_S1_SIZE 1
#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_SCHMEN_SIZE 1
#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_OE_SIZE 1
#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_A_SIZE 1

#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_PD_SHIFT 1
#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_PU_SHIFT 2
#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_S0_SHIFT 3
#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_S1_SHIFT 4
#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_SCHMEN_SHIFT 5
#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_OE_SHIFT 6
#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_A_SHIFT 7

#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_PD_MASK 0x2
#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_PU_MASK 0x4
#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_S0_MASK 0x8
#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_S1_MASK 0x10
#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_SCHMEN_MASK 0x20
#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_OE_MASK 0x40
#define MP2_GPIO4_CTRL_MP_GPIO4_CTRL_A_MASK 0x80

#define MP2_GPIO4_CTRL_MASK \
     (MP2_GPIO4_CTRL_MP_GPIO4_CTRL_PD_MASK | \
      MP2_GPIO4_CTRL_MP_GPIO4_CTRL_PU_MASK | \
      MP2_GPIO4_CTRL_MP_GPIO4_CTRL_S0_MASK | \
      MP2_GPIO4_CTRL_MP_GPIO4_CTRL_S1_MASK | \
      MP2_GPIO4_CTRL_MP_GPIO4_CTRL_SCHMEN_MASK | \
      MP2_GPIO4_CTRL_MP_GPIO4_CTRL_OE_MASK | \
      MP2_GPIO4_CTRL_MP_GPIO4_CTRL_A_MASK)

#define MP2_GPIO4_CTRL_DEFAULT         0x00000038

#define MP2_GPIO4_CTRL_GET_MP_GPIO4_CTRL_PD(mp2_gpio4_ctrl) \
     ((mp2_gpio4_ctrl & MP2_GPIO4_CTRL_MP_GPIO4_CTRL_PD_MASK) >> MP2_GPIO4_CTRL_MP_GPIO4_CTRL_PD_SHIFT)
#define MP2_GPIO4_CTRL_GET_MP_GPIO4_CTRL_PU(mp2_gpio4_ctrl) \
     ((mp2_gpio4_ctrl & MP2_GPIO4_CTRL_MP_GPIO4_CTRL_PU_MASK) >> MP2_GPIO4_CTRL_MP_GPIO4_CTRL_PU_SHIFT)
#define MP2_GPIO4_CTRL_GET_MP_GPIO4_CTRL_S0(mp2_gpio4_ctrl) \
     ((mp2_gpio4_ctrl & MP2_GPIO4_CTRL_MP_GPIO4_CTRL_S0_MASK) >> MP2_GPIO4_CTRL_MP_GPIO4_CTRL_S0_SHIFT)
#define MP2_GPIO4_CTRL_GET_MP_GPIO4_CTRL_S1(mp2_gpio4_ctrl) \
     ((mp2_gpio4_ctrl & MP2_GPIO4_CTRL_MP_GPIO4_CTRL_S1_MASK) >> MP2_GPIO4_CTRL_MP_GPIO4_CTRL_S1_SHIFT)
#define MP2_GPIO4_CTRL_GET_MP_GPIO4_CTRL_SCHMEN(mp2_gpio4_ctrl) \
     ((mp2_gpio4_ctrl & MP2_GPIO4_CTRL_MP_GPIO4_CTRL_SCHMEN_MASK) >> MP2_GPIO4_CTRL_MP_GPIO4_CTRL_SCHMEN_SHIFT)
#define MP2_GPIO4_CTRL_GET_MP_GPIO4_CTRL_OE(mp2_gpio4_ctrl) \
     ((mp2_gpio4_ctrl & MP2_GPIO4_CTRL_MP_GPIO4_CTRL_OE_MASK) >> MP2_GPIO4_CTRL_MP_GPIO4_CTRL_OE_SHIFT)
#define MP2_GPIO4_CTRL_GET_MP_GPIO4_CTRL_A(mp2_gpio4_ctrl) \
     ((mp2_gpio4_ctrl & MP2_GPIO4_CTRL_MP_GPIO4_CTRL_A_MASK) >> MP2_GPIO4_CTRL_MP_GPIO4_CTRL_A_SHIFT)

#define MP2_GPIO4_CTRL_SET_MP_GPIO4_CTRL_PD(mp2_gpio4_ctrl_reg, mp_gpio4_ctrl_pd) \
     mp2_gpio4_ctrl_reg = (mp2_gpio4_ctrl_reg & ~MP2_GPIO4_CTRL_MP_GPIO4_CTRL_PD_MASK) | (mp_gpio4_ctrl_pd << MP2_GPIO4_CTRL_MP_GPIO4_CTRL_PD_SHIFT)
#define MP2_GPIO4_CTRL_SET_MP_GPIO4_CTRL_PU(mp2_gpio4_ctrl_reg, mp_gpio4_ctrl_pu) \
     mp2_gpio4_ctrl_reg = (mp2_gpio4_ctrl_reg & ~MP2_GPIO4_CTRL_MP_GPIO4_CTRL_PU_MASK) | (mp_gpio4_ctrl_pu << MP2_GPIO4_CTRL_MP_GPIO4_CTRL_PU_SHIFT)
#define MP2_GPIO4_CTRL_SET_MP_GPIO4_CTRL_S0(mp2_gpio4_ctrl_reg, mp_gpio4_ctrl_s0) \
     mp2_gpio4_ctrl_reg = (mp2_gpio4_ctrl_reg & ~MP2_GPIO4_CTRL_MP_GPIO4_CTRL_S0_MASK) | (mp_gpio4_ctrl_s0 << MP2_GPIO4_CTRL_MP_GPIO4_CTRL_S0_SHIFT)
#define MP2_GPIO4_CTRL_SET_MP_GPIO4_CTRL_S1(mp2_gpio4_ctrl_reg, mp_gpio4_ctrl_s1) \
     mp2_gpio4_ctrl_reg = (mp2_gpio4_ctrl_reg & ~MP2_GPIO4_CTRL_MP_GPIO4_CTRL_S1_MASK) | (mp_gpio4_ctrl_s1 << MP2_GPIO4_CTRL_MP_GPIO4_CTRL_S1_SHIFT)
#define MP2_GPIO4_CTRL_SET_MP_GPIO4_CTRL_SCHMEN(mp2_gpio4_ctrl_reg, mp_gpio4_ctrl_schmen) \
     mp2_gpio4_ctrl_reg = (mp2_gpio4_ctrl_reg & ~MP2_GPIO4_CTRL_MP_GPIO4_CTRL_SCHMEN_MASK) | (mp_gpio4_ctrl_schmen << MP2_GPIO4_CTRL_MP_GPIO4_CTRL_SCHMEN_SHIFT)
#define MP2_GPIO4_CTRL_SET_MP_GPIO4_CTRL_OE(mp2_gpio4_ctrl_reg, mp_gpio4_ctrl_oe) \
     mp2_gpio4_ctrl_reg = (mp2_gpio4_ctrl_reg & ~MP2_GPIO4_CTRL_MP_GPIO4_CTRL_OE_MASK) | (mp_gpio4_ctrl_oe << MP2_GPIO4_CTRL_MP_GPIO4_CTRL_OE_SHIFT)
#define MP2_GPIO4_CTRL_SET_MP_GPIO4_CTRL_A(mp2_gpio4_ctrl_reg, mp_gpio4_ctrl_a) \
     mp2_gpio4_ctrl_reg = (mp2_gpio4_ctrl_reg & ~MP2_GPIO4_CTRL_MP_GPIO4_CTRL_A_MASK) | (mp_gpio4_ctrl_a << MP2_GPIO4_CTRL_MP_GPIO4_CTRL_A_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio4_ctrl_t {
          unsigned int                                : 1;
          unsigned int mp_gpio4_ctrl_pd               : MP2_GPIO4_CTRL_MP_GPIO4_CTRL_PD_SIZE;
          unsigned int mp_gpio4_ctrl_pu               : MP2_GPIO4_CTRL_MP_GPIO4_CTRL_PU_SIZE;
          unsigned int mp_gpio4_ctrl_s0               : MP2_GPIO4_CTRL_MP_GPIO4_CTRL_S0_SIZE;
          unsigned int mp_gpio4_ctrl_s1               : MP2_GPIO4_CTRL_MP_GPIO4_CTRL_S1_SIZE;
          unsigned int mp_gpio4_ctrl_schmen           : MP2_GPIO4_CTRL_MP_GPIO4_CTRL_SCHMEN_SIZE;
          unsigned int mp_gpio4_ctrl_oe               : MP2_GPIO4_CTRL_MP_GPIO4_CTRL_OE_SIZE;
          unsigned int mp_gpio4_ctrl_a                : MP2_GPIO4_CTRL_MP_GPIO4_CTRL_A_SIZE;
          unsigned int                                : 24;
     } mp2_gpio4_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio4_ctrl_t {
          unsigned int                                : 24;
          unsigned int mp_gpio4_ctrl_a                : MP2_GPIO4_CTRL_MP_GPIO4_CTRL_A_SIZE;
          unsigned int mp_gpio4_ctrl_oe               : MP2_GPIO4_CTRL_MP_GPIO4_CTRL_OE_SIZE;
          unsigned int mp_gpio4_ctrl_schmen           : MP2_GPIO4_CTRL_MP_GPIO4_CTRL_SCHMEN_SIZE;
          unsigned int mp_gpio4_ctrl_s1               : MP2_GPIO4_CTRL_MP_GPIO4_CTRL_S1_SIZE;
          unsigned int mp_gpio4_ctrl_s0               : MP2_GPIO4_CTRL_MP_GPIO4_CTRL_S0_SIZE;
          unsigned int mp_gpio4_ctrl_pu               : MP2_GPIO4_CTRL_MP_GPIO4_CTRL_PU_SIZE;
          unsigned int mp_gpio4_ctrl_pd               : MP2_GPIO4_CTRL_MP_GPIO4_CTRL_PD_SIZE;
          unsigned int                                : 1;
     } mp2_gpio4_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio4_ctrl_t f;
} mp2_gpio4_ctrl_u;


/*
 * MP2_GPIO4_FCH_INT_OVERRIDE struct
 */

#define MP2_GPIO4_FCH_INT_OVERRIDE_REG_SIZE 32
#define MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_EN_SIZE 1
#define MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_OUTPUT_SIZE 1
#define MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_STAT_SIZE 1

#define MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_EN_SHIFT 0
#define MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_OUTPUT_SHIFT 1
#define MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_STAT_SHIFT 2

#define MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_EN_MASK 0x1
#define MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_OUTPUT_MASK 0x2
#define MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_STAT_MASK 0x4

#define MP2_GPIO4_FCH_INT_OVERRIDE_MASK \
     (MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_EN_MASK | \
      MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_OUTPUT_MASK | \
      MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_STAT_MASK)

#define MP2_GPIO4_FCH_INT_OVERRIDE_DEFAULT 0x00000000

#define MP2_GPIO4_FCH_INT_OVERRIDE_GET_MP_FCH_INT_OVERRIDE_GPIO4_EN(mp2_gpio4_fch_int_override) \
     ((mp2_gpio4_fch_int_override & MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_EN_MASK) >> MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_EN_SHIFT)
#define MP2_GPIO4_FCH_INT_OVERRIDE_GET_MP_FCH_INT_OVERRIDE_GPIO4_OUTPUT(mp2_gpio4_fch_int_override) \
     ((mp2_gpio4_fch_int_override & MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_OUTPUT_MASK) >> MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_OUTPUT_SHIFT)
#define MP2_GPIO4_FCH_INT_OVERRIDE_GET_MP_FCH_INT_OVERRIDE_GPIO4_STAT(mp2_gpio4_fch_int_override) \
     ((mp2_gpio4_fch_int_override & MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_STAT_MASK) >> MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_STAT_SHIFT)

#define MP2_GPIO4_FCH_INT_OVERRIDE_SET_MP_FCH_INT_OVERRIDE_GPIO4_EN(mp2_gpio4_fch_int_override_reg, mp_fch_int_override_gpio4_en) \
     mp2_gpio4_fch_int_override_reg = (mp2_gpio4_fch_int_override_reg & ~MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_EN_MASK) | (mp_fch_int_override_gpio4_en << MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_EN_SHIFT)
#define MP2_GPIO4_FCH_INT_OVERRIDE_SET_MP_FCH_INT_OVERRIDE_GPIO4_OUTPUT(mp2_gpio4_fch_int_override_reg, mp_fch_int_override_gpio4_output) \
     mp2_gpio4_fch_int_override_reg = (mp2_gpio4_fch_int_override_reg & ~MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_OUTPUT_MASK) | (mp_fch_int_override_gpio4_output << MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_OUTPUT_SHIFT)
#define MP2_GPIO4_FCH_INT_OVERRIDE_SET_MP_FCH_INT_OVERRIDE_GPIO4_STAT(mp2_gpio4_fch_int_override_reg, mp_fch_int_override_gpio4_stat) \
     mp2_gpio4_fch_int_override_reg = (mp2_gpio4_fch_int_override_reg & ~MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_STAT_MASK) | (mp_fch_int_override_gpio4_stat << MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio4_fch_int_override_t {
          unsigned int mp_fch_int_override_gpio4_en   : MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_EN_SIZE;
          unsigned int mp_fch_int_override_gpio4_output : MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_OUTPUT_SIZE;
          unsigned int mp_fch_int_override_gpio4_stat : MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_gpio4_fch_int_override_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio4_fch_int_override_t {
          unsigned int                                : 29;
          unsigned int mp_fch_int_override_gpio4_stat : MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_STAT_SIZE;
          unsigned int mp_fch_int_override_gpio4_output : MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_OUTPUT_SIZE;
          unsigned int mp_fch_int_override_gpio4_en   : MP2_GPIO4_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO4_EN_SIZE;
     } mp2_gpio4_fch_int_override_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio4_fch_int_override_t f;
} mp2_gpio4_fch_int_override_u;


/*
 * MP2_GPIO4_MP_INT struct
 */

#define MP2_GPIO4_MP_INT_REG_SIZE      32
#define MP2_GPIO4_MP_INT_MP2_GPIO4_MP_INT_EN_SIZE 2
#define MP2_GPIO4_MP_INT_MP2_GPIO4_MP_INT_STAT_SIZE 1

#define MP2_GPIO4_MP_INT_MP2_GPIO4_MP_INT_EN_SHIFT 0
#define MP2_GPIO4_MP_INT_MP2_GPIO4_MP_INT_STAT_SHIFT 2

#define MP2_GPIO4_MP_INT_MP2_GPIO4_MP_INT_EN_MASK 0x3
#define MP2_GPIO4_MP_INT_MP2_GPIO4_MP_INT_STAT_MASK 0x4

#define MP2_GPIO4_MP_INT_MASK \
     (MP2_GPIO4_MP_INT_MP2_GPIO4_MP_INT_EN_MASK | \
      MP2_GPIO4_MP_INT_MP2_GPIO4_MP_INT_STAT_MASK)

#define MP2_GPIO4_MP_INT_DEFAULT       0x00000000

#define MP2_GPIO4_MP_INT_GET_MP2_GPIO4_MP_INT_EN(mp2_gpio4_mp_int) \
     ((mp2_gpio4_mp_int & MP2_GPIO4_MP_INT_MP2_GPIO4_MP_INT_EN_MASK) >> MP2_GPIO4_MP_INT_MP2_GPIO4_MP_INT_EN_SHIFT)
#define MP2_GPIO4_MP_INT_GET_MP2_GPIO4_MP_INT_STAT(mp2_gpio4_mp_int) \
     ((mp2_gpio4_mp_int & MP2_GPIO4_MP_INT_MP2_GPIO4_MP_INT_STAT_MASK) >> MP2_GPIO4_MP_INT_MP2_GPIO4_MP_INT_STAT_SHIFT)

#define MP2_GPIO4_MP_INT_SET_MP2_GPIO4_MP_INT_EN(mp2_gpio4_mp_int_reg, mp2_gpio4_mp_int_en) \
     mp2_gpio4_mp_int_reg = (mp2_gpio4_mp_int_reg & ~MP2_GPIO4_MP_INT_MP2_GPIO4_MP_INT_EN_MASK) | (mp2_gpio4_mp_int_en << MP2_GPIO4_MP_INT_MP2_GPIO4_MP_INT_EN_SHIFT)
#define MP2_GPIO4_MP_INT_SET_MP2_GPIO4_MP_INT_STAT(mp2_gpio4_mp_int_reg, mp2_gpio4_mp_int_stat) \
     mp2_gpio4_mp_int_reg = (mp2_gpio4_mp_int_reg & ~MP2_GPIO4_MP_INT_MP2_GPIO4_MP_INT_STAT_MASK) | (mp2_gpio4_mp_int_stat << MP2_GPIO4_MP_INT_MP2_GPIO4_MP_INT_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio4_mp_int_t {
          unsigned int mp2_gpio4_mp_int_en            : MP2_GPIO4_MP_INT_MP2_GPIO4_MP_INT_EN_SIZE;
          unsigned int mp2_gpio4_mp_int_stat          : MP2_GPIO4_MP_INT_MP2_GPIO4_MP_INT_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_gpio4_mp_int_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio4_mp_int_t {
          unsigned int                                : 29;
          unsigned int mp2_gpio4_mp_int_stat          : MP2_GPIO4_MP_INT_MP2_GPIO4_MP_INT_STAT_SIZE;
          unsigned int mp2_gpio4_mp_int_en            : MP2_GPIO4_MP_INT_MP2_GPIO4_MP_INT_EN_SIZE;
     } mp2_gpio4_mp_int_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio4_mp_int_t f;
} mp2_gpio4_mp_int_u;


/*
 * MP2_GPIO4_FCH_INT struct
 */

#define MP2_GPIO4_FCH_INT_REG_SIZE     32
#define MP2_GPIO4_FCH_INT_MP2_GPIO4_FCH_INT_EN_SIZE 2
#define MP2_GPIO4_FCH_INT_MP2_GPIO4_FCH_INT_STAT_SIZE 1

#define MP2_GPIO4_FCH_INT_MP2_GPIO4_FCH_INT_EN_SHIFT 0
#define MP2_GPIO4_FCH_INT_MP2_GPIO4_FCH_INT_STAT_SHIFT 2

#define MP2_GPIO4_FCH_INT_MP2_GPIO4_FCH_INT_EN_MASK 0x3
#define MP2_GPIO4_FCH_INT_MP2_GPIO4_FCH_INT_STAT_MASK 0x4

#define MP2_GPIO4_FCH_INT_MASK \
     (MP2_GPIO4_FCH_INT_MP2_GPIO4_FCH_INT_EN_MASK | \
      MP2_GPIO4_FCH_INT_MP2_GPIO4_FCH_INT_STAT_MASK)

#define MP2_GPIO4_FCH_INT_DEFAULT      0x00000000

#define MP2_GPIO4_FCH_INT_GET_MP2_GPIO4_FCH_INT_EN(mp2_gpio4_fch_int) \
     ((mp2_gpio4_fch_int & MP2_GPIO4_FCH_INT_MP2_GPIO4_FCH_INT_EN_MASK) >> MP2_GPIO4_FCH_INT_MP2_GPIO4_FCH_INT_EN_SHIFT)
#define MP2_GPIO4_FCH_INT_GET_MP2_GPIO4_FCH_INT_STAT(mp2_gpio4_fch_int) \
     ((mp2_gpio4_fch_int & MP2_GPIO4_FCH_INT_MP2_GPIO4_FCH_INT_STAT_MASK) >> MP2_GPIO4_FCH_INT_MP2_GPIO4_FCH_INT_STAT_SHIFT)

#define MP2_GPIO4_FCH_INT_SET_MP2_GPIO4_FCH_INT_EN(mp2_gpio4_fch_int_reg, mp2_gpio4_fch_int_en) \
     mp2_gpio4_fch_int_reg = (mp2_gpio4_fch_int_reg & ~MP2_GPIO4_FCH_INT_MP2_GPIO4_FCH_INT_EN_MASK) | (mp2_gpio4_fch_int_en << MP2_GPIO4_FCH_INT_MP2_GPIO4_FCH_INT_EN_SHIFT)
#define MP2_GPIO4_FCH_INT_SET_MP2_GPIO4_FCH_INT_STAT(mp2_gpio4_fch_int_reg, mp2_gpio4_fch_int_stat) \
     mp2_gpio4_fch_int_reg = (mp2_gpio4_fch_int_reg & ~MP2_GPIO4_FCH_INT_MP2_GPIO4_FCH_INT_STAT_MASK) | (mp2_gpio4_fch_int_stat << MP2_GPIO4_FCH_INT_MP2_GPIO4_FCH_INT_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio4_fch_int_t {
          unsigned int mp2_gpio4_fch_int_en           : MP2_GPIO4_FCH_INT_MP2_GPIO4_FCH_INT_EN_SIZE;
          unsigned int mp2_gpio4_fch_int_stat         : MP2_GPIO4_FCH_INT_MP2_GPIO4_FCH_INT_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_gpio4_fch_int_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio4_fch_int_t {
          unsigned int                                : 29;
          unsigned int mp2_gpio4_fch_int_stat         : MP2_GPIO4_FCH_INT_MP2_GPIO4_FCH_INT_STAT_SIZE;
          unsigned int mp2_gpio4_fch_int_en           : MP2_GPIO4_FCH_INT_MP2_GPIO4_FCH_INT_EN_SIZE;
     } mp2_gpio4_fch_int_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio4_fch_int_t f;
} mp2_gpio4_fch_int_u;


/*
 * MP2_GPIO4_IO_STATUS struct
 */

#define MP2_GPIO4_IO_STATUS_REG_SIZE   32
#define MP2_GPIO4_IO_STATUS_MP_GPIO_INPUT_GPIO4_SIZE 1
#define MP2_GPIO4_IO_STATUS_MP_GPIO_OUTPUT_GPIO4_SIZE 1

#define MP2_GPIO4_IO_STATUS_MP_GPIO_INPUT_GPIO4_SHIFT 0
#define MP2_GPIO4_IO_STATUS_MP_GPIO_OUTPUT_GPIO4_SHIFT 1

#define MP2_GPIO4_IO_STATUS_MP_GPIO_INPUT_GPIO4_MASK 0x1
#define MP2_GPIO4_IO_STATUS_MP_GPIO_OUTPUT_GPIO4_MASK 0x2

#define MP2_GPIO4_IO_STATUS_MASK \
     (MP2_GPIO4_IO_STATUS_MP_GPIO_INPUT_GPIO4_MASK | \
      MP2_GPIO4_IO_STATUS_MP_GPIO_OUTPUT_GPIO4_MASK)

#define MP2_GPIO4_IO_STATUS_DEFAULT    0x00000000

#define MP2_GPIO4_IO_STATUS_GET_MP_GPIO_INPUT_GPIO4(mp2_gpio4_io_status) \
     ((mp2_gpio4_io_status & MP2_GPIO4_IO_STATUS_MP_GPIO_INPUT_GPIO4_MASK) >> MP2_GPIO4_IO_STATUS_MP_GPIO_INPUT_GPIO4_SHIFT)
#define MP2_GPIO4_IO_STATUS_GET_MP_GPIO_OUTPUT_GPIO4(mp2_gpio4_io_status) \
     ((mp2_gpio4_io_status & MP2_GPIO4_IO_STATUS_MP_GPIO_OUTPUT_GPIO4_MASK) >> MP2_GPIO4_IO_STATUS_MP_GPIO_OUTPUT_GPIO4_SHIFT)

#define MP2_GPIO4_IO_STATUS_SET_MP_GPIO_INPUT_GPIO4(mp2_gpio4_io_status_reg, mp_gpio_input_gpio4) \
     mp2_gpio4_io_status_reg = (mp2_gpio4_io_status_reg & ~MP2_GPIO4_IO_STATUS_MP_GPIO_INPUT_GPIO4_MASK) | (mp_gpio_input_gpio4 << MP2_GPIO4_IO_STATUS_MP_GPIO_INPUT_GPIO4_SHIFT)
#define MP2_GPIO4_IO_STATUS_SET_MP_GPIO_OUTPUT_GPIO4(mp2_gpio4_io_status_reg, mp_gpio_output_gpio4) \
     mp2_gpio4_io_status_reg = (mp2_gpio4_io_status_reg & ~MP2_GPIO4_IO_STATUS_MP_GPIO_OUTPUT_GPIO4_MASK) | (mp_gpio_output_gpio4 << MP2_GPIO4_IO_STATUS_MP_GPIO_OUTPUT_GPIO4_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio4_io_status_t {
          unsigned int mp_gpio_input_gpio4            : MP2_GPIO4_IO_STATUS_MP_GPIO_INPUT_GPIO4_SIZE;
          unsigned int mp_gpio_output_gpio4           : MP2_GPIO4_IO_STATUS_MP_GPIO_OUTPUT_GPIO4_SIZE;
          unsigned int                                : 30;
     } mp2_gpio4_io_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio4_io_status_t {
          unsigned int                                : 30;
          unsigned int mp_gpio_output_gpio4           : MP2_GPIO4_IO_STATUS_MP_GPIO_OUTPUT_GPIO4_SIZE;
          unsigned int mp_gpio_input_gpio4            : MP2_GPIO4_IO_STATUS_MP_GPIO_INPUT_GPIO4_SIZE;
     } mp2_gpio4_io_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio4_io_status_t f;
} mp2_gpio4_io_status_u;


/*
 * MP2_GPIO5_CTRL struct
 */

#define MP2_GPIO5_CTRL_REG_SIZE        32
#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_PD_SIZE 1
#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_PU_SIZE 1
#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_S0_SIZE 1
#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_S1_SIZE 1
#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_SCHMEN_SIZE 1
#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_OE_SIZE 1
#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_A_SIZE 1

#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_PD_SHIFT 1
#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_PU_SHIFT 2
#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_S0_SHIFT 3
#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_S1_SHIFT 4
#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_SCHMEN_SHIFT 5
#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_OE_SHIFT 6
#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_A_SHIFT 7

#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_PD_MASK 0x2
#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_PU_MASK 0x4
#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_S0_MASK 0x8
#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_S1_MASK 0x10
#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_SCHMEN_MASK 0x20
#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_OE_MASK 0x40
#define MP2_GPIO5_CTRL_MP_GPIO5_CTRL_A_MASK 0x80

#define MP2_GPIO5_CTRL_MASK \
     (MP2_GPIO5_CTRL_MP_GPIO5_CTRL_PD_MASK | \
      MP2_GPIO5_CTRL_MP_GPIO5_CTRL_PU_MASK | \
      MP2_GPIO5_CTRL_MP_GPIO5_CTRL_S0_MASK | \
      MP2_GPIO5_CTRL_MP_GPIO5_CTRL_S1_MASK | \
      MP2_GPIO5_CTRL_MP_GPIO5_CTRL_SCHMEN_MASK | \
      MP2_GPIO5_CTRL_MP_GPIO5_CTRL_OE_MASK | \
      MP2_GPIO5_CTRL_MP_GPIO5_CTRL_A_MASK)

#define MP2_GPIO5_CTRL_DEFAULT         0x00000038

#define MP2_GPIO5_CTRL_GET_MP_GPIO5_CTRL_PD(mp2_gpio5_ctrl) \
     ((mp2_gpio5_ctrl & MP2_GPIO5_CTRL_MP_GPIO5_CTRL_PD_MASK) >> MP2_GPIO5_CTRL_MP_GPIO5_CTRL_PD_SHIFT)
#define MP2_GPIO5_CTRL_GET_MP_GPIO5_CTRL_PU(mp2_gpio5_ctrl) \
     ((mp2_gpio5_ctrl & MP2_GPIO5_CTRL_MP_GPIO5_CTRL_PU_MASK) >> MP2_GPIO5_CTRL_MP_GPIO5_CTRL_PU_SHIFT)
#define MP2_GPIO5_CTRL_GET_MP_GPIO5_CTRL_S0(mp2_gpio5_ctrl) \
     ((mp2_gpio5_ctrl & MP2_GPIO5_CTRL_MP_GPIO5_CTRL_S0_MASK) >> MP2_GPIO5_CTRL_MP_GPIO5_CTRL_S0_SHIFT)
#define MP2_GPIO5_CTRL_GET_MP_GPIO5_CTRL_S1(mp2_gpio5_ctrl) \
     ((mp2_gpio5_ctrl & MP2_GPIO5_CTRL_MP_GPIO5_CTRL_S1_MASK) >> MP2_GPIO5_CTRL_MP_GPIO5_CTRL_S1_SHIFT)
#define MP2_GPIO5_CTRL_GET_MP_GPIO5_CTRL_SCHMEN(mp2_gpio5_ctrl) \
     ((mp2_gpio5_ctrl & MP2_GPIO5_CTRL_MP_GPIO5_CTRL_SCHMEN_MASK) >> MP2_GPIO5_CTRL_MP_GPIO5_CTRL_SCHMEN_SHIFT)
#define MP2_GPIO5_CTRL_GET_MP_GPIO5_CTRL_OE(mp2_gpio5_ctrl) \
     ((mp2_gpio5_ctrl & MP2_GPIO5_CTRL_MP_GPIO5_CTRL_OE_MASK) >> MP2_GPIO5_CTRL_MP_GPIO5_CTRL_OE_SHIFT)
#define MP2_GPIO5_CTRL_GET_MP_GPIO5_CTRL_A(mp2_gpio5_ctrl) \
     ((mp2_gpio5_ctrl & MP2_GPIO5_CTRL_MP_GPIO5_CTRL_A_MASK) >> MP2_GPIO5_CTRL_MP_GPIO5_CTRL_A_SHIFT)

#define MP2_GPIO5_CTRL_SET_MP_GPIO5_CTRL_PD(mp2_gpio5_ctrl_reg, mp_gpio5_ctrl_pd) \
     mp2_gpio5_ctrl_reg = (mp2_gpio5_ctrl_reg & ~MP2_GPIO5_CTRL_MP_GPIO5_CTRL_PD_MASK) | (mp_gpio5_ctrl_pd << MP2_GPIO5_CTRL_MP_GPIO5_CTRL_PD_SHIFT)
#define MP2_GPIO5_CTRL_SET_MP_GPIO5_CTRL_PU(mp2_gpio5_ctrl_reg, mp_gpio5_ctrl_pu) \
     mp2_gpio5_ctrl_reg = (mp2_gpio5_ctrl_reg & ~MP2_GPIO5_CTRL_MP_GPIO5_CTRL_PU_MASK) | (mp_gpio5_ctrl_pu << MP2_GPIO5_CTRL_MP_GPIO5_CTRL_PU_SHIFT)
#define MP2_GPIO5_CTRL_SET_MP_GPIO5_CTRL_S0(mp2_gpio5_ctrl_reg, mp_gpio5_ctrl_s0) \
     mp2_gpio5_ctrl_reg = (mp2_gpio5_ctrl_reg & ~MP2_GPIO5_CTRL_MP_GPIO5_CTRL_S0_MASK) | (mp_gpio5_ctrl_s0 << MP2_GPIO5_CTRL_MP_GPIO5_CTRL_S0_SHIFT)
#define MP2_GPIO5_CTRL_SET_MP_GPIO5_CTRL_S1(mp2_gpio5_ctrl_reg, mp_gpio5_ctrl_s1) \
     mp2_gpio5_ctrl_reg = (mp2_gpio5_ctrl_reg & ~MP2_GPIO5_CTRL_MP_GPIO5_CTRL_S1_MASK) | (mp_gpio5_ctrl_s1 << MP2_GPIO5_CTRL_MP_GPIO5_CTRL_S1_SHIFT)
#define MP2_GPIO5_CTRL_SET_MP_GPIO5_CTRL_SCHMEN(mp2_gpio5_ctrl_reg, mp_gpio5_ctrl_schmen) \
     mp2_gpio5_ctrl_reg = (mp2_gpio5_ctrl_reg & ~MP2_GPIO5_CTRL_MP_GPIO5_CTRL_SCHMEN_MASK) | (mp_gpio5_ctrl_schmen << MP2_GPIO5_CTRL_MP_GPIO5_CTRL_SCHMEN_SHIFT)
#define MP2_GPIO5_CTRL_SET_MP_GPIO5_CTRL_OE(mp2_gpio5_ctrl_reg, mp_gpio5_ctrl_oe) \
     mp2_gpio5_ctrl_reg = (mp2_gpio5_ctrl_reg & ~MP2_GPIO5_CTRL_MP_GPIO5_CTRL_OE_MASK) | (mp_gpio5_ctrl_oe << MP2_GPIO5_CTRL_MP_GPIO5_CTRL_OE_SHIFT)
#define MP2_GPIO5_CTRL_SET_MP_GPIO5_CTRL_A(mp2_gpio5_ctrl_reg, mp_gpio5_ctrl_a) \
     mp2_gpio5_ctrl_reg = (mp2_gpio5_ctrl_reg & ~MP2_GPIO5_CTRL_MP_GPIO5_CTRL_A_MASK) | (mp_gpio5_ctrl_a << MP2_GPIO5_CTRL_MP_GPIO5_CTRL_A_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio5_ctrl_t {
          unsigned int                                : 1;
          unsigned int mp_gpio5_ctrl_pd               : MP2_GPIO5_CTRL_MP_GPIO5_CTRL_PD_SIZE;
          unsigned int mp_gpio5_ctrl_pu               : MP2_GPIO5_CTRL_MP_GPIO5_CTRL_PU_SIZE;
          unsigned int mp_gpio5_ctrl_s0               : MP2_GPIO5_CTRL_MP_GPIO5_CTRL_S0_SIZE;
          unsigned int mp_gpio5_ctrl_s1               : MP2_GPIO5_CTRL_MP_GPIO5_CTRL_S1_SIZE;
          unsigned int mp_gpio5_ctrl_schmen           : MP2_GPIO5_CTRL_MP_GPIO5_CTRL_SCHMEN_SIZE;
          unsigned int mp_gpio5_ctrl_oe               : MP2_GPIO5_CTRL_MP_GPIO5_CTRL_OE_SIZE;
          unsigned int mp_gpio5_ctrl_a                : MP2_GPIO5_CTRL_MP_GPIO5_CTRL_A_SIZE;
          unsigned int                                : 24;
     } mp2_gpio5_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio5_ctrl_t {
          unsigned int                                : 24;
          unsigned int mp_gpio5_ctrl_a                : MP2_GPIO5_CTRL_MP_GPIO5_CTRL_A_SIZE;
          unsigned int mp_gpio5_ctrl_oe               : MP2_GPIO5_CTRL_MP_GPIO5_CTRL_OE_SIZE;
          unsigned int mp_gpio5_ctrl_schmen           : MP2_GPIO5_CTRL_MP_GPIO5_CTRL_SCHMEN_SIZE;
          unsigned int mp_gpio5_ctrl_s1               : MP2_GPIO5_CTRL_MP_GPIO5_CTRL_S1_SIZE;
          unsigned int mp_gpio5_ctrl_s0               : MP2_GPIO5_CTRL_MP_GPIO5_CTRL_S0_SIZE;
          unsigned int mp_gpio5_ctrl_pu               : MP2_GPIO5_CTRL_MP_GPIO5_CTRL_PU_SIZE;
          unsigned int mp_gpio5_ctrl_pd               : MP2_GPIO5_CTRL_MP_GPIO5_CTRL_PD_SIZE;
          unsigned int                                : 1;
     } mp2_gpio5_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio5_ctrl_t f;
} mp2_gpio5_ctrl_u;


/*
 * MP2_GPIO5_FCH_INT_OVERRIDE struct
 */

#define MP2_GPIO5_FCH_INT_OVERRIDE_REG_SIZE 32
#define MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_EN_SIZE 1
#define MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_OUTPUT_SIZE 1
#define MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_STAT_SIZE 1

#define MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_EN_SHIFT 0
#define MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_OUTPUT_SHIFT 1
#define MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_STAT_SHIFT 2

#define MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_EN_MASK 0x1
#define MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_OUTPUT_MASK 0x2
#define MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_STAT_MASK 0x4

#define MP2_GPIO5_FCH_INT_OVERRIDE_MASK \
     (MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_EN_MASK | \
      MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_OUTPUT_MASK | \
      MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_STAT_MASK)

#define MP2_GPIO5_FCH_INT_OVERRIDE_DEFAULT 0x00000000

#define MP2_GPIO5_FCH_INT_OVERRIDE_GET_MP_FCH_INT_OVERRIDE_GPIO5_EN(mp2_gpio5_fch_int_override) \
     ((mp2_gpio5_fch_int_override & MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_EN_MASK) >> MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_EN_SHIFT)
#define MP2_GPIO5_FCH_INT_OVERRIDE_GET_MP_FCH_INT_OVERRIDE_GPIO5_OUTPUT(mp2_gpio5_fch_int_override) \
     ((mp2_gpio5_fch_int_override & MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_OUTPUT_MASK) >> MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_OUTPUT_SHIFT)
#define MP2_GPIO5_FCH_INT_OVERRIDE_GET_MP_FCH_INT_OVERRIDE_GPIO5_STAT(mp2_gpio5_fch_int_override) \
     ((mp2_gpio5_fch_int_override & MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_STAT_MASK) >> MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_STAT_SHIFT)

#define MP2_GPIO5_FCH_INT_OVERRIDE_SET_MP_FCH_INT_OVERRIDE_GPIO5_EN(mp2_gpio5_fch_int_override_reg, mp_fch_int_override_gpio5_en) \
     mp2_gpio5_fch_int_override_reg = (mp2_gpio5_fch_int_override_reg & ~MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_EN_MASK) | (mp_fch_int_override_gpio5_en << MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_EN_SHIFT)
#define MP2_GPIO5_FCH_INT_OVERRIDE_SET_MP_FCH_INT_OVERRIDE_GPIO5_OUTPUT(mp2_gpio5_fch_int_override_reg, mp_fch_int_override_gpio5_output) \
     mp2_gpio5_fch_int_override_reg = (mp2_gpio5_fch_int_override_reg & ~MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_OUTPUT_MASK) | (mp_fch_int_override_gpio5_output << MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_OUTPUT_SHIFT)
#define MP2_GPIO5_FCH_INT_OVERRIDE_SET_MP_FCH_INT_OVERRIDE_GPIO5_STAT(mp2_gpio5_fch_int_override_reg, mp_fch_int_override_gpio5_stat) \
     mp2_gpio5_fch_int_override_reg = (mp2_gpio5_fch_int_override_reg & ~MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_STAT_MASK) | (mp_fch_int_override_gpio5_stat << MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio5_fch_int_override_t {
          unsigned int mp_fch_int_override_gpio5_en   : MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_EN_SIZE;
          unsigned int mp_fch_int_override_gpio5_output : MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_OUTPUT_SIZE;
          unsigned int mp_fch_int_override_gpio5_stat : MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_gpio5_fch_int_override_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio5_fch_int_override_t {
          unsigned int                                : 29;
          unsigned int mp_fch_int_override_gpio5_stat : MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_STAT_SIZE;
          unsigned int mp_fch_int_override_gpio5_output : MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_OUTPUT_SIZE;
          unsigned int mp_fch_int_override_gpio5_en   : MP2_GPIO5_FCH_INT_OVERRIDE_MP_FCH_INT_OVERRIDE_GPIO5_EN_SIZE;
     } mp2_gpio5_fch_int_override_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio5_fch_int_override_t f;
} mp2_gpio5_fch_int_override_u;


/*
 * MP2_GPIO5_MP_INT struct
 */

#define MP2_GPIO5_MP_INT_REG_SIZE      32
#define MP2_GPIO5_MP_INT_MP2_GPIO5_MP_INT_EN_SIZE 2
#define MP2_GPIO5_MP_INT_MP2_GPIO5_MP_INT_STAT_SIZE 1

#define MP2_GPIO5_MP_INT_MP2_GPIO5_MP_INT_EN_SHIFT 0
#define MP2_GPIO5_MP_INT_MP2_GPIO5_MP_INT_STAT_SHIFT 2

#define MP2_GPIO5_MP_INT_MP2_GPIO5_MP_INT_EN_MASK 0x3
#define MP2_GPIO5_MP_INT_MP2_GPIO5_MP_INT_STAT_MASK 0x4

#define MP2_GPIO5_MP_INT_MASK \
     (MP2_GPIO5_MP_INT_MP2_GPIO5_MP_INT_EN_MASK | \
      MP2_GPIO5_MP_INT_MP2_GPIO5_MP_INT_STAT_MASK)

#define MP2_GPIO5_MP_INT_DEFAULT       0x00000000

#define MP2_GPIO5_MP_INT_GET_MP2_GPIO5_MP_INT_EN(mp2_gpio5_mp_int) \
     ((mp2_gpio5_mp_int & MP2_GPIO5_MP_INT_MP2_GPIO5_MP_INT_EN_MASK) >> MP2_GPIO5_MP_INT_MP2_GPIO5_MP_INT_EN_SHIFT)
#define MP2_GPIO5_MP_INT_GET_MP2_GPIO5_MP_INT_STAT(mp2_gpio5_mp_int) \
     ((mp2_gpio5_mp_int & MP2_GPIO5_MP_INT_MP2_GPIO5_MP_INT_STAT_MASK) >> MP2_GPIO5_MP_INT_MP2_GPIO5_MP_INT_STAT_SHIFT)

#define MP2_GPIO5_MP_INT_SET_MP2_GPIO5_MP_INT_EN(mp2_gpio5_mp_int_reg, mp2_gpio5_mp_int_en) \
     mp2_gpio5_mp_int_reg = (mp2_gpio5_mp_int_reg & ~MP2_GPIO5_MP_INT_MP2_GPIO5_MP_INT_EN_MASK) | (mp2_gpio5_mp_int_en << MP2_GPIO5_MP_INT_MP2_GPIO5_MP_INT_EN_SHIFT)
#define MP2_GPIO5_MP_INT_SET_MP2_GPIO5_MP_INT_STAT(mp2_gpio5_mp_int_reg, mp2_gpio5_mp_int_stat) \
     mp2_gpio5_mp_int_reg = (mp2_gpio5_mp_int_reg & ~MP2_GPIO5_MP_INT_MP2_GPIO5_MP_INT_STAT_MASK) | (mp2_gpio5_mp_int_stat << MP2_GPIO5_MP_INT_MP2_GPIO5_MP_INT_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio5_mp_int_t {
          unsigned int mp2_gpio5_mp_int_en            : MP2_GPIO5_MP_INT_MP2_GPIO5_MP_INT_EN_SIZE;
          unsigned int mp2_gpio5_mp_int_stat          : MP2_GPIO5_MP_INT_MP2_GPIO5_MP_INT_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_gpio5_mp_int_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio5_mp_int_t {
          unsigned int                                : 29;
          unsigned int mp2_gpio5_mp_int_stat          : MP2_GPIO5_MP_INT_MP2_GPIO5_MP_INT_STAT_SIZE;
          unsigned int mp2_gpio5_mp_int_en            : MP2_GPIO5_MP_INT_MP2_GPIO5_MP_INT_EN_SIZE;
     } mp2_gpio5_mp_int_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio5_mp_int_t f;
} mp2_gpio5_mp_int_u;


/*
 * MP2_GPIO5_FCH_INT struct
 */

#define MP2_GPIO5_FCH_INT_REG_SIZE     32
#define MP2_GPIO5_FCH_INT_MP2_GPIO5_FCH_INT_EN_SIZE 2
#define MP2_GPIO5_FCH_INT_MP2_GPIO5_FCH_INT_STAT_SIZE 1

#define MP2_GPIO5_FCH_INT_MP2_GPIO5_FCH_INT_EN_SHIFT 0
#define MP2_GPIO5_FCH_INT_MP2_GPIO5_FCH_INT_STAT_SHIFT 2

#define MP2_GPIO5_FCH_INT_MP2_GPIO5_FCH_INT_EN_MASK 0x3
#define MP2_GPIO5_FCH_INT_MP2_GPIO5_FCH_INT_STAT_MASK 0x4

#define MP2_GPIO5_FCH_INT_MASK \
     (MP2_GPIO5_FCH_INT_MP2_GPIO5_FCH_INT_EN_MASK | \
      MP2_GPIO5_FCH_INT_MP2_GPIO5_FCH_INT_STAT_MASK)

#define MP2_GPIO5_FCH_INT_DEFAULT      0x00000000

#define MP2_GPIO5_FCH_INT_GET_MP2_GPIO5_FCH_INT_EN(mp2_gpio5_fch_int) \
     ((mp2_gpio5_fch_int & MP2_GPIO5_FCH_INT_MP2_GPIO5_FCH_INT_EN_MASK) >> MP2_GPIO5_FCH_INT_MP2_GPIO5_FCH_INT_EN_SHIFT)
#define MP2_GPIO5_FCH_INT_GET_MP2_GPIO5_FCH_INT_STAT(mp2_gpio5_fch_int) \
     ((mp2_gpio5_fch_int & MP2_GPIO5_FCH_INT_MP2_GPIO5_FCH_INT_STAT_MASK) >> MP2_GPIO5_FCH_INT_MP2_GPIO5_FCH_INT_STAT_SHIFT)

#define MP2_GPIO5_FCH_INT_SET_MP2_GPIO5_FCH_INT_EN(mp2_gpio5_fch_int_reg, mp2_gpio5_fch_int_en) \
     mp2_gpio5_fch_int_reg = (mp2_gpio5_fch_int_reg & ~MP2_GPIO5_FCH_INT_MP2_GPIO5_FCH_INT_EN_MASK) | (mp2_gpio5_fch_int_en << MP2_GPIO5_FCH_INT_MP2_GPIO5_FCH_INT_EN_SHIFT)
#define MP2_GPIO5_FCH_INT_SET_MP2_GPIO5_FCH_INT_STAT(mp2_gpio5_fch_int_reg, mp2_gpio5_fch_int_stat) \
     mp2_gpio5_fch_int_reg = (mp2_gpio5_fch_int_reg & ~MP2_GPIO5_FCH_INT_MP2_GPIO5_FCH_INT_STAT_MASK) | (mp2_gpio5_fch_int_stat << MP2_GPIO5_FCH_INT_MP2_GPIO5_FCH_INT_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio5_fch_int_t {
          unsigned int mp2_gpio5_fch_int_en           : MP2_GPIO5_FCH_INT_MP2_GPIO5_FCH_INT_EN_SIZE;
          unsigned int mp2_gpio5_fch_int_stat         : MP2_GPIO5_FCH_INT_MP2_GPIO5_FCH_INT_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_gpio5_fch_int_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio5_fch_int_t {
          unsigned int                                : 29;
          unsigned int mp2_gpio5_fch_int_stat         : MP2_GPIO5_FCH_INT_MP2_GPIO5_FCH_INT_STAT_SIZE;
          unsigned int mp2_gpio5_fch_int_en           : MP2_GPIO5_FCH_INT_MP2_GPIO5_FCH_INT_EN_SIZE;
     } mp2_gpio5_fch_int_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio5_fch_int_t f;
} mp2_gpio5_fch_int_u;


/*
 * MP2_GPIO5_IO_STATUS struct
 */

#define MP2_GPIO5_IO_STATUS_REG_SIZE   32
#define MP2_GPIO5_IO_STATUS_MP_GPIO_INPUT_GPIO5_SIZE 1
#define MP2_GPIO5_IO_STATUS_MP_GPIO_OUTPUT_GPIO5_SIZE 1

#define MP2_GPIO5_IO_STATUS_MP_GPIO_INPUT_GPIO5_SHIFT 0
#define MP2_GPIO5_IO_STATUS_MP_GPIO_OUTPUT_GPIO5_SHIFT 1

#define MP2_GPIO5_IO_STATUS_MP_GPIO_INPUT_GPIO5_MASK 0x1
#define MP2_GPIO5_IO_STATUS_MP_GPIO_OUTPUT_GPIO5_MASK 0x2

#define MP2_GPIO5_IO_STATUS_MASK \
     (MP2_GPIO5_IO_STATUS_MP_GPIO_INPUT_GPIO5_MASK | \
      MP2_GPIO5_IO_STATUS_MP_GPIO_OUTPUT_GPIO5_MASK)

#define MP2_GPIO5_IO_STATUS_DEFAULT    0x00000000

#define MP2_GPIO5_IO_STATUS_GET_MP_GPIO_INPUT_GPIO5(mp2_gpio5_io_status) \
     ((mp2_gpio5_io_status & MP2_GPIO5_IO_STATUS_MP_GPIO_INPUT_GPIO5_MASK) >> MP2_GPIO5_IO_STATUS_MP_GPIO_INPUT_GPIO5_SHIFT)
#define MP2_GPIO5_IO_STATUS_GET_MP_GPIO_OUTPUT_GPIO5(mp2_gpio5_io_status) \
     ((mp2_gpio5_io_status & MP2_GPIO5_IO_STATUS_MP_GPIO_OUTPUT_GPIO5_MASK) >> MP2_GPIO5_IO_STATUS_MP_GPIO_OUTPUT_GPIO5_SHIFT)

#define MP2_GPIO5_IO_STATUS_SET_MP_GPIO_INPUT_GPIO5(mp2_gpio5_io_status_reg, mp_gpio_input_gpio5) \
     mp2_gpio5_io_status_reg = (mp2_gpio5_io_status_reg & ~MP2_GPIO5_IO_STATUS_MP_GPIO_INPUT_GPIO5_MASK) | (mp_gpio_input_gpio5 << MP2_GPIO5_IO_STATUS_MP_GPIO_INPUT_GPIO5_SHIFT)
#define MP2_GPIO5_IO_STATUS_SET_MP_GPIO_OUTPUT_GPIO5(mp2_gpio5_io_status_reg, mp_gpio_output_gpio5) \
     mp2_gpio5_io_status_reg = (mp2_gpio5_io_status_reg & ~MP2_GPIO5_IO_STATUS_MP_GPIO_OUTPUT_GPIO5_MASK) | (mp_gpio_output_gpio5 << MP2_GPIO5_IO_STATUS_MP_GPIO_OUTPUT_GPIO5_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_gpio5_io_status_t {
          unsigned int mp_gpio_input_gpio5            : MP2_GPIO5_IO_STATUS_MP_GPIO_INPUT_GPIO5_SIZE;
          unsigned int mp_gpio_output_gpio5           : MP2_GPIO5_IO_STATUS_MP_GPIO_OUTPUT_GPIO5_SIZE;
          unsigned int                                : 30;
     } mp2_gpio5_io_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_gpio5_io_status_t {
          unsigned int                                : 30;
          unsigned int mp_gpio_output_gpio5           : MP2_GPIO5_IO_STATUS_MP_GPIO_OUTPUT_GPIO5_SIZE;
          unsigned int mp_gpio_input_gpio5            : MP2_GPIO5_IO_STATUS_MP_GPIO_INPUT_GPIO5_SIZE;
     } mp2_gpio5_io_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_gpio5_io_status_t f;
} mp2_gpio5_io_status_u;


/*
 * MP2_I2C0_REG_OUTPUT struct
 */

#define MP2_I2C0_REG_OUTPUT_REG_SIZE   32
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Spare0_SIZE 1
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Spare1_SIZE 1
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_ResBiasEn_SIZE 1
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CompSel_SIZE 1
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_NG_SIZE 4
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_I2cRxSel_SIZE 2
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_PdEn0_SIZE 1
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_PdEn1_SIZE 1
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_DI2C0_SIZE 1
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_DI2C1_SIZE 1
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_FallSlewSel_SIZE 2
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Slewn_SIZE 1
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_SpikeRcEn_SIZE 1
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_SpikeRcSel_SIZE 1
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CSel0p9_SIZE 1
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CSel1p1_SIZE 1
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_RSel0p9_SIZE 1
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_RSel1p1_SIZE 1
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_BiasCrtEn_SIZE 1

#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Spare0_SHIFT 0
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Spare1_SHIFT 1
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_ResBiasEn_SHIFT 2
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CompSel_SHIFT 3
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_NG_SHIFT 4
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_I2cRxSel_SHIFT 8
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_PdEn0_SHIFT 10
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_PdEn1_SHIFT 11
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_DI2C0_SHIFT 12
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_DI2C1_SHIFT 13
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_FallSlewSel_SHIFT 14
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Slewn_SHIFT 16
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_SpikeRcEn_SHIFT 17
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_SpikeRcSel_SHIFT 18
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CSel0p9_SHIFT 19
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CSel1p1_SHIFT 20
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_RSel0p9_SHIFT 21
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_RSel1p1_SHIFT 22
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_BiasCrtEn_SHIFT 23

#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Spare0_MASK 0x1
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Spare1_MASK 0x2
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_ResBiasEn_MASK 0x4
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CompSel_MASK 0x8
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_NG_MASK 0xf0
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_I2cRxSel_MASK 0x300
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_PdEn0_MASK 0x400
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_PdEn1_MASK 0x800
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_DI2C0_MASK 0x1000
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_DI2C1_MASK 0x2000
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_FallSlewSel_MASK 0xc000
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Slewn_MASK 0x10000
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_SpikeRcEn_MASK 0x20000
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_SpikeRcSel_MASK 0x40000
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CSel0p9_MASK 0x80000
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CSel1p1_MASK 0x100000
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_RSel0p9_MASK 0x200000
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_RSel1p1_MASK 0x400000
#define MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_BiasCrtEn_MASK 0x800000

#define MP2_I2C0_REG_OUTPUT_MASK \
     (MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Spare0_MASK | \
      MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Spare1_MASK | \
      MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_ResBiasEn_MASK | \
      MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CompSel_MASK | \
      MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_NG_MASK | \
      MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_I2cRxSel_MASK | \
      MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_PdEn0_MASK | \
      MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_PdEn1_MASK | \
      MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_DI2C0_MASK | \
      MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_DI2C1_MASK | \
      MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_FallSlewSel_MASK | \
      MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Slewn_MASK | \
      MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_SpikeRcEn_MASK | \
      MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_SpikeRcSel_MASK | \
      MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CSel0p9_MASK | \
      MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CSel1p1_MASK | \
      MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_RSel0p9_MASK | \
      MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_RSel1p1_MASK | \
      MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_BiasCrtEn_MASK)

#define MP2_I2C0_REG_OUTPUT_DEFAULT    0x000003c0

#define MP2_I2C0_REG_OUTPUT_GET_MP_I2C0_OUTPUT_Spare0(mp2_i2c0_reg_output) \
     ((mp2_i2c0_reg_output & MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Spare0_MASK) >> MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Spare0_SHIFT)
#define MP2_I2C0_REG_OUTPUT_GET_MP_I2C0_OUTPUT_Spare1(mp2_i2c0_reg_output) \
     ((mp2_i2c0_reg_output & MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Spare1_MASK) >> MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Spare1_SHIFT)
#define MP2_I2C0_REG_OUTPUT_GET_MP_I2C0_OUTPUT_ResBiasEn(mp2_i2c0_reg_output) \
     ((mp2_i2c0_reg_output & MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_ResBiasEn_MASK) >> MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_ResBiasEn_SHIFT)
#define MP2_I2C0_REG_OUTPUT_GET_MP_I2C0_OUTPUT_CompSel(mp2_i2c0_reg_output) \
     ((mp2_i2c0_reg_output & MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CompSel_MASK) >> MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CompSel_SHIFT)
#define MP2_I2C0_REG_OUTPUT_GET_MP_I2C0_OUTPUT_NG(mp2_i2c0_reg_output) \
     ((mp2_i2c0_reg_output & MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_NG_MASK) >> MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_NG_SHIFT)
#define MP2_I2C0_REG_OUTPUT_GET_MP_I2C0_OUTPUT_I2cRxSel(mp2_i2c0_reg_output) \
     ((mp2_i2c0_reg_output & MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_I2cRxSel_MASK) >> MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_I2cRxSel_SHIFT)
#define MP2_I2C0_REG_OUTPUT_GET_MP_I2C0_OUTPUT_PdEn0(mp2_i2c0_reg_output) \
     ((mp2_i2c0_reg_output & MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_PdEn0_MASK) >> MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_PdEn0_SHIFT)
#define MP2_I2C0_REG_OUTPUT_GET_MP_I2C0_OUTPUT_PdEn1(mp2_i2c0_reg_output) \
     ((mp2_i2c0_reg_output & MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_PdEn1_MASK) >> MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_PdEn1_SHIFT)
#define MP2_I2C0_REG_OUTPUT_GET_MP_I2C0_OUTPUT_DI2C0(mp2_i2c0_reg_output) \
     ((mp2_i2c0_reg_output & MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_DI2C0_MASK) >> MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_DI2C0_SHIFT)
#define MP2_I2C0_REG_OUTPUT_GET_MP_I2C0_OUTPUT_DI2C1(mp2_i2c0_reg_output) \
     ((mp2_i2c0_reg_output & MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_DI2C1_MASK) >> MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_DI2C1_SHIFT)
#define MP2_I2C0_REG_OUTPUT_GET_MP_I2C0_OUTPUT_FallSlewSel(mp2_i2c0_reg_output) \
     ((mp2_i2c0_reg_output & MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_FallSlewSel_MASK) >> MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_FallSlewSel_SHIFT)
#define MP2_I2C0_REG_OUTPUT_GET_MP_I2C0_OUTPUT_Slewn(mp2_i2c0_reg_output) \
     ((mp2_i2c0_reg_output & MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Slewn_MASK) >> MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Slewn_SHIFT)
#define MP2_I2C0_REG_OUTPUT_GET_MP_I2C0_OUTPUT_SpikeRcEn(mp2_i2c0_reg_output) \
     ((mp2_i2c0_reg_output & MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_SpikeRcEn_MASK) >> MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_SpikeRcEn_SHIFT)
#define MP2_I2C0_REG_OUTPUT_GET_MP_I2C0_OUTPUT_SpikeRcSel(mp2_i2c0_reg_output) \
     ((mp2_i2c0_reg_output & MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_SpikeRcSel_MASK) >> MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_SpikeRcSel_SHIFT)
#define MP2_I2C0_REG_OUTPUT_GET_MP_I2C0_OUTPUT_CSel0p9(mp2_i2c0_reg_output) \
     ((mp2_i2c0_reg_output & MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CSel0p9_MASK) >> MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CSel0p9_SHIFT)
#define MP2_I2C0_REG_OUTPUT_GET_MP_I2C0_OUTPUT_CSel1p1(mp2_i2c0_reg_output) \
     ((mp2_i2c0_reg_output & MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CSel1p1_MASK) >> MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CSel1p1_SHIFT)
#define MP2_I2C0_REG_OUTPUT_GET_MP_I2C0_OUTPUT_RSel0p9(mp2_i2c0_reg_output) \
     ((mp2_i2c0_reg_output & MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_RSel0p9_MASK) >> MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_RSel0p9_SHIFT)
#define MP2_I2C0_REG_OUTPUT_GET_MP_I2C0_OUTPUT_RSel1p1(mp2_i2c0_reg_output) \
     ((mp2_i2c0_reg_output & MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_RSel1p1_MASK) >> MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_RSel1p1_SHIFT)
#define MP2_I2C0_REG_OUTPUT_GET_MP_I2C0_OUTPUT_BiasCrtEn(mp2_i2c0_reg_output) \
     ((mp2_i2c0_reg_output & MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_BiasCrtEn_MASK) >> MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_BiasCrtEn_SHIFT)

#define MP2_I2C0_REG_OUTPUT_SET_MP_I2C0_OUTPUT_Spare0(mp2_i2c0_reg_output_reg, mp_i2c0_output_spare0) \
     mp2_i2c0_reg_output_reg = (mp2_i2c0_reg_output_reg & ~MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Spare0_MASK) | (mp_i2c0_output_spare0 << MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Spare0_SHIFT)
#define MP2_I2C0_REG_OUTPUT_SET_MP_I2C0_OUTPUT_Spare1(mp2_i2c0_reg_output_reg, mp_i2c0_output_spare1) \
     mp2_i2c0_reg_output_reg = (mp2_i2c0_reg_output_reg & ~MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Spare1_MASK) | (mp_i2c0_output_spare1 << MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Spare1_SHIFT)
#define MP2_I2C0_REG_OUTPUT_SET_MP_I2C0_OUTPUT_ResBiasEn(mp2_i2c0_reg_output_reg, mp_i2c0_output_resbiasen) \
     mp2_i2c0_reg_output_reg = (mp2_i2c0_reg_output_reg & ~MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_ResBiasEn_MASK) | (mp_i2c0_output_resbiasen << MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_ResBiasEn_SHIFT)
#define MP2_I2C0_REG_OUTPUT_SET_MP_I2C0_OUTPUT_CompSel(mp2_i2c0_reg_output_reg, mp_i2c0_output_compsel) \
     mp2_i2c0_reg_output_reg = (mp2_i2c0_reg_output_reg & ~MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CompSel_MASK) | (mp_i2c0_output_compsel << MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CompSel_SHIFT)
#define MP2_I2C0_REG_OUTPUT_SET_MP_I2C0_OUTPUT_NG(mp2_i2c0_reg_output_reg, mp_i2c0_output_ng) \
     mp2_i2c0_reg_output_reg = (mp2_i2c0_reg_output_reg & ~MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_NG_MASK) | (mp_i2c0_output_ng << MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_NG_SHIFT)
#define MP2_I2C0_REG_OUTPUT_SET_MP_I2C0_OUTPUT_I2cRxSel(mp2_i2c0_reg_output_reg, mp_i2c0_output_i2crxsel) \
     mp2_i2c0_reg_output_reg = (mp2_i2c0_reg_output_reg & ~MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_I2cRxSel_MASK) | (mp_i2c0_output_i2crxsel << MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_I2cRxSel_SHIFT)
#define MP2_I2C0_REG_OUTPUT_SET_MP_I2C0_OUTPUT_PdEn0(mp2_i2c0_reg_output_reg, mp_i2c0_output_pden0) \
     mp2_i2c0_reg_output_reg = (mp2_i2c0_reg_output_reg & ~MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_PdEn0_MASK) | (mp_i2c0_output_pden0 << MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_PdEn0_SHIFT)
#define MP2_I2C0_REG_OUTPUT_SET_MP_I2C0_OUTPUT_PdEn1(mp2_i2c0_reg_output_reg, mp_i2c0_output_pden1) \
     mp2_i2c0_reg_output_reg = (mp2_i2c0_reg_output_reg & ~MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_PdEn1_MASK) | (mp_i2c0_output_pden1 << MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_PdEn1_SHIFT)
#define MP2_I2C0_REG_OUTPUT_SET_MP_I2C0_OUTPUT_DI2C0(mp2_i2c0_reg_output_reg, mp_i2c0_output_di2c0) \
     mp2_i2c0_reg_output_reg = (mp2_i2c0_reg_output_reg & ~MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_DI2C0_MASK) | (mp_i2c0_output_di2c0 << MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_DI2C0_SHIFT)
#define MP2_I2C0_REG_OUTPUT_SET_MP_I2C0_OUTPUT_DI2C1(mp2_i2c0_reg_output_reg, mp_i2c0_output_di2c1) \
     mp2_i2c0_reg_output_reg = (mp2_i2c0_reg_output_reg & ~MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_DI2C1_MASK) | (mp_i2c0_output_di2c1 << MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_DI2C1_SHIFT)
#define MP2_I2C0_REG_OUTPUT_SET_MP_I2C0_OUTPUT_FallSlewSel(mp2_i2c0_reg_output_reg, mp_i2c0_output_fallslewsel) \
     mp2_i2c0_reg_output_reg = (mp2_i2c0_reg_output_reg & ~MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_FallSlewSel_MASK) | (mp_i2c0_output_fallslewsel << MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_FallSlewSel_SHIFT)
#define MP2_I2C0_REG_OUTPUT_SET_MP_I2C0_OUTPUT_Slewn(mp2_i2c0_reg_output_reg, mp_i2c0_output_slewn) \
     mp2_i2c0_reg_output_reg = (mp2_i2c0_reg_output_reg & ~MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Slewn_MASK) | (mp_i2c0_output_slewn << MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Slewn_SHIFT)
#define MP2_I2C0_REG_OUTPUT_SET_MP_I2C0_OUTPUT_SpikeRcEn(mp2_i2c0_reg_output_reg, mp_i2c0_output_spikercen) \
     mp2_i2c0_reg_output_reg = (mp2_i2c0_reg_output_reg & ~MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_SpikeRcEn_MASK) | (mp_i2c0_output_spikercen << MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_SpikeRcEn_SHIFT)
#define MP2_I2C0_REG_OUTPUT_SET_MP_I2C0_OUTPUT_SpikeRcSel(mp2_i2c0_reg_output_reg, mp_i2c0_output_spikercsel) \
     mp2_i2c0_reg_output_reg = (mp2_i2c0_reg_output_reg & ~MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_SpikeRcSel_MASK) | (mp_i2c0_output_spikercsel << MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_SpikeRcSel_SHIFT)
#define MP2_I2C0_REG_OUTPUT_SET_MP_I2C0_OUTPUT_CSel0p9(mp2_i2c0_reg_output_reg, mp_i2c0_output_csel0p9) \
     mp2_i2c0_reg_output_reg = (mp2_i2c0_reg_output_reg & ~MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CSel0p9_MASK) | (mp_i2c0_output_csel0p9 << MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CSel0p9_SHIFT)
#define MP2_I2C0_REG_OUTPUT_SET_MP_I2C0_OUTPUT_CSel1p1(mp2_i2c0_reg_output_reg, mp_i2c0_output_csel1p1) \
     mp2_i2c0_reg_output_reg = (mp2_i2c0_reg_output_reg & ~MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CSel1p1_MASK) | (mp_i2c0_output_csel1p1 << MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CSel1p1_SHIFT)
#define MP2_I2C0_REG_OUTPUT_SET_MP_I2C0_OUTPUT_RSel0p9(mp2_i2c0_reg_output_reg, mp_i2c0_output_rsel0p9) \
     mp2_i2c0_reg_output_reg = (mp2_i2c0_reg_output_reg & ~MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_RSel0p9_MASK) | (mp_i2c0_output_rsel0p9 << MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_RSel0p9_SHIFT)
#define MP2_I2C0_REG_OUTPUT_SET_MP_I2C0_OUTPUT_RSel1p1(mp2_i2c0_reg_output_reg, mp_i2c0_output_rsel1p1) \
     mp2_i2c0_reg_output_reg = (mp2_i2c0_reg_output_reg & ~MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_RSel1p1_MASK) | (mp_i2c0_output_rsel1p1 << MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_RSel1p1_SHIFT)
#define MP2_I2C0_REG_OUTPUT_SET_MP_I2C0_OUTPUT_BiasCrtEn(mp2_i2c0_reg_output_reg, mp_i2c0_output_biascrten) \
     mp2_i2c0_reg_output_reg = (mp2_i2c0_reg_output_reg & ~MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_BiasCrtEn_MASK) | (mp_i2c0_output_biascrten << MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_BiasCrtEn_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_reg_output_t {
          unsigned int mp_i2c0_output_spare0          : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Spare0_SIZE;
          unsigned int mp_i2c0_output_spare1          : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Spare1_SIZE;
          unsigned int mp_i2c0_output_resbiasen       : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_ResBiasEn_SIZE;
          unsigned int mp_i2c0_output_compsel         : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CompSel_SIZE;
          unsigned int mp_i2c0_output_ng              : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_NG_SIZE;
          unsigned int mp_i2c0_output_i2crxsel        : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_I2cRxSel_SIZE;
          unsigned int mp_i2c0_output_pden0           : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_PdEn0_SIZE;
          unsigned int mp_i2c0_output_pden1           : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_PdEn1_SIZE;
          unsigned int mp_i2c0_output_di2c0           : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_DI2C0_SIZE;
          unsigned int mp_i2c0_output_di2c1           : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_DI2C1_SIZE;
          unsigned int mp_i2c0_output_fallslewsel     : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_FallSlewSel_SIZE;
          unsigned int mp_i2c0_output_slewn           : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Slewn_SIZE;
          unsigned int mp_i2c0_output_spikercen       : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_SpikeRcEn_SIZE;
          unsigned int mp_i2c0_output_spikercsel      : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_SpikeRcSel_SIZE;
          unsigned int mp_i2c0_output_csel0p9         : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CSel0p9_SIZE;
          unsigned int mp_i2c0_output_csel1p1         : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CSel1p1_SIZE;
          unsigned int mp_i2c0_output_rsel0p9         : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_RSel0p9_SIZE;
          unsigned int mp_i2c0_output_rsel1p1         : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_RSel1p1_SIZE;
          unsigned int mp_i2c0_output_biascrten       : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_BiasCrtEn_SIZE;
          unsigned int                                : 8;
     } mp2_i2c0_reg_output_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_reg_output_t {
          unsigned int                                : 8;
          unsigned int mp_i2c0_output_biascrten       : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_BiasCrtEn_SIZE;
          unsigned int mp_i2c0_output_rsel1p1         : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_RSel1p1_SIZE;
          unsigned int mp_i2c0_output_rsel0p9         : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_RSel0p9_SIZE;
          unsigned int mp_i2c0_output_csel1p1         : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CSel1p1_SIZE;
          unsigned int mp_i2c0_output_csel0p9         : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CSel0p9_SIZE;
          unsigned int mp_i2c0_output_spikercsel      : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_SpikeRcSel_SIZE;
          unsigned int mp_i2c0_output_spikercen       : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_SpikeRcEn_SIZE;
          unsigned int mp_i2c0_output_slewn           : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Slewn_SIZE;
          unsigned int mp_i2c0_output_fallslewsel     : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_FallSlewSel_SIZE;
          unsigned int mp_i2c0_output_di2c1           : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_DI2C1_SIZE;
          unsigned int mp_i2c0_output_di2c0           : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_DI2C0_SIZE;
          unsigned int mp_i2c0_output_pden1           : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_PdEn1_SIZE;
          unsigned int mp_i2c0_output_pden0           : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_PdEn0_SIZE;
          unsigned int mp_i2c0_output_i2crxsel        : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_I2cRxSel_SIZE;
          unsigned int mp_i2c0_output_ng              : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_NG_SIZE;
          unsigned int mp_i2c0_output_compsel         : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_CompSel_SIZE;
          unsigned int mp_i2c0_output_resbiasen       : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_ResBiasEn_SIZE;
          unsigned int mp_i2c0_output_spare1          : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Spare1_SIZE;
          unsigned int mp_i2c0_output_spare0          : MP2_I2C0_REG_OUTPUT_MP_I2C0_OUTPUT_Spare0_SIZE;
     } mp2_i2c0_reg_output_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_reg_output_t f;
} mp2_i2c0_reg_output_u;


/*
 * MP2_I2C0_OUTPUT_SEL struct
 */

#define MP2_I2C0_OUTPUT_SEL_REG_SIZE   32
#define MP2_I2C0_OUTPUT_SEL_MP_I2C0_OUTPUT_SEL_DI2C0_SIZE 1
#define MP2_I2C0_OUTPUT_SEL_MP_I2C0_OUTPUT_SEL_DI2C1_SIZE 1

#define MP2_I2C0_OUTPUT_SEL_MP_I2C0_OUTPUT_SEL_DI2C0_SHIFT 0
#define MP2_I2C0_OUTPUT_SEL_MP_I2C0_OUTPUT_SEL_DI2C1_SHIFT 1

#define MP2_I2C0_OUTPUT_SEL_MP_I2C0_OUTPUT_SEL_DI2C0_MASK 0x1
#define MP2_I2C0_OUTPUT_SEL_MP_I2C0_OUTPUT_SEL_DI2C1_MASK 0x2

#define MP2_I2C0_OUTPUT_SEL_MASK \
     (MP2_I2C0_OUTPUT_SEL_MP_I2C0_OUTPUT_SEL_DI2C0_MASK | \
      MP2_I2C0_OUTPUT_SEL_MP_I2C0_OUTPUT_SEL_DI2C1_MASK)

#define MP2_I2C0_OUTPUT_SEL_DEFAULT    0x00000000

#define MP2_I2C0_OUTPUT_SEL_GET_MP_I2C0_OUTPUT_SEL_DI2C0(mp2_i2c0_output_sel) \
     ((mp2_i2c0_output_sel & MP2_I2C0_OUTPUT_SEL_MP_I2C0_OUTPUT_SEL_DI2C0_MASK) >> MP2_I2C0_OUTPUT_SEL_MP_I2C0_OUTPUT_SEL_DI2C0_SHIFT)
#define MP2_I2C0_OUTPUT_SEL_GET_MP_I2C0_OUTPUT_SEL_DI2C1(mp2_i2c0_output_sel) \
     ((mp2_i2c0_output_sel & MP2_I2C0_OUTPUT_SEL_MP_I2C0_OUTPUT_SEL_DI2C1_MASK) >> MP2_I2C0_OUTPUT_SEL_MP_I2C0_OUTPUT_SEL_DI2C1_SHIFT)

#define MP2_I2C0_OUTPUT_SEL_SET_MP_I2C0_OUTPUT_SEL_DI2C0(mp2_i2c0_output_sel_reg, mp_i2c0_output_sel_di2c0) \
     mp2_i2c0_output_sel_reg = (mp2_i2c0_output_sel_reg & ~MP2_I2C0_OUTPUT_SEL_MP_I2C0_OUTPUT_SEL_DI2C0_MASK) | (mp_i2c0_output_sel_di2c0 << MP2_I2C0_OUTPUT_SEL_MP_I2C0_OUTPUT_SEL_DI2C0_SHIFT)
#define MP2_I2C0_OUTPUT_SEL_SET_MP_I2C0_OUTPUT_SEL_DI2C1(mp2_i2c0_output_sel_reg, mp_i2c0_output_sel_di2c1) \
     mp2_i2c0_output_sel_reg = (mp2_i2c0_output_sel_reg & ~MP2_I2C0_OUTPUT_SEL_MP_I2C0_OUTPUT_SEL_DI2C1_MASK) | (mp_i2c0_output_sel_di2c1 << MP2_I2C0_OUTPUT_SEL_MP_I2C0_OUTPUT_SEL_DI2C1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_output_sel_t {
          unsigned int mp_i2c0_output_sel_di2c0       : MP2_I2C0_OUTPUT_SEL_MP_I2C0_OUTPUT_SEL_DI2C0_SIZE;
          unsigned int mp_i2c0_output_sel_di2c1       : MP2_I2C0_OUTPUT_SEL_MP_I2C0_OUTPUT_SEL_DI2C1_SIZE;
          unsigned int                                : 30;
     } mp2_i2c0_output_sel_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_output_sel_t {
          unsigned int                                : 30;
          unsigned int mp_i2c0_output_sel_di2c1       : MP2_I2C0_OUTPUT_SEL_MP_I2C0_OUTPUT_SEL_DI2C1_SIZE;
          unsigned int mp_i2c0_output_sel_di2c0       : MP2_I2C0_OUTPUT_SEL_MP_I2C0_OUTPUT_SEL_DI2C0_SIZE;
     } mp2_i2c0_output_sel_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_output_sel_t f;
} mp2_i2c0_output_sel_u;


/*
 * MP2_I2C0_OUTPUT_VAL struct
 */

#define MP2_I2C0_OUTPUT_VAL_REG_SIZE   32
#define MP2_I2C0_OUTPUT_VAL_MP_I2C0_OUTPUT_VAL_DI2C0_SIZE 1
#define MP2_I2C0_OUTPUT_VAL_MP_I2C0_OUTPUT_VAL_DI2C1_SIZE 1

#define MP2_I2C0_OUTPUT_VAL_MP_I2C0_OUTPUT_VAL_DI2C0_SHIFT 0
#define MP2_I2C0_OUTPUT_VAL_MP_I2C0_OUTPUT_VAL_DI2C1_SHIFT 1

#define MP2_I2C0_OUTPUT_VAL_MP_I2C0_OUTPUT_VAL_DI2C0_MASK 0x1
#define MP2_I2C0_OUTPUT_VAL_MP_I2C0_OUTPUT_VAL_DI2C1_MASK 0x2

#define MP2_I2C0_OUTPUT_VAL_MASK \
     (MP2_I2C0_OUTPUT_VAL_MP_I2C0_OUTPUT_VAL_DI2C0_MASK | \
      MP2_I2C0_OUTPUT_VAL_MP_I2C0_OUTPUT_VAL_DI2C1_MASK)

#define MP2_I2C0_OUTPUT_VAL_DEFAULT    0x00000000

#define MP2_I2C0_OUTPUT_VAL_GET_MP_I2C0_OUTPUT_VAL_DI2C0(mp2_i2c0_output_val) \
     ((mp2_i2c0_output_val & MP2_I2C0_OUTPUT_VAL_MP_I2C0_OUTPUT_VAL_DI2C0_MASK) >> MP2_I2C0_OUTPUT_VAL_MP_I2C0_OUTPUT_VAL_DI2C0_SHIFT)
#define MP2_I2C0_OUTPUT_VAL_GET_MP_I2C0_OUTPUT_VAL_DI2C1(mp2_i2c0_output_val) \
     ((mp2_i2c0_output_val & MP2_I2C0_OUTPUT_VAL_MP_I2C0_OUTPUT_VAL_DI2C1_MASK) >> MP2_I2C0_OUTPUT_VAL_MP_I2C0_OUTPUT_VAL_DI2C1_SHIFT)

#define MP2_I2C0_OUTPUT_VAL_SET_MP_I2C0_OUTPUT_VAL_DI2C0(mp2_i2c0_output_val_reg, mp_i2c0_output_val_di2c0) \
     mp2_i2c0_output_val_reg = (mp2_i2c0_output_val_reg & ~MP2_I2C0_OUTPUT_VAL_MP_I2C0_OUTPUT_VAL_DI2C0_MASK) | (mp_i2c0_output_val_di2c0 << MP2_I2C0_OUTPUT_VAL_MP_I2C0_OUTPUT_VAL_DI2C0_SHIFT)
#define MP2_I2C0_OUTPUT_VAL_SET_MP_I2C0_OUTPUT_VAL_DI2C1(mp2_i2c0_output_val_reg, mp_i2c0_output_val_di2c1) \
     mp2_i2c0_output_val_reg = (mp2_i2c0_output_val_reg & ~MP2_I2C0_OUTPUT_VAL_MP_I2C0_OUTPUT_VAL_DI2C1_MASK) | (mp_i2c0_output_val_di2c1 << MP2_I2C0_OUTPUT_VAL_MP_I2C0_OUTPUT_VAL_DI2C1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_output_val_t {
          unsigned int mp_i2c0_output_val_di2c0       : MP2_I2C0_OUTPUT_VAL_MP_I2C0_OUTPUT_VAL_DI2C0_SIZE;
          unsigned int mp_i2c0_output_val_di2c1       : MP2_I2C0_OUTPUT_VAL_MP_I2C0_OUTPUT_VAL_DI2C1_SIZE;
          unsigned int                                : 30;
     } mp2_i2c0_output_val_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_output_val_t {
          unsigned int                                : 30;
          unsigned int mp_i2c0_output_val_di2c1       : MP2_I2C0_OUTPUT_VAL_MP_I2C0_OUTPUT_VAL_DI2C1_SIZE;
          unsigned int mp_i2c0_output_val_di2c0       : MP2_I2C0_OUTPUT_VAL_MP_I2C0_OUTPUT_VAL_DI2C0_SIZE;
     } mp2_i2c0_output_val_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_output_val_t f;
} mp2_i2c0_output_val_u;


/*
 * MP2_I2C1_REG_OUTPUT struct
 */

#define MP2_I2C1_REG_OUTPUT_REG_SIZE   32
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Spare0_SIZE 1
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Spare1_SIZE 1
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_ResBiasEn_SIZE 1
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CompSel_SIZE 1
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_NG_SIZE 4
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_I2cRxSel_SIZE 2
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_PdEn0_SIZE 1
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_PdEn1_SIZE 1
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_DI2C0_SIZE 1
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_DI2C1_SIZE 1
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_FallSlewSel_SIZE 2
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Slewn_SIZE 1
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_SpikeRcEn_SIZE 1
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_SpikeRcSel_SIZE 1
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CSel0p9_SIZE 1
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CSel1p1_SIZE 1
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_RSel0p9_SIZE 1
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_RSel1p1_SIZE 1
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_BiasCrtEn_SIZE 1

#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Spare0_SHIFT 0
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Spare1_SHIFT 1
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_ResBiasEn_SHIFT 2
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CompSel_SHIFT 3
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_NG_SHIFT 4
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_I2cRxSel_SHIFT 8
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_PdEn0_SHIFT 10
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_PdEn1_SHIFT 11
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_DI2C0_SHIFT 12
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_DI2C1_SHIFT 13
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_FallSlewSel_SHIFT 14
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Slewn_SHIFT 16
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_SpikeRcEn_SHIFT 17
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_SpikeRcSel_SHIFT 18
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CSel0p9_SHIFT 19
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CSel1p1_SHIFT 20
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_RSel0p9_SHIFT 21
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_RSel1p1_SHIFT 22
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_BiasCrtEn_SHIFT 23

#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Spare0_MASK 0x1
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Spare1_MASK 0x2
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_ResBiasEn_MASK 0x4
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CompSel_MASK 0x8
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_NG_MASK 0xf0
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_I2cRxSel_MASK 0x300
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_PdEn0_MASK 0x400
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_PdEn1_MASK 0x800
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_DI2C0_MASK 0x1000
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_DI2C1_MASK 0x2000
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_FallSlewSel_MASK 0xc000
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Slewn_MASK 0x10000
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_SpikeRcEn_MASK 0x20000
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_SpikeRcSel_MASK 0x40000
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CSel0p9_MASK 0x80000
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CSel1p1_MASK 0x100000
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_RSel0p9_MASK 0x200000
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_RSel1p1_MASK 0x400000
#define MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_BiasCrtEn_MASK 0x800000

#define MP2_I2C1_REG_OUTPUT_MASK \
     (MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Spare0_MASK | \
      MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Spare1_MASK | \
      MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_ResBiasEn_MASK | \
      MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CompSel_MASK | \
      MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_NG_MASK | \
      MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_I2cRxSel_MASK | \
      MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_PdEn0_MASK | \
      MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_PdEn1_MASK | \
      MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_DI2C0_MASK | \
      MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_DI2C1_MASK | \
      MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_FallSlewSel_MASK | \
      MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Slewn_MASK | \
      MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_SpikeRcEn_MASK | \
      MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_SpikeRcSel_MASK | \
      MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CSel0p9_MASK | \
      MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CSel1p1_MASK | \
      MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_RSel0p9_MASK | \
      MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_RSel1p1_MASK | \
      MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_BiasCrtEn_MASK)

#define MP2_I2C1_REG_OUTPUT_DEFAULT    0x000003c0

#define MP2_I2C1_REG_OUTPUT_GET_MP_I2C1_OUTPUT_Spare0(mp2_i2c1_reg_output) \
     ((mp2_i2c1_reg_output & MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Spare0_MASK) >> MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Spare0_SHIFT)
#define MP2_I2C1_REG_OUTPUT_GET_MP_I2C1_OUTPUT_Spare1(mp2_i2c1_reg_output) \
     ((mp2_i2c1_reg_output & MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Spare1_MASK) >> MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Spare1_SHIFT)
#define MP2_I2C1_REG_OUTPUT_GET_MP_I2C1_OUTPUT_ResBiasEn(mp2_i2c1_reg_output) \
     ((mp2_i2c1_reg_output & MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_ResBiasEn_MASK) >> MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_ResBiasEn_SHIFT)
#define MP2_I2C1_REG_OUTPUT_GET_MP_I2C1_OUTPUT_CompSel(mp2_i2c1_reg_output) \
     ((mp2_i2c1_reg_output & MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CompSel_MASK) >> MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CompSel_SHIFT)
#define MP2_I2C1_REG_OUTPUT_GET_MP_I2C1_OUTPUT_NG(mp2_i2c1_reg_output) \
     ((mp2_i2c1_reg_output & MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_NG_MASK) >> MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_NG_SHIFT)
#define MP2_I2C1_REG_OUTPUT_GET_MP_I2C1_OUTPUT_I2cRxSel(mp2_i2c1_reg_output) \
     ((mp2_i2c1_reg_output & MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_I2cRxSel_MASK) >> MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_I2cRxSel_SHIFT)
#define MP2_I2C1_REG_OUTPUT_GET_MP_I2C1_OUTPUT_PdEn0(mp2_i2c1_reg_output) \
     ((mp2_i2c1_reg_output & MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_PdEn0_MASK) >> MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_PdEn0_SHIFT)
#define MP2_I2C1_REG_OUTPUT_GET_MP_I2C1_OUTPUT_PdEn1(mp2_i2c1_reg_output) \
     ((mp2_i2c1_reg_output & MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_PdEn1_MASK) >> MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_PdEn1_SHIFT)
#define MP2_I2C1_REG_OUTPUT_GET_MP_I2C1_OUTPUT_DI2C0(mp2_i2c1_reg_output) \
     ((mp2_i2c1_reg_output & MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_DI2C0_MASK) >> MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_DI2C0_SHIFT)
#define MP2_I2C1_REG_OUTPUT_GET_MP_I2C1_OUTPUT_DI2C1(mp2_i2c1_reg_output) \
     ((mp2_i2c1_reg_output & MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_DI2C1_MASK) >> MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_DI2C1_SHIFT)
#define MP2_I2C1_REG_OUTPUT_GET_MP_I2C1_OUTPUT_FallSlewSel(mp2_i2c1_reg_output) \
     ((mp2_i2c1_reg_output & MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_FallSlewSel_MASK) >> MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_FallSlewSel_SHIFT)
#define MP2_I2C1_REG_OUTPUT_GET_MP_I2C1_OUTPUT_Slewn(mp2_i2c1_reg_output) \
     ((mp2_i2c1_reg_output & MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Slewn_MASK) >> MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Slewn_SHIFT)
#define MP2_I2C1_REG_OUTPUT_GET_MP_I2C1_OUTPUT_SpikeRcEn(mp2_i2c1_reg_output) \
     ((mp2_i2c1_reg_output & MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_SpikeRcEn_MASK) >> MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_SpikeRcEn_SHIFT)
#define MP2_I2C1_REG_OUTPUT_GET_MP_I2C1_OUTPUT_SpikeRcSel(mp2_i2c1_reg_output) \
     ((mp2_i2c1_reg_output & MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_SpikeRcSel_MASK) >> MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_SpikeRcSel_SHIFT)
#define MP2_I2C1_REG_OUTPUT_GET_MP_I2C1_OUTPUT_CSel0p9(mp2_i2c1_reg_output) \
     ((mp2_i2c1_reg_output & MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CSel0p9_MASK) >> MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CSel0p9_SHIFT)
#define MP2_I2C1_REG_OUTPUT_GET_MP_I2C1_OUTPUT_CSel1p1(mp2_i2c1_reg_output) \
     ((mp2_i2c1_reg_output & MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CSel1p1_MASK) >> MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CSel1p1_SHIFT)
#define MP2_I2C1_REG_OUTPUT_GET_MP_I2C1_OUTPUT_RSel0p9(mp2_i2c1_reg_output) \
     ((mp2_i2c1_reg_output & MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_RSel0p9_MASK) >> MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_RSel0p9_SHIFT)
#define MP2_I2C1_REG_OUTPUT_GET_MP_I2C1_OUTPUT_RSel1p1(mp2_i2c1_reg_output) \
     ((mp2_i2c1_reg_output & MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_RSel1p1_MASK) >> MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_RSel1p1_SHIFT)
#define MP2_I2C1_REG_OUTPUT_GET_MP_I2C1_OUTPUT_BiasCrtEn(mp2_i2c1_reg_output) \
     ((mp2_i2c1_reg_output & MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_BiasCrtEn_MASK) >> MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_BiasCrtEn_SHIFT)

#define MP2_I2C1_REG_OUTPUT_SET_MP_I2C1_OUTPUT_Spare0(mp2_i2c1_reg_output_reg, mp_i2c1_output_spare0) \
     mp2_i2c1_reg_output_reg = (mp2_i2c1_reg_output_reg & ~MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Spare0_MASK) | (mp_i2c1_output_spare0 << MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Spare0_SHIFT)
#define MP2_I2C1_REG_OUTPUT_SET_MP_I2C1_OUTPUT_Spare1(mp2_i2c1_reg_output_reg, mp_i2c1_output_spare1) \
     mp2_i2c1_reg_output_reg = (mp2_i2c1_reg_output_reg & ~MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Spare1_MASK) | (mp_i2c1_output_spare1 << MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Spare1_SHIFT)
#define MP2_I2C1_REG_OUTPUT_SET_MP_I2C1_OUTPUT_ResBiasEn(mp2_i2c1_reg_output_reg, mp_i2c1_output_resbiasen) \
     mp2_i2c1_reg_output_reg = (mp2_i2c1_reg_output_reg & ~MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_ResBiasEn_MASK) | (mp_i2c1_output_resbiasen << MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_ResBiasEn_SHIFT)
#define MP2_I2C1_REG_OUTPUT_SET_MP_I2C1_OUTPUT_CompSel(mp2_i2c1_reg_output_reg, mp_i2c1_output_compsel) \
     mp2_i2c1_reg_output_reg = (mp2_i2c1_reg_output_reg & ~MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CompSel_MASK) | (mp_i2c1_output_compsel << MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CompSel_SHIFT)
#define MP2_I2C1_REG_OUTPUT_SET_MP_I2C1_OUTPUT_NG(mp2_i2c1_reg_output_reg, mp_i2c1_output_ng) \
     mp2_i2c1_reg_output_reg = (mp2_i2c1_reg_output_reg & ~MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_NG_MASK) | (mp_i2c1_output_ng << MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_NG_SHIFT)
#define MP2_I2C1_REG_OUTPUT_SET_MP_I2C1_OUTPUT_I2cRxSel(mp2_i2c1_reg_output_reg, mp_i2c1_output_i2crxsel) \
     mp2_i2c1_reg_output_reg = (mp2_i2c1_reg_output_reg & ~MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_I2cRxSel_MASK) | (mp_i2c1_output_i2crxsel << MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_I2cRxSel_SHIFT)
#define MP2_I2C1_REG_OUTPUT_SET_MP_I2C1_OUTPUT_PdEn0(mp2_i2c1_reg_output_reg, mp_i2c1_output_pden0) \
     mp2_i2c1_reg_output_reg = (mp2_i2c1_reg_output_reg & ~MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_PdEn0_MASK) | (mp_i2c1_output_pden0 << MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_PdEn0_SHIFT)
#define MP2_I2C1_REG_OUTPUT_SET_MP_I2C1_OUTPUT_PdEn1(mp2_i2c1_reg_output_reg, mp_i2c1_output_pden1) \
     mp2_i2c1_reg_output_reg = (mp2_i2c1_reg_output_reg & ~MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_PdEn1_MASK) | (mp_i2c1_output_pden1 << MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_PdEn1_SHIFT)
#define MP2_I2C1_REG_OUTPUT_SET_MP_I2C1_OUTPUT_DI2C0(mp2_i2c1_reg_output_reg, mp_i2c1_output_di2c0) \
     mp2_i2c1_reg_output_reg = (mp2_i2c1_reg_output_reg & ~MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_DI2C0_MASK) | (mp_i2c1_output_di2c0 << MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_DI2C0_SHIFT)
#define MP2_I2C1_REG_OUTPUT_SET_MP_I2C1_OUTPUT_DI2C1(mp2_i2c1_reg_output_reg, mp_i2c1_output_di2c1) \
     mp2_i2c1_reg_output_reg = (mp2_i2c1_reg_output_reg & ~MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_DI2C1_MASK) | (mp_i2c1_output_di2c1 << MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_DI2C1_SHIFT)
#define MP2_I2C1_REG_OUTPUT_SET_MP_I2C1_OUTPUT_FallSlewSel(mp2_i2c1_reg_output_reg, mp_i2c1_output_fallslewsel) \
     mp2_i2c1_reg_output_reg = (mp2_i2c1_reg_output_reg & ~MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_FallSlewSel_MASK) | (mp_i2c1_output_fallslewsel << MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_FallSlewSel_SHIFT)
#define MP2_I2C1_REG_OUTPUT_SET_MP_I2C1_OUTPUT_Slewn(mp2_i2c1_reg_output_reg, mp_i2c1_output_slewn) \
     mp2_i2c1_reg_output_reg = (mp2_i2c1_reg_output_reg & ~MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Slewn_MASK) | (mp_i2c1_output_slewn << MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Slewn_SHIFT)
#define MP2_I2C1_REG_OUTPUT_SET_MP_I2C1_OUTPUT_SpikeRcEn(mp2_i2c1_reg_output_reg, mp_i2c1_output_spikercen) \
     mp2_i2c1_reg_output_reg = (mp2_i2c1_reg_output_reg & ~MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_SpikeRcEn_MASK) | (mp_i2c1_output_spikercen << MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_SpikeRcEn_SHIFT)
#define MP2_I2C1_REG_OUTPUT_SET_MP_I2C1_OUTPUT_SpikeRcSel(mp2_i2c1_reg_output_reg, mp_i2c1_output_spikercsel) \
     mp2_i2c1_reg_output_reg = (mp2_i2c1_reg_output_reg & ~MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_SpikeRcSel_MASK) | (mp_i2c1_output_spikercsel << MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_SpikeRcSel_SHIFT)
#define MP2_I2C1_REG_OUTPUT_SET_MP_I2C1_OUTPUT_CSel0p9(mp2_i2c1_reg_output_reg, mp_i2c1_output_csel0p9) \
     mp2_i2c1_reg_output_reg = (mp2_i2c1_reg_output_reg & ~MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CSel0p9_MASK) | (mp_i2c1_output_csel0p9 << MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CSel0p9_SHIFT)
#define MP2_I2C1_REG_OUTPUT_SET_MP_I2C1_OUTPUT_CSel1p1(mp2_i2c1_reg_output_reg, mp_i2c1_output_csel1p1) \
     mp2_i2c1_reg_output_reg = (mp2_i2c1_reg_output_reg & ~MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CSel1p1_MASK) | (mp_i2c1_output_csel1p1 << MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CSel1p1_SHIFT)
#define MP2_I2C1_REG_OUTPUT_SET_MP_I2C1_OUTPUT_RSel0p9(mp2_i2c1_reg_output_reg, mp_i2c1_output_rsel0p9) \
     mp2_i2c1_reg_output_reg = (mp2_i2c1_reg_output_reg & ~MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_RSel0p9_MASK) | (mp_i2c1_output_rsel0p9 << MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_RSel0p9_SHIFT)
#define MP2_I2C1_REG_OUTPUT_SET_MP_I2C1_OUTPUT_RSel1p1(mp2_i2c1_reg_output_reg, mp_i2c1_output_rsel1p1) \
     mp2_i2c1_reg_output_reg = (mp2_i2c1_reg_output_reg & ~MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_RSel1p1_MASK) | (mp_i2c1_output_rsel1p1 << MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_RSel1p1_SHIFT)
#define MP2_I2C1_REG_OUTPUT_SET_MP_I2C1_OUTPUT_BiasCrtEn(mp2_i2c1_reg_output_reg, mp_i2c1_output_biascrten) \
     mp2_i2c1_reg_output_reg = (mp2_i2c1_reg_output_reg & ~MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_BiasCrtEn_MASK) | (mp_i2c1_output_biascrten << MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_BiasCrtEn_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c1_reg_output_t {
          unsigned int mp_i2c1_output_spare0          : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Spare0_SIZE;
          unsigned int mp_i2c1_output_spare1          : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Spare1_SIZE;
          unsigned int mp_i2c1_output_resbiasen       : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_ResBiasEn_SIZE;
          unsigned int mp_i2c1_output_compsel         : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CompSel_SIZE;
          unsigned int mp_i2c1_output_ng              : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_NG_SIZE;
          unsigned int mp_i2c1_output_i2crxsel        : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_I2cRxSel_SIZE;
          unsigned int mp_i2c1_output_pden0           : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_PdEn0_SIZE;
          unsigned int mp_i2c1_output_pden1           : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_PdEn1_SIZE;
          unsigned int mp_i2c1_output_di2c0           : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_DI2C0_SIZE;
          unsigned int mp_i2c1_output_di2c1           : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_DI2C1_SIZE;
          unsigned int mp_i2c1_output_fallslewsel     : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_FallSlewSel_SIZE;
          unsigned int mp_i2c1_output_slewn           : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Slewn_SIZE;
          unsigned int mp_i2c1_output_spikercen       : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_SpikeRcEn_SIZE;
          unsigned int mp_i2c1_output_spikercsel      : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_SpikeRcSel_SIZE;
          unsigned int mp_i2c1_output_csel0p9         : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CSel0p9_SIZE;
          unsigned int mp_i2c1_output_csel1p1         : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CSel1p1_SIZE;
          unsigned int mp_i2c1_output_rsel0p9         : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_RSel0p9_SIZE;
          unsigned int mp_i2c1_output_rsel1p1         : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_RSel1p1_SIZE;
          unsigned int mp_i2c1_output_biascrten       : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_BiasCrtEn_SIZE;
          unsigned int                                : 8;
     } mp2_i2c1_reg_output_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c1_reg_output_t {
          unsigned int                                : 8;
          unsigned int mp_i2c1_output_biascrten       : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_BiasCrtEn_SIZE;
          unsigned int mp_i2c1_output_rsel1p1         : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_RSel1p1_SIZE;
          unsigned int mp_i2c1_output_rsel0p9         : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_RSel0p9_SIZE;
          unsigned int mp_i2c1_output_csel1p1         : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CSel1p1_SIZE;
          unsigned int mp_i2c1_output_csel0p9         : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CSel0p9_SIZE;
          unsigned int mp_i2c1_output_spikercsel      : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_SpikeRcSel_SIZE;
          unsigned int mp_i2c1_output_spikercen       : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_SpikeRcEn_SIZE;
          unsigned int mp_i2c1_output_slewn           : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Slewn_SIZE;
          unsigned int mp_i2c1_output_fallslewsel     : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_FallSlewSel_SIZE;
          unsigned int mp_i2c1_output_di2c1           : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_DI2C1_SIZE;
          unsigned int mp_i2c1_output_di2c0           : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_DI2C0_SIZE;
          unsigned int mp_i2c1_output_pden1           : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_PdEn1_SIZE;
          unsigned int mp_i2c1_output_pden0           : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_PdEn0_SIZE;
          unsigned int mp_i2c1_output_i2crxsel        : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_I2cRxSel_SIZE;
          unsigned int mp_i2c1_output_ng              : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_NG_SIZE;
          unsigned int mp_i2c1_output_compsel         : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_CompSel_SIZE;
          unsigned int mp_i2c1_output_resbiasen       : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_ResBiasEn_SIZE;
          unsigned int mp_i2c1_output_spare1          : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Spare1_SIZE;
          unsigned int mp_i2c1_output_spare0          : MP2_I2C1_REG_OUTPUT_MP_I2C1_OUTPUT_Spare0_SIZE;
     } mp2_i2c1_reg_output_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c1_reg_output_t f;
} mp2_i2c1_reg_output_u;


/*
 * MP2_I2C1_OUTPUT_SEL struct
 */

#define MP2_I2C1_OUTPUT_SEL_REG_SIZE   32
#define MP2_I2C1_OUTPUT_SEL_MP_I2C1_OUTPUT_SEL_DI2C0_SIZE 1
#define MP2_I2C1_OUTPUT_SEL_MP_I2C1_OUTPUT_SEL_DI2C1_SIZE 1

#define MP2_I2C1_OUTPUT_SEL_MP_I2C1_OUTPUT_SEL_DI2C0_SHIFT 0
#define MP2_I2C1_OUTPUT_SEL_MP_I2C1_OUTPUT_SEL_DI2C1_SHIFT 1

#define MP2_I2C1_OUTPUT_SEL_MP_I2C1_OUTPUT_SEL_DI2C0_MASK 0x1
#define MP2_I2C1_OUTPUT_SEL_MP_I2C1_OUTPUT_SEL_DI2C1_MASK 0x2

#define MP2_I2C1_OUTPUT_SEL_MASK \
     (MP2_I2C1_OUTPUT_SEL_MP_I2C1_OUTPUT_SEL_DI2C0_MASK | \
      MP2_I2C1_OUTPUT_SEL_MP_I2C1_OUTPUT_SEL_DI2C1_MASK)

#define MP2_I2C1_OUTPUT_SEL_DEFAULT    0x00000000

#define MP2_I2C1_OUTPUT_SEL_GET_MP_I2C1_OUTPUT_SEL_DI2C0(mp2_i2c1_output_sel) \
     ((mp2_i2c1_output_sel & MP2_I2C1_OUTPUT_SEL_MP_I2C1_OUTPUT_SEL_DI2C0_MASK) >> MP2_I2C1_OUTPUT_SEL_MP_I2C1_OUTPUT_SEL_DI2C0_SHIFT)
#define MP2_I2C1_OUTPUT_SEL_GET_MP_I2C1_OUTPUT_SEL_DI2C1(mp2_i2c1_output_sel) \
     ((mp2_i2c1_output_sel & MP2_I2C1_OUTPUT_SEL_MP_I2C1_OUTPUT_SEL_DI2C1_MASK) >> MP2_I2C1_OUTPUT_SEL_MP_I2C1_OUTPUT_SEL_DI2C1_SHIFT)

#define MP2_I2C1_OUTPUT_SEL_SET_MP_I2C1_OUTPUT_SEL_DI2C0(mp2_i2c1_output_sel_reg, mp_i2c1_output_sel_di2c0) \
     mp2_i2c1_output_sel_reg = (mp2_i2c1_output_sel_reg & ~MP2_I2C1_OUTPUT_SEL_MP_I2C1_OUTPUT_SEL_DI2C0_MASK) | (mp_i2c1_output_sel_di2c0 << MP2_I2C1_OUTPUT_SEL_MP_I2C1_OUTPUT_SEL_DI2C0_SHIFT)
#define MP2_I2C1_OUTPUT_SEL_SET_MP_I2C1_OUTPUT_SEL_DI2C1(mp2_i2c1_output_sel_reg, mp_i2c1_output_sel_di2c1) \
     mp2_i2c1_output_sel_reg = (mp2_i2c1_output_sel_reg & ~MP2_I2C1_OUTPUT_SEL_MP_I2C1_OUTPUT_SEL_DI2C1_MASK) | (mp_i2c1_output_sel_di2c1 << MP2_I2C1_OUTPUT_SEL_MP_I2C1_OUTPUT_SEL_DI2C1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c1_output_sel_t {
          unsigned int mp_i2c1_output_sel_di2c0       : MP2_I2C1_OUTPUT_SEL_MP_I2C1_OUTPUT_SEL_DI2C0_SIZE;
          unsigned int mp_i2c1_output_sel_di2c1       : MP2_I2C1_OUTPUT_SEL_MP_I2C1_OUTPUT_SEL_DI2C1_SIZE;
          unsigned int                                : 30;
     } mp2_i2c1_output_sel_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c1_output_sel_t {
          unsigned int                                : 30;
          unsigned int mp_i2c1_output_sel_di2c1       : MP2_I2C1_OUTPUT_SEL_MP_I2C1_OUTPUT_SEL_DI2C1_SIZE;
          unsigned int mp_i2c1_output_sel_di2c0       : MP2_I2C1_OUTPUT_SEL_MP_I2C1_OUTPUT_SEL_DI2C0_SIZE;
     } mp2_i2c1_output_sel_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c1_output_sel_t f;
} mp2_i2c1_output_sel_u;


/*
 * MP2_I2C1_OUTPUT_VAL struct
 */

#define MP2_I2C1_OUTPUT_VAL_REG_SIZE   32
#define MP2_I2C1_OUTPUT_VAL_MP_I2C1_OUTPUT_VAL_DI2C0_SIZE 1
#define MP2_I2C1_OUTPUT_VAL_MP_I2C1_OUTPUT_VAL_DI2C1_SIZE 1

#define MP2_I2C1_OUTPUT_VAL_MP_I2C1_OUTPUT_VAL_DI2C0_SHIFT 0
#define MP2_I2C1_OUTPUT_VAL_MP_I2C1_OUTPUT_VAL_DI2C1_SHIFT 1

#define MP2_I2C1_OUTPUT_VAL_MP_I2C1_OUTPUT_VAL_DI2C0_MASK 0x1
#define MP2_I2C1_OUTPUT_VAL_MP_I2C1_OUTPUT_VAL_DI2C1_MASK 0x2

#define MP2_I2C1_OUTPUT_VAL_MASK \
     (MP2_I2C1_OUTPUT_VAL_MP_I2C1_OUTPUT_VAL_DI2C0_MASK | \
      MP2_I2C1_OUTPUT_VAL_MP_I2C1_OUTPUT_VAL_DI2C1_MASK)

#define MP2_I2C1_OUTPUT_VAL_DEFAULT    0x00000000

#define MP2_I2C1_OUTPUT_VAL_GET_MP_I2C1_OUTPUT_VAL_DI2C0(mp2_i2c1_output_val) \
     ((mp2_i2c1_output_val & MP2_I2C1_OUTPUT_VAL_MP_I2C1_OUTPUT_VAL_DI2C0_MASK) >> MP2_I2C1_OUTPUT_VAL_MP_I2C1_OUTPUT_VAL_DI2C0_SHIFT)
#define MP2_I2C1_OUTPUT_VAL_GET_MP_I2C1_OUTPUT_VAL_DI2C1(mp2_i2c1_output_val) \
     ((mp2_i2c1_output_val & MP2_I2C1_OUTPUT_VAL_MP_I2C1_OUTPUT_VAL_DI2C1_MASK) >> MP2_I2C1_OUTPUT_VAL_MP_I2C1_OUTPUT_VAL_DI2C1_SHIFT)

#define MP2_I2C1_OUTPUT_VAL_SET_MP_I2C1_OUTPUT_VAL_DI2C0(mp2_i2c1_output_val_reg, mp_i2c1_output_val_di2c0) \
     mp2_i2c1_output_val_reg = (mp2_i2c1_output_val_reg & ~MP2_I2C1_OUTPUT_VAL_MP_I2C1_OUTPUT_VAL_DI2C0_MASK) | (mp_i2c1_output_val_di2c0 << MP2_I2C1_OUTPUT_VAL_MP_I2C1_OUTPUT_VAL_DI2C0_SHIFT)
#define MP2_I2C1_OUTPUT_VAL_SET_MP_I2C1_OUTPUT_VAL_DI2C1(mp2_i2c1_output_val_reg, mp_i2c1_output_val_di2c1) \
     mp2_i2c1_output_val_reg = (mp2_i2c1_output_val_reg & ~MP2_I2C1_OUTPUT_VAL_MP_I2C1_OUTPUT_VAL_DI2C1_MASK) | (mp_i2c1_output_val_di2c1 << MP2_I2C1_OUTPUT_VAL_MP_I2C1_OUTPUT_VAL_DI2C1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c1_output_val_t {
          unsigned int mp_i2c1_output_val_di2c0       : MP2_I2C1_OUTPUT_VAL_MP_I2C1_OUTPUT_VAL_DI2C0_SIZE;
          unsigned int mp_i2c1_output_val_di2c1       : MP2_I2C1_OUTPUT_VAL_MP_I2C1_OUTPUT_VAL_DI2C1_SIZE;
          unsigned int                                : 30;
     } mp2_i2c1_output_val_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c1_output_val_t {
          unsigned int                                : 30;
          unsigned int mp_i2c1_output_val_di2c1       : MP2_I2C1_OUTPUT_VAL_MP_I2C1_OUTPUT_VAL_DI2C1_SIZE;
          unsigned int mp_i2c1_output_val_di2c0       : MP2_I2C1_OUTPUT_VAL_MP_I2C1_OUTPUT_VAL_DI2C0_SIZE;
     } mp2_i2c1_output_val_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c1_output_val_t f;
} mp2_i2c1_output_val_u;


/*
 * MP2_I2C0_OUTPUT struct
 */

#define MP2_I2C0_OUTPUT_REG_SIZE       32
#define MP2_I2C0_OUTPUT_MP_I2C0_SCL_SIZE 1
#define MP2_I2C0_OUTPUT_MP_I2C0_SDA_SIZE 1

#define MP2_I2C0_OUTPUT_MP_I2C0_SCL_SHIFT 0
#define MP2_I2C0_OUTPUT_MP_I2C0_SDA_SHIFT 1

#define MP2_I2C0_OUTPUT_MP_I2C0_SCL_MASK 0x1
#define MP2_I2C0_OUTPUT_MP_I2C0_SDA_MASK 0x2

#define MP2_I2C0_OUTPUT_MASK \
     (MP2_I2C0_OUTPUT_MP_I2C0_SCL_MASK | \
      MP2_I2C0_OUTPUT_MP_I2C0_SDA_MASK)

#define MP2_I2C0_OUTPUT_DEFAULT        0x00000000

#define MP2_I2C0_OUTPUT_GET_MP_I2C0_SCL(mp2_i2c0_output) \
     ((mp2_i2c0_output & MP2_I2C0_OUTPUT_MP_I2C0_SCL_MASK) >> MP2_I2C0_OUTPUT_MP_I2C0_SCL_SHIFT)
#define MP2_I2C0_OUTPUT_GET_MP_I2C0_SDA(mp2_i2c0_output) \
     ((mp2_i2c0_output & MP2_I2C0_OUTPUT_MP_I2C0_SDA_MASK) >> MP2_I2C0_OUTPUT_MP_I2C0_SDA_SHIFT)

#define MP2_I2C0_OUTPUT_SET_MP_I2C0_SCL(mp2_i2c0_output_reg, mp_i2c0_scl) \
     mp2_i2c0_output_reg = (mp2_i2c0_output_reg & ~MP2_I2C0_OUTPUT_MP_I2C0_SCL_MASK) | (mp_i2c0_scl << MP2_I2C0_OUTPUT_MP_I2C0_SCL_SHIFT)
#define MP2_I2C0_OUTPUT_SET_MP_I2C0_SDA(mp2_i2c0_output_reg, mp_i2c0_sda) \
     mp2_i2c0_output_reg = (mp2_i2c0_output_reg & ~MP2_I2C0_OUTPUT_MP_I2C0_SDA_MASK) | (mp_i2c0_sda << MP2_I2C0_OUTPUT_MP_I2C0_SDA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_output_t {
          unsigned int mp_i2c0_scl                    : MP2_I2C0_OUTPUT_MP_I2C0_SCL_SIZE;
          unsigned int mp_i2c0_sda                    : MP2_I2C0_OUTPUT_MP_I2C0_SDA_SIZE;
          unsigned int                                : 30;
     } mp2_i2c0_output_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_output_t {
          unsigned int                                : 30;
          unsigned int mp_i2c0_sda                    : MP2_I2C0_OUTPUT_MP_I2C0_SDA_SIZE;
          unsigned int mp_i2c0_scl                    : MP2_I2C0_OUTPUT_MP_I2C0_SCL_SIZE;
     } mp2_i2c0_output_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_output_t f;
} mp2_i2c0_output_u;


/*
 * MP2_I2C0_INPUT struct
 */

#define MP2_I2C0_INPUT_REG_SIZE        32
#define MP2_I2C0_INPUT_MP_INPUT_I2C0_SCL_SIZE 1
#define MP2_I2C0_INPUT_MP_INPUT_I2C0_SDA_SIZE 1
#define MP2_I2C0_INPUT_MP_INPUT_I2C0_ART12_SIZE 1

#define MP2_I2C0_INPUT_MP_INPUT_I2C0_SCL_SHIFT 0
#define MP2_I2C0_INPUT_MP_INPUT_I2C0_SDA_SHIFT 1
#define MP2_I2C0_INPUT_MP_INPUT_I2C0_ART12_SHIFT 2

#define MP2_I2C0_INPUT_MP_INPUT_I2C0_SCL_MASK 0x1
#define MP2_I2C0_INPUT_MP_INPUT_I2C0_SDA_MASK 0x2
#define MP2_I2C0_INPUT_MP_INPUT_I2C0_ART12_MASK 0x4

#define MP2_I2C0_INPUT_MASK \
     (MP2_I2C0_INPUT_MP_INPUT_I2C0_SCL_MASK | \
      MP2_I2C0_INPUT_MP_INPUT_I2C0_SDA_MASK | \
      MP2_I2C0_INPUT_MP_INPUT_I2C0_ART12_MASK)

#define MP2_I2C0_INPUT_DEFAULT         0x00000000

#define MP2_I2C0_INPUT_GET_MP_INPUT_I2C0_SCL(mp2_i2c0_input) \
     ((mp2_i2c0_input & MP2_I2C0_INPUT_MP_INPUT_I2C0_SCL_MASK) >> MP2_I2C0_INPUT_MP_INPUT_I2C0_SCL_SHIFT)
#define MP2_I2C0_INPUT_GET_MP_INPUT_I2C0_SDA(mp2_i2c0_input) \
     ((mp2_i2c0_input & MP2_I2C0_INPUT_MP_INPUT_I2C0_SDA_MASK) >> MP2_I2C0_INPUT_MP_INPUT_I2C0_SDA_SHIFT)
#define MP2_I2C0_INPUT_GET_MP_INPUT_I2C0_ART12(mp2_i2c0_input) \
     ((mp2_i2c0_input & MP2_I2C0_INPUT_MP_INPUT_I2C0_ART12_MASK) >> MP2_I2C0_INPUT_MP_INPUT_I2C0_ART12_SHIFT)

#define MP2_I2C0_INPUT_SET_MP_INPUT_I2C0_SCL(mp2_i2c0_input_reg, mp_input_i2c0_scl) \
     mp2_i2c0_input_reg = (mp2_i2c0_input_reg & ~MP2_I2C0_INPUT_MP_INPUT_I2C0_SCL_MASK) | (mp_input_i2c0_scl << MP2_I2C0_INPUT_MP_INPUT_I2C0_SCL_SHIFT)
#define MP2_I2C0_INPUT_SET_MP_INPUT_I2C0_SDA(mp2_i2c0_input_reg, mp_input_i2c0_sda) \
     mp2_i2c0_input_reg = (mp2_i2c0_input_reg & ~MP2_I2C0_INPUT_MP_INPUT_I2C0_SDA_MASK) | (mp_input_i2c0_sda << MP2_I2C0_INPUT_MP_INPUT_I2C0_SDA_SHIFT)
#define MP2_I2C0_INPUT_SET_MP_INPUT_I2C0_ART12(mp2_i2c0_input_reg, mp_input_i2c0_art12) \
     mp2_i2c0_input_reg = (mp2_i2c0_input_reg & ~MP2_I2C0_INPUT_MP_INPUT_I2C0_ART12_MASK) | (mp_input_i2c0_art12 << MP2_I2C0_INPUT_MP_INPUT_I2C0_ART12_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_input_t {
          unsigned int mp_input_i2c0_scl              : MP2_I2C0_INPUT_MP_INPUT_I2C0_SCL_SIZE;
          unsigned int mp_input_i2c0_sda              : MP2_I2C0_INPUT_MP_INPUT_I2C0_SDA_SIZE;
          unsigned int mp_input_i2c0_art12            : MP2_I2C0_INPUT_MP_INPUT_I2C0_ART12_SIZE;
          unsigned int                                : 29;
     } mp2_i2c0_input_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_input_t {
          unsigned int                                : 29;
          unsigned int mp_input_i2c0_art12            : MP2_I2C0_INPUT_MP_INPUT_I2C0_ART12_SIZE;
          unsigned int mp_input_i2c0_sda              : MP2_I2C0_INPUT_MP_INPUT_I2C0_SDA_SIZE;
          unsigned int mp_input_i2c0_scl              : MP2_I2C0_INPUT_MP_INPUT_I2C0_SCL_SIZE;
     } mp2_i2c0_input_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_input_t f;
} mp2_i2c0_input_u;


/*
 * MP2_I2C0_SCL_INT struct
 */

#define MP2_I2C0_SCL_INT_REG_SIZE      32
#define MP2_I2C0_SCL_INT_MP2_I2C0_SCL_INT_EN_SIZE 2
#define MP2_I2C0_SCL_INT_MP2_I2C0_SCL_INT_STAT_SIZE 1

#define MP2_I2C0_SCL_INT_MP2_I2C0_SCL_INT_EN_SHIFT 0
#define MP2_I2C0_SCL_INT_MP2_I2C0_SCL_INT_STAT_SHIFT 2

#define MP2_I2C0_SCL_INT_MP2_I2C0_SCL_INT_EN_MASK 0x3
#define MP2_I2C0_SCL_INT_MP2_I2C0_SCL_INT_STAT_MASK 0x4

#define MP2_I2C0_SCL_INT_MASK \
     (MP2_I2C0_SCL_INT_MP2_I2C0_SCL_INT_EN_MASK | \
      MP2_I2C0_SCL_INT_MP2_I2C0_SCL_INT_STAT_MASK)

#define MP2_I2C0_SCL_INT_DEFAULT       0x00000000

#define MP2_I2C0_SCL_INT_GET_MP2_I2C0_SCL_INT_EN(mp2_i2c0_scl_int) \
     ((mp2_i2c0_scl_int & MP2_I2C0_SCL_INT_MP2_I2C0_SCL_INT_EN_MASK) >> MP2_I2C0_SCL_INT_MP2_I2C0_SCL_INT_EN_SHIFT)
#define MP2_I2C0_SCL_INT_GET_MP2_I2C0_SCL_INT_STAT(mp2_i2c0_scl_int) \
     ((mp2_i2c0_scl_int & MP2_I2C0_SCL_INT_MP2_I2C0_SCL_INT_STAT_MASK) >> MP2_I2C0_SCL_INT_MP2_I2C0_SCL_INT_STAT_SHIFT)

#define MP2_I2C0_SCL_INT_SET_MP2_I2C0_SCL_INT_EN(mp2_i2c0_scl_int_reg, mp2_i2c0_scl_int_en) \
     mp2_i2c0_scl_int_reg = (mp2_i2c0_scl_int_reg & ~MP2_I2C0_SCL_INT_MP2_I2C0_SCL_INT_EN_MASK) | (mp2_i2c0_scl_int_en << MP2_I2C0_SCL_INT_MP2_I2C0_SCL_INT_EN_SHIFT)
#define MP2_I2C0_SCL_INT_SET_MP2_I2C0_SCL_INT_STAT(mp2_i2c0_scl_int_reg, mp2_i2c0_scl_int_stat) \
     mp2_i2c0_scl_int_reg = (mp2_i2c0_scl_int_reg & ~MP2_I2C0_SCL_INT_MP2_I2C0_SCL_INT_STAT_MASK) | (mp2_i2c0_scl_int_stat << MP2_I2C0_SCL_INT_MP2_I2C0_SCL_INT_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_scl_int_t {
          unsigned int mp2_i2c0_scl_int_en            : MP2_I2C0_SCL_INT_MP2_I2C0_SCL_INT_EN_SIZE;
          unsigned int mp2_i2c0_scl_int_stat          : MP2_I2C0_SCL_INT_MP2_I2C0_SCL_INT_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_i2c0_scl_int_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_scl_int_t {
          unsigned int                                : 29;
          unsigned int mp2_i2c0_scl_int_stat          : MP2_I2C0_SCL_INT_MP2_I2C0_SCL_INT_STAT_SIZE;
          unsigned int mp2_i2c0_scl_int_en            : MP2_I2C0_SCL_INT_MP2_I2C0_SCL_INT_EN_SIZE;
     } mp2_i2c0_scl_int_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_scl_int_t f;
} mp2_i2c0_scl_int_u;


/*
 * MP2_I2C0_SDA_INT struct
 */

#define MP2_I2C0_SDA_INT_REG_SIZE      32
#define MP2_I2C0_SDA_INT_MP2_I2C0_SDA_INT_EN_SIZE 2
#define MP2_I2C0_SDA_INT_MP2_I2C0_SDA_INT_STAT_SIZE 1

#define MP2_I2C0_SDA_INT_MP2_I2C0_SDA_INT_EN_SHIFT 0
#define MP2_I2C0_SDA_INT_MP2_I2C0_SDA_INT_STAT_SHIFT 2

#define MP2_I2C0_SDA_INT_MP2_I2C0_SDA_INT_EN_MASK 0x3
#define MP2_I2C0_SDA_INT_MP2_I2C0_SDA_INT_STAT_MASK 0x4

#define MP2_I2C0_SDA_INT_MASK \
     (MP2_I2C0_SDA_INT_MP2_I2C0_SDA_INT_EN_MASK | \
      MP2_I2C0_SDA_INT_MP2_I2C0_SDA_INT_STAT_MASK)

#define MP2_I2C0_SDA_INT_DEFAULT       0x00000000

#define MP2_I2C0_SDA_INT_GET_MP2_I2C0_SDA_INT_EN(mp2_i2c0_sda_int) \
     ((mp2_i2c0_sda_int & MP2_I2C0_SDA_INT_MP2_I2C0_SDA_INT_EN_MASK) >> MP2_I2C0_SDA_INT_MP2_I2C0_SDA_INT_EN_SHIFT)
#define MP2_I2C0_SDA_INT_GET_MP2_I2C0_SDA_INT_STAT(mp2_i2c0_sda_int) \
     ((mp2_i2c0_sda_int & MP2_I2C0_SDA_INT_MP2_I2C0_SDA_INT_STAT_MASK) >> MP2_I2C0_SDA_INT_MP2_I2C0_SDA_INT_STAT_SHIFT)

#define MP2_I2C0_SDA_INT_SET_MP2_I2C0_SDA_INT_EN(mp2_i2c0_sda_int_reg, mp2_i2c0_sda_int_en) \
     mp2_i2c0_sda_int_reg = (mp2_i2c0_sda_int_reg & ~MP2_I2C0_SDA_INT_MP2_I2C0_SDA_INT_EN_MASK) | (mp2_i2c0_sda_int_en << MP2_I2C0_SDA_INT_MP2_I2C0_SDA_INT_EN_SHIFT)
#define MP2_I2C0_SDA_INT_SET_MP2_I2C0_SDA_INT_STAT(mp2_i2c0_sda_int_reg, mp2_i2c0_sda_int_stat) \
     mp2_i2c0_sda_int_reg = (mp2_i2c0_sda_int_reg & ~MP2_I2C0_SDA_INT_MP2_I2C0_SDA_INT_STAT_MASK) | (mp2_i2c0_sda_int_stat << MP2_I2C0_SDA_INT_MP2_I2C0_SDA_INT_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_sda_int_t {
          unsigned int mp2_i2c0_sda_int_en            : MP2_I2C0_SDA_INT_MP2_I2C0_SDA_INT_EN_SIZE;
          unsigned int mp2_i2c0_sda_int_stat          : MP2_I2C0_SDA_INT_MP2_I2C0_SDA_INT_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_i2c0_sda_int_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_sda_int_t {
          unsigned int                                : 29;
          unsigned int mp2_i2c0_sda_int_stat          : MP2_I2C0_SDA_INT_MP2_I2C0_SDA_INT_STAT_SIZE;
          unsigned int mp2_i2c0_sda_int_en            : MP2_I2C0_SDA_INT_MP2_I2C0_SDA_INT_EN_SIZE;
     } mp2_i2c0_sda_int_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_sda_int_t f;
} mp2_i2c0_sda_int_u;


/*
 * MP2_I2C0_INPUT_CTRL struct
 */

#define MP2_I2C0_INPUT_CTRL_REG_SIZE   32
#define MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_ENABLE_INPUT_SYNC_SIZE 1
#define MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_DEBUG_MODE_SIZE 1
#define MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_SELECT_SIZE 1
#define MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_VOLTAGE_SELECT_SIZE 1

#define MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_ENABLE_INPUT_SYNC_SHIFT 0
#define MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_DEBUG_MODE_SHIFT 1
#define MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_SELECT_SHIFT 2
#define MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_VOLTAGE_SELECT_SHIFT 3

#define MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_ENABLE_INPUT_SYNC_MASK 0x1
#define MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_DEBUG_MODE_MASK 0x2
#define MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_SELECT_MASK 0x4
#define MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_VOLTAGE_SELECT_MASK 0x8

#define MP2_I2C0_INPUT_CTRL_MASK \
     (MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_ENABLE_INPUT_SYNC_MASK | \
      MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_DEBUG_MODE_MASK | \
      MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_SELECT_MASK | \
      MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_VOLTAGE_SELECT_MASK)

#define MP2_I2C0_INPUT_CTRL_DEFAULT    0x00000000

#define MP2_I2C0_INPUT_CTRL_GET_MP_I2C0_INPUT_CTRL_ENABLE_INPUT_SYNC(mp2_i2c0_input_ctrl) \
     ((mp2_i2c0_input_ctrl & MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_ENABLE_INPUT_SYNC_MASK) >> MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_ENABLE_INPUT_SYNC_SHIFT)
#define MP2_I2C0_INPUT_CTRL_GET_MP_I2C0_INPUT_CTRL_DEBUG_MODE(mp2_i2c0_input_ctrl) \
     ((mp2_i2c0_input_ctrl & MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_DEBUG_MODE_MASK) >> MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_DEBUG_MODE_SHIFT)
#define MP2_I2C0_INPUT_CTRL_GET_MP_I2C0_INPUT_CTRL_SELECT(mp2_i2c0_input_ctrl) \
     ((mp2_i2c0_input_ctrl & MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_SELECT_MASK) >> MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_SELECT_SHIFT)
#define MP2_I2C0_INPUT_CTRL_GET_MP_I2C0_INPUT_CTRL_VOLTAGE_SELECT(mp2_i2c0_input_ctrl) \
     ((mp2_i2c0_input_ctrl & MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_VOLTAGE_SELECT_MASK) >> MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_VOLTAGE_SELECT_SHIFT)

#define MP2_I2C0_INPUT_CTRL_SET_MP_I2C0_INPUT_CTRL_ENABLE_INPUT_SYNC(mp2_i2c0_input_ctrl_reg, mp_i2c0_input_ctrl_enable_input_sync) \
     mp2_i2c0_input_ctrl_reg = (mp2_i2c0_input_ctrl_reg & ~MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_ENABLE_INPUT_SYNC_MASK) | (mp_i2c0_input_ctrl_enable_input_sync << MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_ENABLE_INPUT_SYNC_SHIFT)
#define MP2_I2C0_INPUT_CTRL_SET_MP_I2C0_INPUT_CTRL_DEBUG_MODE(mp2_i2c0_input_ctrl_reg, mp_i2c0_input_ctrl_debug_mode) \
     mp2_i2c0_input_ctrl_reg = (mp2_i2c0_input_ctrl_reg & ~MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_DEBUG_MODE_MASK) | (mp_i2c0_input_ctrl_debug_mode << MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_DEBUG_MODE_SHIFT)
#define MP2_I2C0_INPUT_CTRL_SET_MP_I2C0_INPUT_CTRL_SELECT(mp2_i2c0_input_ctrl_reg, mp_i2c0_input_ctrl_select) \
     mp2_i2c0_input_ctrl_reg = (mp2_i2c0_input_ctrl_reg & ~MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_SELECT_MASK) | (mp_i2c0_input_ctrl_select << MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_SELECT_SHIFT)
#define MP2_I2C0_INPUT_CTRL_SET_MP_I2C0_INPUT_CTRL_VOLTAGE_SELECT(mp2_i2c0_input_ctrl_reg, mp_i2c0_input_ctrl_voltage_select) \
     mp2_i2c0_input_ctrl_reg = (mp2_i2c0_input_ctrl_reg & ~MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_VOLTAGE_SELECT_MASK) | (mp_i2c0_input_ctrl_voltage_select << MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_VOLTAGE_SELECT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c0_input_ctrl_t {
          unsigned int mp_i2c0_input_ctrl_enable_input_sync : MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_ENABLE_INPUT_SYNC_SIZE;
          unsigned int mp_i2c0_input_ctrl_debug_mode  : MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_DEBUG_MODE_SIZE;
          unsigned int mp_i2c0_input_ctrl_select      : MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_SELECT_SIZE;
          unsigned int mp_i2c0_input_ctrl_voltage_select : MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_VOLTAGE_SELECT_SIZE;
          unsigned int                                : 28;
     } mp2_i2c0_input_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c0_input_ctrl_t {
          unsigned int                                : 28;
          unsigned int mp_i2c0_input_ctrl_voltage_select : MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_VOLTAGE_SELECT_SIZE;
          unsigned int mp_i2c0_input_ctrl_select      : MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_SELECT_SIZE;
          unsigned int mp_i2c0_input_ctrl_debug_mode  : MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_DEBUG_MODE_SIZE;
          unsigned int mp_i2c0_input_ctrl_enable_input_sync : MP2_I2C0_INPUT_CTRL_MP_I2C0_INPUT_CTRL_ENABLE_INPUT_SYNC_SIZE;
     } mp2_i2c0_input_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c0_input_ctrl_t f;
} mp2_i2c0_input_ctrl_u;


/*
 * MP2_I2C1_SCL_INT struct
 */

#define MP2_I2C1_SCL_INT_REG_SIZE      32
#define MP2_I2C1_SCL_INT_MP2_I2C1_SCL_INT_EN_SIZE 2
#define MP2_I2C1_SCL_INT_MP2_I2C1_SCL_INT_STAT_SIZE 1

#define MP2_I2C1_SCL_INT_MP2_I2C1_SCL_INT_EN_SHIFT 0
#define MP2_I2C1_SCL_INT_MP2_I2C1_SCL_INT_STAT_SHIFT 2

#define MP2_I2C1_SCL_INT_MP2_I2C1_SCL_INT_EN_MASK 0x3
#define MP2_I2C1_SCL_INT_MP2_I2C1_SCL_INT_STAT_MASK 0x4

#define MP2_I2C1_SCL_INT_MASK \
     (MP2_I2C1_SCL_INT_MP2_I2C1_SCL_INT_EN_MASK | \
      MP2_I2C1_SCL_INT_MP2_I2C1_SCL_INT_STAT_MASK)

#define MP2_I2C1_SCL_INT_DEFAULT       0x00000000

#define MP2_I2C1_SCL_INT_GET_MP2_I2C1_SCL_INT_EN(mp2_i2c1_scl_int) \
     ((mp2_i2c1_scl_int & MP2_I2C1_SCL_INT_MP2_I2C1_SCL_INT_EN_MASK) >> MP2_I2C1_SCL_INT_MP2_I2C1_SCL_INT_EN_SHIFT)
#define MP2_I2C1_SCL_INT_GET_MP2_I2C1_SCL_INT_STAT(mp2_i2c1_scl_int) \
     ((mp2_i2c1_scl_int & MP2_I2C1_SCL_INT_MP2_I2C1_SCL_INT_STAT_MASK) >> MP2_I2C1_SCL_INT_MP2_I2C1_SCL_INT_STAT_SHIFT)

#define MP2_I2C1_SCL_INT_SET_MP2_I2C1_SCL_INT_EN(mp2_i2c1_scl_int_reg, mp2_i2c1_scl_int_en) \
     mp2_i2c1_scl_int_reg = (mp2_i2c1_scl_int_reg & ~MP2_I2C1_SCL_INT_MP2_I2C1_SCL_INT_EN_MASK) | (mp2_i2c1_scl_int_en << MP2_I2C1_SCL_INT_MP2_I2C1_SCL_INT_EN_SHIFT)
#define MP2_I2C1_SCL_INT_SET_MP2_I2C1_SCL_INT_STAT(mp2_i2c1_scl_int_reg, mp2_i2c1_scl_int_stat) \
     mp2_i2c1_scl_int_reg = (mp2_i2c1_scl_int_reg & ~MP2_I2C1_SCL_INT_MP2_I2C1_SCL_INT_STAT_MASK) | (mp2_i2c1_scl_int_stat << MP2_I2C1_SCL_INT_MP2_I2C1_SCL_INT_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c1_scl_int_t {
          unsigned int mp2_i2c1_scl_int_en            : MP2_I2C1_SCL_INT_MP2_I2C1_SCL_INT_EN_SIZE;
          unsigned int mp2_i2c1_scl_int_stat          : MP2_I2C1_SCL_INT_MP2_I2C1_SCL_INT_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_i2c1_scl_int_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c1_scl_int_t {
          unsigned int                                : 29;
          unsigned int mp2_i2c1_scl_int_stat          : MP2_I2C1_SCL_INT_MP2_I2C1_SCL_INT_STAT_SIZE;
          unsigned int mp2_i2c1_scl_int_en            : MP2_I2C1_SCL_INT_MP2_I2C1_SCL_INT_EN_SIZE;
     } mp2_i2c1_scl_int_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c1_scl_int_t f;
} mp2_i2c1_scl_int_u;


/*
 * MP2_I2C1_SDA_INT struct
 */

#define MP2_I2C1_SDA_INT_REG_SIZE      32
#define MP2_I2C1_SDA_INT_MP2_I2C1_SDA_INT_EN_SIZE 2
#define MP2_I2C1_SDA_INT_MP2_I2C1_SDA_INT_STAT_SIZE 1

#define MP2_I2C1_SDA_INT_MP2_I2C1_SDA_INT_EN_SHIFT 0
#define MP2_I2C1_SDA_INT_MP2_I2C1_SDA_INT_STAT_SHIFT 2

#define MP2_I2C1_SDA_INT_MP2_I2C1_SDA_INT_EN_MASK 0x3
#define MP2_I2C1_SDA_INT_MP2_I2C1_SDA_INT_STAT_MASK 0x4

#define MP2_I2C1_SDA_INT_MASK \
     (MP2_I2C1_SDA_INT_MP2_I2C1_SDA_INT_EN_MASK | \
      MP2_I2C1_SDA_INT_MP2_I2C1_SDA_INT_STAT_MASK)

#define MP2_I2C1_SDA_INT_DEFAULT       0x00000000

#define MP2_I2C1_SDA_INT_GET_MP2_I2C1_SDA_INT_EN(mp2_i2c1_sda_int) \
     ((mp2_i2c1_sda_int & MP2_I2C1_SDA_INT_MP2_I2C1_SDA_INT_EN_MASK) >> MP2_I2C1_SDA_INT_MP2_I2C1_SDA_INT_EN_SHIFT)
#define MP2_I2C1_SDA_INT_GET_MP2_I2C1_SDA_INT_STAT(mp2_i2c1_sda_int) \
     ((mp2_i2c1_sda_int & MP2_I2C1_SDA_INT_MP2_I2C1_SDA_INT_STAT_MASK) >> MP2_I2C1_SDA_INT_MP2_I2C1_SDA_INT_STAT_SHIFT)

#define MP2_I2C1_SDA_INT_SET_MP2_I2C1_SDA_INT_EN(mp2_i2c1_sda_int_reg, mp2_i2c1_sda_int_en) \
     mp2_i2c1_sda_int_reg = (mp2_i2c1_sda_int_reg & ~MP2_I2C1_SDA_INT_MP2_I2C1_SDA_INT_EN_MASK) | (mp2_i2c1_sda_int_en << MP2_I2C1_SDA_INT_MP2_I2C1_SDA_INT_EN_SHIFT)
#define MP2_I2C1_SDA_INT_SET_MP2_I2C1_SDA_INT_STAT(mp2_i2c1_sda_int_reg, mp2_i2c1_sda_int_stat) \
     mp2_i2c1_sda_int_reg = (mp2_i2c1_sda_int_reg & ~MP2_I2C1_SDA_INT_MP2_I2C1_SDA_INT_STAT_MASK) | (mp2_i2c1_sda_int_stat << MP2_I2C1_SDA_INT_MP2_I2C1_SDA_INT_STAT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c1_sda_int_t {
          unsigned int mp2_i2c1_sda_int_en            : MP2_I2C1_SDA_INT_MP2_I2C1_SDA_INT_EN_SIZE;
          unsigned int mp2_i2c1_sda_int_stat          : MP2_I2C1_SDA_INT_MP2_I2C1_SDA_INT_STAT_SIZE;
          unsigned int                                : 29;
     } mp2_i2c1_sda_int_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c1_sda_int_t {
          unsigned int                                : 29;
          unsigned int mp2_i2c1_sda_int_stat          : MP2_I2C1_SDA_INT_MP2_I2C1_SDA_INT_STAT_SIZE;
          unsigned int mp2_i2c1_sda_int_en            : MP2_I2C1_SDA_INT_MP2_I2C1_SDA_INT_EN_SIZE;
     } mp2_i2c1_sda_int_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c1_sda_int_t f;
} mp2_i2c1_sda_int_u;


/*
 * MP2_I2C_SECURE_FENCE struct
 */

#define MP2_I2C_SECURE_FENCE_REG_SIZE  32
#define MP2_I2C_SECURE_FENCE_I2C0_SECURE_FENCE_ENABLE_SIZE 1
#define MP2_I2C_SECURE_FENCE_I2C1_SECURE_FENCE_ENABLE_SIZE 1
#define MP2_I2C_SECURE_FENCE_GPIO0_SECURE_FENCE_ENABLE_SIZE 1
#define MP2_I2C_SECURE_FENCE_GPIO1_SECURE_FENCE_ENABLE_SIZE 1
#define MP2_I2C_SECURE_FENCE_GPIO2_SECURE_FENCE_ENABLE_SIZE 1
#define MP2_I2C_SECURE_FENCE_GPIO3_SECURE_FENCE_ENABLE_SIZE 1
#define MP2_I2C_SECURE_FENCE_GPIO4_SECURE_FENCE_ENABLE_SIZE 1
#define MP2_I2C_SECURE_FENCE_GPIO5_SECURE_FENCE_ENABLE_SIZE 1

#define MP2_I2C_SECURE_FENCE_I2C0_SECURE_FENCE_ENABLE_SHIFT 0
#define MP2_I2C_SECURE_FENCE_I2C1_SECURE_FENCE_ENABLE_SHIFT 1
#define MP2_I2C_SECURE_FENCE_GPIO0_SECURE_FENCE_ENABLE_SHIFT 2
#define MP2_I2C_SECURE_FENCE_GPIO1_SECURE_FENCE_ENABLE_SHIFT 3
#define MP2_I2C_SECURE_FENCE_GPIO2_SECURE_FENCE_ENABLE_SHIFT 4
#define MP2_I2C_SECURE_FENCE_GPIO3_SECURE_FENCE_ENABLE_SHIFT 5
#define MP2_I2C_SECURE_FENCE_GPIO4_SECURE_FENCE_ENABLE_SHIFT 6
#define MP2_I2C_SECURE_FENCE_GPIO5_SECURE_FENCE_ENABLE_SHIFT 7

#define MP2_I2C_SECURE_FENCE_I2C0_SECURE_FENCE_ENABLE_MASK 0x1
#define MP2_I2C_SECURE_FENCE_I2C1_SECURE_FENCE_ENABLE_MASK 0x2
#define MP2_I2C_SECURE_FENCE_GPIO0_SECURE_FENCE_ENABLE_MASK 0x4
#define MP2_I2C_SECURE_FENCE_GPIO1_SECURE_FENCE_ENABLE_MASK 0x8
#define MP2_I2C_SECURE_FENCE_GPIO2_SECURE_FENCE_ENABLE_MASK 0x10
#define MP2_I2C_SECURE_FENCE_GPIO3_SECURE_FENCE_ENABLE_MASK 0x20
#define MP2_I2C_SECURE_FENCE_GPIO4_SECURE_FENCE_ENABLE_MASK 0x40
#define MP2_I2C_SECURE_FENCE_GPIO5_SECURE_FENCE_ENABLE_MASK 0x80

#define MP2_I2C_SECURE_FENCE_MASK \
     (MP2_I2C_SECURE_FENCE_I2C0_SECURE_FENCE_ENABLE_MASK | \
      MP2_I2C_SECURE_FENCE_I2C1_SECURE_FENCE_ENABLE_MASK | \
      MP2_I2C_SECURE_FENCE_GPIO0_SECURE_FENCE_ENABLE_MASK | \
      MP2_I2C_SECURE_FENCE_GPIO1_SECURE_FENCE_ENABLE_MASK | \
      MP2_I2C_SECURE_FENCE_GPIO2_SECURE_FENCE_ENABLE_MASK | \
      MP2_I2C_SECURE_FENCE_GPIO3_SECURE_FENCE_ENABLE_MASK | \
      MP2_I2C_SECURE_FENCE_GPIO4_SECURE_FENCE_ENABLE_MASK | \
      MP2_I2C_SECURE_FENCE_GPIO5_SECURE_FENCE_ENABLE_MASK)

#define MP2_I2C_SECURE_FENCE_DEFAULT   0x00000000

#define MP2_I2C_SECURE_FENCE_GET_I2C0_SECURE_FENCE_ENABLE(mp2_i2c_secure_fence) \
     ((mp2_i2c_secure_fence & MP2_I2C_SECURE_FENCE_I2C0_SECURE_FENCE_ENABLE_MASK) >> MP2_I2C_SECURE_FENCE_I2C0_SECURE_FENCE_ENABLE_SHIFT)
#define MP2_I2C_SECURE_FENCE_GET_I2C1_SECURE_FENCE_ENABLE(mp2_i2c_secure_fence) \
     ((mp2_i2c_secure_fence & MP2_I2C_SECURE_FENCE_I2C1_SECURE_FENCE_ENABLE_MASK) >> MP2_I2C_SECURE_FENCE_I2C1_SECURE_FENCE_ENABLE_SHIFT)
#define MP2_I2C_SECURE_FENCE_GET_GPIO0_SECURE_FENCE_ENABLE(mp2_i2c_secure_fence) \
     ((mp2_i2c_secure_fence & MP2_I2C_SECURE_FENCE_GPIO0_SECURE_FENCE_ENABLE_MASK) >> MP2_I2C_SECURE_FENCE_GPIO0_SECURE_FENCE_ENABLE_SHIFT)
#define MP2_I2C_SECURE_FENCE_GET_GPIO1_SECURE_FENCE_ENABLE(mp2_i2c_secure_fence) \
     ((mp2_i2c_secure_fence & MP2_I2C_SECURE_FENCE_GPIO1_SECURE_FENCE_ENABLE_MASK) >> MP2_I2C_SECURE_FENCE_GPIO1_SECURE_FENCE_ENABLE_SHIFT)
#define MP2_I2C_SECURE_FENCE_GET_GPIO2_SECURE_FENCE_ENABLE(mp2_i2c_secure_fence) \
     ((mp2_i2c_secure_fence & MP2_I2C_SECURE_FENCE_GPIO2_SECURE_FENCE_ENABLE_MASK) >> MP2_I2C_SECURE_FENCE_GPIO2_SECURE_FENCE_ENABLE_SHIFT)
#define MP2_I2C_SECURE_FENCE_GET_GPIO3_SECURE_FENCE_ENABLE(mp2_i2c_secure_fence) \
     ((mp2_i2c_secure_fence & MP2_I2C_SECURE_FENCE_GPIO3_SECURE_FENCE_ENABLE_MASK) >> MP2_I2C_SECURE_FENCE_GPIO3_SECURE_FENCE_ENABLE_SHIFT)
#define MP2_I2C_SECURE_FENCE_GET_GPIO4_SECURE_FENCE_ENABLE(mp2_i2c_secure_fence) \
     ((mp2_i2c_secure_fence & MP2_I2C_SECURE_FENCE_GPIO4_SECURE_FENCE_ENABLE_MASK) >> MP2_I2C_SECURE_FENCE_GPIO4_SECURE_FENCE_ENABLE_SHIFT)
#define MP2_I2C_SECURE_FENCE_GET_GPIO5_SECURE_FENCE_ENABLE(mp2_i2c_secure_fence) \
     ((mp2_i2c_secure_fence & MP2_I2C_SECURE_FENCE_GPIO5_SECURE_FENCE_ENABLE_MASK) >> MP2_I2C_SECURE_FENCE_GPIO5_SECURE_FENCE_ENABLE_SHIFT)

#define MP2_I2C_SECURE_FENCE_SET_I2C0_SECURE_FENCE_ENABLE(mp2_i2c_secure_fence_reg, i2c0_secure_fence_enable) \
     mp2_i2c_secure_fence_reg = (mp2_i2c_secure_fence_reg & ~MP2_I2C_SECURE_FENCE_I2C0_SECURE_FENCE_ENABLE_MASK) | (i2c0_secure_fence_enable << MP2_I2C_SECURE_FENCE_I2C0_SECURE_FENCE_ENABLE_SHIFT)
#define MP2_I2C_SECURE_FENCE_SET_I2C1_SECURE_FENCE_ENABLE(mp2_i2c_secure_fence_reg, i2c1_secure_fence_enable) \
     mp2_i2c_secure_fence_reg = (mp2_i2c_secure_fence_reg & ~MP2_I2C_SECURE_FENCE_I2C1_SECURE_FENCE_ENABLE_MASK) | (i2c1_secure_fence_enable << MP2_I2C_SECURE_FENCE_I2C1_SECURE_FENCE_ENABLE_SHIFT)
#define MP2_I2C_SECURE_FENCE_SET_GPIO0_SECURE_FENCE_ENABLE(mp2_i2c_secure_fence_reg, gpio0_secure_fence_enable) \
     mp2_i2c_secure_fence_reg = (mp2_i2c_secure_fence_reg & ~MP2_I2C_SECURE_FENCE_GPIO0_SECURE_FENCE_ENABLE_MASK) | (gpio0_secure_fence_enable << MP2_I2C_SECURE_FENCE_GPIO0_SECURE_FENCE_ENABLE_SHIFT)
#define MP2_I2C_SECURE_FENCE_SET_GPIO1_SECURE_FENCE_ENABLE(mp2_i2c_secure_fence_reg, gpio1_secure_fence_enable) \
     mp2_i2c_secure_fence_reg = (mp2_i2c_secure_fence_reg & ~MP2_I2C_SECURE_FENCE_GPIO1_SECURE_FENCE_ENABLE_MASK) | (gpio1_secure_fence_enable << MP2_I2C_SECURE_FENCE_GPIO1_SECURE_FENCE_ENABLE_SHIFT)
#define MP2_I2C_SECURE_FENCE_SET_GPIO2_SECURE_FENCE_ENABLE(mp2_i2c_secure_fence_reg, gpio2_secure_fence_enable) \
     mp2_i2c_secure_fence_reg = (mp2_i2c_secure_fence_reg & ~MP2_I2C_SECURE_FENCE_GPIO2_SECURE_FENCE_ENABLE_MASK) | (gpio2_secure_fence_enable << MP2_I2C_SECURE_FENCE_GPIO2_SECURE_FENCE_ENABLE_SHIFT)
#define MP2_I2C_SECURE_FENCE_SET_GPIO3_SECURE_FENCE_ENABLE(mp2_i2c_secure_fence_reg, gpio3_secure_fence_enable) \
     mp2_i2c_secure_fence_reg = (mp2_i2c_secure_fence_reg & ~MP2_I2C_SECURE_FENCE_GPIO3_SECURE_FENCE_ENABLE_MASK) | (gpio3_secure_fence_enable << MP2_I2C_SECURE_FENCE_GPIO3_SECURE_FENCE_ENABLE_SHIFT)
#define MP2_I2C_SECURE_FENCE_SET_GPIO4_SECURE_FENCE_ENABLE(mp2_i2c_secure_fence_reg, gpio4_secure_fence_enable) \
     mp2_i2c_secure_fence_reg = (mp2_i2c_secure_fence_reg & ~MP2_I2C_SECURE_FENCE_GPIO4_SECURE_FENCE_ENABLE_MASK) | (gpio4_secure_fence_enable << MP2_I2C_SECURE_FENCE_GPIO4_SECURE_FENCE_ENABLE_SHIFT)
#define MP2_I2C_SECURE_FENCE_SET_GPIO5_SECURE_FENCE_ENABLE(mp2_i2c_secure_fence_reg, gpio5_secure_fence_enable) \
     mp2_i2c_secure_fence_reg = (mp2_i2c_secure_fence_reg & ~MP2_I2C_SECURE_FENCE_GPIO5_SECURE_FENCE_ENABLE_MASK) | (gpio5_secure_fence_enable << MP2_I2C_SECURE_FENCE_GPIO5_SECURE_FENCE_ENABLE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c_secure_fence_t {
          unsigned int i2c0_secure_fence_enable       : MP2_I2C_SECURE_FENCE_I2C0_SECURE_FENCE_ENABLE_SIZE;
          unsigned int i2c1_secure_fence_enable       : MP2_I2C_SECURE_FENCE_I2C1_SECURE_FENCE_ENABLE_SIZE;
          unsigned int gpio0_secure_fence_enable      : MP2_I2C_SECURE_FENCE_GPIO0_SECURE_FENCE_ENABLE_SIZE;
          unsigned int gpio1_secure_fence_enable      : MP2_I2C_SECURE_FENCE_GPIO1_SECURE_FENCE_ENABLE_SIZE;
          unsigned int gpio2_secure_fence_enable      : MP2_I2C_SECURE_FENCE_GPIO2_SECURE_FENCE_ENABLE_SIZE;
          unsigned int gpio3_secure_fence_enable      : MP2_I2C_SECURE_FENCE_GPIO3_SECURE_FENCE_ENABLE_SIZE;
          unsigned int gpio4_secure_fence_enable      : MP2_I2C_SECURE_FENCE_GPIO4_SECURE_FENCE_ENABLE_SIZE;
          unsigned int gpio5_secure_fence_enable      : MP2_I2C_SECURE_FENCE_GPIO5_SECURE_FENCE_ENABLE_SIZE;
          unsigned int                                : 24;
     } mp2_i2c_secure_fence_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c_secure_fence_t {
          unsigned int                                : 24;
          unsigned int gpio5_secure_fence_enable      : MP2_I2C_SECURE_FENCE_GPIO5_SECURE_FENCE_ENABLE_SIZE;
          unsigned int gpio4_secure_fence_enable      : MP2_I2C_SECURE_FENCE_GPIO4_SECURE_FENCE_ENABLE_SIZE;
          unsigned int gpio3_secure_fence_enable      : MP2_I2C_SECURE_FENCE_GPIO3_SECURE_FENCE_ENABLE_SIZE;
          unsigned int gpio2_secure_fence_enable      : MP2_I2C_SECURE_FENCE_GPIO2_SECURE_FENCE_ENABLE_SIZE;
          unsigned int gpio1_secure_fence_enable      : MP2_I2C_SECURE_FENCE_GPIO1_SECURE_FENCE_ENABLE_SIZE;
          unsigned int gpio0_secure_fence_enable      : MP2_I2C_SECURE_FENCE_GPIO0_SECURE_FENCE_ENABLE_SIZE;
          unsigned int i2c1_secure_fence_enable       : MP2_I2C_SECURE_FENCE_I2C1_SECURE_FENCE_ENABLE_SIZE;
          unsigned int i2c0_secure_fence_enable       : MP2_I2C_SECURE_FENCE_I2C0_SECURE_FENCE_ENABLE_SIZE;
     } mp2_i2c_secure_fence_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c_secure_fence_t f;
} mp2_i2c_secure_fence_u;


/*
 * MP2_I2C_ACC_VIO_ADDR struct
 */

#define MP2_I2C_ACC_VIO_ADDR_REG_SIZE  32
#define MP2_I2C_ACC_VIO_ADDR_I2C_ACC_VIO_ADDR_SIZE 32

#define MP2_I2C_ACC_VIO_ADDR_I2C_ACC_VIO_ADDR_SHIFT 0

#define MP2_I2C_ACC_VIO_ADDR_I2C_ACC_VIO_ADDR_MASK 0xffffffff

#define MP2_I2C_ACC_VIO_ADDR_MASK \
     (MP2_I2C_ACC_VIO_ADDR_I2C_ACC_VIO_ADDR_MASK)

#define MP2_I2C_ACC_VIO_ADDR_DEFAULT   0x00000000

#define MP2_I2C_ACC_VIO_ADDR_GET_I2C_ACC_VIO_ADDR(mp2_i2c_acc_vio_addr) \
     ((mp2_i2c_acc_vio_addr & MP2_I2C_ACC_VIO_ADDR_I2C_ACC_VIO_ADDR_MASK) >> MP2_I2C_ACC_VIO_ADDR_I2C_ACC_VIO_ADDR_SHIFT)

#define MP2_I2C_ACC_VIO_ADDR_SET_I2C_ACC_VIO_ADDR(mp2_i2c_acc_vio_addr_reg, i2c_acc_vio_addr) \
     mp2_i2c_acc_vio_addr_reg = (mp2_i2c_acc_vio_addr_reg & ~MP2_I2C_ACC_VIO_ADDR_I2C_ACC_VIO_ADDR_MASK) | (i2c_acc_vio_addr << MP2_I2C_ACC_VIO_ADDR_I2C_ACC_VIO_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c_acc_vio_addr_t {
          unsigned int i2c_acc_vio_addr               : MP2_I2C_ACC_VIO_ADDR_I2C_ACC_VIO_ADDR_SIZE;
     } mp2_i2c_acc_vio_addr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c_acc_vio_addr_t {
          unsigned int i2c_acc_vio_addr               : MP2_I2C_ACC_VIO_ADDR_I2C_ACC_VIO_ADDR_SIZE;
     } mp2_i2c_acc_vio_addr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c_acc_vio_addr_t f;
} mp2_i2c_acc_vio_addr_u;


/*
 * MP2_I2C_ACC_VIO_STATUS struct
 */

#define MP2_I2C_ACC_VIO_STATUS_REG_SIZE 32
#define MP2_I2C_ACC_VIO_STATUS_ACC_VIO_STATUS_SIZE 1
#define MP2_I2C_ACC_VIO_STATUS_ACC_VIO_OP_SIZE 1
#define MP2_I2C_ACC_VIO_STATUS_ACC_VIO_AXPROT_SIZE 3
#define MP2_I2C_ACC_VIO_STATUS_ACC_VIO_UNIT_ID_SIZE 7
#define MP2_I2C_ACC_VIO_STATUS_ACC_VIO_INIT_ID_SIZE 10

#define MP2_I2C_ACC_VIO_STATUS_ACC_VIO_STATUS_SHIFT 0
#define MP2_I2C_ACC_VIO_STATUS_ACC_VIO_OP_SHIFT 1
#define MP2_I2C_ACC_VIO_STATUS_ACC_VIO_AXPROT_SHIFT 2
#define MP2_I2C_ACC_VIO_STATUS_ACC_VIO_UNIT_ID_SHIFT 5
#define MP2_I2C_ACC_VIO_STATUS_ACC_VIO_INIT_ID_SHIFT 12

#define MP2_I2C_ACC_VIO_STATUS_ACC_VIO_STATUS_MASK 0x1
#define MP2_I2C_ACC_VIO_STATUS_ACC_VIO_OP_MASK 0x2
#define MP2_I2C_ACC_VIO_STATUS_ACC_VIO_AXPROT_MASK 0x1c
#define MP2_I2C_ACC_VIO_STATUS_ACC_VIO_UNIT_ID_MASK 0xfe0
#define MP2_I2C_ACC_VIO_STATUS_ACC_VIO_INIT_ID_MASK 0x3ff000

#define MP2_I2C_ACC_VIO_STATUS_MASK \
     (MP2_I2C_ACC_VIO_STATUS_ACC_VIO_STATUS_MASK | \
      MP2_I2C_ACC_VIO_STATUS_ACC_VIO_OP_MASK | \
      MP2_I2C_ACC_VIO_STATUS_ACC_VIO_AXPROT_MASK | \
      MP2_I2C_ACC_VIO_STATUS_ACC_VIO_UNIT_ID_MASK | \
      MP2_I2C_ACC_VIO_STATUS_ACC_VIO_INIT_ID_MASK)

#define MP2_I2C_ACC_VIO_STATUS_DEFAULT 0x00000000

#define MP2_I2C_ACC_VIO_STATUS_GET_ACC_VIO_STATUS(mp2_i2c_acc_vio_status) \
     ((mp2_i2c_acc_vio_status & MP2_I2C_ACC_VIO_STATUS_ACC_VIO_STATUS_MASK) >> MP2_I2C_ACC_VIO_STATUS_ACC_VIO_STATUS_SHIFT)
#define MP2_I2C_ACC_VIO_STATUS_GET_ACC_VIO_OP(mp2_i2c_acc_vio_status) \
     ((mp2_i2c_acc_vio_status & MP2_I2C_ACC_VIO_STATUS_ACC_VIO_OP_MASK) >> MP2_I2C_ACC_VIO_STATUS_ACC_VIO_OP_SHIFT)
#define MP2_I2C_ACC_VIO_STATUS_GET_ACC_VIO_AXPROT(mp2_i2c_acc_vio_status) \
     ((mp2_i2c_acc_vio_status & MP2_I2C_ACC_VIO_STATUS_ACC_VIO_AXPROT_MASK) >> MP2_I2C_ACC_VIO_STATUS_ACC_VIO_AXPROT_SHIFT)
#define MP2_I2C_ACC_VIO_STATUS_GET_ACC_VIO_UNIT_ID(mp2_i2c_acc_vio_status) \
     ((mp2_i2c_acc_vio_status & MP2_I2C_ACC_VIO_STATUS_ACC_VIO_UNIT_ID_MASK) >> MP2_I2C_ACC_VIO_STATUS_ACC_VIO_UNIT_ID_SHIFT)
#define MP2_I2C_ACC_VIO_STATUS_GET_ACC_VIO_INIT_ID(mp2_i2c_acc_vio_status) \
     ((mp2_i2c_acc_vio_status & MP2_I2C_ACC_VIO_STATUS_ACC_VIO_INIT_ID_MASK) >> MP2_I2C_ACC_VIO_STATUS_ACC_VIO_INIT_ID_SHIFT)

#define MP2_I2C_ACC_VIO_STATUS_SET_ACC_VIO_STATUS(mp2_i2c_acc_vio_status_reg, acc_vio_status) \
     mp2_i2c_acc_vio_status_reg = (mp2_i2c_acc_vio_status_reg & ~MP2_I2C_ACC_VIO_STATUS_ACC_VIO_STATUS_MASK) | (acc_vio_status << MP2_I2C_ACC_VIO_STATUS_ACC_VIO_STATUS_SHIFT)
#define MP2_I2C_ACC_VIO_STATUS_SET_ACC_VIO_OP(mp2_i2c_acc_vio_status_reg, acc_vio_op) \
     mp2_i2c_acc_vio_status_reg = (mp2_i2c_acc_vio_status_reg & ~MP2_I2C_ACC_VIO_STATUS_ACC_VIO_OP_MASK) | (acc_vio_op << MP2_I2C_ACC_VIO_STATUS_ACC_VIO_OP_SHIFT)
#define MP2_I2C_ACC_VIO_STATUS_SET_ACC_VIO_AXPROT(mp2_i2c_acc_vio_status_reg, acc_vio_axprot) \
     mp2_i2c_acc_vio_status_reg = (mp2_i2c_acc_vio_status_reg & ~MP2_I2C_ACC_VIO_STATUS_ACC_VIO_AXPROT_MASK) | (acc_vio_axprot << MP2_I2C_ACC_VIO_STATUS_ACC_VIO_AXPROT_SHIFT)
#define MP2_I2C_ACC_VIO_STATUS_SET_ACC_VIO_UNIT_ID(mp2_i2c_acc_vio_status_reg, acc_vio_unit_id) \
     mp2_i2c_acc_vio_status_reg = (mp2_i2c_acc_vio_status_reg & ~MP2_I2C_ACC_VIO_STATUS_ACC_VIO_UNIT_ID_MASK) | (acc_vio_unit_id << MP2_I2C_ACC_VIO_STATUS_ACC_VIO_UNIT_ID_SHIFT)
#define MP2_I2C_ACC_VIO_STATUS_SET_ACC_VIO_INIT_ID(mp2_i2c_acc_vio_status_reg, acc_vio_init_id) \
     mp2_i2c_acc_vio_status_reg = (mp2_i2c_acc_vio_status_reg & ~MP2_I2C_ACC_VIO_STATUS_ACC_VIO_INIT_ID_MASK) | (acc_vio_init_id << MP2_I2C_ACC_VIO_STATUS_ACC_VIO_INIT_ID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c_acc_vio_status_t {
          unsigned int acc_vio_status                 : MP2_I2C_ACC_VIO_STATUS_ACC_VIO_STATUS_SIZE;
          unsigned int acc_vio_op                     : MP2_I2C_ACC_VIO_STATUS_ACC_VIO_OP_SIZE;
          unsigned int acc_vio_axprot                 : MP2_I2C_ACC_VIO_STATUS_ACC_VIO_AXPROT_SIZE;
          unsigned int acc_vio_unit_id                : MP2_I2C_ACC_VIO_STATUS_ACC_VIO_UNIT_ID_SIZE;
          unsigned int acc_vio_init_id                : MP2_I2C_ACC_VIO_STATUS_ACC_VIO_INIT_ID_SIZE;
          unsigned int                                : 10;
     } mp2_i2c_acc_vio_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c_acc_vio_status_t {
          unsigned int                                : 10;
          unsigned int acc_vio_init_id                : MP2_I2C_ACC_VIO_STATUS_ACC_VIO_INIT_ID_SIZE;
          unsigned int acc_vio_unit_id                : MP2_I2C_ACC_VIO_STATUS_ACC_VIO_UNIT_ID_SIZE;
          unsigned int acc_vio_axprot                 : MP2_I2C_ACC_VIO_STATUS_ACC_VIO_AXPROT_SIZE;
          unsigned int acc_vio_op                     : MP2_I2C_ACC_VIO_STATUS_ACC_VIO_OP_SIZE;
          unsigned int acc_vio_status                 : MP2_I2C_ACC_VIO_STATUS_ACC_VIO_STATUS_SIZE;
     } mp2_i2c_acc_vio_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c_acc_vio_status_t f;
} mp2_i2c_acc_vio_status_u;


/*
 * MP2_I2C_CG_CTRL struct
 */

#define MP2_I2C_CG_CTRL_REG_SIZE       32
#define MP2_I2C_CG_CTRL_CG_TYPE_SIZE   1
#define MP2_I2C_CG_CTRL_CG_OVERRIDE_SIZE 1
#define MP2_I2C_CG_CTRL_CG_EN_SIZE     1
#define MP2_I2C_CG_CTRL_CG_IC_EN_SIZE  1

#define MP2_I2C_CG_CTRL_CG_TYPE_SHIFT  0
#define MP2_I2C_CG_CTRL_CG_OVERRIDE_SHIFT 1
#define MP2_I2C_CG_CTRL_CG_EN_SHIFT    2
#define MP2_I2C_CG_CTRL_CG_IC_EN_SHIFT 3

#define MP2_I2C_CG_CTRL_CG_TYPE_MASK   0x1
#define MP2_I2C_CG_CTRL_CG_OVERRIDE_MASK 0x2
#define MP2_I2C_CG_CTRL_CG_EN_MASK     0x4
#define MP2_I2C_CG_CTRL_CG_IC_EN_MASK  0x8

#define MP2_I2C_CG_CTRL_MASK \
     (MP2_I2C_CG_CTRL_CG_TYPE_MASK | \
      MP2_I2C_CG_CTRL_CG_OVERRIDE_MASK | \
      MP2_I2C_CG_CTRL_CG_EN_MASK | \
      MP2_I2C_CG_CTRL_CG_IC_EN_MASK)

#define MP2_I2C_CG_CTRL_DEFAULT        0x00000000

#define MP2_I2C_CG_CTRL_GET_CG_TYPE(mp2_i2c_cg_ctrl) \
     ((mp2_i2c_cg_ctrl & MP2_I2C_CG_CTRL_CG_TYPE_MASK) >> MP2_I2C_CG_CTRL_CG_TYPE_SHIFT)
#define MP2_I2C_CG_CTRL_GET_CG_OVERRIDE(mp2_i2c_cg_ctrl) \
     ((mp2_i2c_cg_ctrl & MP2_I2C_CG_CTRL_CG_OVERRIDE_MASK) >> MP2_I2C_CG_CTRL_CG_OVERRIDE_SHIFT)
#define MP2_I2C_CG_CTRL_GET_CG_EN(mp2_i2c_cg_ctrl) \
     ((mp2_i2c_cg_ctrl & MP2_I2C_CG_CTRL_CG_EN_MASK) >> MP2_I2C_CG_CTRL_CG_EN_SHIFT)
#define MP2_I2C_CG_CTRL_GET_CG_IC_EN(mp2_i2c_cg_ctrl) \
     ((mp2_i2c_cg_ctrl & MP2_I2C_CG_CTRL_CG_IC_EN_MASK) >> MP2_I2C_CG_CTRL_CG_IC_EN_SHIFT)

#define MP2_I2C_CG_CTRL_SET_CG_TYPE(mp2_i2c_cg_ctrl_reg, cg_type) \
     mp2_i2c_cg_ctrl_reg = (mp2_i2c_cg_ctrl_reg & ~MP2_I2C_CG_CTRL_CG_TYPE_MASK) | (cg_type << MP2_I2C_CG_CTRL_CG_TYPE_SHIFT)
#define MP2_I2C_CG_CTRL_SET_CG_OVERRIDE(mp2_i2c_cg_ctrl_reg, cg_override) \
     mp2_i2c_cg_ctrl_reg = (mp2_i2c_cg_ctrl_reg & ~MP2_I2C_CG_CTRL_CG_OVERRIDE_MASK) | (cg_override << MP2_I2C_CG_CTRL_CG_OVERRIDE_SHIFT)
#define MP2_I2C_CG_CTRL_SET_CG_EN(mp2_i2c_cg_ctrl_reg, cg_en) \
     mp2_i2c_cg_ctrl_reg = (mp2_i2c_cg_ctrl_reg & ~MP2_I2C_CG_CTRL_CG_EN_MASK) | (cg_en << MP2_I2C_CG_CTRL_CG_EN_SHIFT)
#define MP2_I2C_CG_CTRL_SET_CG_IC_EN(mp2_i2c_cg_ctrl_reg, cg_ic_en) \
     mp2_i2c_cg_ctrl_reg = (mp2_i2c_cg_ctrl_reg & ~MP2_I2C_CG_CTRL_CG_IC_EN_MASK) | (cg_ic_en << MP2_I2C_CG_CTRL_CG_IC_EN_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c_cg_ctrl_t {
          unsigned int cg_type                        : MP2_I2C_CG_CTRL_CG_TYPE_SIZE;
          unsigned int cg_override                    : MP2_I2C_CG_CTRL_CG_OVERRIDE_SIZE;
          unsigned int cg_en                          : MP2_I2C_CG_CTRL_CG_EN_SIZE;
          unsigned int cg_ic_en                       : MP2_I2C_CG_CTRL_CG_IC_EN_SIZE;
          unsigned int                                : 28;
     } mp2_i2c_cg_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c_cg_ctrl_t {
          unsigned int                                : 28;
          unsigned int cg_ic_en                       : MP2_I2C_CG_CTRL_CG_IC_EN_SIZE;
          unsigned int cg_en                          : MP2_I2C_CG_CTRL_CG_EN_SIZE;
          unsigned int cg_override                    : MP2_I2C_CG_CTRL_CG_OVERRIDE_SIZE;
          unsigned int cg_type                        : MP2_I2C_CG_CTRL_CG_TYPE_SIZE;
     } mp2_i2c_cg_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c_cg_ctrl_t f;
} mp2_i2c_cg_ctrl_u;


/*
 * MP2_I2C_CG_MASK struct
 */

#define MP2_I2C_CG_MASK_REG_SIZE       32
#define MP2_I2C_CG_MASK_GPIO_MASK_SIZE 9

#define MP2_I2C_CG_MASK_GPIO_MASK_SHIFT 0

#define MP2_I2C_CG_MASK_GPIO_MASK_MASK 0x1ff

#define MP2_I2C_CG_MASK_MASK \
     (MP2_I2C_CG_MASK_GPIO_MASK_MASK)

#define MP2_I2C_CG_MASK_DEFAULT        0x00000000

#define MP2_I2C_CG_MASK_GET_GPIO_MASK(mp2_i2c_cg_mask) \
     ((mp2_i2c_cg_mask & MP2_I2C_CG_MASK_GPIO_MASK_MASK) >> MP2_I2C_CG_MASK_GPIO_MASK_SHIFT)

#define MP2_I2C_CG_MASK_SET_GPIO_MASK(mp2_i2c_cg_mask_reg, gpio_mask) \
     mp2_i2c_cg_mask_reg = (mp2_i2c_cg_mask_reg & ~MP2_I2C_CG_MASK_GPIO_MASK_MASK) | (gpio_mask << MP2_I2C_CG_MASK_GPIO_MASK_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c_cg_mask_t {
          unsigned int gpio_mask                      : MP2_I2C_CG_MASK_GPIO_MASK_SIZE;
          unsigned int                                : 23;
     } mp2_i2c_cg_mask_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c_cg_mask_t {
          unsigned int                                : 23;
          unsigned int gpio_mask                      : MP2_I2C_CG_MASK_GPIO_MASK_SIZE;
     } mp2_i2c_cg_mask_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c_cg_mask_t f;
} mp2_i2c_cg_mask_u;


/*
 * MP2_I2C_CG_LEVEL struct
 */

#define MP2_I2C_CG_LEVEL_REG_SIZE      32
#define MP2_I2C_CG_LEVEL_GPIO_LEVEL_SIZE 9

#define MP2_I2C_CG_LEVEL_GPIO_LEVEL_SHIFT 0

#define MP2_I2C_CG_LEVEL_GPIO_LEVEL_MASK 0x1ff

#define MP2_I2C_CG_LEVEL_MASK \
     (MP2_I2C_CG_LEVEL_GPIO_LEVEL_MASK)

#define MP2_I2C_CG_LEVEL_DEFAULT       0x00000000

#define MP2_I2C_CG_LEVEL_GET_GPIO_LEVEL(mp2_i2c_cg_level) \
     ((mp2_i2c_cg_level & MP2_I2C_CG_LEVEL_GPIO_LEVEL_MASK) >> MP2_I2C_CG_LEVEL_GPIO_LEVEL_SHIFT)

#define MP2_I2C_CG_LEVEL_SET_GPIO_LEVEL(mp2_i2c_cg_level_reg, gpio_level) \
     mp2_i2c_cg_level_reg = (mp2_i2c_cg_level_reg & ~MP2_I2C_CG_LEVEL_GPIO_LEVEL_MASK) | (gpio_level << MP2_I2C_CG_LEVEL_GPIO_LEVEL_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c_cg_level_t {
          unsigned int gpio_level                     : MP2_I2C_CG_LEVEL_GPIO_LEVEL_SIZE;
          unsigned int                                : 23;
     } mp2_i2c_cg_level_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c_cg_level_t {
          unsigned int                                : 23;
          unsigned int gpio_level                     : MP2_I2C_CG_LEVEL_GPIO_LEVEL_SIZE;
     } mp2_i2c_cg_level_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c_cg_level_t f;
} mp2_i2c_cg_level_u;


/*
 * MP2_I2C_CG_TIMEOUT struct
 */

#define MP2_I2C_CG_TIMEOUT_REG_SIZE    32
#define MP2_I2C_CG_TIMEOUT_CG_TIMEOUT_SIZE 20

#define MP2_I2C_CG_TIMEOUT_CG_TIMEOUT_SHIFT 0

#define MP2_I2C_CG_TIMEOUT_CG_TIMEOUT_MASK 0xfffff

#define MP2_I2C_CG_TIMEOUT_MASK \
     (MP2_I2C_CG_TIMEOUT_CG_TIMEOUT_MASK)

#define MP2_I2C_CG_TIMEOUT_DEFAULT     0x00000000

#define MP2_I2C_CG_TIMEOUT_GET_CG_TIMEOUT(mp2_i2c_cg_timeout) \
     ((mp2_i2c_cg_timeout & MP2_I2C_CG_TIMEOUT_CG_TIMEOUT_MASK) >> MP2_I2C_CG_TIMEOUT_CG_TIMEOUT_SHIFT)

#define MP2_I2C_CG_TIMEOUT_SET_CG_TIMEOUT(mp2_i2c_cg_timeout_reg, cg_timeout) \
     mp2_i2c_cg_timeout_reg = (mp2_i2c_cg_timeout_reg & ~MP2_I2C_CG_TIMEOUT_CG_TIMEOUT_MASK) | (cg_timeout << MP2_I2C_CG_TIMEOUT_CG_TIMEOUT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c_cg_timeout_t {
          unsigned int cg_timeout                     : MP2_I2C_CG_TIMEOUT_CG_TIMEOUT_SIZE;
          unsigned int                                : 12;
     } mp2_i2c_cg_timeout_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c_cg_timeout_t {
          unsigned int                                : 12;
          unsigned int cg_timeout                     : MP2_I2C_CG_TIMEOUT_CG_TIMEOUT_SIZE;
     } mp2_i2c_cg_timeout_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c_cg_timeout_t f;
} mp2_i2c_cg_timeout_u;


#endif


