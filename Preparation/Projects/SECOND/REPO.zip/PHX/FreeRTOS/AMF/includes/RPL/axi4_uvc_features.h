// Copyright (c) 2010 - 2019 Advanced Micro Devices, Inc. All rights reserved.
#ifndef __AXI4_UVC_FEATURES_H__
#define __AXI4_UVC_FEATURES_H__
// reference features

// imported features

// local features
#define AXI4_UVC__VARIANT axi4
#define AXI4_UVC__VARIANT__AXI4 1
#define AXI4_UVC__ENABLE_AXI4_UVC 1
#define AXI4_UVC__ENABLE_AXI4_UVC__1 1
#endif
