// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MP2_DMAC_FIDDLE_H)
#define _MP2_DMAC_FIDDLE_H

/*****************************************************************************************************************
 *
 *	mp2_dmac_reg.h
 *
 *	Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif


/*******************************************************
 * Values
 *******************************************************/


/*******************************************************
 * Structures
 *******************************************************/

/*
 * MP2_DMAC_ACC_VIOLATION_LOG_ADDR struct
 */

#define MP2_DMAC_ACC_VIOLATION_LOG_ADDR_REG_SIZE 32
#define MP2_DMAC_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SIZE 32

#define MP2_DMAC_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SHIFT 0

#define MP2_DMAC_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK 0xffffffff

#define MP2_DMAC_ACC_VIOLATION_LOG_ADDR_MASK \
     (MP2_DMAC_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK)

#define MP2_DMAC_ACC_VIOLATION_LOG_ADDR_DEFAULT 0x00000000

#define MP2_DMAC_ACC_VIOLATION_LOG_ADDR_GET_AXI_ADDR(mp2_dmac_acc_violation_log_addr) \
     ((mp2_dmac_acc_violation_log_addr & MP2_DMAC_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK) >> MP2_DMAC_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SHIFT)

#define MP2_DMAC_ACC_VIOLATION_LOG_ADDR_SET_AXI_ADDR(mp2_dmac_acc_violation_log_addr_reg, axi_addr) \
     mp2_dmac_acc_violation_log_addr_reg = (mp2_dmac_acc_violation_log_addr_reg & ~MP2_DMAC_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK) | (axi_addr << MP2_DMAC_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dmac_acc_violation_log_addr_t {
          unsigned int axi_addr                       : MP2_DMAC_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SIZE;
     } mp2_dmac_acc_violation_log_addr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dmac_acc_violation_log_addr_t {
          unsigned int axi_addr                       : MP2_DMAC_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SIZE;
     } mp2_dmac_acc_violation_log_addr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dmac_acc_violation_log_addr_t f;
} mp2_dmac_acc_violation_log_addr_u;


/*
 * MP2_DMAC_ACC_VIOLATION_LOG_STATUS struct
 */

#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_REG_SIZE 32
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE 1
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE 2
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE 1
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_AXI_ID_SIZE 21
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SIZE 3

#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT 0
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT 1
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT 3
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_AXI_ID_SHIFT 8
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SHIFT 29

#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK 0x1
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK 0x6
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK 0x8
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK 0x1fffff00
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_AXI_APROT_MASK 0xe0000000

#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_MASK \
     (MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK | \
      MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK | \
      MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK | \
      MP2_DMAC_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK | \
      MP2_DMAC_ACC_VIOLATION_LOG_STATUS_AXI_APROT_MASK)

#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_DEFAULT 0x00000000

#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_DETECTED(mp2_dmac_acc_violation_log_status) \
     ((mp2_dmac_acc_violation_log_status & MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) >> MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_TYPE(mp2_dmac_acc_violation_log_status) \
     ((mp2_dmac_acc_violation_log_status & MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) >> MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_LOG_CLEAR(mp2_dmac_acc_violation_log_status) \
     ((mp2_dmac_acc_violation_log_status & MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) >> MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_GET_AXI_ID(mp2_dmac_acc_violation_log_status) \
     ((mp2_dmac_acc_violation_log_status & MP2_DMAC_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK) >> MP2_DMAC_ACC_VIOLATION_LOG_STATUS_AXI_ID_SHIFT)
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_GET_AXI_APROT(mp2_dmac_acc_violation_log_status) \
     ((mp2_dmac_acc_violation_log_status & MP2_DMAC_ACC_VIOLATION_LOG_STATUS_AXI_APROT_MASK) >> MP2_DMAC_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SHIFT)

#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_DETECTED(mp2_dmac_acc_violation_log_status_reg, acc_violation_detected) \
     mp2_dmac_acc_violation_log_status_reg = (mp2_dmac_acc_violation_log_status_reg & ~MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) | (acc_violation_detected << MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_TYPE(mp2_dmac_acc_violation_log_status_reg, acc_violation_type) \
     mp2_dmac_acc_violation_log_status_reg = (mp2_dmac_acc_violation_log_status_reg & ~MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) | (acc_violation_type << MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_LOG_CLEAR(mp2_dmac_acc_violation_log_status_reg, acc_violation_log_clear) \
     mp2_dmac_acc_violation_log_status_reg = (mp2_dmac_acc_violation_log_status_reg & ~MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) | (acc_violation_log_clear << MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_SET_AXI_ID(mp2_dmac_acc_violation_log_status_reg, axi_id) \
     mp2_dmac_acc_violation_log_status_reg = (mp2_dmac_acc_violation_log_status_reg & ~MP2_DMAC_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK) | (axi_id << MP2_DMAC_ACC_VIOLATION_LOG_STATUS_AXI_ID_SHIFT)
#define MP2_DMAC_ACC_VIOLATION_LOG_STATUS_SET_AXI_APROT(mp2_dmac_acc_violation_log_status_reg, axi_aprot) \
     mp2_dmac_acc_violation_log_status_reg = (mp2_dmac_acc_violation_log_status_reg & ~MP2_DMAC_ACC_VIOLATION_LOG_STATUS_AXI_APROT_MASK) | (axi_aprot << MP2_DMAC_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dmac_acc_violation_log_status_t {
          unsigned int acc_violation_detected         : MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
          unsigned int acc_violation_type             : MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
          unsigned int acc_violation_log_clear        : MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
          unsigned int                                : 4;
          unsigned int axi_id                         : MP2_DMAC_ACC_VIOLATION_LOG_STATUS_AXI_ID_SIZE;
          unsigned int axi_aprot                      : MP2_DMAC_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SIZE;
     } mp2_dmac_acc_violation_log_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dmac_acc_violation_log_status_t {
          unsigned int axi_aprot                      : MP2_DMAC_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SIZE;
          unsigned int axi_id                         : MP2_DMAC_ACC_VIOLATION_LOG_STATUS_AXI_ID_SIZE;
          unsigned int                                : 4;
          unsigned int acc_violation_log_clear        : MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
          unsigned int acc_violation_type             : MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
          unsigned int acc_violation_detected         : MP2_DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
     } mp2_dmac_acc_violation_log_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dmac_acc_violation_log_status_t f;
} mp2_dmac_acc_violation_log_status_u;


/*
 * MP2_DMAC_MISC_CTRL struct
 */

#define MP2_DMAC_MISC_CTRL_REG_SIZE    32
#define MP2_DMAC_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SIZE 1
#define MP2_DMAC_MISC_CTRL_CLK_GATE_EN_SIZE 1

#define MP2_DMAC_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SHIFT 0
#define MP2_DMAC_MISC_CTRL_CLK_GATE_EN_SHIFT 1

#define MP2_DMAC_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK 0x1
#define MP2_DMAC_MISC_CTRL_CLK_GATE_EN_MASK 0x2

#define MP2_DMAC_MISC_CTRL_MASK \
     (MP2_DMAC_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK | \
      MP2_DMAC_MISC_CTRL_CLK_GATE_EN_MASK)

#define MP2_DMAC_MISC_CTRL_DEFAULT     0x00000003

#define MP2_DMAC_MISC_CTRL_GET_ALLOW_NON_PRIV_REG_ACC(mp2_dmac_misc_ctrl) \
     ((mp2_dmac_misc_ctrl & MP2_DMAC_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK) >> MP2_DMAC_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SHIFT)
#define MP2_DMAC_MISC_CTRL_GET_CLK_GATE_EN(mp2_dmac_misc_ctrl) \
     ((mp2_dmac_misc_ctrl & MP2_DMAC_MISC_CTRL_CLK_GATE_EN_MASK) >> MP2_DMAC_MISC_CTRL_CLK_GATE_EN_SHIFT)

#define MP2_DMAC_MISC_CTRL_SET_ALLOW_NON_PRIV_REG_ACC(mp2_dmac_misc_ctrl_reg, allow_non_priv_reg_acc) \
     mp2_dmac_misc_ctrl_reg = (mp2_dmac_misc_ctrl_reg & ~MP2_DMAC_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK) | (allow_non_priv_reg_acc << MP2_DMAC_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SHIFT)
#define MP2_DMAC_MISC_CTRL_SET_CLK_GATE_EN(mp2_dmac_misc_ctrl_reg, clk_gate_en) \
     mp2_dmac_misc_ctrl_reg = (mp2_dmac_misc_ctrl_reg & ~MP2_DMAC_MISC_CTRL_CLK_GATE_EN_MASK) | (clk_gate_en << MP2_DMAC_MISC_CTRL_CLK_GATE_EN_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dmac_misc_ctrl_t {
          unsigned int allow_non_priv_reg_acc         : MP2_DMAC_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SIZE;
          unsigned int clk_gate_en                    : MP2_DMAC_MISC_CTRL_CLK_GATE_EN_SIZE;
          unsigned int                                : 30;
     } mp2_dmac_misc_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dmac_misc_ctrl_t {
          unsigned int                                : 30;
          unsigned int clk_gate_en                    : MP2_DMAC_MISC_CTRL_CLK_GATE_EN_SIZE;
          unsigned int allow_non_priv_reg_acc         : MP2_DMAC_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SIZE;
     } mp2_dmac_misc_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dmac_misc_ctrl_t f;
} mp2_dmac_misc_ctrl_u;


#endif


