// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MP_DMAC_FIDDLE_H)
#define _MP_DMAC_FIDDLE_H

/*****************************************************************************************************************
 *
 *	mp_dmac_reg.h
 *
 *	Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif


/*******************************************************
 * Values
 *******************************************************/


/*******************************************************
 * Structures
 *******************************************************/

/*
 * DMAC_ACC_VIOLATION_LOG_ADDR struct
 */

#define DMAC_ACC_VIOLATION_LOG_ADDR_REG_SIZE 32
#define DMAC_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SIZE 32

#define DMAC_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SHIFT 0

#define DMAC_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK 0xffffffff

#define DMAC_ACC_VIOLATION_LOG_ADDR_MASK \
     (DMAC_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK)

#define DMAC_ACC_VIOLATION_LOG_ADDR_DEFAULT 0x00000000

#define DMAC_ACC_VIOLATION_LOG_ADDR_GET_AXI_ADDR(dmac_acc_violation_log_addr) \
     ((dmac_acc_violation_log_addr & DMAC_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK) >> DMAC_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SHIFT)

#define DMAC_ACC_VIOLATION_LOG_ADDR_SET_AXI_ADDR(dmac_acc_violation_log_addr_reg, axi_addr) \
     dmac_acc_violation_log_addr_reg = (dmac_acc_violation_log_addr_reg & ~DMAC_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK) | (axi_addr << DMAC_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _dmac_acc_violation_log_addr_t {
          unsigned int axi_addr                       : DMAC_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SIZE;
     } dmac_acc_violation_log_addr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _dmac_acc_violation_log_addr_t {
          unsigned int axi_addr                       : DMAC_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SIZE;
     } dmac_acc_violation_log_addr_t;

#endif

typedef union {
     unsigned int val : 32;
     dmac_acc_violation_log_addr_t f;
} dmac_acc_violation_log_addr_u;


/*
 * DMAC_ACC_VIOLATION_LOG_STATUS struct
 */

#define DMAC_ACC_VIOLATION_LOG_STATUS_REG_SIZE 32
#define DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE 1
#define DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE 2
#define DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE 1
#define DMAC_ACC_VIOLATION_LOG_STATUS_AXI_ID_SIZE 21
#define DMAC_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SIZE 3

#define DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT 0
#define DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT 1
#define DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT 3
#define DMAC_ACC_VIOLATION_LOG_STATUS_AXI_ID_SHIFT 8
#define DMAC_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SHIFT 29

#define DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK 0x1
#define DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK 0x6
#define DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK 0x8
#define DMAC_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK 0x1fffff00
#define DMAC_ACC_VIOLATION_LOG_STATUS_AXI_APROT_MASK 0xe0000000

#define DMAC_ACC_VIOLATION_LOG_STATUS_MASK \
     (DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK | \
      DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK | \
      DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK | \
      DMAC_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK | \
      DMAC_ACC_VIOLATION_LOG_STATUS_AXI_APROT_MASK)

#define DMAC_ACC_VIOLATION_LOG_STATUS_DEFAULT 0x00000000

#define DMAC_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_DETECTED(dmac_acc_violation_log_status) \
     ((dmac_acc_violation_log_status & DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) >> DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define DMAC_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_TYPE(dmac_acc_violation_log_status) \
     ((dmac_acc_violation_log_status & DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) >> DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define DMAC_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_LOG_CLEAR(dmac_acc_violation_log_status) \
     ((dmac_acc_violation_log_status & DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) >> DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)
#define DMAC_ACC_VIOLATION_LOG_STATUS_GET_AXI_ID(dmac_acc_violation_log_status) \
     ((dmac_acc_violation_log_status & DMAC_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK) >> DMAC_ACC_VIOLATION_LOG_STATUS_AXI_ID_SHIFT)
#define DMAC_ACC_VIOLATION_LOG_STATUS_GET_AXI_APROT(dmac_acc_violation_log_status) \
     ((dmac_acc_violation_log_status & DMAC_ACC_VIOLATION_LOG_STATUS_AXI_APROT_MASK) >> DMAC_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SHIFT)

#define DMAC_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_DETECTED(dmac_acc_violation_log_status_reg, acc_violation_detected) \
     dmac_acc_violation_log_status_reg = (dmac_acc_violation_log_status_reg & ~DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) | (acc_violation_detected << DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define DMAC_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_TYPE(dmac_acc_violation_log_status_reg, acc_violation_type) \
     dmac_acc_violation_log_status_reg = (dmac_acc_violation_log_status_reg & ~DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) | (acc_violation_type << DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define DMAC_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_LOG_CLEAR(dmac_acc_violation_log_status_reg, acc_violation_log_clear) \
     dmac_acc_violation_log_status_reg = (dmac_acc_violation_log_status_reg & ~DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) | (acc_violation_log_clear << DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)
#define DMAC_ACC_VIOLATION_LOG_STATUS_SET_AXI_ID(dmac_acc_violation_log_status_reg, axi_id) \
     dmac_acc_violation_log_status_reg = (dmac_acc_violation_log_status_reg & ~DMAC_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK) | (axi_id << DMAC_ACC_VIOLATION_LOG_STATUS_AXI_ID_SHIFT)
#define DMAC_ACC_VIOLATION_LOG_STATUS_SET_AXI_APROT(dmac_acc_violation_log_status_reg, axi_aprot) \
     dmac_acc_violation_log_status_reg = (dmac_acc_violation_log_status_reg & ~DMAC_ACC_VIOLATION_LOG_STATUS_AXI_APROT_MASK) | (axi_aprot << DMAC_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _dmac_acc_violation_log_status_t {
          unsigned int acc_violation_detected         : DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
          unsigned int acc_violation_type             : DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
          unsigned int acc_violation_log_clear        : DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
          unsigned int                                : 4;
          unsigned int axi_id                         : DMAC_ACC_VIOLATION_LOG_STATUS_AXI_ID_SIZE;
          unsigned int axi_aprot                      : DMAC_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SIZE;
     } dmac_acc_violation_log_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _dmac_acc_violation_log_status_t {
          unsigned int axi_aprot                      : DMAC_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SIZE;
          unsigned int axi_id                         : DMAC_ACC_VIOLATION_LOG_STATUS_AXI_ID_SIZE;
          unsigned int                                : 4;
          unsigned int acc_violation_log_clear        : DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
          unsigned int acc_violation_type             : DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
          unsigned int acc_violation_detected         : DMAC_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
     } dmac_acc_violation_log_status_t;

#endif

typedef union {
     unsigned int val : 32;
     dmac_acc_violation_log_status_t f;
} dmac_acc_violation_log_status_u;


/*
 * DMAC_MISC_CTRL struct
 */

#define DMAC_MISC_CTRL_REG_SIZE        32
#define DMAC_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SIZE 1
#define DMAC_MISC_CTRL_CLK_GATE_EN_SIZE 1

#define DMAC_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SHIFT 0
#define DMAC_MISC_CTRL_CLK_GATE_EN_SHIFT 1

#define DMAC_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK 0x1
#define DMAC_MISC_CTRL_CLK_GATE_EN_MASK 0x2

#define DMAC_MISC_CTRL_MASK \
     (DMAC_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK | \
      DMAC_MISC_CTRL_CLK_GATE_EN_MASK)

#define DMAC_MISC_CTRL_DEFAULT         0x00000003

#define DMAC_MISC_CTRL_GET_ALLOW_NON_PRIV_REG_ACC(dmac_misc_ctrl) \
     ((dmac_misc_ctrl & DMAC_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK) >> DMAC_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SHIFT)
#define DMAC_MISC_CTRL_GET_CLK_GATE_EN(dmac_misc_ctrl) \
     ((dmac_misc_ctrl & DMAC_MISC_CTRL_CLK_GATE_EN_MASK) >> DMAC_MISC_CTRL_CLK_GATE_EN_SHIFT)

#define DMAC_MISC_CTRL_SET_ALLOW_NON_PRIV_REG_ACC(dmac_misc_ctrl_reg, allow_non_priv_reg_acc) \
     dmac_misc_ctrl_reg = (dmac_misc_ctrl_reg & ~DMAC_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK) | (allow_non_priv_reg_acc << DMAC_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SHIFT)
#define DMAC_MISC_CTRL_SET_CLK_GATE_EN(dmac_misc_ctrl_reg, clk_gate_en) \
     dmac_misc_ctrl_reg = (dmac_misc_ctrl_reg & ~DMAC_MISC_CTRL_CLK_GATE_EN_MASK) | (clk_gate_en << DMAC_MISC_CTRL_CLK_GATE_EN_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _dmac_misc_ctrl_t {
          unsigned int allow_non_priv_reg_acc         : DMAC_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SIZE;
          unsigned int clk_gate_en                    : DMAC_MISC_CTRL_CLK_GATE_EN_SIZE;
          unsigned int                                : 30;
     } dmac_misc_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _dmac_misc_ctrl_t {
          unsigned int                                : 30;
          unsigned int clk_gate_en                    : DMAC_MISC_CTRL_CLK_GATE_EN_SIZE;
          unsigned int allow_non_priv_reg_acc         : DMAC_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SIZE;
     } dmac_misc_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     dmac_misc_ctrl_t f;
} dmac_misc_ctrl_u;


#endif


