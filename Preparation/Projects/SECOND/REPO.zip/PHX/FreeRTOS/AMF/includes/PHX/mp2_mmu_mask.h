// Copyright (c) 1994 - 2022 Advanced Micro Devices, Inc. All rights reserved.

#if !defined (_MP2_MMU_MASK_H)
#define _MP2_MMU_MASK_H

/*
 *    mp2_mmu_mask.h   
 *
 *    Register Spec Release:  <unknown>
 *
 *
 *      (c) 2021 Advanced Micro Devices, Inc.  (unpublished)
 *
 *        All rights reserved.  This notice is intended as a precaution against
 *     inadvertent publication and does not imply publication or any waiver
 *      of confidentiality.  The year included in the foregoing notice is the
 *     year of creation of the work.
 *
 */

/*******************************************************
 * Read and Write Masks
 *******************************************************/

#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_READ_MASK 0xffffffff
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_WRITE_MASK 0x00000000

#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_READ_MASK 0xc1fffffb
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_WRITE_MASK 0xc0000000

#define MP2_MMU_MISC_CNTL_READ_MASK    0x00ff000d
#define MP2_MMU_MISC_CNTL_WRITE_MASK   0x003f000d

#define MP2_MMU_ACCESS_ERR_LOG_READ_MASK 0x0fffff1f
#define MP2_MMU_ACCESS_ERR_LOG_WRITE_MASK 0x00000018

#define MP2_MMU_SRAM_UNSECURE_BAR_READ_MASK 0xffffffff
#define MP2_MMU_SRAM_UNSECURE_BAR_WRITE_MASK 0xffffffff

#define MP2_MMU_SCRATCH_0_READ_MASK    0xffffffff
#define MP2_MMU_SCRATCH_0_WRITE_MASK   0xffffffff

#define MP2_MMU_SCRATCH_1_READ_MASK    0xffffffff
#define MP2_MMU_SCRATCH_1_WRITE_MASK   0xffffffff

#define MP2_MMU_SCRATCH_2_READ_MASK    0xffffffff
#define MP2_MMU_SCRATCH_2_WRITE_MASK   0xffffffff

#define MP2_MMU_SCRATCH_3_READ_MASK    0xffffffff
#define MP2_MMU_SCRATCH_3_WRITE_MASK   0xffffffff

#define MP2_MMU_SCRATCH_4_READ_MASK    0xffffffff
#define MP2_MMU_SCRATCH_4_WRITE_MASK   0xffffffff

#define MP2_MMU_SCRATCH_5_READ_MASK    0xffffffff
#define MP2_MMU_SCRATCH_5_WRITE_MASK   0xffffffff

#define MP2_MMU_SCRATCH_6_READ_MASK    0xffffffff
#define MP2_MMU_SCRATCH_6_WRITE_MASK   0xffffffff

#define MP2_MMU_SCRATCH_7_READ_MASK    0xffffffff
#define MP2_MMU_SCRATCH_7_WRITE_MASK   0xffffffff

#endif


