// Copyright (c) 2010 - 2019 Advanced Micro Devices, Inc. All rights reserved.
#ifndef __TOOLS_FEATURES_H__
#define __TOOLS_FEATURES_H__
// reference features

// imported features

// local features
#define TOOLS__BIA_IFRIT_VERILOG_CTNR__DEFAULT 1
#define TOOLS__BIA_IFRIT_VERILOG_CTNR__DEFAULT__1 1
#define TOOLS__BIA_IFRIT_CPP_CTNR__DEFAULT 0
#define TOOLS__BIA_IFRIT_CPP_CTNR__DEFAULT__0 1
#define TOOLS__BIA_IFRIT_VERILOG_CTNR_TILE__DEFAULT 0
#define TOOLS__BIA_IFRIT_VERILOG_CTNR_TILE__DEFAULT__0 1
#define TOOLS__REP_INFO__ENABLED 1
#define TOOLS__REP_INFO__ENABLED__1 1
#endif
