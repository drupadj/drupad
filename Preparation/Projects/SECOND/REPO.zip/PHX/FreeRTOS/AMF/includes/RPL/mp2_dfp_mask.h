// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MP2_DFP_MASK_H)
#define _MP2_DFP_MASK_H

/*****************************************************************************************************************
 *
 *	mp2_dfp_mask.h
 *
 *	Register Spec Release:  <unknown>
*
*	 (c) 2000 ATI Technologies Inc.  (unpublished)
*
*	 All rights reserved.  This notice is intended as a precaution against
*	 inadvertent publication and does not imply publication or any waiver
*	 of confidentiality.  The year included in the foregoing notice is the
*	 year of creation of the work.
*
 *****************************************************************************************************************/

/*******************************************************
 * Read and Write Masks
 *******************************************************/

#define MP2_PSP_ACCESS_ONLY_READ_MASK  0x1
#define MP2_PSP_ACCESS_ONLY_WRITE_MASK 0x1

#define MP2_MPCLK_XBAR_CG_CTRL_READ_MASK 0x1
#define MP2_MPCLK_XBAR_CG_CTRL_WRITE_MASK 0x1

#define MP2_MPCLK_XBAR_CG_EN_READ_MASK 0x6
#define MP2_MPCLK_XBAR_CG_EN_WRITE_MASK 0x6

#define MP2_MPCLK_XBAR_CG_MISC_READ_MASK 0xffff
#define MP2_MPCLK_XBAR_CG_MISC_WRITE_MASK 0xffff

#define MP2_DFP_ZSCIF_CTRL_READ_MASK   0x1f
#define MP2_DFP_ZSCIF_CTRL_WRITE_MASK  0x1b

#define MP2_DFP_PGFSM_CTRL_READ_MASK   0x800000b2
#define MP2_DFP_PGFSM_CTRL_WRITE_MASK  0xb3

#define MP2_DFP_CLK_DIV_READ_MASK      0x1f
#define MP2_DFP_CLK_DIV_WRITE_MASK     0x1f

#define MP2_DFP_PGFSM_TRAN_CTRL_READ_MASK 0xfff
#define MP2_DFP_PGFSM_TRAN_CTRL_WRITE_MASK 0x800000ff

#define MP2_DFP_PGFSM_TRAN_WRITE_DATA_READ_MASK 0xffffffff
#define MP2_DFP_PGFSM_TRAN_WRITE_DATA_WRITE_MASK 0xffffffff

#define MP2_DFP_PGFSM_TRAN_READ_DATA_READ_MASK 0xffffffff
#define MP2_DFP_PGFSM_TRAN_READ_DATA_WRITE_MASK 0x0

#define MP2_DFP_PGFSM_OVRD_REG_READ_MASK 0xff01
#define MP2_DFP_PGFSM_OVRD_REG_WRITE_MASK 0xff01

#define MP2_DFP_PGRAM_MMU0_CNTL_READ_MASK 0xffffff
#define MP2_DFP_PGRAM_MMU0_CNTL_WRITE_MASK 0xffffd5

#define MP2_DFP_PGRAM_MMU1_CNTL_READ_MASK 0xffffff
#define MP2_DFP_PGRAM_MMU1_CNTL_WRITE_MASK 0xffffd5

#define MP2_DFP_PGRAM_MMU2_CNTL_READ_MASK 0xffffff
#define MP2_DFP_PGRAM_MMU2_CNTL_WRITE_MASK 0xffffd5

#define MP2_DFP_PGRAM_MMU3_CNTL_READ_MASK 0xffffff
#define MP2_DFP_PGRAM_MMU3_CNTL_WRITE_MASK 0xffffd5

#define MP2_DFP_PGRAM_I3C_CNTL_READ_MASK 0xffffff
#define MP2_DFP_PGRAM_I3C_CNTL_WRITE_MASK 0xffffd5

#define MP2_DFP_MPCLKDS_CTRL_READ_MASK 0x1fff
#define MP2_DFP_MPCLKDS_CTRL_WRITE_MASK 0x1ffd

#define MP2_CM4_WIC_CTRL_READ_MASK     0x7ff
#define MP2_CM4_WIC_CTRL_WRITE_MASK    0x73f

#define MP2_WAKE_EVENT_CTRL_READ_MASK  0x1
#define MP2_WAKE_EVENT_CTRL_WRITE_MASK 0x3

#define MP2_MPAONCLK_XBAR_CG_CTRL_READ_MASK 0x1
#define MP2_MPAONCLK_XBAR_CG_CTRL_WRITE_MASK 0x1

#define MP2_MPAONCLK_XBAR_CG_EN_READ_MASK 0x1e
#define MP2_MPAONCLK_XBAR_CG_EN_WRITE_MASK 0x1e

#define MP2_MPAONCLK_XBAR_CG_MISC_READ_MASK 0xffff
#define MP2_MPAONCLK_XBAR_CG_MISC_WRITE_MASK 0xffff

#define MP2_DFP_PGRAM_RAM0_CNTL_READ_MASK 0xffff3f
#define MP2_DFP_PGRAM_RAM0_CNTL_WRITE_MASK 0xffff15

#define MP2_DFP_PGRAM_RAM1_CNTL_READ_MASK 0xffff3f
#define MP2_DFP_PGRAM_RAM1_CNTL_WRITE_MASK 0xffff15

#define MP2_DFP_PGRAM_RAM2_CNTL_READ_MASK 0xffff3f
#define MP2_DFP_PGRAM_RAM2_CNTL_WRITE_MASK 0xffff15

#define MP2_DFP_PGRAM_RAM3_CNTL_READ_MASK 0xffff3f
#define MP2_DFP_PGRAM_RAM3_CNTL_WRITE_MASK 0xffff15

#define MP2_PG_PUB_STATUS_READ_MASK    0xb
#define MP2_PG_PUB_STATUS_WRITE_MASK   0x0

#endif


