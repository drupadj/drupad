// Copyright (c) 1994 - 2021 Advanced Micro Devices, Inc. All rights reserved. 
 #if !defined (_MPM_ADMA64_REGS_FIDDLE_H)
#define _MPM_ADMA64_REGS_FIDDLE_H
 /*****************************************************************************************************************
 *
 *  mpm_adma64_regs_reg.h
 *
 *  Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif

 /*******************************************************
 * Values
 *******************************************************/

 /*******************************************************
 * Structures
 *******************************************************/

/*
 * mpM_Adma64Cmd_Queue_Priority0 struct
 */

#define mpM_Adma64Cmd_Queue_Priority0_REG_SIZE         32
#define mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue0_SIZE  3
#define mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue1_SIZE  3
#define mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue2_SIZE  3

#define mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue0_SHIFT  0
#define mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue1_SHIFT  3
#define mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue2_SHIFT  6

#define mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue0_MASK  0x00000007
#define mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue1_MASK  0x00000038
#define mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue2_MASK  0x000001c0

#define mpM_Adma64Cmd_Queue_Priority0_MASK \
      (mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue0_MASK | \
      mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue1_MASK | \
      mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue2_MASK)

#define mpM_Adma64Cmd_Queue_Priority0_DEFAULT 0x000001ff

#define mpM_Adma64Cmd_Queue_Priority0_GET_RI_PriorityCmdQueue0(mpm_adma64cmd_queue_priority0) \
      ((mpm_adma64cmd_queue_priority0 & mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue0_MASK) >> mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue0_SHIFT)
#define mpM_Adma64Cmd_Queue_Priority0_GET_RI_PriorityCmdQueue1(mpm_adma64cmd_queue_priority0) \
      ((mpm_adma64cmd_queue_priority0 & mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue1_MASK) >> mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue1_SHIFT)
#define mpM_Adma64Cmd_Queue_Priority0_GET_RI_PriorityCmdQueue2(mpm_adma64cmd_queue_priority0) \
      ((mpm_adma64cmd_queue_priority0 & mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue2_MASK) >> mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue2_SHIFT)

#define mpM_Adma64Cmd_Queue_Priority0_SET_RI_PriorityCmdQueue0(mpm_adma64cmd_queue_priority0_reg, ri_prioritycmdqueue0) \
      mpm_adma64cmd_queue_priority0_reg = (mpm_adma64cmd_queue_priority0_reg & ~mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue0_MASK) | (ri_prioritycmdqueue0 << mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue0_SHIFT)
#define mpM_Adma64Cmd_Queue_Priority0_SET_RI_PriorityCmdQueue1(mpm_adma64cmd_queue_priority0_reg, ri_prioritycmdqueue1) \
      mpm_adma64cmd_queue_priority0_reg = (mpm_adma64cmd_queue_priority0_reg & ~mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue1_MASK) | (ri_prioritycmdqueue1 << mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue1_SHIFT)
#define mpM_Adma64Cmd_Queue_Priority0_SET_RI_PriorityCmdQueue2(mpm_adma64cmd_queue_priority0_reg, ri_prioritycmdqueue2) \
      mpm_adma64cmd_queue_priority0_reg = (mpm_adma64cmd_queue_priority0_reg & ~mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue2_MASK) | (ri_prioritycmdqueue2 << mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue2_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_queue_priority0_t {
            unsigned int ri_prioritycmdqueue0           : mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue0_SIZE;
            unsigned int ri_prioritycmdqueue1           : mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue1_SIZE;
            unsigned int ri_prioritycmdqueue2           : mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue2_SIZE;
            unsigned int                                : 23;
      } mpm_adma64cmd_queue_priority0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_queue_priority0_t {
            unsigned int                                : 23;
            unsigned int ri_prioritycmdqueue2           : mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue2_SIZE;
            unsigned int ri_prioritycmdqueue1           : mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue1_SIZE;
            unsigned int ri_prioritycmdqueue0           : mpM_Adma64Cmd_Queue_Priority0_RI_PriorityCmdQueue0_SIZE;
      } mpm_adma64cmd_queue_priority0_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_queue_priority0_t f;
} mpm_adma64cmd_queue_priority0_u;


/*
 * mpM_Adma64ReqID_Config0 struct
 */

#define mpM_Adma64ReqID_Config0_REG_SIZE         32
#define mpM_Adma64ReqID_Config0_RI_Q0_ReqId_SIZE  3
#define mpM_Adma64ReqID_Config0_RI_Q1_ReqId_SIZE  3
#define mpM_Adma64ReqID_Config0_RI_Q2_ReqId_SIZE  3

#define mpM_Adma64ReqID_Config0_RI_Q0_ReqId_SHIFT  0
#define mpM_Adma64ReqID_Config0_RI_Q1_ReqId_SHIFT  3
#define mpM_Adma64ReqID_Config0_RI_Q2_ReqId_SHIFT  6

#define mpM_Adma64ReqID_Config0_RI_Q0_ReqId_MASK  0x00000007
#define mpM_Adma64ReqID_Config0_RI_Q1_ReqId_MASK  0x00000038
#define mpM_Adma64ReqID_Config0_RI_Q2_ReqId_MASK  0x000001c0

#define mpM_Adma64ReqID_Config0_MASK \
      (mpM_Adma64ReqID_Config0_RI_Q0_ReqId_MASK | \
      mpM_Adma64ReqID_Config0_RI_Q1_ReqId_MASK | \
      mpM_Adma64ReqID_Config0_RI_Q2_ReqId_MASK)

#define mpM_Adma64ReqID_Config0_DEFAULT 0x00000049

#define mpM_Adma64ReqID_Config0_GET_RI_Q0_ReqId(mpm_adma64reqid_config0) \
      ((mpm_adma64reqid_config0 & mpM_Adma64ReqID_Config0_RI_Q0_ReqId_MASK) >> mpM_Adma64ReqID_Config0_RI_Q0_ReqId_SHIFT)
#define mpM_Adma64ReqID_Config0_GET_RI_Q1_ReqId(mpm_adma64reqid_config0) \
      ((mpm_adma64reqid_config0 & mpM_Adma64ReqID_Config0_RI_Q1_ReqId_MASK) >> mpM_Adma64ReqID_Config0_RI_Q1_ReqId_SHIFT)
#define mpM_Adma64ReqID_Config0_GET_RI_Q2_ReqId(mpm_adma64reqid_config0) \
      ((mpm_adma64reqid_config0 & mpM_Adma64ReqID_Config0_RI_Q2_ReqId_MASK) >> mpM_Adma64ReqID_Config0_RI_Q2_ReqId_SHIFT)

#define mpM_Adma64ReqID_Config0_SET_RI_Q0_ReqId(mpm_adma64reqid_config0_reg, ri_q0_reqid) \
      mpm_adma64reqid_config0_reg = (mpm_adma64reqid_config0_reg & ~mpM_Adma64ReqID_Config0_RI_Q0_ReqId_MASK) | (ri_q0_reqid << mpM_Adma64ReqID_Config0_RI_Q0_ReqId_SHIFT)
#define mpM_Adma64ReqID_Config0_SET_RI_Q1_ReqId(mpm_adma64reqid_config0_reg, ri_q1_reqid) \
      mpm_adma64reqid_config0_reg = (mpm_adma64reqid_config0_reg & ~mpM_Adma64ReqID_Config0_RI_Q1_ReqId_MASK) | (ri_q1_reqid << mpM_Adma64ReqID_Config0_RI_Q1_ReqId_SHIFT)
#define mpM_Adma64ReqID_Config0_SET_RI_Q2_ReqId(mpm_adma64reqid_config0_reg, ri_q2_reqid) \
      mpm_adma64reqid_config0_reg = (mpm_adma64reqid_config0_reg & ~mpM_Adma64ReqID_Config0_RI_Q2_ReqId_MASK) | (ri_q2_reqid << mpM_Adma64ReqID_Config0_RI_Q2_ReqId_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64reqid_config0_t {
            unsigned int ri_q0_reqid                    : mpM_Adma64ReqID_Config0_RI_Q0_ReqId_SIZE;
            unsigned int ri_q1_reqid                    : mpM_Adma64ReqID_Config0_RI_Q1_ReqId_SIZE;
            unsigned int ri_q2_reqid                    : mpM_Adma64ReqID_Config0_RI_Q2_ReqId_SIZE;
            unsigned int                                : 23;
      } mpm_adma64reqid_config0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64reqid_config0_t {
            unsigned int                                : 23;
            unsigned int ri_q2_reqid                    : mpM_Adma64ReqID_Config0_RI_Q2_ReqId_SIZE;
            unsigned int ri_q1_reqid                    : mpM_Adma64ReqID_Config0_RI_Q1_ReqId_SIZE;
            unsigned int ri_q0_reqid                    : mpM_Adma64ReqID_Config0_RI_Q0_ReqId_SIZE;
      } mpm_adma64reqid_config0_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64reqid_config0_t f;
} mpm_adma64reqid_config0_u;


/*
 * mpM_Adma64Module_Reset struct
 */

#define mpM_Adma64Module_Reset_REG_SIZE         32
#define mpM_Adma64Module_Reset_RI_PT_Reset_SIZE  1
#define mpM_Adma64Module_Reset_RI_IDMA_Reset_SIZE  1
#define mpM_Adma64Module_Reset_RI_JPM_Reset_SIZE  1
#define mpM_Adma64Module_Reset_RI_ODMA_Reset_SIZE  1
#define mpM_Adma64Module_Reset_RI_VQM0_Reset_SIZE  1
#define mpM_Adma64Module_Reset_RI_VQM1_Reset_SIZE  1
#define mpM_Adma64Module_Reset_RI_VQM2_Reset_SIZE  1

#define mpM_Adma64Module_Reset_RI_PT_Reset_SHIFT  3
#define mpM_Adma64Module_Reset_RI_IDMA_Reset_SHIFT  10
#define mpM_Adma64Module_Reset_RI_JPM_Reset_SHIFT  11
#define mpM_Adma64Module_Reset_RI_ODMA_Reset_SHIFT  12
#define mpM_Adma64Module_Reset_RI_VQM0_Reset_SHIFT  13
#define mpM_Adma64Module_Reset_RI_VQM1_Reset_SHIFT  14
#define mpM_Adma64Module_Reset_RI_VQM2_Reset_SHIFT  15

#define mpM_Adma64Module_Reset_RI_PT_Reset_MASK  0x00000008
#define mpM_Adma64Module_Reset_RI_IDMA_Reset_MASK  0x00000400
#define mpM_Adma64Module_Reset_RI_JPM_Reset_MASK  0x00000800
#define mpM_Adma64Module_Reset_RI_ODMA_Reset_MASK  0x00001000
#define mpM_Adma64Module_Reset_RI_VQM0_Reset_MASK  0x00002000
#define mpM_Adma64Module_Reset_RI_VQM1_Reset_MASK  0x00004000
#define mpM_Adma64Module_Reset_RI_VQM2_Reset_MASK  0x00008000

#define mpM_Adma64Module_Reset_MASK \
      (mpM_Adma64Module_Reset_RI_PT_Reset_MASK | \
      mpM_Adma64Module_Reset_RI_IDMA_Reset_MASK | \
      mpM_Adma64Module_Reset_RI_JPM_Reset_MASK | \
      mpM_Adma64Module_Reset_RI_ODMA_Reset_MASK | \
      mpM_Adma64Module_Reset_RI_VQM0_Reset_MASK | \
      mpM_Adma64Module_Reset_RI_VQM1_Reset_MASK | \
      mpM_Adma64Module_Reset_RI_VQM2_Reset_MASK)

#define mpM_Adma64Module_Reset_DEFAULT 0x00000000

#define mpM_Adma64Module_Reset_GET_RI_PT_Reset(mpm_adma64module_reset) \
      ((mpm_adma64module_reset & mpM_Adma64Module_Reset_RI_PT_Reset_MASK) >> mpM_Adma64Module_Reset_RI_PT_Reset_SHIFT)
#define mpM_Adma64Module_Reset_GET_RI_IDMA_Reset(mpm_adma64module_reset) \
      ((mpm_adma64module_reset & mpM_Adma64Module_Reset_RI_IDMA_Reset_MASK) >> mpM_Adma64Module_Reset_RI_IDMA_Reset_SHIFT)
#define mpM_Adma64Module_Reset_GET_RI_JPM_Reset(mpm_adma64module_reset) \
      ((mpm_adma64module_reset & mpM_Adma64Module_Reset_RI_JPM_Reset_MASK) >> mpM_Adma64Module_Reset_RI_JPM_Reset_SHIFT)
#define mpM_Adma64Module_Reset_GET_RI_ODMA_Reset(mpm_adma64module_reset) \
      ((mpm_adma64module_reset & mpM_Adma64Module_Reset_RI_ODMA_Reset_MASK) >> mpM_Adma64Module_Reset_RI_ODMA_Reset_SHIFT)
#define mpM_Adma64Module_Reset_GET_RI_VQM0_Reset(mpm_adma64module_reset) \
      ((mpm_adma64module_reset & mpM_Adma64Module_Reset_RI_VQM0_Reset_MASK) >> mpM_Adma64Module_Reset_RI_VQM0_Reset_SHIFT)
#define mpM_Adma64Module_Reset_GET_RI_VQM1_Reset(mpm_adma64module_reset) \
      ((mpm_adma64module_reset & mpM_Adma64Module_Reset_RI_VQM1_Reset_MASK) >> mpM_Adma64Module_Reset_RI_VQM1_Reset_SHIFT)
#define mpM_Adma64Module_Reset_GET_RI_VQM2_Reset(mpm_adma64module_reset) \
      ((mpm_adma64module_reset & mpM_Adma64Module_Reset_RI_VQM2_Reset_MASK) >> mpM_Adma64Module_Reset_RI_VQM2_Reset_SHIFT)

#define mpM_Adma64Module_Reset_SET_RI_PT_Reset(mpm_adma64module_reset_reg, ri_pt_reset) \
      mpm_adma64module_reset_reg = (mpm_adma64module_reset_reg & ~mpM_Adma64Module_Reset_RI_PT_Reset_MASK) | (ri_pt_reset << mpM_Adma64Module_Reset_RI_PT_Reset_SHIFT)
#define mpM_Adma64Module_Reset_SET_RI_IDMA_Reset(mpm_adma64module_reset_reg, ri_idma_reset) \
      mpm_adma64module_reset_reg = (mpm_adma64module_reset_reg & ~mpM_Adma64Module_Reset_RI_IDMA_Reset_MASK) | (ri_idma_reset << mpM_Adma64Module_Reset_RI_IDMA_Reset_SHIFT)
#define mpM_Adma64Module_Reset_SET_RI_JPM_Reset(mpm_adma64module_reset_reg, ri_jpm_reset) \
      mpm_adma64module_reset_reg = (mpm_adma64module_reset_reg & ~mpM_Adma64Module_Reset_RI_JPM_Reset_MASK) | (ri_jpm_reset << mpM_Adma64Module_Reset_RI_JPM_Reset_SHIFT)
#define mpM_Adma64Module_Reset_SET_RI_ODMA_Reset(mpm_adma64module_reset_reg, ri_odma_reset) \
      mpm_adma64module_reset_reg = (mpm_adma64module_reset_reg & ~mpM_Adma64Module_Reset_RI_ODMA_Reset_MASK) | (ri_odma_reset << mpM_Adma64Module_Reset_RI_ODMA_Reset_SHIFT)
#define mpM_Adma64Module_Reset_SET_RI_VQM0_Reset(mpm_adma64module_reset_reg, ri_vqm0_reset) \
      mpm_adma64module_reset_reg = (mpm_adma64module_reset_reg & ~mpM_Adma64Module_Reset_RI_VQM0_Reset_MASK) | (ri_vqm0_reset << mpM_Adma64Module_Reset_RI_VQM0_Reset_SHIFT)
#define mpM_Adma64Module_Reset_SET_RI_VQM1_Reset(mpm_adma64module_reset_reg, ri_vqm1_reset) \
      mpm_adma64module_reset_reg = (mpm_adma64module_reset_reg & ~mpM_Adma64Module_Reset_RI_VQM1_Reset_MASK) | (ri_vqm1_reset << mpM_Adma64Module_Reset_RI_VQM1_Reset_SHIFT)
#define mpM_Adma64Module_Reset_SET_RI_VQM2_Reset(mpm_adma64module_reset_reg, ri_vqm2_reset) \
      mpm_adma64module_reset_reg = (mpm_adma64module_reset_reg & ~mpM_Adma64Module_Reset_RI_VQM2_Reset_MASK) | (ri_vqm2_reset << mpM_Adma64Module_Reset_RI_VQM2_Reset_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64module_reset_t {
            unsigned int                                : 3;
            unsigned int ri_pt_reset                    : mpM_Adma64Module_Reset_RI_PT_Reset_SIZE;
            unsigned int                                : 6;
            unsigned int ri_idma_reset                  : mpM_Adma64Module_Reset_RI_IDMA_Reset_SIZE;
            unsigned int ri_jpm_reset                   : mpM_Adma64Module_Reset_RI_JPM_Reset_SIZE;
            unsigned int ri_odma_reset                  : mpM_Adma64Module_Reset_RI_ODMA_Reset_SIZE;
            unsigned int ri_vqm0_reset                  : mpM_Adma64Module_Reset_RI_VQM0_Reset_SIZE;
            unsigned int ri_vqm1_reset                  : mpM_Adma64Module_Reset_RI_VQM1_Reset_SIZE;
            unsigned int ri_vqm2_reset                  : mpM_Adma64Module_Reset_RI_VQM2_Reset_SIZE;
            unsigned int                                : 16;
      } mpm_adma64module_reset_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64module_reset_t {
            unsigned int                                : 16;
            unsigned int ri_vqm2_reset                  : mpM_Adma64Module_Reset_RI_VQM2_Reset_SIZE;
            unsigned int ri_vqm1_reset                  : mpM_Adma64Module_Reset_RI_VQM1_Reset_SIZE;
            unsigned int ri_vqm0_reset                  : mpM_Adma64Module_Reset_RI_VQM0_Reset_SIZE;
            unsigned int ri_odma_reset                  : mpM_Adma64Module_Reset_RI_ODMA_Reset_SIZE;
            unsigned int ri_jpm_reset                   : mpM_Adma64Module_Reset_RI_JPM_Reset_SIZE;
            unsigned int ri_idma_reset                  : mpM_Adma64Module_Reset_RI_IDMA_Reset_SIZE;
            unsigned int                                : 6;
            unsigned int ri_pt_reset                    : mpM_Adma64Module_Reset_RI_PT_Reset_SIZE;
            unsigned int                                : 3;
      } mpm_adma64module_reset_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64module_reset_t f;
} mpm_adma64module_reset_u;


/*
 * mpM_Adma64Cmd_Timeout struct
 */

#define mpM_Adma64Cmd_Timeout_REG_SIZE         32
#define mpM_Adma64Cmd_Timeout_RI_CmdTimeout_SIZE  32

#define mpM_Adma64Cmd_Timeout_RI_CmdTimeout_SHIFT  0

#define mpM_Adma64Cmd_Timeout_RI_CmdTimeout_MASK  0xffffffff

#define mpM_Adma64Cmd_Timeout_MASK \
      (mpM_Adma64Cmd_Timeout_RI_CmdTimeout_MASK)

#define mpM_Adma64Cmd_Timeout_DEFAULT  0x00000000

#define mpM_Adma64Cmd_Timeout_GET_RI_CmdTimeout(mpm_adma64cmd_timeout) \
      ((mpm_adma64cmd_timeout & mpM_Adma64Cmd_Timeout_RI_CmdTimeout_MASK) >> mpM_Adma64Cmd_Timeout_RI_CmdTimeout_SHIFT)

#define mpM_Adma64Cmd_Timeout_SET_RI_CmdTimeout(mpm_adma64cmd_timeout_reg, ri_cmdtimeout) \
      mpm_adma64cmd_timeout_reg = (mpm_adma64cmd_timeout_reg & ~mpM_Adma64Cmd_Timeout_RI_CmdTimeout_MASK) | (ri_cmdtimeout << mpM_Adma64Cmd_Timeout_RI_CmdTimeout_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_timeout_t {
            unsigned int ri_cmdtimeout                  : mpM_Adma64Cmd_Timeout_RI_CmdTimeout_SIZE;
      } mpm_adma64cmd_timeout_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_timeout_t {
            unsigned int ri_cmdtimeout                  : mpM_Adma64Cmd_Timeout_RI_CmdTimeout_SIZE;
      } mpm_adma64cmd_timeout_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_timeout_t f;
} mpm_adma64cmd_timeout_u;


/*
 * mpM_Adma64Cmd_Timeout_Granularity struct
 */

#define mpM_Adma64Cmd_Timeout_Granularity_REG_SIZE         32
#define mpM_Adma64Cmd_Timeout_Granularity_RI_Granularity_SIZE  32

#define mpM_Adma64Cmd_Timeout_Granularity_RI_Granularity_SHIFT  0

#define mpM_Adma64Cmd_Timeout_Granularity_RI_Granularity_MASK  0xffffffff

#define mpM_Adma64Cmd_Timeout_Granularity_MASK \
      (mpM_Adma64Cmd_Timeout_Granularity_RI_Granularity_MASK)

#define mpM_Adma64Cmd_Timeout_Granularity_DEFAULT 0x00000001

#define mpM_Adma64Cmd_Timeout_Granularity_GET_RI_Granularity(mpm_adma64cmd_timeout_granularity) \
      ((mpm_adma64cmd_timeout_granularity & mpM_Adma64Cmd_Timeout_Granularity_RI_Granularity_MASK) >> mpM_Adma64Cmd_Timeout_Granularity_RI_Granularity_SHIFT)

#define mpM_Adma64Cmd_Timeout_Granularity_SET_RI_Granularity(mpm_adma64cmd_timeout_granularity_reg, ri_granularity) \
      mpm_adma64cmd_timeout_granularity_reg = (mpm_adma64cmd_timeout_granularity_reg & ~mpM_Adma64Cmd_Timeout_Granularity_RI_Granularity_MASK) | (ri_granularity << mpM_Adma64Cmd_Timeout_Granularity_RI_Granularity_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_timeout_granularity_t {
            unsigned int ri_granularity                 : mpM_Adma64Cmd_Timeout_Granularity_RI_Granularity_SIZE;
      } mpm_adma64cmd_timeout_granularity_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_timeout_granularity_t {
            unsigned int ri_granularity                 : mpM_Adma64Cmd_Timeout_Granularity_RI_Granularity_SIZE;
      } mpm_adma64cmd_timeout_granularity_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_timeout_granularity_t f;
} mpm_adma64cmd_timeout_granularity_u;


/*
 * mpM_Adma64Memory_Deep_Sleep_Enable struct
 */

#define mpM_Adma64Memory_Deep_Sleep_Enable_REG_SIZE         32
#define mpM_Adma64Memory_Deep_Sleep_Enable_RI_DS_COUNTER_SIZE  10
#define mpM_Adma64Memory_Deep_Sleep_Enable_RI_DS_ENG_SEL_SIZE  5

#define mpM_Adma64Memory_Deep_Sleep_Enable_RI_DS_COUNTER_SHIFT  0
#define mpM_Adma64Memory_Deep_Sleep_Enable_RI_DS_ENG_SEL_SHIFT  10

#define mpM_Adma64Memory_Deep_Sleep_Enable_RI_DS_COUNTER_MASK  0x000003ff
#define mpM_Adma64Memory_Deep_Sleep_Enable_RI_DS_ENG_SEL_MASK  0x00007c00

#define mpM_Adma64Memory_Deep_Sleep_Enable_MASK \
      (mpM_Adma64Memory_Deep_Sleep_Enable_RI_DS_COUNTER_MASK | \
      mpM_Adma64Memory_Deep_Sleep_Enable_RI_DS_ENG_SEL_MASK)

#define mpM_Adma64Memory_Deep_Sleep_Enable_DEFAULT 0x00000000

#define mpM_Adma64Memory_Deep_Sleep_Enable_GET_RI_DS_COUNTER(mpm_adma64memory_deep_sleep_enable) \
      ((mpm_adma64memory_deep_sleep_enable & mpM_Adma64Memory_Deep_Sleep_Enable_RI_DS_COUNTER_MASK) >> mpM_Adma64Memory_Deep_Sleep_Enable_RI_DS_COUNTER_SHIFT)
#define mpM_Adma64Memory_Deep_Sleep_Enable_GET_RI_DS_ENG_SEL(mpm_adma64memory_deep_sleep_enable) \
      ((mpm_adma64memory_deep_sleep_enable & mpM_Adma64Memory_Deep_Sleep_Enable_RI_DS_ENG_SEL_MASK) >> mpM_Adma64Memory_Deep_Sleep_Enable_RI_DS_ENG_SEL_SHIFT)

#define mpM_Adma64Memory_Deep_Sleep_Enable_SET_RI_DS_COUNTER(mpm_adma64memory_deep_sleep_enable_reg, ri_ds_counter) \
      mpm_adma64memory_deep_sleep_enable_reg = (mpm_adma64memory_deep_sleep_enable_reg & ~mpM_Adma64Memory_Deep_Sleep_Enable_RI_DS_COUNTER_MASK) | (ri_ds_counter << mpM_Adma64Memory_Deep_Sleep_Enable_RI_DS_COUNTER_SHIFT)
#define mpM_Adma64Memory_Deep_Sleep_Enable_SET_RI_DS_ENG_SEL(mpm_adma64memory_deep_sleep_enable_reg, ri_ds_eng_sel) \
      mpm_adma64memory_deep_sleep_enable_reg = (mpm_adma64memory_deep_sleep_enable_reg & ~mpM_Adma64Memory_Deep_Sleep_Enable_RI_DS_ENG_SEL_MASK) | (ri_ds_eng_sel << mpM_Adma64Memory_Deep_Sleep_Enable_RI_DS_ENG_SEL_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64memory_deep_sleep_enable_t {
            unsigned int ri_ds_counter                  : mpM_Adma64Memory_Deep_Sleep_Enable_RI_DS_COUNTER_SIZE;
            unsigned int ri_ds_eng_sel                  : mpM_Adma64Memory_Deep_Sleep_Enable_RI_DS_ENG_SEL_SIZE;
            unsigned int                                : 17;
      } mpm_adma64memory_deep_sleep_enable_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64memory_deep_sleep_enable_t {
            unsigned int                                : 17;
            unsigned int ri_ds_eng_sel                  : mpM_Adma64Memory_Deep_Sleep_Enable_RI_DS_ENG_SEL_SIZE;
            unsigned int ri_ds_counter                  : mpM_Adma64Memory_Deep_Sleep_Enable_RI_DS_COUNTER_SIZE;
      } mpm_adma64memory_deep_sleep_enable_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64memory_deep_sleep_enable_t f;
} mpm_adma64memory_deep_sleep_enable_u;


/*
 * mpM_Adma64Memory_Deep_Sleep_Status struct
 */

#define mpM_Adma64Memory_Deep_Sleep_Status_REG_SIZE         32
#define mpM_Adma64Memory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_SIZE  8

#define mpM_Adma64Memory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_SHIFT  0

#define mpM_Adma64Memory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_MASK  0x000000ff

#define mpM_Adma64Memory_Deep_Sleep_Status_MASK \
      (mpM_Adma64Memory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_MASK)

#define mpM_Adma64Memory_Deep_Sleep_Status_DEFAULT 0x000000f9

#define mpM_Adma64Memory_Deep_Sleep_Status_GET_RI_DS_ENG_IS_AWAKE(mpm_adma64memory_deep_sleep_status) \
      ((mpm_adma64memory_deep_sleep_status & mpM_Adma64Memory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_MASK) >> mpM_Adma64Memory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_SHIFT)

#define mpM_Adma64Memory_Deep_Sleep_Status_SET_RI_DS_ENG_IS_AWAKE(mpm_adma64memory_deep_sleep_status_reg, ri_ds_eng_is_awake) \
      mpm_adma64memory_deep_sleep_status_reg = (mpm_adma64memory_deep_sleep_status_reg & ~mpM_Adma64Memory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_MASK) | (ri_ds_eng_is_awake << mpM_Adma64Memory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64memory_deep_sleep_status_t {
            unsigned int ri_ds_eng_is_awake             : mpM_Adma64Memory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_SIZE;
            unsigned int                                : 24;
      } mpm_adma64memory_deep_sleep_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64memory_deep_sleep_status_t {
            unsigned int                                : 24;
            unsigned int ri_ds_eng_is_awake             : mpM_Adma64Memory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_SIZE;
      } mpm_adma64memory_deep_sleep_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64memory_deep_sleep_status_t f;
} mpm_adma64memory_deep_sleep_status_u;


/*
 * mpM_Adma64Clock_Gating_Control struct
 */

#define mpM_Adma64Clock_Gating_Control_REG_SIZE         32
#define mpM_Adma64Clock_Gating_Control_DYN_CLOCK_EN_SIZE  1
#define mpM_Adma64Clock_Gating_Control_GATE_MODE_CCP_SIZE  1
#define mpM_Adma64Clock_Gating_Control_CLK_GATE_DLY_TIMER_SIZE  4
#define mpM_Adma64Clock_Gating_Control_SW_GATE_CCP_SIZE  1
#define mpM_Adma64Clock_Gating_Control_CLK_OFF_DLY_TIMER_SIZE  4

#define mpM_Adma64Clock_Gating_Control_DYN_CLOCK_EN_SHIFT  0
#define mpM_Adma64Clock_Gating_Control_GATE_MODE_CCP_SHIFT  1
#define mpM_Adma64Clock_Gating_Control_CLK_GATE_DLY_TIMER_SHIFT  2
#define mpM_Adma64Clock_Gating_Control_SW_GATE_CCP_SHIFT  6
#define mpM_Adma64Clock_Gating_Control_CLK_OFF_DLY_TIMER_SHIFT  7

#define mpM_Adma64Clock_Gating_Control_DYN_CLOCK_EN_MASK  0x00000001
#define mpM_Adma64Clock_Gating_Control_GATE_MODE_CCP_MASK  0x00000002
#define mpM_Adma64Clock_Gating_Control_CLK_GATE_DLY_TIMER_MASK  0x0000003c
#define mpM_Adma64Clock_Gating_Control_SW_GATE_CCP_MASK  0x00000040
#define mpM_Adma64Clock_Gating_Control_CLK_OFF_DLY_TIMER_MASK  0x00000780

#define mpM_Adma64Clock_Gating_Control_MASK \
      (mpM_Adma64Clock_Gating_Control_DYN_CLOCK_EN_MASK | \
      mpM_Adma64Clock_Gating_Control_GATE_MODE_CCP_MASK | \
      mpM_Adma64Clock_Gating_Control_CLK_GATE_DLY_TIMER_MASK | \
      mpM_Adma64Clock_Gating_Control_SW_GATE_CCP_MASK | \
      mpM_Adma64Clock_Gating_Control_CLK_OFF_DLY_TIMER_MASK)

#define mpM_Adma64Clock_Gating_Control_DEFAULT 0x00000000

#define mpM_Adma64Clock_Gating_Control_GET_DYN_CLOCK_EN(mpm_adma64clock_gating_control) \
      ((mpm_adma64clock_gating_control & mpM_Adma64Clock_Gating_Control_DYN_CLOCK_EN_MASK) >> mpM_Adma64Clock_Gating_Control_DYN_CLOCK_EN_SHIFT)
#define mpM_Adma64Clock_Gating_Control_GET_GATE_MODE_CCP(mpm_adma64clock_gating_control) \
      ((mpm_adma64clock_gating_control & mpM_Adma64Clock_Gating_Control_GATE_MODE_CCP_MASK) >> mpM_Adma64Clock_Gating_Control_GATE_MODE_CCP_SHIFT)
#define mpM_Adma64Clock_Gating_Control_GET_CLK_GATE_DLY_TIMER(mpm_adma64clock_gating_control) \
      ((mpm_adma64clock_gating_control & mpM_Adma64Clock_Gating_Control_CLK_GATE_DLY_TIMER_MASK) >> mpM_Adma64Clock_Gating_Control_CLK_GATE_DLY_TIMER_SHIFT)
#define mpM_Adma64Clock_Gating_Control_GET_SW_GATE_CCP(mpm_adma64clock_gating_control) \
      ((mpm_adma64clock_gating_control & mpM_Adma64Clock_Gating_Control_SW_GATE_CCP_MASK) >> mpM_Adma64Clock_Gating_Control_SW_GATE_CCP_SHIFT)
#define mpM_Adma64Clock_Gating_Control_GET_CLK_OFF_DLY_TIMER(mpm_adma64clock_gating_control) \
      ((mpm_adma64clock_gating_control & mpM_Adma64Clock_Gating_Control_CLK_OFF_DLY_TIMER_MASK) >> mpM_Adma64Clock_Gating_Control_CLK_OFF_DLY_TIMER_SHIFT)

#define mpM_Adma64Clock_Gating_Control_SET_DYN_CLOCK_EN(mpm_adma64clock_gating_control_reg, dyn_clock_en) \
      mpm_adma64clock_gating_control_reg = (mpm_adma64clock_gating_control_reg & ~mpM_Adma64Clock_Gating_Control_DYN_CLOCK_EN_MASK) | (dyn_clock_en << mpM_Adma64Clock_Gating_Control_DYN_CLOCK_EN_SHIFT)
#define mpM_Adma64Clock_Gating_Control_SET_GATE_MODE_CCP(mpm_adma64clock_gating_control_reg, gate_mode_ccp) \
      mpm_adma64clock_gating_control_reg = (mpm_adma64clock_gating_control_reg & ~mpM_Adma64Clock_Gating_Control_GATE_MODE_CCP_MASK) | (gate_mode_ccp << mpM_Adma64Clock_Gating_Control_GATE_MODE_CCP_SHIFT)
#define mpM_Adma64Clock_Gating_Control_SET_CLK_GATE_DLY_TIMER(mpm_adma64clock_gating_control_reg, clk_gate_dly_timer) \
      mpm_adma64clock_gating_control_reg = (mpm_adma64clock_gating_control_reg & ~mpM_Adma64Clock_Gating_Control_CLK_GATE_DLY_TIMER_MASK) | (clk_gate_dly_timer << mpM_Adma64Clock_Gating_Control_CLK_GATE_DLY_TIMER_SHIFT)
#define mpM_Adma64Clock_Gating_Control_SET_SW_GATE_CCP(mpm_adma64clock_gating_control_reg, sw_gate_ccp) \
      mpm_adma64clock_gating_control_reg = (mpm_adma64clock_gating_control_reg & ~mpM_Adma64Clock_Gating_Control_SW_GATE_CCP_MASK) | (sw_gate_ccp << mpM_Adma64Clock_Gating_Control_SW_GATE_CCP_SHIFT)
#define mpM_Adma64Clock_Gating_Control_SET_CLK_OFF_DLY_TIMER(mpm_adma64clock_gating_control_reg, clk_off_dly_timer) \
      mpm_adma64clock_gating_control_reg = (mpm_adma64clock_gating_control_reg & ~mpM_Adma64Clock_Gating_Control_CLK_OFF_DLY_TIMER_MASK) | (clk_off_dly_timer << mpM_Adma64Clock_Gating_Control_CLK_OFF_DLY_TIMER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64clock_gating_control_t {
            unsigned int dyn_clock_en                   : mpM_Adma64Clock_Gating_Control_DYN_CLOCK_EN_SIZE;
            unsigned int gate_mode_ccp                  : mpM_Adma64Clock_Gating_Control_GATE_MODE_CCP_SIZE;
            unsigned int clk_gate_dly_timer             : mpM_Adma64Clock_Gating_Control_CLK_GATE_DLY_TIMER_SIZE;
            unsigned int sw_gate_ccp                    : mpM_Adma64Clock_Gating_Control_SW_GATE_CCP_SIZE;
            unsigned int clk_off_dly_timer              : mpM_Adma64Clock_Gating_Control_CLK_OFF_DLY_TIMER_SIZE;
            unsigned int                                : 21;
      } mpm_adma64clock_gating_control_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64clock_gating_control_t {
            unsigned int                                : 21;
            unsigned int clk_off_dly_timer              : mpM_Adma64Clock_Gating_Control_CLK_OFF_DLY_TIMER_SIZE;
            unsigned int sw_gate_ccp                    : mpM_Adma64Clock_Gating_Control_SW_GATE_CCP_SIZE;
            unsigned int clk_gate_dly_timer             : mpM_Adma64Clock_Gating_Control_CLK_GATE_DLY_TIMER_SIZE;
            unsigned int gate_mode_ccp                  : mpM_Adma64Clock_Gating_Control_GATE_MODE_CCP_SIZE;
            unsigned int dyn_clock_en                   : mpM_Adma64Clock_Gating_Control_DYN_CLOCK_EN_SIZE;
      } mpm_adma64clock_gating_control_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64clock_gating_control_t f;
} mpm_adma64clock_gating_control_u;


/*
 * mpM_Adma64Version struct
 */

#define mpM_Adma64Version_REG_SIZE         32
#define mpM_Adma64Version_RI_VersionNum_SIZE  6
#define mpM_Adma64Version_RI_NumVQM_SIZE  5

#define mpM_Adma64Version_RI_VersionNum_SHIFT  0
#define mpM_Adma64Version_RI_NumVQM_SHIFT  15

#define mpM_Adma64Version_RI_VersionNum_MASK  0x0000003f
#define mpM_Adma64Version_RI_NumVQM_MASK  0x000f8000

#define mpM_Adma64Version_MASK \
      (mpM_Adma64Version_RI_VersionNum_MASK | \
      mpM_Adma64Version_RI_NumVQM_MASK)

#define mpM_Adma64Version_DEFAULT      0x00018003

#define mpM_Adma64Version_GET_RI_VersionNum(mpm_adma64version) \
      ((mpm_adma64version & mpM_Adma64Version_RI_VersionNum_MASK) >> mpM_Adma64Version_RI_VersionNum_SHIFT)
#define mpM_Adma64Version_GET_RI_NumVQM(mpm_adma64version) \
      ((mpm_adma64version & mpM_Adma64Version_RI_NumVQM_MASK) >> mpM_Adma64Version_RI_NumVQM_SHIFT)

#define mpM_Adma64Version_SET_RI_VersionNum(mpm_adma64version_reg, ri_versionnum) \
      mpm_adma64version_reg = (mpm_adma64version_reg & ~mpM_Adma64Version_RI_VersionNum_MASK) | (ri_versionnum << mpM_Adma64Version_RI_VersionNum_SHIFT)
#define mpM_Adma64Version_SET_RI_NumVQM(mpm_adma64version_reg, ri_numvqm) \
      mpm_adma64version_reg = (mpm_adma64version_reg & ~mpM_Adma64Version_RI_NumVQM_MASK) | (ri_numvqm << mpM_Adma64Version_RI_NumVQM_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64version_t {
            unsigned int ri_versionnum                  : mpM_Adma64Version_RI_VersionNum_SIZE;
            unsigned int                                : 9;
            unsigned int ri_numvqm                      : mpM_Adma64Version_RI_NumVQM_SIZE;
            unsigned int                                : 12;
      } mpm_adma64version_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64version_t {
            unsigned int                                : 12;
            unsigned int ri_numvqm                      : mpM_Adma64Version_RI_NumVQM_SIZE;
            unsigned int                                : 9;
            unsigned int ri_versionnum                  : mpM_Adma64Version_RI_VersionNum_SIZE;
      } mpm_adma64version_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64version_t f;
} mpm_adma64version_u;


/*
 * mpM_Adma64Vqd0_Control struct
 */

#define mpM_Adma64Vqd0_Control_REG_SIZE         32
#define mpM_Adma64Vqd0_Control_RI_Run_SIZE  1
#define mpM_Adma64Vqd0_Control_VQM_Halted_SIZE  1
#define mpM_Adma64Vqd0_Control_RI_Mem_Location_SIZE  1
#define mpM_Adma64Vqd0_Control_RI_Queue_Size_SIZE  4
#define mpM_Adma64Vqd0_Control_RI_COMP_DESC_SIZE  1
#define mpM_Adma64Vqd0_Control_RI_VQD_Pointer_Hi_SIZE  16

#define mpM_Adma64Vqd0_Control_RI_Run_SHIFT  0
#define mpM_Adma64Vqd0_Control_VQM_Halted_SHIFT  1
#define mpM_Adma64Vqd0_Control_RI_Mem_Location_SHIFT  2
#define mpM_Adma64Vqd0_Control_RI_Queue_Size_SHIFT  3
#define mpM_Adma64Vqd0_Control_RI_COMP_DESC_SHIFT  7
#define mpM_Adma64Vqd0_Control_RI_VQD_Pointer_Hi_SHIFT  16

#define mpM_Adma64Vqd0_Control_RI_Run_MASK  0x00000001
#define mpM_Adma64Vqd0_Control_VQM_Halted_MASK  0x00000002
#define mpM_Adma64Vqd0_Control_RI_Mem_Location_MASK  0x00000004
#define mpM_Adma64Vqd0_Control_RI_Queue_Size_MASK  0x00000078
#define mpM_Adma64Vqd0_Control_RI_COMP_DESC_MASK  0x00000080
#define mpM_Adma64Vqd0_Control_RI_VQD_Pointer_Hi_MASK  0xffff0000

#define mpM_Adma64Vqd0_Control_MASK \
      (mpM_Adma64Vqd0_Control_RI_Run_MASK | \
      mpM_Adma64Vqd0_Control_VQM_Halted_MASK | \
      mpM_Adma64Vqd0_Control_RI_Mem_Location_MASK | \
      mpM_Adma64Vqd0_Control_RI_Queue_Size_MASK | \
      mpM_Adma64Vqd0_Control_RI_COMP_DESC_MASK | \
      mpM_Adma64Vqd0_Control_RI_VQD_Pointer_Hi_MASK)

#define mpM_Adma64Vqd0_Control_DEFAULT 0x00000002

#define mpM_Adma64Vqd0_Control_GET_RI_Run(mpm_adma64vqd0_control) \
      ((mpm_adma64vqd0_control & mpM_Adma64Vqd0_Control_RI_Run_MASK) >> mpM_Adma64Vqd0_Control_RI_Run_SHIFT)
#define mpM_Adma64Vqd0_Control_GET_VQM_Halted(mpm_adma64vqd0_control) \
      ((mpm_adma64vqd0_control & mpM_Adma64Vqd0_Control_VQM_Halted_MASK) >> mpM_Adma64Vqd0_Control_VQM_Halted_SHIFT)
#define mpM_Adma64Vqd0_Control_GET_RI_Mem_Location(mpm_adma64vqd0_control) \
      ((mpm_adma64vqd0_control & mpM_Adma64Vqd0_Control_RI_Mem_Location_MASK) >> mpM_Adma64Vqd0_Control_RI_Mem_Location_SHIFT)
#define mpM_Adma64Vqd0_Control_GET_RI_Queue_Size(mpm_adma64vqd0_control) \
      ((mpm_adma64vqd0_control & mpM_Adma64Vqd0_Control_RI_Queue_Size_MASK) >> mpM_Adma64Vqd0_Control_RI_Queue_Size_SHIFT)
#define mpM_Adma64Vqd0_Control_GET_RI_COMP_DESC(mpm_adma64vqd0_control) \
      ((mpm_adma64vqd0_control & mpM_Adma64Vqd0_Control_RI_COMP_DESC_MASK) >> mpM_Adma64Vqd0_Control_RI_COMP_DESC_SHIFT)
#define mpM_Adma64Vqd0_Control_GET_RI_VQD_Pointer_Hi(mpm_adma64vqd0_control) \
      ((mpm_adma64vqd0_control & mpM_Adma64Vqd0_Control_RI_VQD_Pointer_Hi_MASK) >> mpM_Adma64Vqd0_Control_RI_VQD_Pointer_Hi_SHIFT)

#define mpM_Adma64Vqd0_Control_SET_RI_Run(mpm_adma64vqd0_control_reg, ri_run) \
      mpm_adma64vqd0_control_reg = (mpm_adma64vqd0_control_reg & ~mpM_Adma64Vqd0_Control_RI_Run_MASK) | (ri_run << mpM_Adma64Vqd0_Control_RI_Run_SHIFT)
#define mpM_Adma64Vqd0_Control_SET_VQM_Halted(mpm_adma64vqd0_control_reg, vqm_halted) \
      mpm_adma64vqd0_control_reg = (mpm_adma64vqd0_control_reg & ~mpM_Adma64Vqd0_Control_VQM_Halted_MASK) | (vqm_halted << mpM_Adma64Vqd0_Control_VQM_Halted_SHIFT)
#define mpM_Adma64Vqd0_Control_SET_RI_Mem_Location(mpm_adma64vqd0_control_reg, ri_mem_location) \
      mpm_adma64vqd0_control_reg = (mpm_adma64vqd0_control_reg & ~mpM_Adma64Vqd0_Control_RI_Mem_Location_MASK) | (ri_mem_location << mpM_Adma64Vqd0_Control_RI_Mem_Location_SHIFT)
#define mpM_Adma64Vqd0_Control_SET_RI_Queue_Size(mpm_adma64vqd0_control_reg, ri_queue_size) \
      mpm_adma64vqd0_control_reg = (mpm_adma64vqd0_control_reg & ~mpM_Adma64Vqd0_Control_RI_Queue_Size_MASK) | (ri_queue_size << mpM_Adma64Vqd0_Control_RI_Queue_Size_SHIFT)
#define mpM_Adma64Vqd0_Control_SET_RI_COMP_DESC(mpm_adma64vqd0_control_reg, ri_comp_desc) \
      mpm_adma64vqd0_control_reg = (mpm_adma64vqd0_control_reg & ~mpM_Adma64Vqd0_Control_RI_COMP_DESC_MASK) | (ri_comp_desc << mpM_Adma64Vqd0_Control_RI_COMP_DESC_SHIFT)
#define mpM_Adma64Vqd0_Control_SET_RI_VQD_Pointer_Hi(mpm_adma64vqd0_control_reg, ri_vqd_pointer_hi) \
      mpm_adma64vqd0_control_reg = (mpm_adma64vqd0_control_reg & ~mpM_Adma64Vqd0_Control_RI_VQD_Pointer_Hi_MASK) | (ri_vqd_pointer_hi << mpM_Adma64Vqd0_Control_RI_VQD_Pointer_Hi_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64vqd0_control_t {
            unsigned int ri_run                         : mpM_Adma64Vqd0_Control_RI_Run_SIZE;
            unsigned int vqm_halted                     : mpM_Adma64Vqd0_Control_VQM_Halted_SIZE;
            unsigned int ri_mem_location                : mpM_Adma64Vqd0_Control_RI_Mem_Location_SIZE;
            unsigned int ri_queue_size                  : mpM_Adma64Vqd0_Control_RI_Queue_Size_SIZE;
            unsigned int ri_comp_desc                   : mpM_Adma64Vqd0_Control_RI_COMP_DESC_SIZE;
            unsigned int                                : 8;
            unsigned int ri_vqd_pointer_hi              : mpM_Adma64Vqd0_Control_RI_VQD_Pointer_Hi_SIZE;
      } mpm_adma64vqd0_control_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64vqd0_control_t {
            unsigned int ri_vqd_pointer_hi              : mpM_Adma64Vqd0_Control_RI_VQD_Pointer_Hi_SIZE;
            unsigned int                                : 8;
            unsigned int ri_comp_desc                   : mpM_Adma64Vqd0_Control_RI_COMP_DESC_SIZE;
            unsigned int ri_queue_size                  : mpM_Adma64Vqd0_Control_RI_Queue_Size_SIZE;
            unsigned int ri_mem_location                : mpM_Adma64Vqd0_Control_RI_Mem_Location_SIZE;
            unsigned int vqm_halted                     : mpM_Adma64Vqd0_Control_VQM_Halted_SIZE;
            unsigned int ri_run                         : mpM_Adma64Vqd0_Control_RI_Run_SIZE;
      } mpm_adma64vqd0_control_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64vqd0_control_t f;
} mpm_adma64vqd0_control_u;


/*
 * mpM_Adma64Vqd0_Tail_Lo struct
 */

#define mpM_Adma64Vqd0_Tail_Lo_REG_SIZE         32
#define mpM_Adma64Vqd0_Tail_Lo_RI_Tail_Pointer_Lo_SIZE  32

#define mpM_Adma64Vqd0_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT  0

#define mpM_Adma64Vqd0_Tail_Lo_RI_Tail_Pointer_Lo_MASK  0xffffffff

#define mpM_Adma64Vqd0_Tail_Lo_MASK \
      (mpM_Adma64Vqd0_Tail_Lo_RI_Tail_Pointer_Lo_MASK)

#define mpM_Adma64Vqd0_Tail_Lo_DEFAULT 0x00000000

#define mpM_Adma64Vqd0_Tail_Lo_GET_RI_Tail_Pointer_Lo(mpm_adma64vqd0_tail_lo) \
      ((mpm_adma64vqd0_tail_lo & mpM_Adma64Vqd0_Tail_Lo_RI_Tail_Pointer_Lo_MASK) >> mpM_Adma64Vqd0_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT)

#define mpM_Adma64Vqd0_Tail_Lo_SET_RI_Tail_Pointer_Lo(mpm_adma64vqd0_tail_lo_reg, ri_tail_pointer_lo) \
      mpm_adma64vqd0_tail_lo_reg = (mpm_adma64vqd0_tail_lo_reg & ~mpM_Adma64Vqd0_Tail_Lo_RI_Tail_Pointer_Lo_MASK) | (ri_tail_pointer_lo << mpM_Adma64Vqd0_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64vqd0_tail_lo_t {
            unsigned int ri_tail_pointer_lo             : mpM_Adma64Vqd0_Tail_Lo_RI_Tail_Pointer_Lo_SIZE;
      } mpm_adma64vqd0_tail_lo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64vqd0_tail_lo_t {
            unsigned int ri_tail_pointer_lo             : mpM_Adma64Vqd0_Tail_Lo_RI_Tail_Pointer_Lo_SIZE;
      } mpm_adma64vqd0_tail_lo_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64vqd0_tail_lo_t f;
} mpm_adma64vqd0_tail_lo_u;


/*
 * mpM_Adma64Vqd0_Head_Lo struct
 */

#define mpM_Adma64Vqd0_Head_Lo_REG_SIZE         32
#define mpM_Adma64Vqd0_Head_Lo_RI_Head_Pointer_Lo_SIZE  32

#define mpM_Adma64Vqd0_Head_Lo_RI_Head_Pointer_Lo_SHIFT  0

#define mpM_Adma64Vqd0_Head_Lo_RI_Head_Pointer_Lo_MASK  0xffffffff

#define mpM_Adma64Vqd0_Head_Lo_MASK \
      (mpM_Adma64Vqd0_Head_Lo_RI_Head_Pointer_Lo_MASK)

#define mpM_Adma64Vqd0_Head_Lo_DEFAULT 0x00000000

#define mpM_Adma64Vqd0_Head_Lo_GET_RI_Head_Pointer_Lo(mpm_adma64vqd0_head_lo) \
      ((mpm_adma64vqd0_head_lo & mpM_Adma64Vqd0_Head_Lo_RI_Head_Pointer_Lo_MASK) >> mpM_Adma64Vqd0_Head_Lo_RI_Head_Pointer_Lo_SHIFT)

#define mpM_Adma64Vqd0_Head_Lo_SET_RI_Head_Pointer_Lo(mpm_adma64vqd0_head_lo_reg, ri_head_pointer_lo) \
      mpm_adma64vqd0_head_lo_reg = (mpm_adma64vqd0_head_lo_reg & ~mpM_Adma64Vqd0_Head_Lo_RI_Head_Pointer_Lo_MASK) | (ri_head_pointer_lo << mpM_Adma64Vqd0_Head_Lo_RI_Head_Pointer_Lo_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64vqd0_head_lo_t {
            unsigned int ri_head_pointer_lo             : mpM_Adma64Vqd0_Head_Lo_RI_Head_Pointer_Lo_SIZE;
      } mpm_adma64vqd0_head_lo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64vqd0_head_lo_t {
            unsigned int ri_head_pointer_lo             : mpM_Adma64Vqd0_Head_Lo_RI_Head_Pointer_Lo_SIZE;
      } mpm_adma64vqd0_head_lo_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64vqd0_head_lo_t f;
} mpm_adma64vqd0_head_lo_u;


/*
 * mpM_Adma64Cmd_Interrupt_Enable_Q0 struct
 */

#define mpM_Adma64Cmd_Interrupt_Enable_Q0_REG_SIZE         32
#define mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_CompInt_Enable_SIZE  1
#define mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_SIZE  1
#define mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_QSI_Enable_SIZE  1
#define mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_QEI_Enable_SIZE  1

#define mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_CompInt_Enable_SHIFT  0
#define mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_SHIFT  1
#define mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_QSI_Enable_SHIFT  2
#define mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_QEI_Enable_SHIFT  3

#define mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_CompInt_Enable_MASK  0x00000001
#define mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_MASK  0x00000002
#define mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_QSI_Enable_MASK  0x00000004
#define mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_QEI_Enable_MASK  0x00000008

#define mpM_Adma64Cmd_Interrupt_Enable_Q0_MASK \
      (mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_CompInt_Enable_MASK | \
      mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_MASK | \
      mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_QSI_Enable_MASK | \
      mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_QEI_Enable_MASK)

#define mpM_Adma64Cmd_Interrupt_Enable_Q0_DEFAULT 0x00000000

#define mpM_Adma64Cmd_Interrupt_Enable_Q0_GET_RI_CompInt_Enable(mpm_adma64cmd_interrupt_enable_q0) \
      ((mpm_adma64cmd_interrupt_enable_q0 & mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_CompInt_Enable_MASK) >> mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_CompInt_Enable_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Enable_Q0_GET_RI_ErrInt_Enable(mpm_adma64cmd_interrupt_enable_q0) \
      ((mpm_adma64cmd_interrupt_enable_q0 & mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_MASK) >> mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Enable_Q0_GET_RI_QSI_Enable(mpm_adma64cmd_interrupt_enable_q0) \
      ((mpm_adma64cmd_interrupt_enable_q0 & mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_QSI_Enable_MASK) >> mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_QSI_Enable_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Enable_Q0_GET_RI_QEI_Enable(mpm_adma64cmd_interrupt_enable_q0) \
      ((mpm_adma64cmd_interrupt_enable_q0 & mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_QEI_Enable_MASK) >> mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_QEI_Enable_SHIFT)

#define mpM_Adma64Cmd_Interrupt_Enable_Q0_SET_RI_CompInt_Enable(mpm_adma64cmd_interrupt_enable_q0_reg, ri_compint_enable) \
      mpm_adma64cmd_interrupt_enable_q0_reg = (mpm_adma64cmd_interrupt_enable_q0_reg & ~mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_CompInt_Enable_MASK) | (ri_compint_enable << mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_CompInt_Enable_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Enable_Q0_SET_RI_ErrInt_Enable(mpm_adma64cmd_interrupt_enable_q0_reg, ri_errint_enable) \
      mpm_adma64cmd_interrupt_enable_q0_reg = (mpm_adma64cmd_interrupt_enable_q0_reg & ~mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_MASK) | (ri_errint_enable << mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Enable_Q0_SET_RI_QSI_Enable(mpm_adma64cmd_interrupt_enable_q0_reg, ri_qsi_enable) \
      mpm_adma64cmd_interrupt_enable_q0_reg = (mpm_adma64cmd_interrupt_enable_q0_reg & ~mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_QSI_Enable_MASK) | (ri_qsi_enable << mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_QSI_Enable_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Enable_Q0_SET_RI_QEI_Enable(mpm_adma64cmd_interrupt_enable_q0_reg, ri_qei_enable) \
      mpm_adma64cmd_interrupt_enable_q0_reg = (mpm_adma64cmd_interrupt_enable_q0_reg & ~mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_QEI_Enable_MASK) | (ri_qei_enable << mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_QEI_Enable_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_interrupt_enable_q0_t {
            unsigned int ri_compint_enable              : mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_CompInt_Enable_SIZE;
            unsigned int ri_errint_enable               : mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_SIZE;
            unsigned int ri_qsi_enable                  : mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_QSI_Enable_SIZE;
            unsigned int ri_qei_enable                  : mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_QEI_Enable_SIZE;
            unsigned int                                : 28;
      } mpm_adma64cmd_interrupt_enable_q0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_interrupt_enable_q0_t {
            unsigned int                                : 28;
            unsigned int ri_qei_enable                  : mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_QEI_Enable_SIZE;
            unsigned int ri_qsi_enable                  : mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_QSI_Enable_SIZE;
            unsigned int ri_errint_enable               : mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_SIZE;
            unsigned int ri_compint_enable              : mpM_Adma64Cmd_Interrupt_Enable_Q0_RI_CompInt_Enable_SIZE;
      } mpm_adma64cmd_interrupt_enable_q0_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_interrupt_enable_q0_t f;
} mpm_adma64cmd_interrupt_enable_q0_u;


/*
 * mpM_Adma64Cmd_Interrupt_Status_Q0 struct
 */

#define mpM_Adma64Cmd_Interrupt_Status_Q0_REG_SIZE         32
#define mpM_Adma64Cmd_Interrupt_Status_Q0_RI_CompInt_Valid_SIZE  1
#define mpM_Adma64Cmd_Interrupt_Status_Q0_RI_ErrInt_Valid_SIZE  1
#define mpM_Adma64Cmd_Interrupt_Status_Q0_RI_QSI_Valid_SIZE  1
#define mpM_Adma64Cmd_Interrupt_Status_Q0_RI_QEI_Valid_SIZE  1

#define mpM_Adma64Cmd_Interrupt_Status_Q0_RI_CompInt_Valid_SHIFT  0
#define mpM_Adma64Cmd_Interrupt_Status_Q0_RI_ErrInt_Valid_SHIFT  1
#define mpM_Adma64Cmd_Interrupt_Status_Q0_RI_QSI_Valid_SHIFT  2
#define mpM_Adma64Cmd_Interrupt_Status_Q0_RI_QEI_Valid_SHIFT  3

#define mpM_Adma64Cmd_Interrupt_Status_Q0_RI_CompInt_Valid_MASK  0x00000001
#define mpM_Adma64Cmd_Interrupt_Status_Q0_RI_ErrInt_Valid_MASK  0x00000002
#define mpM_Adma64Cmd_Interrupt_Status_Q0_RI_QSI_Valid_MASK  0x00000004
#define mpM_Adma64Cmd_Interrupt_Status_Q0_RI_QEI_Valid_MASK  0x00000008

#define mpM_Adma64Cmd_Interrupt_Status_Q0_MASK \
      (mpM_Adma64Cmd_Interrupt_Status_Q0_RI_CompInt_Valid_MASK | \
      mpM_Adma64Cmd_Interrupt_Status_Q0_RI_ErrInt_Valid_MASK | \
      mpM_Adma64Cmd_Interrupt_Status_Q0_RI_QSI_Valid_MASK | \
      mpM_Adma64Cmd_Interrupt_Status_Q0_RI_QEI_Valid_MASK)

#define mpM_Adma64Cmd_Interrupt_Status_Q0_DEFAULT 0x00000000

#define mpM_Adma64Cmd_Interrupt_Status_Q0_GET_RI_CompInt_Valid(mpm_adma64cmd_interrupt_status_q0) \
      ((mpm_adma64cmd_interrupt_status_q0 & mpM_Adma64Cmd_Interrupt_Status_Q0_RI_CompInt_Valid_MASK) >> mpM_Adma64Cmd_Interrupt_Status_Q0_RI_CompInt_Valid_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Status_Q0_GET_RI_ErrInt_Valid(mpm_adma64cmd_interrupt_status_q0) \
      ((mpm_adma64cmd_interrupt_status_q0 & mpM_Adma64Cmd_Interrupt_Status_Q0_RI_ErrInt_Valid_MASK) >> mpM_Adma64Cmd_Interrupt_Status_Q0_RI_ErrInt_Valid_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Status_Q0_GET_RI_QSI_Valid(mpm_adma64cmd_interrupt_status_q0) \
      ((mpm_adma64cmd_interrupt_status_q0 & mpM_Adma64Cmd_Interrupt_Status_Q0_RI_QSI_Valid_MASK) >> mpM_Adma64Cmd_Interrupt_Status_Q0_RI_QSI_Valid_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Status_Q0_GET_RI_QEI_Valid(mpm_adma64cmd_interrupt_status_q0) \
      ((mpm_adma64cmd_interrupt_status_q0 & mpM_Adma64Cmd_Interrupt_Status_Q0_RI_QEI_Valid_MASK) >> mpM_Adma64Cmd_Interrupt_Status_Q0_RI_QEI_Valid_SHIFT)

#define mpM_Adma64Cmd_Interrupt_Status_Q0_SET_RI_CompInt_Valid(mpm_adma64cmd_interrupt_status_q0_reg, ri_compint_valid) \
      mpm_adma64cmd_interrupt_status_q0_reg = (mpm_adma64cmd_interrupt_status_q0_reg & ~mpM_Adma64Cmd_Interrupt_Status_Q0_RI_CompInt_Valid_MASK) | (ri_compint_valid << mpM_Adma64Cmd_Interrupt_Status_Q0_RI_CompInt_Valid_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Status_Q0_SET_RI_ErrInt_Valid(mpm_adma64cmd_interrupt_status_q0_reg, ri_errint_valid) \
      mpm_adma64cmd_interrupt_status_q0_reg = (mpm_adma64cmd_interrupt_status_q0_reg & ~mpM_Adma64Cmd_Interrupt_Status_Q0_RI_ErrInt_Valid_MASK) | (ri_errint_valid << mpM_Adma64Cmd_Interrupt_Status_Q0_RI_ErrInt_Valid_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Status_Q0_SET_RI_QSI_Valid(mpm_adma64cmd_interrupt_status_q0_reg, ri_qsi_valid) \
      mpm_adma64cmd_interrupt_status_q0_reg = (mpm_adma64cmd_interrupt_status_q0_reg & ~mpM_Adma64Cmd_Interrupt_Status_Q0_RI_QSI_Valid_MASK) | (ri_qsi_valid << mpM_Adma64Cmd_Interrupt_Status_Q0_RI_QSI_Valid_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Status_Q0_SET_RI_QEI_Valid(mpm_adma64cmd_interrupt_status_q0_reg, ri_qei_valid) \
      mpm_adma64cmd_interrupt_status_q0_reg = (mpm_adma64cmd_interrupt_status_q0_reg & ~mpM_Adma64Cmd_Interrupt_Status_Q0_RI_QEI_Valid_MASK) | (ri_qei_valid << mpM_Adma64Cmd_Interrupt_Status_Q0_RI_QEI_Valid_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_interrupt_status_q0_t {
            unsigned int ri_compint_valid               : mpM_Adma64Cmd_Interrupt_Status_Q0_RI_CompInt_Valid_SIZE;
            unsigned int ri_errint_valid                : mpM_Adma64Cmd_Interrupt_Status_Q0_RI_ErrInt_Valid_SIZE;
            unsigned int ri_qsi_valid                   : mpM_Adma64Cmd_Interrupt_Status_Q0_RI_QSI_Valid_SIZE;
            unsigned int ri_qei_valid                   : mpM_Adma64Cmd_Interrupt_Status_Q0_RI_QEI_Valid_SIZE;
            unsigned int                                : 28;
      } mpm_adma64cmd_interrupt_status_q0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_interrupt_status_q0_t {
            unsigned int                                : 28;
            unsigned int ri_qei_valid                   : mpM_Adma64Cmd_Interrupt_Status_Q0_RI_QEI_Valid_SIZE;
            unsigned int ri_qsi_valid                   : mpM_Adma64Cmd_Interrupt_Status_Q0_RI_QSI_Valid_SIZE;
            unsigned int ri_errint_valid                : mpM_Adma64Cmd_Interrupt_Status_Q0_RI_ErrInt_Valid_SIZE;
            unsigned int ri_compint_valid               : mpM_Adma64Cmd_Interrupt_Status_Q0_RI_CompInt_Valid_SIZE;
      } mpm_adma64cmd_interrupt_status_q0_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_interrupt_status_q0_t f;
} mpm_adma64cmd_interrupt_status_q0_u;


/*
 * mpM_Adma64Cmd_Status_Q0 struct
 */

#define mpM_Adma64Cmd_Status_Q0_REG_SIZE         32
#define mpM_Adma64Cmd_Status_Q0_VQM_Error_SIZE  6
#define mpM_Adma64Cmd_Status_Q0_VQM_ErrorPrevious_SIZE  1
#define mpM_Adma64Cmd_Status_Q0_VQM_JStatus_SIZE  3
#define mpM_Adma64Cmd_Status_Q0_VQM_ErrorSource_SIZE  3

#define mpM_Adma64Cmd_Status_Q0_VQM_Error_SHIFT  0
#define mpM_Adma64Cmd_Status_Q0_VQM_ErrorPrevious_SHIFT  6
#define mpM_Adma64Cmd_Status_Q0_VQM_JStatus_SHIFT  7
#define mpM_Adma64Cmd_Status_Q0_VQM_ErrorSource_SHIFT  10

#define mpM_Adma64Cmd_Status_Q0_VQM_Error_MASK  0x0000003f
#define mpM_Adma64Cmd_Status_Q0_VQM_ErrorPrevious_MASK  0x00000040
#define mpM_Adma64Cmd_Status_Q0_VQM_JStatus_MASK  0x00000380
#define mpM_Adma64Cmd_Status_Q0_VQM_ErrorSource_MASK  0x00001c00

#define mpM_Adma64Cmd_Status_Q0_MASK \
      (mpM_Adma64Cmd_Status_Q0_VQM_Error_MASK | \
      mpM_Adma64Cmd_Status_Q0_VQM_ErrorPrevious_MASK | \
      mpM_Adma64Cmd_Status_Q0_VQM_JStatus_MASK | \
      mpM_Adma64Cmd_Status_Q0_VQM_ErrorSource_MASK)

#define mpM_Adma64Cmd_Status_Q0_DEFAULT 0x00000000

#define mpM_Adma64Cmd_Status_Q0_GET_VQM_Error(mpm_adma64cmd_status_q0) \
      ((mpm_adma64cmd_status_q0 & mpM_Adma64Cmd_Status_Q0_VQM_Error_MASK) >> mpM_Adma64Cmd_Status_Q0_VQM_Error_SHIFT)
#define mpM_Adma64Cmd_Status_Q0_GET_VQM_ErrorPrevious(mpm_adma64cmd_status_q0) \
      ((mpm_adma64cmd_status_q0 & mpM_Adma64Cmd_Status_Q0_VQM_ErrorPrevious_MASK) >> mpM_Adma64Cmd_Status_Q0_VQM_ErrorPrevious_SHIFT)
#define mpM_Adma64Cmd_Status_Q0_GET_VQM_JStatus(mpm_adma64cmd_status_q0) \
      ((mpm_adma64cmd_status_q0 & mpM_Adma64Cmd_Status_Q0_VQM_JStatus_MASK) >> mpM_Adma64Cmd_Status_Q0_VQM_JStatus_SHIFT)
#define mpM_Adma64Cmd_Status_Q0_GET_VQM_ErrorSource(mpm_adma64cmd_status_q0) \
      ((mpm_adma64cmd_status_q0 & mpM_Adma64Cmd_Status_Q0_VQM_ErrorSource_MASK) >> mpM_Adma64Cmd_Status_Q0_VQM_ErrorSource_SHIFT)

#define mpM_Adma64Cmd_Status_Q0_SET_VQM_Error(mpm_adma64cmd_status_q0_reg, vqm_error) \
      mpm_adma64cmd_status_q0_reg = (mpm_adma64cmd_status_q0_reg & ~mpM_Adma64Cmd_Status_Q0_VQM_Error_MASK) | (vqm_error << mpM_Adma64Cmd_Status_Q0_VQM_Error_SHIFT)
#define mpM_Adma64Cmd_Status_Q0_SET_VQM_ErrorPrevious(mpm_adma64cmd_status_q0_reg, vqm_errorprevious) \
      mpm_adma64cmd_status_q0_reg = (mpm_adma64cmd_status_q0_reg & ~mpM_Adma64Cmd_Status_Q0_VQM_ErrorPrevious_MASK) | (vqm_errorprevious << mpM_Adma64Cmd_Status_Q0_VQM_ErrorPrevious_SHIFT)
#define mpM_Adma64Cmd_Status_Q0_SET_VQM_JStatus(mpm_adma64cmd_status_q0_reg, vqm_jstatus) \
      mpm_adma64cmd_status_q0_reg = (mpm_adma64cmd_status_q0_reg & ~mpM_Adma64Cmd_Status_Q0_VQM_JStatus_MASK) | (vqm_jstatus << mpM_Adma64Cmd_Status_Q0_VQM_JStatus_SHIFT)
#define mpM_Adma64Cmd_Status_Q0_SET_VQM_ErrorSource(mpm_adma64cmd_status_q0_reg, vqm_errorsource) \
      mpm_adma64cmd_status_q0_reg = (mpm_adma64cmd_status_q0_reg & ~mpM_Adma64Cmd_Status_Q0_VQM_ErrorSource_MASK) | (vqm_errorsource << mpM_Adma64Cmd_Status_Q0_VQM_ErrorSource_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_status_q0_t {
            unsigned int vqm_error                      : mpM_Adma64Cmd_Status_Q0_VQM_Error_SIZE;
            unsigned int vqm_errorprevious              : mpM_Adma64Cmd_Status_Q0_VQM_ErrorPrevious_SIZE;
            unsigned int vqm_jstatus                    : mpM_Adma64Cmd_Status_Q0_VQM_JStatus_SIZE;
            unsigned int vqm_errorsource                : mpM_Adma64Cmd_Status_Q0_VQM_ErrorSource_SIZE;
            unsigned int                                : 19;
      } mpm_adma64cmd_status_q0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_status_q0_t {
            unsigned int                                : 19;
            unsigned int vqm_errorsource                : mpM_Adma64Cmd_Status_Q0_VQM_ErrorSource_SIZE;
            unsigned int vqm_jstatus                    : mpM_Adma64Cmd_Status_Q0_VQM_JStatus_SIZE;
            unsigned int vqm_errorprevious              : mpM_Adma64Cmd_Status_Q0_VQM_ErrorPrevious_SIZE;
            unsigned int vqm_error                      : mpM_Adma64Cmd_Status_Q0_VQM_Error_SIZE;
      } mpm_adma64cmd_status_q0_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_status_q0_t f;
} mpm_adma64cmd_status_q0_u;


/*
 * mpM_Adma64Cmd_Int_Status_Q0 struct
 */

#define mpM_Adma64Cmd_Int_Status_Q0_REG_SIZE         32
#define mpM_Adma64Cmd_Int_Status_Q0_IC_EventCnt_SIZE  7

#define mpM_Adma64Cmd_Int_Status_Q0_IC_EventCnt_SHIFT  0

#define mpM_Adma64Cmd_Int_Status_Q0_IC_EventCnt_MASK  0x0000007f

#define mpM_Adma64Cmd_Int_Status_Q0_MASK \
      (mpM_Adma64Cmd_Int_Status_Q0_IC_EventCnt_MASK)

#define mpM_Adma64Cmd_Int_Status_Q0_DEFAULT 0x00000000

#define mpM_Adma64Cmd_Int_Status_Q0_GET_IC_EventCnt(mpm_adma64cmd_int_status_q0) \
      ((mpm_adma64cmd_int_status_q0 & mpM_Adma64Cmd_Int_Status_Q0_IC_EventCnt_MASK) >> mpM_Adma64Cmd_Int_Status_Q0_IC_EventCnt_SHIFT)

#define mpM_Adma64Cmd_Int_Status_Q0_SET_IC_EventCnt(mpm_adma64cmd_int_status_q0_reg, ic_eventcnt) \
      mpm_adma64cmd_int_status_q0_reg = (mpm_adma64cmd_int_status_q0_reg & ~mpM_Adma64Cmd_Int_Status_Q0_IC_EventCnt_MASK) | (ic_eventcnt << mpM_Adma64Cmd_Int_Status_Q0_IC_EventCnt_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_int_status_q0_t {
            unsigned int ic_eventcnt                    : mpM_Adma64Cmd_Int_Status_Q0_IC_EventCnt_SIZE;
            unsigned int                                : 25;
      } mpm_adma64cmd_int_status_q0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_int_status_q0_t {
            unsigned int                                : 25;
            unsigned int ic_eventcnt                    : mpM_Adma64Cmd_Int_Status_Q0_IC_EventCnt_SIZE;
      } mpm_adma64cmd_int_status_q0_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_int_status_q0_t f;
} mpm_adma64cmd_int_status_q0_u;


/*
 * mpM_Adma64Cmd_DMA_Status_Q0 struct
 */

#define mpM_Adma64Cmd_DMA_Status_Q0_REG_SIZE         32
#define mpM_Adma64Cmd_DMA_Status_Q0_DMA_Pwrites_SIZE  10
#define mpM_Adma64Cmd_DMA_Status_Q0_DMA_Preads_SIZE  6
#define mpM_Adma64Cmd_DMA_Status_Q0_DMA_Dstatus_SIZE  3

#define mpM_Adma64Cmd_DMA_Status_Q0_DMA_Pwrites_SHIFT  0
#define mpM_Adma64Cmd_DMA_Status_Q0_DMA_Preads_SHIFT  10
#define mpM_Adma64Cmd_DMA_Status_Q0_DMA_Dstatus_SHIFT  16

#define mpM_Adma64Cmd_DMA_Status_Q0_DMA_Pwrites_MASK  0x000003ff
#define mpM_Adma64Cmd_DMA_Status_Q0_DMA_Preads_MASK  0x0000fc00
#define mpM_Adma64Cmd_DMA_Status_Q0_DMA_Dstatus_MASK  0x00070000

#define mpM_Adma64Cmd_DMA_Status_Q0_MASK \
      (mpM_Adma64Cmd_DMA_Status_Q0_DMA_Pwrites_MASK | \
      mpM_Adma64Cmd_DMA_Status_Q0_DMA_Preads_MASK | \
      mpM_Adma64Cmd_DMA_Status_Q0_DMA_Dstatus_MASK)

#define mpM_Adma64Cmd_DMA_Status_Q0_DEFAULT 0x00000000

#define mpM_Adma64Cmd_DMA_Status_Q0_GET_DMA_Pwrites(mpm_adma64cmd_dma_status_q0) \
      ((mpm_adma64cmd_dma_status_q0 & mpM_Adma64Cmd_DMA_Status_Q0_DMA_Pwrites_MASK) >> mpM_Adma64Cmd_DMA_Status_Q0_DMA_Pwrites_SHIFT)
#define mpM_Adma64Cmd_DMA_Status_Q0_GET_DMA_Preads(mpm_adma64cmd_dma_status_q0) \
      ((mpm_adma64cmd_dma_status_q0 & mpM_Adma64Cmd_DMA_Status_Q0_DMA_Preads_MASK) >> mpM_Adma64Cmd_DMA_Status_Q0_DMA_Preads_SHIFT)
#define mpM_Adma64Cmd_DMA_Status_Q0_GET_DMA_Dstatus(mpm_adma64cmd_dma_status_q0) \
      ((mpm_adma64cmd_dma_status_q0 & mpM_Adma64Cmd_DMA_Status_Q0_DMA_Dstatus_MASK) >> mpM_Adma64Cmd_DMA_Status_Q0_DMA_Dstatus_SHIFT)

#define mpM_Adma64Cmd_DMA_Status_Q0_SET_DMA_Pwrites(mpm_adma64cmd_dma_status_q0_reg, dma_pwrites) \
      mpm_adma64cmd_dma_status_q0_reg = (mpm_adma64cmd_dma_status_q0_reg & ~mpM_Adma64Cmd_DMA_Status_Q0_DMA_Pwrites_MASK) | (dma_pwrites << mpM_Adma64Cmd_DMA_Status_Q0_DMA_Pwrites_SHIFT)
#define mpM_Adma64Cmd_DMA_Status_Q0_SET_DMA_Preads(mpm_adma64cmd_dma_status_q0_reg, dma_preads) \
      mpm_adma64cmd_dma_status_q0_reg = (mpm_adma64cmd_dma_status_q0_reg & ~mpM_Adma64Cmd_DMA_Status_Q0_DMA_Preads_MASK) | (dma_preads << mpM_Adma64Cmd_DMA_Status_Q0_DMA_Preads_SHIFT)
#define mpM_Adma64Cmd_DMA_Status_Q0_SET_DMA_Dstatus(mpm_adma64cmd_dma_status_q0_reg, dma_dstatus) \
      mpm_adma64cmd_dma_status_q0_reg = (mpm_adma64cmd_dma_status_q0_reg & ~mpM_Adma64Cmd_DMA_Status_Q0_DMA_Dstatus_MASK) | (dma_dstatus << mpM_Adma64Cmd_DMA_Status_Q0_DMA_Dstatus_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_dma_status_q0_t {
            unsigned int dma_pwrites                    : mpM_Adma64Cmd_DMA_Status_Q0_DMA_Pwrites_SIZE;
            unsigned int dma_preads                     : mpM_Adma64Cmd_DMA_Status_Q0_DMA_Preads_SIZE;
            unsigned int dma_dstatus                    : mpM_Adma64Cmd_DMA_Status_Q0_DMA_Dstatus_SIZE;
            unsigned int                                : 13;
      } mpm_adma64cmd_dma_status_q0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_dma_status_q0_t {
            unsigned int                                : 13;
            unsigned int dma_dstatus                    : mpM_Adma64Cmd_DMA_Status_Q0_DMA_Dstatus_SIZE;
            unsigned int dma_preads                     : mpM_Adma64Cmd_DMA_Status_Q0_DMA_Preads_SIZE;
            unsigned int dma_pwrites                    : mpM_Adma64Cmd_DMA_Status_Q0_DMA_Pwrites_SIZE;
      } mpm_adma64cmd_dma_status_q0_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_dma_status_q0_t f;
} mpm_adma64cmd_dma_status_q0_u;


/*
 * mpM_Adma64Cmd_DMA_Read_Status_Q0 struct
 */

#define mpM_Adma64Cmd_DMA_Read_Status_Q0_REG_SIZE         32
#define mpM_Adma64Cmd_DMA_Read_Status_Q0_DMA_BytesRead_SIZE  32

#define mpM_Adma64Cmd_DMA_Read_Status_Q0_DMA_BytesRead_SHIFT  0

#define mpM_Adma64Cmd_DMA_Read_Status_Q0_DMA_BytesRead_MASK  0xffffffff

#define mpM_Adma64Cmd_DMA_Read_Status_Q0_MASK \
      (mpM_Adma64Cmd_DMA_Read_Status_Q0_DMA_BytesRead_MASK)

#define mpM_Adma64Cmd_DMA_Read_Status_Q0_DEFAULT 0x00000000

#define mpM_Adma64Cmd_DMA_Read_Status_Q0_GET_DMA_BytesRead(mpm_adma64cmd_dma_read_status_q0) \
      ((mpm_adma64cmd_dma_read_status_q0 & mpM_Adma64Cmd_DMA_Read_Status_Q0_DMA_BytesRead_MASK) >> mpM_Adma64Cmd_DMA_Read_Status_Q0_DMA_BytesRead_SHIFT)

#define mpM_Adma64Cmd_DMA_Read_Status_Q0_SET_DMA_BytesRead(mpm_adma64cmd_dma_read_status_q0_reg, dma_bytesread) \
      mpm_adma64cmd_dma_read_status_q0_reg = (mpm_adma64cmd_dma_read_status_q0_reg & ~mpM_Adma64Cmd_DMA_Read_Status_Q0_DMA_BytesRead_MASK) | (dma_bytesread << mpM_Adma64Cmd_DMA_Read_Status_Q0_DMA_BytesRead_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_dma_read_status_q0_t {
            unsigned int dma_bytesread                  : mpM_Adma64Cmd_DMA_Read_Status_Q0_DMA_BytesRead_SIZE;
      } mpm_adma64cmd_dma_read_status_q0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_dma_read_status_q0_t {
            unsigned int dma_bytesread                  : mpM_Adma64Cmd_DMA_Read_Status_Q0_DMA_BytesRead_SIZE;
      } mpm_adma64cmd_dma_read_status_q0_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_dma_read_status_q0_t f;
} mpm_adma64cmd_dma_read_status_q0_u;


/*
 * mpM_Adma64Cmd_DMA_Write_Status_Q0 struct
 */

#define mpM_Adma64Cmd_DMA_Write_Status_Q0_REG_SIZE         32
#define mpM_Adma64Cmd_DMA_Write_Status_Q0_DMA_BytesWritten_SIZE  32

#define mpM_Adma64Cmd_DMA_Write_Status_Q0_DMA_BytesWritten_SHIFT  0

#define mpM_Adma64Cmd_DMA_Write_Status_Q0_DMA_BytesWritten_MASK  0xffffffff

#define mpM_Adma64Cmd_DMA_Write_Status_Q0_MASK \
      (mpM_Adma64Cmd_DMA_Write_Status_Q0_DMA_BytesWritten_MASK)

#define mpM_Adma64Cmd_DMA_Write_Status_Q0_DEFAULT 0x00000000

#define mpM_Adma64Cmd_DMA_Write_Status_Q0_GET_DMA_BytesWritten(mpm_adma64cmd_dma_write_status_q0) \
      ((mpm_adma64cmd_dma_write_status_q0 & mpM_Adma64Cmd_DMA_Write_Status_Q0_DMA_BytesWritten_MASK) >> mpM_Adma64Cmd_DMA_Write_Status_Q0_DMA_BytesWritten_SHIFT)

#define mpM_Adma64Cmd_DMA_Write_Status_Q0_SET_DMA_BytesWritten(mpm_adma64cmd_dma_write_status_q0_reg, dma_byteswritten) \
      mpm_adma64cmd_dma_write_status_q0_reg = (mpm_adma64cmd_dma_write_status_q0_reg & ~mpM_Adma64Cmd_DMA_Write_Status_Q0_DMA_BytesWritten_MASK) | (dma_byteswritten << mpM_Adma64Cmd_DMA_Write_Status_Q0_DMA_BytesWritten_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_dma_write_status_q0_t {
            unsigned int dma_byteswritten               : mpM_Adma64Cmd_DMA_Write_Status_Q0_DMA_BytesWritten_SIZE;
      } mpm_adma64cmd_dma_write_status_q0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_dma_write_status_q0_t {
            unsigned int dma_byteswritten               : mpM_Adma64Cmd_DMA_Write_Status_Q0_DMA_BytesWritten_SIZE;
      } mpm_adma64cmd_dma_write_status_q0_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_dma_write_status_q0_t f;
} mpm_adma64cmd_dma_write_status_q0_u;


/*
 * mpM_Adma64Cmd_Abort_Q0 struct
 */

#define mpM_Adma64Cmd_Abort_Q0_REG_SIZE         32
#define mpM_Adma64Cmd_Abort_Q0_RI_Offset_SIZE  18
#define mpM_Adma64Cmd_Abort_Q0_RI_Offset_Valid_SIZE  1

#define mpM_Adma64Cmd_Abort_Q0_RI_Offset_SHIFT  0
#define mpM_Adma64Cmd_Abort_Q0_RI_Offset_Valid_SHIFT  31

#define mpM_Adma64Cmd_Abort_Q0_RI_Offset_MASK  0x0003ffff
#define mpM_Adma64Cmd_Abort_Q0_RI_Offset_Valid_MASK  0x80000000

#define mpM_Adma64Cmd_Abort_Q0_MASK \
      (mpM_Adma64Cmd_Abort_Q0_RI_Offset_MASK | \
      mpM_Adma64Cmd_Abort_Q0_RI_Offset_Valid_MASK)

#define mpM_Adma64Cmd_Abort_Q0_DEFAULT 0x00000000

#define mpM_Adma64Cmd_Abort_Q0_GET_RI_Offset(mpm_adma64cmd_abort_q0) \
      ((mpm_adma64cmd_abort_q0 & mpM_Adma64Cmd_Abort_Q0_RI_Offset_MASK) >> mpM_Adma64Cmd_Abort_Q0_RI_Offset_SHIFT)
#define mpM_Adma64Cmd_Abort_Q0_GET_RI_Offset_Valid(mpm_adma64cmd_abort_q0) \
      ((mpm_adma64cmd_abort_q0 & mpM_Adma64Cmd_Abort_Q0_RI_Offset_Valid_MASK) >> mpM_Adma64Cmd_Abort_Q0_RI_Offset_Valid_SHIFT)

#define mpM_Adma64Cmd_Abort_Q0_SET_RI_Offset(mpm_adma64cmd_abort_q0_reg, ri_offset) \
      mpm_adma64cmd_abort_q0_reg = (mpm_adma64cmd_abort_q0_reg & ~mpM_Adma64Cmd_Abort_Q0_RI_Offset_MASK) | (ri_offset << mpM_Adma64Cmd_Abort_Q0_RI_Offset_SHIFT)
#define mpM_Adma64Cmd_Abort_Q0_SET_RI_Offset_Valid(mpm_adma64cmd_abort_q0_reg, ri_offset_valid) \
      mpm_adma64cmd_abort_q0_reg = (mpm_adma64cmd_abort_q0_reg & ~mpM_Adma64Cmd_Abort_Q0_RI_Offset_Valid_MASK) | (ri_offset_valid << mpM_Adma64Cmd_Abort_Q0_RI_Offset_Valid_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_abort_q0_t {
            unsigned int ri_offset                      : mpM_Adma64Cmd_Abort_Q0_RI_Offset_SIZE;
            unsigned int                                : 13;
            unsigned int ri_offset_valid                : mpM_Adma64Cmd_Abort_Q0_RI_Offset_Valid_SIZE;
      } mpm_adma64cmd_abort_q0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_abort_q0_t {
            unsigned int ri_offset_valid                : mpM_Adma64Cmd_Abort_Q0_RI_Offset_Valid_SIZE;
            unsigned int                                : 13;
            unsigned int ri_offset                      : mpM_Adma64Cmd_Abort_Q0_RI_Offset_SIZE;
      } mpm_adma64cmd_abort_q0_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_abort_q0_t f;
} mpm_adma64cmd_abort_q0_u;


/*
 * mpM_Adma64Cmd_AxCACHE_Q0 struct
 */

#define mpM_Adma64Cmd_AxCACHE_Q0_REG_SIZE         32
#define mpM_Adma64Cmd_AxCACHE_Q0_RI_AWCACHE_SIZE  4
#define mpM_Adma64Cmd_AxCACHE_Q0_RI_ARCACHE_SIZE  4
#define mpM_Adma64Cmd_AxCACHE_Q0_RI_VCD_ARCACHE_SIZE  4

#define mpM_Adma64Cmd_AxCACHE_Q0_RI_AWCACHE_SHIFT  0
#define mpM_Adma64Cmd_AxCACHE_Q0_RI_ARCACHE_SHIFT  4
#define mpM_Adma64Cmd_AxCACHE_Q0_RI_VCD_ARCACHE_SHIFT  8

#define mpM_Adma64Cmd_AxCACHE_Q0_RI_AWCACHE_MASK  0x0000000f
#define mpM_Adma64Cmd_AxCACHE_Q0_RI_ARCACHE_MASK  0x000000f0
#define mpM_Adma64Cmd_AxCACHE_Q0_RI_VCD_ARCACHE_MASK  0x00000f00

#define mpM_Adma64Cmd_AxCACHE_Q0_MASK \
      (mpM_Adma64Cmd_AxCACHE_Q0_RI_AWCACHE_MASK | \
      mpM_Adma64Cmd_AxCACHE_Q0_RI_ARCACHE_MASK | \
      mpM_Adma64Cmd_AxCACHE_Q0_RI_VCD_ARCACHE_MASK)

#define mpM_Adma64Cmd_AxCACHE_Q0_DEFAULT 0x00000000

#define mpM_Adma64Cmd_AxCACHE_Q0_GET_RI_AWCACHE(mpm_adma64cmd_axcache_q0) \
      ((mpm_adma64cmd_axcache_q0 & mpM_Adma64Cmd_AxCACHE_Q0_RI_AWCACHE_MASK) >> mpM_Adma64Cmd_AxCACHE_Q0_RI_AWCACHE_SHIFT)
#define mpM_Adma64Cmd_AxCACHE_Q0_GET_RI_ARCACHE(mpm_adma64cmd_axcache_q0) \
      ((mpm_adma64cmd_axcache_q0 & mpM_Adma64Cmd_AxCACHE_Q0_RI_ARCACHE_MASK) >> mpM_Adma64Cmd_AxCACHE_Q0_RI_ARCACHE_SHIFT)
#define mpM_Adma64Cmd_AxCACHE_Q0_GET_RI_VCD_ARCACHE(mpm_adma64cmd_axcache_q0) \
      ((mpm_adma64cmd_axcache_q0 & mpM_Adma64Cmd_AxCACHE_Q0_RI_VCD_ARCACHE_MASK) >> mpM_Adma64Cmd_AxCACHE_Q0_RI_VCD_ARCACHE_SHIFT)

#define mpM_Adma64Cmd_AxCACHE_Q0_SET_RI_AWCACHE(mpm_adma64cmd_axcache_q0_reg, ri_awcache) \
      mpm_adma64cmd_axcache_q0_reg = (mpm_adma64cmd_axcache_q0_reg & ~mpM_Adma64Cmd_AxCACHE_Q0_RI_AWCACHE_MASK) | (ri_awcache << mpM_Adma64Cmd_AxCACHE_Q0_RI_AWCACHE_SHIFT)
#define mpM_Adma64Cmd_AxCACHE_Q0_SET_RI_ARCACHE(mpm_adma64cmd_axcache_q0_reg, ri_arcache) \
      mpm_adma64cmd_axcache_q0_reg = (mpm_adma64cmd_axcache_q0_reg & ~mpM_Adma64Cmd_AxCACHE_Q0_RI_ARCACHE_MASK) | (ri_arcache << mpM_Adma64Cmd_AxCACHE_Q0_RI_ARCACHE_SHIFT)
#define mpM_Adma64Cmd_AxCACHE_Q0_SET_RI_VCD_ARCACHE(mpm_adma64cmd_axcache_q0_reg, ri_vcd_arcache) \
      mpm_adma64cmd_axcache_q0_reg = (mpm_adma64cmd_axcache_q0_reg & ~mpM_Adma64Cmd_AxCACHE_Q0_RI_VCD_ARCACHE_MASK) | (ri_vcd_arcache << mpM_Adma64Cmd_AxCACHE_Q0_RI_VCD_ARCACHE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_axcache_q0_t {
            unsigned int ri_awcache                     : mpM_Adma64Cmd_AxCACHE_Q0_RI_AWCACHE_SIZE;
            unsigned int ri_arcache                     : mpM_Adma64Cmd_AxCACHE_Q0_RI_ARCACHE_SIZE;
            unsigned int ri_vcd_arcache                 : mpM_Adma64Cmd_AxCACHE_Q0_RI_VCD_ARCACHE_SIZE;
            unsigned int                                : 20;
      } mpm_adma64cmd_axcache_q0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_axcache_q0_t {
            unsigned int                                : 20;
            unsigned int ri_vcd_arcache                 : mpM_Adma64Cmd_AxCACHE_Q0_RI_VCD_ARCACHE_SIZE;
            unsigned int ri_arcache                     : mpM_Adma64Cmd_AxCACHE_Q0_RI_ARCACHE_SIZE;
            unsigned int ri_awcache                     : mpM_Adma64Cmd_AxCACHE_Q0_RI_AWCACHE_SIZE;
      } mpm_adma64cmd_axcache_q0_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_axcache_q0_t f;
} mpm_adma64cmd_axcache_q0_u;


/*
 * mpM_Adma64Vqd1_Control struct
 */

#define mpM_Adma64Vqd1_Control_REG_SIZE         32
#define mpM_Adma64Vqd1_Control_RI_Run_SIZE  1
#define mpM_Adma64Vqd1_Control_VQM_Halted_SIZE  1
#define mpM_Adma64Vqd1_Control_RI_Mem_Location_SIZE  1
#define mpM_Adma64Vqd1_Control_RI_Queue_Size_SIZE  4
#define mpM_Adma64Vqd1_Control_RI_COMP_DESC_SIZE  1
#define mpM_Adma64Vqd1_Control_RI_VQD_Pointer_Hi_SIZE  16

#define mpM_Adma64Vqd1_Control_RI_Run_SHIFT  0
#define mpM_Adma64Vqd1_Control_VQM_Halted_SHIFT  1
#define mpM_Adma64Vqd1_Control_RI_Mem_Location_SHIFT  2
#define mpM_Adma64Vqd1_Control_RI_Queue_Size_SHIFT  3
#define mpM_Adma64Vqd1_Control_RI_COMP_DESC_SHIFT  7
#define mpM_Adma64Vqd1_Control_RI_VQD_Pointer_Hi_SHIFT  16

#define mpM_Adma64Vqd1_Control_RI_Run_MASK  0x00000001
#define mpM_Adma64Vqd1_Control_VQM_Halted_MASK  0x00000002
#define mpM_Adma64Vqd1_Control_RI_Mem_Location_MASK  0x00000004
#define mpM_Adma64Vqd1_Control_RI_Queue_Size_MASK  0x00000078
#define mpM_Adma64Vqd1_Control_RI_COMP_DESC_MASK  0x00000080
#define mpM_Adma64Vqd1_Control_RI_VQD_Pointer_Hi_MASK  0xffff0000

#define mpM_Adma64Vqd1_Control_MASK \
      (mpM_Adma64Vqd1_Control_RI_Run_MASK | \
      mpM_Adma64Vqd1_Control_VQM_Halted_MASK | \
      mpM_Adma64Vqd1_Control_RI_Mem_Location_MASK | \
      mpM_Adma64Vqd1_Control_RI_Queue_Size_MASK | \
      mpM_Adma64Vqd1_Control_RI_COMP_DESC_MASK | \
      mpM_Adma64Vqd1_Control_RI_VQD_Pointer_Hi_MASK)

#define mpM_Adma64Vqd1_Control_DEFAULT 0x00000002

#define mpM_Adma64Vqd1_Control_GET_RI_Run(mpm_adma64vqd1_control) \
      ((mpm_adma64vqd1_control & mpM_Adma64Vqd1_Control_RI_Run_MASK) >> mpM_Adma64Vqd1_Control_RI_Run_SHIFT)
#define mpM_Adma64Vqd1_Control_GET_VQM_Halted(mpm_adma64vqd1_control) \
      ((mpm_adma64vqd1_control & mpM_Adma64Vqd1_Control_VQM_Halted_MASK) >> mpM_Adma64Vqd1_Control_VQM_Halted_SHIFT)
#define mpM_Adma64Vqd1_Control_GET_RI_Mem_Location(mpm_adma64vqd1_control) \
      ((mpm_adma64vqd1_control & mpM_Adma64Vqd1_Control_RI_Mem_Location_MASK) >> mpM_Adma64Vqd1_Control_RI_Mem_Location_SHIFT)
#define mpM_Adma64Vqd1_Control_GET_RI_Queue_Size(mpm_adma64vqd1_control) \
      ((mpm_adma64vqd1_control & mpM_Adma64Vqd1_Control_RI_Queue_Size_MASK) >> mpM_Adma64Vqd1_Control_RI_Queue_Size_SHIFT)
#define mpM_Adma64Vqd1_Control_GET_RI_COMP_DESC(mpm_adma64vqd1_control) \
      ((mpm_adma64vqd1_control & mpM_Adma64Vqd1_Control_RI_COMP_DESC_MASK) >> mpM_Adma64Vqd1_Control_RI_COMP_DESC_SHIFT)
#define mpM_Adma64Vqd1_Control_GET_RI_VQD_Pointer_Hi(mpm_adma64vqd1_control) \
      ((mpm_adma64vqd1_control & mpM_Adma64Vqd1_Control_RI_VQD_Pointer_Hi_MASK) >> mpM_Adma64Vqd1_Control_RI_VQD_Pointer_Hi_SHIFT)

#define mpM_Adma64Vqd1_Control_SET_RI_Run(mpm_adma64vqd1_control_reg, ri_run) \
      mpm_adma64vqd1_control_reg = (mpm_adma64vqd1_control_reg & ~mpM_Adma64Vqd1_Control_RI_Run_MASK) | (ri_run << mpM_Adma64Vqd1_Control_RI_Run_SHIFT)
#define mpM_Adma64Vqd1_Control_SET_VQM_Halted(mpm_adma64vqd1_control_reg, vqm_halted) \
      mpm_adma64vqd1_control_reg = (mpm_adma64vqd1_control_reg & ~mpM_Adma64Vqd1_Control_VQM_Halted_MASK) | (vqm_halted << mpM_Adma64Vqd1_Control_VQM_Halted_SHIFT)
#define mpM_Adma64Vqd1_Control_SET_RI_Mem_Location(mpm_adma64vqd1_control_reg, ri_mem_location) \
      mpm_adma64vqd1_control_reg = (mpm_adma64vqd1_control_reg & ~mpM_Adma64Vqd1_Control_RI_Mem_Location_MASK) | (ri_mem_location << mpM_Adma64Vqd1_Control_RI_Mem_Location_SHIFT)
#define mpM_Adma64Vqd1_Control_SET_RI_Queue_Size(mpm_adma64vqd1_control_reg, ri_queue_size) \
      mpm_adma64vqd1_control_reg = (mpm_adma64vqd1_control_reg & ~mpM_Adma64Vqd1_Control_RI_Queue_Size_MASK) | (ri_queue_size << mpM_Adma64Vqd1_Control_RI_Queue_Size_SHIFT)
#define mpM_Adma64Vqd1_Control_SET_RI_COMP_DESC(mpm_adma64vqd1_control_reg, ri_comp_desc) \
      mpm_adma64vqd1_control_reg = (mpm_adma64vqd1_control_reg & ~mpM_Adma64Vqd1_Control_RI_COMP_DESC_MASK) | (ri_comp_desc << mpM_Adma64Vqd1_Control_RI_COMP_DESC_SHIFT)
#define mpM_Adma64Vqd1_Control_SET_RI_VQD_Pointer_Hi(mpm_adma64vqd1_control_reg, ri_vqd_pointer_hi) \
      mpm_adma64vqd1_control_reg = (mpm_adma64vqd1_control_reg & ~mpM_Adma64Vqd1_Control_RI_VQD_Pointer_Hi_MASK) | (ri_vqd_pointer_hi << mpM_Adma64Vqd1_Control_RI_VQD_Pointer_Hi_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64vqd1_control_t {
            unsigned int ri_run                         : mpM_Adma64Vqd1_Control_RI_Run_SIZE;
            unsigned int vqm_halted                     : mpM_Adma64Vqd1_Control_VQM_Halted_SIZE;
            unsigned int ri_mem_location                : mpM_Adma64Vqd1_Control_RI_Mem_Location_SIZE;
            unsigned int ri_queue_size                  : mpM_Adma64Vqd1_Control_RI_Queue_Size_SIZE;
            unsigned int ri_comp_desc                   : mpM_Adma64Vqd1_Control_RI_COMP_DESC_SIZE;
            unsigned int                                : 8;
            unsigned int ri_vqd_pointer_hi              : mpM_Adma64Vqd1_Control_RI_VQD_Pointer_Hi_SIZE;
      } mpm_adma64vqd1_control_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64vqd1_control_t {
            unsigned int ri_vqd_pointer_hi              : mpM_Adma64Vqd1_Control_RI_VQD_Pointer_Hi_SIZE;
            unsigned int                                : 8;
            unsigned int ri_comp_desc                   : mpM_Adma64Vqd1_Control_RI_COMP_DESC_SIZE;
            unsigned int ri_queue_size                  : mpM_Adma64Vqd1_Control_RI_Queue_Size_SIZE;
            unsigned int ri_mem_location                : mpM_Adma64Vqd1_Control_RI_Mem_Location_SIZE;
            unsigned int vqm_halted                     : mpM_Adma64Vqd1_Control_VQM_Halted_SIZE;
            unsigned int ri_run                         : mpM_Adma64Vqd1_Control_RI_Run_SIZE;
      } mpm_adma64vqd1_control_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64vqd1_control_t f;
} mpm_adma64vqd1_control_u;


/*
 * mpM_Adma64Vqd1_Tail_Lo struct
 */

#define mpM_Adma64Vqd1_Tail_Lo_REG_SIZE         32
#define mpM_Adma64Vqd1_Tail_Lo_RI_Tail_Pointer_Lo_SIZE  32

#define mpM_Adma64Vqd1_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT  0

#define mpM_Adma64Vqd1_Tail_Lo_RI_Tail_Pointer_Lo_MASK  0xffffffff

#define mpM_Adma64Vqd1_Tail_Lo_MASK \
      (mpM_Adma64Vqd1_Tail_Lo_RI_Tail_Pointer_Lo_MASK)

#define mpM_Adma64Vqd1_Tail_Lo_DEFAULT 0x00000000

#define mpM_Adma64Vqd1_Tail_Lo_GET_RI_Tail_Pointer_Lo(mpm_adma64vqd1_tail_lo) \
      ((mpm_adma64vqd1_tail_lo & mpM_Adma64Vqd1_Tail_Lo_RI_Tail_Pointer_Lo_MASK) >> mpM_Adma64Vqd1_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT)

#define mpM_Adma64Vqd1_Tail_Lo_SET_RI_Tail_Pointer_Lo(mpm_adma64vqd1_tail_lo_reg, ri_tail_pointer_lo) \
      mpm_adma64vqd1_tail_lo_reg = (mpm_adma64vqd1_tail_lo_reg & ~mpM_Adma64Vqd1_Tail_Lo_RI_Tail_Pointer_Lo_MASK) | (ri_tail_pointer_lo << mpM_Adma64Vqd1_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64vqd1_tail_lo_t {
            unsigned int ri_tail_pointer_lo             : mpM_Adma64Vqd1_Tail_Lo_RI_Tail_Pointer_Lo_SIZE;
      } mpm_adma64vqd1_tail_lo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64vqd1_tail_lo_t {
            unsigned int ri_tail_pointer_lo             : mpM_Adma64Vqd1_Tail_Lo_RI_Tail_Pointer_Lo_SIZE;
      } mpm_adma64vqd1_tail_lo_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64vqd1_tail_lo_t f;
} mpm_adma64vqd1_tail_lo_u;


/*
 * mpM_Adma64Vqd1_Head_Lo struct
 */

#define mpM_Adma64Vqd1_Head_Lo_REG_SIZE         32
#define mpM_Adma64Vqd1_Head_Lo_RI_Head_Pointer_Lo_SIZE  32

#define mpM_Adma64Vqd1_Head_Lo_RI_Head_Pointer_Lo_SHIFT  0

#define mpM_Adma64Vqd1_Head_Lo_RI_Head_Pointer_Lo_MASK  0xffffffff

#define mpM_Adma64Vqd1_Head_Lo_MASK \
      (mpM_Adma64Vqd1_Head_Lo_RI_Head_Pointer_Lo_MASK)

#define mpM_Adma64Vqd1_Head_Lo_DEFAULT 0x00000000

#define mpM_Adma64Vqd1_Head_Lo_GET_RI_Head_Pointer_Lo(mpm_adma64vqd1_head_lo) \
      ((mpm_adma64vqd1_head_lo & mpM_Adma64Vqd1_Head_Lo_RI_Head_Pointer_Lo_MASK) >> mpM_Adma64Vqd1_Head_Lo_RI_Head_Pointer_Lo_SHIFT)

#define mpM_Adma64Vqd1_Head_Lo_SET_RI_Head_Pointer_Lo(mpm_adma64vqd1_head_lo_reg, ri_head_pointer_lo) \
      mpm_adma64vqd1_head_lo_reg = (mpm_adma64vqd1_head_lo_reg & ~mpM_Adma64Vqd1_Head_Lo_RI_Head_Pointer_Lo_MASK) | (ri_head_pointer_lo << mpM_Adma64Vqd1_Head_Lo_RI_Head_Pointer_Lo_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64vqd1_head_lo_t {
            unsigned int ri_head_pointer_lo             : mpM_Adma64Vqd1_Head_Lo_RI_Head_Pointer_Lo_SIZE;
      } mpm_adma64vqd1_head_lo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64vqd1_head_lo_t {
            unsigned int ri_head_pointer_lo             : mpM_Adma64Vqd1_Head_Lo_RI_Head_Pointer_Lo_SIZE;
      } mpm_adma64vqd1_head_lo_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64vqd1_head_lo_t f;
} mpm_adma64vqd1_head_lo_u;


/*
 * mpM_Adma64Cmd_Interrupt_Enable_Q1 struct
 */

#define mpM_Adma64Cmd_Interrupt_Enable_Q1_REG_SIZE         32
#define mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_CompInt_Enable_SIZE  1
#define mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_SIZE  1
#define mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_QSI_Enable_SIZE  1
#define mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_QEI_Enable_SIZE  1

#define mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_CompInt_Enable_SHIFT  0
#define mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_SHIFT  1
#define mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_QSI_Enable_SHIFT  2
#define mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_QEI_Enable_SHIFT  3

#define mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_CompInt_Enable_MASK  0x00000001
#define mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_MASK  0x00000002
#define mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_QSI_Enable_MASK  0x00000004
#define mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_QEI_Enable_MASK  0x00000008

#define mpM_Adma64Cmd_Interrupt_Enable_Q1_MASK \
      (mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_CompInt_Enable_MASK | \
      mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_MASK | \
      mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_QSI_Enable_MASK | \
      mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_QEI_Enable_MASK)

#define mpM_Adma64Cmd_Interrupt_Enable_Q1_DEFAULT 0x00000000

#define mpM_Adma64Cmd_Interrupt_Enable_Q1_GET_RI_CompInt_Enable(mpm_adma64cmd_interrupt_enable_q1) \
      ((mpm_adma64cmd_interrupt_enable_q1 & mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_CompInt_Enable_MASK) >> mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_CompInt_Enable_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Enable_Q1_GET_RI_ErrInt_Enable(mpm_adma64cmd_interrupt_enable_q1) \
      ((mpm_adma64cmd_interrupt_enable_q1 & mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_MASK) >> mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Enable_Q1_GET_RI_QSI_Enable(mpm_adma64cmd_interrupt_enable_q1) \
      ((mpm_adma64cmd_interrupt_enable_q1 & mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_QSI_Enable_MASK) >> mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_QSI_Enable_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Enable_Q1_GET_RI_QEI_Enable(mpm_adma64cmd_interrupt_enable_q1) \
      ((mpm_adma64cmd_interrupt_enable_q1 & mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_QEI_Enable_MASK) >> mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_QEI_Enable_SHIFT)

#define mpM_Adma64Cmd_Interrupt_Enable_Q1_SET_RI_CompInt_Enable(mpm_adma64cmd_interrupt_enable_q1_reg, ri_compint_enable) \
      mpm_adma64cmd_interrupt_enable_q1_reg = (mpm_adma64cmd_interrupt_enable_q1_reg & ~mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_CompInt_Enable_MASK) | (ri_compint_enable << mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_CompInt_Enable_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Enable_Q1_SET_RI_ErrInt_Enable(mpm_adma64cmd_interrupt_enable_q1_reg, ri_errint_enable) \
      mpm_adma64cmd_interrupt_enable_q1_reg = (mpm_adma64cmd_interrupt_enable_q1_reg & ~mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_MASK) | (ri_errint_enable << mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Enable_Q1_SET_RI_QSI_Enable(mpm_adma64cmd_interrupt_enable_q1_reg, ri_qsi_enable) \
      mpm_adma64cmd_interrupt_enable_q1_reg = (mpm_adma64cmd_interrupt_enable_q1_reg & ~mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_QSI_Enable_MASK) | (ri_qsi_enable << mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_QSI_Enable_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Enable_Q1_SET_RI_QEI_Enable(mpm_adma64cmd_interrupt_enable_q1_reg, ri_qei_enable) \
      mpm_adma64cmd_interrupt_enable_q1_reg = (mpm_adma64cmd_interrupt_enable_q1_reg & ~mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_QEI_Enable_MASK) | (ri_qei_enable << mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_QEI_Enable_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_interrupt_enable_q1_t {
            unsigned int ri_compint_enable              : mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_CompInt_Enable_SIZE;
            unsigned int ri_errint_enable               : mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_SIZE;
            unsigned int ri_qsi_enable                  : mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_QSI_Enable_SIZE;
            unsigned int ri_qei_enable                  : mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_QEI_Enable_SIZE;
            unsigned int                                : 28;
      } mpm_adma64cmd_interrupt_enable_q1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_interrupt_enable_q1_t {
            unsigned int                                : 28;
            unsigned int ri_qei_enable                  : mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_QEI_Enable_SIZE;
            unsigned int ri_qsi_enable                  : mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_QSI_Enable_SIZE;
            unsigned int ri_errint_enable               : mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_SIZE;
            unsigned int ri_compint_enable              : mpM_Adma64Cmd_Interrupt_Enable_Q1_RI_CompInt_Enable_SIZE;
      } mpm_adma64cmd_interrupt_enable_q1_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_interrupt_enable_q1_t f;
} mpm_adma64cmd_interrupt_enable_q1_u;


/*
 * mpM_Adma64Cmd_Interrupt_Status_Q1 struct
 */

#define mpM_Adma64Cmd_Interrupt_Status_Q1_REG_SIZE         32
#define mpM_Adma64Cmd_Interrupt_Status_Q1_RI_CompInt_Valid_SIZE  1
#define mpM_Adma64Cmd_Interrupt_Status_Q1_RI_ErrInt_Valid_SIZE  1
#define mpM_Adma64Cmd_Interrupt_Status_Q1_RI_QSI_Valid_SIZE  1
#define mpM_Adma64Cmd_Interrupt_Status_Q1_RI_QEI_Valid_SIZE  1

#define mpM_Adma64Cmd_Interrupt_Status_Q1_RI_CompInt_Valid_SHIFT  0
#define mpM_Adma64Cmd_Interrupt_Status_Q1_RI_ErrInt_Valid_SHIFT  1
#define mpM_Adma64Cmd_Interrupt_Status_Q1_RI_QSI_Valid_SHIFT  2
#define mpM_Adma64Cmd_Interrupt_Status_Q1_RI_QEI_Valid_SHIFT  3

#define mpM_Adma64Cmd_Interrupt_Status_Q1_RI_CompInt_Valid_MASK  0x00000001
#define mpM_Adma64Cmd_Interrupt_Status_Q1_RI_ErrInt_Valid_MASK  0x00000002
#define mpM_Adma64Cmd_Interrupt_Status_Q1_RI_QSI_Valid_MASK  0x00000004
#define mpM_Adma64Cmd_Interrupt_Status_Q1_RI_QEI_Valid_MASK  0x00000008

#define mpM_Adma64Cmd_Interrupt_Status_Q1_MASK \
      (mpM_Adma64Cmd_Interrupt_Status_Q1_RI_CompInt_Valid_MASK | \
      mpM_Adma64Cmd_Interrupt_Status_Q1_RI_ErrInt_Valid_MASK | \
      mpM_Adma64Cmd_Interrupt_Status_Q1_RI_QSI_Valid_MASK | \
      mpM_Adma64Cmd_Interrupt_Status_Q1_RI_QEI_Valid_MASK)

#define mpM_Adma64Cmd_Interrupt_Status_Q1_DEFAULT 0x00000000

#define mpM_Adma64Cmd_Interrupt_Status_Q1_GET_RI_CompInt_Valid(mpm_adma64cmd_interrupt_status_q1) \
      ((mpm_adma64cmd_interrupt_status_q1 & mpM_Adma64Cmd_Interrupt_Status_Q1_RI_CompInt_Valid_MASK) >> mpM_Adma64Cmd_Interrupt_Status_Q1_RI_CompInt_Valid_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Status_Q1_GET_RI_ErrInt_Valid(mpm_adma64cmd_interrupt_status_q1) \
      ((mpm_adma64cmd_interrupt_status_q1 & mpM_Adma64Cmd_Interrupt_Status_Q1_RI_ErrInt_Valid_MASK) >> mpM_Adma64Cmd_Interrupt_Status_Q1_RI_ErrInt_Valid_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Status_Q1_GET_RI_QSI_Valid(mpm_adma64cmd_interrupt_status_q1) \
      ((mpm_adma64cmd_interrupt_status_q1 & mpM_Adma64Cmd_Interrupt_Status_Q1_RI_QSI_Valid_MASK) >> mpM_Adma64Cmd_Interrupt_Status_Q1_RI_QSI_Valid_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Status_Q1_GET_RI_QEI_Valid(mpm_adma64cmd_interrupt_status_q1) \
      ((mpm_adma64cmd_interrupt_status_q1 & mpM_Adma64Cmd_Interrupt_Status_Q1_RI_QEI_Valid_MASK) >> mpM_Adma64Cmd_Interrupt_Status_Q1_RI_QEI_Valid_SHIFT)

#define mpM_Adma64Cmd_Interrupt_Status_Q1_SET_RI_CompInt_Valid(mpm_adma64cmd_interrupt_status_q1_reg, ri_compint_valid) \
      mpm_adma64cmd_interrupt_status_q1_reg = (mpm_adma64cmd_interrupt_status_q1_reg & ~mpM_Adma64Cmd_Interrupt_Status_Q1_RI_CompInt_Valid_MASK) | (ri_compint_valid << mpM_Adma64Cmd_Interrupt_Status_Q1_RI_CompInt_Valid_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Status_Q1_SET_RI_ErrInt_Valid(mpm_adma64cmd_interrupt_status_q1_reg, ri_errint_valid) \
      mpm_adma64cmd_interrupt_status_q1_reg = (mpm_adma64cmd_interrupt_status_q1_reg & ~mpM_Adma64Cmd_Interrupt_Status_Q1_RI_ErrInt_Valid_MASK) | (ri_errint_valid << mpM_Adma64Cmd_Interrupt_Status_Q1_RI_ErrInt_Valid_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Status_Q1_SET_RI_QSI_Valid(mpm_adma64cmd_interrupt_status_q1_reg, ri_qsi_valid) \
      mpm_adma64cmd_interrupt_status_q1_reg = (mpm_adma64cmd_interrupt_status_q1_reg & ~mpM_Adma64Cmd_Interrupt_Status_Q1_RI_QSI_Valid_MASK) | (ri_qsi_valid << mpM_Adma64Cmd_Interrupt_Status_Q1_RI_QSI_Valid_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Status_Q1_SET_RI_QEI_Valid(mpm_adma64cmd_interrupt_status_q1_reg, ri_qei_valid) \
      mpm_adma64cmd_interrupt_status_q1_reg = (mpm_adma64cmd_interrupt_status_q1_reg & ~mpM_Adma64Cmd_Interrupt_Status_Q1_RI_QEI_Valid_MASK) | (ri_qei_valid << mpM_Adma64Cmd_Interrupt_Status_Q1_RI_QEI_Valid_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_interrupt_status_q1_t {
            unsigned int ri_compint_valid               : mpM_Adma64Cmd_Interrupt_Status_Q1_RI_CompInt_Valid_SIZE;
            unsigned int ri_errint_valid                : mpM_Adma64Cmd_Interrupt_Status_Q1_RI_ErrInt_Valid_SIZE;
            unsigned int ri_qsi_valid                   : mpM_Adma64Cmd_Interrupt_Status_Q1_RI_QSI_Valid_SIZE;
            unsigned int ri_qei_valid                   : mpM_Adma64Cmd_Interrupt_Status_Q1_RI_QEI_Valid_SIZE;
            unsigned int                                : 28;
      } mpm_adma64cmd_interrupt_status_q1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_interrupt_status_q1_t {
            unsigned int                                : 28;
            unsigned int ri_qei_valid                   : mpM_Adma64Cmd_Interrupt_Status_Q1_RI_QEI_Valid_SIZE;
            unsigned int ri_qsi_valid                   : mpM_Adma64Cmd_Interrupt_Status_Q1_RI_QSI_Valid_SIZE;
            unsigned int ri_errint_valid                : mpM_Adma64Cmd_Interrupt_Status_Q1_RI_ErrInt_Valid_SIZE;
            unsigned int ri_compint_valid               : mpM_Adma64Cmd_Interrupt_Status_Q1_RI_CompInt_Valid_SIZE;
      } mpm_adma64cmd_interrupt_status_q1_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_interrupt_status_q1_t f;
} mpm_adma64cmd_interrupt_status_q1_u;


/*
 * mpM_Adma64Cmd_Status_Q1 struct
 */

#define mpM_Adma64Cmd_Status_Q1_REG_SIZE         32
#define mpM_Adma64Cmd_Status_Q1_VQM_Error_SIZE  6
#define mpM_Adma64Cmd_Status_Q1_VQM_ErrorPrevious_SIZE  1
#define mpM_Adma64Cmd_Status_Q1_VQM_JStatus_SIZE  3
#define mpM_Adma64Cmd_Status_Q1_VQM_ErrorSource_SIZE  3

#define mpM_Adma64Cmd_Status_Q1_VQM_Error_SHIFT  0
#define mpM_Adma64Cmd_Status_Q1_VQM_ErrorPrevious_SHIFT  6
#define mpM_Adma64Cmd_Status_Q1_VQM_JStatus_SHIFT  7
#define mpM_Adma64Cmd_Status_Q1_VQM_ErrorSource_SHIFT  10

#define mpM_Adma64Cmd_Status_Q1_VQM_Error_MASK  0x0000003f
#define mpM_Adma64Cmd_Status_Q1_VQM_ErrorPrevious_MASK  0x00000040
#define mpM_Adma64Cmd_Status_Q1_VQM_JStatus_MASK  0x00000380
#define mpM_Adma64Cmd_Status_Q1_VQM_ErrorSource_MASK  0x00001c00

#define mpM_Adma64Cmd_Status_Q1_MASK \
      (mpM_Adma64Cmd_Status_Q1_VQM_Error_MASK | \
      mpM_Adma64Cmd_Status_Q1_VQM_ErrorPrevious_MASK | \
      mpM_Adma64Cmd_Status_Q1_VQM_JStatus_MASK | \
      mpM_Adma64Cmd_Status_Q1_VQM_ErrorSource_MASK)

#define mpM_Adma64Cmd_Status_Q1_DEFAULT 0x00000000

#define mpM_Adma64Cmd_Status_Q1_GET_VQM_Error(mpm_adma64cmd_status_q1) \
      ((mpm_adma64cmd_status_q1 & mpM_Adma64Cmd_Status_Q1_VQM_Error_MASK) >> mpM_Adma64Cmd_Status_Q1_VQM_Error_SHIFT)
#define mpM_Adma64Cmd_Status_Q1_GET_VQM_ErrorPrevious(mpm_adma64cmd_status_q1) \
      ((mpm_adma64cmd_status_q1 & mpM_Adma64Cmd_Status_Q1_VQM_ErrorPrevious_MASK) >> mpM_Adma64Cmd_Status_Q1_VQM_ErrorPrevious_SHIFT)
#define mpM_Adma64Cmd_Status_Q1_GET_VQM_JStatus(mpm_adma64cmd_status_q1) \
      ((mpm_adma64cmd_status_q1 & mpM_Adma64Cmd_Status_Q1_VQM_JStatus_MASK) >> mpM_Adma64Cmd_Status_Q1_VQM_JStatus_SHIFT)
#define mpM_Adma64Cmd_Status_Q1_GET_VQM_ErrorSource(mpm_adma64cmd_status_q1) \
      ((mpm_adma64cmd_status_q1 & mpM_Adma64Cmd_Status_Q1_VQM_ErrorSource_MASK) >> mpM_Adma64Cmd_Status_Q1_VQM_ErrorSource_SHIFT)

#define mpM_Adma64Cmd_Status_Q1_SET_VQM_Error(mpm_adma64cmd_status_q1_reg, vqm_error) \
      mpm_adma64cmd_status_q1_reg = (mpm_adma64cmd_status_q1_reg & ~mpM_Adma64Cmd_Status_Q1_VQM_Error_MASK) | (vqm_error << mpM_Adma64Cmd_Status_Q1_VQM_Error_SHIFT)
#define mpM_Adma64Cmd_Status_Q1_SET_VQM_ErrorPrevious(mpm_adma64cmd_status_q1_reg, vqm_errorprevious) \
      mpm_adma64cmd_status_q1_reg = (mpm_adma64cmd_status_q1_reg & ~mpM_Adma64Cmd_Status_Q1_VQM_ErrorPrevious_MASK) | (vqm_errorprevious << mpM_Adma64Cmd_Status_Q1_VQM_ErrorPrevious_SHIFT)
#define mpM_Adma64Cmd_Status_Q1_SET_VQM_JStatus(mpm_adma64cmd_status_q1_reg, vqm_jstatus) \
      mpm_adma64cmd_status_q1_reg = (mpm_adma64cmd_status_q1_reg & ~mpM_Adma64Cmd_Status_Q1_VQM_JStatus_MASK) | (vqm_jstatus << mpM_Adma64Cmd_Status_Q1_VQM_JStatus_SHIFT)
#define mpM_Adma64Cmd_Status_Q1_SET_VQM_ErrorSource(mpm_adma64cmd_status_q1_reg, vqm_errorsource) \
      mpm_adma64cmd_status_q1_reg = (mpm_adma64cmd_status_q1_reg & ~mpM_Adma64Cmd_Status_Q1_VQM_ErrorSource_MASK) | (vqm_errorsource << mpM_Adma64Cmd_Status_Q1_VQM_ErrorSource_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_status_q1_t {
            unsigned int vqm_error                      : mpM_Adma64Cmd_Status_Q1_VQM_Error_SIZE;
            unsigned int vqm_errorprevious              : mpM_Adma64Cmd_Status_Q1_VQM_ErrorPrevious_SIZE;
            unsigned int vqm_jstatus                    : mpM_Adma64Cmd_Status_Q1_VQM_JStatus_SIZE;
            unsigned int vqm_errorsource                : mpM_Adma64Cmd_Status_Q1_VQM_ErrorSource_SIZE;
            unsigned int                                : 19;
      } mpm_adma64cmd_status_q1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_status_q1_t {
            unsigned int                                : 19;
            unsigned int vqm_errorsource                : mpM_Adma64Cmd_Status_Q1_VQM_ErrorSource_SIZE;
            unsigned int vqm_jstatus                    : mpM_Adma64Cmd_Status_Q1_VQM_JStatus_SIZE;
            unsigned int vqm_errorprevious              : mpM_Adma64Cmd_Status_Q1_VQM_ErrorPrevious_SIZE;
            unsigned int vqm_error                      : mpM_Adma64Cmd_Status_Q1_VQM_Error_SIZE;
      } mpm_adma64cmd_status_q1_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_status_q1_t f;
} mpm_adma64cmd_status_q1_u;


/*
 * mpM_Adma64Cmd_Int_Status_Q1 struct
 */

#define mpM_Adma64Cmd_Int_Status_Q1_REG_SIZE         32
#define mpM_Adma64Cmd_Int_Status_Q1_IC_EventCnt_SIZE  7

#define mpM_Adma64Cmd_Int_Status_Q1_IC_EventCnt_SHIFT  0

#define mpM_Adma64Cmd_Int_Status_Q1_IC_EventCnt_MASK  0x0000007f

#define mpM_Adma64Cmd_Int_Status_Q1_MASK \
      (mpM_Adma64Cmd_Int_Status_Q1_IC_EventCnt_MASK)

#define mpM_Adma64Cmd_Int_Status_Q1_DEFAULT 0x00000000

#define mpM_Adma64Cmd_Int_Status_Q1_GET_IC_EventCnt(mpm_adma64cmd_int_status_q1) \
      ((mpm_adma64cmd_int_status_q1 & mpM_Adma64Cmd_Int_Status_Q1_IC_EventCnt_MASK) >> mpM_Adma64Cmd_Int_Status_Q1_IC_EventCnt_SHIFT)

#define mpM_Adma64Cmd_Int_Status_Q1_SET_IC_EventCnt(mpm_adma64cmd_int_status_q1_reg, ic_eventcnt) \
      mpm_adma64cmd_int_status_q1_reg = (mpm_adma64cmd_int_status_q1_reg & ~mpM_Adma64Cmd_Int_Status_Q1_IC_EventCnt_MASK) | (ic_eventcnt << mpM_Adma64Cmd_Int_Status_Q1_IC_EventCnt_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_int_status_q1_t {
            unsigned int ic_eventcnt                    : mpM_Adma64Cmd_Int_Status_Q1_IC_EventCnt_SIZE;
            unsigned int                                : 25;
      } mpm_adma64cmd_int_status_q1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_int_status_q1_t {
            unsigned int                                : 25;
            unsigned int ic_eventcnt                    : mpM_Adma64Cmd_Int_Status_Q1_IC_EventCnt_SIZE;
      } mpm_adma64cmd_int_status_q1_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_int_status_q1_t f;
} mpm_adma64cmd_int_status_q1_u;


/*
 * mpM_Adma64Cmd_DMA_Status_Q1 struct
 */

#define mpM_Adma64Cmd_DMA_Status_Q1_REG_SIZE         32
#define mpM_Adma64Cmd_DMA_Status_Q1_DMA_Pwrites_SIZE  10
#define mpM_Adma64Cmd_DMA_Status_Q1_DMA_Preads_SIZE  6
#define mpM_Adma64Cmd_DMA_Status_Q1_DMA_Dstatus_SIZE  3

#define mpM_Adma64Cmd_DMA_Status_Q1_DMA_Pwrites_SHIFT  0
#define mpM_Adma64Cmd_DMA_Status_Q1_DMA_Preads_SHIFT  10
#define mpM_Adma64Cmd_DMA_Status_Q1_DMA_Dstatus_SHIFT  16

#define mpM_Adma64Cmd_DMA_Status_Q1_DMA_Pwrites_MASK  0x000003ff
#define mpM_Adma64Cmd_DMA_Status_Q1_DMA_Preads_MASK  0x0000fc00
#define mpM_Adma64Cmd_DMA_Status_Q1_DMA_Dstatus_MASK  0x00070000

#define mpM_Adma64Cmd_DMA_Status_Q1_MASK \
      (mpM_Adma64Cmd_DMA_Status_Q1_DMA_Pwrites_MASK | \
      mpM_Adma64Cmd_DMA_Status_Q1_DMA_Preads_MASK | \
      mpM_Adma64Cmd_DMA_Status_Q1_DMA_Dstatus_MASK)

#define mpM_Adma64Cmd_DMA_Status_Q1_DEFAULT 0x00000000

#define mpM_Adma64Cmd_DMA_Status_Q1_GET_DMA_Pwrites(mpm_adma64cmd_dma_status_q1) \
      ((mpm_adma64cmd_dma_status_q1 & mpM_Adma64Cmd_DMA_Status_Q1_DMA_Pwrites_MASK) >> mpM_Adma64Cmd_DMA_Status_Q1_DMA_Pwrites_SHIFT)
#define mpM_Adma64Cmd_DMA_Status_Q1_GET_DMA_Preads(mpm_adma64cmd_dma_status_q1) \
      ((mpm_adma64cmd_dma_status_q1 & mpM_Adma64Cmd_DMA_Status_Q1_DMA_Preads_MASK) >> mpM_Adma64Cmd_DMA_Status_Q1_DMA_Preads_SHIFT)
#define mpM_Adma64Cmd_DMA_Status_Q1_GET_DMA_Dstatus(mpm_adma64cmd_dma_status_q1) \
      ((mpm_adma64cmd_dma_status_q1 & mpM_Adma64Cmd_DMA_Status_Q1_DMA_Dstatus_MASK) >> mpM_Adma64Cmd_DMA_Status_Q1_DMA_Dstatus_SHIFT)

#define mpM_Adma64Cmd_DMA_Status_Q1_SET_DMA_Pwrites(mpm_adma64cmd_dma_status_q1_reg, dma_pwrites) \
      mpm_adma64cmd_dma_status_q1_reg = (mpm_adma64cmd_dma_status_q1_reg & ~mpM_Adma64Cmd_DMA_Status_Q1_DMA_Pwrites_MASK) | (dma_pwrites << mpM_Adma64Cmd_DMA_Status_Q1_DMA_Pwrites_SHIFT)
#define mpM_Adma64Cmd_DMA_Status_Q1_SET_DMA_Preads(mpm_adma64cmd_dma_status_q1_reg, dma_preads) \
      mpm_adma64cmd_dma_status_q1_reg = (mpm_adma64cmd_dma_status_q1_reg & ~mpM_Adma64Cmd_DMA_Status_Q1_DMA_Preads_MASK) | (dma_preads << mpM_Adma64Cmd_DMA_Status_Q1_DMA_Preads_SHIFT)
#define mpM_Adma64Cmd_DMA_Status_Q1_SET_DMA_Dstatus(mpm_adma64cmd_dma_status_q1_reg, dma_dstatus) \
      mpm_adma64cmd_dma_status_q1_reg = (mpm_adma64cmd_dma_status_q1_reg & ~mpM_Adma64Cmd_DMA_Status_Q1_DMA_Dstatus_MASK) | (dma_dstatus << mpM_Adma64Cmd_DMA_Status_Q1_DMA_Dstatus_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_dma_status_q1_t {
            unsigned int dma_pwrites                    : mpM_Adma64Cmd_DMA_Status_Q1_DMA_Pwrites_SIZE;
            unsigned int dma_preads                     : mpM_Adma64Cmd_DMA_Status_Q1_DMA_Preads_SIZE;
            unsigned int dma_dstatus                    : mpM_Adma64Cmd_DMA_Status_Q1_DMA_Dstatus_SIZE;
            unsigned int                                : 13;
      } mpm_adma64cmd_dma_status_q1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_dma_status_q1_t {
            unsigned int                                : 13;
            unsigned int dma_dstatus                    : mpM_Adma64Cmd_DMA_Status_Q1_DMA_Dstatus_SIZE;
            unsigned int dma_preads                     : mpM_Adma64Cmd_DMA_Status_Q1_DMA_Preads_SIZE;
            unsigned int dma_pwrites                    : mpM_Adma64Cmd_DMA_Status_Q1_DMA_Pwrites_SIZE;
      } mpm_adma64cmd_dma_status_q1_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_dma_status_q1_t f;
} mpm_adma64cmd_dma_status_q1_u;


/*
 * mpM_Adma64Cmd_DMA_Read_Status_Q1 struct
 */

#define mpM_Adma64Cmd_DMA_Read_Status_Q1_REG_SIZE         32
#define mpM_Adma64Cmd_DMA_Read_Status_Q1_DMA_BytesRead_SIZE  32

#define mpM_Adma64Cmd_DMA_Read_Status_Q1_DMA_BytesRead_SHIFT  0

#define mpM_Adma64Cmd_DMA_Read_Status_Q1_DMA_BytesRead_MASK  0xffffffff

#define mpM_Adma64Cmd_DMA_Read_Status_Q1_MASK \
      (mpM_Adma64Cmd_DMA_Read_Status_Q1_DMA_BytesRead_MASK)

#define mpM_Adma64Cmd_DMA_Read_Status_Q1_DEFAULT 0x00000000

#define mpM_Adma64Cmd_DMA_Read_Status_Q1_GET_DMA_BytesRead(mpm_adma64cmd_dma_read_status_q1) \
      ((mpm_adma64cmd_dma_read_status_q1 & mpM_Adma64Cmd_DMA_Read_Status_Q1_DMA_BytesRead_MASK) >> mpM_Adma64Cmd_DMA_Read_Status_Q1_DMA_BytesRead_SHIFT)

#define mpM_Adma64Cmd_DMA_Read_Status_Q1_SET_DMA_BytesRead(mpm_adma64cmd_dma_read_status_q1_reg, dma_bytesread) \
      mpm_adma64cmd_dma_read_status_q1_reg = (mpm_adma64cmd_dma_read_status_q1_reg & ~mpM_Adma64Cmd_DMA_Read_Status_Q1_DMA_BytesRead_MASK) | (dma_bytesread << mpM_Adma64Cmd_DMA_Read_Status_Q1_DMA_BytesRead_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_dma_read_status_q1_t {
            unsigned int dma_bytesread                  : mpM_Adma64Cmd_DMA_Read_Status_Q1_DMA_BytesRead_SIZE;
      } mpm_adma64cmd_dma_read_status_q1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_dma_read_status_q1_t {
            unsigned int dma_bytesread                  : mpM_Adma64Cmd_DMA_Read_Status_Q1_DMA_BytesRead_SIZE;
      } mpm_adma64cmd_dma_read_status_q1_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_dma_read_status_q1_t f;
} mpm_adma64cmd_dma_read_status_q1_u;


/*
 * mpM_Adma64Cmd_DMA_Write_Status_Q1 struct
 */

#define mpM_Adma64Cmd_DMA_Write_Status_Q1_REG_SIZE         32
#define mpM_Adma64Cmd_DMA_Write_Status_Q1_DMA_BytesWritten_SIZE  32

#define mpM_Adma64Cmd_DMA_Write_Status_Q1_DMA_BytesWritten_SHIFT  0

#define mpM_Adma64Cmd_DMA_Write_Status_Q1_DMA_BytesWritten_MASK  0xffffffff

#define mpM_Adma64Cmd_DMA_Write_Status_Q1_MASK \
      (mpM_Adma64Cmd_DMA_Write_Status_Q1_DMA_BytesWritten_MASK)

#define mpM_Adma64Cmd_DMA_Write_Status_Q1_DEFAULT 0x00000000

#define mpM_Adma64Cmd_DMA_Write_Status_Q1_GET_DMA_BytesWritten(mpm_adma64cmd_dma_write_status_q1) \
      ((mpm_adma64cmd_dma_write_status_q1 & mpM_Adma64Cmd_DMA_Write_Status_Q1_DMA_BytesWritten_MASK) >> mpM_Adma64Cmd_DMA_Write_Status_Q1_DMA_BytesWritten_SHIFT)

#define mpM_Adma64Cmd_DMA_Write_Status_Q1_SET_DMA_BytesWritten(mpm_adma64cmd_dma_write_status_q1_reg, dma_byteswritten) \
      mpm_adma64cmd_dma_write_status_q1_reg = (mpm_adma64cmd_dma_write_status_q1_reg & ~mpM_Adma64Cmd_DMA_Write_Status_Q1_DMA_BytesWritten_MASK) | (dma_byteswritten << mpM_Adma64Cmd_DMA_Write_Status_Q1_DMA_BytesWritten_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_dma_write_status_q1_t {
            unsigned int dma_byteswritten               : mpM_Adma64Cmd_DMA_Write_Status_Q1_DMA_BytesWritten_SIZE;
      } mpm_adma64cmd_dma_write_status_q1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_dma_write_status_q1_t {
            unsigned int dma_byteswritten               : mpM_Adma64Cmd_DMA_Write_Status_Q1_DMA_BytesWritten_SIZE;
      } mpm_adma64cmd_dma_write_status_q1_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_dma_write_status_q1_t f;
} mpm_adma64cmd_dma_write_status_q1_u;


/*
 * mpM_Adma64Cmd_Abort_Q1 struct
 */

#define mpM_Adma64Cmd_Abort_Q1_REG_SIZE         32
#define mpM_Adma64Cmd_Abort_Q1_RI_Offset_SIZE  18
#define mpM_Adma64Cmd_Abort_Q1_RI_Offset_Valid_SIZE  1

#define mpM_Adma64Cmd_Abort_Q1_RI_Offset_SHIFT  0
#define mpM_Adma64Cmd_Abort_Q1_RI_Offset_Valid_SHIFT  31

#define mpM_Adma64Cmd_Abort_Q1_RI_Offset_MASK  0x0003ffff
#define mpM_Adma64Cmd_Abort_Q1_RI_Offset_Valid_MASK  0x80000000

#define mpM_Adma64Cmd_Abort_Q1_MASK \
      (mpM_Adma64Cmd_Abort_Q1_RI_Offset_MASK | \
      mpM_Adma64Cmd_Abort_Q1_RI_Offset_Valid_MASK)

#define mpM_Adma64Cmd_Abort_Q1_DEFAULT 0x00000000

#define mpM_Adma64Cmd_Abort_Q1_GET_RI_Offset(mpm_adma64cmd_abort_q1) \
      ((mpm_adma64cmd_abort_q1 & mpM_Adma64Cmd_Abort_Q1_RI_Offset_MASK) >> mpM_Adma64Cmd_Abort_Q1_RI_Offset_SHIFT)
#define mpM_Adma64Cmd_Abort_Q1_GET_RI_Offset_Valid(mpm_adma64cmd_abort_q1) \
      ((mpm_adma64cmd_abort_q1 & mpM_Adma64Cmd_Abort_Q1_RI_Offset_Valid_MASK) >> mpM_Adma64Cmd_Abort_Q1_RI_Offset_Valid_SHIFT)

#define mpM_Adma64Cmd_Abort_Q1_SET_RI_Offset(mpm_adma64cmd_abort_q1_reg, ri_offset) \
      mpm_adma64cmd_abort_q1_reg = (mpm_adma64cmd_abort_q1_reg & ~mpM_Adma64Cmd_Abort_Q1_RI_Offset_MASK) | (ri_offset << mpM_Adma64Cmd_Abort_Q1_RI_Offset_SHIFT)
#define mpM_Adma64Cmd_Abort_Q1_SET_RI_Offset_Valid(mpm_adma64cmd_abort_q1_reg, ri_offset_valid) \
      mpm_adma64cmd_abort_q1_reg = (mpm_adma64cmd_abort_q1_reg & ~mpM_Adma64Cmd_Abort_Q1_RI_Offset_Valid_MASK) | (ri_offset_valid << mpM_Adma64Cmd_Abort_Q1_RI_Offset_Valid_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_abort_q1_t {
            unsigned int ri_offset                      : mpM_Adma64Cmd_Abort_Q1_RI_Offset_SIZE;
            unsigned int                                : 13;
            unsigned int ri_offset_valid                : mpM_Adma64Cmd_Abort_Q1_RI_Offset_Valid_SIZE;
      } mpm_adma64cmd_abort_q1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_abort_q1_t {
            unsigned int ri_offset_valid                : mpM_Adma64Cmd_Abort_Q1_RI_Offset_Valid_SIZE;
            unsigned int                                : 13;
            unsigned int ri_offset                      : mpM_Adma64Cmd_Abort_Q1_RI_Offset_SIZE;
      } mpm_adma64cmd_abort_q1_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_abort_q1_t f;
} mpm_adma64cmd_abort_q1_u;


/*
 * mpM_Adma64Cmd_AxCACHE_Q1 struct
 */

#define mpM_Adma64Cmd_AxCACHE_Q1_REG_SIZE         32
#define mpM_Adma64Cmd_AxCACHE_Q1_RI_AWCACHE_SIZE  4
#define mpM_Adma64Cmd_AxCACHE_Q1_RI_ARCACHE_SIZE  4
#define mpM_Adma64Cmd_AxCACHE_Q1_RI_VCD_ARCACHE_SIZE  4

#define mpM_Adma64Cmd_AxCACHE_Q1_RI_AWCACHE_SHIFT  0
#define mpM_Adma64Cmd_AxCACHE_Q1_RI_ARCACHE_SHIFT  4
#define mpM_Adma64Cmd_AxCACHE_Q1_RI_VCD_ARCACHE_SHIFT  8

#define mpM_Adma64Cmd_AxCACHE_Q1_RI_AWCACHE_MASK  0x0000000f
#define mpM_Adma64Cmd_AxCACHE_Q1_RI_ARCACHE_MASK  0x000000f0
#define mpM_Adma64Cmd_AxCACHE_Q1_RI_VCD_ARCACHE_MASK  0x00000f00

#define mpM_Adma64Cmd_AxCACHE_Q1_MASK \
      (mpM_Adma64Cmd_AxCACHE_Q1_RI_AWCACHE_MASK | \
      mpM_Adma64Cmd_AxCACHE_Q1_RI_ARCACHE_MASK | \
      mpM_Adma64Cmd_AxCACHE_Q1_RI_VCD_ARCACHE_MASK)

#define mpM_Adma64Cmd_AxCACHE_Q1_DEFAULT 0x00000000

#define mpM_Adma64Cmd_AxCACHE_Q1_GET_RI_AWCACHE(mpm_adma64cmd_axcache_q1) \
      ((mpm_adma64cmd_axcache_q1 & mpM_Adma64Cmd_AxCACHE_Q1_RI_AWCACHE_MASK) >> mpM_Adma64Cmd_AxCACHE_Q1_RI_AWCACHE_SHIFT)
#define mpM_Adma64Cmd_AxCACHE_Q1_GET_RI_ARCACHE(mpm_adma64cmd_axcache_q1) \
      ((mpm_adma64cmd_axcache_q1 & mpM_Adma64Cmd_AxCACHE_Q1_RI_ARCACHE_MASK) >> mpM_Adma64Cmd_AxCACHE_Q1_RI_ARCACHE_SHIFT)
#define mpM_Adma64Cmd_AxCACHE_Q1_GET_RI_VCD_ARCACHE(mpm_adma64cmd_axcache_q1) \
      ((mpm_adma64cmd_axcache_q1 & mpM_Adma64Cmd_AxCACHE_Q1_RI_VCD_ARCACHE_MASK) >> mpM_Adma64Cmd_AxCACHE_Q1_RI_VCD_ARCACHE_SHIFT)

#define mpM_Adma64Cmd_AxCACHE_Q1_SET_RI_AWCACHE(mpm_adma64cmd_axcache_q1_reg, ri_awcache) \
      mpm_adma64cmd_axcache_q1_reg = (mpm_adma64cmd_axcache_q1_reg & ~mpM_Adma64Cmd_AxCACHE_Q1_RI_AWCACHE_MASK) | (ri_awcache << mpM_Adma64Cmd_AxCACHE_Q1_RI_AWCACHE_SHIFT)
#define mpM_Adma64Cmd_AxCACHE_Q1_SET_RI_ARCACHE(mpm_adma64cmd_axcache_q1_reg, ri_arcache) \
      mpm_adma64cmd_axcache_q1_reg = (mpm_adma64cmd_axcache_q1_reg & ~mpM_Adma64Cmd_AxCACHE_Q1_RI_ARCACHE_MASK) | (ri_arcache << mpM_Adma64Cmd_AxCACHE_Q1_RI_ARCACHE_SHIFT)
#define mpM_Adma64Cmd_AxCACHE_Q1_SET_RI_VCD_ARCACHE(mpm_adma64cmd_axcache_q1_reg, ri_vcd_arcache) \
      mpm_adma64cmd_axcache_q1_reg = (mpm_adma64cmd_axcache_q1_reg & ~mpM_Adma64Cmd_AxCACHE_Q1_RI_VCD_ARCACHE_MASK) | (ri_vcd_arcache << mpM_Adma64Cmd_AxCACHE_Q1_RI_VCD_ARCACHE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_axcache_q1_t {
            unsigned int ri_awcache                     : mpM_Adma64Cmd_AxCACHE_Q1_RI_AWCACHE_SIZE;
            unsigned int ri_arcache                     : mpM_Adma64Cmd_AxCACHE_Q1_RI_ARCACHE_SIZE;
            unsigned int ri_vcd_arcache                 : mpM_Adma64Cmd_AxCACHE_Q1_RI_VCD_ARCACHE_SIZE;
            unsigned int                                : 20;
      } mpm_adma64cmd_axcache_q1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_axcache_q1_t {
            unsigned int                                : 20;
            unsigned int ri_vcd_arcache                 : mpM_Adma64Cmd_AxCACHE_Q1_RI_VCD_ARCACHE_SIZE;
            unsigned int ri_arcache                     : mpM_Adma64Cmd_AxCACHE_Q1_RI_ARCACHE_SIZE;
            unsigned int ri_awcache                     : mpM_Adma64Cmd_AxCACHE_Q1_RI_AWCACHE_SIZE;
      } mpm_adma64cmd_axcache_q1_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_axcache_q1_t f;
} mpm_adma64cmd_axcache_q1_u;


/*
 * mpM_Adma64Vqd2_Control struct
 */

#define mpM_Adma64Vqd2_Control_REG_SIZE         32
#define mpM_Adma64Vqd2_Control_RI_Run_SIZE  1
#define mpM_Adma64Vqd2_Control_VQM_Halted_SIZE  1
#define mpM_Adma64Vqd2_Control_RI_Mem_Location_SIZE  1
#define mpM_Adma64Vqd2_Control_RI_Queue_Size_SIZE  4
#define mpM_Adma64Vqd2_Control_RI_COMP_DESC_SIZE  1
#define mpM_Adma64Vqd2_Control_RI_VQD_Pointer_Hi_SIZE  16

#define mpM_Adma64Vqd2_Control_RI_Run_SHIFT  0
#define mpM_Adma64Vqd2_Control_VQM_Halted_SHIFT  1
#define mpM_Adma64Vqd2_Control_RI_Mem_Location_SHIFT  2
#define mpM_Adma64Vqd2_Control_RI_Queue_Size_SHIFT  3
#define mpM_Adma64Vqd2_Control_RI_COMP_DESC_SHIFT  7
#define mpM_Adma64Vqd2_Control_RI_VQD_Pointer_Hi_SHIFT  16

#define mpM_Adma64Vqd2_Control_RI_Run_MASK  0x00000001
#define mpM_Adma64Vqd2_Control_VQM_Halted_MASK  0x00000002
#define mpM_Adma64Vqd2_Control_RI_Mem_Location_MASK  0x00000004
#define mpM_Adma64Vqd2_Control_RI_Queue_Size_MASK  0x00000078
#define mpM_Adma64Vqd2_Control_RI_COMP_DESC_MASK  0x00000080
#define mpM_Adma64Vqd2_Control_RI_VQD_Pointer_Hi_MASK  0xffff0000

#define mpM_Adma64Vqd2_Control_MASK \
      (mpM_Adma64Vqd2_Control_RI_Run_MASK | \
      mpM_Adma64Vqd2_Control_VQM_Halted_MASK | \
      mpM_Adma64Vqd2_Control_RI_Mem_Location_MASK | \
      mpM_Adma64Vqd2_Control_RI_Queue_Size_MASK | \
      mpM_Adma64Vqd2_Control_RI_COMP_DESC_MASK | \
      mpM_Adma64Vqd2_Control_RI_VQD_Pointer_Hi_MASK)

#define mpM_Adma64Vqd2_Control_DEFAULT 0x00000002

#define mpM_Adma64Vqd2_Control_GET_RI_Run(mpm_adma64vqd2_control) \
      ((mpm_adma64vqd2_control & mpM_Adma64Vqd2_Control_RI_Run_MASK) >> mpM_Adma64Vqd2_Control_RI_Run_SHIFT)
#define mpM_Adma64Vqd2_Control_GET_VQM_Halted(mpm_adma64vqd2_control) \
      ((mpm_adma64vqd2_control & mpM_Adma64Vqd2_Control_VQM_Halted_MASK) >> mpM_Adma64Vqd2_Control_VQM_Halted_SHIFT)
#define mpM_Adma64Vqd2_Control_GET_RI_Mem_Location(mpm_adma64vqd2_control) \
      ((mpm_adma64vqd2_control & mpM_Adma64Vqd2_Control_RI_Mem_Location_MASK) >> mpM_Adma64Vqd2_Control_RI_Mem_Location_SHIFT)
#define mpM_Adma64Vqd2_Control_GET_RI_Queue_Size(mpm_adma64vqd2_control) \
      ((mpm_adma64vqd2_control & mpM_Adma64Vqd2_Control_RI_Queue_Size_MASK) >> mpM_Adma64Vqd2_Control_RI_Queue_Size_SHIFT)
#define mpM_Adma64Vqd2_Control_GET_RI_COMP_DESC(mpm_adma64vqd2_control) \
      ((mpm_adma64vqd2_control & mpM_Adma64Vqd2_Control_RI_COMP_DESC_MASK) >> mpM_Adma64Vqd2_Control_RI_COMP_DESC_SHIFT)
#define mpM_Adma64Vqd2_Control_GET_RI_VQD_Pointer_Hi(mpm_adma64vqd2_control) \
      ((mpm_adma64vqd2_control & mpM_Adma64Vqd2_Control_RI_VQD_Pointer_Hi_MASK) >> mpM_Adma64Vqd2_Control_RI_VQD_Pointer_Hi_SHIFT)

#define mpM_Adma64Vqd2_Control_SET_RI_Run(mpm_adma64vqd2_control_reg, ri_run) \
      mpm_adma64vqd2_control_reg = (mpm_adma64vqd2_control_reg & ~mpM_Adma64Vqd2_Control_RI_Run_MASK) | (ri_run << mpM_Adma64Vqd2_Control_RI_Run_SHIFT)
#define mpM_Adma64Vqd2_Control_SET_VQM_Halted(mpm_adma64vqd2_control_reg, vqm_halted) \
      mpm_adma64vqd2_control_reg = (mpm_adma64vqd2_control_reg & ~mpM_Adma64Vqd2_Control_VQM_Halted_MASK) | (vqm_halted << mpM_Adma64Vqd2_Control_VQM_Halted_SHIFT)
#define mpM_Adma64Vqd2_Control_SET_RI_Mem_Location(mpm_adma64vqd2_control_reg, ri_mem_location) \
      mpm_adma64vqd2_control_reg = (mpm_adma64vqd2_control_reg & ~mpM_Adma64Vqd2_Control_RI_Mem_Location_MASK) | (ri_mem_location << mpM_Adma64Vqd2_Control_RI_Mem_Location_SHIFT)
#define mpM_Adma64Vqd2_Control_SET_RI_Queue_Size(mpm_adma64vqd2_control_reg, ri_queue_size) \
      mpm_adma64vqd2_control_reg = (mpm_adma64vqd2_control_reg & ~mpM_Adma64Vqd2_Control_RI_Queue_Size_MASK) | (ri_queue_size << mpM_Adma64Vqd2_Control_RI_Queue_Size_SHIFT)
#define mpM_Adma64Vqd2_Control_SET_RI_COMP_DESC(mpm_adma64vqd2_control_reg, ri_comp_desc) \
      mpm_adma64vqd2_control_reg = (mpm_adma64vqd2_control_reg & ~mpM_Adma64Vqd2_Control_RI_COMP_DESC_MASK) | (ri_comp_desc << mpM_Adma64Vqd2_Control_RI_COMP_DESC_SHIFT)
#define mpM_Adma64Vqd2_Control_SET_RI_VQD_Pointer_Hi(mpm_adma64vqd2_control_reg, ri_vqd_pointer_hi) \
      mpm_adma64vqd2_control_reg = (mpm_adma64vqd2_control_reg & ~mpM_Adma64Vqd2_Control_RI_VQD_Pointer_Hi_MASK) | (ri_vqd_pointer_hi << mpM_Adma64Vqd2_Control_RI_VQD_Pointer_Hi_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64vqd2_control_t {
            unsigned int ri_run                         : mpM_Adma64Vqd2_Control_RI_Run_SIZE;
            unsigned int vqm_halted                     : mpM_Adma64Vqd2_Control_VQM_Halted_SIZE;
            unsigned int ri_mem_location                : mpM_Adma64Vqd2_Control_RI_Mem_Location_SIZE;
            unsigned int ri_queue_size                  : mpM_Adma64Vqd2_Control_RI_Queue_Size_SIZE;
            unsigned int ri_comp_desc                   : mpM_Adma64Vqd2_Control_RI_COMP_DESC_SIZE;
            unsigned int                                : 8;
            unsigned int ri_vqd_pointer_hi              : mpM_Adma64Vqd2_Control_RI_VQD_Pointer_Hi_SIZE;
      } mpm_adma64vqd2_control_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64vqd2_control_t {
            unsigned int ri_vqd_pointer_hi              : mpM_Adma64Vqd2_Control_RI_VQD_Pointer_Hi_SIZE;
            unsigned int                                : 8;
            unsigned int ri_comp_desc                   : mpM_Adma64Vqd2_Control_RI_COMP_DESC_SIZE;
            unsigned int ri_queue_size                  : mpM_Adma64Vqd2_Control_RI_Queue_Size_SIZE;
            unsigned int ri_mem_location                : mpM_Adma64Vqd2_Control_RI_Mem_Location_SIZE;
            unsigned int vqm_halted                     : mpM_Adma64Vqd2_Control_VQM_Halted_SIZE;
            unsigned int ri_run                         : mpM_Adma64Vqd2_Control_RI_Run_SIZE;
      } mpm_adma64vqd2_control_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64vqd2_control_t f;
} mpm_adma64vqd2_control_u;


/*
 * mpM_Adma64Vqd2_Tail_Lo struct
 */

#define mpM_Adma64Vqd2_Tail_Lo_REG_SIZE         32
#define mpM_Adma64Vqd2_Tail_Lo_RI_Tail_Pointer_Lo_SIZE  32

#define mpM_Adma64Vqd2_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT  0

#define mpM_Adma64Vqd2_Tail_Lo_RI_Tail_Pointer_Lo_MASK  0xffffffff

#define mpM_Adma64Vqd2_Tail_Lo_MASK \
      (mpM_Adma64Vqd2_Tail_Lo_RI_Tail_Pointer_Lo_MASK)

#define mpM_Adma64Vqd2_Tail_Lo_DEFAULT 0x00000000

#define mpM_Adma64Vqd2_Tail_Lo_GET_RI_Tail_Pointer_Lo(mpm_adma64vqd2_tail_lo) \
      ((mpm_adma64vqd2_tail_lo & mpM_Adma64Vqd2_Tail_Lo_RI_Tail_Pointer_Lo_MASK) >> mpM_Adma64Vqd2_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT)

#define mpM_Adma64Vqd2_Tail_Lo_SET_RI_Tail_Pointer_Lo(mpm_adma64vqd2_tail_lo_reg, ri_tail_pointer_lo) \
      mpm_adma64vqd2_tail_lo_reg = (mpm_adma64vqd2_tail_lo_reg & ~mpM_Adma64Vqd2_Tail_Lo_RI_Tail_Pointer_Lo_MASK) | (ri_tail_pointer_lo << mpM_Adma64Vqd2_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64vqd2_tail_lo_t {
            unsigned int ri_tail_pointer_lo             : mpM_Adma64Vqd2_Tail_Lo_RI_Tail_Pointer_Lo_SIZE;
      } mpm_adma64vqd2_tail_lo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64vqd2_tail_lo_t {
            unsigned int ri_tail_pointer_lo             : mpM_Adma64Vqd2_Tail_Lo_RI_Tail_Pointer_Lo_SIZE;
      } mpm_adma64vqd2_tail_lo_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64vqd2_tail_lo_t f;
} mpm_adma64vqd2_tail_lo_u;


/*
 * mpM_Adma64Vqd2_Head_Lo struct
 */

#define mpM_Adma64Vqd2_Head_Lo_REG_SIZE         32
#define mpM_Adma64Vqd2_Head_Lo_RI_Head_Pointer_Lo_SIZE  32

#define mpM_Adma64Vqd2_Head_Lo_RI_Head_Pointer_Lo_SHIFT  0

#define mpM_Adma64Vqd2_Head_Lo_RI_Head_Pointer_Lo_MASK  0xffffffff

#define mpM_Adma64Vqd2_Head_Lo_MASK \
      (mpM_Adma64Vqd2_Head_Lo_RI_Head_Pointer_Lo_MASK)

#define mpM_Adma64Vqd2_Head_Lo_DEFAULT 0x00000000

#define mpM_Adma64Vqd2_Head_Lo_GET_RI_Head_Pointer_Lo(mpm_adma64vqd2_head_lo) \
      ((mpm_adma64vqd2_head_lo & mpM_Adma64Vqd2_Head_Lo_RI_Head_Pointer_Lo_MASK) >> mpM_Adma64Vqd2_Head_Lo_RI_Head_Pointer_Lo_SHIFT)

#define mpM_Adma64Vqd2_Head_Lo_SET_RI_Head_Pointer_Lo(mpm_adma64vqd2_head_lo_reg, ri_head_pointer_lo) \
      mpm_adma64vqd2_head_lo_reg = (mpm_adma64vqd2_head_lo_reg & ~mpM_Adma64Vqd2_Head_Lo_RI_Head_Pointer_Lo_MASK) | (ri_head_pointer_lo << mpM_Adma64Vqd2_Head_Lo_RI_Head_Pointer_Lo_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64vqd2_head_lo_t {
            unsigned int ri_head_pointer_lo             : mpM_Adma64Vqd2_Head_Lo_RI_Head_Pointer_Lo_SIZE;
      } mpm_adma64vqd2_head_lo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64vqd2_head_lo_t {
            unsigned int ri_head_pointer_lo             : mpM_Adma64Vqd2_Head_Lo_RI_Head_Pointer_Lo_SIZE;
      } mpm_adma64vqd2_head_lo_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64vqd2_head_lo_t f;
} mpm_adma64vqd2_head_lo_u;


/*
 * mpM_Adma64Cmd_Interrupt_Enable_Q2 struct
 */

#define mpM_Adma64Cmd_Interrupt_Enable_Q2_REG_SIZE         32
#define mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_CompInt_Enable_SIZE  1
#define mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_SIZE  1
#define mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_QSI_Enable_SIZE  1
#define mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_QEI_Enable_SIZE  1

#define mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_CompInt_Enable_SHIFT  0
#define mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_SHIFT  1
#define mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_QSI_Enable_SHIFT  2
#define mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_QEI_Enable_SHIFT  3

#define mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_CompInt_Enable_MASK  0x00000001
#define mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_MASK  0x00000002
#define mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_QSI_Enable_MASK  0x00000004
#define mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_QEI_Enable_MASK  0x00000008

#define mpM_Adma64Cmd_Interrupt_Enable_Q2_MASK \
      (mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_CompInt_Enable_MASK | \
      mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_MASK | \
      mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_QSI_Enable_MASK | \
      mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_QEI_Enable_MASK)

#define mpM_Adma64Cmd_Interrupt_Enable_Q2_DEFAULT 0x00000000

#define mpM_Adma64Cmd_Interrupt_Enable_Q2_GET_RI_CompInt_Enable(mpm_adma64cmd_interrupt_enable_q2) \
      ((mpm_adma64cmd_interrupt_enable_q2 & mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_CompInt_Enable_MASK) >> mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_CompInt_Enable_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Enable_Q2_GET_RI_ErrInt_Enable(mpm_adma64cmd_interrupt_enable_q2) \
      ((mpm_adma64cmd_interrupt_enable_q2 & mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_MASK) >> mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Enable_Q2_GET_RI_QSI_Enable(mpm_adma64cmd_interrupt_enable_q2) \
      ((mpm_adma64cmd_interrupt_enable_q2 & mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_QSI_Enable_MASK) >> mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_QSI_Enable_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Enable_Q2_GET_RI_QEI_Enable(mpm_adma64cmd_interrupt_enable_q2) \
      ((mpm_adma64cmd_interrupt_enable_q2 & mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_QEI_Enable_MASK) >> mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_QEI_Enable_SHIFT)

#define mpM_Adma64Cmd_Interrupt_Enable_Q2_SET_RI_CompInt_Enable(mpm_adma64cmd_interrupt_enable_q2_reg, ri_compint_enable) \
      mpm_adma64cmd_interrupt_enable_q2_reg = (mpm_adma64cmd_interrupt_enable_q2_reg & ~mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_CompInt_Enable_MASK) | (ri_compint_enable << mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_CompInt_Enable_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Enable_Q2_SET_RI_ErrInt_Enable(mpm_adma64cmd_interrupt_enable_q2_reg, ri_errint_enable) \
      mpm_adma64cmd_interrupt_enable_q2_reg = (mpm_adma64cmd_interrupt_enable_q2_reg & ~mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_MASK) | (ri_errint_enable << mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Enable_Q2_SET_RI_QSI_Enable(mpm_adma64cmd_interrupt_enable_q2_reg, ri_qsi_enable) \
      mpm_adma64cmd_interrupt_enable_q2_reg = (mpm_adma64cmd_interrupt_enable_q2_reg & ~mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_QSI_Enable_MASK) | (ri_qsi_enable << mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_QSI_Enable_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Enable_Q2_SET_RI_QEI_Enable(mpm_adma64cmd_interrupt_enable_q2_reg, ri_qei_enable) \
      mpm_adma64cmd_interrupt_enable_q2_reg = (mpm_adma64cmd_interrupt_enable_q2_reg & ~mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_QEI_Enable_MASK) | (ri_qei_enable << mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_QEI_Enable_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_interrupt_enable_q2_t {
            unsigned int ri_compint_enable              : mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_CompInt_Enable_SIZE;
            unsigned int ri_errint_enable               : mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_SIZE;
            unsigned int ri_qsi_enable                  : mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_QSI_Enable_SIZE;
            unsigned int ri_qei_enable                  : mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_QEI_Enable_SIZE;
            unsigned int                                : 28;
      } mpm_adma64cmd_interrupt_enable_q2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_interrupt_enable_q2_t {
            unsigned int                                : 28;
            unsigned int ri_qei_enable                  : mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_QEI_Enable_SIZE;
            unsigned int ri_qsi_enable                  : mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_QSI_Enable_SIZE;
            unsigned int ri_errint_enable               : mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_SIZE;
            unsigned int ri_compint_enable              : mpM_Adma64Cmd_Interrupt_Enable_Q2_RI_CompInt_Enable_SIZE;
      } mpm_adma64cmd_interrupt_enable_q2_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_interrupt_enable_q2_t f;
} mpm_adma64cmd_interrupt_enable_q2_u;


/*
 * mpM_Adma64Cmd_Interrupt_Status_Q2 struct
 */

#define mpM_Adma64Cmd_Interrupt_Status_Q2_REG_SIZE         32
#define mpM_Adma64Cmd_Interrupt_Status_Q2_RI_CompInt_Valid_SIZE  1
#define mpM_Adma64Cmd_Interrupt_Status_Q2_RI_ErrInt_Valid_SIZE  1
#define mpM_Adma64Cmd_Interrupt_Status_Q2_RI_QSI_Valid_SIZE  1
#define mpM_Adma64Cmd_Interrupt_Status_Q2_RI_QEI_Valid_SIZE  1

#define mpM_Adma64Cmd_Interrupt_Status_Q2_RI_CompInt_Valid_SHIFT  0
#define mpM_Adma64Cmd_Interrupt_Status_Q2_RI_ErrInt_Valid_SHIFT  1
#define mpM_Adma64Cmd_Interrupt_Status_Q2_RI_QSI_Valid_SHIFT  2
#define mpM_Adma64Cmd_Interrupt_Status_Q2_RI_QEI_Valid_SHIFT  3

#define mpM_Adma64Cmd_Interrupt_Status_Q2_RI_CompInt_Valid_MASK  0x00000001
#define mpM_Adma64Cmd_Interrupt_Status_Q2_RI_ErrInt_Valid_MASK  0x00000002
#define mpM_Adma64Cmd_Interrupt_Status_Q2_RI_QSI_Valid_MASK  0x00000004
#define mpM_Adma64Cmd_Interrupt_Status_Q2_RI_QEI_Valid_MASK  0x00000008

#define mpM_Adma64Cmd_Interrupt_Status_Q2_MASK \
      (mpM_Adma64Cmd_Interrupt_Status_Q2_RI_CompInt_Valid_MASK | \
      mpM_Adma64Cmd_Interrupt_Status_Q2_RI_ErrInt_Valid_MASK | \
      mpM_Adma64Cmd_Interrupt_Status_Q2_RI_QSI_Valid_MASK | \
      mpM_Adma64Cmd_Interrupt_Status_Q2_RI_QEI_Valid_MASK)

#define mpM_Adma64Cmd_Interrupt_Status_Q2_DEFAULT 0x00000000

#define mpM_Adma64Cmd_Interrupt_Status_Q2_GET_RI_CompInt_Valid(mpm_adma64cmd_interrupt_status_q2) \
      ((mpm_adma64cmd_interrupt_status_q2 & mpM_Adma64Cmd_Interrupt_Status_Q2_RI_CompInt_Valid_MASK) >> mpM_Adma64Cmd_Interrupt_Status_Q2_RI_CompInt_Valid_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Status_Q2_GET_RI_ErrInt_Valid(mpm_adma64cmd_interrupt_status_q2) \
      ((mpm_adma64cmd_interrupt_status_q2 & mpM_Adma64Cmd_Interrupt_Status_Q2_RI_ErrInt_Valid_MASK) >> mpM_Adma64Cmd_Interrupt_Status_Q2_RI_ErrInt_Valid_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Status_Q2_GET_RI_QSI_Valid(mpm_adma64cmd_interrupt_status_q2) \
      ((mpm_adma64cmd_interrupt_status_q2 & mpM_Adma64Cmd_Interrupt_Status_Q2_RI_QSI_Valid_MASK) >> mpM_Adma64Cmd_Interrupt_Status_Q2_RI_QSI_Valid_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Status_Q2_GET_RI_QEI_Valid(mpm_adma64cmd_interrupt_status_q2) \
      ((mpm_adma64cmd_interrupt_status_q2 & mpM_Adma64Cmd_Interrupt_Status_Q2_RI_QEI_Valid_MASK) >> mpM_Adma64Cmd_Interrupt_Status_Q2_RI_QEI_Valid_SHIFT)

#define mpM_Adma64Cmd_Interrupt_Status_Q2_SET_RI_CompInt_Valid(mpm_adma64cmd_interrupt_status_q2_reg, ri_compint_valid) \
      mpm_adma64cmd_interrupt_status_q2_reg = (mpm_adma64cmd_interrupt_status_q2_reg & ~mpM_Adma64Cmd_Interrupt_Status_Q2_RI_CompInt_Valid_MASK) | (ri_compint_valid << mpM_Adma64Cmd_Interrupt_Status_Q2_RI_CompInt_Valid_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Status_Q2_SET_RI_ErrInt_Valid(mpm_adma64cmd_interrupt_status_q2_reg, ri_errint_valid) \
      mpm_adma64cmd_interrupt_status_q2_reg = (mpm_adma64cmd_interrupt_status_q2_reg & ~mpM_Adma64Cmd_Interrupt_Status_Q2_RI_ErrInt_Valid_MASK) | (ri_errint_valid << mpM_Adma64Cmd_Interrupt_Status_Q2_RI_ErrInt_Valid_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Status_Q2_SET_RI_QSI_Valid(mpm_adma64cmd_interrupt_status_q2_reg, ri_qsi_valid) \
      mpm_adma64cmd_interrupt_status_q2_reg = (mpm_adma64cmd_interrupt_status_q2_reg & ~mpM_Adma64Cmd_Interrupt_Status_Q2_RI_QSI_Valid_MASK) | (ri_qsi_valid << mpM_Adma64Cmd_Interrupt_Status_Q2_RI_QSI_Valid_SHIFT)
#define mpM_Adma64Cmd_Interrupt_Status_Q2_SET_RI_QEI_Valid(mpm_adma64cmd_interrupt_status_q2_reg, ri_qei_valid) \
      mpm_adma64cmd_interrupt_status_q2_reg = (mpm_adma64cmd_interrupt_status_q2_reg & ~mpM_Adma64Cmd_Interrupt_Status_Q2_RI_QEI_Valid_MASK) | (ri_qei_valid << mpM_Adma64Cmd_Interrupt_Status_Q2_RI_QEI_Valid_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_interrupt_status_q2_t {
            unsigned int ri_compint_valid               : mpM_Adma64Cmd_Interrupt_Status_Q2_RI_CompInt_Valid_SIZE;
            unsigned int ri_errint_valid                : mpM_Adma64Cmd_Interrupt_Status_Q2_RI_ErrInt_Valid_SIZE;
            unsigned int ri_qsi_valid                   : mpM_Adma64Cmd_Interrupt_Status_Q2_RI_QSI_Valid_SIZE;
            unsigned int ri_qei_valid                   : mpM_Adma64Cmd_Interrupt_Status_Q2_RI_QEI_Valid_SIZE;
            unsigned int                                : 28;
      } mpm_adma64cmd_interrupt_status_q2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_interrupt_status_q2_t {
            unsigned int                                : 28;
            unsigned int ri_qei_valid                   : mpM_Adma64Cmd_Interrupt_Status_Q2_RI_QEI_Valid_SIZE;
            unsigned int ri_qsi_valid                   : mpM_Adma64Cmd_Interrupt_Status_Q2_RI_QSI_Valid_SIZE;
            unsigned int ri_errint_valid                : mpM_Adma64Cmd_Interrupt_Status_Q2_RI_ErrInt_Valid_SIZE;
            unsigned int ri_compint_valid               : mpM_Adma64Cmd_Interrupt_Status_Q2_RI_CompInt_Valid_SIZE;
      } mpm_adma64cmd_interrupt_status_q2_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_interrupt_status_q2_t f;
} mpm_adma64cmd_interrupt_status_q2_u;


/*
 * mpM_Adma64Cmd_Status_Q2 struct
 */

#define mpM_Adma64Cmd_Status_Q2_REG_SIZE         32
#define mpM_Adma64Cmd_Status_Q2_VQM_Error_SIZE  6
#define mpM_Adma64Cmd_Status_Q2_VQM_ErrorPrevious_SIZE  1
#define mpM_Adma64Cmd_Status_Q2_VQM_JStatus_SIZE  3
#define mpM_Adma64Cmd_Status_Q2_VQM_ErrorSource_SIZE  3

#define mpM_Adma64Cmd_Status_Q2_VQM_Error_SHIFT  0
#define mpM_Adma64Cmd_Status_Q2_VQM_ErrorPrevious_SHIFT  6
#define mpM_Adma64Cmd_Status_Q2_VQM_JStatus_SHIFT  7
#define mpM_Adma64Cmd_Status_Q2_VQM_ErrorSource_SHIFT  10

#define mpM_Adma64Cmd_Status_Q2_VQM_Error_MASK  0x0000003f
#define mpM_Adma64Cmd_Status_Q2_VQM_ErrorPrevious_MASK  0x00000040
#define mpM_Adma64Cmd_Status_Q2_VQM_JStatus_MASK  0x00000380
#define mpM_Adma64Cmd_Status_Q2_VQM_ErrorSource_MASK  0x00001c00

#define mpM_Adma64Cmd_Status_Q2_MASK \
      (mpM_Adma64Cmd_Status_Q2_VQM_Error_MASK | \
      mpM_Adma64Cmd_Status_Q2_VQM_ErrorPrevious_MASK | \
      mpM_Adma64Cmd_Status_Q2_VQM_JStatus_MASK | \
      mpM_Adma64Cmd_Status_Q2_VQM_ErrorSource_MASK)

#define mpM_Adma64Cmd_Status_Q2_DEFAULT 0x00000000

#define mpM_Adma64Cmd_Status_Q2_GET_VQM_Error(mpm_adma64cmd_status_q2) \
      ((mpm_adma64cmd_status_q2 & mpM_Adma64Cmd_Status_Q2_VQM_Error_MASK) >> mpM_Adma64Cmd_Status_Q2_VQM_Error_SHIFT)
#define mpM_Adma64Cmd_Status_Q2_GET_VQM_ErrorPrevious(mpm_adma64cmd_status_q2) \
      ((mpm_adma64cmd_status_q2 & mpM_Adma64Cmd_Status_Q2_VQM_ErrorPrevious_MASK) >> mpM_Adma64Cmd_Status_Q2_VQM_ErrorPrevious_SHIFT)
#define mpM_Adma64Cmd_Status_Q2_GET_VQM_JStatus(mpm_adma64cmd_status_q2) \
      ((mpm_adma64cmd_status_q2 & mpM_Adma64Cmd_Status_Q2_VQM_JStatus_MASK) >> mpM_Adma64Cmd_Status_Q2_VQM_JStatus_SHIFT)
#define mpM_Adma64Cmd_Status_Q2_GET_VQM_ErrorSource(mpm_adma64cmd_status_q2) \
      ((mpm_adma64cmd_status_q2 & mpM_Adma64Cmd_Status_Q2_VQM_ErrorSource_MASK) >> mpM_Adma64Cmd_Status_Q2_VQM_ErrorSource_SHIFT)

#define mpM_Adma64Cmd_Status_Q2_SET_VQM_Error(mpm_adma64cmd_status_q2_reg, vqm_error) \
      mpm_adma64cmd_status_q2_reg = (mpm_adma64cmd_status_q2_reg & ~mpM_Adma64Cmd_Status_Q2_VQM_Error_MASK) | (vqm_error << mpM_Adma64Cmd_Status_Q2_VQM_Error_SHIFT)
#define mpM_Adma64Cmd_Status_Q2_SET_VQM_ErrorPrevious(mpm_adma64cmd_status_q2_reg, vqm_errorprevious) \
      mpm_adma64cmd_status_q2_reg = (mpm_adma64cmd_status_q2_reg & ~mpM_Adma64Cmd_Status_Q2_VQM_ErrorPrevious_MASK) | (vqm_errorprevious << mpM_Adma64Cmd_Status_Q2_VQM_ErrorPrevious_SHIFT)
#define mpM_Adma64Cmd_Status_Q2_SET_VQM_JStatus(mpm_adma64cmd_status_q2_reg, vqm_jstatus) \
      mpm_adma64cmd_status_q2_reg = (mpm_adma64cmd_status_q2_reg & ~mpM_Adma64Cmd_Status_Q2_VQM_JStatus_MASK) | (vqm_jstatus << mpM_Adma64Cmd_Status_Q2_VQM_JStatus_SHIFT)
#define mpM_Adma64Cmd_Status_Q2_SET_VQM_ErrorSource(mpm_adma64cmd_status_q2_reg, vqm_errorsource) \
      mpm_adma64cmd_status_q2_reg = (mpm_adma64cmd_status_q2_reg & ~mpM_Adma64Cmd_Status_Q2_VQM_ErrorSource_MASK) | (vqm_errorsource << mpM_Adma64Cmd_Status_Q2_VQM_ErrorSource_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_status_q2_t {
            unsigned int vqm_error                      : mpM_Adma64Cmd_Status_Q2_VQM_Error_SIZE;
            unsigned int vqm_errorprevious              : mpM_Adma64Cmd_Status_Q2_VQM_ErrorPrevious_SIZE;
            unsigned int vqm_jstatus                    : mpM_Adma64Cmd_Status_Q2_VQM_JStatus_SIZE;
            unsigned int vqm_errorsource                : mpM_Adma64Cmd_Status_Q2_VQM_ErrorSource_SIZE;
            unsigned int                                : 19;
      } mpm_adma64cmd_status_q2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_status_q2_t {
            unsigned int                                : 19;
            unsigned int vqm_errorsource                : mpM_Adma64Cmd_Status_Q2_VQM_ErrorSource_SIZE;
            unsigned int vqm_jstatus                    : mpM_Adma64Cmd_Status_Q2_VQM_JStatus_SIZE;
            unsigned int vqm_errorprevious              : mpM_Adma64Cmd_Status_Q2_VQM_ErrorPrevious_SIZE;
            unsigned int vqm_error                      : mpM_Adma64Cmd_Status_Q2_VQM_Error_SIZE;
      } mpm_adma64cmd_status_q2_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_status_q2_t f;
} mpm_adma64cmd_status_q2_u;


/*
 * mpM_Adma64Cmd_Int_Status_Q2 struct
 */

#define mpM_Adma64Cmd_Int_Status_Q2_REG_SIZE         32
#define mpM_Adma64Cmd_Int_Status_Q2_IC_EventCnt_SIZE  7

#define mpM_Adma64Cmd_Int_Status_Q2_IC_EventCnt_SHIFT  0

#define mpM_Adma64Cmd_Int_Status_Q2_IC_EventCnt_MASK  0x0000007f

#define mpM_Adma64Cmd_Int_Status_Q2_MASK \
      (mpM_Adma64Cmd_Int_Status_Q2_IC_EventCnt_MASK)

#define mpM_Adma64Cmd_Int_Status_Q2_DEFAULT 0x00000000

#define mpM_Adma64Cmd_Int_Status_Q2_GET_IC_EventCnt(mpm_adma64cmd_int_status_q2) \
      ((mpm_adma64cmd_int_status_q2 & mpM_Adma64Cmd_Int_Status_Q2_IC_EventCnt_MASK) >> mpM_Adma64Cmd_Int_Status_Q2_IC_EventCnt_SHIFT)

#define mpM_Adma64Cmd_Int_Status_Q2_SET_IC_EventCnt(mpm_adma64cmd_int_status_q2_reg, ic_eventcnt) \
      mpm_adma64cmd_int_status_q2_reg = (mpm_adma64cmd_int_status_q2_reg & ~mpM_Adma64Cmd_Int_Status_Q2_IC_EventCnt_MASK) | (ic_eventcnt << mpM_Adma64Cmd_Int_Status_Q2_IC_EventCnt_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_int_status_q2_t {
            unsigned int ic_eventcnt                    : mpM_Adma64Cmd_Int_Status_Q2_IC_EventCnt_SIZE;
            unsigned int                                : 25;
      } mpm_adma64cmd_int_status_q2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_int_status_q2_t {
            unsigned int                                : 25;
            unsigned int ic_eventcnt                    : mpM_Adma64Cmd_Int_Status_Q2_IC_EventCnt_SIZE;
      } mpm_adma64cmd_int_status_q2_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_int_status_q2_t f;
} mpm_adma64cmd_int_status_q2_u;


/*
 * mpM_Adma64Cmd_DMA_Status_Q2 struct
 */

#define mpM_Adma64Cmd_DMA_Status_Q2_REG_SIZE         32
#define mpM_Adma64Cmd_DMA_Status_Q2_DMA_Pwrites_SIZE  10
#define mpM_Adma64Cmd_DMA_Status_Q2_DMA_Preads_SIZE  6
#define mpM_Adma64Cmd_DMA_Status_Q2_DMA_Dstatus_SIZE  3

#define mpM_Adma64Cmd_DMA_Status_Q2_DMA_Pwrites_SHIFT  0
#define mpM_Adma64Cmd_DMA_Status_Q2_DMA_Preads_SHIFT  10
#define mpM_Adma64Cmd_DMA_Status_Q2_DMA_Dstatus_SHIFT  16

#define mpM_Adma64Cmd_DMA_Status_Q2_DMA_Pwrites_MASK  0x000003ff
#define mpM_Adma64Cmd_DMA_Status_Q2_DMA_Preads_MASK  0x0000fc00
#define mpM_Adma64Cmd_DMA_Status_Q2_DMA_Dstatus_MASK  0x00070000

#define mpM_Adma64Cmd_DMA_Status_Q2_MASK \
      (mpM_Adma64Cmd_DMA_Status_Q2_DMA_Pwrites_MASK | \
      mpM_Adma64Cmd_DMA_Status_Q2_DMA_Preads_MASK | \
      mpM_Adma64Cmd_DMA_Status_Q2_DMA_Dstatus_MASK)

#define mpM_Adma64Cmd_DMA_Status_Q2_DEFAULT 0x00000000

#define mpM_Adma64Cmd_DMA_Status_Q2_GET_DMA_Pwrites(mpm_adma64cmd_dma_status_q2) \
      ((mpm_adma64cmd_dma_status_q2 & mpM_Adma64Cmd_DMA_Status_Q2_DMA_Pwrites_MASK) >> mpM_Adma64Cmd_DMA_Status_Q2_DMA_Pwrites_SHIFT)
#define mpM_Adma64Cmd_DMA_Status_Q2_GET_DMA_Preads(mpm_adma64cmd_dma_status_q2) \
      ((mpm_adma64cmd_dma_status_q2 & mpM_Adma64Cmd_DMA_Status_Q2_DMA_Preads_MASK) >> mpM_Adma64Cmd_DMA_Status_Q2_DMA_Preads_SHIFT)
#define mpM_Adma64Cmd_DMA_Status_Q2_GET_DMA_Dstatus(mpm_adma64cmd_dma_status_q2) \
      ((mpm_adma64cmd_dma_status_q2 & mpM_Adma64Cmd_DMA_Status_Q2_DMA_Dstatus_MASK) >> mpM_Adma64Cmd_DMA_Status_Q2_DMA_Dstatus_SHIFT)

#define mpM_Adma64Cmd_DMA_Status_Q2_SET_DMA_Pwrites(mpm_adma64cmd_dma_status_q2_reg, dma_pwrites) \
      mpm_adma64cmd_dma_status_q2_reg = (mpm_adma64cmd_dma_status_q2_reg & ~mpM_Adma64Cmd_DMA_Status_Q2_DMA_Pwrites_MASK) | (dma_pwrites << mpM_Adma64Cmd_DMA_Status_Q2_DMA_Pwrites_SHIFT)
#define mpM_Adma64Cmd_DMA_Status_Q2_SET_DMA_Preads(mpm_adma64cmd_dma_status_q2_reg, dma_preads) \
      mpm_adma64cmd_dma_status_q2_reg = (mpm_adma64cmd_dma_status_q2_reg & ~mpM_Adma64Cmd_DMA_Status_Q2_DMA_Preads_MASK) | (dma_preads << mpM_Adma64Cmd_DMA_Status_Q2_DMA_Preads_SHIFT)
#define mpM_Adma64Cmd_DMA_Status_Q2_SET_DMA_Dstatus(mpm_adma64cmd_dma_status_q2_reg, dma_dstatus) \
      mpm_adma64cmd_dma_status_q2_reg = (mpm_adma64cmd_dma_status_q2_reg & ~mpM_Adma64Cmd_DMA_Status_Q2_DMA_Dstatus_MASK) | (dma_dstatus << mpM_Adma64Cmd_DMA_Status_Q2_DMA_Dstatus_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_dma_status_q2_t {
            unsigned int dma_pwrites                    : mpM_Adma64Cmd_DMA_Status_Q2_DMA_Pwrites_SIZE;
            unsigned int dma_preads                     : mpM_Adma64Cmd_DMA_Status_Q2_DMA_Preads_SIZE;
            unsigned int dma_dstatus                    : mpM_Adma64Cmd_DMA_Status_Q2_DMA_Dstatus_SIZE;
            unsigned int                                : 13;
      } mpm_adma64cmd_dma_status_q2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_dma_status_q2_t {
            unsigned int                                : 13;
            unsigned int dma_dstatus                    : mpM_Adma64Cmd_DMA_Status_Q2_DMA_Dstatus_SIZE;
            unsigned int dma_preads                     : mpM_Adma64Cmd_DMA_Status_Q2_DMA_Preads_SIZE;
            unsigned int dma_pwrites                    : mpM_Adma64Cmd_DMA_Status_Q2_DMA_Pwrites_SIZE;
      } mpm_adma64cmd_dma_status_q2_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_dma_status_q2_t f;
} mpm_adma64cmd_dma_status_q2_u;


/*
 * mpM_Adma64Cmd_DMA_Read_Status_Q2 struct
 */

#define mpM_Adma64Cmd_DMA_Read_Status_Q2_REG_SIZE         32
#define mpM_Adma64Cmd_DMA_Read_Status_Q2_DMA_BytesRead_SIZE  32

#define mpM_Adma64Cmd_DMA_Read_Status_Q2_DMA_BytesRead_SHIFT  0

#define mpM_Adma64Cmd_DMA_Read_Status_Q2_DMA_BytesRead_MASK  0xffffffff

#define mpM_Adma64Cmd_DMA_Read_Status_Q2_MASK \
      (mpM_Adma64Cmd_DMA_Read_Status_Q2_DMA_BytesRead_MASK)

#define mpM_Adma64Cmd_DMA_Read_Status_Q2_DEFAULT 0x00000000

#define mpM_Adma64Cmd_DMA_Read_Status_Q2_GET_DMA_BytesRead(mpm_adma64cmd_dma_read_status_q2) \
      ((mpm_adma64cmd_dma_read_status_q2 & mpM_Adma64Cmd_DMA_Read_Status_Q2_DMA_BytesRead_MASK) >> mpM_Adma64Cmd_DMA_Read_Status_Q2_DMA_BytesRead_SHIFT)

#define mpM_Adma64Cmd_DMA_Read_Status_Q2_SET_DMA_BytesRead(mpm_adma64cmd_dma_read_status_q2_reg, dma_bytesread) \
      mpm_adma64cmd_dma_read_status_q2_reg = (mpm_adma64cmd_dma_read_status_q2_reg & ~mpM_Adma64Cmd_DMA_Read_Status_Q2_DMA_BytesRead_MASK) | (dma_bytesread << mpM_Adma64Cmd_DMA_Read_Status_Q2_DMA_BytesRead_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_dma_read_status_q2_t {
            unsigned int dma_bytesread                  : mpM_Adma64Cmd_DMA_Read_Status_Q2_DMA_BytesRead_SIZE;
      } mpm_adma64cmd_dma_read_status_q2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_dma_read_status_q2_t {
            unsigned int dma_bytesread                  : mpM_Adma64Cmd_DMA_Read_Status_Q2_DMA_BytesRead_SIZE;
      } mpm_adma64cmd_dma_read_status_q2_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_dma_read_status_q2_t f;
} mpm_adma64cmd_dma_read_status_q2_u;


/*
 * mpM_Adma64Cmd_DMA_Write_Status_Q2 struct
 */

#define mpM_Adma64Cmd_DMA_Write_Status_Q2_REG_SIZE         32
#define mpM_Adma64Cmd_DMA_Write_Status_Q2_DMA_BytesWritten_SIZE  32

#define mpM_Adma64Cmd_DMA_Write_Status_Q2_DMA_BytesWritten_SHIFT  0

#define mpM_Adma64Cmd_DMA_Write_Status_Q2_DMA_BytesWritten_MASK  0xffffffff

#define mpM_Adma64Cmd_DMA_Write_Status_Q2_MASK \
      (mpM_Adma64Cmd_DMA_Write_Status_Q2_DMA_BytesWritten_MASK)

#define mpM_Adma64Cmd_DMA_Write_Status_Q2_DEFAULT 0x00000000

#define mpM_Adma64Cmd_DMA_Write_Status_Q2_GET_DMA_BytesWritten(mpm_adma64cmd_dma_write_status_q2) \
      ((mpm_adma64cmd_dma_write_status_q2 & mpM_Adma64Cmd_DMA_Write_Status_Q2_DMA_BytesWritten_MASK) >> mpM_Adma64Cmd_DMA_Write_Status_Q2_DMA_BytesWritten_SHIFT)

#define mpM_Adma64Cmd_DMA_Write_Status_Q2_SET_DMA_BytesWritten(mpm_adma64cmd_dma_write_status_q2_reg, dma_byteswritten) \
      mpm_adma64cmd_dma_write_status_q2_reg = (mpm_adma64cmd_dma_write_status_q2_reg & ~mpM_Adma64Cmd_DMA_Write_Status_Q2_DMA_BytesWritten_MASK) | (dma_byteswritten << mpM_Adma64Cmd_DMA_Write_Status_Q2_DMA_BytesWritten_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_dma_write_status_q2_t {
            unsigned int dma_byteswritten               : mpM_Adma64Cmd_DMA_Write_Status_Q2_DMA_BytesWritten_SIZE;
      } mpm_adma64cmd_dma_write_status_q2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_dma_write_status_q2_t {
            unsigned int dma_byteswritten               : mpM_Adma64Cmd_DMA_Write_Status_Q2_DMA_BytesWritten_SIZE;
      } mpm_adma64cmd_dma_write_status_q2_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_dma_write_status_q2_t f;
} mpm_adma64cmd_dma_write_status_q2_u;


/*
 * mpM_Adma64Cmd_Abort_Q2 struct
 */

#define mpM_Adma64Cmd_Abort_Q2_REG_SIZE         32
#define mpM_Adma64Cmd_Abort_Q2_RI_Offset_SIZE  18
#define mpM_Adma64Cmd_Abort_Q2_RI_Offset_Valid_SIZE  1

#define mpM_Adma64Cmd_Abort_Q2_RI_Offset_SHIFT  0
#define mpM_Adma64Cmd_Abort_Q2_RI_Offset_Valid_SHIFT  31

#define mpM_Adma64Cmd_Abort_Q2_RI_Offset_MASK  0x0003ffff
#define mpM_Adma64Cmd_Abort_Q2_RI_Offset_Valid_MASK  0x80000000

#define mpM_Adma64Cmd_Abort_Q2_MASK \
      (mpM_Adma64Cmd_Abort_Q2_RI_Offset_MASK | \
      mpM_Adma64Cmd_Abort_Q2_RI_Offset_Valid_MASK)

#define mpM_Adma64Cmd_Abort_Q2_DEFAULT 0x00000000

#define mpM_Adma64Cmd_Abort_Q2_GET_RI_Offset(mpm_adma64cmd_abort_q2) \
      ((mpm_adma64cmd_abort_q2 & mpM_Adma64Cmd_Abort_Q2_RI_Offset_MASK) >> mpM_Adma64Cmd_Abort_Q2_RI_Offset_SHIFT)
#define mpM_Adma64Cmd_Abort_Q2_GET_RI_Offset_Valid(mpm_adma64cmd_abort_q2) \
      ((mpm_adma64cmd_abort_q2 & mpM_Adma64Cmd_Abort_Q2_RI_Offset_Valid_MASK) >> mpM_Adma64Cmd_Abort_Q2_RI_Offset_Valid_SHIFT)

#define mpM_Adma64Cmd_Abort_Q2_SET_RI_Offset(mpm_adma64cmd_abort_q2_reg, ri_offset) \
      mpm_adma64cmd_abort_q2_reg = (mpm_adma64cmd_abort_q2_reg & ~mpM_Adma64Cmd_Abort_Q2_RI_Offset_MASK) | (ri_offset << mpM_Adma64Cmd_Abort_Q2_RI_Offset_SHIFT)
#define mpM_Adma64Cmd_Abort_Q2_SET_RI_Offset_Valid(mpm_adma64cmd_abort_q2_reg, ri_offset_valid) \
      mpm_adma64cmd_abort_q2_reg = (mpm_adma64cmd_abort_q2_reg & ~mpM_Adma64Cmd_Abort_Q2_RI_Offset_Valid_MASK) | (ri_offset_valid << mpM_Adma64Cmd_Abort_Q2_RI_Offset_Valid_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_abort_q2_t {
            unsigned int ri_offset                      : mpM_Adma64Cmd_Abort_Q2_RI_Offset_SIZE;
            unsigned int                                : 13;
            unsigned int ri_offset_valid                : mpM_Adma64Cmd_Abort_Q2_RI_Offset_Valid_SIZE;
      } mpm_adma64cmd_abort_q2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_abort_q2_t {
            unsigned int ri_offset_valid                : mpM_Adma64Cmd_Abort_Q2_RI_Offset_Valid_SIZE;
            unsigned int                                : 13;
            unsigned int ri_offset                      : mpM_Adma64Cmd_Abort_Q2_RI_Offset_SIZE;
      } mpm_adma64cmd_abort_q2_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_abort_q2_t f;
} mpm_adma64cmd_abort_q2_u;


/*
 * mpM_Adma64Cmd_AxCACHE_Q2 struct
 */

#define mpM_Adma64Cmd_AxCACHE_Q2_REG_SIZE         32
#define mpM_Adma64Cmd_AxCACHE_Q2_RI_AWCACHE_SIZE  4
#define mpM_Adma64Cmd_AxCACHE_Q2_RI_ARCACHE_SIZE  4
#define mpM_Adma64Cmd_AxCACHE_Q2_RI_VCD_ARCACHE_SIZE  4

#define mpM_Adma64Cmd_AxCACHE_Q2_RI_AWCACHE_SHIFT  0
#define mpM_Adma64Cmd_AxCACHE_Q2_RI_ARCACHE_SHIFT  4
#define mpM_Adma64Cmd_AxCACHE_Q2_RI_VCD_ARCACHE_SHIFT  8

#define mpM_Adma64Cmd_AxCACHE_Q2_RI_AWCACHE_MASK  0x0000000f
#define mpM_Adma64Cmd_AxCACHE_Q2_RI_ARCACHE_MASK  0x000000f0
#define mpM_Adma64Cmd_AxCACHE_Q2_RI_VCD_ARCACHE_MASK  0x00000f00

#define mpM_Adma64Cmd_AxCACHE_Q2_MASK \
      (mpM_Adma64Cmd_AxCACHE_Q2_RI_AWCACHE_MASK | \
      mpM_Adma64Cmd_AxCACHE_Q2_RI_ARCACHE_MASK | \
      mpM_Adma64Cmd_AxCACHE_Q2_RI_VCD_ARCACHE_MASK)

#define mpM_Adma64Cmd_AxCACHE_Q2_DEFAULT 0x00000000

#define mpM_Adma64Cmd_AxCACHE_Q2_GET_RI_AWCACHE(mpm_adma64cmd_axcache_q2) \
      ((mpm_adma64cmd_axcache_q2 & mpM_Adma64Cmd_AxCACHE_Q2_RI_AWCACHE_MASK) >> mpM_Adma64Cmd_AxCACHE_Q2_RI_AWCACHE_SHIFT)
#define mpM_Adma64Cmd_AxCACHE_Q2_GET_RI_ARCACHE(mpm_adma64cmd_axcache_q2) \
      ((mpm_adma64cmd_axcache_q2 & mpM_Adma64Cmd_AxCACHE_Q2_RI_ARCACHE_MASK) >> mpM_Adma64Cmd_AxCACHE_Q2_RI_ARCACHE_SHIFT)
#define mpM_Adma64Cmd_AxCACHE_Q2_GET_RI_VCD_ARCACHE(mpm_adma64cmd_axcache_q2) \
      ((mpm_adma64cmd_axcache_q2 & mpM_Adma64Cmd_AxCACHE_Q2_RI_VCD_ARCACHE_MASK) >> mpM_Adma64Cmd_AxCACHE_Q2_RI_VCD_ARCACHE_SHIFT)

#define mpM_Adma64Cmd_AxCACHE_Q2_SET_RI_AWCACHE(mpm_adma64cmd_axcache_q2_reg, ri_awcache) \
      mpm_adma64cmd_axcache_q2_reg = (mpm_adma64cmd_axcache_q2_reg & ~mpM_Adma64Cmd_AxCACHE_Q2_RI_AWCACHE_MASK) | (ri_awcache << mpM_Adma64Cmd_AxCACHE_Q2_RI_AWCACHE_SHIFT)
#define mpM_Adma64Cmd_AxCACHE_Q2_SET_RI_ARCACHE(mpm_adma64cmd_axcache_q2_reg, ri_arcache) \
      mpm_adma64cmd_axcache_q2_reg = (mpm_adma64cmd_axcache_q2_reg & ~mpM_Adma64Cmd_AxCACHE_Q2_RI_ARCACHE_MASK) | (ri_arcache << mpM_Adma64Cmd_AxCACHE_Q2_RI_ARCACHE_SHIFT)
#define mpM_Adma64Cmd_AxCACHE_Q2_SET_RI_VCD_ARCACHE(mpm_adma64cmd_axcache_q2_reg, ri_vcd_arcache) \
      mpm_adma64cmd_axcache_q2_reg = (mpm_adma64cmd_axcache_q2_reg & ~mpM_Adma64Cmd_AxCACHE_Q2_RI_VCD_ARCACHE_MASK) | (ri_vcd_arcache << mpM_Adma64Cmd_AxCACHE_Q2_RI_VCD_ARCACHE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_adma64cmd_axcache_q2_t {
            unsigned int ri_awcache                     : mpM_Adma64Cmd_AxCACHE_Q2_RI_AWCACHE_SIZE;
            unsigned int ri_arcache                     : mpM_Adma64Cmd_AxCACHE_Q2_RI_ARCACHE_SIZE;
            unsigned int ri_vcd_arcache                 : mpM_Adma64Cmd_AxCACHE_Q2_RI_VCD_ARCACHE_SIZE;
            unsigned int                                : 20;
      } mpm_adma64cmd_axcache_q2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_adma64cmd_axcache_q2_t {
            unsigned int                                : 20;
            unsigned int ri_vcd_arcache                 : mpM_Adma64Cmd_AxCACHE_Q2_RI_VCD_ARCACHE_SIZE;
            unsigned int ri_arcache                     : mpM_Adma64Cmd_AxCACHE_Q2_RI_ARCACHE_SIZE;
            unsigned int ri_awcache                     : mpM_Adma64Cmd_AxCACHE_Q2_RI_AWCACHE_SIZE;
      } mpm_adma64cmd_axcache_q2_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_adma64cmd_axcache_q2_t f;
} mpm_adma64cmd_axcache_q2_u;


#endif

