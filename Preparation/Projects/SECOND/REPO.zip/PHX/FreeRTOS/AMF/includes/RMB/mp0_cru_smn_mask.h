// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MP0_CRU_SMN_MASK_H)
#define _MP0_CRU_SMN_MASK_H

/*****************************************************************************************************************
 *
 *	mp0_cru_smn_mask.h
 *
 *	Register Spec Release:  <unknown>
*
*	 (c) 2000 ATI Technologies Inc.  (unpublished)
*
*	 All rights reserved.  This notice is intended as a precaution against
*	 inadvertent publication and does not imply publication or any waiver
*	 of confidentiality.  The year included in the foregoing notice is the
*	 year of creation of the work.
*
 *****************************************************************************************************************/

/*******************************************************
 * Read and Write Masks
 *******************************************************/

#define MP0_SMN_C2PMSG_32_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_32_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_33_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_33_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_34_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_34_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_35_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_35_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_36_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_36_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_37_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_37_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_38_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_38_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_39_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_39_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_40_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_40_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_41_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_41_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_42_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_42_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_43_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_43_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_44_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_44_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_45_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_45_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_46_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_46_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_47_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_47_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_48_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_48_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_49_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_49_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_50_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_50_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_51_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_51_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_52_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_52_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_53_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_53_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_54_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_54_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_55_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_55_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_56_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_56_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_57_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_57_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_58_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_58_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_59_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_59_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_60_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_60_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_61_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_61_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_62_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_62_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_63_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_63_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_64_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_64_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_65_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_65_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_66_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_66_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_67_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_67_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_68_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_68_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_69_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_69_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_70_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_70_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_71_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_71_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_72_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_72_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_73_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_73_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_74_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_74_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_75_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_75_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_76_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_76_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_77_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_77_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_78_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_78_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_79_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_79_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_80_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_80_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_81_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_81_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_82_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_82_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_83_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_83_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_84_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_84_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_85_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_85_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_86_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_86_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_87_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_87_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_88_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_88_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_89_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_89_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_90_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_90_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_91_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_91_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_92_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_92_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_93_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_93_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_94_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_94_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_95_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_95_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_96_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_96_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_97_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_97_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_98_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_98_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_99_READ_MASK    0xffffffff
#define MP0_SMN_C2PMSG_99_WRITE_MASK   0xffffffff

#define MP0_SMN_C2PMSG_100_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_100_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_101_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_101_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_102_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_102_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_103_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_103_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_104_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_104_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_105_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_105_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_106_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_106_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_107_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_107_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_108_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_108_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_109_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_109_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_110_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_110_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_111_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_111_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_112_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_112_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_113_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_113_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_114_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_114_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_115_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_115_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_116_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_116_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_117_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_117_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_118_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_118_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_119_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_119_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_120_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_120_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_121_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_121_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_122_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_122_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_123_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_123_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_124_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_124_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_125_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_125_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_126_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_126_WRITE_MASK  0xffffffff

#define MP0_SMN_C2PMSG_127_READ_MASK   0xffffffff
#define MP0_SMN_C2PMSG_127_WRITE_MASK  0xffffffff

#define MP0_SMN_IH_CREDIT_READ_MASK    0x0
#define MP0_SMN_IH_CREDIT_WRITE_MASK   0xff0003

#define MP0_SMN_IH_SW_INT_READ_MASK    0x1ff
#define MP0_SMN_IH_SW_INT_WRITE_MASK   0x1ff

#define MP0_SMN_IH_SW_INT_CTRL_READ_MASK 0x1
#define MP0_SMN_IH_SW_INT_CTRL_WRITE_MASK 0x101

#endif


