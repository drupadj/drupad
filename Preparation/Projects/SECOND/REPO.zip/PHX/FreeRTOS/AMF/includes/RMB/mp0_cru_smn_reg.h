// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MP0_CRU_SMN_FIDDLE_H)
#define _MP0_CRU_SMN_FIDDLE_H

/*****************************************************************************************************************
 *
 *	mp0_cru_smn_reg.h
 *
 *	Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif


/*******************************************************
 * Values
 *******************************************************/


/*******************************************************
 * Structures
 *******************************************************/

/*
 * MP0_SMN_C2PMSG_32 struct
 */

#define MP0_SMN_C2PMSG_32_REG_SIZE     32
#define MP0_SMN_C2PMSG_32_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_32_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_32_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_32_MASK \
     (MP0_SMN_C2PMSG_32_CONTENT_MASK)

#define MP0_SMN_C2PMSG_32_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_32_GET_CONTENT(mp0_smn_c2pmsg_32) \
     ((mp0_smn_c2pmsg_32 & MP0_SMN_C2PMSG_32_CONTENT_MASK) >> MP0_SMN_C2PMSG_32_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_32_SET_CONTENT(mp0_smn_c2pmsg_32_reg, content) \
     mp0_smn_c2pmsg_32_reg = (mp0_smn_c2pmsg_32_reg & ~MP0_SMN_C2PMSG_32_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_32_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_32_t {
          unsigned int content                        : MP0_SMN_C2PMSG_32_CONTENT_SIZE;
     } mp0_smn_c2pmsg_32_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_32_t {
          unsigned int content                        : MP0_SMN_C2PMSG_32_CONTENT_SIZE;
     } mp0_smn_c2pmsg_32_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_32_t f;
} mp0_smn_c2pmsg_32_u;


/*
 * MP0_SMN_C2PMSG_33 struct
 */

#define MP0_SMN_C2PMSG_33_REG_SIZE     32
#define MP0_SMN_C2PMSG_33_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_33_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_33_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_33_MASK \
     (MP0_SMN_C2PMSG_33_CONTENT_MASK)

#define MP0_SMN_C2PMSG_33_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_33_GET_CONTENT(mp0_smn_c2pmsg_33) \
     ((mp0_smn_c2pmsg_33 & MP0_SMN_C2PMSG_33_CONTENT_MASK) >> MP0_SMN_C2PMSG_33_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_33_SET_CONTENT(mp0_smn_c2pmsg_33_reg, content) \
     mp0_smn_c2pmsg_33_reg = (mp0_smn_c2pmsg_33_reg & ~MP0_SMN_C2PMSG_33_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_33_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_33_t {
          unsigned int content                        : MP0_SMN_C2PMSG_33_CONTENT_SIZE;
     } mp0_smn_c2pmsg_33_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_33_t {
          unsigned int content                        : MP0_SMN_C2PMSG_33_CONTENT_SIZE;
     } mp0_smn_c2pmsg_33_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_33_t f;
} mp0_smn_c2pmsg_33_u;


/*
 * MP0_SMN_C2PMSG_34 struct
 */

#define MP0_SMN_C2PMSG_34_REG_SIZE     32
#define MP0_SMN_C2PMSG_34_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_34_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_34_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_34_MASK \
     (MP0_SMN_C2PMSG_34_CONTENT_MASK)

#define MP0_SMN_C2PMSG_34_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_34_GET_CONTENT(mp0_smn_c2pmsg_34) \
     ((mp0_smn_c2pmsg_34 & MP0_SMN_C2PMSG_34_CONTENT_MASK) >> MP0_SMN_C2PMSG_34_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_34_SET_CONTENT(mp0_smn_c2pmsg_34_reg, content) \
     mp0_smn_c2pmsg_34_reg = (mp0_smn_c2pmsg_34_reg & ~MP0_SMN_C2PMSG_34_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_34_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_34_t {
          unsigned int content                        : MP0_SMN_C2PMSG_34_CONTENT_SIZE;
     } mp0_smn_c2pmsg_34_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_34_t {
          unsigned int content                        : MP0_SMN_C2PMSG_34_CONTENT_SIZE;
     } mp0_smn_c2pmsg_34_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_34_t f;
} mp0_smn_c2pmsg_34_u;


/*
 * MP0_SMN_C2PMSG_35 struct
 */

#define MP0_SMN_C2PMSG_35_REG_SIZE     32
#define MP0_SMN_C2PMSG_35_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_35_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_35_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_35_MASK \
     (MP0_SMN_C2PMSG_35_CONTENT_MASK)

#define MP0_SMN_C2PMSG_35_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_35_GET_CONTENT(mp0_smn_c2pmsg_35) \
     ((mp0_smn_c2pmsg_35 & MP0_SMN_C2PMSG_35_CONTENT_MASK) >> MP0_SMN_C2PMSG_35_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_35_SET_CONTENT(mp0_smn_c2pmsg_35_reg, content) \
     mp0_smn_c2pmsg_35_reg = (mp0_smn_c2pmsg_35_reg & ~MP0_SMN_C2PMSG_35_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_35_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_35_t {
          unsigned int content                        : MP0_SMN_C2PMSG_35_CONTENT_SIZE;
     } mp0_smn_c2pmsg_35_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_35_t {
          unsigned int content                        : MP0_SMN_C2PMSG_35_CONTENT_SIZE;
     } mp0_smn_c2pmsg_35_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_35_t f;
} mp0_smn_c2pmsg_35_u;


/*
 * MP0_SMN_C2PMSG_36 struct
 */

#define MP0_SMN_C2PMSG_36_REG_SIZE     32
#define MP0_SMN_C2PMSG_36_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_36_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_36_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_36_MASK \
     (MP0_SMN_C2PMSG_36_CONTENT_MASK)

#define MP0_SMN_C2PMSG_36_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_36_GET_CONTENT(mp0_smn_c2pmsg_36) \
     ((mp0_smn_c2pmsg_36 & MP0_SMN_C2PMSG_36_CONTENT_MASK) >> MP0_SMN_C2PMSG_36_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_36_SET_CONTENT(mp0_smn_c2pmsg_36_reg, content) \
     mp0_smn_c2pmsg_36_reg = (mp0_smn_c2pmsg_36_reg & ~MP0_SMN_C2PMSG_36_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_36_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_36_t {
          unsigned int content                        : MP0_SMN_C2PMSG_36_CONTENT_SIZE;
     } mp0_smn_c2pmsg_36_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_36_t {
          unsigned int content                        : MP0_SMN_C2PMSG_36_CONTENT_SIZE;
     } mp0_smn_c2pmsg_36_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_36_t f;
} mp0_smn_c2pmsg_36_u;


/*
 * MP0_SMN_C2PMSG_37 struct
 */

#define MP0_SMN_C2PMSG_37_REG_SIZE     32
#define MP0_SMN_C2PMSG_37_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_37_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_37_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_37_MASK \
     (MP0_SMN_C2PMSG_37_CONTENT_MASK)

#define MP0_SMN_C2PMSG_37_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_37_GET_CONTENT(mp0_smn_c2pmsg_37) \
     ((mp0_smn_c2pmsg_37 & MP0_SMN_C2PMSG_37_CONTENT_MASK) >> MP0_SMN_C2PMSG_37_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_37_SET_CONTENT(mp0_smn_c2pmsg_37_reg, content) \
     mp0_smn_c2pmsg_37_reg = (mp0_smn_c2pmsg_37_reg & ~MP0_SMN_C2PMSG_37_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_37_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_37_t {
          unsigned int content                        : MP0_SMN_C2PMSG_37_CONTENT_SIZE;
     } mp0_smn_c2pmsg_37_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_37_t {
          unsigned int content                        : MP0_SMN_C2PMSG_37_CONTENT_SIZE;
     } mp0_smn_c2pmsg_37_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_37_t f;
} mp0_smn_c2pmsg_37_u;


/*
 * MP0_SMN_C2PMSG_38 struct
 */

#define MP0_SMN_C2PMSG_38_REG_SIZE     32
#define MP0_SMN_C2PMSG_38_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_38_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_38_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_38_MASK \
     (MP0_SMN_C2PMSG_38_CONTENT_MASK)

#define MP0_SMN_C2PMSG_38_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_38_GET_CONTENT(mp0_smn_c2pmsg_38) \
     ((mp0_smn_c2pmsg_38 & MP0_SMN_C2PMSG_38_CONTENT_MASK) >> MP0_SMN_C2PMSG_38_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_38_SET_CONTENT(mp0_smn_c2pmsg_38_reg, content) \
     mp0_smn_c2pmsg_38_reg = (mp0_smn_c2pmsg_38_reg & ~MP0_SMN_C2PMSG_38_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_38_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_38_t {
          unsigned int content                        : MP0_SMN_C2PMSG_38_CONTENT_SIZE;
     } mp0_smn_c2pmsg_38_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_38_t {
          unsigned int content                        : MP0_SMN_C2PMSG_38_CONTENT_SIZE;
     } mp0_smn_c2pmsg_38_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_38_t f;
} mp0_smn_c2pmsg_38_u;


/*
 * MP0_SMN_C2PMSG_39 struct
 */

#define MP0_SMN_C2PMSG_39_REG_SIZE     32
#define MP0_SMN_C2PMSG_39_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_39_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_39_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_39_MASK \
     (MP0_SMN_C2PMSG_39_CONTENT_MASK)

#define MP0_SMN_C2PMSG_39_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_39_GET_CONTENT(mp0_smn_c2pmsg_39) \
     ((mp0_smn_c2pmsg_39 & MP0_SMN_C2PMSG_39_CONTENT_MASK) >> MP0_SMN_C2PMSG_39_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_39_SET_CONTENT(mp0_smn_c2pmsg_39_reg, content) \
     mp0_smn_c2pmsg_39_reg = (mp0_smn_c2pmsg_39_reg & ~MP0_SMN_C2PMSG_39_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_39_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_39_t {
          unsigned int content                        : MP0_SMN_C2PMSG_39_CONTENT_SIZE;
     } mp0_smn_c2pmsg_39_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_39_t {
          unsigned int content                        : MP0_SMN_C2PMSG_39_CONTENT_SIZE;
     } mp0_smn_c2pmsg_39_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_39_t f;
} mp0_smn_c2pmsg_39_u;


/*
 * MP0_SMN_C2PMSG_40 struct
 */

#define MP0_SMN_C2PMSG_40_REG_SIZE     32
#define MP0_SMN_C2PMSG_40_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_40_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_40_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_40_MASK \
     (MP0_SMN_C2PMSG_40_CONTENT_MASK)

#define MP0_SMN_C2PMSG_40_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_40_GET_CONTENT(mp0_smn_c2pmsg_40) \
     ((mp0_smn_c2pmsg_40 & MP0_SMN_C2PMSG_40_CONTENT_MASK) >> MP0_SMN_C2PMSG_40_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_40_SET_CONTENT(mp0_smn_c2pmsg_40_reg, content) \
     mp0_smn_c2pmsg_40_reg = (mp0_smn_c2pmsg_40_reg & ~MP0_SMN_C2PMSG_40_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_40_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_40_t {
          unsigned int content                        : MP0_SMN_C2PMSG_40_CONTENT_SIZE;
     } mp0_smn_c2pmsg_40_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_40_t {
          unsigned int content                        : MP0_SMN_C2PMSG_40_CONTENT_SIZE;
     } mp0_smn_c2pmsg_40_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_40_t f;
} mp0_smn_c2pmsg_40_u;


/*
 * MP0_SMN_C2PMSG_41 struct
 */

#define MP0_SMN_C2PMSG_41_REG_SIZE     32
#define MP0_SMN_C2PMSG_41_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_41_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_41_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_41_MASK \
     (MP0_SMN_C2PMSG_41_CONTENT_MASK)

#define MP0_SMN_C2PMSG_41_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_41_GET_CONTENT(mp0_smn_c2pmsg_41) \
     ((mp0_smn_c2pmsg_41 & MP0_SMN_C2PMSG_41_CONTENT_MASK) >> MP0_SMN_C2PMSG_41_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_41_SET_CONTENT(mp0_smn_c2pmsg_41_reg, content) \
     mp0_smn_c2pmsg_41_reg = (mp0_smn_c2pmsg_41_reg & ~MP0_SMN_C2PMSG_41_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_41_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_41_t {
          unsigned int content                        : MP0_SMN_C2PMSG_41_CONTENT_SIZE;
     } mp0_smn_c2pmsg_41_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_41_t {
          unsigned int content                        : MP0_SMN_C2PMSG_41_CONTENT_SIZE;
     } mp0_smn_c2pmsg_41_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_41_t f;
} mp0_smn_c2pmsg_41_u;


/*
 * MP0_SMN_C2PMSG_42 struct
 */

#define MP0_SMN_C2PMSG_42_REG_SIZE     32
#define MP0_SMN_C2PMSG_42_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_42_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_42_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_42_MASK \
     (MP0_SMN_C2PMSG_42_CONTENT_MASK)

#define MP0_SMN_C2PMSG_42_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_42_GET_CONTENT(mp0_smn_c2pmsg_42) \
     ((mp0_smn_c2pmsg_42 & MP0_SMN_C2PMSG_42_CONTENT_MASK) >> MP0_SMN_C2PMSG_42_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_42_SET_CONTENT(mp0_smn_c2pmsg_42_reg, content) \
     mp0_smn_c2pmsg_42_reg = (mp0_smn_c2pmsg_42_reg & ~MP0_SMN_C2PMSG_42_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_42_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_42_t {
          unsigned int content                        : MP0_SMN_C2PMSG_42_CONTENT_SIZE;
     } mp0_smn_c2pmsg_42_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_42_t {
          unsigned int content                        : MP0_SMN_C2PMSG_42_CONTENT_SIZE;
     } mp0_smn_c2pmsg_42_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_42_t f;
} mp0_smn_c2pmsg_42_u;


/*
 * MP0_SMN_C2PMSG_43 struct
 */

#define MP0_SMN_C2PMSG_43_REG_SIZE     32
#define MP0_SMN_C2PMSG_43_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_43_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_43_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_43_MASK \
     (MP0_SMN_C2PMSG_43_CONTENT_MASK)

#define MP0_SMN_C2PMSG_43_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_43_GET_CONTENT(mp0_smn_c2pmsg_43) \
     ((mp0_smn_c2pmsg_43 & MP0_SMN_C2PMSG_43_CONTENT_MASK) >> MP0_SMN_C2PMSG_43_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_43_SET_CONTENT(mp0_smn_c2pmsg_43_reg, content) \
     mp0_smn_c2pmsg_43_reg = (mp0_smn_c2pmsg_43_reg & ~MP0_SMN_C2PMSG_43_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_43_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_43_t {
          unsigned int content                        : MP0_SMN_C2PMSG_43_CONTENT_SIZE;
     } mp0_smn_c2pmsg_43_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_43_t {
          unsigned int content                        : MP0_SMN_C2PMSG_43_CONTENT_SIZE;
     } mp0_smn_c2pmsg_43_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_43_t f;
} mp0_smn_c2pmsg_43_u;


/*
 * MP0_SMN_C2PMSG_44 struct
 */

#define MP0_SMN_C2PMSG_44_REG_SIZE     32
#define MP0_SMN_C2PMSG_44_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_44_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_44_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_44_MASK \
     (MP0_SMN_C2PMSG_44_CONTENT_MASK)

#define MP0_SMN_C2PMSG_44_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_44_GET_CONTENT(mp0_smn_c2pmsg_44) \
     ((mp0_smn_c2pmsg_44 & MP0_SMN_C2PMSG_44_CONTENT_MASK) >> MP0_SMN_C2PMSG_44_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_44_SET_CONTENT(mp0_smn_c2pmsg_44_reg, content) \
     mp0_smn_c2pmsg_44_reg = (mp0_smn_c2pmsg_44_reg & ~MP0_SMN_C2PMSG_44_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_44_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_44_t {
          unsigned int content                        : MP0_SMN_C2PMSG_44_CONTENT_SIZE;
     } mp0_smn_c2pmsg_44_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_44_t {
          unsigned int content                        : MP0_SMN_C2PMSG_44_CONTENT_SIZE;
     } mp0_smn_c2pmsg_44_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_44_t f;
} mp0_smn_c2pmsg_44_u;


/*
 * MP0_SMN_C2PMSG_45 struct
 */

#define MP0_SMN_C2PMSG_45_REG_SIZE     32
#define MP0_SMN_C2PMSG_45_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_45_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_45_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_45_MASK \
     (MP0_SMN_C2PMSG_45_CONTENT_MASK)

#define MP0_SMN_C2PMSG_45_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_45_GET_CONTENT(mp0_smn_c2pmsg_45) \
     ((mp0_smn_c2pmsg_45 & MP0_SMN_C2PMSG_45_CONTENT_MASK) >> MP0_SMN_C2PMSG_45_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_45_SET_CONTENT(mp0_smn_c2pmsg_45_reg, content) \
     mp0_smn_c2pmsg_45_reg = (mp0_smn_c2pmsg_45_reg & ~MP0_SMN_C2PMSG_45_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_45_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_45_t {
          unsigned int content                        : MP0_SMN_C2PMSG_45_CONTENT_SIZE;
     } mp0_smn_c2pmsg_45_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_45_t {
          unsigned int content                        : MP0_SMN_C2PMSG_45_CONTENT_SIZE;
     } mp0_smn_c2pmsg_45_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_45_t f;
} mp0_smn_c2pmsg_45_u;


/*
 * MP0_SMN_C2PMSG_46 struct
 */

#define MP0_SMN_C2PMSG_46_REG_SIZE     32
#define MP0_SMN_C2PMSG_46_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_46_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_46_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_46_MASK \
     (MP0_SMN_C2PMSG_46_CONTENT_MASK)

#define MP0_SMN_C2PMSG_46_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_46_GET_CONTENT(mp0_smn_c2pmsg_46) \
     ((mp0_smn_c2pmsg_46 & MP0_SMN_C2PMSG_46_CONTENT_MASK) >> MP0_SMN_C2PMSG_46_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_46_SET_CONTENT(mp0_smn_c2pmsg_46_reg, content) \
     mp0_smn_c2pmsg_46_reg = (mp0_smn_c2pmsg_46_reg & ~MP0_SMN_C2PMSG_46_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_46_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_46_t {
          unsigned int content                        : MP0_SMN_C2PMSG_46_CONTENT_SIZE;
     } mp0_smn_c2pmsg_46_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_46_t {
          unsigned int content                        : MP0_SMN_C2PMSG_46_CONTENT_SIZE;
     } mp0_smn_c2pmsg_46_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_46_t f;
} mp0_smn_c2pmsg_46_u;


/*
 * MP0_SMN_C2PMSG_47 struct
 */

#define MP0_SMN_C2PMSG_47_REG_SIZE     32
#define MP0_SMN_C2PMSG_47_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_47_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_47_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_47_MASK \
     (MP0_SMN_C2PMSG_47_CONTENT_MASK)

#define MP0_SMN_C2PMSG_47_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_47_GET_CONTENT(mp0_smn_c2pmsg_47) \
     ((mp0_smn_c2pmsg_47 & MP0_SMN_C2PMSG_47_CONTENT_MASK) >> MP0_SMN_C2PMSG_47_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_47_SET_CONTENT(mp0_smn_c2pmsg_47_reg, content) \
     mp0_smn_c2pmsg_47_reg = (mp0_smn_c2pmsg_47_reg & ~MP0_SMN_C2PMSG_47_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_47_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_47_t {
          unsigned int content                        : MP0_SMN_C2PMSG_47_CONTENT_SIZE;
     } mp0_smn_c2pmsg_47_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_47_t {
          unsigned int content                        : MP0_SMN_C2PMSG_47_CONTENT_SIZE;
     } mp0_smn_c2pmsg_47_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_47_t f;
} mp0_smn_c2pmsg_47_u;


/*
 * MP0_SMN_C2PMSG_48 struct
 */

#define MP0_SMN_C2PMSG_48_REG_SIZE     32
#define MP0_SMN_C2PMSG_48_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_48_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_48_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_48_MASK \
     (MP0_SMN_C2PMSG_48_CONTENT_MASK)

#define MP0_SMN_C2PMSG_48_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_48_GET_CONTENT(mp0_smn_c2pmsg_48) \
     ((mp0_smn_c2pmsg_48 & MP0_SMN_C2PMSG_48_CONTENT_MASK) >> MP0_SMN_C2PMSG_48_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_48_SET_CONTENT(mp0_smn_c2pmsg_48_reg, content) \
     mp0_smn_c2pmsg_48_reg = (mp0_smn_c2pmsg_48_reg & ~MP0_SMN_C2PMSG_48_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_48_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_48_t {
          unsigned int content                        : MP0_SMN_C2PMSG_48_CONTENT_SIZE;
     } mp0_smn_c2pmsg_48_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_48_t {
          unsigned int content                        : MP0_SMN_C2PMSG_48_CONTENT_SIZE;
     } mp0_smn_c2pmsg_48_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_48_t f;
} mp0_smn_c2pmsg_48_u;


/*
 * MP0_SMN_C2PMSG_49 struct
 */

#define MP0_SMN_C2PMSG_49_REG_SIZE     32
#define MP0_SMN_C2PMSG_49_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_49_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_49_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_49_MASK \
     (MP0_SMN_C2PMSG_49_CONTENT_MASK)

#define MP0_SMN_C2PMSG_49_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_49_GET_CONTENT(mp0_smn_c2pmsg_49) \
     ((mp0_smn_c2pmsg_49 & MP0_SMN_C2PMSG_49_CONTENT_MASK) >> MP0_SMN_C2PMSG_49_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_49_SET_CONTENT(mp0_smn_c2pmsg_49_reg, content) \
     mp0_smn_c2pmsg_49_reg = (mp0_smn_c2pmsg_49_reg & ~MP0_SMN_C2PMSG_49_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_49_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_49_t {
          unsigned int content                        : MP0_SMN_C2PMSG_49_CONTENT_SIZE;
     } mp0_smn_c2pmsg_49_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_49_t {
          unsigned int content                        : MP0_SMN_C2PMSG_49_CONTENT_SIZE;
     } mp0_smn_c2pmsg_49_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_49_t f;
} mp0_smn_c2pmsg_49_u;


/*
 * MP0_SMN_C2PMSG_50 struct
 */

#define MP0_SMN_C2PMSG_50_REG_SIZE     32
#define MP0_SMN_C2PMSG_50_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_50_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_50_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_50_MASK \
     (MP0_SMN_C2PMSG_50_CONTENT_MASK)

#define MP0_SMN_C2PMSG_50_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_50_GET_CONTENT(mp0_smn_c2pmsg_50) \
     ((mp0_smn_c2pmsg_50 & MP0_SMN_C2PMSG_50_CONTENT_MASK) >> MP0_SMN_C2PMSG_50_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_50_SET_CONTENT(mp0_smn_c2pmsg_50_reg, content) \
     mp0_smn_c2pmsg_50_reg = (mp0_smn_c2pmsg_50_reg & ~MP0_SMN_C2PMSG_50_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_50_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_50_t {
          unsigned int content                        : MP0_SMN_C2PMSG_50_CONTENT_SIZE;
     } mp0_smn_c2pmsg_50_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_50_t {
          unsigned int content                        : MP0_SMN_C2PMSG_50_CONTENT_SIZE;
     } mp0_smn_c2pmsg_50_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_50_t f;
} mp0_smn_c2pmsg_50_u;


/*
 * MP0_SMN_C2PMSG_51 struct
 */

#define MP0_SMN_C2PMSG_51_REG_SIZE     32
#define MP0_SMN_C2PMSG_51_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_51_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_51_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_51_MASK \
     (MP0_SMN_C2PMSG_51_CONTENT_MASK)

#define MP0_SMN_C2PMSG_51_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_51_GET_CONTENT(mp0_smn_c2pmsg_51) \
     ((mp0_smn_c2pmsg_51 & MP0_SMN_C2PMSG_51_CONTENT_MASK) >> MP0_SMN_C2PMSG_51_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_51_SET_CONTENT(mp0_smn_c2pmsg_51_reg, content) \
     mp0_smn_c2pmsg_51_reg = (mp0_smn_c2pmsg_51_reg & ~MP0_SMN_C2PMSG_51_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_51_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_51_t {
          unsigned int content                        : MP0_SMN_C2PMSG_51_CONTENT_SIZE;
     } mp0_smn_c2pmsg_51_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_51_t {
          unsigned int content                        : MP0_SMN_C2PMSG_51_CONTENT_SIZE;
     } mp0_smn_c2pmsg_51_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_51_t f;
} mp0_smn_c2pmsg_51_u;


/*
 * MP0_SMN_C2PMSG_52 struct
 */

#define MP0_SMN_C2PMSG_52_REG_SIZE     32
#define MP0_SMN_C2PMSG_52_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_52_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_52_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_52_MASK \
     (MP0_SMN_C2PMSG_52_CONTENT_MASK)

#define MP0_SMN_C2PMSG_52_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_52_GET_CONTENT(mp0_smn_c2pmsg_52) \
     ((mp0_smn_c2pmsg_52 & MP0_SMN_C2PMSG_52_CONTENT_MASK) >> MP0_SMN_C2PMSG_52_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_52_SET_CONTENT(mp0_smn_c2pmsg_52_reg, content) \
     mp0_smn_c2pmsg_52_reg = (mp0_smn_c2pmsg_52_reg & ~MP0_SMN_C2PMSG_52_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_52_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_52_t {
          unsigned int content                        : MP0_SMN_C2PMSG_52_CONTENT_SIZE;
     } mp0_smn_c2pmsg_52_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_52_t {
          unsigned int content                        : MP0_SMN_C2PMSG_52_CONTENT_SIZE;
     } mp0_smn_c2pmsg_52_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_52_t f;
} mp0_smn_c2pmsg_52_u;


/*
 * MP0_SMN_C2PMSG_53 struct
 */

#define MP0_SMN_C2PMSG_53_REG_SIZE     32
#define MP0_SMN_C2PMSG_53_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_53_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_53_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_53_MASK \
     (MP0_SMN_C2PMSG_53_CONTENT_MASK)

#define MP0_SMN_C2PMSG_53_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_53_GET_CONTENT(mp0_smn_c2pmsg_53) \
     ((mp0_smn_c2pmsg_53 & MP0_SMN_C2PMSG_53_CONTENT_MASK) >> MP0_SMN_C2PMSG_53_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_53_SET_CONTENT(mp0_smn_c2pmsg_53_reg, content) \
     mp0_smn_c2pmsg_53_reg = (mp0_smn_c2pmsg_53_reg & ~MP0_SMN_C2PMSG_53_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_53_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_53_t {
          unsigned int content                        : MP0_SMN_C2PMSG_53_CONTENT_SIZE;
     } mp0_smn_c2pmsg_53_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_53_t {
          unsigned int content                        : MP0_SMN_C2PMSG_53_CONTENT_SIZE;
     } mp0_smn_c2pmsg_53_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_53_t f;
} mp0_smn_c2pmsg_53_u;


/*
 * MP0_SMN_C2PMSG_54 struct
 */

#define MP0_SMN_C2PMSG_54_REG_SIZE     32
#define MP0_SMN_C2PMSG_54_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_54_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_54_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_54_MASK \
     (MP0_SMN_C2PMSG_54_CONTENT_MASK)

#define MP0_SMN_C2PMSG_54_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_54_GET_CONTENT(mp0_smn_c2pmsg_54) \
     ((mp0_smn_c2pmsg_54 & MP0_SMN_C2PMSG_54_CONTENT_MASK) >> MP0_SMN_C2PMSG_54_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_54_SET_CONTENT(mp0_smn_c2pmsg_54_reg, content) \
     mp0_smn_c2pmsg_54_reg = (mp0_smn_c2pmsg_54_reg & ~MP0_SMN_C2PMSG_54_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_54_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_54_t {
          unsigned int content                        : MP0_SMN_C2PMSG_54_CONTENT_SIZE;
     } mp0_smn_c2pmsg_54_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_54_t {
          unsigned int content                        : MP0_SMN_C2PMSG_54_CONTENT_SIZE;
     } mp0_smn_c2pmsg_54_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_54_t f;
} mp0_smn_c2pmsg_54_u;


/*
 * MP0_SMN_C2PMSG_55 struct
 */

#define MP0_SMN_C2PMSG_55_REG_SIZE     32
#define MP0_SMN_C2PMSG_55_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_55_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_55_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_55_MASK \
     (MP0_SMN_C2PMSG_55_CONTENT_MASK)

#define MP0_SMN_C2PMSG_55_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_55_GET_CONTENT(mp0_smn_c2pmsg_55) \
     ((mp0_smn_c2pmsg_55 & MP0_SMN_C2PMSG_55_CONTENT_MASK) >> MP0_SMN_C2PMSG_55_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_55_SET_CONTENT(mp0_smn_c2pmsg_55_reg, content) \
     mp0_smn_c2pmsg_55_reg = (mp0_smn_c2pmsg_55_reg & ~MP0_SMN_C2PMSG_55_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_55_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_55_t {
          unsigned int content                        : MP0_SMN_C2PMSG_55_CONTENT_SIZE;
     } mp0_smn_c2pmsg_55_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_55_t {
          unsigned int content                        : MP0_SMN_C2PMSG_55_CONTENT_SIZE;
     } mp0_smn_c2pmsg_55_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_55_t f;
} mp0_smn_c2pmsg_55_u;


/*
 * MP0_SMN_C2PMSG_56 struct
 */

#define MP0_SMN_C2PMSG_56_REG_SIZE     32
#define MP0_SMN_C2PMSG_56_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_56_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_56_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_56_MASK \
     (MP0_SMN_C2PMSG_56_CONTENT_MASK)

#define MP0_SMN_C2PMSG_56_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_56_GET_CONTENT(mp0_smn_c2pmsg_56) \
     ((mp0_smn_c2pmsg_56 & MP0_SMN_C2PMSG_56_CONTENT_MASK) >> MP0_SMN_C2PMSG_56_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_56_SET_CONTENT(mp0_smn_c2pmsg_56_reg, content) \
     mp0_smn_c2pmsg_56_reg = (mp0_smn_c2pmsg_56_reg & ~MP0_SMN_C2PMSG_56_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_56_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_56_t {
          unsigned int content                        : MP0_SMN_C2PMSG_56_CONTENT_SIZE;
     } mp0_smn_c2pmsg_56_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_56_t {
          unsigned int content                        : MP0_SMN_C2PMSG_56_CONTENT_SIZE;
     } mp0_smn_c2pmsg_56_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_56_t f;
} mp0_smn_c2pmsg_56_u;


/*
 * MP0_SMN_C2PMSG_57 struct
 */

#define MP0_SMN_C2PMSG_57_REG_SIZE     32
#define MP0_SMN_C2PMSG_57_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_57_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_57_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_57_MASK \
     (MP0_SMN_C2PMSG_57_CONTENT_MASK)

#define MP0_SMN_C2PMSG_57_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_57_GET_CONTENT(mp0_smn_c2pmsg_57) \
     ((mp0_smn_c2pmsg_57 & MP0_SMN_C2PMSG_57_CONTENT_MASK) >> MP0_SMN_C2PMSG_57_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_57_SET_CONTENT(mp0_smn_c2pmsg_57_reg, content) \
     mp0_smn_c2pmsg_57_reg = (mp0_smn_c2pmsg_57_reg & ~MP0_SMN_C2PMSG_57_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_57_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_57_t {
          unsigned int content                        : MP0_SMN_C2PMSG_57_CONTENT_SIZE;
     } mp0_smn_c2pmsg_57_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_57_t {
          unsigned int content                        : MP0_SMN_C2PMSG_57_CONTENT_SIZE;
     } mp0_smn_c2pmsg_57_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_57_t f;
} mp0_smn_c2pmsg_57_u;


/*
 * MP0_SMN_C2PMSG_58 struct
 */

#define MP0_SMN_C2PMSG_58_REG_SIZE     32
#define MP0_SMN_C2PMSG_58_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_58_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_58_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_58_MASK \
     (MP0_SMN_C2PMSG_58_CONTENT_MASK)

#define MP0_SMN_C2PMSG_58_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_58_GET_CONTENT(mp0_smn_c2pmsg_58) \
     ((mp0_smn_c2pmsg_58 & MP0_SMN_C2PMSG_58_CONTENT_MASK) >> MP0_SMN_C2PMSG_58_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_58_SET_CONTENT(mp0_smn_c2pmsg_58_reg, content) \
     mp0_smn_c2pmsg_58_reg = (mp0_smn_c2pmsg_58_reg & ~MP0_SMN_C2PMSG_58_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_58_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_58_t {
          unsigned int content                        : MP0_SMN_C2PMSG_58_CONTENT_SIZE;
     } mp0_smn_c2pmsg_58_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_58_t {
          unsigned int content                        : MP0_SMN_C2PMSG_58_CONTENT_SIZE;
     } mp0_smn_c2pmsg_58_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_58_t f;
} mp0_smn_c2pmsg_58_u;


/*
 * MP0_SMN_C2PMSG_59 struct
 */

#define MP0_SMN_C2PMSG_59_REG_SIZE     32
#define MP0_SMN_C2PMSG_59_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_59_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_59_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_59_MASK \
     (MP0_SMN_C2PMSG_59_CONTENT_MASK)

#define MP0_SMN_C2PMSG_59_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_59_GET_CONTENT(mp0_smn_c2pmsg_59) \
     ((mp0_smn_c2pmsg_59 & MP0_SMN_C2PMSG_59_CONTENT_MASK) >> MP0_SMN_C2PMSG_59_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_59_SET_CONTENT(mp0_smn_c2pmsg_59_reg, content) \
     mp0_smn_c2pmsg_59_reg = (mp0_smn_c2pmsg_59_reg & ~MP0_SMN_C2PMSG_59_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_59_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_59_t {
          unsigned int content                        : MP0_SMN_C2PMSG_59_CONTENT_SIZE;
     } mp0_smn_c2pmsg_59_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_59_t {
          unsigned int content                        : MP0_SMN_C2PMSG_59_CONTENT_SIZE;
     } mp0_smn_c2pmsg_59_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_59_t f;
} mp0_smn_c2pmsg_59_u;


/*
 * MP0_SMN_C2PMSG_60 struct
 */

#define MP0_SMN_C2PMSG_60_REG_SIZE     32
#define MP0_SMN_C2PMSG_60_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_60_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_60_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_60_MASK \
     (MP0_SMN_C2PMSG_60_CONTENT_MASK)

#define MP0_SMN_C2PMSG_60_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_60_GET_CONTENT(mp0_smn_c2pmsg_60) \
     ((mp0_smn_c2pmsg_60 & MP0_SMN_C2PMSG_60_CONTENT_MASK) >> MP0_SMN_C2PMSG_60_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_60_SET_CONTENT(mp0_smn_c2pmsg_60_reg, content) \
     mp0_smn_c2pmsg_60_reg = (mp0_smn_c2pmsg_60_reg & ~MP0_SMN_C2PMSG_60_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_60_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_60_t {
          unsigned int content                        : MP0_SMN_C2PMSG_60_CONTENT_SIZE;
     } mp0_smn_c2pmsg_60_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_60_t {
          unsigned int content                        : MP0_SMN_C2PMSG_60_CONTENT_SIZE;
     } mp0_smn_c2pmsg_60_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_60_t f;
} mp0_smn_c2pmsg_60_u;


/*
 * MP0_SMN_C2PMSG_61 struct
 */

#define MP0_SMN_C2PMSG_61_REG_SIZE     32
#define MP0_SMN_C2PMSG_61_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_61_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_61_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_61_MASK \
     (MP0_SMN_C2PMSG_61_CONTENT_MASK)

#define MP0_SMN_C2PMSG_61_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_61_GET_CONTENT(mp0_smn_c2pmsg_61) \
     ((mp0_smn_c2pmsg_61 & MP0_SMN_C2PMSG_61_CONTENT_MASK) >> MP0_SMN_C2PMSG_61_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_61_SET_CONTENT(mp0_smn_c2pmsg_61_reg, content) \
     mp0_smn_c2pmsg_61_reg = (mp0_smn_c2pmsg_61_reg & ~MP0_SMN_C2PMSG_61_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_61_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_61_t {
          unsigned int content                        : MP0_SMN_C2PMSG_61_CONTENT_SIZE;
     } mp0_smn_c2pmsg_61_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_61_t {
          unsigned int content                        : MP0_SMN_C2PMSG_61_CONTENT_SIZE;
     } mp0_smn_c2pmsg_61_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_61_t f;
} mp0_smn_c2pmsg_61_u;


/*
 * MP0_SMN_C2PMSG_62 struct
 */

#define MP0_SMN_C2PMSG_62_REG_SIZE     32
#define MP0_SMN_C2PMSG_62_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_62_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_62_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_62_MASK \
     (MP0_SMN_C2PMSG_62_CONTENT_MASK)

#define MP0_SMN_C2PMSG_62_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_62_GET_CONTENT(mp0_smn_c2pmsg_62) \
     ((mp0_smn_c2pmsg_62 & MP0_SMN_C2PMSG_62_CONTENT_MASK) >> MP0_SMN_C2PMSG_62_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_62_SET_CONTENT(mp0_smn_c2pmsg_62_reg, content) \
     mp0_smn_c2pmsg_62_reg = (mp0_smn_c2pmsg_62_reg & ~MP0_SMN_C2PMSG_62_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_62_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_62_t {
          unsigned int content                        : MP0_SMN_C2PMSG_62_CONTENT_SIZE;
     } mp0_smn_c2pmsg_62_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_62_t {
          unsigned int content                        : MP0_SMN_C2PMSG_62_CONTENT_SIZE;
     } mp0_smn_c2pmsg_62_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_62_t f;
} mp0_smn_c2pmsg_62_u;


/*
 * MP0_SMN_C2PMSG_63 struct
 */

#define MP0_SMN_C2PMSG_63_REG_SIZE     32
#define MP0_SMN_C2PMSG_63_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_63_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_63_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_63_MASK \
     (MP0_SMN_C2PMSG_63_CONTENT_MASK)

#define MP0_SMN_C2PMSG_63_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_63_GET_CONTENT(mp0_smn_c2pmsg_63) \
     ((mp0_smn_c2pmsg_63 & MP0_SMN_C2PMSG_63_CONTENT_MASK) >> MP0_SMN_C2PMSG_63_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_63_SET_CONTENT(mp0_smn_c2pmsg_63_reg, content) \
     mp0_smn_c2pmsg_63_reg = (mp0_smn_c2pmsg_63_reg & ~MP0_SMN_C2PMSG_63_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_63_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_63_t {
          unsigned int content                        : MP0_SMN_C2PMSG_63_CONTENT_SIZE;
     } mp0_smn_c2pmsg_63_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_63_t {
          unsigned int content                        : MP0_SMN_C2PMSG_63_CONTENT_SIZE;
     } mp0_smn_c2pmsg_63_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_63_t f;
} mp0_smn_c2pmsg_63_u;


/*
 * MP0_SMN_C2PMSG_64 struct
 */

#define MP0_SMN_C2PMSG_64_REG_SIZE     32
#define MP0_SMN_C2PMSG_64_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_64_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_64_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_64_MASK \
     (MP0_SMN_C2PMSG_64_CONTENT_MASK)

#define MP0_SMN_C2PMSG_64_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_64_GET_CONTENT(mp0_smn_c2pmsg_64) \
     ((mp0_smn_c2pmsg_64 & MP0_SMN_C2PMSG_64_CONTENT_MASK) >> MP0_SMN_C2PMSG_64_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_64_SET_CONTENT(mp0_smn_c2pmsg_64_reg, content) \
     mp0_smn_c2pmsg_64_reg = (mp0_smn_c2pmsg_64_reg & ~MP0_SMN_C2PMSG_64_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_64_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_64_t {
          unsigned int content                        : MP0_SMN_C2PMSG_64_CONTENT_SIZE;
     } mp0_smn_c2pmsg_64_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_64_t {
          unsigned int content                        : MP0_SMN_C2PMSG_64_CONTENT_SIZE;
     } mp0_smn_c2pmsg_64_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_64_t f;
} mp0_smn_c2pmsg_64_u;


/*
 * MP0_SMN_C2PMSG_65 struct
 */

#define MP0_SMN_C2PMSG_65_REG_SIZE     32
#define MP0_SMN_C2PMSG_65_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_65_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_65_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_65_MASK \
     (MP0_SMN_C2PMSG_65_CONTENT_MASK)

#define MP0_SMN_C2PMSG_65_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_65_GET_CONTENT(mp0_smn_c2pmsg_65) \
     ((mp0_smn_c2pmsg_65 & MP0_SMN_C2PMSG_65_CONTENT_MASK) >> MP0_SMN_C2PMSG_65_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_65_SET_CONTENT(mp0_smn_c2pmsg_65_reg, content) \
     mp0_smn_c2pmsg_65_reg = (mp0_smn_c2pmsg_65_reg & ~MP0_SMN_C2PMSG_65_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_65_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_65_t {
          unsigned int content                        : MP0_SMN_C2PMSG_65_CONTENT_SIZE;
     } mp0_smn_c2pmsg_65_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_65_t {
          unsigned int content                        : MP0_SMN_C2PMSG_65_CONTENT_SIZE;
     } mp0_smn_c2pmsg_65_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_65_t f;
} mp0_smn_c2pmsg_65_u;


/*
 * MP0_SMN_C2PMSG_66 struct
 */

#define MP0_SMN_C2PMSG_66_REG_SIZE     32
#define MP0_SMN_C2PMSG_66_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_66_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_66_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_66_MASK \
     (MP0_SMN_C2PMSG_66_CONTENT_MASK)

#define MP0_SMN_C2PMSG_66_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_66_GET_CONTENT(mp0_smn_c2pmsg_66) \
     ((mp0_smn_c2pmsg_66 & MP0_SMN_C2PMSG_66_CONTENT_MASK) >> MP0_SMN_C2PMSG_66_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_66_SET_CONTENT(mp0_smn_c2pmsg_66_reg, content) \
     mp0_smn_c2pmsg_66_reg = (mp0_smn_c2pmsg_66_reg & ~MP0_SMN_C2PMSG_66_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_66_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_66_t {
          unsigned int content                        : MP0_SMN_C2PMSG_66_CONTENT_SIZE;
     } mp0_smn_c2pmsg_66_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_66_t {
          unsigned int content                        : MP0_SMN_C2PMSG_66_CONTENT_SIZE;
     } mp0_smn_c2pmsg_66_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_66_t f;
} mp0_smn_c2pmsg_66_u;


/*
 * MP0_SMN_C2PMSG_67 struct
 */

#define MP0_SMN_C2PMSG_67_REG_SIZE     32
#define MP0_SMN_C2PMSG_67_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_67_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_67_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_67_MASK \
     (MP0_SMN_C2PMSG_67_CONTENT_MASK)

#define MP0_SMN_C2PMSG_67_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_67_GET_CONTENT(mp0_smn_c2pmsg_67) \
     ((mp0_smn_c2pmsg_67 & MP0_SMN_C2PMSG_67_CONTENT_MASK) >> MP0_SMN_C2PMSG_67_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_67_SET_CONTENT(mp0_smn_c2pmsg_67_reg, content) \
     mp0_smn_c2pmsg_67_reg = (mp0_smn_c2pmsg_67_reg & ~MP0_SMN_C2PMSG_67_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_67_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_67_t {
          unsigned int content                        : MP0_SMN_C2PMSG_67_CONTENT_SIZE;
     } mp0_smn_c2pmsg_67_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_67_t {
          unsigned int content                        : MP0_SMN_C2PMSG_67_CONTENT_SIZE;
     } mp0_smn_c2pmsg_67_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_67_t f;
} mp0_smn_c2pmsg_67_u;


/*
 * MP0_SMN_C2PMSG_68 struct
 */

#define MP0_SMN_C2PMSG_68_REG_SIZE     32
#define MP0_SMN_C2PMSG_68_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_68_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_68_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_68_MASK \
     (MP0_SMN_C2PMSG_68_CONTENT_MASK)

#define MP0_SMN_C2PMSG_68_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_68_GET_CONTENT(mp0_smn_c2pmsg_68) \
     ((mp0_smn_c2pmsg_68 & MP0_SMN_C2PMSG_68_CONTENT_MASK) >> MP0_SMN_C2PMSG_68_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_68_SET_CONTENT(mp0_smn_c2pmsg_68_reg, content) \
     mp0_smn_c2pmsg_68_reg = (mp0_smn_c2pmsg_68_reg & ~MP0_SMN_C2PMSG_68_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_68_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_68_t {
          unsigned int content                        : MP0_SMN_C2PMSG_68_CONTENT_SIZE;
     } mp0_smn_c2pmsg_68_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_68_t {
          unsigned int content                        : MP0_SMN_C2PMSG_68_CONTENT_SIZE;
     } mp0_smn_c2pmsg_68_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_68_t f;
} mp0_smn_c2pmsg_68_u;


/*
 * MP0_SMN_C2PMSG_69 struct
 */

#define MP0_SMN_C2PMSG_69_REG_SIZE     32
#define MP0_SMN_C2PMSG_69_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_69_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_69_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_69_MASK \
     (MP0_SMN_C2PMSG_69_CONTENT_MASK)

#define MP0_SMN_C2PMSG_69_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_69_GET_CONTENT(mp0_smn_c2pmsg_69) \
     ((mp0_smn_c2pmsg_69 & MP0_SMN_C2PMSG_69_CONTENT_MASK) >> MP0_SMN_C2PMSG_69_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_69_SET_CONTENT(mp0_smn_c2pmsg_69_reg, content) \
     mp0_smn_c2pmsg_69_reg = (mp0_smn_c2pmsg_69_reg & ~MP0_SMN_C2PMSG_69_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_69_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_69_t {
          unsigned int content                        : MP0_SMN_C2PMSG_69_CONTENT_SIZE;
     } mp0_smn_c2pmsg_69_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_69_t {
          unsigned int content                        : MP0_SMN_C2PMSG_69_CONTENT_SIZE;
     } mp0_smn_c2pmsg_69_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_69_t f;
} mp0_smn_c2pmsg_69_u;


/*
 * MP0_SMN_C2PMSG_70 struct
 */

#define MP0_SMN_C2PMSG_70_REG_SIZE     32
#define MP0_SMN_C2PMSG_70_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_70_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_70_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_70_MASK \
     (MP0_SMN_C2PMSG_70_CONTENT_MASK)

#define MP0_SMN_C2PMSG_70_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_70_GET_CONTENT(mp0_smn_c2pmsg_70) \
     ((mp0_smn_c2pmsg_70 & MP0_SMN_C2PMSG_70_CONTENT_MASK) >> MP0_SMN_C2PMSG_70_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_70_SET_CONTENT(mp0_smn_c2pmsg_70_reg, content) \
     mp0_smn_c2pmsg_70_reg = (mp0_smn_c2pmsg_70_reg & ~MP0_SMN_C2PMSG_70_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_70_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_70_t {
          unsigned int content                        : MP0_SMN_C2PMSG_70_CONTENT_SIZE;
     } mp0_smn_c2pmsg_70_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_70_t {
          unsigned int content                        : MP0_SMN_C2PMSG_70_CONTENT_SIZE;
     } mp0_smn_c2pmsg_70_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_70_t f;
} mp0_smn_c2pmsg_70_u;


/*
 * MP0_SMN_C2PMSG_71 struct
 */

#define MP0_SMN_C2PMSG_71_REG_SIZE     32
#define MP0_SMN_C2PMSG_71_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_71_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_71_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_71_MASK \
     (MP0_SMN_C2PMSG_71_CONTENT_MASK)

#define MP0_SMN_C2PMSG_71_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_71_GET_CONTENT(mp0_smn_c2pmsg_71) \
     ((mp0_smn_c2pmsg_71 & MP0_SMN_C2PMSG_71_CONTENT_MASK) >> MP0_SMN_C2PMSG_71_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_71_SET_CONTENT(mp0_smn_c2pmsg_71_reg, content) \
     mp0_smn_c2pmsg_71_reg = (mp0_smn_c2pmsg_71_reg & ~MP0_SMN_C2PMSG_71_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_71_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_71_t {
          unsigned int content                        : MP0_SMN_C2PMSG_71_CONTENT_SIZE;
     } mp0_smn_c2pmsg_71_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_71_t {
          unsigned int content                        : MP0_SMN_C2PMSG_71_CONTENT_SIZE;
     } mp0_smn_c2pmsg_71_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_71_t f;
} mp0_smn_c2pmsg_71_u;


/*
 * MP0_SMN_C2PMSG_72 struct
 */

#define MP0_SMN_C2PMSG_72_REG_SIZE     32
#define MP0_SMN_C2PMSG_72_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_72_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_72_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_72_MASK \
     (MP0_SMN_C2PMSG_72_CONTENT_MASK)

#define MP0_SMN_C2PMSG_72_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_72_GET_CONTENT(mp0_smn_c2pmsg_72) \
     ((mp0_smn_c2pmsg_72 & MP0_SMN_C2PMSG_72_CONTENT_MASK) >> MP0_SMN_C2PMSG_72_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_72_SET_CONTENT(mp0_smn_c2pmsg_72_reg, content) \
     mp0_smn_c2pmsg_72_reg = (mp0_smn_c2pmsg_72_reg & ~MP0_SMN_C2PMSG_72_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_72_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_72_t {
          unsigned int content                        : MP0_SMN_C2PMSG_72_CONTENT_SIZE;
     } mp0_smn_c2pmsg_72_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_72_t {
          unsigned int content                        : MP0_SMN_C2PMSG_72_CONTENT_SIZE;
     } mp0_smn_c2pmsg_72_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_72_t f;
} mp0_smn_c2pmsg_72_u;


/*
 * MP0_SMN_C2PMSG_73 struct
 */

#define MP0_SMN_C2PMSG_73_REG_SIZE     32
#define MP0_SMN_C2PMSG_73_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_73_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_73_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_73_MASK \
     (MP0_SMN_C2PMSG_73_CONTENT_MASK)

#define MP0_SMN_C2PMSG_73_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_73_GET_CONTENT(mp0_smn_c2pmsg_73) \
     ((mp0_smn_c2pmsg_73 & MP0_SMN_C2PMSG_73_CONTENT_MASK) >> MP0_SMN_C2PMSG_73_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_73_SET_CONTENT(mp0_smn_c2pmsg_73_reg, content) \
     mp0_smn_c2pmsg_73_reg = (mp0_smn_c2pmsg_73_reg & ~MP0_SMN_C2PMSG_73_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_73_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_73_t {
          unsigned int content                        : MP0_SMN_C2PMSG_73_CONTENT_SIZE;
     } mp0_smn_c2pmsg_73_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_73_t {
          unsigned int content                        : MP0_SMN_C2PMSG_73_CONTENT_SIZE;
     } mp0_smn_c2pmsg_73_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_73_t f;
} mp0_smn_c2pmsg_73_u;


/*
 * MP0_SMN_C2PMSG_74 struct
 */

#define MP0_SMN_C2PMSG_74_REG_SIZE     32
#define MP0_SMN_C2PMSG_74_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_74_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_74_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_74_MASK \
     (MP0_SMN_C2PMSG_74_CONTENT_MASK)

#define MP0_SMN_C2PMSG_74_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_74_GET_CONTENT(mp0_smn_c2pmsg_74) \
     ((mp0_smn_c2pmsg_74 & MP0_SMN_C2PMSG_74_CONTENT_MASK) >> MP0_SMN_C2PMSG_74_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_74_SET_CONTENT(mp0_smn_c2pmsg_74_reg, content) \
     mp0_smn_c2pmsg_74_reg = (mp0_smn_c2pmsg_74_reg & ~MP0_SMN_C2PMSG_74_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_74_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_74_t {
          unsigned int content                        : MP0_SMN_C2PMSG_74_CONTENT_SIZE;
     } mp0_smn_c2pmsg_74_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_74_t {
          unsigned int content                        : MP0_SMN_C2PMSG_74_CONTENT_SIZE;
     } mp0_smn_c2pmsg_74_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_74_t f;
} mp0_smn_c2pmsg_74_u;


/*
 * MP0_SMN_C2PMSG_75 struct
 */

#define MP0_SMN_C2PMSG_75_REG_SIZE     32
#define MP0_SMN_C2PMSG_75_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_75_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_75_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_75_MASK \
     (MP0_SMN_C2PMSG_75_CONTENT_MASK)

#define MP0_SMN_C2PMSG_75_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_75_GET_CONTENT(mp0_smn_c2pmsg_75) \
     ((mp0_smn_c2pmsg_75 & MP0_SMN_C2PMSG_75_CONTENT_MASK) >> MP0_SMN_C2PMSG_75_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_75_SET_CONTENT(mp0_smn_c2pmsg_75_reg, content) \
     mp0_smn_c2pmsg_75_reg = (mp0_smn_c2pmsg_75_reg & ~MP0_SMN_C2PMSG_75_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_75_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_75_t {
          unsigned int content                        : MP0_SMN_C2PMSG_75_CONTENT_SIZE;
     } mp0_smn_c2pmsg_75_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_75_t {
          unsigned int content                        : MP0_SMN_C2PMSG_75_CONTENT_SIZE;
     } mp0_smn_c2pmsg_75_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_75_t f;
} mp0_smn_c2pmsg_75_u;


/*
 * MP0_SMN_C2PMSG_76 struct
 */

#define MP0_SMN_C2PMSG_76_REG_SIZE     32
#define MP0_SMN_C2PMSG_76_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_76_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_76_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_76_MASK \
     (MP0_SMN_C2PMSG_76_CONTENT_MASK)

#define MP0_SMN_C2PMSG_76_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_76_GET_CONTENT(mp0_smn_c2pmsg_76) \
     ((mp0_smn_c2pmsg_76 & MP0_SMN_C2PMSG_76_CONTENT_MASK) >> MP0_SMN_C2PMSG_76_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_76_SET_CONTENT(mp0_smn_c2pmsg_76_reg, content) \
     mp0_smn_c2pmsg_76_reg = (mp0_smn_c2pmsg_76_reg & ~MP0_SMN_C2PMSG_76_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_76_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_76_t {
          unsigned int content                        : MP0_SMN_C2PMSG_76_CONTENT_SIZE;
     } mp0_smn_c2pmsg_76_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_76_t {
          unsigned int content                        : MP0_SMN_C2PMSG_76_CONTENT_SIZE;
     } mp0_smn_c2pmsg_76_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_76_t f;
} mp0_smn_c2pmsg_76_u;


/*
 * MP0_SMN_C2PMSG_77 struct
 */

#define MP0_SMN_C2PMSG_77_REG_SIZE     32
#define MP0_SMN_C2PMSG_77_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_77_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_77_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_77_MASK \
     (MP0_SMN_C2PMSG_77_CONTENT_MASK)

#define MP0_SMN_C2PMSG_77_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_77_GET_CONTENT(mp0_smn_c2pmsg_77) \
     ((mp0_smn_c2pmsg_77 & MP0_SMN_C2PMSG_77_CONTENT_MASK) >> MP0_SMN_C2PMSG_77_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_77_SET_CONTENT(mp0_smn_c2pmsg_77_reg, content) \
     mp0_smn_c2pmsg_77_reg = (mp0_smn_c2pmsg_77_reg & ~MP0_SMN_C2PMSG_77_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_77_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_77_t {
          unsigned int content                        : MP0_SMN_C2PMSG_77_CONTENT_SIZE;
     } mp0_smn_c2pmsg_77_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_77_t {
          unsigned int content                        : MP0_SMN_C2PMSG_77_CONTENT_SIZE;
     } mp0_smn_c2pmsg_77_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_77_t f;
} mp0_smn_c2pmsg_77_u;


/*
 * MP0_SMN_C2PMSG_78 struct
 */

#define MP0_SMN_C2PMSG_78_REG_SIZE     32
#define MP0_SMN_C2PMSG_78_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_78_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_78_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_78_MASK \
     (MP0_SMN_C2PMSG_78_CONTENT_MASK)

#define MP0_SMN_C2PMSG_78_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_78_GET_CONTENT(mp0_smn_c2pmsg_78) \
     ((mp0_smn_c2pmsg_78 & MP0_SMN_C2PMSG_78_CONTENT_MASK) >> MP0_SMN_C2PMSG_78_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_78_SET_CONTENT(mp0_smn_c2pmsg_78_reg, content) \
     mp0_smn_c2pmsg_78_reg = (mp0_smn_c2pmsg_78_reg & ~MP0_SMN_C2PMSG_78_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_78_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_78_t {
          unsigned int content                        : MP0_SMN_C2PMSG_78_CONTENT_SIZE;
     } mp0_smn_c2pmsg_78_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_78_t {
          unsigned int content                        : MP0_SMN_C2PMSG_78_CONTENT_SIZE;
     } mp0_smn_c2pmsg_78_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_78_t f;
} mp0_smn_c2pmsg_78_u;


/*
 * MP0_SMN_C2PMSG_79 struct
 */

#define MP0_SMN_C2PMSG_79_REG_SIZE     32
#define MP0_SMN_C2PMSG_79_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_79_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_79_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_79_MASK \
     (MP0_SMN_C2PMSG_79_CONTENT_MASK)

#define MP0_SMN_C2PMSG_79_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_79_GET_CONTENT(mp0_smn_c2pmsg_79) \
     ((mp0_smn_c2pmsg_79 & MP0_SMN_C2PMSG_79_CONTENT_MASK) >> MP0_SMN_C2PMSG_79_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_79_SET_CONTENT(mp0_smn_c2pmsg_79_reg, content) \
     mp0_smn_c2pmsg_79_reg = (mp0_smn_c2pmsg_79_reg & ~MP0_SMN_C2PMSG_79_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_79_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_79_t {
          unsigned int content                        : MP0_SMN_C2PMSG_79_CONTENT_SIZE;
     } mp0_smn_c2pmsg_79_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_79_t {
          unsigned int content                        : MP0_SMN_C2PMSG_79_CONTENT_SIZE;
     } mp0_smn_c2pmsg_79_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_79_t f;
} mp0_smn_c2pmsg_79_u;


/*
 * MP0_SMN_C2PMSG_80 struct
 */

#define MP0_SMN_C2PMSG_80_REG_SIZE     32
#define MP0_SMN_C2PMSG_80_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_80_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_80_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_80_MASK \
     (MP0_SMN_C2PMSG_80_CONTENT_MASK)

#define MP0_SMN_C2PMSG_80_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_80_GET_CONTENT(mp0_smn_c2pmsg_80) \
     ((mp0_smn_c2pmsg_80 & MP0_SMN_C2PMSG_80_CONTENT_MASK) >> MP0_SMN_C2PMSG_80_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_80_SET_CONTENT(mp0_smn_c2pmsg_80_reg, content) \
     mp0_smn_c2pmsg_80_reg = (mp0_smn_c2pmsg_80_reg & ~MP0_SMN_C2PMSG_80_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_80_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_80_t {
          unsigned int content                        : MP0_SMN_C2PMSG_80_CONTENT_SIZE;
     } mp0_smn_c2pmsg_80_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_80_t {
          unsigned int content                        : MP0_SMN_C2PMSG_80_CONTENT_SIZE;
     } mp0_smn_c2pmsg_80_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_80_t f;
} mp0_smn_c2pmsg_80_u;


/*
 * MP0_SMN_C2PMSG_81 struct
 */

#define MP0_SMN_C2PMSG_81_REG_SIZE     32
#define MP0_SMN_C2PMSG_81_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_81_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_81_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_81_MASK \
     (MP0_SMN_C2PMSG_81_CONTENT_MASK)

#define MP0_SMN_C2PMSG_81_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_81_GET_CONTENT(mp0_smn_c2pmsg_81) \
     ((mp0_smn_c2pmsg_81 & MP0_SMN_C2PMSG_81_CONTENT_MASK) >> MP0_SMN_C2PMSG_81_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_81_SET_CONTENT(mp0_smn_c2pmsg_81_reg, content) \
     mp0_smn_c2pmsg_81_reg = (mp0_smn_c2pmsg_81_reg & ~MP0_SMN_C2PMSG_81_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_81_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_81_t {
          unsigned int content                        : MP0_SMN_C2PMSG_81_CONTENT_SIZE;
     } mp0_smn_c2pmsg_81_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_81_t {
          unsigned int content                        : MP0_SMN_C2PMSG_81_CONTENT_SIZE;
     } mp0_smn_c2pmsg_81_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_81_t f;
} mp0_smn_c2pmsg_81_u;


/*
 * MP0_SMN_C2PMSG_82 struct
 */

#define MP0_SMN_C2PMSG_82_REG_SIZE     32
#define MP0_SMN_C2PMSG_82_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_82_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_82_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_82_MASK \
     (MP0_SMN_C2PMSG_82_CONTENT_MASK)

#define MP0_SMN_C2PMSG_82_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_82_GET_CONTENT(mp0_smn_c2pmsg_82) \
     ((mp0_smn_c2pmsg_82 & MP0_SMN_C2PMSG_82_CONTENT_MASK) >> MP0_SMN_C2PMSG_82_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_82_SET_CONTENT(mp0_smn_c2pmsg_82_reg, content) \
     mp0_smn_c2pmsg_82_reg = (mp0_smn_c2pmsg_82_reg & ~MP0_SMN_C2PMSG_82_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_82_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_82_t {
          unsigned int content                        : MP0_SMN_C2PMSG_82_CONTENT_SIZE;
     } mp0_smn_c2pmsg_82_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_82_t {
          unsigned int content                        : MP0_SMN_C2PMSG_82_CONTENT_SIZE;
     } mp0_smn_c2pmsg_82_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_82_t f;
} mp0_smn_c2pmsg_82_u;


/*
 * MP0_SMN_C2PMSG_83 struct
 */

#define MP0_SMN_C2PMSG_83_REG_SIZE     32
#define MP0_SMN_C2PMSG_83_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_83_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_83_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_83_MASK \
     (MP0_SMN_C2PMSG_83_CONTENT_MASK)

#define MP0_SMN_C2PMSG_83_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_83_GET_CONTENT(mp0_smn_c2pmsg_83) \
     ((mp0_smn_c2pmsg_83 & MP0_SMN_C2PMSG_83_CONTENT_MASK) >> MP0_SMN_C2PMSG_83_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_83_SET_CONTENT(mp0_smn_c2pmsg_83_reg, content) \
     mp0_smn_c2pmsg_83_reg = (mp0_smn_c2pmsg_83_reg & ~MP0_SMN_C2PMSG_83_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_83_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_83_t {
          unsigned int content                        : MP0_SMN_C2PMSG_83_CONTENT_SIZE;
     } mp0_smn_c2pmsg_83_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_83_t {
          unsigned int content                        : MP0_SMN_C2PMSG_83_CONTENT_SIZE;
     } mp0_smn_c2pmsg_83_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_83_t f;
} mp0_smn_c2pmsg_83_u;


/*
 * MP0_SMN_C2PMSG_84 struct
 */

#define MP0_SMN_C2PMSG_84_REG_SIZE     32
#define MP0_SMN_C2PMSG_84_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_84_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_84_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_84_MASK \
     (MP0_SMN_C2PMSG_84_CONTENT_MASK)

#define MP0_SMN_C2PMSG_84_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_84_GET_CONTENT(mp0_smn_c2pmsg_84) \
     ((mp0_smn_c2pmsg_84 & MP0_SMN_C2PMSG_84_CONTENT_MASK) >> MP0_SMN_C2PMSG_84_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_84_SET_CONTENT(mp0_smn_c2pmsg_84_reg, content) \
     mp0_smn_c2pmsg_84_reg = (mp0_smn_c2pmsg_84_reg & ~MP0_SMN_C2PMSG_84_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_84_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_84_t {
          unsigned int content                        : MP0_SMN_C2PMSG_84_CONTENT_SIZE;
     } mp0_smn_c2pmsg_84_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_84_t {
          unsigned int content                        : MP0_SMN_C2PMSG_84_CONTENT_SIZE;
     } mp0_smn_c2pmsg_84_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_84_t f;
} mp0_smn_c2pmsg_84_u;


/*
 * MP0_SMN_C2PMSG_85 struct
 */

#define MP0_SMN_C2PMSG_85_REG_SIZE     32
#define MP0_SMN_C2PMSG_85_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_85_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_85_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_85_MASK \
     (MP0_SMN_C2PMSG_85_CONTENT_MASK)

#define MP0_SMN_C2PMSG_85_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_85_GET_CONTENT(mp0_smn_c2pmsg_85) \
     ((mp0_smn_c2pmsg_85 & MP0_SMN_C2PMSG_85_CONTENT_MASK) >> MP0_SMN_C2PMSG_85_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_85_SET_CONTENT(mp0_smn_c2pmsg_85_reg, content) \
     mp0_smn_c2pmsg_85_reg = (mp0_smn_c2pmsg_85_reg & ~MP0_SMN_C2PMSG_85_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_85_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_85_t {
          unsigned int content                        : MP0_SMN_C2PMSG_85_CONTENT_SIZE;
     } mp0_smn_c2pmsg_85_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_85_t {
          unsigned int content                        : MP0_SMN_C2PMSG_85_CONTENT_SIZE;
     } mp0_smn_c2pmsg_85_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_85_t f;
} mp0_smn_c2pmsg_85_u;


/*
 * MP0_SMN_C2PMSG_86 struct
 */

#define MP0_SMN_C2PMSG_86_REG_SIZE     32
#define MP0_SMN_C2PMSG_86_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_86_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_86_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_86_MASK \
     (MP0_SMN_C2PMSG_86_CONTENT_MASK)

#define MP0_SMN_C2PMSG_86_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_86_GET_CONTENT(mp0_smn_c2pmsg_86) \
     ((mp0_smn_c2pmsg_86 & MP0_SMN_C2PMSG_86_CONTENT_MASK) >> MP0_SMN_C2PMSG_86_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_86_SET_CONTENT(mp0_smn_c2pmsg_86_reg, content) \
     mp0_smn_c2pmsg_86_reg = (mp0_smn_c2pmsg_86_reg & ~MP0_SMN_C2PMSG_86_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_86_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_86_t {
          unsigned int content                        : MP0_SMN_C2PMSG_86_CONTENT_SIZE;
     } mp0_smn_c2pmsg_86_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_86_t {
          unsigned int content                        : MP0_SMN_C2PMSG_86_CONTENT_SIZE;
     } mp0_smn_c2pmsg_86_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_86_t f;
} mp0_smn_c2pmsg_86_u;


/*
 * MP0_SMN_C2PMSG_87 struct
 */

#define MP0_SMN_C2PMSG_87_REG_SIZE     32
#define MP0_SMN_C2PMSG_87_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_87_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_87_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_87_MASK \
     (MP0_SMN_C2PMSG_87_CONTENT_MASK)

#define MP0_SMN_C2PMSG_87_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_87_GET_CONTENT(mp0_smn_c2pmsg_87) \
     ((mp0_smn_c2pmsg_87 & MP0_SMN_C2PMSG_87_CONTENT_MASK) >> MP0_SMN_C2PMSG_87_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_87_SET_CONTENT(mp0_smn_c2pmsg_87_reg, content) \
     mp0_smn_c2pmsg_87_reg = (mp0_smn_c2pmsg_87_reg & ~MP0_SMN_C2PMSG_87_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_87_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_87_t {
          unsigned int content                        : MP0_SMN_C2PMSG_87_CONTENT_SIZE;
     } mp0_smn_c2pmsg_87_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_87_t {
          unsigned int content                        : MP0_SMN_C2PMSG_87_CONTENT_SIZE;
     } mp0_smn_c2pmsg_87_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_87_t f;
} mp0_smn_c2pmsg_87_u;


/*
 * MP0_SMN_C2PMSG_88 struct
 */

#define MP0_SMN_C2PMSG_88_REG_SIZE     32
#define MP0_SMN_C2PMSG_88_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_88_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_88_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_88_MASK \
     (MP0_SMN_C2PMSG_88_CONTENT_MASK)

#define MP0_SMN_C2PMSG_88_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_88_GET_CONTENT(mp0_smn_c2pmsg_88) \
     ((mp0_smn_c2pmsg_88 & MP0_SMN_C2PMSG_88_CONTENT_MASK) >> MP0_SMN_C2PMSG_88_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_88_SET_CONTENT(mp0_smn_c2pmsg_88_reg, content) \
     mp0_smn_c2pmsg_88_reg = (mp0_smn_c2pmsg_88_reg & ~MP0_SMN_C2PMSG_88_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_88_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_88_t {
          unsigned int content                        : MP0_SMN_C2PMSG_88_CONTENT_SIZE;
     } mp0_smn_c2pmsg_88_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_88_t {
          unsigned int content                        : MP0_SMN_C2PMSG_88_CONTENT_SIZE;
     } mp0_smn_c2pmsg_88_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_88_t f;
} mp0_smn_c2pmsg_88_u;


/*
 * MP0_SMN_C2PMSG_89 struct
 */

#define MP0_SMN_C2PMSG_89_REG_SIZE     32
#define MP0_SMN_C2PMSG_89_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_89_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_89_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_89_MASK \
     (MP0_SMN_C2PMSG_89_CONTENT_MASK)

#define MP0_SMN_C2PMSG_89_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_89_GET_CONTENT(mp0_smn_c2pmsg_89) \
     ((mp0_smn_c2pmsg_89 & MP0_SMN_C2PMSG_89_CONTENT_MASK) >> MP0_SMN_C2PMSG_89_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_89_SET_CONTENT(mp0_smn_c2pmsg_89_reg, content) \
     mp0_smn_c2pmsg_89_reg = (mp0_smn_c2pmsg_89_reg & ~MP0_SMN_C2PMSG_89_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_89_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_89_t {
          unsigned int content                        : MP0_SMN_C2PMSG_89_CONTENT_SIZE;
     } mp0_smn_c2pmsg_89_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_89_t {
          unsigned int content                        : MP0_SMN_C2PMSG_89_CONTENT_SIZE;
     } mp0_smn_c2pmsg_89_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_89_t f;
} mp0_smn_c2pmsg_89_u;


/*
 * MP0_SMN_C2PMSG_90 struct
 */

#define MP0_SMN_C2PMSG_90_REG_SIZE     32
#define MP0_SMN_C2PMSG_90_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_90_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_90_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_90_MASK \
     (MP0_SMN_C2PMSG_90_CONTENT_MASK)

#define MP0_SMN_C2PMSG_90_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_90_GET_CONTENT(mp0_smn_c2pmsg_90) \
     ((mp0_smn_c2pmsg_90 & MP0_SMN_C2PMSG_90_CONTENT_MASK) >> MP0_SMN_C2PMSG_90_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_90_SET_CONTENT(mp0_smn_c2pmsg_90_reg, content) \
     mp0_smn_c2pmsg_90_reg = (mp0_smn_c2pmsg_90_reg & ~MP0_SMN_C2PMSG_90_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_90_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_90_t {
          unsigned int content                        : MP0_SMN_C2PMSG_90_CONTENT_SIZE;
     } mp0_smn_c2pmsg_90_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_90_t {
          unsigned int content                        : MP0_SMN_C2PMSG_90_CONTENT_SIZE;
     } mp0_smn_c2pmsg_90_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_90_t f;
} mp0_smn_c2pmsg_90_u;


/*
 * MP0_SMN_C2PMSG_91 struct
 */

#define MP0_SMN_C2PMSG_91_REG_SIZE     32
#define MP0_SMN_C2PMSG_91_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_91_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_91_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_91_MASK \
     (MP0_SMN_C2PMSG_91_CONTENT_MASK)

#define MP0_SMN_C2PMSG_91_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_91_GET_CONTENT(mp0_smn_c2pmsg_91) \
     ((mp0_smn_c2pmsg_91 & MP0_SMN_C2PMSG_91_CONTENT_MASK) >> MP0_SMN_C2PMSG_91_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_91_SET_CONTENT(mp0_smn_c2pmsg_91_reg, content) \
     mp0_smn_c2pmsg_91_reg = (mp0_smn_c2pmsg_91_reg & ~MP0_SMN_C2PMSG_91_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_91_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_91_t {
          unsigned int content                        : MP0_SMN_C2PMSG_91_CONTENT_SIZE;
     } mp0_smn_c2pmsg_91_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_91_t {
          unsigned int content                        : MP0_SMN_C2PMSG_91_CONTENT_SIZE;
     } mp0_smn_c2pmsg_91_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_91_t f;
} mp0_smn_c2pmsg_91_u;


/*
 * MP0_SMN_C2PMSG_92 struct
 */

#define MP0_SMN_C2PMSG_92_REG_SIZE     32
#define MP0_SMN_C2PMSG_92_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_92_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_92_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_92_MASK \
     (MP0_SMN_C2PMSG_92_CONTENT_MASK)

#define MP0_SMN_C2PMSG_92_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_92_GET_CONTENT(mp0_smn_c2pmsg_92) \
     ((mp0_smn_c2pmsg_92 & MP0_SMN_C2PMSG_92_CONTENT_MASK) >> MP0_SMN_C2PMSG_92_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_92_SET_CONTENT(mp0_smn_c2pmsg_92_reg, content) \
     mp0_smn_c2pmsg_92_reg = (mp0_smn_c2pmsg_92_reg & ~MP0_SMN_C2PMSG_92_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_92_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_92_t {
          unsigned int content                        : MP0_SMN_C2PMSG_92_CONTENT_SIZE;
     } mp0_smn_c2pmsg_92_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_92_t {
          unsigned int content                        : MP0_SMN_C2PMSG_92_CONTENT_SIZE;
     } mp0_smn_c2pmsg_92_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_92_t f;
} mp0_smn_c2pmsg_92_u;


/*
 * MP0_SMN_C2PMSG_93 struct
 */

#define MP0_SMN_C2PMSG_93_REG_SIZE     32
#define MP0_SMN_C2PMSG_93_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_93_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_93_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_93_MASK \
     (MP0_SMN_C2PMSG_93_CONTENT_MASK)

#define MP0_SMN_C2PMSG_93_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_93_GET_CONTENT(mp0_smn_c2pmsg_93) \
     ((mp0_smn_c2pmsg_93 & MP0_SMN_C2PMSG_93_CONTENT_MASK) >> MP0_SMN_C2PMSG_93_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_93_SET_CONTENT(mp0_smn_c2pmsg_93_reg, content) \
     mp0_smn_c2pmsg_93_reg = (mp0_smn_c2pmsg_93_reg & ~MP0_SMN_C2PMSG_93_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_93_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_93_t {
          unsigned int content                        : MP0_SMN_C2PMSG_93_CONTENT_SIZE;
     } mp0_smn_c2pmsg_93_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_93_t {
          unsigned int content                        : MP0_SMN_C2PMSG_93_CONTENT_SIZE;
     } mp0_smn_c2pmsg_93_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_93_t f;
} mp0_smn_c2pmsg_93_u;


/*
 * MP0_SMN_C2PMSG_94 struct
 */

#define MP0_SMN_C2PMSG_94_REG_SIZE     32
#define MP0_SMN_C2PMSG_94_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_94_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_94_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_94_MASK \
     (MP0_SMN_C2PMSG_94_CONTENT_MASK)

#define MP0_SMN_C2PMSG_94_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_94_GET_CONTENT(mp0_smn_c2pmsg_94) \
     ((mp0_smn_c2pmsg_94 & MP0_SMN_C2PMSG_94_CONTENT_MASK) >> MP0_SMN_C2PMSG_94_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_94_SET_CONTENT(mp0_smn_c2pmsg_94_reg, content) \
     mp0_smn_c2pmsg_94_reg = (mp0_smn_c2pmsg_94_reg & ~MP0_SMN_C2PMSG_94_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_94_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_94_t {
          unsigned int content                        : MP0_SMN_C2PMSG_94_CONTENT_SIZE;
     } mp0_smn_c2pmsg_94_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_94_t {
          unsigned int content                        : MP0_SMN_C2PMSG_94_CONTENT_SIZE;
     } mp0_smn_c2pmsg_94_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_94_t f;
} mp0_smn_c2pmsg_94_u;


/*
 * MP0_SMN_C2PMSG_95 struct
 */

#define MP0_SMN_C2PMSG_95_REG_SIZE     32
#define MP0_SMN_C2PMSG_95_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_95_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_95_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_95_MASK \
     (MP0_SMN_C2PMSG_95_CONTENT_MASK)

#define MP0_SMN_C2PMSG_95_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_95_GET_CONTENT(mp0_smn_c2pmsg_95) \
     ((mp0_smn_c2pmsg_95 & MP0_SMN_C2PMSG_95_CONTENT_MASK) >> MP0_SMN_C2PMSG_95_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_95_SET_CONTENT(mp0_smn_c2pmsg_95_reg, content) \
     mp0_smn_c2pmsg_95_reg = (mp0_smn_c2pmsg_95_reg & ~MP0_SMN_C2PMSG_95_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_95_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_95_t {
          unsigned int content                        : MP0_SMN_C2PMSG_95_CONTENT_SIZE;
     } mp0_smn_c2pmsg_95_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_95_t {
          unsigned int content                        : MP0_SMN_C2PMSG_95_CONTENT_SIZE;
     } mp0_smn_c2pmsg_95_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_95_t f;
} mp0_smn_c2pmsg_95_u;


/*
 * MP0_SMN_C2PMSG_96 struct
 */

#define MP0_SMN_C2PMSG_96_REG_SIZE     32
#define MP0_SMN_C2PMSG_96_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_96_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_96_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_96_MASK \
     (MP0_SMN_C2PMSG_96_CONTENT_MASK)

#define MP0_SMN_C2PMSG_96_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_96_GET_CONTENT(mp0_smn_c2pmsg_96) \
     ((mp0_smn_c2pmsg_96 & MP0_SMN_C2PMSG_96_CONTENT_MASK) >> MP0_SMN_C2PMSG_96_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_96_SET_CONTENT(mp0_smn_c2pmsg_96_reg, content) \
     mp0_smn_c2pmsg_96_reg = (mp0_smn_c2pmsg_96_reg & ~MP0_SMN_C2PMSG_96_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_96_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_96_t {
          unsigned int content                        : MP0_SMN_C2PMSG_96_CONTENT_SIZE;
     } mp0_smn_c2pmsg_96_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_96_t {
          unsigned int content                        : MP0_SMN_C2PMSG_96_CONTENT_SIZE;
     } mp0_smn_c2pmsg_96_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_96_t f;
} mp0_smn_c2pmsg_96_u;


/*
 * MP0_SMN_C2PMSG_97 struct
 */

#define MP0_SMN_C2PMSG_97_REG_SIZE     32
#define MP0_SMN_C2PMSG_97_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_97_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_97_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_97_MASK \
     (MP0_SMN_C2PMSG_97_CONTENT_MASK)

#define MP0_SMN_C2PMSG_97_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_97_GET_CONTENT(mp0_smn_c2pmsg_97) \
     ((mp0_smn_c2pmsg_97 & MP0_SMN_C2PMSG_97_CONTENT_MASK) >> MP0_SMN_C2PMSG_97_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_97_SET_CONTENT(mp0_smn_c2pmsg_97_reg, content) \
     mp0_smn_c2pmsg_97_reg = (mp0_smn_c2pmsg_97_reg & ~MP0_SMN_C2PMSG_97_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_97_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_97_t {
          unsigned int content                        : MP0_SMN_C2PMSG_97_CONTENT_SIZE;
     } mp0_smn_c2pmsg_97_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_97_t {
          unsigned int content                        : MP0_SMN_C2PMSG_97_CONTENT_SIZE;
     } mp0_smn_c2pmsg_97_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_97_t f;
} mp0_smn_c2pmsg_97_u;


/*
 * MP0_SMN_C2PMSG_98 struct
 */

#define MP0_SMN_C2PMSG_98_REG_SIZE     32
#define MP0_SMN_C2PMSG_98_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_98_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_98_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_98_MASK \
     (MP0_SMN_C2PMSG_98_CONTENT_MASK)

#define MP0_SMN_C2PMSG_98_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_98_GET_CONTENT(mp0_smn_c2pmsg_98) \
     ((mp0_smn_c2pmsg_98 & MP0_SMN_C2PMSG_98_CONTENT_MASK) >> MP0_SMN_C2PMSG_98_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_98_SET_CONTENT(mp0_smn_c2pmsg_98_reg, content) \
     mp0_smn_c2pmsg_98_reg = (mp0_smn_c2pmsg_98_reg & ~MP0_SMN_C2PMSG_98_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_98_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_98_t {
          unsigned int content                        : MP0_SMN_C2PMSG_98_CONTENT_SIZE;
     } mp0_smn_c2pmsg_98_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_98_t {
          unsigned int content                        : MP0_SMN_C2PMSG_98_CONTENT_SIZE;
     } mp0_smn_c2pmsg_98_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_98_t f;
} mp0_smn_c2pmsg_98_u;


/*
 * MP0_SMN_C2PMSG_99 struct
 */

#define MP0_SMN_C2PMSG_99_REG_SIZE     32
#define MP0_SMN_C2PMSG_99_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_99_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_99_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_99_MASK \
     (MP0_SMN_C2PMSG_99_CONTENT_MASK)

#define MP0_SMN_C2PMSG_99_DEFAULT      0x00000000

#define MP0_SMN_C2PMSG_99_GET_CONTENT(mp0_smn_c2pmsg_99) \
     ((mp0_smn_c2pmsg_99 & MP0_SMN_C2PMSG_99_CONTENT_MASK) >> MP0_SMN_C2PMSG_99_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_99_SET_CONTENT(mp0_smn_c2pmsg_99_reg, content) \
     mp0_smn_c2pmsg_99_reg = (mp0_smn_c2pmsg_99_reg & ~MP0_SMN_C2PMSG_99_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_99_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_99_t {
          unsigned int content                        : MP0_SMN_C2PMSG_99_CONTENT_SIZE;
     } mp0_smn_c2pmsg_99_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_99_t {
          unsigned int content                        : MP0_SMN_C2PMSG_99_CONTENT_SIZE;
     } mp0_smn_c2pmsg_99_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_99_t f;
} mp0_smn_c2pmsg_99_u;


/*
 * MP0_SMN_C2PMSG_100 struct
 */

#define MP0_SMN_C2PMSG_100_REG_SIZE    32
#define MP0_SMN_C2PMSG_100_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_100_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_100_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_100_MASK \
     (MP0_SMN_C2PMSG_100_CONTENT_MASK)

#define MP0_SMN_C2PMSG_100_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_100_GET_CONTENT(mp0_smn_c2pmsg_100) \
     ((mp0_smn_c2pmsg_100 & MP0_SMN_C2PMSG_100_CONTENT_MASK) >> MP0_SMN_C2PMSG_100_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_100_SET_CONTENT(mp0_smn_c2pmsg_100_reg, content) \
     mp0_smn_c2pmsg_100_reg = (mp0_smn_c2pmsg_100_reg & ~MP0_SMN_C2PMSG_100_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_100_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_100_t {
          unsigned int content                        : MP0_SMN_C2PMSG_100_CONTENT_SIZE;
     } mp0_smn_c2pmsg_100_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_100_t {
          unsigned int content                        : MP0_SMN_C2PMSG_100_CONTENT_SIZE;
     } mp0_smn_c2pmsg_100_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_100_t f;
} mp0_smn_c2pmsg_100_u;


/*
 * MP0_SMN_C2PMSG_101 struct
 */

#define MP0_SMN_C2PMSG_101_REG_SIZE    32
#define MP0_SMN_C2PMSG_101_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_101_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_101_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_101_MASK \
     (MP0_SMN_C2PMSG_101_CONTENT_MASK)

#define MP0_SMN_C2PMSG_101_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_101_GET_CONTENT(mp0_smn_c2pmsg_101) \
     ((mp0_smn_c2pmsg_101 & MP0_SMN_C2PMSG_101_CONTENT_MASK) >> MP0_SMN_C2PMSG_101_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_101_SET_CONTENT(mp0_smn_c2pmsg_101_reg, content) \
     mp0_smn_c2pmsg_101_reg = (mp0_smn_c2pmsg_101_reg & ~MP0_SMN_C2PMSG_101_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_101_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_101_t {
          unsigned int content                        : MP0_SMN_C2PMSG_101_CONTENT_SIZE;
     } mp0_smn_c2pmsg_101_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_101_t {
          unsigned int content                        : MP0_SMN_C2PMSG_101_CONTENT_SIZE;
     } mp0_smn_c2pmsg_101_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_101_t f;
} mp0_smn_c2pmsg_101_u;


/*
 * MP0_SMN_C2PMSG_102 struct
 */

#define MP0_SMN_C2PMSG_102_REG_SIZE    32
#define MP0_SMN_C2PMSG_102_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_102_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_102_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_102_MASK \
     (MP0_SMN_C2PMSG_102_CONTENT_MASK)

#define MP0_SMN_C2PMSG_102_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_102_GET_CONTENT(mp0_smn_c2pmsg_102) \
     ((mp0_smn_c2pmsg_102 & MP0_SMN_C2PMSG_102_CONTENT_MASK) >> MP0_SMN_C2PMSG_102_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_102_SET_CONTENT(mp0_smn_c2pmsg_102_reg, content) \
     mp0_smn_c2pmsg_102_reg = (mp0_smn_c2pmsg_102_reg & ~MP0_SMN_C2PMSG_102_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_102_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_102_t {
          unsigned int content                        : MP0_SMN_C2PMSG_102_CONTENT_SIZE;
     } mp0_smn_c2pmsg_102_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_102_t {
          unsigned int content                        : MP0_SMN_C2PMSG_102_CONTENT_SIZE;
     } mp0_smn_c2pmsg_102_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_102_t f;
} mp0_smn_c2pmsg_102_u;


/*
 * MP0_SMN_C2PMSG_103 struct
 */

#define MP0_SMN_C2PMSG_103_REG_SIZE    32
#define MP0_SMN_C2PMSG_103_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_103_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_103_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_103_MASK \
     (MP0_SMN_C2PMSG_103_CONTENT_MASK)

#define MP0_SMN_C2PMSG_103_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_103_GET_CONTENT(mp0_smn_c2pmsg_103) \
     ((mp0_smn_c2pmsg_103 & MP0_SMN_C2PMSG_103_CONTENT_MASK) >> MP0_SMN_C2PMSG_103_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_103_SET_CONTENT(mp0_smn_c2pmsg_103_reg, content) \
     mp0_smn_c2pmsg_103_reg = (mp0_smn_c2pmsg_103_reg & ~MP0_SMN_C2PMSG_103_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_103_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_103_t {
          unsigned int content                        : MP0_SMN_C2PMSG_103_CONTENT_SIZE;
     } mp0_smn_c2pmsg_103_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_103_t {
          unsigned int content                        : MP0_SMN_C2PMSG_103_CONTENT_SIZE;
     } mp0_smn_c2pmsg_103_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_103_t f;
} mp0_smn_c2pmsg_103_u;


/*
 * MP0_SMN_C2PMSG_104 struct
 */

#define MP0_SMN_C2PMSG_104_REG_SIZE    32
#define MP0_SMN_C2PMSG_104_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_104_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_104_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_104_MASK \
     (MP0_SMN_C2PMSG_104_CONTENT_MASK)

#define MP0_SMN_C2PMSG_104_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_104_GET_CONTENT(mp0_smn_c2pmsg_104) \
     ((mp0_smn_c2pmsg_104 & MP0_SMN_C2PMSG_104_CONTENT_MASK) >> MP0_SMN_C2PMSG_104_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_104_SET_CONTENT(mp0_smn_c2pmsg_104_reg, content) \
     mp0_smn_c2pmsg_104_reg = (mp0_smn_c2pmsg_104_reg & ~MP0_SMN_C2PMSG_104_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_104_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_104_t {
          unsigned int content                        : MP0_SMN_C2PMSG_104_CONTENT_SIZE;
     } mp0_smn_c2pmsg_104_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_104_t {
          unsigned int content                        : MP0_SMN_C2PMSG_104_CONTENT_SIZE;
     } mp0_smn_c2pmsg_104_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_104_t f;
} mp0_smn_c2pmsg_104_u;


/*
 * MP0_SMN_C2PMSG_105 struct
 */

#define MP0_SMN_C2PMSG_105_REG_SIZE    32
#define MP0_SMN_C2PMSG_105_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_105_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_105_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_105_MASK \
     (MP0_SMN_C2PMSG_105_CONTENT_MASK)

#define MP0_SMN_C2PMSG_105_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_105_GET_CONTENT(mp0_smn_c2pmsg_105) \
     ((mp0_smn_c2pmsg_105 & MP0_SMN_C2PMSG_105_CONTENT_MASK) >> MP0_SMN_C2PMSG_105_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_105_SET_CONTENT(mp0_smn_c2pmsg_105_reg, content) \
     mp0_smn_c2pmsg_105_reg = (mp0_smn_c2pmsg_105_reg & ~MP0_SMN_C2PMSG_105_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_105_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_105_t {
          unsigned int content                        : MP0_SMN_C2PMSG_105_CONTENT_SIZE;
     } mp0_smn_c2pmsg_105_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_105_t {
          unsigned int content                        : MP0_SMN_C2PMSG_105_CONTENT_SIZE;
     } mp0_smn_c2pmsg_105_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_105_t f;
} mp0_smn_c2pmsg_105_u;


/*
 * MP0_SMN_C2PMSG_106 struct
 */

#define MP0_SMN_C2PMSG_106_REG_SIZE    32
#define MP0_SMN_C2PMSG_106_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_106_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_106_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_106_MASK \
     (MP0_SMN_C2PMSG_106_CONTENT_MASK)

#define MP0_SMN_C2PMSG_106_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_106_GET_CONTENT(mp0_smn_c2pmsg_106) \
     ((mp0_smn_c2pmsg_106 & MP0_SMN_C2PMSG_106_CONTENT_MASK) >> MP0_SMN_C2PMSG_106_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_106_SET_CONTENT(mp0_smn_c2pmsg_106_reg, content) \
     mp0_smn_c2pmsg_106_reg = (mp0_smn_c2pmsg_106_reg & ~MP0_SMN_C2PMSG_106_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_106_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_106_t {
          unsigned int content                        : MP0_SMN_C2PMSG_106_CONTENT_SIZE;
     } mp0_smn_c2pmsg_106_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_106_t {
          unsigned int content                        : MP0_SMN_C2PMSG_106_CONTENT_SIZE;
     } mp0_smn_c2pmsg_106_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_106_t f;
} mp0_smn_c2pmsg_106_u;


/*
 * MP0_SMN_C2PMSG_107 struct
 */

#define MP0_SMN_C2PMSG_107_REG_SIZE    32
#define MP0_SMN_C2PMSG_107_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_107_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_107_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_107_MASK \
     (MP0_SMN_C2PMSG_107_CONTENT_MASK)

#define MP0_SMN_C2PMSG_107_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_107_GET_CONTENT(mp0_smn_c2pmsg_107) \
     ((mp0_smn_c2pmsg_107 & MP0_SMN_C2PMSG_107_CONTENT_MASK) >> MP0_SMN_C2PMSG_107_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_107_SET_CONTENT(mp0_smn_c2pmsg_107_reg, content) \
     mp0_smn_c2pmsg_107_reg = (mp0_smn_c2pmsg_107_reg & ~MP0_SMN_C2PMSG_107_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_107_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_107_t {
          unsigned int content                        : MP0_SMN_C2PMSG_107_CONTENT_SIZE;
     } mp0_smn_c2pmsg_107_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_107_t {
          unsigned int content                        : MP0_SMN_C2PMSG_107_CONTENT_SIZE;
     } mp0_smn_c2pmsg_107_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_107_t f;
} mp0_smn_c2pmsg_107_u;


/*
 * MP0_SMN_C2PMSG_108 struct
 */

#define MP0_SMN_C2PMSG_108_REG_SIZE    32
#define MP0_SMN_C2PMSG_108_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_108_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_108_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_108_MASK \
     (MP0_SMN_C2PMSG_108_CONTENT_MASK)

#define MP0_SMN_C2PMSG_108_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_108_GET_CONTENT(mp0_smn_c2pmsg_108) \
     ((mp0_smn_c2pmsg_108 & MP0_SMN_C2PMSG_108_CONTENT_MASK) >> MP0_SMN_C2PMSG_108_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_108_SET_CONTENT(mp0_smn_c2pmsg_108_reg, content) \
     mp0_smn_c2pmsg_108_reg = (mp0_smn_c2pmsg_108_reg & ~MP0_SMN_C2PMSG_108_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_108_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_108_t {
          unsigned int content                        : MP0_SMN_C2PMSG_108_CONTENT_SIZE;
     } mp0_smn_c2pmsg_108_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_108_t {
          unsigned int content                        : MP0_SMN_C2PMSG_108_CONTENT_SIZE;
     } mp0_smn_c2pmsg_108_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_108_t f;
} mp0_smn_c2pmsg_108_u;


/*
 * MP0_SMN_C2PMSG_109 struct
 */

#define MP0_SMN_C2PMSG_109_REG_SIZE    32
#define MP0_SMN_C2PMSG_109_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_109_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_109_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_109_MASK \
     (MP0_SMN_C2PMSG_109_CONTENT_MASK)

#define MP0_SMN_C2PMSG_109_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_109_GET_CONTENT(mp0_smn_c2pmsg_109) \
     ((mp0_smn_c2pmsg_109 & MP0_SMN_C2PMSG_109_CONTENT_MASK) >> MP0_SMN_C2PMSG_109_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_109_SET_CONTENT(mp0_smn_c2pmsg_109_reg, content) \
     mp0_smn_c2pmsg_109_reg = (mp0_smn_c2pmsg_109_reg & ~MP0_SMN_C2PMSG_109_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_109_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_109_t {
          unsigned int content                        : MP0_SMN_C2PMSG_109_CONTENT_SIZE;
     } mp0_smn_c2pmsg_109_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_109_t {
          unsigned int content                        : MP0_SMN_C2PMSG_109_CONTENT_SIZE;
     } mp0_smn_c2pmsg_109_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_109_t f;
} mp0_smn_c2pmsg_109_u;


/*
 * MP0_SMN_C2PMSG_110 struct
 */

#define MP0_SMN_C2PMSG_110_REG_SIZE    32
#define MP0_SMN_C2PMSG_110_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_110_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_110_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_110_MASK \
     (MP0_SMN_C2PMSG_110_CONTENT_MASK)

#define MP0_SMN_C2PMSG_110_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_110_GET_CONTENT(mp0_smn_c2pmsg_110) \
     ((mp0_smn_c2pmsg_110 & MP0_SMN_C2PMSG_110_CONTENT_MASK) >> MP0_SMN_C2PMSG_110_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_110_SET_CONTENT(mp0_smn_c2pmsg_110_reg, content) \
     mp0_smn_c2pmsg_110_reg = (mp0_smn_c2pmsg_110_reg & ~MP0_SMN_C2PMSG_110_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_110_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_110_t {
          unsigned int content                        : MP0_SMN_C2PMSG_110_CONTENT_SIZE;
     } mp0_smn_c2pmsg_110_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_110_t {
          unsigned int content                        : MP0_SMN_C2PMSG_110_CONTENT_SIZE;
     } mp0_smn_c2pmsg_110_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_110_t f;
} mp0_smn_c2pmsg_110_u;


/*
 * MP0_SMN_C2PMSG_111 struct
 */

#define MP0_SMN_C2PMSG_111_REG_SIZE    32
#define MP0_SMN_C2PMSG_111_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_111_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_111_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_111_MASK \
     (MP0_SMN_C2PMSG_111_CONTENT_MASK)

#define MP0_SMN_C2PMSG_111_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_111_GET_CONTENT(mp0_smn_c2pmsg_111) \
     ((mp0_smn_c2pmsg_111 & MP0_SMN_C2PMSG_111_CONTENT_MASK) >> MP0_SMN_C2PMSG_111_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_111_SET_CONTENT(mp0_smn_c2pmsg_111_reg, content) \
     mp0_smn_c2pmsg_111_reg = (mp0_smn_c2pmsg_111_reg & ~MP0_SMN_C2PMSG_111_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_111_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_111_t {
          unsigned int content                        : MP0_SMN_C2PMSG_111_CONTENT_SIZE;
     } mp0_smn_c2pmsg_111_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_111_t {
          unsigned int content                        : MP0_SMN_C2PMSG_111_CONTENT_SIZE;
     } mp0_smn_c2pmsg_111_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_111_t f;
} mp0_smn_c2pmsg_111_u;


/*
 * MP0_SMN_C2PMSG_112 struct
 */

#define MP0_SMN_C2PMSG_112_REG_SIZE    32
#define MP0_SMN_C2PMSG_112_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_112_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_112_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_112_MASK \
     (MP0_SMN_C2PMSG_112_CONTENT_MASK)

#define MP0_SMN_C2PMSG_112_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_112_GET_CONTENT(mp0_smn_c2pmsg_112) \
     ((mp0_smn_c2pmsg_112 & MP0_SMN_C2PMSG_112_CONTENT_MASK) >> MP0_SMN_C2PMSG_112_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_112_SET_CONTENT(mp0_smn_c2pmsg_112_reg, content) \
     mp0_smn_c2pmsg_112_reg = (mp0_smn_c2pmsg_112_reg & ~MP0_SMN_C2PMSG_112_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_112_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_112_t {
          unsigned int content                        : MP0_SMN_C2PMSG_112_CONTENT_SIZE;
     } mp0_smn_c2pmsg_112_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_112_t {
          unsigned int content                        : MP0_SMN_C2PMSG_112_CONTENT_SIZE;
     } mp0_smn_c2pmsg_112_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_112_t f;
} mp0_smn_c2pmsg_112_u;


/*
 * MP0_SMN_C2PMSG_113 struct
 */

#define MP0_SMN_C2PMSG_113_REG_SIZE    32
#define MP0_SMN_C2PMSG_113_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_113_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_113_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_113_MASK \
     (MP0_SMN_C2PMSG_113_CONTENT_MASK)

#define MP0_SMN_C2PMSG_113_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_113_GET_CONTENT(mp0_smn_c2pmsg_113) \
     ((mp0_smn_c2pmsg_113 & MP0_SMN_C2PMSG_113_CONTENT_MASK) >> MP0_SMN_C2PMSG_113_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_113_SET_CONTENT(mp0_smn_c2pmsg_113_reg, content) \
     mp0_smn_c2pmsg_113_reg = (mp0_smn_c2pmsg_113_reg & ~MP0_SMN_C2PMSG_113_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_113_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_113_t {
          unsigned int content                        : MP0_SMN_C2PMSG_113_CONTENT_SIZE;
     } mp0_smn_c2pmsg_113_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_113_t {
          unsigned int content                        : MP0_SMN_C2PMSG_113_CONTENT_SIZE;
     } mp0_smn_c2pmsg_113_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_113_t f;
} mp0_smn_c2pmsg_113_u;


/*
 * MP0_SMN_C2PMSG_114 struct
 */

#define MP0_SMN_C2PMSG_114_REG_SIZE    32
#define MP0_SMN_C2PMSG_114_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_114_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_114_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_114_MASK \
     (MP0_SMN_C2PMSG_114_CONTENT_MASK)

#define MP0_SMN_C2PMSG_114_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_114_GET_CONTENT(mp0_smn_c2pmsg_114) \
     ((mp0_smn_c2pmsg_114 & MP0_SMN_C2PMSG_114_CONTENT_MASK) >> MP0_SMN_C2PMSG_114_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_114_SET_CONTENT(mp0_smn_c2pmsg_114_reg, content) \
     mp0_smn_c2pmsg_114_reg = (mp0_smn_c2pmsg_114_reg & ~MP0_SMN_C2PMSG_114_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_114_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_114_t {
          unsigned int content                        : MP0_SMN_C2PMSG_114_CONTENT_SIZE;
     } mp0_smn_c2pmsg_114_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_114_t {
          unsigned int content                        : MP0_SMN_C2PMSG_114_CONTENT_SIZE;
     } mp0_smn_c2pmsg_114_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_114_t f;
} mp0_smn_c2pmsg_114_u;


/*
 * MP0_SMN_C2PMSG_115 struct
 */

#define MP0_SMN_C2PMSG_115_REG_SIZE    32
#define MP0_SMN_C2PMSG_115_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_115_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_115_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_115_MASK \
     (MP0_SMN_C2PMSG_115_CONTENT_MASK)

#define MP0_SMN_C2PMSG_115_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_115_GET_CONTENT(mp0_smn_c2pmsg_115) \
     ((mp0_smn_c2pmsg_115 & MP0_SMN_C2PMSG_115_CONTENT_MASK) >> MP0_SMN_C2PMSG_115_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_115_SET_CONTENT(mp0_smn_c2pmsg_115_reg, content) \
     mp0_smn_c2pmsg_115_reg = (mp0_smn_c2pmsg_115_reg & ~MP0_SMN_C2PMSG_115_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_115_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_115_t {
          unsigned int content                        : MP0_SMN_C2PMSG_115_CONTENT_SIZE;
     } mp0_smn_c2pmsg_115_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_115_t {
          unsigned int content                        : MP0_SMN_C2PMSG_115_CONTENT_SIZE;
     } mp0_smn_c2pmsg_115_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_115_t f;
} mp0_smn_c2pmsg_115_u;


/*
 * MP0_SMN_C2PMSG_116 struct
 */

#define MP0_SMN_C2PMSG_116_REG_SIZE    32
#define MP0_SMN_C2PMSG_116_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_116_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_116_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_116_MASK \
     (MP0_SMN_C2PMSG_116_CONTENT_MASK)

#define MP0_SMN_C2PMSG_116_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_116_GET_CONTENT(mp0_smn_c2pmsg_116) \
     ((mp0_smn_c2pmsg_116 & MP0_SMN_C2PMSG_116_CONTENT_MASK) >> MP0_SMN_C2PMSG_116_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_116_SET_CONTENT(mp0_smn_c2pmsg_116_reg, content) \
     mp0_smn_c2pmsg_116_reg = (mp0_smn_c2pmsg_116_reg & ~MP0_SMN_C2PMSG_116_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_116_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_116_t {
          unsigned int content                        : MP0_SMN_C2PMSG_116_CONTENT_SIZE;
     } mp0_smn_c2pmsg_116_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_116_t {
          unsigned int content                        : MP0_SMN_C2PMSG_116_CONTENT_SIZE;
     } mp0_smn_c2pmsg_116_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_116_t f;
} mp0_smn_c2pmsg_116_u;


/*
 * MP0_SMN_C2PMSG_117 struct
 */

#define MP0_SMN_C2PMSG_117_REG_SIZE    32
#define MP0_SMN_C2PMSG_117_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_117_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_117_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_117_MASK \
     (MP0_SMN_C2PMSG_117_CONTENT_MASK)

#define MP0_SMN_C2PMSG_117_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_117_GET_CONTENT(mp0_smn_c2pmsg_117) \
     ((mp0_smn_c2pmsg_117 & MP0_SMN_C2PMSG_117_CONTENT_MASK) >> MP0_SMN_C2PMSG_117_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_117_SET_CONTENT(mp0_smn_c2pmsg_117_reg, content) \
     mp0_smn_c2pmsg_117_reg = (mp0_smn_c2pmsg_117_reg & ~MP0_SMN_C2PMSG_117_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_117_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_117_t {
          unsigned int content                        : MP0_SMN_C2PMSG_117_CONTENT_SIZE;
     } mp0_smn_c2pmsg_117_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_117_t {
          unsigned int content                        : MP0_SMN_C2PMSG_117_CONTENT_SIZE;
     } mp0_smn_c2pmsg_117_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_117_t f;
} mp0_smn_c2pmsg_117_u;


/*
 * MP0_SMN_C2PMSG_118 struct
 */

#define MP0_SMN_C2PMSG_118_REG_SIZE    32
#define MP0_SMN_C2PMSG_118_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_118_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_118_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_118_MASK \
     (MP0_SMN_C2PMSG_118_CONTENT_MASK)

#define MP0_SMN_C2PMSG_118_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_118_GET_CONTENT(mp0_smn_c2pmsg_118) \
     ((mp0_smn_c2pmsg_118 & MP0_SMN_C2PMSG_118_CONTENT_MASK) >> MP0_SMN_C2PMSG_118_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_118_SET_CONTENT(mp0_smn_c2pmsg_118_reg, content) \
     mp0_smn_c2pmsg_118_reg = (mp0_smn_c2pmsg_118_reg & ~MP0_SMN_C2PMSG_118_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_118_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_118_t {
          unsigned int content                        : MP0_SMN_C2PMSG_118_CONTENT_SIZE;
     } mp0_smn_c2pmsg_118_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_118_t {
          unsigned int content                        : MP0_SMN_C2PMSG_118_CONTENT_SIZE;
     } mp0_smn_c2pmsg_118_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_118_t f;
} mp0_smn_c2pmsg_118_u;


/*
 * MP0_SMN_C2PMSG_119 struct
 */

#define MP0_SMN_C2PMSG_119_REG_SIZE    32
#define MP0_SMN_C2PMSG_119_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_119_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_119_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_119_MASK \
     (MP0_SMN_C2PMSG_119_CONTENT_MASK)

#define MP0_SMN_C2PMSG_119_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_119_GET_CONTENT(mp0_smn_c2pmsg_119) \
     ((mp0_smn_c2pmsg_119 & MP0_SMN_C2PMSG_119_CONTENT_MASK) >> MP0_SMN_C2PMSG_119_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_119_SET_CONTENT(mp0_smn_c2pmsg_119_reg, content) \
     mp0_smn_c2pmsg_119_reg = (mp0_smn_c2pmsg_119_reg & ~MP0_SMN_C2PMSG_119_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_119_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_119_t {
          unsigned int content                        : MP0_SMN_C2PMSG_119_CONTENT_SIZE;
     } mp0_smn_c2pmsg_119_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_119_t {
          unsigned int content                        : MP0_SMN_C2PMSG_119_CONTENT_SIZE;
     } mp0_smn_c2pmsg_119_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_119_t f;
} mp0_smn_c2pmsg_119_u;


/*
 * MP0_SMN_C2PMSG_120 struct
 */

#define MP0_SMN_C2PMSG_120_REG_SIZE    32
#define MP0_SMN_C2PMSG_120_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_120_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_120_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_120_MASK \
     (MP0_SMN_C2PMSG_120_CONTENT_MASK)

#define MP0_SMN_C2PMSG_120_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_120_GET_CONTENT(mp0_smn_c2pmsg_120) \
     ((mp0_smn_c2pmsg_120 & MP0_SMN_C2PMSG_120_CONTENT_MASK) >> MP0_SMN_C2PMSG_120_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_120_SET_CONTENT(mp0_smn_c2pmsg_120_reg, content) \
     mp0_smn_c2pmsg_120_reg = (mp0_smn_c2pmsg_120_reg & ~MP0_SMN_C2PMSG_120_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_120_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_120_t {
          unsigned int content                        : MP0_SMN_C2PMSG_120_CONTENT_SIZE;
     } mp0_smn_c2pmsg_120_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_120_t {
          unsigned int content                        : MP0_SMN_C2PMSG_120_CONTENT_SIZE;
     } mp0_smn_c2pmsg_120_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_120_t f;
} mp0_smn_c2pmsg_120_u;


/*
 * MP0_SMN_C2PMSG_121 struct
 */

#define MP0_SMN_C2PMSG_121_REG_SIZE    32
#define MP0_SMN_C2PMSG_121_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_121_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_121_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_121_MASK \
     (MP0_SMN_C2PMSG_121_CONTENT_MASK)

#define MP0_SMN_C2PMSG_121_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_121_GET_CONTENT(mp0_smn_c2pmsg_121) \
     ((mp0_smn_c2pmsg_121 & MP0_SMN_C2PMSG_121_CONTENT_MASK) >> MP0_SMN_C2PMSG_121_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_121_SET_CONTENT(mp0_smn_c2pmsg_121_reg, content) \
     mp0_smn_c2pmsg_121_reg = (mp0_smn_c2pmsg_121_reg & ~MP0_SMN_C2PMSG_121_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_121_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_121_t {
          unsigned int content                        : MP0_SMN_C2PMSG_121_CONTENT_SIZE;
     } mp0_smn_c2pmsg_121_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_121_t {
          unsigned int content                        : MP0_SMN_C2PMSG_121_CONTENT_SIZE;
     } mp0_smn_c2pmsg_121_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_121_t f;
} mp0_smn_c2pmsg_121_u;


/*
 * MP0_SMN_C2PMSG_122 struct
 */

#define MP0_SMN_C2PMSG_122_REG_SIZE    32
#define MP0_SMN_C2PMSG_122_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_122_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_122_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_122_MASK \
     (MP0_SMN_C2PMSG_122_CONTENT_MASK)

#define MP0_SMN_C2PMSG_122_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_122_GET_CONTENT(mp0_smn_c2pmsg_122) \
     ((mp0_smn_c2pmsg_122 & MP0_SMN_C2PMSG_122_CONTENT_MASK) >> MP0_SMN_C2PMSG_122_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_122_SET_CONTENT(mp0_smn_c2pmsg_122_reg, content) \
     mp0_smn_c2pmsg_122_reg = (mp0_smn_c2pmsg_122_reg & ~MP0_SMN_C2PMSG_122_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_122_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_122_t {
          unsigned int content                        : MP0_SMN_C2PMSG_122_CONTENT_SIZE;
     } mp0_smn_c2pmsg_122_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_122_t {
          unsigned int content                        : MP0_SMN_C2PMSG_122_CONTENT_SIZE;
     } mp0_smn_c2pmsg_122_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_122_t f;
} mp0_smn_c2pmsg_122_u;


/*
 * MP0_SMN_C2PMSG_123 struct
 */

#define MP0_SMN_C2PMSG_123_REG_SIZE    32
#define MP0_SMN_C2PMSG_123_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_123_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_123_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_123_MASK \
     (MP0_SMN_C2PMSG_123_CONTENT_MASK)

#define MP0_SMN_C2PMSG_123_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_123_GET_CONTENT(mp0_smn_c2pmsg_123) \
     ((mp0_smn_c2pmsg_123 & MP0_SMN_C2PMSG_123_CONTENT_MASK) >> MP0_SMN_C2PMSG_123_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_123_SET_CONTENT(mp0_smn_c2pmsg_123_reg, content) \
     mp0_smn_c2pmsg_123_reg = (mp0_smn_c2pmsg_123_reg & ~MP0_SMN_C2PMSG_123_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_123_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_123_t {
          unsigned int content                        : MP0_SMN_C2PMSG_123_CONTENT_SIZE;
     } mp0_smn_c2pmsg_123_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_123_t {
          unsigned int content                        : MP0_SMN_C2PMSG_123_CONTENT_SIZE;
     } mp0_smn_c2pmsg_123_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_123_t f;
} mp0_smn_c2pmsg_123_u;


/*
 * MP0_SMN_C2PMSG_124 struct
 */

#define MP0_SMN_C2PMSG_124_REG_SIZE    32
#define MP0_SMN_C2PMSG_124_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_124_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_124_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_124_MASK \
     (MP0_SMN_C2PMSG_124_CONTENT_MASK)

#define MP0_SMN_C2PMSG_124_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_124_GET_CONTENT(mp0_smn_c2pmsg_124) \
     ((mp0_smn_c2pmsg_124 & MP0_SMN_C2PMSG_124_CONTENT_MASK) >> MP0_SMN_C2PMSG_124_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_124_SET_CONTENT(mp0_smn_c2pmsg_124_reg, content) \
     mp0_smn_c2pmsg_124_reg = (mp0_smn_c2pmsg_124_reg & ~MP0_SMN_C2PMSG_124_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_124_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_124_t {
          unsigned int content                        : MP0_SMN_C2PMSG_124_CONTENT_SIZE;
     } mp0_smn_c2pmsg_124_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_124_t {
          unsigned int content                        : MP0_SMN_C2PMSG_124_CONTENT_SIZE;
     } mp0_smn_c2pmsg_124_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_124_t f;
} mp0_smn_c2pmsg_124_u;


/*
 * MP0_SMN_C2PMSG_125 struct
 */

#define MP0_SMN_C2PMSG_125_REG_SIZE    32
#define MP0_SMN_C2PMSG_125_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_125_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_125_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_125_MASK \
     (MP0_SMN_C2PMSG_125_CONTENT_MASK)

#define MP0_SMN_C2PMSG_125_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_125_GET_CONTENT(mp0_smn_c2pmsg_125) \
     ((mp0_smn_c2pmsg_125 & MP0_SMN_C2PMSG_125_CONTENT_MASK) >> MP0_SMN_C2PMSG_125_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_125_SET_CONTENT(mp0_smn_c2pmsg_125_reg, content) \
     mp0_smn_c2pmsg_125_reg = (mp0_smn_c2pmsg_125_reg & ~MP0_SMN_C2PMSG_125_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_125_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_125_t {
          unsigned int content                        : MP0_SMN_C2PMSG_125_CONTENT_SIZE;
     } mp0_smn_c2pmsg_125_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_125_t {
          unsigned int content                        : MP0_SMN_C2PMSG_125_CONTENT_SIZE;
     } mp0_smn_c2pmsg_125_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_125_t f;
} mp0_smn_c2pmsg_125_u;


/*
 * MP0_SMN_C2PMSG_126 struct
 */

#define MP0_SMN_C2PMSG_126_REG_SIZE    32
#define MP0_SMN_C2PMSG_126_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_126_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_126_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_126_MASK \
     (MP0_SMN_C2PMSG_126_CONTENT_MASK)

#define MP0_SMN_C2PMSG_126_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_126_GET_CONTENT(mp0_smn_c2pmsg_126) \
     ((mp0_smn_c2pmsg_126 & MP0_SMN_C2PMSG_126_CONTENT_MASK) >> MP0_SMN_C2PMSG_126_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_126_SET_CONTENT(mp0_smn_c2pmsg_126_reg, content) \
     mp0_smn_c2pmsg_126_reg = (mp0_smn_c2pmsg_126_reg & ~MP0_SMN_C2PMSG_126_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_126_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_126_t {
          unsigned int content                        : MP0_SMN_C2PMSG_126_CONTENT_SIZE;
     } mp0_smn_c2pmsg_126_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_126_t {
          unsigned int content                        : MP0_SMN_C2PMSG_126_CONTENT_SIZE;
     } mp0_smn_c2pmsg_126_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_126_t f;
} mp0_smn_c2pmsg_126_u;


/*
 * MP0_SMN_C2PMSG_127 struct
 */

#define MP0_SMN_C2PMSG_127_REG_SIZE    32
#define MP0_SMN_C2PMSG_127_CONTENT_SIZE 32

#define MP0_SMN_C2PMSG_127_CONTENT_SHIFT 0

#define MP0_SMN_C2PMSG_127_CONTENT_MASK 0xffffffff

#define MP0_SMN_C2PMSG_127_MASK \
     (MP0_SMN_C2PMSG_127_CONTENT_MASK)

#define MP0_SMN_C2PMSG_127_DEFAULT     0x00000000

#define MP0_SMN_C2PMSG_127_GET_CONTENT(mp0_smn_c2pmsg_127) \
     ((mp0_smn_c2pmsg_127 & MP0_SMN_C2PMSG_127_CONTENT_MASK) >> MP0_SMN_C2PMSG_127_CONTENT_SHIFT)

#define MP0_SMN_C2PMSG_127_SET_CONTENT(mp0_smn_c2pmsg_127_reg, content) \
     mp0_smn_c2pmsg_127_reg = (mp0_smn_c2pmsg_127_reg & ~MP0_SMN_C2PMSG_127_CONTENT_MASK) | (content << MP0_SMN_C2PMSG_127_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_127_t {
          unsigned int content                        : MP0_SMN_C2PMSG_127_CONTENT_SIZE;
     } mp0_smn_c2pmsg_127_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_c2pmsg_127_t {
          unsigned int content                        : MP0_SMN_C2PMSG_127_CONTENT_SIZE;
     } mp0_smn_c2pmsg_127_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_c2pmsg_127_t f;
} mp0_smn_c2pmsg_127_u;


/*
 * MP0_SMN_IH_CREDIT struct
 */

#define MP0_SMN_IH_CREDIT_REG_SIZE     32
#define MP0_SMN_IH_CREDIT_CREDIT_VALUE_SIZE 2
#define MP0_SMN_IH_CREDIT_CLIENT_ID_SIZE 8

#define MP0_SMN_IH_CREDIT_CREDIT_VALUE_SHIFT 0
#define MP0_SMN_IH_CREDIT_CLIENT_ID_SHIFT 16

#define MP0_SMN_IH_CREDIT_CREDIT_VALUE_MASK 0x3
#define MP0_SMN_IH_CREDIT_CLIENT_ID_MASK 0xff0000

#define MP0_SMN_IH_CREDIT_MASK \
     (MP0_SMN_IH_CREDIT_CREDIT_VALUE_MASK | \
      MP0_SMN_IH_CREDIT_CLIENT_ID_MASK)

#define MP0_SMN_IH_CREDIT_DEFAULT      0x00000000

#define MP0_SMN_IH_CREDIT_GET_CREDIT_VALUE(mp0_smn_ih_credit) \
     ((mp0_smn_ih_credit & MP0_SMN_IH_CREDIT_CREDIT_VALUE_MASK) >> MP0_SMN_IH_CREDIT_CREDIT_VALUE_SHIFT)
#define MP0_SMN_IH_CREDIT_GET_CLIENT_ID(mp0_smn_ih_credit) \
     ((mp0_smn_ih_credit & MP0_SMN_IH_CREDIT_CLIENT_ID_MASK) >> MP0_SMN_IH_CREDIT_CLIENT_ID_SHIFT)

#define MP0_SMN_IH_CREDIT_SET_CREDIT_VALUE(mp0_smn_ih_credit_reg, credit_value) \
     mp0_smn_ih_credit_reg = (mp0_smn_ih_credit_reg & ~MP0_SMN_IH_CREDIT_CREDIT_VALUE_MASK) | (credit_value << MP0_SMN_IH_CREDIT_CREDIT_VALUE_SHIFT)
#define MP0_SMN_IH_CREDIT_SET_CLIENT_ID(mp0_smn_ih_credit_reg, client_id) \
     mp0_smn_ih_credit_reg = (mp0_smn_ih_credit_reg & ~MP0_SMN_IH_CREDIT_CLIENT_ID_MASK) | (client_id << MP0_SMN_IH_CREDIT_CLIENT_ID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_ih_credit_t {
          unsigned int credit_value                   : MP0_SMN_IH_CREDIT_CREDIT_VALUE_SIZE;
          unsigned int                                : 14;
          unsigned int client_id                      : MP0_SMN_IH_CREDIT_CLIENT_ID_SIZE;
          unsigned int                                : 8;
     } mp0_smn_ih_credit_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_ih_credit_t {
          unsigned int                                : 8;
          unsigned int client_id                      : MP0_SMN_IH_CREDIT_CLIENT_ID_SIZE;
          unsigned int                                : 14;
          unsigned int credit_value                   : MP0_SMN_IH_CREDIT_CREDIT_VALUE_SIZE;
     } mp0_smn_ih_credit_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_ih_credit_t f;
} mp0_smn_ih_credit_u;


/*
 * MP0_SMN_IH_SW_INT struct
 */

#define MP0_SMN_IH_SW_INT_REG_SIZE     32
#define MP0_SMN_IH_SW_INT_ID_SIZE      8
#define MP0_SMN_IH_SW_INT_VALID_SIZE   1

#define MP0_SMN_IH_SW_INT_ID_SHIFT     0
#define MP0_SMN_IH_SW_INT_VALID_SHIFT  8

#define MP0_SMN_IH_SW_INT_ID_MASK      0xff
#define MP0_SMN_IH_SW_INT_VALID_MASK   0x100

#define MP0_SMN_IH_SW_INT_MASK \
     (MP0_SMN_IH_SW_INT_ID_MASK | \
      MP0_SMN_IH_SW_INT_VALID_MASK)

#define MP0_SMN_IH_SW_INT_DEFAULT      0x00000000

#define MP0_SMN_IH_SW_INT_GET_ID(mp0_smn_ih_sw_int) \
     ((mp0_smn_ih_sw_int & MP0_SMN_IH_SW_INT_ID_MASK) >> MP0_SMN_IH_SW_INT_ID_SHIFT)
#define MP0_SMN_IH_SW_INT_GET_VALID(mp0_smn_ih_sw_int) \
     ((mp0_smn_ih_sw_int & MP0_SMN_IH_SW_INT_VALID_MASK) >> MP0_SMN_IH_SW_INT_VALID_SHIFT)

#define MP0_SMN_IH_SW_INT_SET_ID(mp0_smn_ih_sw_int_reg, id) \
     mp0_smn_ih_sw_int_reg = (mp0_smn_ih_sw_int_reg & ~MP0_SMN_IH_SW_INT_ID_MASK) | (id << MP0_SMN_IH_SW_INT_ID_SHIFT)
#define MP0_SMN_IH_SW_INT_SET_VALID(mp0_smn_ih_sw_int_reg, valid) \
     mp0_smn_ih_sw_int_reg = (mp0_smn_ih_sw_int_reg & ~MP0_SMN_IH_SW_INT_VALID_MASK) | (valid << MP0_SMN_IH_SW_INT_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_ih_sw_int_t {
          unsigned int id                             : MP0_SMN_IH_SW_INT_ID_SIZE;
          unsigned int valid                          : MP0_SMN_IH_SW_INT_VALID_SIZE;
          unsigned int                                : 23;
     } mp0_smn_ih_sw_int_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_ih_sw_int_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP0_SMN_IH_SW_INT_VALID_SIZE;
          unsigned int id                             : MP0_SMN_IH_SW_INT_ID_SIZE;
     } mp0_smn_ih_sw_int_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_ih_sw_int_t f;
} mp0_smn_ih_sw_int_u;


/*
 * MP0_SMN_IH_SW_INT_CTRL struct
 */

#define MP0_SMN_IH_SW_INT_CTRL_REG_SIZE 32
#define MP0_SMN_IH_SW_INT_CTRL_INT_MASK_SIZE 1
#define MP0_SMN_IH_SW_INT_CTRL_INT_ACK_SIZE 1

#define MP0_SMN_IH_SW_INT_CTRL_INT_MASK_SHIFT 0
#define MP0_SMN_IH_SW_INT_CTRL_INT_ACK_SHIFT 8

#define MP0_SMN_IH_SW_INT_CTRL_INT_MASK_MASK 0x1
#define MP0_SMN_IH_SW_INT_CTRL_INT_ACK_MASK 0x100

#define MP0_SMN_IH_SW_INT_CTRL_MASK \
     (MP0_SMN_IH_SW_INT_CTRL_INT_MASK_MASK | \
      MP0_SMN_IH_SW_INT_CTRL_INT_ACK_MASK)

#define MP0_SMN_IH_SW_INT_CTRL_DEFAULT 0x00000000

#define MP0_SMN_IH_SW_INT_CTRL_GET_INT_MASK(mp0_smn_ih_sw_int_ctrl) \
     ((mp0_smn_ih_sw_int_ctrl & MP0_SMN_IH_SW_INT_CTRL_INT_MASK_MASK) >> MP0_SMN_IH_SW_INT_CTRL_INT_MASK_SHIFT)
#define MP0_SMN_IH_SW_INT_CTRL_GET_INT_ACK(mp0_smn_ih_sw_int_ctrl) \
     ((mp0_smn_ih_sw_int_ctrl & MP0_SMN_IH_SW_INT_CTRL_INT_ACK_MASK) >> MP0_SMN_IH_SW_INT_CTRL_INT_ACK_SHIFT)

#define MP0_SMN_IH_SW_INT_CTRL_SET_INT_MASK(mp0_smn_ih_sw_int_ctrl_reg, int_mask) \
     mp0_smn_ih_sw_int_ctrl_reg = (mp0_smn_ih_sw_int_ctrl_reg & ~MP0_SMN_IH_SW_INT_CTRL_INT_MASK_MASK) | (int_mask << MP0_SMN_IH_SW_INT_CTRL_INT_MASK_SHIFT)
#define MP0_SMN_IH_SW_INT_CTRL_SET_INT_ACK(mp0_smn_ih_sw_int_ctrl_reg, int_ack) \
     mp0_smn_ih_sw_int_ctrl_reg = (mp0_smn_ih_sw_int_ctrl_reg & ~MP0_SMN_IH_SW_INT_CTRL_INT_ACK_MASK) | (int_ack << MP0_SMN_IH_SW_INT_CTRL_INT_ACK_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp0_smn_ih_sw_int_ctrl_t {
          unsigned int int_mask                       : MP0_SMN_IH_SW_INT_CTRL_INT_MASK_SIZE;
          unsigned int                                : 7;
          unsigned int int_ack                        : MP0_SMN_IH_SW_INT_CTRL_INT_ACK_SIZE;
          unsigned int                                : 23;
     } mp0_smn_ih_sw_int_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp0_smn_ih_sw_int_ctrl_t {
          unsigned int                                : 23;
          unsigned int int_ack                        : MP0_SMN_IH_SW_INT_CTRL_INT_ACK_SIZE;
          unsigned int                                : 7;
          unsigned int int_mask                       : MP0_SMN_IH_SW_INT_CTRL_INT_MASK_SIZE;
     } mp0_smn_ih_sw_int_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp0_smn_ih_sw_int_ctrl_t f;
} mp0_smn_ih_sw_int_ctrl_u;


#endif


