// Copyright (c) 1994 - 2021 Advanced Micro Devices, Inc. All rights reserved. 
 #if !defined (_MP_AES_REGS_FIDDLE_H)
#define _MP_AES_REGS_FIDDLE_H
 /*****************************************************************************************************************
 *
 *  mp_aes_regs_reg.h
 *
 *  Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif

 /*******************************************************
 * Values
 *******************************************************/

 /*******************************************************
 * Structures
 *******************************************************/

/*
 * MP0_SYSHUB_AES_Key0_0 struct
 */

#define MP0_SYSHUB_AES_Key0_0_REG_SIZE         32
#define MP0_SYSHUB_AES_Key0_0_MP0_SYSHUB_AES_Key0_0_SIZE  32

#define MP0_SYSHUB_AES_Key0_0_MP0_SYSHUB_AES_Key0_0_SHIFT  0

#define MP0_SYSHUB_AES_Key0_0_MP0_SYSHUB_AES_Key0_0_MASK  0xffffffff

#define MP0_SYSHUB_AES_Key0_0_MASK \
      (MP0_SYSHUB_AES_Key0_0_MP0_SYSHUB_AES_Key0_0_MASK)

#define MP0_SYSHUB_AES_Key0_0_DEFAULT  0x00000000

#define MP0_SYSHUB_AES_Key0_0_GET_MP0_SYSHUB_AES_Key0_0(mp0_syshub_aes_key0_0) \
      ((mp0_syshub_aes_key0_0 & MP0_SYSHUB_AES_Key0_0_MP0_SYSHUB_AES_Key0_0_MASK) >> MP0_SYSHUB_AES_Key0_0_MP0_SYSHUB_AES_Key0_0_SHIFT)

#define MP0_SYSHUB_AES_Key0_0_SET_MP0_SYSHUB_AES_Key0_0(mp0_syshub_aes_key0_0_reg, mp0_syshub_aes_key0_0) \
      mp0_syshub_aes_key0_0_reg = (mp0_syshub_aes_key0_0_reg & ~MP0_SYSHUB_AES_Key0_0_MP0_SYSHUB_AES_Key0_0_MASK) | (mp0_syshub_aes_key0_0 << MP0_SYSHUB_AES_Key0_0_MP0_SYSHUB_AES_Key0_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_aes_key0_0_t {
            unsigned int mp0_syshub_aes_key0_0          : MP0_SYSHUB_AES_Key0_0_MP0_SYSHUB_AES_Key0_0_SIZE;
      } mp0_syshub_aes_key0_0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_aes_key0_0_t {
            unsigned int mp0_syshub_aes_key0_0          : MP0_SYSHUB_AES_Key0_0_MP0_SYSHUB_AES_Key0_0_SIZE;
      } mp0_syshub_aes_key0_0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_aes_key0_0_t f;
} mp0_syshub_aes_key0_0_u;


/*
 * MP0_SYSHUB_AES_Key0_1 struct
 */

#define MP0_SYSHUB_AES_Key0_1_REG_SIZE         32
#define MP0_SYSHUB_AES_Key0_1_MP0_SYSHUB_AES_Key0_1_SIZE  32

#define MP0_SYSHUB_AES_Key0_1_MP0_SYSHUB_AES_Key0_1_SHIFT  0

#define MP0_SYSHUB_AES_Key0_1_MP0_SYSHUB_AES_Key0_1_MASK  0xffffffff

#define MP0_SYSHUB_AES_Key0_1_MASK \
      (MP0_SYSHUB_AES_Key0_1_MP0_SYSHUB_AES_Key0_1_MASK)

#define MP0_SYSHUB_AES_Key0_1_DEFAULT  0x00000000

#define MP0_SYSHUB_AES_Key0_1_GET_MP0_SYSHUB_AES_Key0_1(mp0_syshub_aes_key0_1) \
      ((mp0_syshub_aes_key0_1 & MP0_SYSHUB_AES_Key0_1_MP0_SYSHUB_AES_Key0_1_MASK) >> MP0_SYSHUB_AES_Key0_1_MP0_SYSHUB_AES_Key0_1_SHIFT)

#define MP0_SYSHUB_AES_Key0_1_SET_MP0_SYSHUB_AES_Key0_1(mp0_syshub_aes_key0_1_reg, mp0_syshub_aes_key0_1) \
      mp0_syshub_aes_key0_1_reg = (mp0_syshub_aes_key0_1_reg & ~MP0_SYSHUB_AES_Key0_1_MP0_SYSHUB_AES_Key0_1_MASK) | (mp0_syshub_aes_key0_1 << MP0_SYSHUB_AES_Key0_1_MP0_SYSHUB_AES_Key0_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_aes_key0_1_t {
            unsigned int mp0_syshub_aes_key0_1          : MP0_SYSHUB_AES_Key0_1_MP0_SYSHUB_AES_Key0_1_SIZE;
      } mp0_syshub_aes_key0_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_aes_key0_1_t {
            unsigned int mp0_syshub_aes_key0_1          : MP0_SYSHUB_AES_Key0_1_MP0_SYSHUB_AES_Key0_1_SIZE;
      } mp0_syshub_aes_key0_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_aes_key0_1_t f;
} mp0_syshub_aes_key0_1_u;


/*
 * MP0_SYSHUB_AES_Key0_2 struct
 */

#define MP0_SYSHUB_AES_Key0_2_REG_SIZE         32
#define MP0_SYSHUB_AES_Key0_2_MP0_SYSHUB_AES_Key0_2_SIZE  32

#define MP0_SYSHUB_AES_Key0_2_MP0_SYSHUB_AES_Key0_2_SHIFT  0

#define MP0_SYSHUB_AES_Key0_2_MP0_SYSHUB_AES_Key0_2_MASK  0xffffffff

#define MP0_SYSHUB_AES_Key0_2_MASK \
      (MP0_SYSHUB_AES_Key0_2_MP0_SYSHUB_AES_Key0_2_MASK)

#define MP0_SYSHUB_AES_Key0_2_DEFAULT  0x00000000

#define MP0_SYSHUB_AES_Key0_2_GET_MP0_SYSHUB_AES_Key0_2(mp0_syshub_aes_key0_2) \
      ((mp0_syshub_aes_key0_2 & MP0_SYSHUB_AES_Key0_2_MP0_SYSHUB_AES_Key0_2_MASK) >> MP0_SYSHUB_AES_Key0_2_MP0_SYSHUB_AES_Key0_2_SHIFT)

#define MP0_SYSHUB_AES_Key0_2_SET_MP0_SYSHUB_AES_Key0_2(mp0_syshub_aes_key0_2_reg, mp0_syshub_aes_key0_2) \
      mp0_syshub_aes_key0_2_reg = (mp0_syshub_aes_key0_2_reg & ~MP0_SYSHUB_AES_Key0_2_MP0_SYSHUB_AES_Key0_2_MASK) | (mp0_syshub_aes_key0_2 << MP0_SYSHUB_AES_Key0_2_MP0_SYSHUB_AES_Key0_2_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_aes_key0_2_t {
            unsigned int mp0_syshub_aes_key0_2          : MP0_SYSHUB_AES_Key0_2_MP0_SYSHUB_AES_Key0_2_SIZE;
      } mp0_syshub_aes_key0_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_aes_key0_2_t {
            unsigned int mp0_syshub_aes_key0_2          : MP0_SYSHUB_AES_Key0_2_MP0_SYSHUB_AES_Key0_2_SIZE;
      } mp0_syshub_aes_key0_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_aes_key0_2_t f;
} mp0_syshub_aes_key0_2_u;


/*
 * MP0_SYSHUB_AES_Key0_3 struct
 */

#define MP0_SYSHUB_AES_Key0_3_REG_SIZE         32
#define MP0_SYSHUB_AES_Key0_3_MP0_SYSHUB_AES_Key0_3_SIZE  32

#define MP0_SYSHUB_AES_Key0_3_MP0_SYSHUB_AES_Key0_3_SHIFT  0

#define MP0_SYSHUB_AES_Key0_3_MP0_SYSHUB_AES_Key0_3_MASK  0xffffffff

#define MP0_SYSHUB_AES_Key0_3_MASK \
      (MP0_SYSHUB_AES_Key0_3_MP0_SYSHUB_AES_Key0_3_MASK)

#define MP0_SYSHUB_AES_Key0_3_DEFAULT  0x00000000

#define MP0_SYSHUB_AES_Key0_3_GET_MP0_SYSHUB_AES_Key0_3(mp0_syshub_aes_key0_3) \
      ((mp0_syshub_aes_key0_3 & MP0_SYSHUB_AES_Key0_3_MP0_SYSHUB_AES_Key0_3_MASK) >> MP0_SYSHUB_AES_Key0_3_MP0_SYSHUB_AES_Key0_3_SHIFT)

#define MP0_SYSHUB_AES_Key0_3_SET_MP0_SYSHUB_AES_Key0_3(mp0_syshub_aes_key0_3_reg, mp0_syshub_aes_key0_3) \
      mp0_syshub_aes_key0_3_reg = (mp0_syshub_aes_key0_3_reg & ~MP0_SYSHUB_AES_Key0_3_MP0_SYSHUB_AES_Key0_3_MASK) | (mp0_syshub_aes_key0_3 << MP0_SYSHUB_AES_Key0_3_MP0_SYSHUB_AES_Key0_3_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_aes_key0_3_t {
            unsigned int mp0_syshub_aes_key0_3          : MP0_SYSHUB_AES_Key0_3_MP0_SYSHUB_AES_Key0_3_SIZE;
      } mp0_syshub_aes_key0_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_aes_key0_3_t {
            unsigned int mp0_syshub_aes_key0_3          : MP0_SYSHUB_AES_Key0_3_MP0_SYSHUB_AES_Key0_3_SIZE;
      } mp0_syshub_aes_key0_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_aes_key0_3_t f;
} mp0_syshub_aes_key0_3_u;


/*
 * MP0_SYSHUB_AES_Key1_0 struct
 */

#define MP0_SYSHUB_AES_Key1_0_REG_SIZE         32
#define MP0_SYSHUB_AES_Key1_0_MP0_SYSHUB_AES_Key1_0_SIZE  32

#define MP0_SYSHUB_AES_Key1_0_MP0_SYSHUB_AES_Key1_0_SHIFT  0

#define MP0_SYSHUB_AES_Key1_0_MP0_SYSHUB_AES_Key1_0_MASK  0xffffffff

#define MP0_SYSHUB_AES_Key1_0_MASK \
      (MP0_SYSHUB_AES_Key1_0_MP0_SYSHUB_AES_Key1_0_MASK)

#define MP0_SYSHUB_AES_Key1_0_DEFAULT  0x00000000

#define MP0_SYSHUB_AES_Key1_0_GET_MP0_SYSHUB_AES_Key1_0(mp0_syshub_aes_key1_0) \
      ((mp0_syshub_aes_key1_0 & MP0_SYSHUB_AES_Key1_0_MP0_SYSHUB_AES_Key1_0_MASK) >> MP0_SYSHUB_AES_Key1_0_MP0_SYSHUB_AES_Key1_0_SHIFT)

#define MP0_SYSHUB_AES_Key1_0_SET_MP0_SYSHUB_AES_Key1_0(mp0_syshub_aes_key1_0_reg, mp0_syshub_aes_key1_0) \
      mp0_syshub_aes_key1_0_reg = (mp0_syshub_aes_key1_0_reg & ~MP0_SYSHUB_AES_Key1_0_MP0_SYSHUB_AES_Key1_0_MASK) | (mp0_syshub_aes_key1_0 << MP0_SYSHUB_AES_Key1_0_MP0_SYSHUB_AES_Key1_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_aes_key1_0_t {
            unsigned int mp0_syshub_aes_key1_0          : MP0_SYSHUB_AES_Key1_0_MP0_SYSHUB_AES_Key1_0_SIZE;
      } mp0_syshub_aes_key1_0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_aes_key1_0_t {
            unsigned int mp0_syshub_aes_key1_0          : MP0_SYSHUB_AES_Key1_0_MP0_SYSHUB_AES_Key1_0_SIZE;
      } mp0_syshub_aes_key1_0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_aes_key1_0_t f;
} mp0_syshub_aes_key1_0_u;


/*
 * MP0_SYSHUB_AES_Key1_1 struct
 */

#define MP0_SYSHUB_AES_Key1_1_REG_SIZE         32
#define MP0_SYSHUB_AES_Key1_1_MP0_SYSHUB_AES_Key1_1_SIZE  32

#define MP0_SYSHUB_AES_Key1_1_MP0_SYSHUB_AES_Key1_1_SHIFT  0

#define MP0_SYSHUB_AES_Key1_1_MP0_SYSHUB_AES_Key1_1_MASK  0xffffffff

#define MP0_SYSHUB_AES_Key1_1_MASK \
      (MP0_SYSHUB_AES_Key1_1_MP0_SYSHUB_AES_Key1_1_MASK)

#define MP0_SYSHUB_AES_Key1_1_DEFAULT  0x00000000

#define MP0_SYSHUB_AES_Key1_1_GET_MP0_SYSHUB_AES_Key1_1(mp0_syshub_aes_key1_1) \
      ((mp0_syshub_aes_key1_1 & MP0_SYSHUB_AES_Key1_1_MP0_SYSHUB_AES_Key1_1_MASK) >> MP0_SYSHUB_AES_Key1_1_MP0_SYSHUB_AES_Key1_1_SHIFT)

#define MP0_SYSHUB_AES_Key1_1_SET_MP0_SYSHUB_AES_Key1_1(mp0_syshub_aes_key1_1_reg, mp0_syshub_aes_key1_1) \
      mp0_syshub_aes_key1_1_reg = (mp0_syshub_aes_key1_1_reg & ~MP0_SYSHUB_AES_Key1_1_MP0_SYSHUB_AES_Key1_1_MASK) | (mp0_syshub_aes_key1_1 << MP0_SYSHUB_AES_Key1_1_MP0_SYSHUB_AES_Key1_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_aes_key1_1_t {
            unsigned int mp0_syshub_aes_key1_1          : MP0_SYSHUB_AES_Key1_1_MP0_SYSHUB_AES_Key1_1_SIZE;
      } mp0_syshub_aes_key1_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_aes_key1_1_t {
            unsigned int mp0_syshub_aes_key1_1          : MP0_SYSHUB_AES_Key1_1_MP0_SYSHUB_AES_Key1_1_SIZE;
      } mp0_syshub_aes_key1_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_aes_key1_1_t f;
} mp0_syshub_aes_key1_1_u;


/*
 * MP0_SYSHUB_AES_Key1_2 struct
 */

#define MP0_SYSHUB_AES_Key1_2_REG_SIZE         32
#define MP0_SYSHUB_AES_Key1_2_MP0_SYSHUB_AES_Key1_2_SIZE  32

#define MP0_SYSHUB_AES_Key1_2_MP0_SYSHUB_AES_Key1_2_SHIFT  0

#define MP0_SYSHUB_AES_Key1_2_MP0_SYSHUB_AES_Key1_2_MASK  0xffffffff

#define MP0_SYSHUB_AES_Key1_2_MASK \
      (MP0_SYSHUB_AES_Key1_2_MP0_SYSHUB_AES_Key1_2_MASK)

#define MP0_SYSHUB_AES_Key1_2_DEFAULT  0x00000000

#define MP0_SYSHUB_AES_Key1_2_GET_MP0_SYSHUB_AES_Key1_2(mp0_syshub_aes_key1_2) \
      ((mp0_syshub_aes_key1_2 & MP0_SYSHUB_AES_Key1_2_MP0_SYSHUB_AES_Key1_2_MASK) >> MP0_SYSHUB_AES_Key1_2_MP0_SYSHUB_AES_Key1_2_SHIFT)

#define MP0_SYSHUB_AES_Key1_2_SET_MP0_SYSHUB_AES_Key1_2(mp0_syshub_aes_key1_2_reg, mp0_syshub_aes_key1_2) \
      mp0_syshub_aes_key1_2_reg = (mp0_syshub_aes_key1_2_reg & ~MP0_SYSHUB_AES_Key1_2_MP0_SYSHUB_AES_Key1_2_MASK) | (mp0_syshub_aes_key1_2 << MP0_SYSHUB_AES_Key1_2_MP0_SYSHUB_AES_Key1_2_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_aes_key1_2_t {
            unsigned int mp0_syshub_aes_key1_2          : MP0_SYSHUB_AES_Key1_2_MP0_SYSHUB_AES_Key1_2_SIZE;
      } mp0_syshub_aes_key1_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_aes_key1_2_t {
            unsigned int mp0_syshub_aes_key1_2          : MP0_SYSHUB_AES_Key1_2_MP0_SYSHUB_AES_Key1_2_SIZE;
      } mp0_syshub_aes_key1_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_aes_key1_2_t f;
} mp0_syshub_aes_key1_2_u;


/*
 * MP0_SYSHUB_AES_Key1_3 struct
 */

#define MP0_SYSHUB_AES_Key1_3_REG_SIZE         32
#define MP0_SYSHUB_AES_Key1_3_MP0_SYSHUB_AES_Key1_3_SIZE  32

#define MP0_SYSHUB_AES_Key1_3_MP0_SYSHUB_AES_Key1_3_SHIFT  0

#define MP0_SYSHUB_AES_Key1_3_MP0_SYSHUB_AES_Key1_3_MASK  0xffffffff

#define MP0_SYSHUB_AES_Key1_3_MASK \
      (MP0_SYSHUB_AES_Key1_3_MP0_SYSHUB_AES_Key1_3_MASK)

#define MP0_SYSHUB_AES_Key1_3_DEFAULT  0x00000000

#define MP0_SYSHUB_AES_Key1_3_GET_MP0_SYSHUB_AES_Key1_3(mp0_syshub_aes_key1_3) \
      ((mp0_syshub_aes_key1_3 & MP0_SYSHUB_AES_Key1_3_MP0_SYSHUB_AES_Key1_3_MASK) >> MP0_SYSHUB_AES_Key1_3_MP0_SYSHUB_AES_Key1_3_SHIFT)

#define MP0_SYSHUB_AES_Key1_3_SET_MP0_SYSHUB_AES_Key1_3(mp0_syshub_aes_key1_3_reg, mp0_syshub_aes_key1_3) \
      mp0_syshub_aes_key1_3_reg = (mp0_syshub_aes_key1_3_reg & ~MP0_SYSHUB_AES_Key1_3_MP0_SYSHUB_AES_Key1_3_MASK) | (mp0_syshub_aes_key1_3 << MP0_SYSHUB_AES_Key1_3_MP0_SYSHUB_AES_Key1_3_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_aes_key1_3_t {
            unsigned int mp0_syshub_aes_key1_3          : MP0_SYSHUB_AES_Key1_3_MP0_SYSHUB_AES_Key1_3_SIZE;
      } mp0_syshub_aes_key1_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_aes_key1_3_t {
            unsigned int mp0_syshub_aes_key1_3          : MP0_SYSHUB_AES_Key1_3_MP0_SYSHUB_AES_Key1_3_SIZE;
      } mp0_syshub_aes_key1_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_aes_key1_3_t f;
} mp0_syshub_aes_key1_3_u;


/*
 * MP0_SYSHUB_AES_Key2_0 struct
 */

#define MP0_SYSHUB_AES_Key2_0_REG_SIZE         32
#define MP0_SYSHUB_AES_Key2_0_MP0_SYSHUB_AES_Key2_0_SIZE  32

#define MP0_SYSHUB_AES_Key2_0_MP0_SYSHUB_AES_Key2_0_SHIFT  0

#define MP0_SYSHUB_AES_Key2_0_MP0_SYSHUB_AES_Key2_0_MASK  0xffffffff

#define MP0_SYSHUB_AES_Key2_0_MASK \
      (MP0_SYSHUB_AES_Key2_0_MP0_SYSHUB_AES_Key2_0_MASK)

#define MP0_SYSHUB_AES_Key2_0_DEFAULT  0x00000000

#define MP0_SYSHUB_AES_Key2_0_GET_MP0_SYSHUB_AES_Key2_0(mp0_syshub_aes_key2_0) \
      ((mp0_syshub_aes_key2_0 & MP0_SYSHUB_AES_Key2_0_MP0_SYSHUB_AES_Key2_0_MASK) >> MP0_SYSHUB_AES_Key2_0_MP0_SYSHUB_AES_Key2_0_SHIFT)

#define MP0_SYSHUB_AES_Key2_0_SET_MP0_SYSHUB_AES_Key2_0(mp0_syshub_aes_key2_0_reg, mp0_syshub_aes_key2_0) \
      mp0_syshub_aes_key2_0_reg = (mp0_syshub_aes_key2_0_reg & ~MP0_SYSHUB_AES_Key2_0_MP0_SYSHUB_AES_Key2_0_MASK) | (mp0_syshub_aes_key2_0 << MP0_SYSHUB_AES_Key2_0_MP0_SYSHUB_AES_Key2_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_aes_key2_0_t {
            unsigned int mp0_syshub_aes_key2_0          : MP0_SYSHUB_AES_Key2_0_MP0_SYSHUB_AES_Key2_0_SIZE;
      } mp0_syshub_aes_key2_0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_aes_key2_0_t {
            unsigned int mp0_syshub_aes_key2_0          : MP0_SYSHUB_AES_Key2_0_MP0_SYSHUB_AES_Key2_0_SIZE;
      } mp0_syshub_aes_key2_0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_aes_key2_0_t f;
} mp0_syshub_aes_key2_0_u;


/*
 * MP0_SYSHUB_AES_Key2_1 struct
 */

#define MP0_SYSHUB_AES_Key2_1_REG_SIZE         32
#define MP0_SYSHUB_AES_Key2_1_MP0_SYSHUB_AES_Key2_1_SIZE  32

#define MP0_SYSHUB_AES_Key2_1_MP0_SYSHUB_AES_Key2_1_SHIFT  0

#define MP0_SYSHUB_AES_Key2_1_MP0_SYSHUB_AES_Key2_1_MASK  0xffffffff

#define MP0_SYSHUB_AES_Key2_1_MASK \
      (MP0_SYSHUB_AES_Key2_1_MP0_SYSHUB_AES_Key2_1_MASK)

#define MP0_SYSHUB_AES_Key2_1_DEFAULT  0x00000000

#define MP0_SYSHUB_AES_Key2_1_GET_MP0_SYSHUB_AES_Key2_1(mp0_syshub_aes_key2_1) \
      ((mp0_syshub_aes_key2_1 & MP0_SYSHUB_AES_Key2_1_MP0_SYSHUB_AES_Key2_1_MASK) >> MP0_SYSHUB_AES_Key2_1_MP0_SYSHUB_AES_Key2_1_SHIFT)

#define MP0_SYSHUB_AES_Key2_1_SET_MP0_SYSHUB_AES_Key2_1(mp0_syshub_aes_key2_1_reg, mp0_syshub_aes_key2_1) \
      mp0_syshub_aes_key2_1_reg = (mp0_syshub_aes_key2_1_reg & ~MP0_SYSHUB_AES_Key2_1_MP0_SYSHUB_AES_Key2_1_MASK) | (mp0_syshub_aes_key2_1 << MP0_SYSHUB_AES_Key2_1_MP0_SYSHUB_AES_Key2_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_aes_key2_1_t {
            unsigned int mp0_syshub_aes_key2_1          : MP0_SYSHUB_AES_Key2_1_MP0_SYSHUB_AES_Key2_1_SIZE;
      } mp0_syshub_aes_key2_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_aes_key2_1_t {
            unsigned int mp0_syshub_aes_key2_1          : MP0_SYSHUB_AES_Key2_1_MP0_SYSHUB_AES_Key2_1_SIZE;
      } mp0_syshub_aes_key2_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_aes_key2_1_t f;
} mp0_syshub_aes_key2_1_u;


/*
 * MP0_SYSHUB_AES_Key2_2 struct
 */

#define MP0_SYSHUB_AES_Key2_2_REG_SIZE         32
#define MP0_SYSHUB_AES_Key2_2_MP0_SYSHUB_AES_Key2_2_SIZE  32

#define MP0_SYSHUB_AES_Key2_2_MP0_SYSHUB_AES_Key2_2_SHIFT  0

#define MP0_SYSHUB_AES_Key2_2_MP0_SYSHUB_AES_Key2_2_MASK  0xffffffff

#define MP0_SYSHUB_AES_Key2_2_MASK \
      (MP0_SYSHUB_AES_Key2_2_MP0_SYSHUB_AES_Key2_2_MASK)

#define MP0_SYSHUB_AES_Key2_2_DEFAULT  0x00000000

#define MP0_SYSHUB_AES_Key2_2_GET_MP0_SYSHUB_AES_Key2_2(mp0_syshub_aes_key2_2) \
      ((mp0_syshub_aes_key2_2 & MP0_SYSHUB_AES_Key2_2_MP0_SYSHUB_AES_Key2_2_MASK) >> MP0_SYSHUB_AES_Key2_2_MP0_SYSHUB_AES_Key2_2_SHIFT)

#define MP0_SYSHUB_AES_Key2_2_SET_MP0_SYSHUB_AES_Key2_2(mp0_syshub_aes_key2_2_reg, mp0_syshub_aes_key2_2) \
      mp0_syshub_aes_key2_2_reg = (mp0_syshub_aes_key2_2_reg & ~MP0_SYSHUB_AES_Key2_2_MP0_SYSHUB_AES_Key2_2_MASK) | (mp0_syshub_aes_key2_2 << MP0_SYSHUB_AES_Key2_2_MP0_SYSHUB_AES_Key2_2_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_aes_key2_2_t {
            unsigned int mp0_syshub_aes_key2_2          : MP0_SYSHUB_AES_Key2_2_MP0_SYSHUB_AES_Key2_2_SIZE;
      } mp0_syshub_aes_key2_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_aes_key2_2_t {
            unsigned int mp0_syshub_aes_key2_2          : MP0_SYSHUB_AES_Key2_2_MP0_SYSHUB_AES_Key2_2_SIZE;
      } mp0_syshub_aes_key2_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_aes_key2_2_t f;
} mp0_syshub_aes_key2_2_u;


/*
 * MP0_SYSHUB_AES_Key2_3 struct
 */

#define MP0_SYSHUB_AES_Key2_3_REG_SIZE         32
#define MP0_SYSHUB_AES_Key2_3_MP0_SYSHUB_AES_Key2_3_SIZE  32

#define MP0_SYSHUB_AES_Key2_3_MP0_SYSHUB_AES_Key2_3_SHIFT  0

#define MP0_SYSHUB_AES_Key2_3_MP0_SYSHUB_AES_Key2_3_MASK  0xffffffff

#define MP0_SYSHUB_AES_Key2_3_MASK \
      (MP0_SYSHUB_AES_Key2_3_MP0_SYSHUB_AES_Key2_3_MASK)

#define MP0_SYSHUB_AES_Key2_3_DEFAULT  0x00000000

#define MP0_SYSHUB_AES_Key2_3_GET_MP0_SYSHUB_AES_Key2_3(mp0_syshub_aes_key2_3) \
      ((mp0_syshub_aes_key2_3 & MP0_SYSHUB_AES_Key2_3_MP0_SYSHUB_AES_Key2_3_MASK) >> MP0_SYSHUB_AES_Key2_3_MP0_SYSHUB_AES_Key2_3_SHIFT)

#define MP0_SYSHUB_AES_Key2_3_SET_MP0_SYSHUB_AES_Key2_3(mp0_syshub_aes_key2_3_reg, mp0_syshub_aes_key2_3) \
      mp0_syshub_aes_key2_3_reg = (mp0_syshub_aes_key2_3_reg & ~MP0_SYSHUB_AES_Key2_3_MP0_SYSHUB_AES_Key2_3_MASK) | (mp0_syshub_aes_key2_3 << MP0_SYSHUB_AES_Key2_3_MP0_SYSHUB_AES_Key2_3_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_aes_key2_3_t {
            unsigned int mp0_syshub_aes_key2_3          : MP0_SYSHUB_AES_Key2_3_MP0_SYSHUB_AES_Key2_3_SIZE;
      } mp0_syshub_aes_key2_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_aes_key2_3_t {
            unsigned int mp0_syshub_aes_key2_3          : MP0_SYSHUB_AES_Key2_3_MP0_SYSHUB_AES_Key2_3_SIZE;
      } mp0_syshub_aes_key2_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_aes_key2_3_t f;
} mp0_syshub_aes_key2_3_u;


/*
 * MP0_SYSHUB_AES_Key3_0 struct
 */

#define MP0_SYSHUB_AES_Key3_0_REG_SIZE         32
#define MP0_SYSHUB_AES_Key3_0_MP0_SYSHUB_AES_Key3_0_SIZE  32

#define MP0_SYSHUB_AES_Key3_0_MP0_SYSHUB_AES_Key3_0_SHIFT  0

#define MP0_SYSHUB_AES_Key3_0_MP0_SYSHUB_AES_Key3_0_MASK  0xffffffff

#define MP0_SYSHUB_AES_Key3_0_MASK \
      (MP0_SYSHUB_AES_Key3_0_MP0_SYSHUB_AES_Key3_0_MASK)

#define MP0_SYSHUB_AES_Key3_0_DEFAULT  0x00000000

#define MP0_SYSHUB_AES_Key3_0_GET_MP0_SYSHUB_AES_Key3_0(mp0_syshub_aes_key3_0) \
      ((mp0_syshub_aes_key3_0 & MP0_SYSHUB_AES_Key3_0_MP0_SYSHUB_AES_Key3_0_MASK) >> MP0_SYSHUB_AES_Key3_0_MP0_SYSHUB_AES_Key3_0_SHIFT)

#define MP0_SYSHUB_AES_Key3_0_SET_MP0_SYSHUB_AES_Key3_0(mp0_syshub_aes_key3_0_reg, mp0_syshub_aes_key3_0) \
      mp0_syshub_aes_key3_0_reg = (mp0_syshub_aes_key3_0_reg & ~MP0_SYSHUB_AES_Key3_0_MP0_SYSHUB_AES_Key3_0_MASK) | (mp0_syshub_aes_key3_0 << MP0_SYSHUB_AES_Key3_0_MP0_SYSHUB_AES_Key3_0_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_aes_key3_0_t {
            unsigned int mp0_syshub_aes_key3_0          : MP0_SYSHUB_AES_Key3_0_MP0_SYSHUB_AES_Key3_0_SIZE;
      } mp0_syshub_aes_key3_0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_aes_key3_0_t {
            unsigned int mp0_syshub_aes_key3_0          : MP0_SYSHUB_AES_Key3_0_MP0_SYSHUB_AES_Key3_0_SIZE;
      } mp0_syshub_aes_key3_0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_aes_key3_0_t f;
} mp0_syshub_aes_key3_0_u;


/*
 * MP0_SYSHUB_AES_Key3_1 struct
 */

#define MP0_SYSHUB_AES_Key3_1_REG_SIZE         32
#define MP0_SYSHUB_AES_Key3_1_MP0_SYSHUB_AES_Key3_1_SIZE  32

#define MP0_SYSHUB_AES_Key3_1_MP0_SYSHUB_AES_Key3_1_SHIFT  0

#define MP0_SYSHUB_AES_Key3_1_MP0_SYSHUB_AES_Key3_1_MASK  0xffffffff

#define MP0_SYSHUB_AES_Key3_1_MASK \
      (MP0_SYSHUB_AES_Key3_1_MP0_SYSHUB_AES_Key3_1_MASK)

#define MP0_SYSHUB_AES_Key3_1_DEFAULT  0x00000000

#define MP0_SYSHUB_AES_Key3_1_GET_MP0_SYSHUB_AES_Key3_1(mp0_syshub_aes_key3_1) \
      ((mp0_syshub_aes_key3_1 & MP0_SYSHUB_AES_Key3_1_MP0_SYSHUB_AES_Key3_1_MASK) >> MP0_SYSHUB_AES_Key3_1_MP0_SYSHUB_AES_Key3_1_SHIFT)

#define MP0_SYSHUB_AES_Key3_1_SET_MP0_SYSHUB_AES_Key3_1(mp0_syshub_aes_key3_1_reg, mp0_syshub_aes_key3_1) \
      mp0_syshub_aes_key3_1_reg = (mp0_syshub_aes_key3_1_reg & ~MP0_SYSHUB_AES_Key3_1_MP0_SYSHUB_AES_Key3_1_MASK) | (mp0_syshub_aes_key3_1 << MP0_SYSHUB_AES_Key3_1_MP0_SYSHUB_AES_Key3_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_aes_key3_1_t {
            unsigned int mp0_syshub_aes_key3_1          : MP0_SYSHUB_AES_Key3_1_MP0_SYSHUB_AES_Key3_1_SIZE;
      } mp0_syshub_aes_key3_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_aes_key3_1_t {
            unsigned int mp0_syshub_aes_key3_1          : MP0_SYSHUB_AES_Key3_1_MP0_SYSHUB_AES_Key3_1_SIZE;
      } mp0_syshub_aes_key3_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_aes_key3_1_t f;
} mp0_syshub_aes_key3_1_u;


/*
 * MP0_SYSHUB_AES_Key3_2 struct
 */

#define MP0_SYSHUB_AES_Key3_2_REG_SIZE         32
#define MP0_SYSHUB_AES_Key3_2_MP0_SYSHUB_AES_Key3_2_SIZE  32

#define MP0_SYSHUB_AES_Key3_2_MP0_SYSHUB_AES_Key3_2_SHIFT  0

#define MP0_SYSHUB_AES_Key3_2_MP0_SYSHUB_AES_Key3_2_MASK  0xffffffff

#define MP0_SYSHUB_AES_Key3_2_MASK \
      (MP0_SYSHUB_AES_Key3_2_MP0_SYSHUB_AES_Key3_2_MASK)

#define MP0_SYSHUB_AES_Key3_2_DEFAULT  0x00000000

#define MP0_SYSHUB_AES_Key3_2_GET_MP0_SYSHUB_AES_Key3_2(mp0_syshub_aes_key3_2) \
      ((mp0_syshub_aes_key3_2 & MP0_SYSHUB_AES_Key3_2_MP0_SYSHUB_AES_Key3_2_MASK) >> MP0_SYSHUB_AES_Key3_2_MP0_SYSHUB_AES_Key3_2_SHIFT)

#define MP0_SYSHUB_AES_Key3_2_SET_MP0_SYSHUB_AES_Key3_2(mp0_syshub_aes_key3_2_reg, mp0_syshub_aes_key3_2) \
      mp0_syshub_aes_key3_2_reg = (mp0_syshub_aes_key3_2_reg & ~MP0_SYSHUB_AES_Key3_2_MP0_SYSHUB_AES_Key3_2_MASK) | (mp0_syshub_aes_key3_2 << MP0_SYSHUB_AES_Key3_2_MP0_SYSHUB_AES_Key3_2_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_aes_key3_2_t {
            unsigned int mp0_syshub_aes_key3_2          : MP0_SYSHUB_AES_Key3_2_MP0_SYSHUB_AES_Key3_2_SIZE;
      } mp0_syshub_aes_key3_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_aes_key3_2_t {
            unsigned int mp0_syshub_aes_key3_2          : MP0_SYSHUB_AES_Key3_2_MP0_SYSHUB_AES_Key3_2_SIZE;
      } mp0_syshub_aes_key3_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_aes_key3_2_t f;
} mp0_syshub_aes_key3_2_u;


/*
 * MP0_SYSHUB_AES_Key3_3 struct
 */

#define MP0_SYSHUB_AES_Key3_3_REG_SIZE         32
#define MP0_SYSHUB_AES_Key3_3_MP0_SYSHUB_AES_Key3_3_SIZE  32

#define MP0_SYSHUB_AES_Key3_3_MP0_SYSHUB_AES_Key3_3_SHIFT  0

#define MP0_SYSHUB_AES_Key3_3_MP0_SYSHUB_AES_Key3_3_MASK  0xffffffff

#define MP0_SYSHUB_AES_Key3_3_MASK \
      (MP0_SYSHUB_AES_Key3_3_MP0_SYSHUB_AES_Key3_3_MASK)

#define MP0_SYSHUB_AES_Key3_3_DEFAULT  0x00000000

#define MP0_SYSHUB_AES_Key3_3_GET_MP0_SYSHUB_AES_Key3_3(mp0_syshub_aes_key3_3) \
      ((mp0_syshub_aes_key3_3 & MP0_SYSHUB_AES_Key3_3_MP0_SYSHUB_AES_Key3_3_MASK) >> MP0_SYSHUB_AES_Key3_3_MP0_SYSHUB_AES_Key3_3_SHIFT)

#define MP0_SYSHUB_AES_Key3_3_SET_MP0_SYSHUB_AES_Key3_3(mp0_syshub_aes_key3_3_reg, mp0_syshub_aes_key3_3) \
      mp0_syshub_aes_key3_3_reg = (mp0_syshub_aes_key3_3_reg & ~MP0_SYSHUB_AES_Key3_3_MP0_SYSHUB_AES_Key3_3_MASK) | (mp0_syshub_aes_key3_3 << MP0_SYSHUB_AES_Key3_3_MP0_SYSHUB_AES_Key3_3_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_aes_key3_3_t {
            unsigned int mp0_syshub_aes_key3_3          : MP0_SYSHUB_AES_Key3_3_MP0_SYSHUB_AES_Key3_3_SIZE;
      } mp0_syshub_aes_key3_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_aes_key3_3_t {
            unsigned int mp0_syshub_aes_key3_3          : MP0_SYSHUB_AES_Key3_3_MP0_SYSHUB_AES_Key3_3_SIZE;
      } mp0_syshub_aes_key3_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_aes_key3_3_t f;
} mp0_syshub_aes_key3_3_u;


/*
 * MP0_SYSHUB_AES_Tweak struct
 */

#define MP0_SYSHUB_AES_Tweak_REG_SIZE         32
#define MP0_SYSHUB_AES_Tweak_MP0_SYSHUB_AES_Value_SIZE  32

#define MP0_SYSHUB_AES_Tweak_MP0_SYSHUB_AES_Value_SHIFT  0

#define MP0_SYSHUB_AES_Tweak_MP0_SYSHUB_AES_Value_MASK  0xffffffff

#define MP0_SYSHUB_AES_Tweak_MASK \
      (MP0_SYSHUB_AES_Tweak_MP0_SYSHUB_AES_Value_MASK)

#define MP0_SYSHUB_AES_Tweak_DEFAULT   0x00000000

#define MP0_SYSHUB_AES_Tweak_GET_MP0_SYSHUB_AES_Value(mp0_syshub_aes_tweak) \
      ((mp0_syshub_aes_tweak & MP0_SYSHUB_AES_Tweak_MP0_SYSHUB_AES_Value_MASK) >> MP0_SYSHUB_AES_Tweak_MP0_SYSHUB_AES_Value_SHIFT)

#define MP0_SYSHUB_AES_Tweak_SET_MP0_SYSHUB_AES_Value(mp0_syshub_aes_tweak_reg, mp0_syshub_aes_value) \
      mp0_syshub_aes_tweak_reg = (mp0_syshub_aes_tweak_reg & ~MP0_SYSHUB_AES_Tweak_MP0_SYSHUB_AES_Value_MASK) | (mp0_syshub_aes_value << MP0_SYSHUB_AES_Tweak_MP0_SYSHUB_AES_Value_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_aes_tweak_t {
            unsigned int mp0_syshub_aes_value           : MP0_SYSHUB_AES_Tweak_MP0_SYSHUB_AES_Value_SIZE;
      } mp0_syshub_aes_tweak_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_aes_tweak_t {
            unsigned int mp0_syshub_aes_value           : MP0_SYSHUB_AES_Tweak_MP0_SYSHUB_AES_Value_SIZE;
      } mp0_syshub_aes_tweak_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_aes_tweak_t f;
} mp0_syshub_aes_tweak_u;


/*
 * MP0_SYSHUB_AES_CFG_EnaClkGating struct
 */

#define MP0_SYSHUB_AES_CFG_EnaClkGating_REG_SIZE         32
#define MP0_SYSHUB_AES_CFG_EnaClkGating_CLK_GATE_EN_SIZE  1

#define MP0_SYSHUB_AES_CFG_EnaClkGating_CLK_GATE_EN_SHIFT  0

#define MP0_SYSHUB_AES_CFG_EnaClkGating_CLK_GATE_EN_MASK  0x00000001

#define MP0_SYSHUB_AES_CFG_EnaClkGating_MASK \
      (MP0_SYSHUB_AES_CFG_EnaClkGating_CLK_GATE_EN_MASK)

#define MP0_SYSHUB_AES_CFG_EnaClkGating_DEFAULT 0x00000000

#define MP0_SYSHUB_AES_CFG_EnaClkGating_GET_CLK_GATE_EN(mp0_syshub_aes_cfg_enaclkgating) \
      ((mp0_syshub_aes_cfg_enaclkgating & MP0_SYSHUB_AES_CFG_EnaClkGating_CLK_GATE_EN_MASK) >> MP0_SYSHUB_AES_CFG_EnaClkGating_CLK_GATE_EN_SHIFT)

#define MP0_SYSHUB_AES_CFG_EnaClkGating_SET_CLK_GATE_EN(mp0_syshub_aes_cfg_enaclkgating_reg, clk_gate_en) \
      mp0_syshub_aes_cfg_enaclkgating_reg = (mp0_syshub_aes_cfg_enaclkgating_reg & ~MP0_SYSHUB_AES_CFG_EnaClkGating_CLK_GATE_EN_MASK) | (clk_gate_en << MP0_SYSHUB_AES_CFG_EnaClkGating_CLK_GATE_EN_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_syshub_aes_cfg_enaclkgating_t {
            unsigned int clk_gate_en                    : MP0_SYSHUB_AES_CFG_EnaClkGating_CLK_GATE_EN_SIZE;
            unsigned int                                : 31;
      } mp0_syshub_aes_cfg_enaclkgating_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_syshub_aes_cfg_enaclkgating_t {
            unsigned int                                : 31;
            unsigned int clk_gate_en                    : MP0_SYSHUB_AES_CFG_EnaClkGating_CLK_GATE_EN_SIZE;
      } mp0_syshub_aes_cfg_enaclkgating_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_syshub_aes_cfg_enaclkgating_t f;
} mp0_syshub_aes_cfg_enaclkgating_u;


#endif

