#ifndef SMN_H
#define SMN_H

#include "stdint.h"
#include <mp_smnif_reg.h>
#include "chip_offset_byte.h"
#include <mpm_cru_reg.h>
#include <mp2_cru_reg.h>
//#include "kernel/kernel.h"
//
#define LOCAL_SMNIF_TLB_0               GEN_MP_REG(SMNIF_TLB_0)
#define LOCAL_SMNIF_TLB_1               GEN_MP_REG(SMNIF_TLB_1)
#define SMNIF_GENERIC_TLB               28
#define SMNIF_TLB_ADDR_OFFSET_MASK      0xFFFFF
#define SMNIF_TLB_CONFIG_ADDR_SHIFT     20
#define TLB_ADDR_OFFSET                 (LOCAL_SMNIF_TLB_1 - LOCAL_SMNIF_TLB_0)
#define PRG_TLB_CONFIG_ADDR             (LOCAL_SMNIF_TLB_0 + (TLB_ADDR_OFFSET * (SMNIF_GENERIC_TLB)))

typedef smnif_tlb_14_u TLB;

void SetupSmnIfTLBs();

// CAUTION: This might change from program to program
#define SCF_START_ADDRESS       0x2F00000

// SMN Access Macros
#define RSMU_TLB_INDEX          0   // RSMU MMIO space
#define GPU_TLB_INDEX           1   // GPU0 MMIO space
#define MP0_TLB_INDEX           2   // MP0 MMIO Public space
#define FCH_TLB_INDEX           3   // FCH MMIO space

#define CCX0_TLB_IDX_START      4   // CCX0 - Start TLB
#define CCX0_0_TLB_INDEX        4   // CCX0 - 1st MB
#define CCX0_1_TLB_INDEX        5   // CCX0 - 2nd MB
#define CCX0_2_TLB_INDEX        6   // CCX0 - 3rd MB
#define CCX0_3_TLB_INDEX        7   // CCX0 - 4th MB
#define CCX1_0_TLB_INDEX        8   // CCX1 - 1st MB
#define CCX1_1_TLB_INDEX        9   // CCX1 - 2nd MB
#define CCX1_2_TLB_INDEX        10  // CCX1 - 3rd MB
#define CCX1_3_TLB_INDEX        11  // CCX1 - 4th MB

#define DF_TLB_INDEX            12  // DF
#define SCF_TLB_INDEX           13  // SCF
#define BIF0_TLB_INDEX          14  // BIF0
#define SHUB0_TLB_INDEX         15  // SHUB0
#define AZ_TLB_INDEX            16  // AZ

#define MP2_TLB_INDEX           17  // MP0 MMIO Public space
#define IOHC0_TLB_INDEX         18  // IOHC0
#define RSMU_CCXSEC_TLB_INDEX   19  // RSMU CCXSEC MMIO space

#define USB0_0_TLB_INDEX        20  // USB0 (1st MB)
#define USB0_1_TLB_INDEX        21  // USB0 (2nd MB)
#define USB1_0_TLB_INDEX        22  // USB1 (1st MB)
#define USB1_1_TLB_INDEX        23  // USB1 (2nd MB)
#define XGBE_TLB_INDEX          24  // XGBE

#define S0I3_0_TLB_INDEX        25  // Reserving TLB indexes 25 and 26 for S0i3 SMN Aperture
#define S0I3_1_TLB_INDEX        26

#define STATIC_TLB_INDEX        27  // TODO: This is an available TLB as long as it is set up at boot time.
// Indices 2-27 Unused
#define PRG_TLB_INDEX           28  // Programmable SMN space 

// FIXME Confirm this for SOC15
// Indices 30, 31 that map to TLB15 are dedicated for HDT accesses.
// Firmware should never use indices 30, 31.

#define RSMU_TLB          (((uint32_t) RSMU_TLB_INDEX   ) << 20)  // RSMU MMIO space
#define GPU_TLB           (((uint32_t) GPU_TLB_INDEX    ) << 20)  // GPU0 MMIO space
#define MP0_TLB           (((uint32_t) MP0_TLB_INDEX    ) << 20)  // MP0 MMIO Public space
#define FCH_TLB           (((uint32_t) FCH_TLB_INDEX    ) << 20)  // FCH MMIO space

#define CCX0_0_TLB        (((uint32_t) CCX0_0_TLB_INDEX  ) << 20) // CCX0 CPUCFG space - 1st MB
#define CCX0_1_TLB        (((uint32_t) CCX0_1_TLB_INDEX  ) << 20) // CCX0 CPUCFG space - 2nd MB
#define CCX0_2_TLB        (((uint32_t) CCX0_2_TLB_INDEX  ) << 20) // CCX0 CPUCFG space - 3rd MB
#define CCX0_3_TLB        (((uint32_t) CCX0_3_TLB_INDEX  ) << 20) // CCX0 CPUCFG space - 4th MB
#define CCX1_0_TLB        (((uint32_t) CCX1_0_TLB_INDEX  ) << 20) // CCX1 CPUCFG space - 1st MB
#define CCX1_1_TLB        (((uint32_t) CCX1_1_TLB_INDEX  ) << 20) // CCX1 CPUCFG space - 2nd MB
#define CCX1_2_TLB        (((uint32_t) CCX1_2_TLB_INDEX  ) << 20) // CCX1 CPUCFG space - 3rd MB
#define CCX1_3_TLB        (((uint32_t) CCX1_3_TLB_INDEX  ) << 20) // CCX1 CPUCFG space - 4th MB

#define DF_TLB            (((uint32_t) DF_TLB_INDEX     ) << 20)  // DF MMIO space
#define SCF_TLB           (((uint32_t) SCF_TLB_INDEX    ) << 20)  // SCF MMIO space
#define BIF0_TLB          (((uint32_t) BIF0_TLB_INDEX   ) << 20)  // BIF0 MMIO space
#define SHUB0_TLB         (((uint32_t) SHUB0_TLB_INDEX  ) << 20)  // SHUB0 MMIO space
#define AZ_TLB            (((uint32_t) AZ_TLB_INDEX     ) << 20)  // AZ MMIO space
#define MP2_TLB           (((uint32_t) MP2_TLB_INDEX    ) << 20)  // MP0 MMIO Public space
#define IOHC0_TLB         (((uint32_t) IOHC0_TLB_INDEX  ) << 20)  // IOHC0 MMIO space
#define RSMU_CCXSEC_TLB   (((uint32_t) RSMU_CCXSEC_TLB_INDEX ) << 20)  // RSMU CCXSEC MMIO space
#define USB0_0_TLB        (((uint32_t) USB0_0_TLB_INDEX ) << 20)  // USB0 space
#define USB0_1_TLB        (((uint32_t) USB0_1_TLB_INDEX ) << 20)  // USB0 space
#define USB1_0_TLB        (((uint32_t) USB1_0_TLB_INDEX ) << 20)  // USB1 space
#define USB1_1_TLB        (((uint32_t) USB1_1_TLB_INDEX ) << 20)  // USB1 space
#define XGBE_TLB          (((uint32_t) XGBE_TLB_INDEX   ) << 20)  // XGBE space

#define STATIC_TLB        (((uint32_t) STATIC_TLB_INDEX ) << 20)  // Available TLB
// Indices 2-27 Unused
#define PRG_TLB           (((uint32_t) PRG_TLB_INDEX    ) << 20)  // Programmable space

// AUTOREG macros
/*#define AR_FIELD_SHIFT(reg, field)                      reg##_##field##_SHIFT
#define AR_FIELD_MASK(reg, field)                       reg##_##field##_MASK
#define AR_GET_FIELD(value, reg, field)                 (((value) & AR_FIELD_MASK(reg, field)) >> AR_FIELD_SHIFT(reg, field))
#define AR_SET_FIELD(origval, reg, field, fieldval)     (((origval) & ~AR_FIELD_MASK(reg, field)) | (AR_FIELD_MASK(reg, field) \
                                                        & (((uint32_t)(fieldval)) << AR_FIELD_SHIFT(reg, field))))
#define AR_SET_FIELD_VAR(var, reg, field, fieldval)     var = AR_SET_FIELD(var, reg, field, fieldval)

#ifndef STANDALONE_COMPILE
#define REG8(addr)                                      *((volatile uint8_t *) (addr))
#define REG16(addr)                                     *((volatile uint16_t *) (addr))
#define REG32(addr)                                     *((volatile uint32_t *) (addr))
#define REG64(addr)                                     *((volatile uint64_t *) (addr))
#define DREG32(addr)                                    *((uint32_t *) (addr))
#endif*/

#define MPM_REG(reg)                                    REG32(mm##reg)
#define MPM_DREG(reg)                                   DREG32(mm##reg)
#define MPM_REG_ADDR(reg)                               REG32(reg)
#define MPM_REG64_ADDR(reg)                             REG64(reg)
#define MPM_REG_READ_FIELD(reg, field)                  AR_GET_FIELD(MPM_REG(reg), reg, field)
#define MPM_REG_WRITE_FIELD(reg, field, fieldval)       MPM_REG(reg) = AR_SET_FIELD(MPM_REG(reg), reg, field, fieldval)



#define RSMU_REG(reg)                                   REG32((MP__SMNIF_START_ADDR + RSMU_TLB) + (mm##reg & 0xFFFFF))
#define RSMU_DREG(reg)                                  DREG32((MP__SMNIF_START_ADDR + RSMU_TLB) + (mm##reg & 0xFFFFF))
#define RSMU_REG_ADDR(reg)                              REG32((MP__SMNIF_START_ADDR + RSMU_TLB) + ((reg) & 0xFFFFF))
#define RSMU_DREG_ADDR(reg)                             DREG32((MP__SMNIF_START_ADDR + RSMU_TLB) + ((reg) & 0xFFFFF))
#define RSMU_REG64_ADDR(reg)                                REG64((MP__SMNIF_START_ADDR + RSMU_TLB) + ((reg) & 0xFFFFF))
#define RSMU_REG_READ_FIELD(reg, field)                 AR_GET_FIELD(RSMU_REG(reg), reg, field)
#define RSMU_REG_WRITE_FIELD(reg, field, fieldval)      RSMU_REG(reg) = AR_SET_FIELD(RSMU_REG(reg), reg, field, fieldval)
#define RSMU_REG_RMW(reg, data, mask)                   RSMU_REG(reg) = ((uint32_t)data & (uint32_t)mask) | (RSMU_REG(reg) & ~(uint32_t)mask)
#define RSMU_REG_MAKE_AXI_ADDR_FROM_SMN(addr)           ((MP__SMNIF_START_ADDR + RSMU_TLB) + ((addr) & 0xFFFFF))
#define RSMU_ADDR(reg)                                  ((MP__SMNIF_START_ADDR + RSMU_TLB) + ((reg) & 0xFFFFF))

#define GPU_REG(reg)                                    REG32((MP__SMNIF_START_ADDR + GPU_TLB) + (mm##reg & 0xFFFFF))
#define GPU_DREG(reg)                                   DREG32((MP__SMNIF_START_ADDR + GPU_TLB) + (mm##reg & 0xFFFFF))
#define GPU_REG_ADDR(reg)                               REG32((MP__SMNIF_START_ADDR + GPU_TLB) + ((reg) & 0xFFFFF))
#define GPU_DREG_ADDR(reg)                              DREG32((MP__SMNIF_START_ADDR + GPU_TLB) + ((reg) & 0xFFFFF))
#define GPU_REG_READ_FIELD(reg, field)                  AR_GET_FIELD(GPU_REG(reg), reg, field)
#define GPU_DREG_READ_FIELD(reg, field)                 AR_GET_FIELD(GPU_DREG(reg), reg, field)
#define GPU_REG_WRITE_FIELD(reg, field, fieldval)       GPU_REG(reg) = AR_SET_FIELD(GPU_REG(reg), reg, field, fieldval)
#define GPU_DREG_WRITE_FIELD(reg, field, fieldval)      GPU_DREG(reg) = AR_SET_FIELD(GPU_DREG(reg), reg, field, fieldval)
#define GPU_REG_READ_FIELD_INST(inst, reg, field)                  AR_GET_FIELD(GPU_REG(inst), reg, field)
#define GPU_REG_WRITE_FIELD_INST(inst, reg, field, fieldval)       GPU_REG(inst) = AR_SET_FIELD(GPU_REG(inst), reg, field, fieldval)
#define GPU_REG_RMW(reg, data, mask)                    GPU_REG(reg) = ((uint32_t)data & (uint32_t)mask) | (GPU_REG(reg) & ~(uint32_t)mask)
#define GPU_REG_MAKE_AXI_ADDR(reg)                      ((MP__SMNIF_START_ADDR + GPU_TLB) + (mm##reg & 0xFFFFF))
#define GPU_ADDR_MAKE_AXI_ADDR(reg)                     ((MP__SMNIF_START_ADDR + GPU_TLB) + (reg & 0xFFFFF))
#define GPU_ADDR(reg)                                   ((MP__SMNIF_START_ADDR + GPU_TLB) + (reg & 0xFFFFF))

// Reuses the GPU_TLB with minor modifications from GPU_REG
#define DLDO_REG(reg)                                   REG32((MP__SMNIF_START_ADDR + GPU_TLB) + (mm##reg & 0xFFFFF))
#define DLDO_REG_ADDR(reg)                              REG32((MP__SMNIF_START_ADDR + GPU_TLB) + ((reg) & 0xFFFFF))
#define DLDO_REG_READ_FIELD(reg, field)                 AR_GET_FIELD(DLDO_REG(reg), reg, field)
#define DLDO_REG_WRITE_FIELD(reg, field, fieldval)      DLDO_REG(reg) = AR_SET_FIELD(DLDO_REG(reg), reg, field, fieldval)
#define DLDO_REG_RMW(reg, data, mask)                   DLDO_REG(reg) = ((uint32_t)data & (uint32_t)mask) | (DLDO_REG(reg) & ~(uint32_t)mask)

#define MP0_REG(reg)                                    REG32((MP__SMNIF_START_ADDR + MP0_TLB) + (mm##reg & 0xFFFFF))
#define MP0_REG_ADDR(reg)                               REG32((MP__SMNIF_START_ADDR + MP0_TLB) + ((reg) & 0xFFFFF))
#define MP0_REG_READ_FIELD(reg, field)                  AR_GET_FIELD(MP0_REG(reg), reg, field)
#define MP0_REG_WRITE_FIELD(reg, field, fieldval)       MP0_REG(reg) = AR_SET_FIELD(MP0_REG(reg), reg, field, fieldval)
#define MP0_REG_RMW(reg, data, mask)                    MP0_REG(reg) = ((uint32_t)data & (uint32_t)mask) | (MP0_REG(reg) & ~(uint32_t)mask)

#define MP2_REG(reg)                                    REG32((MP__SMNIF_START_ADDR + MP2_TLB) + (mm##reg & 0xFFFFF))
#define MP2_REG_ADDR(reg)                               REG32((MP__SMNIF_START_ADDR + MP2_TLB) + ((reg) & 0xFFFFF))
#define MP2_REG_READ_FIELD(reg, field)                  AR_GET_FIELD(MP2_REG(reg), reg, field)
#define MP2_REG_WRITE_FIELD(reg, field, fieldval)       MP2_REG(reg) = AR_SET_FIELD(MP2_REG(reg), reg, field, fieldval)
#define MP2_REG_RMW(reg, data, mask)                    MP2_REG(reg) = ((uint32_t)data & (uint32_t)mask) | (MP2_REG(reg) & ~(uint32_t)mask)

#define IOHC0_REG(reg)                                  REG32((MP__SMNIF_START_ADDR + IOHC0_TLB) + (mm##reg & 0xFFFFF))
#define IOHC0_REG_ADDR(reg)                             REG32((MP__SMNIF_START_ADDR + IOHC0_TLB) + ((reg) & 0xFFFFF))
#define IOHC0_REG_READ_FIELD(reg, field)                AR_GET_FIELD(IOHC0_REG(reg), reg, field)
#define IOHC0_REG_WRITE_FIELD(reg, field, fieldval)     IOHC0_REG(reg) = AR_SET_FIELD(IOHC0_REG(reg), reg, field, fieldval)
#define IOHC0_REG_RMW(reg, data, mask)                  IOHC0_REG(reg) = ((uint32_t)data & (uint32_t)mask) | (IOHC0_REG(reg) & ~(uint32_t)mask)

#define FCH_REG(reg)                                    REG32((MP__SMNIF_START_ADDR + FCH_TLB) + (mm##reg & 0xFFFFF))
#define FCH_REG_ADDR(reg)                               REG32((MP__SMNIF_START_ADDR + FCH_TLB) + ((reg) & 0xFFFFF))
#define FCH_REG_READ_FIELD(reg, field)                  AR_GET_FIELD(FCH_REG(reg), reg, field)
#define FCH_REG_WRITE_FIELD(reg, field, fieldval)       FCH_REG(reg) = AR_SET_FIELD(FCH_REG(reg), reg, field, fieldval)
#define FCH_REG_RMW(reg, data, mask)                    FCH_REG(reg) = ((uint32_t)data & (uint32_t)mask) | (FCH_REG(reg) & ~(uint32_t)mask)

#define FCH_REG8(reg)                                   REG8((MP__SMNIF_START_ADDR + FCH_TLB) + (mm##reg & 0xFFFFF))
#define FCH_REG8_ADDR(reg)                              REG8((MP__SMNIF_START_ADDR + FCH_TLB) + ((reg) & 0xFFFFF))
#define FCH_REG16(reg)                                  REG16((MP__SMNIF_START_ADDR + FCH_TLB) + (mm##reg & 0xFFFFF))
#define FCH_REG32(reg)                                  REG32((MP__SMNIF_START_ADDR + FCH_TLB) + (mm##reg & 0xFFFFF))
#define FCH_REG32_ADDR(reg)                             REG32((MP__SMNIF_START_ADDR + FCH_TLB) + ((reg) & 0xFFFFF))
#define FCH_REG32_READ_FIELD(reg, field)                AR_GET_FIELD(FCH_REG(reg), reg, field)
#define FCH_REG32_WRITE_FIELD(reg, field, fieldval)     FCH_REG(reg) = AR_SET_FIELD(FCH_REG(reg), reg, field, fieldval)
#define FCH_REG32_RMW(reg, data, mask)                  FCH_REG(reg) = ((uint32_t)data & (uint32_t)mask) | (FCH_REG(reg) & ~(uint32_t)mask)

#define CCX0_REG(reg)                                   REG32((MP__SMNIF_START_ADDR + CCX0_0_TLB) + (mm##reg & 0x3fffff))
#define CCX0_REG_ADDR(reg)                              REG32((MP__SMNIF_START_ADDR + CCX0_0_TLB) + (reg & 0x3fffff))
#define CCX0_REG_READ_FIELD(reg, field)                 AR_GET_FIELD(CCX0_REG(reg), reg, field)
#define CCX0_REG_WRITE_FIELD(reg, field, fieldval)      CCX0_REG(reg) = AR_SET_FIELD(CCX0_REG(reg), reg, field, fieldval)
#define CCX0_REG_RMW(reg, data, mask)                   CCX0_REG(reg) = ((uint32_t)data & (uint32_t)mask) | (CCX0_REG(reg) & ~(uint32_t)mask)

#define CCX1_REG(reg)                                   REG32((MP__SMNIF_START_ADDR + CCX1_0_TLB) + (mm##reg & 0x3fffff))
#define CCX1_REG_ADDR(reg)                              REG32((MP__SMNIF_START_ADDR + CCX1_0_TLB) + (reg & 0x3fffff))
#define CCX1_REG_READ_FIELD(reg, field)                 AR_GET_FIELD(CCX1_REG(reg), reg, field)
#define CCX1_REG_WRITE_FIELD(reg, field, fieldval)      CCX1_REG(reg) = AR_SET_FIELD(CCX1_REG(reg), reg, field, fieldval)
#define CCX1_REG_RMW(reg, data, mask)                   CCX1_REG(reg) = ((uint32_t)data & (uint32_t)mask) | (CCX1_REG(reg) & ~(uint32_t)mask)

#define CCX_REG(ccx, core, reg)                         REG32 (MP__SMNIF_START_ADDR + (CCX0_0_TLB_INDEX << 20) + (ccx * 0x400000) + (core * 0x20000) + (mm##reg & 0x1FFFF))
#define CCX_REG_READ_FIELD(ccx, core, reg, field)       AR_GET_FIELD(CCX_REG(ccx, core, reg), reg, field)
#define CCX_REG_WRITE_FIELD(ccx, core, reg, field, fieldval)      CCX_REG(ccx, core, reg) = AR_SET_FIELD(CCX_REG(ccx, core, reg), reg, field, fieldval)
#define CCX_REG64(ccx, core, reg)                       REG64 (MP__SMNIF_START_ADDR + ((CCX0_0_TLB_INDEX + ccx * 4) << 20) + ((core << 17) + (mm##reg & 0x1FFFF)))
#define CCX_DREG(ccx, core, reg)                        DREG32(MP__SMNIF_START_ADDR + ((CCX0_0_TLB_INDEX + ccx * 4) << 20) + ((core << 17) + (mm##reg & 0x1FFFF)))
#define CCX_REG_ADDR(ccx, core, reg)                    REG32 (MP__SMNIF_START_ADDR + ((CCX0_0_TLB_INDEX + ccx * 4) << 20) + ((core << 17) + (reg & 0x1FFFF)))
#define CCX_DREG_ADDR(ccx, core, reg)                   DREG32(MP__SMNIF_START_ADDR + ((CCX0_0_TLB_INDEX + ccx * 4) << 20) + ((core << 17) + (reg & 0x1FFFF))) 
#define CCX_ADDR(ccx, core, reg)                        (MP__SMNIF_START_ADDR + ((CCX0_0_TLB_INDEX + ccx * 4) << 20) + ((core << 17) + ((reg) & 0x1FFFF))) 
#define CCX_ADDR_BASE(base, reg)                        ((base) + ((reg) & 0x1FFFF)) 
#define CCX_BASE_ADDR(ccx, core)                        (MP__SMNIF_START_ADDR + ((CCX0_0_TLB_INDEX + ccx * 4) << 20) + (core << 17)) 
#define CCX_REG_BASE(base, reg)                         REG32 ((base) + (mm##reg & 0x1FFFF))
#define CCX_DREG_BASE(base, reg)                        DREG32 ((base) + (mm##reg & 0x1FFFF))
#define CCX_REG_ADDR_BASE(base, reg)                    REG32 ((base) + ((reg) & 0x1FFFF))
#define CCX_DREG_ADDR_BASE(base, reg)                   DREG32 ((base) + ((reg) & 0x1FFFF))
#define CCX_BASE_READ_FIELD(base, reg, field)           AR_GET_FIELD(CCX_REG_BASE(base, reg), reg, field)
#define CCX_DBASE_READ_FIELD(base, reg, field)          AR_GET_FIELD(CCX_DREG_BASE(base, reg), reg, field)

#define DF_REG(reg)                                     REG32((MP__SMNIF_START_ADDR + DF_TLB) + (mm##reg & 0xFFFFF))
#define DF_DREG(reg)                                    DREG32((MP__SMNIF_START_ADDR + DF_TLB) + (mm##reg & 0xFFFFF))
#define DF_REG_ADDR(reg)                                REG32((MP__SMNIF_START_ADDR + DF_TLB) + ((reg) & 0xFFFFF))
#define DF_REG_READ_FIELD(reg, field)                   AR_GET_FIELD(DF_REG(reg), reg, field)
#define DF_REG_WRITE_FIELD(reg, field, fieldval)        DF_REG(reg) = AR_SET_FIELD(DF_REG(reg), reg, field, fieldval)
#define DF_DREG_WRITE_FIELD(reg, field, fieldval)       DF_DREG(reg) = AR_SET_FIELD(DF_DREG(reg), reg, field, fieldval)
#define DF_REG_RMW(reg, data, mask)                     DF_REG(reg) = ((uint32_t)data & (uint32_t)mask) | (DF_REG(reg) & ~(uint32_t)mask)

#define SCF_REG(reg)                                    REG32((MP__SMNIF_START_ADDR + SCF_TLB) + (mm##reg & 0xFFFFF))
#define SCF_DREG(reg)                                   DREG32((MP__SMNIF_START_ADDR + SCF_TLB) + (mm##reg & 0xFFFFF))
#define SCF_REG_ADDR(reg)                               REG32((MP__SMNIF_START_ADDR + SCF_TLB) + ((reg) & 0xFFFFF))
#define SCF_REG_READ_FIELD(reg, field)                  AR_GET_FIELD(SCF_REG(reg), reg, field)
#define SCF_REG_WRITE_FIELD(reg, field, fieldval)       SCF_REG(reg) = AR_SET_FIELD(SCF_REG(reg), reg, field, fieldval)
#define SCF_REG_RMW(reg, data, mask)                    SCF_REG(reg) = ((uint32_t)data & (uint32_t)mask) | (SCF_REG(reg) & ~(uint32_t)mask)

#define BIF0_REG(reg)                                   REG32((MP__SMNIF_START_ADDR + BIF0_TLB) + (mmnbif_gpu_##reg & 0xFFFFF))
#define BIF0_REG_ADDR(reg)                              REG32((MP__SMNIF_START_ADDR + BIF0_TLB) + ((reg) & 0xFFFFF))
#define BIF0_REG_READ_FIELD(reg, field)                 AR_GET_FIELD(BIF0_REG(reg), nbif_gpu_##reg, field)
#define BIF0_REG_WRITE_FIELD(reg, field, fieldval)      BIF0_REG(reg) = AR_SET_FIELD(BIF0_REG(reg), nbif_gpu_##reg, field, fieldval)
#define BIF0_REG_RMW(reg, data, mask)                   BIF0_REG(reg) = ((uint32_t)data & (uint32_t)mask) | (BIF0_REG(reg) & ~(uint32_t)mask)

#define SHUB0_REG(reg)                                  REG32((MP__SMNIF_START_ADDR + SHUB0_TLB) + (mmnbif_gpu_##reg & 0xFFFFF))
#define SHUB0_REG_ADDR(reg)                             REG32((MP__SMNIF_START_ADDR + SHUB0_TLB) + ((reg) & 0xFFFFF))
#define SHUB0_REG_READ_FIELD(reg, field)                AR_GET_FIELD(SHUB0_REG(reg), nbif_gpu_##reg, field)
#define SHUB0_REG_WRITE_FIELD(reg, field, fieldval)     SHUB0_REG(reg) = AR_SET_FIELD(SHUB0_REG(reg), nbif_gpu_##reg, field, fieldval)
#define SHUB0_REG_RMW(reg, data, mask)                  SHUB0_REG(reg) = ((uint32_t)data & (uint32_t)mask) | (SHUB0_REG(reg) & ~(uint32_t)mask)

#define AZ_REG(reg)                                     REG32((MP__SMNIF_START_ADDR + AZ_TLB) + (mm##reg & 0xFFFFF))
#define AZ_REG_ADDR(reg)                                REG32((MP__SMNIF_START_ADDR + AZ_TLB) + ((reg) & 0xFFFFF))
#define AZ_REG_READ_FIELD(reg, field)                   AR_GET_FIELD(AZ_REG(reg), reg, field)
#define AZ_REG_WRITE_FIELD(reg, field, fieldval)        AZ_REG(reg) = AR_SET_FIELD(AZ_REG(reg), reg, field, fieldval)
#define AZ_REG_RMW(reg, data, mask)                     AZ_REG(reg) = ((uint32_t)data & (uint32_t)mask) | (AZ_REG(reg) & ~(uint32_t)mask)

#define RSMU_CCXSEC_REG(reg)                                 REG32((MP__SMNIF_START_ADDR + RSMU_CCXSEC_TLB) + (mm##reg & 0xFFFFF))
#define RSMU_CCXSEC_REG_ADDR(reg)                            REG32((MP__SMNIF_START_ADDR + RSMU_CCXSEC_TLB) + ((reg) & 0xFFFFF))
#define RSMU_CCXSEC_REG_READ_FIELD(reg, field)               AR_GET_FIELD(RSMU_CCXSEC_REG(reg), reg, field)
#define RSMU_CCXSEC_REG_WRITE_FIELD(reg, field, fieldval)    RSMU_CCXSEC_REG(reg) = AR_SET_FIELD(RSMU_CCXSEC_REG(reg), reg, field, fieldval)
#define RSMU_CCXSEC_REG_RMW(reg, data, mask)                 RSMU_CCXSEC_REG(reg) = ((uint32_t)data & (uint32_t)mask) | (RSMU_CCXSEC_REG(reg) & ~(uint32_t)mask)

#define USB0_REG(reg)                                   REG32((MP__SMNIF_START_ADDR + USB0_0_TLB) + (mm##reg - RSMU__RSMU_INST_USB0_USBCFG_START_ADDRESS))
#define USB0_REG_ADDR(reg)                              REG32((MP__SMNIF_START_ADDR + USB0_0_TLB) + ((reg) - RSMU__RSMU_INST_USB0_USBCFG_START_ADDRESS))
#define USB0_REG_READ_FIELD(reg, field)                 AR_GET_FIELD(USB0_REG(reg), reg, field)
#define USB0_REG_WRITE_FIELD(reg, field, fieldval)      USB0_REG(reg) = AR_SET_FIELD(USB0_REG(reg), reg, field, fieldval)
#define USB0_REG_RMW(reg, data, mask)                   USB0_REG(reg) = ((uint32_t)data & (uint32_t)mask) | (USB0_REG(reg) & ~(uint32_t)mask)
#define USB0_REG_ADDR_RMW(reg, data, mask)              USB0_REG_ADDR(reg) = ((uint32_t)data & (uint32_t)mask) | (USB0_REG_ADDR(reg) & ~(uint32_t)mask)

#define USB1_REG(reg)                                   REG32((MP__SMNIF_START_ADDR + USB1_0_TLB) + (mm##reg - RSMU__RSMU_INST_USB1_USBCFG_START_ADDRESS))
#define USB1_REG_ADDR(reg)                              REG32((MP__SMNIF_START_ADDR + USB1_0_TLB) + ((reg) - RSMU__RSMU_INST_USB1_USBCFG_START_ADDRESS))
#define USB1_REG_READ_FIELD(reg, field)                 AR_GET_FIELD(USB1_REG(reg), reg, field)
#define USB1_REG_WRITE_FIELD(reg, field, fieldval)      USB1_REG(reg) = AR_SET_FIELD(USB1_REG(reg), reg, field, fieldval)
#define USB1_REG_RMW(reg, data, mask)                   USB1_REG(reg) = ((uint32_t)data & (uint32_t)mask) | (USB1_REG(reg) & ~(uint32_t)mask)
#define USB1_REG_ADDR_RMW(reg, data, mask)              USB1_REG_ADDR(reg) = ((uint32_t)data & (uint32_t)mask) | (USB1_REG_ADDR(reg) & ~(uint32_t)mask)

#define XGBE_REG(reg)                                   REG32((MP__SMNIF_START_ADDR + XGBE_TLB) + (mm##reg & 0xFFFFF))
#define XGBE_REG_ADDR(reg)                              REG32((MP__SMNIF_START_ADDR + XGBE_TLB) + ((reg) & 0xFFFFF))
#define XGBE_REG_READ_FIELD(reg, field)                 AR_GET_FIELD(XGBE_REG(reg), reg, field)
#define XGBE_REG_WRITE_FIELD(reg, field, fieldval)      XGBE_REG(reg) = AR_SET_FIELD(XGBE_REG(reg), reg, field, fieldval)
#define XGBE_REG_RMW(reg, data, mask)                   XGBE_REG(reg) = ((uint32_t)data & (uint32_t)mask) | (XGBE_REG(reg) & ~(uint32_t)mask)

// Generate SMN addresses
#define SMN_CORE_ADDR(ccx_id, core_id, addr)            (RSMU__RSMU_INST_CCXSEC0_CPUCFG_START_ADDRESS + (0x400000 * ccx_id) + (core_id << 17)) | (addr & 0xFFFFF)

#define SMU_ADDR(reg)                                   ((mm##reg&0xFFFFF))

#define WRITE_SMNREG(data, reg, tlb_idx)                REG32 ((MP__SMNIF_START_ADDR + ((tlb_idx) << 20)) + (mm##reg & 0xFFFFF)) = data
#define WRITE_DSMNREG(data, reg, tlb_idx)               DREG32((MP__SMNIF_START_ADDR + ((tlb_idx) << 20)) + (mm##reg & 0xFFFFF)) = data
#define WRITE_SMNREG_ADDR(data, reg, tlb_idx)           REG32 ((MP__SMNIF_START_ADDR + ((tlb_idx) << 20)) + ((reg) & 0xFFFFF)) = data
#define WRITE_DSMNREG_ADDR(data, reg, tlb_idx)          DREG32((MP__SMNIF_START_ADDR + ((tlb_idx) << 20)) + ((reg) & 0xFFFFF)) = data

#define READ_SMNREG(rd_data, reg, tlb_idx)              rd_data = REG32 ((MP__SMNIF_START_ADDR + ((tlb_idx) << 20)) + (mm##reg & 0xFFFFF))
#define READ_SMNREG_ADDR(rd_data, reg, tlb_idx)         rd_data = REG32 ((MP__SMNIF_START_ADDR + ((tlb_idx) << 20)) + ((reg) & 0xFFFFF))
#define READ_DSMNREG(rd_data, reg, tlb_idx)             rd_data = DREG32((MP__SMNIF_START_ADDR + ((tlb_idx) << 20)) + (mm##reg & 0xFFFFF))
#define READ_DSMNREG_ADDR(rd_data, reg, tlb_idx)        rd_data = DREG32((MP__SMNIF_START_ADDR + ((tlb_idx) << 20)) + ((reg) & 0xFFFFF))

#define REG_PROG(offset, val, reg)                      ((reg) & (0xFFFFFFFF ^ (1<<(offset)))) | ((val) << (offset)) 

#endif
