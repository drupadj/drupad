// Copyright (c) 1994 - 2021 Advanced Micro Devices, Inc. All rights reserved. 
 #if !defined (_MP1_HUBIF_NB_FIDDLE_H)
#define _MP1_HUBIF_NB_FIDDLE_H
 /*****************************************************************************************************************
 *
 *  mp1_hubif_nb_reg.h
 *
 *  Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif

 /*******************************************************
 * Values
 *******************************************************/

 /*******************************************************
 * Structures
 *******************************************************/

/*
 * MP1_HUBIF_NB_AX_ADDR_LO struct
 */

#define MP1_HUBIF_NB_AX_ADDR_LO_REG_SIZE         32
#define MP1_HUBIF_NB_AX_ADDR_LO_AX_ADDR_LO_SIZE  32

#define MP1_HUBIF_NB_AX_ADDR_LO_AX_ADDR_LO_SHIFT  0

#define MP1_HUBIF_NB_AX_ADDR_LO_AX_ADDR_LO_MASK  0xffffffff

#define MP1_HUBIF_NB_AX_ADDR_LO_MASK \
      (MP1_HUBIF_NB_AX_ADDR_LO_AX_ADDR_LO_MASK)

#define MP1_HUBIF_NB_AX_ADDR_LO_DEFAULT 0x00000000

#define MP1_HUBIF_NB_AX_ADDR_LO_GET_AX_ADDR_LO(mp1_hubif_nb_ax_addr_lo) \
      ((mp1_hubif_nb_ax_addr_lo & MP1_HUBIF_NB_AX_ADDR_LO_AX_ADDR_LO_MASK) >> MP1_HUBIF_NB_AX_ADDR_LO_AX_ADDR_LO_SHIFT)

#define MP1_HUBIF_NB_AX_ADDR_LO_SET_AX_ADDR_LO(mp1_hubif_nb_ax_addr_lo_reg, ax_addr_lo) \
      mp1_hubif_nb_ax_addr_lo_reg = (mp1_hubif_nb_ax_addr_lo_reg & ~MP1_HUBIF_NB_AX_ADDR_LO_AX_ADDR_LO_MASK) | (ax_addr_lo << MP1_HUBIF_NB_AX_ADDR_LO_AX_ADDR_LO_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_ax_addr_lo_t {
            unsigned int ax_addr_lo                     : MP1_HUBIF_NB_AX_ADDR_LO_AX_ADDR_LO_SIZE;
      } mp1_hubif_nb_ax_addr_lo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_ax_addr_lo_t {
            unsigned int ax_addr_lo                     : MP1_HUBIF_NB_AX_ADDR_LO_AX_ADDR_LO_SIZE;
      } mp1_hubif_nb_ax_addr_lo_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_ax_addr_lo_t f;
} mp1_hubif_nb_ax_addr_lo_u;


/*
 * MP1_HUBIF_NB_AX_MISC struct
 */

#define MP1_HUBIF_NB_AX_MISC_REG_SIZE         32
#define MP1_HUBIF_NB_AX_MISC_AX_ADDR_HI_SIZE  16
#define MP1_HUBIF_NB_AX_MISC_AX_ID_SIZE  8
#define MP1_HUBIF_NB_AX_MISC_AX_QOS_SIZE  4

#define MP1_HUBIF_NB_AX_MISC_AX_ADDR_HI_SHIFT  0
#define MP1_HUBIF_NB_AX_MISC_AX_ID_SHIFT  16
#define MP1_HUBIF_NB_AX_MISC_AX_QOS_SHIFT  24

#define MP1_HUBIF_NB_AX_MISC_AX_ADDR_HI_MASK  0x0000ffff
#define MP1_HUBIF_NB_AX_MISC_AX_ID_MASK  0x00ff0000
#define MP1_HUBIF_NB_AX_MISC_AX_QOS_MASK  0x0f000000

#define MP1_HUBIF_NB_AX_MISC_MASK \
      (MP1_HUBIF_NB_AX_MISC_AX_ADDR_HI_MASK | \
      MP1_HUBIF_NB_AX_MISC_AX_ID_MASK | \
      MP1_HUBIF_NB_AX_MISC_AX_QOS_MASK)

#define MP1_HUBIF_NB_AX_MISC_DEFAULT   0x00000000

#define MP1_HUBIF_NB_AX_MISC_GET_AX_ADDR_HI(mp1_hubif_nb_ax_misc) \
      ((mp1_hubif_nb_ax_misc & MP1_HUBIF_NB_AX_MISC_AX_ADDR_HI_MASK) >> MP1_HUBIF_NB_AX_MISC_AX_ADDR_HI_SHIFT)
#define MP1_HUBIF_NB_AX_MISC_GET_AX_ID(mp1_hubif_nb_ax_misc) \
      ((mp1_hubif_nb_ax_misc & MP1_HUBIF_NB_AX_MISC_AX_ID_MASK) >> MP1_HUBIF_NB_AX_MISC_AX_ID_SHIFT)
#define MP1_HUBIF_NB_AX_MISC_GET_AX_QOS(mp1_hubif_nb_ax_misc) \
      ((mp1_hubif_nb_ax_misc & MP1_HUBIF_NB_AX_MISC_AX_QOS_MASK) >> MP1_HUBIF_NB_AX_MISC_AX_QOS_SHIFT)

#define MP1_HUBIF_NB_AX_MISC_SET_AX_ADDR_HI(mp1_hubif_nb_ax_misc_reg, ax_addr_hi) \
      mp1_hubif_nb_ax_misc_reg = (mp1_hubif_nb_ax_misc_reg & ~MP1_HUBIF_NB_AX_MISC_AX_ADDR_HI_MASK) | (ax_addr_hi << MP1_HUBIF_NB_AX_MISC_AX_ADDR_HI_SHIFT)
#define MP1_HUBIF_NB_AX_MISC_SET_AX_ID(mp1_hubif_nb_ax_misc_reg, ax_id) \
      mp1_hubif_nb_ax_misc_reg = (mp1_hubif_nb_ax_misc_reg & ~MP1_HUBIF_NB_AX_MISC_AX_ID_MASK) | (ax_id << MP1_HUBIF_NB_AX_MISC_AX_ID_SHIFT)
#define MP1_HUBIF_NB_AX_MISC_SET_AX_QOS(mp1_hubif_nb_ax_misc_reg, ax_qos) \
      mp1_hubif_nb_ax_misc_reg = (mp1_hubif_nb_ax_misc_reg & ~MP1_HUBIF_NB_AX_MISC_AX_QOS_MASK) | (ax_qos << MP1_HUBIF_NB_AX_MISC_AX_QOS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_ax_misc_t {
            unsigned int ax_addr_hi                     : MP1_HUBIF_NB_AX_MISC_AX_ADDR_HI_SIZE;
            unsigned int ax_id                          : MP1_HUBIF_NB_AX_MISC_AX_ID_SIZE;
            unsigned int ax_qos                         : MP1_HUBIF_NB_AX_MISC_AX_QOS_SIZE;
            unsigned int                                : 4;
      } mp1_hubif_nb_ax_misc_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_ax_misc_t {
            unsigned int                                : 4;
            unsigned int ax_qos                         : MP1_HUBIF_NB_AX_MISC_AX_QOS_SIZE;
            unsigned int ax_id                          : MP1_HUBIF_NB_AX_MISC_AX_ID_SIZE;
            unsigned int ax_addr_hi                     : MP1_HUBIF_NB_AX_MISC_AX_ADDR_HI_SIZE;
      } mp1_hubif_nb_ax_misc_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_ax_misc_t f;
} mp1_hubif_nb_ax_misc_u;


/*
 * MP1_HUBIF_NB_AX_MISC_2 struct
 */

#define MP1_HUBIF_NB_AX_MISC_2_REG_SIZE         32
#define MP1_HUBIF_NB_AX_MISC_2_AX_LEN_SIZE  8
#define MP1_HUBIF_NB_AX_MISC_2_AX_SIZE_SIZE  3
#define MP1_HUBIF_NB_AX_MISC_2_AX_BURST_SIZE  2
#define MP1_HUBIF_NB_AX_MISC_2_AX_CACHE_SIZE  4
#define MP1_HUBIF_NB_AX_MISC_2_AX_PROT_SIZE  3
#define MP1_HUBIF_NB_AX_MISC_2_AX_LOCK_SIZE  2
#define MP1_HUBIF_NB_AX_MISC_2_AX_OPCODE_SIZE  1
#define MP1_HUBIF_NB_AX_MISC_2_AX_TRAN_STRT_SIZE  1
#define MP1_HUBIF_NB_AX_MISC_2_AX_TRAN_END_SIZE  1

#define MP1_HUBIF_NB_AX_MISC_2_AX_LEN_SHIFT  0
#define MP1_HUBIF_NB_AX_MISC_2_AX_SIZE_SHIFT  8
#define MP1_HUBIF_NB_AX_MISC_2_AX_BURST_SHIFT  11
#define MP1_HUBIF_NB_AX_MISC_2_AX_CACHE_SHIFT  13
#define MP1_HUBIF_NB_AX_MISC_2_AX_PROT_SHIFT  17
#define MP1_HUBIF_NB_AX_MISC_2_AX_LOCK_SHIFT  26
#define MP1_HUBIF_NB_AX_MISC_2_AX_OPCODE_SHIFT  28
#define MP1_HUBIF_NB_AX_MISC_2_AX_TRAN_STRT_SHIFT  29
#define MP1_HUBIF_NB_AX_MISC_2_AX_TRAN_END_SHIFT  30

#define MP1_HUBIF_NB_AX_MISC_2_AX_LEN_MASK  0x000000ff
#define MP1_HUBIF_NB_AX_MISC_2_AX_SIZE_MASK  0x00000700
#define MP1_HUBIF_NB_AX_MISC_2_AX_BURST_MASK  0x00001800
#define MP1_HUBIF_NB_AX_MISC_2_AX_CACHE_MASK  0x0001e000
#define MP1_HUBIF_NB_AX_MISC_2_AX_PROT_MASK  0x000e0000
#define MP1_HUBIF_NB_AX_MISC_2_AX_LOCK_MASK  0x0c000000
#define MP1_HUBIF_NB_AX_MISC_2_AX_OPCODE_MASK  0x10000000
#define MP1_HUBIF_NB_AX_MISC_2_AX_TRAN_STRT_MASK  0x20000000
#define MP1_HUBIF_NB_AX_MISC_2_AX_TRAN_END_MASK  0x40000000

#define MP1_HUBIF_NB_AX_MISC_2_MASK \
      (MP1_HUBIF_NB_AX_MISC_2_AX_LEN_MASK | \
      MP1_HUBIF_NB_AX_MISC_2_AX_SIZE_MASK | \
      MP1_HUBIF_NB_AX_MISC_2_AX_BURST_MASK | \
      MP1_HUBIF_NB_AX_MISC_2_AX_CACHE_MASK | \
      MP1_HUBIF_NB_AX_MISC_2_AX_PROT_MASK | \
      MP1_HUBIF_NB_AX_MISC_2_AX_LOCK_MASK | \
      MP1_HUBIF_NB_AX_MISC_2_AX_OPCODE_MASK | \
      MP1_HUBIF_NB_AX_MISC_2_AX_TRAN_STRT_MASK | \
      MP1_HUBIF_NB_AX_MISC_2_AX_TRAN_END_MASK)

#define MP1_HUBIF_NB_AX_MISC_2_DEFAULT 0x00000000

#define MP1_HUBIF_NB_AX_MISC_2_GET_AX_LEN(mp1_hubif_nb_ax_misc_2) \
      ((mp1_hubif_nb_ax_misc_2 & MP1_HUBIF_NB_AX_MISC_2_AX_LEN_MASK) >> MP1_HUBIF_NB_AX_MISC_2_AX_LEN_SHIFT)
#define MP1_HUBIF_NB_AX_MISC_2_GET_AX_SIZE(mp1_hubif_nb_ax_misc_2) \
      ((mp1_hubif_nb_ax_misc_2 & MP1_HUBIF_NB_AX_MISC_2_AX_SIZE_MASK) >> MP1_HUBIF_NB_AX_MISC_2_AX_SIZE_SHIFT)
#define MP1_HUBIF_NB_AX_MISC_2_GET_AX_BURST(mp1_hubif_nb_ax_misc_2) \
      ((mp1_hubif_nb_ax_misc_2 & MP1_HUBIF_NB_AX_MISC_2_AX_BURST_MASK) >> MP1_HUBIF_NB_AX_MISC_2_AX_BURST_SHIFT)
#define MP1_HUBIF_NB_AX_MISC_2_GET_AX_CACHE(mp1_hubif_nb_ax_misc_2) \
      ((mp1_hubif_nb_ax_misc_2 & MP1_HUBIF_NB_AX_MISC_2_AX_CACHE_MASK) >> MP1_HUBIF_NB_AX_MISC_2_AX_CACHE_SHIFT)
#define MP1_HUBIF_NB_AX_MISC_2_GET_AX_PROT(mp1_hubif_nb_ax_misc_2) \
      ((mp1_hubif_nb_ax_misc_2 & MP1_HUBIF_NB_AX_MISC_2_AX_PROT_MASK) >> MP1_HUBIF_NB_AX_MISC_2_AX_PROT_SHIFT)
#define MP1_HUBIF_NB_AX_MISC_2_GET_AX_LOCK(mp1_hubif_nb_ax_misc_2) \
      ((mp1_hubif_nb_ax_misc_2 & MP1_HUBIF_NB_AX_MISC_2_AX_LOCK_MASK) >> MP1_HUBIF_NB_AX_MISC_2_AX_LOCK_SHIFT)
#define MP1_HUBIF_NB_AX_MISC_2_GET_AX_OPCODE(mp1_hubif_nb_ax_misc_2) \
      ((mp1_hubif_nb_ax_misc_2 & MP1_HUBIF_NB_AX_MISC_2_AX_OPCODE_MASK) >> MP1_HUBIF_NB_AX_MISC_2_AX_OPCODE_SHIFT)
#define MP1_HUBIF_NB_AX_MISC_2_GET_AX_TRAN_STRT(mp1_hubif_nb_ax_misc_2) \
      ((mp1_hubif_nb_ax_misc_2 & MP1_HUBIF_NB_AX_MISC_2_AX_TRAN_STRT_MASK) >> MP1_HUBIF_NB_AX_MISC_2_AX_TRAN_STRT_SHIFT)
#define MP1_HUBIF_NB_AX_MISC_2_GET_AX_TRAN_END(mp1_hubif_nb_ax_misc_2) \
      ((mp1_hubif_nb_ax_misc_2 & MP1_HUBIF_NB_AX_MISC_2_AX_TRAN_END_MASK) >> MP1_HUBIF_NB_AX_MISC_2_AX_TRAN_END_SHIFT)

#define MP1_HUBIF_NB_AX_MISC_2_SET_AX_LEN(mp1_hubif_nb_ax_misc_2_reg, ax_len) \
      mp1_hubif_nb_ax_misc_2_reg = (mp1_hubif_nb_ax_misc_2_reg & ~MP1_HUBIF_NB_AX_MISC_2_AX_LEN_MASK) | (ax_len << MP1_HUBIF_NB_AX_MISC_2_AX_LEN_SHIFT)
#define MP1_HUBIF_NB_AX_MISC_2_SET_AX_SIZE(mp1_hubif_nb_ax_misc_2_reg, ax_size) \
      mp1_hubif_nb_ax_misc_2_reg = (mp1_hubif_nb_ax_misc_2_reg & ~MP1_HUBIF_NB_AX_MISC_2_AX_SIZE_MASK) | (ax_size << MP1_HUBIF_NB_AX_MISC_2_AX_SIZE_SHIFT)
#define MP1_HUBIF_NB_AX_MISC_2_SET_AX_BURST(mp1_hubif_nb_ax_misc_2_reg, ax_burst) \
      mp1_hubif_nb_ax_misc_2_reg = (mp1_hubif_nb_ax_misc_2_reg & ~MP1_HUBIF_NB_AX_MISC_2_AX_BURST_MASK) | (ax_burst << MP1_HUBIF_NB_AX_MISC_2_AX_BURST_SHIFT)
#define MP1_HUBIF_NB_AX_MISC_2_SET_AX_CACHE(mp1_hubif_nb_ax_misc_2_reg, ax_cache) \
      mp1_hubif_nb_ax_misc_2_reg = (mp1_hubif_nb_ax_misc_2_reg & ~MP1_HUBIF_NB_AX_MISC_2_AX_CACHE_MASK) | (ax_cache << MP1_HUBIF_NB_AX_MISC_2_AX_CACHE_SHIFT)
#define MP1_HUBIF_NB_AX_MISC_2_SET_AX_PROT(mp1_hubif_nb_ax_misc_2_reg, ax_prot) \
      mp1_hubif_nb_ax_misc_2_reg = (mp1_hubif_nb_ax_misc_2_reg & ~MP1_HUBIF_NB_AX_MISC_2_AX_PROT_MASK) | (ax_prot << MP1_HUBIF_NB_AX_MISC_2_AX_PROT_SHIFT)
#define MP1_HUBIF_NB_AX_MISC_2_SET_AX_LOCK(mp1_hubif_nb_ax_misc_2_reg, ax_lock) \
      mp1_hubif_nb_ax_misc_2_reg = (mp1_hubif_nb_ax_misc_2_reg & ~MP1_HUBIF_NB_AX_MISC_2_AX_LOCK_MASK) | (ax_lock << MP1_HUBIF_NB_AX_MISC_2_AX_LOCK_SHIFT)
#define MP1_HUBIF_NB_AX_MISC_2_SET_AX_OPCODE(mp1_hubif_nb_ax_misc_2_reg, ax_opcode) \
      mp1_hubif_nb_ax_misc_2_reg = (mp1_hubif_nb_ax_misc_2_reg & ~MP1_HUBIF_NB_AX_MISC_2_AX_OPCODE_MASK) | (ax_opcode << MP1_HUBIF_NB_AX_MISC_2_AX_OPCODE_SHIFT)
#define MP1_HUBIF_NB_AX_MISC_2_SET_AX_TRAN_STRT(mp1_hubif_nb_ax_misc_2_reg, ax_tran_strt) \
      mp1_hubif_nb_ax_misc_2_reg = (mp1_hubif_nb_ax_misc_2_reg & ~MP1_HUBIF_NB_AX_MISC_2_AX_TRAN_STRT_MASK) | (ax_tran_strt << MP1_HUBIF_NB_AX_MISC_2_AX_TRAN_STRT_SHIFT)
#define MP1_HUBIF_NB_AX_MISC_2_SET_AX_TRAN_END(mp1_hubif_nb_ax_misc_2_reg, ax_tran_end) \
      mp1_hubif_nb_ax_misc_2_reg = (mp1_hubif_nb_ax_misc_2_reg & ~MP1_HUBIF_NB_AX_MISC_2_AX_TRAN_END_MASK) | (ax_tran_end << MP1_HUBIF_NB_AX_MISC_2_AX_TRAN_END_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_ax_misc_2_t {
            unsigned int ax_len                         : MP1_HUBIF_NB_AX_MISC_2_AX_LEN_SIZE;
            unsigned int ax_size                        : MP1_HUBIF_NB_AX_MISC_2_AX_SIZE_SIZE;
            unsigned int ax_burst                       : MP1_HUBIF_NB_AX_MISC_2_AX_BURST_SIZE;
            unsigned int ax_cache                       : MP1_HUBIF_NB_AX_MISC_2_AX_CACHE_SIZE;
            unsigned int ax_prot                        : MP1_HUBIF_NB_AX_MISC_2_AX_PROT_SIZE;
            unsigned int                                : 6;
            unsigned int ax_lock                        : MP1_HUBIF_NB_AX_MISC_2_AX_LOCK_SIZE;
            unsigned int ax_opcode                      : MP1_HUBIF_NB_AX_MISC_2_AX_OPCODE_SIZE;
            unsigned int ax_tran_strt                   : MP1_HUBIF_NB_AX_MISC_2_AX_TRAN_STRT_SIZE;
            unsigned int ax_tran_end                    : MP1_HUBIF_NB_AX_MISC_2_AX_TRAN_END_SIZE;
            unsigned int                                : 1;
      } mp1_hubif_nb_ax_misc_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_ax_misc_2_t {
            unsigned int                                : 1;
            unsigned int ax_tran_end                    : MP1_HUBIF_NB_AX_MISC_2_AX_TRAN_END_SIZE;
            unsigned int ax_tran_strt                   : MP1_HUBIF_NB_AX_MISC_2_AX_TRAN_STRT_SIZE;
            unsigned int ax_opcode                      : MP1_HUBIF_NB_AX_MISC_2_AX_OPCODE_SIZE;
            unsigned int ax_lock                        : MP1_HUBIF_NB_AX_MISC_2_AX_LOCK_SIZE;
            unsigned int                                : 6;
            unsigned int ax_prot                        : MP1_HUBIF_NB_AX_MISC_2_AX_PROT_SIZE;
            unsigned int ax_cache                       : MP1_HUBIF_NB_AX_MISC_2_AX_CACHE_SIZE;
            unsigned int ax_burst                       : MP1_HUBIF_NB_AX_MISC_2_AX_BURST_SIZE;
            unsigned int ax_size                        : MP1_HUBIF_NB_AX_MISC_2_AX_SIZE_SIZE;
            unsigned int ax_len                         : MP1_HUBIF_NB_AX_MISC_2_AX_LEN_SIZE;
      } mp1_hubif_nb_ax_misc_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_ax_misc_2_t f;
} mp1_hubif_nb_ax_misc_2_u;


/*
 * MP1_HUBIF_NB_AX_MISC_3 struct
 */

#define MP1_HUBIF_NB_AX_MISC_3_REG_SIZE         32
#define MP1_HUBIF_NB_AX_MISC_3_AX_USER_SIZE  6

#define MP1_HUBIF_NB_AX_MISC_3_AX_USER_SHIFT  0

#define MP1_HUBIF_NB_AX_MISC_3_AX_USER_MASK  0x0000003f

#define MP1_HUBIF_NB_AX_MISC_3_MASK \
      (MP1_HUBIF_NB_AX_MISC_3_AX_USER_MASK)

#define MP1_HUBIF_NB_AX_MISC_3_DEFAULT 0x00000000

#define MP1_HUBIF_NB_AX_MISC_3_GET_AX_USER(mp1_hubif_nb_ax_misc_3) \
      ((mp1_hubif_nb_ax_misc_3 & MP1_HUBIF_NB_AX_MISC_3_AX_USER_MASK) >> MP1_HUBIF_NB_AX_MISC_3_AX_USER_SHIFT)

#define MP1_HUBIF_NB_AX_MISC_3_SET_AX_USER(mp1_hubif_nb_ax_misc_3_reg, ax_user) \
      mp1_hubif_nb_ax_misc_3_reg = (mp1_hubif_nb_ax_misc_3_reg & ~MP1_HUBIF_NB_AX_MISC_3_AX_USER_MASK) | (ax_user << MP1_HUBIF_NB_AX_MISC_3_AX_USER_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_ax_misc_3_t {
            unsigned int ax_user                        : MP1_HUBIF_NB_AX_MISC_3_AX_USER_SIZE;
            unsigned int                                : 26;
      } mp1_hubif_nb_ax_misc_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_ax_misc_3_t {
            unsigned int                                : 26;
            unsigned int ax_user                        : MP1_HUBIF_NB_AX_MISC_3_AX_USER_SIZE;
      } mp1_hubif_nb_ax_misc_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_ax_misc_3_t f;
} mp1_hubif_nb_ax_misc_3_u;


/*
 * MP1_HUBIF_NB_WSTRB0 struct
 */

#define MP1_HUBIF_NB_WSTRB0_REG_SIZE         32
#define MP1_HUBIF_NB_WSTRB0_AX_WSTRB_SIZE  32

#define MP1_HUBIF_NB_WSTRB0_AX_WSTRB_SHIFT  0

#define MP1_HUBIF_NB_WSTRB0_AX_WSTRB_MASK  0xffffffff

#define MP1_HUBIF_NB_WSTRB0_MASK \
      (MP1_HUBIF_NB_WSTRB0_AX_WSTRB_MASK)

#define MP1_HUBIF_NB_WSTRB0_DEFAULT    0x00000000

#define MP1_HUBIF_NB_WSTRB0_GET_AX_WSTRB(mp1_hubif_nb_wstrb0) \
      ((mp1_hubif_nb_wstrb0 & MP1_HUBIF_NB_WSTRB0_AX_WSTRB_MASK) >> MP1_HUBIF_NB_WSTRB0_AX_WSTRB_SHIFT)

#define MP1_HUBIF_NB_WSTRB0_SET_AX_WSTRB(mp1_hubif_nb_wstrb0_reg, ax_wstrb) \
      mp1_hubif_nb_wstrb0_reg = (mp1_hubif_nb_wstrb0_reg & ~MP1_HUBIF_NB_WSTRB0_AX_WSTRB_MASK) | (ax_wstrb << MP1_HUBIF_NB_WSTRB0_AX_WSTRB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_wstrb0_t {
            unsigned int ax_wstrb                       : MP1_HUBIF_NB_WSTRB0_AX_WSTRB_SIZE;
      } mp1_hubif_nb_wstrb0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_wstrb0_t {
            unsigned int ax_wstrb                       : MP1_HUBIF_NB_WSTRB0_AX_WSTRB_SIZE;
      } mp1_hubif_nb_wstrb0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_wstrb0_t f;
} mp1_hubif_nb_wstrb0_u;


/*
 * MP1_HUBIF_NB_WSTRB1 struct
 */

#define MP1_HUBIF_NB_WSTRB1_REG_SIZE         32
#define MP1_HUBIF_NB_WSTRB1_AX_WSTRB_SIZE  32

#define MP1_HUBIF_NB_WSTRB1_AX_WSTRB_SHIFT  0

#define MP1_HUBIF_NB_WSTRB1_AX_WSTRB_MASK  0xffffffff

#define MP1_HUBIF_NB_WSTRB1_MASK \
      (MP1_HUBIF_NB_WSTRB1_AX_WSTRB_MASK)

#define MP1_HUBIF_NB_WSTRB1_DEFAULT    0x00000000

#define MP1_HUBIF_NB_WSTRB1_GET_AX_WSTRB(mp1_hubif_nb_wstrb1) \
      ((mp1_hubif_nb_wstrb1 & MP1_HUBIF_NB_WSTRB1_AX_WSTRB_MASK) >> MP1_HUBIF_NB_WSTRB1_AX_WSTRB_SHIFT)

#define MP1_HUBIF_NB_WSTRB1_SET_AX_WSTRB(mp1_hubif_nb_wstrb1_reg, ax_wstrb) \
      mp1_hubif_nb_wstrb1_reg = (mp1_hubif_nb_wstrb1_reg & ~MP1_HUBIF_NB_WSTRB1_AX_WSTRB_MASK) | (ax_wstrb << MP1_HUBIF_NB_WSTRB1_AX_WSTRB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_wstrb1_t {
            unsigned int ax_wstrb                       : MP1_HUBIF_NB_WSTRB1_AX_WSTRB_SIZE;
      } mp1_hubif_nb_wstrb1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_wstrb1_t {
            unsigned int ax_wstrb                       : MP1_HUBIF_NB_WSTRB1_AX_WSTRB_SIZE;
      } mp1_hubif_nb_wstrb1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_wstrb1_t f;
} mp1_hubif_nb_wstrb1_u;


/*
 * MP1_HUBIF_NB_WDATA0 struct
 */

#define MP1_HUBIF_NB_WDATA0_REG_SIZE         32
#define MP1_HUBIF_NB_WDATA0_AX_WDATA_SIZE  32

#define MP1_HUBIF_NB_WDATA0_AX_WDATA_SHIFT  0

#define MP1_HUBIF_NB_WDATA0_AX_WDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_WDATA0_MASK \
      (MP1_HUBIF_NB_WDATA0_AX_WDATA_MASK)

#define MP1_HUBIF_NB_WDATA0_DEFAULT    0x00000000

#define MP1_HUBIF_NB_WDATA0_GET_AX_WDATA(mp1_hubif_nb_wdata0) \
      ((mp1_hubif_nb_wdata0 & MP1_HUBIF_NB_WDATA0_AX_WDATA_MASK) >> MP1_HUBIF_NB_WDATA0_AX_WDATA_SHIFT)

#define MP1_HUBIF_NB_WDATA0_SET_AX_WDATA(mp1_hubif_nb_wdata0_reg, ax_wdata) \
      mp1_hubif_nb_wdata0_reg = (mp1_hubif_nb_wdata0_reg & ~MP1_HUBIF_NB_WDATA0_AX_WDATA_MASK) | (ax_wdata << MP1_HUBIF_NB_WDATA0_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata0_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA0_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata0_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA0_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_wdata0_t f;
} mp1_hubif_nb_wdata0_u;


/*
 * MP1_HUBIF_NB_WDATA1 struct
 */

#define MP1_HUBIF_NB_WDATA1_REG_SIZE         32
#define MP1_HUBIF_NB_WDATA1_AX_WDATA_SIZE  32

#define MP1_HUBIF_NB_WDATA1_AX_WDATA_SHIFT  0

#define MP1_HUBIF_NB_WDATA1_AX_WDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_WDATA1_MASK \
      (MP1_HUBIF_NB_WDATA1_AX_WDATA_MASK)

#define MP1_HUBIF_NB_WDATA1_DEFAULT    0x00000000

#define MP1_HUBIF_NB_WDATA1_GET_AX_WDATA(mp1_hubif_nb_wdata1) \
      ((mp1_hubif_nb_wdata1 & MP1_HUBIF_NB_WDATA1_AX_WDATA_MASK) >> MP1_HUBIF_NB_WDATA1_AX_WDATA_SHIFT)

#define MP1_HUBIF_NB_WDATA1_SET_AX_WDATA(mp1_hubif_nb_wdata1_reg, ax_wdata) \
      mp1_hubif_nb_wdata1_reg = (mp1_hubif_nb_wdata1_reg & ~MP1_HUBIF_NB_WDATA1_AX_WDATA_MASK) | (ax_wdata << MP1_HUBIF_NB_WDATA1_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata1_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA1_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata1_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA1_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_wdata1_t f;
} mp1_hubif_nb_wdata1_u;


/*
 * MP1_HUBIF_NB_WDATA2 struct
 */

#define MP1_HUBIF_NB_WDATA2_REG_SIZE         32
#define MP1_HUBIF_NB_WDATA2_AX_WDATA_SIZE  32

#define MP1_HUBIF_NB_WDATA2_AX_WDATA_SHIFT  0

#define MP1_HUBIF_NB_WDATA2_AX_WDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_WDATA2_MASK \
      (MP1_HUBIF_NB_WDATA2_AX_WDATA_MASK)

#define MP1_HUBIF_NB_WDATA2_DEFAULT    0x00000000

#define MP1_HUBIF_NB_WDATA2_GET_AX_WDATA(mp1_hubif_nb_wdata2) \
      ((mp1_hubif_nb_wdata2 & MP1_HUBIF_NB_WDATA2_AX_WDATA_MASK) >> MP1_HUBIF_NB_WDATA2_AX_WDATA_SHIFT)

#define MP1_HUBIF_NB_WDATA2_SET_AX_WDATA(mp1_hubif_nb_wdata2_reg, ax_wdata) \
      mp1_hubif_nb_wdata2_reg = (mp1_hubif_nb_wdata2_reg & ~MP1_HUBIF_NB_WDATA2_AX_WDATA_MASK) | (ax_wdata << MP1_HUBIF_NB_WDATA2_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata2_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA2_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata2_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA2_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_wdata2_t f;
} mp1_hubif_nb_wdata2_u;


/*
 * MP1_HUBIF_NB_WDATA3 struct
 */

#define MP1_HUBIF_NB_WDATA3_REG_SIZE         32
#define MP1_HUBIF_NB_WDATA3_AX_WDATA_SIZE  32

#define MP1_HUBIF_NB_WDATA3_AX_WDATA_SHIFT  0

#define MP1_HUBIF_NB_WDATA3_AX_WDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_WDATA3_MASK \
      (MP1_HUBIF_NB_WDATA3_AX_WDATA_MASK)

#define MP1_HUBIF_NB_WDATA3_DEFAULT    0x00000000

#define MP1_HUBIF_NB_WDATA3_GET_AX_WDATA(mp1_hubif_nb_wdata3) \
      ((mp1_hubif_nb_wdata3 & MP1_HUBIF_NB_WDATA3_AX_WDATA_MASK) >> MP1_HUBIF_NB_WDATA3_AX_WDATA_SHIFT)

#define MP1_HUBIF_NB_WDATA3_SET_AX_WDATA(mp1_hubif_nb_wdata3_reg, ax_wdata) \
      mp1_hubif_nb_wdata3_reg = (mp1_hubif_nb_wdata3_reg & ~MP1_HUBIF_NB_WDATA3_AX_WDATA_MASK) | (ax_wdata << MP1_HUBIF_NB_WDATA3_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata3_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA3_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata3_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA3_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_wdata3_t f;
} mp1_hubif_nb_wdata3_u;


/*
 * MP1_HUBIF_NB_WDATA4 struct
 */

#define MP1_HUBIF_NB_WDATA4_REG_SIZE         32
#define MP1_HUBIF_NB_WDATA4_AX_WDATA_SIZE  32

#define MP1_HUBIF_NB_WDATA4_AX_WDATA_SHIFT  0

#define MP1_HUBIF_NB_WDATA4_AX_WDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_WDATA4_MASK \
      (MP1_HUBIF_NB_WDATA4_AX_WDATA_MASK)

#define MP1_HUBIF_NB_WDATA4_DEFAULT    0x00000000

#define MP1_HUBIF_NB_WDATA4_GET_AX_WDATA(mp1_hubif_nb_wdata4) \
      ((mp1_hubif_nb_wdata4 & MP1_HUBIF_NB_WDATA4_AX_WDATA_MASK) >> MP1_HUBIF_NB_WDATA4_AX_WDATA_SHIFT)

#define MP1_HUBIF_NB_WDATA4_SET_AX_WDATA(mp1_hubif_nb_wdata4_reg, ax_wdata) \
      mp1_hubif_nb_wdata4_reg = (mp1_hubif_nb_wdata4_reg & ~MP1_HUBIF_NB_WDATA4_AX_WDATA_MASK) | (ax_wdata << MP1_HUBIF_NB_WDATA4_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata4_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA4_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata4_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA4_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_wdata4_t f;
} mp1_hubif_nb_wdata4_u;


/*
 * MP1_HUBIF_NB_WDATA5 struct
 */

#define MP1_HUBIF_NB_WDATA5_REG_SIZE         32
#define MP1_HUBIF_NB_WDATA5_AX_WDATA_SIZE  32

#define MP1_HUBIF_NB_WDATA5_AX_WDATA_SHIFT  0

#define MP1_HUBIF_NB_WDATA5_AX_WDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_WDATA5_MASK \
      (MP1_HUBIF_NB_WDATA5_AX_WDATA_MASK)

#define MP1_HUBIF_NB_WDATA5_DEFAULT    0x00000000

#define MP1_HUBIF_NB_WDATA5_GET_AX_WDATA(mp1_hubif_nb_wdata5) \
      ((mp1_hubif_nb_wdata5 & MP1_HUBIF_NB_WDATA5_AX_WDATA_MASK) >> MP1_HUBIF_NB_WDATA5_AX_WDATA_SHIFT)

#define MP1_HUBIF_NB_WDATA5_SET_AX_WDATA(mp1_hubif_nb_wdata5_reg, ax_wdata) \
      mp1_hubif_nb_wdata5_reg = (mp1_hubif_nb_wdata5_reg & ~MP1_HUBIF_NB_WDATA5_AX_WDATA_MASK) | (ax_wdata << MP1_HUBIF_NB_WDATA5_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata5_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA5_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata5_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA5_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_wdata5_t f;
} mp1_hubif_nb_wdata5_u;


/*
 * MP1_HUBIF_NB_WDATA6 struct
 */

#define MP1_HUBIF_NB_WDATA6_REG_SIZE         32
#define MP1_HUBIF_NB_WDATA6_AX_WDATA_SIZE  32

#define MP1_HUBIF_NB_WDATA6_AX_WDATA_SHIFT  0

#define MP1_HUBIF_NB_WDATA6_AX_WDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_WDATA6_MASK \
      (MP1_HUBIF_NB_WDATA6_AX_WDATA_MASK)

#define MP1_HUBIF_NB_WDATA6_DEFAULT    0x00000000

#define MP1_HUBIF_NB_WDATA6_GET_AX_WDATA(mp1_hubif_nb_wdata6) \
      ((mp1_hubif_nb_wdata6 & MP1_HUBIF_NB_WDATA6_AX_WDATA_MASK) >> MP1_HUBIF_NB_WDATA6_AX_WDATA_SHIFT)

#define MP1_HUBIF_NB_WDATA6_SET_AX_WDATA(mp1_hubif_nb_wdata6_reg, ax_wdata) \
      mp1_hubif_nb_wdata6_reg = (mp1_hubif_nb_wdata6_reg & ~MP1_HUBIF_NB_WDATA6_AX_WDATA_MASK) | (ax_wdata << MP1_HUBIF_NB_WDATA6_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata6_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA6_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata6_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA6_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_wdata6_t f;
} mp1_hubif_nb_wdata6_u;


/*
 * MP1_HUBIF_NB_WDATA7 struct
 */

#define MP1_HUBIF_NB_WDATA7_REG_SIZE         32
#define MP1_HUBIF_NB_WDATA7_AX_WDATA_SIZE  32

#define MP1_HUBIF_NB_WDATA7_AX_WDATA_SHIFT  0

#define MP1_HUBIF_NB_WDATA7_AX_WDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_WDATA7_MASK \
      (MP1_HUBIF_NB_WDATA7_AX_WDATA_MASK)

#define MP1_HUBIF_NB_WDATA7_DEFAULT    0x00000000

#define MP1_HUBIF_NB_WDATA7_GET_AX_WDATA(mp1_hubif_nb_wdata7) \
      ((mp1_hubif_nb_wdata7 & MP1_HUBIF_NB_WDATA7_AX_WDATA_MASK) >> MP1_HUBIF_NB_WDATA7_AX_WDATA_SHIFT)

#define MP1_HUBIF_NB_WDATA7_SET_AX_WDATA(mp1_hubif_nb_wdata7_reg, ax_wdata) \
      mp1_hubif_nb_wdata7_reg = (mp1_hubif_nb_wdata7_reg & ~MP1_HUBIF_NB_WDATA7_AX_WDATA_MASK) | (ax_wdata << MP1_HUBIF_NB_WDATA7_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata7_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA7_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata7_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA7_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_wdata7_t f;
} mp1_hubif_nb_wdata7_u;


/*
 * MP1_HUBIF_NB_WDATA8 struct
 */

#define MP1_HUBIF_NB_WDATA8_REG_SIZE         32
#define MP1_HUBIF_NB_WDATA8_AX_WDATA_SIZE  32

#define MP1_HUBIF_NB_WDATA8_AX_WDATA_SHIFT  0

#define MP1_HUBIF_NB_WDATA8_AX_WDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_WDATA8_MASK \
      (MP1_HUBIF_NB_WDATA8_AX_WDATA_MASK)

#define MP1_HUBIF_NB_WDATA8_DEFAULT    0x00000000

#define MP1_HUBIF_NB_WDATA8_GET_AX_WDATA(mp1_hubif_nb_wdata8) \
      ((mp1_hubif_nb_wdata8 & MP1_HUBIF_NB_WDATA8_AX_WDATA_MASK) >> MP1_HUBIF_NB_WDATA8_AX_WDATA_SHIFT)

#define MP1_HUBIF_NB_WDATA8_SET_AX_WDATA(mp1_hubif_nb_wdata8_reg, ax_wdata) \
      mp1_hubif_nb_wdata8_reg = (mp1_hubif_nb_wdata8_reg & ~MP1_HUBIF_NB_WDATA8_AX_WDATA_MASK) | (ax_wdata << MP1_HUBIF_NB_WDATA8_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata8_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA8_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata8_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA8_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_wdata8_t f;
} mp1_hubif_nb_wdata8_u;


/*
 * MP1_HUBIF_NB_WDATA9 struct
 */

#define MP1_HUBIF_NB_WDATA9_REG_SIZE         32
#define MP1_HUBIF_NB_WDATA9_AX_WDATA_SIZE  32

#define MP1_HUBIF_NB_WDATA9_AX_WDATA_SHIFT  0

#define MP1_HUBIF_NB_WDATA9_AX_WDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_WDATA9_MASK \
      (MP1_HUBIF_NB_WDATA9_AX_WDATA_MASK)

#define MP1_HUBIF_NB_WDATA9_DEFAULT    0x00000000

#define MP1_HUBIF_NB_WDATA9_GET_AX_WDATA(mp1_hubif_nb_wdata9) \
      ((mp1_hubif_nb_wdata9 & MP1_HUBIF_NB_WDATA9_AX_WDATA_MASK) >> MP1_HUBIF_NB_WDATA9_AX_WDATA_SHIFT)

#define MP1_HUBIF_NB_WDATA9_SET_AX_WDATA(mp1_hubif_nb_wdata9_reg, ax_wdata) \
      mp1_hubif_nb_wdata9_reg = (mp1_hubif_nb_wdata9_reg & ~MP1_HUBIF_NB_WDATA9_AX_WDATA_MASK) | (ax_wdata << MP1_HUBIF_NB_WDATA9_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata9_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA9_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata9_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA9_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_wdata9_t f;
} mp1_hubif_nb_wdata9_u;


/*
 * MP1_HUBIF_NB_WDATA10 struct
 */

#define MP1_HUBIF_NB_WDATA10_REG_SIZE         32
#define MP1_HUBIF_NB_WDATA10_AX_WDATA_SIZE  32

#define MP1_HUBIF_NB_WDATA10_AX_WDATA_SHIFT  0

#define MP1_HUBIF_NB_WDATA10_AX_WDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_WDATA10_MASK \
      (MP1_HUBIF_NB_WDATA10_AX_WDATA_MASK)

#define MP1_HUBIF_NB_WDATA10_DEFAULT   0x00000000

#define MP1_HUBIF_NB_WDATA10_GET_AX_WDATA(mp1_hubif_nb_wdata10) \
      ((mp1_hubif_nb_wdata10 & MP1_HUBIF_NB_WDATA10_AX_WDATA_MASK) >> MP1_HUBIF_NB_WDATA10_AX_WDATA_SHIFT)

#define MP1_HUBIF_NB_WDATA10_SET_AX_WDATA(mp1_hubif_nb_wdata10_reg, ax_wdata) \
      mp1_hubif_nb_wdata10_reg = (mp1_hubif_nb_wdata10_reg & ~MP1_HUBIF_NB_WDATA10_AX_WDATA_MASK) | (ax_wdata << MP1_HUBIF_NB_WDATA10_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata10_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA10_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata10_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA10_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_wdata10_t f;
} mp1_hubif_nb_wdata10_u;


/*
 * MP1_HUBIF_NB_WDATA11 struct
 */

#define MP1_HUBIF_NB_WDATA11_REG_SIZE         32
#define MP1_HUBIF_NB_WDATA11_AX_WDATA_SIZE  32

#define MP1_HUBIF_NB_WDATA11_AX_WDATA_SHIFT  0

#define MP1_HUBIF_NB_WDATA11_AX_WDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_WDATA11_MASK \
      (MP1_HUBIF_NB_WDATA11_AX_WDATA_MASK)

#define MP1_HUBIF_NB_WDATA11_DEFAULT   0x00000000

#define MP1_HUBIF_NB_WDATA11_GET_AX_WDATA(mp1_hubif_nb_wdata11) \
      ((mp1_hubif_nb_wdata11 & MP1_HUBIF_NB_WDATA11_AX_WDATA_MASK) >> MP1_HUBIF_NB_WDATA11_AX_WDATA_SHIFT)

#define MP1_HUBIF_NB_WDATA11_SET_AX_WDATA(mp1_hubif_nb_wdata11_reg, ax_wdata) \
      mp1_hubif_nb_wdata11_reg = (mp1_hubif_nb_wdata11_reg & ~MP1_HUBIF_NB_WDATA11_AX_WDATA_MASK) | (ax_wdata << MP1_HUBIF_NB_WDATA11_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata11_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA11_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata11_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA11_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_wdata11_t f;
} mp1_hubif_nb_wdata11_u;


/*
 * MP1_HUBIF_NB_WDATA12 struct
 */

#define MP1_HUBIF_NB_WDATA12_REG_SIZE         32
#define MP1_HUBIF_NB_WDATA12_AX_WDATA_SIZE  32

#define MP1_HUBIF_NB_WDATA12_AX_WDATA_SHIFT  0

#define MP1_HUBIF_NB_WDATA12_AX_WDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_WDATA12_MASK \
      (MP1_HUBIF_NB_WDATA12_AX_WDATA_MASK)

#define MP1_HUBIF_NB_WDATA12_DEFAULT   0x00000000

#define MP1_HUBIF_NB_WDATA12_GET_AX_WDATA(mp1_hubif_nb_wdata12) \
      ((mp1_hubif_nb_wdata12 & MP1_HUBIF_NB_WDATA12_AX_WDATA_MASK) >> MP1_HUBIF_NB_WDATA12_AX_WDATA_SHIFT)

#define MP1_HUBIF_NB_WDATA12_SET_AX_WDATA(mp1_hubif_nb_wdata12_reg, ax_wdata) \
      mp1_hubif_nb_wdata12_reg = (mp1_hubif_nb_wdata12_reg & ~MP1_HUBIF_NB_WDATA12_AX_WDATA_MASK) | (ax_wdata << MP1_HUBIF_NB_WDATA12_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata12_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA12_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata12_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA12_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_wdata12_t f;
} mp1_hubif_nb_wdata12_u;


/*
 * MP1_HUBIF_NB_WDATA13 struct
 */

#define MP1_HUBIF_NB_WDATA13_REG_SIZE         32
#define MP1_HUBIF_NB_WDATA13_AX_WDATA_SIZE  32

#define MP1_HUBIF_NB_WDATA13_AX_WDATA_SHIFT  0

#define MP1_HUBIF_NB_WDATA13_AX_WDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_WDATA13_MASK \
      (MP1_HUBIF_NB_WDATA13_AX_WDATA_MASK)

#define MP1_HUBIF_NB_WDATA13_DEFAULT   0x00000000

#define MP1_HUBIF_NB_WDATA13_GET_AX_WDATA(mp1_hubif_nb_wdata13) \
      ((mp1_hubif_nb_wdata13 & MP1_HUBIF_NB_WDATA13_AX_WDATA_MASK) >> MP1_HUBIF_NB_WDATA13_AX_WDATA_SHIFT)

#define MP1_HUBIF_NB_WDATA13_SET_AX_WDATA(mp1_hubif_nb_wdata13_reg, ax_wdata) \
      mp1_hubif_nb_wdata13_reg = (mp1_hubif_nb_wdata13_reg & ~MP1_HUBIF_NB_WDATA13_AX_WDATA_MASK) | (ax_wdata << MP1_HUBIF_NB_WDATA13_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata13_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA13_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata13_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA13_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_wdata13_t f;
} mp1_hubif_nb_wdata13_u;


/*
 * MP1_HUBIF_NB_WDATA14 struct
 */

#define MP1_HUBIF_NB_WDATA14_REG_SIZE         32
#define MP1_HUBIF_NB_WDATA14_AX_WDATA_SIZE  32

#define MP1_HUBIF_NB_WDATA14_AX_WDATA_SHIFT  0

#define MP1_HUBIF_NB_WDATA14_AX_WDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_WDATA14_MASK \
      (MP1_HUBIF_NB_WDATA14_AX_WDATA_MASK)

#define MP1_HUBIF_NB_WDATA14_DEFAULT   0x00000000

#define MP1_HUBIF_NB_WDATA14_GET_AX_WDATA(mp1_hubif_nb_wdata14) \
      ((mp1_hubif_nb_wdata14 & MP1_HUBIF_NB_WDATA14_AX_WDATA_MASK) >> MP1_HUBIF_NB_WDATA14_AX_WDATA_SHIFT)

#define MP1_HUBIF_NB_WDATA14_SET_AX_WDATA(mp1_hubif_nb_wdata14_reg, ax_wdata) \
      mp1_hubif_nb_wdata14_reg = (mp1_hubif_nb_wdata14_reg & ~MP1_HUBIF_NB_WDATA14_AX_WDATA_MASK) | (ax_wdata << MP1_HUBIF_NB_WDATA14_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata14_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA14_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata14_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA14_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata14_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_wdata14_t f;
} mp1_hubif_nb_wdata14_u;


/*
 * MP1_HUBIF_NB_WDATA15 struct
 */

#define MP1_HUBIF_NB_WDATA15_REG_SIZE         32
#define MP1_HUBIF_NB_WDATA15_AX_WDATA_SIZE  32

#define MP1_HUBIF_NB_WDATA15_AX_WDATA_SHIFT  0

#define MP1_HUBIF_NB_WDATA15_AX_WDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_WDATA15_MASK \
      (MP1_HUBIF_NB_WDATA15_AX_WDATA_MASK)

#define MP1_HUBIF_NB_WDATA15_DEFAULT   0x00000000

#define MP1_HUBIF_NB_WDATA15_GET_AX_WDATA(mp1_hubif_nb_wdata15) \
      ((mp1_hubif_nb_wdata15 & MP1_HUBIF_NB_WDATA15_AX_WDATA_MASK) >> MP1_HUBIF_NB_WDATA15_AX_WDATA_SHIFT)

#define MP1_HUBIF_NB_WDATA15_SET_AX_WDATA(mp1_hubif_nb_wdata15_reg, ax_wdata) \
      mp1_hubif_nb_wdata15_reg = (mp1_hubif_nb_wdata15_reg & ~MP1_HUBIF_NB_WDATA15_AX_WDATA_MASK) | (ax_wdata << MP1_HUBIF_NB_WDATA15_AX_WDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata15_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA15_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_wdata15_t {
            unsigned int ax_wdata                       : MP1_HUBIF_NB_WDATA15_AX_WDATA_SIZE;
      } mp1_hubif_nb_wdata15_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_wdata15_t f;
} mp1_hubif_nb_wdata15_u;


/*
 * MP1_HUBIF_NB_RDATA0 struct
 */

#define MP1_HUBIF_NB_RDATA0_REG_SIZE         32
#define MP1_HUBIF_NB_RDATA0_AX_RDATA_SIZE  32

#define MP1_HUBIF_NB_RDATA0_AX_RDATA_SHIFT  0

#define MP1_HUBIF_NB_RDATA0_AX_RDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_RDATA0_MASK \
      (MP1_HUBIF_NB_RDATA0_AX_RDATA_MASK)

#define MP1_HUBIF_NB_RDATA0_DEFAULT    0x00000000

#define MP1_HUBIF_NB_RDATA0_GET_AX_RDATA(mp1_hubif_nb_rdata0) \
      ((mp1_hubif_nb_rdata0 & MP1_HUBIF_NB_RDATA0_AX_RDATA_MASK) >> MP1_HUBIF_NB_RDATA0_AX_RDATA_SHIFT)

#define MP1_HUBIF_NB_RDATA0_SET_AX_RDATA(mp1_hubif_nb_rdata0_reg, ax_rdata) \
      mp1_hubif_nb_rdata0_reg = (mp1_hubif_nb_rdata0_reg & ~MP1_HUBIF_NB_RDATA0_AX_RDATA_MASK) | (ax_rdata << MP1_HUBIF_NB_RDATA0_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata0_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA0_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata0_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA0_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_rdata0_t f;
} mp1_hubif_nb_rdata0_u;


/*
 * MP1_HUBIF_NB_RDATA1 struct
 */

#define MP1_HUBIF_NB_RDATA1_REG_SIZE         32
#define MP1_HUBIF_NB_RDATA1_AX_RDATA_SIZE  32

#define MP1_HUBIF_NB_RDATA1_AX_RDATA_SHIFT  0

#define MP1_HUBIF_NB_RDATA1_AX_RDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_RDATA1_MASK \
      (MP1_HUBIF_NB_RDATA1_AX_RDATA_MASK)

#define MP1_HUBIF_NB_RDATA1_DEFAULT    0x00000000

#define MP1_HUBIF_NB_RDATA1_GET_AX_RDATA(mp1_hubif_nb_rdata1) \
      ((mp1_hubif_nb_rdata1 & MP1_HUBIF_NB_RDATA1_AX_RDATA_MASK) >> MP1_HUBIF_NB_RDATA1_AX_RDATA_SHIFT)

#define MP1_HUBIF_NB_RDATA1_SET_AX_RDATA(mp1_hubif_nb_rdata1_reg, ax_rdata) \
      mp1_hubif_nb_rdata1_reg = (mp1_hubif_nb_rdata1_reg & ~MP1_HUBIF_NB_RDATA1_AX_RDATA_MASK) | (ax_rdata << MP1_HUBIF_NB_RDATA1_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata1_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA1_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata1_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA1_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_rdata1_t f;
} mp1_hubif_nb_rdata1_u;


/*
 * MP1_HUBIF_NB_RDATA2 struct
 */

#define MP1_HUBIF_NB_RDATA2_REG_SIZE         32
#define MP1_HUBIF_NB_RDATA2_AX_RDATA_SIZE  32

#define MP1_HUBIF_NB_RDATA2_AX_RDATA_SHIFT  0

#define MP1_HUBIF_NB_RDATA2_AX_RDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_RDATA2_MASK \
      (MP1_HUBIF_NB_RDATA2_AX_RDATA_MASK)

#define MP1_HUBIF_NB_RDATA2_DEFAULT    0x00000000

#define MP1_HUBIF_NB_RDATA2_GET_AX_RDATA(mp1_hubif_nb_rdata2) \
      ((mp1_hubif_nb_rdata2 & MP1_HUBIF_NB_RDATA2_AX_RDATA_MASK) >> MP1_HUBIF_NB_RDATA2_AX_RDATA_SHIFT)

#define MP1_HUBIF_NB_RDATA2_SET_AX_RDATA(mp1_hubif_nb_rdata2_reg, ax_rdata) \
      mp1_hubif_nb_rdata2_reg = (mp1_hubif_nb_rdata2_reg & ~MP1_HUBIF_NB_RDATA2_AX_RDATA_MASK) | (ax_rdata << MP1_HUBIF_NB_RDATA2_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata2_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA2_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata2_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA2_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_rdata2_t f;
} mp1_hubif_nb_rdata2_u;


/*
 * MP1_HUBIF_NB_RDATA3 struct
 */

#define MP1_HUBIF_NB_RDATA3_REG_SIZE         32
#define MP1_HUBIF_NB_RDATA3_AX_RDATA_SIZE  32

#define MP1_HUBIF_NB_RDATA3_AX_RDATA_SHIFT  0

#define MP1_HUBIF_NB_RDATA3_AX_RDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_RDATA3_MASK \
      (MP1_HUBIF_NB_RDATA3_AX_RDATA_MASK)

#define MP1_HUBIF_NB_RDATA3_DEFAULT    0x00000000

#define MP1_HUBIF_NB_RDATA3_GET_AX_RDATA(mp1_hubif_nb_rdata3) \
      ((mp1_hubif_nb_rdata3 & MP1_HUBIF_NB_RDATA3_AX_RDATA_MASK) >> MP1_HUBIF_NB_RDATA3_AX_RDATA_SHIFT)

#define MP1_HUBIF_NB_RDATA3_SET_AX_RDATA(mp1_hubif_nb_rdata3_reg, ax_rdata) \
      mp1_hubif_nb_rdata3_reg = (mp1_hubif_nb_rdata3_reg & ~MP1_HUBIF_NB_RDATA3_AX_RDATA_MASK) | (ax_rdata << MP1_HUBIF_NB_RDATA3_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata3_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA3_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata3_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA3_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_rdata3_t f;
} mp1_hubif_nb_rdata3_u;


/*
 * MP1_HUBIF_NB_RDATA4 struct
 */

#define MP1_HUBIF_NB_RDATA4_REG_SIZE         32
#define MP1_HUBIF_NB_RDATA4_AX_RDATA_SIZE  32

#define MP1_HUBIF_NB_RDATA4_AX_RDATA_SHIFT  0

#define MP1_HUBIF_NB_RDATA4_AX_RDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_RDATA4_MASK \
      (MP1_HUBIF_NB_RDATA4_AX_RDATA_MASK)

#define MP1_HUBIF_NB_RDATA4_DEFAULT    0x00000000

#define MP1_HUBIF_NB_RDATA4_GET_AX_RDATA(mp1_hubif_nb_rdata4) \
      ((mp1_hubif_nb_rdata4 & MP1_HUBIF_NB_RDATA4_AX_RDATA_MASK) >> MP1_HUBIF_NB_RDATA4_AX_RDATA_SHIFT)

#define MP1_HUBIF_NB_RDATA4_SET_AX_RDATA(mp1_hubif_nb_rdata4_reg, ax_rdata) \
      mp1_hubif_nb_rdata4_reg = (mp1_hubif_nb_rdata4_reg & ~MP1_HUBIF_NB_RDATA4_AX_RDATA_MASK) | (ax_rdata << MP1_HUBIF_NB_RDATA4_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata4_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA4_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata4_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA4_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_rdata4_t f;
} mp1_hubif_nb_rdata4_u;


/*
 * MP1_HUBIF_NB_RDATA5 struct
 */

#define MP1_HUBIF_NB_RDATA5_REG_SIZE         32
#define MP1_HUBIF_NB_RDATA5_AX_RDATA_SIZE  32

#define MP1_HUBIF_NB_RDATA5_AX_RDATA_SHIFT  0

#define MP1_HUBIF_NB_RDATA5_AX_RDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_RDATA5_MASK \
      (MP1_HUBIF_NB_RDATA5_AX_RDATA_MASK)

#define MP1_HUBIF_NB_RDATA5_DEFAULT    0x00000000

#define MP1_HUBIF_NB_RDATA5_GET_AX_RDATA(mp1_hubif_nb_rdata5) \
      ((mp1_hubif_nb_rdata5 & MP1_HUBIF_NB_RDATA5_AX_RDATA_MASK) >> MP1_HUBIF_NB_RDATA5_AX_RDATA_SHIFT)

#define MP1_HUBIF_NB_RDATA5_SET_AX_RDATA(mp1_hubif_nb_rdata5_reg, ax_rdata) \
      mp1_hubif_nb_rdata5_reg = (mp1_hubif_nb_rdata5_reg & ~MP1_HUBIF_NB_RDATA5_AX_RDATA_MASK) | (ax_rdata << MP1_HUBIF_NB_RDATA5_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata5_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA5_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata5_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA5_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_rdata5_t f;
} mp1_hubif_nb_rdata5_u;


/*
 * MP1_HUBIF_NB_RDATA6 struct
 */

#define MP1_HUBIF_NB_RDATA6_REG_SIZE         32
#define MP1_HUBIF_NB_RDATA6_AX_RDATA_SIZE  32

#define MP1_HUBIF_NB_RDATA6_AX_RDATA_SHIFT  0

#define MP1_HUBIF_NB_RDATA6_AX_RDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_RDATA6_MASK \
      (MP1_HUBIF_NB_RDATA6_AX_RDATA_MASK)

#define MP1_HUBIF_NB_RDATA6_DEFAULT    0x00000000

#define MP1_HUBIF_NB_RDATA6_GET_AX_RDATA(mp1_hubif_nb_rdata6) \
      ((mp1_hubif_nb_rdata6 & MP1_HUBIF_NB_RDATA6_AX_RDATA_MASK) >> MP1_HUBIF_NB_RDATA6_AX_RDATA_SHIFT)

#define MP1_HUBIF_NB_RDATA6_SET_AX_RDATA(mp1_hubif_nb_rdata6_reg, ax_rdata) \
      mp1_hubif_nb_rdata6_reg = (mp1_hubif_nb_rdata6_reg & ~MP1_HUBIF_NB_RDATA6_AX_RDATA_MASK) | (ax_rdata << MP1_HUBIF_NB_RDATA6_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata6_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA6_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata6_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA6_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_rdata6_t f;
} mp1_hubif_nb_rdata6_u;


/*
 * MP1_HUBIF_NB_RDATA7 struct
 */

#define MP1_HUBIF_NB_RDATA7_REG_SIZE         32
#define MP1_HUBIF_NB_RDATA7_AX_RDATA_SIZE  32

#define MP1_HUBIF_NB_RDATA7_AX_RDATA_SHIFT  0

#define MP1_HUBIF_NB_RDATA7_AX_RDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_RDATA7_MASK \
      (MP1_HUBIF_NB_RDATA7_AX_RDATA_MASK)

#define MP1_HUBIF_NB_RDATA7_DEFAULT    0x00000000

#define MP1_HUBIF_NB_RDATA7_GET_AX_RDATA(mp1_hubif_nb_rdata7) \
      ((mp1_hubif_nb_rdata7 & MP1_HUBIF_NB_RDATA7_AX_RDATA_MASK) >> MP1_HUBIF_NB_RDATA7_AX_RDATA_SHIFT)

#define MP1_HUBIF_NB_RDATA7_SET_AX_RDATA(mp1_hubif_nb_rdata7_reg, ax_rdata) \
      mp1_hubif_nb_rdata7_reg = (mp1_hubif_nb_rdata7_reg & ~MP1_HUBIF_NB_RDATA7_AX_RDATA_MASK) | (ax_rdata << MP1_HUBIF_NB_RDATA7_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata7_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA7_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata7_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA7_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_rdata7_t f;
} mp1_hubif_nb_rdata7_u;


/*
 * MP1_HUBIF_NB_RDATA8 struct
 */

#define MP1_HUBIF_NB_RDATA8_REG_SIZE         32
#define MP1_HUBIF_NB_RDATA8_AX_RDATA_SIZE  32

#define MP1_HUBIF_NB_RDATA8_AX_RDATA_SHIFT  0

#define MP1_HUBIF_NB_RDATA8_AX_RDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_RDATA8_MASK \
      (MP1_HUBIF_NB_RDATA8_AX_RDATA_MASK)

#define MP1_HUBIF_NB_RDATA8_DEFAULT    0x00000000

#define MP1_HUBIF_NB_RDATA8_GET_AX_RDATA(mp1_hubif_nb_rdata8) \
      ((mp1_hubif_nb_rdata8 & MP1_HUBIF_NB_RDATA8_AX_RDATA_MASK) >> MP1_HUBIF_NB_RDATA8_AX_RDATA_SHIFT)

#define MP1_HUBIF_NB_RDATA8_SET_AX_RDATA(mp1_hubif_nb_rdata8_reg, ax_rdata) \
      mp1_hubif_nb_rdata8_reg = (mp1_hubif_nb_rdata8_reg & ~MP1_HUBIF_NB_RDATA8_AX_RDATA_MASK) | (ax_rdata << MP1_HUBIF_NB_RDATA8_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata8_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA8_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata8_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA8_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_rdata8_t f;
} mp1_hubif_nb_rdata8_u;


/*
 * MP1_HUBIF_NB_RDATA9 struct
 */

#define MP1_HUBIF_NB_RDATA9_REG_SIZE         32
#define MP1_HUBIF_NB_RDATA9_AX_RDATA_SIZE  32

#define MP1_HUBIF_NB_RDATA9_AX_RDATA_SHIFT  0

#define MP1_HUBIF_NB_RDATA9_AX_RDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_RDATA9_MASK \
      (MP1_HUBIF_NB_RDATA9_AX_RDATA_MASK)

#define MP1_HUBIF_NB_RDATA9_DEFAULT    0x00000000

#define MP1_HUBIF_NB_RDATA9_GET_AX_RDATA(mp1_hubif_nb_rdata9) \
      ((mp1_hubif_nb_rdata9 & MP1_HUBIF_NB_RDATA9_AX_RDATA_MASK) >> MP1_HUBIF_NB_RDATA9_AX_RDATA_SHIFT)

#define MP1_HUBIF_NB_RDATA9_SET_AX_RDATA(mp1_hubif_nb_rdata9_reg, ax_rdata) \
      mp1_hubif_nb_rdata9_reg = (mp1_hubif_nb_rdata9_reg & ~MP1_HUBIF_NB_RDATA9_AX_RDATA_MASK) | (ax_rdata << MP1_HUBIF_NB_RDATA9_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata9_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA9_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata9_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA9_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_rdata9_t f;
} mp1_hubif_nb_rdata9_u;


/*
 * MP1_HUBIF_NB_RDATA10 struct
 */

#define MP1_HUBIF_NB_RDATA10_REG_SIZE         32
#define MP1_HUBIF_NB_RDATA10_AX_RDATA_SIZE  32

#define MP1_HUBIF_NB_RDATA10_AX_RDATA_SHIFT  0

#define MP1_HUBIF_NB_RDATA10_AX_RDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_RDATA10_MASK \
      (MP1_HUBIF_NB_RDATA10_AX_RDATA_MASK)

#define MP1_HUBIF_NB_RDATA10_DEFAULT   0x00000000

#define MP1_HUBIF_NB_RDATA10_GET_AX_RDATA(mp1_hubif_nb_rdata10) \
      ((mp1_hubif_nb_rdata10 & MP1_HUBIF_NB_RDATA10_AX_RDATA_MASK) >> MP1_HUBIF_NB_RDATA10_AX_RDATA_SHIFT)

#define MP1_HUBIF_NB_RDATA10_SET_AX_RDATA(mp1_hubif_nb_rdata10_reg, ax_rdata) \
      mp1_hubif_nb_rdata10_reg = (mp1_hubif_nb_rdata10_reg & ~MP1_HUBIF_NB_RDATA10_AX_RDATA_MASK) | (ax_rdata << MP1_HUBIF_NB_RDATA10_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata10_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA10_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata10_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA10_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_rdata10_t f;
} mp1_hubif_nb_rdata10_u;


/*
 * MP1_HUBIF_NB_RDATA11 struct
 */

#define MP1_HUBIF_NB_RDATA11_REG_SIZE         32
#define MP1_HUBIF_NB_RDATA11_AX_RDATA_SIZE  32

#define MP1_HUBIF_NB_RDATA11_AX_RDATA_SHIFT  0

#define MP1_HUBIF_NB_RDATA11_AX_RDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_RDATA11_MASK \
      (MP1_HUBIF_NB_RDATA11_AX_RDATA_MASK)

#define MP1_HUBIF_NB_RDATA11_DEFAULT   0x00000000

#define MP1_HUBIF_NB_RDATA11_GET_AX_RDATA(mp1_hubif_nb_rdata11) \
      ((mp1_hubif_nb_rdata11 & MP1_HUBIF_NB_RDATA11_AX_RDATA_MASK) >> MP1_HUBIF_NB_RDATA11_AX_RDATA_SHIFT)

#define MP1_HUBIF_NB_RDATA11_SET_AX_RDATA(mp1_hubif_nb_rdata11_reg, ax_rdata) \
      mp1_hubif_nb_rdata11_reg = (mp1_hubif_nb_rdata11_reg & ~MP1_HUBIF_NB_RDATA11_AX_RDATA_MASK) | (ax_rdata << MP1_HUBIF_NB_RDATA11_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata11_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA11_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata11_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA11_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_rdata11_t f;
} mp1_hubif_nb_rdata11_u;


/*
 * MP1_HUBIF_NB_RDATA12 struct
 */

#define MP1_HUBIF_NB_RDATA12_REG_SIZE         32
#define MP1_HUBIF_NB_RDATA12_AX_RDATA_SIZE  32

#define MP1_HUBIF_NB_RDATA12_AX_RDATA_SHIFT  0

#define MP1_HUBIF_NB_RDATA12_AX_RDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_RDATA12_MASK \
      (MP1_HUBIF_NB_RDATA12_AX_RDATA_MASK)

#define MP1_HUBIF_NB_RDATA12_DEFAULT   0x00000000

#define MP1_HUBIF_NB_RDATA12_GET_AX_RDATA(mp1_hubif_nb_rdata12) \
      ((mp1_hubif_nb_rdata12 & MP1_HUBIF_NB_RDATA12_AX_RDATA_MASK) >> MP1_HUBIF_NB_RDATA12_AX_RDATA_SHIFT)

#define MP1_HUBIF_NB_RDATA12_SET_AX_RDATA(mp1_hubif_nb_rdata12_reg, ax_rdata) \
      mp1_hubif_nb_rdata12_reg = (mp1_hubif_nb_rdata12_reg & ~MP1_HUBIF_NB_RDATA12_AX_RDATA_MASK) | (ax_rdata << MP1_HUBIF_NB_RDATA12_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata12_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA12_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata12_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA12_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_rdata12_t f;
} mp1_hubif_nb_rdata12_u;


/*
 * MP1_HUBIF_NB_RDATA13 struct
 */

#define MP1_HUBIF_NB_RDATA13_REG_SIZE         32
#define MP1_HUBIF_NB_RDATA13_AX_RDATA_SIZE  32

#define MP1_HUBIF_NB_RDATA13_AX_RDATA_SHIFT  0

#define MP1_HUBIF_NB_RDATA13_AX_RDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_RDATA13_MASK \
      (MP1_HUBIF_NB_RDATA13_AX_RDATA_MASK)

#define MP1_HUBIF_NB_RDATA13_DEFAULT   0x00000000

#define MP1_HUBIF_NB_RDATA13_GET_AX_RDATA(mp1_hubif_nb_rdata13) \
      ((mp1_hubif_nb_rdata13 & MP1_HUBIF_NB_RDATA13_AX_RDATA_MASK) >> MP1_HUBIF_NB_RDATA13_AX_RDATA_SHIFT)

#define MP1_HUBIF_NB_RDATA13_SET_AX_RDATA(mp1_hubif_nb_rdata13_reg, ax_rdata) \
      mp1_hubif_nb_rdata13_reg = (mp1_hubif_nb_rdata13_reg & ~MP1_HUBIF_NB_RDATA13_AX_RDATA_MASK) | (ax_rdata << MP1_HUBIF_NB_RDATA13_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata13_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA13_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata13_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA13_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_rdata13_t f;
} mp1_hubif_nb_rdata13_u;


/*
 * MP1_HUBIF_NB_RDATA14 struct
 */

#define MP1_HUBIF_NB_RDATA14_REG_SIZE         32
#define MP1_HUBIF_NB_RDATA14_AX_RDATA_SIZE  32

#define MP1_HUBIF_NB_RDATA14_AX_RDATA_SHIFT  0

#define MP1_HUBIF_NB_RDATA14_AX_RDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_RDATA14_MASK \
      (MP1_HUBIF_NB_RDATA14_AX_RDATA_MASK)

#define MP1_HUBIF_NB_RDATA14_DEFAULT   0x00000000

#define MP1_HUBIF_NB_RDATA14_GET_AX_RDATA(mp1_hubif_nb_rdata14) \
      ((mp1_hubif_nb_rdata14 & MP1_HUBIF_NB_RDATA14_AX_RDATA_MASK) >> MP1_HUBIF_NB_RDATA14_AX_RDATA_SHIFT)

#define MP1_HUBIF_NB_RDATA14_SET_AX_RDATA(mp1_hubif_nb_rdata14_reg, ax_rdata) \
      mp1_hubif_nb_rdata14_reg = (mp1_hubif_nb_rdata14_reg & ~MP1_HUBIF_NB_RDATA14_AX_RDATA_MASK) | (ax_rdata << MP1_HUBIF_NB_RDATA14_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata14_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA14_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata14_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA14_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata14_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_rdata14_t f;
} mp1_hubif_nb_rdata14_u;


/*
 * MP1_HUBIF_NB_RDATA15 struct
 */

#define MP1_HUBIF_NB_RDATA15_REG_SIZE         32
#define MP1_HUBIF_NB_RDATA15_AX_RDATA_SIZE  32

#define MP1_HUBIF_NB_RDATA15_AX_RDATA_SHIFT  0

#define MP1_HUBIF_NB_RDATA15_AX_RDATA_MASK  0xffffffff

#define MP1_HUBIF_NB_RDATA15_MASK \
      (MP1_HUBIF_NB_RDATA15_AX_RDATA_MASK)

#define MP1_HUBIF_NB_RDATA15_DEFAULT   0x00000000

#define MP1_HUBIF_NB_RDATA15_GET_AX_RDATA(mp1_hubif_nb_rdata15) \
      ((mp1_hubif_nb_rdata15 & MP1_HUBIF_NB_RDATA15_AX_RDATA_MASK) >> MP1_HUBIF_NB_RDATA15_AX_RDATA_SHIFT)

#define MP1_HUBIF_NB_RDATA15_SET_AX_RDATA(mp1_hubif_nb_rdata15_reg, ax_rdata) \
      mp1_hubif_nb_rdata15_reg = (mp1_hubif_nb_rdata15_reg & ~MP1_HUBIF_NB_RDATA15_AX_RDATA_MASK) | (ax_rdata << MP1_HUBIF_NB_RDATA15_AX_RDATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata15_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA15_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_rdata15_t {
            unsigned int ax_rdata                       : MP1_HUBIF_NB_RDATA15_AX_RDATA_SIZE;
      } mp1_hubif_nb_rdata15_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_rdata15_t f;
} mp1_hubif_nb_rdata15_u;


/*
 * MP1_HUBIF_NB_AXI_RESP struct
 */

#define MP1_HUBIF_NB_AXI_RESP_REG_SIZE         32
#define MP1_HUBIF_NB_AXI_RESP_AXI_RESP_SIZE  32

#define MP1_HUBIF_NB_AXI_RESP_AXI_RESP_SHIFT  0

#define MP1_HUBIF_NB_AXI_RESP_AXI_RESP_MASK  0xffffffff

#define MP1_HUBIF_NB_AXI_RESP_MASK \
      (MP1_HUBIF_NB_AXI_RESP_AXI_RESP_MASK)

#define MP1_HUBIF_NB_AXI_RESP_DEFAULT  0xffffffff

#define MP1_HUBIF_NB_AXI_RESP_GET_AXI_RESP(mp1_hubif_nb_axi_resp) \
      ((mp1_hubif_nb_axi_resp & MP1_HUBIF_NB_AXI_RESP_AXI_RESP_MASK) >> MP1_HUBIF_NB_AXI_RESP_AXI_RESP_SHIFT)

#define MP1_HUBIF_NB_AXI_RESP_SET_AXI_RESP(mp1_hubif_nb_axi_resp_reg, axi_resp) \
      mp1_hubif_nb_axi_resp_reg = (mp1_hubif_nb_axi_resp_reg & ~MP1_HUBIF_NB_AXI_RESP_AXI_RESP_MASK) | (axi_resp << MP1_HUBIF_NB_AXI_RESP_AXI_RESP_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_axi_resp_t {
            unsigned int axi_resp                       : MP1_HUBIF_NB_AXI_RESP_AXI_RESP_SIZE;
      } mp1_hubif_nb_axi_resp_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_axi_resp_t {
            unsigned int axi_resp                       : MP1_HUBIF_NB_AXI_RESP_AXI_RESP_SIZE;
      } mp1_hubif_nb_axi_resp_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_axi_resp_t f;
} mp1_hubif_nb_axi_resp_u;


/*
 * MP1_HUBIF_NB_MISC_CTRL struct
 */

#define MP1_HUBIF_NB_MISC_CTRL_REG_SIZE         32
#define MP1_HUBIF_NB_MISC_CTRL_CLK_GATE_EN_SIZE  1
#define MP1_HUBIF_NB_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SIZE  1

#define MP1_HUBIF_NB_MISC_CTRL_CLK_GATE_EN_SHIFT  0
#define MP1_HUBIF_NB_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SHIFT  16

#define MP1_HUBIF_NB_MISC_CTRL_CLK_GATE_EN_MASK  0x00000001
#define MP1_HUBIF_NB_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK  0x00010000

#define MP1_HUBIF_NB_MISC_CTRL_MASK \
      (MP1_HUBIF_NB_MISC_CTRL_CLK_GATE_EN_MASK | \
      MP1_HUBIF_NB_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK)

#define MP1_HUBIF_NB_MISC_CTRL_DEFAULT 0x00010000

#define MP1_HUBIF_NB_MISC_CTRL_GET_CLK_GATE_EN(mp1_hubif_nb_misc_ctrl) \
      ((mp1_hubif_nb_misc_ctrl & MP1_HUBIF_NB_MISC_CTRL_CLK_GATE_EN_MASK) >> MP1_HUBIF_NB_MISC_CTRL_CLK_GATE_EN_SHIFT)
#define MP1_HUBIF_NB_MISC_CTRL_GET_ALLOW_NON_PRIV_REG_ACC(mp1_hubif_nb_misc_ctrl) \
      ((mp1_hubif_nb_misc_ctrl & MP1_HUBIF_NB_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK) >> MP1_HUBIF_NB_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SHIFT)

#define MP1_HUBIF_NB_MISC_CTRL_SET_CLK_GATE_EN(mp1_hubif_nb_misc_ctrl_reg, clk_gate_en) \
      mp1_hubif_nb_misc_ctrl_reg = (mp1_hubif_nb_misc_ctrl_reg & ~MP1_HUBIF_NB_MISC_CTRL_CLK_GATE_EN_MASK) | (clk_gate_en << MP1_HUBIF_NB_MISC_CTRL_CLK_GATE_EN_SHIFT)
#define MP1_HUBIF_NB_MISC_CTRL_SET_ALLOW_NON_PRIV_REG_ACC(mp1_hubif_nb_misc_ctrl_reg, allow_non_priv_reg_acc) \
      mp1_hubif_nb_misc_ctrl_reg = (mp1_hubif_nb_misc_ctrl_reg & ~MP1_HUBIF_NB_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_MASK) | (allow_non_priv_reg_acc << MP1_HUBIF_NB_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_misc_ctrl_t {
            unsigned int clk_gate_en                    : MP1_HUBIF_NB_MISC_CTRL_CLK_GATE_EN_SIZE;
            unsigned int                                : 15;
            unsigned int allow_non_priv_reg_acc         : MP1_HUBIF_NB_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SIZE;
            unsigned int                                : 15;
      } mp1_hubif_nb_misc_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_misc_ctrl_t {
            unsigned int                                : 15;
            unsigned int allow_non_priv_reg_acc         : MP1_HUBIF_NB_MISC_CTRL_ALLOW_NON_PRIV_REG_ACC_SIZE;
            unsigned int                                : 15;
            unsigned int clk_gate_en                    : MP1_HUBIF_NB_MISC_CTRL_CLK_GATE_EN_SIZE;
      } mp1_hubif_nb_misc_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_misc_ctrl_t f;
} mp1_hubif_nb_misc_ctrl_u;


/*
 * MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS struct
 */

#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_REG_SIZE         32
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE  1
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE  2
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE  1
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_ID_SIZE  21
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SIZE  3

#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT  0
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT  1
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT  3
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_ID_SHIFT  8
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SHIFT  29

#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK  0x00000001
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK  0x00000006
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK  0x00000008
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK  0x1fffff00
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_APROT_MASK  0xe0000000

#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_MASK \
      (MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK | \
      MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK | \
      MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK | \
      MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK | \
      MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_APROT_MASK)

#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_DEFAULT 0x00000000

#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_DETECTED(mp1_hubif_nb_acc_violation_log_status) \
      ((mp1_hubif_nb_acc_violation_log_status & MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) >> MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_TYPE(mp1_hubif_nb_acc_violation_log_status) \
      ((mp1_hubif_nb_acc_violation_log_status & MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) >> MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_LOG_CLEAR(mp1_hubif_nb_acc_violation_log_status) \
      ((mp1_hubif_nb_acc_violation_log_status & MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) >> MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_GET_AXI_ID(mp1_hubif_nb_acc_violation_log_status) \
      ((mp1_hubif_nb_acc_violation_log_status & MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK) >> MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_ID_SHIFT)
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_GET_AXI_APROT(mp1_hubif_nb_acc_violation_log_status) \
      ((mp1_hubif_nb_acc_violation_log_status & MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_APROT_MASK) >> MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SHIFT)

#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_DETECTED(mp1_hubif_nb_acc_violation_log_status_reg, acc_violation_detected) \
      mp1_hubif_nb_acc_violation_log_status_reg = (mp1_hubif_nb_acc_violation_log_status_reg & ~MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) | (acc_violation_detected << MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_TYPE(mp1_hubif_nb_acc_violation_log_status_reg, acc_violation_type) \
      mp1_hubif_nb_acc_violation_log_status_reg = (mp1_hubif_nb_acc_violation_log_status_reg & ~MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) | (acc_violation_type << MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_LOG_CLEAR(mp1_hubif_nb_acc_violation_log_status_reg, acc_violation_log_clear) \
      mp1_hubif_nb_acc_violation_log_status_reg = (mp1_hubif_nb_acc_violation_log_status_reg & ~MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) | (acc_violation_log_clear << MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_SET_AXI_ID(mp1_hubif_nb_acc_violation_log_status_reg, axi_id) \
      mp1_hubif_nb_acc_violation_log_status_reg = (mp1_hubif_nb_acc_violation_log_status_reg & ~MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_ID_MASK) | (axi_id << MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_ID_SHIFT)
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_SET_AXI_APROT(mp1_hubif_nb_acc_violation_log_status_reg, axi_aprot) \
      mp1_hubif_nb_acc_violation_log_status_reg = (mp1_hubif_nb_acc_violation_log_status_reg & ~MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_APROT_MASK) | (axi_aprot << MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_acc_violation_log_status_t {
            unsigned int acc_violation_detected         : MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
            unsigned int acc_violation_type             : MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
            unsigned int acc_violation_log_clear        : MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
            unsigned int                                : 4;
            unsigned int axi_id                         : MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_ID_SIZE;
            unsigned int axi_aprot                      : MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SIZE;
      } mp1_hubif_nb_acc_violation_log_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_acc_violation_log_status_t {
            unsigned int axi_aprot                      : MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_APROT_SIZE;
            unsigned int axi_id                         : MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_AXI_ID_SIZE;
            unsigned int                                : 4;
            unsigned int acc_violation_log_clear        : MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
            unsigned int acc_violation_type             : MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
            unsigned int acc_violation_detected         : MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
      } mp1_hubif_nb_acc_violation_log_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_acc_violation_log_status_t f;
} mp1_hubif_nb_acc_violation_log_status_u;


/*
 * MP1_HUBIF_NB_ACC_VIOLATION_LOG_ADDR struct
 */

#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_REG_SIZE         32
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SIZE  32

#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SHIFT  0

#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK  0xffffffff

#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_MASK \
      (MP1_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK)

#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_DEFAULT 0x00000000

#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_GET_AXI_ADDR(mp1_hubif_nb_acc_violation_log_addr) \
      ((mp1_hubif_nb_acc_violation_log_addr & MP1_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK) >> MP1_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SHIFT)

#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_SET_AXI_ADDR(mp1_hubif_nb_acc_violation_log_addr_reg, axi_addr) \
      mp1_hubif_nb_acc_violation_log_addr_reg = (mp1_hubif_nb_acc_violation_log_addr_reg & ~MP1_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_MASK) | (axi_addr << MP1_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_acc_violation_log_addr_t {
            unsigned int axi_addr                       : MP1_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SIZE;
      } mp1_hubif_nb_acc_violation_log_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_acc_violation_log_addr_t {
            unsigned int axi_addr                       : MP1_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_AXI_ADDR_SIZE;
      } mp1_hubif_nb_acc_violation_log_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_acc_violation_log_addr_t f;
} mp1_hubif_nb_acc_violation_log_addr_u;


/*
 * MP1_HUBIF_NB_OBFF_EMUL struct
 */

#define MP1_HUBIF_NB_OBFF_EMUL_REG_SIZE         32
#define MP1_HUBIF_NB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SIZE  1

#define MP1_HUBIF_NB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SHIFT  1

#define MP1_HUBIF_NB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_MASK  0x00000002

#define MP1_HUBIF_NB_OBFF_EMUL_MASK \
      (MP1_HUBIF_NB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_MASK)

#define MP1_HUBIF_NB_OBFF_EMUL_DEFAULT 0x00000000

#define MP1_HUBIF_NB_OBFF_EMUL_GET_IP_SYSHUB_URGENT_DMA(mp1_hubif_nb_obff_emul) \
      ((mp1_hubif_nb_obff_emul & MP1_HUBIF_NB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_MASK) >> MP1_HUBIF_NB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SHIFT)

#define MP1_HUBIF_NB_OBFF_EMUL_SET_IP_SYSHUB_URGENT_DMA(mp1_hubif_nb_obff_emul_reg, ip_syshub_urgent_dma) \
      mp1_hubif_nb_obff_emul_reg = (mp1_hubif_nb_obff_emul_reg & ~MP1_HUBIF_NB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_MASK) | (ip_syshub_urgent_dma << MP1_HUBIF_NB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_hubif_nb_obff_emul_t {
            unsigned int                                : 1;
            unsigned int ip_syshub_urgent_dma           : MP1_HUBIF_NB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SIZE;
            unsigned int                                : 30;
      } mp1_hubif_nb_obff_emul_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_hubif_nb_obff_emul_t {
            unsigned int                                : 30;
            unsigned int ip_syshub_urgent_dma           : MP1_HUBIF_NB_OBFF_EMUL_IP_SYSHUB_URGENT_DMA_SIZE;
            unsigned int                                : 1;
      } mp1_hubif_nb_obff_emul_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_hubif_nb_obff_emul_t f;
} mp1_hubif_nb_obff_emul_u;


#endif

