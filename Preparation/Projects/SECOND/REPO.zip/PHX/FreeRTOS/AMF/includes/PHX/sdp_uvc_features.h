// Copyright (c) 2010 - 2019 Advanced Micro Devices, Inc. All rights reserved.
#ifndef __SDP_UVC_FEATURES_H__
#define __SDP_UVC_FEATURES_H__
// reference features

// imported features

// local features
#define SDP_UVC__NUM_RDRSP_CHAN 1
#define SDP_UVC__NUM_RDRSP_CHAN__1 1
#define SDP_COMP__NUM_RDRSP_CHAN 1
#define SDP_COMP__NUM_RDRSP_CHAN__1 1
#endif
