// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_PSPCCP_REGS_FIDDLE_H)
#define _PSPCCP_REGS_FIDDLE_H

/*****************************************************************************************************************
 *
 *	pspccp_regs_reg.h
 *
 *	Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif


/*******************************************************
 * Values
 *******************************************************/


/*******************************************************
 * Structures
 *******************************************************/

/*
 * PspCcpCmd_Queue_Mask struct
 */

#define PspCcpCmd_Queue_Mask_REG_SIZE  32
#define PspCcpCmd_Queue_Mask_RI_CmdQueueMask_SIZE 3

#define PspCcpCmd_Queue_Mask_RI_CmdQueueMask_SHIFT 0

#define PspCcpCmd_Queue_Mask_RI_CmdQueueMask_MASK 0x7

#define PspCcpCmd_Queue_Mask_MASK \
     (PspCcpCmd_Queue_Mask_RI_CmdQueueMask_MASK)

#define PspCcpCmd_Queue_Mask_DEFAULT   0x00000000

#define PspCcpCmd_Queue_Mask_GET_RI_CmdQueueMask(pspccpcmd_queue_mask) \
     ((pspccpcmd_queue_mask & PspCcpCmd_Queue_Mask_RI_CmdQueueMask_MASK) >> PspCcpCmd_Queue_Mask_RI_CmdQueueMask_SHIFT)

#define PspCcpCmd_Queue_Mask_SET_RI_CmdQueueMask(pspccpcmd_queue_mask_reg, ri_cmdqueuemask) \
     pspccpcmd_queue_mask_reg = (pspccpcmd_queue_mask_reg & ~PspCcpCmd_Queue_Mask_RI_CmdQueueMask_MASK) | (ri_cmdqueuemask << PspCcpCmd_Queue_Mask_RI_CmdQueueMask_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_queue_mask_t {
          unsigned int ri_cmdqueuemask                : PspCcpCmd_Queue_Mask_RI_CmdQueueMask_SIZE;
          unsigned int                                : 29;
     } pspccpcmd_queue_mask_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_queue_mask_t {
          unsigned int                                : 29;
          unsigned int ri_cmdqueuemask                : PspCcpCmd_Queue_Mask_RI_CmdQueueMask_SIZE;
     } pspccpcmd_queue_mask_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_queue_mask_t f;
} pspccpcmd_queue_mask_u;


/*
 * PspCcpCmd_Queue_Priority0 struct
 */

#define PspCcpCmd_Queue_Priority0_REG_SIZE 32
#define PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue0_SIZE 3
#define PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue1_SIZE 3
#define PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue2_SIZE 3

#define PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue0_SHIFT 0
#define PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue1_SHIFT 3
#define PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue2_SHIFT 6

#define PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue0_MASK 0x7
#define PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue1_MASK 0x38
#define PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue2_MASK 0x1c0

#define PspCcpCmd_Queue_Priority0_MASK \
     (PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue0_MASK | \
      PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue1_MASK | \
      PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue2_MASK)

#define PspCcpCmd_Queue_Priority0_DEFAULT 0x000001ff

#define PspCcpCmd_Queue_Priority0_GET_RI_PriorityCmdQueue0(pspccpcmd_queue_priority0) \
     ((pspccpcmd_queue_priority0 & PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue0_MASK) >> PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue0_SHIFT)
#define PspCcpCmd_Queue_Priority0_GET_RI_PriorityCmdQueue1(pspccpcmd_queue_priority0) \
     ((pspccpcmd_queue_priority0 & PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue1_MASK) >> PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue1_SHIFT)
#define PspCcpCmd_Queue_Priority0_GET_RI_PriorityCmdQueue2(pspccpcmd_queue_priority0) \
     ((pspccpcmd_queue_priority0 & PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue2_MASK) >> PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue2_SHIFT)

#define PspCcpCmd_Queue_Priority0_SET_RI_PriorityCmdQueue0(pspccpcmd_queue_priority0_reg, ri_prioritycmdqueue0) \
     pspccpcmd_queue_priority0_reg = (pspccpcmd_queue_priority0_reg & ~PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue0_MASK) | (ri_prioritycmdqueue0 << PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue0_SHIFT)
#define PspCcpCmd_Queue_Priority0_SET_RI_PriorityCmdQueue1(pspccpcmd_queue_priority0_reg, ri_prioritycmdqueue1) \
     pspccpcmd_queue_priority0_reg = (pspccpcmd_queue_priority0_reg & ~PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue1_MASK) | (ri_prioritycmdqueue1 << PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue1_SHIFT)
#define PspCcpCmd_Queue_Priority0_SET_RI_PriorityCmdQueue2(pspccpcmd_queue_priority0_reg, ri_prioritycmdqueue2) \
     pspccpcmd_queue_priority0_reg = (pspccpcmd_queue_priority0_reg & ~PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue2_MASK) | (ri_prioritycmdqueue2 << PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue2_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_queue_priority0_t {
          unsigned int ri_prioritycmdqueue0           : PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue0_SIZE;
          unsigned int ri_prioritycmdqueue1           : PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue1_SIZE;
          unsigned int ri_prioritycmdqueue2           : PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue2_SIZE;
          unsigned int                                : 23;
     } pspccpcmd_queue_priority0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_queue_priority0_t {
          unsigned int                                : 23;
          unsigned int ri_prioritycmdqueue2           : PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue2_SIZE;
          unsigned int ri_prioritycmdqueue1           : PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue1_SIZE;
          unsigned int ri_prioritycmdqueue0           : PspCcpCmd_Queue_Priority0_RI_PriorityCmdQueue0_SIZE;
     } pspccpcmd_queue_priority0_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_queue_priority0_t f;
} pspccpcmd_queue_priority0_u;


/*
 * PspCcpReqID_Config0 struct
 */

#define PspCcpReqID_Config0_REG_SIZE   32
#define PspCcpReqID_Config0_RI_Q0_ReqId_SIZE 3
#define PspCcpReqID_Config0_RI_Q1_ReqId_SIZE 3
#define PspCcpReqID_Config0_RI_Q2_ReqId_SIZE 3

#define PspCcpReqID_Config0_RI_Q0_ReqId_SHIFT 0
#define PspCcpReqID_Config0_RI_Q1_ReqId_SHIFT 3
#define PspCcpReqID_Config0_RI_Q2_ReqId_SHIFT 6

#define PspCcpReqID_Config0_RI_Q0_ReqId_MASK 0x7
#define PspCcpReqID_Config0_RI_Q1_ReqId_MASK 0x38
#define PspCcpReqID_Config0_RI_Q2_ReqId_MASK 0x1c0

#define PspCcpReqID_Config0_MASK \
     (PspCcpReqID_Config0_RI_Q0_ReqId_MASK | \
      PspCcpReqID_Config0_RI_Q1_ReqId_MASK | \
      PspCcpReqID_Config0_RI_Q2_ReqId_MASK)

#define PspCcpReqID_Config0_DEFAULT    0x00000049

#define PspCcpReqID_Config0_GET_RI_Q0_ReqId(pspccpreqid_config0) \
     ((pspccpreqid_config0 & PspCcpReqID_Config0_RI_Q0_ReqId_MASK) >> PspCcpReqID_Config0_RI_Q0_ReqId_SHIFT)
#define PspCcpReqID_Config0_GET_RI_Q1_ReqId(pspccpreqid_config0) \
     ((pspccpreqid_config0 & PspCcpReqID_Config0_RI_Q1_ReqId_MASK) >> PspCcpReqID_Config0_RI_Q1_ReqId_SHIFT)
#define PspCcpReqID_Config0_GET_RI_Q2_ReqId(pspccpreqid_config0) \
     ((pspccpreqid_config0 & PspCcpReqID_Config0_RI_Q2_ReqId_MASK) >> PspCcpReqID_Config0_RI_Q2_ReqId_SHIFT)

#define PspCcpReqID_Config0_SET_RI_Q0_ReqId(pspccpreqid_config0_reg, ri_q0_reqid) \
     pspccpreqid_config0_reg = (pspccpreqid_config0_reg & ~PspCcpReqID_Config0_RI_Q0_ReqId_MASK) | (ri_q0_reqid << PspCcpReqID_Config0_RI_Q0_ReqId_SHIFT)
#define PspCcpReqID_Config0_SET_RI_Q1_ReqId(pspccpreqid_config0_reg, ri_q1_reqid) \
     pspccpreqid_config0_reg = (pspccpreqid_config0_reg & ~PspCcpReqID_Config0_RI_Q1_ReqId_MASK) | (ri_q1_reqid << PspCcpReqID_Config0_RI_Q1_ReqId_SHIFT)
#define PspCcpReqID_Config0_SET_RI_Q2_ReqId(pspccpreqid_config0_reg, ri_q2_reqid) \
     pspccpreqid_config0_reg = (pspccpreqid_config0_reg & ~PspCcpReqID_Config0_RI_Q2_ReqId_MASK) | (ri_q2_reqid << PspCcpReqID_Config0_RI_Q2_ReqId_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpreqid_config0_t {
          unsigned int ri_q0_reqid                    : PspCcpReqID_Config0_RI_Q0_ReqId_SIZE;
          unsigned int ri_q1_reqid                    : PspCcpReqID_Config0_RI_Q1_ReqId_SIZE;
          unsigned int ri_q2_reqid                    : PspCcpReqID_Config0_RI_Q2_ReqId_SIZE;
          unsigned int                                : 23;
     } pspccpreqid_config0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpreqid_config0_t {
          unsigned int                                : 23;
          unsigned int ri_q2_reqid                    : PspCcpReqID_Config0_RI_Q2_ReqId_SIZE;
          unsigned int ri_q1_reqid                    : PspCcpReqID_Config0_RI_Q1_ReqId_SIZE;
          unsigned int ri_q0_reqid                    : PspCcpReqID_Config0_RI_Q0_ReqId_SIZE;
     } pspccpreqid_config0_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpreqid_config0_t f;
} pspccpreqid_config0_u;


/*
 * PspCcpTrng_Out struct
 */

#define PspCcpTrng_Out_REG_SIZE        32
#define PspCcpTrng_Out_RI_RandomValue_SIZE 32

#define PspCcpTrng_Out_RI_RandomValue_SHIFT 0

#define PspCcpTrng_Out_RI_RandomValue_MASK 0xffffffff

#define PspCcpTrng_Out_MASK \
     (PspCcpTrng_Out_RI_RandomValue_MASK)

#define PspCcpTrng_Out_DEFAULT         0x00000000

#define PspCcpTrng_Out_GET_RI_RandomValue(pspccptrng_out) \
     ((pspccptrng_out & PspCcpTrng_Out_RI_RandomValue_MASK) >> PspCcpTrng_Out_RI_RandomValue_SHIFT)

#define PspCcpTrng_Out_SET_RI_RandomValue(pspccptrng_out_reg, ri_randomvalue) \
     pspccptrng_out_reg = (pspccptrng_out_reg & ~PspCcpTrng_Out_RI_RandomValue_MASK) | (ri_randomvalue << PspCcpTrng_Out_RI_RandomValue_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccptrng_out_t {
          unsigned int ri_randomvalue                 : PspCcpTrng_Out_RI_RandomValue_SIZE;
     } pspccptrng_out_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccptrng_out_t {
          unsigned int ri_randomvalue                 : PspCcpTrng_Out_RI_RandomValue_SIZE;
     } pspccptrng_out_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccptrng_out_t f;
} pspccptrng_out_u;


/*
 * PspCcpTrng_Seed struct
 */

#define PspCcpTrng_Seed_REG_SIZE       32
#define PspCcpTrng_Seed_RI_SeedValue_SIZE 32

#define PspCcpTrng_Seed_RI_SeedValue_SHIFT 0

#define PspCcpTrng_Seed_RI_SeedValue_MASK 0xffffffff

#define PspCcpTrng_Seed_MASK \
     (PspCcpTrng_Seed_RI_SeedValue_MASK)

#define PspCcpTrng_Seed_DEFAULT        0x00000000

#define PspCcpTrng_Seed_GET_RI_SeedValue(pspccptrng_seed) \
     ((pspccptrng_seed & PspCcpTrng_Seed_RI_SeedValue_MASK) >> PspCcpTrng_Seed_RI_SeedValue_SHIFT)

#define PspCcpTrng_Seed_SET_RI_SeedValue(pspccptrng_seed_reg, ri_seedvalue) \
     pspccptrng_seed_reg = (pspccptrng_seed_reg & ~PspCcpTrng_Seed_RI_SeedValue_MASK) | (ri_seedvalue << PspCcpTrng_Seed_RI_SeedValue_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccptrng_seed_t {
          unsigned int ri_seedvalue                   : PspCcpTrng_Seed_RI_SeedValue_SIZE;
     } pspccptrng_seed_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccptrng_seed_t {
          unsigned int ri_seedvalue                   : PspCcpTrng_Seed_RI_SeedValue_SIZE;
     } pspccptrng_seed_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccptrng_seed_t f;
} pspccptrng_seed_u;


/*
 * PspCcpTrng_Raw struct
 */

#define PspCcpTrng_Raw_REG_SIZE        32
#define PspCcpTrng_Raw_RI_ROValue_SIZE 16

#define PspCcpTrng_Raw_RI_ROValue_SHIFT 0

#define PspCcpTrng_Raw_RI_ROValue_MASK 0xffff

#define PspCcpTrng_Raw_MASK \
     (PspCcpTrng_Raw_RI_ROValue_MASK)

#define PspCcpTrng_Raw_DEFAULT         0x00000000

#define PspCcpTrng_Raw_GET_RI_ROValue(pspccptrng_raw) \
     ((pspccptrng_raw & PspCcpTrng_Raw_RI_ROValue_MASK) >> PspCcpTrng_Raw_RI_ROValue_SHIFT)

#define PspCcpTrng_Raw_SET_RI_ROValue(pspccptrng_raw_reg, ri_rovalue) \
     pspccptrng_raw_reg = (pspccptrng_raw_reg & ~PspCcpTrng_Raw_RI_ROValue_MASK) | (ri_rovalue << PspCcpTrng_Raw_RI_ROValue_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccptrng_raw_t {
          unsigned int ri_rovalue                     : PspCcpTrng_Raw_RI_ROValue_SIZE;
          unsigned int                                : 16;
     } pspccptrng_raw_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccptrng_raw_t {
          unsigned int                                : 16;
          unsigned int ri_rovalue                     : PspCcpTrng_Raw_RI_ROValue_SIZE;
     } pspccptrng_raw_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccptrng_raw_t f;
} pspccptrng_raw_u;


/*
 * PspCcpModule_Reset struct
 */

#define PspCcpModule_Reset_REG_SIZE    32
#define PspCcpModule_Reset_RI_AES_Reset_SIZE 1
#define PspCcpModule_Reset_RI_SHA_Reset_SIZE 1
#define PspCcpModule_Reset_RI_PT_Reset_SIZE 1
#define PspCcpModule_Reset_RI_PKI_Reset_SIZE 1
#define PspCcpModule_Reset_RI_ZDE_Reset_SIZE 1
#define PspCcpModule_Reset_RI_TRNG_Reset_SIZE 1
#define PspCcpModule_Reset_RI_EFLC_Reset_SIZE 1
#define PspCcpModule_Reset_RI_IDMA_Reset_SIZE 1
#define PspCcpModule_Reset_RI_JPM_Reset_SIZE 1
#define PspCcpModule_Reset_RI_ODMA_Reset_SIZE 1
#define PspCcpModule_Reset_RI_VQM0_Reset_SIZE 1
#define PspCcpModule_Reset_RI_VQM1_Reset_SIZE 1
#define PspCcpModule_Reset_RI_VQM2_Reset_SIZE 1

#define PspCcpModule_Reset_RI_AES_Reset_SHIFT 0
#define PspCcpModule_Reset_RI_SHA_Reset_SHIFT 2
#define PspCcpModule_Reset_RI_PT_Reset_SHIFT 3
#define PspCcpModule_Reset_RI_PKI_Reset_SHIFT 4
#define PspCcpModule_Reset_RI_ZDE_Reset_SHIFT 5
#define PspCcpModule_Reset_RI_TRNG_Reset_SHIFT 8
#define PspCcpModule_Reset_RI_EFLC_Reset_SHIFT 9
#define PspCcpModule_Reset_RI_IDMA_Reset_SHIFT 10
#define PspCcpModule_Reset_RI_JPM_Reset_SHIFT 11
#define PspCcpModule_Reset_RI_ODMA_Reset_SHIFT 12
#define PspCcpModule_Reset_RI_VQM0_Reset_SHIFT 13
#define PspCcpModule_Reset_RI_VQM1_Reset_SHIFT 14
#define PspCcpModule_Reset_RI_VQM2_Reset_SHIFT 15

#define PspCcpModule_Reset_RI_AES_Reset_MASK 0x1
#define PspCcpModule_Reset_RI_SHA_Reset_MASK 0x4
#define PspCcpModule_Reset_RI_PT_Reset_MASK 0x8
#define PspCcpModule_Reset_RI_PKI_Reset_MASK 0x10
#define PspCcpModule_Reset_RI_ZDE_Reset_MASK 0x20
#define PspCcpModule_Reset_RI_TRNG_Reset_MASK 0x100
#define PspCcpModule_Reset_RI_EFLC_Reset_MASK 0x200
#define PspCcpModule_Reset_RI_IDMA_Reset_MASK 0x400
#define PspCcpModule_Reset_RI_JPM_Reset_MASK 0x800
#define PspCcpModule_Reset_RI_ODMA_Reset_MASK 0x1000
#define PspCcpModule_Reset_RI_VQM0_Reset_MASK 0x2000
#define PspCcpModule_Reset_RI_VQM1_Reset_MASK 0x4000
#define PspCcpModule_Reset_RI_VQM2_Reset_MASK 0x8000

#define PspCcpModule_Reset_MASK \
     (PspCcpModule_Reset_RI_AES_Reset_MASK | \
      PspCcpModule_Reset_RI_SHA_Reset_MASK | \
      PspCcpModule_Reset_RI_PT_Reset_MASK | \
      PspCcpModule_Reset_RI_PKI_Reset_MASK | \
      PspCcpModule_Reset_RI_ZDE_Reset_MASK | \
      PspCcpModule_Reset_RI_TRNG_Reset_MASK | \
      PspCcpModule_Reset_RI_EFLC_Reset_MASK | \
      PspCcpModule_Reset_RI_IDMA_Reset_MASK | \
      PspCcpModule_Reset_RI_JPM_Reset_MASK | \
      PspCcpModule_Reset_RI_ODMA_Reset_MASK | \
      PspCcpModule_Reset_RI_VQM0_Reset_MASK | \
      PspCcpModule_Reset_RI_VQM1_Reset_MASK | \
      PspCcpModule_Reset_RI_VQM2_Reset_MASK)

#define PspCcpModule_Reset_DEFAULT     0x00000000

#define PspCcpModule_Reset_GET_RI_AES_Reset(pspccpmodule_reset) \
     ((pspccpmodule_reset & PspCcpModule_Reset_RI_AES_Reset_MASK) >> PspCcpModule_Reset_RI_AES_Reset_SHIFT)
#define PspCcpModule_Reset_GET_RI_SHA_Reset(pspccpmodule_reset) \
     ((pspccpmodule_reset & PspCcpModule_Reset_RI_SHA_Reset_MASK) >> PspCcpModule_Reset_RI_SHA_Reset_SHIFT)
#define PspCcpModule_Reset_GET_RI_PT_Reset(pspccpmodule_reset) \
     ((pspccpmodule_reset & PspCcpModule_Reset_RI_PT_Reset_MASK) >> PspCcpModule_Reset_RI_PT_Reset_SHIFT)
#define PspCcpModule_Reset_GET_RI_PKI_Reset(pspccpmodule_reset) \
     ((pspccpmodule_reset & PspCcpModule_Reset_RI_PKI_Reset_MASK) >> PspCcpModule_Reset_RI_PKI_Reset_SHIFT)
#define PspCcpModule_Reset_GET_RI_ZDE_Reset(pspccpmodule_reset) \
     ((pspccpmodule_reset & PspCcpModule_Reset_RI_ZDE_Reset_MASK) >> PspCcpModule_Reset_RI_ZDE_Reset_SHIFT)
#define PspCcpModule_Reset_GET_RI_TRNG_Reset(pspccpmodule_reset) \
     ((pspccpmodule_reset & PspCcpModule_Reset_RI_TRNG_Reset_MASK) >> PspCcpModule_Reset_RI_TRNG_Reset_SHIFT)
#define PspCcpModule_Reset_GET_RI_EFLC_Reset(pspccpmodule_reset) \
     ((pspccpmodule_reset & PspCcpModule_Reset_RI_EFLC_Reset_MASK) >> PspCcpModule_Reset_RI_EFLC_Reset_SHIFT)
#define PspCcpModule_Reset_GET_RI_IDMA_Reset(pspccpmodule_reset) \
     ((pspccpmodule_reset & PspCcpModule_Reset_RI_IDMA_Reset_MASK) >> PspCcpModule_Reset_RI_IDMA_Reset_SHIFT)
#define PspCcpModule_Reset_GET_RI_JPM_Reset(pspccpmodule_reset) \
     ((pspccpmodule_reset & PspCcpModule_Reset_RI_JPM_Reset_MASK) >> PspCcpModule_Reset_RI_JPM_Reset_SHIFT)
#define PspCcpModule_Reset_GET_RI_ODMA_Reset(pspccpmodule_reset) \
     ((pspccpmodule_reset & PspCcpModule_Reset_RI_ODMA_Reset_MASK) >> PspCcpModule_Reset_RI_ODMA_Reset_SHIFT)
#define PspCcpModule_Reset_GET_RI_VQM0_Reset(pspccpmodule_reset) \
     ((pspccpmodule_reset & PspCcpModule_Reset_RI_VQM0_Reset_MASK) >> PspCcpModule_Reset_RI_VQM0_Reset_SHIFT)
#define PspCcpModule_Reset_GET_RI_VQM1_Reset(pspccpmodule_reset) \
     ((pspccpmodule_reset & PspCcpModule_Reset_RI_VQM1_Reset_MASK) >> PspCcpModule_Reset_RI_VQM1_Reset_SHIFT)
#define PspCcpModule_Reset_GET_RI_VQM2_Reset(pspccpmodule_reset) \
     ((pspccpmodule_reset & PspCcpModule_Reset_RI_VQM2_Reset_MASK) >> PspCcpModule_Reset_RI_VQM2_Reset_SHIFT)

#define PspCcpModule_Reset_SET_RI_AES_Reset(pspccpmodule_reset_reg, ri_aes_reset) \
     pspccpmodule_reset_reg = (pspccpmodule_reset_reg & ~PspCcpModule_Reset_RI_AES_Reset_MASK) | (ri_aes_reset << PspCcpModule_Reset_RI_AES_Reset_SHIFT)
#define PspCcpModule_Reset_SET_RI_SHA_Reset(pspccpmodule_reset_reg, ri_sha_reset) \
     pspccpmodule_reset_reg = (pspccpmodule_reset_reg & ~PspCcpModule_Reset_RI_SHA_Reset_MASK) | (ri_sha_reset << PspCcpModule_Reset_RI_SHA_Reset_SHIFT)
#define PspCcpModule_Reset_SET_RI_PT_Reset(pspccpmodule_reset_reg, ri_pt_reset) \
     pspccpmodule_reset_reg = (pspccpmodule_reset_reg & ~PspCcpModule_Reset_RI_PT_Reset_MASK) | (ri_pt_reset << PspCcpModule_Reset_RI_PT_Reset_SHIFT)
#define PspCcpModule_Reset_SET_RI_PKI_Reset(pspccpmodule_reset_reg, ri_pki_reset) \
     pspccpmodule_reset_reg = (pspccpmodule_reset_reg & ~PspCcpModule_Reset_RI_PKI_Reset_MASK) | (ri_pki_reset << PspCcpModule_Reset_RI_PKI_Reset_SHIFT)
#define PspCcpModule_Reset_SET_RI_ZDE_Reset(pspccpmodule_reset_reg, ri_zde_reset) \
     pspccpmodule_reset_reg = (pspccpmodule_reset_reg & ~PspCcpModule_Reset_RI_ZDE_Reset_MASK) | (ri_zde_reset << PspCcpModule_Reset_RI_ZDE_Reset_SHIFT)
#define PspCcpModule_Reset_SET_RI_TRNG_Reset(pspccpmodule_reset_reg, ri_trng_reset) \
     pspccpmodule_reset_reg = (pspccpmodule_reset_reg & ~PspCcpModule_Reset_RI_TRNG_Reset_MASK) | (ri_trng_reset << PspCcpModule_Reset_RI_TRNG_Reset_SHIFT)
#define PspCcpModule_Reset_SET_RI_EFLC_Reset(pspccpmodule_reset_reg, ri_eflc_reset) \
     pspccpmodule_reset_reg = (pspccpmodule_reset_reg & ~PspCcpModule_Reset_RI_EFLC_Reset_MASK) | (ri_eflc_reset << PspCcpModule_Reset_RI_EFLC_Reset_SHIFT)
#define PspCcpModule_Reset_SET_RI_IDMA_Reset(pspccpmodule_reset_reg, ri_idma_reset) \
     pspccpmodule_reset_reg = (pspccpmodule_reset_reg & ~PspCcpModule_Reset_RI_IDMA_Reset_MASK) | (ri_idma_reset << PspCcpModule_Reset_RI_IDMA_Reset_SHIFT)
#define PspCcpModule_Reset_SET_RI_JPM_Reset(pspccpmodule_reset_reg, ri_jpm_reset) \
     pspccpmodule_reset_reg = (pspccpmodule_reset_reg & ~PspCcpModule_Reset_RI_JPM_Reset_MASK) | (ri_jpm_reset << PspCcpModule_Reset_RI_JPM_Reset_SHIFT)
#define PspCcpModule_Reset_SET_RI_ODMA_Reset(pspccpmodule_reset_reg, ri_odma_reset) \
     pspccpmodule_reset_reg = (pspccpmodule_reset_reg & ~PspCcpModule_Reset_RI_ODMA_Reset_MASK) | (ri_odma_reset << PspCcpModule_Reset_RI_ODMA_Reset_SHIFT)
#define PspCcpModule_Reset_SET_RI_VQM0_Reset(pspccpmodule_reset_reg, ri_vqm0_reset) \
     pspccpmodule_reset_reg = (pspccpmodule_reset_reg & ~PspCcpModule_Reset_RI_VQM0_Reset_MASK) | (ri_vqm0_reset << PspCcpModule_Reset_RI_VQM0_Reset_SHIFT)
#define PspCcpModule_Reset_SET_RI_VQM1_Reset(pspccpmodule_reset_reg, ri_vqm1_reset) \
     pspccpmodule_reset_reg = (pspccpmodule_reset_reg & ~PspCcpModule_Reset_RI_VQM1_Reset_MASK) | (ri_vqm1_reset << PspCcpModule_Reset_RI_VQM1_Reset_SHIFT)
#define PspCcpModule_Reset_SET_RI_VQM2_Reset(pspccpmodule_reset_reg, ri_vqm2_reset) \
     pspccpmodule_reset_reg = (pspccpmodule_reset_reg & ~PspCcpModule_Reset_RI_VQM2_Reset_MASK) | (ri_vqm2_reset << PspCcpModule_Reset_RI_VQM2_Reset_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpmodule_reset_t {
          unsigned int ri_aes_reset                   : PspCcpModule_Reset_RI_AES_Reset_SIZE;
          unsigned int                                : 1;
          unsigned int ri_sha_reset                   : PspCcpModule_Reset_RI_SHA_Reset_SIZE;
          unsigned int ri_pt_reset                    : PspCcpModule_Reset_RI_PT_Reset_SIZE;
          unsigned int ri_pki_reset                   : PspCcpModule_Reset_RI_PKI_Reset_SIZE;
          unsigned int ri_zde_reset                   : PspCcpModule_Reset_RI_ZDE_Reset_SIZE;
          unsigned int                                : 2;
          unsigned int ri_trng_reset                  : PspCcpModule_Reset_RI_TRNG_Reset_SIZE;
          unsigned int ri_eflc_reset                  : PspCcpModule_Reset_RI_EFLC_Reset_SIZE;
          unsigned int ri_idma_reset                  : PspCcpModule_Reset_RI_IDMA_Reset_SIZE;
          unsigned int ri_jpm_reset                   : PspCcpModule_Reset_RI_JPM_Reset_SIZE;
          unsigned int ri_odma_reset                  : PspCcpModule_Reset_RI_ODMA_Reset_SIZE;
          unsigned int ri_vqm0_reset                  : PspCcpModule_Reset_RI_VQM0_Reset_SIZE;
          unsigned int ri_vqm1_reset                  : PspCcpModule_Reset_RI_VQM1_Reset_SIZE;
          unsigned int ri_vqm2_reset                  : PspCcpModule_Reset_RI_VQM2_Reset_SIZE;
          unsigned int                                : 16;
     } pspccpmodule_reset_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpmodule_reset_t {
          unsigned int                                : 16;
          unsigned int ri_vqm2_reset                  : PspCcpModule_Reset_RI_VQM2_Reset_SIZE;
          unsigned int ri_vqm1_reset                  : PspCcpModule_Reset_RI_VQM1_Reset_SIZE;
          unsigned int ri_vqm0_reset                  : PspCcpModule_Reset_RI_VQM0_Reset_SIZE;
          unsigned int ri_odma_reset                  : PspCcpModule_Reset_RI_ODMA_Reset_SIZE;
          unsigned int ri_jpm_reset                   : PspCcpModule_Reset_RI_JPM_Reset_SIZE;
          unsigned int ri_idma_reset                  : PspCcpModule_Reset_RI_IDMA_Reset_SIZE;
          unsigned int ri_eflc_reset                  : PspCcpModule_Reset_RI_EFLC_Reset_SIZE;
          unsigned int ri_trng_reset                  : PspCcpModule_Reset_RI_TRNG_Reset_SIZE;
          unsigned int                                : 2;
          unsigned int ri_zde_reset                   : PspCcpModule_Reset_RI_ZDE_Reset_SIZE;
          unsigned int ri_pki_reset                   : PspCcpModule_Reset_RI_PKI_Reset_SIZE;
          unsigned int ri_pt_reset                    : PspCcpModule_Reset_RI_PT_Reset_SIZE;
          unsigned int ri_sha_reset                   : PspCcpModule_Reset_RI_SHA_Reset_SIZE;
          unsigned int                                : 1;
          unsigned int ri_aes_reset                   : PspCcpModule_Reset_RI_AES_Reset_SIZE;
     } pspccpmodule_reset_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpmodule_reset_t f;
} pspccpmodule_reset_u;


/*
 * PspCcpCmd_Timeout struct
 */

#define PspCcpCmd_Timeout_REG_SIZE     32
#define PspCcpCmd_Timeout_RI_CmdTimeout_SIZE 32

#define PspCcpCmd_Timeout_RI_CmdTimeout_SHIFT 0

#define PspCcpCmd_Timeout_RI_CmdTimeout_MASK 0xffffffff

#define PspCcpCmd_Timeout_MASK \
     (PspCcpCmd_Timeout_RI_CmdTimeout_MASK)

#define PspCcpCmd_Timeout_DEFAULT      0x00000000

#define PspCcpCmd_Timeout_GET_RI_CmdTimeout(pspccpcmd_timeout) \
     ((pspccpcmd_timeout & PspCcpCmd_Timeout_RI_CmdTimeout_MASK) >> PspCcpCmd_Timeout_RI_CmdTimeout_SHIFT)

#define PspCcpCmd_Timeout_SET_RI_CmdTimeout(pspccpcmd_timeout_reg, ri_cmdtimeout) \
     pspccpcmd_timeout_reg = (pspccpcmd_timeout_reg & ~PspCcpCmd_Timeout_RI_CmdTimeout_MASK) | (ri_cmdtimeout << PspCcpCmd_Timeout_RI_CmdTimeout_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_timeout_t {
          unsigned int ri_cmdtimeout                  : PspCcpCmd_Timeout_RI_CmdTimeout_SIZE;
     } pspccpcmd_timeout_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_timeout_t {
          unsigned int ri_cmdtimeout                  : PspCcpCmd_Timeout_RI_CmdTimeout_SIZE;
     } pspccpcmd_timeout_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_timeout_t f;
} pspccpcmd_timeout_u;


/*
 * PspCcpCmd_Timeout_Granularity struct
 */

#define PspCcpCmd_Timeout_Granularity_REG_SIZE 32
#define PspCcpCmd_Timeout_Granularity_RI_Granularity_SIZE 32

#define PspCcpCmd_Timeout_Granularity_RI_Granularity_SHIFT 0

#define PspCcpCmd_Timeout_Granularity_RI_Granularity_MASK 0xffffffff

#define PspCcpCmd_Timeout_Granularity_MASK \
     (PspCcpCmd_Timeout_Granularity_RI_Granularity_MASK)

#define PspCcpCmd_Timeout_Granularity_DEFAULT 0x00000001

#define PspCcpCmd_Timeout_Granularity_GET_RI_Granularity(pspccpcmd_timeout_granularity) \
     ((pspccpcmd_timeout_granularity & PspCcpCmd_Timeout_Granularity_RI_Granularity_MASK) >> PspCcpCmd_Timeout_Granularity_RI_Granularity_SHIFT)

#define PspCcpCmd_Timeout_Granularity_SET_RI_Granularity(pspccpcmd_timeout_granularity_reg, ri_granularity) \
     pspccpcmd_timeout_granularity_reg = (pspccpcmd_timeout_granularity_reg & ~PspCcpCmd_Timeout_Granularity_RI_Granularity_MASK) | (ri_granularity << PspCcpCmd_Timeout_Granularity_RI_Granularity_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_timeout_granularity_t {
          unsigned int ri_granularity                 : PspCcpCmd_Timeout_Granularity_RI_Granularity_SIZE;
     } pspccpcmd_timeout_granularity_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_timeout_granularity_t {
          unsigned int ri_granularity                 : PspCcpCmd_Timeout_Granularity_RI_Granularity_SIZE;
     } pspccpcmd_timeout_granularity_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_timeout_granularity_t f;
} pspccpcmd_timeout_granularity_u;


/*
 * PspCcpLsb_Public_Protection_Mask_R0 struct
 */

#define PspCcpLsb_Public_Protection_Mask_R0_REG_SIZE 32
#define PspCcpLsb_Public_Protection_Mask_R0_RI_R0_Mask_SIZE 3

#define PspCcpLsb_Public_Protection_Mask_R0_RI_R0_Mask_SHIFT 0

#define PspCcpLsb_Public_Protection_Mask_R0_RI_R0_Mask_MASK 0x7

#define PspCcpLsb_Public_Protection_Mask_R0_MASK \
     (PspCcpLsb_Public_Protection_Mask_R0_RI_R0_Mask_MASK)

#define PspCcpLsb_Public_Protection_Mask_R0_DEFAULT 0x00000000

#define PspCcpLsb_Public_Protection_Mask_R0_GET_RI_R0_Mask(pspccplsb_public_protection_mask_r0) \
     ((pspccplsb_public_protection_mask_r0 & PspCcpLsb_Public_Protection_Mask_R0_RI_R0_Mask_MASK) >> PspCcpLsb_Public_Protection_Mask_R0_RI_R0_Mask_SHIFT)

#define PspCcpLsb_Public_Protection_Mask_R0_SET_RI_R0_Mask(pspccplsb_public_protection_mask_r0_reg, ri_r0_mask) \
     pspccplsb_public_protection_mask_r0_reg = (pspccplsb_public_protection_mask_r0_reg & ~PspCcpLsb_Public_Protection_Mask_R0_RI_R0_Mask_MASK) | (ri_r0_mask << PspCcpLsb_Public_Protection_Mask_R0_RI_R0_Mask_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccplsb_public_protection_mask_r0_t {
          unsigned int ri_r0_mask                     : PspCcpLsb_Public_Protection_Mask_R0_RI_R0_Mask_SIZE;
          unsigned int                                : 29;
     } pspccplsb_public_protection_mask_r0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccplsb_public_protection_mask_r0_t {
          unsigned int                                : 29;
          unsigned int ri_r0_mask                     : PspCcpLsb_Public_Protection_Mask_R0_RI_R0_Mask_SIZE;
     } pspccplsb_public_protection_mask_r0_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccplsb_public_protection_mask_r0_t f;
} pspccplsb_public_protection_mask_r0_u;


/*
 * PspCcpLsb_Public_Protection_Mask_R1 struct
 */

#define PspCcpLsb_Public_Protection_Mask_R1_REG_SIZE 32
#define PspCcpLsb_Public_Protection_Mask_R1_RI_R1_Mask_SIZE 3

#define PspCcpLsb_Public_Protection_Mask_R1_RI_R1_Mask_SHIFT 0

#define PspCcpLsb_Public_Protection_Mask_R1_RI_R1_Mask_MASK 0x7

#define PspCcpLsb_Public_Protection_Mask_R1_MASK \
     (PspCcpLsb_Public_Protection_Mask_R1_RI_R1_Mask_MASK)

#define PspCcpLsb_Public_Protection_Mask_R1_DEFAULT 0x00000000

#define PspCcpLsb_Public_Protection_Mask_R1_GET_RI_R1_Mask(pspccplsb_public_protection_mask_r1) \
     ((pspccplsb_public_protection_mask_r1 & PspCcpLsb_Public_Protection_Mask_R1_RI_R1_Mask_MASK) >> PspCcpLsb_Public_Protection_Mask_R1_RI_R1_Mask_SHIFT)

#define PspCcpLsb_Public_Protection_Mask_R1_SET_RI_R1_Mask(pspccplsb_public_protection_mask_r1_reg, ri_r1_mask) \
     pspccplsb_public_protection_mask_r1_reg = (pspccplsb_public_protection_mask_r1_reg & ~PspCcpLsb_Public_Protection_Mask_R1_RI_R1_Mask_MASK) | (ri_r1_mask << PspCcpLsb_Public_Protection_Mask_R1_RI_R1_Mask_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccplsb_public_protection_mask_r1_t {
          unsigned int ri_r1_mask                     : PspCcpLsb_Public_Protection_Mask_R1_RI_R1_Mask_SIZE;
          unsigned int                                : 29;
     } pspccplsb_public_protection_mask_r1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccplsb_public_protection_mask_r1_t {
          unsigned int                                : 29;
          unsigned int ri_r1_mask                     : PspCcpLsb_Public_Protection_Mask_R1_RI_R1_Mask_SIZE;
     } pspccplsb_public_protection_mask_r1_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccplsb_public_protection_mask_r1_t f;
} pspccplsb_public_protection_mask_r1_u;


/*
 * PspCcpLsb_Public_Protection_Mask_R2 struct
 */

#define PspCcpLsb_Public_Protection_Mask_R2_REG_SIZE 32
#define PspCcpLsb_Public_Protection_Mask_R2_RI_R2_Mask_SIZE 3

#define PspCcpLsb_Public_Protection_Mask_R2_RI_R2_Mask_SHIFT 0

#define PspCcpLsb_Public_Protection_Mask_R2_RI_R2_Mask_MASK 0x7

#define PspCcpLsb_Public_Protection_Mask_R2_MASK \
     (PspCcpLsb_Public_Protection_Mask_R2_RI_R2_Mask_MASK)

#define PspCcpLsb_Public_Protection_Mask_R2_DEFAULT 0x00000000

#define PspCcpLsb_Public_Protection_Mask_R2_GET_RI_R2_Mask(pspccplsb_public_protection_mask_r2) \
     ((pspccplsb_public_protection_mask_r2 & PspCcpLsb_Public_Protection_Mask_R2_RI_R2_Mask_MASK) >> PspCcpLsb_Public_Protection_Mask_R2_RI_R2_Mask_SHIFT)

#define PspCcpLsb_Public_Protection_Mask_R2_SET_RI_R2_Mask(pspccplsb_public_protection_mask_r2_reg, ri_r2_mask) \
     pspccplsb_public_protection_mask_r2_reg = (pspccplsb_public_protection_mask_r2_reg & ~PspCcpLsb_Public_Protection_Mask_R2_RI_R2_Mask_MASK) | (ri_r2_mask << PspCcpLsb_Public_Protection_Mask_R2_RI_R2_Mask_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccplsb_public_protection_mask_r2_t {
          unsigned int ri_r2_mask                     : PspCcpLsb_Public_Protection_Mask_R2_RI_R2_Mask_SIZE;
          unsigned int                                : 29;
     } pspccplsb_public_protection_mask_r2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccplsb_public_protection_mask_r2_t {
          unsigned int                                : 29;
          unsigned int ri_r2_mask                     : PspCcpLsb_Public_Protection_Mask_R2_RI_R2_Mask_SIZE;
     } pspccplsb_public_protection_mask_r2_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccplsb_public_protection_mask_r2_t f;
} pspccplsb_public_protection_mask_r2_u;


/*
 * PspCcpLsb_Public_Protection_Mask_R3 struct
 */

#define PspCcpLsb_Public_Protection_Mask_R3_REG_SIZE 32
#define PspCcpLsb_Public_Protection_Mask_R3_RI_R3_Mask_SIZE 3

#define PspCcpLsb_Public_Protection_Mask_R3_RI_R3_Mask_SHIFT 0

#define PspCcpLsb_Public_Protection_Mask_R3_RI_R3_Mask_MASK 0x7

#define PspCcpLsb_Public_Protection_Mask_R3_MASK \
     (PspCcpLsb_Public_Protection_Mask_R3_RI_R3_Mask_MASK)

#define PspCcpLsb_Public_Protection_Mask_R3_DEFAULT 0x00000000

#define PspCcpLsb_Public_Protection_Mask_R3_GET_RI_R3_Mask(pspccplsb_public_protection_mask_r3) \
     ((pspccplsb_public_protection_mask_r3 & PspCcpLsb_Public_Protection_Mask_R3_RI_R3_Mask_MASK) >> PspCcpLsb_Public_Protection_Mask_R3_RI_R3_Mask_SHIFT)

#define PspCcpLsb_Public_Protection_Mask_R3_SET_RI_R3_Mask(pspccplsb_public_protection_mask_r3_reg, ri_r3_mask) \
     pspccplsb_public_protection_mask_r3_reg = (pspccplsb_public_protection_mask_r3_reg & ~PspCcpLsb_Public_Protection_Mask_R3_RI_R3_Mask_MASK) | (ri_r3_mask << PspCcpLsb_Public_Protection_Mask_R3_RI_R3_Mask_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccplsb_public_protection_mask_r3_t {
          unsigned int ri_r3_mask                     : PspCcpLsb_Public_Protection_Mask_R3_RI_R3_Mask_SIZE;
          unsigned int                                : 29;
     } pspccplsb_public_protection_mask_r3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccplsb_public_protection_mask_r3_t {
          unsigned int                                : 29;
          unsigned int ri_r3_mask                     : PspCcpLsb_Public_Protection_Mask_R3_RI_R3_Mask_SIZE;
     } pspccplsb_public_protection_mask_r3_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccplsb_public_protection_mask_r3_t f;
} pspccplsb_public_protection_mask_r3_u;


/*
 * PspCcpLsb_Public_Protection_Mask_R4 struct
 */

#define PspCcpLsb_Public_Protection_Mask_R4_REG_SIZE 32
#define PspCcpLsb_Public_Protection_Mask_R4_RI_R4_Mask_SIZE 3

#define PspCcpLsb_Public_Protection_Mask_R4_RI_R4_Mask_SHIFT 0

#define PspCcpLsb_Public_Protection_Mask_R4_RI_R4_Mask_MASK 0x7

#define PspCcpLsb_Public_Protection_Mask_R4_MASK \
     (PspCcpLsb_Public_Protection_Mask_R4_RI_R4_Mask_MASK)

#define PspCcpLsb_Public_Protection_Mask_R4_DEFAULT 0x00000000

#define PspCcpLsb_Public_Protection_Mask_R4_GET_RI_R4_Mask(pspccplsb_public_protection_mask_r4) \
     ((pspccplsb_public_protection_mask_r4 & PspCcpLsb_Public_Protection_Mask_R4_RI_R4_Mask_MASK) >> PspCcpLsb_Public_Protection_Mask_R4_RI_R4_Mask_SHIFT)

#define PspCcpLsb_Public_Protection_Mask_R4_SET_RI_R4_Mask(pspccplsb_public_protection_mask_r4_reg, ri_r4_mask) \
     pspccplsb_public_protection_mask_r4_reg = (pspccplsb_public_protection_mask_r4_reg & ~PspCcpLsb_Public_Protection_Mask_R4_RI_R4_Mask_MASK) | (ri_r4_mask << PspCcpLsb_Public_Protection_Mask_R4_RI_R4_Mask_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccplsb_public_protection_mask_r4_t {
          unsigned int ri_r4_mask                     : PspCcpLsb_Public_Protection_Mask_R4_RI_R4_Mask_SIZE;
          unsigned int                                : 29;
     } pspccplsb_public_protection_mask_r4_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccplsb_public_protection_mask_r4_t {
          unsigned int                                : 29;
          unsigned int ri_r4_mask                     : PspCcpLsb_Public_Protection_Mask_R4_RI_R4_Mask_SIZE;
     } pspccplsb_public_protection_mask_r4_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccplsb_public_protection_mask_r4_t f;
} pspccplsb_public_protection_mask_r4_u;


/*
 * PspCcpLsb_Public_Protection_Mask_R5 struct
 */

#define PspCcpLsb_Public_Protection_Mask_R5_REG_SIZE 32
#define PspCcpLsb_Public_Protection_Mask_R5_RI_R5_Mask_SIZE 3

#define PspCcpLsb_Public_Protection_Mask_R5_RI_R5_Mask_SHIFT 0

#define PspCcpLsb_Public_Protection_Mask_R5_RI_R5_Mask_MASK 0x7

#define PspCcpLsb_Public_Protection_Mask_R5_MASK \
     (PspCcpLsb_Public_Protection_Mask_R5_RI_R5_Mask_MASK)

#define PspCcpLsb_Public_Protection_Mask_R5_DEFAULT 0x00000000

#define PspCcpLsb_Public_Protection_Mask_R5_GET_RI_R5_Mask(pspccplsb_public_protection_mask_r5) \
     ((pspccplsb_public_protection_mask_r5 & PspCcpLsb_Public_Protection_Mask_R5_RI_R5_Mask_MASK) >> PspCcpLsb_Public_Protection_Mask_R5_RI_R5_Mask_SHIFT)

#define PspCcpLsb_Public_Protection_Mask_R5_SET_RI_R5_Mask(pspccplsb_public_protection_mask_r5_reg, ri_r5_mask) \
     pspccplsb_public_protection_mask_r5_reg = (pspccplsb_public_protection_mask_r5_reg & ~PspCcpLsb_Public_Protection_Mask_R5_RI_R5_Mask_MASK) | (ri_r5_mask << PspCcpLsb_Public_Protection_Mask_R5_RI_R5_Mask_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccplsb_public_protection_mask_r5_t {
          unsigned int ri_r5_mask                     : PspCcpLsb_Public_Protection_Mask_R5_RI_R5_Mask_SIZE;
          unsigned int                                : 29;
     } pspccplsb_public_protection_mask_r5_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccplsb_public_protection_mask_r5_t {
          unsigned int                                : 29;
          unsigned int ri_r5_mask                     : PspCcpLsb_Public_Protection_Mask_R5_RI_R5_Mask_SIZE;
     } pspccplsb_public_protection_mask_r5_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccplsb_public_protection_mask_r5_t f;
} pspccplsb_public_protection_mask_r5_u;


/*
 * PspCcpLsb_Public_Protection_Mask_R6 struct
 */

#define PspCcpLsb_Public_Protection_Mask_R6_REG_SIZE 32
#define PspCcpLsb_Public_Protection_Mask_R6_RI_R6_Mask_SIZE 3

#define PspCcpLsb_Public_Protection_Mask_R6_RI_R6_Mask_SHIFT 0

#define PspCcpLsb_Public_Protection_Mask_R6_RI_R6_Mask_MASK 0x7

#define PspCcpLsb_Public_Protection_Mask_R6_MASK \
     (PspCcpLsb_Public_Protection_Mask_R6_RI_R6_Mask_MASK)

#define PspCcpLsb_Public_Protection_Mask_R6_DEFAULT 0x00000000

#define PspCcpLsb_Public_Protection_Mask_R6_GET_RI_R6_Mask(pspccplsb_public_protection_mask_r6) \
     ((pspccplsb_public_protection_mask_r6 & PspCcpLsb_Public_Protection_Mask_R6_RI_R6_Mask_MASK) >> PspCcpLsb_Public_Protection_Mask_R6_RI_R6_Mask_SHIFT)

#define PspCcpLsb_Public_Protection_Mask_R6_SET_RI_R6_Mask(pspccplsb_public_protection_mask_r6_reg, ri_r6_mask) \
     pspccplsb_public_protection_mask_r6_reg = (pspccplsb_public_protection_mask_r6_reg & ~PspCcpLsb_Public_Protection_Mask_R6_RI_R6_Mask_MASK) | (ri_r6_mask << PspCcpLsb_Public_Protection_Mask_R6_RI_R6_Mask_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccplsb_public_protection_mask_r6_t {
          unsigned int ri_r6_mask                     : PspCcpLsb_Public_Protection_Mask_R6_RI_R6_Mask_SIZE;
          unsigned int                                : 29;
     } pspccplsb_public_protection_mask_r6_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccplsb_public_protection_mask_r6_t {
          unsigned int                                : 29;
          unsigned int ri_r6_mask                     : PspCcpLsb_Public_Protection_Mask_R6_RI_R6_Mask_SIZE;
     } pspccplsb_public_protection_mask_r6_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccplsb_public_protection_mask_r6_t f;
} pspccplsb_public_protection_mask_r6_u;


/*
 * PspCcpLsb_Public_Protection_Mask_R7 struct
 */

#define PspCcpLsb_Public_Protection_Mask_R7_REG_SIZE 32
#define PspCcpLsb_Public_Protection_Mask_R7_RI_R7_Mask_SIZE 3

#define PspCcpLsb_Public_Protection_Mask_R7_RI_R7_Mask_SHIFT 0

#define PspCcpLsb_Public_Protection_Mask_R7_RI_R7_Mask_MASK 0x7

#define PspCcpLsb_Public_Protection_Mask_R7_MASK \
     (PspCcpLsb_Public_Protection_Mask_R7_RI_R7_Mask_MASK)

#define PspCcpLsb_Public_Protection_Mask_R7_DEFAULT 0x00000000

#define PspCcpLsb_Public_Protection_Mask_R7_GET_RI_R7_Mask(pspccplsb_public_protection_mask_r7) \
     ((pspccplsb_public_protection_mask_r7 & PspCcpLsb_Public_Protection_Mask_R7_RI_R7_Mask_MASK) >> PspCcpLsb_Public_Protection_Mask_R7_RI_R7_Mask_SHIFT)

#define PspCcpLsb_Public_Protection_Mask_R7_SET_RI_R7_Mask(pspccplsb_public_protection_mask_r7_reg, ri_r7_mask) \
     pspccplsb_public_protection_mask_r7_reg = (pspccplsb_public_protection_mask_r7_reg & ~PspCcpLsb_Public_Protection_Mask_R7_RI_R7_Mask_MASK) | (ri_r7_mask << PspCcpLsb_Public_Protection_Mask_R7_RI_R7_Mask_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccplsb_public_protection_mask_r7_t {
          unsigned int ri_r7_mask                     : PspCcpLsb_Public_Protection_Mask_R7_RI_R7_Mask_SIZE;
          unsigned int                                : 29;
     } pspccplsb_public_protection_mask_r7_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccplsb_public_protection_mask_r7_t {
          unsigned int                                : 29;
          unsigned int ri_r7_mask                     : PspCcpLsb_Public_Protection_Mask_R7_RI_R7_Mask_SIZE;
     } pspccplsb_public_protection_mask_r7_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccplsb_public_protection_mask_r7_t f;
} pspccplsb_public_protection_mask_r7_u;


/*
 * PspCcpLsb_Private_Protection_Mask_R0 struct
 */

#define PspCcpLsb_Private_Protection_Mask_R0_REG_SIZE 32
#define PspCcpLsb_Private_Protection_Mask_R0_RI_R0_Mask_SIZE 3

#define PspCcpLsb_Private_Protection_Mask_R0_RI_R0_Mask_SHIFT 0

#define PspCcpLsb_Private_Protection_Mask_R0_RI_R0_Mask_MASK 0x7

#define PspCcpLsb_Private_Protection_Mask_R0_MASK \
     (PspCcpLsb_Private_Protection_Mask_R0_RI_R0_Mask_MASK)

#define PspCcpLsb_Private_Protection_Mask_R0_DEFAULT 0x00000000

#define PspCcpLsb_Private_Protection_Mask_R0_GET_RI_R0_Mask(pspccplsb_private_protection_mask_r0) \
     ((pspccplsb_private_protection_mask_r0 & PspCcpLsb_Private_Protection_Mask_R0_RI_R0_Mask_MASK) >> PspCcpLsb_Private_Protection_Mask_R0_RI_R0_Mask_SHIFT)

#define PspCcpLsb_Private_Protection_Mask_R0_SET_RI_R0_Mask(pspccplsb_private_protection_mask_r0_reg, ri_r0_mask) \
     pspccplsb_private_protection_mask_r0_reg = (pspccplsb_private_protection_mask_r0_reg & ~PspCcpLsb_Private_Protection_Mask_R0_RI_R0_Mask_MASK) | (ri_r0_mask << PspCcpLsb_Private_Protection_Mask_R0_RI_R0_Mask_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccplsb_private_protection_mask_r0_t {
          unsigned int ri_r0_mask                     : PspCcpLsb_Private_Protection_Mask_R0_RI_R0_Mask_SIZE;
          unsigned int                                : 29;
     } pspccplsb_private_protection_mask_r0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccplsb_private_protection_mask_r0_t {
          unsigned int                                : 29;
          unsigned int ri_r0_mask                     : PspCcpLsb_Private_Protection_Mask_R0_RI_R0_Mask_SIZE;
     } pspccplsb_private_protection_mask_r0_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccplsb_private_protection_mask_r0_t f;
} pspccplsb_private_protection_mask_r0_u;


/*
 * PspCcpLsb_Private_Protection_Mask_R1 struct
 */

#define PspCcpLsb_Private_Protection_Mask_R1_REG_SIZE 32
#define PspCcpLsb_Private_Protection_Mask_R1_RI_R1_Mask_SIZE 3

#define PspCcpLsb_Private_Protection_Mask_R1_RI_R1_Mask_SHIFT 0

#define PspCcpLsb_Private_Protection_Mask_R1_RI_R1_Mask_MASK 0x7

#define PspCcpLsb_Private_Protection_Mask_R1_MASK \
     (PspCcpLsb_Private_Protection_Mask_R1_RI_R1_Mask_MASK)

#define PspCcpLsb_Private_Protection_Mask_R1_DEFAULT 0x00000000

#define PspCcpLsb_Private_Protection_Mask_R1_GET_RI_R1_Mask(pspccplsb_private_protection_mask_r1) \
     ((pspccplsb_private_protection_mask_r1 & PspCcpLsb_Private_Protection_Mask_R1_RI_R1_Mask_MASK) >> PspCcpLsb_Private_Protection_Mask_R1_RI_R1_Mask_SHIFT)

#define PspCcpLsb_Private_Protection_Mask_R1_SET_RI_R1_Mask(pspccplsb_private_protection_mask_r1_reg, ri_r1_mask) \
     pspccplsb_private_protection_mask_r1_reg = (pspccplsb_private_protection_mask_r1_reg & ~PspCcpLsb_Private_Protection_Mask_R1_RI_R1_Mask_MASK) | (ri_r1_mask << PspCcpLsb_Private_Protection_Mask_R1_RI_R1_Mask_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccplsb_private_protection_mask_r1_t {
          unsigned int ri_r1_mask                     : PspCcpLsb_Private_Protection_Mask_R1_RI_R1_Mask_SIZE;
          unsigned int                                : 29;
     } pspccplsb_private_protection_mask_r1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccplsb_private_protection_mask_r1_t {
          unsigned int                                : 29;
          unsigned int ri_r1_mask                     : PspCcpLsb_Private_Protection_Mask_R1_RI_R1_Mask_SIZE;
     } pspccplsb_private_protection_mask_r1_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccplsb_private_protection_mask_r1_t f;
} pspccplsb_private_protection_mask_r1_u;


/*
 * PspCcpLsb_Private_Protection_Mask_R2 struct
 */

#define PspCcpLsb_Private_Protection_Mask_R2_REG_SIZE 32
#define PspCcpLsb_Private_Protection_Mask_R2_RI_R2_Mask_SIZE 3

#define PspCcpLsb_Private_Protection_Mask_R2_RI_R2_Mask_SHIFT 0

#define PspCcpLsb_Private_Protection_Mask_R2_RI_R2_Mask_MASK 0x7

#define PspCcpLsb_Private_Protection_Mask_R2_MASK \
     (PspCcpLsb_Private_Protection_Mask_R2_RI_R2_Mask_MASK)

#define PspCcpLsb_Private_Protection_Mask_R2_DEFAULT 0x00000000

#define PspCcpLsb_Private_Protection_Mask_R2_GET_RI_R2_Mask(pspccplsb_private_protection_mask_r2) \
     ((pspccplsb_private_protection_mask_r2 & PspCcpLsb_Private_Protection_Mask_R2_RI_R2_Mask_MASK) >> PspCcpLsb_Private_Protection_Mask_R2_RI_R2_Mask_SHIFT)

#define PspCcpLsb_Private_Protection_Mask_R2_SET_RI_R2_Mask(pspccplsb_private_protection_mask_r2_reg, ri_r2_mask) \
     pspccplsb_private_protection_mask_r2_reg = (pspccplsb_private_protection_mask_r2_reg & ~PspCcpLsb_Private_Protection_Mask_R2_RI_R2_Mask_MASK) | (ri_r2_mask << PspCcpLsb_Private_Protection_Mask_R2_RI_R2_Mask_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccplsb_private_protection_mask_r2_t {
          unsigned int ri_r2_mask                     : PspCcpLsb_Private_Protection_Mask_R2_RI_R2_Mask_SIZE;
          unsigned int                                : 29;
     } pspccplsb_private_protection_mask_r2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccplsb_private_protection_mask_r2_t {
          unsigned int                                : 29;
          unsigned int ri_r2_mask                     : PspCcpLsb_Private_Protection_Mask_R2_RI_R2_Mask_SIZE;
     } pspccplsb_private_protection_mask_r2_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccplsb_private_protection_mask_r2_t f;
} pspccplsb_private_protection_mask_r2_u;


/*
 * PspCcpLsb_Private_Protection_Mask_R3 struct
 */

#define PspCcpLsb_Private_Protection_Mask_R3_REG_SIZE 32
#define PspCcpLsb_Private_Protection_Mask_R3_RI_R3_Mask_SIZE 3

#define PspCcpLsb_Private_Protection_Mask_R3_RI_R3_Mask_SHIFT 0

#define PspCcpLsb_Private_Protection_Mask_R3_RI_R3_Mask_MASK 0x7

#define PspCcpLsb_Private_Protection_Mask_R3_MASK \
     (PspCcpLsb_Private_Protection_Mask_R3_RI_R3_Mask_MASK)

#define PspCcpLsb_Private_Protection_Mask_R3_DEFAULT 0x00000000

#define PspCcpLsb_Private_Protection_Mask_R3_GET_RI_R3_Mask(pspccplsb_private_protection_mask_r3) \
     ((pspccplsb_private_protection_mask_r3 & PspCcpLsb_Private_Protection_Mask_R3_RI_R3_Mask_MASK) >> PspCcpLsb_Private_Protection_Mask_R3_RI_R3_Mask_SHIFT)

#define PspCcpLsb_Private_Protection_Mask_R3_SET_RI_R3_Mask(pspccplsb_private_protection_mask_r3_reg, ri_r3_mask) \
     pspccplsb_private_protection_mask_r3_reg = (pspccplsb_private_protection_mask_r3_reg & ~PspCcpLsb_Private_Protection_Mask_R3_RI_R3_Mask_MASK) | (ri_r3_mask << PspCcpLsb_Private_Protection_Mask_R3_RI_R3_Mask_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccplsb_private_protection_mask_r3_t {
          unsigned int ri_r3_mask                     : PspCcpLsb_Private_Protection_Mask_R3_RI_R3_Mask_SIZE;
          unsigned int                                : 29;
     } pspccplsb_private_protection_mask_r3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccplsb_private_protection_mask_r3_t {
          unsigned int                                : 29;
          unsigned int ri_r3_mask                     : PspCcpLsb_Private_Protection_Mask_R3_RI_R3_Mask_SIZE;
     } pspccplsb_private_protection_mask_r3_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccplsb_private_protection_mask_r3_t f;
} pspccplsb_private_protection_mask_r3_u;


/*
 * PspCcpLsb_Private_Protection_Mask_R4 struct
 */

#define PspCcpLsb_Private_Protection_Mask_R4_REG_SIZE 32
#define PspCcpLsb_Private_Protection_Mask_R4_RI_R4_Mask_SIZE 3

#define PspCcpLsb_Private_Protection_Mask_R4_RI_R4_Mask_SHIFT 0

#define PspCcpLsb_Private_Protection_Mask_R4_RI_R4_Mask_MASK 0x7

#define PspCcpLsb_Private_Protection_Mask_R4_MASK \
     (PspCcpLsb_Private_Protection_Mask_R4_RI_R4_Mask_MASK)

#define PspCcpLsb_Private_Protection_Mask_R4_DEFAULT 0x00000000

#define PspCcpLsb_Private_Protection_Mask_R4_GET_RI_R4_Mask(pspccplsb_private_protection_mask_r4) \
     ((pspccplsb_private_protection_mask_r4 & PspCcpLsb_Private_Protection_Mask_R4_RI_R4_Mask_MASK) >> PspCcpLsb_Private_Protection_Mask_R4_RI_R4_Mask_SHIFT)

#define PspCcpLsb_Private_Protection_Mask_R4_SET_RI_R4_Mask(pspccplsb_private_protection_mask_r4_reg, ri_r4_mask) \
     pspccplsb_private_protection_mask_r4_reg = (pspccplsb_private_protection_mask_r4_reg & ~PspCcpLsb_Private_Protection_Mask_R4_RI_R4_Mask_MASK) | (ri_r4_mask << PspCcpLsb_Private_Protection_Mask_R4_RI_R4_Mask_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccplsb_private_protection_mask_r4_t {
          unsigned int ri_r4_mask                     : PspCcpLsb_Private_Protection_Mask_R4_RI_R4_Mask_SIZE;
          unsigned int                                : 29;
     } pspccplsb_private_protection_mask_r4_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccplsb_private_protection_mask_r4_t {
          unsigned int                                : 29;
          unsigned int ri_r4_mask                     : PspCcpLsb_Private_Protection_Mask_R4_RI_R4_Mask_SIZE;
     } pspccplsb_private_protection_mask_r4_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccplsb_private_protection_mask_r4_t f;
} pspccplsb_private_protection_mask_r4_u;


/*
 * PspCcpLsb_Private_Protection_Mask_R5 struct
 */

#define PspCcpLsb_Private_Protection_Mask_R5_REG_SIZE 32
#define PspCcpLsb_Private_Protection_Mask_R5_RI_R5_Mask_SIZE 3

#define PspCcpLsb_Private_Protection_Mask_R5_RI_R5_Mask_SHIFT 0

#define PspCcpLsb_Private_Protection_Mask_R5_RI_R5_Mask_MASK 0x7

#define PspCcpLsb_Private_Protection_Mask_R5_MASK \
     (PspCcpLsb_Private_Protection_Mask_R5_RI_R5_Mask_MASK)

#define PspCcpLsb_Private_Protection_Mask_R5_DEFAULT 0x00000000

#define PspCcpLsb_Private_Protection_Mask_R5_GET_RI_R5_Mask(pspccplsb_private_protection_mask_r5) \
     ((pspccplsb_private_protection_mask_r5 & PspCcpLsb_Private_Protection_Mask_R5_RI_R5_Mask_MASK) >> PspCcpLsb_Private_Protection_Mask_R5_RI_R5_Mask_SHIFT)

#define PspCcpLsb_Private_Protection_Mask_R5_SET_RI_R5_Mask(pspccplsb_private_protection_mask_r5_reg, ri_r5_mask) \
     pspccplsb_private_protection_mask_r5_reg = (pspccplsb_private_protection_mask_r5_reg & ~PspCcpLsb_Private_Protection_Mask_R5_RI_R5_Mask_MASK) | (ri_r5_mask << PspCcpLsb_Private_Protection_Mask_R5_RI_R5_Mask_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccplsb_private_protection_mask_r5_t {
          unsigned int ri_r5_mask                     : PspCcpLsb_Private_Protection_Mask_R5_RI_R5_Mask_SIZE;
          unsigned int                                : 29;
     } pspccplsb_private_protection_mask_r5_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccplsb_private_protection_mask_r5_t {
          unsigned int                                : 29;
          unsigned int ri_r5_mask                     : PspCcpLsb_Private_Protection_Mask_R5_RI_R5_Mask_SIZE;
     } pspccplsb_private_protection_mask_r5_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccplsb_private_protection_mask_r5_t f;
} pspccplsb_private_protection_mask_r5_u;


/*
 * PspCcpLsb_Private_Protection_Mask_R6 struct
 */

#define PspCcpLsb_Private_Protection_Mask_R6_REG_SIZE 32
#define PspCcpLsb_Private_Protection_Mask_R6_RI_R6_Mask_SIZE 3

#define PspCcpLsb_Private_Protection_Mask_R6_RI_R6_Mask_SHIFT 0

#define PspCcpLsb_Private_Protection_Mask_R6_RI_R6_Mask_MASK 0x7

#define PspCcpLsb_Private_Protection_Mask_R6_MASK \
     (PspCcpLsb_Private_Protection_Mask_R6_RI_R6_Mask_MASK)

#define PspCcpLsb_Private_Protection_Mask_R6_DEFAULT 0x00000000

#define PspCcpLsb_Private_Protection_Mask_R6_GET_RI_R6_Mask(pspccplsb_private_protection_mask_r6) \
     ((pspccplsb_private_protection_mask_r6 & PspCcpLsb_Private_Protection_Mask_R6_RI_R6_Mask_MASK) >> PspCcpLsb_Private_Protection_Mask_R6_RI_R6_Mask_SHIFT)

#define PspCcpLsb_Private_Protection_Mask_R6_SET_RI_R6_Mask(pspccplsb_private_protection_mask_r6_reg, ri_r6_mask) \
     pspccplsb_private_protection_mask_r6_reg = (pspccplsb_private_protection_mask_r6_reg & ~PspCcpLsb_Private_Protection_Mask_R6_RI_R6_Mask_MASK) | (ri_r6_mask << PspCcpLsb_Private_Protection_Mask_R6_RI_R6_Mask_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccplsb_private_protection_mask_r6_t {
          unsigned int ri_r6_mask                     : PspCcpLsb_Private_Protection_Mask_R6_RI_R6_Mask_SIZE;
          unsigned int                                : 29;
     } pspccplsb_private_protection_mask_r6_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccplsb_private_protection_mask_r6_t {
          unsigned int                                : 29;
          unsigned int ri_r6_mask                     : PspCcpLsb_Private_Protection_Mask_R6_RI_R6_Mask_SIZE;
     } pspccplsb_private_protection_mask_r6_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccplsb_private_protection_mask_r6_t f;
} pspccplsb_private_protection_mask_r6_u;


/*
 * PspCcpLsb_Private_Protection_Mask_R7 struct
 */

#define PspCcpLsb_Private_Protection_Mask_R7_REG_SIZE 32
#define PspCcpLsb_Private_Protection_Mask_R7_RI_R7_Mask_SIZE 3

#define PspCcpLsb_Private_Protection_Mask_R7_RI_R7_Mask_SHIFT 0

#define PspCcpLsb_Private_Protection_Mask_R7_RI_R7_Mask_MASK 0x7

#define PspCcpLsb_Private_Protection_Mask_R7_MASK \
     (PspCcpLsb_Private_Protection_Mask_R7_RI_R7_Mask_MASK)

#define PspCcpLsb_Private_Protection_Mask_R7_DEFAULT 0x00000000

#define PspCcpLsb_Private_Protection_Mask_R7_GET_RI_R7_Mask(pspccplsb_private_protection_mask_r7) \
     ((pspccplsb_private_protection_mask_r7 & PspCcpLsb_Private_Protection_Mask_R7_RI_R7_Mask_MASK) >> PspCcpLsb_Private_Protection_Mask_R7_RI_R7_Mask_SHIFT)

#define PspCcpLsb_Private_Protection_Mask_R7_SET_RI_R7_Mask(pspccplsb_private_protection_mask_r7_reg, ri_r7_mask) \
     pspccplsb_private_protection_mask_r7_reg = (pspccplsb_private_protection_mask_r7_reg & ~PspCcpLsb_Private_Protection_Mask_R7_RI_R7_Mask_MASK) | (ri_r7_mask << PspCcpLsb_Private_Protection_Mask_R7_RI_R7_Mask_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccplsb_private_protection_mask_r7_t {
          unsigned int ri_r7_mask                     : PspCcpLsb_Private_Protection_Mask_R7_RI_R7_Mask_SIZE;
          unsigned int                                : 29;
     } pspccplsb_private_protection_mask_r7_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccplsb_private_protection_mask_r7_t {
          unsigned int                                : 29;
          unsigned int ri_r7_mask                     : PspCcpLsb_Private_Protection_Mask_R7_RI_R7_Mask_SIZE;
     } pspccplsb_private_protection_mask_r7_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccplsb_private_protection_mask_r7_t f;
} pspccplsb_private_protection_mask_r7_u;


/*
 * PspCcpMemory_Deep_Sleep_Enable struct
 */

#define PspCcpMemory_Deep_Sleep_Enable_REG_SIZE 32
#define PspCcpMemory_Deep_Sleep_Enable_RI_DS_COUNTER_SIZE 10
#define PspCcpMemory_Deep_Sleep_Enable_RI_DS_ENG_SEL_SIZE 5

#define PspCcpMemory_Deep_Sleep_Enable_RI_DS_COUNTER_SHIFT 0
#define PspCcpMemory_Deep_Sleep_Enable_RI_DS_ENG_SEL_SHIFT 10

#define PspCcpMemory_Deep_Sleep_Enable_RI_DS_COUNTER_MASK 0x3ff
#define PspCcpMemory_Deep_Sleep_Enable_RI_DS_ENG_SEL_MASK 0x7c00

#define PspCcpMemory_Deep_Sleep_Enable_MASK \
     (PspCcpMemory_Deep_Sleep_Enable_RI_DS_COUNTER_MASK | \
      PspCcpMemory_Deep_Sleep_Enable_RI_DS_ENG_SEL_MASK)

#define PspCcpMemory_Deep_Sleep_Enable_DEFAULT 0x00000000

#define PspCcpMemory_Deep_Sleep_Enable_GET_RI_DS_COUNTER(pspccpmemory_deep_sleep_enable) \
     ((pspccpmemory_deep_sleep_enable & PspCcpMemory_Deep_Sleep_Enable_RI_DS_COUNTER_MASK) >> PspCcpMemory_Deep_Sleep_Enable_RI_DS_COUNTER_SHIFT)
#define PspCcpMemory_Deep_Sleep_Enable_GET_RI_DS_ENG_SEL(pspccpmemory_deep_sleep_enable) \
     ((pspccpmemory_deep_sleep_enable & PspCcpMemory_Deep_Sleep_Enable_RI_DS_ENG_SEL_MASK) >> PspCcpMemory_Deep_Sleep_Enable_RI_DS_ENG_SEL_SHIFT)

#define PspCcpMemory_Deep_Sleep_Enable_SET_RI_DS_COUNTER(pspccpmemory_deep_sleep_enable_reg, ri_ds_counter) \
     pspccpmemory_deep_sleep_enable_reg = (pspccpmemory_deep_sleep_enable_reg & ~PspCcpMemory_Deep_Sleep_Enable_RI_DS_COUNTER_MASK) | (ri_ds_counter << PspCcpMemory_Deep_Sleep_Enable_RI_DS_COUNTER_SHIFT)
#define PspCcpMemory_Deep_Sleep_Enable_SET_RI_DS_ENG_SEL(pspccpmemory_deep_sleep_enable_reg, ri_ds_eng_sel) \
     pspccpmemory_deep_sleep_enable_reg = (pspccpmemory_deep_sleep_enable_reg & ~PspCcpMemory_Deep_Sleep_Enable_RI_DS_ENG_SEL_MASK) | (ri_ds_eng_sel << PspCcpMemory_Deep_Sleep_Enable_RI_DS_ENG_SEL_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpmemory_deep_sleep_enable_t {
          unsigned int ri_ds_counter                  : PspCcpMemory_Deep_Sleep_Enable_RI_DS_COUNTER_SIZE;
          unsigned int ri_ds_eng_sel                  : PspCcpMemory_Deep_Sleep_Enable_RI_DS_ENG_SEL_SIZE;
          unsigned int                                : 17;
     } pspccpmemory_deep_sleep_enable_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpmemory_deep_sleep_enable_t {
          unsigned int                                : 17;
          unsigned int ri_ds_eng_sel                  : PspCcpMemory_Deep_Sleep_Enable_RI_DS_ENG_SEL_SIZE;
          unsigned int ri_ds_counter                  : PspCcpMemory_Deep_Sleep_Enable_RI_DS_COUNTER_SIZE;
     } pspccpmemory_deep_sleep_enable_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpmemory_deep_sleep_enable_t f;
} pspccpmemory_deep_sleep_enable_u;


/*
 * PspCcpMemory_Deep_Sleep_Status struct
 */

#define PspCcpMemory_Deep_Sleep_Status_REG_SIZE 32
#define PspCcpMemory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_SIZE 8

#define PspCcpMemory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_SHIFT 0

#define PspCcpMemory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_MASK 0xff

#define PspCcpMemory_Deep_Sleep_Status_MASK \
     (PspCcpMemory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_MASK)

#define PspCcpMemory_Deep_Sleep_Status_DEFAULT 0x000000f9

#define PspCcpMemory_Deep_Sleep_Status_GET_RI_DS_ENG_IS_AWAKE(pspccpmemory_deep_sleep_status) \
     ((pspccpmemory_deep_sleep_status & PspCcpMemory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_MASK) >> PspCcpMemory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_SHIFT)

#define PspCcpMemory_Deep_Sleep_Status_SET_RI_DS_ENG_IS_AWAKE(pspccpmemory_deep_sleep_status_reg, ri_ds_eng_is_awake) \
     pspccpmemory_deep_sleep_status_reg = (pspccpmemory_deep_sleep_status_reg & ~PspCcpMemory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_MASK) | (ri_ds_eng_is_awake << PspCcpMemory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpmemory_deep_sleep_status_t {
          unsigned int ri_ds_eng_is_awake             : PspCcpMemory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_SIZE;
          unsigned int                                : 24;
     } pspccpmemory_deep_sleep_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpmemory_deep_sleep_status_t {
          unsigned int                                : 24;
          unsigned int ri_ds_eng_is_awake             : PspCcpMemory_Deep_Sleep_Status_RI_DS_ENG_IS_AWAKE_SIZE;
     } pspccpmemory_deep_sleep_status_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpmemory_deep_sleep_status_t f;
} pspccpmemory_deep_sleep_status_u;


/*
 * PspCcpVersion struct
 */

#define PspCcpVersion_REG_SIZE         32
#define PspCcpVersion_RI_VersionNum_SIZE 6
#define PspCcpVersion_RI_AES_Present_SIZE 1
#define PspCcpVersion_RI_3DES_Present_SIZE 1
#define PspCcpVersion_RI_SHA_Present_SIZE 1
#define PspCcpVersion_RI_RSA_Present_SIZE 1
#define PspCcpVersion_RI_ECC_Present_SIZE 1
#define PspCcpVersion_RI_ZDE_Present_SIZE 1
#define PspCcpVersion_RI_ZCE_Present_SIZE 1
#define PspCcpVersion_RI_TRNG_Present_SIZE 1
#define PspCcpVersion_RI_ELFC_Present_SIZE 1
#define PspCcpVersion_RI_NumVQM_SIZE   5
#define PspCcpVersion_RI_LSBSize_SIZE  10

#define PspCcpVersion_RI_VersionNum_SHIFT 0
#define PspCcpVersion_RI_AES_Present_SHIFT 6
#define PspCcpVersion_RI_3DES_Present_SHIFT 7
#define PspCcpVersion_RI_SHA_Present_SHIFT 8
#define PspCcpVersion_RI_RSA_Present_SHIFT 9
#define PspCcpVersion_RI_ECC_Present_SHIFT 10
#define PspCcpVersion_RI_ZDE_Present_SHIFT 11
#define PspCcpVersion_RI_ZCE_Present_SHIFT 12
#define PspCcpVersion_RI_TRNG_Present_SHIFT 13
#define PspCcpVersion_RI_ELFC_Present_SHIFT 14
#define PspCcpVersion_RI_NumVQM_SHIFT  15
#define PspCcpVersion_RI_LSBSize_SHIFT 20

#define PspCcpVersion_RI_VersionNum_MASK 0x3f
#define PspCcpVersion_RI_AES_Present_MASK 0x40
#define PspCcpVersion_RI_3DES_Present_MASK 0x80
#define PspCcpVersion_RI_SHA_Present_MASK 0x100
#define PspCcpVersion_RI_RSA_Present_MASK 0x200
#define PspCcpVersion_RI_ECC_Present_MASK 0x400
#define PspCcpVersion_RI_ZDE_Present_MASK 0x800
#define PspCcpVersion_RI_ZCE_Present_MASK 0x1000
#define PspCcpVersion_RI_TRNG_Present_MASK 0x2000
#define PspCcpVersion_RI_ELFC_Present_MASK 0x4000
#define PspCcpVersion_RI_NumVQM_MASK   0xf8000
#define PspCcpVersion_RI_LSBSize_MASK  0x3ff00000

#define PspCcpVersion_MASK \
     (PspCcpVersion_RI_VersionNum_MASK | \
      PspCcpVersion_RI_AES_Present_MASK | \
      PspCcpVersion_RI_3DES_Present_MASK | \
      PspCcpVersion_RI_SHA_Present_MASK | \
      PspCcpVersion_RI_RSA_Present_MASK | \
      PspCcpVersion_RI_ECC_Present_MASK | \
      PspCcpVersion_RI_ZDE_Present_MASK | \
      PspCcpVersion_RI_ZCE_Present_MASK | \
      PspCcpVersion_RI_TRNG_Present_MASK | \
      PspCcpVersion_RI_ELFC_Present_MASK | \
      PspCcpVersion_RI_NumVQM_MASK | \
      PspCcpVersion_RI_LSBSize_MASK)

#define PspCcpVersion_DEFAULT          0x0801ef4d

#define PspCcpVersion_GET_RI_VersionNum(pspccpversion) \
     ((pspccpversion & PspCcpVersion_RI_VersionNum_MASK) >> PspCcpVersion_RI_VersionNum_SHIFT)
#define PspCcpVersion_GET_RI_AES_Present(pspccpversion) \
     ((pspccpversion & PspCcpVersion_RI_AES_Present_MASK) >> PspCcpVersion_RI_AES_Present_SHIFT)
#define PspCcpVersion_GET_RI_3DES_Present(pspccpversion) \
     ((pspccpversion & PspCcpVersion_RI_3DES_Present_MASK) >> PspCcpVersion_RI_3DES_Present_SHIFT)
#define PspCcpVersion_GET_RI_SHA_Present(pspccpversion) \
     ((pspccpversion & PspCcpVersion_RI_SHA_Present_MASK) >> PspCcpVersion_RI_SHA_Present_SHIFT)
#define PspCcpVersion_GET_RI_RSA_Present(pspccpversion) \
     ((pspccpversion & PspCcpVersion_RI_RSA_Present_MASK) >> PspCcpVersion_RI_RSA_Present_SHIFT)
#define PspCcpVersion_GET_RI_ECC_Present(pspccpversion) \
     ((pspccpversion & PspCcpVersion_RI_ECC_Present_MASK) >> PspCcpVersion_RI_ECC_Present_SHIFT)
#define PspCcpVersion_GET_RI_ZDE_Present(pspccpversion) \
     ((pspccpversion & PspCcpVersion_RI_ZDE_Present_MASK) >> PspCcpVersion_RI_ZDE_Present_SHIFT)
#define PspCcpVersion_GET_RI_ZCE_Present(pspccpversion) \
     ((pspccpversion & PspCcpVersion_RI_ZCE_Present_MASK) >> PspCcpVersion_RI_ZCE_Present_SHIFT)
#define PspCcpVersion_GET_RI_TRNG_Present(pspccpversion) \
     ((pspccpversion & PspCcpVersion_RI_TRNG_Present_MASK) >> PspCcpVersion_RI_TRNG_Present_SHIFT)
#define PspCcpVersion_GET_RI_ELFC_Present(pspccpversion) \
     ((pspccpversion & PspCcpVersion_RI_ELFC_Present_MASK) >> PspCcpVersion_RI_ELFC_Present_SHIFT)
#define PspCcpVersion_GET_RI_NumVQM(pspccpversion) \
     ((pspccpversion & PspCcpVersion_RI_NumVQM_MASK) >> PspCcpVersion_RI_NumVQM_SHIFT)
#define PspCcpVersion_GET_RI_LSBSize(pspccpversion) \
     ((pspccpversion & PspCcpVersion_RI_LSBSize_MASK) >> PspCcpVersion_RI_LSBSize_SHIFT)

#define PspCcpVersion_SET_RI_VersionNum(pspccpversion_reg, ri_versionnum) \
     pspccpversion_reg = (pspccpversion_reg & ~PspCcpVersion_RI_VersionNum_MASK) | (ri_versionnum << PspCcpVersion_RI_VersionNum_SHIFT)
#define PspCcpVersion_SET_RI_AES_Present(pspccpversion_reg, ri_aes_present) \
     pspccpversion_reg = (pspccpversion_reg & ~PspCcpVersion_RI_AES_Present_MASK) | (ri_aes_present << PspCcpVersion_RI_AES_Present_SHIFT)
#define PspCcpVersion_SET_RI_3DES_Present(pspccpversion_reg, ri_3des_present) \
     pspccpversion_reg = (pspccpversion_reg & ~PspCcpVersion_RI_3DES_Present_MASK) | (ri_3des_present << PspCcpVersion_RI_3DES_Present_SHIFT)
#define PspCcpVersion_SET_RI_SHA_Present(pspccpversion_reg, ri_sha_present) \
     pspccpversion_reg = (pspccpversion_reg & ~PspCcpVersion_RI_SHA_Present_MASK) | (ri_sha_present << PspCcpVersion_RI_SHA_Present_SHIFT)
#define PspCcpVersion_SET_RI_RSA_Present(pspccpversion_reg, ri_rsa_present) \
     pspccpversion_reg = (pspccpversion_reg & ~PspCcpVersion_RI_RSA_Present_MASK) | (ri_rsa_present << PspCcpVersion_RI_RSA_Present_SHIFT)
#define PspCcpVersion_SET_RI_ECC_Present(pspccpversion_reg, ri_ecc_present) \
     pspccpversion_reg = (pspccpversion_reg & ~PspCcpVersion_RI_ECC_Present_MASK) | (ri_ecc_present << PspCcpVersion_RI_ECC_Present_SHIFT)
#define PspCcpVersion_SET_RI_ZDE_Present(pspccpversion_reg, ri_zde_present) \
     pspccpversion_reg = (pspccpversion_reg & ~PspCcpVersion_RI_ZDE_Present_MASK) | (ri_zde_present << PspCcpVersion_RI_ZDE_Present_SHIFT)
#define PspCcpVersion_SET_RI_ZCE_Present(pspccpversion_reg, ri_zce_present) \
     pspccpversion_reg = (pspccpversion_reg & ~PspCcpVersion_RI_ZCE_Present_MASK) | (ri_zce_present << PspCcpVersion_RI_ZCE_Present_SHIFT)
#define PspCcpVersion_SET_RI_TRNG_Present(pspccpversion_reg, ri_trng_present) \
     pspccpversion_reg = (pspccpversion_reg & ~PspCcpVersion_RI_TRNG_Present_MASK) | (ri_trng_present << PspCcpVersion_RI_TRNG_Present_SHIFT)
#define PspCcpVersion_SET_RI_ELFC_Present(pspccpversion_reg, ri_elfc_present) \
     pspccpversion_reg = (pspccpversion_reg & ~PspCcpVersion_RI_ELFC_Present_MASK) | (ri_elfc_present << PspCcpVersion_RI_ELFC_Present_SHIFT)
#define PspCcpVersion_SET_RI_NumVQM(pspccpversion_reg, ri_numvqm) \
     pspccpversion_reg = (pspccpversion_reg & ~PspCcpVersion_RI_NumVQM_MASK) | (ri_numvqm << PspCcpVersion_RI_NumVQM_SHIFT)
#define PspCcpVersion_SET_RI_LSBSize(pspccpversion_reg, ri_lsbsize) \
     pspccpversion_reg = (pspccpversion_reg & ~PspCcpVersion_RI_LSBSize_MASK) | (ri_lsbsize << PspCcpVersion_RI_LSBSize_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpversion_t {
          unsigned int ri_versionnum                  : PspCcpVersion_RI_VersionNum_SIZE;
          unsigned int ri_aes_present                 : PspCcpVersion_RI_AES_Present_SIZE;
          unsigned int ri_3des_present                : PspCcpVersion_RI_3DES_Present_SIZE;
          unsigned int ri_sha_present                 : PspCcpVersion_RI_SHA_Present_SIZE;
          unsigned int ri_rsa_present                 : PspCcpVersion_RI_RSA_Present_SIZE;
          unsigned int ri_ecc_present                 : PspCcpVersion_RI_ECC_Present_SIZE;
          unsigned int ri_zde_present                 : PspCcpVersion_RI_ZDE_Present_SIZE;
          unsigned int ri_zce_present                 : PspCcpVersion_RI_ZCE_Present_SIZE;
          unsigned int ri_trng_present                : PspCcpVersion_RI_TRNG_Present_SIZE;
          unsigned int ri_elfc_present                : PspCcpVersion_RI_ELFC_Present_SIZE;
          unsigned int ri_numvqm                      : PspCcpVersion_RI_NumVQM_SIZE;
          unsigned int ri_lsbsize                     : PspCcpVersion_RI_LSBSize_SIZE;
          unsigned int                                : 2;
     } pspccpversion_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpversion_t {
          unsigned int                                : 2;
          unsigned int ri_lsbsize                     : PspCcpVersion_RI_LSBSize_SIZE;
          unsigned int ri_numvqm                      : PspCcpVersion_RI_NumVQM_SIZE;
          unsigned int ri_elfc_present                : PspCcpVersion_RI_ELFC_Present_SIZE;
          unsigned int ri_trng_present                : PspCcpVersion_RI_TRNG_Present_SIZE;
          unsigned int ri_zce_present                 : PspCcpVersion_RI_ZCE_Present_SIZE;
          unsigned int ri_zde_present                 : PspCcpVersion_RI_ZDE_Present_SIZE;
          unsigned int ri_ecc_present                 : PspCcpVersion_RI_ECC_Present_SIZE;
          unsigned int ri_rsa_present                 : PspCcpVersion_RI_RSA_Present_SIZE;
          unsigned int ri_sha_present                 : PspCcpVersion_RI_SHA_Present_SIZE;
          unsigned int ri_3des_present                : PspCcpVersion_RI_3DES_Present_SIZE;
          unsigned int ri_aes_present                 : PspCcpVersion_RI_AES_Present_SIZE;
          unsigned int ri_versionnum                  : PspCcpVersion_RI_VersionNum_SIZE;
     } pspccpversion_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpversion_t f;
} pspccpversion_u;


/*
 * PspCcpVqd0_Control struct
 */

#define PspCcpVqd0_Control_REG_SIZE    32
#define PspCcpVqd0_Control_RI_Run_SIZE 1
#define PspCcpVqd0_Control_VQM_Halted_SIZE 1
#define PspCcpVqd0_Control_RI_Mem_Location_SIZE 1
#define PspCcpVqd0_Control_RI_Queue_Size_SIZE 4
#define PspCcpVqd0_Control_RI_VQD_Pointer_Hi_SIZE 20

#define PspCcpVqd0_Control_RI_Run_SHIFT 0
#define PspCcpVqd0_Control_VQM_Halted_SHIFT 1
#define PspCcpVqd0_Control_RI_Mem_Location_SHIFT 2
#define PspCcpVqd0_Control_RI_Queue_Size_SHIFT 3
#define PspCcpVqd0_Control_RI_VQD_Pointer_Hi_SHIFT 12

#define PspCcpVqd0_Control_RI_Run_MASK 0x1
#define PspCcpVqd0_Control_VQM_Halted_MASK 0x2
#define PspCcpVqd0_Control_RI_Mem_Location_MASK 0x4
#define PspCcpVqd0_Control_RI_Queue_Size_MASK 0x78
#define PspCcpVqd0_Control_RI_VQD_Pointer_Hi_MASK 0xfffff000

#define PspCcpVqd0_Control_MASK \
     (PspCcpVqd0_Control_RI_Run_MASK | \
      PspCcpVqd0_Control_VQM_Halted_MASK | \
      PspCcpVqd0_Control_RI_Mem_Location_MASK | \
      PspCcpVqd0_Control_RI_Queue_Size_MASK | \
      PspCcpVqd0_Control_RI_VQD_Pointer_Hi_MASK)

#define PspCcpVqd0_Control_DEFAULT     0x00000002

#define PspCcpVqd0_Control_GET_RI_Run(pspccpvqd0_control) \
     ((pspccpvqd0_control & PspCcpVqd0_Control_RI_Run_MASK) >> PspCcpVqd0_Control_RI_Run_SHIFT)
#define PspCcpVqd0_Control_GET_VQM_Halted(pspccpvqd0_control) \
     ((pspccpvqd0_control & PspCcpVqd0_Control_VQM_Halted_MASK) >> PspCcpVqd0_Control_VQM_Halted_SHIFT)
#define PspCcpVqd0_Control_GET_RI_Mem_Location(pspccpvqd0_control) \
     ((pspccpvqd0_control & PspCcpVqd0_Control_RI_Mem_Location_MASK) >> PspCcpVqd0_Control_RI_Mem_Location_SHIFT)
#define PspCcpVqd0_Control_GET_RI_Queue_Size(pspccpvqd0_control) \
     ((pspccpvqd0_control & PspCcpVqd0_Control_RI_Queue_Size_MASK) >> PspCcpVqd0_Control_RI_Queue_Size_SHIFT)
#define PspCcpVqd0_Control_GET_RI_VQD_Pointer_Hi(pspccpvqd0_control) \
     ((pspccpvqd0_control & PspCcpVqd0_Control_RI_VQD_Pointer_Hi_MASK) >> PspCcpVqd0_Control_RI_VQD_Pointer_Hi_SHIFT)

#define PspCcpVqd0_Control_SET_RI_Run(pspccpvqd0_control_reg, ri_run) \
     pspccpvqd0_control_reg = (pspccpvqd0_control_reg & ~PspCcpVqd0_Control_RI_Run_MASK) | (ri_run << PspCcpVqd0_Control_RI_Run_SHIFT)
#define PspCcpVqd0_Control_SET_VQM_Halted(pspccpvqd0_control_reg, vqm_halted) \
     pspccpvqd0_control_reg = (pspccpvqd0_control_reg & ~PspCcpVqd0_Control_VQM_Halted_MASK) | (vqm_halted << PspCcpVqd0_Control_VQM_Halted_SHIFT)
#define PspCcpVqd0_Control_SET_RI_Mem_Location(pspccpvqd0_control_reg, ri_mem_location) \
     pspccpvqd0_control_reg = (pspccpvqd0_control_reg & ~PspCcpVqd0_Control_RI_Mem_Location_MASK) | (ri_mem_location << PspCcpVqd0_Control_RI_Mem_Location_SHIFT)
#define PspCcpVqd0_Control_SET_RI_Queue_Size(pspccpvqd0_control_reg, ri_queue_size) \
     pspccpvqd0_control_reg = (pspccpvqd0_control_reg & ~PspCcpVqd0_Control_RI_Queue_Size_MASK) | (ri_queue_size << PspCcpVqd0_Control_RI_Queue_Size_SHIFT)
#define PspCcpVqd0_Control_SET_RI_VQD_Pointer_Hi(pspccpvqd0_control_reg, ri_vqd_pointer_hi) \
     pspccpvqd0_control_reg = (pspccpvqd0_control_reg & ~PspCcpVqd0_Control_RI_VQD_Pointer_Hi_MASK) | (ri_vqd_pointer_hi << PspCcpVqd0_Control_RI_VQD_Pointer_Hi_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpvqd0_control_t {
          unsigned int ri_run                         : PspCcpVqd0_Control_RI_Run_SIZE;
          unsigned int vqm_halted                     : PspCcpVqd0_Control_VQM_Halted_SIZE;
          unsigned int ri_mem_location                : PspCcpVqd0_Control_RI_Mem_Location_SIZE;
          unsigned int ri_queue_size                  : PspCcpVqd0_Control_RI_Queue_Size_SIZE;
          unsigned int                                : 5;
          unsigned int ri_vqd_pointer_hi              : PspCcpVqd0_Control_RI_VQD_Pointer_Hi_SIZE;
     } pspccpvqd0_control_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpvqd0_control_t {
          unsigned int ri_vqd_pointer_hi              : PspCcpVqd0_Control_RI_VQD_Pointer_Hi_SIZE;
          unsigned int                                : 5;
          unsigned int ri_queue_size                  : PspCcpVqd0_Control_RI_Queue_Size_SIZE;
          unsigned int ri_mem_location                : PspCcpVqd0_Control_RI_Mem_Location_SIZE;
          unsigned int vqm_halted                     : PspCcpVqd0_Control_VQM_Halted_SIZE;
          unsigned int ri_run                         : PspCcpVqd0_Control_RI_Run_SIZE;
     } pspccpvqd0_control_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpvqd0_control_t f;
} pspccpvqd0_control_u;


/*
 * PspCcpVqd1_Control struct
 */

#define PspCcpVqd1_Control_REG_SIZE    32
#define PspCcpVqd1_Control_RI_Run_SIZE 1
#define PspCcpVqd1_Control_VQM_Halted_SIZE 1
#define PspCcpVqd1_Control_RI_Mem_Location_SIZE 1
#define PspCcpVqd1_Control_RI_Queue_Size_SIZE 4
#define PspCcpVqd1_Control_RI_VQD_Pointer_Hi_SIZE 20

#define PspCcpVqd1_Control_RI_Run_SHIFT 0
#define PspCcpVqd1_Control_VQM_Halted_SHIFT 1
#define PspCcpVqd1_Control_RI_Mem_Location_SHIFT 2
#define PspCcpVqd1_Control_RI_Queue_Size_SHIFT 3
#define PspCcpVqd1_Control_RI_VQD_Pointer_Hi_SHIFT 12

#define PspCcpVqd1_Control_RI_Run_MASK 0x1
#define PspCcpVqd1_Control_VQM_Halted_MASK 0x2
#define PspCcpVqd1_Control_RI_Mem_Location_MASK 0x4
#define PspCcpVqd1_Control_RI_Queue_Size_MASK 0x78
#define PspCcpVqd1_Control_RI_VQD_Pointer_Hi_MASK 0xfffff000

#define PspCcpVqd1_Control_MASK \
     (PspCcpVqd1_Control_RI_Run_MASK | \
      PspCcpVqd1_Control_VQM_Halted_MASK | \
      PspCcpVqd1_Control_RI_Mem_Location_MASK | \
      PspCcpVqd1_Control_RI_Queue_Size_MASK | \
      PspCcpVqd1_Control_RI_VQD_Pointer_Hi_MASK)

#define PspCcpVqd1_Control_DEFAULT     0x00000002

#define PspCcpVqd1_Control_GET_RI_Run(pspccpvqd1_control) \
     ((pspccpvqd1_control & PspCcpVqd1_Control_RI_Run_MASK) >> PspCcpVqd1_Control_RI_Run_SHIFT)
#define PspCcpVqd1_Control_GET_VQM_Halted(pspccpvqd1_control) \
     ((pspccpvqd1_control & PspCcpVqd1_Control_VQM_Halted_MASK) >> PspCcpVqd1_Control_VQM_Halted_SHIFT)
#define PspCcpVqd1_Control_GET_RI_Mem_Location(pspccpvqd1_control) \
     ((pspccpvqd1_control & PspCcpVqd1_Control_RI_Mem_Location_MASK) >> PspCcpVqd1_Control_RI_Mem_Location_SHIFT)
#define PspCcpVqd1_Control_GET_RI_Queue_Size(pspccpvqd1_control) \
     ((pspccpvqd1_control & PspCcpVqd1_Control_RI_Queue_Size_MASK) >> PspCcpVqd1_Control_RI_Queue_Size_SHIFT)
#define PspCcpVqd1_Control_GET_RI_VQD_Pointer_Hi(pspccpvqd1_control) \
     ((pspccpvqd1_control & PspCcpVqd1_Control_RI_VQD_Pointer_Hi_MASK) >> PspCcpVqd1_Control_RI_VQD_Pointer_Hi_SHIFT)

#define PspCcpVqd1_Control_SET_RI_Run(pspccpvqd1_control_reg, ri_run) \
     pspccpvqd1_control_reg = (pspccpvqd1_control_reg & ~PspCcpVqd1_Control_RI_Run_MASK) | (ri_run << PspCcpVqd1_Control_RI_Run_SHIFT)
#define PspCcpVqd1_Control_SET_VQM_Halted(pspccpvqd1_control_reg, vqm_halted) \
     pspccpvqd1_control_reg = (pspccpvqd1_control_reg & ~PspCcpVqd1_Control_VQM_Halted_MASK) | (vqm_halted << PspCcpVqd1_Control_VQM_Halted_SHIFT)
#define PspCcpVqd1_Control_SET_RI_Mem_Location(pspccpvqd1_control_reg, ri_mem_location) \
     pspccpvqd1_control_reg = (pspccpvqd1_control_reg & ~PspCcpVqd1_Control_RI_Mem_Location_MASK) | (ri_mem_location << PspCcpVqd1_Control_RI_Mem_Location_SHIFT)
#define PspCcpVqd1_Control_SET_RI_Queue_Size(pspccpvqd1_control_reg, ri_queue_size) \
     pspccpvqd1_control_reg = (pspccpvqd1_control_reg & ~PspCcpVqd1_Control_RI_Queue_Size_MASK) | (ri_queue_size << PspCcpVqd1_Control_RI_Queue_Size_SHIFT)
#define PspCcpVqd1_Control_SET_RI_VQD_Pointer_Hi(pspccpvqd1_control_reg, ri_vqd_pointer_hi) \
     pspccpvqd1_control_reg = (pspccpvqd1_control_reg & ~PspCcpVqd1_Control_RI_VQD_Pointer_Hi_MASK) | (ri_vqd_pointer_hi << PspCcpVqd1_Control_RI_VQD_Pointer_Hi_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpvqd1_control_t {
          unsigned int ri_run                         : PspCcpVqd1_Control_RI_Run_SIZE;
          unsigned int vqm_halted                     : PspCcpVqd1_Control_VQM_Halted_SIZE;
          unsigned int ri_mem_location                : PspCcpVqd1_Control_RI_Mem_Location_SIZE;
          unsigned int ri_queue_size                  : PspCcpVqd1_Control_RI_Queue_Size_SIZE;
          unsigned int                                : 5;
          unsigned int ri_vqd_pointer_hi              : PspCcpVqd1_Control_RI_VQD_Pointer_Hi_SIZE;
     } pspccpvqd1_control_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpvqd1_control_t {
          unsigned int ri_vqd_pointer_hi              : PspCcpVqd1_Control_RI_VQD_Pointer_Hi_SIZE;
          unsigned int                                : 5;
          unsigned int ri_queue_size                  : PspCcpVqd1_Control_RI_Queue_Size_SIZE;
          unsigned int ri_mem_location                : PspCcpVqd1_Control_RI_Mem_Location_SIZE;
          unsigned int vqm_halted                     : PspCcpVqd1_Control_VQM_Halted_SIZE;
          unsigned int ri_run                         : PspCcpVqd1_Control_RI_Run_SIZE;
     } pspccpvqd1_control_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpvqd1_control_t f;
} pspccpvqd1_control_u;


/*
 * PspCcpVqd2_Control struct
 */

#define PspCcpVqd2_Control_REG_SIZE    32
#define PspCcpVqd2_Control_RI_Run_SIZE 1
#define PspCcpVqd2_Control_VQM_Halted_SIZE 1
#define PspCcpVqd2_Control_RI_Mem_Location_SIZE 1
#define PspCcpVqd2_Control_RI_Queue_Size_SIZE 4
#define PspCcpVqd2_Control_RI_VQD_Pointer_Hi_SIZE 20

#define PspCcpVqd2_Control_RI_Run_SHIFT 0
#define PspCcpVqd2_Control_VQM_Halted_SHIFT 1
#define PspCcpVqd2_Control_RI_Mem_Location_SHIFT 2
#define PspCcpVqd2_Control_RI_Queue_Size_SHIFT 3
#define PspCcpVqd2_Control_RI_VQD_Pointer_Hi_SHIFT 12

#define PspCcpVqd2_Control_RI_Run_MASK 0x1
#define PspCcpVqd2_Control_VQM_Halted_MASK 0x2
#define PspCcpVqd2_Control_RI_Mem_Location_MASK 0x4
#define PspCcpVqd2_Control_RI_Queue_Size_MASK 0x78
#define PspCcpVqd2_Control_RI_VQD_Pointer_Hi_MASK 0xfffff000

#define PspCcpVqd2_Control_MASK \
     (PspCcpVqd2_Control_RI_Run_MASK | \
      PspCcpVqd2_Control_VQM_Halted_MASK | \
      PspCcpVqd2_Control_RI_Mem_Location_MASK | \
      PspCcpVqd2_Control_RI_Queue_Size_MASK | \
      PspCcpVqd2_Control_RI_VQD_Pointer_Hi_MASK)

#define PspCcpVqd2_Control_DEFAULT     0x00000002

#define PspCcpVqd2_Control_GET_RI_Run(pspccpvqd2_control) \
     ((pspccpvqd2_control & PspCcpVqd2_Control_RI_Run_MASK) >> PspCcpVqd2_Control_RI_Run_SHIFT)
#define PspCcpVqd2_Control_GET_VQM_Halted(pspccpvqd2_control) \
     ((pspccpvqd2_control & PspCcpVqd2_Control_VQM_Halted_MASK) >> PspCcpVqd2_Control_VQM_Halted_SHIFT)
#define PspCcpVqd2_Control_GET_RI_Mem_Location(pspccpvqd2_control) \
     ((pspccpvqd2_control & PspCcpVqd2_Control_RI_Mem_Location_MASK) >> PspCcpVqd2_Control_RI_Mem_Location_SHIFT)
#define PspCcpVqd2_Control_GET_RI_Queue_Size(pspccpvqd2_control) \
     ((pspccpvqd2_control & PspCcpVqd2_Control_RI_Queue_Size_MASK) >> PspCcpVqd2_Control_RI_Queue_Size_SHIFT)
#define PspCcpVqd2_Control_GET_RI_VQD_Pointer_Hi(pspccpvqd2_control) \
     ((pspccpvqd2_control & PspCcpVqd2_Control_RI_VQD_Pointer_Hi_MASK) >> PspCcpVqd2_Control_RI_VQD_Pointer_Hi_SHIFT)

#define PspCcpVqd2_Control_SET_RI_Run(pspccpvqd2_control_reg, ri_run) \
     pspccpvqd2_control_reg = (pspccpvqd2_control_reg & ~PspCcpVqd2_Control_RI_Run_MASK) | (ri_run << PspCcpVqd2_Control_RI_Run_SHIFT)
#define PspCcpVqd2_Control_SET_VQM_Halted(pspccpvqd2_control_reg, vqm_halted) \
     pspccpvqd2_control_reg = (pspccpvqd2_control_reg & ~PspCcpVqd2_Control_VQM_Halted_MASK) | (vqm_halted << PspCcpVqd2_Control_VQM_Halted_SHIFT)
#define PspCcpVqd2_Control_SET_RI_Mem_Location(pspccpvqd2_control_reg, ri_mem_location) \
     pspccpvqd2_control_reg = (pspccpvqd2_control_reg & ~PspCcpVqd2_Control_RI_Mem_Location_MASK) | (ri_mem_location << PspCcpVqd2_Control_RI_Mem_Location_SHIFT)
#define PspCcpVqd2_Control_SET_RI_Queue_Size(pspccpvqd2_control_reg, ri_queue_size) \
     pspccpvqd2_control_reg = (pspccpvqd2_control_reg & ~PspCcpVqd2_Control_RI_Queue_Size_MASK) | (ri_queue_size << PspCcpVqd2_Control_RI_Queue_Size_SHIFT)
#define PspCcpVqd2_Control_SET_RI_VQD_Pointer_Hi(pspccpvqd2_control_reg, ri_vqd_pointer_hi) \
     pspccpvqd2_control_reg = (pspccpvqd2_control_reg & ~PspCcpVqd2_Control_RI_VQD_Pointer_Hi_MASK) | (ri_vqd_pointer_hi << PspCcpVqd2_Control_RI_VQD_Pointer_Hi_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpvqd2_control_t {
          unsigned int ri_run                         : PspCcpVqd2_Control_RI_Run_SIZE;
          unsigned int vqm_halted                     : PspCcpVqd2_Control_VQM_Halted_SIZE;
          unsigned int ri_mem_location                : PspCcpVqd2_Control_RI_Mem_Location_SIZE;
          unsigned int ri_queue_size                  : PspCcpVqd2_Control_RI_Queue_Size_SIZE;
          unsigned int                                : 5;
          unsigned int ri_vqd_pointer_hi              : PspCcpVqd2_Control_RI_VQD_Pointer_Hi_SIZE;
     } pspccpvqd2_control_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpvqd2_control_t {
          unsigned int ri_vqd_pointer_hi              : PspCcpVqd2_Control_RI_VQD_Pointer_Hi_SIZE;
          unsigned int                                : 5;
          unsigned int ri_queue_size                  : PspCcpVqd2_Control_RI_Queue_Size_SIZE;
          unsigned int ri_mem_location                : PspCcpVqd2_Control_RI_Mem_Location_SIZE;
          unsigned int vqm_halted                     : PspCcpVqd2_Control_VQM_Halted_SIZE;
          unsigned int ri_run                         : PspCcpVqd2_Control_RI_Run_SIZE;
     } pspccpvqd2_control_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpvqd2_control_t f;
} pspccpvqd2_control_u;


/*
 * PspCcpVqd0_Tail_Lo struct
 */

#define PspCcpVqd0_Tail_Lo_REG_SIZE    32
#define PspCcpVqd0_Tail_Lo_RI_Tail_Pointer_Lo_SIZE 32

#define PspCcpVqd0_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT 0

#define PspCcpVqd0_Tail_Lo_RI_Tail_Pointer_Lo_MASK 0xffffffff

#define PspCcpVqd0_Tail_Lo_MASK \
     (PspCcpVqd0_Tail_Lo_RI_Tail_Pointer_Lo_MASK)

#define PspCcpVqd0_Tail_Lo_DEFAULT     0x00000000

#define PspCcpVqd0_Tail_Lo_GET_RI_Tail_Pointer_Lo(pspccpvqd0_tail_lo) \
     ((pspccpvqd0_tail_lo & PspCcpVqd0_Tail_Lo_RI_Tail_Pointer_Lo_MASK) >> PspCcpVqd0_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT)

#define PspCcpVqd0_Tail_Lo_SET_RI_Tail_Pointer_Lo(pspccpvqd0_tail_lo_reg, ri_tail_pointer_lo) \
     pspccpvqd0_tail_lo_reg = (pspccpvqd0_tail_lo_reg & ~PspCcpVqd0_Tail_Lo_RI_Tail_Pointer_Lo_MASK) | (ri_tail_pointer_lo << PspCcpVqd0_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpvqd0_tail_lo_t {
          unsigned int ri_tail_pointer_lo             : PspCcpVqd0_Tail_Lo_RI_Tail_Pointer_Lo_SIZE;
     } pspccpvqd0_tail_lo_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpvqd0_tail_lo_t {
          unsigned int ri_tail_pointer_lo             : PspCcpVqd0_Tail_Lo_RI_Tail_Pointer_Lo_SIZE;
     } pspccpvqd0_tail_lo_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpvqd0_tail_lo_t f;
} pspccpvqd0_tail_lo_u;


/*
 * PspCcpVqd1_Tail_Lo struct
 */

#define PspCcpVqd1_Tail_Lo_REG_SIZE    32
#define PspCcpVqd1_Tail_Lo_RI_Tail_Pointer_Lo_SIZE 32

#define PspCcpVqd1_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT 0

#define PspCcpVqd1_Tail_Lo_RI_Tail_Pointer_Lo_MASK 0xffffffff

#define PspCcpVqd1_Tail_Lo_MASK \
     (PspCcpVqd1_Tail_Lo_RI_Tail_Pointer_Lo_MASK)

#define PspCcpVqd1_Tail_Lo_DEFAULT     0x00000000

#define PspCcpVqd1_Tail_Lo_GET_RI_Tail_Pointer_Lo(pspccpvqd1_tail_lo) \
     ((pspccpvqd1_tail_lo & PspCcpVqd1_Tail_Lo_RI_Tail_Pointer_Lo_MASK) >> PspCcpVqd1_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT)

#define PspCcpVqd1_Tail_Lo_SET_RI_Tail_Pointer_Lo(pspccpvqd1_tail_lo_reg, ri_tail_pointer_lo) \
     pspccpvqd1_tail_lo_reg = (pspccpvqd1_tail_lo_reg & ~PspCcpVqd1_Tail_Lo_RI_Tail_Pointer_Lo_MASK) | (ri_tail_pointer_lo << PspCcpVqd1_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpvqd1_tail_lo_t {
          unsigned int ri_tail_pointer_lo             : PspCcpVqd1_Tail_Lo_RI_Tail_Pointer_Lo_SIZE;
     } pspccpvqd1_tail_lo_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpvqd1_tail_lo_t {
          unsigned int ri_tail_pointer_lo             : PspCcpVqd1_Tail_Lo_RI_Tail_Pointer_Lo_SIZE;
     } pspccpvqd1_tail_lo_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpvqd1_tail_lo_t f;
} pspccpvqd1_tail_lo_u;


/*
 * PspCcpVqd2_Tail_Lo struct
 */

#define PspCcpVqd2_Tail_Lo_REG_SIZE    32
#define PspCcpVqd2_Tail_Lo_RI_Tail_Pointer_Lo_SIZE 32

#define PspCcpVqd2_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT 0

#define PspCcpVqd2_Tail_Lo_RI_Tail_Pointer_Lo_MASK 0xffffffff

#define PspCcpVqd2_Tail_Lo_MASK \
     (PspCcpVqd2_Tail_Lo_RI_Tail_Pointer_Lo_MASK)

#define PspCcpVqd2_Tail_Lo_DEFAULT     0x00000000

#define PspCcpVqd2_Tail_Lo_GET_RI_Tail_Pointer_Lo(pspccpvqd2_tail_lo) \
     ((pspccpvqd2_tail_lo & PspCcpVqd2_Tail_Lo_RI_Tail_Pointer_Lo_MASK) >> PspCcpVqd2_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT)

#define PspCcpVqd2_Tail_Lo_SET_RI_Tail_Pointer_Lo(pspccpvqd2_tail_lo_reg, ri_tail_pointer_lo) \
     pspccpvqd2_tail_lo_reg = (pspccpvqd2_tail_lo_reg & ~PspCcpVqd2_Tail_Lo_RI_Tail_Pointer_Lo_MASK) | (ri_tail_pointer_lo << PspCcpVqd2_Tail_Lo_RI_Tail_Pointer_Lo_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpvqd2_tail_lo_t {
          unsigned int ri_tail_pointer_lo             : PspCcpVqd2_Tail_Lo_RI_Tail_Pointer_Lo_SIZE;
     } pspccpvqd2_tail_lo_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpvqd2_tail_lo_t {
          unsigned int ri_tail_pointer_lo             : PspCcpVqd2_Tail_Lo_RI_Tail_Pointer_Lo_SIZE;
     } pspccpvqd2_tail_lo_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpvqd2_tail_lo_t f;
} pspccpvqd2_tail_lo_u;


/*
 * PspCcpVqd0_Head_Lo struct
 */

#define PspCcpVqd0_Head_Lo_REG_SIZE    32
#define PspCcpVqd0_Head_Lo_RI_Head_Pointer_Lo_SIZE 32

#define PspCcpVqd0_Head_Lo_RI_Head_Pointer_Lo_SHIFT 0

#define PspCcpVqd0_Head_Lo_RI_Head_Pointer_Lo_MASK 0xffffffff

#define PspCcpVqd0_Head_Lo_MASK \
     (PspCcpVqd0_Head_Lo_RI_Head_Pointer_Lo_MASK)

#define PspCcpVqd0_Head_Lo_DEFAULT     0x00000000

#define PspCcpVqd0_Head_Lo_GET_RI_Head_Pointer_Lo(pspccpvqd0_head_lo) \
     ((pspccpvqd0_head_lo & PspCcpVqd0_Head_Lo_RI_Head_Pointer_Lo_MASK) >> PspCcpVqd0_Head_Lo_RI_Head_Pointer_Lo_SHIFT)

#define PspCcpVqd0_Head_Lo_SET_RI_Head_Pointer_Lo(pspccpvqd0_head_lo_reg, ri_head_pointer_lo) \
     pspccpvqd0_head_lo_reg = (pspccpvqd0_head_lo_reg & ~PspCcpVqd0_Head_Lo_RI_Head_Pointer_Lo_MASK) | (ri_head_pointer_lo << PspCcpVqd0_Head_Lo_RI_Head_Pointer_Lo_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpvqd0_head_lo_t {
          unsigned int ri_head_pointer_lo             : PspCcpVqd0_Head_Lo_RI_Head_Pointer_Lo_SIZE;
     } pspccpvqd0_head_lo_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpvqd0_head_lo_t {
          unsigned int ri_head_pointer_lo             : PspCcpVqd0_Head_Lo_RI_Head_Pointer_Lo_SIZE;
     } pspccpvqd0_head_lo_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpvqd0_head_lo_t f;
} pspccpvqd0_head_lo_u;


/*
 * PspCcpVqd1_Head_Lo struct
 */

#define PspCcpVqd1_Head_Lo_REG_SIZE    32
#define PspCcpVqd1_Head_Lo_RI_Head_Pointer_Lo_SIZE 32

#define PspCcpVqd1_Head_Lo_RI_Head_Pointer_Lo_SHIFT 0

#define PspCcpVqd1_Head_Lo_RI_Head_Pointer_Lo_MASK 0xffffffff

#define PspCcpVqd1_Head_Lo_MASK \
     (PspCcpVqd1_Head_Lo_RI_Head_Pointer_Lo_MASK)

#define PspCcpVqd1_Head_Lo_DEFAULT     0x00000000

#define PspCcpVqd1_Head_Lo_GET_RI_Head_Pointer_Lo(pspccpvqd1_head_lo) \
     ((pspccpvqd1_head_lo & PspCcpVqd1_Head_Lo_RI_Head_Pointer_Lo_MASK) >> PspCcpVqd1_Head_Lo_RI_Head_Pointer_Lo_SHIFT)

#define PspCcpVqd1_Head_Lo_SET_RI_Head_Pointer_Lo(pspccpvqd1_head_lo_reg, ri_head_pointer_lo) \
     pspccpvqd1_head_lo_reg = (pspccpvqd1_head_lo_reg & ~PspCcpVqd1_Head_Lo_RI_Head_Pointer_Lo_MASK) | (ri_head_pointer_lo << PspCcpVqd1_Head_Lo_RI_Head_Pointer_Lo_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpvqd1_head_lo_t {
          unsigned int ri_head_pointer_lo             : PspCcpVqd1_Head_Lo_RI_Head_Pointer_Lo_SIZE;
     } pspccpvqd1_head_lo_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpvqd1_head_lo_t {
          unsigned int ri_head_pointer_lo             : PspCcpVqd1_Head_Lo_RI_Head_Pointer_Lo_SIZE;
     } pspccpvqd1_head_lo_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpvqd1_head_lo_t f;
} pspccpvqd1_head_lo_u;


/*
 * PspCcpVqd2_Head_Lo struct
 */

#define PspCcpVqd2_Head_Lo_REG_SIZE    32
#define PspCcpVqd2_Head_Lo_RI_Head_Pointer_Lo_SIZE 32

#define PspCcpVqd2_Head_Lo_RI_Head_Pointer_Lo_SHIFT 0

#define PspCcpVqd2_Head_Lo_RI_Head_Pointer_Lo_MASK 0xffffffff

#define PspCcpVqd2_Head_Lo_MASK \
     (PspCcpVqd2_Head_Lo_RI_Head_Pointer_Lo_MASK)

#define PspCcpVqd2_Head_Lo_DEFAULT     0x00000000

#define PspCcpVqd2_Head_Lo_GET_RI_Head_Pointer_Lo(pspccpvqd2_head_lo) \
     ((pspccpvqd2_head_lo & PspCcpVqd2_Head_Lo_RI_Head_Pointer_Lo_MASK) >> PspCcpVqd2_Head_Lo_RI_Head_Pointer_Lo_SHIFT)

#define PspCcpVqd2_Head_Lo_SET_RI_Head_Pointer_Lo(pspccpvqd2_head_lo_reg, ri_head_pointer_lo) \
     pspccpvqd2_head_lo_reg = (pspccpvqd2_head_lo_reg & ~PspCcpVqd2_Head_Lo_RI_Head_Pointer_Lo_MASK) | (ri_head_pointer_lo << PspCcpVqd2_Head_Lo_RI_Head_Pointer_Lo_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpvqd2_head_lo_t {
          unsigned int ri_head_pointer_lo             : PspCcpVqd2_Head_Lo_RI_Head_Pointer_Lo_SIZE;
     } pspccpvqd2_head_lo_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpvqd2_head_lo_t {
          unsigned int ri_head_pointer_lo             : PspCcpVqd2_Head_Lo_RI_Head_Pointer_Lo_SIZE;
     } pspccpvqd2_head_lo_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpvqd2_head_lo_t f;
} pspccpvqd2_head_lo_u;


/*
 * PspCcpCmd_Interrupt_Enable_Q0 struct
 */

#define PspCcpCmd_Interrupt_Enable_Q0_REG_SIZE 32
#define PspCcpCmd_Interrupt_Enable_Q0_RI_CompInt_Enable_SIZE 1
#define PspCcpCmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_SIZE 1
#define PspCcpCmd_Interrupt_Enable_Q0_RI_QSI_Enable_SIZE 1
#define PspCcpCmd_Interrupt_Enable_Q0_RI_QEI_Enable_SIZE 1

#define PspCcpCmd_Interrupt_Enable_Q0_RI_CompInt_Enable_SHIFT 0
#define PspCcpCmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_SHIFT 1
#define PspCcpCmd_Interrupt_Enable_Q0_RI_QSI_Enable_SHIFT 2
#define PspCcpCmd_Interrupt_Enable_Q0_RI_QEI_Enable_SHIFT 3

#define PspCcpCmd_Interrupt_Enable_Q0_RI_CompInt_Enable_MASK 0x1
#define PspCcpCmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_MASK 0x2
#define PspCcpCmd_Interrupt_Enable_Q0_RI_QSI_Enable_MASK 0x4
#define PspCcpCmd_Interrupt_Enable_Q0_RI_QEI_Enable_MASK 0x8

#define PspCcpCmd_Interrupt_Enable_Q0_MASK \
     (PspCcpCmd_Interrupt_Enable_Q0_RI_CompInt_Enable_MASK | \
      PspCcpCmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_MASK | \
      PspCcpCmd_Interrupt_Enable_Q0_RI_QSI_Enable_MASK | \
      PspCcpCmd_Interrupt_Enable_Q0_RI_QEI_Enable_MASK)

#define PspCcpCmd_Interrupt_Enable_Q0_DEFAULT 0x00000000

#define PspCcpCmd_Interrupt_Enable_Q0_GET_RI_CompInt_Enable(pspccpcmd_interrupt_enable_q0) \
     ((pspccpcmd_interrupt_enable_q0 & PspCcpCmd_Interrupt_Enable_Q0_RI_CompInt_Enable_MASK) >> PspCcpCmd_Interrupt_Enable_Q0_RI_CompInt_Enable_SHIFT)
#define PspCcpCmd_Interrupt_Enable_Q0_GET_RI_ErrInt_Enable(pspccpcmd_interrupt_enable_q0) \
     ((pspccpcmd_interrupt_enable_q0 & PspCcpCmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_MASK) >> PspCcpCmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_SHIFT)
#define PspCcpCmd_Interrupt_Enable_Q0_GET_RI_QSI_Enable(pspccpcmd_interrupt_enable_q0) \
     ((pspccpcmd_interrupt_enable_q0 & PspCcpCmd_Interrupt_Enable_Q0_RI_QSI_Enable_MASK) >> PspCcpCmd_Interrupt_Enable_Q0_RI_QSI_Enable_SHIFT)
#define PspCcpCmd_Interrupt_Enable_Q0_GET_RI_QEI_Enable(pspccpcmd_interrupt_enable_q0) \
     ((pspccpcmd_interrupt_enable_q0 & PspCcpCmd_Interrupt_Enable_Q0_RI_QEI_Enable_MASK) >> PspCcpCmd_Interrupt_Enable_Q0_RI_QEI_Enable_SHIFT)

#define PspCcpCmd_Interrupt_Enable_Q0_SET_RI_CompInt_Enable(pspccpcmd_interrupt_enable_q0_reg, ri_compint_enable) \
     pspccpcmd_interrupt_enable_q0_reg = (pspccpcmd_interrupt_enable_q0_reg & ~PspCcpCmd_Interrupt_Enable_Q0_RI_CompInt_Enable_MASK) | (ri_compint_enable << PspCcpCmd_Interrupt_Enable_Q0_RI_CompInt_Enable_SHIFT)
#define PspCcpCmd_Interrupt_Enable_Q0_SET_RI_ErrInt_Enable(pspccpcmd_interrupt_enable_q0_reg, ri_errint_enable) \
     pspccpcmd_interrupt_enable_q0_reg = (pspccpcmd_interrupt_enable_q0_reg & ~PspCcpCmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_MASK) | (ri_errint_enable << PspCcpCmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_SHIFT)
#define PspCcpCmd_Interrupt_Enable_Q0_SET_RI_QSI_Enable(pspccpcmd_interrupt_enable_q0_reg, ri_qsi_enable) \
     pspccpcmd_interrupt_enable_q0_reg = (pspccpcmd_interrupt_enable_q0_reg & ~PspCcpCmd_Interrupt_Enable_Q0_RI_QSI_Enable_MASK) | (ri_qsi_enable << PspCcpCmd_Interrupt_Enable_Q0_RI_QSI_Enable_SHIFT)
#define PspCcpCmd_Interrupt_Enable_Q0_SET_RI_QEI_Enable(pspccpcmd_interrupt_enable_q0_reg, ri_qei_enable) \
     pspccpcmd_interrupt_enable_q0_reg = (pspccpcmd_interrupt_enable_q0_reg & ~PspCcpCmd_Interrupt_Enable_Q0_RI_QEI_Enable_MASK) | (ri_qei_enable << PspCcpCmd_Interrupt_Enable_Q0_RI_QEI_Enable_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_interrupt_enable_q0_t {
          unsigned int ri_compint_enable              : PspCcpCmd_Interrupt_Enable_Q0_RI_CompInt_Enable_SIZE;
          unsigned int ri_errint_enable               : PspCcpCmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_SIZE;
          unsigned int ri_qsi_enable                  : PspCcpCmd_Interrupt_Enable_Q0_RI_QSI_Enable_SIZE;
          unsigned int ri_qei_enable                  : PspCcpCmd_Interrupt_Enable_Q0_RI_QEI_Enable_SIZE;
          unsigned int                                : 28;
     } pspccpcmd_interrupt_enable_q0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_interrupt_enable_q0_t {
          unsigned int                                : 28;
          unsigned int ri_qei_enable                  : PspCcpCmd_Interrupt_Enable_Q0_RI_QEI_Enable_SIZE;
          unsigned int ri_qsi_enable                  : PspCcpCmd_Interrupt_Enable_Q0_RI_QSI_Enable_SIZE;
          unsigned int ri_errint_enable               : PspCcpCmd_Interrupt_Enable_Q0_RI_ErrInt_Enable_SIZE;
          unsigned int ri_compint_enable              : PspCcpCmd_Interrupt_Enable_Q0_RI_CompInt_Enable_SIZE;
     } pspccpcmd_interrupt_enable_q0_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_interrupt_enable_q0_t f;
} pspccpcmd_interrupt_enable_q0_u;


/*
 * PspCcpCmd_Interrupt_Enable_Q1 struct
 */

#define PspCcpCmd_Interrupt_Enable_Q1_REG_SIZE 32
#define PspCcpCmd_Interrupt_Enable_Q1_RI_CompInt_Enable_SIZE 1
#define PspCcpCmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_SIZE 1
#define PspCcpCmd_Interrupt_Enable_Q1_RI_QSI_Enable_SIZE 1
#define PspCcpCmd_Interrupt_Enable_Q1_RI_QEI_Enable_SIZE 1

#define PspCcpCmd_Interrupt_Enable_Q1_RI_CompInt_Enable_SHIFT 0
#define PspCcpCmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_SHIFT 1
#define PspCcpCmd_Interrupt_Enable_Q1_RI_QSI_Enable_SHIFT 2
#define PspCcpCmd_Interrupt_Enable_Q1_RI_QEI_Enable_SHIFT 3

#define PspCcpCmd_Interrupt_Enable_Q1_RI_CompInt_Enable_MASK 0x1
#define PspCcpCmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_MASK 0x2
#define PspCcpCmd_Interrupt_Enable_Q1_RI_QSI_Enable_MASK 0x4
#define PspCcpCmd_Interrupt_Enable_Q1_RI_QEI_Enable_MASK 0x8

#define PspCcpCmd_Interrupt_Enable_Q1_MASK \
     (PspCcpCmd_Interrupt_Enable_Q1_RI_CompInt_Enable_MASK | \
      PspCcpCmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_MASK | \
      PspCcpCmd_Interrupt_Enable_Q1_RI_QSI_Enable_MASK | \
      PspCcpCmd_Interrupt_Enable_Q1_RI_QEI_Enable_MASK)

#define PspCcpCmd_Interrupt_Enable_Q1_DEFAULT 0x00000000

#define PspCcpCmd_Interrupt_Enable_Q1_GET_RI_CompInt_Enable(pspccpcmd_interrupt_enable_q1) \
     ((pspccpcmd_interrupt_enable_q1 & PspCcpCmd_Interrupt_Enable_Q1_RI_CompInt_Enable_MASK) >> PspCcpCmd_Interrupt_Enable_Q1_RI_CompInt_Enable_SHIFT)
#define PspCcpCmd_Interrupt_Enable_Q1_GET_RI_ErrInt_Enable(pspccpcmd_interrupt_enable_q1) \
     ((pspccpcmd_interrupt_enable_q1 & PspCcpCmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_MASK) >> PspCcpCmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_SHIFT)
#define PspCcpCmd_Interrupt_Enable_Q1_GET_RI_QSI_Enable(pspccpcmd_interrupt_enable_q1) \
     ((pspccpcmd_interrupt_enable_q1 & PspCcpCmd_Interrupt_Enable_Q1_RI_QSI_Enable_MASK) >> PspCcpCmd_Interrupt_Enable_Q1_RI_QSI_Enable_SHIFT)
#define PspCcpCmd_Interrupt_Enable_Q1_GET_RI_QEI_Enable(pspccpcmd_interrupt_enable_q1) \
     ((pspccpcmd_interrupt_enable_q1 & PspCcpCmd_Interrupt_Enable_Q1_RI_QEI_Enable_MASK) >> PspCcpCmd_Interrupt_Enable_Q1_RI_QEI_Enable_SHIFT)

#define PspCcpCmd_Interrupt_Enable_Q1_SET_RI_CompInt_Enable(pspccpcmd_interrupt_enable_q1_reg, ri_compint_enable) \
     pspccpcmd_interrupt_enable_q1_reg = (pspccpcmd_interrupt_enable_q1_reg & ~PspCcpCmd_Interrupt_Enable_Q1_RI_CompInt_Enable_MASK) | (ri_compint_enable << PspCcpCmd_Interrupt_Enable_Q1_RI_CompInt_Enable_SHIFT)
#define PspCcpCmd_Interrupt_Enable_Q1_SET_RI_ErrInt_Enable(pspccpcmd_interrupt_enable_q1_reg, ri_errint_enable) \
     pspccpcmd_interrupt_enable_q1_reg = (pspccpcmd_interrupt_enable_q1_reg & ~PspCcpCmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_MASK) | (ri_errint_enable << PspCcpCmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_SHIFT)
#define PspCcpCmd_Interrupt_Enable_Q1_SET_RI_QSI_Enable(pspccpcmd_interrupt_enable_q1_reg, ri_qsi_enable) \
     pspccpcmd_interrupt_enable_q1_reg = (pspccpcmd_interrupt_enable_q1_reg & ~PspCcpCmd_Interrupt_Enable_Q1_RI_QSI_Enable_MASK) | (ri_qsi_enable << PspCcpCmd_Interrupt_Enable_Q1_RI_QSI_Enable_SHIFT)
#define PspCcpCmd_Interrupt_Enable_Q1_SET_RI_QEI_Enable(pspccpcmd_interrupt_enable_q1_reg, ri_qei_enable) \
     pspccpcmd_interrupt_enable_q1_reg = (pspccpcmd_interrupt_enable_q1_reg & ~PspCcpCmd_Interrupt_Enable_Q1_RI_QEI_Enable_MASK) | (ri_qei_enable << PspCcpCmd_Interrupt_Enable_Q1_RI_QEI_Enable_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_interrupt_enable_q1_t {
          unsigned int ri_compint_enable              : PspCcpCmd_Interrupt_Enable_Q1_RI_CompInt_Enable_SIZE;
          unsigned int ri_errint_enable               : PspCcpCmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_SIZE;
          unsigned int ri_qsi_enable                  : PspCcpCmd_Interrupt_Enable_Q1_RI_QSI_Enable_SIZE;
          unsigned int ri_qei_enable                  : PspCcpCmd_Interrupt_Enable_Q1_RI_QEI_Enable_SIZE;
          unsigned int                                : 28;
     } pspccpcmd_interrupt_enable_q1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_interrupt_enable_q1_t {
          unsigned int                                : 28;
          unsigned int ri_qei_enable                  : PspCcpCmd_Interrupt_Enable_Q1_RI_QEI_Enable_SIZE;
          unsigned int ri_qsi_enable                  : PspCcpCmd_Interrupt_Enable_Q1_RI_QSI_Enable_SIZE;
          unsigned int ri_errint_enable               : PspCcpCmd_Interrupt_Enable_Q1_RI_ErrInt_Enable_SIZE;
          unsigned int ri_compint_enable              : PspCcpCmd_Interrupt_Enable_Q1_RI_CompInt_Enable_SIZE;
     } pspccpcmd_interrupt_enable_q1_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_interrupt_enable_q1_t f;
} pspccpcmd_interrupt_enable_q1_u;


/*
 * PspCcpCmd_Interrupt_Enable_Q2 struct
 */

#define PspCcpCmd_Interrupt_Enable_Q2_REG_SIZE 32
#define PspCcpCmd_Interrupt_Enable_Q2_RI_CompInt_Enable_SIZE 1
#define PspCcpCmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_SIZE 1
#define PspCcpCmd_Interrupt_Enable_Q2_RI_QSI_Enable_SIZE 1
#define PspCcpCmd_Interrupt_Enable_Q2_RI_QEI_Enable_SIZE 1

#define PspCcpCmd_Interrupt_Enable_Q2_RI_CompInt_Enable_SHIFT 0
#define PspCcpCmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_SHIFT 1
#define PspCcpCmd_Interrupt_Enable_Q2_RI_QSI_Enable_SHIFT 2
#define PspCcpCmd_Interrupt_Enable_Q2_RI_QEI_Enable_SHIFT 3

#define PspCcpCmd_Interrupt_Enable_Q2_RI_CompInt_Enable_MASK 0x1
#define PspCcpCmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_MASK 0x2
#define PspCcpCmd_Interrupt_Enable_Q2_RI_QSI_Enable_MASK 0x4
#define PspCcpCmd_Interrupt_Enable_Q2_RI_QEI_Enable_MASK 0x8

#define PspCcpCmd_Interrupt_Enable_Q2_MASK \
     (PspCcpCmd_Interrupt_Enable_Q2_RI_CompInt_Enable_MASK | \
      PspCcpCmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_MASK | \
      PspCcpCmd_Interrupt_Enable_Q2_RI_QSI_Enable_MASK | \
      PspCcpCmd_Interrupt_Enable_Q2_RI_QEI_Enable_MASK)

#define PspCcpCmd_Interrupt_Enable_Q2_DEFAULT 0x00000000

#define PspCcpCmd_Interrupt_Enable_Q2_GET_RI_CompInt_Enable(pspccpcmd_interrupt_enable_q2) \
     ((pspccpcmd_interrupt_enable_q2 & PspCcpCmd_Interrupt_Enable_Q2_RI_CompInt_Enable_MASK) >> PspCcpCmd_Interrupt_Enable_Q2_RI_CompInt_Enable_SHIFT)
#define PspCcpCmd_Interrupt_Enable_Q2_GET_RI_ErrInt_Enable(pspccpcmd_interrupt_enable_q2) \
     ((pspccpcmd_interrupt_enable_q2 & PspCcpCmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_MASK) >> PspCcpCmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_SHIFT)
#define PspCcpCmd_Interrupt_Enable_Q2_GET_RI_QSI_Enable(pspccpcmd_interrupt_enable_q2) \
     ((pspccpcmd_interrupt_enable_q2 & PspCcpCmd_Interrupt_Enable_Q2_RI_QSI_Enable_MASK) >> PspCcpCmd_Interrupt_Enable_Q2_RI_QSI_Enable_SHIFT)
#define PspCcpCmd_Interrupt_Enable_Q2_GET_RI_QEI_Enable(pspccpcmd_interrupt_enable_q2) \
     ((pspccpcmd_interrupt_enable_q2 & PspCcpCmd_Interrupt_Enable_Q2_RI_QEI_Enable_MASK) >> PspCcpCmd_Interrupt_Enable_Q2_RI_QEI_Enable_SHIFT)

#define PspCcpCmd_Interrupt_Enable_Q2_SET_RI_CompInt_Enable(pspccpcmd_interrupt_enable_q2_reg, ri_compint_enable) \
     pspccpcmd_interrupt_enable_q2_reg = (pspccpcmd_interrupt_enable_q2_reg & ~PspCcpCmd_Interrupt_Enable_Q2_RI_CompInt_Enable_MASK) | (ri_compint_enable << PspCcpCmd_Interrupt_Enable_Q2_RI_CompInt_Enable_SHIFT)
#define PspCcpCmd_Interrupt_Enable_Q2_SET_RI_ErrInt_Enable(pspccpcmd_interrupt_enable_q2_reg, ri_errint_enable) \
     pspccpcmd_interrupt_enable_q2_reg = (pspccpcmd_interrupt_enable_q2_reg & ~PspCcpCmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_MASK) | (ri_errint_enable << PspCcpCmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_SHIFT)
#define PspCcpCmd_Interrupt_Enable_Q2_SET_RI_QSI_Enable(pspccpcmd_interrupt_enable_q2_reg, ri_qsi_enable) \
     pspccpcmd_interrupt_enable_q2_reg = (pspccpcmd_interrupt_enable_q2_reg & ~PspCcpCmd_Interrupt_Enable_Q2_RI_QSI_Enable_MASK) | (ri_qsi_enable << PspCcpCmd_Interrupt_Enable_Q2_RI_QSI_Enable_SHIFT)
#define PspCcpCmd_Interrupt_Enable_Q2_SET_RI_QEI_Enable(pspccpcmd_interrupt_enable_q2_reg, ri_qei_enable) \
     pspccpcmd_interrupt_enable_q2_reg = (pspccpcmd_interrupt_enable_q2_reg & ~PspCcpCmd_Interrupt_Enable_Q2_RI_QEI_Enable_MASK) | (ri_qei_enable << PspCcpCmd_Interrupt_Enable_Q2_RI_QEI_Enable_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_interrupt_enable_q2_t {
          unsigned int ri_compint_enable              : PspCcpCmd_Interrupt_Enable_Q2_RI_CompInt_Enable_SIZE;
          unsigned int ri_errint_enable               : PspCcpCmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_SIZE;
          unsigned int ri_qsi_enable                  : PspCcpCmd_Interrupt_Enable_Q2_RI_QSI_Enable_SIZE;
          unsigned int ri_qei_enable                  : PspCcpCmd_Interrupt_Enable_Q2_RI_QEI_Enable_SIZE;
          unsigned int                                : 28;
     } pspccpcmd_interrupt_enable_q2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_interrupt_enable_q2_t {
          unsigned int                                : 28;
          unsigned int ri_qei_enable                  : PspCcpCmd_Interrupt_Enable_Q2_RI_QEI_Enable_SIZE;
          unsigned int ri_qsi_enable                  : PspCcpCmd_Interrupt_Enable_Q2_RI_QSI_Enable_SIZE;
          unsigned int ri_errint_enable               : PspCcpCmd_Interrupt_Enable_Q2_RI_ErrInt_Enable_SIZE;
          unsigned int ri_compint_enable              : PspCcpCmd_Interrupt_Enable_Q2_RI_CompInt_Enable_SIZE;
     } pspccpcmd_interrupt_enable_q2_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_interrupt_enable_q2_t f;
} pspccpcmd_interrupt_enable_q2_u;


/*
 * PspCcpCmd_Interrupt_Status_Q0 struct
 */

#define PspCcpCmd_Interrupt_Status_Q0_REG_SIZE 32
#define PspCcpCmd_Interrupt_Status_Q0_RI_CompInt_Valid_SIZE 1
#define PspCcpCmd_Interrupt_Status_Q0_RI_ErrInt_Valid_SIZE 1
#define PspCcpCmd_Interrupt_Status_Q0_RI_QSI_Valid_SIZE 1
#define PspCcpCmd_Interrupt_Status_Q0_RI_QEI_Valid_SIZE 1

#define PspCcpCmd_Interrupt_Status_Q0_RI_CompInt_Valid_SHIFT 0
#define PspCcpCmd_Interrupt_Status_Q0_RI_ErrInt_Valid_SHIFT 1
#define PspCcpCmd_Interrupt_Status_Q0_RI_QSI_Valid_SHIFT 2
#define PspCcpCmd_Interrupt_Status_Q0_RI_QEI_Valid_SHIFT 3

#define PspCcpCmd_Interrupt_Status_Q0_RI_CompInt_Valid_MASK 0x1
#define PspCcpCmd_Interrupt_Status_Q0_RI_ErrInt_Valid_MASK 0x2
#define PspCcpCmd_Interrupt_Status_Q0_RI_QSI_Valid_MASK 0x4
#define PspCcpCmd_Interrupt_Status_Q0_RI_QEI_Valid_MASK 0x8

#define PspCcpCmd_Interrupt_Status_Q0_MASK \
     (PspCcpCmd_Interrupt_Status_Q0_RI_CompInt_Valid_MASK | \
      PspCcpCmd_Interrupt_Status_Q0_RI_ErrInt_Valid_MASK | \
      PspCcpCmd_Interrupt_Status_Q0_RI_QSI_Valid_MASK | \
      PspCcpCmd_Interrupt_Status_Q0_RI_QEI_Valid_MASK)

#define PspCcpCmd_Interrupt_Status_Q0_DEFAULT 0x00000000

#define PspCcpCmd_Interrupt_Status_Q0_GET_RI_CompInt_Valid(pspccpcmd_interrupt_status_q0) \
     ((pspccpcmd_interrupt_status_q0 & PspCcpCmd_Interrupt_Status_Q0_RI_CompInt_Valid_MASK) >> PspCcpCmd_Interrupt_Status_Q0_RI_CompInt_Valid_SHIFT)
#define PspCcpCmd_Interrupt_Status_Q0_GET_RI_ErrInt_Valid(pspccpcmd_interrupt_status_q0) \
     ((pspccpcmd_interrupt_status_q0 & PspCcpCmd_Interrupt_Status_Q0_RI_ErrInt_Valid_MASK) >> PspCcpCmd_Interrupt_Status_Q0_RI_ErrInt_Valid_SHIFT)
#define PspCcpCmd_Interrupt_Status_Q0_GET_RI_QSI_Valid(pspccpcmd_interrupt_status_q0) \
     ((pspccpcmd_interrupt_status_q0 & PspCcpCmd_Interrupt_Status_Q0_RI_QSI_Valid_MASK) >> PspCcpCmd_Interrupt_Status_Q0_RI_QSI_Valid_SHIFT)
#define PspCcpCmd_Interrupt_Status_Q0_GET_RI_QEI_Valid(pspccpcmd_interrupt_status_q0) \
     ((pspccpcmd_interrupt_status_q0 & PspCcpCmd_Interrupt_Status_Q0_RI_QEI_Valid_MASK) >> PspCcpCmd_Interrupt_Status_Q0_RI_QEI_Valid_SHIFT)

#define PspCcpCmd_Interrupt_Status_Q0_SET_RI_CompInt_Valid(pspccpcmd_interrupt_status_q0_reg, ri_compint_valid) \
     pspccpcmd_interrupt_status_q0_reg = (pspccpcmd_interrupt_status_q0_reg & ~PspCcpCmd_Interrupt_Status_Q0_RI_CompInt_Valid_MASK) | (ri_compint_valid << PspCcpCmd_Interrupt_Status_Q0_RI_CompInt_Valid_SHIFT)
#define PspCcpCmd_Interrupt_Status_Q0_SET_RI_ErrInt_Valid(pspccpcmd_interrupt_status_q0_reg, ri_errint_valid) \
     pspccpcmd_interrupt_status_q0_reg = (pspccpcmd_interrupt_status_q0_reg & ~PspCcpCmd_Interrupt_Status_Q0_RI_ErrInt_Valid_MASK) | (ri_errint_valid << PspCcpCmd_Interrupt_Status_Q0_RI_ErrInt_Valid_SHIFT)
#define PspCcpCmd_Interrupt_Status_Q0_SET_RI_QSI_Valid(pspccpcmd_interrupt_status_q0_reg, ri_qsi_valid) \
     pspccpcmd_interrupt_status_q0_reg = (pspccpcmd_interrupt_status_q0_reg & ~PspCcpCmd_Interrupt_Status_Q0_RI_QSI_Valid_MASK) | (ri_qsi_valid << PspCcpCmd_Interrupt_Status_Q0_RI_QSI_Valid_SHIFT)
#define PspCcpCmd_Interrupt_Status_Q0_SET_RI_QEI_Valid(pspccpcmd_interrupt_status_q0_reg, ri_qei_valid) \
     pspccpcmd_interrupt_status_q0_reg = (pspccpcmd_interrupt_status_q0_reg & ~PspCcpCmd_Interrupt_Status_Q0_RI_QEI_Valid_MASK) | (ri_qei_valid << PspCcpCmd_Interrupt_Status_Q0_RI_QEI_Valid_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_interrupt_status_q0_t {
          unsigned int ri_compint_valid               : PspCcpCmd_Interrupt_Status_Q0_RI_CompInt_Valid_SIZE;
          unsigned int ri_errint_valid                : PspCcpCmd_Interrupt_Status_Q0_RI_ErrInt_Valid_SIZE;
          unsigned int ri_qsi_valid                   : PspCcpCmd_Interrupt_Status_Q0_RI_QSI_Valid_SIZE;
          unsigned int ri_qei_valid                   : PspCcpCmd_Interrupt_Status_Q0_RI_QEI_Valid_SIZE;
          unsigned int                                : 28;
     } pspccpcmd_interrupt_status_q0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_interrupt_status_q0_t {
          unsigned int                                : 28;
          unsigned int ri_qei_valid                   : PspCcpCmd_Interrupt_Status_Q0_RI_QEI_Valid_SIZE;
          unsigned int ri_qsi_valid                   : PspCcpCmd_Interrupt_Status_Q0_RI_QSI_Valid_SIZE;
          unsigned int ri_errint_valid                : PspCcpCmd_Interrupt_Status_Q0_RI_ErrInt_Valid_SIZE;
          unsigned int ri_compint_valid               : PspCcpCmd_Interrupt_Status_Q0_RI_CompInt_Valid_SIZE;
     } pspccpcmd_interrupt_status_q0_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_interrupt_status_q0_t f;
} pspccpcmd_interrupt_status_q0_u;


/*
 * PspCcpCmd_Interrupt_Status_Q1 struct
 */

#define PspCcpCmd_Interrupt_Status_Q1_REG_SIZE 32
#define PspCcpCmd_Interrupt_Status_Q1_RI_CompInt_Valid_SIZE 1
#define PspCcpCmd_Interrupt_Status_Q1_RI_ErrInt_Valid_SIZE 1
#define PspCcpCmd_Interrupt_Status_Q1_RI_QSI_Valid_SIZE 1
#define PspCcpCmd_Interrupt_Status_Q1_RI_QEI_Valid_SIZE 1

#define PspCcpCmd_Interrupt_Status_Q1_RI_CompInt_Valid_SHIFT 0
#define PspCcpCmd_Interrupt_Status_Q1_RI_ErrInt_Valid_SHIFT 1
#define PspCcpCmd_Interrupt_Status_Q1_RI_QSI_Valid_SHIFT 2
#define PspCcpCmd_Interrupt_Status_Q1_RI_QEI_Valid_SHIFT 3

#define PspCcpCmd_Interrupt_Status_Q1_RI_CompInt_Valid_MASK 0x1
#define PspCcpCmd_Interrupt_Status_Q1_RI_ErrInt_Valid_MASK 0x2
#define PspCcpCmd_Interrupt_Status_Q1_RI_QSI_Valid_MASK 0x4
#define PspCcpCmd_Interrupt_Status_Q1_RI_QEI_Valid_MASK 0x8

#define PspCcpCmd_Interrupt_Status_Q1_MASK \
     (PspCcpCmd_Interrupt_Status_Q1_RI_CompInt_Valid_MASK | \
      PspCcpCmd_Interrupt_Status_Q1_RI_ErrInt_Valid_MASK | \
      PspCcpCmd_Interrupt_Status_Q1_RI_QSI_Valid_MASK | \
      PspCcpCmd_Interrupt_Status_Q1_RI_QEI_Valid_MASK)

#define PspCcpCmd_Interrupt_Status_Q1_DEFAULT 0x00000000

#define PspCcpCmd_Interrupt_Status_Q1_GET_RI_CompInt_Valid(pspccpcmd_interrupt_status_q1) \
     ((pspccpcmd_interrupt_status_q1 & PspCcpCmd_Interrupt_Status_Q1_RI_CompInt_Valid_MASK) >> PspCcpCmd_Interrupt_Status_Q1_RI_CompInt_Valid_SHIFT)
#define PspCcpCmd_Interrupt_Status_Q1_GET_RI_ErrInt_Valid(pspccpcmd_interrupt_status_q1) \
     ((pspccpcmd_interrupt_status_q1 & PspCcpCmd_Interrupt_Status_Q1_RI_ErrInt_Valid_MASK) >> PspCcpCmd_Interrupt_Status_Q1_RI_ErrInt_Valid_SHIFT)
#define PspCcpCmd_Interrupt_Status_Q1_GET_RI_QSI_Valid(pspccpcmd_interrupt_status_q1) \
     ((pspccpcmd_interrupt_status_q1 & PspCcpCmd_Interrupt_Status_Q1_RI_QSI_Valid_MASK) >> PspCcpCmd_Interrupt_Status_Q1_RI_QSI_Valid_SHIFT)
#define PspCcpCmd_Interrupt_Status_Q1_GET_RI_QEI_Valid(pspccpcmd_interrupt_status_q1) \
     ((pspccpcmd_interrupt_status_q1 & PspCcpCmd_Interrupt_Status_Q1_RI_QEI_Valid_MASK) >> PspCcpCmd_Interrupt_Status_Q1_RI_QEI_Valid_SHIFT)

#define PspCcpCmd_Interrupt_Status_Q1_SET_RI_CompInt_Valid(pspccpcmd_interrupt_status_q1_reg, ri_compint_valid) \
     pspccpcmd_interrupt_status_q1_reg = (pspccpcmd_interrupt_status_q1_reg & ~PspCcpCmd_Interrupt_Status_Q1_RI_CompInt_Valid_MASK) | (ri_compint_valid << PspCcpCmd_Interrupt_Status_Q1_RI_CompInt_Valid_SHIFT)
#define PspCcpCmd_Interrupt_Status_Q1_SET_RI_ErrInt_Valid(pspccpcmd_interrupt_status_q1_reg, ri_errint_valid) \
     pspccpcmd_interrupt_status_q1_reg = (pspccpcmd_interrupt_status_q1_reg & ~PspCcpCmd_Interrupt_Status_Q1_RI_ErrInt_Valid_MASK) | (ri_errint_valid << PspCcpCmd_Interrupt_Status_Q1_RI_ErrInt_Valid_SHIFT)
#define PspCcpCmd_Interrupt_Status_Q1_SET_RI_QSI_Valid(pspccpcmd_interrupt_status_q1_reg, ri_qsi_valid) \
     pspccpcmd_interrupt_status_q1_reg = (pspccpcmd_interrupt_status_q1_reg & ~PspCcpCmd_Interrupt_Status_Q1_RI_QSI_Valid_MASK) | (ri_qsi_valid << PspCcpCmd_Interrupt_Status_Q1_RI_QSI_Valid_SHIFT)
#define PspCcpCmd_Interrupt_Status_Q1_SET_RI_QEI_Valid(pspccpcmd_interrupt_status_q1_reg, ri_qei_valid) \
     pspccpcmd_interrupt_status_q1_reg = (pspccpcmd_interrupt_status_q1_reg & ~PspCcpCmd_Interrupt_Status_Q1_RI_QEI_Valid_MASK) | (ri_qei_valid << PspCcpCmd_Interrupt_Status_Q1_RI_QEI_Valid_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_interrupt_status_q1_t {
          unsigned int ri_compint_valid               : PspCcpCmd_Interrupt_Status_Q1_RI_CompInt_Valid_SIZE;
          unsigned int ri_errint_valid                : PspCcpCmd_Interrupt_Status_Q1_RI_ErrInt_Valid_SIZE;
          unsigned int ri_qsi_valid                   : PspCcpCmd_Interrupt_Status_Q1_RI_QSI_Valid_SIZE;
          unsigned int ri_qei_valid                   : PspCcpCmd_Interrupt_Status_Q1_RI_QEI_Valid_SIZE;
          unsigned int                                : 28;
     } pspccpcmd_interrupt_status_q1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_interrupt_status_q1_t {
          unsigned int                                : 28;
          unsigned int ri_qei_valid                   : PspCcpCmd_Interrupt_Status_Q1_RI_QEI_Valid_SIZE;
          unsigned int ri_qsi_valid                   : PspCcpCmd_Interrupt_Status_Q1_RI_QSI_Valid_SIZE;
          unsigned int ri_errint_valid                : PspCcpCmd_Interrupt_Status_Q1_RI_ErrInt_Valid_SIZE;
          unsigned int ri_compint_valid               : PspCcpCmd_Interrupt_Status_Q1_RI_CompInt_Valid_SIZE;
     } pspccpcmd_interrupt_status_q1_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_interrupt_status_q1_t f;
} pspccpcmd_interrupt_status_q1_u;


/*
 * PspCcpCmd_Interrupt_Status_Q2 struct
 */

#define PspCcpCmd_Interrupt_Status_Q2_REG_SIZE 32
#define PspCcpCmd_Interrupt_Status_Q2_RI_CompInt_Valid_SIZE 1
#define PspCcpCmd_Interrupt_Status_Q2_RI_ErrInt_Valid_SIZE 1
#define PspCcpCmd_Interrupt_Status_Q2_RI_QSI_Valid_SIZE 1
#define PspCcpCmd_Interrupt_Status_Q2_RI_QEI_Valid_SIZE 1

#define PspCcpCmd_Interrupt_Status_Q2_RI_CompInt_Valid_SHIFT 0
#define PspCcpCmd_Interrupt_Status_Q2_RI_ErrInt_Valid_SHIFT 1
#define PspCcpCmd_Interrupt_Status_Q2_RI_QSI_Valid_SHIFT 2
#define PspCcpCmd_Interrupt_Status_Q2_RI_QEI_Valid_SHIFT 3

#define PspCcpCmd_Interrupt_Status_Q2_RI_CompInt_Valid_MASK 0x1
#define PspCcpCmd_Interrupt_Status_Q2_RI_ErrInt_Valid_MASK 0x2
#define PspCcpCmd_Interrupt_Status_Q2_RI_QSI_Valid_MASK 0x4
#define PspCcpCmd_Interrupt_Status_Q2_RI_QEI_Valid_MASK 0x8

#define PspCcpCmd_Interrupt_Status_Q2_MASK \
     (PspCcpCmd_Interrupt_Status_Q2_RI_CompInt_Valid_MASK | \
      PspCcpCmd_Interrupt_Status_Q2_RI_ErrInt_Valid_MASK | \
      PspCcpCmd_Interrupt_Status_Q2_RI_QSI_Valid_MASK | \
      PspCcpCmd_Interrupt_Status_Q2_RI_QEI_Valid_MASK)

#define PspCcpCmd_Interrupt_Status_Q2_DEFAULT 0x00000000

#define PspCcpCmd_Interrupt_Status_Q2_GET_RI_CompInt_Valid(pspccpcmd_interrupt_status_q2) \
     ((pspccpcmd_interrupt_status_q2 & PspCcpCmd_Interrupt_Status_Q2_RI_CompInt_Valid_MASK) >> PspCcpCmd_Interrupt_Status_Q2_RI_CompInt_Valid_SHIFT)
#define PspCcpCmd_Interrupt_Status_Q2_GET_RI_ErrInt_Valid(pspccpcmd_interrupt_status_q2) \
     ((pspccpcmd_interrupt_status_q2 & PspCcpCmd_Interrupt_Status_Q2_RI_ErrInt_Valid_MASK) >> PspCcpCmd_Interrupt_Status_Q2_RI_ErrInt_Valid_SHIFT)
#define PspCcpCmd_Interrupt_Status_Q2_GET_RI_QSI_Valid(pspccpcmd_interrupt_status_q2) \
     ((pspccpcmd_interrupt_status_q2 & PspCcpCmd_Interrupt_Status_Q2_RI_QSI_Valid_MASK) >> PspCcpCmd_Interrupt_Status_Q2_RI_QSI_Valid_SHIFT)
#define PspCcpCmd_Interrupt_Status_Q2_GET_RI_QEI_Valid(pspccpcmd_interrupt_status_q2) \
     ((pspccpcmd_interrupt_status_q2 & PspCcpCmd_Interrupt_Status_Q2_RI_QEI_Valid_MASK) >> PspCcpCmd_Interrupt_Status_Q2_RI_QEI_Valid_SHIFT)

#define PspCcpCmd_Interrupt_Status_Q2_SET_RI_CompInt_Valid(pspccpcmd_interrupt_status_q2_reg, ri_compint_valid) \
     pspccpcmd_interrupt_status_q2_reg = (pspccpcmd_interrupt_status_q2_reg & ~PspCcpCmd_Interrupt_Status_Q2_RI_CompInt_Valid_MASK) | (ri_compint_valid << PspCcpCmd_Interrupt_Status_Q2_RI_CompInt_Valid_SHIFT)
#define PspCcpCmd_Interrupt_Status_Q2_SET_RI_ErrInt_Valid(pspccpcmd_interrupt_status_q2_reg, ri_errint_valid) \
     pspccpcmd_interrupt_status_q2_reg = (pspccpcmd_interrupt_status_q2_reg & ~PspCcpCmd_Interrupt_Status_Q2_RI_ErrInt_Valid_MASK) | (ri_errint_valid << PspCcpCmd_Interrupt_Status_Q2_RI_ErrInt_Valid_SHIFT)
#define PspCcpCmd_Interrupt_Status_Q2_SET_RI_QSI_Valid(pspccpcmd_interrupt_status_q2_reg, ri_qsi_valid) \
     pspccpcmd_interrupt_status_q2_reg = (pspccpcmd_interrupt_status_q2_reg & ~PspCcpCmd_Interrupt_Status_Q2_RI_QSI_Valid_MASK) | (ri_qsi_valid << PspCcpCmd_Interrupt_Status_Q2_RI_QSI_Valid_SHIFT)
#define PspCcpCmd_Interrupt_Status_Q2_SET_RI_QEI_Valid(pspccpcmd_interrupt_status_q2_reg, ri_qei_valid) \
     pspccpcmd_interrupt_status_q2_reg = (pspccpcmd_interrupt_status_q2_reg & ~PspCcpCmd_Interrupt_Status_Q2_RI_QEI_Valid_MASK) | (ri_qei_valid << PspCcpCmd_Interrupt_Status_Q2_RI_QEI_Valid_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_interrupt_status_q2_t {
          unsigned int ri_compint_valid               : PspCcpCmd_Interrupt_Status_Q2_RI_CompInt_Valid_SIZE;
          unsigned int ri_errint_valid                : PspCcpCmd_Interrupt_Status_Q2_RI_ErrInt_Valid_SIZE;
          unsigned int ri_qsi_valid                   : PspCcpCmd_Interrupt_Status_Q2_RI_QSI_Valid_SIZE;
          unsigned int ri_qei_valid                   : PspCcpCmd_Interrupt_Status_Q2_RI_QEI_Valid_SIZE;
          unsigned int                                : 28;
     } pspccpcmd_interrupt_status_q2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_interrupt_status_q2_t {
          unsigned int                                : 28;
          unsigned int ri_qei_valid                   : PspCcpCmd_Interrupt_Status_Q2_RI_QEI_Valid_SIZE;
          unsigned int ri_qsi_valid                   : PspCcpCmd_Interrupt_Status_Q2_RI_QSI_Valid_SIZE;
          unsigned int ri_errint_valid                : PspCcpCmd_Interrupt_Status_Q2_RI_ErrInt_Valid_SIZE;
          unsigned int ri_compint_valid               : PspCcpCmd_Interrupt_Status_Q2_RI_CompInt_Valid_SIZE;
     } pspccpcmd_interrupt_status_q2_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_interrupt_status_q2_t f;
} pspccpcmd_interrupt_status_q2_u;


/*
 * PspCcpCmd_Status_Q0 struct
 */

#define PspCcpCmd_Status_Q0_REG_SIZE   32
#define PspCcpCmd_Status_Q0_VQM_Error_SIZE 6
#define PspCcpCmd_Status_Q0_VQM_ErrorPrevious_SIZE 1
#define PspCcpCmd_Status_Q0_VQM_JStatus_SIZE 3
#define PspCcpCmd_Status_Q0_VQM_ErrorSource_SIZE 3

#define PspCcpCmd_Status_Q0_VQM_Error_SHIFT 0
#define PspCcpCmd_Status_Q0_VQM_ErrorPrevious_SHIFT 6
#define PspCcpCmd_Status_Q0_VQM_JStatus_SHIFT 7
#define PspCcpCmd_Status_Q0_VQM_ErrorSource_SHIFT 10

#define PspCcpCmd_Status_Q0_VQM_Error_MASK 0x3f
#define PspCcpCmd_Status_Q0_VQM_ErrorPrevious_MASK 0x40
#define PspCcpCmd_Status_Q0_VQM_JStatus_MASK 0x380
#define PspCcpCmd_Status_Q0_VQM_ErrorSource_MASK 0x1c00

#define PspCcpCmd_Status_Q0_MASK \
     (PspCcpCmd_Status_Q0_VQM_Error_MASK | \
      PspCcpCmd_Status_Q0_VQM_ErrorPrevious_MASK | \
      PspCcpCmd_Status_Q0_VQM_JStatus_MASK | \
      PspCcpCmd_Status_Q0_VQM_ErrorSource_MASK)

#define PspCcpCmd_Status_Q0_DEFAULT    0x00000000

#define PspCcpCmd_Status_Q0_GET_VQM_Error(pspccpcmd_status_q0) \
     ((pspccpcmd_status_q0 & PspCcpCmd_Status_Q0_VQM_Error_MASK) >> PspCcpCmd_Status_Q0_VQM_Error_SHIFT)
#define PspCcpCmd_Status_Q0_GET_VQM_ErrorPrevious(pspccpcmd_status_q0) \
     ((pspccpcmd_status_q0 & PspCcpCmd_Status_Q0_VQM_ErrorPrevious_MASK) >> PspCcpCmd_Status_Q0_VQM_ErrorPrevious_SHIFT)
#define PspCcpCmd_Status_Q0_GET_VQM_JStatus(pspccpcmd_status_q0) \
     ((pspccpcmd_status_q0 & PspCcpCmd_Status_Q0_VQM_JStatus_MASK) >> PspCcpCmd_Status_Q0_VQM_JStatus_SHIFT)
#define PspCcpCmd_Status_Q0_GET_VQM_ErrorSource(pspccpcmd_status_q0) \
     ((pspccpcmd_status_q0 & PspCcpCmd_Status_Q0_VQM_ErrorSource_MASK) >> PspCcpCmd_Status_Q0_VQM_ErrorSource_SHIFT)

#define PspCcpCmd_Status_Q0_SET_VQM_Error(pspccpcmd_status_q0_reg, vqm_error) \
     pspccpcmd_status_q0_reg = (pspccpcmd_status_q0_reg & ~PspCcpCmd_Status_Q0_VQM_Error_MASK) | (vqm_error << PspCcpCmd_Status_Q0_VQM_Error_SHIFT)
#define PspCcpCmd_Status_Q0_SET_VQM_ErrorPrevious(pspccpcmd_status_q0_reg, vqm_errorprevious) \
     pspccpcmd_status_q0_reg = (pspccpcmd_status_q0_reg & ~PspCcpCmd_Status_Q0_VQM_ErrorPrevious_MASK) | (vqm_errorprevious << PspCcpCmd_Status_Q0_VQM_ErrorPrevious_SHIFT)
#define PspCcpCmd_Status_Q0_SET_VQM_JStatus(pspccpcmd_status_q0_reg, vqm_jstatus) \
     pspccpcmd_status_q0_reg = (pspccpcmd_status_q0_reg & ~PspCcpCmd_Status_Q0_VQM_JStatus_MASK) | (vqm_jstatus << PspCcpCmd_Status_Q0_VQM_JStatus_SHIFT)
#define PspCcpCmd_Status_Q0_SET_VQM_ErrorSource(pspccpcmd_status_q0_reg, vqm_errorsource) \
     pspccpcmd_status_q0_reg = (pspccpcmd_status_q0_reg & ~PspCcpCmd_Status_Q0_VQM_ErrorSource_MASK) | (vqm_errorsource << PspCcpCmd_Status_Q0_VQM_ErrorSource_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_status_q0_t {
          unsigned int vqm_error                      : PspCcpCmd_Status_Q0_VQM_Error_SIZE;
          unsigned int vqm_errorprevious              : PspCcpCmd_Status_Q0_VQM_ErrorPrevious_SIZE;
          unsigned int vqm_jstatus                    : PspCcpCmd_Status_Q0_VQM_JStatus_SIZE;
          unsigned int vqm_errorsource                : PspCcpCmd_Status_Q0_VQM_ErrorSource_SIZE;
          unsigned int                                : 19;
     } pspccpcmd_status_q0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_status_q0_t {
          unsigned int                                : 19;
          unsigned int vqm_errorsource                : PspCcpCmd_Status_Q0_VQM_ErrorSource_SIZE;
          unsigned int vqm_jstatus                    : PspCcpCmd_Status_Q0_VQM_JStatus_SIZE;
          unsigned int vqm_errorprevious              : PspCcpCmd_Status_Q0_VQM_ErrorPrevious_SIZE;
          unsigned int vqm_error                      : PspCcpCmd_Status_Q0_VQM_Error_SIZE;
     } pspccpcmd_status_q0_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_status_q0_t f;
} pspccpcmd_status_q0_u;


/*
 * PspCcpCmd_Status_Q1 struct
 */

#define PspCcpCmd_Status_Q1_REG_SIZE   32
#define PspCcpCmd_Status_Q1_VQM_Error_SIZE 6
#define PspCcpCmd_Status_Q1_VQM_ErrorPrevious_SIZE 1
#define PspCcpCmd_Status_Q1_VQM_JStatus_SIZE 3
#define PspCcpCmd_Status_Q1_VQM_ErrorSource_SIZE 3

#define PspCcpCmd_Status_Q1_VQM_Error_SHIFT 0
#define PspCcpCmd_Status_Q1_VQM_ErrorPrevious_SHIFT 6
#define PspCcpCmd_Status_Q1_VQM_JStatus_SHIFT 7
#define PspCcpCmd_Status_Q1_VQM_ErrorSource_SHIFT 10

#define PspCcpCmd_Status_Q1_VQM_Error_MASK 0x3f
#define PspCcpCmd_Status_Q1_VQM_ErrorPrevious_MASK 0x40
#define PspCcpCmd_Status_Q1_VQM_JStatus_MASK 0x380
#define PspCcpCmd_Status_Q1_VQM_ErrorSource_MASK 0x1c00

#define PspCcpCmd_Status_Q1_MASK \
     (PspCcpCmd_Status_Q1_VQM_Error_MASK | \
      PspCcpCmd_Status_Q1_VQM_ErrorPrevious_MASK | \
      PspCcpCmd_Status_Q1_VQM_JStatus_MASK | \
      PspCcpCmd_Status_Q1_VQM_ErrorSource_MASK)

#define PspCcpCmd_Status_Q1_DEFAULT    0x00000000

#define PspCcpCmd_Status_Q1_GET_VQM_Error(pspccpcmd_status_q1) \
     ((pspccpcmd_status_q1 & PspCcpCmd_Status_Q1_VQM_Error_MASK) >> PspCcpCmd_Status_Q1_VQM_Error_SHIFT)
#define PspCcpCmd_Status_Q1_GET_VQM_ErrorPrevious(pspccpcmd_status_q1) \
     ((pspccpcmd_status_q1 & PspCcpCmd_Status_Q1_VQM_ErrorPrevious_MASK) >> PspCcpCmd_Status_Q1_VQM_ErrorPrevious_SHIFT)
#define PspCcpCmd_Status_Q1_GET_VQM_JStatus(pspccpcmd_status_q1) \
     ((pspccpcmd_status_q1 & PspCcpCmd_Status_Q1_VQM_JStatus_MASK) >> PspCcpCmd_Status_Q1_VQM_JStatus_SHIFT)
#define PspCcpCmd_Status_Q1_GET_VQM_ErrorSource(pspccpcmd_status_q1) \
     ((pspccpcmd_status_q1 & PspCcpCmd_Status_Q1_VQM_ErrorSource_MASK) >> PspCcpCmd_Status_Q1_VQM_ErrorSource_SHIFT)

#define PspCcpCmd_Status_Q1_SET_VQM_Error(pspccpcmd_status_q1_reg, vqm_error) \
     pspccpcmd_status_q1_reg = (pspccpcmd_status_q1_reg & ~PspCcpCmd_Status_Q1_VQM_Error_MASK) | (vqm_error << PspCcpCmd_Status_Q1_VQM_Error_SHIFT)
#define PspCcpCmd_Status_Q1_SET_VQM_ErrorPrevious(pspccpcmd_status_q1_reg, vqm_errorprevious) \
     pspccpcmd_status_q1_reg = (pspccpcmd_status_q1_reg & ~PspCcpCmd_Status_Q1_VQM_ErrorPrevious_MASK) | (vqm_errorprevious << PspCcpCmd_Status_Q1_VQM_ErrorPrevious_SHIFT)
#define PspCcpCmd_Status_Q1_SET_VQM_JStatus(pspccpcmd_status_q1_reg, vqm_jstatus) \
     pspccpcmd_status_q1_reg = (pspccpcmd_status_q1_reg & ~PspCcpCmd_Status_Q1_VQM_JStatus_MASK) | (vqm_jstatus << PspCcpCmd_Status_Q1_VQM_JStatus_SHIFT)
#define PspCcpCmd_Status_Q1_SET_VQM_ErrorSource(pspccpcmd_status_q1_reg, vqm_errorsource) \
     pspccpcmd_status_q1_reg = (pspccpcmd_status_q1_reg & ~PspCcpCmd_Status_Q1_VQM_ErrorSource_MASK) | (vqm_errorsource << PspCcpCmd_Status_Q1_VQM_ErrorSource_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_status_q1_t {
          unsigned int vqm_error                      : PspCcpCmd_Status_Q1_VQM_Error_SIZE;
          unsigned int vqm_errorprevious              : PspCcpCmd_Status_Q1_VQM_ErrorPrevious_SIZE;
          unsigned int vqm_jstatus                    : PspCcpCmd_Status_Q1_VQM_JStatus_SIZE;
          unsigned int vqm_errorsource                : PspCcpCmd_Status_Q1_VQM_ErrorSource_SIZE;
          unsigned int                                : 19;
     } pspccpcmd_status_q1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_status_q1_t {
          unsigned int                                : 19;
          unsigned int vqm_errorsource                : PspCcpCmd_Status_Q1_VQM_ErrorSource_SIZE;
          unsigned int vqm_jstatus                    : PspCcpCmd_Status_Q1_VQM_JStatus_SIZE;
          unsigned int vqm_errorprevious              : PspCcpCmd_Status_Q1_VQM_ErrorPrevious_SIZE;
          unsigned int vqm_error                      : PspCcpCmd_Status_Q1_VQM_Error_SIZE;
     } pspccpcmd_status_q1_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_status_q1_t f;
} pspccpcmd_status_q1_u;


/*
 * PspCcpCmd_Status_Q2 struct
 */

#define PspCcpCmd_Status_Q2_REG_SIZE   32
#define PspCcpCmd_Status_Q2_VQM_Error_SIZE 6
#define PspCcpCmd_Status_Q2_VQM_ErrorPrevious_SIZE 1
#define PspCcpCmd_Status_Q2_VQM_JStatus_SIZE 3
#define PspCcpCmd_Status_Q2_VQM_ErrorSource_SIZE 3

#define PspCcpCmd_Status_Q2_VQM_Error_SHIFT 0
#define PspCcpCmd_Status_Q2_VQM_ErrorPrevious_SHIFT 6
#define PspCcpCmd_Status_Q2_VQM_JStatus_SHIFT 7
#define PspCcpCmd_Status_Q2_VQM_ErrorSource_SHIFT 10

#define PspCcpCmd_Status_Q2_VQM_Error_MASK 0x3f
#define PspCcpCmd_Status_Q2_VQM_ErrorPrevious_MASK 0x40
#define PspCcpCmd_Status_Q2_VQM_JStatus_MASK 0x380
#define PspCcpCmd_Status_Q2_VQM_ErrorSource_MASK 0x1c00

#define PspCcpCmd_Status_Q2_MASK \
     (PspCcpCmd_Status_Q2_VQM_Error_MASK | \
      PspCcpCmd_Status_Q2_VQM_ErrorPrevious_MASK | \
      PspCcpCmd_Status_Q2_VQM_JStatus_MASK | \
      PspCcpCmd_Status_Q2_VQM_ErrorSource_MASK)

#define PspCcpCmd_Status_Q2_DEFAULT    0x00000000

#define PspCcpCmd_Status_Q2_GET_VQM_Error(pspccpcmd_status_q2) \
     ((pspccpcmd_status_q2 & PspCcpCmd_Status_Q2_VQM_Error_MASK) >> PspCcpCmd_Status_Q2_VQM_Error_SHIFT)
#define PspCcpCmd_Status_Q2_GET_VQM_ErrorPrevious(pspccpcmd_status_q2) \
     ((pspccpcmd_status_q2 & PspCcpCmd_Status_Q2_VQM_ErrorPrevious_MASK) >> PspCcpCmd_Status_Q2_VQM_ErrorPrevious_SHIFT)
#define PspCcpCmd_Status_Q2_GET_VQM_JStatus(pspccpcmd_status_q2) \
     ((pspccpcmd_status_q2 & PspCcpCmd_Status_Q2_VQM_JStatus_MASK) >> PspCcpCmd_Status_Q2_VQM_JStatus_SHIFT)
#define PspCcpCmd_Status_Q2_GET_VQM_ErrorSource(pspccpcmd_status_q2) \
     ((pspccpcmd_status_q2 & PspCcpCmd_Status_Q2_VQM_ErrorSource_MASK) >> PspCcpCmd_Status_Q2_VQM_ErrorSource_SHIFT)

#define PspCcpCmd_Status_Q2_SET_VQM_Error(pspccpcmd_status_q2_reg, vqm_error) \
     pspccpcmd_status_q2_reg = (pspccpcmd_status_q2_reg & ~PspCcpCmd_Status_Q2_VQM_Error_MASK) | (vqm_error << PspCcpCmd_Status_Q2_VQM_Error_SHIFT)
#define PspCcpCmd_Status_Q2_SET_VQM_ErrorPrevious(pspccpcmd_status_q2_reg, vqm_errorprevious) \
     pspccpcmd_status_q2_reg = (pspccpcmd_status_q2_reg & ~PspCcpCmd_Status_Q2_VQM_ErrorPrevious_MASK) | (vqm_errorprevious << PspCcpCmd_Status_Q2_VQM_ErrorPrevious_SHIFT)
#define PspCcpCmd_Status_Q2_SET_VQM_JStatus(pspccpcmd_status_q2_reg, vqm_jstatus) \
     pspccpcmd_status_q2_reg = (pspccpcmd_status_q2_reg & ~PspCcpCmd_Status_Q2_VQM_JStatus_MASK) | (vqm_jstatus << PspCcpCmd_Status_Q2_VQM_JStatus_SHIFT)
#define PspCcpCmd_Status_Q2_SET_VQM_ErrorSource(pspccpcmd_status_q2_reg, vqm_errorsource) \
     pspccpcmd_status_q2_reg = (pspccpcmd_status_q2_reg & ~PspCcpCmd_Status_Q2_VQM_ErrorSource_MASK) | (vqm_errorsource << PspCcpCmd_Status_Q2_VQM_ErrorSource_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_status_q2_t {
          unsigned int vqm_error                      : PspCcpCmd_Status_Q2_VQM_Error_SIZE;
          unsigned int vqm_errorprevious              : PspCcpCmd_Status_Q2_VQM_ErrorPrevious_SIZE;
          unsigned int vqm_jstatus                    : PspCcpCmd_Status_Q2_VQM_JStatus_SIZE;
          unsigned int vqm_errorsource                : PspCcpCmd_Status_Q2_VQM_ErrorSource_SIZE;
          unsigned int                                : 19;
     } pspccpcmd_status_q2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_status_q2_t {
          unsigned int                                : 19;
          unsigned int vqm_errorsource                : PspCcpCmd_Status_Q2_VQM_ErrorSource_SIZE;
          unsigned int vqm_jstatus                    : PspCcpCmd_Status_Q2_VQM_JStatus_SIZE;
          unsigned int vqm_errorprevious              : PspCcpCmd_Status_Q2_VQM_ErrorPrevious_SIZE;
          unsigned int vqm_error                      : PspCcpCmd_Status_Q2_VQM_Error_SIZE;
     } pspccpcmd_status_q2_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_status_q2_t f;
} pspccpcmd_status_q2_u;


/*
 * PspCcpCmd_Int_Status_Q0 struct
 */

#define PspCcpCmd_Int_Status_Q0_REG_SIZE 32
#define PspCcpCmd_Int_Status_Q0_IC_EventCnt_SIZE 7

#define PspCcpCmd_Int_Status_Q0_IC_EventCnt_SHIFT 0

#define PspCcpCmd_Int_Status_Q0_IC_EventCnt_MASK 0x7f

#define PspCcpCmd_Int_Status_Q0_MASK \
     (PspCcpCmd_Int_Status_Q0_IC_EventCnt_MASK)

#define PspCcpCmd_Int_Status_Q0_DEFAULT 0x00000000

#define PspCcpCmd_Int_Status_Q0_GET_IC_EventCnt(pspccpcmd_int_status_q0) \
     ((pspccpcmd_int_status_q0 & PspCcpCmd_Int_Status_Q0_IC_EventCnt_MASK) >> PspCcpCmd_Int_Status_Q0_IC_EventCnt_SHIFT)

#define PspCcpCmd_Int_Status_Q0_SET_IC_EventCnt(pspccpcmd_int_status_q0_reg, ic_eventcnt) \
     pspccpcmd_int_status_q0_reg = (pspccpcmd_int_status_q0_reg & ~PspCcpCmd_Int_Status_Q0_IC_EventCnt_MASK) | (ic_eventcnt << PspCcpCmd_Int_Status_Q0_IC_EventCnt_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_int_status_q0_t {
          unsigned int ic_eventcnt                    : PspCcpCmd_Int_Status_Q0_IC_EventCnt_SIZE;
          unsigned int                                : 25;
     } pspccpcmd_int_status_q0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_int_status_q0_t {
          unsigned int                                : 25;
          unsigned int ic_eventcnt                    : PspCcpCmd_Int_Status_Q0_IC_EventCnt_SIZE;
     } pspccpcmd_int_status_q0_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_int_status_q0_t f;
} pspccpcmd_int_status_q0_u;


/*
 * PspCcpCmd_Int_Status_Q1 struct
 */

#define PspCcpCmd_Int_Status_Q1_REG_SIZE 32
#define PspCcpCmd_Int_Status_Q1_IC_EventCnt_SIZE 7

#define PspCcpCmd_Int_Status_Q1_IC_EventCnt_SHIFT 0

#define PspCcpCmd_Int_Status_Q1_IC_EventCnt_MASK 0x7f

#define PspCcpCmd_Int_Status_Q1_MASK \
     (PspCcpCmd_Int_Status_Q1_IC_EventCnt_MASK)

#define PspCcpCmd_Int_Status_Q1_DEFAULT 0x00000000

#define PspCcpCmd_Int_Status_Q1_GET_IC_EventCnt(pspccpcmd_int_status_q1) \
     ((pspccpcmd_int_status_q1 & PspCcpCmd_Int_Status_Q1_IC_EventCnt_MASK) >> PspCcpCmd_Int_Status_Q1_IC_EventCnt_SHIFT)

#define PspCcpCmd_Int_Status_Q1_SET_IC_EventCnt(pspccpcmd_int_status_q1_reg, ic_eventcnt) \
     pspccpcmd_int_status_q1_reg = (pspccpcmd_int_status_q1_reg & ~PspCcpCmd_Int_Status_Q1_IC_EventCnt_MASK) | (ic_eventcnt << PspCcpCmd_Int_Status_Q1_IC_EventCnt_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_int_status_q1_t {
          unsigned int ic_eventcnt                    : PspCcpCmd_Int_Status_Q1_IC_EventCnt_SIZE;
          unsigned int                                : 25;
     } pspccpcmd_int_status_q1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_int_status_q1_t {
          unsigned int                                : 25;
          unsigned int ic_eventcnt                    : PspCcpCmd_Int_Status_Q1_IC_EventCnt_SIZE;
     } pspccpcmd_int_status_q1_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_int_status_q1_t f;
} pspccpcmd_int_status_q1_u;


/*
 * PspCcpCmd_Int_Status_Q2 struct
 */

#define PspCcpCmd_Int_Status_Q2_REG_SIZE 32
#define PspCcpCmd_Int_Status_Q2_IC_EventCnt_SIZE 7

#define PspCcpCmd_Int_Status_Q2_IC_EventCnt_SHIFT 0

#define PspCcpCmd_Int_Status_Q2_IC_EventCnt_MASK 0x7f

#define PspCcpCmd_Int_Status_Q2_MASK \
     (PspCcpCmd_Int_Status_Q2_IC_EventCnt_MASK)

#define PspCcpCmd_Int_Status_Q2_DEFAULT 0x00000000

#define PspCcpCmd_Int_Status_Q2_GET_IC_EventCnt(pspccpcmd_int_status_q2) \
     ((pspccpcmd_int_status_q2 & PspCcpCmd_Int_Status_Q2_IC_EventCnt_MASK) >> PspCcpCmd_Int_Status_Q2_IC_EventCnt_SHIFT)

#define PspCcpCmd_Int_Status_Q2_SET_IC_EventCnt(pspccpcmd_int_status_q2_reg, ic_eventcnt) \
     pspccpcmd_int_status_q2_reg = (pspccpcmd_int_status_q2_reg & ~PspCcpCmd_Int_Status_Q2_IC_EventCnt_MASK) | (ic_eventcnt << PspCcpCmd_Int_Status_Q2_IC_EventCnt_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_int_status_q2_t {
          unsigned int ic_eventcnt                    : PspCcpCmd_Int_Status_Q2_IC_EventCnt_SIZE;
          unsigned int                                : 25;
     } pspccpcmd_int_status_q2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_int_status_q2_t {
          unsigned int                                : 25;
          unsigned int ic_eventcnt                    : PspCcpCmd_Int_Status_Q2_IC_EventCnt_SIZE;
     } pspccpcmd_int_status_q2_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_int_status_q2_t f;
} pspccpcmd_int_status_q2_u;


/*
 * PspCcpCmd_DMA_Status_Q0 struct
 */

#define PspCcpCmd_DMA_Status_Q0_REG_SIZE 32
#define PspCcpCmd_DMA_Status_Q0_DMA_Pwrites_SIZE 10
#define PspCcpCmd_DMA_Status_Q0_DMA_Preads_SIZE 6
#define PspCcpCmd_DMA_Status_Q0_DMA_Dstatus_SIZE 3

#define PspCcpCmd_DMA_Status_Q0_DMA_Pwrites_SHIFT 0
#define PspCcpCmd_DMA_Status_Q0_DMA_Preads_SHIFT 10
#define PspCcpCmd_DMA_Status_Q0_DMA_Dstatus_SHIFT 16

#define PspCcpCmd_DMA_Status_Q0_DMA_Pwrites_MASK 0x3ff
#define PspCcpCmd_DMA_Status_Q0_DMA_Preads_MASK 0xfc00
#define PspCcpCmd_DMA_Status_Q0_DMA_Dstatus_MASK 0x70000

#define PspCcpCmd_DMA_Status_Q0_MASK \
     (PspCcpCmd_DMA_Status_Q0_DMA_Pwrites_MASK | \
      PspCcpCmd_DMA_Status_Q0_DMA_Preads_MASK | \
      PspCcpCmd_DMA_Status_Q0_DMA_Dstatus_MASK)

#define PspCcpCmd_DMA_Status_Q0_DEFAULT 0x00000000

#define PspCcpCmd_DMA_Status_Q0_GET_DMA_Pwrites(pspccpcmd_dma_status_q0) \
     ((pspccpcmd_dma_status_q0 & PspCcpCmd_DMA_Status_Q0_DMA_Pwrites_MASK) >> PspCcpCmd_DMA_Status_Q0_DMA_Pwrites_SHIFT)
#define PspCcpCmd_DMA_Status_Q0_GET_DMA_Preads(pspccpcmd_dma_status_q0) \
     ((pspccpcmd_dma_status_q0 & PspCcpCmd_DMA_Status_Q0_DMA_Preads_MASK) >> PspCcpCmd_DMA_Status_Q0_DMA_Preads_SHIFT)
#define PspCcpCmd_DMA_Status_Q0_GET_DMA_Dstatus(pspccpcmd_dma_status_q0) \
     ((pspccpcmd_dma_status_q0 & PspCcpCmd_DMA_Status_Q0_DMA_Dstatus_MASK) >> PspCcpCmd_DMA_Status_Q0_DMA_Dstatus_SHIFT)

#define PspCcpCmd_DMA_Status_Q0_SET_DMA_Pwrites(pspccpcmd_dma_status_q0_reg, dma_pwrites) \
     pspccpcmd_dma_status_q0_reg = (pspccpcmd_dma_status_q0_reg & ~PspCcpCmd_DMA_Status_Q0_DMA_Pwrites_MASK) | (dma_pwrites << PspCcpCmd_DMA_Status_Q0_DMA_Pwrites_SHIFT)
#define PspCcpCmd_DMA_Status_Q0_SET_DMA_Preads(pspccpcmd_dma_status_q0_reg, dma_preads) \
     pspccpcmd_dma_status_q0_reg = (pspccpcmd_dma_status_q0_reg & ~PspCcpCmd_DMA_Status_Q0_DMA_Preads_MASK) | (dma_preads << PspCcpCmd_DMA_Status_Q0_DMA_Preads_SHIFT)
#define PspCcpCmd_DMA_Status_Q0_SET_DMA_Dstatus(pspccpcmd_dma_status_q0_reg, dma_dstatus) \
     pspccpcmd_dma_status_q0_reg = (pspccpcmd_dma_status_q0_reg & ~PspCcpCmd_DMA_Status_Q0_DMA_Dstatus_MASK) | (dma_dstatus << PspCcpCmd_DMA_Status_Q0_DMA_Dstatus_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_dma_status_q0_t {
          unsigned int dma_pwrites                    : PspCcpCmd_DMA_Status_Q0_DMA_Pwrites_SIZE;
          unsigned int dma_preads                     : PspCcpCmd_DMA_Status_Q0_DMA_Preads_SIZE;
          unsigned int dma_dstatus                    : PspCcpCmd_DMA_Status_Q0_DMA_Dstatus_SIZE;
          unsigned int                                : 13;
     } pspccpcmd_dma_status_q0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_dma_status_q0_t {
          unsigned int                                : 13;
          unsigned int dma_dstatus                    : PspCcpCmd_DMA_Status_Q0_DMA_Dstatus_SIZE;
          unsigned int dma_preads                     : PspCcpCmd_DMA_Status_Q0_DMA_Preads_SIZE;
          unsigned int dma_pwrites                    : PspCcpCmd_DMA_Status_Q0_DMA_Pwrites_SIZE;
     } pspccpcmd_dma_status_q0_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_dma_status_q0_t f;
} pspccpcmd_dma_status_q0_u;


/*
 * PspCcpCmd_DMA_Status_Q1 struct
 */

#define PspCcpCmd_DMA_Status_Q1_REG_SIZE 32
#define PspCcpCmd_DMA_Status_Q1_DMA_Pwrites_SIZE 10
#define PspCcpCmd_DMA_Status_Q1_DMA_Preads_SIZE 6
#define PspCcpCmd_DMA_Status_Q1_DMA_Dstatus_SIZE 3

#define PspCcpCmd_DMA_Status_Q1_DMA_Pwrites_SHIFT 0
#define PspCcpCmd_DMA_Status_Q1_DMA_Preads_SHIFT 10
#define PspCcpCmd_DMA_Status_Q1_DMA_Dstatus_SHIFT 16

#define PspCcpCmd_DMA_Status_Q1_DMA_Pwrites_MASK 0x3ff
#define PspCcpCmd_DMA_Status_Q1_DMA_Preads_MASK 0xfc00
#define PspCcpCmd_DMA_Status_Q1_DMA_Dstatus_MASK 0x70000

#define PspCcpCmd_DMA_Status_Q1_MASK \
     (PspCcpCmd_DMA_Status_Q1_DMA_Pwrites_MASK | \
      PspCcpCmd_DMA_Status_Q1_DMA_Preads_MASK | \
      PspCcpCmd_DMA_Status_Q1_DMA_Dstatus_MASK)

#define PspCcpCmd_DMA_Status_Q1_DEFAULT 0x00000000

#define PspCcpCmd_DMA_Status_Q1_GET_DMA_Pwrites(pspccpcmd_dma_status_q1) \
     ((pspccpcmd_dma_status_q1 & PspCcpCmd_DMA_Status_Q1_DMA_Pwrites_MASK) >> PspCcpCmd_DMA_Status_Q1_DMA_Pwrites_SHIFT)
#define PspCcpCmd_DMA_Status_Q1_GET_DMA_Preads(pspccpcmd_dma_status_q1) \
     ((pspccpcmd_dma_status_q1 & PspCcpCmd_DMA_Status_Q1_DMA_Preads_MASK) >> PspCcpCmd_DMA_Status_Q1_DMA_Preads_SHIFT)
#define PspCcpCmd_DMA_Status_Q1_GET_DMA_Dstatus(pspccpcmd_dma_status_q1) \
     ((pspccpcmd_dma_status_q1 & PspCcpCmd_DMA_Status_Q1_DMA_Dstatus_MASK) >> PspCcpCmd_DMA_Status_Q1_DMA_Dstatus_SHIFT)

#define PspCcpCmd_DMA_Status_Q1_SET_DMA_Pwrites(pspccpcmd_dma_status_q1_reg, dma_pwrites) \
     pspccpcmd_dma_status_q1_reg = (pspccpcmd_dma_status_q1_reg & ~PspCcpCmd_DMA_Status_Q1_DMA_Pwrites_MASK) | (dma_pwrites << PspCcpCmd_DMA_Status_Q1_DMA_Pwrites_SHIFT)
#define PspCcpCmd_DMA_Status_Q1_SET_DMA_Preads(pspccpcmd_dma_status_q1_reg, dma_preads) \
     pspccpcmd_dma_status_q1_reg = (pspccpcmd_dma_status_q1_reg & ~PspCcpCmd_DMA_Status_Q1_DMA_Preads_MASK) | (dma_preads << PspCcpCmd_DMA_Status_Q1_DMA_Preads_SHIFT)
#define PspCcpCmd_DMA_Status_Q1_SET_DMA_Dstatus(pspccpcmd_dma_status_q1_reg, dma_dstatus) \
     pspccpcmd_dma_status_q1_reg = (pspccpcmd_dma_status_q1_reg & ~PspCcpCmd_DMA_Status_Q1_DMA_Dstatus_MASK) | (dma_dstatus << PspCcpCmd_DMA_Status_Q1_DMA_Dstatus_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_dma_status_q1_t {
          unsigned int dma_pwrites                    : PspCcpCmd_DMA_Status_Q1_DMA_Pwrites_SIZE;
          unsigned int dma_preads                     : PspCcpCmd_DMA_Status_Q1_DMA_Preads_SIZE;
          unsigned int dma_dstatus                    : PspCcpCmd_DMA_Status_Q1_DMA_Dstatus_SIZE;
          unsigned int                                : 13;
     } pspccpcmd_dma_status_q1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_dma_status_q1_t {
          unsigned int                                : 13;
          unsigned int dma_dstatus                    : PspCcpCmd_DMA_Status_Q1_DMA_Dstatus_SIZE;
          unsigned int dma_preads                     : PspCcpCmd_DMA_Status_Q1_DMA_Preads_SIZE;
          unsigned int dma_pwrites                    : PspCcpCmd_DMA_Status_Q1_DMA_Pwrites_SIZE;
     } pspccpcmd_dma_status_q1_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_dma_status_q1_t f;
} pspccpcmd_dma_status_q1_u;


/*
 * PspCcpCmd_DMA_Status_Q2 struct
 */

#define PspCcpCmd_DMA_Status_Q2_REG_SIZE 32
#define PspCcpCmd_DMA_Status_Q2_DMA_Pwrites_SIZE 10
#define PspCcpCmd_DMA_Status_Q2_DMA_Preads_SIZE 6
#define PspCcpCmd_DMA_Status_Q2_DMA_Dstatus_SIZE 3

#define PspCcpCmd_DMA_Status_Q2_DMA_Pwrites_SHIFT 0
#define PspCcpCmd_DMA_Status_Q2_DMA_Preads_SHIFT 10
#define PspCcpCmd_DMA_Status_Q2_DMA_Dstatus_SHIFT 16

#define PspCcpCmd_DMA_Status_Q2_DMA_Pwrites_MASK 0x3ff
#define PspCcpCmd_DMA_Status_Q2_DMA_Preads_MASK 0xfc00
#define PspCcpCmd_DMA_Status_Q2_DMA_Dstatus_MASK 0x70000

#define PspCcpCmd_DMA_Status_Q2_MASK \
     (PspCcpCmd_DMA_Status_Q2_DMA_Pwrites_MASK | \
      PspCcpCmd_DMA_Status_Q2_DMA_Preads_MASK | \
      PspCcpCmd_DMA_Status_Q2_DMA_Dstatus_MASK)

#define PspCcpCmd_DMA_Status_Q2_DEFAULT 0x00000000

#define PspCcpCmd_DMA_Status_Q2_GET_DMA_Pwrites(pspccpcmd_dma_status_q2) \
     ((pspccpcmd_dma_status_q2 & PspCcpCmd_DMA_Status_Q2_DMA_Pwrites_MASK) >> PspCcpCmd_DMA_Status_Q2_DMA_Pwrites_SHIFT)
#define PspCcpCmd_DMA_Status_Q2_GET_DMA_Preads(pspccpcmd_dma_status_q2) \
     ((pspccpcmd_dma_status_q2 & PspCcpCmd_DMA_Status_Q2_DMA_Preads_MASK) >> PspCcpCmd_DMA_Status_Q2_DMA_Preads_SHIFT)
#define PspCcpCmd_DMA_Status_Q2_GET_DMA_Dstatus(pspccpcmd_dma_status_q2) \
     ((pspccpcmd_dma_status_q2 & PspCcpCmd_DMA_Status_Q2_DMA_Dstatus_MASK) >> PspCcpCmd_DMA_Status_Q2_DMA_Dstatus_SHIFT)

#define PspCcpCmd_DMA_Status_Q2_SET_DMA_Pwrites(pspccpcmd_dma_status_q2_reg, dma_pwrites) \
     pspccpcmd_dma_status_q2_reg = (pspccpcmd_dma_status_q2_reg & ~PspCcpCmd_DMA_Status_Q2_DMA_Pwrites_MASK) | (dma_pwrites << PspCcpCmd_DMA_Status_Q2_DMA_Pwrites_SHIFT)
#define PspCcpCmd_DMA_Status_Q2_SET_DMA_Preads(pspccpcmd_dma_status_q2_reg, dma_preads) \
     pspccpcmd_dma_status_q2_reg = (pspccpcmd_dma_status_q2_reg & ~PspCcpCmd_DMA_Status_Q2_DMA_Preads_MASK) | (dma_preads << PspCcpCmd_DMA_Status_Q2_DMA_Preads_SHIFT)
#define PspCcpCmd_DMA_Status_Q2_SET_DMA_Dstatus(pspccpcmd_dma_status_q2_reg, dma_dstatus) \
     pspccpcmd_dma_status_q2_reg = (pspccpcmd_dma_status_q2_reg & ~PspCcpCmd_DMA_Status_Q2_DMA_Dstatus_MASK) | (dma_dstatus << PspCcpCmd_DMA_Status_Q2_DMA_Dstatus_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_dma_status_q2_t {
          unsigned int dma_pwrites                    : PspCcpCmd_DMA_Status_Q2_DMA_Pwrites_SIZE;
          unsigned int dma_preads                     : PspCcpCmd_DMA_Status_Q2_DMA_Preads_SIZE;
          unsigned int dma_dstatus                    : PspCcpCmd_DMA_Status_Q2_DMA_Dstatus_SIZE;
          unsigned int                                : 13;
     } pspccpcmd_dma_status_q2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_dma_status_q2_t {
          unsigned int                                : 13;
          unsigned int dma_dstatus                    : PspCcpCmd_DMA_Status_Q2_DMA_Dstatus_SIZE;
          unsigned int dma_preads                     : PspCcpCmd_DMA_Status_Q2_DMA_Preads_SIZE;
          unsigned int dma_pwrites                    : PspCcpCmd_DMA_Status_Q2_DMA_Pwrites_SIZE;
     } pspccpcmd_dma_status_q2_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_dma_status_q2_t f;
} pspccpcmd_dma_status_q2_u;


/*
 * PspCcpCmd_DMA_Read_Status_Q0 struct
 */

#define PspCcpCmd_DMA_Read_Status_Q0_REG_SIZE 32
#define PspCcpCmd_DMA_Read_Status_Q0_DMA_BytesRead_SIZE 32

#define PspCcpCmd_DMA_Read_Status_Q0_DMA_BytesRead_SHIFT 0

#define PspCcpCmd_DMA_Read_Status_Q0_DMA_BytesRead_MASK 0xffffffff

#define PspCcpCmd_DMA_Read_Status_Q0_MASK \
     (PspCcpCmd_DMA_Read_Status_Q0_DMA_BytesRead_MASK)

#define PspCcpCmd_DMA_Read_Status_Q0_DEFAULT 0x00000000

#define PspCcpCmd_DMA_Read_Status_Q0_GET_DMA_BytesRead(pspccpcmd_dma_read_status_q0) \
     ((pspccpcmd_dma_read_status_q0 & PspCcpCmd_DMA_Read_Status_Q0_DMA_BytesRead_MASK) >> PspCcpCmd_DMA_Read_Status_Q0_DMA_BytesRead_SHIFT)

#define PspCcpCmd_DMA_Read_Status_Q0_SET_DMA_BytesRead(pspccpcmd_dma_read_status_q0_reg, dma_bytesread) \
     pspccpcmd_dma_read_status_q0_reg = (pspccpcmd_dma_read_status_q0_reg & ~PspCcpCmd_DMA_Read_Status_Q0_DMA_BytesRead_MASK) | (dma_bytesread << PspCcpCmd_DMA_Read_Status_Q0_DMA_BytesRead_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_dma_read_status_q0_t {
          unsigned int dma_bytesread                  : PspCcpCmd_DMA_Read_Status_Q0_DMA_BytesRead_SIZE;
     } pspccpcmd_dma_read_status_q0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_dma_read_status_q0_t {
          unsigned int dma_bytesread                  : PspCcpCmd_DMA_Read_Status_Q0_DMA_BytesRead_SIZE;
     } pspccpcmd_dma_read_status_q0_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_dma_read_status_q0_t f;
} pspccpcmd_dma_read_status_q0_u;


/*
 * PspCcpCmd_DMA_Read_Status_Q1 struct
 */

#define PspCcpCmd_DMA_Read_Status_Q1_REG_SIZE 32
#define PspCcpCmd_DMA_Read_Status_Q1_DMA_BytesRead_SIZE 32

#define PspCcpCmd_DMA_Read_Status_Q1_DMA_BytesRead_SHIFT 0

#define PspCcpCmd_DMA_Read_Status_Q1_DMA_BytesRead_MASK 0xffffffff

#define PspCcpCmd_DMA_Read_Status_Q1_MASK \
     (PspCcpCmd_DMA_Read_Status_Q1_DMA_BytesRead_MASK)

#define PspCcpCmd_DMA_Read_Status_Q1_DEFAULT 0x00000000

#define PspCcpCmd_DMA_Read_Status_Q1_GET_DMA_BytesRead(pspccpcmd_dma_read_status_q1) \
     ((pspccpcmd_dma_read_status_q1 & PspCcpCmd_DMA_Read_Status_Q1_DMA_BytesRead_MASK) >> PspCcpCmd_DMA_Read_Status_Q1_DMA_BytesRead_SHIFT)

#define PspCcpCmd_DMA_Read_Status_Q1_SET_DMA_BytesRead(pspccpcmd_dma_read_status_q1_reg, dma_bytesread) \
     pspccpcmd_dma_read_status_q1_reg = (pspccpcmd_dma_read_status_q1_reg & ~PspCcpCmd_DMA_Read_Status_Q1_DMA_BytesRead_MASK) | (dma_bytesread << PspCcpCmd_DMA_Read_Status_Q1_DMA_BytesRead_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_dma_read_status_q1_t {
          unsigned int dma_bytesread                  : PspCcpCmd_DMA_Read_Status_Q1_DMA_BytesRead_SIZE;
     } pspccpcmd_dma_read_status_q1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_dma_read_status_q1_t {
          unsigned int dma_bytesread                  : PspCcpCmd_DMA_Read_Status_Q1_DMA_BytesRead_SIZE;
     } pspccpcmd_dma_read_status_q1_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_dma_read_status_q1_t f;
} pspccpcmd_dma_read_status_q1_u;


/*
 * PspCcpCmd_DMA_Read_Status_Q2 struct
 */

#define PspCcpCmd_DMA_Read_Status_Q2_REG_SIZE 32
#define PspCcpCmd_DMA_Read_Status_Q2_DMA_BytesRead_SIZE 32

#define PspCcpCmd_DMA_Read_Status_Q2_DMA_BytesRead_SHIFT 0

#define PspCcpCmd_DMA_Read_Status_Q2_DMA_BytesRead_MASK 0xffffffff

#define PspCcpCmd_DMA_Read_Status_Q2_MASK \
     (PspCcpCmd_DMA_Read_Status_Q2_DMA_BytesRead_MASK)

#define PspCcpCmd_DMA_Read_Status_Q2_DEFAULT 0x00000000

#define PspCcpCmd_DMA_Read_Status_Q2_GET_DMA_BytesRead(pspccpcmd_dma_read_status_q2) \
     ((pspccpcmd_dma_read_status_q2 & PspCcpCmd_DMA_Read_Status_Q2_DMA_BytesRead_MASK) >> PspCcpCmd_DMA_Read_Status_Q2_DMA_BytesRead_SHIFT)

#define PspCcpCmd_DMA_Read_Status_Q2_SET_DMA_BytesRead(pspccpcmd_dma_read_status_q2_reg, dma_bytesread) \
     pspccpcmd_dma_read_status_q2_reg = (pspccpcmd_dma_read_status_q2_reg & ~PspCcpCmd_DMA_Read_Status_Q2_DMA_BytesRead_MASK) | (dma_bytesread << PspCcpCmd_DMA_Read_Status_Q2_DMA_BytesRead_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_dma_read_status_q2_t {
          unsigned int dma_bytesread                  : PspCcpCmd_DMA_Read_Status_Q2_DMA_BytesRead_SIZE;
     } pspccpcmd_dma_read_status_q2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_dma_read_status_q2_t {
          unsigned int dma_bytesread                  : PspCcpCmd_DMA_Read_Status_Q2_DMA_BytesRead_SIZE;
     } pspccpcmd_dma_read_status_q2_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_dma_read_status_q2_t f;
} pspccpcmd_dma_read_status_q2_u;


/*
 * PspCcpCmd_DMA_Write_Status_Q0 struct
 */

#define PspCcpCmd_DMA_Write_Status_Q0_REG_SIZE 32
#define PspCcpCmd_DMA_Write_Status_Q0_DMA_BytesWritten_SIZE 32

#define PspCcpCmd_DMA_Write_Status_Q0_DMA_BytesWritten_SHIFT 0

#define PspCcpCmd_DMA_Write_Status_Q0_DMA_BytesWritten_MASK 0xffffffff

#define PspCcpCmd_DMA_Write_Status_Q0_MASK \
     (PspCcpCmd_DMA_Write_Status_Q0_DMA_BytesWritten_MASK)

#define PspCcpCmd_DMA_Write_Status_Q0_DEFAULT 0x00000000

#define PspCcpCmd_DMA_Write_Status_Q0_GET_DMA_BytesWritten(pspccpcmd_dma_write_status_q0) \
     ((pspccpcmd_dma_write_status_q0 & PspCcpCmd_DMA_Write_Status_Q0_DMA_BytesWritten_MASK) >> PspCcpCmd_DMA_Write_Status_Q0_DMA_BytesWritten_SHIFT)

#define PspCcpCmd_DMA_Write_Status_Q0_SET_DMA_BytesWritten(pspccpcmd_dma_write_status_q0_reg, dma_byteswritten) \
     pspccpcmd_dma_write_status_q0_reg = (pspccpcmd_dma_write_status_q0_reg & ~PspCcpCmd_DMA_Write_Status_Q0_DMA_BytesWritten_MASK) | (dma_byteswritten << PspCcpCmd_DMA_Write_Status_Q0_DMA_BytesWritten_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_dma_write_status_q0_t {
          unsigned int dma_byteswritten               : PspCcpCmd_DMA_Write_Status_Q0_DMA_BytesWritten_SIZE;
     } pspccpcmd_dma_write_status_q0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_dma_write_status_q0_t {
          unsigned int dma_byteswritten               : PspCcpCmd_DMA_Write_Status_Q0_DMA_BytesWritten_SIZE;
     } pspccpcmd_dma_write_status_q0_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_dma_write_status_q0_t f;
} pspccpcmd_dma_write_status_q0_u;


/*
 * PspCcpCmd_DMA_Write_Status_Q1 struct
 */

#define PspCcpCmd_DMA_Write_Status_Q1_REG_SIZE 32
#define PspCcpCmd_DMA_Write_Status_Q1_DMA_BytesWritten_SIZE 32

#define PspCcpCmd_DMA_Write_Status_Q1_DMA_BytesWritten_SHIFT 0

#define PspCcpCmd_DMA_Write_Status_Q1_DMA_BytesWritten_MASK 0xffffffff

#define PspCcpCmd_DMA_Write_Status_Q1_MASK \
     (PspCcpCmd_DMA_Write_Status_Q1_DMA_BytesWritten_MASK)

#define PspCcpCmd_DMA_Write_Status_Q1_DEFAULT 0x00000000

#define PspCcpCmd_DMA_Write_Status_Q1_GET_DMA_BytesWritten(pspccpcmd_dma_write_status_q1) \
     ((pspccpcmd_dma_write_status_q1 & PspCcpCmd_DMA_Write_Status_Q1_DMA_BytesWritten_MASK) >> PspCcpCmd_DMA_Write_Status_Q1_DMA_BytesWritten_SHIFT)

#define PspCcpCmd_DMA_Write_Status_Q1_SET_DMA_BytesWritten(pspccpcmd_dma_write_status_q1_reg, dma_byteswritten) \
     pspccpcmd_dma_write_status_q1_reg = (pspccpcmd_dma_write_status_q1_reg & ~PspCcpCmd_DMA_Write_Status_Q1_DMA_BytesWritten_MASK) | (dma_byteswritten << PspCcpCmd_DMA_Write_Status_Q1_DMA_BytesWritten_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_dma_write_status_q1_t {
          unsigned int dma_byteswritten               : PspCcpCmd_DMA_Write_Status_Q1_DMA_BytesWritten_SIZE;
     } pspccpcmd_dma_write_status_q1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_dma_write_status_q1_t {
          unsigned int dma_byteswritten               : PspCcpCmd_DMA_Write_Status_Q1_DMA_BytesWritten_SIZE;
     } pspccpcmd_dma_write_status_q1_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_dma_write_status_q1_t f;
} pspccpcmd_dma_write_status_q1_u;


/*
 * PspCcpCmd_DMA_Write_Status_Q2 struct
 */

#define PspCcpCmd_DMA_Write_Status_Q2_REG_SIZE 32
#define PspCcpCmd_DMA_Write_Status_Q2_DMA_BytesWritten_SIZE 32

#define PspCcpCmd_DMA_Write_Status_Q2_DMA_BytesWritten_SHIFT 0

#define PspCcpCmd_DMA_Write_Status_Q2_DMA_BytesWritten_MASK 0xffffffff

#define PspCcpCmd_DMA_Write_Status_Q2_MASK \
     (PspCcpCmd_DMA_Write_Status_Q2_DMA_BytesWritten_MASK)

#define PspCcpCmd_DMA_Write_Status_Q2_DEFAULT 0x00000000

#define PspCcpCmd_DMA_Write_Status_Q2_GET_DMA_BytesWritten(pspccpcmd_dma_write_status_q2) \
     ((pspccpcmd_dma_write_status_q2 & PspCcpCmd_DMA_Write_Status_Q2_DMA_BytesWritten_MASK) >> PspCcpCmd_DMA_Write_Status_Q2_DMA_BytesWritten_SHIFT)

#define PspCcpCmd_DMA_Write_Status_Q2_SET_DMA_BytesWritten(pspccpcmd_dma_write_status_q2_reg, dma_byteswritten) \
     pspccpcmd_dma_write_status_q2_reg = (pspccpcmd_dma_write_status_q2_reg & ~PspCcpCmd_DMA_Write_Status_Q2_DMA_BytesWritten_MASK) | (dma_byteswritten << PspCcpCmd_DMA_Write_Status_Q2_DMA_BytesWritten_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_dma_write_status_q2_t {
          unsigned int dma_byteswritten               : PspCcpCmd_DMA_Write_Status_Q2_DMA_BytesWritten_SIZE;
     } pspccpcmd_dma_write_status_q2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_dma_write_status_q2_t {
          unsigned int dma_byteswritten               : PspCcpCmd_DMA_Write_Status_Q2_DMA_BytesWritten_SIZE;
     } pspccpcmd_dma_write_status_q2_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_dma_write_status_q2_t f;
} pspccpcmd_dma_write_status_q2_u;


/*
 * PspCcpCmd_Abort_Q0 struct
 */

#define PspCcpCmd_Abort_Q0_REG_SIZE    32
#define PspCcpCmd_Abort_Q0_RI_Offset_SIZE 18
#define PspCcpCmd_Abort_Q0_RI_Offset_Valid_SIZE 1

#define PspCcpCmd_Abort_Q0_RI_Offset_SHIFT 0
#define PspCcpCmd_Abort_Q0_RI_Offset_Valid_SHIFT 31

#define PspCcpCmd_Abort_Q0_RI_Offset_MASK 0x3ffff
#define PspCcpCmd_Abort_Q0_RI_Offset_Valid_MASK 0x80000000

#define PspCcpCmd_Abort_Q0_MASK \
     (PspCcpCmd_Abort_Q0_RI_Offset_MASK | \
      PspCcpCmd_Abort_Q0_RI_Offset_Valid_MASK)

#define PspCcpCmd_Abort_Q0_DEFAULT     0x00000000

#define PspCcpCmd_Abort_Q0_GET_RI_Offset(pspccpcmd_abort_q0) \
     ((pspccpcmd_abort_q0 & PspCcpCmd_Abort_Q0_RI_Offset_MASK) >> PspCcpCmd_Abort_Q0_RI_Offset_SHIFT)
#define PspCcpCmd_Abort_Q0_GET_RI_Offset_Valid(pspccpcmd_abort_q0) \
     ((pspccpcmd_abort_q0 & PspCcpCmd_Abort_Q0_RI_Offset_Valid_MASK) >> PspCcpCmd_Abort_Q0_RI_Offset_Valid_SHIFT)

#define PspCcpCmd_Abort_Q0_SET_RI_Offset(pspccpcmd_abort_q0_reg, ri_offset) \
     pspccpcmd_abort_q0_reg = (pspccpcmd_abort_q0_reg & ~PspCcpCmd_Abort_Q0_RI_Offset_MASK) | (ri_offset << PspCcpCmd_Abort_Q0_RI_Offset_SHIFT)
#define PspCcpCmd_Abort_Q0_SET_RI_Offset_Valid(pspccpcmd_abort_q0_reg, ri_offset_valid) \
     pspccpcmd_abort_q0_reg = (pspccpcmd_abort_q0_reg & ~PspCcpCmd_Abort_Q0_RI_Offset_Valid_MASK) | (ri_offset_valid << PspCcpCmd_Abort_Q0_RI_Offset_Valid_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_abort_q0_t {
          unsigned int ri_offset                      : PspCcpCmd_Abort_Q0_RI_Offset_SIZE;
          unsigned int                                : 13;
          unsigned int ri_offset_valid                : PspCcpCmd_Abort_Q0_RI_Offset_Valid_SIZE;
     } pspccpcmd_abort_q0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_abort_q0_t {
          unsigned int ri_offset_valid                : PspCcpCmd_Abort_Q0_RI_Offset_Valid_SIZE;
          unsigned int                                : 13;
          unsigned int ri_offset                      : PspCcpCmd_Abort_Q0_RI_Offset_SIZE;
     } pspccpcmd_abort_q0_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_abort_q0_t f;
} pspccpcmd_abort_q0_u;


/*
 * PspCcpCmd_Abort_Q1 struct
 */

#define PspCcpCmd_Abort_Q1_REG_SIZE    32
#define PspCcpCmd_Abort_Q1_RI_Offset_SIZE 18
#define PspCcpCmd_Abort_Q1_RI_Offset_Valid_SIZE 1

#define PspCcpCmd_Abort_Q1_RI_Offset_SHIFT 0
#define PspCcpCmd_Abort_Q1_RI_Offset_Valid_SHIFT 31

#define PspCcpCmd_Abort_Q1_RI_Offset_MASK 0x3ffff
#define PspCcpCmd_Abort_Q1_RI_Offset_Valid_MASK 0x80000000

#define PspCcpCmd_Abort_Q1_MASK \
     (PspCcpCmd_Abort_Q1_RI_Offset_MASK | \
      PspCcpCmd_Abort_Q1_RI_Offset_Valid_MASK)

#define PspCcpCmd_Abort_Q1_DEFAULT     0x00000000

#define PspCcpCmd_Abort_Q1_GET_RI_Offset(pspccpcmd_abort_q1) \
     ((pspccpcmd_abort_q1 & PspCcpCmd_Abort_Q1_RI_Offset_MASK) >> PspCcpCmd_Abort_Q1_RI_Offset_SHIFT)
#define PspCcpCmd_Abort_Q1_GET_RI_Offset_Valid(pspccpcmd_abort_q1) \
     ((pspccpcmd_abort_q1 & PspCcpCmd_Abort_Q1_RI_Offset_Valid_MASK) >> PspCcpCmd_Abort_Q1_RI_Offset_Valid_SHIFT)

#define PspCcpCmd_Abort_Q1_SET_RI_Offset(pspccpcmd_abort_q1_reg, ri_offset) \
     pspccpcmd_abort_q1_reg = (pspccpcmd_abort_q1_reg & ~PspCcpCmd_Abort_Q1_RI_Offset_MASK) | (ri_offset << PspCcpCmd_Abort_Q1_RI_Offset_SHIFT)
#define PspCcpCmd_Abort_Q1_SET_RI_Offset_Valid(pspccpcmd_abort_q1_reg, ri_offset_valid) \
     pspccpcmd_abort_q1_reg = (pspccpcmd_abort_q1_reg & ~PspCcpCmd_Abort_Q1_RI_Offset_Valid_MASK) | (ri_offset_valid << PspCcpCmd_Abort_Q1_RI_Offset_Valid_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_abort_q1_t {
          unsigned int ri_offset                      : PspCcpCmd_Abort_Q1_RI_Offset_SIZE;
          unsigned int                                : 13;
          unsigned int ri_offset_valid                : PspCcpCmd_Abort_Q1_RI_Offset_Valid_SIZE;
     } pspccpcmd_abort_q1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_abort_q1_t {
          unsigned int ri_offset_valid                : PspCcpCmd_Abort_Q1_RI_Offset_Valid_SIZE;
          unsigned int                                : 13;
          unsigned int ri_offset                      : PspCcpCmd_Abort_Q1_RI_Offset_SIZE;
     } pspccpcmd_abort_q1_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_abort_q1_t f;
} pspccpcmd_abort_q1_u;


/*
 * PspCcpCmd_Abort_Q2 struct
 */

#define PspCcpCmd_Abort_Q2_REG_SIZE    32
#define PspCcpCmd_Abort_Q2_RI_Offset_SIZE 18
#define PspCcpCmd_Abort_Q2_RI_Offset_Valid_SIZE 1

#define PspCcpCmd_Abort_Q2_RI_Offset_SHIFT 0
#define PspCcpCmd_Abort_Q2_RI_Offset_Valid_SHIFT 31

#define PspCcpCmd_Abort_Q2_RI_Offset_MASK 0x3ffff
#define PspCcpCmd_Abort_Q2_RI_Offset_Valid_MASK 0x80000000

#define PspCcpCmd_Abort_Q2_MASK \
     (PspCcpCmd_Abort_Q2_RI_Offset_MASK | \
      PspCcpCmd_Abort_Q2_RI_Offset_Valid_MASK)

#define PspCcpCmd_Abort_Q2_DEFAULT     0x00000000

#define PspCcpCmd_Abort_Q2_GET_RI_Offset(pspccpcmd_abort_q2) \
     ((pspccpcmd_abort_q2 & PspCcpCmd_Abort_Q2_RI_Offset_MASK) >> PspCcpCmd_Abort_Q2_RI_Offset_SHIFT)
#define PspCcpCmd_Abort_Q2_GET_RI_Offset_Valid(pspccpcmd_abort_q2) \
     ((pspccpcmd_abort_q2 & PspCcpCmd_Abort_Q2_RI_Offset_Valid_MASK) >> PspCcpCmd_Abort_Q2_RI_Offset_Valid_SHIFT)

#define PspCcpCmd_Abort_Q2_SET_RI_Offset(pspccpcmd_abort_q2_reg, ri_offset) \
     pspccpcmd_abort_q2_reg = (pspccpcmd_abort_q2_reg & ~PspCcpCmd_Abort_Q2_RI_Offset_MASK) | (ri_offset << PspCcpCmd_Abort_Q2_RI_Offset_SHIFT)
#define PspCcpCmd_Abort_Q2_SET_RI_Offset_Valid(pspccpcmd_abort_q2_reg, ri_offset_valid) \
     pspccpcmd_abort_q2_reg = (pspccpcmd_abort_q2_reg & ~PspCcpCmd_Abort_Q2_RI_Offset_Valid_MASK) | (ri_offset_valid << PspCcpCmd_Abort_Q2_RI_Offset_Valid_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_abort_q2_t {
          unsigned int ri_offset                      : PspCcpCmd_Abort_Q2_RI_Offset_SIZE;
          unsigned int                                : 13;
          unsigned int ri_offset_valid                : PspCcpCmd_Abort_Q2_RI_Offset_Valid_SIZE;
     } pspccpcmd_abort_q2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_abort_q2_t {
          unsigned int ri_offset_valid                : PspCcpCmd_Abort_Q2_RI_Offset_Valid_SIZE;
          unsigned int                                : 13;
          unsigned int ri_offset                      : PspCcpCmd_Abort_Q2_RI_Offset_SIZE;
     } pspccpcmd_abort_q2_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_abort_q2_t f;
} pspccpcmd_abort_q2_u;


/*
 * PspCcpCmd_AxCACHE_Q0 struct
 */

#define PspCcpCmd_AxCACHE_Q0_REG_SIZE  32
#define PspCcpCmd_AxCACHE_Q0_RI_AWCACHE_SIZE 4
#define PspCcpCmd_AxCACHE_Q0_RI_ARCACHE_SIZE 4
#define PspCcpCmd_AxCACHE_Q0_RI_VCD_ARCACHE_SIZE 4

#define PspCcpCmd_AxCACHE_Q0_RI_AWCACHE_SHIFT 0
#define PspCcpCmd_AxCACHE_Q0_RI_ARCACHE_SHIFT 4
#define PspCcpCmd_AxCACHE_Q0_RI_VCD_ARCACHE_SHIFT 8

#define PspCcpCmd_AxCACHE_Q0_RI_AWCACHE_MASK 0xf
#define PspCcpCmd_AxCACHE_Q0_RI_ARCACHE_MASK 0xf0
#define PspCcpCmd_AxCACHE_Q0_RI_VCD_ARCACHE_MASK 0xf00

#define PspCcpCmd_AxCACHE_Q0_MASK \
     (PspCcpCmd_AxCACHE_Q0_RI_AWCACHE_MASK | \
      PspCcpCmd_AxCACHE_Q0_RI_ARCACHE_MASK | \
      PspCcpCmd_AxCACHE_Q0_RI_VCD_ARCACHE_MASK)

#define PspCcpCmd_AxCACHE_Q0_DEFAULT   0x00000000

#define PspCcpCmd_AxCACHE_Q0_GET_RI_AWCACHE(pspccpcmd_axcache_q0) \
     ((pspccpcmd_axcache_q0 & PspCcpCmd_AxCACHE_Q0_RI_AWCACHE_MASK) >> PspCcpCmd_AxCACHE_Q0_RI_AWCACHE_SHIFT)
#define PspCcpCmd_AxCACHE_Q0_GET_RI_ARCACHE(pspccpcmd_axcache_q0) \
     ((pspccpcmd_axcache_q0 & PspCcpCmd_AxCACHE_Q0_RI_ARCACHE_MASK) >> PspCcpCmd_AxCACHE_Q0_RI_ARCACHE_SHIFT)
#define PspCcpCmd_AxCACHE_Q0_GET_RI_VCD_ARCACHE(pspccpcmd_axcache_q0) \
     ((pspccpcmd_axcache_q0 & PspCcpCmd_AxCACHE_Q0_RI_VCD_ARCACHE_MASK) >> PspCcpCmd_AxCACHE_Q0_RI_VCD_ARCACHE_SHIFT)

#define PspCcpCmd_AxCACHE_Q0_SET_RI_AWCACHE(pspccpcmd_axcache_q0_reg, ri_awcache) \
     pspccpcmd_axcache_q0_reg = (pspccpcmd_axcache_q0_reg & ~PspCcpCmd_AxCACHE_Q0_RI_AWCACHE_MASK) | (ri_awcache << PspCcpCmd_AxCACHE_Q0_RI_AWCACHE_SHIFT)
#define PspCcpCmd_AxCACHE_Q0_SET_RI_ARCACHE(pspccpcmd_axcache_q0_reg, ri_arcache) \
     pspccpcmd_axcache_q0_reg = (pspccpcmd_axcache_q0_reg & ~PspCcpCmd_AxCACHE_Q0_RI_ARCACHE_MASK) | (ri_arcache << PspCcpCmd_AxCACHE_Q0_RI_ARCACHE_SHIFT)
#define PspCcpCmd_AxCACHE_Q0_SET_RI_VCD_ARCACHE(pspccpcmd_axcache_q0_reg, ri_vcd_arcache) \
     pspccpcmd_axcache_q0_reg = (pspccpcmd_axcache_q0_reg & ~PspCcpCmd_AxCACHE_Q0_RI_VCD_ARCACHE_MASK) | (ri_vcd_arcache << PspCcpCmd_AxCACHE_Q0_RI_VCD_ARCACHE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_axcache_q0_t {
          unsigned int ri_awcache                     : PspCcpCmd_AxCACHE_Q0_RI_AWCACHE_SIZE;
          unsigned int ri_arcache                     : PspCcpCmd_AxCACHE_Q0_RI_ARCACHE_SIZE;
          unsigned int ri_vcd_arcache                 : PspCcpCmd_AxCACHE_Q0_RI_VCD_ARCACHE_SIZE;
          unsigned int                                : 20;
     } pspccpcmd_axcache_q0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_axcache_q0_t {
          unsigned int                                : 20;
          unsigned int ri_vcd_arcache                 : PspCcpCmd_AxCACHE_Q0_RI_VCD_ARCACHE_SIZE;
          unsigned int ri_arcache                     : PspCcpCmd_AxCACHE_Q0_RI_ARCACHE_SIZE;
          unsigned int ri_awcache                     : PspCcpCmd_AxCACHE_Q0_RI_AWCACHE_SIZE;
     } pspccpcmd_axcache_q0_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_axcache_q0_t f;
} pspccpcmd_axcache_q0_u;


/*
 * PspCcpCmd_AxCACHE_Q1 struct
 */

#define PspCcpCmd_AxCACHE_Q1_REG_SIZE  32
#define PspCcpCmd_AxCACHE_Q1_RI_AWCACHE_SIZE 4
#define PspCcpCmd_AxCACHE_Q1_RI_ARCACHE_SIZE 4
#define PspCcpCmd_AxCACHE_Q1_RI_VCD_ARCACHE_SIZE 4

#define PspCcpCmd_AxCACHE_Q1_RI_AWCACHE_SHIFT 0
#define PspCcpCmd_AxCACHE_Q1_RI_ARCACHE_SHIFT 4
#define PspCcpCmd_AxCACHE_Q1_RI_VCD_ARCACHE_SHIFT 8

#define PspCcpCmd_AxCACHE_Q1_RI_AWCACHE_MASK 0xf
#define PspCcpCmd_AxCACHE_Q1_RI_ARCACHE_MASK 0xf0
#define PspCcpCmd_AxCACHE_Q1_RI_VCD_ARCACHE_MASK 0xf00

#define PspCcpCmd_AxCACHE_Q1_MASK \
     (PspCcpCmd_AxCACHE_Q1_RI_AWCACHE_MASK | \
      PspCcpCmd_AxCACHE_Q1_RI_ARCACHE_MASK | \
      PspCcpCmd_AxCACHE_Q1_RI_VCD_ARCACHE_MASK)

#define PspCcpCmd_AxCACHE_Q1_DEFAULT   0x00000000

#define PspCcpCmd_AxCACHE_Q1_GET_RI_AWCACHE(pspccpcmd_axcache_q1) \
     ((pspccpcmd_axcache_q1 & PspCcpCmd_AxCACHE_Q1_RI_AWCACHE_MASK) >> PspCcpCmd_AxCACHE_Q1_RI_AWCACHE_SHIFT)
#define PspCcpCmd_AxCACHE_Q1_GET_RI_ARCACHE(pspccpcmd_axcache_q1) \
     ((pspccpcmd_axcache_q1 & PspCcpCmd_AxCACHE_Q1_RI_ARCACHE_MASK) >> PspCcpCmd_AxCACHE_Q1_RI_ARCACHE_SHIFT)
#define PspCcpCmd_AxCACHE_Q1_GET_RI_VCD_ARCACHE(pspccpcmd_axcache_q1) \
     ((pspccpcmd_axcache_q1 & PspCcpCmd_AxCACHE_Q1_RI_VCD_ARCACHE_MASK) >> PspCcpCmd_AxCACHE_Q1_RI_VCD_ARCACHE_SHIFT)

#define PspCcpCmd_AxCACHE_Q1_SET_RI_AWCACHE(pspccpcmd_axcache_q1_reg, ri_awcache) \
     pspccpcmd_axcache_q1_reg = (pspccpcmd_axcache_q1_reg & ~PspCcpCmd_AxCACHE_Q1_RI_AWCACHE_MASK) | (ri_awcache << PspCcpCmd_AxCACHE_Q1_RI_AWCACHE_SHIFT)
#define PspCcpCmd_AxCACHE_Q1_SET_RI_ARCACHE(pspccpcmd_axcache_q1_reg, ri_arcache) \
     pspccpcmd_axcache_q1_reg = (pspccpcmd_axcache_q1_reg & ~PspCcpCmd_AxCACHE_Q1_RI_ARCACHE_MASK) | (ri_arcache << PspCcpCmd_AxCACHE_Q1_RI_ARCACHE_SHIFT)
#define PspCcpCmd_AxCACHE_Q1_SET_RI_VCD_ARCACHE(pspccpcmd_axcache_q1_reg, ri_vcd_arcache) \
     pspccpcmd_axcache_q1_reg = (pspccpcmd_axcache_q1_reg & ~PspCcpCmd_AxCACHE_Q1_RI_VCD_ARCACHE_MASK) | (ri_vcd_arcache << PspCcpCmd_AxCACHE_Q1_RI_VCD_ARCACHE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_axcache_q1_t {
          unsigned int ri_awcache                     : PspCcpCmd_AxCACHE_Q1_RI_AWCACHE_SIZE;
          unsigned int ri_arcache                     : PspCcpCmd_AxCACHE_Q1_RI_ARCACHE_SIZE;
          unsigned int ri_vcd_arcache                 : PspCcpCmd_AxCACHE_Q1_RI_VCD_ARCACHE_SIZE;
          unsigned int                                : 20;
     } pspccpcmd_axcache_q1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_axcache_q1_t {
          unsigned int                                : 20;
          unsigned int ri_vcd_arcache                 : PspCcpCmd_AxCACHE_Q1_RI_VCD_ARCACHE_SIZE;
          unsigned int ri_arcache                     : PspCcpCmd_AxCACHE_Q1_RI_ARCACHE_SIZE;
          unsigned int ri_awcache                     : PspCcpCmd_AxCACHE_Q1_RI_AWCACHE_SIZE;
     } pspccpcmd_axcache_q1_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_axcache_q1_t f;
} pspccpcmd_axcache_q1_u;


/*
 * PspCcpCmd_AxCACHE_Q2 struct
 */

#define PspCcpCmd_AxCACHE_Q2_REG_SIZE  32
#define PspCcpCmd_AxCACHE_Q2_RI_AWCACHE_SIZE 4
#define PspCcpCmd_AxCACHE_Q2_RI_ARCACHE_SIZE 4
#define PspCcpCmd_AxCACHE_Q2_RI_VCD_ARCACHE_SIZE 4

#define PspCcpCmd_AxCACHE_Q2_RI_AWCACHE_SHIFT 0
#define PspCcpCmd_AxCACHE_Q2_RI_ARCACHE_SHIFT 4
#define PspCcpCmd_AxCACHE_Q2_RI_VCD_ARCACHE_SHIFT 8

#define PspCcpCmd_AxCACHE_Q2_RI_AWCACHE_MASK 0xf
#define PspCcpCmd_AxCACHE_Q2_RI_ARCACHE_MASK 0xf0
#define PspCcpCmd_AxCACHE_Q2_RI_VCD_ARCACHE_MASK 0xf00

#define PspCcpCmd_AxCACHE_Q2_MASK \
     (PspCcpCmd_AxCACHE_Q2_RI_AWCACHE_MASK | \
      PspCcpCmd_AxCACHE_Q2_RI_ARCACHE_MASK | \
      PspCcpCmd_AxCACHE_Q2_RI_VCD_ARCACHE_MASK)

#define PspCcpCmd_AxCACHE_Q2_DEFAULT   0x00000000

#define PspCcpCmd_AxCACHE_Q2_GET_RI_AWCACHE(pspccpcmd_axcache_q2) \
     ((pspccpcmd_axcache_q2 & PspCcpCmd_AxCACHE_Q2_RI_AWCACHE_MASK) >> PspCcpCmd_AxCACHE_Q2_RI_AWCACHE_SHIFT)
#define PspCcpCmd_AxCACHE_Q2_GET_RI_ARCACHE(pspccpcmd_axcache_q2) \
     ((pspccpcmd_axcache_q2 & PspCcpCmd_AxCACHE_Q2_RI_ARCACHE_MASK) >> PspCcpCmd_AxCACHE_Q2_RI_ARCACHE_SHIFT)
#define PspCcpCmd_AxCACHE_Q2_GET_RI_VCD_ARCACHE(pspccpcmd_axcache_q2) \
     ((pspccpcmd_axcache_q2 & PspCcpCmd_AxCACHE_Q2_RI_VCD_ARCACHE_MASK) >> PspCcpCmd_AxCACHE_Q2_RI_VCD_ARCACHE_SHIFT)

#define PspCcpCmd_AxCACHE_Q2_SET_RI_AWCACHE(pspccpcmd_axcache_q2_reg, ri_awcache) \
     pspccpcmd_axcache_q2_reg = (pspccpcmd_axcache_q2_reg & ~PspCcpCmd_AxCACHE_Q2_RI_AWCACHE_MASK) | (ri_awcache << PspCcpCmd_AxCACHE_Q2_RI_AWCACHE_SHIFT)
#define PspCcpCmd_AxCACHE_Q2_SET_RI_ARCACHE(pspccpcmd_axcache_q2_reg, ri_arcache) \
     pspccpcmd_axcache_q2_reg = (pspccpcmd_axcache_q2_reg & ~PspCcpCmd_AxCACHE_Q2_RI_ARCACHE_MASK) | (ri_arcache << PspCcpCmd_AxCACHE_Q2_RI_ARCACHE_SHIFT)
#define PspCcpCmd_AxCACHE_Q2_SET_RI_VCD_ARCACHE(pspccpcmd_axcache_q2_reg, ri_vcd_arcache) \
     pspccpcmd_axcache_q2_reg = (pspccpcmd_axcache_q2_reg & ~PspCcpCmd_AxCACHE_Q2_RI_VCD_ARCACHE_MASK) | (ri_vcd_arcache << PspCcpCmd_AxCACHE_Q2_RI_VCD_ARCACHE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_axcache_q2_t {
          unsigned int ri_awcache                     : PspCcpCmd_AxCACHE_Q2_RI_AWCACHE_SIZE;
          unsigned int ri_arcache                     : PspCcpCmd_AxCACHE_Q2_RI_ARCACHE_SIZE;
          unsigned int ri_vcd_arcache                 : PspCcpCmd_AxCACHE_Q2_RI_VCD_ARCACHE_SIZE;
          unsigned int                                : 20;
     } pspccpcmd_axcache_q2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_axcache_q2_t {
          unsigned int                                : 20;
          unsigned int ri_vcd_arcache                 : PspCcpCmd_AxCACHE_Q2_RI_VCD_ARCACHE_SIZE;
          unsigned int ri_arcache                     : PspCcpCmd_AxCACHE_Q2_RI_ARCACHE_SIZE;
          unsigned int ri_awcache                     : PspCcpCmd_AxCACHE_Q2_RI_AWCACHE_SIZE;
     } pspccpcmd_axcache_q2_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_axcache_q2_t f;
} pspccpcmd_axcache_q2_u;


/*
 * PspCcpCmd_WFQ_Command_ID_Q0 struct
 */

#define PspCcpCmd_WFQ_Command_ID_Q0_REG_SIZE 32
#define PspCcpCmd_WFQ_Command_ID_Q0_WFQ_Command_ID_SIZE 16

#define PspCcpCmd_WFQ_Command_ID_Q0_WFQ_Command_ID_SHIFT 0

#define PspCcpCmd_WFQ_Command_ID_Q0_WFQ_Command_ID_MASK 0xffff

#define PspCcpCmd_WFQ_Command_ID_Q0_MASK \
     (PspCcpCmd_WFQ_Command_ID_Q0_WFQ_Command_ID_MASK)

#define PspCcpCmd_WFQ_Command_ID_Q0_DEFAULT 0x00000000

#define PspCcpCmd_WFQ_Command_ID_Q0_GET_WFQ_Command_ID(pspccpcmd_wfq_command_id_q0) \
     ((pspccpcmd_wfq_command_id_q0 & PspCcpCmd_WFQ_Command_ID_Q0_WFQ_Command_ID_MASK) >> PspCcpCmd_WFQ_Command_ID_Q0_WFQ_Command_ID_SHIFT)

#define PspCcpCmd_WFQ_Command_ID_Q0_SET_WFQ_Command_ID(pspccpcmd_wfq_command_id_q0_reg, wfq_command_id) \
     pspccpcmd_wfq_command_id_q0_reg = (pspccpcmd_wfq_command_id_q0_reg & ~PspCcpCmd_WFQ_Command_ID_Q0_WFQ_Command_ID_MASK) | (wfq_command_id << PspCcpCmd_WFQ_Command_ID_Q0_WFQ_Command_ID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_wfq_command_id_q0_t {
          unsigned int wfq_command_id                 : PspCcpCmd_WFQ_Command_ID_Q0_WFQ_Command_ID_SIZE;
          unsigned int                                : 16;
     } pspccpcmd_wfq_command_id_q0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_wfq_command_id_q0_t {
          unsigned int                                : 16;
          unsigned int wfq_command_id                 : PspCcpCmd_WFQ_Command_ID_Q0_WFQ_Command_ID_SIZE;
     } pspccpcmd_wfq_command_id_q0_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_wfq_command_id_q0_t f;
} pspccpcmd_wfq_command_id_q0_u;


/*
 * PspCcpCmd_WFQ_Command_ID_Q1 struct
 */

#define PspCcpCmd_WFQ_Command_ID_Q1_REG_SIZE 32
#define PspCcpCmd_WFQ_Command_ID_Q1_WFQ_Command_ID_SIZE 16

#define PspCcpCmd_WFQ_Command_ID_Q1_WFQ_Command_ID_SHIFT 0

#define PspCcpCmd_WFQ_Command_ID_Q1_WFQ_Command_ID_MASK 0xffff

#define PspCcpCmd_WFQ_Command_ID_Q1_MASK \
     (PspCcpCmd_WFQ_Command_ID_Q1_WFQ_Command_ID_MASK)

#define PspCcpCmd_WFQ_Command_ID_Q1_DEFAULT 0x00000000

#define PspCcpCmd_WFQ_Command_ID_Q1_GET_WFQ_Command_ID(pspccpcmd_wfq_command_id_q1) \
     ((pspccpcmd_wfq_command_id_q1 & PspCcpCmd_WFQ_Command_ID_Q1_WFQ_Command_ID_MASK) >> PspCcpCmd_WFQ_Command_ID_Q1_WFQ_Command_ID_SHIFT)

#define PspCcpCmd_WFQ_Command_ID_Q1_SET_WFQ_Command_ID(pspccpcmd_wfq_command_id_q1_reg, wfq_command_id) \
     pspccpcmd_wfq_command_id_q1_reg = (pspccpcmd_wfq_command_id_q1_reg & ~PspCcpCmd_WFQ_Command_ID_Q1_WFQ_Command_ID_MASK) | (wfq_command_id << PspCcpCmd_WFQ_Command_ID_Q1_WFQ_Command_ID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_wfq_command_id_q1_t {
          unsigned int wfq_command_id                 : PspCcpCmd_WFQ_Command_ID_Q1_WFQ_Command_ID_SIZE;
          unsigned int                                : 16;
     } pspccpcmd_wfq_command_id_q1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_wfq_command_id_q1_t {
          unsigned int                                : 16;
          unsigned int wfq_command_id                 : PspCcpCmd_WFQ_Command_ID_Q1_WFQ_Command_ID_SIZE;
     } pspccpcmd_wfq_command_id_q1_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_wfq_command_id_q1_t f;
} pspccpcmd_wfq_command_id_q1_u;


/*
 * PspCcpCmd_WFQ_Command_ID_Q2 struct
 */

#define PspCcpCmd_WFQ_Command_ID_Q2_REG_SIZE 32
#define PspCcpCmd_WFQ_Command_ID_Q2_WFQ_Command_ID_SIZE 16

#define PspCcpCmd_WFQ_Command_ID_Q2_WFQ_Command_ID_SHIFT 0

#define PspCcpCmd_WFQ_Command_ID_Q2_WFQ_Command_ID_MASK 0xffff

#define PspCcpCmd_WFQ_Command_ID_Q2_MASK \
     (PspCcpCmd_WFQ_Command_ID_Q2_WFQ_Command_ID_MASK)

#define PspCcpCmd_WFQ_Command_ID_Q2_DEFAULT 0x00000000

#define PspCcpCmd_WFQ_Command_ID_Q2_GET_WFQ_Command_ID(pspccpcmd_wfq_command_id_q2) \
     ((pspccpcmd_wfq_command_id_q2 & PspCcpCmd_WFQ_Command_ID_Q2_WFQ_Command_ID_MASK) >> PspCcpCmd_WFQ_Command_ID_Q2_WFQ_Command_ID_SHIFT)

#define PspCcpCmd_WFQ_Command_ID_Q2_SET_WFQ_Command_ID(pspccpcmd_wfq_command_id_q2_reg, wfq_command_id) \
     pspccpcmd_wfq_command_id_q2_reg = (pspccpcmd_wfq_command_id_q2_reg & ~PspCcpCmd_WFQ_Command_ID_Q2_WFQ_Command_ID_MASK) | (wfq_command_id << PspCcpCmd_WFQ_Command_ID_Q2_WFQ_Command_ID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_wfq_command_id_q2_t {
          unsigned int wfq_command_id                 : PspCcpCmd_WFQ_Command_ID_Q2_WFQ_Command_ID_SIZE;
          unsigned int                                : 16;
     } pspccpcmd_wfq_command_id_q2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_wfq_command_id_q2_t {
          unsigned int                                : 16;
          unsigned int wfq_command_id                 : PspCcpCmd_WFQ_Command_ID_Q2_WFQ_Command_ID_SIZE;
     } pspccpcmd_wfq_command_id_q2_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_wfq_command_id_q2_t f;
} pspccpcmd_wfq_command_id_q2_u;


/*
 * PspCcpCmd_WFQ_Status_Q0 struct
 */

#define PspCcpCmd_WFQ_Status_Q0_REG_SIZE 32
#define PspCcpCmd_WFQ_Status_Q0_WFQ_Error_Status_SIZE 1
#define PspCcpCmd_WFQ_Status_Q0_WFQ_Queue_ID_SIZE 5
#define PspCcpCmd_WFQ_Status_Q0_WFQ_Command_ID_SIZE 16

#define PspCcpCmd_WFQ_Status_Q0_WFQ_Error_Status_SHIFT 0
#define PspCcpCmd_WFQ_Status_Q0_WFQ_Queue_ID_SHIFT 1
#define PspCcpCmd_WFQ_Status_Q0_WFQ_Command_ID_SHIFT 16

#define PspCcpCmd_WFQ_Status_Q0_WFQ_Error_Status_MASK 0x1
#define PspCcpCmd_WFQ_Status_Q0_WFQ_Queue_ID_MASK 0x3e
#define PspCcpCmd_WFQ_Status_Q0_WFQ_Command_ID_MASK 0xffff0000

#define PspCcpCmd_WFQ_Status_Q0_MASK \
     (PspCcpCmd_WFQ_Status_Q0_WFQ_Error_Status_MASK | \
      PspCcpCmd_WFQ_Status_Q0_WFQ_Queue_ID_MASK | \
      PspCcpCmd_WFQ_Status_Q0_WFQ_Command_ID_MASK)

#define PspCcpCmd_WFQ_Status_Q0_DEFAULT 0x00000000

#define PspCcpCmd_WFQ_Status_Q0_GET_WFQ_Error_Status(pspccpcmd_wfq_status_q0) \
     ((pspccpcmd_wfq_status_q0 & PspCcpCmd_WFQ_Status_Q0_WFQ_Error_Status_MASK) >> PspCcpCmd_WFQ_Status_Q0_WFQ_Error_Status_SHIFT)
#define PspCcpCmd_WFQ_Status_Q0_GET_WFQ_Queue_ID(pspccpcmd_wfq_status_q0) \
     ((pspccpcmd_wfq_status_q0 & PspCcpCmd_WFQ_Status_Q0_WFQ_Queue_ID_MASK) >> PspCcpCmd_WFQ_Status_Q0_WFQ_Queue_ID_SHIFT)
#define PspCcpCmd_WFQ_Status_Q0_GET_WFQ_Command_ID(pspccpcmd_wfq_status_q0) \
     ((pspccpcmd_wfq_status_q0 & PspCcpCmd_WFQ_Status_Q0_WFQ_Command_ID_MASK) >> PspCcpCmd_WFQ_Status_Q0_WFQ_Command_ID_SHIFT)

#define PspCcpCmd_WFQ_Status_Q0_SET_WFQ_Error_Status(pspccpcmd_wfq_status_q0_reg, wfq_error_status) \
     pspccpcmd_wfq_status_q0_reg = (pspccpcmd_wfq_status_q0_reg & ~PspCcpCmd_WFQ_Status_Q0_WFQ_Error_Status_MASK) | (wfq_error_status << PspCcpCmd_WFQ_Status_Q0_WFQ_Error_Status_SHIFT)
#define PspCcpCmd_WFQ_Status_Q0_SET_WFQ_Queue_ID(pspccpcmd_wfq_status_q0_reg, wfq_queue_id) \
     pspccpcmd_wfq_status_q0_reg = (pspccpcmd_wfq_status_q0_reg & ~PspCcpCmd_WFQ_Status_Q0_WFQ_Queue_ID_MASK) | (wfq_queue_id << PspCcpCmd_WFQ_Status_Q0_WFQ_Queue_ID_SHIFT)
#define PspCcpCmd_WFQ_Status_Q0_SET_WFQ_Command_ID(pspccpcmd_wfq_status_q0_reg, wfq_command_id) \
     pspccpcmd_wfq_status_q0_reg = (pspccpcmd_wfq_status_q0_reg & ~PspCcpCmd_WFQ_Status_Q0_WFQ_Command_ID_MASK) | (wfq_command_id << PspCcpCmd_WFQ_Status_Q0_WFQ_Command_ID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_wfq_status_q0_t {
          unsigned int wfq_error_status               : PspCcpCmd_WFQ_Status_Q0_WFQ_Error_Status_SIZE;
          unsigned int wfq_queue_id                   : PspCcpCmd_WFQ_Status_Q0_WFQ_Queue_ID_SIZE;
          unsigned int                                : 10;
          unsigned int wfq_command_id                 : PspCcpCmd_WFQ_Status_Q0_WFQ_Command_ID_SIZE;
     } pspccpcmd_wfq_status_q0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_wfq_status_q0_t {
          unsigned int wfq_command_id                 : PspCcpCmd_WFQ_Status_Q0_WFQ_Command_ID_SIZE;
          unsigned int                                : 10;
          unsigned int wfq_queue_id                   : PspCcpCmd_WFQ_Status_Q0_WFQ_Queue_ID_SIZE;
          unsigned int wfq_error_status               : PspCcpCmd_WFQ_Status_Q0_WFQ_Error_Status_SIZE;
     } pspccpcmd_wfq_status_q0_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_wfq_status_q0_t f;
} pspccpcmd_wfq_status_q0_u;


/*
 * PspCcpCmd_WFQ_Status_Q1 struct
 */

#define PspCcpCmd_WFQ_Status_Q1_REG_SIZE 32
#define PspCcpCmd_WFQ_Status_Q1_WFQ_Error_Status_SIZE 1
#define PspCcpCmd_WFQ_Status_Q1_WFQ_Queue_ID_SIZE 5
#define PspCcpCmd_WFQ_Status_Q1_WFQ_Command_ID_SIZE 16

#define PspCcpCmd_WFQ_Status_Q1_WFQ_Error_Status_SHIFT 0
#define PspCcpCmd_WFQ_Status_Q1_WFQ_Queue_ID_SHIFT 1
#define PspCcpCmd_WFQ_Status_Q1_WFQ_Command_ID_SHIFT 16

#define PspCcpCmd_WFQ_Status_Q1_WFQ_Error_Status_MASK 0x1
#define PspCcpCmd_WFQ_Status_Q1_WFQ_Queue_ID_MASK 0x3e
#define PspCcpCmd_WFQ_Status_Q1_WFQ_Command_ID_MASK 0xffff0000

#define PspCcpCmd_WFQ_Status_Q1_MASK \
     (PspCcpCmd_WFQ_Status_Q1_WFQ_Error_Status_MASK | \
      PspCcpCmd_WFQ_Status_Q1_WFQ_Queue_ID_MASK | \
      PspCcpCmd_WFQ_Status_Q1_WFQ_Command_ID_MASK)

#define PspCcpCmd_WFQ_Status_Q1_DEFAULT 0x00000000

#define PspCcpCmd_WFQ_Status_Q1_GET_WFQ_Error_Status(pspccpcmd_wfq_status_q1) \
     ((pspccpcmd_wfq_status_q1 & PspCcpCmd_WFQ_Status_Q1_WFQ_Error_Status_MASK) >> PspCcpCmd_WFQ_Status_Q1_WFQ_Error_Status_SHIFT)
#define PspCcpCmd_WFQ_Status_Q1_GET_WFQ_Queue_ID(pspccpcmd_wfq_status_q1) \
     ((pspccpcmd_wfq_status_q1 & PspCcpCmd_WFQ_Status_Q1_WFQ_Queue_ID_MASK) >> PspCcpCmd_WFQ_Status_Q1_WFQ_Queue_ID_SHIFT)
#define PspCcpCmd_WFQ_Status_Q1_GET_WFQ_Command_ID(pspccpcmd_wfq_status_q1) \
     ((pspccpcmd_wfq_status_q1 & PspCcpCmd_WFQ_Status_Q1_WFQ_Command_ID_MASK) >> PspCcpCmd_WFQ_Status_Q1_WFQ_Command_ID_SHIFT)

#define PspCcpCmd_WFQ_Status_Q1_SET_WFQ_Error_Status(pspccpcmd_wfq_status_q1_reg, wfq_error_status) \
     pspccpcmd_wfq_status_q1_reg = (pspccpcmd_wfq_status_q1_reg & ~PspCcpCmd_WFQ_Status_Q1_WFQ_Error_Status_MASK) | (wfq_error_status << PspCcpCmd_WFQ_Status_Q1_WFQ_Error_Status_SHIFT)
#define PspCcpCmd_WFQ_Status_Q1_SET_WFQ_Queue_ID(pspccpcmd_wfq_status_q1_reg, wfq_queue_id) \
     pspccpcmd_wfq_status_q1_reg = (pspccpcmd_wfq_status_q1_reg & ~PspCcpCmd_WFQ_Status_Q1_WFQ_Queue_ID_MASK) | (wfq_queue_id << PspCcpCmd_WFQ_Status_Q1_WFQ_Queue_ID_SHIFT)
#define PspCcpCmd_WFQ_Status_Q1_SET_WFQ_Command_ID(pspccpcmd_wfq_status_q1_reg, wfq_command_id) \
     pspccpcmd_wfq_status_q1_reg = (pspccpcmd_wfq_status_q1_reg & ~PspCcpCmd_WFQ_Status_Q1_WFQ_Command_ID_MASK) | (wfq_command_id << PspCcpCmd_WFQ_Status_Q1_WFQ_Command_ID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_wfq_status_q1_t {
          unsigned int wfq_error_status               : PspCcpCmd_WFQ_Status_Q1_WFQ_Error_Status_SIZE;
          unsigned int wfq_queue_id                   : PspCcpCmd_WFQ_Status_Q1_WFQ_Queue_ID_SIZE;
          unsigned int                                : 10;
          unsigned int wfq_command_id                 : PspCcpCmd_WFQ_Status_Q1_WFQ_Command_ID_SIZE;
     } pspccpcmd_wfq_status_q1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_wfq_status_q1_t {
          unsigned int wfq_command_id                 : PspCcpCmd_WFQ_Status_Q1_WFQ_Command_ID_SIZE;
          unsigned int                                : 10;
          unsigned int wfq_queue_id                   : PspCcpCmd_WFQ_Status_Q1_WFQ_Queue_ID_SIZE;
          unsigned int wfq_error_status               : PspCcpCmd_WFQ_Status_Q1_WFQ_Error_Status_SIZE;
     } pspccpcmd_wfq_status_q1_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_wfq_status_q1_t f;
} pspccpcmd_wfq_status_q1_u;


/*
 * PspCcpCmd_WFQ_Status_Q2 struct
 */

#define PspCcpCmd_WFQ_Status_Q2_REG_SIZE 32
#define PspCcpCmd_WFQ_Status_Q2_WFQ_Error_Status_SIZE 1
#define PspCcpCmd_WFQ_Status_Q2_WFQ_Queue_ID_SIZE 5
#define PspCcpCmd_WFQ_Status_Q2_WFQ_Command_ID_SIZE 16

#define PspCcpCmd_WFQ_Status_Q2_WFQ_Error_Status_SHIFT 0
#define PspCcpCmd_WFQ_Status_Q2_WFQ_Queue_ID_SHIFT 1
#define PspCcpCmd_WFQ_Status_Q2_WFQ_Command_ID_SHIFT 16

#define PspCcpCmd_WFQ_Status_Q2_WFQ_Error_Status_MASK 0x1
#define PspCcpCmd_WFQ_Status_Q2_WFQ_Queue_ID_MASK 0x3e
#define PspCcpCmd_WFQ_Status_Q2_WFQ_Command_ID_MASK 0xffff0000

#define PspCcpCmd_WFQ_Status_Q2_MASK \
     (PspCcpCmd_WFQ_Status_Q2_WFQ_Error_Status_MASK | \
      PspCcpCmd_WFQ_Status_Q2_WFQ_Queue_ID_MASK | \
      PspCcpCmd_WFQ_Status_Q2_WFQ_Command_ID_MASK)

#define PspCcpCmd_WFQ_Status_Q2_DEFAULT 0x00000000

#define PspCcpCmd_WFQ_Status_Q2_GET_WFQ_Error_Status(pspccpcmd_wfq_status_q2) \
     ((pspccpcmd_wfq_status_q2 & PspCcpCmd_WFQ_Status_Q2_WFQ_Error_Status_MASK) >> PspCcpCmd_WFQ_Status_Q2_WFQ_Error_Status_SHIFT)
#define PspCcpCmd_WFQ_Status_Q2_GET_WFQ_Queue_ID(pspccpcmd_wfq_status_q2) \
     ((pspccpcmd_wfq_status_q2 & PspCcpCmd_WFQ_Status_Q2_WFQ_Queue_ID_MASK) >> PspCcpCmd_WFQ_Status_Q2_WFQ_Queue_ID_SHIFT)
#define PspCcpCmd_WFQ_Status_Q2_GET_WFQ_Command_ID(pspccpcmd_wfq_status_q2) \
     ((pspccpcmd_wfq_status_q2 & PspCcpCmd_WFQ_Status_Q2_WFQ_Command_ID_MASK) >> PspCcpCmd_WFQ_Status_Q2_WFQ_Command_ID_SHIFT)

#define PspCcpCmd_WFQ_Status_Q2_SET_WFQ_Error_Status(pspccpcmd_wfq_status_q2_reg, wfq_error_status) \
     pspccpcmd_wfq_status_q2_reg = (pspccpcmd_wfq_status_q2_reg & ~PspCcpCmd_WFQ_Status_Q2_WFQ_Error_Status_MASK) | (wfq_error_status << PspCcpCmd_WFQ_Status_Q2_WFQ_Error_Status_SHIFT)
#define PspCcpCmd_WFQ_Status_Q2_SET_WFQ_Queue_ID(pspccpcmd_wfq_status_q2_reg, wfq_queue_id) \
     pspccpcmd_wfq_status_q2_reg = (pspccpcmd_wfq_status_q2_reg & ~PspCcpCmd_WFQ_Status_Q2_WFQ_Queue_ID_MASK) | (wfq_queue_id << PspCcpCmd_WFQ_Status_Q2_WFQ_Queue_ID_SHIFT)
#define PspCcpCmd_WFQ_Status_Q2_SET_WFQ_Command_ID(pspccpcmd_wfq_status_q2_reg, wfq_command_id) \
     pspccpcmd_wfq_status_q2_reg = (pspccpcmd_wfq_status_q2_reg & ~PspCcpCmd_WFQ_Status_Q2_WFQ_Command_ID_MASK) | (wfq_command_id << PspCcpCmd_WFQ_Status_Q2_WFQ_Command_ID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpcmd_wfq_status_q2_t {
          unsigned int wfq_error_status               : PspCcpCmd_WFQ_Status_Q2_WFQ_Error_Status_SIZE;
          unsigned int wfq_queue_id                   : PspCcpCmd_WFQ_Status_Q2_WFQ_Queue_ID_SIZE;
          unsigned int                                : 10;
          unsigned int wfq_command_id                 : PspCcpCmd_WFQ_Status_Q2_WFQ_Command_ID_SIZE;
     } pspccpcmd_wfq_status_q2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpcmd_wfq_status_q2_t {
          unsigned int wfq_command_id                 : PspCcpCmd_WFQ_Status_Q2_WFQ_Command_ID_SIZE;
          unsigned int                                : 10;
          unsigned int wfq_queue_id                   : PspCcpCmd_WFQ_Status_Q2_WFQ_Queue_ID_SIZE;
          unsigned int wfq_error_status               : PspCcpCmd_WFQ_Status_Q2_WFQ_Error_Status_SIZE;
     } pspccpcmd_wfq_status_q2_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpcmd_wfq_status_q2_t f;
} pspccpcmd_wfq_status_q2_u;


/*
 * PspCcpConfig0 struct
 */

#define PspCcpConfig0_REG_SIZE         32
#define PspCcpConfig0_RI_VHBEnable_SIZE 1
#define PspCcpConfig0_RI_IAPM_Enable_SIZE 1
#define PspCcpConfig0_RI_ZLIB_Checksum_Disable_SIZE 1
#define PspCcpConfig0_RI_ZLIB_Disable_2nd_Match_SIZE 1

#define PspCcpConfig0_RI_VHBEnable_SHIFT 0
#define PspCcpConfig0_RI_IAPM_Enable_SHIFT 1
#define PspCcpConfig0_RI_ZLIB_Checksum_Disable_SHIFT 2
#define PspCcpConfig0_RI_ZLIB_Disable_2nd_Match_SHIFT 3

#define PspCcpConfig0_RI_VHBEnable_MASK 0x1
#define PspCcpConfig0_RI_IAPM_Enable_MASK 0x2
#define PspCcpConfig0_RI_ZLIB_Checksum_Disable_MASK 0x4
#define PspCcpConfig0_RI_ZLIB_Disable_2nd_Match_MASK 0x8

#define PspCcpConfig0_MASK \
     (PspCcpConfig0_RI_VHBEnable_MASK | \
      PspCcpConfig0_RI_IAPM_Enable_MASK | \
      PspCcpConfig0_RI_ZLIB_Checksum_Disable_MASK | \
      PspCcpConfig0_RI_ZLIB_Disable_2nd_Match_MASK)

#define PspCcpConfig0_DEFAULT          0x00000000

#define PspCcpConfig0_GET_RI_VHBEnable(pspccpconfig0) \
     ((pspccpconfig0 & PspCcpConfig0_RI_VHBEnable_MASK) >> PspCcpConfig0_RI_VHBEnable_SHIFT)
#define PspCcpConfig0_GET_RI_IAPM_Enable(pspccpconfig0) \
     ((pspccpconfig0 & PspCcpConfig0_RI_IAPM_Enable_MASK) >> PspCcpConfig0_RI_IAPM_Enable_SHIFT)
#define PspCcpConfig0_GET_RI_ZLIB_Checksum_Disable(pspccpconfig0) \
     ((pspccpconfig0 & PspCcpConfig0_RI_ZLIB_Checksum_Disable_MASK) >> PspCcpConfig0_RI_ZLIB_Checksum_Disable_SHIFT)
#define PspCcpConfig0_GET_RI_ZLIB_Disable_2nd_Match(pspccpconfig0) \
     ((pspccpconfig0 & PspCcpConfig0_RI_ZLIB_Disable_2nd_Match_MASK) >> PspCcpConfig0_RI_ZLIB_Disable_2nd_Match_SHIFT)

#define PspCcpConfig0_SET_RI_VHBEnable(pspccpconfig0_reg, ri_vhbenable) \
     pspccpconfig0_reg = (pspccpconfig0_reg & ~PspCcpConfig0_RI_VHBEnable_MASK) | (ri_vhbenable << PspCcpConfig0_RI_VHBEnable_SHIFT)
#define PspCcpConfig0_SET_RI_IAPM_Enable(pspccpconfig0_reg, ri_iapm_enable) \
     pspccpconfig0_reg = (pspccpconfig0_reg & ~PspCcpConfig0_RI_IAPM_Enable_MASK) | (ri_iapm_enable << PspCcpConfig0_RI_IAPM_Enable_SHIFT)
#define PspCcpConfig0_SET_RI_ZLIB_Checksum_Disable(pspccpconfig0_reg, ri_zlib_checksum_disable) \
     pspccpconfig0_reg = (pspccpconfig0_reg & ~PspCcpConfig0_RI_ZLIB_Checksum_Disable_MASK) | (ri_zlib_checksum_disable << PspCcpConfig0_RI_ZLIB_Checksum_Disable_SHIFT)
#define PspCcpConfig0_SET_RI_ZLIB_Disable_2nd_Match(pspccpconfig0_reg, ri_zlib_disable_2nd_match) \
     pspccpconfig0_reg = (pspccpconfig0_reg & ~PspCcpConfig0_RI_ZLIB_Disable_2nd_Match_MASK) | (ri_zlib_disable_2nd_match << PspCcpConfig0_RI_ZLIB_Disable_2nd_Match_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpconfig0_t {
          unsigned int ri_vhbenable                   : PspCcpConfig0_RI_VHBEnable_SIZE;
          unsigned int ri_iapm_enable                 : PspCcpConfig0_RI_IAPM_Enable_SIZE;
          unsigned int ri_zlib_checksum_disable       : PspCcpConfig0_RI_ZLIB_Checksum_Disable_SIZE;
          unsigned int ri_zlib_disable_2nd_match      : PspCcpConfig0_RI_ZLIB_Disable_2nd_Match_SIZE;
          unsigned int                                : 28;
     } pspccpconfig0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpconfig0_t {
          unsigned int                                : 28;
          unsigned int ri_zlib_disable_2nd_match      : PspCcpConfig0_RI_ZLIB_Disable_2nd_Match_SIZE;
          unsigned int ri_zlib_checksum_disable       : PspCcpConfig0_RI_ZLIB_Checksum_Disable_SIZE;
          unsigned int ri_iapm_enable                 : PspCcpConfig0_RI_IAPM_Enable_SIZE;
          unsigned int ri_vhbenable                   : PspCcpConfig0_RI_VHBEnable_SIZE;
     } pspccpconfig0_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpconfig0_t f;
} pspccpconfig0_u;


/*
 * PspCcpTrng_Control struct
 */

#define PspCcpTrng_Control_REG_SIZE    32
#define PspCcpTrng_Control_RI_RoEn_SIZE 1
#define PspCcpTrng_Control_RI_EhcEn_SIZE 1
#define PspCcpTrng_Control_RI_DrbgEn_SIZE 1
#define PspCcpTrng_Control_RI_RepCountCutoff_SIZE 4
#define PspCcpTrng_Control_RI_AdapPropCutoff_SIZE 8
#define PspCcpTrng_Control_RI_EhcIntEn_SIZE 1
#define PspCcpTrng_Control_RI_EhcIntStatus_SIZE 1
#define PspCcpTrng_Control_RI_BadEntropy_SIZE 1
#define PspCcpTrng_Control_RI_Lock_SIZE 1
#define PspCcpTrng_Control_RI_TestMode_SIZE 1

#define PspCcpTrng_Control_RI_RoEn_SHIFT 0
#define PspCcpTrng_Control_RI_EhcEn_SHIFT 1
#define PspCcpTrng_Control_RI_DrbgEn_SHIFT 2
#define PspCcpTrng_Control_RI_RepCountCutoff_SHIFT 4
#define PspCcpTrng_Control_RI_AdapPropCutoff_SHIFT 8
#define PspCcpTrng_Control_RI_EhcIntEn_SHIFT 16
#define PspCcpTrng_Control_RI_EhcIntStatus_SHIFT 17
#define PspCcpTrng_Control_RI_BadEntropy_SHIFT 29
#define PspCcpTrng_Control_RI_Lock_SHIFT 30
#define PspCcpTrng_Control_RI_TestMode_SHIFT 31

#define PspCcpTrng_Control_RI_RoEn_MASK 0x1
#define PspCcpTrng_Control_RI_EhcEn_MASK 0x2
#define PspCcpTrng_Control_RI_DrbgEn_MASK 0x4
#define PspCcpTrng_Control_RI_RepCountCutoff_MASK 0xf0
#define PspCcpTrng_Control_RI_AdapPropCutoff_MASK 0xff00
#define PspCcpTrng_Control_RI_EhcIntEn_MASK 0x10000
#define PspCcpTrng_Control_RI_EhcIntStatus_MASK 0x20000
#define PspCcpTrng_Control_RI_BadEntropy_MASK 0x20000000
#define PspCcpTrng_Control_RI_Lock_MASK 0x40000000
#define PspCcpTrng_Control_RI_TestMode_MASK 0x80000000

#define PspCcpTrng_Control_MASK \
     (PspCcpTrng_Control_RI_RoEn_MASK | \
      PspCcpTrng_Control_RI_EhcEn_MASK | \
      PspCcpTrng_Control_RI_DrbgEn_MASK | \
      PspCcpTrng_Control_RI_RepCountCutoff_MASK | \
      PspCcpTrng_Control_RI_AdapPropCutoff_MASK | \
      PspCcpTrng_Control_RI_EhcIntEn_MASK | \
      PspCcpTrng_Control_RI_EhcIntStatus_MASK | \
      PspCcpTrng_Control_RI_BadEntropy_MASK | \
      PspCcpTrng_Control_RI_Lock_MASK | \
      PspCcpTrng_Control_RI_TestMode_MASK)

#define PspCcpTrng_Control_DEFAULT     0x00000000

#define PspCcpTrng_Control_GET_RI_RoEn(pspccptrng_control) \
     ((pspccptrng_control & PspCcpTrng_Control_RI_RoEn_MASK) >> PspCcpTrng_Control_RI_RoEn_SHIFT)
#define PspCcpTrng_Control_GET_RI_EhcEn(pspccptrng_control) \
     ((pspccptrng_control & PspCcpTrng_Control_RI_EhcEn_MASK) >> PspCcpTrng_Control_RI_EhcEn_SHIFT)
#define PspCcpTrng_Control_GET_RI_DrbgEn(pspccptrng_control) \
     ((pspccptrng_control & PspCcpTrng_Control_RI_DrbgEn_MASK) >> PspCcpTrng_Control_RI_DrbgEn_SHIFT)
#define PspCcpTrng_Control_GET_RI_RepCountCutoff(pspccptrng_control) \
     ((pspccptrng_control & PspCcpTrng_Control_RI_RepCountCutoff_MASK) >> PspCcpTrng_Control_RI_RepCountCutoff_SHIFT)
#define PspCcpTrng_Control_GET_RI_AdapPropCutoff(pspccptrng_control) \
     ((pspccptrng_control & PspCcpTrng_Control_RI_AdapPropCutoff_MASK) >> PspCcpTrng_Control_RI_AdapPropCutoff_SHIFT)
#define PspCcpTrng_Control_GET_RI_EhcIntEn(pspccptrng_control) \
     ((pspccptrng_control & PspCcpTrng_Control_RI_EhcIntEn_MASK) >> PspCcpTrng_Control_RI_EhcIntEn_SHIFT)
#define PspCcpTrng_Control_GET_RI_EhcIntStatus(pspccptrng_control) \
     ((pspccptrng_control & PspCcpTrng_Control_RI_EhcIntStatus_MASK) >> PspCcpTrng_Control_RI_EhcIntStatus_SHIFT)
#define PspCcpTrng_Control_GET_RI_BadEntropy(pspccptrng_control) \
     ((pspccptrng_control & PspCcpTrng_Control_RI_BadEntropy_MASK) >> PspCcpTrng_Control_RI_BadEntropy_SHIFT)
#define PspCcpTrng_Control_GET_RI_Lock(pspccptrng_control) \
     ((pspccptrng_control & PspCcpTrng_Control_RI_Lock_MASK) >> PspCcpTrng_Control_RI_Lock_SHIFT)
#define PspCcpTrng_Control_GET_RI_TestMode(pspccptrng_control) \
     ((pspccptrng_control & PspCcpTrng_Control_RI_TestMode_MASK) >> PspCcpTrng_Control_RI_TestMode_SHIFT)

#define PspCcpTrng_Control_SET_RI_RoEn(pspccptrng_control_reg, ri_roen) \
     pspccptrng_control_reg = (pspccptrng_control_reg & ~PspCcpTrng_Control_RI_RoEn_MASK) | (ri_roen << PspCcpTrng_Control_RI_RoEn_SHIFT)
#define PspCcpTrng_Control_SET_RI_EhcEn(pspccptrng_control_reg, ri_ehcen) \
     pspccptrng_control_reg = (pspccptrng_control_reg & ~PspCcpTrng_Control_RI_EhcEn_MASK) | (ri_ehcen << PspCcpTrng_Control_RI_EhcEn_SHIFT)
#define PspCcpTrng_Control_SET_RI_DrbgEn(pspccptrng_control_reg, ri_drbgen) \
     pspccptrng_control_reg = (pspccptrng_control_reg & ~PspCcpTrng_Control_RI_DrbgEn_MASK) | (ri_drbgen << PspCcpTrng_Control_RI_DrbgEn_SHIFT)
#define PspCcpTrng_Control_SET_RI_RepCountCutoff(pspccptrng_control_reg, ri_repcountcutoff) \
     pspccptrng_control_reg = (pspccptrng_control_reg & ~PspCcpTrng_Control_RI_RepCountCutoff_MASK) | (ri_repcountcutoff << PspCcpTrng_Control_RI_RepCountCutoff_SHIFT)
#define PspCcpTrng_Control_SET_RI_AdapPropCutoff(pspccptrng_control_reg, ri_adappropcutoff) \
     pspccptrng_control_reg = (pspccptrng_control_reg & ~PspCcpTrng_Control_RI_AdapPropCutoff_MASK) | (ri_adappropcutoff << PspCcpTrng_Control_RI_AdapPropCutoff_SHIFT)
#define PspCcpTrng_Control_SET_RI_EhcIntEn(pspccptrng_control_reg, ri_ehcinten) \
     pspccptrng_control_reg = (pspccptrng_control_reg & ~PspCcpTrng_Control_RI_EhcIntEn_MASK) | (ri_ehcinten << PspCcpTrng_Control_RI_EhcIntEn_SHIFT)
#define PspCcpTrng_Control_SET_RI_EhcIntStatus(pspccptrng_control_reg, ri_ehcintstatus) \
     pspccptrng_control_reg = (pspccptrng_control_reg & ~PspCcpTrng_Control_RI_EhcIntStatus_MASK) | (ri_ehcintstatus << PspCcpTrng_Control_RI_EhcIntStatus_SHIFT)
#define PspCcpTrng_Control_SET_RI_BadEntropy(pspccptrng_control_reg, ri_badentropy) \
     pspccptrng_control_reg = (pspccptrng_control_reg & ~PspCcpTrng_Control_RI_BadEntropy_MASK) | (ri_badentropy << PspCcpTrng_Control_RI_BadEntropy_SHIFT)
#define PspCcpTrng_Control_SET_RI_Lock(pspccptrng_control_reg, ri_lock) \
     pspccptrng_control_reg = (pspccptrng_control_reg & ~PspCcpTrng_Control_RI_Lock_MASK) | (ri_lock << PspCcpTrng_Control_RI_Lock_SHIFT)
#define PspCcpTrng_Control_SET_RI_TestMode(pspccptrng_control_reg, ri_testmode) \
     pspccptrng_control_reg = (pspccptrng_control_reg & ~PspCcpTrng_Control_RI_TestMode_MASK) | (ri_testmode << PspCcpTrng_Control_RI_TestMode_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccptrng_control_t {
          unsigned int ri_roen                        : PspCcpTrng_Control_RI_RoEn_SIZE;
          unsigned int ri_ehcen                       : PspCcpTrng_Control_RI_EhcEn_SIZE;
          unsigned int ri_drbgen                      : PspCcpTrng_Control_RI_DrbgEn_SIZE;
          unsigned int                                : 1;
          unsigned int ri_repcountcutoff              : PspCcpTrng_Control_RI_RepCountCutoff_SIZE;
          unsigned int ri_adappropcutoff              : PspCcpTrng_Control_RI_AdapPropCutoff_SIZE;
          unsigned int ri_ehcinten                    : PspCcpTrng_Control_RI_EhcIntEn_SIZE;
          unsigned int ri_ehcintstatus                : PspCcpTrng_Control_RI_EhcIntStatus_SIZE;
          unsigned int                                : 11;
          unsigned int ri_badentropy                  : PspCcpTrng_Control_RI_BadEntropy_SIZE;
          unsigned int ri_lock                        : PspCcpTrng_Control_RI_Lock_SIZE;
          unsigned int ri_testmode                    : PspCcpTrng_Control_RI_TestMode_SIZE;
     } pspccptrng_control_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccptrng_control_t {
          unsigned int ri_testmode                    : PspCcpTrng_Control_RI_TestMode_SIZE;
          unsigned int ri_lock                        : PspCcpTrng_Control_RI_Lock_SIZE;
          unsigned int ri_badentropy                  : PspCcpTrng_Control_RI_BadEntropy_SIZE;
          unsigned int                                : 11;
          unsigned int ri_ehcintstatus                : PspCcpTrng_Control_RI_EhcIntStatus_SIZE;
          unsigned int ri_ehcinten                    : PspCcpTrng_Control_RI_EhcIntEn_SIZE;
          unsigned int ri_adappropcutoff              : PspCcpTrng_Control_RI_AdapPropCutoff_SIZE;
          unsigned int ri_repcountcutoff              : PspCcpTrng_Control_RI_RepCountCutoff_SIZE;
          unsigned int                                : 1;
          unsigned int ri_drbgen                      : PspCcpTrng_Control_RI_DrbgEn_SIZE;
          unsigned int ri_ehcen                       : PspCcpTrng_Control_RI_EhcEn_SIZE;
          unsigned int ri_roen                        : PspCcpTrng_Control_RI_RoEn_SIZE;
     } pspccptrng_control_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccptrng_control_t f;
} pspccptrng_control_u;


/*
 * PspCcpDecompression0_Limit_Lo struct
 */

#define PspCcpDecompression0_Limit_Lo_REG_SIZE 32
#define PspCcpDecompression0_Limit_Lo_RI_ZLIB0_DecompressionLimitLo_SIZE 32

#define PspCcpDecompression0_Limit_Lo_RI_ZLIB0_DecompressionLimitLo_SHIFT 0

#define PspCcpDecompression0_Limit_Lo_RI_ZLIB0_DecompressionLimitLo_MASK 0xffffffff

#define PspCcpDecompression0_Limit_Lo_MASK \
     (PspCcpDecompression0_Limit_Lo_RI_ZLIB0_DecompressionLimitLo_MASK)

#define PspCcpDecompression0_Limit_Lo_DEFAULT 0x00000000

#define PspCcpDecompression0_Limit_Lo_GET_RI_ZLIB0_DecompressionLimitLo(pspccpdecompression0_limit_lo) \
     ((pspccpdecompression0_limit_lo & PspCcpDecompression0_Limit_Lo_RI_ZLIB0_DecompressionLimitLo_MASK) >> PspCcpDecompression0_Limit_Lo_RI_ZLIB0_DecompressionLimitLo_SHIFT)

#define PspCcpDecompression0_Limit_Lo_SET_RI_ZLIB0_DecompressionLimitLo(pspccpdecompression0_limit_lo_reg, ri_zlib0_decompressionlimitlo) \
     pspccpdecompression0_limit_lo_reg = (pspccpdecompression0_limit_lo_reg & ~PspCcpDecompression0_Limit_Lo_RI_ZLIB0_DecompressionLimitLo_MASK) | (ri_zlib0_decompressionlimitlo << PspCcpDecompression0_Limit_Lo_RI_ZLIB0_DecompressionLimitLo_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpdecompression0_limit_lo_t {
          unsigned int ri_zlib0_decompressionlimitlo  : PspCcpDecompression0_Limit_Lo_RI_ZLIB0_DecompressionLimitLo_SIZE;
     } pspccpdecompression0_limit_lo_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpdecompression0_limit_lo_t {
          unsigned int ri_zlib0_decompressionlimitlo  : PspCcpDecompression0_Limit_Lo_RI_ZLIB0_DecompressionLimitLo_SIZE;
     } pspccpdecompression0_limit_lo_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpdecompression0_limit_lo_t f;
} pspccpdecompression0_limit_lo_u;


/*
 * PspCcpDecompression0_Limit_Hi struct
 */

#define PspCcpDecompression0_Limit_Hi_REG_SIZE 32
#define PspCcpDecompression0_Limit_Hi_RI_ZLIB0_DecompressionLimitHi_SIZE 32

#define PspCcpDecompression0_Limit_Hi_RI_ZLIB0_DecompressionLimitHi_SHIFT 0

#define PspCcpDecompression0_Limit_Hi_RI_ZLIB0_DecompressionLimitHi_MASK 0xffffffff

#define PspCcpDecompression0_Limit_Hi_MASK \
     (PspCcpDecompression0_Limit_Hi_RI_ZLIB0_DecompressionLimitHi_MASK)

#define PspCcpDecompression0_Limit_Hi_DEFAULT 0x00000000

#define PspCcpDecompression0_Limit_Hi_GET_RI_ZLIB0_DecompressionLimitHi(pspccpdecompression0_limit_hi) \
     ((pspccpdecompression0_limit_hi & PspCcpDecompression0_Limit_Hi_RI_ZLIB0_DecompressionLimitHi_MASK) >> PspCcpDecompression0_Limit_Hi_RI_ZLIB0_DecompressionLimitHi_SHIFT)

#define PspCcpDecompression0_Limit_Hi_SET_RI_ZLIB0_DecompressionLimitHi(pspccpdecompression0_limit_hi_reg, ri_zlib0_decompressionlimithi) \
     pspccpdecompression0_limit_hi_reg = (pspccpdecompression0_limit_hi_reg & ~PspCcpDecompression0_Limit_Hi_RI_ZLIB0_DecompressionLimitHi_MASK) | (ri_zlib0_decompressionlimithi << PspCcpDecompression0_Limit_Hi_RI_ZLIB0_DecompressionLimitHi_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpdecompression0_limit_hi_t {
          unsigned int ri_zlib0_decompressionlimithi  : PspCcpDecompression0_Limit_Hi_RI_ZLIB0_DecompressionLimitHi_SIZE;
     } pspccpdecompression0_limit_hi_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpdecompression0_limit_hi_t {
          unsigned int ri_zlib0_decompressionlimithi  : PspCcpDecompression0_Limit_Hi_RI_ZLIB0_DecompressionLimitHi_SIZE;
     } pspccpdecompression0_limit_hi_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpdecompression0_limit_hi_t f;
} pspccpdecompression0_limit_hi_u;


/*
 * PspCcpDecompression0_Status_Lo struct
 */

#define PspCcpDecompression0_Status_Lo_REG_SIZE 32
#define PspCcpDecompression0_Status_Lo_ZLIB0_OutputSize_Lo_SIZE 32

#define PspCcpDecompression0_Status_Lo_ZLIB0_OutputSize_Lo_SHIFT 0

#define PspCcpDecompression0_Status_Lo_ZLIB0_OutputSize_Lo_MASK 0xffffffff

#define PspCcpDecompression0_Status_Lo_MASK \
     (PspCcpDecompression0_Status_Lo_ZLIB0_OutputSize_Lo_MASK)

#define PspCcpDecompression0_Status_Lo_DEFAULT 0x00000000

#define PspCcpDecompression0_Status_Lo_GET_ZLIB0_OutputSize_Lo(pspccpdecompression0_status_lo) \
     ((pspccpdecompression0_status_lo & PspCcpDecompression0_Status_Lo_ZLIB0_OutputSize_Lo_MASK) >> PspCcpDecompression0_Status_Lo_ZLIB0_OutputSize_Lo_SHIFT)

#define PspCcpDecompression0_Status_Lo_SET_ZLIB0_OutputSize_Lo(pspccpdecompression0_status_lo_reg, zlib0_outputsize_lo) \
     pspccpdecompression0_status_lo_reg = (pspccpdecompression0_status_lo_reg & ~PspCcpDecompression0_Status_Lo_ZLIB0_OutputSize_Lo_MASK) | (zlib0_outputsize_lo << PspCcpDecompression0_Status_Lo_ZLIB0_OutputSize_Lo_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpdecompression0_status_lo_t {
          unsigned int zlib0_outputsize_lo            : PspCcpDecompression0_Status_Lo_ZLIB0_OutputSize_Lo_SIZE;
     } pspccpdecompression0_status_lo_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpdecompression0_status_lo_t {
          unsigned int zlib0_outputsize_lo            : PspCcpDecompression0_Status_Lo_ZLIB0_OutputSize_Lo_SIZE;
     } pspccpdecompression0_status_lo_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpdecompression0_status_lo_t f;
} pspccpdecompression0_status_lo_u;


/*
 * PspCcpDecompression0_Status_Hi struct
 */

#define PspCcpDecompression0_Status_Hi_REG_SIZE 32
#define PspCcpDecompression0_Status_Hi_ZLIB0_OutputSize_Hi_SIZE 32

#define PspCcpDecompression0_Status_Hi_ZLIB0_OutputSize_Hi_SHIFT 0

#define PspCcpDecompression0_Status_Hi_ZLIB0_OutputSize_Hi_MASK 0xffffffff

#define PspCcpDecompression0_Status_Hi_MASK \
     (PspCcpDecompression0_Status_Hi_ZLIB0_OutputSize_Hi_MASK)

#define PspCcpDecompression0_Status_Hi_DEFAULT 0x00000000

#define PspCcpDecompression0_Status_Hi_GET_ZLIB0_OutputSize_Hi(pspccpdecompression0_status_hi) \
     ((pspccpdecompression0_status_hi & PspCcpDecompression0_Status_Hi_ZLIB0_OutputSize_Hi_MASK) >> PspCcpDecompression0_Status_Hi_ZLIB0_OutputSize_Hi_SHIFT)

#define PspCcpDecompression0_Status_Hi_SET_ZLIB0_OutputSize_Hi(pspccpdecompression0_status_hi_reg, zlib0_outputsize_hi) \
     pspccpdecompression0_status_hi_reg = (pspccpdecompression0_status_hi_reg & ~PspCcpDecompression0_Status_Hi_ZLIB0_OutputSize_Hi_MASK) | (zlib0_outputsize_hi << PspCcpDecompression0_Status_Hi_ZLIB0_OutputSize_Hi_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpdecompression0_status_hi_t {
          unsigned int zlib0_outputsize_hi            : PspCcpDecompression0_Status_Hi_ZLIB0_OutputSize_Hi_SIZE;
     } pspccpdecompression0_status_hi_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpdecompression0_status_hi_t {
          unsigned int zlib0_outputsize_hi            : PspCcpDecompression0_Status_Hi_ZLIB0_OutputSize_Hi_SIZE;
     } pspccpdecompression0_status_hi_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpdecompression0_status_hi_t f;
} pspccpdecompression0_status_hi_u;


/*
 * PspCcpFuse_Strap struct
 */

#define PspCcpFuse_Strap_REG_SIZE      32
#define PspCcpFuse_Strap_RI_Write_disable_SIZE 1
#define PspCcpFuse_Strap_RI_Crypto_disable_SIZE 1
#define PspCcpFuse_Strap_RI_Crypto_IV_Index_SIZE 6

#define PspCcpFuse_Strap_RI_Write_disable_SHIFT 0
#define PspCcpFuse_Strap_RI_Crypto_disable_SHIFT 1
#define PspCcpFuse_Strap_RI_Crypto_IV_Index_SHIFT 2

#define PspCcpFuse_Strap_RI_Write_disable_MASK 0x1
#define PspCcpFuse_Strap_RI_Crypto_disable_MASK 0x2
#define PspCcpFuse_Strap_RI_Crypto_IV_Index_MASK 0xfc

#define PspCcpFuse_Strap_MASK \
     (PspCcpFuse_Strap_RI_Write_disable_MASK | \
      PspCcpFuse_Strap_RI_Crypto_disable_MASK | \
      PspCcpFuse_Strap_RI_Crypto_IV_Index_MASK)

#define PspCcpFuse_Strap_DEFAULT       0x00000000

#define PspCcpFuse_Strap_GET_RI_Write_disable(pspccpfuse_strap) \
     ((pspccpfuse_strap & PspCcpFuse_Strap_RI_Write_disable_MASK) >> PspCcpFuse_Strap_RI_Write_disable_SHIFT)
#define PspCcpFuse_Strap_GET_RI_Crypto_disable(pspccpfuse_strap) \
     ((pspccpfuse_strap & PspCcpFuse_Strap_RI_Crypto_disable_MASK) >> PspCcpFuse_Strap_RI_Crypto_disable_SHIFT)
#define PspCcpFuse_Strap_GET_RI_Crypto_IV_Index(pspccpfuse_strap) \
     ((pspccpfuse_strap & PspCcpFuse_Strap_RI_Crypto_IV_Index_MASK) >> PspCcpFuse_Strap_RI_Crypto_IV_Index_SHIFT)

#define PspCcpFuse_Strap_SET_RI_Write_disable(pspccpfuse_strap_reg, ri_write_disable) \
     pspccpfuse_strap_reg = (pspccpfuse_strap_reg & ~PspCcpFuse_Strap_RI_Write_disable_MASK) | (ri_write_disable << PspCcpFuse_Strap_RI_Write_disable_SHIFT)
#define PspCcpFuse_Strap_SET_RI_Crypto_disable(pspccpfuse_strap_reg, ri_crypto_disable) \
     pspccpfuse_strap_reg = (pspccpfuse_strap_reg & ~PspCcpFuse_Strap_RI_Crypto_disable_MASK) | (ri_crypto_disable << PspCcpFuse_Strap_RI_Crypto_disable_SHIFT)
#define PspCcpFuse_Strap_SET_RI_Crypto_IV_Index(pspccpfuse_strap_reg, ri_crypto_iv_index) \
     pspccpfuse_strap_reg = (pspccpfuse_strap_reg & ~PspCcpFuse_Strap_RI_Crypto_IV_Index_MASK) | (ri_crypto_iv_index << PspCcpFuse_Strap_RI_Crypto_IV_Index_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpfuse_strap_t {
          unsigned int ri_write_disable               : PspCcpFuse_Strap_RI_Write_disable_SIZE;
          unsigned int ri_crypto_disable              : PspCcpFuse_Strap_RI_Crypto_disable_SIZE;
          unsigned int ri_crypto_iv_index             : PspCcpFuse_Strap_RI_Crypto_IV_Index_SIZE;
          unsigned int                                : 24;
     } pspccpfuse_strap_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpfuse_strap_t {
          unsigned int                                : 24;
          unsigned int ri_crypto_iv_index             : PspCcpFuse_Strap_RI_Crypto_IV_Index_SIZE;
          unsigned int ri_crypto_disable              : PspCcpFuse_Strap_RI_Crypto_disable_SIZE;
          unsigned int ri_write_disable               : PspCcpFuse_Strap_RI_Write_disable_SIZE;
     } pspccpfuse_strap_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpfuse_strap_t f;
} pspccpfuse_strap_u;


/*
 * PspCcpLoad_Crypto_Key struct
 */

#define PspCcpLoad_Crypto_Key_REG_SIZE 32
#define PspCcpLoad_Crypto_Key_RI_KeyData_SIZE 32

#define PspCcpLoad_Crypto_Key_RI_KeyData_SHIFT 0

#define PspCcpLoad_Crypto_Key_RI_KeyData_MASK 0xffffffff

#define PspCcpLoad_Crypto_Key_MASK \
     (PspCcpLoad_Crypto_Key_RI_KeyData_MASK)

#define PspCcpLoad_Crypto_Key_DEFAULT  0x00000000

#define PspCcpLoad_Crypto_Key_GET_RI_KeyData(pspccpload_crypto_key) \
     ((pspccpload_crypto_key & PspCcpLoad_Crypto_Key_RI_KeyData_MASK) >> PspCcpLoad_Crypto_Key_RI_KeyData_SHIFT)

#define PspCcpLoad_Crypto_Key_SET_RI_KeyData(pspccpload_crypto_key_reg, ri_keydata) \
     pspccpload_crypto_key_reg = (pspccpload_crypto_key_reg & ~PspCcpLoad_Crypto_Key_RI_KeyData_MASK) | (ri_keydata << PspCcpLoad_Crypto_Key_RI_KeyData_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpload_crypto_key_t {
          unsigned int ri_keydata                     : PspCcpLoad_Crypto_Key_RI_KeyData_SIZE;
     } pspccpload_crypto_key_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpload_crypto_key_t {
          unsigned int ri_keydata                     : PspCcpLoad_Crypto_Key_RI_KeyData_SIZE;
     } pspccpload_crypto_key_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpload_crypto_key_t f;
} pspccpload_crypto_key_u;


/*
 * PspCcpLoad_Crypto_Key_Ready struct
 */

#define PspCcpLoad_Crypto_Key_Ready_REG_SIZE 32
#define PspCcpLoad_Crypto_Key_Ready_Crypto_Key_Ready_SIZE 1

#define PspCcpLoad_Crypto_Key_Ready_Crypto_Key_Ready_SHIFT 0

#define PspCcpLoad_Crypto_Key_Ready_Crypto_Key_Ready_MASK 0x1

#define PspCcpLoad_Crypto_Key_Ready_MASK \
     (PspCcpLoad_Crypto_Key_Ready_Crypto_Key_Ready_MASK)

#define PspCcpLoad_Crypto_Key_Ready_DEFAULT 0x00000000

#define PspCcpLoad_Crypto_Key_Ready_GET_Crypto_Key_Ready(pspccpload_crypto_key_ready) \
     ((pspccpload_crypto_key_ready & PspCcpLoad_Crypto_Key_Ready_Crypto_Key_Ready_MASK) >> PspCcpLoad_Crypto_Key_Ready_Crypto_Key_Ready_SHIFT)

#define PspCcpLoad_Crypto_Key_Ready_SET_Crypto_Key_Ready(pspccpload_crypto_key_ready_reg, crypto_key_ready) \
     pspccpload_crypto_key_ready_reg = (pspccpload_crypto_key_ready_reg & ~PspCcpLoad_Crypto_Key_Ready_Crypto_Key_Ready_MASK) | (crypto_key_ready << PspCcpLoad_Crypto_Key_Ready_Crypto_Key_Ready_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpload_crypto_key_ready_t {
          unsigned int crypto_key_ready               : PspCcpLoad_Crypto_Key_Ready_Crypto_Key_Ready_SIZE;
          unsigned int                                : 31;
     } pspccpload_crypto_key_ready_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpload_crypto_key_ready_t {
          unsigned int                                : 31;
          unsigned int crypto_key_ready               : PspCcpLoad_Crypto_Key_Ready_Crypto_Key_Ready_SIZE;
     } pspccpload_crypto_key_ready_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpload_crypto_key_ready_t f;
} pspccpload_crypto_key_ready_u;


/*
 * PspCcpClock_Gating_Control struct
 */

#define PspCcpClock_Gating_Control_REG_SIZE 32
#define PspCcpClock_Gating_Control_DYN_CLOCK_EN_SIZE 1
#define PspCcpClock_Gating_Control_GATE_MODE_CCP_SIZE 1
#define PspCcpClock_Gating_Control_CLK_GATE_DLY_TIMER_SIZE 4
#define PspCcpClock_Gating_Control_SW_GATE_CCP_SIZE 1
#define PspCcpClock_Gating_Control_CLK_OFF_DLY_TIMER_SIZE 4
#define PspCcpClock_Gating_Control_VAR_CCP_LS_EN_SIZE 1
#define PspCcpClock_Gating_Control_LS_SET_DLY_SIZE 4
#define PspCcpClock_Gating_Control_LS_CLR_DLY_SIZE 4
#define PspCcpClock_Gating_Control_SW_LIGHT_SLEEP_SIZE 1

#define PspCcpClock_Gating_Control_DYN_CLOCK_EN_SHIFT 0
#define PspCcpClock_Gating_Control_GATE_MODE_CCP_SHIFT 1
#define PspCcpClock_Gating_Control_CLK_GATE_DLY_TIMER_SHIFT 2
#define PspCcpClock_Gating_Control_SW_GATE_CCP_SHIFT 6
#define PspCcpClock_Gating_Control_CLK_OFF_DLY_TIMER_SHIFT 7
#define PspCcpClock_Gating_Control_VAR_CCP_LS_EN_SHIFT 11
#define PspCcpClock_Gating_Control_LS_SET_DLY_SHIFT 12
#define PspCcpClock_Gating_Control_LS_CLR_DLY_SHIFT 16
#define PspCcpClock_Gating_Control_SW_LIGHT_SLEEP_SHIFT 20

#define PspCcpClock_Gating_Control_DYN_CLOCK_EN_MASK 0x1
#define PspCcpClock_Gating_Control_GATE_MODE_CCP_MASK 0x2
#define PspCcpClock_Gating_Control_CLK_GATE_DLY_TIMER_MASK 0x3c
#define PspCcpClock_Gating_Control_SW_GATE_CCP_MASK 0x40
#define PspCcpClock_Gating_Control_CLK_OFF_DLY_TIMER_MASK 0x780
#define PspCcpClock_Gating_Control_VAR_CCP_LS_EN_MASK 0x800
#define PspCcpClock_Gating_Control_LS_SET_DLY_MASK 0xf000
#define PspCcpClock_Gating_Control_LS_CLR_DLY_MASK 0xf0000
#define PspCcpClock_Gating_Control_SW_LIGHT_SLEEP_MASK 0x100000

#define PspCcpClock_Gating_Control_MASK \
     (PspCcpClock_Gating_Control_DYN_CLOCK_EN_MASK | \
      PspCcpClock_Gating_Control_GATE_MODE_CCP_MASK | \
      PspCcpClock_Gating_Control_CLK_GATE_DLY_TIMER_MASK | \
      PspCcpClock_Gating_Control_SW_GATE_CCP_MASK | \
      PspCcpClock_Gating_Control_CLK_OFF_DLY_TIMER_MASK | \
      PspCcpClock_Gating_Control_VAR_CCP_LS_EN_MASK | \
      PspCcpClock_Gating_Control_LS_SET_DLY_MASK | \
      PspCcpClock_Gating_Control_LS_CLR_DLY_MASK | \
      PspCcpClock_Gating_Control_SW_LIGHT_SLEEP_MASK)

#define PspCcpClock_Gating_Control_DEFAULT 0x00000000

#define PspCcpClock_Gating_Control_GET_DYN_CLOCK_EN(pspccpclock_gating_control) \
     ((pspccpclock_gating_control & PspCcpClock_Gating_Control_DYN_CLOCK_EN_MASK) >> PspCcpClock_Gating_Control_DYN_CLOCK_EN_SHIFT)
#define PspCcpClock_Gating_Control_GET_GATE_MODE_CCP(pspccpclock_gating_control) \
     ((pspccpclock_gating_control & PspCcpClock_Gating_Control_GATE_MODE_CCP_MASK) >> PspCcpClock_Gating_Control_GATE_MODE_CCP_SHIFT)
#define PspCcpClock_Gating_Control_GET_CLK_GATE_DLY_TIMER(pspccpclock_gating_control) \
     ((pspccpclock_gating_control & PspCcpClock_Gating_Control_CLK_GATE_DLY_TIMER_MASK) >> PspCcpClock_Gating_Control_CLK_GATE_DLY_TIMER_SHIFT)
#define PspCcpClock_Gating_Control_GET_SW_GATE_CCP(pspccpclock_gating_control) \
     ((pspccpclock_gating_control & PspCcpClock_Gating_Control_SW_GATE_CCP_MASK) >> PspCcpClock_Gating_Control_SW_GATE_CCP_SHIFT)
#define PspCcpClock_Gating_Control_GET_CLK_OFF_DLY_TIMER(pspccpclock_gating_control) \
     ((pspccpclock_gating_control & PspCcpClock_Gating_Control_CLK_OFF_DLY_TIMER_MASK) >> PspCcpClock_Gating_Control_CLK_OFF_DLY_TIMER_SHIFT)
#define PspCcpClock_Gating_Control_GET_VAR_CCP_LS_EN(pspccpclock_gating_control) \
     ((pspccpclock_gating_control & PspCcpClock_Gating_Control_VAR_CCP_LS_EN_MASK) >> PspCcpClock_Gating_Control_VAR_CCP_LS_EN_SHIFT)
#define PspCcpClock_Gating_Control_GET_LS_SET_DLY(pspccpclock_gating_control) \
     ((pspccpclock_gating_control & PspCcpClock_Gating_Control_LS_SET_DLY_MASK) >> PspCcpClock_Gating_Control_LS_SET_DLY_SHIFT)
#define PspCcpClock_Gating_Control_GET_LS_CLR_DLY(pspccpclock_gating_control) \
     ((pspccpclock_gating_control & PspCcpClock_Gating_Control_LS_CLR_DLY_MASK) >> PspCcpClock_Gating_Control_LS_CLR_DLY_SHIFT)
#define PspCcpClock_Gating_Control_GET_SW_LIGHT_SLEEP(pspccpclock_gating_control) \
     ((pspccpclock_gating_control & PspCcpClock_Gating_Control_SW_LIGHT_SLEEP_MASK) >> PspCcpClock_Gating_Control_SW_LIGHT_SLEEP_SHIFT)

#define PspCcpClock_Gating_Control_SET_DYN_CLOCK_EN(pspccpclock_gating_control_reg, dyn_clock_en) \
     pspccpclock_gating_control_reg = (pspccpclock_gating_control_reg & ~PspCcpClock_Gating_Control_DYN_CLOCK_EN_MASK) | (dyn_clock_en << PspCcpClock_Gating_Control_DYN_CLOCK_EN_SHIFT)
#define PspCcpClock_Gating_Control_SET_GATE_MODE_CCP(pspccpclock_gating_control_reg, gate_mode_ccp) \
     pspccpclock_gating_control_reg = (pspccpclock_gating_control_reg & ~PspCcpClock_Gating_Control_GATE_MODE_CCP_MASK) | (gate_mode_ccp << PspCcpClock_Gating_Control_GATE_MODE_CCP_SHIFT)
#define PspCcpClock_Gating_Control_SET_CLK_GATE_DLY_TIMER(pspccpclock_gating_control_reg, clk_gate_dly_timer) \
     pspccpclock_gating_control_reg = (pspccpclock_gating_control_reg & ~PspCcpClock_Gating_Control_CLK_GATE_DLY_TIMER_MASK) | (clk_gate_dly_timer << PspCcpClock_Gating_Control_CLK_GATE_DLY_TIMER_SHIFT)
#define PspCcpClock_Gating_Control_SET_SW_GATE_CCP(pspccpclock_gating_control_reg, sw_gate_ccp) \
     pspccpclock_gating_control_reg = (pspccpclock_gating_control_reg & ~PspCcpClock_Gating_Control_SW_GATE_CCP_MASK) | (sw_gate_ccp << PspCcpClock_Gating_Control_SW_GATE_CCP_SHIFT)
#define PspCcpClock_Gating_Control_SET_CLK_OFF_DLY_TIMER(pspccpclock_gating_control_reg, clk_off_dly_timer) \
     pspccpclock_gating_control_reg = (pspccpclock_gating_control_reg & ~PspCcpClock_Gating_Control_CLK_OFF_DLY_TIMER_MASK) | (clk_off_dly_timer << PspCcpClock_Gating_Control_CLK_OFF_DLY_TIMER_SHIFT)
#define PspCcpClock_Gating_Control_SET_VAR_CCP_LS_EN(pspccpclock_gating_control_reg, var_ccp_ls_en) \
     pspccpclock_gating_control_reg = (pspccpclock_gating_control_reg & ~PspCcpClock_Gating_Control_VAR_CCP_LS_EN_MASK) | (var_ccp_ls_en << PspCcpClock_Gating_Control_VAR_CCP_LS_EN_SHIFT)
#define PspCcpClock_Gating_Control_SET_LS_SET_DLY(pspccpclock_gating_control_reg, ls_set_dly) \
     pspccpclock_gating_control_reg = (pspccpclock_gating_control_reg & ~PspCcpClock_Gating_Control_LS_SET_DLY_MASK) | (ls_set_dly << PspCcpClock_Gating_Control_LS_SET_DLY_SHIFT)
#define PspCcpClock_Gating_Control_SET_LS_CLR_DLY(pspccpclock_gating_control_reg, ls_clr_dly) \
     pspccpclock_gating_control_reg = (pspccpclock_gating_control_reg & ~PspCcpClock_Gating_Control_LS_CLR_DLY_MASK) | (ls_clr_dly << PspCcpClock_Gating_Control_LS_CLR_DLY_SHIFT)
#define PspCcpClock_Gating_Control_SET_SW_LIGHT_SLEEP(pspccpclock_gating_control_reg, sw_light_sleep) \
     pspccpclock_gating_control_reg = (pspccpclock_gating_control_reg & ~PspCcpClock_Gating_Control_SW_LIGHT_SLEEP_MASK) | (sw_light_sleep << PspCcpClock_Gating_Control_SW_LIGHT_SLEEP_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccpclock_gating_control_t {
          unsigned int dyn_clock_en                   : PspCcpClock_Gating_Control_DYN_CLOCK_EN_SIZE;
          unsigned int gate_mode_ccp                  : PspCcpClock_Gating_Control_GATE_MODE_CCP_SIZE;
          unsigned int clk_gate_dly_timer             : PspCcpClock_Gating_Control_CLK_GATE_DLY_TIMER_SIZE;
          unsigned int sw_gate_ccp                    : PspCcpClock_Gating_Control_SW_GATE_CCP_SIZE;
          unsigned int clk_off_dly_timer              : PspCcpClock_Gating_Control_CLK_OFF_DLY_TIMER_SIZE;
          unsigned int var_ccp_ls_en                  : PspCcpClock_Gating_Control_VAR_CCP_LS_EN_SIZE;
          unsigned int ls_set_dly                     : PspCcpClock_Gating_Control_LS_SET_DLY_SIZE;
          unsigned int ls_clr_dly                     : PspCcpClock_Gating_Control_LS_CLR_DLY_SIZE;
          unsigned int sw_light_sleep                 : PspCcpClock_Gating_Control_SW_LIGHT_SLEEP_SIZE;
          unsigned int                                : 11;
     } pspccpclock_gating_control_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccpclock_gating_control_t {
          unsigned int                                : 11;
          unsigned int sw_light_sleep                 : PspCcpClock_Gating_Control_SW_LIGHT_SLEEP_SIZE;
          unsigned int ls_clr_dly                     : PspCcpClock_Gating_Control_LS_CLR_DLY_SIZE;
          unsigned int ls_set_dly                     : PspCcpClock_Gating_Control_LS_SET_DLY_SIZE;
          unsigned int var_ccp_ls_en                  : PspCcpClock_Gating_Control_VAR_CCP_LS_EN_SIZE;
          unsigned int clk_off_dly_timer              : PspCcpClock_Gating_Control_CLK_OFF_DLY_TIMER_SIZE;
          unsigned int sw_gate_ccp                    : PspCcpClock_Gating_Control_SW_GATE_CCP_SIZE;
          unsigned int clk_gate_dly_timer             : PspCcpClock_Gating_Control_CLK_GATE_DLY_TIMER_SIZE;
          unsigned int gate_mode_ccp                  : PspCcpClock_Gating_Control_GATE_MODE_CCP_SIZE;
          unsigned int dyn_clock_en                   : PspCcpClock_Gating_Control_DYN_CLOCK_EN_SIZE;
     } pspccpclock_gating_control_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccpclock_gating_control_t f;
} pspccpclock_gating_control_u;


/*
 * PspCcpPgfsm_Config_Reg struct
 */

#define PspCcpPgfsm_Config_Reg_REG_SIZE 32
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_FSM_Addr_SIZE 8
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_Power_Down_SIZE 1
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_Power_Up_SIZE 1
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_P1_Select_SIZE 1
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_Write_SIZE 1
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_Read_SIZE 1
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_RdData_Reset_SIZE 1
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_Short_Format_SIZE 1
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_Reg_Addr_SIZE 4

#define PspCcpPgfsm_Config_Reg_RI_PGFSM_FSM_Addr_SHIFT 0
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_Power_Down_SHIFT 8
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_Power_Up_SHIFT 9
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_P1_Select_SHIFT 10
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_Write_SHIFT 12
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_Read_SHIFT 13
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_RdData_Reset_SHIFT 14
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_Short_Format_SHIFT 15
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_Reg_Addr_SHIFT 28

#define PspCcpPgfsm_Config_Reg_RI_PGFSM_FSM_Addr_MASK 0xff
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_Power_Down_MASK 0x100
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_Power_Up_MASK 0x200
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_P1_Select_MASK 0x400
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_Write_MASK 0x1000
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_Read_MASK 0x2000
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_RdData_Reset_MASK 0x4000
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_Short_Format_MASK 0x8000
#define PspCcpPgfsm_Config_Reg_RI_PGFSM_Reg_Addr_MASK 0xf0000000

#define PspCcpPgfsm_Config_Reg_MASK \
     (PspCcpPgfsm_Config_Reg_RI_PGFSM_FSM_Addr_MASK | \
      PspCcpPgfsm_Config_Reg_RI_PGFSM_Power_Down_MASK | \
      PspCcpPgfsm_Config_Reg_RI_PGFSM_Power_Up_MASK | \
      PspCcpPgfsm_Config_Reg_RI_PGFSM_P1_Select_MASK | \
      PspCcpPgfsm_Config_Reg_RI_PGFSM_Write_MASK | \
      PspCcpPgfsm_Config_Reg_RI_PGFSM_Read_MASK | \
      PspCcpPgfsm_Config_Reg_RI_PGFSM_RdData_Reset_MASK | \
      PspCcpPgfsm_Config_Reg_RI_PGFSM_Short_Format_MASK | \
      PspCcpPgfsm_Config_Reg_RI_PGFSM_Reg_Addr_MASK)

#define PspCcpPgfsm_Config_Reg_DEFAULT 0x00000000

#define PspCcpPgfsm_Config_Reg_GET_RI_PGFSM_FSM_Addr(pspccppgfsm_config_reg) \
     ((pspccppgfsm_config_reg & PspCcpPgfsm_Config_Reg_RI_PGFSM_FSM_Addr_MASK) >> PspCcpPgfsm_Config_Reg_RI_PGFSM_FSM_Addr_SHIFT)
#define PspCcpPgfsm_Config_Reg_GET_RI_PGFSM_Power_Down(pspccppgfsm_config_reg) \
     ((pspccppgfsm_config_reg & PspCcpPgfsm_Config_Reg_RI_PGFSM_Power_Down_MASK) >> PspCcpPgfsm_Config_Reg_RI_PGFSM_Power_Down_SHIFT)
#define PspCcpPgfsm_Config_Reg_GET_RI_PGFSM_Power_Up(pspccppgfsm_config_reg) \
     ((pspccppgfsm_config_reg & PspCcpPgfsm_Config_Reg_RI_PGFSM_Power_Up_MASK) >> PspCcpPgfsm_Config_Reg_RI_PGFSM_Power_Up_SHIFT)
#define PspCcpPgfsm_Config_Reg_GET_RI_PGFSM_P1_Select(pspccppgfsm_config_reg) \
     ((pspccppgfsm_config_reg & PspCcpPgfsm_Config_Reg_RI_PGFSM_P1_Select_MASK) >> PspCcpPgfsm_Config_Reg_RI_PGFSM_P1_Select_SHIFT)
#define PspCcpPgfsm_Config_Reg_GET_RI_PGFSM_Write(pspccppgfsm_config_reg) \
     ((pspccppgfsm_config_reg & PspCcpPgfsm_Config_Reg_RI_PGFSM_Write_MASK) >> PspCcpPgfsm_Config_Reg_RI_PGFSM_Write_SHIFT)
#define PspCcpPgfsm_Config_Reg_GET_RI_PGFSM_Read(pspccppgfsm_config_reg) \
     ((pspccppgfsm_config_reg & PspCcpPgfsm_Config_Reg_RI_PGFSM_Read_MASK) >> PspCcpPgfsm_Config_Reg_RI_PGFSM_Read_SHIFT)
#define PspCcpPgfsm_Config_Reg_GET_RI_PGFSM_RdData_Reset(pspccppgfsm_config_reg) \
     ((pspccppgfsm_config_reg & PspCcpPgfsm_Config_Reg_RI_PGFSM_RdData_Reset_MASK) >> PspCcpPgfsm_Config_Reg_RI_PGFSM_RdData_Reset_SHIFT)
#define PspCcpPgfsm_Config_Reg_GET_RI_PGFSM_Short_Format(pspccppgfsm_config_reg) \
     ((pspccppgfsm_config_reg & PspCcpPgfsm_Config_Reg_RI_PGFSM_Short_Format_MASK) >> PspCcpPgfsm_Config_Reg_RI_PGFSM_Short_Format_SHIFT)
#define PspCcpPgfsm_Config_Reg_GET_RI_PGFSM_Reg_Addr(pspccppgfsm_config_reg) \
     ((pspccppgfsm_config_reg & PspCcpPgfsm_Config_Reg_RI_PGFSM_Reg_Addr_MASK) >> PspCcpPgfsm_Config_Reg_RI_PGFSM_Reg_Addr_SHIFT)

#define PspCcpPgfsm_Config_Reg_SET_RI_PGFSM_FSM_Addr(pspccppgfsm_config_reg_reg, ri_pgfsm_fsm_addr) \
     pspccppgfsm_config_reg_reg = (pspccppgfsm_config_reg_reg & ~PspCcpPgfsm_Config_Reg_RI_PGFSM_FSM_Addr_MASK) | (ri_pgfsm_fsm_addr << PspCcpPgfsm_Config_Reg_RI_PGFSM_FSM_Addr_SHIFT)
#define PspCcpPgfsm_Config_Reg_SET_RI_PGFSM_Power_Down(pspccppgfsm_config_reg_reg, ri_pgfsm_power_down) \
     pspccppgfsm_config_reg_reg = (pspccppgfsm_config_reg_reg & ~PspCcpPgfsm_Config_Reg_RI_PGFSM_Power_Down_MASK) | (ri_pgfsm_power_down << PspCcpPgfsm_Config_Reg_RI_PGFSM_Power_Down_SHIFT)
#define PspCcpPgfsm_Config_Reg_SET_RI_PGFSM_Power_Up(pspccppgfsm_config_reg_reg, ri_pgfsm_power_up) \
     pspccppgfsm_config_reg_reg = (pspccppgfsm_config_reg_reg & ~PspCcpPgfsm_Config_Reg_RI_PGFSM_Power_Up_MASK) | (ri_pgfsm_power_up << PspCcpPgfsm_Config_Reg_RI_PGFSM_Power_Up_SHIFT)
#define PspCcpPgfsm_Config_Reg_SET_RI_PGFSM_P1_Select(pspccppgfsm_config_reg_reg, ri_pgfsm_p1_select) \
     pspccppgfsm_config_reg_reg = (pspccppgfsm_config_reg_reg & ~PspCcpPgfsm_Config_Reg_RI_PGFSM_P1_Select_MASK) | (ri_pgfsm_p1_select << PspCcpPgfsm_Config_Reg_RI_PGFSM_P1_Select_SHIFT)
#define PspCcpPgfsm_Config_Reg_SET_RI_PGFSM_Write(pspccppgfsm_config_reg_reg, ri_pgfsm_write) \
     pspccppgfsm_config_reg_reg = (pspccppgfsm_config_reg_reg & ~PspCcpPgfsm_Config_Reg_RI_PGFSM_Write_MASK) | (ri_pgfsm_write << PspCcpPgfsm_Config_Reg_RI_PGFSM_Write_SHIFT)
#define PspCcpPgfsm_Config_Reg_SET_RI_PGFSM_Read(pspccppgfsm_config_reg_reg, ri_pgfsm_read) \
     pspccppgfsm_config_reg_reg = (pspccppgfsm_config_reg_reg & ~PspCcpPgfsm_Config_Reg_RI_PGFSM_Read_MASK) | (ri_pgfsm_read << PspCcpPgfsm_Config_Reg_RI_PGFSM_Read_SHIFT)
#define PspCcpPgfsm_Config_Reg_SET_RI_PGFSM_RdData_Reset(pspccppgfsm_config_reg_reg, ri_pgfsm_rddata_reset) \
     pspccppgfsm_config_reg_reg = (pspccppgfsm_config_reg_reg & ~PspCcpPgfsm_Config_Reg_RI_PGFSM_RdData_Reset_MASK) | (ri_pgfsm_rddata_reset << PspCcpPgfsm_Config_Reg_RI_PGFSM_RdData_Reset_SHIFT)
#define PspCcpPgfsm_Config_Reg_SET_RI_PGFSM_Short_Format(pspccppgfsm_config_reg_reg, ri_pgfsm_short_format) \
     pspccppgfsm_config_reg_reg = (pspccppgfsm_config_reg_reg & ~PspCcpPgfsm_Config_Reg_RI_PGFSM_Short_Format_MASK) | (ri_pgfsm_short_format << PspCcpPgfsm_Config_Reg_RI_PGFSM_Short_Format_SHIFT)
#define PspCcpPgfsm_Config_Reg_SET_RI_PGFSM_Reg_Addr(pspccppgfsm_config_reg_reg, ri_pgfsm_reg_addr) \
     pspccppgfsm_config_reg_reg = (pspccppgfsm_config_reg_reg & ~PspCcpPgfsm_Config_Reg_RI_PGFSM_Reg_Addr_MASK) | (ri_pgfsm_reg_addr << PspCcpPgfsm_Config_Reg_RI_PGFSM_Reg_Addr_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccppgfsm_config_reg_t {
          unsigned int ri_pgfsm_fsm_addr              : PspCcpPgfsm_Config_Reg_RI_PGFSM_FSM_Addr_SIZE;
          unsigned int ri_pgfsm_power_down            : PspCcpPgfsm_Config_Reg_RI_PGFSM_Power_Down_SIZE;
          unsigned int ri_pgfsm_power_up              : PspCcpPgfsm_Config_Reg_RI_PGFSM_Power_Up_SIZE;
          unsigned int ri_pgfsm_p1_select             : PspCcpPgfsm_Config_Reg_RI_PGFSM_P1_Select_SIZE;
          unsigned int                                : 1;
          unsigned int ri_pgfsm_write                 : PspCcpPgfsm_Config_Reg_RI_PGFSM_Write_SIZE;
          unsigned int ri_pgfsm_read                  : PspCcpPgfsm_Config_Reg_RI_PGFSM_Read_SIZE;
          unsigned int ri_pgfsm_rddata_reset          : PspCcpPgfsm_Config_Reg_RI_PGFSM_RdData_Reset_SIZE;
          unsigned int ri_pgfsm_short_format          : PspCcpPgfsm_Config_Reg_RI_PGFSM_Short_Format_SIZE;
          unsigned int                                : 12;
          unsigned int ri_pgfsm_reg_addr              : PspCcpPgfsm_Config_Reg_RI_PGFSM_Reg_Addr_SIZE;
     } pspccppgfsm_config_reg_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccppgfsm_config_reg_t {
          unsigned int ri_pgfsm_reg_addr              : PspCcpPgfsm_Config_Reg_RI_PGFSM_Reg_Addr_SIZE;
          unsigned int                                : 12;
          unsigned int ri_pgfsm_short_format          : PspCcpPgfsm_Config_Reg_RI_PGFSM_Short_Format_SIZE;
          unsigned int ri_pgfsm_rddata_reset          : PspCcpPgfsm_Config_Reg_RI_PGFSM_RdData_Reset_SIZE;
          unsigned int ri_pgfsm_read                  : PspCcpPgfsm_Config_Reg_RI_PGFSM_Read_SIZE;
          unsigned int ri_pgfsm_write                 : PspCcpPgfsm_Config_Reg_RI_PGFSM_Write_SIZE;
          unsigned int                                : 1;
          unsigned int ri_pgfsm_p1_select             : PspCcpPgfsm_Config_Reg_RI_PGFSM_P1_Select_SIZE;
          unsigned int ri_pgfsm_power_up              : PspCcpPgfsm_Config_Reg_RI_PGFSM_Power_Up_SIZE;
          unsigned int ri_pgfsm_power_down            : PspCcpPgfsm_Config_Reg_RI_PGFSM_Power_Down_SIZE;
          unsigned int ri_pgfsm_fsm_addr              : PspCcpPgfsm_Config_Reg_RI_PGFSM_FSM_Addr_SIZE;
     } pspccppgfsm_config_reg_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccppgfsm_config_reg_t f;
} pspccppgfsm_config_reg_u;


/*
 * PspCcpPgfsm_Write_Reg struct
 */

#define PspCcpPgfsm_Write_Reg_REG_SIZE 32
#define PspCcpPgfsm_Write_Reg_RI_PGFSM_Write_Value_SIZE 32

#define PspCcpPgfsm_Write_Reg_RI_PGFSM_Write_Value_SHIFT 0

#define PspCcpPgfsm_Write_Reg_RI_PGFSM_Write_Value_MASK 0xffffffff

#define PspCcpPgfsm_Write_Reg_MASK \
     (PspCcpPgfsm_Write_Reg_RI_PGFSM_Write_Value_MASK)

#define PspCcpPgfsm_Write_Reg_DEFAULT  0x00000000

#define PspCcpPgfsm_Write_Reg_GET_RI_PGFSM_Write_Value(pspccppgfsm_write_reg) \
     ((pspccppgfsm_write_reg & PspCcpPgfsm_Write_Reg_RI_PGFSM_Write_Value_MASK) >> PspCcpPgfsm_Write_Reg_RI_PGFSM_Write_Value_SHIFT)

#define PspCcpPgfsm_Write_Reg_SET_RI_PGFSM_Write_Value(pspccppgfsm_write_reg_reg, ri_pgfsm_write_value) \
     pspccppgfsm_write_reg_reg = (pspccppgfsm_write_reg_reg & ~PspCcpPgfsm_Write_Reg_RI_PGFSM_Write_Value_MASK) | (ri_pgfsm_write_value << PspCcpPgfsm_Write_Reg_RI_PGFSM_Write_Value_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccppgfsm_write_reg_t {
          unsigned int ri_pgfsm_write_value           : PspCcpPgfsm_Write_Reg_RI_PGFSM_Write_Value_SIZE;
     } pspccppgfsm_write_reg_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccppgfsm_write_reg_t {
          unsigned int ri_pgfsm_write_value           : PspCcpPgfsm_Write_Reg_RI_PGFSM_Write_Value_SIZE;
     } pspccppgfsm_write_reg_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccppgfsm_write_reg_t f;
} pspccppgfsm_write_reg_u;


/*
 * PspCcpPgfsm_Read_Reg struct
 */

#define PspCcpPgfsm_Read_Reg_REG_SIZE  32
#define PspCcpPgfsm_Read_Reg_RI_PGFSM_Read_Value_SIZE 32

#define PspCcpPgfsm_Read_Reg_RI_PGFSM_Read_Value_SHIFT 0

#define PspCcpPgfsm_Read_Reg_RI_PGFSM_Read_Value_MASK 0xffffffff

#define PspCcpPgfsm_Read_Reg_MASK \
     (PspCcpPgfsm_Read_Reg_RI_PGFSM_Read_Value_MASK)

#define PspCcpPgfsm_Read_Reg_DEFAULT   0x00000000

#define PspCcpPgfsm_Read_Reg_GET_RI_PGFSM_Read_Value(pspccppgfsm_read_reg) \
     ((pspccppgfsm_read_reg & PspCcpPgfsm_Read_Reg_RI_PGFSM_Read_Value_MASK) >> PspCcpPgfsm_Read_Reg_RI_PGFSM_Read_Value_SHIFT)

#define PspCcpPgfsm_Read_Reg_SET_RI_PGFSM_Read_Value(pspccppgfsm_read_reg_reg, ri_pgfsm_read_value) \
     pspccppgfsm_read_reg_reg = (pspccppgfsm_read_reg_reg & ~PspCcpPgfsm_Read_Reg_RI_PGFSM_Read_Value_MASK) | (ri_pgfsm_read_value << PspCcpPgfsm_Read_Reg_RI_PGFSM_Read_Value_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccppgfsm_read_reg_t {
          unsigned int ri_pgfsm_read_value            : PspCcpPgfsm_Read_Reg_RI_PGFSM_Read_Value_SIZE;
     } pspccppgfsm_read_reg_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccppgfsm_read_reg_t {
          unsigned int ri_pgfsm_read_value            : PspCcpPgfsm_Read_Reg_RI_PGFSM_Read_Value_SIZE;
     } pspccppgfsm_read_reg_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccppgfsm_read_reg_t f;
} pspccppgfsm_read_reg_u;


/*
 * PspCcpPg_Control struct
 */

#define PspCcpPg_Control_REG_SIZE      32
#define PspCcpPg_Control_PG_DELAY_SIZE 8
#define PspCcpPg_Control_HW_PG_EN_SIZE 1

#define PspCcpPg_Control_PG_DELAY_SHIFT 0
#define PspCcpPg_Control_HW_PG_EN_SHIFT 8

#define PspCcpPg_Control_PG_DELAY_MASK 0xff
#define PspCcpPg_Control_HW_PG_EN_MASK 0x100

#define PspCcpPg_Control_MASK \
     (PspCcpPg_Control_PG_DELAY_MASK | \
      PspCcpPg_Control_HW_PG_EN_MASK)

#define PspCcpPg_Control_DEFAULT       0x0000000f

#define PspCcpPg_Control_GET_PG_DELAY(pspccppg_control) \
     ((pspccppg_control & PspCcpPg_Control_PG_DELAY_MASK) >> PspCcpPg_Control_PG_DELAY_SHIFT)
#define PspCcpPg_Control_GET_HW_PG_EN(pspccppg_control) \
     ((pspccppg_control & PspCcpPg_Control_HW_PG_EN_MASK) >> PspCcpPg_Control_HW_PG_EN_SHIFT)

#define PspCcpPg_Control_SET_PG_DELAY(pspccppg_control_reg, pg_delay) \
     pspccppg_control_reg = (pspccppg_control_reg & ~PspCcpPg_Control_PG_DELAY_MASK) | (pg_delay << PspCcpPg_Control_PG_DELAY_SHIFT)
#define PspCcpPg_Control_SET_HW_PG_EN(pspccppg_control_reg, hw_pg_en) \
     pspccppg_control_reg = (pspccppg_control_reg & ~PspCcpPg_Control_HW_PG_EN_MASK) | (hw_pg_en << PspCcpPg_Control_HW_PG_EN_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccppg_control_t {
          unsigned int pg_delay                       : PspCcpPg_Control_PG_DELAY_SIZE;
          unsigned int hw_pg_en                       : PspCcpPg_Control_HW_PG_EN_SIZE;
          unsigned int                                : 23;
     } pspccppg_control_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccppg_control_t {
          unsigned int                                : 23;
          unsigned int hw_pg_en                       : PspCcpPg_Control_HW_PG_EN_SIZE;
          unsigned int pg_delay                       : PspCcpPg_Control_PG_DELAY_SIZE;
     } pspccppg_control_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccppg_control_t f;
} pspccppg_control_u;


/*
 * PspCcpPg_Status struct
 */

#define PspCcpPg_Status_REG_SIZE       32
#define PspCcpPg_Status_POWER_STATUS_P1_SIZE 2

#define PspCcpPg_Status_POWER_STATUS_P1_SHIFT 0

#define PspCcpPg_Status_POWER_STATUS_P1_MASK 0x3

#define PspCcpPg_Status_MASK \
     (PspCcpPg_Status_POWER_STATUS_P1_MASK)

#define PspCcpPg_Status_DEFAULT        0x00000000

#define PspCcpPg_Status_GET_POWER_STATUS_P1(pspccppg_status) \
     ((pspccppg_status & PspCcpPg_Status_POWER_STATUS_P1_MASK) >> PspCcpPg_Status_POWER_STATUS_P1_SHIFT)

#define PspCcpPg_Status_SET_POWER_STATUS_P1(pspccppg_status_reg, power_status_p1) \
     pspccppg_status_reg = (pspccppg_status_reg & ~PspCcpPg_Status_POWER_STATUS_P1_MASK) | (power_status_p1 << PspCcpPg_Status_POWER_STATUS_P1_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccppg_status_t {
          unsigned int power_status_p1                : PspCcpPg_Status_POWER_STATUS_P1_SIZE;
          unsigned int                                : 30;
     } pspccppg_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccppg_status_t {
          unsigned int                                : 30;
          unsigned int power_status_p1                : PspCcpPg_Status_POWER_STATUS_P1_SIZE;
     } pspccppg_status_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccppg_status_t f;
} pspccppg_status_u;


/*
 * PspCcp_pgmem_Control struct
 */

#define PspCcp_pgmem_Control_REG_SIZE  32
#define PspCcp_pgmem_Control_KSB_RAM_LS_EN_SIZE 1
#define PspCcp_pgmem_Control_KSB_RAM_DS_EN_SIZE 1
#define PspCcp_pgmem_Control_KSB_RAM_SLEEP_SIZE 1
#define PspCcp_pgmem_Control_LS_INACT_TIMER_SIZE 8
#define PspCcp_pgmem_Control_DS_INACT_TIMER_SIZE 8
#define PspCcp_pgmem_Control_MEM_SLEEP_TIMER_SIZE 8

#define PspCcp_pgmem_Control_KSB_RAM_LS_EN_SHIFT 0
#define PspCcp_pgmem_Control_KSB_RAM_DS_EN_SHIFT 1
#define PspCcp_pgmem_Control_KSB_RAM_SLEEP_SHIFT 2
#define PspCcp_pgmem_Control_LS_INACT_TIMER_SHIFT 8
#define PspCcp_pgmem_Control_DS_INACT_TIMER_SHIFT 16
#define PspCcp_pgmem_Control_MEM_SLEEP_TIMER_SHIFT 24

#define PspCcp_pgmem_Control_KSB_RAM_LS_EN_MASK 0x1
#define PspCcp_pgmem_Control_KSB_RAM_DS_EN_MASK 0x2
#define PspCcp_pgmem_Control_KSB_RAM_SLEEP_MASK 0x4
#define PspCcp_pgmem_Control_LS_INACT_TIMER_MASK 0xff00
#define PspCcp_pgmem_Control_DS_INACT_TIMER_MASK 0xff0000
#define PspCcp_pgmem_Control_MEM_SLEEP_TIMER_MASK 0xff000000

#define PspCcp_pgmem_Control_MASK \
     (PspCcp_pgmem_Control_KSB_RAM_LS_EN_MASK | \
      PspCcp_pgmem_Control_KSB_RAM_DS_EN_MASK | \
      PspCcp_pgmem_Control_KSB_RAM_SLEEP_MASK | \
      PspCcp_pgmem_Control_LS_INACT_TIMER_MASK | \
      PspCcp_pgmem_Control_DS_INACT_TIMER_MASK | \
      PspCcp_pgmem_Control_MEM_SLEEP_TIMER_MASK)

#define PspCcp_pgmem_Control_DEFAULT   0x0f010100

#define PspCcp_pgmem_Control_GET_KSB_RAM_LS_EN(pspccp_pgmem_control) \
     ((pspccp_pgmem_control & PspCcp_pgmem_Control_KSB_RAM_LS_EN_MASK) >> PspCcp_pgmem_Control_KSB_RAM_LS_EN_SHIFT)
#define PspCcp_pgmem_Control_GET_KSB_RAM_DS_EN(pspccp_pgmem_control) \
     ((pspccp_pgmem_control & PspCcp_pgmem_Control_KSB_RAM_DS_EN_MASK) >> PspCcp_pgmem_Control_KSB_RAM_DS_EN_SHIFT)
#define PspCcp_pgmem_Control_GET_KSB_RAM_SLEEP(pspccp_pgmem_control) \
     ((pspccp_pgmem_control & PspCcp_pgmem_Control_KSB_RAM_SLEEP_MASK) >> PspCcp_pgmem_Control_KSB_RAM_SLEEP_SHIFT)
#define PspCcp_pgmem_Control_GET_LS_INACT_TIMER(pspccp_pgmem_control) \
     ((pspccp_pgmem_control & PspCcp_pgmem_Control_LS_INACT_TIMER_MASK) >> PspCcp_pgmem_Control_LS_INACT_TIMER_SHIFT)
#define PspCcp_pgmem_Control_GET_DS_INACT_TIMER(pspccp_pgmem_control) \
     ((pspccp_pgmem_control & PspCcp_pgmem_Control_DS_INACT_TIMER_MASK) >> PspCcp_pgmem_Control_DS_INACT_TIMER_SHIFT)
#define PspCcp_pgmem_Control_GET_MEM_SLEEP_TIMER(pspccp_pgmem_control) \
     ((pspccp_pgmem_control & PspCcp_pgmem_Control_MEM_SLEEP_TIMER_MASK) >> PspCcp_pgmem_Control_MEM_SLEEP_TIMER_SHIFT)

#define PspCcp_pgmem_Control_SET_KSB_RAM_LS_EN(pspccp_pgmem_control_reg, ksb_ram_ls_en) \
     pspccp_pgmem_control_reg = (pspccp_pgmem_control_reg & ~PspCcp_pgmem_Control_KSB_RAM_LS_EN_MASK) | (ksb_ram_ls_en << PspCcp_pgmem_Control_KSB_RAM_LS_EN_SHIFT)
#define PspCcp_pgmem_Control_SET_KSB_RAM_DS_EN(pspccp_pgmem_control_reg, ksb_ram_ds_en) \
     pspccp_pgmem_control_reg = (pspccp_pgmem_control_reg & ~PspCcp_pgmem_Control_KSB_RAM_DS_EN_MASK) | (ksb_ram_ds_en << PspCcp_pgmem_Control_KSB_RAM_DS_EN_SHIFT)
#define PspCcp_pgmem_Control_SET_KSB_RAM_SLEEP(pspccp_pgmem_control_reg, ksb_ram_sleep) \
     pspccp_pgmem_control_reg = (pspccp_pgmem_control_reg & ~PspCcp_pgmem_Control_KSB_RAM_SLEEP_MASK) | (ksb_ram_sleep << PspCcp_pgmem_Control_KSB_RAM_SLEEP_SHIFT)
#define PspCcp_pgmem_Control_SET_LS_INACT_TIMER(pspccp_pgmem_control_reg, ls_inact_timer) \
     pspccp_pgmem_control_reg = (pspccp_pgmem_control_reg & ~PspCcp_pgmem_Control_LS_INACT_TIMER_MASK) | (ls_inact_timer << PspCcp_pgmem_Control_LS_INACT_TIMER_SHIFT)
#define PspCcp_pgmem_Control_SET_DS_INACT_TIMER(pspccp_pgmem_control_reg, ds_inact_timer) \
     pspccp_pgmem_control_reg = (pspccp_pgmem_control_reg & ~PspCcp_pgmem_Control_DS_INACT_TIMER_MASK) | (ds_inact_timer << PspCcp_pgmem_Control_DS_INACT_TIMER_SHIFT)
#define PspCcp_pgmem_Control_SET_MEM_SLEEP_TIMER(pspccp_pgmem_control_reg, mem_sleep_timer) \
     pspccp_pgmem_control_reg = (pspccp_pgmem_control_reg & ~PspCcp_pgmem_Control_MEM_SLEEP_TIMER_MASK) | (mem_sleep_timer << PspCcp_pgmem_Control_MEM_SLEEP_TIMER_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _pspccp_pgmem_control_t {
          unsigned int ksb_ram_ls_en                  : PspCcp_pgmem_Control_KSB_RAM_LS_EN_SIZE;
          unsigned int ksb_ram_ds_en                  : PspCcp_pgmem_Control_KSB_RAM_DS_EN_SIZE;
          unsigned int ksb_ram_sleep                  : PspCcp_pgmem_Control_KSB_RAM_SLEEP_SIZE;
          unsigned int                                : 5;
          unsigned int ls_inact_timer                 : PspCcp_pgmem_Control_LS_INACT_TIMER_SIZE;
          unsigned int ds_inact_timer                 : PspCcp_pgmem_Control_DS_INACT_TIMER_SIZE;
          unsigned int mem_sleep_timer                : PspCcp_pgmem_Control_MEM_SLEEP_TIMER_SIZE;
     } pspccp_pgmem_control_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _pspccp_pgmem_control_t {
          unsigned int mem_sleep_timer                : PspCcp_pgmem_Control_MEM_SLEEP_TIMER_SIZE;
          unsigned int ds_inact_timer                 : PspCcp_pgmem_Control_DS_INACT_TIMER_SIZE;
          unsigned int ls_inact_timer                 : PspCcp_pgmem_Control_LS_INACT_TIMER_SIZE;
          unsigned int                                : 5;
          unsigned int ksb_ram_sleep                  : PspCcp_pgmem_Control_KSB_RAM_SLEEP_SIZE;
          unsigned int ksb_ram_ds_en                  : PspCcp_pgmem_Control_KSB_RAM_DS_EN_SIZE;
          unsigned int ksb_ram_ls_en                  : PspCcp_pgmem_Control_KSB_RAM_LS_EN_SIZE;
     } pspccp_pgmem_control_t;

#endif

typedef union {
     unsigned int val : 32;
     pspccp_pgmem_control_t f;
} pspccp_pgmem_control_u;


#endif


