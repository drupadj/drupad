// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MP0_DRM_SMN_MASK_H)
#define _MP0_DRM_SMN_MASK_H

/*****************************************************************************************************************
 *
 *	mp0_drm_smn_mask.h
 *
 *	Register Spec Release:  <unknown>
*
*	 (c) 2000 ATI Technologies Inc.  (unpublished)
*
*	 All rights reserved.  This notice is intended as a precaution against
*	 inadvertent publication and does not imply publication or any waiver
*	 of confidentiality.  The year included in the foregoing notice is the
*	 year of creation of the work.
*
 *****************************************************************************************************************/

/*******************************************************
 * Read and Write Masks
 *******************************************************/

#define MP0_SMN_DRM_KEYGEN_START_READ_MASK 0x0
#define MP0_SMN_DRM_KEYGEN_START_WRITE_MASK 0xffffffff

#define MP0_SMN_DRM_KEYGEN_CONT_READ_MASK 0x0
#define MP0_SMN_DRM_KEYGEN_CONT_WRITE_MASK 0xffffffff

#define MP0_SMN_DRM_KEYGEN_RADDR_READ_MASK 0x3f
#define MP0_SMN_DRM_KEYGEN_RADDR_WRITE_MASK 0x3f

#define MP0_SMN_DRM_KEYGEN_RDATA_READ_MASK 0xffffffff
#define MP0_SMN_DRM_KEYGEN_RDATA_WRITE_MASK 0xffffffff

#define MP0_SMN_DRM_KEYGEN_WADDR_READ_MASK 0x3f
#define MP0_SMN_DRM_KEYGEN_WADDR_WRITE_MASK 0x3f

#define MP0_SMN_DRM_KEYGEN_WDATA_READ_MASK 0xffffffff
#define MP0_SMN_DRM_KEYGEN_WDATA_WRITE_MASK 0xffffffff

#define MP0_SMN_DRM_HFS_START_READ_MASK 0xf
#define MP0_SMN_DRM_HFS_START_WRITE_MASK 0xf

#define MP0_SMN_DRM_HFS_SW_NONCE0_READ_MASK 0xffffffff
#define MP0_SMN_DRM_HFS_SW_NONCE0_WRITE_MASK 0xffffffff

#define MP0_SMN_DRM_HFS_SW_NONCE1_READ_MASK 0xffffffff
#define MP0_SMN_DRM_HFS_SW_NONCE1_WRITE_MASK 0xffffffff

#define MP0_SMN_DRM_HFS_SW_NONCE2_READ_MASK 0xffffffff
#define MP0_SMN_DRM_HFS_SW_NONCE2_WRITE_MASK 0xffffffff

#define MP0_SMN_DRM_HFS_SW_NONCE3_READ_MASK 0xffffffff
#define MP0_SMN_DRM_HFS_SW_NONCE3_WRITE_MASK 0xffffffff

#define MP0_SMN_DRM_HFS_HW_NONCE0_READ_MASK 0xffffffff
#define MP0_SMN_DRM_HFS_HW_NONCE0_WRITE_MASK 0x0

#define MP0_SMN_DRM_HFS_HW_NONCE1_READ_MASK 0xffffffff
#define MP0_SMN_DRM_HFS_HW_NONCE1_WRITE_MASK 0x0

#define MP0_SMN_DRM_HFS_HW_NONCE2_READ_MASK 0xffffffff
#define MP0_SMN_DRM_HFS_HW_NONCE2_WRITE_MASK 0x0

#define MP0_SMN_DRM_HFS_HW_NONCE3_READ_MASK 0xffffffff
#define MP0_SMN_DRM_HFS_HW_NONCE3_WRITE_MASK 0x0

#define MP0_SMN_DRM_SHARED_CLIENT_READ_MASK 0x1
#define MP0_SMN_DRM_SHARED_CLIENT_WRITE_MASK 0x1

#define MP0_SMN_DRM_TIMEOUT_READ_MASK  0xffffffff
#define MP0_SMN_DRM_TIMEOUT_WRITE_MASK 0xffffffff

#define MP0_SMN_DRM_BYTESWAP_READ_MASK 0x3010101
#define MP0_SMN_DRM_BYTESWAP_WRITE_MASK 0x3010101

#define MP0_SMN_DRM_RESET_READ_MASK    0xff810101
#define MP0_SMN_DRM_RESET_WRITE_MASK   0xff810101

#define MP0_SMN_DRM_ARB_PRIORITY_READ_MASK 0xffffffff
#define MP0_SMN_DRM_ARB_PRIORITY_WRITE_MASK 0xffffffff

#define MP0_SMN_DRM_TRNG_CNTL_READ_MASK 0x103
#define MP0_SMN_DRM_TRNG_CNTL_WRITE_MASK 0x103

#define MP0_SMN_DRM_TRNG_DATA_READ_MASK 0xffffffff
#define MP0_SMN_DRM_TRNG_DATA_WRITE_MASK 0x0

#define MP0_SMN_DRM_PERFMON_CNTL_READ_MASK 0xf
#define MP0_SMN_DRM_PERFMON_CNTL_WRITE_MASK 0xf

#define MP0_SMN_DRM_PERFCOUNTER1_SELECT_READ_MASK 0x3f
#define MP0_SMN_DRM_PERFCOUNTER1_SELECT_WRITE_MASK 0x3f

#define MP0_SMN_DRM_PERFCOUNTER2_SELECT_READ_MASK 0x3f
#define MP0_SMN_DRM_PERFCOUNTER2_SELECT_WRITE_MASK 0x3f

#define MP0_SMN_DRM_PERFCOUNTER1_LO_READ_MASK 0xffffffff
#define MP0_SMN_DRM_PERFCOUNTER1_LO_WRITE_MASK 0xffffffff

#define MP0_SMN_DRM_PERFCOUNTER1_HI_READ_MASK 0xffff
#define MP0_SMN_DRM_PERFCOUNTER1_HI_WRITE_MASK 0xffff

#define MP0_SMN_DRM_PERFCOUNTER2_LO_READ_MASK 0xffffffff
#define MP0_SMN_DRM_PERFCOUNTER2_LO_WRITE_MASK 0xffffffff

#define MP0_SMN_DRM_PERFCOUNTER2_HI_READ_MASK 0xffff
#define MP0_SMN_DRM_PERFCOUNTER2_HI_WRITE_MASK 0xffff

#define MP0_SMN_DRM_DEBUG_READ_MASK    0xffffffff
#define MP0_SMN_DRM_DEBUG_WRITE_MASK   0xffffffff

#define MP0_SMN_DRM_IH_CREDITS_READ_MASK 0x1f
#define MP0_SMN_DRM_IH_CREDITS_WRITE_MASK 0x1f

#define MP0_SMN_DRM_INT_STATUS_READ_MASK 0x7fff
#define MP0_SMN_DRM_INT_STATUS_WRITE_MASK 0x7fff

#define MP0_SMN_DRM_INT_MASK_READ_MASK 0x7fff
#define MP0_SMN_DRM_INT_MASK_WRITE_MASK 0x7fff

#define MP0_SMN_DRM_INT_ACK_READ_MASK  0x0
#define MP0_SMN_DRM_INT_ACK_WRITE_MASK 0x7fff

#define MP0_SMN_DRM_STATUS_READ_MASK   0xff771fff
#define MP0_SMN_DRM_STATUS_WRITE_MASK  0x0

#define MP0_SMN_DRM_PROTO_ADDR_READ_MASK 0xfff
#define MP0_SMN_DRM_PROTO_ADDR_WRITE_MASK 0xfff

#define MP0_SMN_DRM_PROTO_DATA_READ_MASK 0xffffffff
#define MP0_SMN_DRM_PROTO_DATA_WRITE_MASK 0xffffffff

#define MP0_SMN_CGTT_DRM_CLK_CTRL0_READ_MASK 0xff607fff
#define MP0_SMN_CGTT_DRM_CLK_CTRL0_WRITE_MASK 0xff207fff

#define MP0_SMN_DRM_MASTER_CTRL_READ_MASK 0xf
#define MP0_SMN_DRM_MASTER_CTRL_WRITE_MASK 0xf

#define MP0_SMN_DRM_AUTH_SESSION_READ_MASK 0xf
#define MP0_SMN_DRM_AUTH_SESSION_WRITE_MASK 0xf

#define MP0_SMN_DC_TEST_DEBUG_INDEX_READ_MASK 0x1ff
#define MP0_SMN_DC_TEST_DEBUG_INDEX_WRITE_MASK 0x1ff

#define MP0_SMN_DC_TEST_DEBUG_DATA_READ_MASK 0xffffffff
#define MP0_SMN_DC_TEST_DEBUG_DATA_WRITE_MASK 0xffffffff

#define MP0_SMN_DRM_CNT_KEY_STATUS_READ_MASK 0x1f
#define MP0_SMN_DRM_CNT_KEY_STATUS_WRITE_MASK 0x1f

#define MP0_SMN_DRM_CLIENT4_EXT_READ_MASK 0x7ff
#define MP0_SMN_DRM_CLIENT4_EXT_WRITE_MASK 0x7ff

#define MP0_SMN_DH_TEST_READ_MASK      0x1
#define MP0_SMN_DH_TEST_WRITE_MASK     0x1

#define MP0_SMN_DRM_DEBUG_ID_READ_MASK 0xffffffff
#define MP0_SMN_DRM_DEBUG_ID_WRITE_MASK 0xffffffff

#endif


