// Copyright (c) 2010 - 2019 Advanced Micro Devices, Inc. All rights reserved.
#ifndef __ENV_FEATURES_H__
#define __ENV_FEATURES_H__
// reference features

// imported features

// local features
#define ENV__VARIANT raphael
#define ENV__VARIANT__RAPHAEL 1
#define ENV__FLAVOR apu
#define ENV__FLAVOR__APU 1
#define ENV__PERF_VIEW 1
#define ENV__PERF_VIEW__1 1
#define GC__PERF_VIEW 1
#define GC__PERF_VIEW__1 1
#define ENV__IP_ENV 0
#define ENV__IP_ENV__0 1
#define GC__IP_ENV 0
#define GC__IP_ENV__0 1
#define ENV__SOC_ENV 1
#define ENV__SOC_ENV__1 1
#define GC__SOC_ENV 1
#define GC__SOC_ENV__1 1
#endif
