// Copyright (c) 2010 - 2019 Advanced Micro Devices, Inc. All rights reserved.
#ifndef __TECH_FEATURES_H__
#define __TECH_FEATURES_H__
// reference features

// imported features

// local features
#define GPU__TECH__VARIANT phoenix
#define GPU__TECH__VARIANT__PHOENIX 1
#define TECH__VARIANT phoenix
#define TECH__VARIANT__PHOENIX 1
#define GPU__TECH__TECHVARIANT phx_lib
#define GPU__TECH__TECHVARIANT__PHX_LIB 1
#define TECH__TECHVARIANT phx_lib
#define TECH__TECHVARIANT__PHX_LIB 1
#define GPU__TECH__TAPEOUT a0
#define GPU__TECH__TAPEOUT__A0 1
#define TECH__TAPEOUT a0
#define TECH__TAPEOUT__A0 1
#define GPU__TECH__TECHVER 3.0.0
#define GPU__TECH__TECHVER__3_0_0 1
#define TECH__TECHVER 3.0.0
#define TECH__TECHVER__3_0_0 1
#define GPU__TECH__TECH tsmc5n210h
#define GPU__TECH__TECH__TSMC5N210H 1
#define TECH__TECH tsmc5n210h
#define TECH__TECH__TSMC5N210H 1
#define GPU__TECH__TECHOPCON tt0p65v0c
#define GPU__TECH__TECHOPCON__TT0P65V0C 1
#define TECH__TECHOPCON tt0p65v0c
#define TECH__TECHOPCON__TT0P65V0C 1
#define GPU__TECH__TECHVER2 lib_3.0.0
#define GPU__TECH__TECHVER2__LIB_3_0_0 1
#define TECH__TECHVER2 lib_3.0.0
#define TECH__TECHVER2__LIB_3_0_0 1
#define GPU__TECH__LIB_PATH "/proj/phx_lib/a0/library/lib_3.0.0"
#define TECH__LIB_PATH "/proj/phx_lib/a0/library/lib_3.0.0"
#endif
