// Copyright (c) 2010 - 2019 Advanced Micro Devices, Inc. All rights reserved.
#ifndef __SMU_FEATURES_H__
#define __SMU_FEATURES_H__
// reference features

// imported features

// local features
#define GPU__SMU__VARIANT rembrandt
#define GPU__SMU__VARIANT__REMBRANDT 1
#define SMU__VARIANT rembrandt
#define SMU__VARIANT__REMBRANDT 1
#define GPU__SMU__PRESENT 1
#define GPU__SMU__PRESENT__1 1
#define SMU__PRESENT 1
#define SMU__PRESENT__1 1
#define GPU__SMU__BLOCK_COMPILE 1
#define GPU__SMU__BLOCK_COMPILE__1 1
#define SMU__BLOCK_COMPILE 1
#define SMU__BLOCK_COMPILE__1 1
#endif
