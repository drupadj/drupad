// Copyright (c) 1994 - 2021 Advanced Micro Devices, Inc. All rights reserved. 
 #if !defined (_MP0_MMU_FIDDLE_H)
#define _MP0_MMU_FIDDLE_H
 /*****************************************************************************************************************
 *
 *  mp0_mmu_reg.h
 *
 *  Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif

 /*******************************************************
 * Values
 *******************************************************/

 /*******************************************************
 * Structures
 *******************************************************/

/*
 * MP0_MMU_SRAM_FLOP_START_ADDR struct
 */

#define MP0_MMU_SRAM_FLOP_START_ADDR_REG_SIZE         32
#define MP0_MMU_SRAM_FLOP_START_ADDR_VALUE_SIZE  32

#define MP0_MMU_SRAM_FLOP_START_ADDR_VALUE_SHIFT  0

#define MP0_MMU_SRAM_FLOP_START_ADDR_VALUE_MASK  0xffffffff

#define MP0_MMU_SRAM_FLOP_START_ADDR_MASK \
      (MP0_MMU_SRAM_FLOP_START_ADDR_VALUE_MASK)

#define MP0_MMU_SRAM_FLOP_START_ADDR_DEFAULT 0x00000000

#define MP0_MMU_SRAM_FLOP_START_ADDR_GET_VALUE(mp0_mmu_sram_flop_start_addr) \
      ((mp0_mmu_sram_flop_start_addr & MP0_MMU_SRAM_FLOP_START_ADDR_VALUE_MASK) >> MP0_MMU_SRAM_FLOP_START_ADDR_VALUE_SHIFT)

#define MP0_MMU_SRAM_FLOP_START_ADDR_SET_VALUE(mp0_mmu_sram_flop_start_addr_reg, value) \
      mp0_mmu_sram_flop_start_addr_reg = (mp0_mmu_sram_flop_start_addr_reg & ~MP0_MMU_SRAM_FLOP_START_ADDR_VALUE_MASK) | (value << MP0_MMU_SRAM_FLOP_START_ADDR_VALUE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_mmu_sram_flop_start_addr_t {
            unsigned int value                          : MP0_MMU_SRAM_FLOP_START_ADDR_VALUE_SIZE;
      } mp0_mmu_sram_flop_start_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_mmu_sram_flop_start_addr_t {
            unsigned int value                          : MP0_MMU_SRAM_FLOP_START_ADDR_VALUE_SIZE;
      } mp0_mmu_sram_flop_start_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_mmu_sram_flop_start_addr_t f;
} mp0_mmu_sram_flop_start_addr_u;


/*
 * MP0_CONFIG struct
 */

#define MP0_CONFIG_REG_SIZE         32
#define MP0_CONFIG_EnableCacheClear_OnReset_SIZE  1

#define MP0_CONFIG_EnableCacheClear_OnReset_SHIFT  3

#define MP0_CONFIG_EnableCacheClear_OnReset_MASK  0x00000008

#define MP0_CONFIG_MASK \
      (MP0_CONFIG_EnableCacheClear_OnReset_MASK)

#define MP0_CONFIG_DEFAULT             0x00000000

#define MP0_CONFIG_GET_EnableCacheClear_OnReset(mp0_config) \
      ((mp0_config & MP0_CONFIG_EnableCacheClear_OnReset_MASK) >> MP0_CONFIG_EnableCacheClear_OnReset_SHIFT)

#define MP0_CONFIG_SET_EnableCacheClear_OnReset(mp0_config_reg, enablecacheclear_onreset) \
      mp0_config_reg = (mp0_config_reg & ~MP0_CONFIG_EnableCacheClear_OnReset_MASK) | (enablecacheclear_onreset << MP0_CONFIG_EnableCacheClear_OnReset_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_config_t {
            unsigned int                                : 3;
            unsigned int enablecacheclear_onreset       : MP0_CONFIG_EnableCacheClear_OnReset_SIZE;
            unsigned int                                : 28;
      } mp0_config_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_config_t {
            unsigned int                                : 28;
            unsigned int enablecacheclear_onreset       : MP0_CONFIG_EnableCacheClear_OnReset_SIZE;
            unsigned int                                : 3;
      } mp0_config_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_config_t f;
} mp0_config_u;


/*
 * MP0_MMU_SRAM_ACC_VIOLATION_LOG_ADDR struct
 */

#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_REG_SIZE         32
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SIZE  32

#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SHIFT  0

#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK  0xffffffff

#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_MASK \
      (MP0_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK)

#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_DEFAULT 0x00000000

#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_GET_ADDRESS(mp0_mmu_sram_acc_violation_log_addr) \
      ((mp0_mmu_sram_acc_violation_log_addr & MP0_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK) >> MP0_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SHIFT)

#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_SET_ADDRESS(mp0_mmu_sram_acc_violation_log_addr_reg, address) \
      mp0_mmu_sram_acc_violation_log_addr_reg = (mp0_mmu_sram_acc_violation_log_addr_reg & ~MP0_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK) | (address << MP0_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_mmu_sram_acc_violation_log_addr_t {
            unsigned int address                        : MP0_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SIZE;
      } mp0_mmu_sram_acc_violation_log_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_mmu_sram_acc_violation_log_addr_t {
            unsigned int address                        : MP0_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SIZE;
      } mp0_mmu_sram_acc_violation_log_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_mmu_sram_acc_violation_log_addr_t f;
} mp0_mmu_sram_acc_violation_log_addr_u;


/*
 * MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS struct
 */

#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_REG_SIZE         32
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE  1
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SIZE  1
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SIZE  1
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE  2
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SIZE  2
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SIZE  7
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SIZE  10
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SIZE  1
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE  1

#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT  0
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SHIFT  1
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SHIFT  3
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT  4
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SHIFT  6
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SHIFT  8
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SHIFT  15
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SHIFT  30
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT  31

#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK  0x00000001
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_MASK  0x00000002
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_MASK  0x00000008
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK  0x00000030
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_MASK  0x000000c0
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_MASK  0x00007f00
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_MASK  0x01ff8000
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_MASK  0x40000000
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK  0x80000000

#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_MASK \
      (MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK | \
      MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_MASK | \
      MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_MASK | \
      MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK | \
      MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_MASK | \
      MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_MASK | \
      MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_MASK | \
      MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_MASK | \
      MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK)

#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_DEFAULT 0x00000000

#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_DETECTED(mp0_mmu_sram_acc_violation_log_status) \
      ((mp0_mmu_sram_acc_violation_log_status & MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) >> MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_UNSECURE_BAR(mp0_mmu_sram_acc_violation_log_status) \
      ((mp0_mmu_sram_acc_violation_log_status & MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_MASK) >> MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SHIFT)
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_OP(mp0_mmu_sram_acc_violation_log_status) \
      ((mp0_mmu_sram_acc_violation_log_status & MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_MASK) >> MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SHIFT)
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_TYPE(mp0_mmu_sram_acc_violation_log_status) \
      ((mp0_mmu_sram_acc_violation_log_status & MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) >> MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_PERMISSION(mp0_mmu_sram_acc_violation_log_status) \
      ((mp0_mmu_sram_acc_violation_log_status & MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_MASK) >> MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SHIFT)
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_AXI_UNIT_ID(mp0_mmu_sram_acc_violation_log_status) \
      ((mp0_mmu_sram_acc_violation_log_status & MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_MASK) >> MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SHIFT)
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_AXI_INIT_ID(mp0_mmu_sram_acc_violation_log_status) \
      ((mp0_mmu_sram_acc_violation_log_status & MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_MASK) >> MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SHIFT)
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_SRAM_NS0_VIOL_CLEAR(mp0_mmu_sram_acc_violation_log_status) \
      ((mp0_mmu_sram_acc_violation_log_status & MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_MASK) >> MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SHIFT)
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_LOG_CLEAR(mp0_mmu_sram_acc_violation_log_status) \
      ((mp0_mmu_sram_acc_violation_log_status & MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) >> MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)

#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_DETECTED(mp0_mmu_sram_acc_violation_log_status_reg, acc_violation_detected) \
      mp0_mmu_sram_acc_violation_log_status_reg = (mp0_mmu_sram_acc_violation_log_status_reg & ~MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) | (acc_violation_detected << MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_UNSECURE_BAR(mp0_mmu_sram_acc_violation_log_status_reg, acc_violation_unsecure_bar) \
      mp0_mmu_sram_acc_violation_log_status_reg = (mp0_mmu_sram_acc_violation_log_status_reg & ~MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_MASK) | (acc_violation_unsecure_bar << MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SHIFT)
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_OP(mp0_mmu_sram_acc_violation_log_status_reg, acc_violation_op) \
      mp0_mmu_sram_acc_violation_log_status_reg = (mp0_mmu_sram_acc_violation_log_status_reg & ~MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_MASK) | (acc_violation_op << MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SHIFT)
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_TYPE(mp0_mmu_sram_acc_violation_log_status_reg, acc_violation_type) \
      mp0_mmu_sram_acc_violation_log_status_reg = (mp0_mmu_sram_acc_violation_log_status_reg & ~MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) | (acc_violation_type << MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_PERMISSION(mp0_mmu_sram_acc_violation_log_status_reg, acc_violation_permission) \
      mp0_mmu_sram_acc_violation_log_status_reg = (mp0_mmu_sram_acc_violation_log_status_reg & ~MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_MASK) | (acc_violation_permission << MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SHIFT)
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_AXI_UNIT_ID(mp0_mmu_sram_acc_violation_log_status_reg, acc_violation_axi_unit_id) \
      mp0_mmu_sram_acc_violation_log_status_reg = (mp0_mmu_sram_acc_violation_log_status_reg & ~MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_MASK) | (acc_violation_axi_unit_id << MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SHIFT)
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_AXI_INIT_ID(mp0_mmu_sram_acc_violation_log_status_reg, acc_violation_axi_init_id) \
      mp0_mmu_sram_acc_violation_log_status_reg = (mp0_mmu_sram_acc_violation_log_status_reg & ~MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_MASK) | (acc_violation_axi_init_id << MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SHIFT)
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_SRAM_NS0_VIOL_CLEAR(mp0_mmu_sram_acc_violation_log_status_reg, sram_ns0_viol_clear) \
      mp0_mmu_sram_acc_violation_log_status_reg = (mp0_mmu_sram_acc_violation_log_status_reg & ~MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_MASK) | (sram_ns0_viol_clear << MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SHIFT)
#define MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_LOG_CLEAR(mp0_mmu_sram_acc_violation_log_status_reg, acc_violation_log_clear) \
      mp0_mmu_sram_acc_violation_log_status_reg = (mp0_mmu_sram_acc_violation_log_status_reg & ~MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) | (acc_violation_log_clear << MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_mmu_sram_acc_violation_log_status_t {
            unsigned int acc_violation_detected         : MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
            unsigned int acc_violation_unsecure_bar     : MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SIZE;
            unsigned int                                : 1;
            unsigned int acc_violation_op               : MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SIZE;
            unsigned int acc_violation_type             : MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
            unsigned int acc_violation_permission       : MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SIZE;
            unsigned int acc_violation_axi_unit_id      : MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SIZE;
            unsigned int acc_violation_axi_init_id      : MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SIZE;
            unsigned int                                : 5;
            unsigned int sram_ns0_viol_clear            : MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SIZE;
            unsigned int acc_violation_log_clear        : MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
      } mp0_mmu_sram_acc_violation_log_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_mmu_sram_acc_violation_log_status_t {
            unsigned int acc_violation_log_clear        : MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
            unsigned int sram_ns0_viol_clear            : MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SIZE;
            unsigned int                                : 5;
            unsigned int acc_violation_axi_init_id      : MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SIZE;
            unsigned int acc_violation_axi_unit_id      : MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SIZE;
            unsigned int acc_violation_permission       : MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SIZE;
            unsigned int acc_violation_type             : MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
            unsigned int acc_violation_op               : MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SIZE;
            unsigned int                                : 1;
            unsigned int acc_violation_unsecure_bar     : MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SIZE;
            unsigned int acc_violation_detected         : MP0_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
      } mp0_mmu_sram_acc_violation_log_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_mmu_sram_acc_violation_log_status_t f;
} mp0_mmu_sram_acc_violation_log_status_u;


/*
 * MP0_MMU_MISC_CNTL struct
 */

#define MP0_MMU_MISC_CNTL_REG_SIZE         32
#define MP0_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SIZE  1
#define MP0_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SIZE  1
#define MP0_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SIZE  1
#define MP0_MMU_MISC_CNTL_ENABLE_RAM_FLOPS_SIZE  1
#define MP0_MMU_MISC_CNTL_CLK_GATE_EN_SIZE  1
#define MP0_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SIZE  1
#define MP0_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SIZE  4
#define MP0_MMU_MISC_CNTL_REGCLK_STATUS_SIZE  1
#define MP0_MMU_MISC_CNTL_SYSCLK_STATUS_SIZE  1

#define MP0_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SHIFT  0
#define MP0_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SHIFT  2
#define MP0_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SHIFT  3
#define MP0_MMU_MISC_CNTL_ENABLE_RAM_FLOPS_SHIFT  4
#define MP0_MMU_MISC_CNTL_CLK_GATE_EN_SHIFT  16
#define MP0_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SHIFT  17
#define MP0_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SHIFT  18
#define MP0_MMU_MISC_CNTL_REGCLK_STATUS_SHIFT  22
#define MP0_MMU_MISC_CNTL_SYSCLK_STATUS_SHIFT  23

#define MP0_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_MASK  0x00000001
#define MP0_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_MASK  0x00000004
#define MP0_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_MASK  0x00000008
#define MP0_MMU_MISC_CNTL_ENABLE_RAM_FLOPS_MASK  0x00000010
#define MP0_MMU_MISC_CNTL_CLK_GATE_EN_MASK  0x00010000
#define MP0_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_MASK  0x00020000
#define MP0_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_MASK  0x003c0000
#define MP0_MMU_MISC_CNTL_REGCLK_STATUS_MASK  0x00400000
#define MP0_MMU_MISC_CNTL_SYSCLK_STATUS_MASK  0x00800000

#define MP0_MMU_MISC_CNTL_MASK \
      (MP0_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_MASK | \
      MP0_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_MASK | \
      MP0_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_MASK | \
      MP0_MMU_MISC_CNTL_ENABLE_RAM_FLOPS_MASK | \
      MP0_MMU_MISC_CNTL_CLK_GATE_EN_MASK | \
      MP0_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_MASK | \
      MP0_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_MASK | \
      MP0_MMU_MISC_CNTL_REGCLK_STATUS_MASK | \
      MP0_MMU_MISC_CNTL_SYSCLK_STATUS_MASK)

#define MP0_MMU_MISC_CNTL_DEFAULT      0x00e00001

#define MP0_MMU_MISC_CNTL_GET_ALLOW_UNPRIVILIGED_REG_ACC(mp0_mmu_misc_cntl) \
      ((mp0_mmu_misc_cntl & MP0_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_MASK) >> MP0_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SHIFT)
#define MP0_MMU_MISC_CNTL_GET_ENABLE_MEM_CHECKS_PSRAM(mp0_mmu_misc_cntl) \
      ((mp0_mmu_misc_cntl & MP0_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_MASK) >> MP0_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SHIFT)
#define MP0_MMU_MISC_CNTL_GET_ENABLE_MEM_CHECKS_CPU(mp0_mmu_misc_cntl) \
      ((mp0_mmu_misc_cntl & MP0_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_MASK) >> MP0_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SHIFT)
#define MP0_MMU_MISC_CNTL_GET_ENABLE_RAM_FLOPS(mp0_mmu_misc_cntl) \
      ((mp0_mmu_misc_cntl & MP0_MMU_MISC_CNTL_ENABLE_RAM_FLOPS_MASK) >> MP0_MMU_MISC_CNTL_ENABLE_RAM_FLOPS_SHIFT)
#define MP0_MMU_MISC_CNTL_GET_CLK_GATE_EN(mp0_mmu_misc_cntl) \
      ((mp0_mmu_misc_cntl & MP0_MMU_MISC_CNTL_CLK_GATE_EN_MASK) >> MP0_MMU_MISC_CNTL_CLK_GATE_EN_SHIFT)
#define MP0_MMU_MISC_CNTL_GET_CLK_GATE_OVERRIDE(mp0_mmu_misc_cntl) \
      ((mp0_mmu_misc_cntl & MP0_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_MASK) >> MP0_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SHIFT)
#define MP0_MMU_MISC_CNTL_GET_CLK_GATE_TIMEOUT(mp0_mmu_misc_cntl) \
      ((mp0_mmu_misc_cntl & MP0_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_MASK) >> MP0_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SHIFT)
#define MP0_MMU_MISC_CNTL_GET_REGCLK_STATUS(mp0_mmu_misc_cntl) \
      ((mp0_mmu_misc_cntl & MP0_MMU_MISC_CNTL_REGCLK_STATUS_MASK) >> MP0_MMU_MISC_CNTL_REGCLK_STATUS_SHIFT)
#define MP0_MMU_MISC_CNTL_GET_SYSCLK_STATUS(mp0_mmu_misc_cntl) \
      ((mp0_mmu_misc_cntl & MP0_MMU_MISC_CNTL_SYSCLK_STATUS_MASK) >> MP0_MMU_MISC_CNTL_SYSCLK_STATUS_SHIFT)

#define MP0_MMU_MISC_CNTL_SET_ALLOW_UNPRIVILIGED_REG_ACC(mp0_mmu_misc_cntl_reg, allow_unpriviliged_reg_acc) \
      mp0_mmu_misc_cntl_reg = (mp0_mmu_misc_cntl_reg & ~MP0_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_MASK) | (allow_unpriviliged_reg_acc << MP0_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SHIFT)
#define MP0_MMU_MISC_CNTL_SET_ENABLE_MEM_CHECKS_PSRAM(mp0_mmu_misc_cntl_reg, enable_mem_checks_psram) \
      mp0_mmu_misc_cntl_reg = (mp0_mmu_misc_cntl_reg & ~MP0_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_MASK) | (enable_mem_checks_psram << MP0_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SHIFT)
#define MP0_MMU_MISC_CNTL_SET_ENABLE_MEM_CHECKS_CPU(mp0_mmu_misc_cntl_reg, enable_mem_checks_cpu) \
      mp0_mmu_misc_cntl_reg = (mp0_mmu_misc_cntl_reg & ~MP0_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_MASK) | (enable_mem_checks_cpu << MP0_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SHIFT)
#define MP0_MMU_MISC_CNTL_SET_ENABLE_RAM_FLOPS(mp0_mmu_misc_cntl_reg, enable_ram_flops) \
      mp0_mmu_misc_cntl_reg = (mp0_mmu_misc_cntl_reg & ~MP0_MMU_MISC_CNTL_ENABLE_RAM_FLOPS_MASK) | (enable_ram_flops << MP0_MMU_MISC_CNTL_ENABLE_RAM_FLOPS_SHIFT)
#define MP0_MMU_MISC_CNTL_SET_CLK_GATE_EN(mp0_mmu_misc_cntl_reg, clk_gate_en) \
      mp0_mmu_misc_cntl_reg = (mp0_mmu_misc_cntl_reg & ~MP0_MMU_MISC_CNTL_CLK_GATE_EN_MASK) | (clk_gate_en << MP0_MMU_MISC_CNTL_CLK_GATE_EN_SHIFT)
#define MP0_MMU_MISC_CNTL_SET_CLK_GATE_OVERRIDE(mp0_mmu_misc_cntl_reg, clk_gate_override) \
      mp0_mmu_misc_cntl_reg = (mp0_mmu_misc_cntl_reg & ~MP0_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_MASK) | (clk_gate_override << MP0_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SHIFT)
#define MP0_MMU_MISC_CNTL_SET_CLK_GATE_TIMEOUT(mp0_mmu_misc_cntl_reg, clk_gate_timeout) \
      mp0_mmu_misc_cntl_reg = (mp0_mmu_misc_cntl_reg & ~MP0_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_MASK) | (clk_gate_timeout << MP0_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SHIFT)
#define MP0_MMU_MISC_CNTL_SET_REGCLK_STATUS(mp0_mmu_misc_cntl_reg, regclk_status) \
      mp0_mmu_misc_cntl_reg = (mp0_mmu_misc_cntl_reg & ~MP0_MMU_MISC_CNTL_REGCLK_STATUS_MASK) | (regclk_status << MP0_MMU_MISC_CNTL_REGCLK_STATUS_SHIFT)
#define MP0_MMU_MISC_CNTL_SET_SYSCLK_STATUS(mp0_mmu_misc_cntl_reg, sysclk_status) \
      mp0_mmu_misc_cntl_reg = (mp0_mmu_misc_cntl_reg & ~MP0_MMU_MISC_CNTL_SYSCLK_STATUS_MASK) | (sysclk_status << MP0_MMU_MISC_CNTL_SYSCLK_STATUS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_mmu_misc_cntl_t {
            unsigned int allow_unpriviliged_reg_acc     : MP0_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SIZE;
            unsigned int                                : 1;
            unsigned int enable_mem_checks_psram        : MP0_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SIZE;
            unsigned int enable_mem_checks_cpu          : MP0_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SIZE;
            unsigned int enable_ram_flops               : MP0_MMU_MISC_CNTL_ENABLE_RAM_FLOPS_SIZE;
            unsigned int                                : 11;
            unsigned int clk_gate_en                    : MP0_MMU_MISC_CNTL_CLK_GATE_EN_SIZE;
            unsigned int clk_gate_override              : MP0_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SIZE;
            unsigned int clk_gate_timeout               : MP0_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SIZE;
            unsigned int regclk_status                  : MP0_MMU_MISC_CNTL_REGCLK_STATUS_SIZE;
            unsigned int sysclk_status                  : MP0_MMU_MISC_CNTL_SYSCLK_STATUS_SIZE;
            unsigned int                                : 8;
      } mp0_mmu_misc_cntl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_mmu_misc_cntl_t {
            unsigned int                                : 8;
            unsigned int sysclk_status                  : MP0_MMU_MISC_CNTL_SYSCLK_STATUS_SIZE;
            unsigned int regclk_status                  : MP0_MMU_MISC_CNTL_REGCLK_STATUS_SIZE;
            unsigned int clk_gate_timeout               : MP0_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SIZE;
            unsigned int clk_gate_override              : MP0_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SIZE;
            unsigned int clk_gate_en                    : MP0_MMU_MISC_CNTL_CLK_GATE_EN_SIZE;
            unsigned int                                : 11;
            unsigned int enable_ram_flops               : MP0_MMU_MISC_CNTL_ENABLE_RAM_FLOPS_SIZE;
            unsigned int enable_mem_checks_cpu          : MP0_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SIZE;
            unsigned int enable_mem_checks_psram        : MP0_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SIZE;
            unsigned int                                : 1;
            unsigned int allow_unpriviliged_reg_acc     : MP0_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SIZE;
      } mp0_mmu_misc_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_mmu_misc_cntl_t f;
} mp0_mmu_misc_cntl_u;


/*
 * MP0_MMU_ACCESS_ERR_LOG struct
 */

#define MP0_MMU_ACCESS_ERR_LOG_REG_SIZE         32
#define MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SIZE  1
#define MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SIZE  2
#define MP0_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SIZE  1
#define MP0_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SIZE  1
#define MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SIZE  7
#define MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SIZE  10
#define MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SIZE  3

#define MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SHIFT  0
#define MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SHIFT  1
#define MP0_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SHIFT  3
#define MP0_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SHIFT  4
#define MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SHIFT  8
#define MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SHIFT  15
#define MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SHIFT  25

#define MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_MASK  0x00000001
#define MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_MASK  0x00000006
#define MP0_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_MASK  0x00000008
#define MP0_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_MASK  0x00000010
#define MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_MASK  0x00007f00
#define MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_MASK  0x01ff8000
#define MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_MASK  0x0e000000

#define MP0_MMU_ACCESS_ERR_LOG_MASK \
      (MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_MASK | \
      MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_MASK | \
      MP0_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_MASK | \
      MP0_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_MASK | \
      MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_MASK | \
      MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_MASK | \
      MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_MASK)

#define MP0_MMU_ACCESS_ERR_LOG_DEFAULT 0x00000000

#define MP0_MMU_ACCESS_ERR_LOG_GET_AXI_ACC_VIOLATION_DETECTED(mp0_mmu_access_err_log) \
      ((mp0_mmu_access_err_log & MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_MASK) >> MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SHIFT)
#define MP0_MMU_ACCESS_ERR_LOG_GET_AXI_ACC_VIOLATION_BLOCK(mp0_mmu_access_err_log) \
      ((mp0_mmu_access_err_log & MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_MASK) >> MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SHIFT)
#define MP0_MMU_ACCESS_ERR_LOG_GET_ACC_VIOLATION_LOG_CLEAR(mp0_mmu_access_err_log) \
      ((mp0_mmu_access_err_log & MP0_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_MASK) >> MP0_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SHIFT)
#define MP0_MMU_ACCESS_ERR_LOG_GET_CFG_NS0_VIOL_CLEAR(mp0_mmu_access_err_log) \
      ((mp0_mmu_access_err_log & MP0_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_MASK) >> MP0_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SHIFT)
#define MP0_MMU_ACCESS_ERR_LOG_GET_AXI_ACC_VIOLATION_AXI_UNIT_ID(mp0_mmu_access_err_log) \
      ((mp0_mmu_access_err_log & MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_MASK) >> MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SHIFT)
#define MP0_MMU_ACCESS_ERR_LOG_GET_AXI_ACC_VIOLATION_AXI_INIT_ID(mp0_mmu_access_err_log) \
      ((mp0_mmu_access_err_log & MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_MASK) >> MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SHIFT)
#define MP0_MMU_ACCESS_ERR_LOG_GET_AXI_ACC_VIOLATION_AXI_PROT(mp0_mmu_access_err_log) \
      ((mp0_mmu_access_err_log & MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_MASK) >> MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SHIFT)

#define MP0_MMU_ACCESS_ERR_LOG_SET_AXI_ACC_VIOLATION_DETECTED(mp0_mmu_access_err_log_reg, axi_acc_violation_detected) \
      mp0_mmu_access_err_log_reg = (mp0_mmu_access_err_log_reg & ~MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_MASK) | (axi_acc_violation_detected << MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SHIFT)
#define MP0_MMU_ACCESS_ERR_LOG_SET_AXI_ACC_VIOLATION_BLOCK(mp0_mmu_access_err_log_reg, axi_acc_violation_block) \
      mp0_mmu_access_err_log_reg = (mp0_mmu_access_err_log_reg & ~MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_MASK) | (axi_acc_violation_block << MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SHIFT)
#define MP0_MMU_ACCESS_ERR_LOG_SET_ACC_VIOLATION_LOG_CLEAR(mp0_mmu_access_err_log_reg, acc_violation_log_clear) \
      mp0_mmu_access_err_log_reg = (mp0_mmu_access_err_log_reg & ~MP0_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_MASK) | (acc_violation_log_clear << MP0_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SHIFT)
#define MP0_MMU_ACCESS_ERR_LOG_SET_CFG_NS0_VIOL_CLEAR(mp0_mmu_access_err_log_reg, cfg_ns0_viol_clear) \
      mp0_mmu_access_err_log_reg = (mp0_mmu_access_err_log_reg & ~MP0_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_MASK) | (cfg_ns0_viol_clear << MP0_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SHIFT)
#define MP0_MMU_ACCESS_ERR_LOG_SET_AXI_ACC_VIOLATION_AXI_UNIT_ID(mp0_mmu_access_err_log_reg, axi_acc_violation_axi_unit_id) \
      mp0_mmu_access_err_log_reg = (mp0_mmu_access_err_log_reg & ~MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_MASK) | (axi_acc_violation_axi_unit_id << MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SHIFT)
#define MP0_MMU_ACCESS_ERR_LOG_SET_AXI_ACC_VIOLATION_AXI_INIT_ID(mp0_mmu_access_err_log_reg, axi_acc_violation_axi_init_id) \
      mp0_mmu_access_err_log_reg = (mp0_mmu_access_err_log_reg & ~MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_MASK) | (axi_acc_violation_axi_init_id << MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SHIFT)
#define MP0_MMU_ACCESS_ERR_LOG_SET_AXI_ACC_VIOLATION_AXI_PROT(mp0_mmu_access_err_log_reg, axi_acc_violation_axi_prot) \
      mp0_mmu_access_err_log_reg = (mp0_mmu_access_err_log_reg & ~MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_MASK) | (axi_acc_violation_axi_prot << MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_mmu_access_err_log_t {
            unsigned int axi_acc_violation_detected     : MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SIZE;
            unsigned int axi_acc_violation_block        : MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SIZE;
            unsigned int acc_violation_log_clear        : MP0_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SIZE;
            unsigned int cfg_ns0_viol_clear             : MP0_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SIZE;
            unsigned int                                : 3;
            unsigned int axi_acc_violation_axi_unit_id  : MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SIZE;
            unsigned int axi_acc_violation_axi_init_id  : MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SIZE;
            unsigned int axi_acc_violation_axi_prot     : MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SIZE;
            unsigned int                                : 4;
      } mp0_mmu_access_err_log_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_mmu_access_err_log_t {
            unsigned int                                : 4;
            unsigned int axi_acc_violation_axi_prot     : MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SIZE;
            unsigned int axi_acc_violation_axi_init_id  : MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SIZE;
            unsigned int axi_acc_violation_axi_unit_id  : MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SIZE;
            unsigned int                                : 3;
            unsigned int cfg_ns0_viol_clear             : MP0_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SIZE;
            unsigned int acc_violation_log_clear        : MP0_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SIZE;
            unsigned int axi_acc_violation_block        : MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SIZE;
            unsigned int axi_acc_violation_detected     : MP0_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SIZE;
      } mp0_mmu_access_err_log_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_mmu_access_err_log_t f;
} mp0_mmu_access_err_log_u;


/*
 * MP0_MMU_SRAM_UNSECURE_BAR struct
 */

#define MP0_MMU_SRAM_UNSECURE_BAR_REG_SIZE         32
#define MP0_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SIZE  32

#define MP0_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SHIFT  0

#define MP0_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_MASK  0xffffffff

#define MP0_MMU_SRAM_UNSECURE_BAR_MASK \
      (MP0_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_MASK)

#define MP0_MMU_SRAM_UNSECURE_BAR_DEFAULT 0x00050000

#define MP0_MMU_SRAM_UNSECURE_BAR_GET_SRAM_UNSECURE_BAR(mp0_mmu_sram_unsecure_bar) \
      ((mp0_mmu_sram_unsecure_bar & MP0_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_MASK) >> MP0_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SHIFT)

#define MP0_MMU_SRAM_UNSECURE_BAR_SET_SRAM_UNSECURE_BAR(mp0_mmu_sram_unsecure_bar_reg, sram_unsecure_bar) \
      mp0_mmu_sram_unsecure_bar_reg = (mp0_mmu_sram_unsecure_bar_reg & ~MP0_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_MASK) | (sram_unsecure_bar << MP0_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_mmu_sram_unsecure_bar_t {
            unsigned int sram_unsecure_bar              : MP0_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SIZE;
      } mp0_mmu_sram_unsecure_bar_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_mmu_sram_unsecure_bar_t {
            unsigned int sram_unsecure_bar              : MP0_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SIZE;
      } mp0_mmu_sram_unsecure_bar_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_mmu_sram_unsecure_bar_t f;
} mp0_mmu_sram_unsecure_bar_u;


/*
 * MP0_MMU_SCRATCH_0 struct
 */

#define MP0_MMU_SCRATCH_0_REG_SIZE         32
#define MP0_MMU_SCRATCH_0_RESERVED_SIZE  32

#define MP0_MMU_SCRATCH_0_RESERVED_SHIFT  0

#define MP0_MMU_SCRATCH_0_RESERVED_MASK  0xffffffff

#define MP0_MMU_SCRATCH_0_MASK \
      (MP0_MMU_SCRATCH_0_RESERVED_MASK)

#define MP0_MMU_SCRATCH_0_DEFAULT      0x00000000

#define MP0_MMU_SCRATCH_0_GET_RESERVED(mp0_mmu_scratch_0) \
      ((mp0_mmu_scratch_0 & MP0_MMU_SCRATCH_0_RESERVED_MASK) >> MP0_MMU_SCRATCH_0_RESERVED_SHIFT)

#define MP0_MMU_SCRATCH_0_SET_RESERVED(mp0_mmu_scratch_0_reg, reserved) \
      mp0_mmu_scratch_0_reg = (mp0_mmu_scratch_0_reg & ~MP0_MMU_SCRATCH_0_RESERVED_MASK) | (reserved << MP0_MMU_SCRATCH_0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_mmu_scratch_0_t {
            unsigned int reserved                       : MP0_MMU_SCRATCH_0_RESERVED_SIZE;
      } mp0_mmu_scratch_0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_mmu_scratch_0_t {
            unsigned int reserved                       : MP0_MMU_SCRATCH_0_RESERVED_SIZE;
      } mp0_mmu_scratch_0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_mmu_scratch_0_t f;
} mp0_mmu_scratch_0_u;


/*
 * MP0_MMU_SCRATCH_1 struct
 */

#define MP0_MMU_SCRATCH_1_REG_SIZE         32
#define MP0_MMU_SCRATCH_1_RESERVED_SIZE  32

#define MP0_MMU_SCRATCH_1_RESERVED_SHIFT  0

#define MP0_MMU_SCRATCH_1_RESERVED_MASK  0xffffffff

#define MP0_MMU_SCRATCH_1_MASK \
      (MP0_MMU_SCRATCH_1_RESERVED_MASK)

#define MP0_MMU_SCRATCH_1_DEFAULT      0x00000000

#define MP0_MMU_SCRATCH_1_GET_RESERVED(mp0_mmu_scratch_1) \
      ((mp0_mmu_scratch_1 & MP0_MMU_SCRATCH_1_RESERVED_MASK) >> MP0_MMU_SCRATCH_1_RESERVED_SHIFT)

#define MP0_MMU_SCRATCH_1_SET_RESERVED(mp0_mmu_scratch_1_reg, reserved) \
      mp0_mmu_scratch_1_reg = (mp0_mmu_scratch_1_reg & ~MP0_MMU_SCRATCH_1_RESERVED_MASK) | (reserved << MP0_MMU_SCRATCH_1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_mmu_scratch_1_t {
            unsigned int reserved                       : MP0_MMU_SCRATCH_1_RESERVED_SIZE;
      } mp0_mmu_scratch_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_mmu_scratch_1_t {
            unsigned int reserved                       : MP0_MMU_SCRATCH_1_RESERVED_SIZE;
      } mp0_mmu_scratch_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_mmu_scratch_1_t f;
} mp0_mmu_scratch_1_u;


/*
 * MP0_MMU_SCRATCH_2 struct
 */

#define MP0_MMU_SCRATCH_2_REG_SIZE         32
#define MP0_MMU_SCRATCH_2_RESERVED_SIZE  32

#define MP0_MMU_SCRATCH_2_RESERVED_SHIFT  0

#define MP0_MMU_SCRATCH_2_RESERVED_MASK  0xffffffff

#define MP0_MMU_SCRATCH_2_MASK \
      (MP0_MMU_SCRATCH_2_RESERVED_MASK)

#define MP0_MMU_SCRATCH_2_DEFAULT      0x00000000

#define MP0_MMU_SCRATCH_2_GET_RESERVED(mp0_mmu_scratch_2) \
      ((mp0_mmu_scratch_2 & MP0_MMU_SCRATCH_2_RESERVED_MASK) >> MP0_MMU_SCRATCH_2_RESERVED_SHIFT)

#define MP0_MMU_SCRATCH_2_SET_RESERVED(mp0_mmu_scratch_2_reg, reserved) \
      mp0_mmu_scratch_2_reg = (mp0_mmu_scratch_2_reg & ~MP0_MMU_SCRATCH_2_RESERVED_MASK) | (reserved << MP0_MMU_SCRATCH_2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_mmu_scratch_2_t {
            unsigned int reserved                       : MP0_MMU_SCRATCH_2_RESERVED_SIZE;
      } mp0_mmu_scratch_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_mmu_scratch_2_t {
            unsigned int reserved                       : MP0_MMU_SCRATCH_2_RESERVED_SIZE;
      } mp0_mmu_scratch_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_mmu_scratch_2_t f;
} mp0_mmu_scratch_2_u;


/*
 * MP0_MMU_SCRATCH_3 struct
 */

#define MP0_MMU_SCRATCH_3_REG_SIZE         32
#define MP0_MMU_SCRATCH_3_RESERVED_SIZE  32

#define MP0_MMU_SCRATCH_3_RESERVED_SHIFT  0

#define MP0_MMU_SCRATCH_3_RESERVED_MASK  0xffffffff

#define MP0_MMU_SCRATCH_3_MASK \
      (MP0_MMU_SCRATCH_3_RESERVED_MASK)

#define MP0_MMU_SCRATCH_3_DEFAULT      0x00000000

#define MP0_MMU_SCRATCH_3_GET_RESERVED(mp0_mmu_scratch_3) \
      ((mp0_mmu_scratch_3 & MP0_MMU_SCRATCH_3_RESERVED_MASK) >> MP0_MMU_SCRATCH_3_RESERVED_SHIFT)

#define MP0_MMU_SCRATCH_3_SET_RESERVED(mp0_mmu_scratch_3_reg, reserved) \
      mp0_mmu_scratch_3_reg = (mp0_mmu_scratch_3_reg & ~MP0_MMU_SCRATCH_3_RESERVED_MASK) | (reserved << MP0_MMU_SCRATCH_3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_mmu_scratch_3_t {
            unsigned int reserved                       : MP0_MMU_SCRATCH_3_RESERVED_SIZE;
      } mp0_mmu_scratch_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_mmu_scratch_3_t {
            unsigned int reserved                       : MP0_MMU_SCRATCH_3_RESERVED_SIZE;
      } mp0_mmu_scratch_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_mmu_scratch_3_t f;
} mp0_mmu_scratch_3_u;


/*
 * MP0_MMU_SCRATCH_4 struct
 */

#define MP0_MMU_SCRATCH_4_REG_SIZE         32
#define MP0_MMU_SCRATCH_4_RESERVED_SIZE  32

#define MP0_MMU_SCRATCH_4_RESERVED_SHIFT  0

#define MP0_MMU_SCRATCH_4_RESERVED_MASK  0xffffffff

#define MP0_MMU_SCRATCH_4_MASK \
      (MP0_MMU_SCRATCH_4_RESERVED_MASK)

#define MP0_MMU_SCRATCH_4_DEFAULT      0x00000000

#define MP0_MMU_SCRATCH_4_GET_RESERVED(mp0_mmu_scratch_4) \
      ((mp0_mmu_scratch_4 & MP0_MMU_SCRATCH_4_RESERVED_MASK) >> MP0_MMU_SCRATCH_4_RESERVED_SHIFT)

#define MP0_MMU_SCRATCH_4_SET_RESERVED(mp0_mmu_scratch_4_reg, reserved) \
      mp0_mmu_scratch_4_reg = (mp0_mmu_scratch_4_reg & ~MP0_MMU_SCRATCH_4_RESERVED_MASK) | (reserved << MP0_MMU_SCRATCH_4_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_mmu_scratch_4_t {
            unsigned int reserved                       : MP0_MMU_SCRATCH_4_RESERVED_SIZE;
      } mp0_mmu_scratch_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_mmu_scratch_4_t {
            unsigned int reserved                       : MP0_MMU_SCRATCH_4_RESERVED_SIZE;
      } mp0_mmu_scratch_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_mmu_scratch_4_t f;
} mp0_mmu_scratch_4_u;


/*
 * MP0_MMU_SCRATCH_5 struct
 */

#define MP0_MMU_SCRATCH_5_REG_SIZE         32
#define MP0_MMU_SCRATCH_5_RESERVED_SIZE  32

#define MP0_MMU_SCRATCH_5_RESERVED_SHIFT  0

#define MP0_MMU_SCRATCH_5_RESERVED_MASK  0xffffffff

#define MP0_MMU_SCRATCH_5_MASK \
      (MP0_MMU_SCRATCH_5_RESERVED_MASK)

#define MP0_MMU_SCRATCH_5_DEFAULT      0x00000000

#define MP0_MMU_SCRATCH_5_GET_RESERVED(mp0_mmu_scratch_5) \
      ((mp0_mmu_scratch_5 & MP0_MMU_SCRATCH_5_RESERVED_MASK) >> MP0_MMU_SCRATCH_5_RESERVED_SHIFT)

#define MP0_MMU_SCRATCH_5_SET_RESERVED(mp0_mmu_scratch_5_reg, reserved) \
      mp0_mmu_scratch_5_reg = (mp0_mmu_scratch_5_reg & ~MP0_MMU_SCRATCH_5_RESERVED_MASK) | (reserved << MP0_MMU_SCRATCH_5_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_mmu_scratch_5_t {
            unsigned int reserved                       : MP0_MMU_SCRATCH_5_RESERVED_SIZE;
      } mp0_mmu_scratch_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_mmu_scratch_5_t {
            unsigned int reserved                       : MP0_MMU_SCRATCH_5_RESERVED_SIZE;
      } mp0_mmu_scratch_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_mmu_scratch_5_t f;
} mp0_mmu_scratch_5_u;


/*
 * MP0_MMU_SCRATCH_6 struct
 */

#define MP0_MMU_SCRATCH_6_REG_SIZE         32
#define MP0_MMU_SCRATCH_6_RESERVED_SIZE  32

#define MP0_MMU_SCRATCH_6_RESERVED_SHIFT  0

#define MP0_MMU_SCRATCH_6_RESERVED_MASK  0xffffffff

#define MP0_MMU_SCRATCH_6_MASK \
      (MP0_MMU_SCRATCH_6_RESERVED_MASK)

#define MP0_MMU_SCRATCH_6_DEFAULT      0x00000000

#define MP0_MMU_SCRATCH_6_GET_RESERVED(mp0_mmu_scratch_6) \
      ((mp0_mmu_scratch_6 & MP0_MMU_SCRATCH_6_RESERVED_MASK) >> MP0_MMU_SCRATCH_6_RESERVED_SHIFT)

#define MP0_MMU_SCRATCH_6_SET_RESERVED(mp0_mmu_scratch_6_reg, reserved) \
      mp0_mmu_scratch_6_reg = (mp0_mmu_scratch_6_reg & ~MP0_MMU_SCRATCH_6_RESERVED_MASK) | (reserved << MP0_MMU_SCRATCH_6_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_mmu_scratch_6_t {
            unsigned int reserved                       : MP0_MMU_SCRATCH_6_RESERVED_SIZE;
      } mp0_mmu_scratch_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_mmu_scratch_6_t {
            unsigned int reserved                       : MP0_MMU_SCRATCH_6_RESERVED_SIZE;
      } mp0_mmu_scratch_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_mmu_scratch_6_t f;
} mp0_mmu_scratch_6_u;


/*
 * MP0_MMU_SCRATCH_7 struct
 */

#define MP0_MMU_SCRATCH_7_REG_SIZE         32
#define MP0_MMU_SCRATCH_7_RESERVED_SIZE  32

#define MP0_MMU_SCRATCH_7_RESERVED_SHIFT  0

#define MP0_MMU_SCRATCH_7_RESERVED_MASK  0xffffffff

#define MP0_MMU_SCRATCH_7_MASK \
      (MP0_MMU_SCRATCH_7_RESERVED_MASK)

#define MP0_MMU_SCRATCH_7_DEFAULT      0x00000000

#define MP0_MMU_SCRATCH_7_GET_RESERVED(mp0_mmu_scratch_7) \
      ((mp0_mmu_scratch_7 & MP0_MMU_SCRATCH_7_RESERVED_MASK) >> MP0_MMU_SCRATCH_7_RESERVED_SHIFT)

#define MP0_MMU_SCRATCH_7_SET_RESERVED(mp0_mmu_scratch_7_reg, reserved) \
      mp0_mmu_scratch_7_reg = (mp0_mmu_scratch_7_reg & ~MP0_MMU_SCRATCH_7_RESERVED_MASK) | (reserved << MP0_MMU_SCRATCH_7_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp0_mmu_scratch_7_t {
            unsigned int reserved                       : MP0_MMU_SCRATCH_7_RESERVED_SIZE;
      } mp0_mmu_scratch_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp0_mmu_scratch_7_t {
            unsigned int reserved                       : MP0_MMU_SCRATCH_7_RESERVED_SIZE;
      } mp0_mmu_scratch_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp0_mmu_scratch_7_t f;
} mp0_mmu_scratch_7_u;


#endif

