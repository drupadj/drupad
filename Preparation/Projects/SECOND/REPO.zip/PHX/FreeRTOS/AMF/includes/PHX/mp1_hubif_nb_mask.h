// Copyright (c) 1994 - 2022 Advanced Micro Devices, Inc. All rights reserved.

#if !defined (_MP1_HUBIF_NB_MASK_H)
#define _MP1_HUBIF_NB_MASK_H

/*
 *    mp1_hubif_nb_mask.h      
 *
 *    Register Spec Release:  <unknown>
 *
 *
 *      (c) 2021 Advanced Micro Devices, Inc.  (unpublished)
 *
 *        All rights reserved.  This notice is intended as a precaution against
 *     inadvertent publication and does not imply publication or any waiver
 *      of confidentiality.  The year included in the foregoing notice is the
 *     year of creation of the work.
 *
 */

/*******************************************************
 * Read and Write Masks
 *******************************************************/

#define MP1_HUBIF_NB_AX_ADDR_LO_READ_MASK 0xffffffff
#define MP1_HUBIF_NB_AX_ADDR_LO_WRITE_MASK 0xffffffff

#define MP1_HUBIF_NB_AX_MISC_READ_MASK 0x0fffffff
#define MP1_HUBIF_NB_AX_MISC_WRITE_MASK 0x0fffffff

#define MP1_HUBIF_NB_AX_MISC_2_READ_MASK 0x7c0fffff
#define MP1_HUBIF_NB_AX_MISC_2_WRITE_MASK 0x3c0fffff

#define MP1_HUBIF_NB_AX_MISC_3_READ_MASK 0x0000003f
#define MP1_HUBIF_NB_AX_MISC_3_WRITE_MASK 0x0000003f

#define MP1_HUBIF_NB_WSTRB0_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_WSTRB0_WRITE_MASK 0xffffffff

#define MP1_HUBIF_NB_WSTRB1_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_WSTRB1_WRITE_MASK 0xffffffff

#define MP1_HUBIF_NB_WDATA0_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_WDATA0_WRITE_MASK 0xffffffff

#define MP1_HUBIF_NB_WDATA1_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_WDATA1_WRITE_MASK 0xffffffff

#define MP1_HUBIF_NB_WDATA2_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_WDATA2_WRITE_MASK 0xffffffff

#define MP1_HUBIF_NB_WDATA3_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_WDATA3_WRITE_MASK 0xffffffff

#define MP1_HUBIF_NB_WDATA4_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_WDATA4_WRITE_MASK 0xffffffff

#define MP1_HUBIF_NB_WDATA5_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_WDATA5_WRITE_MASK 0xffffffff

#define MP1_HUBIF_NB_WDATA6_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_WDATA6_WRITE_MASK 0xffffffff

#define MP1_HUBIF_NB_WDATA7_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_WDATA7_WRITE_MASK 0xffffffff

#define MP1_HUBIF_NB_WDATA8_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_WDATA8_WRITE_MASK 0xffffffff

#define MP1_HUBIF_NB_WDATA9_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_WDATA9_WRITE_MASK 0xffffffff

#define MP1_HUBIF_NB_WDATA10_READ_MASK 0xffffffff
#define MP1_HUBIF_NB_WDATA10_WRITE_MASK 0xffffffff

#define MP1_HUBIF_NB_WDATA11_READ_MASK 0xffffffff
#define MP1_HUBIF_NB_WDATA11_WRITE_MASK 0xffffffff

#define MP1_HUBIF_NB_WDATA12_READ_MASK 0xffffffff
#define MP1_HUBIF_NB_WDATA12_WRITE_MASK 0xffffffff

#define MP1_HUBIF_NB_WDATA13_READ_MASK 0xffffffff
#define MP1_HUBIF_NB_WDATA13_WRITE_MASK 0xffffffff

#define MP1_HUBIF_NB_WDATA14_READ_MASK 0xffffffff
#define MP1_HUBIF_NB_WDATA14_WRITE_MASK 0xffffffff

#define MP1_HUBIF_NB_WDATA15_READ_MASK 0xffffffff
#define MP1_HUBIF_NB_WDATA15_WRITE_MASK 0xffffffff

#define MP1_HUBIF_NB_RDATA0_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_RDATA0_WRITE_MASK 0x00000000

#define MP1_HUBIF_NB_RDATA1_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_RDATA1_WRITE_MASK 0x00000000

#define MP1_HUBIF_NB_RDATA2_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_RDATA2_WRITE_MASK 0x00000000

#define MP1_HUBIF_NB_RDATA3_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_RDATA3_WRITE_MASK 0x00000000

#define MP1_HUBIF_NB_RDATA4_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_RDATA4_WRITE_MASK 0x00000000

#define MP1_HUBIF_NB_RDATA5_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_RDATA5_WRITE_MASK 0x00000000

#define MP1_HUBIF_NB_RDATA6_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_RDATA6_WRITE_MASK 0x00000000

#define MP1_HUBIF_NB_RDATA7_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_RDATA7_WRITE_MASK 0x00000000

#define MP1_HUBIF_NB_RDATA8_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_RDATA8_WRITE_MASK 0x00000000

#define MP1_HUBIF_NB_RDATA9_READ_MASK  0xffffffff
#define MP1_HUBIF_NB_RDATA9_WRITE_MASK 0x00000000

#define MP1_HUBIF_NB_RDATA10_READ_MASK 0xffffffff
#define MP1_HUBIF_NB_RDATA10_WRITE_MASK 0x00000000

#define MP1_HUBIF_NB_RDATA11_READ_MASK 0xffffffff
#define MP1_HUBIF_NB_RDATA11_WRITE_MASK 0x00000000

#define MP1_HUBIF_NB_RDATA12_READ_MASK 0xffffffff
#define MP1_HUBIF_NB_RDATA12_WRITE_MASK 0x00000000

#define MP1_HUBIF_NB_RDATA13_READ_MASK 0xffffffff
#define MP1_HUBIF_NB_RDATA13_WRITE_MASK 0x00000000

#define MP1_HUBIF_NB_RDATA14_READ_MASK 0xffffffff
#define MP1_HUBIF_NB_RDATA14_WRITE_MASK 0x00000000

#define MP1_HUBIF_NB_RDATA15_READ_MASK 0xffffffff
#define MP1_HUBIF_NB_RDATA15_WRITE_MASK 0x00000000

#define MP1_HUBIF_NB_AXI_RESP_READ_MASK 0xffffffff
#define MP1_HUBIF_NB_AXI_RESP_WRITE_MASK 0x00000000

#define MP1_HUBIF_NB_MISC_CTRL_READ_MASK 0x00010001
#define MP1_HUBIF_NB_MISC_CTRL_WRITE_MASK 0x00010001

#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_READ_MASK 0xffffff0f
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_STATUS_WRITE_MASK 0x00000008

#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_READ_MASK 0xffffffff
#define MP1_HUBIF_NB_ACC_VIOLATION_LOG_ADDR_WRITE_MASK 0x00000000

#define MP1_HUBIF_NB_OBFF_EMUL_READ_MASK 0x00000002
#define MP1_HUBIF_NB_OBFF_EMUL_WRITE_MASK 0x00000002

#endif


