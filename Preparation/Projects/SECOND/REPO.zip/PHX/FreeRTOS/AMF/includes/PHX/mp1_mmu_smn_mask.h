// Copyright (c) 1994 - 2022 Advanced Micro Devices, Inc. All rights reserved.

#if !defined (_MP1_MMU_SMN_MASK_H)
#define _MP1_MMU_SMN_MASK_H

/*
 *    mp1_mmu_smn_mask.h       
 *
 *    Register Spec Release:  <unknown>
 *
 *
 *      (c) 2021 Advanced Micro Devices, Inc.  (unpublished)
 *
 *        All rights reserved.  This notice is intended as a precaution against
 *     inadvertent publication and does not imply publication or any waiver
 *      of confidentiality.  The year included in the foregoing notice is the
 *     year of creation of the work.
 *
 */

/*******************************************************
 * Read and Write Masks
 *******************************************************/

#define MP1_SMN_PMI_3_READ_MASK        0xffffffff
#define MP1_SMN_PMI_3_WRITE_MASK       0xffffffff

#define MP1_SMN_PMI_3_STATUS_READ_MASK 0x00000003
#define MP1_SMN_PMI_3_STATUS_WRITE_MASK 0x00000000

#define MP1_SMN_PMI_3_READ_POINTER_READ_MASK 0x000fffff
#define MP1_SMN_PMI_3_READ_POINTER_WRITE_MASK 0x00000000

#define MP1_SMN_PMI_3_WRITE_POINTER_READ_MASK 0x000fffff
#define MP1_SMN_PMI_3_WRITE_POINTER_WRITE_MASK 0x00000000

#endif


