// Copyright (c) 1994 - 2021 Advanced Micro Devices, Inc. All rights reserved. 
 #if !defined (_MPM_DFP_FIDDLE_H)
#define _MPM_DFP_FIDDLE_H
 /*****************************************************************************************************************
 *
 *  mpm_dfp_reg.h
 *
 *  Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#define LITTLEENDIAN_CPU 1
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif

 /*******************************************************
 * Values
 *******************************************************/

 /*******************************************************
 * Structures
 *******************************************************/

/*
 * MPM_PSP_ACCESS_ONLY struct
 */

#define MPM_PSP_ACCESS_ONLY_REG_SIZE         32
#define MPM_PSP_ACCESS_ONLY_PSP_FORCE_PG_SIZE  1

#define MPM_PSP_ACCESS_ONLY_PSP_FORCE_PG_SHIFT  0

#define MPM_PSP_ACCESS_ONLY_PSP_FORCE_PG_MASK  0x00000001

#define MPM_PSP_ACCESS_ONLY_MASK \
      (MPM_PSP_ACCESS_ONLY_PSP_FORCE_PG_MASK)

#define MPM_PSP_ACCESS_ONLY_DEFAULT    0x00000000

#define MPM_PSP_ACCESS_ONLY_GET_PSP_FORCE_PG(mpm_psp_access_only) \
      ((mpm_psp_access_only & MPM_PSP_ACCESS_ONLY_PSP_FORCE_PG_MASK) >> MPM_PSP_ACCESS_ONLY_PSP_FORCE_PG_SHIFT)

#define MPM_PSP_ACCESS_ONLY_SET_PSP_FORCE_PG(mpm_psp_access_only_reg, psp_force_pg) \
      mpm_psp_access_only_reg = (mpm_psp_access_only_reg & ~MPM_PSP_ACCESS_ONLY_PSP_FORCE_PG_MASK) | (psp_force_pg << MPM_PSP_ACCESS_ONLY_PSP_FORCE_PG_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_psp_access_only_t {
            unsigned int psp_force_pg                   : MPM_PSP_ACCESS_ONLY_PSP_FORCE_PG_SIZE;
            unsigned int                                : 31;
      } mpm_psp_access_only_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_psp_access_only_t {
            unsigned int                                : 31;
            unsigned int psp_force_pg                   : MPM_PSP_ACCESS_ONLY_PSP_FORCE_PG_SIZE;
      } mpm_psp_access_only_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_psp_access_only_t f;
} mpm_psp_access_only_u;


/*
 * MPM_MPCLK_XBAR_CG_CTRL struct
 */

#define MPM_MPCLK_XBAR_CG_CTRL_REG_SIZE         32
#define MPM_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SIZE  1

#define MPM_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SHIFT  0

#define MPM_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_MASK  0x00000001

#define MPM_MPCLK_XBAR_CG_CTRL_MASK \
      (MPM_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_MASK)

#define MPM_MPCLK_XBAR_CG_CTRL_DEFAULT 0x00000000

#define MPM_MPCLK_XBAR_CG_CTRL_GET_MPCLK_XBAR_CACTIVE_EN(mpm_mpclk_xbar_cg_ctrl) \
      ((mpm_mpclk_xbar_cg_ctrl & MPM_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_MASK) >> MPM_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SHIFT)

#define MPM_MPCLK_XBAR_CG_CTRL_SET_MPCLK_XBAR_CACTIVE_EN(mpm_mpclk_xbar_cg_ctrl_reg, mpclk_xbar_cactive_en) \
      mpm_mpclk_xbar_cg_ctrl_reg = (mpm_mpclk_xbar_cg_ctrl_reg & ~MPM_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_MASK) | (mpclk_xbar_cactive_en << MPM_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_mpclk_xbar_cg_ctrl_t {
            unsigned int mpclk_xbar_cactive_en          : MPM_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SIZE;
            unsigned int                                : 31;
      } mpm_mpclk_xbar_cg_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_mpclk_xbar_cg_ctrl_t {
            unsigned int                                : 31;
            unsigned int mpclk_xbar_cactive_en          : MPM_MPCLK_XBAR_CG_CTRL_MPCLK_XBAR_CACTIVE_EN_SIZE;
      } mpm_mpclk_xbar_cg_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_mpclk_xbar_cg_ctrl_t f;
} mpm_mpclk_xbar_cg_ctrl_u;


/*
 * MPM_MPCLK_XBAR_CG_EN struct
 */

#define MPM_MPCLK_XBAR_CG_EN_REG_SIZE         32
#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SIZE  1
#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_SIZE  1
#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SIZE  1
#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_SIZE  1

#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SHIFT  1
#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_SHIFT  2
#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SHIFT  3
#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_SHIFT  4

#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_MASK  0x00000002
#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_MASK  0x00000004
#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_MASK  0x00000008
#define MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_MASK  0x00000010

#define MPM_MPCLK_XBAR_CG_EN_MASK \
      (MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_MASK | \
      MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_MASK | \
      MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_MASK | \
      MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_MASK)

#define MPM_MPCLK_XBAR_CG_EN_DEFAULT   0x00000006

#define MPM_MPCLK_XBAR_CG_EN_GET_MPCLK_XBAR_CG_EN_0(mpm_mpclk_xbar_cg_en) \
      ((mpm_mpclk_xbar_cg_en & MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_MASK) >> MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SHIFT)
#define MPM_MPCLK_XBAR_CG_EN_GET_MPCLK_XBAR_CG_EN_1(mpm_mpclk_xbar_cg_en) \
      ((mpm_mpclk_xbar_cg_en & MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_MASK) >> MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_SHIFT)
#define MPM_MPCLK_XBAR_CG_EN_GET_MPCLK_XBAR_CG_OVERRIDE_0(mpm_mpclk_xbar_cg_en) \
      ((mpm_mpclk_xbar_cg_en & MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_MASK) >> MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SHIFT)
#define MPM_MPCLK_XBAR_CG_EN_GET_MPCLK_XBAR_CG_OVERRIDE_1(mpm_mpclk_xbar_cg_en) \
      ((mpm_mpclk_xbar_cg_en & MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_MASK) >> MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_SHIFT)

#define MPM_MPCLK_XBAR_CG_EN_SET_MPCLK_XBAR_CG_EN_0(mpm_mpclk_xbar_cg_en_reg, mpclk_xbar_cg_en_0) \
      mpm_mpclk_xbar_cg_en_reg = (mpm_mpclk_xbar_cg_en_reg & ~MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_MASK) | (mpclk_xbar_cg_en_0 << MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SHIFT)
#define MPM_MPCLK_XBAR_CG_EN_SET_MPCLK_XBAR_CG_EN_1(mpm_mpclk_xbar_cg_en_reg, mpclk_xbar_cg_en_1) \
      mpm_mpclk_xbar_cg_en_reg = (mpm_mpclk_xbar_cg_en_reg & ~MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_MASK) | (mpclk_xbar_cg_en_1 << MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_SHIFT)
#define MPM_MPCLK_XBAR_CG_EN_SET_MPCLK_XBAR_CG_OVERRIDE_0(mpm_mpclk_xbar_cg_en_reg, mpclk_xbar_cg_override_0) \
      mpm_mpclk_xbar_cg_en_reg = (mpm_mpclk_xbar_cg_en_reg & ~MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_MASK) | (mpclk_xbar_cg_override_0 << MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SHIFT)
#define MPM_MPCLK_XBAR_CG_EN_SET_MPCLK_XBAR_CG_OVERRIDE_1(mpm_mpclk_xbar_cg_en_reg, mpclk_xbar_cg_override_1) \
      mpm_mpclk_xbar_cg_en_reg = (mpm_mpclk_xbar_cg_en_reg & ~MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_MASK) | (mpclk_xbar_cg_override_1 << MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_mpclk_xbar_cg_en_t {
            unsigned int                                : 1;
            unsigned int mpclk_xbar_cg_en_0             : MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SIZE;
            unsigned int mpclk_xbar_cg_en_1             : MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_SIZE;
            unsigned int mpclk_xbar_cg_override_0       : MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SIZE;
            unsigned int mpclk_xbar_cg_override_1       : MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_SIZE;
            unsigned int                                : 27;
      } mpm_mpclk_xbar_cg_en_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_mpclk_xbar_cg_en_t {
            unsigned int                                : 27;
            unsigned int mpclk_xbar_cg_override_1       : MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_1_SIZE;
            unsigned int mpclk_xbar_cg_override_0       : MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_OVERRIDE_0_SIZE;
            unsigned int mpclk_xbar_cg_en_1             : MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_1_SIZE;
            unsigned int mpclk_xbar_cg_en_0             : MPM_MPCLK_XBAR_CG_EN_MPCLK_XBAR_CG_EN_0_SIZE;
            unsigned int                                : 1;
      } mpm_mpclk_xbar_cg_en_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_mpclk_xbar_cg_en_t f;
} mpm_mpclk_xbar_cg_en_u;


/*
 * MPM_MPCLK_XBAR_CG_MISC struct
 */

#define MPM_MPCLK_XBAR_CG_MISC_REG_SIZE         32
#define MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SIZE  8
#define MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SIZE  8

#define MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SHIFT  0
#define MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SHIFT  8

#define MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_MASK  0x000000ff
#define MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_MASK  0x0000ff00

#define MPM_MPCLK_XBAR_CG_MISC_MASK \
      (MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_MASK | \
      MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_MASK)

#define MPM_MPCLK_XBAR_CG_MISC_DEFAULT 0x00000606

#define MPM_MPCLK_XBAR_CG_MISC_GET_MPCLK_XBAR_CG_TIMEOUT(mpm_mpclk_xbar_cg_misc) \
      ((mpm_mpclk_xbar_cg_misc & MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_MASK) >> MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MPM_MPCLK_XBAR_CG_MISC_GET_MPCLK_XBAR_CSYS_DELAY(mpm_mpclk_xbar_cg_misc) \
      ((mpm_mpclk_xbar_cg_misc & MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_MASK) >> MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SHIFT)

#define MPM_MPCLK_XBAR_CG_MISC_SET_MPCLK_XBAR_CG_TIMEOUT(mpm_mpclk_xbar_cg_misc_reg, mpclk_xbar_cg_timeout) \
      mpm_mpclk_xbar_cg_misc_reg = (mpm_mpclk_xbar_cg_misc_reg & ~MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_MASK) | (mpclk_xbar_cg_timeout << MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MPM_MPCLK_XBAR_CG_MISC_SET_MPCLK_XBAR_CSYS_DELAY(mpm_mpclk_xbar_cg_misc_reg, mpclk_xbar_csys_delay) \
      mpm_mpclk_xbar_cg_misc_reg = (mpm_mpclk_xbar_cg_misc_reg & ~MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_MASK) | (mpclk_xbar_csys_delay << MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_mpclk_xbar_cg_misc_t {
            unsigned int mpclk_xbar_cg_timeout          : MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SIZE;
            unsigned int mpclk_xbar_csys_delay          : MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SIZE;
            unsigned int                                : 16;
      } mpm_mpclk_xbar_cg_misc_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_mpclk_xbar_cg_misc_t {
            unsigned int                                : 16;
            unsigned int mpclk_xbar_csys_delay          : MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CSYS_DELAY_SIZE;
            unsigned int mpclk_xbar_cg_timeout          : MPM_MPCLK_XBAR_CG_MISC_MPCLK_XBAR_CG_TIMEOUT_SIZE;
      } mpm_mpclk_xbar_cg_misc_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_mpclk_xbar_cg_misc_t f;
} mpm_mpclk_xbar_cg_misc_u;


/*
 * MPM_DFP_PGRAM_MMU_CNTL struct
 */

#define MPM_DFP_PGRAM_MMU_CNTL_REG_SIZE         32
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_SIZE  1
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_SIZE  1
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_SIZE  1
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_SIZE  1
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_SIZE  1
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_SIZE  8
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_SIZE  8
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DOWN_DLY_MMU_SIZE  8

#define MPM_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_SHIFT  0
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_SHIFT  2
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_SHIFT  3
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_SHIFT  4
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_SHIFT  5
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_SHIFT  8
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_SHIFT  16
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DOWN_DLY_MMU_SHIFT  24

#define MPM_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_MASK  0x00000001
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_MASK  0x00000004
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_MASK  0x00000008
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_MASK  0x00000010
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_MASK  0x00000020
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_MASK  0x0000ff00
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_MASK  0x00ff0000
#define MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DOWN_DLY_MMU_MASK  0xff000000

#define MPM_DFP_PGRAM_MMU_CNTL_MASK \
      (MPM_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_MASK | \
      MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_MASK | \
      MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_MASK | \
      MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_MASK | \
      MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_MASK | \
      MPM_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_MASK | \
      MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_MASK | \
      MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DOWN_DLY_MMU_MASK)

#define MPM_DFP_PGRAM_MMU_CNTL_DEFAULT 0x10101028

#define MPM_DFP_PGRAM_MMU_CNTL_GET_MEM_SD_MMU(mpm_dfp_pgram_mmu_cntl) \
      ((mpm_dfp_pgram_mmu_cntl & MPM_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_MASK) >> MPM_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_GET_MEM_DEEP_SLEEP_EN_MMU(mpm_dfp_pgram_mmu_cntl) \
      ((mpm_dfp_pgram_mmu_cntl & MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_MASK) >> MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_GET_MEM_DEEP_SLEEP_STATUS_MMU(mpm_dfp_pgram_mmu_cntl) \
      ((mpm_dfp_pgram_mmu_cntl & MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_MASK) >> MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_GET_MEM_LIGHT_SLEEP_EN_MMU(mpm_dfp_pgram_mmu_cntl) \
      ((mpm_dfp_pgram_mmu_cntl & MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_MASK) >> MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_MMU(mpm_dfp_pgram_mmu_cntl) \
      ((mpm_dfp_pgram_mmu_cntl & MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_MASK) >> MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_GET_MEM_SLEEP_TIMEOUT_MMU(mpm_dfp_pgram_mmu_cntl) \
      ((mpm_dfp_pgram_mmu_cntl & MPM_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_MASK) >> MPM_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_GET_MEM_PG_DLY_MMU(mpm_dfp_pgram_mmu_cntl) \
      ((mpm_dfp_pgram_mmu_cntl & MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_MASK) >> MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_GET_MEM_PG_DOWN_DLY_MMU(mpm_dfp_pgram_mmu_cntl) \
      ((mpm_dfp_pgram_mmu_cntl & MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DOWN_DLY_MMU_MASK) >> MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DOWN_DLY_MMU_SHIFT)

#define MPM_DFP_PGRAM_MMU_CNTL_SET_MEM_SD_MMU(mpm_dfp_pgram_mmu_cntl_reg, mem_sd_mmu) \
      mpm_dfp_pgram_mmu_cntl_reg = (mpm_dfp_pgram_mmu_cntl_reg & ~MPM_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_MASK) | (mem_sd_mmu << MPM_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_SET_MEM_DEEP_SLEEP_EN_MMU(mpm_dfp_pgram_mmu_cntl_reg, mem_deep_sleep_en_mmu) \
      mpm_dfp_pgram_mmu_cntl_reg = (mpm_dfp_pgram_mmu_cntl_reg & ~MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_MASK) | (mem_deep_sleep_en_mmu << MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_SET_MEM_DEEP_SLEEP_STATUS_MMU(mpm_dfp_pgram_mmu_cntl_reg, mem_deep_sleep_status_mmu) \
      mpm_dfp_pgram_mmu_cntl_reg = (mpm_dfp_pgram_mmu_cntl_reg & ~MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_MASK) | (mem_deep_sleep_status_mmu << MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_SET_MEM_LIGHT_SLEEP_EN_MMU(mpm_dfp_pgram_mmu_cntl_reg, mem_light_sleep_en_mmu) \
      mpm_dfp_pgram_mmu_cntl_reg = (mpm_dfp_pgram_mmu_cntl_reg & ~MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_MASK) | (mem_light_sleep_en_mmu << MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_MMU(mpm_dfp_pgram_mmu_cntl_reg, mem_light_sleep_status_mmu) \
      mpm_dfp_pgram_mmu_cntl_reg = (mpm_dfp_pgram_mmu_cntl_reg & ~MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_MASK) | (mem_light_sleep_status_mmu << MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_SET_MEM_SLEEP_TIMEOUT_MMU(mpm_dfp_pgram_mmu_cntl_reg, mem_sleep_timeout_mmu) \
      mpm_dfp_pgram_mmu_cntl_reg = (mpm_dfp_pgram_mmu_cntl_reg & ~MPM_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_MASK) | (mem_sleep_timeout_mmu << MPM_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_SET_MEM_PG_DLY_MMU(mpm_dfp_pgram_mmu_cntl_reg, mem_pg_dly_mmu) \
      mpm_dfp_pgram_mmu_cntl_reg = (mpm_dfp_pgram_mmu_cntl_reg & ~MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_MASK) | (mem_pg_dly_mmu << MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_SHIFT)
#define MPM_DFP_PGRAM_MMU_CNTL_SET_MEM_PG_DOWN_DLY_MMU(mpm_dfp_pgram_mmu_cntl_reg, mem_pg_down_dly_mmu) \
      mpm_dfp_pgram_mmu_cntl_reg = (mpm_dfp_pgram_mmu_cntl_reg & ~MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DOWN_DLY_MMU_MASK) | (mem_pg_down_dly_mmu << MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DOWN_DLY_MMU_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_dfp_pgram_mmu_cntl_t {
            unsigned int mem_sd_mmu                     : MPM_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_SIZE;
            unsigned int                                : 1;
            unsigned int mem_deep_sleep_en_mmu          : MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_SIZE;
            unsigned int mem_deep_sleep_status_mmu      : MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_SIZE;
            unsigned int mem_light_sleep_en_mmu         : MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_SIZE;
            unsigned int mem_light_sleep_status_mmu     : MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_SIZE;
            unsigned int                                : 2;
            unsigned int mem_sleep_timeout_mmu          : MPM_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_SIZE;
            unsigned int mem_pg_dly_mmu                 : MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_SIZE;
            unsigned int mem_pg_down_dly_mmu            : MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DOWN_DLY_MMU_SIZE;
      } mpm_dfp_pgram_mmu_cntl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_dfp_pgram_mmu_cntl_t {
            unsigned int mem_pg_down_dly_mmu            : MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DOWN_DLY_MMU_SIZE;
            unsigned int mem_pg_dly_mmu                 : MPM_DFP_PGRAM_MMU_CNTL_MEM_PG_DLY_MMU_SIZE;
            unsigned int mem_sleep_timeout_mmu          : MPM_DFP_PGRAM_MMU_CNTL_MEM_SLEEP_TIMEOUT_MMU_SIZE;
            unsigned int                                : 2;
            unsigned int mem_light_sleep_status_mmu     : MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_STATUS_MMU_SIZE;
            unsigned int mem_light_sleep_en_mmu         : MPM_DFP_PGRAM_MMU_CNTL_MEM_LIGHT_SLEEP_EN_MMU_SIZE;
            unsigned int mem_deep_sleep_status_mmu      : MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_STATUS_MMU_SIZE;
            unsigned int mem_deep_sleep_en_mmu          : MPM_DFP_PGRAM_MMU_CNTL_MEM_DEEP_SLEEP_EN_MMU_SIZE;
            unsigned int                                : 1;
            unsigned int mem_sd_mmu                     : MPM_DFP_PGRAM_MMU_CNTL_MEM_SD_MMU_SIZE;
      } mpm_dfp_pgram_mmu_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_dfp_pgram_mmu_cntl_t f;
} mpm_dfp_pgram_mmu_cntl_u;


/*
 * MPM_DFP_PGRAM_CPU_CNTL struct
 */

#define MPM_DFP_PGRAM_CPU_CNTL_REG_SIZE         32
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_SIZE  1
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_SIZE  1
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_SIZE  1
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_SIZE  1
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_SIZE  1
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_SIZE  8
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_SIZE  8
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DOWN_DLY_CPU_SIZE  8

#define MPM_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_SHIFT  0
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_SHIFT  2
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_SHIFT  3
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_SHIFT  4
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_SHIFT  5
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_SHIFT  8
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_SHIFT  16
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DOWN_DLY_CPU_SHIFT  24

#define MPM_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_MASK  0x00000001
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_MASK  0x00000004
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_MASK  0x00000008
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_MASK  0x00000010
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_MASK  0x00000020
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_MASK  0x0000ff00
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_MASK  0x00ff0000
#define MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DOWN_DLY_CPU_MASK  0xff000000

#define MPM_DFP_PGRAM_CPU_CNTL_MASK \
      (MPM_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_MASK | \
      MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_MASK | \
      MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_MASK | \
      MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_MASK | \
      MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_MASK | \
      MPM_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_MASK | \
      MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_MASK | \
      MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DOWN_DLY_CPU_MASK)

#define MPM_DFP_PGRAM_CPU_CNTL_DEFAULT 0x10101028

#define MPM_DFP_PGRAM_CPU_CNTL_GET_MEM_SD_CPU(mpm_dfp_pgram_cpu_cntl) \
      ((mpm_dfp_pgram_cpu_cntl & MPM_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_MASK) >> MPM_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_GET_MEM_DEEP_SLEEP_EN_CPU(mpm_dfp_pgram_cpu_cntl) \
      ((mpm_dfp_pgram_cpu_cntl & MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_MASK) >> MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_GET_MEM_DEEP_SLEEP_STATUS_CPU(mpm_dfp_pgram_cpu_cntl) \
      ((mpm_dfp_pgram_cpu_cntl & MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_MASK) >> MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_GET_MEM_LIGHT_SLEEP_EN_CPU(mpm_dfp_pgram_cpu_cntl) \
      ((mpm_dfp_pgram_cpu_cntl & MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_MASK) >> MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_CPU(mpm_dfp_pgram_cpu_cntl) \
      ((mpm_dfp_pgram_cpu_cntl & MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_MASK) >> MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_GET_MEM_SLEEP_TIMEOUT_CPU(mpm_dfp_pgram_cpu_cntl) \
      ((mpm_dfp_pgram_cpu_cntl & MPM_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_MASK) >> MPM_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_GET_MEM_PG_DLY_CPU(mpm_dfp_pgram_cpu_cntl) \
      ((mpm_dfp_pgram_cpu_cntl & MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_MASK) >> MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_GET_MEM_PG_DOWN_DLY_CPU(mpm_dfp_pgram_cpu_cntl) \
      ((mpm_dfp_pgram_cpu_cntl & MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DOWN_DLY_CPU_MASK) >> MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DOWN_DLY_CPU_SHIFT)

#define MPM_DFP_PGRAM_CPU_CNTL_SET_MEM_SD_CPU(mpm_dfp_pgram_cpu_cntl_reg, mem_sd_cpu) \
      mpm_dfp_pgram_cpu_cntl_reg = (mpm_dfp_pgram_cpu_cntl_reg & ~MPM_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_MASK) | (mem_sd_cpu << MPM_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_SET_MEM_DEEP_SLEEP_EN_CPU(mpm_dfp_pgram_cpu_cntl_reg, mem_deep_sleep_en_cpu) \
      mpm_dfp_pgram_cpu_cntl_reg = (mpm_dfp_pgram_cpu_cntl_reg & ~MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_MASK) | (mem_deep_sleep_en_cpu << MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_SET_MEM_DEEP_SLEEP_STATUS_CPU(mpm_dfp_pgram_cpu_cntl_reg, mem_deep_sleep_status_cpu) \
      mpm_dfp_pgram_cpu_cntl_reg = (mpm_dfp_pgram_cpu_cntl_reg & ~MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_MASK) | (mem_deep_sleep_status_cpu << MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_SET_MEM_LIGHT_SLEEP_EN_CPU(mpm_dfp_pgram_cpu_cntl_reg, mem_light_sleep_en_cpu) \
      mpm_dfp_pgram_cpu_cntl_reg = (mpm_dfp_pgram_cpu_cntl_reg & ~MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_MASK) | (mem_light_sleep_en_cpu << MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_CPU(mpm_dfp_pgram_cpu_cntl_reg, mem_light_sleep_status_cpu) \
      mpm_dfp_pgram_cpu_cntl_reg = (mpm_dfp_pgram_cpu_cntl_reg & ~MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_MASK) | (mem_light_sleep_status_cpu << MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_SET_MEM_SLEEP_TIMEOUT_CPU(mpm_dfp_pgram_cpu_cntl_reg, mem_sleep_timeout_cpu) \
      mpm_dfp_pgram_cpu_cntl_reg = (mpm_dfp_pgram_cpu_cntl_reg & ~MPM_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_MASK) | (mem_sleep_timeout_cpu << MPM_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_SET_MEM_PG_DLY_CPU(mpm_dfp_pgram_cpu_cntl_reg, mem_pg_dly_cpu) \
      mpm_dfp_pgram_cpu_cntl_reg = (mpm_dfp_pgram_cpu_cntl_reg & ~MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_MASK) | (mem_pg_dly_cpu << MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_SHIFT)
#define MPM_DFP_PGRAM_CPU_CNTL_SET_MEM_PG_DOWN_DLY_CPU(mpm_dfp_pgram_cpu_cntl_reg, mem_pg_down_dly_cpu) \
      mpm_dfp_pgram_cpu_cntl_reg = (mpm_dfp_pgram_cpu_cntl_reg & ~MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DOWN_DLY_CPU_MASK) | (mem_pg_down_dly_cpu << MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DOWN_DLY_CPU_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_dfp_pgram_cpu_cntl_t {
            unsigned int mem_sd_cpu                     : MPM_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_SIZE;
            unsigned int                                : 1;
            unsigned int mem_deep_sleep_en_cpu          : MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_SIZE;
            unsigned int mem_deep_sleep_status_cpu      : MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_SIZE;
            unsigned int mem_light_sleep_en_cpu         : MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_SIZE;
            unsigned int mem_light_sleep_status_cpu     : MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_SIZE;
            unsigned int                                : 2;
            unsigned int mem_sleep_timeout_cpu          : MPM_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_SIZE;
            unsigned int mem_pg_dly_cpu                 : MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_SIZE;
            unsigned int mem_pg_down_dly_cpu            : MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DOWN_DLY_CPU_SIZE;
      } mpm_dfp_pgram_cpu_cntl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_dfp_pgram_cpu_cntl_t {
            unsigned int mem_pg_down_dly_cpu            : MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DOWN_DLY_CPU_SIZE;
            unsigned int mem_pg_dly_cpu                 : MPM_DFP_PGRAM_CPU_CNTL_MEM_PG_DLY_CPU_SIZE;
            unsigned int mem_sleep_timeout_cpu          : MPM_DFP_PGRAM_CPU_CNTL_MEM_SLEEP_TIMEOUT_CPU_SIZE;
            unsigned int                                : 2;
            unsigned int mem_light_sleep_status_cpu     : MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_STATUS_CPU_SIZE;
            unsigned int mem_light_sleep_en_cpu         : MPM_DFP_PGRAM_CPU_CNTL_MEM_LIGHT_SLEEP_EN_CPU_SIZE;
            unsigned int mem_deep_sleep_status_cpu      : MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_STATUS_CPU_SIZE;
            unsigned int mem_deep_sleep_en_cpu          : MPM_DFP_PGRAM_CPU_CNTL_MEM_DEEP_SLEEP_EN_CPU_SIZE;
            unsigned int                                : 1;
            unsigned int mem_sd_cpu                     : MPM_DFP_PGRAM_CPU_CNTL_MEM_SD_CPU_SIZE;
      } mpm_dfp_pgram_cpu_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_dfp_pgram_cpu_cntl_t f;
} mpm_dfp_pgram_cpu_cntl_u;


/*
 * MPM_DFP_PGRAM_CRU_CNTL struct
 */

#define MPM_DFP_PGRAM_CRU_CNTL_REG_SIZE         32
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_SIZE  1
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_SIZE  1
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_SIZE  1
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_SIZE  1
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_SIZE  1
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_SIZE  8
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_SIZE  8
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DOWN_DLY_CRU_SIZE  8

#define MPM_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_SHIFT  0
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_SHIFT  2
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_SHIFT  3
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_SHIFT  4
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_SHIFT  5
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_SHIFT  8
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_SHIFT  16
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DOWN_DLY_CRU_SHIFT  24

#define MPM_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_MASK  0x00000001
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_MASK  0x00000004
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_MASK  0x00000008
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_MASK  0x00000010
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_MASK  0x00000020
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_MASK  0x0000ff00
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_MASK  0x00ff0000
#define MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DOWN_DLY_CRU_MASK  0xff000000

#define MPM_DFP_PGRAM_CRU_CNTL_MASK \
      (MPM_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_MASK | \
      MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_MASK | \
      MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_MASK | \
      MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_MASK | \
      MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_MASK | \
      MPM_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_MASK | \
      MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_MASK | \
      MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DOWN_DLY_CRU_MASK)

#define MPM_DFP_PGRAM_CRU_CNTL_DEFAULT 0x10101028

#define MPM_DFP_PGRAM_CRU_CNTL_GET_MEM_SD_CRU(mpm_dfp_pgram_cru_cntl) \
      ((mpm_dfp_pgram_cru_cntl & MPM_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_MASK) >> MPM_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_GET_MEM_DEEP_SLEEP_EN_CRU(mpm_dfp_pgram_cru_cntl) \
      ((mpm_dfp_pgram_cru_cntl & MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_MASK) >> MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_GET_MEM_DEEP_SLEEP_STATUS_CRU(mpm_dfp_pgram_cru_cntl) \
      ((mpm_dfp_pgram_cru_cntl & MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_MASK) >> MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_GET_MEM_LIGHT_SLEEP_EN_CRU(mpm_dfp_pgram_cru_cntl) \
      ((mpm_dfp_pgram_cru_cntl & MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_MASK) >> MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_CRU(mpm_dfp_pgram_cru_cntl) \
      ((mpm_dfp_pgram_cru_cntl & MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_MASK) >> MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_GET_MEM_SLEEP_TIMEOUT_CRU(mpm_dfp_pgram_cru_cntl) \
      ((mpm_dfp_pgram_cru_cntl & MPM_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_MASK) >> MPM_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_GET_MEM_PG_DLY_CRU(mpm_dfp_pgram_cru_cntl) \
      ((mpm_dfp_pgram_cru_cntl & MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_MASK) >> MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_GET_MEM_PG_DOWN_DLY_CRU(mpm_dfp_pgram_cru_cntl) \
      ((mpm_dfp_pgram_cru_cntl & MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DOWN_DLY_CRU_MASK) >> MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DOWN_DLY_CRU_SHIFT)

#define MPM_DFP_PGRAM_CRU_CNTL_SET_MEM_SD_CRU(mpm_dfp_pgram_cru_cntl_reg, mem_sd_cru) \
      mpm_dfp_pgram_cru_cntl_reg = (mpm_dfp_pgram_cru_cntl_reg & ~MPM_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_MASK) | (mem_sd_cru << MPM_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_SET_MEM_DEEP_SLEEP_EN_CRU(mpm_dfp_pgram_cru_cntl_reg, mem_deep_sleep_en_cru) \
      mpm_dfp_pgram_cru_cntl_reg = (mpm_dfp_pgram_cru_cntl_reg & ~MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_MASK) | (mem_deep_sleep_en_cru << MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_SET_MEM_DEEP_SLEEP_STATUS_CRU(mpm_dfp_pgram_cru_cntl_reg, mem_deep_sleep_status_cru) \
      mpm_dfp_pgram_cru_cntl_reg = (mpm_dfp_pgram_cru_cntl_reg & ~MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_MASK) | (mem_deep_sleep_status_cru << MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_SET_MEM_LIGHT_SLEEP_EN_CRU(mpm_dfp_pgram_cru_cntl_reg, mem_light_sleep_en_cru) \
      mpm_dfp_pgram_cru_cntl_reg = (mpm_dfp_pgram_cru_cntl_reg & ~MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_MASK) | (mem_light_sleep_en_cru << MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_CRU(mpm_dfp_pgram_cru_cntl_reg, mem_light_sleep_status_cru) \
      mpm_dfp_pgram_cru_cntl_reg = (mpm_dfp_pgram_cru_cntl_reg & ~MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_MASK) | (mem_light_sleep_status_cru << MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_SET_MEM_SLEEP_TIMEOUT_CRU(mpm_dfp_pgram_cru_cntl_reg, mem_sleep_timeout_cru) \
      mpm_dfp_pgram_cru_cntl_reg = (mpm_dfp_pgram_cru_cntl_reg & ~MPM_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_MASK) | (mem_sleep_timeout_cru << MPM_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_SET_MEM_PG_DLY_CRU(mpm_dfp_pgram_cru_cntl_reg, mem_pg_dly_cru) \
      mpm_dfp_pgram_cru_cntl_reg = (mpm_dfp_pgram_cru_cntl_reg & ~MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_MASK) | (mem_pg_dly_cru << MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_SHIFT)
#define MPM_DFP_PGRAM_CRU_CNTL_SET_MEM_PG_DOWN_DLY_CRU(mpm_dfp_pgram_cru_cntl_reg, mem_pg_down_dly_cru) \
      mpm_dfp_pgram_cru_cntl_reg = (mpm_dfp_pgram_cru_cntl_reg & ~MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DOWN_DLY_CRU_MASK) | (mem_pg_down_dly_cru << MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DOWN_DLY_CRU_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_dfp_pgram_cru_cntl_t {
            unsigned int mem_sd_cru                     : MPM_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_SIZE;
            unsigned int                                : 1;
            unsigned int mem_deep_sleep_en_cru          : MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_SIZE;
            unsigned int mem_deep_sleep_status_cru      : MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_SIZE;
            unsigned int mem_light_sleep_en_cru         : MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_SIZE;
            unsigned int mem_light_sleep_status_cru     : MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_SIZE;
            unsigned int                                : 2;
            unsigned int mem_sleep_timeout_cru          : MPM_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_SIZE;
            unsigned int mem_pg_dly_cru                 : MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_SIZE;
            unsigned int mem_pg_down_dly_cru            : MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DOWN_DLY_CRU_SIZE;
      } mpm_dfp_pgram_cru_cntl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_dfp_pgram_cru_cntl_t {
            unsigned int mem_pg_down_dly_cru            : MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DOWN_DLY_CRU_SIZE;
            unsigned int mem_pg_dly_cru                 : MPM_DFP_PGRAM_CRU_CNTL_MEM_PG_DLY_CRU_SIZE;
            unsigned int mem_sleep_timeout_cru          : MPM_DFP_PGRAM_CRU_CNTL_MEM_SLEEP_TIMEOUT_CRU_SIZE;
            unsigned int                                : 2;
            unsigned int mem_light_sleep_status_cru     : MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_STATUS_CRU_SIZE;
            unsigned int mem_light_sleep_en_cru         : MPM_DFP_PGRAM_CRU_CNTL_MEM_LIGHT_SLEEP_EN_CRU_SIZE;
            unsigned int mem_deep_sleep_status_cru      : MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_STATUS_CRU_SIZE;
            unsigned int mem_deep_sleep_en_cru          : MPM_DFP_PGRAM_CRU_CNTL_MEM_DEEP_SLEEP_EN_CRU_SIZE;
            unsigned int                                : 1;
            unsigned int mem_sd_cru                     : MPM_DFP_PGRAM_CRU_CNTL_MEM_SD_CRU_SIZE;
      } mpm_dfp_pgram_cru_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_dfp_pgram_cru_cntl_t f;
} mpm_dfp_pgram_cru_cntl_u;


/*
 * MPM_DFP_MPCLKDS_CTRL struct
 */

#define MPM_DFP_MPCLKDS_CTRL_REG_SIZE         32
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SIZE  1
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SIZE  1
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SIZE  8
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SIZE  1
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SIZE  1

#define MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SHIFT  0
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SHIFT  1
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SHIFT  2
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SHIFT  10
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SHIFT  11

#define MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_MASK  0x00000001
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_MASK  0x00000002
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_MASK  0x000003fc
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_MASK  0x00000400
#define MPM_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_MASK  0x00000800

#define MPM_DFP_MPCLKDS_CTRL_MASK \
      (MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_MASK | \
      MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_MASK | \
      MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_MASK | \
      MPM_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_MASK | \
      MPM_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_MASK)

#define MPM_DFP_MPCLKDS_CTRL_DEFAULT   0x00000ffc

#define MPM_DFP_MPCLKDS_CTRL_GET_MPCLK_DS_ENB(mpm_dfp_mpclkds_ctrl) \
      ((mpm_dfp_mpclkds_ctrl & MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_MASK) >> MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SHIFT)
#define MPM_DFP_MPCLKDS_CTRL_GET_MPCLK_DS_STATUS(mpm_dfp_mpclkds_ctrl) \
      ((mpm_dfp_mpclkds_ctrl & MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_MASK) >> MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SHIFT)
#define MPM_DFP_MPCLKDS_CTRL_GET_MPCLK_DS_TIMEOUT(mpm_dfp_mpclkds_ctrl) \
      ((mpm_dfp_mpclkds_ctrl & MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_MASK) >> MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SHIFT)
#define MPM_DFP_MPCLKDS_CTRL_GET_MPCLK_CPUINTR_WAKE_MASK(mpm_dfp_mpclkds_ctrl) \
      ((mpm_dfp_mpclkds_ctrl & MPM_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_MASK) >> MPM_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SHIFT)
#define MPM_DFP_MPCLKDS_CTRL_GET_MPCLK_SMN_WAKE_MASK(mpm_dfp_mpclkds_ctrl) \
      ((mpm_dfp_mpclkds_ctrl & MPM_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_MASK) >> MPM_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SHIFT)

#define MPM_DFP_MPCLKDS_CTRL_SET_MPCLK_DS_ENB(mpm_dfp_mpclkds_ctrl_reg, mpclk_ds_enb) \
      mpm_dfp_mpclkds_ctrl_reg = (mpm_dfp_mpclkds_ctrl_reg & ~MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_MASK) | (mpclk_ds_enb << MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SHIFT)
#define MPM_DFP_MPCLKDS_CTRL_SET_MPCLK_DS_STATUS(mpm_dfp_mpclkds_ctrl_reg, mpclk_ds_status) \
      mpm_dfp_mpclkds_ctrl_reg = (mpm_dfp_mpclkds_ctrl_reg & ~MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_MASK) | (mpclk_ds_status << MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SHIFT)
#define MPM_DFP_MPCLKDS_CTRL_SET_MPCLK_DS_TIMEOUT(mpm_dfp_mpclkds_ctrl_reg, mpclk_ds_timeout) \
      mpm_dfp_mpclkds_ctrl_reg = (mpm_dfp_mpclkds_ctrl_reg & ~MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_MASK) | (mpclk_ds_timeout << MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SHIFT)
#define MPM_DFP_MPCLKDS_CTRL_SET_MPCLK_CPUINTR_WAKE_MASK(mpm_dfp_mpclkds_ctrl_reg, mpclk_cpuintr_wake_mask) \
      mpm_dfp_mpclkds_ctrl_reg = (mpm_dfp_mpclkds_ctrl_reg & ~MPM_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_MASK) | (mpclk_cpuintr_wake_mask << MPM_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SHIFT)
#define MPM_DFP_MPCLKDS_CTRL_SET_MPCLK_SMN_WAKE_MASK(mpm_dfp_mpclkds_ctrl_reg, mpclk_smn_wake_mask) \
      mpm_dfp_mpclkds_ctrl_reg = (mpm_dfp_mpclkds_ctrl_reg & ~MPM_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_MASK) | (mpclk_smn_wake_mask << MPM_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_dfp_mpclkds_ctrl_t {
            unsigned int mpclk_ds_enb                   : MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SIZE;
            unsigned int mpclk_ds_status                : MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SIZE;
            unsigned int mpclk_ds_timeout               : MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SIZE;
            unsigned int mpclk_cpuintr_wake_mask        : MPM_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SIZE;
            unsigned int mpclk_smn_wake_mask            : MPM_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SIZE;
            unsigned int                                : 20;
      } mpm_dfp_mpclkds_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_dfp_mpclkds_ctrl_t {
            unsigned int                                : 20;
            unsigned int mpclk_smn_wake_mask            : MPM_DFP_MPCLKDS_CTRL_MPCLK_SMN_WAKE_MASK_SIZE;
            unsigned int mpclk_cpuintr_wake_mask        : MPM_DFP_MPCLKDS_CTRL_MPCLK_CPUINTR_WAKE_MASK_SIZE;
            unsigned int mpclk_ds_timeout               : MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_TIMEOUT_SIZE;
            unsigned int mpclk_ds_status                : MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_STATUS_SIZE;
            unsigned int mpclk_ds_enb                   : MPM_DFP_MPCLKDS_CTRL_MPCLK_DS_ENB_SIZE;
      } mpm_dfp_mpclkds_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_dfp_mpclkds_ctrl_t f;
} mpm_dfp_mpclkds_ctrl_u;


/*
 * MPM_SOCCLK_XBAR_CG_CTRL struct
 */

#define MPM_SOCCLK_XBAR_CG_CTRL_REG_SIZE         32
#define MPM_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_SIZE  1

#define MPM_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_SHIFT  0

#define MPM_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_MASK  0x00000001

#define MPM_SOCCLK_XBAR_CG_CTRL_MASK \
      (MPM_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_MASK)

#define MPM_SOCCLK_XBAR_CG_CTRL_DEFAULT 0x00000000

#define MPM_SOCCLK_XBAR_CG_CTRL_GET_SOCCLK_XBAR_CACTIVE_EN(mpm_socclk_xbar_cg_ctrl) \
      ((mpm_socclk_xbar_cg_ctrl & MPM_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_MASK) >> MPM_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_SHIFT)

#define MPM_SOCCLK_XBAR_CG_CTRL_SET_SOCCLK_XBAR_CACTIVE_EN(mpm_socclk_xbar_cg_ctrl_reg, socclk_xbar_cactive_en) \
      mpm_socclk_xbar_cg_ctrl_reg = (mpm_socclk_xbar_cg_ctrl_reg & ~MPM_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_MASK) | (socclk_xbar_cactive_en << MPM_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_socclk_xbar_cg_ctrl_t {
            unsigned int socclk_xbar_cactive_en         : MPM_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_SIZE;
            unsigned int                                : 31;
      } mpm_socclk_xbar_cg_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_socclk_xbar_cg_ctrl_t {
            unsigned int                                : 31;
            unsigned int socclk_xbar_cactive_en         : MPM_SOCCLK_XBAR_CG_CTRL_SOCCLK_XBAR_CACTIVE_EN_SIZE;
      } mpm_socclk_xbar_cg_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_socclk_xbar_cg_ctrl_t f;
} mpm_socclk_xbar_cg_ctrl_u;


/*
 * MPM_SOCCLK_XBAR_CG_EN struct
 */

#define MPM_SOCCLK_XBAR_CG_EN_REG_SIZE         32
#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_SIZE  1
#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_SIZE  1
#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_SIZE  1
#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_SIZE  1

#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_SHIFT  1
#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_SHIFT  2
#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_SHIFT  3
#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_SHIFT  4

#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_MASK  0x00000002
#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_MASK  0x00000004
#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_MASK  0x00000008
#define MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_MASK  0x00000010

#define MPM_SOCCLK_XBAR_CG_EN_MASK \
      (MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_MASK | \
      MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_MASK | \
      MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_MASK | \
      MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_MASK)

#define MPM_SOCCLK_XBAR_CG_EN_DEFAULT  0x00000006

#define MPM_SOCCLK_XBAR_CG_EN_GET_SOCCLK_XBAR_CG_EN_0(mpm_socclk_xbar_cg_en) \
      ((mpm_socclk_xbar_cg_en & MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_MASK) >> MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_SHIFT)
#define MPM_SOCCLK_XBAR_CG_EN_GET_SOCCLK_XBAR_CG_EN_1(mpm_socclk_xbar_cg_en) \
      ((mpm_socclk_xbar_cg_en & MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_MASK) >> MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_SHIFT)
#define MPM_SOCCLK_XBAR_CG_EN_GET_SOCCLK_XBAR_CG_OVERRIDE_0(mpm_socclk_xbar_cg_en) \
      ((mpm_socclk_xbar_cg_en & MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_MASK) >> MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_SHIFT)
#define MPM_SOCCLK_XBAR_CG_EN_GET_SOCCLK_XBAR_CG_OVERRIDE_1(mpm_socclk_xbar_cg_en) \
      ((mpm_socclk_xbar_cg_en & MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_MASK) >> MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_SHIFT)

#define MPM_SOCCLK_XBAR_CG_EN_SET_SOCCLK_XBAR_CG_EN_0(mpm_socclk_xbar_cg_en_reg, socclk_xbar_cg_en_0) \
      mpm_socclk_xbar_cg_en_reg = (mpm_socclk_xbar_cg_en_reg & ~MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_MASK) | (socclk_xbar_cg_en_0 << MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_SHIFT)
#define MPM_SOCCLK_XBAR_CG_EN_SET_SOCCLK_XBAR_CG_EN_1(mpm_socclk_xbar_cg_en_reg, socclk_xbar_cg_en_1) \
      mpm_socclk_xbar_cg_en_reg = (mpm_socclk_xbar_cg_en_reg & ~MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_MASK) | (socclk_xbar_cg_en_1 << MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_SHIFT)
#define MPM_SOCCLK_XBAR_CG_EN_SET_SOCCLK_XBAR_CG_OVERRIDE_0(mpm_socclk_xbar_cg_en_reg, socclk_xbar_cg_override_0) \
      mpm_socclk_xbar_cg_en_reg = (mpm_socclk_xbar_cg_en_reg & ~MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_MASK) | (socclk_xbar_cg_override_0 << MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_SHIFT)
#define MPM_SOCCLK_XBAR_CG_EN_SET_SOCCLK_XBAR_CG_OVERRIDE_1(mpm_socclk_xbar_cg_en_reg, socclk_xbar_cg_override_1) \
      mpm_socclk_xbar_cg_en_reg = (mpm_socclk_xbar_cg_en_reg & ~MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_MASK) | (socclk_xbar_cg_override_1 << MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_socclk_xbar_cg_en_t {
            unsigned int                                : 1;
            unsigned int socclk_xbar_cg_en_0            : MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_SIZE;
            unsigned int socclk_xbar_cg_en_1            : MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_SIZE;
            unsigned int socclk_xbar_cg_override_0      : MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_SIZE;
            unsigned int socclk_xbar_cg_override_1      : MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_SIZE;
            unsigned int                                : 27;
      } mpm_socclk_xbar_cg_en_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_socclk_xbar_cg_en_t {
            unsigned int                                : 27;
            unsigned int socclk_xbar_cg_override_1      : MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_1_SIZE;
            unsigned int socclk_xbar_cg_override_0      : MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_OVERRIDE_0_SIZE;
            unsigned int socclk_xbar_cg_en_1            : MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_1_SIZE;
            unsigned int socclk_xbar_cg_en_0            : MPM_SOCCLK_XBAR_CG_EN_SOCCLK_XBAR_CG_EN_0_SIZE;
            unsigned int                                : 1;
      } mpm_socclk_xbar_cg_en_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_socclk_xbar_cg_en_t f;
} mpm_socclk_xbar_cg_en_u;


/*
 * MPM_SOCCLK_XBAR_CG_MISC struct
 */

#define MPM_SOCCLK_XBAR_CG_MISC_REG_SIZE         32
#define MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_SIZE  8
#define MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_SIZE  8

#define MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_SHIFT  0
#define MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_SHIFT  8

#define MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_MASK  0x000000ff
#define MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_MASK  0x0000ff00

#define MPM_SOCCLK_XBAR_CG_MISC_MASK \
      (MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_MASK | \
      MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_MASK)

#define MPM_SOCCLK_XBAR_CG_MISC_DEFAULT 0x00000606

#define MPM_SOCCLK_XBAR_CG_MISC_GET_SOCCLK_XBAR_CG_TIMEOUT(mpm_socclk_xbar_cg_misc) \
      ((mpm_socclk_xbar_cg_misc & MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_MASK) >> MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MPM_SOCCLK_XBAR_CG_MISC_GET_SOCCLK_XBAR_CSYS_DELAY(mpm_socclk_xbar_cg_misc) \
      ((mpm_socclk_xbar_cg_misc & MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_MASK) >> MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_SHIFT)

#define MPM_SOCCLK_XBAR_CG_MISC_SET_SOCCLK_XBAR_CG_TIMEOUT(mpm_socclk_xbar_cg_misc_reg, socclk_xbar_cg_timeout) \
      mpm_socclk_xbar_cg_misc_reg = (mpm_socclk_xbar_cg_misc_reg & ~MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_MASK) | (socclk_xbar_cg_timeout << MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MPM_SOCCLK_XBAR_CG_MISC_SET_SOCCLK_XBAR_CSYS_DELAY(mpm_socclk_xbar_cg_misc_reg, socclk_xbar_csys_delay) \
      mpm_socclk_xbar_cg_misc_reg = (mpm_socclk_xbar_cg_misc_reg & ~MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_MASK) | (socclk_xbar_csys_delay << MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_socclk_xbar_cg_misc_t {
            unsigned int socclk_xbar_cg_timeout         : MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_SIZE;
            unsigned int socclk_xbar_csys_delay         : MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_SIZE;
            unsigned int                                : 16;
      } mpm_socclk_xbar_cg_misc_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_socclk_xbar_cg_misc_t {
            unsigned int                                : 16;
            unsigned int socclk_xbar_csys_delay         : MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CSYS_DELAY_SIZE;
            unsigned int socclk_xbar_cg_timeout         : MPM_SOCCLK_XBAR_CG_MISC_SOCCLK_XBAR_CG_TIMEOUT_SIZE;
      } mpm_socclk_xbar_cg_misc_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_socclk_xbar_cg_misc_t f;
} mpm_socclk_xbar_cg_misc_u;


/*
 * MPM_DFP_PGRAM_MHUB_CNTL struct
 */

#define MPM_DFP_PGRAM_MHUB_CNTL_REG_SIZE         32
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_SIZE  1
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_SIZE  1
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_SIZE  1
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_SIZE  1
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_SIZE  1
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_SIZE  8
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_SIZE  8
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DOWN_DLY_MHUB_SIZE  8

#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_SHIFT  0
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_SHIFT  2
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_SHIFT  3
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_SHIFT  4
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_SHIFT  5
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_SHIFT  8
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_SHIFT  16
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DOWN_DLY_MHUB_SHIFT  24

#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_MASK  0x00000001
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_MASK  0x00000004
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_MASK  0x00000008
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_MASK  0x00000010
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_MASK  0x00000020
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_MASK  0x0000ff00
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_MASK  0x00ff0000
#define MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DOWN_DLY_MHUB_MASK  0xff000000

#define MPM_DFP_PGRAM_MHUB_CNTL_MASK \
      (MPM_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_MASK | \
      MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_MASK | \
      MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_MASK | \
      MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_MASK | \
      MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_MASK | \
      MPM_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_MASK | \
      MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_MASK | \
      MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DOWN_DLY_MHUB_MASK)

#define MPM_DFP_PGRAM_MHUB_CNTL_DEFAULT 0x10101028

#define MPM_DFP_PGRAM_MHUB_CNTL_GET_MEM_SD_MHUB(mpm_dfp_pgram_mhub_cntl) \
      ((mpm_dfp_pgram_mhub_cntl & MPM_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_MASK) >> MPM_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_GET_MEM_DEEP_SLEEP_EN_MHUB(mpm_dfp_pgram_mhub_cntl) \
      ((mpm_dfp_pgram_mhub_cntl & MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_MASK) >> MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_GET_MEM_DEEP_SLEEP_STATUS_MHUB(mpm_dfp_pgram_mhub_cntl) \
      ((mpm_dfp_pgram_mhub_cntl & MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_MASK) >> MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_GET_MEM_LIGHT_SLEEP_EN_MHUB(mpm_dfp_pgram_mhub_cntl) \
      ((mpm_dfp_pgram_mhub_cntl & MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_MASK) >> MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_MHUB(mpm_dfp_pgram_mhub_cntl) \
      ((mpm_dfp_pgram_mhub_cntl & MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_MASK) >> MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_GET_MEM_SLEEP_TIMEOUT_MHUB(mpm_dfp_pgram_mhub_cntl) \
      ((mpm_dfp_pgram_mhub_cntl & MPM_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_MASK) >> MPM_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_GET_MEM_PG_DLY_MHUB(mpm_dfp_pgram_mhub_cntl) \
      ((mpm_dfp_pgram_mhub_cntl & MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_MASK) >> MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_GET_MEM_PG_DOWN_DLY_MHUB(mpm_dfp_pgram_mhub_cntl) \
      ((mpm_dfp_pgram_mhub_cntl & MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DOWN_DLY_MHUB_MASK) >> MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DOWN_DLY_MHUB_SHIFT)

#define MPM_DFP_PGRAM_MHUB_CNTL_SET_MEM_SD_MHUB(mpm_dfp_pgram_mhub_cntl_reg, mem_sd_mhub) \
      mpm_dfp_pgram_mhub_cntl_reg = (mpm_dfp_pgram_mhub_cntl_reg & ~MPM_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_MASK) | (mem_sd_mhub << MPM_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_SET_MEM_DEEP_SLEEP_EN_MHUB(mpm_dfp_pgram_mhub_cntl_reg, mem_deep_sleep_en_mhub) \
      mpm_dfp_pgram_mhub_cntl_reg = (mpm_dfp_pgram_mhub_cntl_reg & ~MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_MASK) | (mem_deep_sleep_en_mhub << MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_SET_MEM_DEEP_SLEEP_STATUS_MHUB(mpm_dfp_pgram_mhub_cntl_reg, mem_deep_sleep_status_mhub) \
      mpm_dfp_pgram_mhub_cntl_reg = (mpm_dfp_pgram_mhub_cntl_reg & ~MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_MASK) | (mem_deep_sleep_status_mhub << MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_SET_MEM_LIGHT_SLEEP_EN_MHUB(mpm_dfp_pgram_mhub_cntl_reg, mem_light_sleep_en_mhub) \
      mpm_dfp_pgram_mhub_cntl_reg = (mpm_dfp_pgram_mhub_cntl_reg & ~MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_MASK) | (mem_light_sleep_en_mhub << MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_MHUB(mpm_dfp_pgram_mhub_cntl_reg, mem_light_sleep_status_mhub) \
      mpm_dfp_pgram_mhub_cntl_reg = (mpm_dfp_pgram_mhub_cntl_reg & ~MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_MASK) | (mem_light_sleep_status_mhub << MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_SET_MEM_SLEEP_TIMEOUT_MHUB(mpm_dfp_pgram_mhub_cntl_reg, mem_sleep_timeout_mhub) \
      mpm_dfp_pgram_mhub_cntl_reg = (mpm_dfp_pgram_mhub_cntl_reg & ~MPM_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_MASK) | (mem_sleep_timeout_mhub << MPM_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_SET_MEM_PG_DLY_MHUB(mpm_dfp_pgram_mhub_cntl_reg, mem_pg_dly_mhub) \
      mpm_dfp_pgram_mhub_cntl_reg = (mpm_dfp_pgram_mhub_cntl_reg & ~MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_MASK) | (mem_pg_dly_mhub << MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_SHIFT)
#define MPM_DFP_PGRAM_MHUB_CNTL_SET_MEM_PG_DOWN_DLY_MHUB(mpm_dfp_pgram_mhub_cntl_reg, mem_pg_down_dly_mhub) \
      mpm_dfp_pgram_mhub_cntl_reg = (mpm_dfp_pgram_mhub_cntl_reg & ~MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DOWN_DLY_MHUB_MASK) | (mem_pg_down_dly_mhub << MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DOWN_DLY_MHUB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_dfp_pgram_mhub_cntl_t {
            unsigned int mem_sd_mhub                    : MPM_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_SIZE;
            unsigned int                                : 1;
            unsigned int mem_deep_sleep_en_mhub         : MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_SIZE;
            unsigned int mem_deep_sleep_status_mhub     : MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_SIZE;
            unsigned int mem_light_sleep_en_mhub        : MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_SIZE;
            unsigned int mem_light_sleep_status_mhub    : MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_SIZE;
            unsigned int                                : 2;
            unsigned int mem_sleep_timeout_mhub         : MPM_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_SIZE;
            unsigned int mem_pg_dly_mhub                : MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_SIZE;
            unsigned int mem_pg_down_dly_mhub           : MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DOWN_DLY_MHUB_SIZE;
      } mpm_dfp_pgram_mhub_cntl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_dfp_pgram_mhub_cntl_t {
            unsigned int mem_pg_down_dly_mhub           : MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DOWN_DLY_MHUB_SIZE;
            unsigned int mem_pg_dly_mhub                : MPM_DFP_PGRAM_MHUB_CNTL_MEM_PG_DLY_MHUB_SIZE;
            unsigned int mem_sleep_timeout_mhub         : MPM_DFP_PGRAM_MHUB_CNTL_MEM_SLEEP_TIMEOUT_MHUB_SIZE;
            unsigned int                                : 2;
            unsigned int mem_light_sleep_status_mhub    : MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_MHUB_SIZE;
            unsigned int mem_light_sleep_en_mhub        : MPM_DFP_PGRAM_MHUB_CNTL_MEM_LIGHT_SLEEP_EN_MHUB_SIZE;
            unsigned int mem_deep_sleep_status_mhub     : MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_STATUS_MHUB_SIZE;
            unsigned int mem_deep_sleep_en_mhub         : MPM_DFP_PGRAM_MHUB_CNTL_MEM_DEEP_SLEEP_EN_MHUB_SIZE;
            unsigned int                                : 1;
            unsigned int mem_sd_mhub                    : MPM_DFP_PGRAM_MHUB_CNTL_MEM_SD_MHUB_SIZE;
      } mpm_dfp_pgram_mhub_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_dfp_pgram_mhub_cntl_t f;
} mpm_dfp_pgram_mhub_cntl_u;


/*
 * MPM_DFP_SOCCLKDS_CTRL struct
 */

#define MPM_DFP_SOCCLKDS_CTRL_REG_SIZE         32
#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_SIZE  1
#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_SIZE  1
#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_SIZE  8
#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_SIZE  1

#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_SHIFT  0
#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_SHIFT  1
#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_SHIFT  2
#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_SHIFT  10

#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_MASK  0x00000001
#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_MASK  0x00000002
#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_MASK  0x000003fc
#define MPM_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_MASK  0x00000400

#define MPM_DFP_SOCCLKDS_CTRL_MASK \
      (MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_MASK | \
      MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_MASK | \
      MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_MASK | \
      MPM_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_MASK)

#define MPM_DFP_SOCCLKDS_CTRL_DEFAULT  0x000007fc

#define MPM_DFP_SOCCLKDS_CTRL_GET_SOCCLK_DS_ENB(mpm_dfp_socclkds_ctrl) \
      ((mpm_dfp_socclkds_ctrl & MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_MASK) >> MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_SHIFT)
#define MPM_DFP_SOCCLKDS_CTRL_GET_SOCCLK_DS_STATUS(mpm_dfp_socclkds_ctrl) \
      ((mpm_dfp_socclkds_ctrl & MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_MASK) >> MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_SHIFT)
#define MPM_DFP_SOCCLKDS_CTRL_GET_SOCCLK_DS_TIMEOUT(mpm_dfp_socclkds_ctrl) \
      ((mpm_dfp_socclkds_ctrl & MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_MASK) >> MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_SHIFT)
#define MPM_DFP_SOCCLKDS_CTRL_GET_SOCCLK_MHUBIF_WAKE_MASK(mpm_dfp_socclkds_ctrl) \
      ((mpm_dfp_socclkds_ctrl & MPM_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_MASK) >> MPM_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_SHIFT)

#define MPM_DFP_SOCCLKDS_CTRL_SET_SOCCLK_DS_ENB(mpm_dfp_socclkds_ctrl_reg, socclk_ds_enb) \
      mpm_dfp_socclkds_ctrl_reg = (mpm_dfp_socclkds_ctrl_reg & ~MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_MASK) | (socclk_ds_enb << MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_SHIFT)
#define MPM_DFP_SOCCLKDS_CTRL_SET_SOCCLK_DS_STATUS(mpm_dfp_socclkds_ctrl_reg, socclk_ds_status) \
      mpm_dfp_socclkds_ctrl_reg = (mpm_dfp_socclkds_ctrl_reg & ~MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_MASK) | (socclk_ds_status << MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_SHIFT)
#define MPM_DFP_SOCCLKDS_CTRL_SET_SOCCLK_DS_TIMEOUT(mpm_dfp_socclkds_ctrl_reg, socclk_ds_timeout) \
      mpm_dfp_socclkds_ctrl_reg = (mpm_dfp_socclkds_ctrl_reg & ~MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_MASK) | (socclk_ds_timeout << MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_SHIFT)
#define MPM_DFP_SOCCLKDS_CTRL_SET_SOCCLK_MHUBIF_WAKE_MASK(mpm_dfp_socclkds_ctrl_reg, socclk_mhubif_wake_mask) \
      mpm_dfp_socclkds_ctrl_reg = (mpm_dfp_socclkds_ctrl_reg & ~MPM_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_MASK) | (socclk_mhubif_wake_mask << MPM_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_dfp_socclkds_ctrl_t {
            unsigned int socclk_ds_enb                  : MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_SIZE;
            unsigned int socclk_ds_status               : MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_SIZE;
            unsigned int socclk_ds_timeout              : MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_SIZE;
            unsigned int socclk_mhubif_wake_mask        : MPM_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_SIZE;
            unsigned int                                : 21;
      } mpm_dfp_socclkds_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_dfp_socclkds_ctrl_t {
            unsigned int                                : 21;
            unsigned int socclk_mhubif_wake_mask        : MPM_DFP_SOCCLKDS_CTRL_SOCCLK_MHUBIF_WAKE_MASK_SIZE;
            unsigned int socclk_ds_timeout              : MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_TIMEOUT_SIZE;
            unsigned int socclk_ds_status               : MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_STATUS_SIZE;
            unsigned int socclk_ds_enb                  : MPM_DFP_SOCCLKDS_CTRL_SOCCLK_DS_ENB_SIZE;
      } mpm_dfp_socclkds_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_dfp_socclkds_ctrl_t f;
} mpm_dfp_socclkds_ctrl_u;


/*
 * MPM_SHUBCLK_XBAR_CG_CTRL struct
 */

#define MPM_SHUBCLK_XBAR_CG_CTRL_REG_SIZE         32
#define MPM_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_SIZE  1

#define MPM_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_SHIFT  0

#define MPM_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_MASK  0x00000001

#define MPM_SHUBCLK_XBAR_CG_CTRL_MASK \
      (MPM_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_MASK)

#define MPM_SHUBCLK_XBAR_CG_CTRL_DEFAULT 0x00000000

#define MPM_SHUBCLK_XBAR_CG_CTRL_GET_SHUBCLK_XBAR_CACTIVE_EN(mpm_shubclk_xbar_cg_ctrl) \
      ((mpm_shubclk_xbar_cg_ctrl & MPM_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_MASK) >> MPM_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_SHIFT)

#define MPM_SHUBCLK_XBAR_CG_CTRL_SET_SHUBCLK_XBAR_CACTIVE_EN(mpm_shubclk_xbar_cg_ctrl_reg, shubclk_xbar_cactive_en) \
      mpm_shubclk_xbar_cg_ctrl_reg = (mpm_shubclk_xbar_cg_ctrl_reg & ~MPM_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_MASK) | (shubclk_xbar_cactive_en << MPM_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_shubclk_xbar_cg_ctrl_t {
            unsigned int shubclk_xbar_cactive_en        : MPM_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_SIZE;
            unsigned int                                : 31;
      } mpm_shubclk_xbar_cg_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_shubclk_xbar_cg_ctrl_t {
            unsigned int                                : 31;
            unsigned int shubclk_xbar_cactive_en        : MPM_SHUBCLK_XBAR_CG_CTRL_SHUBCLK_XBAR_CACTIVE_EN_SIZE;
      } mpm_shubclk_xbar_cg_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_shubclk_xbar_cg_ctrl_t f;
} mpm_shubclk_xbar_cg_ctrl_u;


/*
 * MPM_SHUBCLK_XBAR_CG_EN struct
 */

#define MPM_SHUBCLK_XBAR_CG_EN_REG_SIZE         32
#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_SIZE  1
#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_SIZE  1
#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_SIZE  1
#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_SIZE  1

#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_SHIFT  1
#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_SHIFT  2
#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_SHIFT  3
#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_SHIFT  4

#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_MASK  0x00000002
#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_MASK  0x00000004
#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_MASK  0x00000008
#define MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_MASK  0x00000010

#define MPM_SHUBCLK_XBAR_CG_EN_MASK \
      (MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_MASK | \
      MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_MASK | \
      MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_MASK | \
      MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_MASK)

#define MPM_SHUBCLK_XBAR_CG_EN_DEFAULT 0x00000006

#define MPM_SHUBCLK_XBAR_CG_EN_GET_SHUBCLK_XBAR_CG_EN_0(mpm_shubclk_xbar_cg_en) \
      ((mpm_shubclk_xbar_cg_en & MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_MASK) >> MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_SHIFT)
#define MPM_SHUBCLK_XBAR_CG_EN_GET_SHUBCLK_XBAR_CG_EN_1(mpm_shubclk_xbar_cg_en) \
      ((mpm_shubclk_xbar_cg_en & MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_MASK) >> MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_SHIFT)
#define MPM_SHUBCLK_XBAR_CG_EN_GET_SHUBCLK_XBAR_CG_OVERRIDE_0(mpm_shubclk_xbar_cg_en) \
      ((mpm_shubclk_xbar_cg_en & MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_MASK) >> MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_SHIFT)
#define MPM_SHUBCLK_XBAR_CG_EN_GET_SHUBCLK_XBAR_CG_OVERRIDE_1(mpm_shubclk_xbar_cg_en) \
      ((mpm_shubclk_xbar_cg_en & MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_MASK) >> MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_SHIFT)

#define MPM_SHUBCLK_XBAR_CG_EN_SET_SHUBCLK_XBAR_CG_EN_0(mpm_shubclk_xbar_cg_en_reg, shubclk_xbar_cg_en_0) \
      mpm_shubclk_xbar_cg_en_reg = (mpm_shubclk_xbar_cg_en_reg & ~MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_MASK) | (shubclk_xbar_cg_en_0 << MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_SHIFT)
#define MPM_SHUBCLK_XBAR_CG_EN_SET_SHUBCLK_XBAR_CG_EN_1(mpm_shubclk_xbar_cg_en_reg, shubclk_xbar_cg_en_1) \
      mpm_shubclk_xbar_cg_en_reg = (mpm_shubclk_xbar_cg_en_reg & ~MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_MASK) | (shubclk_xbar_cg_en_1 << MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_SHIFT)
#define MPM_SHUBCLK_XBAR_CG_EN_SET_SHUBCLK_XBAR_CG_OVERRIDE_0(mpm_shubclk_xbar_cg_en_reg, shubclk_xbar_cg_override_0) \
      mpm_shubclk_xbar_cg_en_reg = (mpm_shubclk_xbar_cg_en_reg & ~MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_MASK) | (shubclk_xbar_cg_override_0 << MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_SHIFT)
#define MPM_SHUBCLK_XBAR_CG_EN_SET_SHUBCLK_XBAR_CG_OVERRIDE_1(mpm_shubclk_xbar_cg_en_reg, shubclk_xbar_cg_override_1) \
      mpm_shubclk_xbar_cg_en_reg = (mpm_shubclk_xbar_cg_en_reg & ~MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_MASK) | (shubclk_xbar_cg_override_1 << MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_shubclk_xbar_cg_en_t {
            unsigned int                                : 1;
            unsigned int shubclk_xbar_cg_en_0           : MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_SIZE;
            unsigned int shubclk_xbar_cg_en_1           : MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_SIZE;
            unsigned int shubclk_xbar_cg_override_0     : MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_SIZE;
            unsigned int shubclk_xbar_cg_override_1     : MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_SIZE;
            unsigned int                                : 27;
      } mpm_shubclk_xbar_cg_en_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_shubclk_xbar_cg_en_t {
            unsigned int                                : 27;
            unsigned int shubclk_xbar_cg_override_1     : MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_1_SIZE;
            unsigned int shubclk_xbar_cg_override_0     : MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_OVERRIDE_0_SIZE;
            unsigned int shubclk_xbar_cg_en_1           : MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_1_SIZE;
            unsigned int shubclk_xbar_cg_en_0           : MPM_SHUBCLK_XBAR_CG_EN_SHUBCLK_XBAR_CG_EN_0_SIZE;
            unsigned int                                : 1;
      } mpm_shubclk_xbar_cg_en_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_shubclk_xbar_cg_en_t f;
} mpm_shubclk_xbar_cg_en_u;


/*
 * MPM_SHUBCLK_XBAR_CG_MISC struct
 */

#define MPM_SHUBCLK_XBAR_CG_MISC_REG_SIZE         32
#define MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_SIZE  8
#define MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_SIZE  8

#define MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_SHIFT  0
#define MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_SHIFT  8

#define MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_MASK  0x000000ff
#define MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_MASK  0x0000ff00

#define MPM_SHUBCLK_XBAR_CG_MISC_MASK \
      (MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_MASK | \
      MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_MASK)

#define MPM_SHUBCLK_XBAR_CG_MISC_DEFAULT 0x00000606

#define MPM_SHUBCLK_XBAR_CG_MISC_GET_SHUBCLK_XBAR_CG_TIMEOUT(mpm_shubclk_xbar_cg_misc) \
      ((mpm_shubclk_xbar_cg_misc & MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_MASK) >> MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MPM_SHUBCLK_XBAR_CG_MISC_GET_SHUBCLK_XBAR_CSYS_DELAY(mpm_shubclk_xbar_cg_misc) \
      ((mpm_shubclk_xbar_cg_misc & MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_MASK) >> MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_SHIFT)

#define MPM_SHUBCLK_XBAR_CG_MISC_SET_SHUBCLK_XBAR_CG_TIMEOUT(mpm_shubclk_xbar_cg_misc_reg, shubclk_xbar_cg_timeout) \
      mpm_shubclk_xbar_cg_misc_reg = (mpm_shubclk_xbar_cg_misc_reg & ~MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_MASK) | (shubclk_xbar_cg_timeout << MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_SHIFT)
#define MPM_SHUBCLK_XBAR_CG_MISC_SET_SHUBCLK_XBAR_CSYS_DELAY(mpm_shubclk_xbar_cg_misc_reg, shubclk_xbar_csys_delay) \
      mpm_shubclk_xbar_cg_misc_reg = (mpm_shubclk_xbar_cg_misc_reg & ~MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_MASK) | (shubclk_xbar_csys_delay << MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_shubclk_xbar_cg_misc_t {
            unsigned int shubclk_xbar_cg_timeout        : MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_SIZE;
            unsigned int shubclk_xbar_csys_delay        : MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_SIZE;
            unsigned int                                : 16;
      } mpm_shubclk_xbar_cg_misc_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_shubclk_xbar_cg_misc_t {
            unsigned int                                : 16;
            unsigned int shubclk_xbar_csys_delay        : MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CSYS_DELAY_SIZE;
            unsigned int shubclk_xbar_cg_timeout        : MPM_SHUBCLK_XBAR_CG_MISC_SHUBCLK_XBAR_CG_TIMEOUT_SIZE;
      } mpm_shubclk_xbar_cg_misc_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_shubclk_xbar_cg_misc_t f;
} mpm_shubclk_xbar_cg_misc_u;


/*
 * MPM_DFP_PGRAM_SHUB_CNTL struct
 */

#define MPM_DFP_PGRAM_SHUB_CNTL_REG_SIZE         32
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_SIZE  1
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_SIZE  1
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_SIZE  1
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_SIZE  1
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_SIZE  1
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_SIZE  8
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_SIZE  8
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DOWN_DLY_SHUB_SIZE  8

#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_SHIFT  0
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_SHIFT  2
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_SHIFT  3
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_SHIFT  4
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_SHIFT  5
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_SHIFT  8
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_SHIFT  16
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DOWN_DLY_SHUB_SHIFT  24

#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_MASK  0x00000001
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_MASK  0x00000004
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_MASK  0x00000008
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_MASK  0x00000010
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_MASK  0x00000020
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_MASK  0x0000ff00
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_MASK  0x00ff0000
#define MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DOWN_DLY_SHUB_MASK  0xff000000

#define MPM_DFP_PGRAM_SHUB_CNTL_MASK \
      (MPM_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_MASK | \
      MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_MASK | \
      MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_MASK | \
      MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_MASK | \
      MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_MASK | \
      MPM_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_MASK | \
      MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_MASK | \
      MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DOWN_DLY_SHUB_MASK)

#define MPM_DFP_PGRAM_SHUB_CNTL_DEFAULT 0x10101028

#define MPM_DFP_PGRAM_SHUB_CNTL_GET_MEM_SD_SHUB(mpm_dfp_pgram_shub_cntl) \
      ((mpm_dfp_pgram_shub_cntl & MPM_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_MASK) >> MPM_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_GET_MEM_DEEP_SLEEP_EN_SHUB(mpm_dfp_pgram_shub_cntl) \
      ((mpm_dfp_pgram_shub_cntl & MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_MASK) >> MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_GET_MEM_DEEP_SLEEP_STATUS_SHUB(mpm_dfp_pgram_shub_cntl) \
      ((mpm_dfp_pgram_shub_cntl & MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_MASK) >> MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_GET_MEM_LIGHT_SLEEP_EN_SHUB(mpm_dfp_pgram_shub_cntl) \
      ((mpm_dfp_pgram_shub_cntl & MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_MASK) >> MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_GET_MEM_LIGHT_SLEEP_STATUS_SHUB(mpm_dfp_pgram_shub_cntl) \
      ((mpm_dfp_pgram_shub_cntl & MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_MASK) >> MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_GET_MEM_SLEEP_TIMEOUT_SHUB(mpm_dfp_pgram_shub_cntl) \
      ((mpm_dfp_pgram_shub_cntl & MPM_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_MASK) >> MPM_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_GET_MEM_PG_DLY_SHUB(mpm_dfp_pgram_shub_cntl) \
      ((mpm_dfp_pgram_shub_cntl & MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_MASK) >> MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_GET_MEM_PG_DOWN_DLY_SHUB(mpm_dfp_pgram_shub_cntl) \
      ((mpm_dfp_pgram_shub_cntl & MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DOWN_DLY_SHUB_MASK) >> MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DOWN_DLY_SHUB_SHIFT)

#define MPM_DFP_PGRAM_SHUB_CNTL_SET_MEM_SD_SHUB(mpm_dfp_pgram_shub_cntl_reg, mem_sd_shub) \
      mpm_dfp_pgram_shub_cntl_reg = (mpm_dfp_pgram_shub_cntl_reg & ~MPM_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_MASK) | (mem_sd_shub << MPM_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_SET_MEM_DEEP_SLEEP_EN_SHUB(mpm_dfp_pgram_shub_cntl_reg, mem_deep_sleep_en_shub) \
      mpm_dfp_pgram_shub_cntl_reg = (mpm_dfp_pgram_shub_cntl_reg & ~MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_MASK) | (mem_deep_sleep_en_shub << MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_SET_MEM_DEEP_SLEEP_STATUS_SHUB(mpm_dfp_pgram_shub_cntl_reg, mem_deep_sleep_status_shub) \
      mpm_dfp_pgram_shub_cntl_reg = (mpm_dfp_pgram_shub_cntl_reg & ~MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_MASK) | (mem_deep_sleep_status_shub << MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_SET_MEM_LIGHT_SLEEP_EN_SHUB(mpm_dfp_pgram_shub_cntl_reg, mem_light_sleep_en_shub) \
      mpm_dfp_pgram_shub_cntl_reg = (mpm_dfp_pgram_shub_cntl_reg & ~MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_MASK) | (mem_light_sleep_en_shub << MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_SET_MEM_LIGHT_SLEEP_STATUS_SHUB(mpm_dfp_pgram_shub_cntl_reg, mem_light_sleep_status_shub) \
      mpm_dfp_pgram_shub_cntl_reg = (mpm_dfp_pgram_shub_cntl_reg & ~MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_MASK) | (mem_light_sleep_status_shub << MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_SET_MEM_SLEEP_TIMEOUT_SHUB(mpm_dfp_pgram_shub_cntl_reg, mem_sleep_timeout_shub) \
      mpm_dfp_pgram_shub_cntl_reg = (mpm_dfp_pgram_shub_cntl_reg & ~MPM_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_MASK) | (mem_sleep_timeout_shub << MPM_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_SET_MEM_PG_DLY_SHUB(mpm_dfp_pgram_shub_cntl_reg, mem_pg_dly_shub) \
      mpm_dfp_pgram_shub_cntl_reg = (mpm_dfp_pgram_shub_cntl_reg & ~MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_MASK) | (mem_pg_dly_shub << MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_SHIFT)
#define MPM_DFP_PGRAM_SHUB_CNTL_SET_MEM_PG_DOWN_DLY_SHUB(mpm_dfp_pgram_shub_cntl_reg, mem_pg_down_dly_shub) \
      mpm_dfp_pgram_shub_cntl_reg = (mpm_dfp_pgram_shub_cntl_reg & ~MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DOWN_DLY_SHUB_MASK) | (mem_pg_down_dly_shub << MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DOWN_DLY_SHUB_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_dfp_pgram_shub_cntl_t {
            unsigned int mem_sd_shub                    : MPM_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_SIZE;
            unsigned int                                : 1;
            unsigned int mem_deep_sleep_en_shub         : MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_SIZE;
            unsigned int mem_deep_sleep_status_shub     : MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_SIZE;
            unsigned int mem_light_sleep_en_shub        : MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_SIZE;
            unsigned int mem_light_sleep_status_shub    : MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_SIZE;
            unsigned int                                : 2;
            unsigned int mem_sleep_timeout_shub         : MPM_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_SIZE;
            unsigned int mem_pg_dly_shub                : MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_SIZE;
            unsigned int mem_pg_down_dly_shub           : MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DOWN_DLY_SHUB_SIZE;
      } mpm_dfp_pgram_shub_cntl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_dfp_pgram_shub_cntl_t {
            unsigned int mem_pg_down_dly_shub           : MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DOWN_DLY_SHUB_SIZE;
            unsigned int mem_pg_dly_shub                : MPM_DFP_PGRAM_SHUB_CNTL_MEM_PG_DLY_SHUB_SIZE;
            unsigned int mem_sleep_timeout_shub         : MPM_DFP_PGRAM_SHUB_CNTL_MEM_SLEEP_TIMEOUT_SHUB_SIZE;
            unsigned int                                : 2;
            unsigned int mem_light_sleep_status_shub    : MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_STATUS_SHUB_SIZE;
            unsigned int mem_light_sleep_en_shub        : MPM_DFP_PGRAM_SHUB_CNTL_MEM_LIGHT_SLEEP_EN_SHUB_SIZE;
            unsigned int mem_deep_sleep_status_shub     : MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_STATUS_SHUB_SIZE;
            unsigned int mem_deep_sleep_en_shub         : MPM_DFP_PGRAM_SHUB_CNTL_MEM_DEEP_SLEEP_EN_SHUB_SIZE;
            unsigned int                                : 1;
            unsigned int mem_sd_shub                    : MPM_DFP_PGRAM_SHUB_CNTL_MEM_SD_SHUB_SIZE;
      } mpm_dfp_pgram_shub_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_dfp_pgram_shub_cntl_t f;
} mpm_dfp_pgram_shub_cntl_u;


/*
 * MPM_DFP_SHUBCLKDS_CTRL struct
 */

#define MPM_DFP_SHUBCLKDS_CTRL_REG_SIZE         32
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_SIZE  1
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_SIZE  1
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_SIZE  8
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_SIZE  1
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_HUBIFNB_WAKE_MASK_SIZE  1

#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_SHIFT  0
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_SHIFT  1
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_SHIFT  2
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_SHIFT  10
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_HUBIFNB_WAKE_MASK_SHIFT  11

#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_MASK  0x00000001
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_MASK  0x00000002
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_MASK  0x000003fc
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_MASK  0x00000400
#define MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_HUBIFNB_WAKE_MASK_MASK  0x00000800

#define MPM_DFP_SHUBCLKDS_CTRL_MASK \
      (MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_MASK | \
      MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_MASK | \
      MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_MASK | \
      MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_MASK | \
      MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_HUBIFNB_WAKE_MASK_MASK)

#define MPM_DFP_SHUBCLKDS_CTRL_DEFAULT 0x00000ffc

#define MPM_DFP_SHUBCLKDS_CTRL_GET_SHUBCLK_DS_ENB(mpm_dfp_shubclkds_ctrl) \
      ((mpm_dfp_shubclkds_ctrl & MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_MASK) >> MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_SHIFT)
#define MPM_DFP_SHUBCLKDS_CTRL_GET_SHUBCLK_DS_STATUS(mpm_dfp_shubclkds_ctrl) \
      ((mpm_dfp_shubclkds_ctrl & MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_MASK) >> MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_SHIFT)
#define MPM_DFP_SHUBCLKDS_CTRL_GET_SHUBCLK_DS_TIMEOUT(mpm_dfp_shubclkds_ctrl) \
      ((mpm_dfp_shubclkds_ctrl & MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_MASK) >> MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_SHIFT)
#define MPM_DFP_SHUBCLKDS_CTRL_GET_SHUBCLK_SHUBIF_WAKE_MASK(mpm_dfp_shubclkds_ctrl) \
      ((mpm_dfp_shubclkds_ctrl & MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_MASK) >> MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_SHIFT)
#define MPM_DFP_SHUBCLKDS_CTRL_GET_SHUBCLK_HUBIFNB_WAKE_MASK(mpm_dfp_shubclkds_ctrl) \
      ((mpm_dfp_shubclkds_ctrl & MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_HUBIFNB_WAKE_MASK_MASK) >> MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_HUBIFNB_WAKE_MASK_SHIFT)

#define MPM_DFP_SHUBCLKDS_CTRL_SET_SHUBCLK_DS_ENB(mpm_dfp_shubclkds_ctrl_reg, shubclk_ds_enb) \
      mpm_dfp_shubclkds_ctrl_reg = (mpm_dfp_shubclkds_ctrl_reg & ~MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_MASK) | (shubclk_ds_enb << MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_SHIFT)
#define MPM_DFP_SHUBCLKDS_CTRL_SET_SHUBCLK_DS_STATUS(mpm_dfp_shubclkds_ctrl_reg, shubclk_ds_status) \
      mpm_dfp_shubclkds_ctrl_reg = (mpm_dfp_shubclkds_ctrl_reg & ~MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_MASK) | (shubclk_ds_status << MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_SHIFT)
#define MPM_DFP_SHUBCLKDS_CTRL_SET_SHUBCLK_DS_TIMEOUT(mpm_dfp_shubclkds_ctrl_reg, shubclk_ds_timeout) \
      mpm_dfp_shubclkds_ctrl_reg = (mpm_dfp_shubclkds_ctrl_reg & ~MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_MASK) | (shubclk_ds_timeout << MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_SHIFT)
#define MPM_DFP_SHUBCLKDS_CTRL_SET_SHUBCLK_SHUBIF_WAKE_MASK(mpm_dfp_shubclkds_ctrl_reg, shubclk_shubif_wake_mask) \
      mpm_dfp_shubclkds_ctrl_reg = (mpm_dfp_shubclkds_ctrl_reg & ~MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_MASK) | (shubclk_shubif_wake_mask << MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_SHIFT)
#define MPM_DFP_SHUBCLKDS_CTRL_SET_SHUBCLK_HUBIFNB_WAKE_MASK(mpm_dfp_shubclkds_ctrl_reg, shubclk_hubifnb_wake_mask) \
      mpm_dfp_shubclkds_ctrl_reg = (mpm_dfp_shubclkds_ctrl_reg & ~MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_HUBIFNB_WAKE_MASK_MASK) | (shubclk_hubifnb_wake_mask << MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_HUBIFNB_WAKE_MASK_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mpm_dfp_shubclkds_ctrl_t {
            unsigned int shubclk_ds_enb                 : MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_SIZE;
            unsigned int shubclk_ds_status              : MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_SIZE;
            unsigned int shubclk_ds_timeout             : MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_SIZE;
            unsigned int shubclk_shubif_wake_mask       : MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_SIZE;
            unsigned int shubclk_hubifnb_wake_mask      : MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_HUBIFNB_WAKE_MASK_SIZE;
            unsigned int                                : 20;
      } mpm_dfp_shubclkds_ctrl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mpm_dfp_shubclkds_ctrl_t {
            unsigned int                                : 20;
            unsigned int shubclk_hubifnb_wake_mask      : MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_HUBIFNB_WAKE_MASK_SIZE;
            unsigned int shubclk_shubif_wake_mask       : MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_SHUBIF_WAKE_MASK_SIZE;
            unsigned int shubclk_ds_timeout             : MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_TIMEOUT_SIZE;
            unsigned int shubclk_ds_status              : MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_STATUS_SIZE;
            unsigned int shubclk_ds_enb                 : MPM_DFP_SHUBCLKDS_CTRL_SHUBCLK_DS_ENB_SIZE;
      } mpm_dfp_shubclkds_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
          mpm_dfp_shubclkds_ctrl_t f;
} mpm_dfp_shubclkds_ctrl_u;


#endif

