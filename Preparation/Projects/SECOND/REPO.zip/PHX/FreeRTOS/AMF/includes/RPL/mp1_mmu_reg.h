// Copyright (c) 1994 - 2021 Advanced Micro Devices, Inc. All rights reserved. 
 #if !defined (_MP1_MMU_FIDDLE_H)
#define _MP1_MMU_FIDDLE_H
 /*****************************************************************************************************************
 *
 *  mp1_mmu_reg.h
 *
 *  Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif

 /*******************************************************
 * Values
 *******************************************************/

 /*******************************************************
 * Structures
 *******************************************************/

/*
 * MP1_CONFIG struct
 */

#define MP1_CONFIG_REG_SIZE         32
#define MP1_CONFIG_EnableCacheClear_OnReset_SIZE  1

#define MP1_CONFIG_EnableCacheClear_OnReset_SHIFT  3

#define MP1_CONFIG_EnableCacheClear_OnReset_MASK  0x00000008

#define MP1_CONFIG_MASK \
      (MP1_CONFIG_EnableCacheClear_OnReset_MASK)

#define MP1_CONFIG_DEFAULT             0x00000000

#define MP1_CONFIG_GET_EnableCacheClear_OnReset(mp1_config) \
      ((mp1_config & MP1_CONFIG_EnableCacheClear_OnReset_MASK) >> MP1_CONFIG_EnableCacheClear_OnReset_SHIFT)

#define MP1_CONFIG_SET_EnableCacheClear_OnReset(mp1_config_reg, enablecacheclear_onreset) \
      mp1_config_reg = (mp1_config_reg & ~MP1_CONFIG_EnableCacheClear_OnReset_MASK) | (enablecacheclear_onreset << MP1_CONFIG_EnableCacheClear_OnReset_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_config_t {
            unsigned int                                : 3;
            unsigned int enablecacheclear_onreset       : MP1_CONFIG_EnableCacheClear_OnReset_SIZE;
            unsigned int                                : 28;
      } mp1_config_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_config_t {
            unsigned int                                : 28;
            unsigned int enablecacheclear_onreset       : MP1_CONFIG_EnableCacheClear_OnReset_SIZE;
            unsigned int                                : 3;
      } mp1_config_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_config_t f;
} mp1_config_u;


/*
 * MP1_PMI_0_START struct
 */

#define MP1_PMI_0_START_REG_SIZE         32
#define MP1_PMI_0_START_ADDR_SIZE  18
#define MP1_PMI_0_START_ENABLE_SIZE  1

#define MP1_PMI_0_START_ADDR_SHIFT  0
#define MP1_PMI_0_START_ENABLE_SHIFT  31

#define MP1_PMI_0_START_ADDR_MASK       0x0003ffff
#define MP1_PMI_0_START_ENABLE_MASK     0x80000000

#define MP1_PMI_0_START_MASK \
      (MP1_PMI_0_START_ADDR_MASK | \
      MP1_PMI_0_START_ENABLE_MASK)

#define MP1_PMI_0_START_DEFAULT        0x00000000

#define MP1_PMI_0_START_GET_ADDR(mp1_pmi_0_start) \
      ((mp1_pmi_0_start & MP1_PMI_0_START_ADDR_MASK) >> MP1_PMI_0_START_ADDR_SHIFT)
#define MP1_PMI_0_START_GET_ENABLE(mp1_pmi_0_start) \
      ((mp1_pmi_0_start & MP1_PMI_0_START_ENABLE_MASK) >> MP1_PMI_0_START_ENABLE_SHIFT)

#define MP1_PMI_0_START_SET_ADDR(mp1_pmi_0_start_reg, addr) \
      mp1_pmi_0_start_reg = (mp1_pmi_0_start_reg & ~MP1_PMI_0_START_ADDR_MASK) | (addr << MP1_PMI_0_START_ADDR_SHIFT)
#define MP1_PMI_0_START_SET_ENABLE(mp1_pmi_0_start_reg, enable) \
      mp1_pmi_0_start_reg = (mp1_pmi_0_start_reg & ~MP1_PMI_0_START_ENABLE_MASK) | (enable << MP1_PMI_0_START_ENABLE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_0_start_t {
            unsigned int addr                           : MP1_PMI_0_START_ADDR_SIZE;
            unsigned int                                : 13;
            unsigned int enable                         : MP1_PMI_0_START_ENABLE_SIZE;
      } mp1_pmi_0_start_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_0_start_t {
            unsigned int enable                         : MP1_PMI_0_START_ENABLE_SIZE;
            unsigned int                                : 13;
            unsigned int addr                           : MP1_PMI_0_START_ADDR_SIZE;
      } mp1_pmi_0_start_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_0_start_t f;
} mp1_pmi_0_start_u;


/*
 * MP1_PMI_0_FIFO struct
 */

#define MP1_PMI_0_FIFO_REG_SIZE         32
#define MP1_PMI_0_FIFO_DEPTH_SIZE  4

#define MP1_PMI_0_FIFO_DEPTH_SHIFT  0

#define MP1_PMI_0_FIFO_DEPTH_MASK       0x0000000f

#define MP1_PMI_0_FIFO_MASK \
      (MP1_PMI_0_FIFO_DEPTH_MASK)

#define MP1_PMI_0_FIFO_DEFAULT         0x00000004

#define MP1_PMI_0_FIFO_GET_DEPTH(mp1_pmi_0_fifo) \
      ((mp1_pmi_0_fifo & MP1_PMI_0_FIFO_DEPTH_MASK) >> MP1_PMI_0_FIFO_DEPTH_SHIFT)

#define MP1_PMI_0_FIFO_SET_DEPTH(mp1_pmi_0_fifo_reg, depth) \
      mp1_pmi_0_fifo_reg = (mp1_pmi_0_fifo_reg & ~MP1_PMI_0_FIFO_DEPTH_MASK) | (depth << MP1_PMI_0_FIFO_DEPTH_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_0_fifo_t {
            unsigned int depth                          : MP1_PMI_0_FIFO_DEPTH_SIZE;
            unsigned int                                : 28;
      } mp1_pmi_0_fifo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_0_fifo_t {
            unsigned int                                : 28;
            unsigned int depth                          : MP1_PMI_0_FIFO_DEPTH_SIZE;
      } mp1_pmi_0_fifo_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_0_fifo_t f;
} mp1_pmi_0_fifo_u;


/*
 * MP1_PMI_0_STATUS struct
 */

#define MP1_PMI_0_STATUS_REG_SIZE         32
#define MP1_PMI_0_STATUS_FULL_SIZE  1
#define MP1_PMI_0_STATUS_EMPTY_SIZE  1

#define MP1_PMI_0_STATUS_FULL_SHIFT  0
#define MP1_PMI_0_STATUS_EMPTY_SHIFT  1

#define MP1_PMI_0_STATUS_FULL_MASK      0x00000001
#define MP1_PMI_0_STATUS_EMPTY_MASK     0x00000002

#define MP1_PMI_0_STATUS_MASK \
      (MP1_PMI_0_STATUS_FULL_MASK | \
      MP1_PMI_0_STATUS_EMPTY_MASK)

#define MP1_PMI_0_STATUS_DEFAULT       0x00000002

#define MP1_PMI_0_STATUS_GET_FULL(mp1_pmi_0_status) \
      ((mp1_pmi_0_status & MP1_PMI_0_STATUS_FULL_MASK) >> MP1_PMI_0_STATUS_FULL_SHIFT)
#define MP1_PMI_0_STATUS_GET_EMPTY(mp1_pmi_0_status) \
      ((mp1_pmi_0_status & MP1_PMI_0_STATUS_EMPTY_MASK) >> MP1_PMI_0_STATUS_EMPTY_SHIFT)

#define MP1_PMI_0_STATUS_SET_FULL(mp1_pmi_0_status_reg, full) \
      mp1_pmi_0_status_reg = (mp1_pmi_0_status_reg & ~MP1_PMI_0_STATUS_FULL_MASK) | (full << MP1_PMI_0_STATUS_FULL_SHIFT)
#define MP1_PMI_0_STATUS_SET_EMPTY(mp1_pmi_0_status_reg, empty) \
      mp1_pmi_0_status_reg = (mp1_pmi_0_status_reg & ~MP1_PMI_0_STATUS_EMPTY_MASK) | (empty << MP1_PMI_0_STATUS_EMPTY_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_0_status_t {
            unsigned int full                           : MP1_PMI_0_STATUS_FULL_SIZE;
            unsigned int empty                          : MP1_PMI_0_STATUS_EMPTY_SIZE;
            unsigned int                                : 30;
      } mp1_pmi_0_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_0_status_t {
            unsigned int                                : 30;
            unsigned int empty                          : MP1_PMI_0_STATUS_EMPTY_SIZE;
            unsigned int full                           : MP1_PMI_0_STATUS_FULL_SIZE;
      } mp1_pmi_0_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_0_status_t f;
} mp1_pmi_0_status_u;


/*
 * MP1_PMI_0_READ_POINTER struct
 */

#define MP1_PMI_0_READ_POINTER_REG_SIZE         32
#define MP1_PMI_0_READ_POINTER_CURRENT_SIZE  18

#define MP1_PMI_0_READ_POINTER_CURRENT_SHIFT  0

#define MP1_PMI_0_READ_POINTER_CURRENT_MASK  0x0003ffff

#define MP1_PMI_0_READ_POINTER_MASK \
      (MP1_PMI_0_READ_POINTER_CURRENT_MASK)

#define MP1_PMI_0_READ_POINTER_DEFAULT 0x00000000

#define MP1_PMI_0_READ_POINTER_GET_CURRENT(mp1_pmi_0_read_pointer) \
      ((mp1_pmi_0_read_pointer & MP1_PMI_0_READ_POINTER_CURRENT_MASK) >> MP1_PMI_0_READ_POINTER_CURRENT_SHIFT)

#define MP1_PMI_0_READ_POINTER_SET_CURRENT(mp1_pmi_0_read_pointer_reg, current) \
      mp1_pmi_0_read_pointer_reg = (mp1_pmi_0_read_pointer_reg & ~MP1_PMI_0_READ_POINTER_CURRENT_MASK) | (current << MP1_PMI_0_READ_POINTER_CURRENT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_0_read_pointer_t {
            unsigned int current                        : MP1_PMI_0_READ_POINTER_CURRENT_SIZE;
            unsigned int                                : 14;
      } mp1_pmi_0_read_pointer_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_0_read_pointer_t {
            unsigned int                                : 14;
            unsigned int current                        : MP1_PMI_0_READ_POINTER_CURRENT_SIZE;
      } mp1_pmi_0_read_pointer_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_0_read_pointer_t f;
} mp1_pmi_0_read_pointer_u;


/*
 * MP1_PMI_0_WRITE_POINTER struct
 */

#define MP1_PMI_0_WRITE_POINTER_REG_SIZE         32
#define MP1_PMI_0_WRITE_POINTER_CURRENT_SIZE  18

#define MP1_PMI_0_WRITE_POINTER_CURRENT_SHIFT  0

#define MP1_PMI_0_WRITE_POINTER_CURRENT_MASK  0x0003ffff

#define MP1_PMI_0_WRITE_POINTER_MASK \
      (MP1_PMI_0_WRITE_POINTER_CURRENT_MASK)

#define MP1_PMI_0_WRITE_POINTER_DEFAULT 0x00000000

#define MP1_PMI_0_WRITE_POINTER_GET_CURRENT(mp1_pmi_0_write_pointer) \
      ((mp1_pmi_0_write_pointer & MP1_PMI_0_WRITE_POINTER_CURRENT_MASK) >> MP1_PMI_0_WRITE_POINTER_CURRENT_SHIFT)

#define MP1_PMI_0_WRITE_POINTER_SET_CURRENT(mp1_pmi_0_write_pointer_reg, current) \
      mp1_pmi_0_write_pointer_reg = (mp1_pmi_0_write_pointer_reg & ~MP1_PMI_0_WRITE_POINTER_CURRENT_MASK) | (current << MP1_PMI_0_WRITE_POINTER_CURRENT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_0_write_pointer_t {
            unsigned int current                        : MP1_PMI_0_WRITE_POINTER_CURRENT_SIZE;
            unsigned int                                : 14;
      } mp1_pmi_0_write_pointer_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_0_write_pointer_t {
            unsigned int                                : 14;
            unsigned int current                        : MP1_PMI_0_WRITE_POINTER_CURRENT_SIZE;
      } mp1_pmi_0_write_pointer_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_0_write_pointer_t f;
} mp1_pmi_0_write_pointer_u;


/*
 * MP1_PMI_1_START struct
 */

#define MP1_PMI_1_START_REG_SIZE         32
#define MP1_PMI_1_START_ADDR_SIZE  18
#define MP1_PMI_1_START_ENABLE_SIZE  1

#define MP1_PMI_1_START_ADDR_SHIFT  0
#define MP1_PMI_1_START_ENABLE_SHIFT  31

#define MP1_PMI_1_START_ADDR_MASK       0x0003ffff
#define MP1_PMI_1_START_ENABLE_MASK     0x80000000

#define MP1_PMI_1_START_MASK \
      (MP1_PMI_1_START_ADDR_MASK | \
      MP1_PMI_1_START_ENABLE_MASK)

#define MP1_PMI_1_START_DEFAULT        0x00000000

#define MP1_PMI_1_START_GET_ADDR(mp1_pmi_1_start) \
      ((mp1_pmi_1_start & MP1_PMI_1_START_ADDR_MASK) >> MP1_PMI_1_START_ADDR_SHIFT)
#define MP1_PMI_1_START_GET_ENABLE(mp1_pmi_1_start) \
      ((mp1_pmi_1_start & MP1_PMI_1_START_ENABLE_MASK) >> MP1_PMI_1_START_ENABLE_SHIFT)

#define MP1_PMI_1_START_SET_ADDR(mp1_pmi_1_start_reg, addr) \
      mp1_pmi_1_start_reg = (mp1_pmi_1_start_reg & ~MP1_PMI_1_START_ADDR_MASK) | (addr << MP1_PMI_1_START_ADDR_SHIFT)
#define MP1_PMI_1_START_SET_ENABLE(mp1_pmi_1_start_reg, enable) \
      mp1_pmi_1_start_reg = (mp1_pmi_1_start_reg & ~MP1_PMI_1_START_ENABLE_MASK) | (enable << MP1_PMI_1_START_ENABLE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_1_start_t {
            unsigned int addr                           : MP1_PMI_1_START_ADDR_SIZE;
            unsigned int                                : 13;
            unsigned int enable                         : MP1_PMI_1_START_ENABLE_SIZE;
      } mp1_pmi_1_start_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_1_start_t {
            unsigned int enable                         : MP1_PMI_1_START_ENABLE_SIZE;
            unsigned int                                : 13;
            unsigned int addr                           : MP1_PMI_1_START_ADDR_SIZE;
      } mp1_pmi_1_start_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_1_start_t f;
} mp1_pmi_1_start_u;


/*
 * MP1_PMI_1_FIFO struct
 */

#define MP1_PMI_1_FIFO_REG_SIZE         32
#define MP1_PMI_1_FIFO_DEPTH_SIZE  4

#define MP1_PMI_1_FIFO_DEPTH_SHIFT  0

#define MP1_PMI_1_FIFO_DEPTH_MASK       0x0000000f

#define MP1_PMI_1_FIFO_MASK \
      (MP1_PMI_1_FIFO_DEPTH_MASK)

#define MP1_PMI_1_FIFO_DEFAULT         0x00000004

#define MP1_PMI_1_FIFO_GET_DEPTH(mp1_pmi_1_fifo) \
      ((mp1_pmi_1_fifo & MP1_PMI_1_FIFO_DEPTH_MASK) >> MP1_PMI_1_FIFO_DEPTH_SHIFT)

#define MP1_PMI_1_FIFO_SET_DEPTH(mp1_pmi_1_fifo_reg, depth) \
      mp1_pmi_1_fifo_reg = (mp1_pmi_1_fifo_reg & ~MP1_PMI_1_FIFO_DEPTH_MASK) | (depth << MP1_PMI_1_FIFO_DEPTH_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_1_fifo_t {
            unsigned int depth                          : MP1_PMI_1_FIFO_DEPTH_SIZE;
            unsigned int                                : 28;
      } mp1_pmi_1_fifo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_1_fifo_t {
            unsigned int                                : 28;
            unsigned int depth                          : MP1_PMI_1_FIFO_DEPTH_SIZE;
      } mp1_pmi_1_fifo_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_1_fifo_t f;
} mp1_pmi_1_fifo_u;


/*
 * MP1_PMI_1_STATUS struct
 */

#define MP1_PMI_1_STATUS_REG_SIZE         32
#define MP1_PMI_1_STATUS_FULL_SIZE  1
#define MP1_PMI_1_STATUS_EMPTY_SIZE  1

#define MP1_PMI_1_STATUS_FULL_SHIFT  0
#define MP1_PMI_1_STATUS_EMPTY_SHIFT  1

#define MP1_PMI_1_STATUS_FULL_MASK      0x00000001
#define MP1_PMI_1_STATUS_EMPTY_MASK     0x00000002

#define MP1_PMI_1_STATUS_MASK \
      (MP1_PMI_1_STATUS_FULL_MASK | \
      MP1_PMI_1_STATUS_EMPTY_MASK)

#define MP1_PMI_1_STATUS_DEFAULT       0x00000002

#define MP1_PMI_1_STATUS_GET_FULL(mp1_pmi_1_status) \
      ((mp1_pmi_1_status & MP1_PMI_1_STATUS_FULL_MASK) >> MP1_PMI_1_STATUS_FULL_SHIFT)
#define MP1_PMI_1_STATUS_GET_EMPTY(mp1_pmi_1_status) \
      ((mp1_pmi_1_status & MP1_PMI_1_STATUS_EMPTY_MASK) >> MP1_PMI_1_STATUS_EMPTY_SHIFT)

#define MP1_PMI_1_STATUS_SET_FULL(mp1_pmi_1_status_reg, full) \
      mp1_pmi_1_status_reg = (mp1_pmi_1_status_reg & ~MP1_PMI_1_STATUS_FULL_MASK) | (full << MP1_PMI_1_STATUS_FULL_SHIFT)
#define MP1_PMI_1_STATUS_SET_EMPTY(mp1_pmi_1_status_reg, empty) \
      mp1_pmi_1_status_reg = (mp1_pmi_1_status_reg & ~MP1_PMI_1_STATUS_EMPTY_MASK) | (empty << MP1_PMI_1_STATUS_EMPTY_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_1_status_t {
            unsigned int full                           : MP1_PMI_1_STATUS_FULL_SIZE;
            unsigned int empty                          : MP1_PMI_1_STATUS_EMPTY_SIZE;
            unsigned int                                : 30;
      } mp1_pmi_1_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_1_status_t {
            unsigned int                                : 30;
            unsigned int empty                          : MP1_PMI_1_STATUS_EMPTY_SIZE;
            unsigned int full                           : MP1_PMI_1_STATUS_FULL_SIZE;
      } mp1_pmi_1_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_1_status_t f;
} mp1_pmi_1_status_u;


/*
 * MP1_PMI_1_READ_POINTER struct
 */

#define MP1_PMI_1_READ_POINTER_REG_SIZE         32
#define MP1_PMI_1_READ_POINTER_CURRENT_SIZE  18

#define MP1_PMI_1_READ_POINTER_CURRENT_SHIFT  0

#define MP1_PMI_1_READ_POINTER_CURRENT_MASK  0x0003ffff

#define MP1_PMI_1_READ_POINTER_MASK \
      (MP1_PMI_1_READ_POINTER_CURRENT_MASK)

#define MP1_PMI_1_READ_POINTER_DEFAULT 0x00000000

#define MP1_PMI_1_READ_POINTER_GET_CURRENT(mp1_pmi_1_read_pointer) \
      ((mp1_pmi_1_read_pointer & MP1_PMI_1_READ_POINTER_CURRENT_MASK) >> MP1_PMI_1_READ_POINTER_CURRENT_SHIFT)

#define MP1_PMI_1_READ_POINTER_SET_CURRENT(mp1_pmi_1_read_pointer_reg, current) \
      mp1_pmi_1_read_pointer_reg = (mp1_pmi_1_read_pointer_reg & ~MP1_PMI_1_READ_POINTER_CURRENT_MASK) | (current << MP1_PMI_1_READ_POINTER_CURRENT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_1_read_pointer_t {
            unsigned int current                        : MP1_PMI_1_READ_POINTER_CURRENT_SIZE;
            unsigned int                                : 14;
      } mp1_pmi_1_read_pointer_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_1_read_pointer_t {
            unsigned int                                : 14;
            unsigned int current                        : MP1_PMI_1_READ_POINTER_CURRENT_SIZE;
      } mp1_pmi_1_read_pointer_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_1_read_pointer_t f;
} mp1_pmi_1_read_pointer_u;


/*
 * MP1_PMI_1_WRITE_POINTER struct
 */

#define MP1_PMI_1_WRITE_POINTER_REG_SIZE         32
#define MP1_PMI_1_WRITE_POINTER_CURRENT_SIZE  18

#define MP1_PMI_1_WRITE_POINTER_CURRENT_SHIFT  0

#define MP1_PMI_1_WRITE_POINTER_CURRENT_MASK  0x0003ffff

#define MP1_PMI_1_WRITE_POINTER_MASK \
      (MP1_PMI_1_WRITE_POINTER_CURRENT_MASK)

#define MP1_PMI_1_WRITE_POINTER_DEFAULT 0x00000000

#define MP1_PMI_1_WRITE_POINTER_GET_CURRENT(mp1_pmi_1_write_pointer) \
      ((mp1_pmi_1_write_pointer & MP1_PMI_1_WRITE_POINTER_CURRENT_MASK) >> MP1_PMI_1_WRITE_POINTER_CURRENT_SHIFT)

#define MP1_PMI_1_WRITE_POINTER_SET_CURRENT(mp1_pmi_1_write_pointer_reg, current) \
      mp1_pmi_1_write_pointer_reg = (mp1_pmi_1_write_pointer_reg & ~MP1_PMI_1_WRITE_POINTER_CURRENT_MASK) | (current << MP1_PMI_1_WRITE_POINTER_CURRENT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_1_write_pointer_t {
            unsigned int current                        : MP1_PMI_1_WRITE_POINTER_CURRENT_SIZE;
            unsigned int                                : 14;
      } mp1_pmi_1_write_pointer_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_1_write_pointer_t {
            unsigned int                                : 14;
            unsigned int current                        : MP1_PMI_1_WRITE_POINTER_CURRENT_SIZE;
      } mp1_pmi_1_write_pointer_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_1_write_pointer_t f;
} mp1_pmi_1_write_pointer_u;


/*
 * MP1_PMI_2_START struct
 */

#define MP1_PMI_2_START_REG_SIZE         32
#define MP1_PMI_2_START_ADDR_SIZE  18
#define MP1_PMI_2_START_ENABLE_SIZE  1

#define MP1_PMI_2_START_ADDR_SHIFT  0
#define MP1_PMI_2_START_ENABLE_SHIFT  31

#define MP1_PMI_2_START_ADDR_MASK       0x0003ffff
#define MP1_PMI_2_START_ENABLE_MASK     0x80000000

#define MP1_PMI_2_START_MASK \
      (MP1_PMI_2_START_ADDR_MASK | \
      MP1_PMI_2_START_ENABLE_MASK)

#define MP1_PMI_2_START_DEFAULT        0x00000000

#define MP1_PMI_2_START_GET_ADDR(mp1_pmi_2_start) \
      ((mp1_pmi_2_start & MP1_PMI_2_START_ADDR_MASK) >> MP1_PMI_2_START_ADDR_SHIFT)
#define MP1_PMI_2_START_GET_ENABLE(mp1_pmi_2_start) \
      ((mp1_pmi_2_start & MP1_PMI_2_START_ENABLE_MASK) >> MP1_PMI_2_START_ENABLE_SHIFT)

#define MP1_PMI_2_START_SET_ADDR(mp1_pmi_2_start_reg, addr) \
      mp1_pmi_2_start_reg = (mp1_pmi_2_start_reg & ~MP1_PMI_2_START_ADDR_MASK) | (addr << MP1_PMI_2_START_ADDR_SHIFT)
#define MP1_PMI_2_START_SET_ENABLE(mp1_pmi_2_start_reg, enable) \
      mp1_pmi_2_start_reg = (mp1_pmi_2_start_reg & ~MP1_PMI_2_START_ENABLE_MASK) | (enable << MP1_PMI_2_START_ENABLE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_2_start_t {
            unsigned int addr                           : MP1_PMI_2_START_ADDR_SIZE;
            unsigned int                                : 13;
            unsigned int enable                         : MP1_PMI_2_START_ENABLE_SIZE;
      } mp1_pmi_2_start_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_2_start_t {
            unsigned int enable                         : MP1_PMI_2_START_ENABLE_SIZE;
            unsigned int                                : 13;
            unsigned int addr                           : MP1_PMI_2_START_ADDR_SIZE;
      } mp1_pmi_2_start_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_2_start_t f;
} mp1_pmi_2_start_u;


/*
 * MP1_PMI_2_FIFO struct
 */

#define MP1_PMI_2_FIFO_REG_SIZE         32
#define MP1_PMI_2_FIFO_DEPTH_SIZE  4

#define MP1_PMI_2_FIFO_DEPTH_SHIFT  0

#define MP1_PMI_2_FIFO_DEPTH_MASK       0x0000000f

#define MP1_PMI_2_FIFO_MASK \
      (MP1_PMI_2_FIFO_DEPTH_MASK)

#define MP1_PMI_2_FIFO_DEFAULT         0x00000004

#define MP1_PMI_2_FIFO_GET_DEPTH(mp1_pmi_2_fifo) \
      ((mp1_pmi_2_fifo & MP1_PMI_2_FIFO_DEPTH_MASK) >> MP1_PMI_2_FIFO_DEPTH_SHIFT)

#define MP1_PMI_2_FIFO_SET_DEPTH(mp1_pmi_2_fifo_reg, depth) \
      mp1_pmi_2_fifo_reg = (mp1_pmi_2_fifo_reg & ~MP1_PMI_2_FIFO_DEPTH_MASK) | (depth << MP1_PMI_2_FIFO_DEPTH_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_2_fifo_t {
            unsigned int depth                          : MP1_PMI_2_FIFO_DEPTH_SIZE;
            unsigned int                                : 28;
      } mp1_pmi_2_fifo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_2_fifo_t {
            unsigned int                                : 28;
            unsigned int depth                          : MP1_PMI_2_FIFO_DEPTH_SIZE;
      } mp1_pmi_2_fifo_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_2_fifo_t f;
} mp1_pmi_2_fifo_u;


/*
 * MP1_PMI_2_STATUS struct
 */

#define MP1_PMI_2_STATUS_REG_SIZE         32
#define MP1_PMI_2_STATUS_FULL_SIZE  1
#define MP1_PMI_2_STATUS_EMPTY_SIZE  1

#define MP1_PMI_2_STATUS_FULL_SHIFT  0
#define MP1_PMI_2_STATUS_EMPTY_SHIFT  1

#define MP1_PMI_2_STATUS_FULL_MASK      0x00000001
#define MP1_PMI_2_STATUS_EMPTY_MASK     0x00000002

#define MP1_PMI_2_STATUS_MASK \
      (MP1_PMI_2_STATUS_FULL_MASK | \
      MP1_PMI_2_STATUS_EMPTY_MASK)

#define MP1_PMI_2_STATUS_DEFAULT       0x00000002

#define MP1_PMI_2_STATUS_GET_FULL(mp1_pmi_2_status) \
      ((mp1_pmi_2_status & MP1_PMI_2_STATUS_FULL_MASK) >> MP1_PMI_2_STATUS_FULL_SHIFT)
#define MP1_PMI_2_STATUS_GET_EMPTY(mp1_pmi_2_status) \
      ((mp1_pmi_2_status & MP1_PMI_2_STATUS_EMPTY_MASK) >> MP1_PMI_2_STATUS_EMPTY_SHIFT)

#define MP1_PMI_2_STATUS_SET_FULL(mp1_pmi_2_status_reg, full) \
      mp1_pmi_2_status_reg = (mp1_pmi_2_status_reg & ~MP1_PMI_2_STATUS_FULL_MASK) | (full << MP1_PMI_2_STATUS_FULL_SHIFT)
#define MP1_PMI_2_STATUS_SET_EMPTY(mp1_pmi_2_status_reg, empty) \
      mp1_pmi_2_status_reg = (mp1_pmi_2_status_reg & ~MP1_PMI_2_STATUS_EMPTY_MASK) | (empty << MP1_PMI_2_STATUS_EMPTY_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_2_status_t {
            unsigned int full                           : MP1_PMI_2_STATUS_FULL_SIZE;
            unsigned int empty                          : MP1_PMI_2_STATUS_EMPTY_SIZE;
            unsigned int                                : 30;
      } mp1_pmi_2_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_2_status_t {
            unsigned int                                : 30;
            unsigned int empty                          : MP1_PMI_2_STATUS_EMPTY_SIZE;
            unsigned int full                           : MP1_PMI_2_STATUS_FULL_SIZE;
      } mp1_pmi_2_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_2_status_t f;
} mp1_pmi_2_status_u;


/*
 * MP1_PMI_2_READ_POINTER struct
 */

#define MP1_PMI_2_READ_POINTER_REG_SIZE         32
#define MP1_PMI_2_READ_POINTER_CURRENT_SIZE  18

#define MP1_PMI_2_READ_POINTER_CURRENT_SHIFT  0

#define MP1_PMI_2_READ_POINTER_CURRENT_MASK  0x0003ffff

#define MP1_PMI_2_READ_POINTER_MASK \
      (MP1_PMI_2_READ_POINTER_CURRENT_MASK)

#define MP1_PMI_2_READ_POINTER_DEFAULT 0x00000000

#define MP1_PMI_2_READ_POINTER_GET_CURRENT(mp1_pmi_2_read_pointer) \
      ((mp1_pmi_2_read_pointer & MP1_PMI_2_READ_POINTER_CURRENT_MASK) >> MP1_PMI_2_READ_POINTER_CURRENT_SHIFT)

#define MP1_PMI_2_READ_POINTER_SET_CURRENT(mp1_pmi_2_read_pointer_reg, current) \
      mp1_pmi_2_read_pointer_reg = (mp1_pmi_2_read_pointer_reg & ~MP1_PMI_2_READ_POINTER_CURRENT_MASK) | (current << MP1_PMI_2_READ_POINTER_CURRENT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_2_read_pointer_t {
            unsigned int current                        : MP1_PMI_2_READ_POINTER_CURRENT_SIZE;
            unsigned int                                : 14;
      } mp1_pmi_2_read_pointer_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_2_read_pointer_t {
            unsigned int                                : 14;
            unsigned int current                        : MP1_PMI_2_READ_POINTER_CURRENT_SIZE;
      } mp1_pmi_2_read_pointer_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_2_read_pointer_t f;
} mp1_pmi_2_read_pointer_u;


/*
 * MP1_PMI_2_WRITE_POINTER struct
 */

#define MP1_PMI_2_WRITE_POINTER_REG_SIZE         32
#define MP1_PMI_2_WRITE_POINTER_CURRENT_SIZE  18

#define MP1_PMI_2_WRITE_POINTER_CURRENT_SHIFT  0

#define MP1_PMI_2_WRITE_POINTER_CURRENT_MASK  0x0003ffff

#define MP1_PMI_2_WRITE_POINTER_MASK \
      (MP1_PMI_2_WRITE_POINTER_CURRENT_MASK)

#define MP1_PMI_2_WRITE_POINTER_DEFAULT 0x00000000

#define MP1_PMI_2_WRITE_POINTER_GET_CURRENT(mp1_pmi_2_write_pointer) \
      ((mp1_pmi_2_write_pointer & MP1_PMI_2_WRITE_POINTER_CURRENT_MASK) >> MP1_PMI_2_WRITE_POINTER_CURRENT_SHIFT)

#define MP1_PMI_2_WRITE_POINTER_SET_CURRENT(mp1_pmi_2_write_pointer_reg, current) \
      mp1_pmi_2_write_pointer_reg = (mp1_pmi_2_write_pointer_reg & ~MP1_PMI_2_WRITE_POINTER_CURRENT_MASK) | (current << MP1_PMI_2_WRITE_POINTER_CURRENT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_2_write_pointer_t {
            unsigned int current                        : MP1_PMI_2_WRITE_POINTER_CURRENT_SIZE;
            unsigned int                                : 14;
      } mp1_pmi_2_write_pointer_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_2_write_pointer_t {
            unsigned int                                : 14;
            unsigned int current                        : MP1_PMI_2_WRITE_POINTER_CURRENT_SIZE;
      } mp1_pmi_2_write_pointer_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_2_write_pointer_t f;
} mp1_pmi_2_write_pointer_u;


/*
 * MP1_PMI_OUT_CONFIG struct
 */

#define MP1_PMI_OUT_CONFIG_REG_SIZE         32
#define MP1_PMI_OUT_CONFIG_PMI0_OUT_SEL_SIZE  2
#define MP1_PMI_OUT_CONFIG_PMI1_OUT_SEL_SIZE  2
#define MP1_PMI_OUT_CONFIG_PMI2_OUT_SEL_SIZE  2

#define MP1_PMI_OUT_CONFIG_PMI0_OUT_SEL_SHIFT  0
#define MP1_PMI_OUT_CONFIG_PMI1_OUT_SEL_SHIFT  2
#define MP1_PMI_OUT_CONFIG_PMI2_OUT_SEL_SHIFT  4

#define MP1_PMI_OUT_CONFIG_PMI0_OUT_SEL_MASK  0x00000003
#define MP1_PMI_OUT_CONFIG_PMI1_OUT_SEL_MASK  0x0000000c
#define MP1_PMI_OUT_CONFIG_PMI2_OUT_SEL_MASK  0x00000030

#define MP1_PMI_OUT_CONFIG_MASK \
      (MP1_PMI_OUT_CONFIG_PMI0_OUT_SEL_MASK | \
      MP1_PMI_OUT_CONFIG_PMI1_OUT_SEL_MASK | \
      MP1_PMI_OUT_CONFIG_PMI2_OUT_SEL_MASK)

#define MP1_PMI_OUT_CONFIG_DEFAULT     0x00000024

#define MP1_PMI_OUT_CONFIG_GET_PMI0_OUT_SEL(mp1_pmi_out_config) \
      ((mp1_pmi_out_config & MP1_PMI_OUT_CONFIG_PMI0_OUT_SEL_MASK) >> MP1_PMI_OUT_CONFIG_PMI0_OUT_SEL_SHIFT)
#define MP1_PMI_OUT_CONFIG_GET_PMI1_OUT_SEL(mp1_pmi_out_config) \
      ((mp1_pmi_out_config & MP1_PMI_OUT_CONFIG_PMI1_OUT_SEL_MASK) >> MP1_PMI_OUT_CONFIG_PMI1_OUT_SEL_SHIFT)
#define MP1_PMI_OUT_CONFIG_GET_PMI2_OUT_SEL(mp1_pmi_out_config) \
      ((mp1_pmi_out_config & MP1_PMI_OUT_CONFIG_PMI2_OUT_SEL_MASK) >> MP1_PMI_OUT_CONFIG_PMI2_OUT_SEL_SHIFT)

#define MP1_PMI_OUT_CONFIG_SET_PMI0_OUT_SEL(mp1_pmi_out_config_reg, pmi0_out_sel) \
      mp1_pmi_out_config_reg = (mp1_pmi_out_config_reg & ~MP1_PMI_OUT_CONFIG_PMI0_OUT_SEL_MASK) | (pmi0_out_sel << MP1_PMI_OUT_CONFIG_PMI0_OUT_SEL_SHIFT)
#define MP1_PMI_OUT_CONFIG_SET_PMI1_OUT_SEL(mp1_pmi_out_config_reg, pmi1_out_sel) \
      mp1_pmi_out_config_reg = (mp1_pmi_out_config_reg & ~MP1_PMI_OUT_CONFIG_PMI1_OUT_SEL_MASK) | (pmi1_out_sel << MP1_PMI_OUT_CONFIG_PMI1_OUT_SEL_SHIFT)
#define MP1_PMI_OUT_CONFIG_SET_PMI2_OUT_SEL(mp1_pmi_out_config_reg, pmi2_out_sel) \
      mp1_pmi_out_config_reg = (mp1_pmi_out_config_reg & ~MP1_PMI_OUT_CONFIG_PMI2_OUT_SEL_MASK) | (pmi2_out_sel << MP1_PMI_OUT_CONFIG_PMI2_OUT_SEL_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_out_config_t {
            unsigned int pmi0_out_sel                   : MP1_PMI_OUT_CONFIG_PMI0_OUT_SEL_SIZE;
            unsigned int pmi1_out_sel                   : MP1_PMI_OUT_CONFIG_PMI1_OUT_SEL_SIZE;
            unsigned int pmi2_out_sel                   : MP1_PMI_OUT_CONFIG_PMI2_OUT_SEL_SIZE;
            unsigned int                                : 26;
      } mp1_pmi_out_config_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_out_config_t {
            unsigned int                                : 26;
            unsigned int pmi2_out_sel                   : MP1_PMI_OUT_CONFIG_PMI2_OUT_SEL_SIZE;
            unsigned int pmi1_out_sel                   : MP1_PMI_OUT_CONFIG_PMI1_OUT_SEL_SIZE;
            unsigned int pmi0_out_sel                   : MP1_PMI_OUT_CONFIG_PMI0_OUT_SEL_SIZE;
      } mp1_pmi_out_config_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_out_config_t f;
} mp1_pmi_out_config_u;


/*
 * MP1_PMI_RELOAD struct
 */

#define MP1_PMI_RELOAD_REG_SIZE         32
#define MP1_PMI_RELOAD_PMI_PARAMETERS_SIZE  3

#define MP1_PMI_RELOAD_PMI_PARAMETERS_SHIFT  0

#define MP1_PMI_RELOAD_PMI_PARAMETERS_MASK  0x00000007

#define MP1_PMI_RELOAD_MASK \
      (MP1_PMI_RELOAD_PMI_PARAMETERS_MASK)

#define MP1_PMI_RELOAD_DEFAULT         0x00000000

#define MP1_PMI_RELOAD_GET_PMI_PARAMETERS(mp1_pmi_reload) \
      ((mp1_pmi_reload & MP1_PMI_RELOAD_PMI_PARAMETERS_MASK) >> MP1_PMI_RELOAD_PMI_PARAMETERS_SHIFT)

#define MP1_PMI_RELOAD_SET_PMI_PARAMETERS(mp1_pmi_reload_reg, pmi_parameters) \
      mp1_pmi_reload_reg = (mp1_pmi_reload_reg & ~MP1_PMI_RELOAD_PMI_PARAMETERS_MASK) | (pmi_parameters << MP1_PMI_RELOAD_PMI_PARAMETERS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_reload_t {
            unsigned int pmi_parameters                 : MP1_PMI_RELOAD_PMI_PARAMETERS_SIZE;
            unsigned int                                : 29;
      } mp1_pmi_reload_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_reload_t {
            unsigned int                                : 29;
            unsigned int pmi_parameters                 : MP1_PMI_RELOAD_PMI_PARAMETERS_SIZE;
      } mp1_pmi_reload_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_reload_t f;
} mp1_pmi_reload_u;


/*
 * MP1_PMI_INTERRUPT_CONTROL struct
 */

#define MP1_PMI_INTERRUPT_CONTROL_REG_SIZE         32
#define MP1_PMI_INTERRUPT_CONTROL_PMI_PENDING_SIZE  3
#define MP1_PMI_INTERRUPT_CONTROL_PMI_INTERRUPT_MASK_SIZE  3
#define MP1_PMI_INTERRUPT_CONTROL_PMI_FULL_PENDING_SIZE  3
#define MP1_PMI_INTERRUPT_CONTROL_PMI_FULLINTERRUPT_MASK_SIZE  3

#define MP1_PMI_INTERRUPT_CONTROL_PMI_PENDING_SHIFT  0
#define MP1_PMI_INTERRUPT_CONTROL_PMI_INTERRUPT_MASK_SHIFT  3
#define MP1_PMI_INTERRUPT_CONTROL_PMI_FULL_PENDING_SHIFT  6
#define MP1_PMI_INTERRUPT_CONTROL_PMI_FULLINTERRUPT_MASK_SHIFT  9

#define MP1_PMI_INTERRUPT_CONTROL_PMI_PENDING_MASK  0x00000007
#define MP1_PMI_INTERRUPT_CONTROL_PMI_INTERRUPT_MASK_MASK  0x00000038
#define MP1_PMI_INTERRUPT_CONTROL_PMI_FULL_PENDING_MASK  0x000001c0
#define MP1_PMI_INTERRUPT_CONTROL_PMI_FULLINTERRUPT_MASK_MASK  0x00000e00

#define MP1_PMI_INTERRUPT_CONTROL_MASK \
      (MP1_PMI_INTERRUPT_CONTROL_PMI_PENDING_MASK | \
      MP1_PMI_INTERRUPT_CONTROL_PMI_INTERRUPT_MASK_MASK | \
      MP1_PMI_INTERRUPT_CONTROL_PMI_FULL_PENDING_MASK | \
      MP1_PMI_INTERRUPT_CONTROL_PMI_FULLINTERRUPT_MASK_MASK)

#define MP1_PMI_INTERRUPT_CONTROL_DEFAULT 0x00000000

#define MP1_PMI_INTERRUPT_CONTROL_GET_PMI_PENDING(mp1_pmi_interrupt_control) \
      ((mp1_pmi_interrupt_control & MP1_PMI_INTERRUPT_CONTROL_PMI_PENDING_MASK) >> MP1_PMI_INTERRUPT_CONTROL_PMI_PENDING_SHIFT)
#define MP1_PMI_INTERRUPT_CONTROL_GET_PMI_INTERRUPT_MASK(mp1_pmi_interrupt_control) \
      ((mp1_pmi_interrupt_control & MP1_PMI_INTERRUPT_CONTROL_PMI_INTERRUPT_MASK_MASK) >> MP1_PMI_INTERRUPT_CONTROL_PMI_INTERRUPT_MASK_SHIFT)
#define MP1_PMI_INTERRUPT_CONTROL_GET_PMI_FULL_PENDING(mp1_pmi_interrupt_control) \
      ((mp1_pmi_interrupt_control & MP1_PMI_INTERRUPT_CONTROL_PMI_FULL_PENDING_MASK) >> MP1_PMI_INTERRUPT_CONTROL_PMI_FULL_PENDING_SHIFT)
#define MP1_PMI_INTERRUPT_CONTROL_GET_PMI_FULLINTERRUPT_MASK(mp1_pmi_interrupt_control) \
      ((mp1_pmi_interrupt_control & MP1_PMI_INTERRUPT_CONTROL_PMI_FULLINTERRUPT_MASK_MASK) >> MP1_PMI_INTERRUPT_CONTROL_PMI_FULLINTERRUPT_MASK_SHIFT)

#define MP1_PMI_INTERRUPT_CONTROL_SET_PMI_PENDING(mp1_pmi_interrupt_control_reg, pmi_pending) \
      mp1_pmi_interrupt_control_reg = (mp1_pmi_interrupt_control_reg & ~MP1_PMI_INTERRUPT_CONTROL_PMI_PENDING_MASK) | (pmi_pending << MP1_PMI_INTERRUPT_CONTROL_PMI_PENDING_SHIFT)
#define MP1_PMI_INTERRUPT_CONTROL_SET_PMI_INTERRUPT_MASK(mp1_pmi_interrupt_control_reg, pmi_interrupt_mask) \
      mp1_pmi_interrupt_control_reg = (mp1_pmi_interrupt_control_reg & ~MP1_PMI_INTERRUPT_CONTROL_PMI_INTERRUPT_MASK_MASK) | (pmi_interrupt_mask << MP1_PMI_INTERRUPT_CONTROL_PMI_INTERRUPT_MASK_SHIFT)
#define MP1_PMI_INTERRUPT_CONTROL_SET_PMI_FULL_PENDING(mp1_pmi_interrupt_control_reg, pmi_full_pending) \
      mp1_pmi_interrupt_control_reg = (mp1_pmi_interrupt_control_reg & ~MP1_PMI_INTERRUPT_CONTROL_PMI_FULL_PENDING_MASK) | (pmi_full_pending << MP1_PMI_INTERRUPT_CONTROL_PMI_FULL_PENDING_SHIFT)
#define MP1_PMI_INTERRUPT_CONTROL_SET_PMI_FULLINTERRUPT_MASK(mp1_pmi_interrupt_control_reg, pmi_fullinterrupt_mask) \
      mp1_pmi_interrupt_control_reg = (mp1_pmi_interrupt_control_reg & ~MP1_PMI_INTERRUPT_CONTROL_PMI_FULLINTERRUPT_MASK_MASK) | (pmi_fullinterrupt_mask << MP1_PMI_INTERRUPT_CONTROL_PMI_FULLINTERRUPT_MASK_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_interrupt_control_t {
            unsigned int pmi_pending                    : MP1_PMI_INTERRUPT_CONTROL_PMI_PENDING_SIZE;
            unsigned int pmi_interrupt_mask             : MP1_PMI_INTERRUPT_CONTROL_PMI_INTERRUPT_MASK_SIZE;
            unsigned int pmi_full_pending               : MP1_PMI_INTERRUPT_CONTROL_PMI_FULL_PENDING_SIZE;
            unsigned int pmi_fullinterrupt_mask         : MP1_PMI_INTERRUPT_CONTROL_PMI_FULLINTERRUPT_MASK_SIZE;
            unsigned int                                : 20;
      } mp1_pmi_interrupt_control_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_interrupt_control_t {
            unsigned int                                : 20;
            unsigned int pmi_fullinterrupt_mask         : MP1_PMI_INTERRUPT_CONTROL_PMI_FULLINTERRUPT_MASK_SIZE;
            unsigned int pmi_full_pending               : MP1_PMI_INTERRUPT_CONTROL_PMI_FULL_PENDING_SIZE;
            unsigned int pmi_interrupt_mask             : MP1_PMI_INTERRUPT_CONTROL_PMI_INTERRUPT_MASK_SIZE;
            unsigned int pmi_pending                    : MP1_PMI_INTERRUPT_CONTROL_PMI_PENDING_SIZE;
      } mp1_pmi_interrupt_control_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_interrupt_control_t f;
} mp1_pmi_interrupt_control_u;


/*
 * MP1_MMU_SRAM_ACC_VIOLATION_LOG_ADDR struct
 */

#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_REG_SIZE         32
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SIZE  32

#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SHIFT  0

#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK  0xffffffff

#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_MASK \
      (MP1_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK)

#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_DEFAULT 0x00000000

#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_GET_ADDRESS(mp1_mmu_sram_acc_violation_log_addr) \
      ((mp1_mmu_sram_acc_violation_log_addr & MP1_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK) >> MP1_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SHIFT)

#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_SET_ADDRESS(mp1_mmu_sram_acc_violation_log_addr_reg, address) \
      mp1_mmu_sram_acc_violation_log_addr_reg = (mp1_mmu_sram_acc_violation_log_addr_reg & ~MP1_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK) | (address << MP1_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmu_sram_acc_violation_log_addr_t {
            unsigned int address                        : MP1_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SIZE;
      } mp1_mmu_sram_acc_violation_log_addr_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmu_sram_acc_violation_log_addr_t {
            unsigned int address                        : MP1_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SIZE;
      } mp1_mmu_sram_acc_violation_log_addr_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmu_sram_acc_violation_log_addr_t f;
} mp1_mmu_sram_acc_violation_log_addr_u;


/*
 * MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS struct
 */

#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_REG_SIZE         32
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE  1
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SIZE  1
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SIZE  1
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE  2
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SIZE  2
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SIZE  7
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SIZE  10
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SIZE  1
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE  1

#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT  0
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SHIFT  1
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SHIFT  3
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT  4
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SHIFT  6
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SHIFT  8
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SHIFT  15
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SHIFT  30
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT  31

#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK  0x00000001
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_MASK  0x00000002
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_MASK  0x00000008
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK  0x00000030
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_MASK  0x000000c0
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_MASK  0x00007f00
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_MASK  0x01ff8000
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_MASK  0x40000000
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK  0x80000000

#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_MASK \
      (MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK | \
      MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_MASK | \
      MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_MASK | \
      MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK | \
      MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_MASK | \
      MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_MASK | \
      MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_MASK | \
      MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_MASK | \
      MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK)

#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_DEFAULT 0x00000000

#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_DETECTED(mp1_mmu_sram_acc_violation_log_status) \
      ((mp1_mmu_sram_acc_violation_log_status & MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) >> MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_UNSECURE_BAR(mp1_mmu_sram_acc_violation_log_status) \
      ((mp1_mmu_sram_acc_violation_log_status & MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_MASK) >> MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SHIFT)
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_OP(mp1_mmu_sram_acc_violation_log_status) \
      ((mp1_mmu_sram_acc_violation_log_status & MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_MASK) >> MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SHIFT)
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_TYPE(mp1_mmu_sram_acc_violation_log_status) \
      ((mp1_mmu_sram_acc_violation_log_status & MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) >> MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_PERMISSION(mp1_mmu_sram_acc_violation_log_status) \
      ((mp1_mmu_sram_acc_violation_log_status & MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_MASK) >> MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SHIFT)
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_AXI_UNIT_ID(mp1_mmu_sram_acc_violation_log_status) \
      ((mp1_mmu_sram_acc_violation_log_status & MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_MASK) >> MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SHIFT)
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_AXI_INIT_ID(mp1_mmu_sram_acc_violation_log_status) \
      ((mp1_mmu_sram_acc_violation_log_status & MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_MASK) >> MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SHIFT)
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_SRAM_NS0_VIOL_CLEAR(mp1_mmu_sram_acc_violation_log_status) \
      ((mp1_mmu_sram_acc_violation_log_status & MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_MASK) >> MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SHIFT)
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_LOG_CLEAR(mp1_mmu_sram_acc_violation_log_status) \
      ((mp1_mmu_sram_acc_violation_log_status & MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) >> MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)

#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_DETECTED(mp1_mmu_sram_acc_violation_log_status_reg, acc_violation_detected) \
      mp1_mmu_sram_acc_violation_log_status_reg = (mp1_mmu_sram_acc_violation_log_status_reg & ~MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) | (acc_violation_detected << MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_UNSECURE_BAR(mp1_mmu_sram_acc_violation_log_status_reg, acc_violation_unsecure_bar) \
      mp1_mmu_sram_acc_violation_log_status_reg = (mp1_mmu_sram_acc_violation_log_status_reg & ~MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_MASK) | (acc_violation_unsecure_bar << MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SHIFT)
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_OP(mp1_mmu_sram_acc_violation_log_status_reg, acc_violation_op) \
      mp1_mmu_sram_acc_violation_log_status_reg = (mp1_mmu_sram_acc_violation_log_status_reg & ~MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_MASK) | (acc_violation_op << MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SHIFT)
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_TYPE(mp1_mmu_sram_acc_violation_log_status_reg, acc_violation_type) \
      mp1_mmu_sram_acc_violation_log_status_reg = (mp1_mmu_sram_acc_violation_log_status_reg & ~MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) | (acc_violation_type << MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_PERMISSION(mp1_mmu_sram_acc_violation_log_status_reg, acc_violation_permission) \
      mp1_mmu_sram_acc_violation_log_status_reg = (mp1_mmu_sram_acc_violation_log_status_reg & ~MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_MASK) | (acc_violation_permission << MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SHIFT)
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_AXI_UNIT_ID(mp1_mmu_sram_acc_violation_log_status_reg, acc_violation_axi_unit_id) \
      mp1_mmu_sram_acc_violation_log_status_reg = (mp1_mmu_sram_acc_violation_log_status_reg & ~MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_MASK) | (acc_violation_axi_unit_id << MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SHIFT)
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_AXI_INIT_ID(mp1_mmu_sram_acc_violation_log_status_reg, acc_violation_axi_init_id) \
      mp1_mmu_sram_acc_violation_log_status_reg = (mp1_mmu_sram_acc_violation_log_status_reg & ~MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_MASK) | (acc_violation_axi_init_id << MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SHIFT)
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_SRAM_NS0_VIOL_CLEAR(mp1_mmu_sram_acc_violation_log_status_reg, sram_ns0_viol_clear) \
      mp1_mmu_sram_acc_violation_log_status_reg = (mp1_mmu_sram_acc_violation_log_status_reg & ~MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_MASK) | (sram_ns0_viol_clear << MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SHIFT)
#define MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_LOG_CLEAR(mp1_mmu_sram_acc_violation_log_status_reg, acc_violation_log_clear) \
      mp1_mmu_sram_acc_violation_log_status_reg = (mp1_mmu_sram_acc_violation_log_status_reg & ~MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) | (acc_violation_log_clear << MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmu_sram_acc_violation_log_status_t {
            unsigned int acc_violation_detected         : MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
            unsigned int acc_violation_unsecure_bar     : MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SIZE;
            unsigned int                                : 1;
            unsigned int acc_violation_op               : MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SIZE;
            unsigned int acc_violation_type             : MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
            unsigned int acc_violation_permission       : MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SIZE;
            unsigned int acc_violation_axi_unit_id      : MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SIZE;
            unsigned int acc_violation_axi_init_id      : MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SIZE;
            unsigned int                                : 5;
            unsigned int sram_ns0_viol_clear            : MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SIZE;
            unsigned int acc_violation_log_clear        : MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
      } mp1_mmu_sram_acc_violation_log_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmu_sram_acc_violation_log_status_t {
            unsigned int acc_violation_log_clear        : MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
            unsigned int sram_ns0_viol_clear            : MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SIZE;
            unsigned int                                : 5;
            unsigned int acc_violation_axi_init_id      : MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SIZE;
            unsigned int acc_violation_axi_unit_id      : MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SIZE;
            unsigned int acc_violation_permission       : MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SIZE;
            unsigned int acc_violation_type             : MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
            unsigned int acc_violation_op               : MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SIZE;
            unsigned int                                : 1;
            unsigned int acc_violation_unsecure_bar     : MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SIZE;
            unsigned int acc_violation_detected         : MP1_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
      } mp1_mmu_sram_acc_violation_log_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmu_sram_acc_violation_log_status_t f;
} mp1_mmu_sram_acc_violation_log_status_u;


/*
 * MP1_MMU_MISC_CNTL struct
 */

#define MP1_MMU_MISC_CNTL_REG_SIZE         32
#define MP1_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SIZE  1
#define MP1_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SIZE  1
#define MP1_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SIZE  1
#define MP1_MMU_MISC_CNTL_CLK_GATE_EN_SIZE  1
#define MP1_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SIZE  1
#define MP1_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SIZE  4
#define MP1_MMU_MISC_CNTL_REGCLK_STATUS_SIZE  1
#define MP1_MMU_MISC_CNTL_SYSCLK_STATUS_SIZE  1

#define MP1_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SHIFT  0
#define MP1_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SHIFT  2
#define MP1_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SHIFT  3
#define MP1_MMU_MISC_CNTL_CLK_GATE_EN_SHIFT  16
#define MP1_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SHIFT  17
#define MP1_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SHIFT  18
#define MP1_MMU_MISC_CNTL_REGCLK_STATUS_SHIFT  22
#define MP1_MMU_MISC_CNTL_SYSCLK_STATUS_SHIFT  23

#define MP1_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_MASK  0x00000001
#define MP1_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_MASK  0x00000004
#define MP1_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_MASK  0x00000008
#define MP1_MMU_MISC_CNTL_CLK_GATE_EN_MASK  0x00010000
#define MP1_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_MASK  0x00020000
#define MP1_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_MASK  0x003c0000
#define MP1_MMU_MISC_CNTL_REGCLK_STATUS_MASK  0x00400000
#define MP1_MMU_MISC_CNTL_SYSCLK_STATUS_MASK  0x00800000

#define MP1_MMU_MISC_CNTL_MASK \
      (MP1_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_MASK | \
      MP1_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_MASK | \
      MP1_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_MASK | \
      MP1_MMU_MISC_CNTL_CLK_GATE_EN_MASK | \
      MP1_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_MASK | \
      MP1_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_MASK | \
      MP1_MMU_MISC_CNTL_REGCLK_STATUS_MASK | \
      MP1_MMU_MISC_CNTL_SYSCLK_STATUS_MASK)

#define MP1_MMU_MISC_CNTL_DEFAULT      0x00e00001

#define MP1_MMU_MISC_CNTL_GET_ALLOW_UNPRIVILIGED_REG_ACC(mp1_mmu_misc_cntl) \
      ((mp1_mmu_misc_cntl & MP1_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_MASK) >> MP1_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SHIFT)
#define MP1_MMU_MISC_CNTL_GET_ENABLE_MEM_CHECKS_PSRAM(mp1_mmu_misc_cntl) \
      ((mp1_mmu_misc_cntl & MP1_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_MASK) >> MP1_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SHIFT)
#define MP1_MMU_MISC_CNTL_GET_ENABLE_MEM_CHECKS_CPU(mp1_mmu_misc_cntl) \
      ((mp1_mmu_misc_cntl & MP1_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_MASK) >> MP1_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SHIFT)
#define MP1_MMU_MISC_CNTL_GET_CLK_GATE_EN(mp1_mmu_misc_cntl) \
      ((mp1_mmu_misc_cntl & MP1_MMU_MISC_CNTL_CLK_GATE_EN_MASK) >> MP1_MMU_MISC_CNTL_CLK_GATE_EN_SHIFT)
#define MP1_MMU_MISC_CNTL_GET_CLK_GATE_OVERRIDE(mp1_mmu_misc_cntl) \
      ((mp1_mmu_misc_cntl & MP1_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_MASK) >> MP1_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SHIFT)
#define MP1_MMU_MISC_CNTL_GET_CLK_GATE_TIMEOUT(mp1_mmu_misc_cntl) \
      ((mp1_mmu_misc_cntl & MP1_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_MASK) >> MP1_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SHIFT)
#define MP1_MMU_MISC_CNTL_GET_REGCLK_STATUS(mp1_mmu_misc_cntl) \
      ((mp1_mmu_misc_cntl & MP1_MMU_MISC_CNTL_REGCLK_STATUS_MASK) >> MP1_MMU_MISC_CNTL_REGCLK_STATUS_SHIFT)
#define MP1_MMU_MISC_CNTL_GET_SYSCLK_STATUS(mp1_mmu_misc_cntl) \
      ((mp1_mmu_misc_cntl & MP1_MMU_MISC_CNTL_SYSCLK_STATUS_MASK) >> MP1_MMU_MISC_CNTL_SYSCLK_STATUS_SHIFT)

#define MP1_MMU_MISC_CNTL_SET_ALLOW_UNPRIVILIGED_REG_ACC(mp1_mmu_misc_cntl_reg, allow_unpriviliged_reg_acc) \
      mp1_mmu_misc_cntl_reg = (mp1_mmu_misc_cntl_reg & ~MP1_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_MASK) | (allow_unpriviliged_reg_acc << MP1_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SHIFT)
#define MP1_MMU_MISC_CNTL_SET_ENABLE_MEM_CHECKS_PSRAM(mp1_mmu_misc_cntl_reg, enable_mem_checks_psram) \
      mp1_mmu_misc_cntl_reg = (mp1_mmu_misc_cntl_reg & ~MP1_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_MASK) | (enable_mem_checks_psram << MP1_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SHIFT)
#define MP1_MMU_MISC_CNTL_SET_ENABLE_MEM_CHECKS_CPU(mp1_mmu_misc_cntl_reg, enable_mem_checks_cpu) \
      mp1_mmu_misc_cntl_reg = (mp1_mmu_misc_cntl_reg & ~MP1_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_MASK) | (enable_mem_checks_cpu << MP1_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SHIFT)
#define MP1_MMU_MISC_CNTL_SET_CLK_GATE_EN(mp1_mmu_misc_cntl_reg, clk_gate_en) \
      mp1_mmu_misc_cntl_reg = (mp1_mmu_misc_cntl_reg & ~MP1_MMU_MISC_CNTL_CLK_GATE_EN_MASK) | (clk_gate_en << MP1_MMU_MISC_CNTL_CLK_GATE_EN_SHIFT)
#define MP1_MMU_MISC_CNTL_SET_CLK_GATE_OVERRIDE(mp1_mmu_misc_cntl_reg, clk_gate_override) \
      mp1_mmu_misc_cntl_reg = (mp1_mmu_misc_cntl_reg & ~MP1_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_MASK) | (clk_gate_override << MP1_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SHIFT)
#define MP1_MMU_MISC_CNTL_SET_CLK_GATE_TIMEOUT(mp1_mmu_misc_cntl_reg, clk_gate_timeout) \
      mp1_mmu_misc_cntl_reg = (mp1_mmu_misc_cntl_reg & ~MP1_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_MASK) | (clk_gate_timeout << MP1_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SHIFT)
#define MP1_MMU_MISC_CNTL_SET_REGCLK_STATUS(mp1_mmu_misc_cntl_reg, regclk_status) \
      mp1_mmu_misc_cntl_reg = (mp1_mmu_misc_cntl_reg & ~MP1_MMU_MISC_CNTL_REGCLK_STATUS_MASK) | (regclk_status << MP1_MMU_MISC_CNTL_REGCLK_STATUS_SHIFT)
#define MP1_MMU_MISC_CNTL_SET_SYSCLK_STATUS(mp1_mmu_misc_cntl_reg, sysclk_status) \
      mp1_mmu_misc_cntl_reg = (mp1_mmu_misc_cntl_reg & ~MP1_MMU_MISC_CNTL_SYSCLK_STATUS_MASK) | (sysclk_status << MP1_MMU_MISC_CNTL_SYSCLK_STATUS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmu_misc_cntl_t {
            unsigned int allow_unpriviliged_reg_acc     : MP1_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SIZE;
            unsigned int                                : 1;
            unsigned int enable_mem_checks_psram        : MP1_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SIZE;
            unsigned int enable_mem_checks_cpu          : MP1_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SIZE;
            unsigned int                                : 12;
            unsigned int clk_gate_en                    : MP1_MMU_MISC_CNTL_CLK_GATE_EN_SIZE;
            unsigned int clk_gate_override              : MP1_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SIZE;
            unsigned int clk_gate_timeout               : MP1_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SIZE;
            unsigned int regclk_status                  : MP1_MMU_MISC_CNTL_REGCLK_STATUS_SIZE;
            unsigned int sysclk_status                  : MP1_MMU_MISC_CNTL_SYSCLK_STATUS_SIZE;
            unsigned int                                : 8;
      } mp1_mmu_misc_cntl_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmu_misc_cntl_t {
            unsigned int                                : 8;
            unsigned int sysclk_status                  : MP1_MMU_MISC_CNTL_SYSCLK_STATUS_SIZE;
            unsigned int regclk_status                  : MP1_MMU_MISC_CNTL_REGCLK_STATUS_SIZE;
            unsigned int clk_gate_timeout               : MP1_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SIZE;
            unsigned int clk_gate_override              : MP1_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SIZE;
            unsigned int clk_gate_en                    : MP1_MMU_MISC_CNTL_CLK_GATE_EN_SIZE;
            unsigned int                                : 12;
            unsigned int enable_mem_checks_cpu          : MP1_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SIZE;
            unsigned int enable_mem_checks_psram        : MP1_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SIZE;
            unsigned int                                : 1;
            unsigned int allow_unpriviliged_reg_acc     : MP1_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SIZE;
      } mp1_mmu_misc_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmu_misc_cntl_t f;
} mp1_mmu_misc_cntl_u;


/*
 * MP1_MMU_ACCESS_ERR_LOG struct
 */

#define MP1_MMU_ACCESS_ERR_LOG_REG_SIZE         32
#define MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SIZE  1
#define MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SIZE  2
#define MP1_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SIZE  1
#define MP1_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SIZE  1
#define MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SIZE  7
#define MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SIZE  10
#define MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SIZE  3

#define MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SHIFT  0
#define MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SHIFT  1
#define MP1_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SHIFT  3
#define MP1_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SHIFT  4
#define MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SHIFT  8
#define MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SHIFT  15
#define MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SHIFT  25

#define MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_MASK  0x00000001
#define MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_MASK  0x00000006
#define MP1_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_MASK  0x00000008
#define MP1_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_MASK  0x00000010
#define MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_MASK  0x00007f00
#define MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_MASK  0x01ff8000
#define MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_MASK  0x0e000000

#define MP1_MMU_ACCESS_ERR_LOG_MASK \
      (MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_MASK | \
      MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_MASK | \
      MP1_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_MASK | \
      MP1_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_MASK | \
      MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_MASK | \
      MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_MASK | \
      MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_MASK)

#define MP1_MMU_ACCESS_ERR_LOG_DEFAULT 0x00000000

#define MP1_MMU_ACCESS_ERR_LOG_GET_AXI_ACC_VIOLATION_DETECTED(mp1_mmu_access_err_log) \
      ((mp1_mmu_access_err_log & MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_MASK) >> MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SHIFT)
#define MP1_MMU_ACCESS_ERR_LOG_GET_AXI_ACC_VIOLATION_BLOCK(mp1_mmu_access_err_log) \
      ((mp1_mmu_access_err_log & MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_MASK) >> MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SHIFT)
#define MP1_MMU_ACCESS_ERR_LOG_GET_ACC_VIOLATION_LOG_CLEAR(mp1_mmu_access_err_log) \
      ((mp1_mmu_access_err_log & MP1_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_MASK) >> MP1_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SHIFT)
#define MP1_MMU_ACCESS_ERR_LOG_GET_CFG_NS0_VIOL_CLEAR(mp1_mmu_access_err_log) \
      ((mp1_mmu_access_err_log & MP1_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_MASK) >> MP1_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SHIFT)
#define MP1_MMU_ACCESS_ERR_LOG_GET_AXI_ACC_VIOLATION_AXI_UNIT_ID(mp1_mmu_access_err_log) \
      ((mp1_mmu_access_err_log & MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_MASK) >> MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SHIFT)
#define MP1_MMU_ACCESS_ERR_LOG_GET_AXI_ACC_VIOLATION_AXI_INIT_ID(mp1_mmu_access_err_log) \
      ((mp1_mmu_access_err_log & MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_MASK) >> MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SHIFT)
#define MP1_MMU_ACCESS_ERR_LOG_GET_AXI_ACC_VIOLATION_AXI_PROT(mp1_mmu_access_err_log) \
      ((mp1_mmu_access_err_log & MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_MASK) >> MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SHIFT)

#define MP1_MMU_ACCESS_ERR_LOG_SET_AXI_ACC_VIOLATION_DETECTED(mp1_mmu_access_err_log_reg, axi_acc_violation_detected) \
      mp1_mmu_access_err_log_reg = (mp1_mmu_access_err_log_reg & ~MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_MASK) | (axi_acc_violation_detected << MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SHIFT)
#define MP1_MMU_ACCESS_ERR_LOG_SET_AXI_ACC_VIOLATION_BLOCK(mp1_mmu_access_err_log_reg, axi_acc_violation_block) \
      mp1_mmu_access_err_log_reg = (mp1_mmu_access_err_log_reg & ~MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_MASK) | (axi_acc_violation_block << MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SHIFT)
#define MP1_MMU_ACCESS_ERR_LOG_SET_ACC_VIOLATION_LOG_CLEAR(mp1_mmu_access_err_log_reg, acc_violation_log_clear) \
      mp1_mmu_access_err_log_reg = (mp1_mmu_access_err_log_reg & ~MP1_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_MASK) | (acc_violation_log_clear << MP1_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SHIFT)
#define MP1_MMU_ACCESS_ERR_LOG_SET_CFG_NS0_VIOL_CLEAR(mp1_mmu_access_err_log_reg, cfg_ns0_viol_clear) \
      mp1_mmu_access_err_log_reg = (mp1_mmu_access_err_log_reg & ~MP1_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_MASK) | (cfg_ns0_viol_clear << MP1_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SHIFT)
#define MP1_MMU_ACCESS_ERR_LOG_SET_AXI_ACC_VIOLATION_AXI_UNIT_ID(mp1_mmu_access_err_log_reg, axi_acc_violation_axi_unit_id) \
      mp1_mmu_access_err_log_reg = (mp1_mmu_access_err_log_reg & ~MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_MASK) | (axi_acc_violation_axi_unit_id << MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SHIFT)
#define MP1_MMU_ACCESS_ERR_LOG_SET_AXI_ACC_VIOLATION_AXI_INIT_ID(mp1_mmu_access_err_log_reg, axi_acc_violation_axi_init_id) \
      mp1_mmu_access_err_log_reg = (mp1_mmu_access_err_log_reg & ~MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_MASK) | (axi_acc_violation_axi_init_id << MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SHIFT)
#define MP1_MMU_ACCESS_ERR_LOG_SET_AXI_ACC_VIOLATION_AXI_PROT(mp1_mmu_access_err_log_reg, axi_acc_violation_axi_prot) \
      mp1_mmu_access_err_log_reg = (mp1_mmu_access_err_log_reg & ~MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_MASK) | (axi_acc_violation_axi_prot << MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmu_access_err_log_t {
            unsigned int axi_acc_violation_detected     : MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SIZE;
            unsigned int axi_acc_violation_block        : MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SIZE;
            unsigned int acc_violation_log_clear        : MP1_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SIZE;
            unsigned int cfg_ns0_viol_clear             : MP1_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SIZE;
            unsigned int                                : 3;
            unsigned int axi_acc_violation_axi_unit_id  : MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SIZE;
            unsigned int axi_acc_violation_axi_init_id  : MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SIZE;
            unsigned int axi_acc_violation_axi_prot     : MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SIZE;
            unsigned int                                : 4;
      } mp1_mmu_access_err_log_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmu_access_err_log_t {
            unsigned int                                : 4;
            unsigned int axi_acc_violation_axi_prot     : MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SIZE;
            unsigned int axi_acc_violation_axi_init_id  : MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SIZE;
            unsigned int axi_acc_violation_axi_unit_id  : MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SIZE;
            unsigned int                                : 3;
            unsigned int cfg_ns0_viol_clear             : MP1_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SIZE;
            unsigned int acc_violation_log_clear        : MP1_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SIZE;
            unsigned int axi_acc_violation_block        : MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SIZE;
            unsigned int axi_acc_violation_detected     : MP1_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SIZE;
      } mp1_mmu_access_err_log_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmu_access_err_log_t f;
} mp1_mmu_access_err_log_u;


/*
 * MP1_MMU_SRAM_UNSECURE_BAR struct
 */

#define MP1_MMU_SRAM_UNSECURE_BAR_REG_SIZE         32
#define MP1_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SIZE  32

#define MP1_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SHIFT  0

#define MP1_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_MASK  0xffffffff

#define MP1_MMU_SRAM_UNSECURE_BAR_MASK \
      (MP1_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_MASK)

#define MP1_MMU_SRAM_UNSECURE_BAR_DEFAULT 0x00044000

#define MP1_MMU_SRAM_UNSECURE_BAR_GET_SRAM_UNSECURE_BAR(mp1_mmu_sram_unsecure_bar) \
      ((mp1_mmu_sram_unsecure_bar & MP1_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_MASK) >> MP1_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SHIFT)

#define MP1_MMU_SRAM_UNSECURE_BAR_SET_SRAM_UNSECURE_BAR(mp1_mmu_sram_unsecure_bar_reg, sram_unsecure_bar) \
      mp1_mmu_sram_unsecure_bar_reg = (mp1_mmu_sram_unsecure_bar_reg & ~MP1_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_MASK) | (sram_unsecure_bar << MP1_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmu_sram_unsecure_bar_t {
            unsigned int sram_unsecure_bar              : MP1_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SIZE;
      } mp1_mmu_sram_unsecure_bar_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmu_sram_unsecure_bar_t {
            unsigned int sram_unsecure_bar              : MP1_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SIZE;
      } mp1_mmu_sram_unsecure_bar_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmu_sram_unsecure_bar_t f;
} mp1_mmu_sram_unsecure_bar_u;


/*
 * MP1_MMU_SCRATCH_0 struct
 */

#define MP1_MMU_SCRATCH_0_REG_SIZE         32
#define MP1_MMU_SCRATCH_0_RESERVED_SIZE  32

#define MP1_MMU_SCRATCH_0_RESERVED_SHIFT  0

#define MP1_MMU_SCRATCH_0_RESERVED_MASK  0xffffffff

#define MP1_MMU_SCRATCH_0_MASK \
      (MP1_MMU_SCRATCH_0_RESERVED_MASK)

#define MP1_MMU_SCRATCH_0_DEFAULT      0x00000000

#define MP1_MMU_SCRATCH_0_GET_RESERVED(mp1_mmu_scratch_0) \
      ((mp1_mmu_scratch_0 & MP1_MMU_SCRATCH_0_RESERVED_MASK) >> MP1_MMU_SCRATCH_0_RESERVED_SHIFT)

#define MP1_MMU_SCRATCH_0_SET_RESERVED(mp1_mmu_scratch_0_reg, reserved) \
      mp1_mmu_scratch_0_reg = (mp1_mmu_scratch_0_reg & ~MP1_MMU_SCRATCH_0_RESERVED_MASK) | (reserved << MP1_MMU_SCRATCH_0_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmu_scratch_0_t {
            unsigned int reserved                       : MP1_MMU_SCRATCH_0_RESERVED_SIZE;
      } mp1_mmu_scratch_0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmu_scratch_0_t {
            unsigned int reserved                       : MP1_MMU_SCRATCH_0_RESERVED_SIZE;
      } mp1_mmu_scratch_0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmu_scratch_0_t f;
} mp1_mmu_scratch_0_u;


/*
 * MP1_MMU_SCRATCH_1 struct
 */

#define MP1_MMU_SCRATCH_1_REG_SIZE         32
#define MP1_MMU_SCRATCH_1_RESERVED_SIZE  32

#define MP1_MMU_SCRATCH_1_RESERVED_SHIFT  0

#define MP1_MMU_SCRATCH_1_RESERVED_MASK  0xffffffff

#define MP1_MMU_SCRATCH_1_MASK \
      (MP1_MMU_SCRATCH_1_RESERVED_MASK)

#define MP1_MMU_SCRATCH_1_DEFAULT      0x00000000

#define MP1_MMU_SCRATCH_1_GET_RESERVED(mp1_mmu_scratch_1) \
      ((mp1_mmu_scratch_1 & MP1_MMU_SCRATCH_1_RESERVED_MASK) >> MP1_MMU_SCRATCH_1_RESERVED_SHIFT)

#define MP1_MMU_SCRATCH_1_SET_RESERVED(mp1_mmu_scratch_1_reg, reserved) \
      mp1_mmu_scratch_1_reg = (mp1_mmu_scratch_1_reg & ~MP1_MMU_SCRATCH_1_RESERVED_MASK) | (reserved << MP1_MMU_SCRATCH_1_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmu_scratch_1_t {
            unsigned int reserved                       : MP1_MMU_SCRATCH_1_RESERVED_SIZE;
      } mp1_mmu_scratch_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmu_scratch_1_t {
            unsigned int reserved                       : MP1_MMU_SCRATCH_1_RESERVED_SIZE;
      } mp1_mmu_scratch_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmu_scratch_1_t f;
} mp1_mmu_scratch_1_u;


/*
 * MP1_MMU_SCRATCH_2 struct
 */

#define MP1_MMU_SCRATCH_2_REG_SIZE         32
#define MP1_MMU_SCRATCH_2_RESERVED_SIZE  32

#define MP1_MMU_SCRATCH_2_RESERVED_SHIFT  0

#define MP1_MMU_SCRATCH_2_RESERVED_MASK  0xffffffff

#define MP1_MMU_SCRATCH_2_MASK \
      (MP1_MMU_SCRATCH_2_RESERVED_MASK)

#define MP1_MMU_SCRATCH_2_DEFAULT      0x00000000

#define MP1_MMU_SCRATCH_2_GET_RESERVED(mp1_mmu_scratch_2) \
      ((mp1_mmu_scratch_2 & MP1_MMU_SCRATCH_2_RESERVED_MASK) >> MP1_MMU_SCRATCH_2_RESERVED_SHIFT)

#define MP1_MMU_SCRATCH_2_SET_RESERVED(mp1_mmu_scratch_2_reg, reserved) \
      mp1_mmu_scratch_2_reg = (mp1_mmu_scratch_2_reg & ~MP1_MMU_SCRATCH_2_RESERVED_MASK) | (reserved << MP1_MMU_SCRATCH_2_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmu_scratch_2_t {
            unsigned int reserved                       : MP1_MMU_SCRATCH_2_RESERVED_SIZE;
      } mp1_mmu_scratch_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmu_scratch_2_t {
            unsigned int reserved                       : MP1_MMU_SCRATCH_2_RESERVED_SIZE;
      } mp1_mmu_scratch_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmu_scratch_2_t f;
} mp1_mmu_scratch_2_u;


/*
 * MP1_MMU_SCRATCH_3 struct
 */

#define MP1_MMU_SCRATCH_3_REG_SIZE         32
#define MP1_MMU_SCRATCH_3_RESERVED_SIZE  32

#define MP1_MMU_SCRATCH_3_RESERVED_SHIFT  0

#define MP1_MMU_SCRATCH_3_RESERVED_MASK  0xffffffff

#define MP1_MMU_SCRATCH_3_MASK \
      (MP1_MMU_SCRATCH_3_RESERVED_MASK)

#define MP1_MMU_SCRATCH_3_DEFAULT      0x00000000

#define MP1_MMU_SCRATCH_3_GET_RESERVED(mp1_mmu_scratch_3) \
      ((mp1_mmu_scratch_3 & MP1_MMU_SCRATCH_3_RESERVED_MASK) >> MP1_MMU_SCRATCH_3_RESERVED_SHIFT)

#define MP1_MMU_SCRATCH_3_SET_RESERVED(mp1_mmu_scratch_3_reg, reserved) \
      mp1_mmu_scratch_3_reg = (mp1_mmu_scratch_3_reg & ~MP1_MMU_SCRATCH_3_RESERVED_MASK) | (reserved << MP1_MMU_SCRATCH_3_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmu_scratch_3_t {
            unsigned int reserved                       : MP1_MMU_SCRATCH_3_RESERVED_SIZE;
      } mp1_mmu_scratch_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmu_scratch_3_t {
            unsigned int reserved                       : MP1_MMU_SCRATCH_3_RESERVED_SIZE;
      } mp1_mmu_scratch_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmu_scratch_3_t f;
} mp1_mmu_scratch_3_u;


/*
 * MP1_MMU_SCRATCH_4 struct
 */

#define MP1_MMU_SCRATCH_4_REG_SIZE         32
#define MP1_MMU_SCRATCH_4_RESERVED_SIZE  32

#define MP1_MMU_SCRATCH_4_RESERVED_SHIFT  0

#define MP1_MMU_SCRATCH_4_RESERVED_MASK  0xffffffff

#define MP1_MMU_SCRATCH_4_MASK \
      (MP1_MMU_SCRATCH_4_RESERVED_MASK)

#define MP1_MMU_SCRATCH_4_DEFAULT      0x00000000

#define MP1_MMU_SCRATCH_4_GET_RESERVED(mp1_mmu_scratch_4) \
      ((mp1_mmu_scratch_4 & MP1_MMU_SCRATCH_4_RESERVED_MASK) >> MP1_MMU_SCRATCH_4_RESERVED_SHIFT)

#define MP1_MMU_SCRATCH_4_SET_RESERVED(mp1_mmu_scratch_4_reg, reserved) \
      mp1_mmu_scratch_4_reg = (mp1_mmu_scratch_4_reg & ~MP1_MMU_SCRATCH_4_RESERVED_MASK) | (reserved << MP1_MMU_SCRATCH_4_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmu_scratch_4_t {
            unsigned int reserved                       : MP1_MMU_SCRATCH_4_RESERVED_SIZE;
      } mp1_mmu_scratch_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmu_scratch_4_t {
            unsigned int reserved                       : MP1_MMU_SCRATCH_4_RESERVED_SIZE;
      } mp1_mmu_scratch_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmu_scratch_4_t f;
} mp1_mmu_scratch_4_u;


/*
 * MP1_MMU_SCRATCH_5 struct
 */

#define MP1_MMU_SCRATCH_5_REG_SIZE         32
#define MP1_MMU_SCRATCH_5_RESERVED_SIZE  32

#define MP1_MMU_SCRATCH_5_RESERVED_SHIFT  0

#define MP1_MMU_SCRATCH_5_RESERVED_MASK  0xffffffff

#define MP1_MMU_SCRATCH_5_MASK \
      (MP1_MMU_SCRATCH_5_RESERVED_MASK)

#define MP1_MMU_SCRATCH_5_DEFAULT      0x00000000

#define MP1_MMU_SCRATCH_5_GET_RESERVED(mp1_mmu_scratch_5) \
      ((mp1_mmu_scratch_5 & MP1_MMU_SCRATCH_5_RESERVED_MASK) >> MP1_MMU_SCRATCH_5_RESERVED_SHIFT)

#define MP1_MMU_SCRATCH_5_SET_RESERVED(mp1_mmu_scratch_5_reg, reserved) \
      mp1_mmu_scratch_5_reg = (mp1_mmu_scratch_5_reg & ~MP1_MMU_SCRATCH_5_RESERVED_MASK) | (reserved << MP1_MMU_SCRATCH_5_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmu_scratch_5_t {
            unsigned int reserved                       : MP1_MMU_SCRATCH_5_RESERVED_SIZE;
      } mp1_mmu_scratch_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmu_scratch_5_t {
            unsigned int reserved                       : MP1_MMU_SCRATCH_5_RESERVED_SIZE;
      } mp1_mmu_scratch_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmu_scratch_5_t f;
} mp1_mmu_scratch_5_u;


/*
 * MP1_MMU_SCRATCH_6 struct
 */

#define MP1_MMU_SCRATCH_6_REG_SIZE         32
#define MP1_MMU_SCRATCH_6_RESERVED_SIZE  32

#define MP1_MMU_SCRATCH_6_RESERVED_SHIFT  0

#define MP1_MMU_SCRATCH_6_RESERVED_MASK  0xffffffff

#define MP1_MMU_SCRATCH_6_MASK \
      (MP1_MMU_SCRATCH_6_RESERVED_MASK)

#define MP1_MMU_SCRATCH_6_DEFAULT      0x00000000

#define MP1_MMU_SCRATCH_6_GET_RESERVED(mp1_mmu_scratch_6) \
      ((mp1_mmu_scratch_6 & MP1_MMU_SCRATCH_6_RESERVED_MASK) >> MP1_MMU_SCRATCH_6_RESERVED_SHIFT)

#define MP1_MMU_SCRATCH_6_SET_RESERVED(mp1_mmu_scratch_6_reg, reserved) \
      mp1_mmu_scratch_6_reg = (mp1_mmu_scratch_6_reg & ~MP1_MMU_SCRATCH_6_RESERVED_MASK) | (reserved << MP1_MMU_SCRATCH_6_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmu_scratch_6_t {
            unsigned int reserved                       : MP1_MMU_SCRATCH_6_RESERVED_SIZE;
      } mp1_mmu_scratch_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmu_scratch_6_t {
            unsigned int reserved                       : MP1_MMU_SCRATCH_6_RESERVED_SIZE;
      } mp1_mmu_scratch_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmu_scratch_6_t f;
} mp1_mmu_scratch_6_u;


/*
 * MP1_MMU_SCRATCH_7 struct
 */

#define MP1_MMU_SCRATCH_7_REG_SIZE         32
#define MP1_MMU_SCRATCH_7_RESERVED_SIZE  32

#define MP1_MMU_SCRATCH_7_RESERVED_SHIFT  0

#define MP1_MMU_SCRATCH_7_RESERVED_MASK  0xffffffff

#define MP1_MMU_SCRATCH_7_MASK \
      (MP1_MMU_SCRATCH_7_RESERVED_MASK)

#define MP1_MMU_SCRATCH_7_DEFAULT      0x00000000

#define MP1_MMU_SCRATCH_7_GET_RESERVED(mp1_mmu_scratch_7) \
      ((mp1_mmu_scratch_7 & MP1_MMU_SCRATCH_7_RESERVED_MASK) >> MP1_MMU_SCRATCH_7_RESERVED_SHIFT)

#define MP1_MMU_SCRATCH_7_SET_RESERVED(mp1_mmu_scratch_7_reg, reserved) \
      mp1_mmu_scratch_7_reg = (mp1_mmu_scratch_7_reg & ~MP1_MMU_SCRATCH_7_RESERVED_MASK) | (reserved << MP1_MMU_SCRATCH_7_RESERVED_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_mmu_scratch_7_t {
            unsigned int reserved                       : MP1_MMU_SCRATCH_7_RESERVED_SIZE;
      } mp1_mmu_scratch_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_mmu_scratch_7_t {
            unsigned int reserved                       : MP1_MMU_SCRATCH_7_RESERVED_SIZE;
      } mp1_mmu_scratch_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_mmu_scratch_7_t f;
} mp1_mmu_scratch_7_u;


/*
 * MP1_PMI_INITID_CONFIG struct
 */

#define MP1_PMI_INITID_CONFIG_REG_SIZE         32
#define MP1_PMI_INITID_CONFIG_DISABLE_PMI_SIZE  1
#define MP1_PMI_INITID_CONFIG_ENABLE_ALL_SIZE  1

#define MP1_PMI_INITID_CONFIG_DISABLE_PMI_SHIFT  0
#define MP1_PMI_INITID_CONFIG_ENABLE_ALL_SHIFT  1

#define MP1_PMI_INITID_CONFIG_DISABLE_PMI_MASK  0x00000001
#define MP1_PMI_INITID_CONFIG_ENABLE_ALL_MASK  0x00000002

#define MP1_PMI_INITID_CONFIG_MASK \
      (MP1_PMI_INITID_CONFIG_DISABLE_PMI_MASK | \
      MP1_PMI_INITID_CONFIG_ENABLE_ALL_MASK)

#define MP1_PMI_INITID_CONFIG_DEFAULT  0x00000002

#define MP1_PMI_INITID_CONFIG_GET_DISABLE_PMI(mp1_pmi_initid_config) \
      ((mp1_pmi_initid_config & MP1_PMI_INITID_CONFIG_DISABLE_PMI_MASK) >> MP1_PMI_INITID_CONFIG_DISABLE_PMI_SHIFT)
#define MP1_PMI_INITID_CONFIG_GET_ENABLE_ALL(mp1_pmi_initid_config) \
      ((mp1_pmi_initid_config & MP1_PMI_INITID_CONFIG_ENABLE_ALL_MASK) >> MP1_PMI_INITID_CONFIG_ENABLE_ALL_SHIFT)

#define MP1_PMI_INITID_CONFIG_SET_DISABLE_PMI(mp1_pmi_initid_config_reg, disable_pmi) \
      mp1_pmi_initid_config_reg = (mp1_pmi_initid_config_reg & ~MP1_PMI_INITID_CONFIG_DISABLE_PMI_MASK) | (disable_pmi << MP1_PMI_INITID_CONFIG_DISABLE_PMI_SHIFT)
#define MP1_PMI_INITID_CONFIG_SET_ENABLE_ALL(mp1_pmi_initid_config_reg, enable_all) \
      mp1_pmi_initid_config_reg = (mp1_pmi_initid_config_reg & ~MP1_PMI_INITID_CONFIG_ENABLE_ALL_MASK) | (enable_all << MP1_PMI_INITID_CONFIG_ENABLE_ALL_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_initid_config_t {
            unsigned int disable_pmi                    : MP1_PMI_INITID_CONFIG_DISABLE_PMI_SIZE;
            unsigned int enable_all                     : MP1_PMI_INITID_CONFIG_ENABLE_ALL_SIZE;
            unsigned int                                : 30;
      } mp1_pmi_initid_config_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_initid_config_t {
            unsigned int                                : 30;
            unsigned int enable_all                     : MP1_PMI_INITID_CONFIG_ENABLE_ALL_SIZE;
            unsigned int disable_pmi                    : MP1_PMI_INITID_CONFIG_DISABLE_PMI_SIZE;
      } mp1_pmi_initid_config_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_initid_config_t f;
} mp1_pmi_initid_config_u;


/*
 * MP1_PMI_INITID_0 struct
 */

#define MP1_PMI_INITID_0_REG_SIZE         32
#define MP1_PMI_INITID_0_INITID_SIZE  10
#define MP1_PMI_INITID_0_VALID_SIZE  1

#define MP1_PMI_INITID_0_INITID_SHIFT  0
#define MP1_PMI_INITID_0_VALID_SHIFT  16

#define MP1_PMI_INITID_0_INITID_MASK    0x000003ff
#define MP1_PMI_INITID_0_VALID_MASK     0x00010000

#define MP1_PMI_INITID_0_MASK \
      (MP1_PMI_INITID_0_INITID_MASK | \
      MP1_PMI_INITID_0_VALID_MASK)

#define MP1_PMI_INITID_0_DEFAULT       0x00000000

#define MP1_PMI_INITID_0_GET_INITID(mp1_pmi_initid_0) \
      ((mp1_pmi_initid_0 & MP1_PMI_INITID_0_INITID_MASK) >> MP1_PMI_INITID_0_INITID_SHIFT)
#define MP1_PMI_INITID_0_GET_VALID(mp1_pmi_initid_0) \
      ((mp1_pmi_initid_0 & MP1_PMI_INITID_0_VALID_MASK) >> MP1_PMI_INITID_0_VALID_SHIFT)

#define MP1_PMI_INITID_0_SET_INITID(mp1_pmi_initid_0_reg, initid) \
      mp1_pmi_initid_0_reg = (mp1_pmi_initid_0_reg & ~MP1_PMI_INITID_0_INITID_MASK) | (initid << MP1_PMI_INITID_0_INITID_SHIFT)
#define MP1_PMI_INITID_0_SET_VALID(mp1_pmi_initid_0_reg, valid) \
      mp1_pmi_initid_0_reg = (mp1_pmi_initid_0_reg & ~MP1_PMI_INITID_0_VALID_MASK) | (valid << MP1_PMI_INITID_0_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_initid_0_t {
            unsigned int initid                         : MP1_PMI_INITID_0_INITID_SIZE;
            unsigned int                                : 6;
            unsigned int valid                          : MP1_PMI_INITID_0_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_pmi_initid_0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_initid_0_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_PMI_INITID_0_VALID_SIZE;
            unsigned int                                : 6;
            unsigned int initid                         : MP1_PMI_INITID_0_INITID_SIZE;
      } mp1_pmi_initid_0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_initid_0_t f;
} mp1_pmi_initid_0_u;


/*
 * MP1_PMI_INITID_1 struct
 */

#define MP1_PMI_INITID_1_REG_SIZE         32
#define MP1_PMI_INITID_1_INITID_SIZE  10
#define MP1_PMI_INITID_1_VALID_SIZE  1

#define MP1_PMI_INITID_1_INITID_SHIFT  0
#define MP1_PMI_INITID_1_VALID_SHIFT  16

#define MP1_PMI_INITID_1_INITID_MASK    0x000003ff
#define MP1_PMI_INITID_1_VALID_MASK     0x00010000

#define MP1_PMI_INITID_1_MASK \
      (MP1_PMI_INITID_1_INITID_MASK | \
      MP1_PMI_INITID_1_VALID_MASK)

#define MP1_PMI_INITID_1_DEFAULT       0x00000000

#define MP1_PMI_INITID_1_GET_INITID(mp1_pmi_initid_1) \
      ((mp1_pmi_initid_1 & MP1_PMI_INITID_1_INITID_MASK) >> MP1_PMI_INITID_1_INITID_SHIFT)
#define MP1_PMI_INITID_1_GET_VALID(mp1_pmi_initid_1) \
      ((mp1_pmi_initid_1 & MP1_PMI_INITID_1_VALID_MASK) >> MP1_PMI_INITID_1_VALID_SHIFT)

#define MP1_PMI_INITID_1_SET_INITID(mp1_pmi_initid_1_reg, initid) \
      mp1_pmi_initid_1_reg = (mp1_pmi_initid_1_reg & ~MP1_PMI_INITID_1_INITID_MASK) | (initid << MP1_PMI_INITID_1_INITID_SHIFT)
#define MP1_PMI_INITID_1_SET_VALID(mp1_pmi_initid_1_reg, valid) \
      mp1_pmi_initid_1_reg = (mp1_pmi_initid_1_reg & ~MP1_PMI_INITID_1_VALID_MASK) | (valid << MP1_PMI_INITID_1_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_initid_1_t {
            unsigned int initid                         : MP1_PMI_INITID_1_INITID_SIZE;
            unsigned int                                : 6;
            unsigned int valid                          : MP1_PMI_INITID_1_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_pmi_initid_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_initid_1_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_PMI_INITID_1_VALID_SIZE;
            unsigned int                                : 6;
            unsigned int initid                         : MP1_PMI_INITID_1_INITID_SIZE;
      } mp1_pmi_initid_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_initid_1_t f;
} mp1_pmi_initid_1_u;


/*
 * MP1_PMI_INITID_2 struct
 */

#define MP1_PMI_INITID_2_REG_SIZE         32
#define MP1_PMI_INITID_2_INITID_SIZE  10
#define MP1_PMI_INITID_2_VALID_SIZE  1

#define MP1_PMI_INITID_2_INITID_SHIFT  0
#define MP1_PMI_INITID_2_VALID_SHIFT  16

#define MP1_PMI_INITID_2_INITID_MASK    0x000003ff
#define MP1_PMI_INITID_2_VALID_MASK     0x00010000

#define MP1_PMI_INITID_2_MASK \
      (MP1_PMI_INITID_2_INITID_MASK | \
      MP1_PMI_INITID_2_VALID_MASK)

#define MP1_PMI_INITID_2_DEFAULT       0x00000000

#define MP1_PMI_INITID_2_GET_INITID(mp1_pmi_initid_2) \
      ((mp1_pmi_initid_2 & MP1_PMI_INITID_2_INITID_MASK) >> MP1_PMI_INITID_2_INITID_SHIFT)
#define MP1_PMI_INITID_2_GET_VALID(mp1_pmi_initid_2) \
      ((mp1_pmi_initid_2 & MP1_PMI_INITID_2_VALID_MASK) >> MP1_PMI_INITID_2_VALID_SHIFT)

#define MP1_PMI_INITID_2_SET_INITID(mp1_pmi_initid_2_reg, initid) \
      mp1_pmi_initid_2_reg = (mp1_pmi_initid_2_reg & ~MP1_PMI_INITID_2_INITID_MASK) | (initid << MP1_PMI_INITID_2_INITID_SHIFT)
#define MP1_PMI_INITID_2_SET_VALID(mp1_pmi_initid_2_reg, valid) \
      mp1_pmi_initid_2_reg = (mp1_pmi_initid_2_reg & ~MP1_PMI_INITID_2_VALID_MASK) | (valid << MP1_PMI_INITID_2_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_initid_2_t {
            unsigned int initid                         : MP1_PMI_INITID_2_INITID_SIZE;
            unsigned int                                : 6;
            unsigned int valid                          : MP1_PMI_INITID_2_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_pmi_initid_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_initid_2_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_PMI_INITID_2_VALID_SIZE;
            unsigned int                                : 6;
            unsigned int initid                         : MP1_PMI_INITID_2_INITID_SIZE;
      } mp1_pmi_initid_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_initid_2_t f;
} mp1_pmi_initid_2_u;


/*
 * MP1_PMI_INITID_3 struct
 */

#define MP1_PMI_INITID_3_REG_SIZE         32
#define MP1_PMI_INITID_3_INITID_SIZE  10
#define MP1_PMI_INITID_3_VALID_SIZE  1

#define MP1_PMI_INITID_3_INITID_SHIFT  0
#define MP1_PMI_INITID_3_VALID_SHIFT  16

#define MP1_PMI_INITID_3_INITID_MASK    0x000003ff
#define MP1_PMI_INITID_3_VALID_MASK     0x00010000

#define MP1_PMI_INITID_3_MASK \
      (MP1_PMI_INITID_3_INITID_MASK | \
      MP1_PMI_INITID_3_VALID_MASK)

#define MP1_PMI_INITID_3_DEFAULT       0x00000000

#define MP1_PMI_INITID_3_GET_INITID(mp1_pmi_initid_3) \
      ((mp1_pmi_initid_3 & MP1_PMI_INITID_3_INITID_MASK) >> MP1_PMI_INITID_3_INITID_SHIFT)
#define MP1_PMI_INITID_3_GET_VALID(mp1_pmi_initid_3) \
      ((mp1_pmi_initid_3 & MP1_PMI_INITID_3_VALID_MASK) >> MP1_PMI_INITID_3_VALID_SHIFT)

#define MP1_PMI_INITID_3_SET_INITID(mp1_pmi_initid_3_reg, initid) \
      mp1_pmi_initid_3_reg = (mp1_pmi_initid_3_reg & ~MP1_PMI_INITID_3_INITID_MASK) | (initid << MP1_PMI_INITID_3_INITID_SHIFT)
#define MP1_PMI_INITID_3_SET_VALID(mp1_pmi_initid_3_reg, valid) \
      mp1_pmi_initid_3_reg = (mp1_pmi_initid_3_reg & ~MP1_PMI_INITID_3_VALID_MASK) | (valid << MP1_PMI_INITID_3_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_initid_3_t {
            unsigned int initid                         : MP1_PMI_INITID_3_INITID_SIZE;
            unsigned int                                : 6;
            unsigned int valid                          : MP1_PMI_INITID_3_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_pmi_initid_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_initid_3_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_PMI_INITID_3_VALID_SIZE;
            unsigned int                                : 6;
            unsigned int initid                         : MP1_PMI_INITID_3_INITID_SIZE;
      } mp1_pmi_initid_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_initid_3_t f;
} mp1_pmi_initid_3_u;


/*
 * MP1_PMI_INITID_4 struct
 */

#define MP1_PMI_INITID_4_REG_SIZE         32
#define MP1_PMI_INITID_4_INITID_SIZE  10
#define MP1_PMI_INITID_4_VALID_SIZE  1

#define MP1_PMI_INITID_4_INITID_SHIFT  0
#define MP1_PMI_INITID_4_VALID_SHIFT  16

#define MP1_PMI_INITID_4_INITID_MASK    0x000003ff
#define MP1_PMI_INITID_4_VALID_MASK     0x00010000

#define MP1_PMI_INITID_4_MASK \
      (MP1_PMI_INITID_4_INITID_MASK | \
      MP1_PMI_INITID_4_VALID_MASK)

#define MP1_PMI_INITID_4_DEFAULT       0x00000000

#define MP1_PMI_INITID_4_GET_INITID(mp1_pmi_initid_4) \
      ((mp1_pmi_initid_4 & MP1_PMI_INITID_4_INITID_MASK) >> MP1_PMI_INITID_4_INITID_SHIFT)
#define MP1_PMI_INITID_4_GET_VALID(mp1_pmi_initid_4) \
      ((mp1_pmi_initid_4 & MP1_PMI_INITID_4_VALID_MASK) >> MP1_PMI_INITID_4_VALID_SHIFT)

#define MP1_PMI_INITID_4_SET_INITID(mp1_pmi_initid_4_reg, initid) \
      mp1_pmi_initid_4_reg = (mp1_pmi_initid_4_reg & ~MP1_PMI_INITID_4_INITID_MASK) | (initid << MP1_PMI_INITID_4_INITID_SHIFT)
#define MP1_PMI_INITID_4_SET_VALID(mp1_pmi_initid_4_reg, valid) \
      mp1_pmi_initid_4_reg = (mp1_pmi_initid_4_reg & ~MP1_PMI_INITID_4_VALID_MASK) | (valid << MP1_PMI_INITID_4_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_initid_4_t {
            unsigned int initid                         : MP1_PMI_INITID_4_INITID_SIZE;
            unsigned int                                : 6;
            unsigned int valid                          : MP1_PMI_INITID_4_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_pmi_initid_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_initid_4_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_PMI_INITID_4_VALID_SIZE;
            unsigned int                                : 6;
            unsigned int initid                         : MP1_PMI_INITID_4_INITID_SIZE;
      } mp1_pmi_initid_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_initid_4_t f;
} mp1_pmi_initid_4_u;


/*
 * MP1_PMI_INITID_5 struct
 */

#define MP1_PMI_INITID_5_REG_SIZE         32
#define MP1_PMI_INITID_5_INITID_SIZE  10
#define MP1_PMI_INITID_5_VALID_SIZE  1

#define MP1_PMI_INITID_5_INITID_SHIFT  0
#define MP1_PMI_INITID_5_VALID_SHIFT  16

#define MP1_PMI_INITID_5_INITID_MASK    0x000003ff
#define MP1_PMI_INITID_5_VALID_MASK     0x00010000

#define MP1_PMI_INITID_5_MASK \
      (MP1_PMI_INITID_5_INITID_MASK | \
      MP1_PMI_INITID_5_VALID_MASK)

#define MP1_PMI_INITID_5_DEFAULT       0x00000000

#define MP1_PMI_INITID_5_GET_INITID(mp1_pmi_initid_5) \
      ((mp1_pmi_initid_5 & MP1_PMI_INITID_5_INITID_MASK) >> MP1_PMI_INITID_5_INITID_SHIFT)
#define MP1_PMI_INITID_5_GET_VALID(mp1_pmi_initid_5) \
      ((mp1_pmi_initid_5 & MP1_PMI_INITID_5_VALID_MASK) >> MP1_PMI_INITID_5_VALID_SHIFT)

#define MP1_PMI_INITID_5_SET_INITID(mp1_pmi_initid_5_reg, initid) \
      mp1_pmi_initid_5_reg = (mp1_pmi_initid_5_reg & ~MP1_PMI_INITID_5_INITID_MASK) | (initid << MP1_PMI_INITID_5_INITID_SHIFT)
#define MP1_PMI_INITID_5_SET_VALID(mp1_pmi_initid_5_reg, valid) \
      mp1_pmi_initid_5_reg = (mp1_pmi_initid_5_reg & ~MP1_PMI_INITID_5_VALID_MASK) | (valid << MP1_PMI_INITID_5_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_initid_5_t {
            unsigned int initid                         : MP1_PMI_INITID_5_INITID_SIZE;
            unsigned int                                : 6;
            unsigned int valid                          : MP1_PMI_INITID_5_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_pmi_initid_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_initid_5_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_PMI_INITID_5_VALID_SIZE;
            unsigned int                                : 6;
            unsigned int initid                         : MP1_PMI_INITID_5_INITID_SIZE;
      } mp1_pmi_initid_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_initid_5_t f;
} mp1_pmi_initid_5_u;


/*
 * MP1_PMI_INITID_6 struct
 */

#define MP1_PMI_INITID_6_REG_SIZE         32
#define MP1_PMI_INITID_6_INITID_SIZE  10
#define MP1_PMI_INITID_6_VALID_SIZE  1

#define MP1_PMI_INITID_6_INITID_SHIFT  0
#define MP1_PMI_INITID_6_VALID_SHIFT  16

#define MP1_PMI_INITID_6_INITID_MASK    0x000003ff
#define MP1_PMI_INITID_6_VALID_MASK     0x00010000

#define MP1_PMI_INITID_6_MASK \
      (MP1_PMI_INITID_6_INITID_MASK | \
      MP1_PMI_INITID_6_VALID_MASK)

#define MP1_PMI_INITID_6_DEFAULT       0x00000000

#define MP1_PMI_INITID_6_GET_INITID(mp1_pmi_initid_6) \
      ((mp1_pmi_initid_6 & MP1_PMI_INITID_6_INITID_MASK) >> MP1_PMI_INITID_6_INITID_SHIFT)
#define MP1_PMI_INITID_6_GET_VALID(mp1_pmi_initid_6) \
      ((mp1_pmi_initid_6 & MP1_PMI_INITID_6_VALID_MASK) >> MP1_PMI_INITID_6_VALID_SHIFT)

#define MP1_PMI_INITID_6_SET_INITID(mp1_pmi_initid_6_reg, initid) \
      mp1_pmi_initid_6_reg = (mp1_pmi_initid_6_reg & ~MP1_PMI_INITID_6_INITID_MASK) | (initid << MP1_PMI_INITID_6_INITID_SHIFT)
#define MP1_PMI_INITID_6_SET_VALID(mp1_pmi_initid_6_reg, valid) \
      mp1_pmi_initid_6_reg = (mp1_pmi_initid_6_reg & ~MP1_PMI_INITID_6_VALID_MASK) | (valid << MP1_PMI_INITID_6_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_initid_6_t {
            unsigned int initid                         : MP1_PMI_INITID_6_INITID_SIZE;
            unsigned int                                : 6;
            unsigned int valid                          : MP1_PMI_INITID_6_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_pmi_initid_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_initid_6_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_PMI_INITID_6_VALID_SIZE;
            unsigned int                                : 6;
            unsigned int initid                         : MP1_PMI_INITID_6_INITID_SIZE;
      } mp1_pmi_initid_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_initid_6_t f;
} mp1_pmi_initid_6_u;


/*
 * MP1_PMI_INITID_7 struct
 */

#define MP1_PMI_INITID_7_REG_SIZE         32
#define MP1_PMI_INITID_7_INITID_SIZE  10
#define MP1_PMI_INITID_7_VALID_SIZE  1

#define MP1_PMI_INITID_7_INITID_SHIFT  0
#define MP1_PMI_INITID_7_VALID_SHIFT  16

#define MP1_PMI_INITID_7_INITID_MASK    0x000003ff
#define MP1_PMI_INITID_7_VALID_MASK     0x00010000

#define MP1_PMI_INITID_7_MASK \
      (MP1_PMI_INITID_7_INITID_MASK | \
      MP1_PMI_INITID_7_VALID_MASK)

#define MP1_PMI_INITID_7_DEFAULT       0x00000000

#define MP1_PMI_INITID_7_GET_INITID(mp1_pmi_initid_7) \
      ((mp1_pmi_initid_7 & MP1_PMI_INITID_7_INITID_MASK) >> MP1_PMI_INITID_7_INITID_SHIFT)
#define MP1_PMI_INITID_7_GET_VALID(mp1_pmi_initid_7) \
      ((mp1_pmi_initid_7 & MP1_PMI_INITID_7_VALID_MASK) >> MP1_PMI_INITID_7_VALID_SHIFT)

#define MP1_PMI_INITID_7_SET_INITID(mp1_pmi_initid_7_reg, initid) \
      mp1_pmi_initid_7_reg = (mp1_pmi_initid_7_reg & ~MP1_PMI_INITID_7_INITID_MASK) | (initid << MP1_PMI_INITID_7_INITID_SHIFT)
#define MP1_PMI_INITID_7_SET_VALID(mp1_pmi_initid_7_reg, valid) \
      mp1_pmi_initid_7_reg = (mp1_pmi_initid_7_reg & ~MP1_PMI_INITID_7_VALID_MASK) | (valid << MP1_PMI_INITID_7_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_initid_7_t {
            unsigned int initid                         : MP1_PMI_INITID_7_INITID_SIZE;
            unsigned int                                : 6;
            unsigned int valid                          : MP1_PMI_INITID_7_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_pmi_initid_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_initid_7_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_PMI_INITID_7_VALID_SIZE;
            unsigned int                                : 6;
            unsigned int initid                         : MP1_PMI_INITID_7_INITID_SIZE;
      } mp1_pmi_initid_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_initid_7_t f;
} mp1_pmi_initid_7_u;


/*
 * MP1_PMI_INITID_8 struct
 */

#define MP1_PMI_INITID_8_REG_SIZE         32
#define MP1_PMI_INITID_8_INITID_SIZE  10
#define MP1_PMI_INITID_8_VALID_SIZE  1

#define MP1_PMI_INITID_8_INITID_SHIFT  0
#define MP1_PMI_INITID_8_VALID_SHIFT  16

#define MP1_PMI_INITID_8_INITID_MASK    0x000003ff
#define MP1_PMI_INITID_8_VALID_MASK     0x00010000

#define MP1_PMI_INITID_8_MASK \
      (MP1_PMI_INITID_8_INITID_MASK | \
      MP1_PMI_INITID_8_VALID_MASK)

#define MP1_PMI_INITID_8_DEFAULT       0x00000000

#define MP1_PMI_INITID_8_GET_INITID(mp1_pmi_initid_8) \
      ((mp1_pmi_initid_8 & MP1_PMI_INITID_8_INITID_MASK) >> MP1_PMI_INITID_8_INITID_SHIFT)
#define MP1_PMI_INITID_8_GET_VALID(mp1_pmi_initid_8) \
      ((mp1_pmi_initid_8 & MP1_PMI_INITID_8_VALID_MASK) >> MP1_PMI_INITID_8_VALID_SHIFT)

#define MP1_PMI_INITID_8_SET_INITID(mp1_pmi_initid_8_reg, initid) \
      mp1_pmi_initid_8_reg = (mp1_pmi_initid_8_reg & ~MP1_PMI_INITID_8_INITID_MASK) | (initid << MP1_PMI_INITID_8_INITID_SHIFT)
#define MP1_PMI_INITID_8_SET_VALID(mp1_pmi_initid_8_reg, valid) \
      mp1_pmi_initid_8_reg = (mp1_pmi_initid_8_reg & ~MP1_PMI_INITID_8_VALID_MASK) | (valid << MP1_PMI_INITID_8_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_initid_8_t {
            unsigned int initid                         : MP1_PMI_INITID_8_INITID_SIZE;
            unsigned int                                : 6;
            unsigned int valid                          : MP1_PMI_INITID_8_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_pmi_initid_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_initid_8_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_PMI_INITID_8_VALID_SIZE;
            unsigned int                                : 6;
            unsigned int initid                         : MP1_PMI_INITID_8_INITID_SIZE;
      } mp1_pmi_initid_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_initid_8_t f;
} mp1_pmi_initid_8_u;


/*
 * MP1_PMI_INITID_9 struct
 */

#define MP1_PMI_INITID_9_REG_SIZE         32
#define MP1_PMI_INITID_9_INITID_SIZE  10
#define MP1_PMI_INITID_9_VALID_SIZE  1

#define MP1_PMI_INITID_9_INITID_SHIFT  0
#define MP1_PMI_INITID_9_VALID_SHIFT  16

#define MP1_PMI_INITID_9_INITID_MASK    0x000003ff
#define MP1_PMI_INITID_9_VALID_MASK     0x00010000

#define MP1_PMI_INITID_9_MASK \
      (MP1_PMI_INITID_9_INITID_MASK | \
      MP1_PMI_INITID_9_VALID_MASK)

#define MP1_PMI_INITID_9_DEFAULT       0x00000000

#define MP1_PMI_INITID_9_GET_INITID(mp1_pmi_initid_9) \
      ((mp1_pmi_initid_9 & MP1_PMI_INITID_9_INITID_MASK) >> MP1_PMI_INITID_9_INITID_SHIFT)
#define MP1_PMI_INITID_9_GET_VALID(mp1_pmi_initid_9) \
      ((mp1_pmi_initid_9 & MP1_PMI_INITID_9_VALID_MASK) >> MP1_PMI_INITID_9_VALID_SHIFT)

#define MP1_PMI_INITID_9_SET_INITID(mp1_pmi_initid_9_reg, initid) \
      mp1_pmi_initid_9_reg = (mp1_pmi_initid_9_reg & ~MP1_PMI_INITID_9_INITID_MASK) | (initid << MP1_PMI_INITID_9_INITID_SHIFT)
#define MP1_PMI_INITID_9_SET_VALID(mp1_pmi_initid_9_reg, valid) \
      mp1_pmi_initid_9_reg = (mp1_pmi_initid_9_reg & ~MP1_PMI_INITID_9_VALID_MASK) | (valid << MP1_PMI_INITID_9_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_initid_9_t {
            unsigned int initid                         : MP1_PMI_INITID_9_INITID_SIZE;
            unsigned int                                : 6;
            unsigned int valid                          : MP1_PMI_INITID_9_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_pmi_initid_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_initid_9_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_PMI_INITID_9_VALID_SIZE;
            unsigned int                                : 6;
            unsigned int initid                         : MP1_PMI_INITID_9_INITID_SIZE;
      } mp1_pmi_initid_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_initid_9_t f;
} mp1_pmi_initid_9_u;


/*
 * MP1_PMI_INITID_10 struct
 */

#define MP1_PMI_INITID_10_REG_SIZE         32
#define MP1_PMI_INITID_10_INITID_SIZE  10
#define MP1_PMI_INITID_10_VALID_SIZE  1

#define MP1_PMI_INITID_10_INITID_SHIFT  0
#define MP1_PMI_INITID_10_VALID_SHIFT  16

#define MP1_PMI_INITID_10_INITID_MASK   0x000003ff
#define MP1_PMI_INITID_10_VALID_MASK    0x00010000

#define MP1_PMI_INITID_10_MASK \
      (MP1_PMI_INITID_10_INITID_MASK | \
      MP1_PMI_INITID_10_VALID_MASK)

#define MP1_PMI_INITID_10_DEFAULT      0x00000000

#define MP1_PMI_INITID_10_GET_INITID(mp1_pmi_initid_10) \
      ((mp1_pmi_initid_10 & MP1_PMI_INITID_10_INITID_MASK) >> MP1_PMI_INITID_10_INITID_SHIFT)
#define MP1_PMI_INITID_10_GET_VALID(mp1_pmi_initid_10) \
      ((mp1_pmi_initid_10 & MP1_PMI_INITID_10_VALID_MASK) >> MP1_PMI_INITID_10_VALID_SHIFT)

#define MP1_PMI_INITID_10_SET_INITID(mp1_pmi_initid_10_reg, initid) \
      mp1_pmi_initid_10_reg = (mp1_pmi_initid_10_reg & ~MP1_PMI_INITID_10_INITID_MASK) | (initid << MP1_PMI_INITID_10_INITID_SHIFT)
#define MP1_PMI_INITID_10_SET_VALID(mp1_pmi_initid_10_reg, valid) \
      mp1_pmi_initid_10_reg = (mp1_pmi_initid_10_reg & ~MP1_PMI_INITID_10_VALID_MASK) | (valid << MP1_PMI_INITID_10_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_initid_10_t {
            unsigned int initid                         : MP1_PMI_INITID_10_INITID_SIZE;
            unsigned int                                : 6;
            unsigned int valid                          : MP1_PMI_INITID_10_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_pmi_initid_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_initid_10_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_PMI_INITID_10_VALID_SIZE;
            unsigned int                                : 6;
            unsigned int initid                         : MP1_PMI_INITID_10_INITID_SIZE;
      } mp1_pmi_initid_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_initid_10_t f;
} mp1_pmi_initid_10_u;


/*
 * MP1_PMI_INITID_11 struct
 */

#define MP1_PMI_INITID_11_REG_SIZE         32
#define MP1_PMI_INITID_11_INITID_SIZE  10
#define MP1_PMI_INITID_11_VALID_SIZE  1

#define MP1_PMI_INITID_11_INITID_SHIFT  0
#define MP1_PMI_INITID_11_VALID_SHIFT  16

#define MP1_PMI_INITID_11_INITID_MASK   0x000003ff
#define MP1_PMI_INITID_11_VALID_MASK    0x00010000

#define MP1_PMI_INITID_11_MASK \
      (MP1_PMI_INITID_11_INITID_MASK | \
      MP1_PMI_INITID_11_VALID_MASK)

#define MP1_PMI_INITID_11_DEFAULT      0x00000000

#define MP1_PMI_INITID_11_GET_INITID(mp1_pmi_initid_11) \
      ((mp1_pmi_initid_11 & MP1_PMI_INITID_11_INITID_MASK) >> MP1_PMI_INITID_11_INITID_SHIFT)
#define MP1_PMI_INITID_11_GET_VALID(mp1_pmi_initid_11) \
      ((mp1_pmi_initid_11 & MP1_PMI_INITID_11_VALID_MASK) >> MP1_PMI_INITID_11_VALID_SHIFT)

#define MP1_PMI_INITID_11_SET_INITID(mp1_pmi_initid_11_reg, initid) \
      mp1_pmi_initid_11_reg = (mp1_pmi_initid_11_reg & ~MP1_PMI_INITID_11_INITID_MASK) | (initid << MP1_PMI_INITID_11_INITID_SHIFT)
#define MP1_PMI_INITID_11_SET_VALID(mp1_pmi_initid_11_reg, valid) \
      mp1_pmi_initid_11_reg = (mp1_pmi_initid_11_reg & ~MP1_PMI_INITID_11_VALID_MASK) | (valid << MP1_PMI_INITID_11_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_initid_11_t {
            unsigned int initid                         : MP1_PMI_INITID_11_INITID_SIZE;
            unsigned int                                : 6;
            unsigned int valid                          : MP1_PMI_INITID_11_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_pmi_initid_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_initid_11_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_PMI_INITID_11_VALID_SIZE;
            unsigned int                                : 6;
            unsigned int initid                         : MP1_PMI_INITID_11_INITID_SIZE;
      } mp1_pmi_initid_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_initid_11_t f;
} mp1_pmi_initid_11_u;


/*
 * MP1_PMI_INITID_12 struct
 */

#define MP1_PMI_INITID_12_REG_SIZE         32
#define MP1_PMI_INITID_12_INITID_SIZE  10
#define MP1_PMI_INITID_12_VALID_SIZE  1

#define MP1_PMI_INITID_12_INITID_SHIFT  0
#define MP1_PMI_INITID_12_VALID_SHIFT  16

#define MP1_PMI_INITID_12_INITID_MASK   0x000003ff
#define MP1_PMI_INITID_12_VALID_MASK    0x00010000

#define MP1_PMI_INITID_12_MASK \
      (MP1_PMI_INITID_12_INITID_MASK | \
      MP1_PMI_INITID_12_VALID_MASK)

#define MP1_PMI_INITID_12_DEFAULT      0x00000000

#define MP1_PMI_INITID_12_GET_INITID(mp1_pmi_initid_12) \
      ((mp1_pmi_initid_12 & MP1_PMI_INITID_12_INITID_MASK) >> MP1_PMI_INITID_12_INITID_SHIFT)
#define MP1_PMI_INITID_12_GET_VALID(mp1_pmi_initid_12) \
      ((mp1_pmi_initid_12 & MP1_PMI_INITID_12_VALID_MASK) >> MP1_PMI_INITID_12_VALID_SHIFT)

#define MP1_PMI_INITID_12_SET_INITID(mp1_pmi_initid_12_reg, initid) \
      mp1_pmi_initid_12_reg = (mp1_pmi_initid_12_reg & ~MP1_PMI_INITID_12_INITID_MASK) | (initid << MP1_PMI_INITID_12_INITID_SHIFT)
#define MP1_PMI_INITID_12_SET_VALID(mp1_pmi_initid_12_reg, valid) \
      mp1_pmi_initid_12_reg = (mp1_pmi_initid_12_reg & ~MP1_PMI_INITID_12_VALID_MASK) | (valid << MP1_PMI_INITID_12_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_initid_12_t {
            unsigned int initid                         : MP1_PMI_INITID_12_INITID_SIZE;
            unsigned int                                : 6;
            unsigned int valid                          : MP1_PMI_INITID_12_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_pmi_initid_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_initid_12_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_PMI_INITID_12_VALID_SIZE;
            unsigned int                                : 6;
            unsigned int initid                         : MP1_PMI_INITID_12_INITID_SIZE;
      } mp1_pmi_initid_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_initid_12_t f;
} mp1_pmi_initid_12_u;


/*
 * MP1_PMI_INITID_13 struct
 */

#define MP1_PMI_INITID_13_REG_SIZE         32
#define MP1_PMI_INITID_13_INITID_SIZE  10
#define MP1_PMI_INITID_13_VALID_SIZE  1

#define MP1_PMI_INITID_13_INITID_SHIFT  0
#define MP1_PMI_INITID_13_VALID_SHIFT  16

#define MP1_PMI_INITID_13_INITID_MASK   0x000003ff
#define MP1_PMI_INITID_13_VALID_MASK    0x00010000

#define MP1_PMI_INITID_13_MASK \
      (MP1_PMI_INITID_13_INITID_MASK | \
      MP1_PMI_INITID_13_VALID_MASK)

#define MP1_PMI_INITID_13_DEFAULT      0x00000000

#define MP1_PMI_INITID_13_GET_INITID(mp1_pmi_initid_13) \
      ((mp1_pmi_initid_13 & MP1_PMI_INITID_13_INITID_MASK) >> MP1_PMI_INITID_13_INITID_SHIFT)
#define MP1_PMI_INITID_13_GET_VALID(mp1_pmi_initid_13) \
      ((mp1_pmi_initid_13 & MP1_PMI_INITID_13_VALID_MASK) >> MP1_PMI_INITID_13_VALID_SHIFT)

#define MP1_PMI_INITID_13_SET_INITID(mp1_pmi_initid_13_reg, initid) \
      mp1_pmi_initid_13_reg = (mp1_pmi_initid_13_reg & ~MP1_PMI_INITID_13_INITID_MASK) | (initid << MP1_PMI_INITID_13_INITID_SHIFT)
#define MP1_PMI_INITID_13_SET_VALID(mp1_pmi_initid_13_reg, valid) \
      mp1_pmi_initid_13_reg = (mp1_pmi_initid_13_reg & ~MP1_PMI_INITID_13_VALID_MASK) | (valid << MP1_PMI_INITID_13_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_initid_13_t {
            unsigned int initid                         : MP1_PMI_INITID_13_INITID_SIZE;
            unsigned int                                : 6;
            unsigned int valid                          : MP1_PMI_INITID_13_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_pmi_initid_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_initid_13_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_PMI_INITID_13_VALID_SIZE;
            unsigned int                                : 6;
            unsigned int initid                         : MP1_PMI_INITID_13_INITID_SIZE;
      } mp1_pmi_initid_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_initid_13_t f;
} mp1_pmi_initid_13_u;


/*
 * MP1_PMI_INITID_14 struct
 */

#define MP1_PMI_INITID_14_REG_SIZE         32
#define MP1_PMI_INITID_14_INITID_SIZE  10
#define MP1_PMI_INITID_14_VALID_SIZE  1

#define MP1_PMI_INITID_14_INITID_SHIFT  0
#define MP1_PMI_INITID_14_VALID_SHIFT  16

#define MP1_PMI_INITID_14_INITID_MASK   0x000003ff
#define MP1_PMI_INITID_14_VALID_MASK    0x00010000

#define MP1_PMI_INITID_14_MASK \
      (MP1_PMI_INITID_14_INITID_MASK | \
      MP1_PMI_INITID_14_VALID_MASK)

#define MP1_PMI_INITID_14_DEFAULT      0x00000000

#define MP1_PMI_INITID_14_GET_INITID(mp1_pmi_initid_14) \
      ((mp1_pmi_initid_14 & MP1_PMI_INITID_14_INITID_MASK) >> MP1_PMI_INITID_14_INITID_SHIFT)
#define MP1_PMI_INITID_14_GET_VALID(mp1_pmi_initid_14) \
      ((mp1_pmi_initid_14 & MP1_PMI_INITID_14_VALID_MASK) >> MP1_PMI_INITID_14_VALID_SHIFT)

#define MP1_PMI_INITID_14_SET_INITID(mp1_pmi_initid_14_reg, initid) \
      mp1_pmi_initid_14_reg = (mp1_pmi_initid_14_reg & ~MP1_PMI_INITID_14_INITID_MASK) | (initid << MP1_PMI_INITID_14_INITID_SHIFT)
#define MP1_PMI_INITID_14_SET_VALID(mp1_pmi_initid_14_reg, valid) \
      mp1_pmi_initid_14_reg = (mp1_pmi_initid_14_reg & ~MP1_PMI_INITID_14_VALID_MASK) | (valid << MP1_PMI_INITID_14_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_initid_14_t {
            unsigned int initid                         : MP1_PMI_INITID_14_INITID_SIZE;
            unsigned int                                : 6;
            unsigned int valid                          : MP1_PMI_INITID_14_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_pmi_initid_14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_initid_14_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_PMI_INITID_14_VALID_SIZE;
            unsigned int                                : 6;
            unsigned int initid                         : MP1_PMI_INITID_14_INITID_SIZE;
      } mp1_pmi_initid_14_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_initid_14_t f;
} mp1_pmi_initid_14_u;


/*
 * MP1_PMI_INITID_15 struct
 */

#define MP1_PMI_INITID_15_REG_SIZE         32
#define MP1_PMI_INITID_15_INITID_SIZE  10
#define MP1_PMI_INITID_15_VALID_SIZE  1

#define MP1_PMI_INITID_15_INITID_SHIFT  0
#define MP1_PMI_INITID_15_VALID_SHIFT  16

#define MP1_PMI_INITID_15_INITID_MASK   0x000003ff
#define MP1_PMI_INITID_15_VALID_MASK    0x00010000

#define MP1_PMI_INITID_15_MASK \
      (MP1_PMI_INITID_15_INITID_MASK | \
      MP1_PMI_INITID_15_VALID_MASK)

#define MP1_PMI_INITID_15_DEFAULT      0x00000000

#define MP1_PMI_INITID_15_GET_INITID(mp1_pmi_initid_15) \
      ((mp1_pmi_initid_15 & MP1_PMI_INITID_15_INITID_MASK) >> MP1_PMI_INITID_15_INITID_SHIFT)
#define MP1_PMI_INITID_15_GET_VALID(mp1_pmi_initid_15) \
      ((mp1_pmi_initid_15 & MP1_PMI_INITID_15_VALID_MASK) >> MP1_PMI_INITID_15_VALID_SHIFT)

#define MP1_PMI_INITID_15_SET_INITID(mp1_pmi_initid_15_reg, initid) \
      mp1_pmi_initid_15_reg = (mp1_pmi_initid_15_reg & ~MP1_PMI_INITID_15_INITID_MASK) | (initid << MP1_PMI_INITID_15_INITID_SHIFT)
#define MP1_PMI_INITID_15_SET_VALID(mp1_pmi_initid_15_reg, valid) \
      mp1_pmi_initid_15_reg = (mp1_pmi_initid_15_reg & ~MP1_PMI_INITID_15_VALID_MASK) | (valid << MP1_PMI_INITID_15_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_initid_15_t {
            unsigned int initid                         : MP1_PMI_INITID_15_INITID_SIZE;
            unsigned int                                : 6;
            unsigned int valid                          : MP1_PMI_INITID_15_VALID_SIZE;
            unsigned int                                : 15;
      } mp1_pmi_initid_15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_initid_15_t {
            unsigned int                                : 15;
            unsigned int valid                          : MP1_PMI_INITID_15_VALID_SIZE;
            unsigned int                                : 6;
            unsigned int initid                         : MP1_PMI_INITID_15_INITID_SIZE;
      } mp1_pmi_initid_15_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_initid_15_t f;
} mp1_pmi_initid_15_u;


/*
 * MP1_PMI_0 struct
 */

#define MP1_PMI_0_REG_SIZE         32
#define MP1_PMI_0_DATA_SIZE  32

#define MP1_PMI_0_DATA_SHIFT  0

#define MP1_PMI_0_DATA_MASK             0xffffffff

#define MP1_PMI_0_MASK \
      (MP1_PMI_0_DATA_MASK)

#define MP1_PMI_0_DEFAULT              0x00000000

#define MP1_PMI_0_GET_DATA(mp1_pmi_0) \
      ((mp1_pmi_0 & MP1_PMI_0_DATA_MASK) >> MP1_PMI_0_DATA_SHIFT)

#define MP1_PMI_0_SET_DATA(mp1_pmi_0_reg, data) \
      mp1_pmi_0_reg = (mp1_pmi_0_reg & ~MP1_PMI_0_DATA_MASK) | (data << MP1_PMI_0_DATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_0_t {
            unsigned int data                           : MP1_PMI_0_DATA_SIZE;
      } mp1_pmi_0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_0_t {
            unsigned int data                           : MP1_PMI_0_DATA_SIZE;
      } mp1_pmi_0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_0_t f;
} mp1_pmi_0_u;


/*
 * MP1_PMI_1 struct
 */

#define MP1_PMI_1_REG_SIZE         32
#define MP1_PMI_1_DATA_SIZE  32

#define MP1_PMI_1_DATA_SHIFT  0

#define MP1_PMI_1_DATA_MASK             0xffffffff

#define MP1_PMI_1_MASK \
      (MP1_PMI_1_DATA_MASK)

#define MP1_PMI_1_DEFAULT              0x00000000

#define MP1_PMI_1_GET_DATA(mp1_pmi_1) \
      ((mp1_pmi_1 & MP1_PMI_1_DATA_MASK) >> MP1_PMI_1_DATA_SHIFT)

#define MP1_PMI_1_SET_DATA(mp1_pmi_1_reg, data) \
      mp1_pmi_1_reg = (mp1_pmi_1_reg & ~MP1_PMI_1_DATA_MASK) | (data << MP1_PMI_1_DATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_1_t {
            unsigned int data                           : MP1_PMI_1_DATA_SIZE;
      } mp1_pmi_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_1_t {
            unsigned int data                           : MP1_PMI_1_DATA_SIZE;
      } mp1_pmi_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_1_t f;
} mp1_pmi_1_u;


/*
 * MP1_PMI_2 struct
 */

#define MP1_PMI_2_REG_SIZE         32
#define MP1_PMI_2_DATA_SIZE  32

#define MP1_PMI_2_DATA_SHIFT  0

#define MP1_PMI_2_DATA_MASK             0xffffffff

#define MP1_PMI_2_MASK \
      (MP1_PMI_2_DATA_MASK)

#define MP1_PMI_2_DEFAULT              0x00000000

#define MP1_PMI_2_GET_DATA(mp1_pmi_2) \
      ((mp1_pmi_2 & MP1_PMI_2_DATA_MASK) >> MP1_PMI_2_DATA_SHIFT)

#define MP1_PMI_2_SET_DATA(mp1_pmi_2_reg, data) \
      mp1_pmi_2_reg = (mp1_pmi_2_reg & ~MP1_PMI_2_DATA_MASK) | (data << MP1_PMI_2_DATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_2_t {
            unsigned int data                           : MP1_PMI_2_DATA_SIZE;
      } mp1_pmi_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_2_t {
            unsigned int data                           : MP1_PMI_2_DATA_SIZE;
      } mp1_pmi_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_2_t f;
} mp1_pmi_2_u;


/*
 * MP1_PMI_3_RELOAD struct
 */

#define MP1_PMI_3_RELOAD_REG_SIZE         32
#define MP1_PMI_3_RELOAD_PMI_PARAMETERS_SIZE  1

#define MP1_PMI_3_RELOAD_PMI_PARAMETERS_SHIFT  0

#define MP1_PMI_3_RELOAD_PMI_PARAMETERS_MASK  0x00000001

#define MP1_PMI_3_RELOAD_MASK \
      (MP1_PMI_3_RELOAD_PMI_PARAMETERS_MASK)

#define MP1_PMI_3_RELOAD_DEFAULT       0x00000000

#define MP1_PMI_3_RELOAD_GET_PMI_PARAMETERS(mp1_pmi_3_reload) \
      ((mp1_pmi_3_reload & MP1_PMI_3_RELOAD_PMI_PARAMETERS_MASK) >> MP1_PMI_3_RELOAD_PMI_PARAMETERS_SHIFT)

#define MP1_PMI_3_RELOAD_SET_PMI_PARAMETERS(mp1_pmi_3_reload_reg, pmi_parameters) \
      mp1_pmi_3_reload_reg = (mp1_pmi_3_reload_reg & ~MP1_PMI_3_RELOAD_PMI_PARAMETERS_MASK) | (pmi_parameters << MP1_PMI_3_RELOAD_PMI_PARAMETERS_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_3_reload_t {
            unsigned int pmi_parameters                 : MP1_PMI_3_RELOAD_PMI_PARAMETERS_SIZE;
            unsigned int                                : 31;
      } mp1_pmi_3_reload_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_3_reload_t {
            unsigned int                                : 31;
            unsigned int pmi_parameters                 : MP1_PMI_3_RELOAD_PMI_PARAMETERS_SIZE;
      } mp1_pmi_3_reload_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_3_reload_t f;
} mp1_pmi_3_reload_u;


/*
 * MP1_PMI_3_START struct
 */

#define MP1_PMI_3_START_REG_SIZE         32
#define MP1_PMI_3_START_ADDR_SIZE  19
#define MP1_PMI_3_START_ENABLE_SIZE  1

#define MP1_PMI_3_START_ADDR_SHIFT  0
#define MP1_PMI_3_START_ENABLE_SHIFT  31

#define MP1_PMI_3_START_ADDR_MASK       0x0007ffff
#define MP1_PMI_3_START_ENABLE_MASK     0x80000000

#define MP1_PMI_3_START_MASK \
      (MP1_PMI_3_START_ADDR_MASK | \
      MP1_PMI_3_START_ENABLE_MASK)

#define MP1_PMI_3_START_DEFAULT        0x80040000

#define MP1_PMI_3_START_GET_ADDR(mp1_pmi_3_start) \
      ((mp1_pmi_3_start & MP1_PMI_3_START_ADDR_MASK) >> MP1_PMI_3_START_ADDR_SHIFT)
#define MP1_PMI_3_START_GET_ENABLE(mp1_pmi_3_start) \
      ((mp1_pmi_3_start & MP1_PMI_3_START_ENABLE_MASK) >> MP1_PMI_3_START_ENABLE_SHIFT)

#define MP1_PMI_3_START_SET_ADDR(mp1_pmi_3_start_reg, addr) \
      mp1_pmi_3_start_reg = (mp1_pmi_3_start_reg & ~MP1_PMI_3_START_ADDR_MASK) | (addr << MP1_PMI_3_START_ADDR_SHIFT)
#define MP1_PMI_3_START_SET_ENABLE(mp1_pmi_3_start_reg, enable) \
      mp1_pmi_3_start_reg = (mp1_pmi_3_start_reg & ~MP1_PMI_3_START_ENABLE_MASK) | (enable << MP1_PMI_3_START_ENABLE_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_3_start_t {
            unsigned int addr                           : MP1_PMI_3_START_ADDR_SIZE;
            unsigned int                                : 12;
            unsigned int enable                         : MP1_PMI_3_START_ENABLE_SIZE;
      } mp1_pmi_3_start_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_3_start_t {
            unsigned int enable                         : MP1_PMI_3_START_ENABLE_SIZE;
            unsigned int                                : 12;
            unsigned int addr                           : MP1_PMI_3_START_ADDR_SIZE;
      } mp1_pmi_3_start_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_3_start_t f;
} mp1_pmi_3_start_u;


/*
 * MP1_PMI_3_FIFO struct
 */

#define MP1_PMI_3_FIFO_REG_SIZE         32
#define MP1_PMI_3_FIFO_DEPTH_SIZE  12
#define MP1_PMI_3_FIFO_DISABLE_EMPTY_FULL_SIZE  1
#define MP1_PMI_3_FIFO_DISABLE_ROLLOVER_INTR_SIZE  1
#define MP1_PMI_3_FIFO_DISABLE_FIFOFULL_INTR_SIZE  1
#define MP1_PMI_3_FIFO_DISABLE_FULLEMPTY_SLVERR_SIZE  1
#define MP1_PMI_3_FIFO_CLEAR_ROLLOVER_INTR_SIZE  1
#define MP1_PMI_3_FIFO_CLEAR_FIFOFULL_INTR_SIZE  1

#define MP1_PMI_3_FIFO_DEPTH_SHIFT  0
#define MP1_PMI_3_FIFO_DISABLE_EMPTY_FULL_SHIFT  16
#define MP1_PMI_3_FIFO_DISABLE_ROLLOVER_INTR_SHIFT  17
#define MP1_PMI_3_FIFO_DISABLE_FIFOFULL_INTR_SHIFT  18
#define MP1_PMI_3_FIFO_DISABLE_FULLEMPTY_SLVERR_SHIFT  19
#define MP1_PMI_3_FIFO_CLEAR_ROLLOVER_INTR_SHIFT  24
#define MP1_PMI_3_FIFO_CLEAR_FIFOFULL_INTR_SHIFT  25

#define MP1_PMI_3_FIFO_DEPTH_MASK       0x00000fff
#define MP1_PMI_3_FIFO_DISABLE_EMPTY_FULL_MASK  0x00010000
#define MP1_PMI_3_FIFO_DISABLE_ROLLOVER_INTR_MASK  0x00020000
#define MP1_PMI_3_FIFO_DISABLE_FIFOFULL_INTR_MASK  0x00040000
#define MP1_PMI_3_FIFO_DISABLE_FULLEMPTY_SLVERR_MASK  0x00080000
#define MP1_PMI_3_FIFO_CLEAR_ROLLOVER_INTR_MASK  0x01000000
#define MP1_PMI_3_FIFO_CLEAR_FIFOFULL_INTR_MASK  0x02000000

#define MP1_PMI_3_FIFO_MASK \
      (MP1_PMI_3_FIFO_DEPTH_MASK | \
      MP1_PMI_3_FIFO_DISABLE_EMPTY_FULL_MASK | \
      MP1_PMI_3_FIFO_DISABLE_ROLLOVER_INTR_MASK | \
      MP1_PMI_3_FIFO_DISABLE_FIFOFULL_INTR_MASK | \
      MP1_PMI_3_FIFO_DISABLE_FULLEMPTY_SLVERR_MASK | \
      MP1_PMI_3_FIFO_CLEAR_ROLLOVER_INTR_MASK | \
      MP1_PMI_3_FIFO_CLEAR_FIFOFULL_INTR_MASK)

#define MP1_PMI_3_FIFO_DEFAULT         0x0009000b

#define MP1_PMI_3_FIFO_GET_DEPTH(mp1_pmi_3_fifo) \
      ((mp1_pmi_3_fifo & MP1_PMI_3_FIFO_DEPTH_MASK) >> MP1_PMI_3_FIFO_DEPTH_SHIFT)
#define MP1_PMI_3_FIFO_GET_DISABLE_EMPTY_FULL(mp1_pmi_3_fifo) \
      ((mp1_pmi_3_fifo & MP1_PMI_3_FIFO_DISABLE_EMPTY_FULL_MASK) >> MP1_PMI_3_FIFO_DISABLE_EMPTY_FULL_SHIFT)
#define MP1_PMI_3_FIFO_GET_DISABLE_ROLLOVER_INTR(mp1_pmi_3_fifo) \
      ((mp1_pmi_3_fifo & MP1_PMI_3_FIFO_DISABLE_ROLLOVER_INTR_MASK) >> MP1_PMI_3_FIFO_DISABLE_ROLLOVER_INTR_SHIFT)
#define MP1_PMI_3_FIFO_GET_DISABLE_FIFOFULL_INTR(mp1_pmi_3_fifo) \
      ((mp1_pmi_3_fifo & MP1_PMI_3_FIFO_DISABLE_FIFOFULL_INTR_MASK) >> MP1_PMI_3_FIFO_DISABLE_FIFOFULL_INTR_SHIFT)
#define MP1_PMI_3_FIFO_GET_DISABLE_FULLEMPTY_SLVERR(mp1_pmi_3_fifo) \
      ((mp1_pmi_3_fifo & MP1_PMI_3_FIFO_DISABLE_FULLEMPTY_SLVERR_MASK) >> MP1_PMI_3_FIFO_DISABLE_FULLEMPTY_SLVERR_SHIFT)
#define MP1_PMI_3_FIFO_GET_CLEAR_ROLLOVER_INTR(mp1_pmi_3_fifo) \
      ((mp1_pmi_3_fifo & MP1_PMI_3_FIFO_CLEAR_ROLLOVER_INTR_MASK) >> MP1_PMI_3_FIFO_CLEAR_ROLLOVER_INTR_SHIFT)
#define MP1_PMI_3_FIFO_GET_CLEAR_FIFOFULL_INTR(mp1_pmi_3_fifo) \
      ((mp1_pmi_3_fifo & MP1_PMI_3_FIFO_CLEAR_FIFOFULL_INTR_MASK) >> MP1_PMI_3_FIFO_CLEAR_FIFOFULL_INTR_SHIFT)

#define MP1_PMI_3_FIFO_SET_DEPTH(mp1_pmi_3_fifo_reg, depth) \
      mp1_pmi_3_fifo_reg = (mp1_pmi_3_fifo_reg & ~MP1_PMI_3_FIFO_DEPTH_MASK) | (depth << MP1_PMI_3_FIFO_DEPTH_SHIFT)
#define MP1_PMI_3_FIFO_SET_DISABLE_EMPTY_FULL(mp1_pmi_3_fifo_reg, disable_empty_full) \
      mp1_pmi_3_fifo_reg = (mp1_pmi_3_fifo_reg & ~MP1_PMI_3_FIFO_DISABLE_EMPTY_FULL_MASK) | (disable_empty_full << MP1_PMI_3_FIFO_DISABLE_EMPTY_FULL_SHIFT)
#define MP1_PMI_3_FIFO_SET_DISABLE_ROLLOVER_INTR(mp1_pmi_3_fifo_reg, disable_rollover_intr) \
      mp1_pmi_3_fifo_reg = (mp1_pmi_3_fifo_reg & ~MP1_PMI_3_FIFO_DISABLE_ROLLOVER_INTR_MASK) | (disable_rollover_intr << MP1_PMI_3_FIFO_DISABLE_ROLLOVER_INTR_SHIFT)
#define MP1_PMI_3_FIFO_SET_DISABLE_FIFOFULL_INTR(mp1_pmi_3_fifo_reg, disable_fifofull_intr) \
      mp1_pmi_3_fifo_reg = (mp1_pmi_3_fifo_reg & ~MP1_PMI_3_FIFO_DISABLE_FIFOFULL_INTR_MASK) | (disable_fifofull_intr << MP1_PMI_3_FIFO_DISABLE_FIFOFULL_INTR_SHIFT)
#define MP1_PMI_3_FIFO_SET_DISABLE_FULLEMPTY_SLVERR(mp1_pmi_3_fifo_reg, disable_fullempty_slverr) \
      mp1_pmi_3_fifo_reg = (mp1_pmi_3_fifo_reg & ~MP1_PMI_3_FIFO_DISABLE_FULLEMPTY_SLVERR_MASK) | (disable_fullempty_slverr << MP1_PMI_3_FIFO_DISABLE_FULLEMPTY_SLVERR_SHIFT)
#define MP1_PMI_3_FIFO_SET_CLEAR_ROLLOVER_INTR(mp1_pmi_3_fifo_reg, clear_rollover_intr) \
      mp1_pmi_3_fifo_reg = (mp1_pmi_3_fifo_reg & ~MP1_PMI_3_FIFO_CLEAR_ROLLOVER_INTR_MASK) | (clear_rollover_intr << MP1_PMI_3_FIFO_CLEAR_ROLLOVER_INTR_SHIFT)
#define MP1_PMI_3_FIFO_SET_CLEAR_FIFOFULL_INTR(mp1_pmi_3_fifo_reg, clear_fifofull_intr) \
      mp1_pmi_3_fifo_reg = (mp1_pmi_3_fifo_reg & ~MP1_PMI_3_FIFO_CLEAR_FIFOFULL_INTR_MASK) | (clear_fifofull_intr << MP1_PMI_3_FIFO_CLEAR_FIFOFULL_INTR_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_3_fifo_t {
            unsigned int depth                          : MP1_PMI_3_FIFO_DEPTH_SIZE;
            unsigned int                                : 4;
            unsigned int disable_empty_full             : MP1_PMI_3_FIFO_DISABLE_EMPTY_FULL_SIZE;
            unsigned int disable_rollover_intr          : MP1_PMI_3_FIFO_DISABLE_ROLLOVER_INTR_SIZE;
            unsigned int disable_fifofull_intr          : MP1_PMI_3_FIFO_DISABLE_FIFOFULL_INTR_SIZE;
            unsigned int disable_fullempty_slverr       : MP1_PMI_3_FIFO_DISABLE_FULLEMPTY_SLVERR_SIZE;
            unsigned int                                : 4;
            unsigned int clear_rollover_intr            : MP1_PMI_3_FIFO_CLEAR_ROLLOVER_INTR_SIZE;
            unsigned int clear_fifofull_intr            : MP1_PMI_3_FIFO_CLEAR_FIFOFULL_INTR_SIZE;
            unsigned int                                : 6;
      } mp1_pmi_3_fifo_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_3_fifo_t {
            unsigned int                                : 6;
            unsigned int clear_fifofull_intr            : MP1_PMI_3_FIFO_CLEAR_FIFOFULL_INTR_SIZE;
            unsigned int clear_rollover_intr            : MP1_PMI_3_FIFO_CLEAR_ROLLOVER_INTR_SIZE;
            unsigned int                                : 4;
            unsigned int disable_fullempty_slverr       : MP1_PMI_3_FIFO_DISABLE_FULLEMPTY_SLVERR_SIZE;
            unsigned int disable_fifofull_intr          : MP1_PMI_3_FIFO_DISABLE_FIFOFULL_INTR_SIZE;
            unsigned int disable_rollover_intr          : MP1_PMI_3_FIFO_DISABLE_ROLLOVER_INTR_SIZE;
            unsigned int disable_empty_full             : MP1_PMI_3_FIFO_DISABLE_EMPTY_FULL_SIZE;
            unsigned int                                : 4;
            unsigned int depth                          : MP1_PMI_3_FIFO_DEPTH_SIZE;
      } mp1_pmi_3_fifo_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_3_fifo_t f;
} mp1_pmi_3_fifo_u;


/*
 * MP1_POSTCODE_CONFIG struct
 */

#define MP1_POSTCODE_CONFIG_REG_SIZE         32
#define MP1_POSTCODE_CONFIG_IGNORE_IP_CHECK_SIZE  1
#define MP1_POSTCODE_CONFIG_IGNORE_FEATURE_CHECK_SIZE  1

#define MP1_POSTCODE_CONFIG_IGNORE_IP_CHECK_SHIFT  0
#define MP1_POSTCODE_CONFIG_IGNORE_FEATURE_CHECK_SHIFT  1

#define MP1_POSTCODE_CONFIG_IGNORE_IP_CHECK_MASK  0x00000001
#define MP1_POSTCODE_CONFIG_IGNORE_FEATURE_CHECK_MASK  0x00000002

#define MP1_POSTCODE_CONFIG_MASK \
      (MP1_POSTCODE_CONFIG_IGNORE_IP_CHECK_MASK | \
      MP1_POSTCODE_CONFIG_IGNORE_FEATURE_CHECK_MASK)

#define MP1_POSTCODE_CONFIG_DEFAULT    0x00000003

#define MP1_POSTCODE_CONFIG_GET_IGNORE_IP_CHECK(mp1_postcode_config) \
      ((mp1_postcode_config & MP1_POSTCODE_CONFIG_IGNORE_IP_CHECK_MASK) >> MP1_POSTCODE_CONFIG_IGNORE_IP_CHECK_SHIFT)
#define MP1_POSTCODE_CONFIG_GET_IGNORE_FEATURE_CHECK(mp1_postcode_config) \
      ((mp1_postcode_config & MP1_POSTCODE_CONFIG_IGNORE_FEATURE_CHECK_MASK) >> MP1_POSTCODE_CONFIG_IGNORE_FEATURE_CHECK_SHIFT)

#define MP1_POSTCODE_CONFIG_SET_IGNORE_IP_CHECK(mp1_postcode_config_reg, ignore_ip_check) \
      mp1_postcode_config_reg = (mp1_postcode_config_reg & ~MP1_POSTCODE_CONFIG_IGNORE_IP_CHECK_MASK) | (ignore_ip_check << MP1_POSTCODE_CONFIG_IGNORE_IP_CHECK_SHIFT)
#define MP1_POSTCODE_CONFIG_SET_IGNORE_FEATURE_CHECK(mp1_postcode_config_reg, ignore_feature_check) \
      mp1_postcode_config_reg = (mp1_postcode_config_reg & ~MP1_POSTCODE_CONFIG_IGNORE_FEATURE_CHECK_MASK) | (ignore_feature_check << MP1_POSTCODE_CONFIG_IGNORE_FEATURE_CHECK_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_config_t {
            unsigned int ignore_ip_check                : MP1_POSTCODE_CONFIG_IGNORE_IP_CHECK_SIZE;
            unsigned int ignore_feature_check           : MP1_POSTCODE_CONFIG_IGNORE_FEATURE_CHECK_SIZE;
            unsigned int                                : 30;
      } mp1_postcode_config_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_config_t {
            unsigned int                                : 30;
            unsigned int ignore_feature_check           : MP1_POSTCODE_CONFIG_IGNORE_FEATURE_CHECK_SIZE;
            unsigned int ignore_ip_check                : MP1_POSTCODE_CONFIG_IGNORE_IP_CHECK_SIZE;
      } mp1_postcode_config_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_config_t f;
} mp1_postcode_config_u;


/*
 * MP1_POSTCODE_IP_0 struct
 */

#define MP1_POSTCODE_IP_0_REG_SIZE         32
#define MP1_POSTCODE_IP_0_IP_SIZE  8
#define MP1_POSTCODE_IP_0_VALID_SIZE  1

#define MP1_POSTCODE_IP_0_IP_SHIFT  0
#define MP1_POSTCODE_IP_0_VALID_SHIFT  8

#define MP1_POSTCODE_IP_0_IP_MASK       0x000000ff
#define MP1_POSTCODE_IP_0_VALID_MASK    0x00000100

#define MP1_POSTCODE_IP_0_MASK \
      (MP1_POSTCODE_IP_0_IP_MASK | \
      MP1_POSTCODE_IP_0_VALID_MASK)

#define MP1_POSTCODE_IP_0_DEFAULT      0x00000000

#define MP1_POSTCODE_IP_0_GET_IP(mp1_postcode_ip_0) \
      ((mp1_postcode_ip_0 & MP1_POSTCODE_IP_0_IP_MASK) >> MP1_POSTCODE_IP_0_IP_SHIFT)
#define MP1_POSTCODE_IP_0_GET_VALID(mp1_postcode_ip_0) \
      ((mp1_postcode_ip_0 & MP1_POSTCODE_IP_0_VALID_MASK) >> MP1_POSTCODE_IP_0_VALID_SHIFT)

#define MP1_POSTCODE_IP_0_SET_IP(mp1_postcode_ip_0_reg, ip) \
      mp1_postcode_ip_0_reg = (mp1_postcode_ip_0_reg & ~MP1_POSTCODE_IP_0_IP_MASK) | (ip << MP1_POSTCODE_IP_0_IP_SHIFT)
#define MP1_POSTCODE_IP_0_SET_VALID(mp1_postcode_ip_0_reg, valid) \
      mp1_postcode_ip_0_reg = (mp1_postcode_ip_0_reg & ~MP1_POSTCODE_IP_0_VALID_MASK) | (valid << MP1_POSTCODE_IP_0_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_ip_0_t {
            unsigned int ip                             : MP1_POSTCODE_IP_0_IP_SIZE;
            unsigned int valid                          : MP1_POSTCODE_IP_0_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_ip_0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_ip_0_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_IP_0_VALID_SIZE;
            unsigned int ip                             : MP1_POSTCODE_IP_0_IP_SIZE;
      } mp1_postcode_ip_0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_ip_0_t f;
} mp1_postcode_ip_0_u;


/*
 * MP1_POSTCODE_IP_1 struct
 */

#define MP1_POSTCODE_IP_1_REG_SIZE         32
#define MP1_POSTCODE_IP_1_IP_SIZE  8
#define MP1_POSTCODE_IP_1_VALID_SIZE  1

#define MP1_POSTCODE_IP_1_IP_SHIFT  0
#define MP1_POSTCODE_IP_1_VALID_SHIFT  8

#define MP1_POSTCODE_IP_1_IP_MASK       0x000000ff
#define MP1_POSTCODE_IP_1_VALID_MASK    0x00000100

#define MP1_POSTCODE_IP_1_MASK \
      (MP1_POSTCODE_IP_1_IP_MASK | \
      MP1_POSTCODE_IP_1_VALID_MASK)

#define MP1_POSTCODE_IP_1_DEFAULT      0x00000000

#define MP1_POSTCODE_IP_1_GET_IP(mp1_postcode_ip_1) \
      ((mp1_postcode_ip_1 & MP1_POSTCODE_IP_1_IP_MASK) >> MP1_POSTCODE_IP_1_IP_SHIFT)
#define MP1_POSTCODE_IP_1_GET_VALID(mp1_postcode_ip_1) \
      ((mp1_postcode_ip_1 & MP1_POSTCODE_IP_1_VALID_MASK) >> MP1_POSTCODE_IP_1_VALID_SHIFT)

#define MP1_POSTCODE_IP_1_SET_IP(mp1_postcode_ip_1_reg, ip) \
      mp1_postcode_ip_1_reg = (mp1_postcode_ip_1_reg & ~MP1_POSTCODE_IP_1_IP_MASK) | (ip << MP1_POSTCODE_IP_1_IP_SHIFT)
#define MP1_POSTCODE_IP_1_SET_VALID(mp1_postcode_ip_1_reg, valid) \
      mp1_postcode_ip_1_reg = (mp1_postcode_ip_1_reg & ~MP1_POSTCODE_IP_1_VALID_MASK) | (valid << MP1_POSTCODE_IP_1_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_ip_1_t {
            unsigned int ip                             : MP1_POSTCODE_IP_1_IP_SIZE;
            unsigned int valid                          : MP1_POSTCODE_IP_1_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_ip_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_ip_1_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_IP_1_VALID_SIZE;
            unsigned int ip                             : MP1_POSTCODE_IP_1_IP_SIZE;
      } mp1_postcode_ip_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_ip_1_t f;
} mp1_postcode_ip_1_u;


/*
 * MP1_POSTCODE_IP_2 struct
 */

#define MP1_POSTCODE_IP_2_REG_SIZE         32
#define MP1_POSTCODE_IP_2_IP_SIZE  8
#define MP1_POSTCODE_IP_2_VALID_SIZE  1

#define MP1_POSTCODE_IP_2_IP_SHIFT  0
#define MP1_POSTCODE_IP_2_VALID_SHIFT  8

#define MP1_POSTCODE_IP_2_IP_MASK       0x000000ff
#define MP1_POSTCODE_IP_2_VALID_MASK    0x00000100

#define MP1_POSTCODE_IP_2_MASK \
      (MP1_POSTCODE_IP_2_IP_MASK | \
      MP1_POSTCODE_IP_2_VALID_MASK)

#define MP1_POSTCODE_IP_2_DEFAULT      0x00000000

#define MP1_POSTCODE_IP_2_GET_IP(mp1_postcode_ip_2) \
      ((mp1_postcode_ip_2 & MP1_POSTCODE_IP_2_IP_MASK) >> MP1_POSTCODE_IP_2_IP_SHIFT)
#define MP1_POSTCODE_IP_2_GET_VALID(mp1_postcode_ip_2) \
      ((mp1_postcode_ip_2 & MP1_POSTCODE_IP_2_VALID_MASK) >> MP1_POSTCODE_IP_2_VALID_SHIFT)

#define MP1_POSTCODE_IP_2_SET_IP(mp1_postcode_ip_2_reg, ip) \
      mp1_postcode_ip_2_reg = (mp1_postcode_ip_2_reg & ~MP1_POSTCODE_IP_2_IP_MASK) | (ip << MP1_POSTCODE_IP_2_IP_SHIFT)
#define MP1_POSTCODE_IP_2_SET_VALID(mp1_postcode_ip_2_reg, valid) \
      mp1_postcode_ip_2_reg = (mp1_postcode_ip_2_reg & ~MP1_POSTCODE_IP_2_VALID_MASK) | (valid << MP1_POSTCODE_IP_2_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_ip_2_t {
            unsigned int ip                             : MP1_POSTCODE_IP_2_IP_SIZE;
            unsigned int valid                          : MP1_POSTCODE_IP_2_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_ip_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_ip_2_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_IP_2_VALID_SIZE;
            unsigned int ip                             : MP1_POSTCODE_IP_2_IP_SIZE;
      } mp1_postcode_ip_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_ip_2_t f;
} mp1_postcode_ip_2_u;


/*
 * MP1_POSTCODE_IP_3 struct
 */

#define MP1_POSTCODE_IP_3_REG_SIZE         32
#define MP1_POSTCODE_IP_3_IP_SIZE  8
#define MP1_POSTCODE_IP_3_VALID_SIZE  1

#define MP1_POSTCODE_IP_3_IP_SHIFT  0
#define MP1_POSTCODE_IP_3_VALID_SHIFT  8

#define MP1_POSTCODE_IP_3_IP_MASK       0x000000ff
#define MP1_POSTCODE_IP_3_VALID_MASK    0x00000100

#define MP1_POSTCODE_IP_3_MASK \
      (MP1_POSTCODE_IP_3_IP_MASK | \
      MP1_POSTCODE_IP_3_VALID_MASK)

#define MP1_POSTCODE_IP_3_DEFAULT      0x00000000

#define MP1_POSTCODE_IP_3_GET_IP(mp1_postcode_ip_3) \
      ((mp1_postcode_ip_3 & MP1_POSTCODE_IP_3_IP_MASK) >> MP1_POSTCODE_IP_3_IP_SHIFT)
#define MP1_POSTCODE_IP_3_GET_VALID(mp1_postcode_ip_3) \
      ((mp1_postcode_ip_3 & MP1_POSTCODE_IP_3_VALID_MASK) >> MP1_POSTCODE_IP_3_VALID_SHIFT)

#define MP1_POSTCODE_IP_3_SET_IP(mp1_postcode_ip_3_reg, ip) \
      mp1_postcode_ip_3_reg = (mp1_postcode_ip_3_reg & ~MP1_POSTCODE_IP_3_IP_MASK) | (ip << MP1_POSTCODE_IP_3_IP_SHIFT)
#define MP1_POSTCODE_IP_3_SET_VALID(mp1_postcode_ip_3_reg, valid) \
      mp1_postcode_ip_3_reg = (mp1_postcode_ip_3_reg & ~MP1_POSTCODE_IP_3_VALID_MASK) | (valid << MP1_POSTCODE_IP_3_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_ip_3_t {
            unsigned int ip                             : MP1_POSTCODE_IP_3_IP_SIZE;
            unsigned int valid                          : MP1_POSTCODE_IP_3_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_ip_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_ip_3_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_IP_3_VALID_SIZE;
            unsigned int ip                             : MP1_POSTCODE_IP_3_IP_SIZE;
      } mp1_postcode_ip_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_ip_3_t f;
} mp1_postcode_ip_3_u;


/*
 * MP1_POSTCODE_IP_4 struct
 */

#define MP1_POSTCODE_IP_4_REG_SIZE         32
#define MP1_POSTCODE_IP_4_IP_SIZE  8
#define MP1_POSTCODE_IP_4_VALID_SIZE  1

#define MP1_POSTCODE_IP_4_IP_SHIFT  0
#define MP1_POSTCODE_IP_4_VALID_SHIFT  8

#define MP1_POSTCODE_IP_4_IP_MASK       0x000000ff
#define MP1_POSTCODE_IP_4_VALID_MASK    0x00000100

#define MP1_POSTCODE_IP_4_MASK \
      (MP1_POSTCODE_IP_4_IP_MASK | \
      MP1_POSTCODE_IP_4_VALID_MASK)

#define MP1_POSTCODE_IP_4_DEFAULT      0x00000000

#define MP1_POSTCODE_IP_4_GET_IP(mp1_postcode_ip_4) \
      ((mp1_postcode_ip_4 & MP1_POSTCODE_IP_4_IP_MASK) >> MP1_POSTCODE_IP_4_IP_SHIFT)
#define MP1_POSTCODE_IP_4_GET_VALID(mp1_postcode_ip_4) \
      ((mp1_postcode_ip_4 & MP1_POSTCODE_IP_4_VALID_MASK) >> MP1_POSTCODE_IP_4_VALID_SHIFT)

#define MP1_POSTCODE_IP_4_SET_IP(mp1_postcode_ip_4_reg, ip) \
      mp1_postcode_ip_4_reg = (mp1_postcode_ip_4_reg & ~MP1_POSTCODE_IP_4_IP_MASK) | (ip << MP1_POSTCODE_IP_4_IP_SHIFT)
#define MP1_POSTCODE_IP_4_SET_VALID(mp1_postcode_ip_4_reg, valid) \
      mp1_postcode_ip_4_reg = (mp1_postcode_ip_4_reg & ~MP1_POSTCODE_IP_4_VALID_MASK) | (valid << MP1_POSTCODE_IP_4_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_ip_4_t {
            unsigned int ip                             : MP1_POSTCODE_IP_4_IP_SIZE;
            unsigned int valid                          : MP1_POSTCODE_IP_4_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_ip_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_ip_4_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_IP_4_VALID_SIZE;
            unsigned int ip                             : MP1_POSTCODE_IP_4_IP_SIZE;
      } mp1_postcode_ip_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_ip_4_t f;
} mp1_postcode_ip_4_u;


/*
 * MP1_POSTCODE_IP_5 struct
 */

#define MP1_POSTCODE_IP_5_REG_SIZE         32
#define MP1_POSTCODE_IP_5_IP_SIZE  8
#define MP1_POSTCODE_IP_5_VALID_SIZE  1

#define MP1_POSTCODE_IP_5_IP_SHIFT  0
#define MP1_POSTCODE_IP_5_VALID_SHIFT  8

#define MP1_POSTCODE_IP_5_IP_MASK       0x000000ff
#define MP1_POSTCODE_IP_5_VALID_MASK    0x00000100

#define MP1_POSTCODE_IP_5_MASK \
      (MP1_POSTCODE_IP_5_IP_MASK | \
      MP1_POSTCODE_IP_5_VALID_MASK)

#define MP1_POSTCODE_IP_5_DEFAULT      0x00000000

#define MP1_POSTCODE_IP_5_GET_IP(mp1_postcode_ip_5) \
      ((mp1_postcode_ip_5 & MP1_POSTCODE_IP_5_IP_MASK) >> MP1_POSTCODE_IP_5_IP_SHIFT)
#define MP1_POSTCODE_IP_5_GET_VALID(mp1_postcode_ip_5) \
      ((mp1_postcode_ip_5 & MP1_POSTCODE_IP_5_VALID_MASK) >> MP1_POSTCODE_IP_5_VALID_SHIFT)

#define MP1_POSTCODE_IP_5_SET_IP(mp1_postcode_ip_5_reg, ip) \
      mp1_postcode_ip_5_reg = (mp1_postcode_ip_5_reg & ~MP1_POSTCODE_IP_5_IP_MASK) | (ip << MP1_POSTCODE_IP_5_IP_SHIFT)
#define MP1_POSTCODE_IP_5_SET_VALID(mp1_postcode_ip_5_reg, valid) \
      mp1_postcode_ip_5_reg = (mp1_postcode_ip_5_reg & ~MP1_POSTCODE_IP_5_VALID_MASK) | (valid << MP1_POSTCODE_IP_5_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_ip_5_t {
            unsigned int ip                             : MP1_POSTCODE_IP_5_IP_SIZE;
            unsigned int valid                          : MP1_POSTCODE_IP_5_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_ip_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_ip_5_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_IP_5_VALID_SIZE;
            unsigned int ip                             : MP1_POSTCODE_IP_5_IP_SIZE;
      } mp1_postcode_ip_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_ip_5_t f;
} mp1_postcode_ip_5_u;


/*
 * MP1_POSTCODE_IP_6 struct
 */

#define MP1_POSTCODE_IP_6_REG_SIZE         32
#define MP1_POSTCODE_IP_6_IP_SIZE  8
#define MP1_POSTCODE_IP_6_VALID_SIZE  1

#define MP1_POSTCODE_IP_6_IP_SHIFT  0
#define MP1_POSTCODE_IP_6_VALID_SHIFT  8

#define MP1_POSTCODE_IP_6_IP_MASK       0x000000ff
#define MP1_POSTCODE_IP_6_VALID_MASK    0x00000100

#define MP1_POSTCODE_IP_6_MASK \
      (MP1_POSTCODE_IP_6_IP_MASK | \
      MP1_POSTCODE_IP_6_VALID_MASK)

#define MP1_POSTCODE_IP_6_DEFAULT      0x00000000

#define MP1_POSTCODE_IP_6_GET_IP(mp1_postcode_ip_6) \
      ((mp1_postcode_ip_6 & MP1_POSTCODE_IP_6_IP_MASK) >> MP1_POSTCODE_IP_6_IP_SHIFT)
#define MP1_POSTCODE_IP_6_GET_VALID(mp1_postcode_ip_6) \
      ((mp1_postcode_ip_6 & MP1_POSTCODE_IP_6_VALID_MASK) >> MP1_POSTCODE_IP_6_VALID_SHIFT)

#define MP1_POSTCODE_IP_6_SET_IP(mp1_postcode_ip_6_reg, ip) \
      mp1_postcode_ip_6_reg = (mp1_postcode_ip_6_reg & ~MP1_POSTCODE_IP_6_IP_MASK) | (ip << MP1_POSTCODE_IP_6_IP_SHIFT)
#define MP1_POSTCODE_IP_6_SET_VALID(mp1_postcode_ip_6_reg, valid) \
      mp1_postcode_ip_6_reg = (mp1_postcode_ip_6_reg & ~MP1_POSTCODE_IP_6_VALID_MASK) | (valid << MP1_POSTCODE_IP_6_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_ip_6_t {
            unsigned int ip                             : MP1_POSTCODE_IP_6_IP_SIZE;
            unsigned int valid                          : MP1_POSTCODE_IP_6_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_ip_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_ip_6_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_IP_6_VALID_SIZE;
            unsigned int ip                             : MP1_POSTCODE_IP_6_IP_SIZE;
      } mp1_postcode_ip_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_ip_6_t f;
} mp1_postcode_ip_6_u;


/*
 * MP1_POSTCODE_IP_7 struct
 */

#define MP1_POSTCODE_IP_7_REG_SIZE         32
#define MP1_POSTCODE_IP_7_IP_SIZE  8
#define MP1_POSTCODE_IP_7_VALID_SIZE  1

#define MP1_POSTCODE_IP_7_IP_SHIFT  0
#define MP1_POSTCODE_IP_7_VALID_SHIFT  8

#define MP1_POSTCODE_IP_7_IP_MASK       0x000000ff
#define MP1_POSTCODE_IP_7_VALID_MASK    0x00000100

#define MP1_POSTCODE_IP_7_MASK \
      (MP1_POSTCODE_IP_7_IP_MASK | \
      MP1_POSTCODE_IP_7_VALID_MASK)

#define MP1_POSTCODE_IP_7_DEFAULT      0x00000000

#define MP1_POSTCODE_IP_7_GET_IP(mp1_postcode_ip_7) \
      ((mp1_postcode_ip_7 & MP1_POSTCODE_IP_7_IP_MASK) >> MP1_POSTCODE_IP_7_IP_SHIFT)
#define MP1_POSTCODE_IP_7_GET_VALID(mp1_postcode_ip_7) \
      ((mp1_postcode_ip_7 & MP1_POSTCODE_IP_7_VALID_MASK) >> MP1_POSTCODE_IP_7_VALID_SHIFT)

#define MP1_POSTCODE_IP_7_SET_IP(mp1_postcode_ip_7_reg, ip) \
      mp1_postcode_ip_7_reg = (mp1_postcode_ip_7_reg & ~MP1_POSTCODE_IP_7_IP_MASK) | (ip << MP1_POSTCODE_IP_7_IP_SHIFT)
#define MP1_POSTCODE_IP_7_SET_VALID(mp1_postcode_ip_7_reg, valid) \
      mp1_postcode_ip_7_reg = (mp1_postcode_ip_7_reg & ~MP1_POSTCODE_IP_7_VALID_MASK) | (valid << MP1_POSTCODE_IP_7_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_ip_7_t {
            unsigned int ip                             : MP1_POSTCODE_IP_7_IP_SIZE;
            unsigned int valid                          : MP1_POSTCODE_IP_7_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_ip_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_ip_7_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_IP_7_VALID_SIZE;
            unsigned int ip                             : MP1_POSTCODE_IP_7_IP_SIZE;
      } mp1_postcode_ip_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_ip_7_t f;
} mp1_postcode_ip_7_u;


/*
 * MP1_POSTCODE_IP_8 struct
 */

#define MP1_POSTCODE_IP_8_REG_SIZE         32
#define MP1_POSTCODE_IP_8_IP_SIZE  8
#define MP1_POSTCODE_IP_8_VALID_SIZE  1

#define MP1_POSTCODE_IP_8_IP_SHIFT  0
#define MP1_POSTCODE_IP_8_VALID_SHIFT  8

#define MP1_POSTCODE_IP_8_IP_MASK       0x000000ff
#define MP1_POSTCODE_IP_8_VALID_MASK    0x00000100

#define MP1_POSTCODE_IP_8_MASK \
      (MP1_POSTCODE_IP_8_IP_MASK | \
      MP1_POSTCODE_IP_8_VALID_MASK)

#define MP1_POSTCODE_IP_8_DEFAULT      0x00000000

#define MP1_POSTCODE_IP_8_GET_IP(mp1_postcode_ip_8) \
      ((mp1_postcode_ip_8 & MP1_POSTCODE_IP_8_IP_MASK) >> MP1_POSTCODE_IP_8_IP_SHIFT)
#define MP1_POSTCODE_IP_8_GET_VALID(mp1_postcode_ip_8) \
      ((mp1_postcode_ip_8 & MP1_POSTCODE_IP_8_VALID_MASK) >> MP1_POSTCODE_IP_8_VALID_SHIFT)

#define MP1_POSTCODE_IP_8_SET_IP(mp1_postcode_ip_8_reg, ip) \
      mp1_postcode_ip_8_reg = (mp1_postcode_ip_8_reg & ~MP1_POSTCODE_IP_8_IP_MASK) | (ip << MP1_POSTCODE_IP_8_IP_SHIFT)
#define MP1_POSTCODE_IP_8_SET_VALID(mp1_postcode_ip_8_reg, valid) \
      mp1_postcode_ip_8_reg = (mp1_postcode_ip_8_reg & ~MP1_POSTCODE_IP_8_VALID_MASK) | (valid << MP1_POSTCODE_IP_8_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_ip_8_t {
            unsigned int ip                             : MP1_POSTCODE_IP_8_IP_SIZE;
            unsigned int valid                          : MP1_POSTCODE_IP_8_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_ip_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_ip_8_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_IP_8_VALID_SIZE;
            unsigned int ip                             : MP1_POSTCODE_IP_8_IP_SIZE;
      } mp1_postcode_ip_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_ip_8_t f;
} mp1_postcode_ip_8_u;


/*
 * MP1_POSTCODE_IP_9 struct
 */

#define MP1_POSTCODE_IP_9_REG_SIZE         32
#define MP1_POSTCODE_IP_9_IP_SIZE  8
#define MP1_POSTCODE_IP_9_VALID_SIZE  1

#define MP1_POSTCODE_IP_9_IP_SHIFT  0
#define MP1_POSTCODE_IP_9_VALID_SHIFT  8

#define MP1_POSTCODE_IP_9_IP_MASK       0x000000ff
#define MP1_POSTCODE_IP_9_VALID_MASK    0x00000100

#define MP1_POSTCODE_IP_9_MASK \
      (MP1_POSTCODE_IP_9_IP_MASK | \
      MP1_POSTCODE_IP_9_VALID_MASK)

#define MP1_POSTCODE_IP_9_DEFAULT      0x00000000

#define MP1_POSTCODE_IP_9_GET_IP(mp1_postcode_ip_9) \
      ((mp1_postcode_ip_9 & MP1_POSTCODE_IP_9_IP_MASK) >> MP1_POSTCODE_IP_9_IP_SHIFT)
#define MP1_POSTCODE_IP_9_GET_VALID(mp1_postcode_ip_9) \
      ((mp1_postcode_ip_9 & MP1_POSTCODE_IP_9_VALID_MASK) >> MP1_POSTCODE_IP_9_VALID_SHIFT)

#define MP1_POSTCODE_IP_9_SET_IP(mp1_postcode_ip_9_reg, ip) \
      mp1_postcode_ip_9_reg = (mp1_postcode_ip_9_reg & ~MP1_POSTCODE_IP_9_IP_MASK) | (ip << MP1_POSTCODE_IP_9_IP_SHIFT)
#define MP1_POSTCODE_IP_9_SET_VALID(mp1_postcode_ip_9_reg, valid) \
      mp1_postcode_ip_9_reg = (mp1_postcode_ip_9_reg & ~MP1_POSTCODE_IP_9_VALID_MASK) | (valid << MP1_POSTCODE_IP_9_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_ip_9_t {
            unsigned int ip                             : MP1_POSTCODE_IP_9_IP_SIZE;
            unsigned int valid                          : MP1_POSTCODE_IP_9_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_ip_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_ip_9_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_IP_9_VALID_SIZE;
            unsigned int ip                             : MP1_POSTCODE_IP_9_IP_SIZE;
      } mp1_postcode_ip_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_ip_9_t f;
} mp1_postcode_ip_9_u;


/*
 * MP1_POSTCODE_IP_10 struct
 */

#define MP1_POSTCODE_IP_10_REG_SIZE         32
#define MP1_POSTCODE_IP_10_IP_SIZE  8
#define MP1_POSTCODE_IP_10_VALID_SIZE  1

#define MP1_POSTCODE_IP_10_IP_SHIFT  0
#define MP1_POSTCODE_IP_10_VALID_SHIFT  8

#define MP1_POSTCODE_IP_10_IP_MASK      0x000000ff
#define MP1_POSTCODE_IP_10_VALID_MASK   0x00000100

#define MP1_POSTCODE_IP_10_MASK \
      (MP1_POSTCODE_IP_10_IP_MASK | \
      MP1_POSTCODE_IP_10_VALID_MASK)

#define MP1_POSTCODE_IP_10_DEFAULT     0x00000000

#define MP1_POSTCODE_IP_10_GET_IP(mp1_postcode_ip_10) \
      ((mp1_postcode_ip_10 & MP1_POSTCODE_IP_10_IP_MASK) >> MP1_POSTCODE_IP_10_IP_SHIFT)
#define MP1_POSTCODE_IP_10_GET_VALID(mp1_postcode_ip_10) \
      ((mp1_postcode_ip_10 & MP1_POSTCODE_IP_10_VALID_MASK) >> MP1_POSTCODE_IP_10_VALID_SHIFT)

#define MP1_POSTCODE_IP_10_SET_IP(mp1_postcode_ip_10_reg, ip) \
      mp1_postcode_ip_10_reg = (mp1_postcode_ip_10_reg & ~MP1_POSTCODE_IP_10_IP_MASK) | (ip << MP1_POSTCODE_IP_10_IP_SHIFT)
#define MP1_POSTCODE_IP_10_SET_VALID(mp1_postcode_ip_10_reg, valid) \
      mp1_postcode_ip_10_reg = (mp1_postcode_ip_10_reg & ~MP1_POSTCODE_IP_10_VALID_MASK) | (valid << MP1_POSTCODE_IP_10_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_ip_10_t {
            unsigned int ip                             : MP1_POSTCODE_IP_10_IP_SIZE;
            unsigned int valid                          : MP1_POSTCODE_IP_10_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_ip_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_ip_10_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_IP_10_VALID_SIZE;
            unsigned int ip                             : MP1_POSTCODE_IP_10_IP_SIZE;
      } mp1_postcode_ip_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_ip_10_t f;
} mp1_postcode_ip_10_u;


/*
 * MP1_POSTCODE_IP_11 struct
 */

#define MP1_POSTCODE_IP_11_REG_SIZE         32
#define MP1_POSTCODE_IP_11_IP_SIZE  8
#define MP1_POSTCODE_IP_11_VALID_SIZE  1

#define MP1_POSTCODE_IP_11_IP_SHIFT  0
#define MP1_POSTCODE_IP_11_VALID_SHIFT  8

#define MP1_POSTCODE_IP_11_IP_MASK      0x000000ff
#define MP1_POSTCODE_IP_11_VALID_MASK   0x00000100

#define MP1_POSTCODE_IP_11_MASK \
      (MP1_POSTCODE_IP_11_IP_MASK | \
      MP1_POSTCODE_IP_11_VALID_MASK)

#define MP1_POSTCODE_IP_11_DEFAULT     0x00000000

#define MP1_POSTCODE_IP_11_GET_IP(mp1_postcode_ip_11) \
      ((mp1_postcode_ip_11 & MP1_POSTCODE_IP_11_IP_MASK) >> MP1_POSTCODE_IP_11_IP_SHIFT)
#define MP1_POSTCODE_IP_11_GET_VALID(mp1_postcode_ip_11) \
      ((mp1_postcode_ip_11 & MP1_POSTCODE_IP_11_VALID_MASK) >> MP1_POSTCODE_IP_11_VALID_SHIFT)

#define MP1_POSTCODE_IP_11_SET_IP(mp1_postcode_ip_11_reg, ip) \
      mp1_postcode_ip_11_reg = (mp1_postcode_ip_11_reg & ~MP1_POSTCODE_IP_11_IP_MASK) | (ip << MP1_POSTCODE_IP_11_IP_SHIFT)
#define MP1_POSTCODE_IP_11_SET_VALID(mp1_postcode_ip_11_reg, valid) \
      mp1_postcode_ip_11_reg = (mp1_postcode_ip_11_reg & ~MP1_POSTCODE_IP_11_VALID_MASK) | (valid << MP1_POSTCODE_IP_11_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_ip_11_t {
            unsigned int ip                             : MP1_POSTCODE_IP_11_IP_SIZE;
            unsigned int valid                          : MP1_POSTCODE_IP_11_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_ip_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_ip_11_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_IP_11_VALID_SIZE;
            unsigned int ip                             : MP1_POSTCODE_IP_11_IP_SIZE;
      } mp1_postcode_ip_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_ip_11_t f;
} mp1_postcode_ip_11_u;


/*
 * MP1_POSTCODE_IP_12 struct
 */

#define MP1_POSTCODE_IP_12_REG_SIZE         32
#define MP1_POSTCODE_IP_12_IP_SIZE  8
#define MP1_POSTCODE_IP_12_VALID_SIZE  1

#define MP1_POSTCODE_IP_12_IP_SHIFT  0
#define MP1_POSTCODE_IP_12_VALID_SHIFT  8

#define MP1_POSTCODE_IP_12_IP_MASK      0x000000ff
#define MP1_POSTCODE_IP_12_VALID_MASK   0x00000100

#define MP1_POSTCODE_IP_12_MASK \
      (MP1_POSTCODE_IP_12_IP_MASK | \
      MP1_POSTCODE_IP_12_VALID_MASK)

#define MP1_POSTCODE_IP_12_DEFAULT     0x00000000

#define MP1_POSTCODE_IP_12_GET_IP(mp1_postcode_ip_12) \
      ((mp1_postcode_ip_12 & MP1_POSTCODE_IP_12_IP_MASK) >> MP1_POSTCODE_IP_12_IP_SHIFT)
#define MP1_POSTCODE_IP_12_GET_VALID(mp1_postcode_ip_12) \
      ((mp1_postcode_ip_12 & MP1_POSTCODE_IP_12_VALID_MASK) >> MP1_POSTCODE_IP_12_VALID_SHIFT)

#define MP1_POSTCODE_IP_12_SET_IP(mp1_postcode_ip_12_reg, ip) \
      mp1_postcode_ip_12_reg = (mp1_postcode_ip_12_reg & ~MP1_POSTCODE_IP_12_IP_MASK) | (ip << MP1_POSTCODE_IP_12_IP_SHIFT)
#define MP1_POSTCODE_IP_12_SET_VALID(mp1_postcode_ip_12_reg, valid) \
      mp1_postcode_ip_12_reg = (mp1_postcode_ip_12_reg & ~MP1_POSTCODE_IP_12_VALID_MASK) | (valid << MP1_POSTCODE_IP_12_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_ip_12_t {
            unsigned int ip                             : MP1_POSTCODE_IP_12_IP_SIZE;
            unsigned int valid                          : MP1_POSTCODE_IP_12_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_ip_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_ip_12_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_IP_12_VALID_SIZE;
            unsigned int ip                             : MP1_POSTCODE_IP_12_IP_SIZE;
      } mp1_postcode_ip_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_ip_12_t f;
} mp1_postcode_ip_12_u;


/*
 * MP1_POSTCODE_IP_13 struct
 */

#define MP1_POSTCODE_IP_13_REG_SIZE         32
#define MP1_POSTCODE_IP_13_IP_SIZE  8
#define MP1_POSTCODE_IP_13_VALID_SIZE  1

#define MP1_POSTCODE_IP_13_IP_SHIFT  0
#define MP1_POSTCODE_IP_13_VALID_SHIFT  8

#define MP1_POSTCODE_IP_13_IP_MASK      0x000000ff
#define MP1_POSTCODE_IP_13_VALID_MASK   0x00000100

#define MP1_POSTCODE_IP_13_MASK \
      (MP1_POSTCODE_IP_13_IP_MASK | \
      MP1_POSTCODE_IP_13_VALID_MASK)

#define MP1_POSTCODE_IP_13_DEFAULT     0x00000000

#define MP1_POSTCODE_IP_13_GET_IP(mp1_postcode_ip_13) \
      ((mp1_postcode_ip_13 & MP1_POSTCODE_IP_13_IP_MASK) >> MP1_POSTCODE_IP_13_IP_SHIFT)
#define MP1_POSTCODE_IP_13_GET_VALID(mp1_postcode_ip_13) \
      ((mp1_postcode_ip_13 & MP1_POSTCODE_IP_13_VALID_MASK) >> MP1_POSTCODE_IP_13_VALID_SHIFT)

#define MP1_POSTCODE_IP_13_SET_IP(mp1_postcode_ip_13_reg, ip) \
      mp1_postcode_ip_13_reg = (mp1_postcode_ip_13_reg & ~MP1_POSTCODE_IP_13_IP_MASK) | (ip << MP1_POSTCODE_IP_13_IP_SHIFT)
#define MP1_POSTCODE_IP_13_SET_VALID(mp1_postcode_ip_13_reg, valid) \
      mp1_postcode_ip_13_reg = (mp1_postcode_ip_13_reg & ~MP1_POSTCODE_IP_13_VALID_MASK) | (valid << MP1_POSTCODE_IP_13_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_ip_13_t {
            unsigned int ip                             : MP1_POSTCODE_IP_13_IP_SIZE;
            unsigned int valid                          : MP1_POSTCODE_IP_13_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_ip_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_ip_13_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_IP_13_VALID_SIZE;
            unsigned int ip                             : MP1_POSTCODE_IP_13_IP_SIZE;
      } mp1_postcode_ip_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_ip_13_t f;
} mp1_postcode_ip_13_u;


/*
 * MP1_POSTCODE_IP_14 struct
 */

#define MP1_POSTCODE_IP_14_REG_SIZE         32
#define MP1_POSTCODE_IP_14_IP_SIZE  8
#define MP1_POSTCODE_IP_14_VALID_SIZE  1

#define MP1_POSTCODE_IP_14_IP_SHIFT  0
#define MP1_POSTCODE_IP_14_VALID_SHIFT  8

#define MP1_POSTCODE_IP_14_IP_MASK      0x000000ff
#define MP1_POSTCODE_IP_14_VALID_MASK   0x00000100

#define MP1_POSTCODE_IP_14_MASK \
      (MP1_POSTCODE_IP_14_IP_MASK | \
      MP1_POSTCODE_IP_14_VALID_MASK)

#define MP1_POSTCODE_IP_14_DEFAULT     0x00000000

#define MP1_POSTCODE_IP_14_GET_IP(mp1_postcode_ip_14) \
      ((mp1_postcode_ip_14 & MP1_POSTCODE_IP_14_IP_MASK) >> MP1_POSTCODE_IP_14_IP_SHIFT)
#define MP1_POSTCODE_IP_14_GET_VALID(mp1_postcode_ip_14) \
      ((mp1_postcode_ip_14 & MP1_POSTCODE_IP_14_VALID_MASK) >> MP1_POSTCODE_IP_14_VALID_SHIFT)

#define MP1_POSTCODE_IP_14_SET_IP(mp1_postcode_ip_14_reg, ip) \
      mp1_postcode_ip_14_reg = (mp1_postcode_ip_14_reg & ~MP1_POSTCODE_IP_14_IP_MASK) | (ip << MP1_POSTCODE_IP_14_IP_SHIFT)
#define MP1_POSTCODE_IP_14_SET_VALID(mp1_postcode_ip_14_reg, valid) \
      mp1_postcode_ip_14_reg = (mp1_postcode_ip_14_reg & ~MP1_POSTCODE_IP_14_VALID_MASK) | (valid << MP1_POSTCODE_IP_14_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_ip_14_t {
            unsigned int ip                             : MP1_POSTCODE_IP_14_IP_SIZE;
            unsigned int valid                          : MP1_POSTCODE_IP_14_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_ip_14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_ip_14_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_IP_14_VALID_SIZE;
            unsigned int ip                             : MP1_POSTCODE_IP_14_IP_SIZE;
      } mp1_postcode_ip_14_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_ip_14_t f;
} mp1_postcode_ip_14_u;


/*
 * MP1_POSTCODE_IP_15 struct
 */

#define MP1_POSTCODE_IP_15_REG_SIZE         32
#define MP1_POSTCODE_IP_15_IP_SIZE  8
#define MP1_POSTCODE_IP_15_VALID_SIZE  1

#define MP1_POSTCODE_IP_15_IP_SHIFT  0
#define MP1_POSTCODE_IP_15_VALID_SHIFT  8

#define MP1_POSTCODE_IP_15_IP_MASK      0x000000ff
#define MP1_POSTCODE_IP_15_VALID_MASK   0x00000100

#define MP1_POSTCODE_IP_15_MASK \
      (MP1_POSTCODE_IP_15_IP_MASK | \
      MP1_POSTCODE_IP_15_VALID_MASK)

#define MP1_POSTCODE_IP_15_DEFAULT     0x00000000

#define MP1_POSTCODE_IP_15_GET_IP(mp1_postcode_ip_15) \
      ((mp1_postcode_ip_15 & MP1_POSTCODE_IP_15_IP_MASK) >> MP1_POSTCODE_IP_15_IP_SHIFT)
#define MP1_POSTCODE_IP_15_GET_VALID(mp1_postcode_ip_15) \
      ((mp1_postcode_ip_15 & MP1_POSTCODE_IP_15_VALID_MASK) >> MP1_POSTCODE_IP_15_VALID_SHIFT)

#define MP1_POSTCODE_IP_15_SET_IP(mp1_postcode_ip_15_reg, ip) \
      mp1_postcode_ip_15_reg = (mp1_postcode_ip_15_reg & ~MP1_POSTCODE_IP_15_IP_MASK) | (ip << MP1_POSTCODE_IP_15_IP_SHIFT)
#define MP1_POSTCODE_IP_15_SET_VALID(mp1_postcode_ip_15_reg, valid) \
      mp1_postcode_ip_15_reg = (mp1_postcode_ip_15_reg & ~MP1_POSTCODE_IP_15_VALID_MASK) | (valid << MP1_POSTCODE_IP_15_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_ip_15_t {
            unsigned int ip                             : MP1_POSTCODE_IP_15_IP_SIZE;
            unsigned int valid                          : MP1_POSTCODE_IP_15_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_ip_15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_ip_15_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_IP_15_VALID_SIZE;
            unsigned int ip                             : MP1_POSTCODE_IP_15_IP_SIZE;
      } mp1_postcode_ip_15_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_ip_15_t f;
} mp1_postcode_ip_15_u;


/*
 * MP1_POSTCODE_FEATURE_0 struct
 */

#define MP1_POSTCODE_FEATURE_0_REG_SIZE         32
#define MP1_POSTCODE_FEATURE_0_FEATURE_SIZE  8
#define MP1_POSTCODE_FEATURE_0_VALID_SIZE  1

#define MP1_POSTCODE_FEATURE_0_FEATURE_SHIFT  0
#define MP1_POSTCODE_FEATURE_0_VALID_SHIFT  8

#define MP1_POSTCODE_FEATURE_0_FEATURE_MASK  0x000000ff
#define MP1_POSTCODE_FEATURE_0_VALID_MASK  0x00000100

#define MP1_POSTCODE_FEATURE_0_MASK \
      (MP1_POSTCODE_FEATURE_0_FEATURE_MASK | \
      MP1_POSTCODE_FEATURE_0_VALID_MASK)

#define MP1_POSTCODE_FEATURE_0_DEFAULT 0x00000000

#define MP1_POSTCODE_FEATURE_0_GET_FEATURE(mp1_postcode_feature_0) \
      ((mp1_postcode_feature_0 & MP1_POSTCODE_FEATURE_0_FEATURE_MASK) >> MP1_POSTCODE_FEATURE_0_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_0_GET_VALID(mp1_postcode_feature_0) \
      ((mp1_postcode_feature_0 & MP1_POSTCODE_FEATURE_0_VALID_MASK) >> MP1_POSTCODE_FEATURE_0_VALID_SHIFT)

#define MP1_POSTCODE_FEATURE_0_SET_FEATURE(mp1_postcode_feature_0_reg, feature) \
      mp1_postcode_feature_0_reg = (mp1_postcode_feature_0_reg & ~MP1_POSTCODE_FEATURE_0_FEATURE_MASK) | (feature << MP1_POSTCODE_FEATURE_0_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_0_SET_VALID(mp1_postcode_feature_0_reg, valid) \
      mp1_postcode_feature_0_reg = (mp1_postcode_feature_0_reg & ~MP1_POSTCODE_FEATURE_0_VALID_MASK) | (valid << MP1_POSTCODE_FEATURE_0_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_feature_0_t {
            unsigned int feature                        : MP1_POSTCODE_FEATURE_0_FEATURE_SIZE;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_0_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_feature_0_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_feature_0_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_0_VALID_SIZE;
            unsigned int feature                        : MP1_POSTCODE_FEATURE_0_FEATURE_SIZE;
      } mp1_postcode_feature_0_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_feature_0_t f;
} mp1_postcode_feature_0_u;


/*
 * MP1_POSTCODE_FEATURE_1 struct
 */

#define MP1_POSTCODE_FEATURE_1_REG_SIZE         32
#define MP1_POSTCODE_FEATURE_1_FEATURE_SIZE  8
#define MP1_POSTCODE_FEATURE_1_VALID_SIZE  1

#define MP1_POSTCODE_FEATURE_1_FEATURE_SHIFT  0
#define MP1_POSTCODE_FEATURE_1_VALID_SHIFT  8

#define MP1_POSTCODE_FEATURE_1_FEATURE_MASK  0x000000ff
#define MP1_POSTCODE_FEATURE_1_VALID_MASK  0x00000100

#define MP1_POSTCODE_FEATURE_1_MASK \
      (MP1_POSTCODE_FEATURE_1_FEATURE_MASK | \
      MP1_POSTCODE_FEATURE_1_VALID_MASK)

#define MP1_POSTCODE_FEATURE_1_DEFAULT 0x00000000

#define MP1_POSTCODE_FEATURE_1_GET_FEATURE(mp1_postcode_feature_1) \
      ((mp1_postcode_feature_1 & MP1_POSTCODE_FEATURE_1_FEATURE_MASK) >> MP1_POSTCODE_FEATURE_1_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_1_GET_VALID(mp1_postcode_feature_1) \
      ((mp1_postcode_feature_1 & MP1_POSTCODE_FEATURE_1_VALID_MASK) >> MP1_POSTCODE_FEATURE_1_VALID_SHIFT)

#define MP1_POSTCODE_FEATURE_1_SET_FEATURE(mp1_postcode_feature_1_reg, feature) \
      mp1_postcode_feature_1_reg = (mp1_postcode_feature_1_reg & ~MP1_POSTCODE_FEATURE_1_FEATURE_MASK) | (feature << MP1_POSTCODE_FEATURE_1_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_1_SET_VALID(mp1_postcode_feature_1_reg, valid) \
      mp1_postcode_feature_1_reg = (mp1_postcode_feature_1_reg & ~MP1_POSTCODE_FEATURE_1_VALID_MASK) | (valid << MP1_POSTCODE_FEATURE_1_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_feature_1_t {
            unsigned int feature                        : MP1_POSTCODE_FEATURE_1_FEATURE_SIZE;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_1_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_feature_1_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_feature_1_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_1_VALID_SIZE;
            unsigned int feature                        : MP1_POSTCODE_FEATURE_1_FEATURE_SIZE;
      } mp1_postcode_feature_1_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_feature_1_t f;
} mp1_postcode_feature_1_u;


/*
 * MP1_POSTCODE_FEATURE_2 struct
 */

#define MP1_POSTCODE_FEATURE_2_REG_SIZE         32
#define MP1_POSTCODE_FEATURE_2_FEATURE_SIZE  8
#define MP1_POSTCODE_FEATURE_2_VALID_SIZE  1

#define MP1_POSTCODE_FEATURE_2_FEATURE_SHIFT  0
#define MP1_POSTCODE_FEATURE_2_VALID_SHIFT  8

#define MP1_POSTCODE_FEATURE_2_FEATURE_MASK  0x000000ff
#define MP1_POSTCODE_FEATURE_2_VALID_MASK  0x00000100

#define MP1_POSTCODE_FEATURE_2_MASK \
      (MP1_POSTCODE_FEATURE_2_FEATURE_MASK | \
      MP1_POSTCODE_FEATURE_2_VALID_MASK)

#define MP1_POSTCODE_FEATURE_2_DEFAULT 0x00000000

#define MP1_POSTCODE_FEATURE_2_GET_FEATURE(mp1_postcode_feature_2) \
      ((mp1_postcode_feature_2 & MP1_POSTCODE_FEATURE_2_FEATURE_MASK) >> MP1_POSTCODE_FEATURE_2_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_2_GET_VALID(mp1_postcode_feature_2) \
      ((mp1_postcode_feature_2 & MP1_POSTCODE_FEATURE_2_VALID_MASK) >> MP1_POSTCODE_FEATURE_2_VALID_SHIFT)

#define MP1_POSTCODE_FEATURE_2_SET_FEATURE(mp1_postcode_feature_2_reg, feature) \
      mp1_postcode_feature_2_reg = (mp1_postcode_feature_2_reg & ~MP1_POSTCODE_FEATURE_2_FEATURE_MASK) | (feature << MP1_POSTCODE_FEATURE_2_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_2_SET_VALID(mp1_postcode_feature_2_reg, valid) \
      mp1_postcode_feature_2_reg = (mp1_postcode_feature_2_reg & ~MP1_POSTCODE_FEATURE_2_VALID_MASK) | (valid << MP1_POSTCODE_FEATURE_2_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_feature_2_t {
            unsigned int feature                        : MP1_POSTCODE_FEATURE_2_FEATURE_SIZE;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_2_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_feature_2_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_feature_2_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_2_VALID_SIZE;
            unsigned int feature                        : MP1_POSTCODE_FEATURE_2_FEATURE_SIZE;
      } mp1_postcode_feature_2_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_feature_2_t f;
} mp1_postcode_feature_2_u;


/*
 * MP1_POSTCODE_FEATURE_3 struct
 */

#define MP1_POSTCODE_FEATURE_3_REG_SIZE         32
#define MP1_POSTCODE_FEATURE_3_FEATURE_SIZE  8
#define MP1_POSTCODE_FEATURE_3_VALID_SIZE  1

#define MP1_POSTCODE_FEATURE_3_FEATURE_SHIFT  0
#define MP1_POSTCODE_FEATURE_3_VALID_SHIFT  8

#define MP1_POSTCODE_FEATURE_3_FEATURE_MASK  0x000000ff
#define MP1_POSTCODE_FEATURE_3_VALID_MASK  0x00000100

#define MP1_POSTCODE_FEATURE_3_MASK \
      (MP1_POSTCODE_FEATURE_3_FEATURE_MASK | \
      MP1_POSTCODE_FEATURE_3_VALID_MASK)

#define MP1_POSTCODE_FEATURE_3_DEFAULT 0x00000000

#define MP1_POSTCODE_FEATURE_3_GET_FEATURE(mp1_postcode_feature_3) \
      ((mp1_postcode_feature_3 & MP1_POSTCODE_FEATURE_3_FEATURE_MASK) >> MP1_POSTCODE_FEATURE_3_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_3_GET_VALID(mp1_postcode_feature_3) \
      ((mp1_postcode_feature_3 & MP1_POSTCODE_FEATURE_3_VALID_MASK) >> MP1_POSTCODE_FEATURE_3_VALID_SHIFT)

#define MP1_POSTCODE_FEATURE_3_SET_FEATURE(mp1_postcode_feature_3_reg, feature) \
      mp1_postcode_feature_3_reg = (mp1_postcode_feature_3_reg & ~MP1_POSTCODE_FEATURE_3_FEATURE_MASK) | (feature << MP1_POSTCODE_FEATURE_3_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_3_SET_VALID(mp1_postcode_feature_3_reg, valid) \
      mp1_postcode_feature_3_reg = (mp1_postcode_feature_3_reg & ~MP1_POSTCODE_FEATURE_3_VALID_MASK) | (valid << MP1_POSTCODE_FEATURE_3_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_feature_3_t {
            unsigned int feature                        : MP1_POSTCODE_FEATURE_3_FEATURE_SIZE;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_3_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_feature_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_feature_3_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_3_VALID_SIZE;
            unsigned int feature                        : MP1_POSTCODE_FEATURE_3_FEATURE_SIZE;
      } mp1_postcode_feature_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_feature_3_t f;
} mp1_postcode_feature_3_u;


/*
 * MP1_POSTCODE_FEATURE_4 struct
 */

#define MP1_POSTCODE_FEATURE_4_REG_SIZE         32
#define MP1_POSTCODE_FEATURE_4_FEATURE_SIZE  8
#define MP1_POSTCODE_FEATURE_4_VALID_SIZE  1

#define MP1_POSTCODE_FEATURE_4_FEATURE_SHIFT  0
#define MP1_POSTCODE_FEATURE_4_VALID_SHIFT  8

#define MP1_POSTCODE_FEATURE_4_FEATURE_MASK  0x000000ff
#define MP1_POSTCODE_FEATURE_4_VALID_MASK  0x00000100

#define MP1_POSTCODE_FEATURE_4_MASK \
      (MP1_POSTCODE_FEATURE_4_FEATURE_MASK | \
      MP1_POSTCODE_FEATURE_4_VALID_MASK)

#define MP1_POSTCODE_FEATURE_4_DEFAULT 0x00000000

#define MP1_POSTCODE_FEATURE_4_GET_FEATURE(mp1_postcode_feature_4) \
      ((mp1_postcode_feature_4 & MP1_POSTCODE_FEATURE_4_FEATURE_MASK) >> MP1_POSTCODE_FEATURE_4_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_4_GET_VALID(mp1_postcode_feature_4) \
      ((mp1_postcode_feature_4 & MP1_POSTCODE_FEATURE_4_VALID_MASK) >> MP1_POSTCODE_FEATURE_4_VALID_SHIFT)

#define MP1_POSTCODE_FEATURE_4_SET_FEATURE(mp1_postcode_feature_4_reg, feature) \
      mp1_postcode_feature_4_reg = (mp1_postcode_feature_4_reg & ~MP1_POSTCODE_FEATURE_4_FEATURE_MASK) | (feature << MP1_POSTCODE_FEATURE_4_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_4_SET_VALID(mp1_postcode_feature_4_reg, valid) \
      mp1_postcode_feature_4_reg = (mp1_postcode_feature_4_reg & ~MP1_POSTCODE_FEATURE_4_VALID_MASK) | (valid << MP1_POSTCODE_FEATURE_4_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_feature_4_t {
            unsigned int feature                        : MP1_POSTCODE_FEATURE_4_FEATURE_SIZE;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_4_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_feature_4_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_feature_4_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_4_VALID_SIZE;
            unsigned int feature                        : MP1_POSTCODE_FEATURE_4_FEATURE_SIZE;
      } mp1_postcode_feature_4_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_feature_4_t f;
} mp1_postcode_feature_4_u;


/*
 * MP1_POSTCODE_FEATURE_5 struct
 */

#define MP1_POSTCODE_FEATURE_5_REG_SIZE         32
#define MP1_POSTCODE_FEATURE_5_FEATURE_SIZE  8
#define MP1_POSTCODE_FEATURE_5_VALID_SIZE  1

#define MP1_POSTCODE_FEATURE_5_FEATURE_SHIFT  0
#define MP1_POSTCODE_FEATURE_5_VALID_SHIFT  8

#define MP1_POSTCODE_FEATURE_5_FEATURE_MASK  0x000000ff
#define MP1_POSTCODE_FEATURE_5_VALID_MASK  0x00000100

#define MP1_POSTCODE_FEATURE_5_MASK \
      (MP1_POSTCODE_FEATURE_5_FEATURE_MASK | \
      MP1_POSTCODE_FEATURE_5_VALID_MASK)

#define MP1_POSTCODE_FEATURE_5_DEFAULT 0x00000000

#define MP1_POSTCODE_FEATURE_5_GET_FEATURE(mp1_postcode_feature_5) \
      ((mp1_postcode_feature_5 & MP1_POSTCODE_FEATURE_5_FEATURE_MASK) >> MP1_POSTCODE_FEATURE_5_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_5_GET_VALID(mp1_postcode_feature_5) \
      ((mp1_postcode_feature_5 & MP1_POSTCODE_FEATURE_5_VALID_MASK) >> MP1_POSTCODE_FEATURE_5_VALID_SHIFT)

#define MP1_POSTCODE_FEATURE_5_SET_FEATURE(mp1_postcode_feature_5_reg, feature) \
      mp1_postcode_feature_5_reg = (mp1_postcode_feature_5_reg & ~MP1_POSTCODE_FEATURE_5_FEATURE_MASK) | (feature << MP1_POSTCODE_FEATURE_5_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_5_SET_VALID(mp1_postcode_feature_5_reg, valid) \
      mp1_postcode_feature_5_reg = (mp1_postcode_feature_5_reg & ~MP1_POSTCODE_FEATURE_5_VALID_MASK) | (valid << MP1_POSTCODE_FEATURE_5_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_feature_5_t {
            unsigned int feature                        : MP1_POSTCODE_FEATURE_5_FEATURE_SIZE;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_5_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_feature_5_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_feature_5_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_5_VALID_SIZE;
            unsigned int feature                        : MP1_POSTCODE_FEATURE_5_FEATURE_SIZE;
      } mp1_postcode_feature_5_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_feature_5_t f;
} mp1_postcode_feature_5_u;


/*
 * MP1_POSTCODE_FEATURE_6 struct
 */

#define MP1_POSTCODE_FEATURE_6_REG_SIZE         32
#define MP1_POSTCODE_FEATURE_6_FEATURE_SIZE  8
#define MP1_POSTCODE_FEATURE_6_VALID_SIZE  1

#define MP1_POSTCODE_FEATURE_6_FEATURE_SHIFT  0
#define MP1_POSTCODE_FEATURE_6_VALID_SHIFT  8

#define MP1_POSTCODE_FEATURE_6_FEATURE_MASK  0x000000ff
#define MP1_POSTCODE_FEATURE_6_VALID_MASK  0x00000100

#define MP1_POSTCODE_FEATURE_6_MASK \
      (MP1_POSTCODE_FEATURE_6_FEATURE_MASK | \
      MP1_POSTCODE_FEATURE_6_VALID_MASK)

#define MP1_POSTCODE_FEATURE_6_DEFAULT 0x00000000

#define MP1_POSTCODE_FEATURE_6_GET_FEATURE(mp1_postcode_feature_6) \
      ((mp1_postcode_feature_6 & MP1_POSTCODE_FEATURE_6_FEATURE_MASK) >> MP1_POSTCODE_FEATURE_6_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_6_GET_VALID(mp1_postcode_feature_6) \
      ((mp1_postcode_feature_6 & MP1_POSTCODE_FEATURE_6_VALID_MASK) >> MP1_POSTCODE_FEATURE_6_VALID_SHIFT)

#define MP1_POSTCODE_FEATURE_6_SET_FEATURE(mp1_postcode_feature_6_reg, feature) \
      mp1_postcode_feature_6_reg = (mp1_postcode_feature_6_reg & ~MP1_POSTCODE_FEATURE_6_FEATURE_MASK) | (feature << MP1_POSTCODE_FEATURE_6_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_6_SET_VALID(mp1_postcode_feature_6_reg, valid) \
      mp1_postcode_feature_6_reg = (mp1_postcode_feature_6_reg & ~MP1_POSTCODE_FEATURE_6_VALID_MASK) | (valid << MP1_POSTCODE_FEATURE_6_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_feature_6_t {
            unsigned int feature                        : MP1_POSTCODE_FEATURE_6_FEATURE_SIZE;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_6_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_feature_6_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_feature_6_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_6_VALID_SIZE;
            unsigned int feature                        : MP1_POSTCODE_FEATURE_6_FEATURE_SIZE;
      } mp1_postcode_feature_6_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_feature_6_t f;
} mp1_postcode_feature_6_u;


/*
 * MP1_POSTCODE_FEATURE_7 struct
 */

#define MP1_POSTCODE_FEATURE_7_REG_SIZE         32
#define MP1_POSTCODE_FEATURE_7_FEATURE_SIZE  8
#define MP1_POSTCODE_FEATURE_7_VALID_SIZE  1

#define MP1_POSTCODE_FEATURE_7_FEATURE_SHIFT  0
#define MP1_POSTCODE_FEATURE_7_VALID_SHIFT  8

#define MP1_POSTCODE_FEATURE_7_FEATURE_MASK  0x000000ff
#define MP1_POSTCODE_FEATURE_7_VALID_MASK  0x00000100

#define MP1_POSTCODE_FEATURE_7_MASK \
      (MP1_POSTCODE_FEATURE_7_FEATURE_MASK | \
      MP1_POSTCODE_FEATURE_7_VALID_MASK)

#define MP1_POSTCODE_FEATURE_7_DEFAULT 0x00000000

#define MP1_POSTCODE_FEATURE_7_GET_FEATURE(mp1_postcode_feature_7) \
      ((mp1_postcode_feature_7 & MP1_POSTCODE_FEATURE_7_FEATURE_MASK) >> MP1_POSTCODE_FEATURE_7_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_7_GET_VALID(mp1_postcode_feature_7) \
      ((mp1_postcode_feature_7 & MP1_POSTCODE_FEATURE_7_VALID_MASK) >> MP1_POSTCODE_FEATURE_7_VALID_SHIFT)

#define MP1_POSTCODE_FEATURE_7_SET_FEATURE(mp1_postcode_feature_7_reg, feature) \
      mp1_postcode_feature_7_reg = (mp1_postcode_feature_7_reg & ~MP1_POSTCODE_FEATURE_7_FEATURE_MASK) | (feature << MP1_POSTCODE_FEATURE_7_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_7_SET_VALID(mp1_postcode_feature_7_reg, valid) \
      mp1_postcode_feature_7_reg = (mp1_postcode_feature_7_reg & ~MP1_POSTCODE_FEATURE_7_VALID_MASK) | (valid << MP1_POSTCODE_FEATURE_7_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_feature_7_t {
            unsigned int feature                        : MP1_POSTCODE_FEATURE_7_FEATURE_SIZE;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_7_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_feature_7_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_feature_7_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_7_VALID_SIZE;
            unsigned int feature                        : MP1_POSTCODE_FEATURE_7_FEATURE_SIZE;
      } mp1_postcode_feature_7_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_feature_7_t f;
} mp1_postcode_feature_7_u;


/*
 * MP1_POSTCODE_FEATURE_8 struct
 */

#define MP1_POSTCODE_FEATURE_8_REG_SIZE         32
#define MP1_POSTCODE_FEATURE_8_FEATURE_SIZE  8
#define MP1_POSTCODE_FEATURE_8_VALID_SIZE  1

#define MP1_POSTCODE_FEATURE_8_FEATURE_SHIFT  0
#define MP1_POSTCODE_FEATURE_8_VALID_SHIFT  8

#define MP1_POSTCODE_FEATURE_8_FEATURE_MASK  0x000000ff
#define MP1_POSTCODE_FEATURE_8_VALID_MASK  0x00000100

#define MP1_POSTCODE_FEATURE_8_MASK \
      (MP1_POSTCODE_FEATURE_8_FEATURE_MASK | \
      MP1_POSTCODE_FEATURE_8_VALID_MASK)

#define MP1_POSTCODE_FEATURE_8_DEFAULT 0x00000000

#define MP1_POSTCODE_FEATURE_8_GET_FEATURE(mp1_postcode_feature_8) \
      ((mp1_postcode_feature_8 & MP1_POSTCODE_FEATURE_8_FEATURE_MASK) >> MP1_POSTCODE_FEATURE_8_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_8_GET_VALID(mp1_postcode_feature_8) \
      ((mp1_postcode_feature_8 & MP1_POSTCODE_FEATURE_8_VALID_MASK) >> MP1_POSTCODE_FEATURE_8_VALID_SHIFT)

#define MP1_POSTCODE_FEATURE_8_SET_FEATURE(mp1_postcode_feature_8_reg, feature) \
      mp1_postcode_feature_8_reg = (mp1_postcode_feature_8_reg & ~MP1_POSTCODE_FEATURE_8_FEATURE_MASK) | (feature << MP1_POSTCODE_FEATURE_8_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_8_SET_VALID(mp1_postcode_feature_8_reg, valid) \
      mp1_postcode_feature_8_reg = (mp1_postcode_feature_8_reg & ~MP1_POSTCODE_FEATURE_8_VALID_MASK) | (valid << MP1_POSTCODE_FEATURE_8_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_feature_8_t {
            unsigned int feature                        : MP1_POSTCODE_FEATURE_8_FEATURE_SIZE;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_8_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_feature_8_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_feature_8_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_8_VALID_SIZE;
            unsigned int feature                        : MP1_POSTCODE_FEATURE_8_FEATURE_SIZE;
      } mp1_postcode_feature_8_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_feature_8_t f;
} mp1_postcode_feature_8_u;


/*
 * MP1_POSTCODE_FEATURE_9 struct
 */

#define MP1_POSTCODE_FEATURE_9_REG_SIZE         32
#define MP1_POSTCODE_FEATURE_9_FEATURE_SIZE  8
#define MP1_POSTCODE_FEATURE_9_VALID_SIZE  1

#define MP1_POSTCODE_FEATURE_9_FEATURE_SHIFT  0
#define MP1_POSTCODE_FEATURE_9_VALID_SHIFT  8

#define MP1_POSTCODE_FEATURE_9_FEATURE_MASK  0x000000ff
#define MP1_POSTCODE_FEATURE_9_VALID_MASK  0x00000100

#define MP1_POSTCODE_FEATURE_9_MASK \
      (MP1_POSTCODE_FEATURE_9_FEATURE_MASK | \
      MP1_POSTCODE_FEATURE_9_VALID_MASK)

#define MP1_POSTCODE_FEATURE_9_DEFAULT 0x00000000

#define MP1_POSTCODE_FEATURE_9_GET_FEATURE(mp1_postcode_feature_9) \
      ((mp1_postcode_feature_9 & MP1_POSTCODE_FEATURE_9_FEATURE_MASK) >> MP1_POSTCODE_FEATURE_9_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_9_GET_VALID(mp1_postcode_feature_9) \
      ((mp1_postcode_feature_9 & MP1_POSTCODE_FEATURE_9_VALID_MASK) >> MP1_POSTCODE_FEATURE_9_VALID_SHIFT)

#define MP1_POSTCODE_FEATURE_9_SET_FEATURE(mp1_postcode_feature_9_reg, feature) \
      mp1_postcode_feature_9_reg = (mp1_postcode_feature_9_reg & ~MP1_POSTCODE_FEATURE_9_FEATURE_MASK) | (feature << MP1_POSTCODE_FEATURE_9_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_9_SET_VALID(mp1_postcode_feature_9_reg, valid) \
      mp1_postcode_feature_9_reg = (mp1_postcode_feature_9_reg & ~MP1_POSTCODE_FEATURE_9_VALID_MASK) | (valid << MP1_POSTCODE_FEATURE_9_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_feature_9_t {
            unsigned int feature                        : MP1_POSTCODE_FEATURE_9_FEATURE_SIZE;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_9_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_feature_9_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_feature_9_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_9_VALID_SIZE;
            unsigned int feature                        : MP1_POSTCODE_FEATURE_9_FEATURE_SIZE;
      } mp1_postcode_feature_9_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_feature_9_t f;
} mp1_postcode_feature_9_u;


/*
 * MP1_POSTCODE_FEATURE_10 struct
 */

#define MP1_POSTCODE_FEATURE_10_REG_SIZE         32
#define MP1_POSTCODE_FEATURE_10_FEATURE_SIZE  8
#define MP1_POSTCODE_FEATURE_10_VALID_SIZE  1

#define MP1_POSTCODE_FEATURE_10_FEATURE_SHIFT  0
#define MP1_POSTCODE_FEATURE_10_VALID_SHIFT  8

#define MP1_POSTCODE_FEATURE_10_FEATURE_MASK  0x000000ff
#define MP1_POSTCODE_FEATURE_10_VALID_MASK  0x00000100

#define MP1_POSTCODE_FEATURE_10_MASK \
      (MP1_POSTCODE_FEATURE_10_FEATURE_MASK | \
      MP1_POSTCODE_FEATURE_10_VALID_MASK)

#define MP1_POSTCODE_FEATURE_10_DEFAULT 0x00000000

#define MP1_POSTCODE_FEATURE_10_GET_FEATURE(mp1_postcode_feature_10) \
      ((mp1_postcode_feature_10 & MP1_POSTCODE_FEATURE_10_FEATURE_MASK) >> MP1_POSTCODE_FEATURE_10_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_10_GET_VALID(mp1_postcode_feature_10) \
      ((mp1_postcode_feature_10 & MP1_POSTCODE_FEATURE_10_VALID_MASK) >> MP1_POSTCODE_FEATURE_10_VALID_SHIFT)

#define MP1_POSTCODE_FEATURE_10_SET_FEATURE(mp1_postcode_feature_10_reg, feature) \
      mp1_postcode_feature_10_reg = (mp1_postcode_feature_10_reg & ~MP1_POSTCODE_FEATURE_10_FEATURE_MASK) | (feature << MP1_POSTCODE_FEATURE_10_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_10_SET_VALID(mp1_postcode_feature_10_reg, valid) \
      mp1_postcode_feature_10_reg = (mp1_postcode_feature_10_reg & ~MP1_POSTCODE_FEATURE_10_VALID_MASK) | (valid << MP1_POSTCODE_FEATURE_10_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_feature_10_t {
            unsigned int feature                        : MP1_POSTCODE_FEATURE_10_FEATURE_SIZE;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_10_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_feature_10_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_feature_10_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_10_VALID_SIZE;
            unsigned int feature                        : MP1_POSTCODE_FEATURE_10_FEATURE_SIZE;
      } mp1_postcode_feature_10_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_feature_10_t f;
} mp1_postcode_feature_10_u;


/*
 * MP1_POSTCODE_FEATURE_11 struct
 */

#define MP1_POSTCODE_FEATURE_11_REG_SIZE         32
#define MP1_POSTCODE_FEATURE_11_FEATURE_SIZE  8
#define MP1_POSTCODE_FEATURE_11_VALID_SIZE  1

#define MP1_POSTCODE_FEATURE_11_FEATURE_SHIFT  0
#define MP1_POSTCODE_FEATURE_11_VALID_SHIFT  8

#define MP1_POSTCODE_FEATURE_11_FEATURE_MASK  0x000000ff
#define MP1_POSTCODE_FEATURE_11_VALID_MASK  0x00000100

#define MP1_POSTCODE_FEATURE_11_MASK \
      (MP1_POSTCODE_FEATURE_11_FEATURE_MASK | \
      MP1_POSTCODE_FEATURE_11_VALID_MASK)

#define MP1_POSTCODE_FEATURE_11_DEFAULT 0x00000000

#define MP1_POSTCODE_FEATURE_11_GET_FEATURE(mp1_postcode_feature_11) \
      ((mp1_postcode_feature_11 & MP1_POSTCODE_FEATURE_11_FEATURE_MASK) >> MP1_POSTCODE_FEATURE_11_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_11_GET_VALID(mp1_postcode_feature_11) \
      ((mp1_postcode_feature_11 & MP1_POSTCODE_FEATURE_11_VALID_MASK) >> MP1_POSTCODE_FEATURE_11_VALID_SHIFT)

#define MP1_POSTCODE_FEATURE_11_SET_FEATURE(mp1_postcode_feature_11_reg, feature) \
      mp1_postcode_feature_11_reg = (mp1_postcode_feature_11_reg & ~MP1_POSTCODE_FEATURE_11_FEATURE_MASK) | (feature << MP1_POSTCODE_FEATURE_11_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_11_SET_VALID(mp1_postcode_feature_11_reg, valid) \
      mp1_postcode_feature_11_reg = (mp1_postcode_feature_11_reg & ~MP1_POSTCODE_FEATURE_11_VALID_MASK) | (valid << MP1_POSTCODE_FEATURE_11_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_feature_11_t {
            unsigned int feature                        : MP1_POSTCODE_FEATURE_11_FEATURE_SIZE;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_11_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_feature_11_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_feature_11_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_11_VALID_SIZE;
            unsigned int feature                        : MP1_POSTCODE_FEATURE_11_FEATURE_SIZE;
      } mp1_postcode_feature_11_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_feature_11_t f;
} mp1_postcode_feature_11_u;


/*
 * MP1_POSTCODE_FEATURE_12 struct
 */

#define MP1_POSTCODE_FEATURE_12_REG_SIZE         32
#define MP1_POSTCODE_FEATURE_12_FEATURE_SIZE  8
#define MP1_POSTCODE_FEATURE_12_VALID_SIZE  1

#define MP1_POSTCODE_FEATURE_12_FEATURE_SHIFT  0
#define MP1_POSTCODE_FEATURE_12_VALID_SHIFT  8

#define MP1_POSTCODE_FEATURE_12_FEATURE_MASK  0x000000ff
#define MP1_POSTCODE_FEATURE_12_VALID_MASK  0x00000100

#define MP1_POSTCODE_FEATURE_12_MASK \
      (MP1_POSTCODE_FEATURE_12_FEATURE_MASK | \
      MP1_POSTCODE_FEATURE_12_VALID_MASK)

#define MP1_POSTCODE_FEATURE_12_DEFAULT 0x00000000

#define MP1_POSTCODE_FEATURE_12_GET_FEATURE(mp1_postcode_feature_12) \
      ((mp1_postcode_feature_12 & MP1_POSTCODE_FEATURE_12_FEATURE_MASK) >> MP1_POSTCODE_FEATURE_12_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_12_GET_VALID(mp1_postcode_feature_12) \
      ((mp1_postcode_feature_12 & MP1_POSTCODE_FEATURE_12_VALID_MASK) >> MP1_POSTCODE_FEATURE_12_VALID_SHIFT)

#define MP1_POSTCODE_FEATURE_12_SET_FEATURE(mp1_postcode_feature_12_reg, feature) \
      mp1_postcode_feature_12_reg = (mp1_postcode_feature_12_reg & ~MP1_POSTCODE_FEATURE_12_FEATURE_MASK) | (feature << MP1_POSTCODE_FEATURE_12_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_12_SET_VALID(mp1_postcode_feature_12_reg, valid) \
      mp1_postcode_feature_12_reg = (mp1_postcode_feature_12_reg & ~MP1_POSTCODE_FEATURE_12_VALID_MASK) | (valid << MP1_POSTCODE_FEATURE_12_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_feature_12_t {
            unsigned int feature                        : MP1_POSTCODE_FEATURE_12_FEATURE_SIZE;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_12_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_feature_12_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_feature_12_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_12_VALID_SIZE;
            unsigned int feature                        : MP1_POSTCODE_FEATURE_12_FEATURE_SIZE;
      } mp1_postcode_feature_12_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_feature_12_t f;
} mp1_postcode_feature_12_u;


/*
 * MP1_POSTCODE_FEATURE_13 struct
 */

#define MP1_POSTCODE_FEATURE_13_REG_SIZE         32
#define MP1_POSTCODE_FEATURE_13_FEATURE_SIZE  8
#define MP1_POSTCODE_FEATURE_13_VALID_SIZE  1

#define MP1_POSTCODE_FEATURE_13_FEATURE_SHIFT  0
#define MP1_POSTCODE_FEATURE_13_VALID_SHIFT  8

#define MP1_POSTCODE_FEATURE_13_FEATURE_MASK  0x000000ff
#define MP1_POSTCODE_FEATURE_13_VALID_MASK  0x00000100

#define MP1_POSTCODE_FEATURE_13_MASK \
      (MP1_POSTCODE_FEATURE_13_FEATURE_MASK | \
      MP1_POSTCODE_FEATURE_13_VALID_MASK)

#define MP1_POSTCODE_FEATURE_13_DEFAULT 0x00000000

#define MP1_POSTCODE_FEATURE_13_GET_FEATURE(mp1_postcode_feature_13) \
      ((mp1_postcode_feature_13 & MP1_POSTCODE_FEATURE_13_FEATURE_MASK) >> MP1_POSTCODE_FEATURE_13_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_13_GET_VALID(mp1_postcode_feature_13) \
      ((mp1_postcode_feature_13 & MP1_POSTCODE_FEATURE_13_VALID_MASK) >> MP1_POSTCODE_FEATURE_13_VALID_SHIFT)

#define MP1_POSTCODE_FEATURE_13_SET_FEATURE(mp1_postcode_feature_13_reg, feature) \
      mp1_postcode_feature_13_reg = (mp1_postcode_feature_13_reg & ~MP1_POSTCODE_FEATURE_13_FEATURE_MASK) | (feature << MP1_POSTCODE_FEATURE_13_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_13_SET_VALID(mp1_postcode_feature_13_reg, valid) \
      mp1_postcode_feature_13_reg = (mp1_postcode_feature_13_reg & ~MP1_POSTCODE_FEATURE_13_VALID_MASK) | (valid << MP1_POSTCODE_FEATURE_13_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_feature_13_t {
            unsigned int feature                        : MP1_POSTCODE_FEATURE_13_FEATURE_SIZE;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_13_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_feature_13_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_feature_13_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_13_VALID_SIZE;
            unsigned int feature                        : MP1_POSTCODE_FEATURE_13_FEATURE_SIZE;
      } mp1_postcode_feature_13_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_feature_13_t f;
} mp1_postcode_feature_13_u;


/*
 * MP1_POSTCODE_FEATURE_14 struct
 */

#define MP1_POSTCODE_FEATURE_14_REG_SIZE         32
#define MP1_POSTCODE_FEATURE_14_FEATURE_SIZE  8
#define MP1_POSTCODE_FEATURE_14_VALID_SIZE  1

#define MP1_POSTCODE_FEATURE_14_FEATURE_SHIFT  0
#define MP1_POSTCODE_FEATURE_14_VALID_SHIFT  8

#define MP1_POSTCODE_FEATURE_14_FEATURE_MASK  0x000000ff
#define MP1_POSTCODE_FEATURE_14_VALID_MASK  0x00000100

#define MP1_POSTCODE_FEATURE_14_MASK \
      (MP1_POSTCODE_FEATURE_14_FEATURE_MASK | \
      MP1_POSTCODE_FEATURE_14_VALID_MASK)

#define MP1_POSTCODE_FEATURE_14_DEFAULT 0x00000000

#define MP1_POSTCODE_FEATURE_14_GET_FEATURE(mp1_postcode_feature_14) \
      ((mp1_postcode_feature_14 & MP1_POSTCODE_FEATURE_14_FEATURE_MASK) >> MP1_POSTCODE_FEATURE_14_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_14_GET_VALID(mp1_postcode_feature_14) \
      ((mp1_postcode_feature_14 & MP1_POSTCODE_FEATURE_14_VALID_MASK) >> MP1_POSTCODE_FEATURE_14_VALID_SHIFT)

#define MP1_POSTCODE_FEATURE_14_SET_FEATURE(mp1_postcode_feature_14_reg, feature) \
      mp1_postcode_feature_14_reg = (mp1_postcode_feature_14_reg & ~MP1_POSTCODE_FEATURE_14_FEATURE_MASK) | (feature << MP1_POSTCODE_FEATURE_14_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_14_SET_VALID(mp1_postcode_feature_14_reg, valid) \
      mp1_postcode_feature_14_reg = (mp1_postcode_feature_14_reg & ~MP1_POSTCODE_FEATURE_14_VALID_MASK) | (valid << MP1_POSTCODE_FEATURE_14_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_feature_14_t {
            unsigned int feature                        : MP1_POSTCODE_FEATURE_14_FEATURE_SIZE;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_14_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_feature_14_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_feature_14_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_14_VALID_SIZE;
            unsigned int feature                        : MP1_POSTCODE_FEATURE_14_FEATURE_SIZE;
      } mp1_postcode_feature_14_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_feature_14_t f;
} mp1_postcode_feature_14_u;


/*
 * MP1_POSTCODE_FEATURE_15 struct
 */

#define MP1_POSTCODE_FEATURE_15_REG_SIZE         32
#define MP1_POSTCODE_FEATURE_15_FEATURE_SIZE  8
#define MP1_POSTCODE_FEATURE_15_VALID_SIZE  1

#define MP1_POSTCODE_FEATURE_15_FEATURE_SHIFT  0
#define MP1_POSTCODE_FEATURE_15_VALID_SHIFT  8

#define MP1_POSTCODE_FEATURE_15_FEATURE_MASK  0x000000ff
#define MP1_POSTCODE_FEATURE_15_VALID_MASK  0x00000100

#define MP1_POSTCODE_FEATURE_15_MASK \
      (MP1_POSTCODE_FEATURE_15_FEATURE_MASK | \
      MP1_POSTCODE_FEATURE_15_VALID_MASK)

#define MP1_POSTCODE_FEATURE_15_DEFAULT 0x00000000

#define MP1_POSTCODE_FEATURE_15_GET_FEATURE(mp1_postcode_feature_15) \
      ((mp1_postcode_feature_15 & MP1_POSTCODE_FEATURE_15_FEATURE_MASK) >> MP1_POSTCODE_FEATURE_15_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_15_GET_VALID(mp1_postcode_feature_15) \
      ((mp1_postcode_feature_15 & MP1_POSTCODE_FEATURE_15_VALID_MASK) >> MP1_POSTCODE_FEATURE_15_VALID_SHIFT)

#define MP1_POSTCODE_FEATURE_15_SET_FEATURE(mp1_postcode_feature_15_reg, feature) \
      mp1_postcode_feature_15_reg = (mp1_postcode_feature_15_reg & ~MP1_POSTCODE_FEATURE_15_FEATURE_MASK) | (feature << MP1_POSTCODE_FEATURE_15_FEATURE_SHIFT)
#define MP1_POSTCODE_FEATURE_15_SET_VALID(mp1_postcode_feature_15_reg, valid) \
      mp1_postcode_feature_15_reg = (mp1_postcode_feature_15_reg & ~MP1_POSTCODE_FEATURE_15_VALID_MASK) | (valid << MP1_POSTCODE_FEATURE_15_VALID_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_postcode_feature_15_t {
            unsigned int feature                        : MP1_POSTCODE_FEATURE_15_FEATURE_SIZE;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_15_VALID_SIZE;
            unsigned int                                : 23;
      } mp1_postcode_feature_15_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_postcode_feature_15_t {
            unsigned int                                : 23;
            unsigned int valid                          : MP1_POSTCODE_FEATURE_15_VALID_SIZE;
            unsigned int feature                        : MP1_POSTCODE_FEATURE_15_FEATURE_SIZE;
      } mp1_postcode_feature_15_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_postcode_feature_15_t f;
} mp1_postcode_feature_15_u;


/*
 * MP1_PMI_3 struct
 */

#define MP1_PMI_3_REG_SIZE         32
#define MP1_PMI_3_DATA_SIZE  32

#define MP1_PMI_3_DATA_SHIFT  0

#define MP1_PMI_3_DATA_MASK             0xffffffff

#define MP1_PMI_3_MASK \
      (MP1_PMI_3_DATA_MASK)

#define MP1_PMI_3_DEFAULT              0x00000000

#define MP1_PMI_3_GET_DATA(mp1_pmi_3) \
      ((mp1_pmi_3 & MP1_PMI_3_DATA_MASK) >> MP1_PMI_3_DATA_SHIFT)

#define MP1_PMI_3_SET_DATA(mp1_pmi_3_reg, data) \
      mp1_pmi_3_reg = (mp1_pmi_3_reg & ~MP1_PMI_3_DATA_MASK) | (data << MP1_PMI_3_DATA_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_3_t {
            unsigned int data                           : MP1_PMI_3_DATA_SIZE;
      } mp1_pmi_3_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_3_t {
            unsigned int data                           : MP1_PMI_3_DATA_SIZE;
      } mp1_pmi_3_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_3_t f;
} mp1_pmi_3_u;


/*
 * MP1_PMI_3_STATUS struct
 */

#define MP1_PMI_3_STATUS_REG_SIZE         32
#define MP1_PMI_3_STATUS_FULL_SIZE  1
#define MP1_PMI_3_STATUS_EMPTY_SIZE  1

#define MP1_PMI_3_STATUS_FULL_SHIFT  0
#define MP1_PMI_3_STATUS_EMPTY_SHIFT  1

#define MP1_PMI_3_STATUS_FULL_MASK      0x00000001
#define MP1_PMI_3_STATUS_EMPTY_MASK     0x00000002

#define MP1_PMI_3_STATUS_MASK \
      (MP1_PMI_3_STATUS_FULL_MASK | \
      MP1_PMI_3_STATUS_EMPTY_MASK)

#define MP1_PMI_3_STATUS_DEFAULT       0x00000002

#define MP1_PMI_3_STATUS_GET_FULL(mp1_pmi_3_status) \
      ((mp1_pmi_3_status & MP1_PMI_3_STATUS_FULL_MASK) >> MP1_PMI_3_STATUS_FULL_SHIFT)
#define MP1_PMI_3_STATUS_GET_EMPTY(mp1_pmi_3_status) \
      ((mp1_pmi_3_status & MP1_PMI_3_STATUS_EMPTY_MASK) >> MP1_PMI_3_STATUS_EMPTY_SHIFT)

#define MP1_PMI_3_STATUS_SET_FULL(mp1_pmi_3_status_reg, full) \
      mp1_pmi_3_status_reg = (mp1_pmi_3_status_reg & ~MP1_PMI_3_STATUS_FULL_MASK) | (full << MP1_PMI_3_STATUS_FULL_SHIFT)
#define MP1_PMI_3_STATUS_SET_EMPTY(mp1_pmi_3_status_reg, empty) \
      mp1_pmi_3_status_reg = (mp1_pmi_3_status_reg & ~MP1_PMI_3_STATUS_EMPTY_MASK) | (empty << MP1_PMI_3_STATUS_EMPTY_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_3_status_t {
            unsigned int full                           : MP1_PMI_3_STATUS_FULL_SIZE;
            unsigned int empty                          : MP1_PMI_3_STATUS_EMPTY_SIZE;
            unsigned int                                : 30;
      } mp1_pmi_3_status_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_3_status_t {
            unsigned int                                : 30;
            unsigned int empty                          : MP1_PMI_3_STATUS_EMPTY_SIZE;
            unsigned int full                           : MP1_PMI_3_STATUS_FULL_SIZE;
      } mp1_pmi_3_status_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_3_status_t f;
} mp1_pmi_3_status_u;


/*
 * MP1_PMI_3_READ_POINTER struct
 */

#define MP1_PMI_3_READ_POINTER_REG_SIZE         32
#define MP1_PMI_3_READ_POINTER_CURRENT_SIZE  19

#define MP1_PMI_3_READ_POINTER_CURRENT_SHIFT  0

#define MP1_PMI_3_READ_POINTER_CURRENT_MASK  0x0007ffff

#define MP1_PMI_3_READ_POINTER_MASK \
      (MP1_PMI_3_READ_POINTER_CURRENT_MASK)

#define MP1_PMI_3_READ_POINTER_DEFAULT 0x00000000

#define MP1_PMI_3_READ_POINTER_GET_CURRENT(mp1_pmi_3_read_pointer) \
      ((mp1_pmi_3_read_pointer & MP1_PMI_3_READ_POINTER_CURRENT_MASK) >> MP1_PMI_3_READ_POINTER_CURRENT_SHIFT)

#define MP1_PMI_3_READ_POINTER_SET_CURRENT(mp1_pmi_3_read_pointer_reg, current) \
      mp1_pmi_3_read_pointer_reg = (mp1_pmi_3_read_pointer_reg & ~MP1_PMI_3_READ_POINTER_CURRENT_MASK) | (current << MP1_PMI_3_READ_POINTER_CURRENT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_3_read_pointer_t {
            unsigned int current                        : MP1_PMI_3_READ_POINTER_CURRENT_SIZE;
            unsigned int                                : 13;
      } mp1_pmi_3_read_pointer_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_3_read_pointer_t {
            unsigned int                                : 13;
            unsigned int current                        : MP1_PMI_3_READ_POINTER_CURRENT_SIZE;
      } mp1_pmi_3_read_pointer_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_3_read_pointer_t f;
} mp1_pmi_3_read_pointer_u;


/*
 * MP1_PMI_3_WRITE_POINTER struct
 */

#define MP1_PMI_3_WRITE_POINTER_REG_SIZE         32
#define MP1_PMI_3_WRITE_POINTER_CURRENT_SIZE  19

#define MP1_PMI_3_WRITE_POINTER_CURRENT_SHIFT  0

#define MP1_PMI_3_WRITE_POINTER_CURRENT_MASK  0x0007ffff

#define MP1_PMI_3_WRITE_POINTER_MASK \
      (MP1_PMI_3_WRITE_POINTER_CURRENT_MASK)

#define MP1_PMI_3_WRITE_POINTER_DEFAULT 0x00000000

#define MP1_PMI_3_WRITE_POINTER_GET_CURRENT(mp1_pmi_3_write_pointer) \
      ((mp1_pmi_3_write_pointer & MP1_PMI_3_WRITE_POINTER_CURRENT_MASK) >> MP1_PMI_3_WRITE_POINTER_CURRENT_SHIFT)

#define MP1_PMI_3_WRITE_POINTER_SET_CURRENT(mp1_pmi_3_write_pointer_reg, current) \
      mp1_pmi_3_write_pointer_reg = (mp1_pmi_3_write_pointer_reg & ~MP1_PMI_3_WRITE_POINTER_CURRENT_MASK) | (current << MP1_PMI_3_WRITE_POINTER_CURRENT_SHIFT)

#if             defined(LITTLEENDIAN_CPU)

      typedef struct mp1_pmi_3_write_pointer_t {
            unsigned int current                        : MP1_PMI_3_WRITE_POINTER_CURRENT_SIZE;
            unsigned int                                : 13;
      } mp1_pmi_3_write_pointer_t;

#elif           defined(BIGENDIAN_CPU)

      typedef struct mp1_pmi_3_write_pointer_t {
            unsigned int                                : 13;
            unsigned int current                        : MP1_PMI_3_WRITE_POINTER_CURRENT_SIZE;
      } mp1_pmi_3_write_pointer_t;

#endif

typedef union {
     unsigned int val : 32;
          mp1_pmi_3_write_pointer_t f;
} mp1_pmi_3_write_pointer_u;


#endif

