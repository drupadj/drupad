// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MP2_CRU_FIDDLE_H)
#define _MP2_CRU_FIDDLE_H

/*****************************************************************************************************************
 *
 *	mp2_cru_reg.h
 *
 *	Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif


/*******************************************************
 * Values
 *******************************************************/


/*******************************************************
 * Structures
 *******************************************************/

/*
 * MP2_SMNIF_ERROR struct
 */

#define MP2_SMNIF_ERROR_REG_SIZE       32
#define MP2_SMNIF_ERROR_RESERVED_SIZE  32

#define MP2_SMNIF_ERROR_RESERVED_SHIFT 0

#define MP2_SMNIF_ERROR_RESERVED_MASK  0xffffffff

#define MP2_SMNIF_ERROR_MASK \
     (MP2_SMNIF_ERROR_RESERVED_MASK)

#define MP2_SMNIF_ERROR_DEFAULT        0x00000000

#define MP2_SMNIF_ERROR_GET_RESERVED(mp2_smnif_error) \
     ((mp2_smnif_error & MP2_SMNIF_ERROR_RESERVED_MASK) >> MP2_SMNIF_ERROR_RESERVED_SHIFT)

#define MP2_SMNIF_ERROR_SET_RESERVED(mp2_smnif_error_reg, reserved) \
     mp2_smnif_error_reg = (mp2_smnif_error_reg & ~MP2_SMNIF_ERROR_RESERVED_MASK) | (reserved << MP2_SMNIF_ERROR_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_smnif_error_t {
          unsigned int reserved                       : MP2_SMNIF_ERROR_RESERVED_SIZE;
     } mp2_smnif_error_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_smnif_error_t {
          unsigned int reserved                       : MP2_SMNIF_ERROR_RESERVED_SIZE;
     } mp2_smnif_error_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_smnif_error_t f;
} mp2_smnif_error_u;


/*
 * MP2_FW_DEBUG_CNT0 struct
 */

#define MP2_FW_DEBUG_CNT0_REG_SIZE     32
#define MP2_FW_DEBUG_CNT0_DATA_SIZE    32

#define MP2_FW_DEBUG_CNT0_DATA_SHIFT   0

#define MP2_FW_DEBUG_CNT0_DATA_MASK    0xffffffff

#define MP2_FW_DEBUG_CNT0_MASK \
     (MP2_FW_DEBUG_CNT0_DATA_MASK)

#define MP2_FW_DEBUG_CNT0_DEFAULT      0x00000000

#define MP2_FW_DEBUG_CNT0_GET_DATA(mp2_fw_debug_cnt0) \
     ((mp2_fw_debug_cnt0 & MP2_FW_DEBUG_CNT0_DATA_MASK) >> MP2_FW_DEBUG_CNT0_DATA_SHIFT)

#define MP2_FW_DEBUG_CNT0_SET_DATA(mp2_fw_debug_cnt0_reg, data) \
     mp2_fw_debug_cnt0_reg = (mp2_fw_debug_cnt0_reg & ~MP2_FW_DEBUG_CNT0_DATA_MASK) | (data << MP2_FW_DEBUG_CNT0_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_fw_debug_cnt0_t {
          unsigned int data                           : MP2_FW_DEBUG_CNT0_DATA_SIZE;
     } mp2_fw_debug_cnt0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_fw_debug_cnt0_t {
          unsigned int data                           : MP2_FW_DEBUG_CNT0_DATA_SIZE;
     } mp2_fw_debug_cnt0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_fw_debug_cnt0_t f;
} mp2_fw_debug_cnt0_u;


/*
 * MP2_FW_DEBUG_CNT1 struct
 */

#define MP2_FW_DEBUG_CNT1_REG_SIZE     32
#define MP2_FW_DEBUG_CNT1_DATA_SIZE    32

#define MP2_FW_DEBUG_CNT1_DATA_SHIFT   0

#define MP2_FW_DEBUG_CNT1_DATA_MASK    0xffffffff

#define MP2_FW_DEBUG_CNT1_MASK \
     (MP2_FW_DEBUG_CNT1_DATA_MASK)

#define MP2_FW_DEBUG_CNT1_DEFAULT      0x00000000

#define MP2_FW_DEBUG_CNT1_GET_DATA(mp2_fw_debug_cnt1) \
     ((mp2_fw_debug_cnt1 & MP2_FW_DEBUG_CNT1_DATA_MASK) >> MP2_FW_DEBUG_CNT1_DATA_SHIFT)

#define MP2_FW_DEBUG_CNT1_SET_DATA(mp2_fw_debug_cnt1_reg, data) \
     mp2_fw_debug_cnt1_reg = (mp2_fw_debug_cnt1_reg & ~MP2_FW_DEBUG_CNT1_DATA_MASK) | (data << MP2_FW_DEBUG_CNT1_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_fw_debug_cnt1_t {
          unsigned int data                           : MP2_FW_DEBUG_CNT1_DATA_SIZE;
     } mp2_fw_debug_cnt1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_fw_debug_cnt1_t {
          unsigned int data                           : MP2_FW_DEBUG_CNT1_DATA_SIZE;
     } mp2_fw_debug_cnt1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_fw_debug_cnt1_t f;
} mp2_fw_debug_cnt1_u;


/*
 * MP2_FW_DEBUG_CNT2 struct
 */

#define MP2_FW_DEBUG_CNT2_REG_SIZE     32
#define MP2_FW_DEBUG_CNT2_DATA_SIZE    32

#define MP2_FW_DEBUG_CNT2_DATA_SHIFT   0

#define MP2_FW_DEBUG_CNT2_DATA_MASK    0xffffffff

#define MP2_FW_DEBUG_CNT2_MASK \
     (MP2_FW_DEBUG_CNT2_DATA_MASK)

#define MP2_FW_DEBUG_CNT2_DEFAULT      0x00000000

#define MP2_FW_DEBUG_CNT2_GET_DATA(mp2_fw_debug_cnt2) \
     ((mp2_fw_debug_cnt2 & MP2_FW_DEBUG_CNT2_DATA_MASK) >> MP2_FW_DEBUG_CNT2_DATA_SHIFT)

#define MP2_FW_DEBUG_CNT2_SET_DATA(mp2_fw_debug_cnt2_reg, data) \
     mp2_fw_debug_cnt2_reg = (mp2_fw_debug_cnt2_reg & ~MP2_FW_DEBUG_CNT2_DATA_MASK) | (data << MP2_FW_DEBUG_CNT2_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_fw_debug_cnt2_t {
          unsigned int data                           : MP2_FW_DEBUG_CNT2_DATA_SIZE;
     } mp2_fw_debug_cnt2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_fw_debug_cnt2_t {
          unsigned int data                           : MP2_FW_DEBUG_CNT2_DATA_SIZE;
     } mp2_fw_debug_cnt2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_fw_debug_cnt2_t f;
} mp2_fw_debug_cnt2_u;


/*
 * MP2_FW_DEBUG_CNT3 struct
 */

#define MP2_FW_DEBUG_CNT3_REG_SIZE     32
#define MP2_FW_DEBUG_CNT3_DATA_SIZE    32

#define MP2_FW_DEBUG_CNT3_DATA_SHIFT   0

#define MP2_FW_DEBUG_CNT3_DATA_MASK    0xffffffff

#define MP2_FW_DEBUG_CNT3_MASK \
     (MP2_FW_DEBUG_CNT3_DATA_MASK)

#define MP2_FW_DEBUG_CNT3_DEFAULT      0x00000000

#define MP2_FW_DEBUG_CNT3_GET_DATA(mp2_fw_debug_cnt3) \
     ((mp2_fw_debug_cnt3 & MP2_FW_DEBUG_CNT3_DATA_MASK) >> MP2_FW_DEBUG_CNT3_DATA_SHIFT)

#define MP2_FW_DEBUG_CNT3_SET_DATA(mp2_fw_debug_cnt3_reg, data) \
     mp2_fw_debug_cnt3_reg = (mp2_fw_debug_cnt3_reg & ~MP2_FW_DEBUG_CNT3_DATA_MASK) | (data << MP2_FW_DEBUG_CNT3_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_fw_debug_cnt3_t {
          unsigned int data                           : MP2_FW_DEBUG_CNT3_DATA_SIZE;
     } mp2_fw_debug_cnt3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_fw_debug_cnt3_t {
          unsigned int data                           : MP2_FW_DEBUG_CNT3_DATA_SIZE;
     } mp2_fw_debug_cnt3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_fw_debug_cnt3_t f;
} mp2_fw_debug_cnt3_u;


/*
 * MP2_FW_DEBUG_SIGNAL0 struct
 */

#define MP2_FW_DEBUG_SIGNAL0_REG_SIZE  32
#define MP2_FW_DEBUG_SIGNAL0_DATA_SIZE 32

#define MP2_FW_DEBUG_SIGNAL0_DATA_SHIFT 0

#define MP2_FW_DEBUG_SIGNAL0_DATA_MASK 0xffffffff

#define MP2_FW_DEBUG_SIGNAL0_MASK \
     (MP2_FW_DEBUG_SIGNAL0_DATA_MASK)

#define MP2_FW_DEBUG_SIGNAL0_DEFAULT   0x00000000

#define MP2_FW_DEBUG_SIGNAL0_GET_DATA(mp2_fw_debug_signal0) \
     ((mp2_fw_debug_signal0 & MP2_FW_DEBUG_SIGNAL0_DATA_MASK) >> MP2_FW_DEBUG_SIGNAL0_DATA_SHIFT)

#define MP2_FW_DEBUG_SIGNAL0_SET_DATA(mp2_fw_debug_signal0_reg, data) \
     mp2_fw_debug_signal0_reg = (mp2_fw_debug_signal0_reg & ~MP2_FW_DEBUG_SIGNAL0_DATA_MASK) | (data << MP2_FW_DEBUG_SIGNAL0_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_fw_debug_signal0_t {
          unsigned int data                           : MP2_FW_DEBUG_SIGNAL0_DATA_SIZE;
     } mp2_fw_debug_signal0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_fw_debug_signal0_t {
          unsigned int data                           : MP2_FW_DEBUG_SIGNAL0_DATA_SIZE;
     } mp2_fw_debug_signal0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_fw_debug_signal0_t f;
} mp2_fw_debug_signal0_u;


/*
 * MP2_FW_DEBUG_SIGNAL1 struct
 */

#define MP2_FW_DEBUG_SIGNAL1_REG_SIZE  32
#define MP2_FW_DEBUG_SIGNAL1_DATA_SIZE 32

#define MP2_FW_DEBUG_SIGNAL1_DATA_SHIFT 0

#define MP2_FW_DEBUG_SIGNAL1_DATA_MASK 0xffffffff

#define MP2_FW_DEBUG_SIGNAL1_MASK \
     (MP2_FW_DEBUG_SIGNAL1_DATA_MASK)

#define MP2_FW_DEBUG_SIGNAL1_DEFAULT   0x00000000

#define MP2_FW_DEBUG_SIGNAL1_GET_DATA(mp2_fw_debug_signal1) \
     ((mp2_fw_debug_signal1 & MP2_FW_DEBUG_SIGNAL1_DATA_MASK) >> MP2_FW_DEBUG_SIGNAL1_DATA_SHIFT)

#define MP2_FW_DEBUG_SIGNAL1_SET_DATA(mp2_fw_debug_signal1_reg, data) \
     mp2_fw_debug_signal1_reg = (mp2_fw_debug_signal1_reg & ~MP2_FW_DEBUG_SIGNAL1_DATA_MASK) | (data << MP2_FW_DEBUG_SIGNAL1_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_fw_debug_signal1_t {
          unsigned int data                           : MP2_FW_DEBUG_SIGNAL1_DATA_SIZE;
     } mp2_fw_debug_signal1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_fw_debug_signal1_t {
          unsigned int data                           : MP2_FW_DEBUG_SIGNAL1_DATA_SIZE;
     } mp2_fw_debug_signal1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_fw_debug_signal1_t f;
} mp2_fw_debug_signal1_u;


/*
 * MP2_DSM_ENABLE struct
 */

#define MP2_DSM_ENABLE_REG_SIZE        32
#define MP2_DSM_ENABLE_MP2_ENB_EDBGREQ_SIZE 1
#define MP2_DSM_ENABLE_MP2_ENB_DBGRESTART_SIZE 1
#define MP2_DSM_ENABLE_MP2_ENB_UNUSED_SIZE 1
#define MP2_DSM_ENABLE_MP2_ENB_DSMINT_SIZE 1

#define MP2_DSM_ENABLE_MP2_ENB_EDBGREQ_SHIFT 0
#define MP2_DSM_ENABLE_MP2_ENB_DBGRESTART_SHIFT 1
#define MP2_DSM_ENABLE_MP2_ENB_UNUSED_SHIFT 2
#define MP2_DSM_ENABLE_MP2_ENB_DSMINT_SHIFT 3

#define MP2_DSM_ENABLE_MP2_ENB_EDBGREQ_MASK 0x1
#define MP2_DSM_ENABLE_MP2_ENB_DBGRESTART_MASK 0x2
#define MP2_DSM_ENABLE_MP2_ENB_UNUSED_MASK 0x4
#define MP2_DSM_ENABLE_MP2_ENB_DSMINT_MASK 0x8

#define MP2_DSM_ENABLE_MASK \
     (MP2_DSM_ENABLE_MP2_ENB_EDBGREQ_MASK | \
      MP2_DSM_ENABLE_MP2_ENB_DBGRESTART_MASK | \
      MP2_DSM_ENABLE_MP2_ENB_UNUSED_MASK | \
      MP2_DSM_ENABLE_MP2_ENB_DSMINT_MASK)

#define MP2_DSM_ENABLE_DEFAULT         0x00000000

#define MP2_DSM_ENABLE_GET_MP2_ENB_EDBGREQ(mp2_dsm_enable) \
     ((mp2_dsm_enable & MP2_DSM_ENABLE_MP2_ENB_EDBGREQ_MASK) >> MP2_DSM_ENABLE_MP2_ENB_EDBGREQ_SHIFT)
#define MP2_DSM_ENABLE_GET_MP2_ENB_DBGRESTART(mp2_dsm_enable) \
     ((mp2_dsm_enable & MP2_DSM_ENABLE_MP2_ENB_DBGRESTART_MASK) >> MP2_DSM_ENABLE_MP2_ENB_DBGRESTART_SHIFT)
#define MP2_DSM_ENABLE_GET_MP2_ENB_UNUSED(mp2_dsm_enable) \
     ((mp2_dsm_enable & MP2_DSM_ENABLE_MP2_ENB_UNUSED_MASK) >> MP2_DSM_ENABLE_MP2_ENB_UNUSED_SHIFT)
#define MP2_DSM_ENABLE_GET_MP2_ENB_DSMINT(mp2_dsm_enable) \
     ((mp2_dsm_enable & MP2_DSM_ENABLE_MP2_ENB_DSMINT_MASK) >> MP2_DSM_ENABLE_MP2_ENB_DSMINT_SHIFT)

#define MP2_DSM_ENABLE_SET_MP2_ENB_EDBGREQ(mp2_dsm_enable_reg, mp2_enb_edbgreq) \
     mp2_dsm_enable_reg = (mp2_dsm_enable_reg & ~MP2_DSM_ENABLE_MP2_ENB_EDBGREQ_MASK) | (mp2_enb_edbgreq << MP2_DSM_ENABLE_MP2_ENB_EDBGREQ_SHIFT)
#define MP2_DSM_ENABLE_SET_MP2_ENB_DBGRESTART(mp2_dsm_enable_reg, mp2_enb_dbgrestart) \
     mp2_dsm_enable_reg = (mp2_dsm_enable_reg & ~MP2_DSM_ENABLE_MP2_ENB_DBGRESTART_MASK) | (mp2_enb_dbgrestart << MP2_DSM_ENABLE_MP2_ENB_DBGRESTART_SHIFT)
#define MP2_DSM_ENABLE_SET_MP2_ENB_UNUSED(mp2_dsm_enable_reg, mp2_enb_unused) \
     mp2_dsm_enable_reg = (mp2_dsm_enable_reg & ~MP2_DSM_ENABLE_MP2_ENB_UNUSED_MASK) | (mp2_enb_unused << MP2_DSM_ENABLE_MP2_ENB_UNUSED_SHIFT)
#define MP2_DSM_ENABLE_SET_MP2_ENB_DSMINT(mp2_dsm_enable_reg, mp2_enb_dsmint) \
     mp2_dsm_enable_reg = (mp2_dsm_enable_reg & ~MP2_DSM_ENABLE_MP2_ENB_DSMINT_MASK) | (mp2_enb_dsmint << MP2_DSM_ENABLE_MP2_ENB_DSMINT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dsm_enable_t {
          unsigned int mp2_enb_edbgreq                : MP2_DSM_ENABLE_MP2_ENB_EDBGREQ_SIZE;
          unsigned int mp2_enb_dbgrestart             : MP2_DSM_ENABLE_MP2_ENB_DBGRESTART_SIZE;
          unsigned int mp2_enb_unused                 : MP2_DSM_ENABLE_MP2_ENB_UNUSED_SIZE;
          unsigned int mp2_enb_dsmint                 : MP2_DSM_ENABLE_MP2_ENB_DSMINT_SIZE;
          unsigned int                                : 28;
     } mp2_dsm_enable_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dsm_enable_t {
          unsigned int                                : 28;
          unsigned int mp2_enb_dsmint                 : MP2_DSM_ENABLE_MP2_ENB_DSMINT_SIZE;
          unsigned int mp2_enb_unused                 : MP2_DSM_ENABLE_MP2_ENB_UNUSED_SIZE;
          unsigned int mp2_enb_dbgrestart             : MP2_DSM_ENABLE_MP2_ENB_DBGRESTART_SIZE;
          unsigned int mp2_enb_edbgreq                : MP2_DSM_ENABLE_MP2_ENB_EDBGREQ_SIZE;
     } mp2_dsm_enable_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dsm_enable_t f;
} mp2_dsm_enable_u;


/*
 * MP2_FIRMWARE_FLAGS struct
 */

#define MP2_FIRMWARE_FLAGS_REG_SIZE    32
#define MP2_FIRMWARE_FLAGS_INTERRUPTS_ENABLED_SIZE 1
#define MP2_FIRMWARE_FLAGS_RESERVED_SIZE 31

#define MP2_FIRMWARE_FLAGS_INTERRUPTS_ENABLED_SHIFT 0
#define MP2_FIRMWARE_FLAGS_RESERVED_SHIFT 1

#define MP2_FIRMWARE_FLAGS_INTERRUPTS_ENABLED_MASK 0x1
#define MP2_FIRMWARE_FLAGS_RESERVED_MASK 0xfffffffe

#define MP2_FIRMWARE_FLAGS_MASK \
     (MP2_FIRMWARE_FLAGS_INTERRUPTS_ENABLED_MASK | \
      MP2_FIRMWARE_FLAGS_RESERVED_MASK)

#define MP2_FIRMWARE_FLAGS_DEFAULT     0x00000000

#define MP2_FIRMWARE_FLAGS_GET_INTERRUPTS_ENABLED(mp2_firmware_flags) \
     ((mp2_firmware_flags & MP2_FIRMWARE_FLAGS_INTERRUPTS_ENABLED_MASK) >> MP2_FIRMWARE_FLAGS_INTERRUPTS_ENABLED_SHIFT)
#define MP2_FIRMWARE_FLAGS_GET_RESERVED(mp2_firmware_flags) \
     ((mp2_firmware_flags & MP2_FIRMWARE_FLAGS_RESERVED_MASK) >> MP2_FIRMWARE_FLAGS_RESERVED_SHIFT)

#define MP2_FIRMWARE_FLAGS_SET_INTERRUPTS_ENABLED(mp2_firmware_flags_reg, interrupts_enabled) \
     mp2_firmware_flags_reg = (mp2_firmware_flags_reg & ~MP2_FIRMWARE_FLAGS_INTERRUPTS_ENABLED_MASK) | (interrupts_enabled << MP2_FIRMWARE_FLAGS_INTERRUPTS_ENABLED_SHIFT)
#define MP2_FIRMWARE_FLAGS_SET_RESERVED(mp2_firmware_flags_reg, reserved) \
     mp2_firmware_flags_reg = (mp2_firmware_flags_reg & ~MP2_FIRMWARE_FLAGS_RESERVED_MASK) | (reserved << MP2_FIRMWARE_FLAGS_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_firmware_flags_t {
          unsigned int interrupts_enabled             : MP2_FIRMWARE_FLAGS_INTERRUPTS_ENABLED_SIZE;
          unsigned int reserved                       : MP2_FIRMWARE_FLAGS_RESERVED_SIZE;
     } mp2_firmware_flags_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_firmware_flags_t {
          unsigned int reserved                       : MP2_FIRMWARE_FLAGS_RESERVED_SIZE;
          unsigned int interrupts_enabled             : MP2_FIRMWARE_FLAGS_INTERRUPTS_ENABLED_SIZE;
     } mp2_firmware_flags_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_firmware_flags_t f;
} mp2_firmware_flags_u;


/*
 * MP2_MUTEX_0 struct
 */

#define MP2_MUTEX_0_REG_SIZE           32
#define MP2_MUTEX_0_MUTEX_SIZE         8

#define MP2_MUTEX_0_MUTEX_SHIFT        0

#define MP2_MUTEX_0_MUTEX_MASK         0xff

#define MP2_MUTEX_0_MASK \
     (MP2_MUTEX_0_MUTEX_MASK)

#define MP2_MUTEX_0_DEFAULT            0x00000000

#define MP2_MUTEX_0_GET_MUTEX(mp2_mutex_0) \
     ((mp2_mutex_0 & MP2_MUTEX_0_MUTEX_MASK) >> MP2_MUTEX_0_MUTEX_SHIFT)

#define MP2_MUTEX_0_SET_MUTEX(mp2_mutex_0_reg, mutex) \
     mp2_mutex_0_reg = (mp2_mutex_0_reg & ~MP2_MUTEX_0_MUTEX_MASK) | (mutex << MP2_MUTEX_0_MUTEX_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mutex_0_t {
          unsigned int mutex                          : MP2_MUTEX_0_MUTEX_SIZE;
          unsigned int                                : 24;
     } mp2_mutex_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mutex_0_t {
          unsigned int                                : 24;
          unsigned int mutex                          : MP2_MUTEX_0_MUTEX_SIZE;
     } mp2_mutex_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mutex_0_t f;
} mp2_mutex_0_u;


/*
 * MP2_MUTEX_1 struct
 */

#define MP2_MUTEX_1_REG_SIZE           32
#define MP2_MUTEX_1_MUTEX_SIZE         8

#define MP2_MUTEX_1_MUTEX_SHIFT        0

#define MP2_MUTEX_1_MUTEX_MASK         0xff

#define MP2_MUTEX_1_MASK \
     (MP2_MUTEX_1_MUTEX_MASK)

#define MP2_MUTEX_1_DEFAULT            0x00000000

#define MP2_MUTEX_1_GET_MUTEX(mp2_mutex_1) \
     ((mp2_mutex_1 & MP2_MUTEX_1_MUTEX_MASK) >> MP2_MUTEX_1_MUTEX_SHIFT)

#define MP2_MUTEX_1_SET_MUTEX(mp2_mutex_1_reg, mutex) \
     mp2_mutex_1_reg = (mp2_mutex_1_reg & ~MP2_MUTEX_1_MUTEX_MASK) | (mutex << MP2_MUTEX_1_MUTEX_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mutex_1_t {
          unsigned int mutex                          : MP2_MUTEX_1_MUTEX_SIZE;
          unsigned int                                : 24;
     } mp2_mutex_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mutex_1_t {
          unsigned int                                : 24;
          unsigned int mutex                          : MP2_MUTEX_1_MUTEX_SIZE;
     } mp2_mutex_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mutex_1_t f;
} mp2_mutex_1_u;


/*
 * MP2_MUTEX_2 struct
 */

#define MP2_MUTEX_2_REG_SIZE           32
#define MP2_MUTEX_2_MUTEX_SIZE         8

#define MP2_MUTEX_2_MUTEX_SHIFT        0

#define MP2_MUTEX_2_MUTEX_MASK         0xff

#define MP2_MUTEX_2_MASK \
     (MP2_MUTEX_2_MUTEX_MASK)

#define MP2_MUTEX_2_DEFAULT            0x00000000

#define MP2_MUTEX_2_GET_MUTEX(mp2_mutex_2) \
     ((mp2_mutex_2 & MP2_MUTEX_2_MUTEX_MASK) >> MP2_MUTEX_2_MUTEX_SHIFT)

#define MP2_MUTEX_2_SET_MUTEX(mp2_mutex_2_reg, mutex) \
     mp2_mutex_2_reg = (mp2_mutex_2_reg & ~MP2_MUTEX_2_MUTEX_MASK) | (mutex << MP2_MUTEX_2_MUTEX_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mutex_2_t {
          unsigned int mutex                          : MP2_MUTEX_2_MUTEX_SIZE;
          unsigned int                                : 24;
     } mp2_mutex_2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mutex_2_t {
          unsigned int                                : 24;
          unsigned int mutex                          : MP2_MUTEX_2_MUTEX_SIZE;
     } mp2_mutex_2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mutex_2_t f;
} mp2_mutex_2_u;


/*
 * MP2_MUTEX_3 struct
 */

#define MP2_MUTEX_3_REG_SIZE           32
#define MP2_MUTEX_3_MUTEX_SIZE         8

#define MP2_MUTEX_3_MUTEX_SHIFT        0

#define MP2_MUTEX_3_MUTEX_MASK         0xff

#define MP2_MUTEX_3_MASK \
     (MP2_MUTEX_3_MUTEX_MASK)

#define MP2_MUTEX_3_DEFAULT            0x00000000

#define MP2_MUTEX_3_GET_MUTEX(mp2_mutex_3) \
     ((mp2_mutex_3 & MP2_MUTEX_3_MUTEX_MASK) >> MP2_MUTEX_3_MUTEX_SHIFT)

#define MP2_MUTEX_3_SET_MUTEX(mp2_mutex_3_reg, mutex) \
     mp2_mutex_3_reg = (mp2_mutex_3_reg & ~MP2_MUTEX_3_MUTEX_MASK) | (mutex << MP2_MUTEX_3_MUTEX_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mutex_3_t {
          unsigned int mutex                          : MP2_MUTEX_3_MUTEX_SIZE;
          unsigned int                                : 24;
     } mp2_mutex_3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mutex_3_t {
          unsigned int                                : 24;
          unsigned int mutex                          : MP2_MUTEX_3_MUTEX_SIZE;
     } mp2_mutex_3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mutex_3_t f;
} mp2_mutex_3_u;


/*
 * MP2_MISC_STATUS struct
 */

#define MP2_MISC_STATUS_REG_SIZE       32
#define MP2_MISC_STATUS_S5_STATE_SIZE  1
#define MP2_MISC_STATUS_SFI_DIS_STATUS_SIZE 1
#define MP2_MISC_STATUS_S0I3_RAM_DIS_STATUS_SIZE 1
#define MP2_MISC_STATUS_RESERVED_SIZE  12
#define MP2_MISC_STATUS_MP2_MP0_Interrupt_SIZE 1
#define MP2_MISC_STATUS_MP0_INTR_STATUS_SIZE 16

#define MP2_MISC_STATUS_S5_STATE_SHIFT 0
#define MP2_MISC_STATUS_SFI_DIS_STATUS_SHIFT 1
#define MP2_MISC_STATUS_S0I3_RAM_DIS_STATUS_SHIFT 2
#define MP2_MISC_STATUS_RESERVED_SHIFT 3
#define MP2_MISC_STATUS_MP2_MP0_Interrupt_SHIFT 15
#define MP2_MISC_STATUS_MP0_INTR_STATUS_SHIFT 16

#define MP2_MISC_STATUS_S5_STATE_MASK  0x1
#define MP2_MISC_STATUS_SFI_DIS_STATUS_MASK 0x2
#define MP2_MISC_STATUS_S0I3_RAM_DIS_STATUS_MASK 0x4
#define MP2_MISC_STATUS_RESERVED_MASK  0x7ff8
#define MP2_MISC_STATUS_MP2_MP0_Interrupt_MASK 0x8000
#define MP2_MISC_STATUS_MP0_INTR_STATUS_MASK 0xffff0000

#define MP2_MISC_STATUS_MASK \
     (MP2_MISC_STATUS_S5_STATE_MASK | \
      MP2_MISC_STATUS_SFI_DIS_STATUS_MASK | \
      MP2_MISC_STATUS_S0I3_RAM_DIS_STATUS_MASK | \
      MP2_MISC_STATUS_RESERVED_MASK | \
      MP2_MISC_STATUS_MP2_MP0_Interrupt_MASK | \
      MP2_MISC_STATUS_MP0_INTR_STATUS_MASK)

#define MP2_MISC_STATUS_DEFAULT        0x00000000

#define MP2_MISC_STATUS_GET_S5_STATE(mp2_misc_status) \
     ((mp2_misc_status & MP2_MISC_STATUS_S5_STATE_MASK) >> MP2_MISC_STATUS_S5_STATE_SHIFT)
#define MP2_MISC_STATUS_GET_SFI_DIS_STATUS(mp2_misc_status) \
     ((mp2_misc_status & MP2_MISC_STATUS_SFI_DIS_STATUS_MASK) >> MP2_MISC_STATUS_SFI_DIS_STATUS_SHIFT)
#define MP2_MISC_STATUS_GET_S0I3_RAM_DIS_STATUS(mp2_misc_status) \
     ((mp2_misc_status & MP2_MISC_STATUS_S0I3_RAM_DIS_STATUS_MASK) >> MP2_MISC_STATUS_S0I3_RAM_DIS_STATUS_SHIFT)
#define MP2_MISC_STATUS_GET_RESERVED(mp2_misc_status) \
     ((mp2_misc_status & MP2_MISC_STATUS_RESERVED_MASK) >> MP2_MISC_STATUS_RESERVED_SHIFT)
#define MP2_MISC_STATUS_GET_MP2_MP0_Interrupt(mp2_misc_status) \
     ((mp2_misc_status & MP2_MISC_STATUS_MP2_MP0_Interrupt_MASK) >> MP2_MISC_STATUS_MP2_MP0_Interrupt_SHIFT)
#define MP2_MISC_STATUS_GET_MP0_INTR_STATUS(mp2_misc_status) \
     ((mp2_misc_status & MP2_MISC_STATUS_MP0_INTR_STATUS_MASK) >> MP2_MISC_STATUS_MP0_INTR_STATUS_SHIFT)

#define MP2_MISC_STATUS_SET_S5_STATE(mp2_misc_status_reg, s5_state) \
     mp2_misc_status_reg = (mp2_misc_status_reg & ~MP2_MISC_STATUS_S5_STATE_MASK) | (s5_state << MP2_MISC_STATUS_S5_STATE_SHIFT)
#define MP2_MISC_STATUS_SET_SFI_DIS_STATUS(mp2_misc_status_reg, sfi_dis_status) \
     mp2_misc_status_reg = (mp2_misc_status_reg & ~MP2_MISC_STATUS_SFI_DIS_STATUS_MASK) | (sfi_dis_status << MP2_MISC_STATUS_SFI_DIS_STATUS_SHIFT)
#define MP2_MISC_STATUS_SET_S0I3_RAM_DIS_STATUS(mp2_misc_status_reg, s0i3_ram_dis_status) \
     mp2_misc_status_reg = (mp2_misc_status_reg & ~MP2_MISC_STATUS_S0I3_RAM_DIS_STATUS_MASK) | (s0i3_ram_dis_status << MP2_MISC_STATUS_S0I3_RAM_DIS_STATUS_SHIFT)
#define MP2_MISC_STATUS_SET_RESERVED(mp2_misc_status_reg, reserved) \
     mp2_misc_status_reg = (mp2_misc_status_reg & ~MP2_MISC_STATUS_RESERVED_MASK) | (reserved << MP2_MISC_STATUS_RESERVED_SHIFT)
#define MP2_MISC_STATUS_SET_MP2_MP0_Interrupt(mp2_misc_status_reg, mp2_mp0_interrupt) \
     mp2_misc_status_reg = (mp2_misc_status_reg & ~MP2_MISC_STATUS_MP2_MP0_Interrupt_MASK) | (mp2_mp0_interrupt << MP2_MISC_STATUS_MP2_MP0_Interrupt_SHIFT)
#define MP2_MISC_STATUS_SET_MP0_INTR_STATUS(mp2_misc_status_reg, mp0_intr_status) \
     mp2_misc_status_reg = (mp2_misc_status_reg & ~MP2_MISC_STATUS_MP0_INTR_STATUS_MASK) | (mp0_intr_status << MP2_MISC_STATUS_MP0_INTR_STATUS_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_misc_status_t {
          unsigned int s5_state                       : MP2_MISC_STATUS_S5_STATE_SIZE;
          unsigned int sfi_dis_status                 : MP2_MISC_STATUS_SFI_DIS_STATUS_SIZE;
          unsigned int s0i3_ram_dis_status            : MP2_MISC_STATUS_S0I3_RAM_DIS_STATUS_SIZE;
          unsigned int reserved                       : MP2_MISC_STATUS_RESERVED_SIZE;
          unsigned int mp2_mp0_interrupt              : MP2_MISC_STATUS_MP2_MP0_Interrupt_SIZE;
          unsigned int mp0_intr_status                : MP2_MISC_STATUS_MP0_INTR_STATUS_SIZE;
     } mp2_misc_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_misc_status_t {
          unsigned int mp0_intr_status                : MP2_MISC_STATUS_MP0_INTR_STATUS_SIZE;
          unsigned int mp2_mp0_interrupt              : MP2_MISC_STATUS_MP2_MP0_Interrupt_SIZE;
          unsigned int reserved                       : MP2_MISC_STATUS_RESERVED_SIZE;
          unsigned int s0i3_ram_dis_status            : MP2_MISC_STATUS_S0I3_RAM_DIS_STATUS_SIZE;
          unsigned int sfi_dis_status                 : MP2_MISC_STATUS_SFI_DIS_STATUS_SIZE;
          unsigned int s5_state                       : MP2_MISC_STATUS_S5_STATE_SIZE;
     } mp2_misc_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_misc_status_t f;
} mp2_misc_status_u;


/*
 * MP2_PUB_ECO0 struct
 */

#define MP2_PUB_ECO0_REG_SIZE          32
#define MP2_PUB_ECO0_DATA_SIZE         32

#define MP2_PUB_ECO0_DATA_SHIFT        0

#define MP2_PUB_ECO0_DATA_MASK         0xffffffff

#define MP2_PUB_ECO0_MASK \
     (MP2_PUB_ECO0_DATA_MASK)

#define MP2_PUB_ECO0_DEFAULT           0x00000000

#define MP2_PUB_ECO0_GET_DATA(mp2_pub_eco0) \
     ((mp2_pub_eco0 & MP2_PUB_ECO0_DATA_MASK) >> MP2_PUB_ECO0_DATA_SHIFT)

#define MP2_PUB_ECO0_SET_DATA(mp2_pub_eco0_reg, data) \
     mp2_pub_eco0_reg = (mp2_pub_eco0_reg & ~MP2_PUB_ECO0_DATA_MASK) | (data << MP2_PUB_ECO0_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pub_eco0_t {
          unsigned int data                           : MP2_PUB_ECO0_DATA_SIZE;
     } mp2_pub_eco0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pub_eco0_t {
          unsigned int data                           : MP2_PUB_ECO0_DATA_SIZE;
     } mp2_pub_eco0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pub_eco0_t f;
} mp2_pub_eco0_u;


/*
 * MP2_PUB_ECO1 struct
 */

#define MP2_PUB_ECO1_REG_SIZE          32
#define MP2_PUB_ECO1_DATA_SIZE         32

#define MP2_PUB_ECO1_DATA_SHIFT        0

#define MP2_PUB_ECO1_DATA_MASK         0xffffffff

#define MP2_PUB_ECO1_MASK \
     (MP2_PUB_ECO1_DATA_MASK)

#define MP2_PUB_ECO1_DEFAULT           0x00000000

#define MP2_PUB_ECO1_GET_DATA(mp2_pub_eco1) \
     ((mp2_pub_eco1 & MP2_PUB_ECO1_DATA_MASK) >> MP2_PUB_ECO1_DATA_SHIFT)

#define MP2_PUB_ECO1_SET_DATA(mp2_pub_eco1_reg, data) \
     mp2_pub_eco1_reg = (mp2_pub_eco1_reg & ~MP2_PUB_ECO1_DATA_MASK) | (data << MP2_PUB_ECO1_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pub_eco1_t {
          unsigned int data                           : MP2_PUB_ECO1_DATA_SIZE;
     } mp2_pub_eco1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pub_eco1_t {
          unsigned int data                           : MP2_PUB_ECO1_DATA_SIZE;
     } mp2_pub_eco1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pub_eco1_t f;
} mp2_pub_eco1_u;


/*
 * MP2_PUB_ECO2 struct
 */

#define MP2_PUB_ECO2_REG_SIZE          32
#define MP2_PUB_ECO2_DATA_SIZE         32

#define MP2_PUB_ECO2_DATA_SHIFT        0

#define MP2_PUB_ECO2_DATA_MASK         0xffffffff

#define MP2_PUB_ECO2_MASK \
     (MP2_PUB_ECO2_DATA_MASK)

#define MP2_PUB_ECO2_DEFAULT           0x00000000

#define MP2_PUB_ECO2_GET_DATA(mp2_pub_eco2) \
     ((mp2_pub_eco2 & MP2_PUB_ECO2_DATA_MASK) >> MP2_PUB_ECO2_DATA_SHIFT)

#define MP2_PUB_ECO2_SET_DATA(mp2_pub_eco2_reg, data) \
     mp2_pub_eco2_reg = (mp2_pub_eco2_reg & ~MP2_PUB_ECO2_DATA_MASK) | (data << MP2_PUB_ECO2_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pub_eco2_t {
          unsigned int data                           : MP2_PUB_ECO2_DATA_SIZE;
     } mp2_pub_eco2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pub_eco2_t {
          unsigned int data                           : MP2_PUB_ECO2_DATA_SIZE;
     } mp2_pub_eco2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pub_eco2_t f;
} mp2_pub_eco2_u;


/*
 * MP2_PUB_ECO3 struct
 */

#define MP2_PUB_ECO3_REG_SIZE          32
#define MP2_PUB_ECO3_DATA_SIZE         32

#define MP2_PUB_ECO3_DATA_SHIFT        0

#define MP2_PUB_ECO3_DATA_MASK         0xffffffff

#define MP2_PUB_ECO3_MASK \
     (MP2_PUB_ECO3_DATA_MASK)

#define MP2_PUB_ECO3_DEFAULT           0x00000000

#define MP2_PUB_ECO3_GET_DATA(mp2_pub_eco3) \
     ((mp2_pub_eco3 & MP2_PUB_ECO3_DATA_MASK) >> MP2_PUB_ECO3_DATA_SHIFT)

#define MP2_PUB_ECO3_SET_DATA(mp2_pub_eco3_reg, data) \
     mp2_pub_eco3_reg = (mp2_pub_eco3_reg & ~MP2_PUB_ECO3_DATA_MASK) | (data << MP2_PUB_ECO3_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pub_eco3_t {
          unsigned int data                           : MP2_PUB_ECO3_DATA_SIZE;
     } mp2_pub_eco3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pub_eco3_t {
          unsigned int data                           : MP2_PUB_ECO3_DATA_SIZE;
     } mp2_pub_eco3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pub_eco3_t f;
} mp2_pub_eco3_u;


/*
 * MP2_PUB_SCRATCH0 struct
 */

#define MP2_PUB_SCRATCH0_REG_SIZE      32
#define MP2_PUB_SCRATCH0_DATA_SIZE     32

#define MP2_PUB_SCRATCH0_DATA_SHIFT    0

#define MP2_PUB_SCRATCH0_DATA_MASK     0xffffffff

#define MP2_PUB_SCRATCH0_MASK \
     (MP2_PUB_SCRATCH0_DATA_MASK)

#define MP2_PUB_SCRATCH0_DEFAULT       0x00000000

#define MP2_PUB_SCRATCH0_GET_DATA(mp2_pub_scratch0) \
     ((mp2_pub_scratch0 & MP2_PUB_SCRATCH0_DATA_MASK) >> MP2_PUB_SCRATCH0_DATA_SHIFT)

#define MP2_PUB_SCRATCH0_SET_DATA(mp2_pub_scratch0_reg, data) \
     mp2_pub_scratch0_reg = (mp2_pub_scratch0_reg & ~MP2_PUB_SCRATCH0_DATA_MASK) | (data << MP2_PUB_SCRATCH0_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pub_scratch0_t {
          unsigned int data                           : MP2_PUB_SCRATCH0_DATA_SIZE;
     } mp2_pub_scratch0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pub_scratch0_t {
          unsigned int data                           : MP2_PUB_SCRATCH0_DATA_SIZE;
     } mp2_pub_scratch0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pub_scratch0_t f;
} mp2_pub_scratch0_u;


/*
 * MP2_PUB_SCRATCH1 struct
 */

#define MP2_PUB_SCRATCH1_REG_SIZE      32
#define MP2_PUB_SCRATCH1_DATA_SIZE     32

#define MP2_PUB_SCRATCH1_DATA_SHIFT    0

#define MP2_PUB_SCRATCH1_DATA_MASK     0xffffffff

#define MP2_PUB_SCRATCH1_MASK \
     (MP2_PUB_SCRATCH1_DATA_MASK)

#define MP2_PUB_SCRATCH1_DEFAULT       0x00000000

#define MP2_PUB_SCRATCH1_GET_DATA(mp2_pub_scratch1) \
     ((mp2_pub_scratch1 & MP2_PUB_SCRATCH1_DATA_MASK) >> MP2_PUB_SCRATCH1_DATA_SHIFT)

#define MP2_PUB_SCRATCH1_SET_DATA(mp2_pub_scratch1_reg, data) \
     mp2_pub_scratch1_reg = (mp2_pub_scratch1_reg & ~MP2_PUB_SCRATCH1_DATA_MASK) | (data << MP2_PUB_SCRATCH1_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pub_scratch1_t {
          unsigned int data                           : MP2_PUB_SCRATCH1_DATA_SIZE;
     } mp2_pub_scratch1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pub_scratch1_t {
          unsigned int data                           : MP2_PUB_SCRATCH1_DATA_SIZE;
     } mp2_pub_scratch1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pub_scratch1_t f;
} mp2_pub_scratch1_u;


/*
 * MP2_PUB_SCRATCH2 struct
 */

#define MP2_PUB_SCRATCH2_REG_SIZE      32
#define MP2_PUB_SCRATCH2_DATA_SIZE     32

#define MP2_PUB_SCRATCH2_DATA_SHIFT    0

#define MP2_PUB_SCRATCH2_DATA_MASK     0xffffffff

#define MP2_PUB_SCRATCH2_MASK \
     (MP2_PUB_SCRATCH2_DATA_MASK)

#define MP2_PUB_SCRATCH2_DEFAULT       0x00000000

#define MP2_PUB_SCRATCH2_GET_DATA(mp2_pub_scratch2) \
     ((mp2_pub_scratch2 & MP2_PUB_SCRATCH2_DATA_MASK) >> MP2_PUB_SCRATCH2_DATA_SHIFT)

#define MP2_PUB_SCRATCH2_SET_DATA(mp2_pub_scratch2_reg, data) \
     mp2_pub_scratch2_reg = (mp2_pub_scratch2_reg & ~MP2_PUB_SCRATCH2_DATA_MASK) | (data << MP2_PUB_SCRATCH2_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pub_scratch2_t {
          unsigned int data                           : MP2_PUB_SCRATCH2_DATA_SIZE;
     } mp2_pub_scratch2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pub_scratch2_t {
          unsigned int data                           : MP2_PUB_SCRATCH2_DATA_SIZE;
     } mp2_pub_scratch2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pub_scratch2_t f;
} mp2_pub_scratch2_u;


/*
 * MP2_PUB_SCRATCH3 struct
 */

#define MP2_PUB_SCRATCH3_REG_SIZE      32
#define MP2_PUB_SCRATCH3_DATA_SIZE     32

#define MP2_PUB_SCRATCH3_DATA_SHIFT    0

#define MP2_PUB_SCRATCH3_DATA_MASK     0xffffffff

#define MP2_PUB_SCRATCH3_MASK \
     (MP2_PUB_SCRATCH3_DATA_MASK)

#define MP2_PUB_SCRATCH3_DEFAULT       0x00000000

#define MP2_PUB_SCRATCH3_GET_DATA(mp2_pub_scratch3) \
     ((mp2_pub_scratch3 & MP2_PUB_SCRATCH3_DATA_MASK) >> MP2_PUB_SCRATCH3_DATA_SHIFT)

#define MP2_PUB_SCRATCH3_SET_DATA(mp2_pub_scratch3_reg, data) \
     mp2_pub_scratch3_reg = (mp2_pub_scratch3_reg & ~MP2_PUB_SCRATCH3_DATA_MASK) | (data << MP2_PUB_SCRATCH3_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pub_scratch3_t {
          unsigned int data                           : MP2_PUB_SCRATCH3_DATA_SIZE;
     } mp2_pub_scratch3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pub_scratch3_t {
          unsigned int data                           : MP2_PUB_SCRATCH3_DATA_SIZE;
     } mp2_pub_scratch3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pub_scratch3_t f;
} mp2_pub_scratch3_u;


/*
 * MP2_DFIFO_PUSH struct
 */

#define MP2_DFIFO_PUSH_REG_SIZE        32
#define MP2_DFIFO_PUSH_DATA_SIZE       32

#define MP2_DFIFO_PUSH_DATA_SHIFT      0

#define MP2_DFIFO_PUSH_DATA_MASK       0xffffffff

#define MP2_DFIFO_PUSH_MASK \
     (MP2_DFIFO_PUSH_DATA_MASK)

#define MP2_DFIFO_PUSH_DEFAULT         0x00000000

#define MP2_DFIFO_PUSH_GET_DATA(mp2_dfifo_push) \
     ((mp2_dfifo_push & MP2_DFIFO_PUSH_DATA_MASK) >> MP2_DFIFO_PUSH_DATA_SHIFT)

#define MP2_DFIFO_PUSH_SET_DATA(mp2_dfifo_push_reg, data) \
     mp2_dfifo_push_reg = (mp2_dfifo_push_reg & ~MP2_DFIFO_PUSH_DATA_MASK) | (data << MP2_DFIFO_PUSH_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfifo_push_t {
          unsigned int data                           : MP2_DFIFO_PUSH_DATA_SIZE;
     } mp2_dfifo_push_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfifo_push_t {
          unsigned int data                           : MP2_DFIFO_PUSH_DATA_SIZE;
     } mp2_dfifo_push_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfifo_push_t f;
} mp2_dfifo_push_u;


/*
 * MP2_DFIFO_POP struct
 */

#define MP2_DFIFO_POP_REG_SIZE         32
#define MP2_DFIFO_POP_DATA_SIZE        32

#define MP2_DFIFO_POP_DATA_SHIFT       0

#define MP2_DFIFO_POP_DATA_MASK        0xffffffff

#define MP2_DFIFO_POP_MASK \
     (MP2_DFIFO_POP_DATA_MASK)

#define MP2_DFIFO_POP_DEFAULT          0x00000000

#define MP2_DFIFO_POP_GET_DATA(mp2_dfifo_pop) \
     ((mp2_dfifo_pop & MP2_DFIFO_POP_DATA_MASK) >> MP2_DFIFO_POP_DATA_SHIFT)

#define MP2_DFIFO_POP_SET_DATA(mp2_dfifo_pop_reg, data) \
     mp2_dfifo_pop_reg = (mp2_dfifo_pop_reg & ~MP2_DFIFO_POP_DATA_MASK) | (data << MP2_DFIFO_POP_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfifo_pop_t {
          unsigned int data                           : MP2_DFIFO_POP_DATA_SIZE;
     } mp2_dfifo_pop_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfifo_pop_t {
          unsigned int data                           : MP2_DFIFO_POP_DATA_SIZE;
     } mp2_dfifo_pop_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfifo_pop_t f;
} mp2_dfifo_pop_u;


/*
 * MP2_DFIFO_STATUS struct
 */

#define MP2_DFIFO_STATUS_REG_SIZE      32
#define MP2_DFIFO_STATUS_FIFO_COUNT_SIZE 6
#define MP2_DFIFO_STATUS_FIFO_EMPTY_SIZE 1
#define MP2_DFIFO_STATUS_FIFO_FULL_SIZE 1

#define MP2_DFIFO_STATUS_FIFO_COUNT_SHIFT 0
#define MP2_DFIFO_STATUS_FIFO_EMPTY_SHIFT 8
#define MP2_DFIFO_STATUS_FIFO_FULL_SHIFT 9

#define MP2_DFIFO_STATUS_FIFO_COUNT_MASK 0x3f
#define MP2_DFIFO_STATUS_FIFO_EMPTY_MASK 0x100
#define MP2_DFIFO_STATUS_FIFO_FULL_MASK 0x200

#define MP2_DFIFO_STATUS_MASK \
     (MP2_DFIFO_STATUS_FIFO_COUNT_MASK | \
      MP2_DFIFO_STATUS_FIFO_EMPTY_MASK | \
      MP2_DFIFO_STATUS_FIFO_FULL_MASK)

#define MP2_DFIFO_STATUS_DEFAULT       0x00000100

#define MP2_DFIFO_STATUS_GET_FIFO_COUNT(mp2_dfifo_status) \
     ((mp2_dfifo_status & MP2_DFIFO_STATUS_FIFO_COUNT_MASK) >> MP2_DFIFO_STATUS_FIFO_COUNT_SHIFT)
#define MP2_DFIFO_STATUS_GET_FIFO_EMPTY(mp2_dfifo_status) \
     ((mp2_dfifo_status & MP2_DFIFO_STATUS_FIFO_EMPTY_MASK) >> MP2_DFIFO_STATUS_FIFO_EMPTY_SHIFT)
#define MP2_DFIFO_STATUS_GET_FIFO_FULL(mp2_dfifo_status) \
     ((mp2_dfifo_status & MP2_DFIFO_STATUS_FIFO_FULL_MASK) >> MP2_DFIFO_STATUS_FIFO_FULL_SHIFT)

#define MP2_DFIFO_STATUS_SET_FIFO_COUNT(mp2_dfifo_status_reg, fifo_count) \
     mp2_dfifo_status_reg = (mp2_dfifo_status_reg & ~MP2_DFIFO_STATUS_FIFO_COUNT_MASK) | (fifo_count << MP2_DFIFO_STATUS_FIFO_COUNT_SHIFT)
#define MP2_DFIFO_STATUS_SET_FIFO_EMPTY(mp2_dfifo_status_reg, fifo_empty) \
     mp2_dfifo_status_reg = (mp2_dfifo_status_reg & ~MP2_DFIFO_STATUS_FIFO_EMPTY_MASK) | (fifo_empty << MP2_DFIFO_STATUS_FIFO_EMPTY_SHIFT)
#define MP2_DFIFO_STATUS_SET_FIFO_FULL(mp2_dfifo_status_reg, fifo_full) \
     mp2_dfifo_status_reg = (mp2_dfifo_status_reg & ~MP2_DFIFO_STATUS_FIFO_FULL_MASK) | (fifo_full << MP2_DFIFO_STATUS_FIFO_FULL_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfifo_status_t {
          unsigned int fifo_count                     : MP2_DFIFO_STATUS_FIFO_COUNT_SIZE;
          unsigned int                                : 2;
          unsigned int fifo_empty                     : MP2_DFIFO_STATUS_FIFO_EMPTY_SIZE;
          unsigned int fifo_full                      : MP2_DFIFO_STATUS_FIFO_FULL_SIZE;
          unsigned int                                : 22;
     } mp2_dfifo_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfifo_status_t {
          unsigned int                                : 22;
          unsigned int fifo_full                      : MP2_DFIFO_STATUS_FIFO_FULL_SIZE;
          unsigned int fifo_empty                     : MP2_DFIFO_STATUS_FIFO_EMPTY_SIZE;
          unsigned int                                : 2;
          unsigned int fifo_count                     : MP2_DFIFO_STATUS_FIFO_COUNT_SIZE;
     } mp2_dfifo_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfifo_status_t f;
} mp2_dfifo_status_u;


/*
 * MP2_DFIFO_FLUSH struct
 */

#define MP2_DFIFO_FLUSH_REG_SIZE       32
#define MP2_DFIFO_FLUSH_RESERVED_SIZE  32

#define MP2_DFIFO_FLUSH_RESERVED_SHIFT 0

#define MP2_DFIFO_FLUSH_RESERVED_MASK  0xffffffff

#define MP2_DFIFO_FLUSH_MASK \
     (MP2_DFIFO_FLUSH_RESERVED_MASK)

#define MP2_DFIFO_FLUSH_DEFAULT        0x00000000

#define MP2_DFIFO_FLUSH_GET_RESERVED(mp2_dfifo_flush) \
     ((mp2_dfifo_flush & MP2_DFIFO_FLUSH_RESERVED_MASK) >> MP2_DFIFO_FLUSH_RESERVED_SHIFT)

#define MP2_DFIFO_FLUSH_SET_RESERVED(mp2_dfifo_flush_reg, reserved) \
     mp2_dfifo_flush_reg = (mp2_dfifo_flush_reg & ~MP2_DFIFO_FLUSH_RESERVED_MASK) | (reserved << MP2_DFIFO_FLUSH_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_dfifo_flush_t {
          unsigned int reserved                       : MP2_DFIFO_FLUSH_RESERVED_SIZE;
     } mp2_dfifo_flush_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_dfifo_flush_t {
          unsigned int reserved                       : MP2_DFIFO_FLUSH_RESERVED_SIZE;
     } mp2_dfifo_flush_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_dfifo_flush_t f;
} mp2_dfifo_flush_u;


/*
 * MP2_C2PMSG_0 struct
 */

#define MP2_C2PMSG_0_REG_SIZE          32
#define MP2_C2PMSG_0_CONTENT_SIZE      32

#define MP2_C2PMSG_0_CONTENT_SHIFT     0

#define MP2_C2PMSG_0_CONTENT_MASK      0xffffffff

#define MP2_C2PMSG_0_MASK \
     (MP2_C2PMSG_0_CONTENT_MASK)

#define MP2_C2PMSG_0_DEFAULT           0x00000000

#define MP2_C2PMSG_0_GET_CONTENT(mp2_c2pmsg_0) \
     ((mp2_c2pmsg_0 & MP2_C2PMSG_0_CONTENT_MASK) >> MP2_C2PMSG_0_CONTENT_SHIFT)

#define MP2_C2PMSG_0_SET_CONTENT(mp2_c2pmsg_0_reg, content) \
     mp2_c2pmsg_0_reg = (mp2_c2pmsg_0_reg & ~MP2_C2PMSG_0_CONTENT_MASK) | (content << MP2_C2PMSG_0_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_0_t {
          unsigned int content                        : MP2_C2PMSG_0_CONTENT_SIZE;
     } mp2_c2pmsg_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_0_t {
          unsigned int content                        : MP2_C2PMSG_0_CONTENT_SIZE;
     } mp2_c2pmsg_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_0_t f;
} mp2_c2pmsg_0_u;


/*
 * MP2_C2PMSG_1 struct
 */

#define MP2_C2PMSG_1_REG_SIZE          32
#define MP2_C2PMSG_1_CONTENT_SIZE      32

#define MP2_C2PMSG_1_CONTENT_SHIFT     0

#define MP2_C2PMSG_1_CONTENT_MASK      0xffffffff

#define MP2_C2PMSG_1_MASK \
     (MP2_C2PMSG_1_CONTENT_MASK)

#define MP2_C2PMSG_1_DEFAULT           0x00000000

#define MP2_C2PMSG_1_GET_CONTENT(mp2_c2pmsg_1) \
     ((mp2_c2pmsg_1 & MP2_C2PMSG_1_CONTENT_MASK) >> MP2_C2PMSG_1_CONTENT_SHIFT)

#define MP2_C2PMSG_1_SET_CONTENT(mp2_c2pmsg_1_reg, content) \
     mp2_c2pmsg_1_reg = (mp2_c2pmsg_1_reg & ~MP2_C2PMSG_1_CONTENT_MASK) | (content << MP2_C2PMSG_1_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_1_t {
          unsigned int content                        : MP2_C2PMSG_1_CONTENT_SIZE;
     } mp2_c2pmsg_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_1_t {
          unsigned int content                        : MP2_C2PMSG_1_CONTENT_SIZE;
     } mp2_c2pmsg_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_1_t f;
} mp2_c2pmsg_1_u;


/*
 * MP2_C2PMSG_2 struct
 */

#define MP2_C2PMSG_2_REG_SIZE          32
#define MP2_C2PMSG_2_CONTENT_SIZE      32

#define MP2_C2PMSG_2_CONTENT_SHIFT     0

#define MP2_C2PMSG_2_CONTENT_MASK      0xffffffff

#define MP2_C2PMSG_2_MASK \
     (MP2_C2PMSG_2_CONTENT_MASK)

#define MP2_C2PMSG_2_DEFAULT           0x00000000

#define MP2_C2PMSG_2_GET_CONTENT(mp2_c2pmsg_2) \
     ((mp2_c2pmsg_2 & MP2_C2PMSG_2_CONTENT_MASK) >> MP2_C2PMSG_2_CONTENT_SHIFT)

#define MP2_C2PMSG_2_SET_CONTENT(mp2_c2pmsg_2_reg, content) \
     mp2_c2pmsg_2_reg = (mp2_c2pmsg_2_reg & ~MP2_C2PMSG_2_CONTENT_MASK) | (content << MP2_C2PMSG_2_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_2_t {
          unsigned int content                        : MP2_C2PMSG_2_CONTENT_SIZE;
     } mp2_c2pmsg_2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_2_t {
          unsigned int content                        : MP2_C2PMSG_2_CONTENT_SIZE;
     } mp2_c2pmsg_2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_2_t f;
} mp2_c2pmsg_2_u;


/*
 * MP2_C2PMSG_3 struct
 */

#define MP2_C2PMSG_3_REG_SIZE          32
#define MP2_C2PMSG_3_CONTENT_SIZE      32

#define MP2_C2PMSG_3_CONTENT_SHIFT     0

#define MP2_C2PMSG_3_CONTENT_MASK      0xffffffff

#define MP2_C2PMSG_3_MASK \
     (MP2_C2PMSG_3_CONTENT_MASK)

#define MP2_C2PMSG_3_DEFAULT           0x00000000

#define MP2_C2PMSG_3_GET_CONTENT(mp2_c2pmsg_3) \
     ((mp2_c2pmsg_3 & MP2_C2PMSG_3_CONTENT_MASK) >> MP2_C2PMSG_3_CONTENT_SHIFT)

#define MP2_C2PMSG_3_SET_CONTENT(mp2_c2pmsg_3_reg, content) \
     mp2_c2pmsg_3_reg = (mp2_c2pmsg_3_reg & ~MP2_C2PMSG_3_CONTENT_MASK) | (content << MP2_C2PMSG_3_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_3_t {
          unsigned int content                        : MP2_C2PMSG_3_CONTENT_SIZE;
     } mp2_c2pmsg_3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_3_t {
          unsigned int content                        : MP2_C2PMSG_3_CONTENT_SIZE;
     } mp2_c2pmsg_3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_3_t f;
} mp2_c2pmsg_3_u;


/*
 * MP2_C2PMSG_4 struct
 */

#define MP2_C2PMSG_4_REG_SIZE          32
#define MP2_C2PMSG_4_CONTENT_SIZE      32

#define MP2_C2PMSG_4_CONTENT_SHIFT     0

#define MP2_C2PMSG_4_CONTENT_MASK      0xffffffff

#define MP2_C2PMSG_4_MASK \
     (MP2_C2PMSG_4_CONTENT_MASK)

#define MP2_C2PMSG_4_DEFAULT           0x00000000

#define MP2_C2PMSG_4_GET_CONTENT(mp2_c2pmsg_4) \
     ((mp2_c2pmsg_4 & MP2_C2PMSG_4_CONTENT_MASK) >> MP2_C2PMSG_4_CONTENT_SHIFT)

#define MP2_C2PMSG_4_SET_CONTENT(mp2_c2pmsg_4_reg, content) \
     mp2_c2pmsg_4_reg = (mp2_c2pmsg_4_reg & ~MP2_C2PMSG_4_CONTENT_MASK) | (content << MP2_C2PMSG_4_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_4_t {
          unsigned int content                        : MP2_C2PMSG_4_CONTENT_SIZE;
     } mp2_c2pmsg_4_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_4_t {
          unsigned int content                        : MP2_C2PMSG_4_CONTENT_SIZE;
     } mp2_c2pmsg_4_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_4_t f;
} mp2_c2pmsg_4_u;


/*
 * MP2_C2PMSG_5 struct
 */

#define MP2_C2PMSG_5_REG_SIZE          32
#define MP2_C2PMSG_5_CONTENT_SIZE      32

#define MP2_C2PMSG_5_CONTENT_SHIFT     0

#define MP2_C2PMSG_5_CONTENT_MASK      0xffffffff

#define MP2_C2PMSG_5_MASK \
     (MP2_C2PMSG_5_CONTENT_MASK)

#define MP2_C2PMSG_5_DEFAULT           0x00000000

#define MP2_C2PMSG_5_GET_CONTENT(mp2_c2pmsg_5) \
     ((mp2_c2pmsg_5 & MP2_C2PMSG_5_CONTENT_MASK) >> MP2_C2PMSG_5_CONTENT_SHIFT)

#define MP2_C2PMSG_5_SET_CONTENT(mp2_c2pmsg_5_reg, content) \
     mp2_c2pmsg_5_reg = (mp2_c2pmsg_5_reg & ~MP2_C2PMSG_5_CONTENT_MASK) | (content << MP2_C2PMSG_5_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_5_t {
          unsigned int content                        : MP2_C2PMSG_5_CONTENT_SIZE;
     } mp2_c2pmsg_5_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_5_t {
          unsigned int content                        : MP2_C2PMSG_5_CONTENT_SIZE;
     } mp2_c2pmsg_5_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_5_t f;
} mp2_c2pmsg_5_u;


/*
 * MP2_C2PMSG_6 struct
 */

#define MP2_C2PMSG_6_REG_SIZE          32
#define MP2_C2PMSG_6_CONTENT_SIZE      32

#define MP2_C2PMSG_6_CONTENT_SHIFT     0

#define MP2_C2PMSG_6_CONTENT_MASK      0xffffffff

#define MP2_C2PMSG_6_MASK \
     (MP2_C2PMSG_6_CONTENT_MASK)

#define MP2_C2PMSG_6_DEFAULT           0x00000000

#define MP2_C2PMSG_6_GET_CONTENT(mp2_c2pmsg_6) \
     ((mp2_c2pmsg_6 & MP2_C2PMSG_6_CONTENT_MASK) >> MP2_C2PMSG_6_CONTENT_SHIFT)

#define MP2_C2PMSG_6_SET_CONTENT(mp2_c2pmsg_6_reg, content) \
     mp2_c2pmsg_6_reg = (mp2_c2pmsg_6_reg & ~MP2_C2PMSG_6_CONTENT_MASK) | (content << MP2_C2PMSG_6_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_6_t {
          unsigned int content                        : MP2_C2PMSG_6_CONTENT_SIZE;
     } mp2_c2pmsg_6_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_6_t {
          unsigned int content                        : MP2_C2PMSG_6_CONTENT_SIZE;
     } mp2_c2pmsg_6_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_6_t f;
} mp2_c2pmsg_6_u;


/*
 * MP2_C2PMSG_7 struct
 */

#define MP2_C2PMSG_7_REG_SIZE          32
#define MP2_C2PMSG_7_CONTENT_SIZE      32

#define MP2_C2PMSG_7_CONTENT_SHIFT     0

#define MP2_C2PMSG_7_CONTENT_MASK      0xffffffff

#define MP2_C2PMSG_7_MASK \
     (MP2_C2PMSG_7_CONTENT_MASK)

#define MP2_C2PMSG_7_DEFAULT           0x00000000

#define MP2_C2PMSG_7_GET_CONTENT(mp2_c2pmsg_7) \
     ((mp2_c2pmsg_7 & MP2_C2PMSG_7_CONTENT_MASK) >> MP2_C2PMSG_7_CONTENT_SHIFT)

#define MP2_C2PMSG_7_SET_CONTENT(mp2_c2pmsg_7_reg, content) \
     mp2_c2pmsg_7_reg = (mp2_c2pmsg_7_reg & ~MP2_C2PMSG_7_CONTENT_MASK) | (content << MP2_C2PMSG_7_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_7_t {
          unsigned int content                        : MP2_C2PMSG_7_CONTENT_SIZE;
     } mp2_c2pmsg_7_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_7_t {
          unsigned int content                        : MP2_C2PMSG_7_CONTENT_SIZE;
     } mp2_c2pmsg_7_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_7_t f;
} mp2_c2pmsg_7_u;


/*
 * MP2_C2PMSG_8 struct
 */

#define MP2_C2PMSG_8_REG_SIZE          32
#define MP2_C2PMSG_8_CONTENT_SIZE      32

#define MP2_C2PMSG_8_CONTENT_SHIFT     0

#define MP2_C2PMSG_8_CONTENT_MASK      0xffffffff

#define MP2_C2PMSG_8_MASK \
     (MP2_C2PMSG_8_CONTENT_MASK)

#define MP2_C2PMSG_8_DEFAULT           0x00000000

#define MP2_C2PMSG_8_GET_CONTENT(mp2_c2pmsg_8) \
     ((mp2_c2pmsg_8 & MP2_C2PMSG_8_CONTENT_MASK) >> MP2_C2PMSG_8_CONTENT_SHIFT)

#define MP2_C2PMSG_8_SET_CONTENT(mp2_c2pmsg_8_reg, content) \
     mp2_c2pmsg_8_reg = (mp2_c2pmsg_8_reg & ~MP2_C2PMSG_8_CONTENT_MASK) | (content << MP2_C2PMSG_8_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_8_t {
          unsigned int content                        : MP2_C2PMSG_8_CONTENT_SIZE;
     } mp2_c2pmsg_8_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_8_t {
          unsigned int content                        : MP2_C2PMSG_8_CONTENT_SIZE;
     } mp2_c2pmsg_8_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_8_t f;
} mp2_c2pmsg_8_u;


/*
 * MP2_C2PMSG_9 struct
 */

#define MP2_C2PMSG_9_REG_SIZE          32
#define MP2_C2PMSG_9_CONTENT_SIZE      32

#define MP2_C2PMSG_9_CONTENT_SHIFT     0

#define MP2_C2PMSG_9_CONTENT_MASK      0xffffffff

#define MP2_C2PMSG_9_MASK \
     (MP2_C2PMSG_9_CONTENT_MASK)

#define MP2_C2PMSG_9_DEFAULT           0x00000000

#define MP2_C2PMSG_9_GET_CONTENT(mp2_c2pmsg_9) \
     ((mp2_c2pmsg_9 & MP2_C2PMSG_9_CONTENT_MASK) >> MP2_C2PMSG_9_CONTENT_SHIFT)

#define MP2_C2PMSG_9_SET_CONTENT(mp2_c2pmsg_9_reg, content) \
     mp2_c2pmsg_9_reg = (mp2_c2pmsg_9_reg & ~MP2_C2PMSG_9_CONTENT_MASK) | (content << MP2_C2PMSG_9_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_9_t {
          unsigned int content                        : MP2_C2PMSG_9_CONTENT_SIZE;
     } mp2_c2pmsg_9_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_9_t {
          unsigned int content                        : MP2_C2PMSG_9_CONTENT_SIZE;
     } mp2_c2pmsg_9_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_9_t f;
} mp2_c2pmsg_9_u;


/*
 * MP2_C2PMSG_10 struct
 */

#define MP2_C2PMSG_10_REG_SIZE         32
#define MP2_C2PMSG_10_CONTENT_SIZE     32

#define MP2_C2PMSG_10_CONTENT_SHIFT    0

#define MP2_C2PMSG_10_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_10_MASK \
     (MP2_C2PMSG_10_CONTENT_MASK)

#define MP2_C2PMSG_10_DEFAULT          0x00000000

#define MP2_C2PMSG_10_GET_CONTENT(mp2_c2pmsg_10) \
     ((mp2_c2pmsg_10 & MP2_C2PMSG_10_CONTENT_MASK) >> MP2_C2PMSG_10_CONTENT_SHIFT)

#define MP2_C2PMSG_10_SET_CONTENT(mp2_c2pmsg_10_reg, content) \
     mp2_c2pmsg_10_reg = (mp2_c2pmsg_10_reg & ~MP2_C2PMSG_10_CONTENT_MASK) | (content << MP2_C2PMSG_10_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_10_t {
          unsigned int content                        : MP2_C2PMSG_10_CONTENT_SIZE;
     } mp2_c2pmsg_10_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_10_t {
          unsigned int content                        : MP2_C2PMSG_10_CONTENT_SIZE;
     } mp2_c2pmsg_10_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_10_t f;
} mp2_c2pmsg_10_u;


/*
 * MP2_C2PMSG_11 struct
 */

#define MP2_C2PMSG_11_REG_SIZE         32
#define MP2_C2PMSG_11_CONTENT_SIZE     32

#define MP2_C2PMSG_11_CONTENT_SHIFT    0

#define MP2_C2PMSG_11_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_11_MASK \
     (MP2_C2PMSG_11_CONTENT_MASK)

#define MP2_C2PMSG_11_DEFAULT          0x00000000

#define MP2_C2PMSG_11_GET_CONTENT(mp2_c2pmsg_11) \
     ((mp2_c2pmsg_11 & MP2_C2PMSG_11_CONTENT_MASK) >> MP2_C2PMSG_11_CONTENT_SHIFT)

#define MP2_C2PMSG_11_SET_CONTENT(mp2_c2pmsg_11_reg, content) \
     mp2_c2pmsg_11_reg = (mp2_c2pmsg_11_reg & ~MP2_C2PMSG_11_CONTENT_MASK) | (content << MP2_C2PMSG_11_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_11_t {
          unsigned int content                        : MP2_C2PMSG_11_CONTENT_SIZE;
     } mp2_c2pmsg_11_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_11_t {
          unsigned int content                        : MP2_C2PMSG_11_CONTENT_SIZE;
     } mp2_c2pmsg_11_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_11_t f;
} mp2_c2pmsg_11_u;


/*
 * MP2_C2PMSG_12 struct
 */

#define MP2_C2PMSG_12_REG_SIZE         32
#define MP2_C2PMSG_12_CONTENT_SIZE     32

#define MP2_C2PMSG_12_CONTENT_SHIFT    0

#define MP2_C2PMSG_12_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_12_MASK \
     (MP2_C2PMSG_12_CONTENT_MASK)

#define MP2_C2PMSG_12_DEFAULT          0x00000000

#define MP2_C2PMSG_12_GET_CONTENT(mp2_c2pmsg_12) \
     ((mp2_c2pmsg_12 & MP2_C2PMSG_12_CONTENT_MASK) >> MP2_C2PMSG_12_CONTENT_SHIFT)

#define MP2_C2PMSG_12_SET_CONTENT(mp2_c2pmsg_12_reg, content) \
     mp2_c2pmsg_12_reg = (mp2_c2pmsg_12_reg & ~MP2_C2PMSG_12_CONTENT_MASK) | (content << MP2_C2PMSG_12_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_12_t {
          unsigned int content                        : MP2_C2PMSG_12_CONTENT_SIZE;
     } mp2_c2pmsg_12_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_12_t {
          unsigned int content                        : MP2_C2PMSG_12_CONTENT_SIZE;
     } mp2_c2pmsg_12_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_12_t f;
} mp2_c2pmsg_12_u;


/*
 * MP2_C2PMSG_13 struct
 */

#define MP2_C2PMSG_13_REG_SIZE         32
#define MP2_C2PMSG_13_CONTENT_SIZE     32

#define MP2_C2PMSG_13_CONTENT_SHIFT    0

#define MP2_C2PMSG_13_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_13_MASK \
     (MP2_C2PMSG_13_CONTENT_MASK)

#define MP2_C2PMSG_13_DEFAULT          0x00000000

#define MP2_C2PMSG_13_GET_CONTENT(mp2_c2pmsg_13) \
     ((mp2_c2pmsg_13 & MP2_C2PMSG_13_CONTENT_MASK) >> MP2_C2PMSG_13_CONTENT_SHIFT)

#define MP2_C2PMSG_13_SET_CONTENT(mp2_c2pmsg_13_reg, content) \
     mp2_c2pmsg_13_reg = (mp2_c2pmsg_13_reg & ~MP2_C2PMSG_13_CONTENT_MASK) | (content << MP2_C2PMSG_13_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_13_t {
          unsigned int content                        : MP2_C2PMSG_13_CONTENT_SIZE;
     } mp2_c2pmsg_13_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_13_t {
          unsigned int content                        : MP2_C2PMSG_13_CONTENT_SIZE;
     } mp2_c2pmsg_13_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_13_t f;
} mp2_c2pmsg_13_u;


/*
 * MP2_C2PMSG_14 struct
 */

#define MP2_C2PMSG_14_REG_SIZE         32
#define MP2_C2PMSG_14_CONTENT_SIZE     32

#define MP2_C2PMSG_14_CONTENT_SHIFT    0

#define MP2_C2PMSG_14_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_14_MASK \
     (MP2_C2PMSG_14_CONTENT_MASK)

#define MP2_C2PMSG_14_DEFAULT          0x00000000

#define MP2_C2PMSG_14_GET_CONTENT(mp2_c2pmsg_14) \
     ((mp2_c2pmsg_14 & MP2_C2PMSG_14_CONTENT_MASK) >> MP2_C2PMSG_14_CONTENT_SHIFT)

#define MP2_C2PMSG_14_SET_CONTENT(mp2_c2pmsg_14_reg, content) \
     mp2_c2pmsg_14_reg = (mp2_c2pmsg_14_reg & ~MP2_C2PMSG_14_CONTENT_MASK) | (content << MP2_C2PMSG_14_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_14_t {
          unsigned int content                        : MP2_C2PMSG_14_CONTENT_SIZE;
     } mp2_c2pmsg_14_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_14_t {
          unsigned int content                        : MP2_C2PMSG_14_CONTENT_SIZE;
     } mp2_c2pmsg_14_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_14_t f;
} mp2_c2pmsg_14_u;


/*
 * MP2_C2PMSG_15 struct
 */

#define MP2_C2PMSG_15_REG_SIZE         32
#define MP2_C2PMSG_15_CONTENT_SIZE     32

#define MP2_C2PMSG_15_CONTENT_SHIFT    0

#define MP2_C2PMSG_15_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_15_MASK \
     (MP2_C2PMSG_15_CONTENT_MASK)

#define MP2_C2PMSG_15_DEFAULT          0x00000000

#define MP2_C2PMSG_15_GET_CONTENT(mp2_c2pmsg_15) \
     ((mp2_c2pmsg_15 & MP2_C2PMSG_15_CONTENT_MASK) >> MP2_C2PMSG_15_CONTENT_SHIFT)

#define MP2_C2PMSG_15_SET_CONTENT(mp2_c2pmsg_15_reg, content) \
     mp2_c2pmsg_15_reg = (mp2_c2pmsg_15_reg & ~MP2_C2PMSG_15_CONTENT_MASK) | (content << MP2_C2PMSG_15_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_15_t {
          unsigned int content                        : MP2_C2PMSG_15_CONTENT_SIZE;
     } mp2_c2pmsg_15_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_15_t {
          unsigned int content                        : MP2_C2PMSG_15_CONTENT_SIZE;
     } mp2_c2pmsg_15_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_15_t f;
} mp2_c2pmsg_15_u;


/*
 * MP2_C2PMSG_16 struct
 */

#define MP2_C2PMSG_16_REG_SIZE         32
#define MP2_C2PMSG_16_CONTENT_SIZE     32

#define MP2_C2PMSG_16_CONTENT_SHIFT    0

#define MP2_C2PMSG_16_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_16_MASK \
     (MP2_C2PMSG_16_CONTENT_MASK)

#define MP2_C2PMSG_16_DEFAULT          0x00000000

#define MP2_C2PMSG_16_GET_CONTENT(mp2_c2pmsg_16) \
     ((mp2_c2pmsg_16 & MP2_C2PMSG_16_CONTENT_MASK) >> MP2_C2PMSG_16_CONTENT_SHIFT)

#define MP2_C2PMSG_16_SET_CONTENT(mp2_c2pmsg_16_reg, content) \
     mp2_c2pmsg_16_reg = (mp2_c2pmsg_16_reg & ~MP2_C2PMSG_16_CONTENT_MASK) | (content << MP2_C2PMSG_16_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_16_t {
          unsigned int content                        : MP2_C2PMSG_16_CONTENT_SIZE;
     } mp2_c2pmsg_16_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_16_t {
          unsigned int content                        : MP2_C2PMSG_16_CONTENT_SIZE;
     } mp2_c2pmsg_16_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_16_t f;
} mp2_c2pmsg_16_u;


/*
 * MP2_C2PMSG_17 struct
 */

#define MP2_C2PMSG_17_REG_SIZE         32
#define MP2_C2PMSG_17_CONTENT_SIZE     32

#define MP2_C2PMSG_17_CONTENT_SHIFT    0

#define MP2_C2PMSG_17_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_17_MASK \
     (MP2_C2PMSG_17_CONTENT_MASK)

#define MP2_C2PMSG_17_DEFAULT          0x00000000

#define MP2_C2PMSG_17_GET_CONTENT(mp2_c2pmsg_17) \
     ((mp2_c2pmsg_17 & MP2_C2PMSG_17_CONTENT_MASK) >> MP2_C2PMSG_17_CONTENT_SHIFT)

#define MP2_C2PMSG_17_SET_CONTENT(mp2_c2pmsg_17_reg, content) \
     mp2_c2pmsg_17_reg = (mp2_c2pmsg_17_reg & ~MP2_C2PMSG_17_CONTENT_MASK) | (content << MP2_C2PMSG_17_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_17_t {
          unsigned int content                        : MP2_C2PMSG_17_CONTENT_SIZE;
     } mp2_c2pmsg_17_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_17_t {
          unsigned int content                        : MP2_C2PMSG_17_CONTENT_SIZE;
     } mp2_c2pmsg_17_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_17_t f;
} mp2_c2pmsg_17_u;


/*
 * MP2_C2PMSG_18 struct
 */

#define MP2_C2PMSG_18_REG_SIZE         32
#define MP2_C2PMSG_18_CONTENT_SIZE     32

#define MP2_C2PMSG_18_CONTENT_SHIFT    0

#define MP2_C2PMSG_18_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_18_MASK \
     (MP2_C2PMSG_18_CONTENT_MASK)

#define MP2_C2PMSG_18_DEFAULT          0x00000000

#define MP2_C2PMSG_18_GET_CONTENT(mp2_c2pmsg_18) \
     ((mp2_c2pmsg_18 & MP2_C2PMSG_18_CONTENT_MASK) >> MP2_C2PMSG_18_CONTENT_SHIFT)

#define MP2_C2PMSG_18_SET_CONTENT(mp2_c2pmsg_18_reg, content) \
     mp2_c2pmsg_18_reg = (mp2_c2pmsg_18_reg & ~MP2_C2PMSG_18_CONTENT_MASK) | (content << MP2_C2PMSG_18_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_18_t {
          unsigned int content                        : MP2_C2PMSG_18_CONTENT_SIZE;
     } mp2_c2pmsg_18_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_18_t {
          unsigned int content                        : MP2_C2PMSG_18_CONTENT_SIZE;
     } mp2_c2pmsg_18_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_18_t f;
} mp2_c2pmsg_18_u;


/*
 * MP2_C2PMSG_19 struct
 */

#define MP2_C2PMSG_19_REG_SIZE         32
#define MP2_C2PMSG_19_CONTENT_SIZE     32

#define MP2_C2PMSG_19_CONTENT_SHIFT    0

#define MP2_C2PMSG_19_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_19_MASK \
     (MP2_C2PMSG_19_CONTENT_MASK)

#define MP2_C2PMSG_19_DEFAULT          0x00000000

#define MP2_C2PMSG_19_GET_CONTENT(mp2_c2pmsg_19) \
     ((mp2_c2pmsg_19 & MP2_C2PMSG_19_CONTENT_MASK) >> MP2_C2PMSG_19_CONTENT_SHIFT)

#define MP2_C2PMSG_19_SET_CONTENT(mp2_c2pmsg_19_reg, content) \
     mp2_c2pmsg_19_reg = (mp2_c2pmsg_19_reg & ~MP2_C2PMSG_19_CONTENT_MASK) | (content << MP2_C2PMSG_19_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_19_t {
          unsigned int content                        : MP2_C2PMSG_19_CONTENT_SIZE;
     } mp2_c2pmsg_19_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_19_t {
          unsigned int content                        : MP2_C2PMSG_19_CONTENT_SIZE;
     } mp2_c2pmsg_19_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_19_t f;
} mp2_c2pmsg_19_u;


/*
 * MP2_C2PMSG_20 struct
 */

#define MP2_C2PMSG_20_REG_SIZE         32
#define MP2_C2PMSG_20_CONTENT_SIZE     32

#define MP2_C2PMSG_20_CONTENT_SHIFT    0

#define MP2_C2PMSG_20_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_20_MASK \
     (MP2_C2PMSG_20_CONTENT_MASK)

#define MP2_C2PMSG_20_DEFAULT          0x00000000

#define MP2_C2PMSG_20_GET_CONTENT(mp2_c2pmsg_20) \
     ((mp2_c2pmsg_20 & MP2_C2PMSG_20_CONTENT_MASK) >> MP2_C2PMSG_20_CONTENT_SHIFT)

#define MP2_C2PMSG_20_SET_CONTENT(mp2_c2pmsg_20_reg, content) \
     mp2_c2pmsg_20_reg = (mp2_c2pmsg_20_reg & ~MP2_C2PMSG_20_CONTENT_MASK) | (content << MP2_C2PMSG_20_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_20_t {
          unsigned int content                        : MP2_C2PMSG_20_CONTENT_SIZE;
     } mp2_c2pmsg_20_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_20_t {
          unsigned int content                        : MP2_C2PMSG_20_CONTENT_SIZE;
     } mp2_c2pmsg_20_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_20_t f;
} mp2_c2pmsg_20_u;


/*
 * MP2_C2PMSG_21 struct
 */

#define MP2_C2PMSG_21_REG_SIZE         32
#define MP2_C2PMSG_21_CONTENT_SIZE     32

#define MP2_C2PMSG_21_CONTENT_SHIFT    0

#define MP2_C2PMSG_21_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_21_MASK \
     (MP2_C2PMSG_21_CONTENT_MASK)

#define MP2_C2PMSG_21_DEFAULT          0x00000000

#define MP2_C2PMSG_21_GET_CONTENT(mp2_c2pmsg_21) \
     ((mp2_c2pmsg_21 & MP2_C2PMSG_21_CONTENT_MASK) >> MP2_C2PMSG_21_CONTENT_SHIFT)

#define MP2_C2PMSG_21_SET_CONTENT(mp2_c2pmsg_21_reg, content) \
     mp2_c2pmsg_21_reg = (mp2_c2pmsg_21_reg & ~MP2_C2PMSG_21_CONTENT_MASK) | (content << MP2_C2PMSG_21_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_21_t {
          unsigned int content                        : MP2_C2PMSG_21_CONTENT_SIZE;
     } mp2_c2pmsg_21_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_21_t {
          unsigned int content                        : MP2_C2PMSG_21_CONTENT_SIZE;
     } mp2_c2pmsg_21_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_21_t f;
} mp2_c2pmsg_21_u;


/*
 * MP2_C2PMSG_22 struct
 */

#define MP2_C2PMSG_22_REG_SIZE         32
#define MP2_C2PMSG_22_CONTENT_SIZE     32

#define MP2_C2PMSG_22_CONTENT_SHIFT    0

#define MP2_C2PMSG_22_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_22_MASK \
     (MP2_C2PMSG_22_CONTENT_MASK)

#define MP2_C2PMSG_22_DEFAULT          0x00000000

#define MP2_C2PMSG_22_GET_CONTENT(mp2_c2pmsg_22) \
     ((mp2_c2pmsg_22 & MP2_C2PMSG_22_CONTENT_MASK) >> MP2_C2PMSG_22_CONTENT_SHIFT)

#define MP2_C2PMSG_22_SET_CONTENT(mp2_c2pmsg_22_reg, content) \
     mp2_c2pmsg_22_reg = (mp2_c2pmsg_22_reg & ~MP2_C2PMSG_22_CONTENT_MASK) | (content << MP2_C2PMSG_22_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_22_t {
          unsigned int content                        : MP2_C2PMSG_22_CONTENT_SIZE;
     } mp2_c2pmsg_22_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_22_t {
          unsigned int content                        : MP2_C2PMSG_22_CONTENT_SIZE;
     } mp2_c2pmsg_22_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_22_t f;
} mp2_c2pmsg_22_u;


/*
 * MP2_C2PMSG_23 struct
 */

#define MP2_C2PMSG_23_REG_SIZE         32
#define MP2_C2PMSG_23_CONTENT_SIZE     32

#define MP2_C2PMSG_23_CONTENT_SHIFT    0

#define MP2_C2PMSG_23_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_23_MASK \
     (MP2_C2PMSG_23_CONTENT_MASK)

#define MP2_C2PMSG_23_DEFAULT          0x00000000

#define MP2_C2PMSG_23_GET_CONTENT(mp2_c2pmsg_23) \
     ((mp2_c2pmsg_23 & MP2_C2PMSG_23_CONTENT_MASK) >> MP2_C2PMSG_23_CONTENT_SHIFT)

#define MP2_C2PMSG_23_SET_CONTENT(mp2_c2pmsg_23_reg, content) \
     mp2_c2pmsg_23_reg = (mp2_c2pmsg_23_reg & ~MP2_C2PMSG_23_CONTENT_MASK) | (content << MP2_C2PMSG_23_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_23_t {
          unsigned int content                        : MP2_C2PMSG_23_CONTENT_SIZE;
     } mp2_c2pmsg_23_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_23_t {
          unsigned int content                        : MP2_C2PMSG_23_CONTENT_SIZE;
     } mp2_c2pmsg_23_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_23_t f;
} mp2_c2pmsg_23_u;


/*
 * MP2_C2PMSG_24 struct
 */

#define MP2_C2PMSG_24_REG_SIZE         32
#define MP2_C2PMSG_24_CONTENT_SIZE     32

#define MP2_C2PMSG_24_CONTENT_SHIFT    0

#define MP2_C2PMSG_24_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_24_MASK \
     (MP2_C2PMSG_24_CONTENT_MASK)

#define MP2_C2PMSG_24_DEFAULT          0x00000000

#define MP2_C2PMSG_24_GET_CONTENT(mp2_c2pmsg_24) \
     ((mp2_c2pmsg_24 & MP2_C2PMSG_24_CONTENT_MASK) >> MP2_C2PMSG_24_CONTENT_SHIFT)

#define MP2_C2PMSG_24_SET_CONTENT(mp2_c2pmsg_24_reg, content) \
     mp2_c2pmsg_24_reg = (mp2_c2pmsg_24_reg & ~MP2_C2PMSG_24_CONTENT_MASK) | (content << MP2_C2PMSG_24_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_24_t {
          unsigned int content                        : MP2_C2PMSG_24_CONTENT_SIZE;
     } mp2_c2pmsg_24_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_24_t {
          unsigned int content                        : MP2_C2PMSG_24_CONTENT_SIZE;
     } mp2_c2pmsg_24_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_24_t f;
} mp2_c2pmsg_24_u;


/*
 * MP2_C2PMSG_25 struct
 */

#define MP2_C2PMSG_25_REG_SIZE         32
#define MP2_C2PMSG_25_CONTENT_SIZE     32

#define MP2_C2PMSG_25_CONTENT_SHIFT    0

#define MP2_C2PMSG_25_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_25_MASK \
     (MP2_C2PMSG_25_CONTENT_MASK)

#define MP2_C2PMSG_25_DEFAULT          0x00000000

#define MP2_C2PMSG_25_GET_CONTENT(mp2_c2pmsg_25) \
     ((mp2_c2pmsg_25 & MP2_C2PMSG_25_CONTENT_MASK) >> MP2_C2PMSG_25_CONTENT_SHIFT)

#define MP2_C2PMSG_25_SET_CONTENT(mp2_c2pmsg_25_reg, content) \
     mp2_c2pmsg_25_reg = (mp2_c2pmsg_25_reg & ~MP2_C2PMSG_25_CONTENT_MASK) | (content << MP2_C2PMSG_25_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_25_t {
          unsigned int content                        : MP2_C2PMSG_25_CONTENT_SIZE;
     } mp2_c2pmsg_25_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_25_t {
          unsigned int content                        : MP2_C2PMSG_25_CONTENT_SIZE;
     } mp2_c2pmsg_25_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_25_t f;
} mp2_c2pmsg_25_u;


/*
 * MP2_C2PMSG_26 struct
 */

#define MP2_C2PMSG_26_REG_SIZE         32
#define MP2_C2PMSG_26_CONTENT_SIZE     32

#define MP2_C2PMSG_26_CONTENT_SHIFT    0

#define MP2_C2PMSG_26_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_26_MASK \
     (MP2_C2PMSG_26_CONTENT_MASK)

#define MP2_C2PMSG_26_DEFAULT          0x00000000

#define MP2_C2PMSG_26_GET_CONTENT(mp2_c2pmsg_26) \
     ((mp2_c2pmsg_26 & MP2_C2PMSG_26_CONTENT_MASK) >> MP2_C2PMSG_26_CONTENT_SHIFT)

#define MP2_C2PMSG_26_SET_CONTENT(mp2_c2pmsg_26_reg, content) \
     mp2_c2pmsg_26_reg = (mp2_c2pmsg_26_reg & ~MP2_C2PMSG_26_CONTENT_MASK) | (content << MP2_C2PMSG_26_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_26_t {
          unsigned int content                        : MP2_C2PMSG_26_CONTENT_SIZE;
     } mp2_c2pmsg_26_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_26_t {
          unsigned int content                        : MP2_C2PMSG_26_CONTENT_SIZE;
     } mp2_c2pmsg_26_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_26_t f;
} mp2_c2pmsg_26_u;


/*
 * MP2_C2PMSG_27 struct
 */

#define MP2_C2PMSG_27_REG_SIZE         32
#define MP2_C2PMSG_27_CONTENT_SIZE     32

#define MP2_C2PMSG_27_CONTENT_SHIFT    0

#define MP2_C2PMSG_27_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_27_MASK \
     (MP2_C2PMSG_27_CONTENT_MASK)

#define MP2_C2PMSG_27_DEFAULT          0x00000000

#define MP2_C2PMSG_27_GET_CONTENT(mp2_c2pmsg_27) \
     ((mp2_c2pmsg_27 & MP2_C2PMSG_27_CONTENT_MASK) >> MP2_C2PMSG_27_CONTENT_SHIFT)

#define MP2_C2PMSG_27_SET_CONTENT(mp2_c2pmsg_27_reg, content) \
     mp2_c2pmsg_27_reg = (mp2_c2pmsg_27_reg & ~MP2_C2PMSG_27_CONTENT_MASK) | (content << MP2_C2PMSG_27_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_27_t {
          unsigned int content                        : MP2_C2PMSG_27_CONTENT_SIZE;
     } mp2_c2pmsg_27_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_27_t {
          unsigned int content                        : MP2_C2PMSG_27_CONTENT_SIZE;
     } mp2_c2pmsg_27_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_27_t f;
} mp2_c2pmsg_27_u;


/*
 * MP2_C2PMSG_28 struct
 */

#define MP2_C2PMSG_28_REG_SIZE         32
#define MP2_C2PMSG_28_CONTENT_SIZE     32

#define MP2_C2PMSG_28_CONTENT_SHIFT    0

#define MP2_C2PMSG_28_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_28_MASK \
     (MP2_C2PMSG_28_CONTENT_MASK)

#define MP2_C2PMSG_28_DEFAULT          0x00000000

#define MP2_C2PMSG_28_GET_CONTENT(mp2_c2pmsg_28) \
     ((mp2_c2pmsg_28 & MP2_C2PMSG_28_CONTENT_MASK) >> MP2_C2PMSG_28_CONTENT_SHIFT)

#define MP2_C2PMSG_28_SET_CONTENT(mp2_c2pmsg_28_reg, content) \
     mp2_c2pmsg_28_reg = (mp2_c2pmsg_28_reg & ~MP2_C2PMSG_28_CONTENT_MASK) | (content << MP2_C2PMSG_28_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_28_t {
          unsigned int content                        : MP2_C2PMSG_28_CONTENT_SIZE;
     } mp2_c2pmsg_28_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_28_t {
          unsigned int content                        : MP2_C2PMSG_28_CONTENT_SIZE;
     } mp2_c2pmsg_28_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_28_t f;
} mp2_c2pmsg_28_u;


/*
 * MP2_C2PMSG_29 struct
 */

#define MP2_C2PMSG_29_REG_SIZE         32
#define MP2_C2PMSG_29_CONTENT_SIZE     32

#define MP2_C2PMSG_29_CONTENT_SHIFT    0

#define MP2_C2PMSG_29_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_29_MASK \
     (MP2_C2PMSG_29_CONTENT_MASK)

#define MP2_C2PMSG_29_DEFAULT          0x00000000

#define MP2_C2PMSG_29_GET_CONTENT(mp2_c2pmsg_29) \
     ((mp2_c2pmsg_29 & MP2_C2PMSG_29_CONTENT_MASK) >> MP2_C2PMSG_29_CONTENT_SHIFT)

#define MP2_C2PMSG_29_SET_CONTENT(mp2_c2pmsg_29_reg, content) \
     mp2_c2pmsg_29_reg = (mp2_c2pmsg_29_reg & ~MP2_C2PMSG_29_CONTENT_MASK) | (content << MP2_C2PMSG_29_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_29_t {
          unsigned int content                        : MP2_C2PMSG_29_CONTENT_SIZE;
     } mp2_c2pmsg_29_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_29_t {
          unsigned int content                        : MP2_C2PMSG_29_CONTENT_SIZE;
     } mp2_c2pmsg_29_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_29_t f;
} mp2_c2pmsg_29_u;


/*
 * MP2_C2PMSG_30 struct
 */

#define MP2_C2PMSG_30_REG_SIZE         32
#define MP2_C2PMSG_30_CONTENT_SIZE     32

#define MP2_C2PMSG_30_CONTENT_SHIFT    0

#define MP2_C2PMSG_30_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_30_MASK \
     (MP2_C2PMSG_30_CONTENT_MASK)

#define MP2_C2PMSG_30_DEFAULT          0x00000000

#define MP2_C2PMSG_30_GET_CONTENT(mp2_c2pmsg_30) \
     ((mp2_c2pmsg_30 & MP2_C2PMSG_30_CONTENT_MASK) >> MP2_C2PMSG_30_CONTENT_SHIFT)

#define MP2_C2PMSG_30_SET_CONTENT(mp2_c2pmsg_30_reg, content) \
     mp2_c2pmsg_30_reg = (mp2_c2pmsg_30_reg & ~MP2_C2PMSG_30_CONTENT_MASK) | (content << MP2_C2PMSG_30_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_30_t {
          unsigned int content                        : MP2_C2PMSG_30_CONTENT_SIZE;
     } mp2_c2pmsg_30_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_30_t {
          unsigned int content                        : MP2_C2PMSG_30_CONTENT_SIZE;
     } mp2_c2pmsg_30_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_30_t f;
} mp2_c2pmsg_30_u;


/*
 * MP2_C2PMSG_31 struct
 */

#define MP2_C2PMSG_31_REG_SIZE         32
#define MP2_C2PMSG_31_CONTENT_SIZE     32

#define MP2_C2PMSG_31_CONTENT_SHIFT    0

#define MP2_C2PMSG_31_CONTENT_MASK     0xffffffff

#define MP2_C2PMSG_31_MASK \
     (MP2_C2PMSG_31_CONTENT_MASK)

#define MP2_C2PMSG_31_DEFAULT          0x00000000

#define MP2_C2PMSG_31_GET_CONTENT(mp2_c2pmsg_31) \
     ((mp2_c2pmsg_31 & MP2_C2PMSG_31_CONTENT_MASK) >> MP2_C2PMSG_31_CONTENT_SHIFT)

#define MP2_C2PMSG_31_SET_CONTENT(mp2_c2pmsg_31_reg, content) \
     mp2_c2pmsg_31_reg = (mp2_c2pmsg_31_reg & ~MP2_C2PMSG_31_CONTENT_MASK) | (content << MP2_C2PMSG_31_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_31_t {
          unsigned int content                        : MP2_C2PMSG_31_CONTENT_SIZE;
     } mp2_c2pmsg_31_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_31_t {
          unsigned int content                        : MP2_C2PMSG_31_CONTENT_SIZE;
     } mp2_c2pmsg_31_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_31_t f;
} mp2_c2pmsg_31_u;


/*
 * MP2_P2CMSG_0 struct
 */

#define MP2_P2CMSG_0_REG_SIZE          32
#define MP2_P2CMSG_0_CONTENT_SIZE      32

#define MP2_P2CMSG_0_CONTENT_SHIFT     0

#define MP2_P2CMSG_0_CONTENT_MASK      0xffffffff

#define MP2_P2CMSG_0_MASK \
     (MP2_P2CMSG_0_CONTENT_MASK)

#define MP2_P2CMSG_0_DEFAULT           0x00000000

#define MP2_P2CMSG_0_GET_CONTENT(mp2_p2cmsg_0) \
     ((mp2_p2cmsg_0 & MP2_P2CMSG_0_CONTENT_MASK) >> MP2_P2CMSG_0_CONTENT_SHIFT)

#define MP2_P2CMSG_0_SET_CONTENT(mp2_p2cmsg_0_reg, content) \
     mp2_p2cmsg_0_reg = (mp2_p2cmsg_0_reg & ~MP2_P2CMSG_0_CONTENT_MASK) | (content << MP2_P2CMSG_0_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_p2cmsg_0_t {
          unsigned int content                        : MP2_P2CMSG_0_CONTENT_SIZE;
     } mp2_p2cmsg_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_p2cmsg_0_t {
          unsigned int content                        : MP2_P2CMSG_0_CONTENT_SIZE;
     } mp2_p2cmsg_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_p2cmsg_0_t f;
} mp2_p2cmsg_0_u;


/*
 * MP2_P2CMSG_1 struct
 */

#define MP2_P2CMSG_1_REG_SIZE          32
#define MP2_P2CMSG_1_CONTENT_SIZE      32

#define MP2_P2CMSG_1_CONTENT_SHIFT     0

#define MP2_P2CMSG_1_CONTENT_MASK      0xffffffff

#define MP2_P2CMSG_1_MASK \
     (MP2_P2CMSG_1_CONTENT_MASK)

#define MP2_P2CMSG_1_DEFAULT           0x00000000

#define MP2_P2CMSG_1_GET_CONTENT(mp2_p2cmsg_1) \
     ((mp2_p2cmsg_1 & MP2_P2CMSG_1_CONTENT_MASK) >> MP2_P2CMSG_1_CONTENT_SHIFT)

#define MP2_P2CMSG_1_SET_CONTENT(mp2_p2cmsg_1_reg, content) \
     mp2_p2cmsg_1_reg = (mp2_p2cmsg_1_reg & ~MP2_P2CMSG_1_CONTENT_MASK) | (content << MP2_P2CMSG_1_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_p2cmsg_1_t {
          unsigned int content                        : MP2_P2CMSG_1_CONTENT_SIZE;
     } mp2_p2cmsg_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_p2cmsg_1_t {
          unsigned int content                        : MP2_P2CMSG_1_CONTENT_SIZE;
     } mp2_p2cmsg_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_p2cmsg_1_t f;
} mp2_p2cmsg_1_u;


/*
 * MP2_P2CMSG_2 struct
 */

#define MP2_P2CMSG_2_REG_SIZE          32
#define MP2_P2CMSG_2_CONTENT_SIZE      32

#define MP2_P2CMSG_2_CONTENT_SHIFT     0

#define MP2_P2CMSG_2_CONTENT_MASK      0xffffffff

#define MP2_P2CMSG_2_MASK \
     (MP2_P2CMSG_2_CONTENT_MASK)

#define MP2_P2CMSG_2_DEFAULT           0x00000000

#define MP2_P2CMSG_2_GET_CONTENT(mp2_p2cmsg_2) \
     ((mp2_p2cmsg_2 & MP2_P2CMSG_2_CONTENT_MASK) >> MP2_P2CMSG_2_CONTENT_SHIFT)

#define MP2_P2CMSG_2_SET_CONTENT(mp2_p2cmsg_2_reg, content) \
     mp2_p2cmsg_2_reg = (mp2_p2cmsg_2_reg & ~MP2_P2CMSG_2_CONTENT_MASK) | (content << MP2_P2CMSG_2_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_p2cmsg_2_t {
          unsigned int content                        : MP2_P2CMSG_2_CONTENT_SIZE;
     } mp2_p2cmsg_2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_p2cmsg_2_t {
          unsigned int content                        : MP2_P2CMSG_2_CONTENT_SIZE;
     } mp2_p2cmsg_2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_p2cmsg_2_t f;
} mp2_p2cmsg_2_u;


/*
 * MP2_P2CMSG_3 struct
 */

#define MP2_P2CMSG_3_REG_SIZE          32
#define MP2_P2CMSG_3_CONTENT_SIZE      32

#define MP2_P2CMSG_3_CONTENT_SHIFT     0

#define MP2_P2CMSG_3_CONTENT_MASK      0xffffffff

#define MP2_P2CMSG_3_MASK \
     (MP2_P2CMSG_3_CONTENT_MASK)

#define MP2_P2CMSG_3_DEFAULT           0x00000000

#define MP2_P2CMSG_3_GET_CONTENT(mp2_p2cmsg_3) \
     ((mp2_p2cmsg_3 & MP2_P2CMSG_3_CONTENT_MASK) >> MP2_P2CMSG_3_CONTENT_SHIFT)

#define MP2_P2CMSG_3_SET_CONTENT(mp2_p2cmsg_3_reg, content) \
     mp2_p2cmsg_3_reg = (mp2_p2cmsg_3_reg & ~MP2_P2CMSG_3_CONTENT_MASK) | (content << MP2_P2CMSG_3_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_p2cmsg_3_t {
          unsigned int content                        : MP2_P2CMSG_3_CONTENT_SIZE;
     } mp2_p2cmsg_3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_p2cmsg_3_t {
          unsigned int content                        : MP2_P2CMSG_3_CONTENT_SIZE;
     } mp2_p2cmsg_3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_p2cmsg_3_t f;
} mp2_p2cmsg_3_u;


/*
 * MP2_P2CMSG_INTEN struct
 */

#define MP2_P2CMSG_INTEN_REG_SIZE      32
#define MP2_P2CMSG_INTEN_INTEN_SIZE    4

#define MP2_P2CMSG_INTEN_INTEN_SHIFT   0

#define MP2_P2CMSG_INTEN_INTEN_MASK    0xf

#define MP2_P2CMSG_INTEN_MASK \
     (MP2_P2CMSG_INTEN_INTEN_MASK)

#define MP2_P2CMSG_INTEN_DEFAULT       0x00000000

#define MP2_P2CMSG_INTEN_GET_INTEN(mp2_p2cmsg_inten) \
     ((mp2_p2cmsg_inten & MP2_P2CMSG_INTEN_INTEN_MASK) >> MP2_P2CMSG_INTEN_INTEN_SHIFT)

#define MP2_P2CMSG_INTEN_SET_INTEN(mp2_p2cmsg_inten_reg, inten) \
     mp2_p2cmsg_inten_reg = (mp2_p2cmsg_inten_reg & ~MP2_P2CMSG_INTEN_INTEN_MASK) | (inten << MP2_P2CMSG_INTEN_INTEN_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_p2cmsg_inten_t {
          unsigned int inten                          : MP2_P2CMSG_INTEN_INTEN_SIZE;
          unsigned int                                : 28;
     } mp2_p2cmsg_inten_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_p2cmsg_inten_t {
          unsigned int                                : 28;
          unsigned int inten                          : MP2_P2CMSG_INTEN_INTEN_SIZE;
     } mp2_p2cmsg_inten_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_p2cmsg_inten_t f;
} mp2_p2cmsg_inten_u;


/*
 * MP2_P2CMSG_INTSTS struct
 */

#define MP2_P2CMSG_INTSTS_REG_SIZE     32
#define MP2_P2CMSG_INTSTS_INTSTS0_SIZE 1
#define MP2_P2CMSG_INTSTS_INTSTS1_SIZE 1
#define MP2_P2CMSG_INTSTS_INTSTS2_SIZE 1
#define MP2_P2CMSG_INTSTS_INTSTS3_SIZE 1

#define MP2_P2CMSG_INTSTS_INTSTS0_SHIFT 0
#define MP2_P2CMSG_INTSTS_INTSTS1_SHIFT 1
#define MP2_P2CMSG_INTSTS_INTSTS2_SHIFT 2
#define MP2_P2CMSG_INTSTS_INTSTS3_SHIFT 3

#define MP2_P2CMSG_INTSTS_INTSTS0_MASK 0x1
#define MP2_P2CMSG_INTSTS_INTSTS1_MASK 0x2
#define MP2_P2CMSG_INTSTS_INTSTS2_MASK 0x4
#define MP2_P2CMSG_INTSTS_INTSTS3_MASK 0x8

#define MP2_P2CMSG_INTSTS_MASK \
     (MP2_P2CMSG_INTSTS_INTSTS0_MASK | \
      MP2_P2CMSG_INTSTS_INTSTS1_MASK | \
      MP2_P2CMSG_INTSTS_INTSTS2_MASK | \
      MP2_P2CMSG_INTSTS_INTSTS3_MASK)

#define MP2_P2CMSG_INTSTS_DEFAULT      0x00000000

#define MP2_P2CMSG_INTSTS_GET_INTSTS0(mp2_p2cmsg_intsts) \
     ((mp2_p2cmsg_intsts & MP2_P2CMSG_INTSTS_INTSTS0_MASK) >> MP2_P2CMSG_INTSTS_INTSTS0_SHIFT)
#define MP2_P2CMSG_INTSTS_GET_INTSTS1(mp2_p2cmsg_intsts) \
     ((mp2_p2cmsg_intsts & MP2_P2CMSG_INTSTS_INTSTS1_MASK) >> MP2_P2CMSG_INTSTS_INTSTS1_SHIFT)
#define MP2_P2CMSG_INTSTS_GET_INTSTS2(mp2_p2cmsg_intsts) \
     ((mp2_p2cmsg_intsts & MP2_P2CMSG_INTSTS_INTSTS2_MASK) >> MP2_P2CMSG_INTSTS_INTSTS2_SHIFT)
#define MP2_P2CMSG_INTSTS_GET_INTSTS3(mp2_p2cmsg_intsts) \
     ((mp2_p2cmsg_intsts & MP2_P2CMSG_INTSTS_INTSTS3_MASK) >> MP2_P2CMSG_INTSTS_INTSTS3_SHIFT)

#define MP2_P2CMSG_INTSTS_SET_INTSTS0(mp2_p2cmsg_intsts_reg, intsts0) \
     mp2_p2cmsg_intsts_reg = (mp2_p2cmsg_intsts_reg & ~MP2_P2CMSG_INTSTS_INTSTS0_MASK) | (intsts0 << MP2_P2CMSG_INTSTS_INTSTS0_SHIFT)
#define MP2_P2CMSG_INTSTS_SET_INTSTS1(mp2_p2cmsg_intsts_reg, intsts1) \
     mp2_p2cmsg_intsts_reg = (mp2_p2cmsg_intsts_reg & ~MP2_P2CMSG_INTSTS_INTSTS1_MASK) | (intsts1 << MP2_P2CMSG_INTSTS_INTSTS1_SHIFT)
#define MP2_P2CMSG_INTSTS_SET_INTSTS2(mp2_p2cmsg_intsts_reg, intsts2) \
     mp2_p2cmsg_intsts_reg = (mp2_p2cmsg_intsts_reg & ~MP2_P2CMSG_INTSTS_INTSTS2_MASK) | (intsts2 << MP2_P2CMSG_INTSTS_INTSTS2_SHIFT)
#define MP2_P2CMSG_INTSTS_SET_INTSTS3(mp2_p2cmsg_intsts_reg, intsts3) \
     mp2_p2cmsg_intsts_reg = (mp2_p2cmsg_intsts_reg & ~MP2_P2CMSG_INTSTS_INTSTS3_MASK) | (intsts3 << MP2_P2CMSG_INTSTS_INTSTS3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_p2cmsg_intsts_t {
          unsigned int intsts0                        : MP2_P2CMSG_INTSTS_INTSTS0_SIZE;
          unsigned int intsts1                        : MP2_P2CMSG_INTSTS_INTSTS1_SIZE;
          unsigned int intsts2                        : MP2_P2CMSG_INTSTS_INTSTS2_SIZE;
          unsigned int intsts3                        : MP2_P2CMSG_INTSTS_INTSTS3_SIZE;
          unsigned int                                : 28;
     } mp2_p2cmsg_intsts_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_p2cmsg_intsts_t {
          unsigned int                                : 28;
          unsigned int intsts3                        : MP2_P2CMSG_INTSTS_INTSTS3_SIZE;
          unsigned int intsts2                        : MP2_P2CMSG_INTSTS_INTSTS2_SIZE;
          unsigned int intsts1                        : MP2_P2CMSG_INTSTS_INTSTS1_SIZE;
          unsigned int intsts0                        : MP2_P2CMSG_INTSTS_INTSTS0_SIZE;
     } mp2_p2cmsg_intsts_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_p2cmsg_intsts_t f;
} mp2_p2cmsg_intsts_u;


/*
 * MP2_P2SMSG_0 struct
 */

#define MP2_P2SMSG_0_REG_SIZE          32
#define MP2_P2SMSG_0_CONTENT_SIZE      32

#define MP2_P2SMSG_0_CONTENT_SHIFT     0

#define MP2_P2SMSG_0_CONTENT_MASK      0xffffffff

#define MP2_P2SMSG_0_MASK \
     (MP2_P2SMSG_0_CONTENT_MASK)

#define MP2_P2SMSG_0_DEFAULT           0x00000000

#define MP2_P2SMSG_0_GET_CONTENT(mp2_p2smsg_0) \
     ((mp2_p2smsg_0 & MP2_P2SMSG_0_CONTENT_MASK) >> MP2_P2SMSG_0_CONTENT_SHIFT)

#define MP2_P2SMSG_0_SET_CONTENT(mp2_p2smsg_0_reg, content) \
     mp2_p2smsg_0_reg = (mp2_p2smsg_0_reg & ~MP2_P2SMSG_0_CONTENT_MASK) | (content << MP2_P2SMSG_0_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_p2smsg_0_t {
          unsigned int content                        : MP2_P2SMSG_0_CONTENT_SIZE;
     } mp2_p2smsg_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_p2smsg_0_t {
          unsigned int content                        : MP2_P2SMSG_0_CONTENT_SIZE;
     } mp2_p2smsg_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_p2smsg_0_t f;
} mp2_p2smsg_0_u;


/*
 * MP2_P2SMSG_1 struct
 */

#define MP2_P2SMSG_1_REG_SIZE          32
#define MP2_P2SMSG_1_CONTENT_SIZE      32

#define MP2_P2SMSG_1_CONTENT_SHIFT     0

#define MP2_P2SMSG_1_CONTENT_MASK      0xffffffff

#define MP2_P2SMSG_1_MASK \
     (MP2_P2SMSG_1_CONTENT_MASK)

#define MP2_P2SMSG_1_DEFAULT           0x00000000

#define MP2_P2SMSG_1_GET_CONTENT(mp2_p2smsg_1) \
     ((mp2_p2smsg_1 & MP2_P2SMSG_1_CONTENT_MASK) >> MP2_P2SMSG_1_CONTENT_SHIFT)

#define MP2_P2SMSG_1_SET_CONTENT(mp2_p2smsg_1_reg, content) \
     mp2_p2smsg_1_reg = (mp2_p2smsg_1_reg & ~MP2_P2SMSG_1_CONTENT_MASK) | (content << MP2_P2SMSG_1_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_p2smsg_1_t {
          unsigned int content                        : MP2_P2SMSG_1_CONTENT_SIZE;
     } mp2_p2smsg_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_p2smsg_1_t {
          unsigned int content                        : MP2_P2SMSG_1_CONTENT_SIZE;
     } mp2_p2smsg_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_p2smsg_1_t f;
} mp2_p2smsg_1_u;


/*
 * MP2_P2SMSG_2 struct
 */

#define MP2_P2SMSG_2_REG_SIZE          32
#define MP2_P2SMSG_2_CONTENT_SIZE      32

#define MP2_P2SMSG_2_CONTENT_SHIFT     0

#define MP2_P2SMSG_2_CONTENT_MASK      0xffffffff

#define MP2_P2SMSG_2_MASK \
     (MP2_P2SMSG_2_CONTENT_MASK)

#define MP2_P2SMSG_2_DEFAULT           0x00000000

#define MP2_P2SMSG_2_GET_CONTENT(mp2_p2smsg_2) \
     ((mp2_p2smsg_2 & MP2_P2SMSG_2_CONTENT_MASK) >> MP2_P2SMSG_2_CONTENT_SHIFT)

#define MP2_P2SMSG_2_SET_CONTENT(mp2_p2smsg_2_reg, content) \
     mp2_p2smsg_2_reg = (mp2_p2smsg_2_reg & ~MP2_P2SMSG_2_CONTENT_MASK) | (content << MP2_P2SMSG_2_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_p2smsg_2_t {
          unsigned int content                        : MP2_P2SMSG_2_CONTENT_SIZE;
     } mp2_p2smsg_2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_p2smsg_2_t {
          unsigned int content                        : MP2_P2SMSG_2_CONTENT_SIZE;
     } mp2_p2smsg_2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_p2smsg_2_t f;
} mp2_p2smsg_2_u;


/*
 * MP2_P2SMSG_3 struct
 */

#define MP2_P2SMSG_3_REG_SIZE          32
#define MP2_P2SMSG_3_CONTENT_SIZE      32

#define MP2_P2SMSG_3_CONTENT_SHIFT     0

#define MP2_P2SMSG_3_CONTENT_MASK      0xffffffff

#define MP2_P2SMSG_3_MASK \
     (MP2_P2SMSG_3_CONTENT_MASK)

#define MP2_P2SMSG_3_DEFAULT           0x00000000

#define MP2_P2SMSG_3_GET_CONTENT(mp2_p2smsg_3) \
     ((mp2_p2smsg_3 & MP2_P2SMSG_3_CONTENT_MASK) >> MP2_P2SMSG_3_CONTENT_SHIFT)

#define MP2_P2SMSG_3_SET_CONTENT(mp2_p2smsg_3_reg, content) \
     mp2_p2smsg_3_reg = (mp2_p2smsg_3_reg & ~MP2_P2SMSG_3_CONTENT_MASK) | (content << MP2_P2SMSG_3_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_p2smsg_3_t {
          unsigned int content                        : MP2_P2SMSG_3_CONTENT_SIZE;
     } mp2_p2smsg_3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_p2smsg_3_t {
          unsigned int content                        : MP2_P2SMSG_3_CONTENT_SIZE;
     } mp2_p2smsg_3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_p2smsg_3_t f;
} mp2_p2smsg_3_u;


/*
 * MP2_P2SMSG_INTSTS struct
 */

#define MP2_P2SMSG_INTSTS_REG_SIZE     32
#define MP2_P2SMSG_INTSTS_INTSTS0_SIZE 1
#define MP2_P2SMSG_INTSTS_INTSTS1_SIZE 1
#define MP2_P2SMSG_INTSTS_INTSTS2_SIZE 1
#define MP2_P2SMSG_INTSTS_INTSTS3_SIZE 1

#define MP2_P2SMSG_INTSTS_INTSTS0_SHIFT 0
#define MP2_P2SMSG_INTSTS_INTSTS1_SHIFT 1
#define MP2_P2SMSG_INTSTS_INTSTS2_SHIFT 2
#define MP2_P2SMSG_INTSTS_INTSTS3_SHIFT 3

#define MP2_P2SMSG_INTSTS_INTSTS0_MASK 0x1
#define MP2_P2SMSG_INTSTS_INTSTS1_MASK 0x2
#define MP2_P2SMSG_INTSTS_INTSTS2_MASK 0x4
#define MP2_P2SMSG_INTSTS_INTSTS3_MASK 0x8

#define MP2_P2SMSG_INTSTS_MASK \
     (MP2_P2SMSG_INTSTS_INTSTS0_MASK | \
      MP2_P2SMSG_INTSTS_INTSTS1_MASK | \
      MP2_P2SMSG_INTSTS_INTSTS2_MASK | \
      MP2_P2SMSG_INTSTS_INTSTS3_MASK)

#define MP2_P2SMSG_INTSTS_DEFAULT      0x00000000

#define MP2_P2SMSG_INTSTS_GET_INTSTS0(mp2_p2smsg_intsts) \
     ((mp2_p2smsg_intsts & MP2_P2SMSG_INTSTS_INTSTS0_MASK) >> MP2_P2SMSG_INTSTS_INTSTS0_SHIFT)
#define MP2_P2SMSG_INTSTS_GET_INTSTS1(mp2_p2smsg_intsts) \
     ((mp2_p2smsg_intsts & MP2_P2SMSG_INTSTS_INTSTS1_MASK) >> MP2_P2SMSG_INTSTS_INTSTS1_SHIFT)
#define MP2_P2SMSG_INTSTS_GET_INTSTS2(mp2_p2smsg_intsts) \
     ((mp2_p2smsg_intsts & MP2_P2SMSG_INTSTS_INTSTS2_MASK) >> MP2_P2SMSG_INTSTS_INTSTS2_SHIFT)
#define MP2_P2SMSG_INTSTS_GET_INTSTS3(mp2_p2smsg_intsts) \
     ((mp2_p2smsg_intsts & MP2_P2SMSG_INTSTS_INTSTS3_MASK) >> MP2_P2SMSG_INTSTS_INTSTS3_SHIFT)

#define MP2_P2SMSG_INTSTS_SET_INTSTS0(mp2_p2smsg_intsts_reg, intsts0) \
     mp2_p2smsg_intsts_reg = (mp2_p2smsg_intsts_reg & ~MP2_P2SMSG_INTSTS_INTSTS0_MASK) | (intsts0 << MP2_P2SMSG_INTSTS_INTSTS0_SHIFT)
#define MP2_P2SMSG_INTSTS_SET_INTSTS1(mp2_p2smsg_intsts_reg, intsts1) \
     mp2_p2smsg_intsts_reg = (mp2_p2smsg_intsts_reg & ~MP2_P2SMSG_INTSTS_INTSTS1_MASK) | (intsts1 << MP2_P2SMSG_INTSTS_INTSTS1_SHIFT)
#define MP2_P2SMSG_INTSTS_SET_INTSTS2(mp2_p2smsg_intsts_reg, intsts2) \
     mp2_p2smsg_intsts_reg = (mp2_p2smsg_intsts_reg & ~MP2_P2SMSG_INTSTS_INTSTS2_MASK) | (intsts2 << MP2_P2SMSG_INTSTS_INTSTS2_SHIFT)
#define MP2_P2SMSG_INTSTS_SET_INTSTS3(mp2_p2smsg_intsts_reg, intsts3) \
     mp2_p2smsg_intsts_reg = (mp2_p2smsg_intsts_reg & ~MP2_P2SMSG_INTSTS_INTSTS3_MASK) | (intsts3 << MP2_P2SMSG_INTSTS_INTSTS3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_p2smsg_intsts_t {
          unsigned int intsts0                        : MP2_P2SMSG_INTSTS_INTSTS0_SIZE;
          unsigned int intsts1                        : MP2_P2SMSG_INTSTS_INTSTS1_SIZE;
          unsigned int intsts2                        : MP2_P2SMSG_INTSTS_INTSTS2_SIZE;
          unsigned int intsts3                        : MP2_P2SMSG_INTSTS_INTSTS3_SIZE;
          unsigned int                                : 28;
     } mp2_p2smsg_intsts_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_p2smsg_intsts_t {
          unsigned int                                : 28;
          unsigned int intsts3                        : MP2_P2SMSG_INTSTS_INTSTS3_SIZE;
          unsigned int intsts2                        : MP2_P2SMSG_INTSTS_INTSTS2_SIZE;
          unsigned int intsts1                        : MP2_P2SMSG_INTSTS_INTSTS1_SIZE;
          unsigned int intsts0                        : MP2_P2SMSG_INTSTS_INTSTS0_SIZE;
     } mp2_p2smsg_intsts_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_p2smsg_intsts_t f;
} mp2_p2smsg_intsts_u;


/*
 * MP2_S2PMSG_0 struct
 */

#define MP2_S2PMSG_0_REG_SIZE          32
#define MP2_S2PMSG_0_CONTENT_SIZE      32

#define MP2_S2PMSG_0_CONTENT_SHIFT     0

#define MP2_S2PMSG_0_CONTENT_MASK      0xffffffff

#define MP2_S2PMSG_0_MASK \
     (MP2_S2PMSG_0_CONTENT_MASK)

#define MP2_S2PMSG_0_DEFAULT           0x00000000

#define MP2_S2PMSG_0_GET_CONTENT(mp2_s2pmsg_0) \
     ((mp2_s2pmsg_0 & MP2_S2PMSG_0_CONTENT_MASK) >> MP2_S2PMSG_0_CONTENT_SHIFT)

#define MP2_S2PMSG_0_SET_CONTENT(mp2_s2pmsg_0_reg, content) \
     mp2_s2pmsg_0_reg = (mp2_s2pmsg_0_reg & ~MP2_S2PMSG_0_CONTENT_MASK) | (content << MP2_S2PMSG_0_CONTENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_s2pmsg_0_t {
          unsigned int content                        : MP2_S2PMSG_0_CONTENT_SIZE;
     } mp2_s2pmsg_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_s2pmsg_0_t {
          unsigned int content                        : MP2_S2PMSG_0_CONTENT_SIZE;
     } mp2_s2pmsg_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_s2pmsg_0_t f;
} mp2_s2pmsg_0_u;


/*
 * MP2_REVID struct
 */

#define MP2_REVID_REG_SIZE             32
#define MP2_REVID_REVID_SIZE           32

#define MP2_REVID_REVID_SHIFT          0

#define MP2_REVID_REVID_MASK           0xffffffff

#define MP2_REVID_MASK \
     (MP2_REVID_REVID_MASK)

#define MP2_REVID_DEFAULT              0x000d0000

#define MP2_REVID_GET_REVID(mp2_revid) \
     ((mp2_revid & MP2_REVID_REVID_MASK) >> MP2_REVID_REVID_SHIFT)

#define MP2_REVID_SET_REVID(mp2_revid_reg, revid) \
     mp2_revid_reg = (mp2_revid_reg & ~MP2_REVID_REVID_MASK) | (revid << MP2_REVID_REVID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_revid_t {
          unsigned int revid                          : MP2_REVID_REVID_SIZE;
     } mp2_revid_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_revid_t {
          unsigned int revid                          : MP2_REVID_REVID_SIZE;
     } mp2_revid_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_revid_t f;
} mp2_revid_u;


/*
 * MP2_RAM_REPAIR_DONE struct
 */

#define MP2_RAM_REPAIR_DONE_REG_SIZE   32
#define MP2_RAM_REPAIR_DONE_STATUS_SIZE 32

#define MP2_RAM_REPAIR_DONE_STATUS_SHIFT 0

#define MP2_RAM_REPAIR_DONE_STATUS_MASK 0xffffffff

#define MP2_RAM_REPAIR_DONE_MASK \
     (MP2_RAM_REPAIR_DONE_STATUS_MASK)

#define MP2_RAM_REPAIR_DONE_DEFAULT    0x00000000

#define MP2_RAM_REPAIR_DONE_GET_STATUS(mp2_ram_repair_done) \
     ((mp2_ram_repair_done & MP2_RAM_REPAIR_DONE_STATUS_MASK) >> MP2_RAM_REPAIR_DONE_STATUS_SHIFT)

#define MP2_RAM_REPAIR_DONE_SET_STATUS(mp2_ram_repair_done_reg, status) \
     mp2_ram_repair_done_reg = (mp2_ram_repair_done_reg & ~MP2_RAM_REPAIR_DONE_STATUS_MASK) | (status << MP2_RAM_REPAIR_DONE_STATUS_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_ram_repair_done_t {
          unsigned int status                         : MP2_RAM_REPAIR_DONE_STATUS_SIZE;
     } mp2_ram_repair_done_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_ram_repair_done_t {
          unsigned int status                         : MP2_RAM_REPAIR_DONE_STATUS_SIZE;
     } mp2_ram_repair_done_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_ram_repair_done_t f;
} mp2_ram_repair_done_u;


/*
 * MP2_RAM_REPAIR_RESULT struct
 */

#define MP2_RAM_REPAIR_RESULT_REG_SIZE 32
#define MP2_RAM_REPAIR_RESULT_PASS_SIZE 32

#define MP2_RAM_REPAIR_RESULT_PASS_SHIFT 0

#define MP2_RAM_REPAIR_RESULT_PASS_MASK 0xffffffff

#define MP2_RAM_REPAIR_RESULT_MASK \
     (MP2_RAM_REPAIR_RESULT_PASS_MASK)

#define MP2_RAM_REPAIR_RESULT_DEFAULT  0x00000000

#define MP2_RAM_REPAIR_RESULT_GET_PASS(mp2_ram_repair_result) \
     ((mp2_ram_repair_result & MP2_RAM_REPAIR_RESULT_PASS_MASK) >> MP2_RAM_REPAIR_RESULT_PASS_SHIFT)

#define MP2_RAM_REPAIR_RESULT_SET_PASS(mp2_ram_repair_result_reg, pass) \
     mp2_ram_repair_result_reg = (mp2_ram_repair_result_reg & ~MP2_RAM_REPAIR_RESULT_PASS_MASK) | (pass << MP2_RAM_REPAIR_RESULT_PASS_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_ram_repair_result_t {
          unsigned int pass                           : MP2_RAM_REPAIR_RESULT_PASS_SIZE;
     } mp2_ram_repair_result_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_ram_repair_result_t {
          unsigned int pass                           : MP2_RAM_REPAIR_RESULT_PASS_SIZE;
     } mp2_ram_repair_result_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_ram_repair_result_t f;
} mp2_ram_repair_result_u;


/*
 * MP2_FUSE_HARVESTING struct
 */

#define MP2_FUSE_HARVESTING_REG_SIZE   32
#define MP2_FUSE_HARVESTING_DATA_SIZE  32

#define MP2_FUSE_HARVESTING_DATA_SHIFT 0

#define MP2_FUSE_HARVESTING_DATA_MASK  0xffffffff

#define MP2_FUSE_HARVESTING_MASK \
     (MP2_FUSE_HARVESTING_DATA_MASK)

#define MP2_FUSE_HARVESTING_DEFAULT    0x00000000

#define MP2_FUSE_HARVESTING_GET_DATA(mp2_fuse_harvesting) \
     ((mp2_fuse_harvesting & MP2_FUSE_HARVESTING_DATA_MASK) >> MP2_FUSE_HARVESTING_DATA_SHIFT)

#define MP2_FUSE_HARVESTING_SET_DATA(mp2_fuse_harvesting_reg, data) \
     mp2_fuse_harvesting_reg = (mp2_fuse_harvesting_reg & ~MP2_FUSE_HARVESTING_DATA_MASK) | (data << MP2_FUSE_HARVESTING_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_fuse_harvesting_t {
          unsigned int data                           : MP2_FUSE_HARVESTING_DATA_SIZE;
     } mp2_fuse_harvesting_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_fuse_harvesting_t {
          unsigned int data                           : MP2_FUSE_HARVESTING_DATA_SIZE;
     } mp2_fuse_harvesting_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_fuse_harvesting_t f;
} mp2_fuse_harvesting_u;


/*
 * MP2_ACC_VIO_INTSTS struct
 */

#define MP2_ACC_VIO_INTSTS_REG_SIZE    32
#define MP2_ACC_VIO_INTSTS_INTSTS0_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS1_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS2_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS3_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS4_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS5_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS6_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS7_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS8_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS9_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS10_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS11_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS12_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS13_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS14_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS15_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS16_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS17_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS18_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS19_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS20_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS21_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS22_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS23_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS24_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS25_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS26_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS27_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS28_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS29_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS30_SIZE 1
#define MP2_ACC_VIO_INTSTS_INTSTS31_SIZE 1

#define MP2_ACC_VIO_INTSTS_INTSTS0_SHIFT 0
#define MP2_ACC_VIO_INTSTS_INTSTS1_SHIFT 1
#define MP2_ACC_VIO_INTSTS_INTSTS2_SHIFT 2
#define MP2_ACC_VIO_INTSTS_INTSTS3_SHIFT 3
#define MP2_ACC_VIO_INTSTS_INTSTS4_SHIFT 4
#define MP2_ACC_VIO_INTSTS_INTSTS5_SHIFT 5
#define MP2_ACC_VIO_INTSTS_INTSTS6_SHIFT 6
#define MP2_ACC_VIO_INTSTS_INTSTS7_SHIFT 7
#define MP2_ACC_VIO_INTSTS_INTSTS8_SHIFT 8
#define MP2_ACC_VIO_INTSTS_INTSTS9_SHIFT 9
#define MP2_ACC_VIO_INTSTS_INTSTS10_SHIFT 10
#define MP2_ACC_VIO_INTSTS_INTSTS11_SHIFT 11
#define MP2_ACC_VIO_INTSTS_INTSTS12_SHIFT 12
#define MP2_ACC_VIO_INTSTS_INTSTS13_SHIFT 13
#define MP2_ACC_VIO_INTSTS_INTSTS14_SHIFT 14
#define MP2_ACC_VIO_INTSTS_INTSTS15_SHIFT 15
#define MP2_ACC_VIO_INTSTS_INTSTS16_SHIFT 16
#define MP2_ACC_VIO_INTSTS_INTSTS17_SHIFT 17
#define MP2_ACC_VIO_INTSTS_INTSTS18_SHIFT 18
#define MP2_ACC_VIO_INTSTS_INTSTS19_SHIFT 19
#define MP2_ACC_VIO_INTSTS_INTSTS20_SHIFT 20
#define MP2_ACC_VIO_INTSTS_INTSTS21_SHIFT 21
#define MP2_ACC_VIO_INTSTS_INTSTS22_SHIFT 22
#define MP2_ACC_VIO_INTSTS_INTSTS23_SHIFT 23
#define MP2_ACC_VIO_INTSTS_INTSTS24_SHIFT 24
#define MP2_ACC_VIO_INTSTS_INTSTS25_SHIFT 25
#define MP2_ACC_VIO_INTSTS_INTSTS26_SHIFT 26
#define MP2_ACC_VIO_INTSTS_INTSTS27_SHIFT 27
#define MP2_ACC_VIO_INTSTS_INTSTS28_SHIFT 28
#define MP2_ACC_VIO_INTSTS_INTSTS29_SHIFT 29
#define MP2_ACC_VIO_INTSTS_INTSTS30_SHIFT 30
#define MP2_ACC_VIO_INTSTS_INTSTS31_SHIFT 31

#define MP2_ACC_VIO_INTSTS_INTSTS0_MASK 0x1
#define MP2_ACC_VIO_INTSTS_INTSTS1_MASK 0x2
#define MP2_ACC_VIO_INTSTS_INTSTS2_MASK 0x4
#define MP2_ACC_VIO_INTSTS_INTSTS3_MASK 0x8
#define MP2_ACC_VIO_INTSTS_INTSTS4_MASK 0x10
#define MP2_ACC_VIO_INTSTS_INTSTS5_MASK 0x20
#define MP2_ACC_VIO_INTSTS_INTSTS6_MASK 0x40
#define MP2_ACC_VIO_INTSTS_INTSTS7_MASK 0x80
#define MP2_ACC_VIO_INTSTS_INTSTS8_MASK 0x100
#define MP2_ACC_VIO_INTSTS_INTSTS9_MASK 0x200
#define MP2_ACC_VIO_INTSTS_INTSTS10_MASK 0x400
#define MP2_ACC_VIO_INTSTS_INTSTS11_MASK 0x800
#define MP2_ACC_VIO_INTSTS_INTSTS12_MASK 0x1000
#define MP2_ACC_VIO_INTSTS_INTSTS13_MASK 0x2000
#define MP2_ACC_VIO_INTSTS_INTSTS14_MASK 0x4000
#define MP2_ACC_VIO_INTSTS_INTSTS15_MASK 0x8000
#define MP2_ACC_VIO_INTSTS_INTSTS16_MASK 0x10000
#define MP2_ACC_VIO_INTSTS_INTSTS17_MASK 0x20000
#define MP2_ACC_VIO_INTSTS_INTSTS18_MASK 0x40000
#define MP2_ACC_VIO_INTSTS_INTSTS19_MASK 0x80000
#define MP2_ACC_VIO_INTSTS_INTSTS20_MASK 0x100000
#define MP2_ACC_VIO_INTSTS_INTSTS21_MASK 0x200000
#define MP2_ACC_VIO_INTSTS_INTSTS22_MASK 0x400000
#define MP2_ACC_VIO_INTSTS_INTSTS23_MASK 0x800000
#define MP2_ACC_VIO_INTSTS_INTSTS24_MASK 0x1000000
#define MP2_ACC_VIO_INTSTS_INTSTS25_MASK 0x2000000
#define MP2_ACC_VIO_INTSTS_INTSTS26_MASK 0x4000000
#define MP2_ACC_VIO_INTSTS_INTSTS27_MASK 0x8000000
#define MP2_ACC_VIO_INTSTS_INTSTS28_MASK 0x10000000
#define MP2_ACC_VIO_INTSTS_INTSTS29_MASK 0x20000000
#define MP2_ACC_VIO_INTSTS_INTSTS30_MASK 0x40000000
#define MP2_ACC_VIO_INTSTS_INTSTS31_MASK 0x80000000

#define MP2_ACC_VIO_INTSTS_MASK \
     (MP2_ACC_VIO_INTSTS_INTSTS0_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS1_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS2_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS3_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS4_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS5_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS6_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS7_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS8_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS9_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS10_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS11_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS12_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS13_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS14_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS15_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS16_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS17_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS18_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS19_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS20_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS21_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS22_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS23_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS24_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS25_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS26_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS27_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS28_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS29_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS30_MASK | \
      MP2_ACC_VIO_INTSTS_INTSTS31_MASK)

#define MP2_ACC_VIO_INTSTS_DEFAULT     0x00000000

#define MP2_ACC_VIO_INTSTS_GET_INTSTS0(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS0_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS0_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS1(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS1_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS1_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS2(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS2_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS2_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS3(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS3_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS3_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS4(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS4_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS4_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS5(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS5_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS5_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS6(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS6_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS6_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS7(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS7_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS7_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS8(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS8_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS8_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS9(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS9_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS9_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS10(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS10_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS10_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS11(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS11_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS11_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS12(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS12_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS12_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS13(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS13_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS13_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS14(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS14_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS14_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS15(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS15_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS15_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS16(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS16_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS16_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS17(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS17_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS17_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS18(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS18_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS18_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS19(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS19_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS19_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS20(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS20_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS20_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS21(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS21_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS21_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS22(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS22_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS22_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS23(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS23_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS23_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS24(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS24_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS24_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS25(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS25_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS25_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS26(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS26_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS26_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS27(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS27_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS27_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS28(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS28_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS28_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS29(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS29_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS29_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS30(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS30_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS30_SHIFT)
#define MP2_ACC_VIO_INTSTS_GET_INTSTS31(mp2_acc_vio_intsts) \
     ((mp2_acc_vio_intsts & MP2_ACC_VIO_INTSTS_INTSTS31_MASK) >> MP2_ACC_VIO_INTSTS_INTSTS31_SHIFT)

#define MP2_ACC_VIO_INTSTS_SET_INTSTS0(mp2_acc_vio_intsts_reg, intsts0) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS0_MASK) | (intsts0 << MP2_ACC_VIO_INTSTS_INTSTS0_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS1(mp2_acc_vio_intsts_reg, intsts1) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS1_MASK) | (intsts1 << MP2_ACC_VIO_INTSTS_INTSTS1_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS2(mp2_acc_vio_intsts_reg, intsts2) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS2_MASK) | (intsts2 << MP2_ACC_VIO_INTSTS_INTSTS2_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS3(mp2_acc_vio_intsts_reg, intsts3) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS3_MASK) | (intsts3 << MP2_ACC_VIO_INTSTS_INTSTS3_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS4(mp2_acc_vio_intsts_reg, intsts4) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS4_MASK) | (intsts4 << MP2_ACC_VIO_INTSTS_INTSTS4_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS5(mp2_acc_vio_intsts_reg, intsts5) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS5_MASK) | (intsts5 << MP2_ACC_VIO_INTSTS_INTSTS5_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS6(mp2_acc_vio_intsts_reg, intsts6) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS6_MASK) | (intsts6 << MP2_ACC_VIO_INTSTS_INTSTS6_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS7(mp2_acc_vio_intsts_reg, intsts7) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS7_MASK) | (intsts7 << MP2_ACC_VIO_INTSTS_INTSTS7_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS8(mp2_acc_vio_intsts_reg, intsts8) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS8_MASK) | (intsts8 << MP2_ACC_VIO_INTSTS_INTSTS8_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS9(mp2_acc_vio_intsts_reg, intsts9) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS9_MASK) | (intsts9 << MP2_ACC_VIO_INTSTS_INTSTS9_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS10(mp2_acc_vio_intsts_reg, intsts10) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS10_MASK) | (intsts10 << MP2_ACC_VIO_INTSTS_INTSTS10_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS11(mp2_acc_vio_intsts_reg, intsts11) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS11_MASK) | (intsts11 << MP2_ACC_VIO_INTSTS_INTSTS11_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS12(mp2_acc_vio_intsts_reg, intsts12) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS12_MASK) | (intsts12 << MP2_ACC_VIO_INTSTS_INTSTS12_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS13(mp2_acc_vio_intsts_reg, intsts13) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS13_MASK) | (intsts13 << MP2_ACC_VIO_INTSTS_INTSTS13_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS14(mp2_acc_vio_intsts_reg, intsts14) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS14_MASK) | (intsts14 << MP2_ACC_VIO_INTSTS_INTSTS14_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS15(mp2_acc_vio_intsts_reg, intsts15) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS15_MASK) | (intsts15 << MP2_ACC_VIO_INTSTS_INTSTS15_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS16(mp2_acc_vio_intsts_reg, intsts16) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS16_MASK) | (intsts16 << MP2_ACC_VIO_INTSTS_INTSTS16_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS17(mp2_acc_vio_intsts_reg, intsts17) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS17_MASK) | (intsts17 << MP2_ACC_VIO_INTSTS_INTSTS17_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS18(mp2_acc_vio_intsts_reg, intsts18) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS18_MASK) | (intsts18 << MP2_ACC_VIO_INTSTS_INTSTS18_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS19(mp2_acc_vio_intsts_reg, intsts19) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS19_MASK) | (intsts19 << MP2_ACC_VIO_INTSTS_INTSTS19_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS20(mp2_acc_vio_intsts_reg, intsts20) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS20_MASK) | (intsts20 << MP2_ACC_VIO_INTSTS_INTSTS20_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS21(mp2_acc_vio_intsts_reg, intsts21) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS21_MASK) | (intsts21 << MP2_ACC_VIO_INTSTS_INTSTS21_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS22(mp2_acc_vio_intsts_reg, intsts22) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS22_MASK) | (intsts22 << MP2_ACC_VIO_INTSTS_INTSTS22_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS23(mp2_acc_vio_intsts_reg, intsts23) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS23_MASK) | (intsts23 << MP2_ACC_VIO_INTSTS_INTSTS23_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS24(mp2_acc_vio_intsts_reg, intsts24) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS24_MASK) | (intsts24 << MP2_ACC_VIO_INTSTS_INTSTS24_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS25(mp2_acc_vio_intsts_reg, intsts25) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS25_MASK) | (intsts25 << MP2_ACC_VIO_INTSTS_INTSTS25_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS26(mp2_acc_vio_intsts_reg, intsts26) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS26_MASK) | (intsts26 << MP2_ACC_VIO_INTSTS_INTSTS26_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS27(mp2_acc_vio_intsts_reg, intsts27) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS27_MASK) | (intsts27 << MP2_ACC_VIO_INTSTS_INTSTS27_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS28(mp2_acc_vio_intsts_reg, intsts28) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS28_MASK) | (intsts28 << MP2_ACC_VIO_INTSTS_INTSTS28_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS29(mp2_acc_vio_intsts_reg, intsts29) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS29_MASK) | (intsts29 << MP2_ACC_VIO_INTSTS_INTSTS29_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS30(mp2_acc_vio_intsts_reg, intsts30) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS30_MASK) | (intsts30 << MP2_ACC_VIO_INTSTS_INTSTS30_SHIFT)
#define MP2_ACC_VIO_INTSTS_SET_INTSTS31(mp2_acc_vio_intsts_reg, intsts31) \
     mp2_acc_vio_intsts_reg = (mp2_acc_vio_intsts_reg & ~MP2_ACC_VIO_INTSTS_INTSTS31_MASK) | (intsts31 << MP2_ACC_VIO_INTSTS_INTSTS31_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_acc_vio_intsts_t {
          unsigned int intsts0                        : MP2_ACC_VIO_INTSTS_INTSTS0_SIZE;
          unsigned int intsts1                        : MP2_ACC_VIO_INTSTS_INTSTS1_SIZE;
          unsigned int intsts2                        : MP2_ACC_VIO_INTSTS_INTSTS2_SIZE;
          unsigned int intsts3                        : MP2_ACC_VIO_INTSTS_INTSTS3_SIZE;
          unsigned int intsts4                        : MP2_ACC_VIO_INTSTS_INTSTS4_SIZE;
          unsigned int intsts5                        : MP2_ACC_VIO_INTSTS_INTSTS5_SIZE;
          unsigned int intsts6                        : MP2_ACC_VIO_INTSTS_INTSTS6_SIZE;
          unsigned int intsts7                        : MP2_ACC_VIO_INTSTS_INTSTS7_SIZE;
          unsigned int intsts8                        : MP2_ACC_VIO_INTSTS_INTSTS8_SIZE;
          unsigned int intsts9                        : MP2_ACC_VIO_INTSTS_INTSTS9_SIZE;
          unsigned int intsts10                       : MP2_ACC_VIO_INTSTS_INTSTS10_SIZE;
          unsigned int intsts11                       : MP2_ACC_VIO_INTSTS_INTSTS11_SIZE;
          unsigned int intsts12                       : MP2_ACC_VIO_INTSTS_INTSTS12_SIZE;
          unsigned int intsts13                       : MP2_ACC_VIO_INTSTS_INTSTS13_SIZE;
          unsigned int intsts14                       : MP2_ACC_VIO_INTSTS_INTSTS14_SIZE;
          unsigned int intsts15                       : MP2_ACC_VIO_INTSTS_INTSTS15_SIZE;
          unsigned int intsts16                       : MP2_ACC_VIO_INTSTS_INTSTS16_SIZE;
          unsigned int intsts17                       : MP2_ACC_VIO_INTSTS_INTSTS17_SIZE;
          unsigned int intsts18                       : MP2_ACC_VIO_INTSTS_INTSTS18_SIZE;
          unsigned int intsts19                       : MP2_ACC_VIO_INTSTS_INTSTS19_SIZE;
          unsigned int intsts20                       : MP2_ACC_VIO_INTSTS_INTSTS20_SIZE;
          unsigned int intsts21                       : MP2_ACC_VIO_INTSTS_INTSTS21_SIZE;
          unsigned int intsts22                       : MP2_ACC_VIO_INTSTS_INTSTS22_SIZE;
          unsigned int intsts23                       : MP2_ACC_VIO_INTSTS_INTSTS23_SIZE;
          unsigned int intsts24                       : MP2_ACC_VIO_INTSTS_INTSTS24_SIZE;
          unsigned int intsts25                       : MP2_ACC_VIO_INTSTS_INTSTS25_SIZE;
          unsigned int intsts26                       : MP2_ACC_VIO_INTSTS_INTSTS26_SIZE;
          unsigned int intsts27                       : MP2_ACC_VIO_INTSTS_INTSTS27_SIZE;
          unsigned int intsts28                       : MP2_ACC_VIO_INTSTS_INTSTS28_SIZE;
          unsigned int intsts29                       : MP2_ACC_VIO_INTSTS_INTSTS29_SIZE;
          unsigned int intsts30                       : MP2_ACC_VIO_INTSTS_INTSTS30_SIZE;
          unsigned int intsts31                       : MP2_ACC_VIO_INTSTS_INTSTS31_SIZE;
     } mp2_acc_vio_intsts_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_acc_vio_intsts_t {
          unsigned int intsts31                       : MP2_ACC_VIO_INTSTS_INTSTS31_SIZE;
          unsigned int intsts30                       : MP2_ACC_VIO_INTSTS_INTSTS30_SIZE;
          unsigned int intsts29                       : MP2_ACC_VIO_INTSTS_INTSTS29_SIZE;
          unsigned int intsts28                       : MP2_ACC_VIO_INTSTS_INTSTS28_SIZE;
          unsigned int intsts27                       : MP2_ACC_VIO_INTSTS_INTSTS27_SIZE;
          unsigned int intsts26                       : MP2_ACC_VIO_INTSTS_INTSTS26_SIZE;
          unsigned int intsts25                       : MP2_ACC_VIO_INTSTS_INTSTS25_SIZE;
          unsigned int intsts24                       : MP2_ACC_VIO_INTSTS_INTSTS24_SIZE;
          unsigned int intsts23                       : MP2_ACC_VIO_INTSTS_INTSTS23_SIZE;
          unsigned int intsts22                       : MP2_ACC_VIO_INTSTS_INTSTS22_SIZE;
          unsigned int intsts21                       : MP2_ACC_VIO_INTSTS_INTSTS21_SIZE;
          unsigned int intsts20                       : MP2_ACC_VIO_INTSTS_INTSTS20_SIZE;
          unsigned int intsts19                       : MP2_ACC_VIO_INTSTS_INTSTS19_SIZE;
          unsigned int intsts18                       : MP2_ACC_VIO_INTSTS_INTSTS18_SIZE;
          unsigned int intsts17                       : MP2_ACC_VIO_INTSTS_INTSTS17_SIZE;
          unsigned int intsts16                       : MP2_ACC_VIO_INTSTS_INTSTS16_SIZE;
          unsigned int intsts15                       : MP2_ACC_VIO_INTSTS_INTSTS15_SIZE;
          unsigned int intsts14                       : MP2_ACC_VIO_INTSTS_INTSTS14_SIZE;
          unsigned int intsts13                       : MP2_ACC_VIO_INTSTS_INTSTS13_SIZE;
          unsigned int intsts12                       : MP2_ACC_VIO_INTSTS_INTSTS12_SIZE;
          unsigned int intsts11                       : MP2_ACC_VIO_INTSTS_INTSTS11_SIZE;
          unsigned int intsts10                       : MP2_ACC_VIO_INTSTS_INTSTS10_SIZE;
          unsigned int intsts9                        : MP2_ACC_VIO_INTSTS_INTSTS9_SIZE;
          unsigned int intsts8                        : MP2_ACC_VIO_INTSTS_INTSTS8_SIZE;
          unsigned int intsts7                        : MP2_ACC_VIO_INTSTS_INTSTS7_SIZE;
          unsigned int intsts6                        : MP2_ACC_VIO_INTSTS_INTSTS6_SIZE;
          unsigned int intsts5                        : MP2_ACC_VIO_INTSTS_INTSTS5_SIZE;
          unsigned int intsts4                        : MP2_ACC_VIO_INTSTS_INTSTS4_SIZE;
          unsigned int intsts3                        : MP2_ACC_VIO_INTSTS_INTSTS3_SIZE;
          unsigned int intsts2                        : MP2_ACC_VIO_INTSTS_INTSTS2_SIZE;
          unsigned int intsts1                        : MP2_ACC_VIO_INTSTS_INTSTS1_SIZE;
          unsigned int intsts0                        : MP2_ACC_VIO_INTSTS_INTSTS0_SIZE;
     } mp2_acc_vio_intsts_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_acc_vio_intsts_t f;
} mp2_acc_vio_intsts_u;


/*
 * MP2_TDR_MISC0_STATUS struct
 */

#define MP2_TDR_MISC0_STATUS_REG_SIZE  32
#define MP2_TDR_MISC0_STATUS_DATA_SIZE 32

#define MP2_TDR_MISC0_STATUS_DATA_SHIFT 0

#define MP2_TDR_MISC0_STATUS_DATA_MASK 0xffffffff

#define MP2_TDR_MISC0_STATUS_MASK \
     (MP2_TDR_MISC0_STATUS_DATA_MASK)

#define MP2_TDR_MISC0_STATUS_DEFAULT   0x00000000

#define MP2_TDR_MISC0_STATUS_GET_DATA(mp2_tdr_misc0_status) \
     ((mp2_tdr_misc0_status & MP2_TDR_MISC0_STATUS_DATA_MASK) >> MP2_TDR_MISC0_STATUS_DATA_SHIFT)

#define MP2_TDR_MISC0_STATUS_SET_DATA(mp2_tdr_misc0_status_reg, data) \
     mp2_tdr_misc0_status_reg = (mp2_tdr_misc0_status_reg & ~MP2_TDR_MISC0_STATUS_DATA_MASK) | (data << MP2_TDR_MISC0_STATUS_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_tdr_misc0_status_t {
          unsigned int data                           : MP2_TDR_MISC0_STATUS_DATA_SIZE;
     } mp2_tdr_misc0_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_tdr_misc0_status_t {
          unsigned int data                           : MP2_TDR_MISC0_STATUS_DATA_SIZE;
     } mp2_tdr_misc0_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_tdr_misc0_status_t f;
} mp2_tdr_misc0_status_u;


/*
 * MP2_FW_OVERRIDE struct
 */

#define MP2_FW_OVERRIDE_REG_SIZE       32
#define MP2_FW_OVERRIDE_RESERVED0_SIZE 1
#define MP2_FW_OVERRIDE_RESERVED1_SIZE 1
#define MP2_FW_OVERRIDE_RESERVED2_SIZE 1
#define MP2_FW_OVERRIDE_ENB_SFI_DIS_SIZE 1
#define MP2_FW_OVERRIDE_ENB_S0I3_RAM_DIS_SIZE 1
#define MP2_FW_OVERRIDE_RESERVED5_SIZE 1
#define MP2_FW_OVERRIDE_MP0_ROMBIST_BYPASS_SIZE 1
#define MP2_FW_OVERRIDE_RESERVED_LO_SIZE 9
#define MP2_FW_OVERRIDE_MP0_INTR_ENB_SIZE 16

#define MP2_FW_OVERRIDE_RESERVED0_SHIFT 0
#define MP2_FW_OVERRIDE_RESERVED1_SHIFT 1
#define MP2_FW_OVERRIDE_RESERVED2_SHIFT 2
#define MP2_FW_OVERRIDE_ENB_SFI_DIS_SHIFT 3
#define MP2_FW_OVERRIDE_ENB_S0I3_RAM_DIS_SHIFT 4
#define MP2_FW_OVERRIDE_RESERVED5_SHIFT 5
#define MP2_FW_OVERRIDE_MP0_ROMBIST_BYPASS_SHIFT 6
#define MP2_FW_OVERRIDE_RESERVED_LO_SHIFT 7
#define MP2_FW_OVERRIDE_MP0_INTR_ENB_SHIFT 16

#define MP2_FW_OVERRIDE_RESERVED0_MASK 0x1
#define MP2_FW_OVERRIDE_RESERVED1_MASK 0x2
#define MP2_FW_OVERRIDE_RESERVED2_MASK 0x4
#define MP2_FW_OVERRIDE_ENB_SFI_DIS_MASK 0x8
#define MP2_FW_OVERRIDE_ENB_S0I3_RAM_DIS_MASK 0x10
#define MP2_FW_OVERRIDE_RESERVED5_MASK 0x20
#define MP2_FW_OVERRIDE_MP0_ROMBIST_BYPASS_MASK 0x40
#define MP2_FW_OVERRIDE_RESERVED_LO_MASK 0xff80
#define MP2_FW_OVERRIDE_MP0_INTR_ENB_MASK 0xffff0000

#define MP2_FW_OVERRIDE_MASK \
     (MP2_FW_OVERRIDE_RESERVED0_MASK | \
      MP2_FW_OVERRIDE_RESERVED1_MASK | \
      MP2_FW_OVERRIDE_RESERVED2_MASK | \
      MP2_FW_OVERRIDE_ENB_SFI_DIS_MASK | \
      MP2_FW_OVERRIDE_ENB_S0I3_RAM_DIS_MASK | \
      MP2_FW_OVERRIDE_RESERVED5_MASK | \
      MP2_FW_OVERRIDE_MP0_ROMBIST_BYPASS_MASK | \
      MP2_FW_OVERRIDE_RESERVED_LO_MASK | \
      MP2_FW_OVERRIDE_MP0_INTR_ENB_MASK)

#define MP2_FW_OVERRIDE_DEFAULT        0x00000000

#define MP2_FW_OVERRIDE_GET_RESERVED0(mp2_fw_override) \
     ((mp2_fw_override & MP2_FW_OVERRIDE_RESERVED0_MASK) >> MP2_FW_OVERRIDE_RESERVED0_SHIFT)
#define MP2_FW_OVERRIDE_GET_RESERVED1(mp2_fw_override) \
     ((mp2_fw_override & MP2_FW_OVERRIDE_RESERVED1_MASK) >> MP2_FW_OVERRIDE_RESERVED1_SHIFT)
#define MP2_FW_OVERRIDE_GET_RESERVED2(mp2_fw_override) \
     ((mp2_fw_override & MP2_FW_OVERRIDE_RESERVED2_MASK) >> MP2_FW_OVERRIDE_RESERVED2_SHIFT)
#define MP2_FW_OVERRIDE_GET_ENB_SFI_DIS(mp2_fw_override) \
     ((mp2_fw_override & MP2_FW_OVERRIDE_ENB_SFI_DIS_MASK) >> MP2_FW_OVERRIDE_ENB_SFI_DIS_SHIFT)
#define MP2_FW_OVERRIDE_GET_ENB_S0I3_RAM_DIS(mp2_fw_override) \
     ((mp2_fw_override & MP2_FW_OVERRIDE_ENB_S0I3_RAM_DIS_MASK) >> MP2_FW_OVERRIDE_ENB_S0I3_RAM_DIS_SHIFT)
#define MP2_FW_OVERRIDE_GET_RESERVED5(mp2_fw_override) \
     ((mp2_fw_override & MP2_FW_OVERRIDE_RESERVED5_MASK) >> MP2_FW_OVERRIDE_RESERVED5_SHIFT)
#define MP2_FW_OVERRIDE_GET_MP0_ROMBIST_BYPASS(mp2_fw_override) \
     ((mp2_fw_override & MP2_FW_OVERRIDE_MP0_ROMBIST_BYPASS_MASK) >> MP2_FW_OVERRIDE_MP0_ROMBIST_BYPASS_SHIFT)
#define MP2_FW_OVERRIDE_GET_RESERVED_LO(mp2_fw_override) \
     ((mp2_fw_override & MP2_FW_OVERRIDE_RESERVED_LO_MASK) >> MP2_FW_OVERRIDE_RESERVED_LO_SHIFT)
#define MP2_FW_OVERRIDE_GET_MP0_INTR_ENB(mp2_fw_override) \
     ((mp2_fw_override & MP2_FW_OVERRIDE_MP0_INTR_ENB_MASK) >> MP2_FW_OVERRIDE_MP0_INTR_ENB_SHIFT)

#define MP2_FW_OVERRIDE_SET_RESERVED0(mp2_fw_override_reg, reserved0) \
     mp2_fw_override_reg = (mp2_fw_override_reg & ~MP2_FW_OVERRIDE_RESERVED0_MASK) | (reserved0 << MP2_FW_OVERRIDE_RESERVED0_SHIFT)
#define MP2_FW_OVERRIDE_SET_RESERVED1(mp2_fw_override_reg, reserved1) \
     mp2_fw_override_reg = (mp2_fw_override_reg & ~MP2_FW_OVERRIDE_RESERVED1_MASK) | (reserved1 << MP2_FW_OVERRIDE_RESERVED1_SHIFT)
#define MP2_FW_OVERRIDE_SET_RESERVED2(mp2_fw_override_reg, reserved2) \
     mp2_fw_override_reg = (mp2_fw_override_reg & ~MP2_FW_OVERRIDE_RESERVED2_MASK) | (reserved2 << MP2_FW_OVERRIDE_RESERVED2_SHIFT)
#define MP2_FW_OVERRIDE_SET_ENB_SFI_DIS(mp2_fw_override_reg, enb_sfi_dis) \
     mp2_fw_override_reg = (mp2_fw_override_reg & ~MP2_FW_OVERRIDE_ENB_SFI_DIS_MASK) | (enb_sfi_dis << MP2_FW_OVERRIDE_ENB_SFI_DIS_SHIFT)
#define MP2_FW_OVERRIDE_SET_ENB_S0I3_RAM_DIS(mp2_fw_override_reg, enb_s0i3_ram_dis) \
     mp2_fw_override_reg = (mp2_fw_override_reg & ~MP2_FW_OVERRIDE_ENB_S0I3_RAM_DIS_MASK) | (enb_s0i3_ram_dis << MP2_FW_OVERRIDE_ENB_S0I3_RAM_DIS_SHIFT)
#define MP2_FW_OVERRIDE_SET_RESERVED5(mp2_fw_override_reg, reserved5) \
     mp2_fw_override_reg = (mp2_fw_override_reg & ~MP2_FW_OVERRIDE_RESERVED5_MASK) | (reserved5 << MP2_FW_OVERRIDE_RESERVED5_SHIFT)
#define MP2_FW_OVERRIDE_SET_MP0_ROMBIST_BYPASS(mp2_fw_override_reg, mp0_rombist_bypass) \
     mp2_fw_override_reg = (mp2_fw_override_reg & ~MP2_FW_OVERRIDE_MP0_ROMBIST_BYPASS_MASK) | (mp0_rombist_bypass << MP2_FW_OVERRIDE_MP0_ROMBIST_BYPASS_SHIFT)
#define MP2_FW_OVERRIDE_SET_RESERVED_LO(mp2_fw_override_reg, reserved_lo) \
     mp2_fw_override_reg = (mp2_fw_override_reg & ~MP2_FW_OVERRIDE_RESERVED_LO_MASK) | (reserved_lo << MP2_FW_OVERRIDE_RESERVED_LO_SHIFT)
#define MP2_FW_OVERRIDE_SET_MP0_INTR_ENB(mp2_fw_override_reg, mp0_intr_enb) \
     mp2_fw_override_reg = (mp2_fw_override_reg & ~MP2_FW_OVERRIDE_MP0_INTR_ENB_MASK) | (mp0_intr_enb << MP2_FW_OVERRIDE_MP0_INTR_ENB_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_fw_override_t {
          unsigned int reserved0                      : MP2_FW_OVERRIDE_RESERVED0_SIZE;
          unsigned int reserved1                      : MP2_FW_OVERRIDE_RESERVED1_SIZE;
          unsigned int reserved2                      : MP2_FW_OVERRIDE_RESERVED2_SIZE;
          unsigned int enb_sfi_dis                    : MP2_FW_OVERRIDE_ENB_SFI_DIS_SIZE;
          unsigned int enb_s0i3_ram_dis               : MP2_FW_OVERRIDE_ENB_S0I3_RAM_DIS_SIZE;
          unsigned int reserved5                      : MP2_FW_OVERRIDE_RESERVED5_SIZE;
          unsigned int mp0_rombist_bypass             : MP2_FW_OVERRIDE_MP0_ROMBIST_BYPASS_SIZE;
          unsigned int reserved_lo                    : MP2_FW_OVERRIDE_RESERVED_LO_SIZE;
          unsigned int mp0_intr_enb                   : MP2_FW_OVERRIDE_MP0_INTR_ENB_SIZE;
     } mp2_fw_override_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_fw_override_t {
          unsigned int mp0_intr_enb                   : MP2_FW_OVERRIDE_MP0_INTR_ENB_SIZE;
          unsigned int reserved_lo                    : MP2_FW_OVERRIDE_RESERVED_LO_SIZE;
          unsigned int mp0_rombist_bypass             : MP2_FW_OVERRIDE_MP0_ROMBIST_BYPASS_SIZE;
          unsigned int reserved5                      : MP2_FW_OVERRIDE_RESERVED5_SIZE;
          unsigned int enb_s0i3_ram_dis               : MP2_FW_OVERRIDE_ENB_S0I3_RAM_DIS_SIZE;
          unsigned int enb_sfi_dis                    : MP2_FW_OVERRIDE_ENB_SFI_DIS_SIZE;
          unsigned int reserved2                      : MP2_FW_OVERRIDE_RESERVED2_SIZE;
          unsigned int reserved1                      : MP2_FW_OVERRIDE_RESERVED1_SIZE;
          unsigned int reserved0                      : MP2_FW_OVERRIDE_RESERVED0_SIZE;
     } mp2_fw_override_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_fw_override_t f;
} mp2_fw_override_u;


/*
 * MP2_CRU_CPU_CTRL_STS struct
 */

#define MP2_CRU_CPU_CTRL_STS_REG_SIZE  32
#define MP2_CRU_CPU_CTRL_STS_PCLKENDBG_SIZE 1
#define MP2_CRU_CPU_CTRL_STS_RESERVED_SIZE 1
#define MP2_CRU_CPU_CTRL_STS_STCALIB_SIZE 30

#define MP2_CRU_CPU_CTRL_STS_PCLKENDBG_SHIFT 0
#define MP2_CRU_CPU_CTRL_STS_RESERVED_SHIFT 1
#define MP2_CRU_CPU_CTRL_STS_STCALIB_SHIFT 2

#define MP2_CRU_CPU_CTRL_STS_PCLKENDBG_MASK 0x1
#define MP2_CRU_CPU_CTRL_STS_RESERVED_MASK 0x2
#define MP2_CRU_CPU_CTRL_STS_STCALIB_MASK 0xfffffffc

#define MP2_CRU_CPU_CTRL_STS_MASK \
     (MP2_CRU_CPU_CTRL_STS_PCLKENDBG_MASK | \
      MP2_CRU_CPU_CTRL_STS_RESERVED_MASK | \
      MP2_CRU_CPU_CTRL_STS_STCALIB_MASK)

#define MP2_CRU_CPU_CTRL_STS_DEFAULT   0x001d4c01

#define MP2_CRU_CPU_CTRL_STS_GET_PCLKENDBG(mp2_cru_cpu_ctrl_sts) \
     ((mp2_cru_cpu_ctrl_sts & MP2_CRU_CPU_CTRL_STS_PCLKENDBG_MASK) >> MP2_CRU_CPU_CTRL_STS_PCLKENDBG_SHIFT)
#define MP2_CRU_CPU_CTRL_STS_GET_RESERVED(mp2_cru_cpu_ctrl_sts) \
     ((mp2_cru_cpu_ctrl_sts & MP2_CRU_CPU_CTRL_STS_RESERVED_MASK) >> MP2_CRU_CPU_CTRL_STS_RESERVED_SHIFT)
#define MP2_CRU_CPU_CTRL_STS_GET_STCALIB(mp2_cru_cpu_ctrl_sts) \
     ((mp2_cru_cpu_ctrl_sts & MP2_CRU_CPU_CTRL_STS_STCALIB_MASK) >> MP2_CRU_CPU_CTRL_STS_STCALIB_SHIFT)

#define MP2_CRU_CPU_CTRL_STS_SET_PCLKENDBG(mp2_cru_cpu_ctrl_sts_reg, pclkendbg) \
     mp2_cru_cpu_ctrl_sts_reg = (mp2_cru_cpu_ctrl_sts_reg & ~MP2_CRU_CPU_CTRL_STS_PCLKENDBG_MASK) | (pclkendbg << MP2_CRU_CPU_CTRL_STS_PCLKENDBG_SHIFT)
#define MP2_CRU_CPU_CTRL_STS_SET_RESERVED(mp2_cru_cpu_ctrl_sts_reg, reserved) \
     mp2_cru_cpu_ctrl_sts_reg = (mp2_cru_cpu_ctrl_sts_reg & ~MP2_CRU_CPU_CTRL_STS_RESERVED_MASK) | (reserved << MP2_CRU_CPU_CTRL_STS_RESERVED_SHIFT)
#define MP2_CRU_CPU_CTRL_STS_SET_STCALIB(mp2_cru_cpu_ctrl_sts_reg, stcalib) \
     mp2_cru_cpu_ctrl_sts_reg = (mp2_cru_cpu_ctrl_sts_reg & ~MP2_CRU_CPU_CTRL_STS_STCALIB_MASK) | (stcalib << MP2_CRU_CPU_CTRL_STS_STCALIB_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_cru_cpu_ctrl_sts_t {
          unsigned int pclkendbg                      : MP2_CRU_CPU_CTRL_STS_PCLKENDBG_SIZE;
          unsigned int reserved                       : MP2_CRU_CPU_CTRL_STS_RESERVED_SIZE;
          unsigned int stcalib                        : MP2_CRU_CPU_CTRL_STS_STCALIB_SIZE;
     } mp2_cru_cpu_ctrl_sts_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_cru_cpu_ctrl_sts_t {
          unsigned int stcalib                        : MP2_CRU_CPU_CTRL_STS_STCALIB_SIZE;
          unsigned int reserved                       : MP2_CRU_CPU_CTRL_STS_RESERVED_SIZE;
          unsigned int pclkendbg                      : MP2_CRU_CPU_CTRL_STS_PCLKENDBG_SIZE;
     } mp2_cru_cpu_ctrl_sts_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_cru_cpu_ctrl_sts_t f;
} mp2_cru_cpu_ctrl_sts_u;


/*
 * MP2_J2P_MBOX0 struct
 */

#define MP2_J2P_MBOX0_REG_SIZE         32
#define MP2_J2P_MBOX0_MBX_SIZE         32

#define MP2_J2P_MBOX0_MBX_SHIFT        0

#define MP2_J2P_MBOX0_MBX_MASK         0xffffffff

#define MP2_J2P_MBOX0_MASK \
     (MP2_J2P_MBOX0_MBX_MASK)

#define MP2_J2P_MBOX0_DEFAULT          0x00000000

#define MP2_J2P_MBOX0_GET_MBX(mp2_j2p_mbox0) \
     ((mp2_j2p_mbox0 & MP2_J2P_MBOX0_MBX_MASK) >> MP2_J2P_MBOX0_MBX_SHIFT)

#define MP2_J2P_MBOX0_SET_MBX(mp2_j2p_mbox0_reg, mbx) \
     mp2_j2p_mbox0_reg = (mp2_j2p_mbox0_reg & ~MP2_J2P_MBOX0_MBX_MASK) | (mbx << MP2_J2P_MBOX0_MBX_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_j2p_mbox0_t {
          unsigned int mbx                            : MP2_J2P_MBOX0_MBX_SIZE;
     } mp2_j2p_mbox0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_j2p_mbox0_t {
          unsigned int mbx                            : MP2_J2P_MBOX0_MBX_SIZE;
     } mp2_j2p_mbox0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_j2p_mbox0_t f;
} mp2_j2p_mbox0_u;


/*
 * MP2_J2P_MBOX1 struct
 */

#define MP2_J2P_MBOX1_REG_SIZE         32
#define MP2_J2P_MBOX1_MBX_SIZE         32

#define MP2_J2P_MBOX1_MBX_SHIFT        0

#define MP2_J2P_MBOX1_MBX_MASK         0xffffffff

#define MP2_J2P_MBOX1_MASK \
     (MP2_J2P_MBOX1_MBX_MASK)

#define MP2_J2P_MBOX1_DEFAULT          0x00000000

#define MP2_J2P_MBOX1_GET_MBX(mp2_j2p_mbox1) \
     ((mp2_j2p_mbox1 & MP2_J2P_MBOX1_MBX_MASK) >> MP2_J2P_MBOX1_MBX_SHIFT)

#define MP2_J2P_MBOX1_SET_MBX(mp2_j2p_mbox1_reg, mbx) \
     mp2_j2p_mbox1_reg = (mp2_j2p_mbox1_reg & ~MP2_J2P_MBOX1_MBX_MASK) | (mbx << MP2_J2P_MBOX1_MBX_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_j2p_mbox1_t {
          unsigned int mbx                            : MP2_J2P_MBOX1_MBX_SIZE;
     } mp2_j2p_mbox1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_j2p_mbox1_t {
          unsigned int mbx                            : MP2_J2P_MBOX1_MBX_SIZE;
     } mp2_j2p_mbox1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_j2p_mbox1_t f;
} mp2_j2p_mbox1_u;


/*
 * MP2_J2P_ATTR struct
 */

#define MP2_J2P_ATTR_REG_SIZE          32
#define MP2_J2P_ATTR_J2P_ATTR_SIZE     2

#define MP2_J2P_ATTR_J2P_ATTR_SHIFT    0

#define MP2_J2P_ATTR_J2P_ATTR_MASK     0x3

#define MP2_J2P_ATTR_MASK \
     (MP2_J2P_ATTR_J2P_ATTR_MASK)

#define MP2_J2P_ATTR_DEFAULT           0x00000003

#define MP2_J2P_ATTR_GET_J2P_ATTR(mp2_j2p_attr) \
     ((mp2_j2p_attr & MP2_J2P_ATTR_J2P_ATTR_MASK) >> MP2_J2P_ATTR_J2P_ATTR_SHIFT)

#define MP2_J2P_ATTR_SET_J2P_ATTR(mp2_j2p_attr_reg, j2p_attr) \
     mp2_j2p_attr_reg = (mp2_j2p_attr_reg & ~MP2_J2P_ATTR_J2P_ATTR_MASK) | (j2p_attr << MP2_J2P_ATTR_J2P_ATTR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_j2p_attr_t {
          unsigned int j2p_attr                       : MP2_J2P_ATTR_J2P_ATTR_SIZE;
          unsigned int                                : 30;
     } mp2_j2p_attr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_j2p_attr_t {
          unsigned int                                : 30;
          unsigned int j2p_attr                       : MP2_J2P_ATTR_J2P_ATTR_SIZE;
     } mp2_j2p_attr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_j2p_attr_t f;
} mp2_j2p_attr_u;


/*
 * MP2_CRU_ACC_VIO_INTSTS struct
 */

#define MP2_CRU_ACC_VIO_INTSTS_REG_SIZE 32
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS0_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS1_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS2_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS3_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS4_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS5_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS6_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS7_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS8_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS9_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS10_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS11_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS12_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS13_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS14_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS15_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS16_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS17_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS18_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS19_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS20_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS21_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS22_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS23_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS24_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS25_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS26_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS27_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS28_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS29_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS30_SIZE 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS31_SIZE 1

#define MP2_CRU_ACC_VIO_INTSTS_INTSTS0_SHIFT 0
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS1_SHIFT 1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS2_SHIFT 2
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS3_SHIFT 3
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS4_SHIFT 4
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS5_SHIFT 5
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS6_SHIFT 6
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS7_SHIFT 7
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS8_SHIFT 8
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS9_SHIFT 9
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS10_SHIFT 10
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS11_SHIFT 11
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS12_SHIFT 12
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS13_SHIFT 13
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS14_SHIFT 14
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS15_SHIFT 15
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS16_SHIFT 16
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS17_SHIFT 17
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS18_SHIFT 18
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS19_SHIFT 19
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS20_SHIFT 20
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS21_SHIFT 21
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS22_SHIFT 22
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS23_SHIFT 23
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS24_SHIFT 24
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS25_SHIFT 25
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS26_SHIFT 26
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS27_SHIFT 27
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS28_SHIFT 28
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS29_SHIFT 29
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS30_SHIFT 30
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS31_SHIFT 31

#define MP2_CRU_ACC_VIO_INTSTS_INTSTS0_MASK 0x1
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS1_MASK 0x2
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS2_MASK 0x4
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS3_MASK 0x8
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS4_MASK 0x10
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS5_MASK 0x20
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS6_MASK 0x40
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS7_MASK 0x80
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS8_MASK 0x100
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS9_MASK 0x200
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS10_MASK 0x400
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS11_MASK 0x800
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS12_MASK 0x1000
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS13_MASK 0x2000
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS14_MASK 0x4000
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS15_MASK 0x8000
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS16_MASK 0x10000
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS17_MASK 0x20000
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS18_MASK 0x40000
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS19_MASK 0x80000
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS20_MASK 0x100000
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS21_MASK 0x200000
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS22_MASK 0x400000
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS23_MASK 0x800000
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS24_MASK 0x1000000
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS25_MASK 0x2000000
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS26_MASK 0x4000000
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS27_MASK 0x8000000
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS28_MASK 0x10000000
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS29_MASK 0x20000000
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS30_MASK 0x40000000
#define MP2_CRU_ACC_VIO_INTSTS_INTSTS31_MASK 0x80000000

#define MP2_CRU_ACC_VIO_INTSTS_MASK \
     (MP2_CRU_ACC_VIO_INTSTS_INTSTS0_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS1_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS2_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS3_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS4_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS5_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS6_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS7_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS8_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS9_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS10_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS11_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS12_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS13_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS14_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS15_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS16_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS17_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS18_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS19_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS20_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS21_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS22_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS23_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS24_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS25_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS26_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS27_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS28_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS29_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS30_MASK | \
      MP2_CRU_ACC_VIO_INTSTS_INTSTS31_MASK)

#define MP2_CRU_ACC_VIO_INTSTS_DEFAULT 0x00000000

#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS0(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS0_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS0_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS1(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS1_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS1_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS2(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS2_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS2_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS3(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS3_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS3_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS4(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS4_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS4_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS5(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS5_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS5_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS6(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS6_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS6_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS7(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS7_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS7_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS8(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS8_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS8_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS9(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS9_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS9_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS10(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS10_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS10_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS11(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS11_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS11_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS12(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS12_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS12_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS13(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS13_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS13_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS14(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS14_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS14_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS15(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS15_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS15_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS16(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS16_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS16_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS17(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS17_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS17_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS18(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS18_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS18_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS19(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS19_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS19_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS20(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS20_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS20_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS21(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS21_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS21_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS22(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS22_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS22_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS23(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS23_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS23_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS24(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS24_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS24_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS25(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS25_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS25_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS26(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS26_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS26_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS27(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS27_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS27_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS28(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS28_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS28_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS29(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS29_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS29_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS30(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS30_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS30_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_GET_INTSTS31(mp2_cru_acc_vio_intsts) \
     ((mp2_cru_acc_vio_intsts & MP2_CRU_ACC_VIO_INTSTS_INTSTS31_MASK) >> MP2_CRU_ACC_VIO_INTSTS_INTSTS31_SHIFT)

#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS0(mp2_cru_acc_vio_intsts_reg, intsts0) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS0_MASK) | (intsts0 << MP2_CRU_ACC_VIO_INTSTS_INTSTS0_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS1(mp2_cru_acc_vio_intsts_reg, intsts1) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS1_MASK) | (intsts1 << MP2_CRU_ACC_VIO_INTSTS_INTSTS1_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS2(mp2_cru_acc_vio_intsts_reg, intsts2) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS2_MASK) | (intsts2 << MP2_CRU_ACC_VIO_INTSTS_INTSTS2_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS3(mp2_cru_acc_vio_intsts_reg, intsts3) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS3_MASK) | (intsts3 << MP2_CRU_ACC_VIO_INTSTS_INTSTS3_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS4(mp2_cru_acc_vio_intsts_reg, intsts4) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS4_MASK) | (intsts4 << MP2_CRU_ACC_VIO_INTSTS_INTSTS4_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS5(mp2_cru_acc_vio_intsts_reg, intsts5) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS5_MASK) | (intsts5 << MP2_CRU_ACC_VIO_INTSTS_INTSTS5_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS6(mp2_cru_acc_vio_intsts_reg, intsts6) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS6_MASK) | (intsts6 << MP2_CRU_ACC_VIO_INTSTS_INTSTS6_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS7(mp2_cru_acc_vio_intsts_reg, intsts7) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS7_MASK) | (intsts7 << MP2_CRU_ACC_VIO_INTSTS_INTSTS7_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS8(mp2_cru_acc_vio_intsts_reg, intsts8) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS8_MASK) | (intsts8 << MP2_CRU_ACC_VIO_INTSTS_INTSTS8_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS9(mp2_cru_acc_vio_intsts_reg, intsts9) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS9_MASK) | (intsts9 << MP2_CRU_ACC_VIO_INTSTS_INTSTS9_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS10(mp2_cru_acc_vio_intsts_reg, intsts10) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS10_MASK) | (intsts10 << MP2_CRU_ACC_VIO_INTSTS_INTSTS10_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS11(mp2_cru_acc_vio_intsts_reg, intsts11) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS11_MASK) | (intsts11 << MP2_CRU_ACC_VIO_INTSTS_INTSTS11_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS12(mp2_cru_acc_vio_intsts_reg, intsts12) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS12_MASK) | (intsts12 << MP2_CRU_ACC_VIO_INTSTS_INTSTS12_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS13(mp2_cru_acc_vio_intsts_reg, intsts13) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS13_MASK) | (intsts13 << MP2_CRU_ACC_VIO_INTSTS_INTSTS13_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS14(mp2_cru_acc_vio_intsts_reg, intsts14) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS14_MASK) | (intsts14 << MP2_CRU_ACC_VIO_INTSTS_INTSTS14_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS15(mp2_cru_acc_vio_intsts_reg, intsts15) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS15_MASK) | (intsts15 << MP2_CRU_ACC_VIO_INTSTS_INTSTS15_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS16(mp2_cru_acc_vio_intsts_reg, intsts16) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS16_MASK) | (intsts16 << MP2_CRU_ACC_VIO_INTSTS_INTSTS16_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS17(mp2_cru_acc_vio_intsts_reg, intsts17) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS17_MASK) | (intsts17 << MP2_CRU_ACC_VIO_INTSTS_INTSTS17_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS18(mp2_cru_acc_vio_intsts_reg, intsts18) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS18_MASK) | (intsts18 << MP2_CRU_ACC_VIO_INTSTS_INTSTS18_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS19(mp2_cru_acc_vio_intsts_reg, intsts19) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS19_MASK) | (intsts19 << MP2_CRU_ACC_VIO_INTSTS_INTSTS19_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS20(mp2_cru_acc_vio_intsts_reg, intsts20) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS20_MASK) | (intsts20 << MP2_CRU_ACC_VIO_INTSTS_INTSTS20_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS21(mp2_cru_acc_vio_intsts_reg, intsts21) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS21_MASK) | (intsts21 << MP2_CRU_ACC_VIO_INTSTS_INTSTS21_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS22(mp2_cru_acc_vio_intsts_reg, intsts22) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS22_MASK) | (intsts22 << MP2_CRU_ACC_VIO_INTSTS_INTSTS22_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS23(mp2_cru_acc_vio_intsts_reg, intsts23) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS23_MASK) | (intsts23 << MP2_CRU_ACC_VIO_INTSTS_INTSTS23_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS24(mp2_cru_acc_vio_intsts_reg, intsts24) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS24_MASK) | (intsts24 << MP2_CRU_ACC_VIO_INTSTS_INTSTS24_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS25(mp2_cru_acc_vio_intsts_reg, intsts25) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS25_MASK) | (intsts25 << MP2_CRU_ACC_VIO_INTSTS_INTSTS25_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS26(mp2_cru_acc_vio_intsts_reg, intsts26) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS26_MASK) | (intsts26 << MP2_CRU_ACC_VIO_INTSTS_INTSTS26_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS27(mp2_cru_acc_vio_intsts_reg, intsts27) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS27_MASK) | (intsts27 << MP2_CRU_ACC_VIO_INTSTS_INTSTS27_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS28(mp2_cru_acc_vio_intsts_reg, intsts28) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS28_MASK) | (intsts28 << MP2_CRU_ACC_VIO_INTSTS_INTSTS28_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS29(mp2_cru_acc_vio_intsts_reg, intsts29) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS29_MASK) | (intsts29 << MP2_CRU_ACC_VIO_INTSTS_INTSTS29_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS30(mp2_cru_acc_vio_intsts_reg, intsts30) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS30_MASK) | (intsts30 << MP2_CRU_ACC_VIO_INTSTS_INTSTS30_SHIFT)
#define MP2_CRU_ACC_VIO_INTSTS_SET_INTSTS31(mp2_cru_acc_vio_intsts_reg, intsts31) \
     mp2_cru_acc_vio_intsts_reg = (mp2_cru_acc_vio_intsts_reg & ~MP2_CRU_ACC_VIO_INTSTS_INTSTS31_MASK) | (intsts31 << MP2_CRU_ACC_VIO_INTSTS_INTSTS31_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_cru_acc_vio_intsts_t {
          unsigned int intsts0                        : MP2_CRU_ACC_VIO_INTSTS_INTSTS0_SIZE;
          unsigned int intsts1                        : MP2_CRU_ACC_VIO_INTSTS_INTSTS1_SIZE;
          unsigned int intsts2                        : MP2_CRU_ACC_VIO_INTSTS_INTSTS2_SIZE;
          unsigned int intsts3                        : MP2_CRU_ACC_VIO_INTSTS_INTSTS3_SIZE;
          unsigned int intsts4                        : MP2_CRU_ACC_VIO_INTSTS_INTSTS4_SIZE;
          unsigned int intsts5                        : MP2_CRU_ACC_VIO_INTSTS_INTSTS5_SIZE;
          unsigned int intsts6                        : MP2_CRU_ACC_VIO_INTSTS_INTSTS6_SIZE;
          unsigned int intsts7                        : MP2_CRU_ACC_VIO_INTSTS_INTSTS7_SIZE;
          unsigned int intsts8                        : MP2_CRU_ACC_VIO_INTSTS_INTSTS8_SIZE;
          unsigned int intsts9                        : MP2_CRU_ACC_VIO_INTSTS_INTSTS9_SIZE;
          unsigned int intsts10                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS10_SIZE;
          unsigned int intsts11                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS11_SIZE;
          unsigned int intsts12                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS12_SIZE;
          unsigned int intsts13                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS13_SIZE;
          unsigned int intsts14                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS14_SIZE;
          unsigned int intsts15                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS15_SIZE;
          unsigned int intsts16                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS16_SIZE;
          unsigned int intsts17                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS17_SIZE;
          unsigned int intsts18                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS18_SIZE;
          unsigned int intsts19                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS19_SIZE;
          unsigned int intsts20                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS20_SIZE;
          unsigned int intsts21                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS21_SIZE;
          unsigned int intsts22                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS22_SIZE;
          unsigned int intsts23                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS23_SIZE;
          unsigned int intsts24                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS24_SIZE;
          unsigned int intsts25                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS25_SIZE;
          unsigned int intsts26                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS26_SIZE;
          unsigned int intsts27                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS27_SIZE;
          unsigned int intsts28                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS28_SIZE;
          unsigned int intsts29                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS29_SIZE;
          unsigned int intsts30                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS30_SIZE;
          unsigned int intsts31                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS31_SIZE;
     } mp2_cru_acc_vio_intsts_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_cru_acc_vio_intsts_t {
          unsigned int intsts31                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS31_SIZE;
          unsigned int intsts30                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS30_SIZE;
          unsigned int intsts29                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS29_SIZE;
          unsigned int intsts28                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS28_SIZE;
          unsigned int intsts27                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS27_SIZE;
          unsigned int intsts26                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS26_SIZE;
          unsigned int intsts25                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS25_SIZE;
          unsigned int intsts24                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS24_SIZE;
          unsigned int intsts23                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS23_SIZE;
          unsigned int intsts22                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS22_SIZE;
          unsigned int intsts21                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS21_SIZE;
          unsigned int intsts20                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS20_SIZE;
          unsigned int intsts19                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS19_SIZE;
          unsigned int intsts18                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS18_SIZE;
          unsigned int intsts17                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS17_SIZE;
          unsigned int intsts16                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS16_SIZE;
          unsigned int intsts15                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS15_SIZE;
          unsigned int intsts14                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS14_SIZE;
          unsigned int intsts13                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS13_SIZE;
          unsigned int intsts12                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS12_SIZE;
          unsigned int intsts11                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS11_SIZE;
          unsigned int intsts10                       : MP2_CRU_ACC_VIO_INTSTS_INTSTS10_SIZE;
          unsigned int intsts9                        : MP2_CRU_ACC_VIO_INTSTS_INTSTS9_SIZE;
          unsigned int intsts8                        : MP2_CRU_ACC_VIO_INTSTS_INTSTS8_SIZE;
          unsigned int intsts7                        : MP2_CRU_ACC_VIO_INTSTS_INTSTS7_SIZE;
          unsigned int intsts6                        : MP2_CRU_ACC_VIO_INTSTS_INTSTS6_SIZE;
          unsigned int intsts5                        : MP2_CRU_ACC_VIO_INTSTS_INTSTS5_SIZE;
          unsigned int intsts4                        : MP2_CRU_ACC_VIO_INTSTS_INTSTS4_SIZE;
          unsigned int intsts3                        : MP2_CRU_ACC_VIO_INTSTS_INTSTS3_SIZE;
          unsigned int intsts2                        : MP2_CRU_ACC_VIO_INTSTS_INTSTS2_SIZE;
          unsigned int intsts1                        : MP2_CRU_ACC_VIO_INTSTS_INTSTS1_SIZE;
          unsigned int intsts0                        : MP2_CRU_ACC_VIO_INTSTS_INTSTS0_SIZE;
     } mp2_cru_acc_vio_intsts_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_cru_acc_vio_intsts_t f;
} mp2_cru_acc_vio_intsts_u;


/*
 * MP2_ACC_VIOL_LOG0 struct
 */

#define MP2_ACC_VIOL_LOG0_REG_SIZE     32
#define MP2_ACC_VIOL_LOG0_AXI_ACC_VIO_LOG_SIZE 31
#define MP2_ACC_VIOL_LOG0_AXI_LOG_CLEAR_SIZE 1

#define MP2_ACC_VIOL_LOG0_AXI_ACC_VIO_LOG_SHIFT 0
#define MP2_ACC_VIOL_LOG0_AXI_LOG_CLEAR_SHIFT 31

#define MP2_ACC_VIOL_LOG0_AXI_ACC_VIO_LOG_MASK 0x7fffffff
#define MP2_ACC_VIOL_LOG0_AXI_LOG_CLEAR_MASK 0x80000000

#define MP2_ACC_VIOL_LOG0_MASK \
     (MP2_ACC_VIOL_LOG0_AXI_ACC_VIO_LOG_MASK | \
      MP2_ACC_VIOL_LOG0_AXI_LOG_CLEAR_MASK)

#define MP2_ACC_VIOL_LOG0_DEFAULT      0x00000000

#define MP2_ACC_VIOL_LOG0_GET_AXI_ACC_VIO_LOG(mp2_acc_viol_log0) \
     ((mp2_acc_viol_log0 & MP2_ACC_VIOL_LOG0_AXI_ACC_VIO_LOG_MASK) >> MP2_ACC_VIOL_LOG0_AXI_ACC_VIO_LOG_SHIFT)
#define MP2_ACC_VIOL_LOG0_GET_AXI_LOG_CLEAR(mp2_acc_viol_log0) \
     ((mp2_acc_viol_log0 & MP2_ACC_VIOL_LOG0_AXI_LOG_CLEAR_MASK) >> MP2_ACC_VIOL_LOG0_AXI_LOG_CLEAR_SHIFT)

#define MP2_ACC_VIOL_LOG0_SET_AXI_ACC_VIO_LOG(mp2_acc_viol_log0_reg, axi_acc_vio_log) \
     mp2_acc_viol_log0_reg = (mp2_acc_viol_log0_reg & ~MP2_ACC_VIOL_LOG0_AXI_ACC_VIO_LOG_MASK) | (axi_acc_vio_log << MP2_ACC_VIOL_LOG0_AXI_ACC_VIO_LOG_SHIFT)
#define MP2_ACC_VIOL_LOG0_SET_AXI_LOG_CLEAR(mp2_acc_viol_log0_reg, axi_log_clear) \
     mp2_acc_viol_log0_reg = (mp2_acc_viol_log0_reg & ~MP2_ACC_VIOL_LOG0_AXI_LOG_CLEAR_MASK) | (axi_log_clear << MP2_ACC_VIOL_LOG0_AXI_LOG_CLEAR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_acc_viol_log0_t {
          unsigned int axi_acc_vio_log                : MP2_ACC_VIOL_LOG0_AXI_ACC_VIO_LOG_SIZE;
          unsigned int axi_log_clear                  : MP2_ACC_VIOL_LOG0_AXI_LOG_CLEAR_SIZE;
     } mp2_acc_viol_log0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_acc_viol_log0_t {
          unsigned int axi_log_clear                  : MP2_ACC_VIOL_LOG0_AXI_LOG_CLEAR_SIZE;
          unsigned int axi_acc_vio_log                : MP2_ACC_VIOL_LOG0_AXI_ACC_VIO_LOG_SIZE;
     } mp2_acc_viol_log0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_acc_viol_log0_t f;
} mp2_acc_viol_log0_u;


/*
 * MP2_ACC_VIOL_LOG1 struct
 */

#define MP2_ACC_VIOL_LOG1_REG_SIZE     32
#define MP2_ACC_VIOL_LOG1_AXI_ACC_VIO_ADDR_SIZE 32

#define MP2_ACC_VIOL_LOG1_AXI_ACC_VIO_ADDR_SHIFT 0

#define MP2_ACC_VIOL_LOG1_AXI_ACC_VIO_ADDR_MASK 0xffffffff

#define MP2_ACC_VIOL_LOG1_MASK \
     (MP2_ACC_VIOL_LOG1_AXI_ACC_VIO_ADDR_MASK)

#define MP2_ACC_VIOL_LOG1_DEFAULT      0x00000000

#define MP2_ACC_VIOL_LOG1_GET_AXI_ACC_VIO_ADDR(mp2_acc_viol_log1) \
     ((mp2_acc_viol_log1 & MP2_ACC_VIOL_LOG1_AXI_ACC_VIO_ADDR_MASK) >> MP2_ACC_VIOL_LOG1_AXI_ACC_VIO_ADDR_SHIFT)

#define MP2_ACC_VIOL_LOG1_SET_AXI_ACC_VIO_ADDR(mp2_acc_viol_log1_reg, axi_acc_vio_addr) \
     mp2_acc_viol_log1_reg = (mp2_acc_viol_log1_reg & ~MP2_ACC_VIOL_LOG1_AXI_ACC_VIO_ADDR_MASK) | (axi_acc_vio_addr << MP2_ACC_VIOL_LOG1_AXI_ACC_VIO_ADDR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_acc_viol_log1_t {
          unsigned int axi_acc_vio_addr               : MP2_ACC_VIOL_LOG1_AXI_ACC_VIO_ADDR_SIZE;
     } mp2_acc_viol_log1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_acc_viol_log1_t {
          unsigned int axi_acc_vio_addr               : MP2_ACC_VIOL_LOG1_AXI_ACC_VIO_ADDR_SIZE;
     } mp2_acc_viol_log1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_acc_viol_log1_t f;
} mp2_acc_viol_log1_u;


/*
 * MP2_STICKY struct
 */

#define MP2_STICKY_REG_SIZE            32
#define MP2_STICKY_DATA_SIZE           32

#define MP2_STICKY_DATA_SHIFT          0

#define MP2_STICKY_DATA_MASK           0xffffffff

#define MP2_STICKY_MASK \
     (MP2_STICKY_DATA_MASK)

#define MP2_STICKY_DEFAULT             0x00000000

#define MP2_STICKY_GET_DATA(mp2_sticky) \
     ((mp2_sticky & MP2_STICKY_DATA_MASK) >> MP2_STICKY_DATA_SHIFT)

#define MP2_STICKY_SET_DATA(mp2_sticky_reg, data) \
     mp2_sticky_reg = (mp2_sticky_reg & ~MP2_STICKY_DATA_MASK) | (data << MP2_STICKY_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_sticky_t {
          unsigned int data                           : MP2_STICKY_DATA_SIZE;
     } mp2_sticky_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_sticky_t {
          unsigned int data                           : MP2_STICKY_DATA_SIZE;
     } mp2_sticky_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_sticky_t f;
} mp2_sticky_u;


/*
 * MP2_CRU_MISC_CTRL struct
 */

#define MP2_CRU_MISC_CTRL_REG_SIZE     32
#define MP2_CRU_MISC_CTRL_ERROR_RESPONSE_ON_ACCVIOL_SIZE 1
#define MP2_CRU_MISC_CTRL_CLK_GATE_EN_SIZE 1
#define MP2_CRU_MISC_CTRL_SYSHUB_PME_SIZE 1
#define MP2_CRU_MISC_CTRL_CPUMSG_MPCPU_INTR_SIZE 1
#define MP2_CRU_MISC_CTRL_CPUMSG_MPJTAG_INTR_SIZE 1
#define MP2_CRU_MISC_CTRL_CPUMSG_SMN_INTR_SIZE 1
#define MP2_CRU_MISC_CTRL_I2C0_SYSHUB_INTR_EN_SIZE 1
#define MP2_CRU_MISC_CTRL_I2C1_SYSHUB_INTR_EN_SIZE 1

#define MP2_CRU_MISC_CTRL_ERROR_RESPONSE_ON_ACCVIOL_SHIFT 0
#define MP2_CRU_MISC_CTRL_CLK_GATE_EN_SHIFT 1
#define MP2_CRU_MISC_CTRL_SYSHUB_PME_SHIFT 16
#define MP2_CRU_MISC_CTRL_CPUMSG_MPCPU_INTR_SHIFT 24
#define MP2_CRU_MISC_CTRL_CPUMSG_MPJTAG_INTR_SHIFT 26
#define MP2_CRU_MISC_CTRL_CPUMSG_SMN_INTR_SHIFT 28
#define MP2_CRU_MISC_CTRL_I2C0_SYSHUB_INTR_EN_SHIFT 29
#define MP2_CRU_MISC_CTRL_I2C1_SYSHUB_INTR_EN_SHIFT 30

#define MP2_CRU_MISC_CTRL_ERROR_RESPONSE_ON_ACCVIOL_MASK 0x1
#define MP2_CRU_MISC_CTRL_CLK_GATE_EN_MASK 0x2
#define MP2_CRU_MISC_CTRL_SYSHUB_PME_MASK 0x10000
#define MP2_CRU_MISC_CTRL_CPUMSG_MPCPU_INTR_MASK 0x1000000
#define MP2_CRU_MISC_CTRL_CPUMSG_MPJTAG_INTR_MASK 0x4000000
#define MP2_CRU_MISC_CTRL_CPUMSG_SMN_INTR_MASK 0x10000000
#define MP2_CRU_MISC_CTRL_I2C0_SYSHUB_INTR_EN_MASK 0x20000000
#define MP2_CRU_MISC_CTRL_I2C1_SYSHUB_INTR_EN_MASK 0x40000000

#define MP2_CRU_MISC_CTRL_MASK \
     (MP2_CRU_MISC_CTRL_ERROR_RESPONSE_ON_ACCVIOL_MASK | \
      MP2_CRU_MISC_CTRL_CLK_GATE_EN_MASK | \
      MP2_CRU_MISC_CTRL_SYSHUB_PME_MASK | \
      MP2_CRU_MISC_CTRL_CPUMSG_MPCPU_INTR_MASK | \
      MP2_CRU_MISC_CTRL_CPUMSG_MPJTAG_INTR_MASK | \
      MP2_CRU_MISC_CTRL_CPUMSG_SMN_INTR_MASK | \
      MP2_CRU_MISC_CTRL_I2C0_SYSHUB_INTR_EN_MASK | \
      MP2_CRU_MISC_CTRL_I2C1_SYSHUB_INTR_EN_MASK)

#define MP2_CRU_MISC_CTRL_DEFAULT      0x10000003

#define MP2_CRU_MISC_CTRL_GET_ERROR_RESPONSE_ON_ACCVIOL(mp2_cru_misc_ctrl) \
     ((mp2_cru_misc_ctrl & MP2_CRU_MISC_CTRL_ERROR_RESPONSE_ON_ACCVIOL_MASK) >> MP2_CRU_MISC_CTRL_ERROR_RESPONSE_ON_ACCVIOL_SHIFT)
#define MP2_CRU_MISC_CTRL_GET_CLK_GATE_EN(mp2_cru_misc_ctrl) \
     ((mp2_cru_misc_ctrl & MP2_CRU_MISC_CTRL_CLK_GATE_EN_MASK) >> MP2_CRU_MISC_CTRL_CLK_GATE_EN_SHIFT)
#define MP2_CRU_MISC_CTRL_GET_SYSHUB_PME(mp2_cru_misc_ctrl) \
     ((mp2_cru_misc_ctrl & MP2_CRU_MISC_CTRL_SYSHUB_PME_MASK) >> MP2_CRU_MISC_CTRL_SYSHUB_PME_SHIFT)
#define MP2_CRU_MISC_CTRL_GET_CPUMSG_MPCPU_INTR(mp2_cru_misc_ctrl) \
     ((mp2_cru_misc_ctrl & MP2_CRU_MISC_CTRL_CPUMSG_MPCPU_INTR_MASK) >> MP2_CRU_MISC_CTRL_CPUMSG_MPCPU_INTR_SHIFT)
#define MP2_CRU_MISC_CTRL_GET_CPUMSG_MPJTAG_INTR(mp2_cru_misc_ctrl) \
     ((mp2_cru_misc_ctrl & MP2_CRU_MISC_CTRL_CPUMSG_MPJTAG_INTR_MASK) >> MP2_CRU_MISC_CTRL_CPUMSG_MPJTAG_INTR_SHIFT)
#define MP2_CRU_MISC_CTRL_GET_CPUMSG_SMN_INTR(mp2_cru_misc_ctrl) \
     ((mp2_cru_misc_ctrl & MP2_CRU_MISC_CTRL_CPUMSG_SMN_INTR_MASK) >> MP2_CRU_MISC_CTRL_CPUMSG_SMN_INTR_SHIFT)
#define MP2_CRU_MISC_CTRL_GET_I2C0_SYSHUB_INTR_EN(mp2_cru_misc_ctrl) \
     ((mp2_cru_misc_ctrl & MP2_CRU_MISC_CTRL_I2C0_SYSHUB_INTR_EN_MASK) >> MP2_CRU_MISC_CTRL_I2C0_SYSHUB_INTR_EN_SHIFT)
#define MP2_CRU_MISC_CTRL_GET_I2C1_SYSHUB_INTR_EN(mp2_cru_misc_ctrl) \
     ((mp2_cru_misc_ctrl & MP2_CRU_MISC_CTRL_I2C1_SYSHUB_INTR_EN_MASK) >> MP2_CRU_MISC_CTRL_I2C1_SYSHUB_INTR_EN_SHIFT)

#define MP2_CRU_MISC_CTRL_SET_ERROR_RESPONSE_ON_ACCVIOL(mp2_cru_misc_ctrl_reg, error_response_on_accviol) \
     mp2_cru_misc_ctrl_reg = (mp2_cru_misc_ctrl_reg & ~MP2_CRU_MISC_CTRL_ERROR_RESPONSE_ON_ACCVIOL_MASK) | (error_response_on_accviol << MP2_CRU_MISC_CTRL_ERROR_RESPONSE_ON_ACCVIOL_SHIFT)
#define MP2_CRU_MISC_CTRL_SET_CLK_GATE_EN(mp2_cru_misc_ctrl_reg, clk_gate_en) \
     mp2_cru_misc_ctrl_reg = (mp2_cru_misc_ctrl_reg & ~MP2_CRU_MISC_CTRL_CLK_GATE_EN_MASK) | (clk_gate_en << MP2_CRU_MISC_CTRL_CLK_GATE_EN_SHIFT)
#define MP2_CRU_MISC_CTRL_SET_SYSHUB_PME(mp2_cru_misc_ctrl_reg, syshub_pme) \
     mp2_cru_misc_ctrl_reg = (mp2_cru_misc_ctrl_reg & ~MP2_CRU_MISC_CTRL_SYSHUB_PME_MASK) | (syshub_pme << MP2_CRU_MISC_CTRL_SYSHUB_PME_SHIFT)
#define MP2_CRU_MISC_CTRL_SET_CPUMSG_MPCPU_INTR(mp2_cru_misc_ctrl_reg, cpumsg_mpcpu_intr) \
     mp2_cru_misc_ctrl_reg = (mp2_cru_misc_ctrl_reg & ~MP2_CRU_MISC_CTRL_CPUMSG_MPCPU_INTR_MASK) | (cpumsg_mpcpu_intr << MP2_CRU_MISC_CTRL_CPUMSG_MPCPU_INTR_SHIFT)
#define MP2_CRU_MISC_CTRL_SET_CPUMSG_MPJTAG_INTR(mp2_cru_misc_ctrl_reg, cpumsg_mpjtag_intr) \
     mp2_cru_misc_ctrl_reg = (mp2_cru_misc_ctrl_reg & ~MP2_CRU_MISC_CTRL_CPUMSG_MPJTAG_INTR_MASK) | (cpumsg_mpjtag_intr << MP2_CRU_MISC_CTRL_CPUMSG_MPJTAG_INTR_SHIFT)
#define MP2_CRU_MISC_CTRL_SET_CPUMSG_SMN_INTR(mp2_cru_misc_ctrl_reg, cpumsg_smn_intr) \
     mp2_cru_misc_ctrl_reg = (mp2_cru_misc_ctrl_reg & ~MP2_CRU_MISC_CTRL_CPUMSG_SMN_INTR_MASK) | (cpumsg_smn_intr << MP2_CRU_MISC_CTRL_CPUMSG_SMN_INTR_SHIFT)
#define MP2_CRU_MISC_CTRL_SET_I2C0_SYSHUB_INTR_EN(mp2_cru_misc_ctrl_reg, i2c0_syshub_intr_en) \
     mp2_cru_misc_ctrl_reg = (mp2_cru_misc_ctrl_reg & ~MP2_CRU_MISC_CTRL_I2C0_SYSHUB_INTR_EN_MASK) | (i2c0_syshub_intr_en << MP2_CRU_MISC_CTRL_I2C0_SYSHUB_INTR_EN_SHIFT)
#define MP2_CRU_MISC_CTRL_SET_I2C1_SYSHUB_INTR_EN(mp2_cru_misc_ctrl_reg, i2c1_syshub_intr_en) \
     mp2_cru_misc_ctrl_reg = (mp2_cru_misc_ctrl_reg & ~MP2_CRU_MISC_CTRL_I2C1_SYSHUB_INTR_EN_MASK) | (i2c1_syshub_intr_en << MP2_CRU_MISC_CTRL_I2C1_SYSHUB_INTR_EN_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_cru_misc_ctrl_t {
          unsigned int error_response_on_accviol      : MP2_CRU_MISC_CTRL_ERROR_RESPONSE_ON_ACCVIOL_SIZE;
          unsigned int clk_gate_en                    : MP2_CRU_MISC_CTRL_CLK_GATE_EN_SIZE;
          unsigned int                                : 14;
          unsigned int syshub_pme                     : MP2_CRU_MISC_CTRL_SYSHUB_PME_SIZE;
          unsigned int                                : 7;
          unsigned int cpumsg_mpcpu_intr              : MP2_CRU_MISC_CTRL_CPUMSG_MPCPU_INTR_SIZE;
          unsigned int                                : 1;
          unsigned int cpumsg_mpjtag_intr             : MP2_CRU_MISC_CTRL_CPUMSG_MPJTAG_INTR_SIZE;
          unsigned int                                : 1;
          unsigned int cpumsg_smn_intr                : MP2_CRU_MISC_CTRL_CPUMSG_SMN_INTR_SIZE;
          unsigned int i2c0_syshub_intr_en            : MP2_CRU_MISC_CTRL_I2C0_SYSHUB_INTR_EN_SIZE;
          unsigned int i2c1_syshub_intr_en            : MP2_CRU_MISC_CTRL_I2C1_SYSHUB_INTR_EN_SIZE;
          unsigned int                                : 1;
     } mp2_cru_misc_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_cru_misc_ctrl_t {
          unsigned int                                : 1;
          unsigned int i2c1_syshub_intr_en            : MP2_CRU_MISC_CTRL_I2C1_SYSHUB_INTR_EN_SIZE;
          unsigned int i2c0_syshub_intr_en            : MP2_CRU_MISC_CTRL_I2C0_SYSHUB_INTR_EN_SIZE;
          unsigned int cpumsg_smn_intr                : MP2_CRU_MISC_CTRL_CPUMSG_SMN_INTR_SIZE;
          unsigned int                                : 1;
          unsigned int cpumsg_mpjtag_intr             : MP2_CRU_MISC_CTRL_CPUMSG_MPJTAG_INTR_SIZE;
          unsigned int                                : 1;
          unsigned int cpumsg_mpcpu_intr              : MP2_CRU_MISC_CTRL_CPUMSG_MPCPU_INTR_SIZE;
          unsigned int                                : 7;
          unsigned int syshub_pme                     : MP2_CRU_MISC_CTRL_SYSHUB_PME_SIZE;
          unsigned int                                : 14;
          unsigned int clk_gate_en                    : MP2_CRU_MISC_CTRL_CLK_GATE_EN_SIZE;
          unsigned int error_response_on_accviol      : MP2_CRU_MISC_CTRL_ERROR_RESPONSE_ON_ACCVIOL_SIZE;
     } mp2_cru_misc_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_cru_misc_ctrl_t f;
} mp2_cru_misc_ctrl_u;


/*
 * MP2_SOFT_RESET_CTRL struct
 */

#define MP2_SOFT_RESET_CTRL_REG_SIZE   32
#define MP2_SOFT_RESET_CTRL_MP_MMU_RESET_SIZE 1
#define MP2_SOFT_RESET_CTRL_MP_CPU_RESET_SIZE 1
#define MP2_SOFT_RESET_CTRL_MP_SMNIF_RESET_SIZE 1
#define MP2_SOFT_RESET_CTRL_MP_DAP_RESET_SIZE 1
#define MP2_SOFT_RESET_CTRL_MP_DMAC_RESET_SIZE 1
#define MP2_SOFT_RESET_CTRL_MP_HUBIFNB_RESET_SIZE 1
#define MP2_SOFT_RESET_CTRL_MP_I2C_RESET_SIZE 1
#define MP2_SOFT_RESET_CTRL_MP_SMN_VDCI_RESET_SIZE 1

#define MP2_SOFT_RESET_CTRL_MP_MMU_RESET_SHIFT 0
#define MP2_SOFT_RESET_CTRL_MP_CPU_RESET_SHIFT 1
#define MP2_SOFT_RESET_CTRL_MP_SMNIF_RESET_SHIFT 2
#define MP2_SOFT_RESET_CTRL_MP_DAP_RESET_SHIFT 4
#define MP2_SOFT_RESET_CTRL_MP_DMAC_RESET_SHIFT 6
#define MP2_SOFT_RESET_CTRL_MP_HUBIFNB_RESET_SHIFT 10
#define MP2_SOFT_RESET_CTRL_MP_I2C_RESET_SHIFT 13
#define MP2_SOFT_RESET_CTRL_MP_SMN_VDCI_RESET_SHIFT 15

#define MP2_SOFT_RESET_CTRL_MP_MMU_RESET_MASK 0x1
#define MP2_SOFT_RESET_CTRL_MP_CPU_RESET_MASK 0x2
#define MP2_SOFT_RESET_CTRL_MP_SMNIF_RESET_MASK 0x4
#define MP2_SOFT_RESET_CTRL_MP_DAP_RESET_MASK 0x10
#define MP2_SOFT_RESET_CTRL_MP_DMAC_RESET_MASK 0x40
#define MP2_SOFT_RESET_CTRL_MP_HUBIFNB_RESET_MASK 0x400
#define MP2_SOFT_RESET_CTRL_MP_I2C_RESET_MASK 0x2000
#define MP2_SOFT_RESET_CTRL_MP_SMN_VDCI_RESET_MASK 0x8000

#define MP2_SOFT_RESET_CTRL_MASK \
     (MP2_SOFT_RESET_CTRL_MP_MMU_RESET_MASK | \
      MP2_SOFT_RESET_CTRL_MP_CPU_RESET_MASK | \
      MP2_SOFT_RESET_CTRL_MP_SMNIF_RESET_MASK | \
      MP2_SOFT_RESET_CTRL_MP_DAP_RESET_MASK | \
      MP2_SOFT_RESET_CTRL_MP_DMAC_RESET_MASK | \
      MP2_SOFT_RESET_CTRL_MP_HUBIFNB_RESET_MASK | \
      MP2_SOFT_RESET_CTRL_MP_I2C_RESET_MASK | \
      MP2_SOFT_RESET_CTRL_MP_SMN_VDCI_RESET_MASK)

#define MP2_SOFT_RESET_CTRL_DEFAULT    0x00000002

#define MP2_SOFT_RESET_CTRL_GET_MP_MMU_RESET(mp2_soft_reset_ctrl) \
     ((mp2_soft_reset_ctrl & MP2_SOFT_RESET_CTRL_MP_MMU_RESET_MASK) >> MP2_SOFT_RESET_CTRL_MP_MMU_RESET_SHIFT)
#define MP2_SOFT_RESET_CTRL_GET_MP_CPU_RESET(mp2_soft_reset_ctrl) \
     ((mp2_soft_reset_ctrl & MP2_SOFT_RESET_CTRL_MP_CPU_RESET_MASK) >> MP2_SOFT_RESET_CTRL_MP_CPU_RESET_SHIFT)
#define MP2_SOFT_RESET_CTRL_GET_MP_SMNIF_RESET(mp2_soft_reset_ctrl) \
     ((mp2_soft_reset_ctrl & MP2_SOFT_RESET_CTRL_MP_SMNIF_RESET_MASK) >> MP2_SOFT_RESET_CTRL_MP_SMNIF_RESET_SHIFT)
#define MP2_SOFT_RESET_CTRL_GET_MP_DAP_RESET(mp2_soft_reset_ctrl) \
     ((mp2_soft_reset_ctrl & MP2_SOFT_RESET_CTRL_MP_DAP_RESET_MASK) >> MP2_SOFT_RESET_CTRL_MP_DAP_RESET_SHIFT)
#define MP2_SOFT_RESET_CTRL_GET_MP_DMAC_RESET(mp2_soft_reset_ctrl) \
     ((mp2_soft_reset_ctrl & MP2_SOFT_RESET_CTRL_MP_DMAC_RESET_MASK) >> MP2_SOFT_RESET_CTRL_MP_DMAC_RESET_SHIFT)
#define MP2_SOFT_RESET_CTRL_GET_MP_HUBIFNB_RESET(mp2_soft_reset_ctrl) \
     ((mp2_soft_reset_ctrl & MP2_SOFT_RESET_CTRL_MP_HUBIFNB_RESET_MASK) >> MP2_SOFT_RESET_CTRL_MP_HUBIFNB_RESET_SHIFT)
#define MP2_SOFT_RESET_CTRL_GET_MP_I2C_RESET(mp2_soft_reset_ctrl) \
     ((mp2_soft_reset_ctrl & MP2_SOFT_RESET_CTRL_MP_I2C_RESET_MASK) >> MP2_SOFT_RESET_CTRL_MP_I2C_RESET_SHIFT)
#define MP2_SOFT_RESET_CTRL_GET_MP_SMN_VDCI_RESET(mp2_soft_reset_ctrl) \
     ((mp2_soft_reset_ctrl & MP2_SOFT_RESET_CTRL_MP_SMN_VDCI_RESET_MASK) >> MP2_SOFT_RESET_CTRL_MP_SMN_VDCI_RESET_SHIFT)

#define MP2_SOFT_RESET_CTRL_SET_MP_MMU_RESET(mp2_soft_reset_ctrl_reg, mp_mmu_reset) \
     mp2_soft_reset_ctrl_reg = (mp2_soft_reset_ctrl_reg & ~MP2_SOFT_RESET_CTRL_MP_MMU_RESET_MASK) | (mp_mmu_reset << MP2_SOFT_RESET_CTRL_MP_MMU_RESET_SHIFT)
#define MP2_SOFT_RESET_CTRL_SET_MP_CPU_RESET(mp2_soft_reset_ctrl_reg, mp_cpu_reset) \
     mp2_soft_reset_ctrl_reg = (mp2_soft_reset_ctrl_reg & ~MP2_SOFT_RESET_CTRL_MP_CPU_RESET_MASK) | (mp_cpu_reset << MP2_SOFT_RESET_CTRL_MP_CPU_RESET_SHIFT)
#define MP2_SOFT_RESET_CTRL_SET_MP_SMNIF_RESET(mp2_soft_reset_ctrl_reg, mp_smnif_reset) \
     mp2_soft_reset_ctrl_reg = (mp2_soft_reset_ctrl_reg & ~MP2_SOFT_RESET_CTRL_MP_SMNIF_RESET_MASK) | (mp_smnif_reset << MP2_SOFT_RESET_CTRL_MP_SMNIF_RESET_SHIFT)
#define MP2_SOFT_RESET_CTRL_SET_MP_DAP_RESET(mp2_soft_reset_ctrl_reg, mp_dap_reset) \
     mp2_soft_reset_ctrl_reg = (mp2_soft_reset_ctrl_reg & ~MP2_SOFT_RESET_CTRL_MP_DAP_RESET_MASK) | (mp_dap_reset << MP2_SOFT_RESET_CTRL_MP_DAP_RESET_SHIFT)
#define MP2_SOFT_RESET_CTRL_SET_MP_DMAC_RESET(mp2_soft_reset_ctrl_reg, mp_dmac_reset) \
     mp2_soft_reset_ctrl_reg = (mp2_soft_reset_ctrl_reg & ~MP2_SOFT_RESET_CTRL_MP_DMAC_RESET_MASK) | (mp_dmac_reset << MP2_SOFT_RESET_CTRL_MP_DMAC_RESET_SHIFT)
#define MP2_SOFT_RESET_CTRL_SET_MP_HUBIFNB_RESET(mp2_soft_reset_ctrl_reg, mp_hubifnb_reset) \
     mp2_soft_reset_ctrl_reg = (mp2_soft_reset_ctrl_reg & ~MP2_SOFT_RESET_CTRL_MP_HUBIFNB_RESET_MASK) | (mp_hubifnb_reset << MP2_SOFT_RESET_CTRL_MP_HUBIFNB_RESET_SHIFT)
#define MP2_SOFT_RESET_CTRL_SET_MP_I2C_RESET(mp2_soft_reset_ctrl_reg, mp_i2c_reset) \
     mp2_soft_reset_ctrl_reg = (mp2_soft_reset_ctrl_reg & ~MP2_SOFT_RESET_CTRL_MP_I2C_RESET_MASK) | (mp_i2c_reset << MP2_SOFT_RESET_CTRL_MP_I2C_RESET_SHIFT)
#define MP2_SOFT_RESET_CTRL_SET_MP_SMN_VDCI_RESET(mp2_soft_reset_ctrl_reg, mp_smn_vdci_reset) \
     mp2_soft_reset_ctrl_reg = (mp2_soft_reset_ctrl_reg & ~MP2_SOFT_RESET_CTRL_MP_SMN_VDCI_RESET_MASK) | (mp_smn_vdci_reset << MP2_SOFT_RESET_CTRL_MP_SMN_VDCI_RESET_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_soft_reset_ctrl_t {
          unsigned int mp_mmu_reset                   : MP2_SOFT_RESET_CTRL_MP_MMU_RESET_SIZE;
          unsigned int mp_cpu_reset                   : MP2_SOFT_RESET_CTRL_MP_CPU_RESET_SIZE;
          unsigned int mp_smnif_reset                 : MP2_SOFT_RESET_CTRL_MP_SMNIF_RESET_SIZE;
          unsigned int                                : 1;
          unsigned int mp_dap_reset                   : MP2_SOFT_RESET_CTRL_MP_DAP_RESET_SIZE;
          unsigned int                                : 1;
          unsigned int mp_dmac_reset                  : MP2_SOFT_RESET_CTRL_MP_DMAC_RESET_SIZE;
          unsigned int                                : 3;
          unsigned int mp_hubifnb_reset               : MP2_SOFT_RESET_CTRL_MP_HUBIFNB_RESET_SIZE;
          unsigned int                                : 2;
          unsigned int mp_i2c_reset                   : MP2_SOFT_RESET_CTRL_MP_I2C_RESET_SIZE;
          unsigned int                                : 1;
          unsigned int mp_smn_vdci_reset              : MP2_SOFT_RESET_CTRL_MP_SMN_VDCI_RESET_SIZE;
          unsigned int                                : 16;
     } mp2_soft_reset_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_soft_reset_ctrl_t {
          unsigned int                                : 16;
          unsigned int mp_smn_vdci_reset              : MP2_SOFT_RESET_CTRL_MP_SMN_VDCI_RESET_SIZE;
          unsigned int                                : 1;
          unsigned int mp_i2c_reset                   : MP2_SOFT_RESET_CTRL_MP_I2C_RESET_SIZE;
          unsigned int                                : 2;
          unsigned int mp_hubifnb_reset               : MP2_SOFT_RESET_CTRL_MP_HUBIFNB_RESET_SIZE;
          unsigned int                                : 3;
          unsigned int mp_dmac_reset                  : MP2_SOFT_RESET_CTRL_MP_DMAC_RESET_SIZE;
          unsigned int                                : 1;
          unsigned int mp_dap_reset                   : MP2_SOFT_RESET_CTRL_MP_DAP_RESET_SIZE;
          unsigned int                                : 1;
          unsigned int mp_smnif_reset                 : MP2_SOFT_RESET_CTRL_MP_SMNIF_RESET_SIZE;
          unsigned int mp_cpu_reset                   : MP2_SOFT_RESET_CTRL_MP_CPU_RESET_SIZE;
          unsigned int mp_mmu_reset                   : MP2_SOFT_RESET_CTRL_MP_MMU_RESET_SIZE;
     } mp2_soft_reset_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_soft_reset_ctrl_t f;
} mp2_soft_reset_ctrl_u;


/*
 * MP2_NS_PROT_FAULT_STATUS_0 struct
 */

#define MP2_NS_PROT_FAULT_STATUS_0_REG_SIZE 32
#define MP2_NS_PROT_FAULT_STATUS_0_MMU_CFG_NS0_VIOL_SIZE 1
#define MP2_NS_PROT_FAULT_STATUS_0_MMU_SRAM_NS0_VIOL_SIZE 1
#define MP2_NS_PROT_FAULT_STATUS_0_CRU_NS0_VIOL_SIZE 1

#define MP2_NS_PROT_FAULT_STATUS_0_MMU_CFG_NS0_VIOL_SHIFT 0
#define MP2_NS_PROT_FAULT_STATUS_0_MMU_SRAM_NS0_VIOL_SHIFT 1
#define MP2_NS_PROT_FAULT_STATUS_0_CRU_NS0_VIOL_SHIFT 4

#define MP2_NS_PROT_FAULT_STATUS_0_MMU_CFG_NS0_VIOL_MASK 0x1
#define MP2_NS_PROT_FAULT_STATUS_0_MMU_SRAM_NS0_VIOL_MASK 0x2
#define MP2_NS_PROT_FAULT_STATUS_0_CRU_NS0_VIOL_MASK 0x10

#define MP2_NS_PROT_FAULT_STATUS_0_MASK \
     (MP2_NS_PROT_FAULT_STATUS_0_MMU_CFG_NS0_VIOL_MASK | \
      MP2_NS_PROT_FAULT_STATUS_0_MMU_SRAM_NS0_VIOL_MASK | \
      MP2_NS_PROT_FAULT_STATUS_0_CRU_NS0_VIOL_MASK)

#define MP2_NS_PROT_FAULT_STATUS_0_DEFAULT 0x00000000

#define MP2_NS_PROT_FAULT_STATUS_0_GET_MMU_CFG_NS0_VIOL(mp2_ns_prot_fault_status_0) \
     ((mp2_ns_prot_fault_status_0 & MP2_NS_PROT_FAULT_STATUS_0_MMU_CFG_NS0_VIOL_MASK) >> MP2_NS_PROT_FAULT_STATUS_0_MMU_CFG_NS0_VIOL_SHIFT)
#define MP2_NS_PROT_FAULT_STATUS_0_GET_MMU_SRAM_NS0_VIOL(mp2_ns_prot_fault_status_0) \
     ((mp2_ns_prot_fault_status_0 & MP2_NS_PROT_FAULT_STATUS_0_MMU_SRAM_NS0_VIOL_MASK) >> MP2_NS_PROT_FAULT_STATUS_0_MMU_SRAM_NS0_VIOL_SHIFT)
#define MP2_NS_PROT_FAULT_STATUS_0_GET_CRU_NS0_VIOL(mp2_ns_prot_fault_status_0) \
     ((mp2_ns_prot_fault_status_0 & MP2_NS_PROT_FAULT_STATUS_0_CRU_NS0_VIOL_MASK) >> MP2_NS_PROT_FAULT_STATUS_0_CRU_NS0_VIOL_SHIFT)

#define MP2_NS_PROT_FAULT_STATUS_0_SET_MMU_CFG_NS0_VIOL(mp2_ns_prot_fault_status_0_reg, mmu_cfg_ns0_viol) \
     mp2_ns_prot_fault_status_0_reg = (mp2_ns_prot_fault_status_0_reg & ~MP2_NS_PROT_FAULT_STATUS_0_MMU_CFG_NS0_VIOL_MASK) | (mmu_cfg_ns0_viol << MP2_NS_PROT_FAULT_STATUS_0_MMU_CFG_NS0_VIOL_SHIFT)
#define MP2_NS_PROT_FAULT_STATUS_0_SET_MMU_SRAM_NS0_VIOL(mp2_ns_prot_fault_status_0_reg, mmu_sram_ns0_viol) \
     mp2_ns_prot_fault_status_0_reg = (mp2_ns_prot_fault_status_0_reg & ~MP2_NS_PROT_FAULT_STATUS_0_MMU_SRAM_NS0_VIOL_MASK) | (mmu_sram_ns0_viol << MP2_NS_PROT_FAULT_STATUS_0_MMU_SRAM_NS0_VIOL_SHIFT)
#define MP2_NS_PROT_FAULT_STATUS_0_SET_CRU_NS0_VIOL(mp2_ns_prot_fault_status_0_reg, cru_ns0_viol) \
     mp2_ns_prot_fault_status_0_reg = (mp2_ns_prot_fault_status_0_reg & ~MP2_NS_PROT_FAULT_STATUS_0_CRU_NS0_VIOL_MASK) | (cru_ns0_viol << MP2_NS_PROT_FAULT_STATUS_0_CRU_NS0_VIOL_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_ns_prot_fault_status_0_t {
          unsigned int mmu_cfg_ns0_viol               : MP2_NS_PROT_FAULT_STATUS_0_MMU_CFG_NS0_VIOL_SIZE;
          unsigned int mmu_sram_ns0_viol              : MP2_NS_PROT_FAULT_STATUS_0_MMU_SRAM_NS0_VIOL_SIZE;
          unsigned int                                : 2;
          unsigned int cru_ns0_viol                   : MP2_NS_PROT_FAULT_STATUS_0_CRU_NS0_VIOL_SIZE;
          unsigned int                                : 27;
     } mp2_ns_prot_fault_status_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_ns_prot_fault_status_0_t {
          unsigned int                                : 27;
          unsigned int cru_ns0_viol                   : MP2_NS_PROT_FAULT_STATUS_0_CRU_NS0_VIOL_SIZE;
          unsigned int                                : 2;
          unsigned int mmu_sram_ns0_viol              : MP2_NS_PROT_FAULT_STATUS_0_MMU_SRAM_NS0_VIOL_SIZE;
          unsigned int mmu_cfg_ns0_viol               : MP2_NS_PROT_FAULT_STATUS_0_MMU_CFG_NS0_VIOL_SIZE;
     } mp2_ns_prot_fault_status_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_ns_prot_fault_status_0_t f;
} mp2_ns_prot_fault_status_0_u;


/*
 * MP2_SEC_SCRATCH0 struct
 */

#define MP2_SEC_SCRATCH0_REG_SIZE      32
#define MP2_SEC_SCRATCH0_DATA_SIZE     32

#define MP2_SEC_SCRATCH0_DATA_SHIFT    0

#define MP2_SEC_SCRATCH0_DATA_MASK     0xffffffff

#define MP2_SEC_SCRATCH0_MASK \
     (MP2_SEC_SCRATCH0_DATA_MASK)

#define MP2_SEC_SCRATCH0_DEFAULT       0x00000000

#define MP2_SEC_SCRATCH0_GET_DATA(mp2_sec_scratch0) \
     ((mp2_sec_scratch0 & MP2_SEC_SCRATCH0_DATA_MASK) >> MP2_SEC_SCRATCH0_DATA_SHIFT)

#define MP2_SEC_SCRATCH0_SET_DATA(mp2_sec_scratch0_reg, data) \
     mp2_sec_scratch0_reg = (mp2_sec_scratch0_reg & ~MP2_SEC_SCRATCH0_DATA_MASK) | (data << MP2_SEC_SCRATCH0_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_sec_scratch0_t {
          unsigned int data                           : MP2_SEC_SCRATCH0_DATA_SIZE;
     } mp2_sec_scratch0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_sec_scratch0_t {
          unsigned int data                           : MP2_SEC_SCRATCH0_DATA_SIZE;
     } mp2_sec_scratch0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_sec_scratch0_t f;
} mp2_sec_scratch0_u;


/*
 * MP2_SEC_SCRATCH1 struct
 */

#define MP2_SEC_SCRATCH1_REG_SIZE      32
#define MP2_SEC_SCRATCH1_DATA_SIZE     32

#define MP2_SEC_SCRATCH1_DATA_SHIFT    0

#define MP2_SEC_SCRATCH1_DATA_MASK     0xffffffff

#define MP2_SEC_SCRATCH1_MASK \
     (MP2_SEC_SCRATCH1_DATA_MASK)

#define MP2_SEC_SCRATCH1_DEFAULT       0x00000000

#define MP2_SEC_SCRATCH1_GET_DATA(mp2_sec_scratch1) \
     ((mp2_sec_scratch1 & MP2_SEC_SCRATCH1_DATA_MASK) >> MP2_SEC_SCRATCH1_DATA_SHIFT)

#define MP2_SEC_SCRATCH1_SET_DATA(mp2_sec_scratch1_reg, data) \
     mp2_sec_scratch1_reg = (mp2_sec_scratch1_reg & ~MP2_SEC_SCRATCH1_DATA_MASK) | (data << MP2_SEC_SCRATCH1_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_sec_scratch1_t {
          unsigned int data                           : MP2_SEC_SCRATCH1_DATA_SIZE;
     } mp2_sec_scratch1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_sec_scratch1_t {
          unsigned int data                           : MP2_SEC_SCRATCH1_DATA_SIZE;
     } mp2_sec_scratch1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_sec_scratch1_t f;
} mp2_sec_scratch1_u;


/*
 * MP2_SEC_SCRATCH2 struct
 */

#define MP2_SEC_SCRATCH2_REG_SIZE      32
#define MP2_SEC_SCRATCH2_DATA_SIZE     32

#define MP2_SEC_SCRATCH2_DATA_SHIFT    0

#define MP2_SEC_SCRATCH2_DATA_MASK     0xffffffff

#define MP2_SEC_SCRATCH2_MASK \
     (MP2_SEC_SCRATCH2_DATA_MASK)

#define MP2_SEC_SCRATCH2_DEFAULT       0x00000000

#define MP2_SEC_SCRATCH2_GET_DATA(mp2_sec_scratch2) \
     ((mp2_sec_scratch2 & MP2_SEC_SCRATCH2_DATA_MASK) >> MP2_SEC_SCRATCH2_DATA_SHIFT)

#define MP2_SEC_SCRATCH2_SET_DATA(mp2_sec_scratch2_reg, data) \
     mp2_sec_scratch2_reg = (mp2_sec_scratch2_reg & ~MP2_SEC_SCRATCH2_DATA_MASK) | (data << MP2_SEC_SCRATCH2_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_sec_scratch2_t {
          unsigned int data                           : MP2_SEC_SCRATCH2_DATA_SIZE;
     } mp2_sec_scratch2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_sec_scratch2_t {
          unsigned int data                           : MP2_SEC_SCRATCH2_DATA_SIZE;
     } mp2_sec_scratch2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_sec_scratch2_t f;
} mp2_sec_scratch2_u;


/*
 * MP2_SEC_SCRATCH3 struct
 */

#define MP2_SEC_SCRATCH3_REG_SIZE      32
#define MP2_SEC_SCRATCH3_DATA_SIZE     32

#define MP2_SEC_SCRATCH3_DATA_SHIFT    0

#define MP2_SEC_SCRATCH3_DATA_MASK     0xffffffff

#define MP2_SEC_SCRATCH3_MASK \
     (MP2_SEC_SCRATCH3_DATA_MASK)

#define MP2_SEC_SCRATCH3_DEFAULT       0x00000000

#define MP2_SEC_SCRATCH3_GET_DATA(mp2_sec_scratch3) \
     ((mp2_sec_scratch3 & MP2_SEC_SCRATCH3_DATA_MASK) >> MP2_SEC_SCRATCH3_DATA_SHIFT)

#define MP2_SEC_SCRATCH3_SET_DATA(mp2_sec_scratch3_reg, data) \
     mp2_sec_scratch3_reg = (mp2_sec_scratch3_reg & ~MP2_SEC_SCRATCH3_DATA_MASK) | (data << MP2_SEC_SCRATCH3_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_sec_scratch3_t {
          unsigned int data                           : MP2_SEC_SCRATCH3_DATA_SIZE;
     } mp2_sec_scratch3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_sec_scratch3_t {
          unsigned int data                           : MP2_SEC_SCRATCH3_DATA_SIZE;
     } mp2_sec_scratch3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_sec_scratch3_t f;
} mp2_sec_scratch3_u;


/*
 * MP2_SEC_ECO0 struct
 */

#define MP2_SEC_ECO0_REG_SIZE          32
#define MP2_SEC_ECO0_DATA_SIZE         32

#define MP2_SEC_ECO0_DATA_SHIFT        0

#define MP2_SEC_ECO0_DATA_MASK         0xffffffff

#define MP2_SEC_ECO0_MASK \
     (MP2_SEC_ECO0_DATA_MASK)

#define MP2_SEC_ECO0_DEFAULT           0x00000000

#define MP2_SEC_ECO0_GET_DATA(mp2_sec_eco0) \
     ((mp2_sec_eco0 & MP2_SEC_ECO0_DATA_MASK) >> MP2_SEC_ECO0_DATA_SHIFT)

#define MP2_SEC_ECO0_SET_DATA(mp2_sec_eco0_reg, data) \
     mp2_sec_eco0_reg = (mp2_sec_eco0_reg & ~MP2_SEC_ECO0_DATA_MASK) | (data << MP2_SEC_ECO0_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_sec_eco0_t {
          unsigned int data                           : MP2_SEC_ECO0_DATA_SIZE;
     } mp2_sec_eco0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_sec_eco0_t {
          unsigned int data                           : MP2_SEC_ECO0_DATA_SIZE;
     } mp2_sec_eco0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_sec_eco0_t f;
} mp2_sec_eco0_u;


/*
 * MP2_SEC_ECO1 struct
 */

#define MP2_SEC_ECO1_REG_SIZE          32
#define MP2_SEC_ECO1_DATA_SIZE         32

#define MP2_SEC_ECO1_DATA_SHIFT        0

#define MP2_SEC_ECO1_DATA_MASK         0xffffffff

#define MP2_SEC_ECO1_MASK \
     (MP2_SEC_ECO1_DATA_MASK)

#define MP2_SEC_ECO1_DEFAULT           0x00000000

#define MP2_SEC_ECO1_GET_DATA(mp2_sec_eco1) \
     ((mp2_sec_eco1 & MP2_SEC_ECO1_DATA_MASK) >> MP2_SEC_ECO1_DATA_SHIFT)

#define MP2_SEC_ECO1_SET_DATA(mp2_sec_eco1_reg, data) \
     mp2_sec_eco1_reg = (mp2_sec_eco1_reg & ~MP2_SEC_ECO1_DATA_MASK) | (data << MP2_SEC_ECO1_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_sec_eco1_t {
          unsigned int data                           : MP2_SEC_ECO1_DATA_SIZE;
     } mp2_sec_eco1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_sec_eco1_t {
          unsigned int data                           : MP2_SEC_ECO1_DATA_SIZE;
     } mp2_sec_eco1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_sec_eco1_t f;
} mp2_sec_eco1_u;


/*
 * MP2_SEC_ECO2 struct
 */

#define MP2_SEC_ECO2_REG_SIZE          32
#define MP2_SEC_ECO2_DATA_SIZE         32

#define MP2_SEC_ECO2_DATA_SHIFT        0

#define MP2_SEC_ECO2_DATA_MASK         0xffffffff

#define MP2_SEC_ECO2_MASK \
     (MP2_SEC_ECO2_DATA_MASK)

#define MP2_SEC_ECO2_DEFAULT           0x00000000

#define MP2_SEC_ECO2_GET_DATA(mp2_sec_eco2) \
     ((mp2_sec_eco2 & MP2_SEC_ECO2_DATA_MASK) >> MP2_SEC_ECO2_DATA_SHIFT)

#define MP2_SEC_ECO2_SET_DATA(mp2_sec_eco2_reg, data) \
     mp2_sec_eco2_reg = (mp2_sec_eco2_reg & ~MP2_SEC_ECO2_DATA_MASK) | (data << MP2_SEC_ECO2_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_sec_eco2_t {
          unsigned int data                           : MP2_SEC_ECO2_DATA_SIZE;
     } mp2_sec_eco2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_sec_eco2_t {
          unsigned int data                           : MP2_SEC_ECO2_DATA_SIZE;
     } mp2_sec_eco2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_sec_eco2_t f;
} mp2_sec_eco2_u;


/*
 * MP2_SEC_ECO3 struct
 */

#define MP2_SEC_ECO3_REG_SIZE          32
#define MP2_SEC_ECO3_DATA_SIZE         32

#define MP2_SEC_ECO3_DATA_SHIFT        0

#define MP2_SEC_ECO3_DATA_MASK         0xffffffff

#define MP2_SEC_ECO3_MASK \
     (MP2_SEC_ECO3_DATA_MASK)

#define MP2_SEC_ECO3_DEFAULT           0x00000000

#define MP2_SEC_ECO3_GET_DATA(mp2_sec_eco3) \
     ((mp2_sec_eco3 & MP2_SEC_ECO3_DATA_MASK) >> MP2_SEC_ECO3_DATA_SHIFT)

#define MP2_SEC_ECO3_SET_DATA(mp2_sec_eco3_reg, data) \
     mp2_sec_eco3_reg = (mp2_sec_eco3_reg & ~MP2_SEC_ECO3_DATA_MASK) | (data << MP2_SEC_ECO3_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_sec_eco3_t {
          unsigned int data                           : MP2_SEC_ECO3_DATA_SIZE;
     } mp2_sec_eco3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_sec_eco3_t {
          unsigned int data                           : MP2_SEC_ECO3_DATA_SIZE;
     } mp2_sec_eco3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_sec_eco3_t f;
} mp2_sec_eco3_u;


/*
 * MP2_I2C_REFCLK_CG_CTRL struct
 */

#define MP2_I2C_REFCLK_CG_CTRL_REG_SIZE 32
#define MP2_I2C_REFCLK_CG_CTRL_I2C_CG_REQ_SIZE 1

#define MP2_I2C_REFCLK_CG_CTRL_I2C_CG_REQ_SHIFT 0

#define MP2_I2C_REFCLK_CG_CTRL_I2C_CG_REQ_MASK 0x1

#define MP2_I2C_REFCLK_CG_CTRL_MASK \
     (MP2_I2C_REFCLK_CG_CTRL_I2C_CG_REQ_MASK)

#define MP2_I2C_REFCLK_CG_CTRL_DEFAULT 0x00000000

#define MP2_I2C_REFCLK_CG_CTRL_GET_I2C_CG_REQ(mp2_i2c_refclk_cg_ctrl) \
     ((mp2_i2c_refclk_cg_ctrl & MP2_I2C_REFCLK_CG_CTRL_I2C_CG_REQ_MASK) >> MP2_I2C_REFCLK_CG_CTRL_I2C_CG_REQ_SHIFT)

#define MP2_I2C_REFCLK_CG_CTRL_SET_I2C_CG_REQ(mp2_i2c_refclk_cg_ctrl_reg, i2c_cg_req) \
     mp2_i2c_refclk_cg_ctrl_reg = (mp2_i2c_refclk_cg_ctrl_reg & ~MP2_I2C_REFCLK_CG_CTRL_I2C_CG_REQ_MASK) | (i2c_cg_req << MP2_I2C_REFCLK_CG_CTRL_I2C_CG_REQ_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_i2c_refclk_cg_ctrl_t {
          unsigned int i2c_cg_req                     : MP2_I2C_REFCLK_CG_CTRL_I2C_CG_REQ_SIZE;
          unsigned int                                : 31;
     } mp2_i2c_refclk_cg_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_i2c_refclk_cg_ctrl_t {
          unsigned int                                : 31;
          unsigned int i2c_cg_req                     : MP2_I2C_REFCLK_CG_CTRL_I2C_CG_REQ_SIZE;
     } mp2_i2c_refclk_cg_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_i2c_refclk_cg_ctrl_t f;
} mp2_i2c_refclk_cg_ctrl_u;


/*
 * S5_MISC_CTRL struct
 */

#define S5_MISC_CTRL_REG_SIZE          32
#define S5_MISC_CTRL_MP2_FCH_VDDCR_S5_wakeup_req_SIZE 1
#define S5_MISC_CTRL_S5_STATE_SIZE     1
#define S5_MISC_CTRL_SEL_MP2CLK_SIZE   1
#define S5_MISC_CTRL_SEL_SMNCLK_SIZE   1
#define S5_MISC_CTRL_S0_PWROK_SIZE     1
#define S5_MISC_CTRL_AEB_ISO_EN_SIZE   1
#define S5_MISC_CTRL_S5_ISO_EN_SIZE    1

#define S5_MISC_CTRL_MP2_FCH_VDDCR_S5_wakeup_req_SHIFT 0
#define S5_MISC_CTRL_S5_STATE_SHIFT    1
#define S5_MISC_CTRL_SEL_MP2CLK_SHIFT  2
#define S5_MISC_CTRL_SEL_SMNCLK_SHIFT  4
#define S5_MISC_CTRL_S0_PWROK_SHIFT    5
#define S5_MISC_CTRL_AEB_ISO_EN_SHIFT  6
#define S5_MISC_CTRL_S5_ISO_EN_SHIFT   7

#define S5_MISC_CTRL_MP2_FCH_VDDCR_S5_wakeup_req_MASK 0x1
#define S5_MISC_CTRL_S5_STATE_MASK     0x2
#define S5_MISC_CTRL_SEL_MP2CLK_MASK   0x4
#define S5_MISC_CTRL_SEL_SMNCLK_MASK   0x10
#define S5_MISC_CTRL_S0_PWROK_MASK     0x20
#define S5_MISC_CTRL_AEB_ISO_EN_MASK   0x40
#define S5_MISC_CTRL_S5_ISO_EN_MASK    0x80

#define S5_MISC_CTRL_MASK \
     (S5_MISC_CTRL_MP2_FCH_VDDCR_S5_wakeup_req_MASK | \
      S5_MISC_CTRL_S5_STATE_MASK | \
      S5_MISC_CTRL_SEL_MP2CLK_MASK | \
      S5_MISC_CTRL_SEL_SMNCLK_MASK | \
      S5_MISC_CTRL_S0_PWROK_MASK | \
      S5_MISC_CTRL_AEB_ISO_EN_MASK | \
      S5_MISC_CTRL_S5_ISO_EN_MASK)

#define S5_MISC_CTRL_DEFAULT           0x00000000

#define S5_MISC_CTRL_GET_MP2_FCH_VDDCR_S5_wakeup_req(s5_misc_ctrl) \
     ((s5_misc_ctrl & S5_MISC_CTRL_MP2_FCH_VDDCR_S5_wakeup_req_MASK) >> S5_MISC_CTRL_MP2_FCH_VDDCR_S5_wakeup_req_SHIFT)
#define S5_MISC_CTRL_GET_S5_STATE(s5_misc_ctrl) \
     ((s5_misc_ctrl & S5_MISC_CTRL_S5_STATE_MASK) >> S5_MISC_CTRL_S5_STATE_SHIFT)
#define S5_MISC_CTRL_GET_SEL_MP2CLK(s5_misc_ctrl) \
     ((s5_misc_ctrl & S5_MISC_CTRL_SEL_MP2CLK_MASK) >> S5_MISC_CTRL_SEL_MP2CLK_SHIFT)
#define S5_MISC_CTRL_GET_SEL_SMNCLK(s5_misc_ctrl) \
     ((s5_misc_ctrl & S5_MISC_CTRL_SEL_SMNCLK_MASK) >> S5_MISC_CTRL_SEL_SMNCLK_SHIFT)
#define S5_MISC_CTRL_GET_S0_PWROK(s5_misc_ctrl) \
     ((s5_misc_ctrl & S5_MISC_CTRL_S0_PWROK_MASK) >> S5_MISC_CTRL_S0_PWROK_SHIFT)
#define S5_MISC_CTRL_GET_AEB_ISO_EN(s5_misc_ctrl) \
     ((s5_misc_ctrl & S5_MISC_CTRL_AEB_ISO_EN_MASK) >> S5_MISC_CTRL_AEB_ISO_EN_SHIFT)
#define S5_MISC_CTRL_GET_S5_ISO_EN(s5_misc_ctrl) \
     ((s5_misc_ctrl & S5_MISC_CTRL_S5_ISO_EN_MASK) >> S5_MISC_CTRL_S5_ISO_EN_SHIFT)

#define S5_MISC_CTRL_SET_MP2_FCH_VDDCR_S5_wakeup_req(s5_misc_ctrl_reg, mp2_fch_vddcr_s5_wakeup_req) \
     s5_misc_ctrl_reg = (s5_misc_ctrl_reg & ~S5_MISC_CTRL_MP2_FCH_VDDCR_S5_wakeup_req_MASK) | (mp2_fch_vddcr_s5_wakeup_req << S5_MISC_CTRL_MP2_FCH_VDDCR_S5_wakeup_req_SHIFT)
#define S5_MISC_CTRL_SET_S5_STATE(s5_misc_ctrl_reg, s5_state) \
     s5_misc_ctrl_reg = (s5_misc_ctrl_reg & ~S5_MISC_CTRL_S5_STATE_MASK) | (s5_state << S5_MISC_CTRL_S5_STATE_SHIFT)
#define S5_MISC_CTRL_SET_SEL_MP2CLK(s5_misc_ctrl_reg, sel_mp2clk) \
     s5_misc_ctrl_reg = (s5_misc_ctrl_reg & ~S5_MISC_CTRL_SEL_MP2CLK_MASK) | (sel_mp2clk << S5_MISC_CTRL_SEL_MP2CLK_SHIFT)
#define S5_MISC_CTRL_SET_SEL_SMNCLK(s5_misc_ctrl_reg, sel_smnclk) \
     s5_misc_ctrl_reg = (s5_misc_ctrl_reg & ~S5_MISC_CTRL_SEL_SMNCLK_MASK) | (sel_smnclk << S5_MISC_CTRL_SEL_SMNCLK_SHIFT)
#define S5_MISC_CTRL_SET_S0_PWROK(s5_misc_ctrl_reg, s0_pwrok) \
     s5_misc_ctrl_reg = (s5_misc_ctrl_reg & ~S5_MISC_CTRL_S0_PWROK_MASK) | (s0_pwrok << S5_MISC_CTRL_S0_PWROK_SHIFT)
#define S5_MISC_CTRL_SET_AEB_ISO_EN(s5_misc_ctrl_reg, aeb_iso_en) \
     s5_misc_ctrl_reg = (s5_misc_ctrl_reg & ~S5_MISC_CTRL_AEB_ISO_EN_MASK) | (aeb_iso_en << S5_MISC_CTRL_AEB_ISO_EN_SHIFT)
#define S5_MISC_CTRL_SET_S5_ISO_EN(s5_misc_ctrl_reg, s5_iso_en) \
     s5_misc_ctrl_reg = (s5_misc_ctrl_reg & ~S5_MISC_CTRL_S5_ISO_EN_MASK) | (s5_iso_en << S5_MISC_CTRL_S5_ISO_EN_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _s5_misc_ctrl_t {
          unsigned int mp2_fch_vddcr_s5_wakeup_req    : S5_MISC_CTRL_MP2_FCH_VDDCR_S5_wakeup_req_SIZE;
          unsigned int s5_state                       : S5_MISC_CTRL_S5_STATE_SIZE;
          unsigned int sel_mp2clk                     : S5_MISC_CTRL_SEL_MP2CLK_SIZE;
          unsigned int                                : 1;
          unsigned int sel_smnclk                     : S5_MISC_CTRL_SEL_SMNCLK_SIZE;
          unsigned int s0_pwrok                       : S5_MISC_CTRL_S0_PWROK_SIZE;
          unsigned int aeb_iso_en                     : S5_MISC_CTRL_AEB_ISO_EN_SIZE;
          unsigned int s5_iso_en                      : S5_MISC_CTRL_S5_ISO_EN_SIZE;
          unsigned int                                : 24;
     } s5_misc_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _s5_misc_ctrl_t {
          unsigned int                                : 24;
          unsigned int s5_iso_en                      : S5_MISC_CTRL_S5_ISO_EN_SIZE;
          unsigned int aeb_iso_en                     : S5_MISC_CTRL_AEB_ISO_EN_SIZE;
          unsigned int s0_pwrok                       : S5_MISC_CTRL_S0_PWROK_SIZE;
          unsigned int sel_smnclk                     : S5_MISC_CTRL_SEL_SMNCLK_SIZE;
          unsigned int                                : 1;
          unsigned int sel_mp2clk                     : S5_MISC_CTRL_SEL_MP2CLK_SIZE;
          unsigned int s5_state                       : S5_MISC_CTRL_S5_STATE_SIZE;
          unsigned int mp2_fch_vddcr_s5_wakeup_req    : S5_MISC_CTRL_MP2_FCH_VDDCR_S5_wakeup_req_SIZE;
     } s5_misc_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     s5_misc_ctrl_t f;
} s5_misc_ctrl_u;


/*
 * M4_INT_CTRL struct
 */

#define M4_INT_CTRL_REG_SIZE           32
#define M4_INT_CTRL_M4_NMI_EN_SIZE     1
#define M4_INT_CTRL_M4_MI_EN_SIZE      1
#define M4_INT_CTRL_M4_MI_SEL_SIZE     1

#define M4_INT_CTRL_M4_NMI_EN_SHIFT    0
#define M4_INT_CTRL_M4_MI_EN_SHIFT     1
#define M4_INT_CTRL_M4_MI_SEL_SHIFT    2

#define M4_INT_CTRL_M4_NMI_EN_MASK     0x1
#define M4_INT_CTRL_M4_MI_EN_MASK      0x2
#define M4_INT_CTRL_M4_MI_SEL_MASK     0x4

#define M4_INT_CTRL_MASK \
     (M4_INT_CTRL_M4_NMI_EN_MASK | \
      M4_INT_CTRL_M4_MI_EN_MASK | \
      M4_INT_CTRL_M4_MI_SEL_MASK)

#define M4_INT_CTRL_DEFAULT            0x00000002

#define M4_INT_CTRL_GET_M4_NMI_EN(m4_int_ctrl) \
     ((m4_int_ctrl & M4_INT_CTRL_M4_NMI_EN_MASK) >> M4_INT_CTRL_M4_NMI_EN_SHIFT)
#define M4_INT_CTRL_GET_M4_MI_EN(m4_int_ctrl) \
     ((m4_int_ctrl & M4_INT_CTRL_M4_MI_EN_MASK) >> M4_INT_CTRL_M4_MI_EN_SHIFT)
#define M4_INT_CTRL_GET_M4_MI_SEL(m4_int_ctrl) \
     ((m4_int_ctrl & M4_INT_CTRL_M4_MI_SEL_MASK) >> M4_INT_CTRL_M4_MI_SEL_SHIFT)

#define M4_INT_CTRL_SET_M4_NMI_EN(m4_int_ctrl_reg, m4_nmi_en) \
     m4_int_ctrl_reg = (m4_int_ctrl_reg & ~M4_INT_CTRL_M4_NMI_EN_MASK) | (m4_nmi_en << M4_INT_CTRL_M4_NMI_EN_SHIFT)
#define M4_INT_CTRL_SET_M4_MI_EN(m4_int_ctrl_reg, m4_mi_en) \
     m4_int_ctrl_reg = (m4_int_ctrl_reg & ~M4_INT_CTRL_M4_MI_EN_MASK) | (m4_mi_en << M4_INT_CTRL_M4_MI_EN_SHIFT)
#define M4_INT_CTRL_SET_M4_MI_SEL(m4_int_ctrl_reg, m4_mi_sel) \
     m4_int_ctrl_reg = (m4_int_ctrl_reg & ~M4_INT_CTRL_M4_MI_SEL_MASK) | (m4_mi_sel << M4_INT_CTRL_M4_MI_SEL_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _m4_int_ctrl_t {
          unsigned int m4_nmi_en                      : M4_INT_CTRL_M4_NMI_EN_SIZE;
          unsigned int m4_mi_en                       : M4_INT_CTRL_M4_MI_EN_SIZE;
          unsigned int m4_mi_sel                      : M4_INT_CTRL_M4_MI_SEL_SIZE;
          unsigned int                                : 29;
     } m4_int_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _m4_int_ctrl_t {
          unsigned int                                : 29;
          unsigned int m4_mi_sel                      : M4_INT_CTRL_M4_MI_SEL_SIZE;
          unsigned int m4_mi_en                       : M4_INT_CTRL_M4_MI_EN_SIZE;
          unsigned int m4_nmi_en                      : M4_INT_CTRL_M4_NMI_EN_SIZE;
     } m4_int_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     m4_int_ctrl_t f;
} m4_int_ctrl_u;


/*
 * MP2_FW_MISC_CTRL struct
 */

#define MP2_FW_MISC_CTRL_REG_SIZE      32
#define MP2_FW_MISC_CTRL_MP_FW_VALUE_SIZE 32

#define MP2_FW_MISC_CTRL_MP_FW_VALUE_SHIFT 0

#define MP2_FW_MISC_CTRL_MP_FW_VALUE_MASK 0xffffffff

#define MP2_FW_MISC_CTRL_MASK \
     (MP2_FW_MISC_CTRL_MP_FW_VALUE_MASK)

#define MP2_FW_MISC_CTRL_DEFAULT       0x00000000

#define MP2_FW_MISC_CTRL_GET_MP_FW_VALUE(mp2_fw_misc_ctrl) \
     ((mp2_fw_misc_ctrl & MP2_FW_MISC_CTRL_MP_FW_VALUE_MASK) >> MP2_FW_MISC_CTRL_MP_FW_VALUE_SHIFT)

#define MP2_FW_MISC_CTRL_SET_MP_FW_VALUE(mp2_fw_misc_ctrl_reg, mp_fw_value) \
     mp2_fw_misc_ctrl_reg = (mp2_fw_misc_ctrl_reg & ~MP2_FW_MISC_CTRL_MP_FW_VALUE_MASK) | (mp_fw_value << MP2_FW_MISC_CTRL_MP_FW_VALUE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_fw_misc_ctrl_t {
          unsigned int mp_fw_value                    : MP2_FW_MISC_CTRL_MP_FW_VALUE_SIZE;
     } mp2_fw_misc_ctrl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_fw_misc_ctrl_t {
          unsigned int mp_fw_value                    : MP2_FW_MISC_CTRL_MP_FW_VALUE_SIZE;
     } mp2_fw_misc_ctrl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_fw_misc_ctrl_t f;
} mp2_fw_misc_ctrl_u;


/*
 * MP2_AEB_STATUS_0 struct
 */

#define MP2_AEB_STATUS_0_REG_SIZE      32
#define MP2_AEB_STATUS_0_MP2_AEB_DBG_BUS_en_SIZE 1
#define MP2_AEB_STATUS_0_MP2_AEB_CPU_DBG_TDRs_en_SIZE 1
#define MP2_AEB_STATUS_0_MP2_AEB_JTAG_AXI_master_en_SIZE 1
#define MP2_AEB_STATUS_0_MP2_AEB_SCAN_DUMP_en_SIZE 1

#define MP2_AEB_STATUS_0_MP2_AEB_DBG_BUS_en_SHIFT 0
#define MP2_AEB_STATUS_0_MP2_AEB_CPU_DBG_TDRs_en_SHIFT 1
#define MP2_AEB_STATUS_0_MP2_AEB_JTAG_AXI_master_en_SHIFT 2
#define MP2_AEB_STATUS_0_MP2_AEB_SCAN_DUMP_en_SHIFT 3

#define MP2_AEB_STATUS_0_MP2_AEB_DBG_BUS_en_MASK 0x1
#define MP2_AEB_STATUS_0_MP2_AEB_CPU_DBG_TDRs_en_MASK 0x2
#define MP2_AEB_STATUS_0_MP2_AEB_JTAG_AXI_master_en_MASK 0x4
#define MP2_AEB_STATUS_0_MP2_AEB_SCAN_DUMP_en_MASK 0x8

#define MP2_AEB_STATUS_0_MASK \
     (MP2_AEB_STATUS_0_MP2_AEB_DBG_BUS_en_MASK | \
      MP2_AEB_STATUS_0_MP2_AEB_CPU_DBG_TDRs_en_MASK | \
      MP2_AEB_STATUS_0_MP2_AEB_JTAG_AXI_master_en_MASK | \
      MP2_AEB_STATUS_0_MP2_AEB_SCAN_DUMP_en_MASK)

#define MP2_AEB_STATUS_0_DEFAULT       0x00000000

#define MP2_AEB_STATUS_0_GET_MP2_AEB_DBG_BUS_en(mp2_aeb_status_0) \
     ((mp2_aeb_status_0 & MP2_AEB_STATUS_0_MP2_AEB_DBG_BUS_en_MASK) >> MP2_AEB_STATUS_0_MP2_AEB_DBG_BUS_en_SHIFT)
#define MP2_AEB_STATUS_0_GET_MP2_AEB_CPU_DBG_TDRs_en(mp2_aeb_status_0) \
     ((mp2_aeb_status_0 & MP2_AEB_STATUS_0_MP2_AEB_CPU_DBG_TDRs_en_MASK) >> MP2_AEB_STATUS_0_MP2_AEB_CPU_DBG_TDRs_en_SHIFT)
#define MP2_AEB_STATUS_0_GET_MP2_AEB_JTAG_AXI_master_en(mp2_aeb_status_0) \
     ((mp2_aeb_status_0 & MP2_AEB_STATUS_0_MP2_AEB_JTAG_AXI_master_en_MASK) >> MP2_AEB_STATUS_0_MP2_AEB_JTAG_AXI_master_en_SHIFT)
#define MP2_AEB_STATUS_0_GET_MP2_AEB_SCAN_DUMP_en(mp2_aeb_status_0) \
     ((mp2_aeb_status_0 & MP2_AEB_STATUS_0_MP2_AEB_SCAN_DUMP_en_MASK) >> MP2_AEB_STATUS_0_MP2_AEB_SCAN_DUMP_en_SHIFT)

#define MP2_AEB_STATUS_0_SET_MP2_AEB_DBG_BUS_en(mp2_aeb_status_0_reg, mp2_aeb_dbg_bus_en) \
     mp2_aeb_status_0_reg = (mp2_aeb_status_0_reg & ~MP2_AEB_STATUS_0_MP2_AEB_DBG_BUS_en_MASK) | (mp2_aeb_dbg_bus_en << MP2_AEB_STATUS_0_MP2_AEB_DBG_BUS_en_SHIFT)
#define MP2_AEB_STATUS_0_SET_MP2_AEB_CPU_DBG_TDRs_en(mp2_aeb_status_0_reg, mp2_aeb_cpu_dbg_tdrs_en) \
     mp2_aeb_status_0_reg = (mp2_aeb_status_0_reg & ~MP2_AEB_STATUS_0_MP2_AEB_CPU_DBG_TDRs_en_MASK) | (mp2_aeb_cpu_dbg_tdrs_en << MP2_AEB_STATUS_0_MP2_AEB_CPU_DBG_TDRs_en_SHIFT)
#define MP2_AEB_STATUS_0_SET_MP2_AEB_JTAG_AXI_master_en(mp2_aeb_status_0_reg, mp2_aeb_jtag_axi_master_en) \
     mp2_aeb_status_0_reg = (mp2_aeb_status_0_reg & ~MP2_AEB_STATUS_0_MP2_AEB_JTAG_AXI_master_en_MASK) | (mp2_aeb_jtag_axi_master_en << MP2_AEB_STATUS_0_MP2_AEB_JTAG_AXI_master_en_SHIFT)
#define MP2_AEB_STATUS_0_SET_MP2_AEB_SCAN_DUMP_en(mp2_aeb_status_0_reg, mp2_aeb_scan_dump_en) \
     mp2_aeb_status_0_reg = (mp2_aeb_status_0_reg & ~MP2_AEB_STATUS_0_MP2_AEB_SCAN_DUMP_en_MASK) | (mp2_aeb_scan_dump_en << MP2_AEB_STATUS_0_MP2_AEB_SCAN_DUMP_en_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_aeb_status_0_t {
          unsigned int mp2_aeb_dbg_bus_en             : MP2_AEB_STATUS_0_MP2_AEB_DBG_BUS_en_SIZE;
          unsigned int mp2_aeb_cpu_dbg_tdrs_en        : MP2_AEB_STATUS_0_MP2_AEB_CPU_DBG_TDRs_en_SIZE;
          unsigned int mp2_aeb_jtag_axi_master_en     : MP2_AEB_STATUS_0_MP2_AEB_JTAG_AXI_master_en_SIZE;
          unsigned int mp2_aeb_scan_dump_en           : MP2_AEB_STATUS_0_MP2_AEB_SCAN_DUMP_en_SIZE;
          unsigned int                                : 28;
     } mp2_aeb_status_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_aeb_status_0_t {
          unsigned int                                : 28;
          unsigned int mp2_aeb_scan_dump_en           : MP2_AEB_STATUS_0_MP2_AEB_SCAN_DUMP_en_SIZE;
          unsigned int mp2_aeb_jtag_axi_master_en     : MP2_AEB_STATUS_0_MP2_AEB_JTAG_AXI_master_en_SIZE;
          unsigned int mp2_aeb_cpu_dbg_tdrs_en        : MP2_AEB_STATUS_0_MP2_AEB_CPU_DBG_TDRs_en_SIZE;
          unsigned int mp2_aeb_dbg_bus_en             : MP2_AEB_STATUS_0_MP2_AEB_DBG_BUS_en_SIZE;
     } mp2_aeb_status_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_aeb_status_0_t f;
} mp2_aeb_status_0_u;


/*
 * MP2_FW_CHRONO_LO struct
 */

#define MP2_FW_CHRONO_LO_REG_SIZE      32
#define MP2_FW_CHRONO_LO_COUNT_SIZE    32

#define MP2_FW_CHRONO_LO_COUNT_SHIFT   0

#define MP2_FW_CHRONO_LO_COUNT_MASK    0xffffffff

#define MP2_FW_CHRONO_LO_MASK \
     (MP2_FW_CHRONO_LO_COUNT_MASK)

#define MP2_FW_CHRONO_LO_DEFAULT       0x00000000

#define MP2_FW_CHRONO_LO_GET_COUNT(mp2_fw_chrono_lo) \
     ((mp2_fw_chrono_lo & MP2_FW_CHRONO_LO_COUNT_MASK) >> MP2_FW_CHRONO_LO_COUNT_SHIFT)

#define MP2_FW_CHRONO_LO_SET_COUNT(mp2_fw_chrono_lo_reg, count) \
     mp2_fw_chrono_lo_reg = (mp2_fw_chrono_lo_reg & ~MP2_FW_CHRONO_LO_COUNT_MASK) | (count << MP2_FW_CHRONO_LO_COUNT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_fw_chrono_lo_t {
          unsigned int count                          : MP2_FW_CHRONO_LO_COUNT_SIZE;
     } mp2_fw_chrono_lo_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_fw_chrono_lo_t {
          unsigned int count                          : MP2_FW_CHRONO_LO_COUNT_SIZE;
     } mp2_fw_chrono_lo_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_fw_chrono_lo_t f;
} mp2_fw_chrono_lo_u;


/*
 * MP2_FW_CHRONO_HI struct
 */

#define MP2_FW_CHRONO_HI_REG_SIZE      32
#define MP2_FW_CHRONO_HI_COUNT_SIZE    32

#define MP2_FW_CHRONO_HI_COUNT_SHIFT   0

#define MP2_FW_CHRONO_HI_COUNT_MASK    0xffffffff

#define MP2_FW_CHRONO_HI_MASK \
     (MP2_FW_CHRONO_HI_COUNT_MASK)

#define MP2_FW_CHRONO_HI_DEFAULT       0x00000000

#define MP2_FW_CHRONO_HI_GET_COUNT(mp2_fw_chrono_hi) \
     ((mp2_fw_chrono_hi & MP2_FW_CHRONO_HI_COUNT_MASK) >> MP2_FW_CHRONO_HI_COUNT_SHIFT)

#define MP2_FW_CHRONO_HI_SET_COUNT(mp2_fw_chrono_hi_reg, count) \
     mp2_fw_chrono_hi_reg = (mp2_fw_chrono_hi_reg & ~MP2_FW_CHRONO_HI_COUNT_MASK) | (count << MP2_FW_CHRONO_HI_COUNT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_fw_chrono_hi_t {
          unsigned int count                          : MP2_FW_CHRONO_HI_COUNT_SIZE;
     } mp2_fw_chrono_hi_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_fw_chrono_hi_t {
          unsigned int count                          : MP2_FW_CHRONO_HI_COUNT_SIZE;
     } mp2_fw_chrono_hi_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_fw_chrono_hi_t f;
} mp2_fw_chrono_hi_u;


/*
 * MP2_PIC0_MASK_0 struct
 */

#define MP2_PIC0_MASK_0_REG_SIZE       32
#define MP2_PIC0_MASK_0_INTR_MASK_0_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_1_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_2_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_3_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_4_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_5_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_6_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_7_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_8_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_9_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_10_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_11_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_12_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_13_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_14_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_15_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_16_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_17_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_18_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_19_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_20_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_21_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_22_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_23_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_24_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_25_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_26_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_27_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_28_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_29_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_30_SIZE 1
#define MP2_PIC0_MASK_0_INTR_MASK_31_SIZE 1

#define MP2_PIC0_MASK_0_INTR_MASK_0_SHIFT 0
#define MP2_PIC0_MASK_0_INTR_MASK_1_SHIFT 1
#define MP2_PIC0_MASK_0_INTR_MASK_2_SHIFT 2
#define MP2_PIC0_MASK_0_INTR_MASK_3_SHIFT 3
#define MP2_PIC0_MASK_0_INTR_MASK_4_SHIFT 4
#define MP2_PIC0_MASK_0_INTR_MASK_5_SHIFT 5
#define MP2_PIC0_MASK_0_INTR_MASK_6_SHIFT 6
#define MP2_PIC0_MASK_0_INTR_MASK_7_SHIFT 7
#define MP2_PIC0_MASK_0_INTR_MASK_8_SHIFT 8
#define MP2_PIC0_MASK_0_INTR_MASK_9_SHIFT 9
#define MP2_PIC0_MASK_0_INTR_MASK_10_SHIFT 10
#define MP2_PIC0_MASK_0_INTR_MASK_11_SHIFT 11
#define MP2_PIC0_MASK_0_INTR_MASK_12_SHIFT 12
#define MP2_PIC0_MASK_0_INTR_MASK_13_SHIFT 13
#define MP2_PIC0_MASK_0_INTR_MASK_14_SHIFT 14
#define MP2_PIC0_MASK_0_INTR_MASK_15_SHIFT 15
#define MP2_PIC0_MASK_0_INTR_MASK_16_SHIFT 16
#define MP2_PIC0_MASK_0_INTR_MASK_17_SHIFT 17
#define MP2_PIC0_MASK_0_INTR_MASK_18_SHIFT 18
#define MP2_PIC0_MASK_0_INTR_MASK_19_SHIFT 19
#define MP2_PIC0_MASK_0_INTR_MASK_20_SHIFT 20
#define MP2_PIC0_MASK_0_INTR_MASK_21_SHIFT 21
#define MP2_PIC0_MASK_0_INTR_MASK_22_SHIFT 22
#define MP2_PIC0_MASK_0_INTR_MASK_23_SHIFT 23
#define MP2_PIC0_MASK_0_INTR_MASK_24_SHIFT 24
#define MP2_PIC0_MASK_0_INTR_MASK_25_SHIFT 25
#define MP2_PIC0_MASK_0_INTR_MASK_26_SHIFT 26
#define MP2_PIC0_MASK_0_INTR_MASK_27_SHIFT 27
#define MP2_PIC0_MASK_0_INTR_MASK_28_SHIFT 28
#define MP2_PIC0_MASK_0_INTR_MASK_29_SHIFT 29
#define MP2_PIC0_MASK_0_INTR_MASK_30_SHIFT 30
#define MP2_PIC0_MASK_0_INTR_MASK_31_SHIFT 31

#define MP2_PIC0_MASK_0_INTR_MASK_0_MASK 0x1
#define MP2_PIC0_MASK_0_INTR_MASK_1_MASK 0x2
#define MP2_PIC0_MASK_0_INTR_MASK_2_MASK 0x4
#define MP2_PIC0_MASK_0_INTR_MASK_3_MASK 0x8
#define MP2_PIC0_MASK_0_INTR_MASK_4_MASK 0x10
#define MP2_PIC0_MASK_0_INTR_MASK_5_MASK 0x20
#define MP2_PIC0_MASK_0_INTR_MASK_6_MASK 0x40
#define MP2_PIC0_MASK_0_INTR_MASK_7_MASK 0x80
#define MP2_PIC0_MASK_0_INTR_MASK_8_MASK 0x100
#define MP2_PIC0_MASK_0_INTR_MASK_9_MASK 0x200
#define MP2_PIC0_MASK_0_INTR_MASK_10_MASK 0x400
#define MP2_PIC0_MASK_0_INTR_MASK_11_MASK 0x800
#define MP2_PIC0_MASK_0_INTR_MASK_12_MASK 0x1000
#define MP2_PIC0_MASK_0_INTR_MASK_13_MASK 0x2000
#define MP2_PIC0_MASK_0_INTR_MASK_14_MASK 0x4000
#define MP2_PIC0_MASK_0_INTR_MASK_15_MASK 0x8000
#define MP2_PIC0_MASK_0_INTR_MASK_16_MASK 0x10000
#define MP2_PIC0_MASK_0_INTR_MASK_17_MASK 0x20000
#define MP2_PIC0_MASK_0_INTR_MASK_18_MASK 0x40000
#define MP2_PIC0_MASK_0_INTR_MASK_19_MASK 0x80000
#define MP2_PIC0_MASK_0_INTR_MASK_20_MASK 0x100000
#define MP2_PIC0_MASK_0_INTR_MASK_21_MASK 0x200000
#define MP2_PIC0_MASK_0_INTR_MASK_22_MASK 0x400000
#define MP2_PIC0_MASK_0_INTR_MASK_23_MASK 0x800000
#define MP2_PIC0_MASK_0_INTR_MASK_24_MASK 0x1000000
#define MP2_PIC0_MASK_0_INTR_MASK_25_MASK 0x2000000
#define MP2_PIC0_MASK_0_INTR_MASK_26_MASK 0x4000000
#define MP2_PIC0_MASK_0_INTR_MASK_27_MASK 0x8000000
#define MP2_PIC0_MASK_0_INTR_MASK_28_MASK 0x10000000
#define MP2_PIC0_MASK_0_INTR_MASK_29_MASK 0x20000000
#define MP2_PIC0_MASK_0_INTR_MASK_30_MASK 0x40000000
#define MP2_PIC0_MASK_0_INTR_MASK_31_MASK 0x80000000

#define MP2_PIC0_MASK_0_MASK \
     (MP2_PIC0_MASK_0_INTR_MASK_0_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_1_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_2_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_3_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_4_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_5_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_6_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_7_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_8_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_9_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_10_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_11_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_12_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_13_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_14_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_15_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_16_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_17_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_18_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_19_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_20_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_21_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_22_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_23_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_24_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_25_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_26_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_27_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_28_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_29_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_30_MASK | \
      MP2_PIC0_MASK_0_INTR_MASK_31_MASK)

#define MP2_PIC0_MASK_0_DEFAULT        0x00000000

#define MP2_PIC0_MASK_0_GET_INTR_MASK_0(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_0_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_0_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_1(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_1_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_1_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_2(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_2_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_2_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_3(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_3_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_3_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_4(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_4_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_4_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_5(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_5_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_5_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_6(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_6_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_6_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_7(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_7_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_7_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_8(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_8_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_8_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_9(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_9_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_9_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_10(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_10_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_10_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_11(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_11_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_11_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_12(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_12_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_12_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_13(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_13_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_13_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_14(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_14_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_14_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_15(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_15_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_15_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_16(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_16_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_16_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_17(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_17_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_17_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_18(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_18_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_18_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_19(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_19_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_19_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_20(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_20_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_20_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_21(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_21_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_21_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_22(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_22_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_22_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_23(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_23_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_23_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_24(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_24_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_24_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_25(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_25_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_25_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_26(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_26_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_26_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_27(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_27_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_27_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_28(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_28_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_28_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_29(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_29_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_29_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_30(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_30_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_30_SHIFT)
#define MP2_PIC0_MASK_0_GET_INTR_MASK_31(mp2_pic0_mask_0) \
     ((mp2_pic0_mask_0 & MP2_PIC0_MASK_0_INTR_MASK_31_MASK) >> MP2_PIC0_MASK_0_INTR_MASK_31_SHIFT)

#define MP2_PIC0_MASK_0_SET_INTR_MASK_0(mp2_pic0_mask_0_reg, intr_mask_0) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_0_MASK) | (intr_mask_0 << MP2_PIC0_MASK_0_INTR_MASK_0_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_1(mp2_pic0_mask_0_reg, intr_mask_1) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_1_MASK) | (intr_mask_1 << MP2_PIC0_MASK_0_INTR_MASK_1_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_2(mp2_pic0_mask_0_reg, intr_mask_2) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_2_MASK) | (intr_mask_2 << MP2_PIC0_MASK_0_INTR_MASK_2_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_3(mp2_pic0_mask_0_reg, intr_mask_3) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_3_MASK) | (intr_mask_3 << MP2_PIC0_MASK_0_INTR_MASK_3_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_4(mp2_pic0_mask_0_reg, intr_mask_4) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_4_MASK) | (intr_mask_4 << MP2_PIC0_MASK_0_INTR_MASK_4_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_5(mp2_pic0_mask_0_reg, intr_mask_5) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_5_MASK) | (intr_mask_5 << MP2_PIC0_MASK_0_INTR_MASK_5_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_6(mp2_pic0_mask_0_reg, intr_mask_6) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_6_MASK) | (intr_mask_6 << MP2_PIC0_MASK_0_INTR_MASK_6_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_7(mp2_pic0_mask_0_reg, intr_mask_7) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_7_MASK) | (intr_mask_7 << MP2_PIC0_MASK_0_INTR_MASK_7_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_8(mp2_pic0_mask_0_reg, intr_mask_8) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_8_MASK) | (intr_mask_8 << MP2_PIC0_MASK_0_INTR_MASK_8_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_9(mp2_pic0_mask_0_reg, intr_mask_9) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_9_MASK) | (intr_mask_9 << MP2_PIC0_MASK_0_INTR_MASK_9_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_10(mp2_pic0_mask_0_reg, intr_mask_10) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_10_MASK) | (intr_mask_10 << MP2_PIC0_MASK_0_INTR_MASK_10_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_11(mp2_pic0_mask_0_reg, intr_mask_11) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_11_MASK) | (intr_mask_11 << MP2_PIC0_MASK_0_INTR_MASK_11_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_12(mp2_pic0_mask_0_reg, intr_mask_12) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_12_MASK) | (intr_mask_12 << MP2_PIC0_MASK_0_INTR_MASK_12_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_13(mp2_pic0_mask_0_reg, intr_mask_13) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_13_MASK) | (intr_mask_13 << MP2_PIC0_MASK_0_INTR_MASK_13_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_14(mp2_pic0_mask_0_reg, intr_mask_14) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_14_MASK) | (intr_mask_14 << MP2_PIC0_MASK_0_INTR_MASK_14_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_15(mp2_pic0_mask_0_reg, intr_mask_15) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_15_MASK) | (intr_mask_15 << MP2_PIC0_MASK_0_INTR_MASK_15_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_16(mp2_pic0_mask_0_reg, intr_mask_16) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_16_MASK) | (intr_mask_16 << MP2_PIC0_MASK_0_INTR_MASK_16_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_17(mp2_pic0_mask_0_reg, intr_mask_17) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_17_MASK) | (intr_mask_17 << MP2_PIC0_MASK_0_INTR_MASK_17_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_18(mp2_pic0_mask_0_reg, intr_mask_18) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_18_MASK) | (intr_mask_18 << MP2_PIC0_MASK_0_INTR_MASK_18_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_19(mp2_pic0_mask_0_reg, intr_mask_19) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_19_MASK) | (intr_mask_19 << MP2_PIC0_MASK_0_INTR_MASK_19_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_20(mp2_pic0_mask_0_reg, intr_mask_20) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_20_MASK) | (intr_mask_20 << MP2_PIC0_MASK_0_INTR_MASK_20_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_21(mp2_pic0_mask_0_reg, intr_mask_21) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_21_MASK) | (intr_mask_21 << MP2_PIC0_MASK_0_INTR_MASK_21_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_22(mp2_pic0_mask_0_reg, intr_mask_22) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_22_MASK) | (intr_mask_22 << MP2_PIC0_MASK_0_INTR_MASK_22_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_23(mp2_pic0_mask_0_reg, intr_mask_23) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_23_MASK) | (intr_mask_23 << MP2_PIC0_MASK_0_INTR_MASK_23_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_24(mp2_pic0_mask_0_reg, intr_mask_24) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_24_MASK) | (intr_mask_24 << MP2_PIC0_MASK_0_INTR_MASK_24_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_25(mp2_pic0_mask_0_reg, intr_mask_25) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_25_MASK) | (intr_mask_25 << MP2_PIC0_MASK_0_INTR_MASK_25_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_26(mp2_pic0_mask_0_reg, intr_mask_26) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_26_MASK) | (intr_mask_26 << MP2_PIC0_MASK_0_INTR_MASK_26_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_27(mp2_pic0_mask_0_reg, intr_mask_27) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_27_MASK) | (intr_mask_27 << MP2_PIC0_MASK_0_INTR_MASK_27_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_28(mp2_pic0_mask_0_reg, intr_mask_28) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_28_MASK) | (intr_mask_28 << MP2_PIC0_MASK_0_INTR_MASK_28_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_29(mp2_pic0_mask_0_reg, intr_mask_29) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_29_MASK) | (intr_mask_29 << MP2_PIC0_MASK_0_INTR_MASK_29_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_30(mp2_pic0_mask_0_reg, intr_mask_30) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_30_MASK) | (intr_mask_30 << MP2_PIC0_MASK_0_INTR_MASK_30_SHIFT)
#define MP2_PIC0_MASK_0_SET_INTR_MASK_31(mp2_pic0_mask_0_reg, intr_mask_31) \
     mp2_pic0_mask_0_reg = (mp2_pic0_mask_0_reg & ~MP2_PIC0_MASK_0_INTR_MASK_31_MASK) | (intr_mask_31 << MP2_PIC0_MASK_0_INTR_MASK_31_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_mask_0_t {
          unsigned int intr_mask_0                    : MP2_PIC0_MASK_0_INTR_MASK_0_SIZE;
          unsigned int intr_mask_1                    : MP2_PIC0_MASK_0_INTR_MASK_1_SIZE;
          unsigned int intr_mask_2                    : MP2_PIC0_MASK_0_INTR_MASK_2_SIZE;
          unsigned int intr_mask_3                    : MP2_PIC0_MASK_0_INTR_MASK_3_SIZE;
          unsigned int intr_mask_4                    : MP2_PIC0_MASK_0_INTR_MASK_4_SIZE;
          unsigned int intr_mask_5                    : MP2_PIC0_MASK_0_INTR_MASK_5_SIZE;
          unsigned int intr_mask_6                    : MP2_PIC0_MASK_0_INTR_MASK_6_SIZE;
          unsigned int intr_mask_7                    : MP2_PIC0_MASK_0_INTR_MASK_7_SIZE;
          unsigned int intr_mask_8                    : MP2_PIC0_MASK_0_INTR_MASK_8_SIZE;
          unsigned int intr_mask_9                    : MP2_PIC0_MASK_0_INTR_MASK_9_SIZE;
          unsigned int intr_mask_10                   : MP2_PIC0_MASK_0_INTR_MASK_10_SIZE;
          unsigned int intr_mask_11                   : MP2_PIC0_MASK_0_INTR_MASK_11_SIZE;
          unsigned int intr_mask_12                   : MP2_PIC0_MASK_0_INTR_MASK_12_SIZE;
          unsigned int intr_mask_13                   : MP2_PIC0_MASK_0_INTR_MASK_13_SIZE;
          unsigned int intr_mask_14                   : MP2_PIC0_MASK_0_INTR_MASK_14_SIZE;
          unsigned int intr_mask_15                   : MP2_PIC0_MASK_0_INTR_MASK_15_SIZE;
          unsigned int intr_mask_16                   : MP2_PIC0_MASK_0_INTR_MASK_16_SIZE;
          unsigned int intr_mask_17                   : MP2_PIC0_MASK_0_INTR_MASK_17_SIZE;
          unsigned int intr_mask_18                   : MP2_PIC0_MASK_0_INTR_MASK_18_SIZE;
          unsigned int intr_mask_19                   : MP2_PIC0_MASK_0_INTR_MASK_19_SIZE;
          unsigned int intr_mask_20                   : MP2_PIC0_MASK_0_INTR_MASK_20_SIZE;
          unsigned int intr_mask_21                   : MP2_PIC0_MASK_0_INTR_MASK_21_SIZE;
          unsigned int intr_mask_22                   : MP2_PIC0_MASK_0_INTR_MASK_22_SIZE;
          unsigned int intr_mask_23                   : MP2_PIC0_MASK_0_INTR_MASK_23_SIZE;
          unsigned int intr_mask_24                   : MP2_PIC0_MASK_0_INTR_MASK_24_SIZE;
          unsigned int intr_mask_25                   : MP2_PIC0_MASK_0_INTR_MASK_25_SIZE;
          unsigned int intr_mask_26                   : MP2_PIC0_MASK_0_INTR_MASK_26_SIZE;
          unsigned int intr_mask_27                   : MP2_PIC0_MASK_0_INTR_MASK_27_SIZE;
          unsigned int intr_mask_28                   : MP2_PIC0_MASK_0_INTR_MASK_28_SIZE;
          unsigned int intr_mask_29                   : MP2_PIC0_MASK_0_INTR_MASK_29_SIZE;
          unsigned int intr_mask_30                   : MP2_PIC0_MASK_0_INTR_MASK_30_SIZE;
          unsigned int intr_mask_31                   : MP2_PIC0_MASK_0_INTR_MASK_31_SIZE;
     } mp2_pic0_mask_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_mask_0_t {
          unsigned int intr_mask_31                   : MP2_PIC0_MASK_0_INTR_MASK_31_SIZE;
          unsigned int intr_mask_30                   : MP2_PIC0_MASK_0_INTR_MASK_30_SIZE;
          unsigned int intr_mask_29                   : MP2_PIC0_MASK_0_INTR_MASK_29_SIZE;
          unsigned int intr_mask_28                   : MP2_PIC0_MASK_0_INTR_MASK_28_SIZE;
          unsigned int intr_mask_27                   : MP2_PIC0_MASK_0_INTR_MASK_27_SIZE;
          unsigned int intr_mask_26                   : MP2_PIC0_MASK_0_INTR_MASK_26_SIZE;
          unsigned int intr_mask_25                   : MP2_PIC0_MASK_0_INTR_MASK_25_SIZE;
          unsigned int intr_mask_24                   : MP2_PIC0_MASK_0_INTR_MASK_24_SIZE;
          unsigned int intr_mask_23                   : MP2_PIC0_MASK_0_INTR_MASK_23_SIZE;
          unsigned int intr_mask_22                   : MP2_PIC0_MASK_0_INTR_MASK_22_SIZE;
          unsigned int intr_mask_21                   : MP2_PIC0_MASK_0_INTR_MASK_21_SIZE;
          unsigned int intr_mask_20                   : MP2_PIC0_MASK_0_INTR_MASK_20_SIZE;
          unsigned int intr_mask_19                   : MP2_PIC0_MASK_0_INTR_MASK_19_SIZE;
          unsigned int intr_mask_18                   : MP2_PIC0_MASK_0_INTR_MASK_18_SIZE;
          unsigned int intr_mask_17                   : MP2_PIC0_MASK_0_INTR_MASK_17_SIZE;
          unsigned int intr_mask_16                   : MP2_PIC0_MASK_0_INTR_MASK_16_SIZE;
          unsigned int intr_mask_15                   : MP2_PIC0_MASK_0_INTR_MASK_15_SIZE;
          unsigned int intr_mask_14                   : MP2_PIC0_MASK_0_INTR_MASK_14_SIZE;
          unsigned int intr_mask_13                   : MP2_PIC0_MASK_0_INTR_MASK_13_SIZE;
          unsigned int intr_mask_12                   : MP2_PIC0_MASK_0_INTR_MASK_12_SIZE;
          unsigned int intr_mask_11                   : MP2_PIC0_MASK_0_INTR_MASK_11_SIZE;
          unsigned int intr_mask_10                   : MP2_PIC0_MASK_0_INTR_MASK_10_SIZE;
          unsigned int intr_mask_9                    : MP2_PIC0_MASK_0_INTR_MASK_9_SIZE;
          unsigned int intr_mask_8                    : MP2_PIC0_MASK_0_INTR_MASK_8_SIZE;
          unsigned int intr_mask_7                    : MP2_PIC0_MASK_0_INTR_MASK_7_SIZE;
          unsigned int intr_mask_6                    : MP2_PIC0_MASK_0_INTR_MASK_6_SIZE;
          unsigned int intr_mask_5                    : MP2_PIC0_MASK_0_INTR_MASK_5_SIZE;
          unsigned int intr_mask_4                    : MP2_PIC0_MASK_0_INTR_MASK_4_SIZE;
          unsigned int intr_mask_3                    : MP2_PIC0_MASK_0_INTR_MASK_3_SIZE;
          unsigned int intr_mask_2                    : MP2_PIC0_MASK_0_INTR_MASK_2_SIZE;
          unsigned int intr_mask_1                    : MP2_PIC0_MASK_0_INTR_MASK_1_SIZE;
          unsigned int intr_mask_0                    : MP2_PIC0_MASK_0_INTR_MASK_0_SIZE;
     } mp2_pic0_mask_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_mask_0_t f;
} mp2_pic0_mask_0_u;


/*
 * MP2_PIC0_MASK_1 struct
 */

#define MP2_PIC0_MASK_1_REG_SIZE       32
#define MP2_PIC0_MASK_1_INTR_MASK_0_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_1_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_2_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_3_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_4_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_5_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_6_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_7_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_8_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_9_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_10_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_11_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_12_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_13_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_14_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_15_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_16_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_17_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_18_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_19_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_20_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_21_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_22_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_23_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_24_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_25_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_26_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_27_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_28_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_29_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_30_SIZE 1
#define MP2_PIC0_MASK_1_INTR_MASK_31_SIZE 1

#define MP2_PIC0_MASK_1_INTR_MASK_0_SHIFT 0
#define MP2_PIC0_MASK_1_INTR_MASK_1_SHIFT 1
#define MP2_PIC0_MASK_1_INTR_MASK_2_SHIFT 2
#define MP2_PIC0_MASK_1_INTR_MASK_3_SHIFT 3
#define MP2_PIC0_MASK_1_INTR_MASK_4_SHIFT 4
#define MP2_PIC0_MASK_1_INTR_MASK_5_SHIFT 5
#define MP2_PIC0_MASK_1_INTR_MASK_6_SHIFT 6
#define MP2_PIC0_MASK_1_INTR_MASK_7_SHIFT 7
#define MP2_PIC0_MASK_1_INTR_MASK_8_SHIFT 8
#define MP2_PIC0_MASK_1_INTR_MASK_9_SHIFT 9
#define MP2_PIC0_MASK_1_INTR_MASK_10_SHIFT 10
#define MP2_PIC0_MASK_1_INTR_MASK_11_SHIFT 11
#define MP2_PIC0_MASK_1_INTR_MASK_12_SHIFT 12
#define MP2_PIC0_MASK_1_INTR_MASK_13_SHIFT 13
#define MP2_PIC0_MASK_1_INTR_MASK_14_SHIFT 14
#define MP2_PIC0_MASK_1_INTR_MASK_15_SHIFT 15
#define MP2_PIC0_MASK_1_INTR_MASK_16_SHIFT 16
#define MP2_PIC0_MASK_1_INTR_MASK_17_SHIFT 17
#define MP2_PIC0_MASK_1_INTR_MASK_18_SHIFT 18
#define MP2_PIC0_MASK_1_INTR_MASK_19_SHIFT 19
#define MP2_PIC0_MASK_1_INTR_MASK_20_SHIFT 20
#define MP2_PIC0_MASK_1_INTR_MASK_21_SHIFT 21
#define MP2_PIC0_MASK_1_INTR_MASK_22_SHIFT 22
#define MP2_PIC0_MASK_1_INTR_MASK_23_SHIFT 23
#define MP2_PIC0_MASK_1_INTR_MASK_24_SHIFT 24
#define MP2_PIC0_MASK_1_INTR_MASK_25_SHIFT 25
#define MP2_PIC0_MASK_1_INTR_MASK_26_SHIFT 26
#define MP2_PIC0_MASK_1_INTR_MASK_27_SHIFT 27
#define MP2_PIC0_MASK_1_INTR_MASK_28_SHIFT 28
#define MP2_PIC0_MASK_1_INTR_MASK_29_SHIFT 29
#define MP2_PIC0_MASK_1_INTR_MASK_30_SHIFT 30
#define MP2_PIC0_MASK_1_INTR_MASK_31_SHIFT 31

#define MP2_PIC0_MASK_1_INTR_MASK_0_MASK 0x1
#define MP2_PIC0_MASK_1_INTR_MASK_1_MASK 0x2
#define MP2_PIC0_MASK_1_INTR_MASK_2_MASK 0x4
#define MP2_PIC0_MASK_1_INTR_MASK_3_MASK 0x8
#define MP2_PIC0_MASK_1_INTR_MASK_4_MASK 0x10
#define MP2_PIC0_MASK_1_INTR_MASK_5_MASK 0x20
#define MP2_PIC0_MASK_1_INTR_MASK_6_MASK 0x40
#define MP2_PIC0_MASK_1_INTR_MASK_7_MASK 0x80
#define MP2_PIC0_MASK_1_INTR_MASK_8_MASK 0x100
#define MP2_PIC0_MASK_1_INTR_MASK_9_MASK 0x200
#define MP2_PIC0_MASK_1_INTR_MASK_10_MASK 0x400
#define MP2_PIC0_MASK_1_INTR_MASK_11_MASK 0x800
#define MP2_PIC0_MASK_1_INTR_MASK_12_MASK 0x1000
#define MP2_PIC0_MASK_1_INTR_MASK_13_MASK 0x2000
#define MP2_PIC0_MASK_1_INTR_MASK_14_MASK 0x4000
#define MP2_PIC0_MASK_1_INTR_MASK_15_MASK 0x8000
#define MP2_PIC0_MASK_1_INTR_MASK_16_MASK 0x10000
#define MP2_PIC0_MASK_1_INTR_MASK_17_MASK 0x20000
#define MP2_PIC0_MASK_1_INTR_MASK_18_MASK 0x40000
#define MP2_PIC0_MASK_1_INTR_MASK_19_MASK 0x80000
#define MP2_PIC0_MASK_1_INTR_MASK_20_MASK 0x100000
#define MP2_PIC0_MASK_1_INTR_MASK_21_MASK 0x200000
#define MP2_PIC0_MASK_1_INTR_MASK_22_MASK 0x400000
#define MP2_PIC0_MASK_1_INTR_MASK_23_MASK 0x800000
#define MP2_PIC0_MASK_1_INTR_MASK_24_MASK 0x1000000
#define MP2_PIC0_MASK_1_INTR_MASK_25_MASK 0x2000000
#define MP2_PIC0_MASK_1_INTR_MASK_26_MASK 0x4000000
#define MP2_PIC0_MASK_1_INTR_MASK_27_MASK 0x8000000
#define MP2_PIC0_MASK_1_INTR_MASK_28_MASK 0x10000000
#define MP2_PIC0_MASK_1_INTR_MASK_29_MASK 0x20000000
#define MP2_PIC0_MASK_1_INTR_MASK_30_MASK 0x40000000
#define MP2_PIC0_MASK_1_INTR_MASK_31_MASK 0x80000000

#define MP2_PIC0_MASK_1_MASK \
     (MP2_PIC0_MASK_1_INTR_MASK_0_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_1_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_2_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_3_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_4_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_5_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_6_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_7_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_8_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_9_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_10_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_11_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_12_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_13_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_14_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_15_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_16_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_17_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_18_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_19_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_20_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_21_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_22_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_23_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_24_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_25_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_26_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_27_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_28_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_29_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_30_MASK | \
      MP2_PIC0_MASK_1_INTR_MASK_31_MASK)

#define MP2_PIC0_MASK_1_DEFAULT        0x00000000

#define MP2_PIC0_MASK_1_GET_INTR_MASK_0(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_0_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_0_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_1(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_1_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_1_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_2(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_2_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_2_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_3(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_3_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_3_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_4(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_4_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_4_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_5(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_5_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_5_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_6(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_6_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_6_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_7(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_7_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_7_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_8(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_8_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_8_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_9(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_9_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_9_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_10(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_10_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_10_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_11(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_11_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_11_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_12(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_12_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_12_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_13(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_13_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_13_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_14(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_14_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_14_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_15(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_15_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_15_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_16(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_16_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_16_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_17(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_17_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_17_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_18(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_18_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_18_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_19(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_19_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_19_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_20(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_20_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_20_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_21(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_21_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_21_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_22(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_22_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_22_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_23(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_23_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_23_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_24(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_24_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_24_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_25(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_25_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_25_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_26(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_26_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_26_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_27(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_27_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_27_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_28(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_28_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_28_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_29(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_29_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_29_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_30(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_30_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_30_SHIFT)
#define MP2_PIC0_MASK_1_GET_INTR_MASK_31(mp2_pic0_mask_1) \
     ((mp2_pic0_mask_1 & MP2_PIC0_MASK_1_INTR_MASK_31_MASK) >> MP2_PIC0_MASK_1_INTR_MASK_31_SHIFT)

#define MP2_PIC0_MASK_1_SET_INTR_MASK_0(mp2_pic0_mask_1_reg, intr_mask_0) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_0_MASK) | (intr_mask_0 << MP2_PIC0_MASK_1_INTR_MASK_0_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_1(mp2_pic0_mask_1_reg, intr_mask_1) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_1_MASK) | (intr_mask_1 << MP2_PIC0_MASK_1_INTR_MASK_1_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_2(mp2_pic0_mask_1_reg, intr_mask_2) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_2_MASK) | (intr_mask_2 << MP2_PIC0_MASK_1_INTR_MASK_2_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_3(mp2_pic0_mask_1_reg, intr_mask_3) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_3_MASK) | (intr_mask_3 << MP2_PIC0_MASK_1_INTR_MASK_3_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_4(mp2_pic0_mask_1_reg, intr_mask_4) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_4_MASK) | (intr_mask_4 << MP2_PIC0_MASK_1_INTR_MASK_4_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_5(mp2_pic0_mask_1_reg, intr_mask_5) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_5_MASK) | (intr_mask_5 << MP2_PIC0_MASK_1_INTR_MASK_5_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_6(mp2_pic0_mask_1_reg, intr_mask_6) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_6_MASK) | (intr_mask_6 << MP2_PIC0_MASK_1_INTR_MASK_6_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_7(mp2_pic0_mask_1_reg, intr_mask_7) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_7_MASK) | (intr_mask_7 << MP2_PIC0_MASK_1_INTR_MASK_7_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_8(mp2_pic0_mask_1_reg, intr_mask_8) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_8_MASK) | (intr_mask_8 << MP2_PIC0_MASK_1_INTR_MASK_8_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_9(mp2_pic0_mask_1_reg, intr_mask_9) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_9_MASK) | (intr_mask_9 << MP2_PIC0_MASK_1_INTR_MASK_9_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_10(mp2_pic0_mask_1_reg, intr_mask_10) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_10_MASK) | (intr_mask_10 << MP2_PIC0_MASK_1_INTR_MASK_10_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_11(mp2_pic0_mask_1_reg, intr_mask_11) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_11_MASK) | (intr_mask_11 << MP2_PIC0_MASK_1_INTR_MASK_11_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_12(mp2_pic0_mask_1_reg, intr_mask_12) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_12_MASK) | (intr_mask_12 << MP2_PIC0_MASK_1_INTR_MASK_12_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_13(mp2_pic0_mask_1_reg, intr_mask_13) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_13_MASK) | (intr_mask_13 << MP2_PIC0_MASK_1_INTR_MASK_13_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_14(mp2_pic0_mask_1_reg, intr_mask_14) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_14_MASK) | (intr_mask_14 << MP2_PIC0_MASK_1_INTR_MASK_14_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_15(mp2_pic0_mask_1_reg, intr_mask_15) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_15_MASK) | (intr_mask_15 << MP2_PIC0_MASK_1_INTR_MASK_15_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_16(mp2_pic0_mask_1_reg, intr_mask_16) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_16_MASK) | (intr_mask_16 << MP2_PIC0_MASK_1_INTR_MASK_16_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_17(mp2_pic0_mask_1_reg, intr_mask_17) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_17_MASK) | (intr_mask_17 << MP2_PIC0_MASK_1_INTR_MASK_17_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_18(mp2_pic0_mask_1_reg, intr_mask_18) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_18_MASK) | (intr_mask_18 << MP2_PIC0_MASK_1_INTR_MASK_18_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_19(mp2_pic0_mask_1_reg, intr_mask_19) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_19_MASK) | (intr_mask_19 << MP2_PIC0_MASK_1_INTR_MASK_19_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_20(mp2_pic0_mask_1_reg, intr_mask_20) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_20_MASK) | (intr_mask_20 << MP2_PIC0_MASK_1_INTR_MASK_20_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_21(mp2_pic0_mask_1_reg, intr_mask_21) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_21_MASK) | (intr_mask_21 << MP2_PIC0_MASK_1_INTR_MASK_21_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_22(mp2_pic0_mask_1_reg, intr_mask_22) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_22_MASK) | (intr_mask_22 << MP2_PIC0_MASK_1_INTR_MASK_22_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_23(mp2_pic0_mask_1_reg, intr_mask_23) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_23_MASK) | (intr_mask_23 << MP2_PIC0_MASK_1_INTR_MASK_23_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_24(mp2_pic0_mask_1_reg, intr_mask_24) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_24_MASK) | (intr_mask_24 << MP2_PIC0_MASK_1_INTR_MASK_24_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_25(mp2_pic0_mask_1_reg, intr_mask_25) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_25_MASK) | (intr_mask_25 << MP2_PIC0_MASK_1_INTR_MASK_25_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_26(mp2_pic0_mask_1_reg, intr_mask_26) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_26_MASK) | (intr_mask_26 << MP2_PIC0_MASK_1_INTR_MASK_26_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_27(mp2_pic0_mask_1_reg, intr_mask_27) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_27_MASK) | (intr_mask_27 << MP2_PIC0_MASK_1_INTR_MASK_27_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_28(mp2_pic0_mask_1_reg, intr_mask_28) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_28_MASK) | (intr_mask_28 << MP2_PIC0_MASK_1_INTR_MASK_28_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_29(mp2_pic0_mask_1_reg, intr_mask_29) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_29_MASK) | (intr_mask_29 << MP2_PIC0_MASK_1_INTR_MASK_29_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_30(mp2_pic0_mask_1_reg, intr_mask_30) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_30_MASK) | (intr_mask_30 << MP2_PIC0_MASK_1_INTR_MASK_30_SHIFT)
#define MP2_PIC0_MASK_1_SET_INTR_MASK_31(mp2_pic0_mask_1_reg, intr_mask_31) \
     mp2_pic0_mask_1_reg = (mp2_pic0_mask_1_reg & ~MP2_PIC0_MASK_1_INTR_MASK_31_MASK) | (intr_mask_31 << MP2_PIC0_MASK_1_INTR_MASK_31_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_mask_1_t {
          unsigned int intr_mask_0                    : MP2_PIC0_MASK_1_INTR_MASK_0_SIZE;
          unsigned int intr_mask_1                    : MP2_PIC0_MASK_1_INTR_MASK_1_SIZE;
          unsigned int intr_mask_2                    : MP2_PIC0_MASK_1_INTR_MASK_2_SIZE;
          unsigned int intr_mask_3                    : MP2_PIC0_MASK_1_INTR_MASK_3_SIZE;
          unsigned int intr_mask_4                    : MP2_PIC0_MASK_1_INTR_MASK_4_SIZE;
          unsigned int intr_mask_5                    : MP2_PIC0_MASK_1_INTR_MASK_5_SIZE;
          unsigned int intr_mask_6                    : MP2_PIC0_MASK_1_INTR_MASK_6_SIZE;
          unsigned int intr_mask_7                    : MP2_PIC0_MASK_1_INTR_MASK_7_SIZE;
          unsigned int intr_mask_8                    : MP2_PIC0_MASK_1_INTR_MASK_8_SIZE;
          unsigned int intr_mask_9                    : MP2_PIC0_MASK_1_INTR_MASK_9_SIZE;
          unsigned int intr_mask_10                   : MP2_PIC0_MASK_1_INTR_MASK_10_SIZE;
          unsigned int intr_mask_11                   : MP2_PIC0_MASK_1_INTR_MASK_11_SIZE;
          unsigned int intr_mask_12                   : MP2_PIC0_MASK_1_INTR_MASK_12_SIZE;
          unsigned int intr_mask_13                   : MP2_PIC0_MASK_1_INTR_MASK_13_SIZE;
          unsigned int intr_mask_14                   : MP2_PIC0_MASK_1_INTR_MASK_14_SIZE;
          unsigned int intr_mask_15                   : MP2_PIC0_MASK_1_INTR_MASK_15_SIZE;
          unsigned int intr_mask_16                   : MP2_PIC0_MASK_1_INTR_MASK_16_SIZE;
          unsigned int intr_mask_17                   : MP2_PIC0_MASK_1_INTR_MASK_17_SIZE;
          unsigned int intr_mask_18                   : MP2_PIC0_MASK_1_INTR_MASK_18_SIZE;
          unsigned int intr_mask_19                   : MP2_PIC0_MASK_1_INTR_MASK_19_SIZE;
          unsigned int intr_mask_20                   : MP2_PIC0_MASK_1_INTR_MASK_20_SIZE;
          unsigned int intr_mask_21                   : MP2_PIC0_MASK_1_INTR_MASK_21_SIZE;
          unsigned int intr_mask_22                   : MP2_PIC0_MASK_1_INTR_MASK_22_SIZE;
          unsigned int intr_mask_23                   : MP2_PIC0_MASK_1_INTR_MASK_23_SIZE;
          unsigned int intr_mask_24                   : MP2_PIC0_MASK_1_INTR_MASK_24_SIZE;
          unsigned int intr_mask_25                   : MP2_PIC0_MASK_1_INTR_MASK_25_SIZE;
          unsigned int intr_mask_26                   : MP2_PIC0_MASK_1_INTR_MASK_26_SIZE;
          unsigned int intr_mask_27                   : MP2_PIC0_MASK_1_INTR_MASK_27_SIZE;
          unsigned int intr_mask_28                   : MP2_PIC0_MASK_1_INTR_MASK_28_SIZE;
          unsigned int intr_mask_29                   : MP2_PIC0_MASK_1_INTR_MASK_29_SIZE;
          unsigned int intr_mask_30                   : MP2_PIC0_MASK_1_INTR_MASK_30_SIZE;
          unsigned int intr_mask_31                   : MP2_PIC0_MASK_1_INTR_MASK_31_SIZE;
     } mp2_pic0_mask_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_mask_1_t {
          unsigned int intr_mask_31                   : MP2_PIC0_MASK_1_INTR_MASK_31_SIZE;
          unsigned int intr_mask_30                   : MP2_PIC0_MASK_1_INTR_MASK_30_SIZE;
          unsigned int intr_mask_29                   : MP2_PIC0_MASK_1_INTR_MASK_29_SIZE;
          unsigned int intr_mask_28                   : MP2_PIC0_MASK_1_INTR_MASK_28_SIZE;
          unsigned int intr_mask_27                   : MP2_PIC0_MASK_1_INTR_MASK_27_SIZE;
          unsigned int intr_mask_26                   : MP2_PIC0_MASK_1_INTR_MASK_26_SIZE;
          unsigned int intr_mask_25                   : MP2_PIC0_MASK_1_INTR_MASK_25_SIZE;
          unsigned int intr_mask_24                   : MP2_PIC0_MASK_1_INTR_MASK_24_SIZE;
          unsigned int intr_mask_23                   : MP2_PIC0_MASK_1_INTR_MASK_23_SIZE;
          unsigned int intr_mask_22                   : MP2_PIC0_MASK_1_INTR_MASK_22_SIZE;
          unsigned int intr_mask_21                   : MP2_PIC0_MASK_1_INTR_MASK_21_SIZE;
          unsigned int intr_mask_20                   : MP2_PIC0_MASK_1_INTR_MASK_20_SIZE;
          unsigned int intr_mask_19                   : MP2_PIC0_MASK_1_INTR_MASK_19_SIZE;
          unsigned int intr_mask_18                   : MP2_PIC0_MASK_1_INTR_MASK_18_SIZE;
          unsigned int intr_mask_17                   : MP2_PIC0_MASK_1_INTR_MASK_17_SIZE;
          unsigned int intr_mask_16                   : MP2_PIC0_MASK_1_INTR_MASK_16_SIZE;
          unsigned int intr_mask_15                   : MP2_PIC0_MASK_1_INTR_MASK_15_SIZE;
          unsigned int intr_mask_14                   : MP2_PIC0_MASK_1_INTR_MASK_14_SIZE;
          unsigned int intr_mask_13                   : MP2_PIC0_MASK_1_INTR_MASK_13_SIZE;
          unsigned int intr_mask_12                   : MP2_PIC0_MASK_1_INTR_MASK_12_SIZE;
          unsigned int intr_mask_11                   : MP2_PIC0_MASK_1_INTR_MASK_11_SIZE;
          unsigned int intr_mask_10                   : MP2_PIC0_MASK_1_INTR_MASK_10_SIZE;
          unsigned int intr_mask_9                    : MP2_PIC0_MASK_1_INTR_MASK_9_SIZE;
          unsigned int intr_mask_8                    : MP2_PIC0_MASK_1_INTR_MASK_8_SIZE;
          unsigned int intr_mask_7                    : MP2_PIC0_MASK_1_INTR_MASK_7_SIZE;
          unsigned int intr_mask_6                    : MP2_PIC0_MASK_1_INTR_MASK_6_SIZE;
          unsigned int intr_mask_5                    : MP2_PIC0_MASK_1_INTR_MASK_5_SIZE;
          unsigned int intr_mask_4                    : MP2_PIC0_MASK_1_INTR_MASK_4_SIZE;
          unsigned int intr_mask_3                    : MP2_PIC0_MASK_1_INTR_MASK_3_SIZE;
          unsigned int intr_mask_2                    : MP2_PIC0_MASK_1_INTR_MASK_2_SIZE;
          unsigned int intr_mask_1                    : MP2_PIC0_MASK_1_INTR_MASK_1_SIZE;
          unsigned int intr_mask_0                    : MP2_PIC0_MASK_1_INTR_MASK_0_SIZE;
     } mp2_pic0_mask_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_mask_1_t f;
} mp2_pic0_mask_1_u;


/*
 * MP2_PIC0_MASK_2 struct
 */

#define MP2_PIC0_MASK_2_REG_SIZE       32
#define MP2_PIC0_MASK_2_INTR_MASK_0_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_1_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_2_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_3_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_4_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_5_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_6_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_7_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_8_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_9_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_10_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_11_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_12_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_13_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_14_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_15_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_16_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_17_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_18_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_19_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_20_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_21_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_22_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_23_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_24_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_25_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_26_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_27_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_28_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_29_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_30_SIZE 1
#define MP2_PIC0_MASK_2_INTR_MASK_31_SIZE 1

#define MP2_PIC0_MASK_2_INTR_MASK_0_SHIFT 0
#define MP2_PIC0_MASK_2_INTR_MASK_1_SHIFT 1
#define MP2_PIC0_MASK_2_INTR_MASK_2_SHIFT 2
#define MP2_PIC0_MASK_2_INTR_MASK_3_SHIFT 3
#define MP2_PIC0_MASK_2_INTR_MASK_4_SHIFT 4
#define MP2_PIC0_MASK_2_INTR_MASK_5_SHIFT 5
#define MP2_PIC0_MASK_2_INTR_MASK_6_SHIFT 6
#define MP2_PIC0_MASK_2_INTR_MASK_7_SHIFT 7
#define MP2_PIC0_MASK_2_INTR_MASK_8_SHIFT 8
#define MP2_PIC0_MASK_2_INTR_MASK_9_SHIFT 9
#define MP2_PIC0_MASK_2_INTR_MASK_10_SHIFT 10
#define MP2_PIC0_MASK_2_INTR_MASK_11_SHIFT 11
#define MP2_PIC0_MASK_2_INTR_MASK_12_SHIFT 12
#define MP2_PIC0_MASK_2_INTR_MASK_13_SHIFT 13
#define MP2_PIC0_MASK_2_INTR_MASK_14_SHIFT 14
#define MP2_PIC0_MASK_2_INTR_MASK_15_SHIFT 15
#define MP2_PIC0_MASK_2_INTR_MASK_16_SHIFT 16
#define MP2_PIC0_MASK_2_INTR_MASK_17_SHIFT 17
#define MP2_PIC0_MASK_2_INTR_MASK_18_SHIFT 18
#define MP2_PIC0_MASK_2_INTR_MASK_19_SHIFT 19
#define MP2_PIC0_MASK_2_INTR_MASK_20_SHIFT 20
#define MP2_PIC0_MASK_2_INTR_MASK_21_SHIFT 21
#define MP2_PIC0_MASK_2_INTR_MASK_22_SHIFT 22
#define MP2_PIC0_MASK_2_INTR_MASK_23_SHIFT 23
#define MP2_PIC0_MASK_2_INTR_MASK_24_SHIFT 24
#define MP2_PIC0_MASK_2_INTR_MASK_25_SHIFT 25
#define MP2_PIC0_MASK_2_INTR_MASK_26_SHIFT 26
#define MP2_PIC0_MASK_2_INTR_MASK_27_SHIFT 27
#define MP2_PIC0_MASK_2_INTR_MASK_28_SHIFT 28
#define MP2_PIC0_MASK_2_INTR_MASK_29_SHIFT 29
#define MP2_PIC0_MASK_2_INTR_MASK_30_SHIFT 30
#define MP2_PIC0_MASK_2_INTR_MASK_31_SHIFT 31

#define MP2_PIC0_MASK_2_INTR_MASK_0_MASK 0x1
#define MP2_PIC0_MASK_2_INTR_MASK_1_MASK 0x2
#define MP2_PIC0_MASK_2_INTR_MASK_2_MASK 0x4
#define MP2_PIC0_MASK_2_INTR_MASK_3_MASK 0x8
#define MP2_PIC0_MASK_2_INTR_MASK_4_MASK 0x10
#define MP2_PIC0_MASK_2_INTR_MASK_5_MASK 0x20
#define MP2_PIC0_MASK_2_INTR_MASK_6_MASK 0x40
#define MP2_PIC0_MASK_2_INTR_MASK_7_MASK 0x80
#define MP2_PIC0_MASK_2_INTR_MASK_8_MASK 0x100
#define MP2_PIC0_MASK_2_INTR_MASK_9_MASK 0x200
#define MP2_PIC0_MASK_2_INTR_MASK_10_MASK 0x400
#define MP2_PIC0_MASK_2_INTR_MASK_11_MASK 0x800
#define MP2_PIC0_MASK_2_INTR_MASK_12_MASK 0x1000
#define MP2_PIC0_MASK_2_INTR_MASK_13_MASK 0x2000
#define MP2_PIC0_MASK_2_INTR_MASK_14_MASK 0x4000
#define MP2_PIC0_MASK_2_INTR_MASK_15_MASK 0x8000
#define MP2_PIC0_MASK_2_INTR_MASK_16_MASK 0x10000
#define MP2_PIC0_MASK_2_INTR_MASK_17_MASK 0x20000
#define MP2_PIC0_MASK_2_INTR_MASK_18_MASK 0x40000
#define MP2_PIC0_MASK_2_INTR_MASK_19_MASK 0x80000
#define MP2_PIC0_MASK_2_INTR_MASK_20_MASK 0x100000
#define MP2_PIC0_MASK_2_INTR_MASK_21_MASK 0x200000
#define MP2_PIC0_MASK_2_INTR_MASK_22_MASK 0x400000
#define MP2_PIC0_MASK_2_INTR_MASK_23_MASK 0x800000
#define MP2_PIC0_MASK_2_INTR_MASK_24_MASK 0x1000000
#define MP2_PIC0_MASK_2_INTR_MASK_25_MASK 0x2000000
#define MP2_PIC0_MASK_2_INTR_MASK_26_MASK 0x4000000
#define MP2_PIC0_MASK_2_INTR_MASK_27_MASK 0x8000000
#define MP2_PIC0_MASK_2_INTR_MASK_28_MASK 0x10000000
#define MP2_PIC0_MASK_2_INTR_MASK_29_MASK 0x20000000
#define MP2_PIC0_MASK_2_INTR_MASK_30_MASK 0x40000000
#define MP2_PIC0_MASK_2_INTR_MASK_31_MASK 0x80000000

#define MP2_PIC0_MASK_2_MASK \
     (MP2_PIC0_MASK_2_INTR_MASK_0_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_1_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_2_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_3_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_4_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_5_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_6_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_7_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_8_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_9_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_10_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_11_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_12_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_13_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_14_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_15_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_16_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_17_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_18_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_19_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_20_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_21_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_22_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_23_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_24_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_25_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_26_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_27_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_28_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_29_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_30_MASK | \
      MP2_PIC0_MASK_2_INTR_MASK_31_MASK)

#define MP2_PIC0_MASK_2_DEFAULT        0x00000000

#define MP2_PIC0_MASK_2_GET_INTR_MASK_0(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_0_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_0_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_1(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_1_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_1_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_2(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_2_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_2_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_3(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_3_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_3_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_4(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_4_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_4_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_5(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_5_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_5_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_6(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_6_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_6_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_7(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_7_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_7_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_8(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_8_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_8_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_9(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_9_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_9_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_10(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_10_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_10_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_11(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_11_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_11_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_12(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_12_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_12_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_13(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_13_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_13_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_14(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_14_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_14_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_15(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_15_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_15_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_16(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_16_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_16_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_17(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_17_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_17_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_18(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_18_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_18_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_19(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_19_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_19_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_20(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_20_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_20_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_21(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_21_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_21_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_22(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_22_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_22_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_23(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_23_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_23_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_24(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_24_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_24_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_25(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_25_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_25_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_26(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_26_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_26_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_27(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_27_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_27_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_28(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_28_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_28_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_29(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_29_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_29_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_30(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_30_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_30_SHIFT)
#define MP2_PIC0_MASK_2_GET_INTR_MASK_31(mp2_pic0_mask_2) \
     ((mp2_pic0_mask_2 & MP2_PIC0_MASK_2_INTR_MASK_31_MASK) >> MP2_PIC0_MASK_2_INTR_MASK_31_SHIFT)

#define MP2_PIC0_MASK_2_SET_INTR_MASK_0(mp2_pic0_mask_2_reg, intr_mask_0) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_0_MASK) | (intr_mask_0 << MP2_PIC0_MASK_2_INTR_MASK_0_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_1(mp2_pic0_mask_2_reg, intr_mask_1) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_1_MASK) | (intr_mask_1 << MP2_PIC0_MASK_2_INTR_MASK_1_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_2(mp2_pic0_mask_2_reg, intr_mask_2) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_2_MASK) | (intr_mask_2 << MP2_PIC0_MASK_2_INTR_MASK_2_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_3(mp2_pic0_mask_2_reg, intr_mask_3) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_3_MASK) | (intr_mask_3 << MP2_PIC0_MASK_2_INTR_MASK_3_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_4(mp2_pic0_mask_2_reg, intr_mask_4) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_4_MASK) | (intr_mask_4 << MP2_PIC0_MASK_2_INTR_MASK_4_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_5(mp2_pic0_mask_2_reg, intr_mask_5) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_5_MASK) | (intr_mask_5 << MP2_PIC0_MASK_2_INTR_MASK_5_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_6(mp2_pic0_mask_2_reg, intr_mask_6) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_6_MASK) | (intr_mask_6 << MP2_PIC0_MASK_2_INTR_MASK_6_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_7(mp2_pic0_mask_2_reg, intr_mask_7) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_7_MASK) | (intr_mask_7 << MP2_PIC0_MASK_2_INTR_MASK_7_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_8(mp2_pic0_mask_2_reg, intr_mask_8) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_8_MASK) | (intr_mask_8 << MP2_PIC0_MASK_2_INTR_MASK_8_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_9(mp2_pic0_mask_2_reg, intr_mask_9) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_9_MASK) | (intr_mask_9 << MP2_PIC0_MASK_2_INTR_MASK_9_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_10(mp2_pic0_mask_2_reg, intr_mask_10) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_10_MASK) | (intr_mask_10 << MP2_PIC0_MASK_2_INTR_MASK_10_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_11(mp2_pic0_mask_2_reg, intr_mask_11) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_11_MASK) | (intr_mask_11 << MP2_PIC0_MASK_2_INTR_MASK_11_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_12(mp2_pic0_mask_2_reg, intr_mask_12) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_12_MASK) | (intr_mask_12 << MP2_PIC0_MASK_2_INTR_MASK_12_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_13(mp2_pic0_mask_2_reg, intr_mask_13) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_13_MASK) | (intr_mask_13 << MP2_PIC0_MASK_2_INTR_MASK_13_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_14(mp2_pic0_mask_2_reg, intr_mask_14) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_14_MASK) | (intr_mask_14 << MP2_PIC0_MASK_2_INTR_MASK_14_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_15(mp2_pic0_mask_2_reg, intr_mask_15) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_15_MASK) | (intr_mask_15 << MP2_PIC0_MASK_2_INTR_MASK_15_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_16(mp2_pic0_mask_2_reg, intr_mask_16) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_16_MASK) | (intr_mask_16 << MP2_PIC0_MASK_2_INTR_MASK_16_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_17(mp2_pic0_mask_2_reg, intr_mask_17) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_17_MASK) | (intr_mask_17 << MP2_PIC0_MASK_2_INTR_MASK_17_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_18(mp2_pic0_mask_2_reg, intr_mask_18) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_18_MASK) | (intr_mask_18 << MP2_PIC0_MASK_2_INTR_MASK_18_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_19(mp2_pic0_mask_2_reg, intr_mask_19) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_19_MASK) | (intr_mask_19 << MP2_PIC0_MASK_2_INTR_MASK_19_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_20(mp2_pic0_mask_2_reg, intr_mask_20) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_20_MASK) | (intr_mask_20 << MP2_PIC0_MASK_2_INTR_MASK_20_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_21(mp2_pic0_mask_2_reg, intr_mask_21) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_21_MASK) | (intr_mask_21 << MP2_PIC0_MASK_2_INTR_MASK_21_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_22(mp2_pic0_mask_2_reg, intr_mask_22) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_22_MASK) | (intr_mask_22 << MP2_PIC0_MASK_2_INTR_MASK_22_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_23(mp2_pic0_mask_2_reg, intr_mask_23) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_23_MASK) | (intr_mask_23 << MP2_PIC0_MASK_2_INTR_MASK_23_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_24(mp2_pic0_mask_2_reg, intr_mask_24) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_24_MASK) | (intr_mask_24 << MP2_PIC0_MASK_2_INTR_MASK_24_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_25(mp2_pic0_mask_2_reg, intr_mask_25) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_25_MASK) | (intr_mask_25 << MP2_PIC0_MASK_2_INTR_MASK_25_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_26(mp2_pic0_mask_2_reg, intr_mask_26) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_26_MASK) | (intr_mask_26 << MP2_PIC0_MASK_2_INTR_MASK_26_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_27(mp2_pic0_mask_2_reg, intr_mask_27) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_27_MASK) | (intr_mask_27 << MP2_PIC0_MASK_2_INTR_MASK_27_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_28(mp2_pic0_mask_2_reg, intr_mask_28) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_28_MASK) | (intr_mask_28 << MP2_PIC0_MASK_2_INTR_MASK_28_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_29(mp2_pic0_mask_2_reg, intr_mask_29) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_29_MASK) | (intr_mask_29 << MP2_PIC0_MASK_2_INTR_MASK_29_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_30(mp2_pic0_mask_2_reg, intr_mask_30) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_30_MASK) | (intr_mask_30 << MP2_PIC0_MASK_2_INTR_MASK_30_SHIFT)
#define MP2_PIC0_MASK_2_SET_INTR_MASK_31(mp2_pic0_mask_2_reg, intr_mask_31) \
     mp2_pic0_mask_2_reg = (mp2_pic0_mask_2_reg & ~MP2_PIC0_MASK_2_INTR_MASK_31_MASK) | (intr_mask_31 << MP2_PIC0_MASK_2_INTR_MASK_31_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_mask_2_t {
          unsigned int intr_mask_0                    : MP2_PIC0_MASK_2_INTR_MASK_0_SIZE;
          unsigned int intr_mask_1                    : MP2_PIC0_MASK_2_INTR_MASK_1_SIZE;
          unsigned int intr_mask_2                    : MP2_PIC0_MASK_2_INTR_MASK_2_SIZE;
          unsigned int intr_mask_3                    : MP2_PIC0_MASK_2_INTR_MASK_3_SIZE;
          unsigned int intr_mask_4                    : MP2_PIC0_MASK_2_INTR_MASK_4_SIZE;
          unsigned int intr_mask_5                    : MP2_PIC0_MASK_2_INTR_MASK_5_SIZE;
          unsigned int intr_mask_6                    : MP2_PIC0_MASK_2_INTR_MASK_6_SIZE;
          unsigned int intr_mask_7                    : MP2_PIC0_MASK_2_INTR_MASK_7_SIZE;
          unsigned int intr_mask_8                    : MP2_PIC0_MASK_2_INTR_MASK_8_SIZE;
          unsigned int intr_mask_9                    : MP2_PIC0_MASK_2_INTR_MASK_9_SIZE;
          unsigned int intr_mask_10                   : MP2_PIC0_MASK_2_INTR_MASK_10_SIZE;
          unsigned int intr_mask_11                   : MP2_PIC0_MASK_2_INTR_MASK_11_SIZE;
          unsigned int intr_mask_12                   : MP2_PIC0_MASK_2_INTR_MASK_12_SIZE;
          unsigned int intr_mask_13                   : MP2_PIC0_MASK_2_INTR_MASK_13_SIZE;
          unsigned int intr_mask_14                   : MP2_PIC0_MASK_2_INTR_MASK_14_SIZE;
          unsigned int intr_mask_15                   : MP2_PIC0_MASK_2_INTR_MASK_15_SIZE;
          unsigned int intr_mask_16                   : MP2_PIC0_MASK_2_INTR_MASK_16_SIZE;
          unsigned int intr_mask_17                   : MP2_PIC0_MASK_2_INTR_MASK_17_SIZE;
          unsigned int intr_mask_18                   : MP2_PIC0_MASK_2_INTR_MASK_18_SIZE;
          unsigned int intr_mask_19                   : MP2_PIC0_MASK_2_INTR_MASK_19_SIZE;
          unsigned int intr_mask_20                   : MP2_PIC0_MASK_2_INTR_MASK_20_SIZE;
          unsigned int intr_mask_21                   : MP2_PIC0_MASK_2_INTR_MASK_21_SIZE;
          unsigned int intr_mask_22                   : MP2_PIC0_MASK_2_INTR_MASK_22_SIZE;
          unsigned int intr_mask_23                   : MP2_PIC0_MASK_2_INTR_MASK_23_SIZE;
          unsigned int intr_mask_24                   : MP2_PIC0_MASK_2_INTR_MASK_24_SIZE;
          unsigned int intr_mask_25                   : MP2_PIC0_MASK_2_INTR_MASK_25_SIZE;
          unsigned int intr_mask_26                   : MP2_PIC0_MASK_2_INTR_MASK_26_SIZE;
          unsigned int intr_mask_27                   : MP2_PIC0_MASK_2_INTR_MASK_27_SIZE;
          unsigned int intr_mask_28                   : MP2_PIC0_MASK_2_INTR_MASK_28_SIZE;
          unsigned int intr_mask_29                   : MP2_PIC0_MASK_2_INTR_MASK_29_SIZE;
          unsigned int intr_mask_30                   : MP2_PIC0_MASK_2_INTR_MASK_30_SIZE;
          unsigned int intr_mask_31                   : MP2_PIC0_MASK_2_INTR_MASK_31_SIZE;
     } mp2_pic0_mask_2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_mask_2_t {
          unsigned int intr_mask_31                   : MP2_PIC0_MASK_2_INTR_MASK_31_SIZE;
          unsigned int intr_mask_30                   : MP2_PIC0_MASK_2_INTR_MASK_30_SIZE;
          unsigned int intr_mask_29                   : MP2_PIC0_MASK_2_INTR_MASK_29_SIZE;
          unsigned int intr_mask_28                   : MP2_PIC0_MASK_2_INTR_MASK_28_SIZE;
          unsigned int intr_mask_27                   : MP2_PIC0_MASK_2_INTR_MASK_27_SIZE;
          unsigned int intr_mask_26                   : MP2_PIC0_MASK_2_INTR_MASK_26_SIZE;
          unsigned int intr_mask_25                   : MP2_PIC0_MASK_2_INTR_MASK_25_SIZE;
          unsigned int intr_mask_24                   : MP2_PIC0_MASK_2_INTR_MASK_24_SIZE;
          unsigned int intr_mask_23                   : MP2_PIC0_MASK_2_INTR_MASK_23_SIZE;
          unsigned int intr_mask_22                   : MP2_PIC0_MASK_2_INTR_MASK_22_SIZE;
          unsigned int intr_mask_21                   : MP2_PIC0_MASK_2_INTR_MASK_21_SIZE;
          unsigned int intr_mask_20                   : MP2_PIC0_MASK_2_INTR_MASK_20_SIZE;
          unsigned int intr_mask_19                   : MP2_PIC0_MASK_2_INTR_MASK_19_SIZE;
          unsigned int intr_mask_18                   : MP2_PIC0_MASK_2_INTR_MASK_18_SIZE;
          unsigned int intr_mask_17                   : MP2_PIC0_MASK_2_INTR_MASK_17_SIZE;
          unsigned int intr_mask_16                   : MP2_PIC0_MASK_2_INTR_MASK_16_SIZE;
          unsigned int intr_mask_15                   : MP2_PIC0_MASK_2_INTR_MASK_15_SIZE;
          unsigned int intr_mask_14                   : MP2_PIC0_MASK_2_INTR_MASK_14_SIZE;
          unsigned int intr_mask_13                   : MP2_PIC0_MASK_2_INTR_MASK_13_SIZE;
          unsigned int intr_mask_12                   : MP2_PIC0_MASK_2_INTR_MASK_12_SIZE;
          unsigned int intr_mask_11                   : MP2_PIC0_MASK_2_INTR_MASK_11_SIZE;
          unsigned int intr_mask_10                   : MP2_PIC0_MASK_2_INTR_MASK_10_SIZE;
          unsigned int intr_mask_9                    : MP2_PIC0_MASK_2_INTR_MASK_9_SIZE;
          unsigned int intr_mask_8                    : MP2_PIC0_MASK_2_INTR_MASK_8_SIZE;
          unsigned int intr_mask_7                    : MP2_PIC0_MASK_2_INTR_MASK_7_SIZE;
          unsigned int intr_mask_6                    : MP2_PIC0_MASK_2_INTR_MASK_6_SIZE;
          unsigned int intr_mask_5                    : MP2_PIC0_MASK_2_INTR_MASK_5_SIZE;
          unsigned int intr_mask_4                    : MP2_PIC0_MASK_2_INTR_MASK_4_SIZE;
          unsigned int intr_mask_3                    : MP2_PIC0_MASK_2_INTR_MASK_3_SIZE;
          unsigned int intr_mask_2                    : MP2_PIC0_MASK_2_INTR_MASK_2_SIZE;
          unsigned int intr_mask_1                    : MP2_PIC0_MASK_2_INTR_MASK_1_SIZE;
          unsigned int intr_mask_0                    : MP2_PIC0_MASK_2_INTR_MASK_0_SIZE;
     } mp2_pic0_mask_2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_mask_2_t f;
} mp2_pic0_mask_2_u;


/*
 * MP2_PIC0_MASK_3 struct
 */

#define MP2_PIC0_MASK_3_REG_SIZE       32
#define MP2_PIC0_MASK_3_INTR_MASK_0_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_1_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_2_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_3_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_4_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_5_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_6_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_7_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_8_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_9_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_10_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_11_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_12_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_13_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_14_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_15_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_16_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_17_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_18_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_19_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_20_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_21_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_22_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_23_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_24_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_25_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_26_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_27_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_28_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_29_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_30_SIZE 1
#define MP2_PIC0_MASK_3_INTR_MASK_31_SIZE 1

#define MP2_PIC0_MASK_3_INTR_MASK_0_SHIFT 0
#define MP2_PIC0_MASK_3_INTR_MASK_1_SHIFT 1
#define MP2_PIC0_MASK_3_INTR_MASK_2_SHIFT 2
#define MP2_PIC0_MASK_3_INTR_MASK_3_SHIFT 3
#define MP2_PIC0_MASK_3_INTR_MASK_4_SHIFT 4
#define MP2_PIC0_MASK_3_INTR_MASK_5_SHIFT 5
#define MP2_PIC0_MASK_3_INTR_MASK_6_SHIFT 6
#define MP2_PIC0_MASK_3_INTR_MASK_7_SHIFT 7
#define MP2_PIC0_MASK_3_INTR_MASK_8_SHIFT 8
#define MP2_PIC0_MASK_3_INTR_MASK_9_SHIFT 9
#define MP2_PIC0_MASK_3_INTR_MASK_10_SHIFT 10
#define MP2_PIC0_MASK_3_INTR_MASK_11_SHIFT 11
#define MP2_PIC0_MASK_3_INTR_MASK_12_SHIFT 12
#define MP2_PIC0_MASK_3_INTR_MASK_13_SHIFT 13
#define MP2_PIC0_MASK_3_INTR_MASK_14_SHIFT 14
#define MP2_PIC0_MASK_3_INTR_MASK_15_SHIFT 15
#define MP2_PIC0_MASK_3_INTR_MASK_16_SHIFT 16
#define MP2_PIC0_MASK_3_INTR_MASK_17_SHIFT 17
#define MP2_PIC0_MASK_3_INTR_MASK_18_SHIFT 18
#define MP2_PIC0_MASK_3_INTR_MASK_19_SHIFT 19
#define MP2_PIC0_MASK_3_INTR_MASK_20_SHIFT 20
#define MP2_PIC0_MASK_3_INTR_MASK_21_SHIFT 21
#define MP2_PIC0_MASK_3_INTR_MASK_22_SHIFT 22
#define MP2_PIC0_MASK_3_INTR_MASK_23_SHIFT 23
#define MP2_PIC0_MASK_3_INTR_MASK_24_SHIFT 24
#define MP2_PIC0_MASK_3_INTR_MASK_25_SHIFT 25
#define MP2_PIC0_MASK_3_INTR_MASK_26_SHIFT 26
#define MP2_PIC0_MASK_3_INTR_MASK_27_SHIFT 27
#define MP2_PIC0_MASK_3_INTR_MASK_28_SHIFT 28
#define MP2_PIC0_MASK_3_INTR_MASK_29_SHIFT 29
#define MP2_PIC0_MASK_3_INTR_MASK_30_SHIFT 30
#define MP2_PIC0_MASK_3_INTR_MASK_31_SHIFT 31

#define MP2_PIC0_MASK_3_INTR_MASK_0_MASK 0x1
#define MP2_PIC0_MASK_3_INTR_MASK_1_MASK 0x2
#define MP2_PIC0_MASK_3_INTR_MASK_2_MASK 0x4
#define MP2_PIC0_MASK_3_INTR_MASK_3_MASK 0x8
#define MP2_PIC0_MASK_3_INTR_MASK_4_MASK 0x10
#define MP2_PIC0_MASK_3_INTR_MASK_5_MASK 0x20
#define MP2_PIC0_MASK_3_INTR_MASK_6_MASK 0x40
#define MP2_PIC0_MASK_3_INTR_MASK_7_MASK 0x80
#define MP2_PIC0_MASK_3_INTR_MASK_8_MASK 0x100
#define MP2_PIC0_MASK_3_INTR_MASK_9_MASK 0x200
#define MP2_PIC0_MASK_3_INTR_MASK_10_MASK 0x400
#define MP2_PIC0_MASK_3_INTR_MASK_11_MASK 0x800
#define MP2_PIC0_MASK_3_INTR_MASK_12_MASK 0x1000
#define MP2_PIC0_MASK_3_INTR_MASK_13_MASK 0x2000
#define MP2_PIC0_MASK_3_INTR_MASK_14_MASK 0x4000
#define MP2_PIC0_MASK_3_INTR_MASK_15_MASK 0x8000
#define MP2_PIC0_MASK_3_INTR_MASK_16_MASK 0x10000
#define MP2_PIC0_MASK_3_INTR_MASK_17_MASK 0x20000
#define MP2_PIC0_MASK_3_INTR_MASK_18_MASK 0x40000
#define MP2_PIC0_MASK_3_INTR_MASK_19_MASK 0x80000
#define MP2_PIC0_MASK_3_INTR_MASK_20_MASK 0x100000
#define MP2_PIC0_MASK_3_INTR_MASK_21_MASK 0x200000
#define MP2_PIC0_MASK_3_INTR_MASK_22_MASK 0x400000
#define MP2_PIC0_MASK_3_INTR_MASK_23_MASK 0x800000
#define MP2_PIC0_MASK_3_INTR_MASK_24_MASK 0x1000000
#define MP2_PIC0_MASK_3_INTR_MASK_25_MASK 0x2000000
#define MP2_PIC0_MASK_3_INTR_MASK_26_MASK 0x4000000
#define MP2_PIC0_MASK_3_INTR_MASK_27_MASK 0x8000000
#define MP2_PIC0_MASK_3_INTR_MASK_28_MASK 0x10000000
#define MP2_PIC0_MASK_3_INTR_MASK_29_MASK 0x20000000
#define MP2_PIC0_MASK_3_INTR_MASK_30_MASK 0x40000000
#define MP2_PIC0_MASK_3_INTR_MASK_31_MASK 0x80000000

#define MP2_PIC0_MASK_3_MASK \
     (MP2_PIC0_MASK_3_INTR_MASK_0_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_1_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_2_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_3_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_4_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_5_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_6_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_7_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_8_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_9_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_10_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_11_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_12_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_13_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_14_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_15_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_16_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_17_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_18_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_19_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_20_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_21_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_22_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_23_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_24_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_25_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_26_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_27_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_28_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_29_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_30_MASK | \
      MP2_PIC0_MASK_3_INTR_MASK_31_MASK)

#define MP2_PIC0_MASK_3_DEFAULT        0x00000000

#define MP2_PIC0_MASK_3_GET_INTR_MASK_0(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_0_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_0_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_1(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_1_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_1_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_2(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_2_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_2_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_3(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_3_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_3_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_4(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_4_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_4_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_5(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_5_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_5_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_6(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_6_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_6_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_7(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_7_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_7_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_8(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_8_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_8_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_9(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_9_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_9_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_10(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_10_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_10_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_11(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_11_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_11_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_12(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_12_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_12_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_13(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_13_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_13_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_14(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_14_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_14_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_15(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_15_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_15_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_16(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_16_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_16_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_17(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_17_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_17_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_18(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_18_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_18_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_19(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_19_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_19_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_20(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_20_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_20_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_21(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_21_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_21_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_22(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_22_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_22_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_23(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_23_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_23_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_24(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_24_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_24_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_25(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_25_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_25_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_26(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_26_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_26_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_27(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_27_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_27_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_28(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_28_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_28_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_29(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_29_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_29_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_30(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_30_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_30_SHIFT)
#define MP2_PIC0_MASK_3_GET_INTR_MASK_31(mp2_pic0_mask_3) \
     ((mp2_pic0_mask_3 & MP2_PIC0_MASK_3_INTR_MASK_31_MASK) >> MP2_PIC0_MASK_3_INTR_MASK_31_SHIFT)

#define MP2_PIC0_MASK_3_SET_INTR_MASK_0(mp2_pic0_mask_3_reg, intr_mask_0) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_0_MASK) | (intr_mask_0 << MP2_PIC0_MASK_3_INTR_MASK_0_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_1(mp2_pic0_mask_3_reg, intr_mask_1) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_1_MASK) | (intr_mask_1 << MP2_PIC0_MASK_3_INTR_MASK_1_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_2(mp2_pic0_mask_3_reg, intr_mask_2) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_2_MASK) | (intr_mask_2 << MP2_PIC0_MASK_3_INTR_MASK_2_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_3(mp2_pic0_mask_3_reg, intr_mask_3) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_3_MASK) | (intr_mask_3 << MP2_PIC0_MASK_3_INTR_MASK_3_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_4(mp2_pic0_mask_3_reg, intr_mask_4) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_4_MASK) | (intr_mask_4 << MP2_PIC0_MASK_3_INTR_MASK_4_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_5(mp2_pic0_mask_3_reg, intr_mask_5) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_5_MASK) | (intr_mask_5 << MP2_PIC0_MASK_3_INTR_MASK_5_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_6(mp2_pic0_mask_3_reg, intr_mask_6) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_6_MASK) | (intr_mask_6 << MP2_PIC0_MASK_3_INTR_MASK_6_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_7(mp2_pic0_mask_3_reg, intr_mask_7) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_7_MASK) | (intr_mask_7 << MP2_PIC0_MASK_3_INTR_MASK_7_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_8(mp2_pic0_mask_3_reg, intr_mask_8) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_8_MASK) | (intr_mask_8 << MP2_PIC0_MASK_3_INTR_MASK_8_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_9(mp2_pic0_mask_3_reg, intr_mask_9) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_9_MASK) | (intr_mask_9 << MP2_PIC0_MASK_3_INTR_MASK_9_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_10(mp2_pic0_mask_3_reg, intr_mask_10) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_10_MASK) | (intr_mask_10 << MP2_PIC0_MASK_3_INTR_MASK_10_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_11(mp2_pic0_mask_3_reg, intr_mask_11) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_11_MASK) | (intr_mask_11 << MP2_PIC0_MASK_3_INTR_MASK_11_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_12(mp2_pic0_mask_3_reg, intr_mask_12) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_12_MASK) | (intr_mask_12 << MP2_PIC0_MASK_3_INTR_MASK_12_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_13(mp2_pic0_mask_3_reg, intr_mask_13) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_13_MASK) | (intr_mask_13 << MP2_PIC0_MASK_3_INTR_MASK_13_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_14(mp2_pic0_mask_3_reg, intr_mask_14) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_14_MASK) | (intr_mask_14 << MP2_PIC0_MASK_3_INTR_MASK_14_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_15(mp2_pic0_mask_3_reg, intr_mask_15) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_15_MASK) | (intr_mask_15 << MP2_PIC0_MASK_3_INTR_MASK_15_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_16(mp2_pic0_mask_3_reg, intr_mask_16) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_16_MASK) | (intr_mask_16 << MP2_PIC0_MASK_3_INTR_MASK_16_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_17(mp2_pic0_mask_3_reg, intr_mask_17) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_17_MASK) | (intr_mask_17 << MP2_PIC0_MASK_3_INTR_MASK_17_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_18(mp2_pic0_mask_3_reg, intr_mask_18) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_18_MASK) | (intr_mask_18 << MP2_PIC0_MASK_3_INTR_MASK_18_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_19(mp2_pic0_mask_3_reg, intr_mask_19) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_19_MASK) | (intr_mask_19 << MP2_PIC0_MASK_3_INTR_MASK_19_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_20(mp2_pic0_mask_3_reg, intr_mask_20) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_20_MASK) | (intr_mask_20 << MP2_PIC0_MASK_3_INTR_MASK_20_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_21(mp2_pic0_mask_3_reg, intr_mask_21) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_21_MASK) | (intr_mask_21 << MP2_PIC0_MASK_3_INTR_MASK_21_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_22(mp2_pic0_mask_3_reg, intr_mask_22) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_22_MASK) | (intr_mask_22 << MP2_PIC0_MASK_3_INTR_MASK_22_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_23(mp2_pic0_mask_3_reg, intr_mask_23) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_23_MASK) | (intr_mask_23 << MP2_PIC0_MASK_3_INTR_MASK_23_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_24(mp2_pic0_mask_3_reg, intr_mask_24) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_24_MASK) | (intr_mask_24 << MP2_PIC0_MASK_3_INTR_MASK_24_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_25(mp2_pic0_mask_3_reg, intr_mask_25) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_25_MASK) | (intr_mask_25 << MP2_PIC0_MASK_3_INTR_MASK_25_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_26(mp2_pic0_mask_3_reg, intr_mask_26) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_26_MASK) | (intr_mask_26 << MP2_PIC0_MASK_3_INTR_MASK_26_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_27(mp2_pic0_mask_3_reg, intr_mask_27) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_27_MASK) | (intr_mask_27 << MP2_PIC0_MASK_3_INTR_MASK_27_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_28(mp2_pic0_mask_3_reg, intr_mask_28) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_28_MASK) | (intr_mask_28 << MP2_PIC0_MASK_3_INTR_MASK_28_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_29(mp2_pic0_mask_3_reg, intr_mask_29) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_29_MASK) | (intr_mask_29 << MP2_PIC0_MASK_3_INTR_MASK_29_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_30(mp2_pic0_mask_3_reg, intr_mask_30) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_30_MASK) | (intr_mask_30 << MP2_PIC0_MASK_3_INTR_MASK_30_SHIFT)
#define MP2_PIC0_MASK_3_SET_INTR_MASK_31(mp2_pic0_mask_3_reg, intr_mask_31) \
     mp2_pic0_mask_3_reg = (mp2_pic0_mask_3_reg & ~MP2_PIC0_MASK_3_INTR_MASK_31_MASK) | (intr_mask_31 << MP2_PIC0_MASK_3_INTR_MASK_31_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_mask_3_t {
          unsigned int intr_mask_0                    : MP2_PIC0_MASK_3_INTR_MASK_0_SIZE;
          unsigned int intr_mask_1                    : MP2_PIC0_MASK_3_INTR_MASK_1_SIZE;
          unsigned int intr_mask_2                    : MP2_PIC0_MASK_3_INTR_MASK_2_SIZE;
          unsigned int intr_mask_3                    : MP2_PIC0_MASK_3_INTR_MASK_3_SIZE;
          unsigned int intr_mask_4                    : MP2_PIC0_MASK_3_INTR_MASK_4_SIZE;
          unsigned int intr_mask_5                    : MP2_PIC0_MASK_3_INTR_MASK_5_SIZE;
          unsigned int intr_mask_6                    : MP2_PIC0_MASK_3_INTR_MASK_6_SIZE;
          unsigned int intr_mask_7                    : MP2_PIC0_MASK_3_INTR_MASK_7_SIZE;
          unsigned int intr_mask_8                    : MP2_PIC0_MASK_3_INTR_MASK_8_SIZE;
          unsigned int intr_mask_9                    : MP2_PIC0_MASK_3_INTR_MASK_9_SIZE;
          unsigned int intr_mask_10                   : MP2_PIC0_MASK_3_INTR_MASK_10_SIZE;
          unsigned int intr_mask_11                   : MP2_PIC0_MASK_3_INTR_MASK_11_SIZE;
          unsigned int intr_mask_12                   : MP2_PIC0_MASK_3_INTR_MASK_12_SIZE;
          unsigned int intr_mask_13                   : MP2_PIC0_MASK_3_INTR_MASK_13_SIZE;
          unsigned int intr_mask_14                   : MP2_PIC0_MASK_3_INTR_MASK_14_SIZE;
          unsigned int intr_mask_15                   : MP2_PIC0_MASK_3_INTR_MASK_15_SIZE;
          unsigned int intr_mask_16                   : MP2_PIC0_MASK_3_INTR_MASK_16_SIZE;
          unsigned int intr_mask_17                   : MP2_PIC0_MASK_3_INTR_MASK_17_SIZE;
          unsigned int intr_mask_18                   : MP2_PIC0_MASK_3_INTR_MASK_18_SIZE;
          unsigned int intr_mask_19                   : MP2_PIC0_MASK_3_INTR_MASK_19_SIZE;
          unsigned int intr_mask_20                   : MP2_PIC0_MASK_3_INTR_MASK_20_SIZE;
          unsigned int intr_mask_21                   : MP2_PIC0_MASK_3_INTR_MASK_21_SIZE;
          unsigned int intr_mask_22                   : MP2_PIC0_MASK_3_INTR_MASK_22_SIZE;
          unsigned int intr_mask_23                   : MP2_PIC0_MASK_3_INTR_MASK_23_SIZE;
          unsigned int intr_mask_24                   : MP2_PIC0_MASK_3_INTR_MASK_24_SIZE;
          unsigned int intr_mask_25                   : MP2_PIC0_MASK_3_INTR_MASK_25_SIZE;
          unsigned int intr_mask_26                   : MP2_PIC0_MASK_3_INTR_MASK_26_SIZE;
          unsigned int intr_mask_27                   : MP2_PIC0_MASK_3_INTR_MASK_27_SIZE;
          unsigned int intr_mask_28                   : MP2_PIC0_MASK_3_INTR_MASK_28_SIZE;
          unsigned int intr_mask_29                   : MP2_PIC0_MASK_3_INTR_MASK_29_SIZE;
          unsigned int intr_mask_30                   : MP2_PIC0_MASK_3_INTR_MASK_30_SIZE;
          unsigned int intr_mask_31                   : MP2_PIC0_MASK_3_INTR_MASK_31_SIZE;
     } mp2_pic0_mask_3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_mask_3_t {
          unsigned int intr_mask_31                   : MP2_PIC0_MASK_3_INTR_MASK_31_SIZE;
          unsigned int intr_mask_30                   : MP2_PIC0_MASK_3_INTR_MASK_30_SIZE;
          unsigned int intr_mask_29                   : MP2_PIC0_MASK_3_INTR_MASK_29_SIZE;
          unsigned int intr_mask_28                   : MP2_PIC0_MASK_3_INTR_MASK_28_SIZE;
          unsigned int intr_mask_27                   : MP2_PIC0_MASK_3_INTR_MASK_27_SIZE;
          unsigned int intr_mask_26                   : MP2_PIC0_MASK_3_INTR_MASK_26_SIZE;
          unsigned int intr_mask_25                   : MP2_PIC0_MASK_3_INTR_MASK_25_SIZE;
          unsigned int intr_mask_24                   : MP2_PIC0_MASK_3_INTR_MASK_24_SIZE;
          unsigned int intr_mask_23                   : MP2_PIC0_MASK_3_INTR_MASK_23_SIZE;
          unsigned int intr_mask_22                   : MP2_PIC0_MASK_3_INTR_MASK_22_SIZE;
          unsigned int intr_mask_21                   : MP2_PIC0_MASK_3_INTR_MASK_21_SIZE;
          unsigned int intr_mask_20                   : MP2_PIC0_MASK_3_INTR_MASK_20_SIZE;
          unsigned int intr_mask_19                   : MP2_PIC0_MASK_3_INTR_MASK_19_SIZE;
          unsigned int intr_mask_18                   : MP2_PIC0_MASK_3_INTR_MASK_18_SIZE;
          unsigned int intr_mask_17                   : MP2_PIC0_MASK_3_INTR_MASK_17_SIZE;
          unsigned int intr_mask_16                   : MP2_PIC0_MASK_3_INTR_MASK_16_SIZE;
          unsigned int intr_mask_15                   : MP2_PIC0_MASK_3_INTR_MASK_15_SIZE;
          unsigned int intr_mask_14                   : MP2_PIC0_MASK_3_INTR_MASK_14_SIZE;
          unsigned int intr_mask_13                   : MP2_PIC0_MASK_3_INTR_MASK_13_SIZE;
          unsigned int intr_mask_12                   : MP2_PIC0_MASK_3_INTR_MASK_12_SIZE;
          unsigned int intr_mask_11                   : MP2_PIC0_MASK_3_INTR_MASK_11_SIZE;
          unsigned int intr_mask_10                   : MP2_PIC0_MASK_3_INTR_MASK_10_SIZE;
          unsigned int intr_mask_9                    : MP2_PIC0_MASK_3_INTR_MASK_9_SIZE;
          unsigned int intr_mask_8                    : MP2_PIC0_MASK_3_INTR_MASK_8_SIZE;
          unsigned int intr_mask_7                    : MP2_PIC0_MASK_3_INTR_MASK_7_SIZE;
          unsigned int intr_mask_6                    : MP2_PIC0_MASK_3_INTR_MASK_6_SIZE;
          unsigned int intr_mask_5                    : MP2_PIC0_MASK_3_INTR_MASK_5_SIZE;
          unsigned int intr_mask_4                    : MP2_PIC0_MASK_3_INTR_MASK_4_SIZE;
          unsigned int intr_mask_3                    : MP2_PIC0_MASK_3_INTR_MASK_3_SIZE;
          unsigned int intr_mask_2                    : MP2_PIC0_MASK_3_INTR_MASK_2_SIZE;
          unsigned int intr_mask_1                    : MP2_PIC0_MASK_3_INTR_MASK_1_SIZE;
          unsigned int intr_mask_0                    : MP2_PIC0_MASK_3_INTR_MASK_0_SIZE;
     } mp2_pic0_mask_3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_mask_3_t f;
} mp2_pic0_mask_3_u;


/*
 * MP2_PIC0_LEVEL_0 struct
 */

#define MP2_PIC0_LEVEL_0_REG_SIZE      32
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_0_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_1_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_2_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_3_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_4_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_5_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_6_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_7_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_8_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_9_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_10_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_11_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_12_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_13_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_14_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_15_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_16_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_17_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_18_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_19_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_20_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_21_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_22_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_23_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_24_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_25_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_26_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_27_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_28_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_29_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_30_SIZE 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_31_SIZE 1

#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_0_SHIFT 0
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_1_SHIFT 1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_2_SHIFT 2
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_3_SHIFT 3
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_4_SHIFT 4
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_5_SHIFT 5
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_6_SHIFT 6
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_7_SHIFT 7
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_8_SHIFT 8
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_9_SHIFT 9
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_10_SHIFT 10
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_11_SHIFT 11
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_12_SHIFT 12
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_13_SHIFT 13
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_14_SHIFT 14
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_15_SHIFT 15
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_16_SHIFT 16
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_17_SHIFT 17
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_18_SHIFT 18
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_19_SHIFT 19
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_20_SHIFT 20
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_21_SHIFT 21
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_22_SHIFT 22
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_23_SHIFT 23
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_24_SHIFT 24
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_25_SHIFT 25
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_26_SHIFT 26
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_27_SHIFT 27
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_28_SHIFT 28
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_29_SHIFT 29
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_30_SHIFT 30
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_31_SHIFT 31

#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_0_MASK 0x1
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_1_MASK 0x2
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_2_MASK 0x4
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_3_MASK 0x8
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_4_MASK 0x10
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_5_MASK 0x20
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_6_MASK 0x40
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_7_MASK 0x80
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_8_MASK 0x100
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_9_MASK 0x200
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_10_MASK 0x400
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_11_MASK 0x800
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_12_MASK 0x1000
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_13_MASK 0x2000
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_14_MASK 0x4000
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_15_MASK 0x8000
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_16_MASK 0x10000
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_17_MASK 0x20000
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_18_MASK 0x40000
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_19_MASK 0x80000
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_20_MASK 0x100000
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_21_MASK 0x200000
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_22_MASK 0x400000
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_23_MASK 0x800000
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_24_MASK 0x1000000
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_25_MASK 0x2000000
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_26_MASK 0x4000000
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_27_MASK 0x8000000
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_28_MASK 0x10000000
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_29_MASK 0x20000000
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_30_MASK 0x40000000
#define MP2_PIC0_LEVEL_0_INTR_TRIGGER_31_MASK 0x80000000

#define MP2_PIC0_LEVEL_0_MASK \
     (MP2_PIC0_LEVEL_0_INTR_TRIGGER_0_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_1_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_2_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_3_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_4_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_5_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_6_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_7_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_8_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_9_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_10_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_11_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_12_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_13_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_14_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_15_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_16_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_17_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_18_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_19_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_20_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_21_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_22_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_23_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_24_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_25_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_26_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_27_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_28_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_29_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_30_MASK | \
      MP2_PIC0_LEVEL_0_INTR_TRIGGER_31_MASK)

#define MP2_PIC0_LEVEL_0_DEFAULT       0x00000000

#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_0(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_0_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_0_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_1(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_1_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_1_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_2(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_2_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_2_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_3(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_3_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_3_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_4(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_4_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_4_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_5(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_5_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_5_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_6(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_6_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_6_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_7(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_7_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_7_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_8(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_8_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_8_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_9(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_9_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_9_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_10(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_10_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_10_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_11(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_11_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_11_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_12(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_12_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_12_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_13(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_13_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_13_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_14(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_14_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_14_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_15(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_15_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_15_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_16(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_16_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_16_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_17(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_17_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_17_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_18(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_18_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_18_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_19(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_19_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_19_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_20(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_20_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_20_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_21(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_21_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_21_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_22(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_22_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_22_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_23(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_23_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_23_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_24(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_24_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_24_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_25(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_25_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_25_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_26(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_26_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_26_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_27(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_27_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_27_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_28(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_28_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_28_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_29(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_29_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_29_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_30(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_30_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_30_SHIFT)
#define MP2_PIC0_LEVEL_0_GET_INTR_TRIGGER_31(mp2_pic0_level_0) \
     ((mp2_pic0_level_0 & MP2_PIC0_LEVEL_0_INTR_TRIGGER_31_MASK) >> MP2_PIC0_LEVEL_0_INTR_TRIGGER_31_SHIFT)

#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_0(mp2_pic0_level_0_reg, intr_trigger_0) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_0_MASK) | (intr_trigger_0 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_0_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_1(mp2_pic0_level_0_reg, intr_trigger_1) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_1_MASK) | (intr_trigger_1 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_1_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_2(mp2_pic0_level_0_reg, intr_trigger_2) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_2_MASK) | (intr_trigger_2 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_2_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_3(mp2_pic0_level_0_reg, intr_trigger_3) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_3_MASK) | (intr_trigger_3 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_3_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_4(mp2_pic0_level_0_reg, intr_trigger_4) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_4_MASK) | (intr_trigger_4 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_4_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_5(mp2_pic0_level_0_reg, intr_trigger_5) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_5_MASK) | (intr_trigger_5 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_5_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_6(mp2_pic0_level_0_reg, intr_trigger_6) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_6_MASK) | (intr_trigger_6 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_6_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_7(mp2_pic0_level_0_reg, intr_trigger_7) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_7_MASK) | (intr_trigger_7 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_7_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_8(mp2_pic0_level_0_reg, intr_trigger_8) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_8_MASK) | (intr_trigger_8 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_8_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_9(mp2_pic0_level_0_reg, intr_trigger_9) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_9_MASK) | (intr_trigger_9 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_9_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_10(mp2_pic0_level_0_reg, intr_trigger_10) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_10_MASK) | (intr_trigger_10 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_10_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_11(mp2_pic0_level_0_reg, intr_trigger_11) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_11_MASK) | (intr_trigger_11 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_11_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_12(mp2_pic0_level_0_reg, intr_trigger_12) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_12_MASK) | (intr_trigger_12 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_12_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_13(mp2_pic0_level_0_reg, intr_trigger_13) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_13_MASK) | (intr_trigger_13 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_13_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_14(mp2_pic0_level_0_reg, intr_trigger_14) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_14_MASK) | (intr_trigger_14 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_14_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_15(mp2_pic0_level_0_reg, intr_trigger_15) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_15_MASK) | (intr_trigger_15 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_15_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_16(mp2_pic0_level_0_reg, intr_trigger_16) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_16_MASK) | (intr_trigger_16 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_16_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_17(mp2_pic0_level_0_reg, intr_trigger_17) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_17_MASK) | (intr_trigger_17 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_17_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_18(mp2_pic0_level_0_reg, intr_trigger_18) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_18_MASK) | (intr_trigger_18 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_18_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_19(mp2_pic0_level_0_reg, intr_trigger_19) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_19_MASK) | (intr_trigger_19 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_19_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_20(mp2_pic0_level_0_reg, intr_trigger_20) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_20_MASK) | (intr_trigger_20 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_20_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_21(mp2_pic0_level_0_reg, intr_trigger_21) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_21_MASK) | (intr_trigger_21 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_21_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_22(mp2_pic0_level_0_reg, intr_trigger_22) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_22_MASK) | (intr_trigger_22 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_22_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_23(mp2_pic0_level_0_reg, intr_trigger_23) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_23_MASK) | (intr_trigger_23 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_23_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_24(mp2_pic0_level_0_reg, intr_trigger_24) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_24_MASK) | (intr_trigger_24 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_24_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_25(mp2_pic0_level_0_reg, intr_trigger_25) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_25_MASK) | (intr_trigger_25 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_25_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_26(mp2_pic0_level_0_reg, intr_trigger_26) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_26_MASK) | (intr_trigger_26 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_26_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_27(mp2_pic0_level_0_reg, intr_trigger_27) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_27_MASK) | (intr_trigger_27 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_27_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_28(mp2_pic0_level_0_reg, intr_trigger_28) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_28_MASK) | (intr_trigger_28 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_28_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_29(mp2_pic0_level_0_reg, intr_trigger_29) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_29_MASK) | (intr_trigger_29 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_29_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_30(mp2_pic0_level_0_reg, intr_trigger_30) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_30_MASK) | (intr_trigger_30 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_30_SHIFT)
#define MP2_PIC0_LEVEL_0_SET_INTR_TRIGGER_31(mp2_pic0_level_0_reg, intr_trigger_31) \
     mp2_pic0_level_0_reg = (mp2_pic0_level_0_reg & ~MP2_PIC0_LEVEL_0_INTR_TRIGGER_31_MASK) | (intr_trigger_31 << MP2_PIC0_LEVEL_0_INTR_TRIGGER_31_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_level_0_t {
          unsigned int intr_trigger_0                 : MP2_PIC0_LEVEL_0_INTR_TRIGGER_0_SIZE;
          unsigned int intr_trigger_1                 : MP2_PIC0_LEVEL_0_INTR_TRIGGER_1_SIZE;
          unsigned int intr_trigger_2                 : MP2_PIC0_LEVEL_0_INTR_TRIGGER_2_SIZE;
          unsigned int intr_trigger_3                 : MP2_PIC0_LEVEL_0_INTR_TRIGGER_3_SIZE;
          unsigned int intr_trigger_4                 : MP2_PIC0_LEVEL_0_INTR_TRIGGER_4_SIZE;
          unsigned int intr_trigger_5                 : MP2_PIC0_LEVEL_0_INTR_TRIGGER_5_SIZE;
          unsigned int intr_trigger_6                 : MP2_PIC0_LEVEL_0_INTR_TRIGGER_6_SIZE;
          unsigned int intr_trigger_7                 : MP2_PIC0_LEVEL_0_INTR_TRIGGER_7_SIZE;
          unsigned int intr_trigger_8                 : MP2_PIC0_LEVEL_0_INTR_TRIGGER_8_SIZE;
          unsigned int intr_trigger_9                 : MP2_PIC0_LEVEL_0_INTR_TRIGGER_9_SIZE;
          unsigned int intr_trigger_10                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_10_SIZE;
          unsigned int intr_trigger_11                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_11_SIZE;
          unsigned int intr_trigger_12                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_12_SIZE;
          unsigned int intr_trigger_13                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_13_SIZE;
          unsigned int intr_trigger_14                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_14_SIZE;
          unsigned int intr_trigger_15                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_15_SIZE;
          unsigned int intr_trigger_16                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_16_SIZE;
          unsigned int intr_trigger_17                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_17_SIZE;
          unsigned int intr_trigger_18                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_18_SIZE;
          unsigned int intr_trigger_19                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_19_SIZE;
          unsigned int intr_trigger_20                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_20_SIZE;
          unsigned int intr_trigger_21                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_21_SIZE;
          unsigned int intr_trigger_22                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_22_SIZE;
          unsigned int intr_trigger_23                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_23_SIZE;
          unsigned int intr_trigger_24                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_24_SIZE;
          unsigned int intr_trigger_25                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_25_SIZE;
          unsigned int intr_trigger_26                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_26_SIZE;
          unsigned int intr_trigger_27                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_27_SIZE;
          unsigned int intr_trigger_28                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_28_SIZE;
          unsigned int intr_trigger_29                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_29_SIZE;
          unsigned int intr_trigger_30                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_30_SIZE;
          unsigned int intr_trigger_31                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_31_SIZE;
     } mp2_pic0_level_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_level_0_t {
          unsigned int intr_trigger_31                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_31_SIZE;
          unsigned int intr_trigger_30                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_30_SIZE;
          unsigned int intr_trigger_29                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_29_SIZE;
          unsigned int intr_trigger_28                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_28_SIZE;
          unsigned int intr_trigger_27                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_27_SIZE;
          unsigned int intr_trigger_26                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_26_SIZE;
          unsigned int intr_trigger_25                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_25_SIZE;
          unsigned int intr_trigger_24                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_24_SIZE;
          unsigned int intr_trigger_23                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_23_SIZE;
          unsigned int intr_trigger_22                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_22_SIZE;
          unsigned int intr_trigger_21                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_21_SIZE;
          unsigned int intr_trigger_20                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_20_SIZE;
          unsigned int intr_trigger_19                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_19_SIZE;
          unsigned int intr_trigger_18                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_18_SIZE;
          unsigned int intr_trigger_17                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_17_SIZE;
          unsigned int intr_trigger_16                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_16_SIZE;
          unsigned int intr_trigger_15                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_15_SIZE;
          unsigned int intr_trigger_14                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_14_SIZE;
          unsigned int intr_trigger_13                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_13_SIZE;
          unsigned int intr_trigger_12                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_12_SIZE;
          unsigned int intr_trigger_11                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_11_SIZE;
          unsigned int intr_trigger_10                : MP2_PIC0_LEVEL_0_INTR_TRIGGER_10_SIZE;
          unsigned int intr_trigger_9                 : MP2_PIC0_LEVEL_0_INTR_TRIGGER_9_SIZE;
          unsigned int intr_trigger_8                 : MP2_PIC0_LEVEL_0_INTR_TRIGGER_8_SIZE;
          unsigned int intr_trigger_7                 : MP2_PIC0_LEVEL_0_INTR_TRIGGER_7_SIZE;
          unsigned int intr_trigger_6                 : MP2_PIC0_LEVEL_0_INTR_TRIGGER_6_SIZE;
          unsigned int intr_trigger_5                 : MP2_PIC0_LEVEL_0_INTR_TRIGGER_5_SIZE;
          unsigned int intr_trigger_4                 : MP2_PIC0_LEVEL_0_INTR_TRIGGER_4_SIZE;
          unsigned int intr_trigger_3                 : MP2_PIC0_LEVEL_0_INTR_TRIGGER_3_SIZE;
          unsigned int intr_trigger_2                 : MP2_PIC0_LEVEL_0_INTR_TRIGGER_2_SIZE;
          unsigned int intr_trigger_1                 : MP2_PIC0_LEVEL_0_INTR_TRIGGER_1_SIZE;
          unsigned int intr_trigger_0                 : MP2_PIC0_LEVEL_0_INTR_TRIGGER_0_SIZE;
     } mp2_pic0_level_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_level_0_t f;
} mp2_pic0_level_0_u;


/*
 * MP2_PIC0_LEVEL_1 struct
 */

#define MP2_PIC0_LEVEL_1_REG_SIZE      32
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_0_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_1_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_2_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_3_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_4_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_5_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_6_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_7_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_8_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_9_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_10_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_11_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_12_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_13_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_14_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_15_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_16_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_17_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_18_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_19_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_20_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_21_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_22_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_23_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_24_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_25_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_26_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_27_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_28_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_29_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_30_SIZE 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_31_SIZE 1

#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_0_SHIFT 0
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_1_SHIFT 1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_2_SHIFT 2
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_3_SHIFT 3
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_4_SHIFT 4
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_5_SHIFT 5
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_6_SHIFT 6
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_7_SHIFT 7
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_8_SHIFT 8
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_9_SHIFT 9
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_10_SHIFT 10
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_11_SHIFT 11
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_12_SHIFT 12
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_13_SHIFT 13
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_14_SHIFT 14
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_15_SHIFT 15
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_16_SHIFT 16
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_17_SHIFT 17
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_18_SHIFT 18
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_19_SHIFT 19
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_20_SHIFT 20
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_21_SHIFT 21
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_22_SHIFT 22
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_23_SHIFT 23
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_24_SHIFT 24
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_25_SHIFT 25
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_26_SHIFT 26
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_27_SHIFT 27
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_28_SHIFT 28
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_29_SHIFT 29
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_30_SHIFT 30
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_31_SHIFT 31

#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_0_MASK 0x1
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_1_MASK 0x2
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_2_MASK 0x4
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_3_MASK 0x8
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_4_MASK 0x10
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_5_MASK 0x20
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_6_MASK 0x40
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_7_MASK 0x80
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_8_MASK 0x100
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_9_MASK 0x200
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_10_MASK 0x400
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_11_MASK 0x800
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_12_MASK 0x1000
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_13_MASK 0x2000
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_14_MASK 0x4000
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_15_MASK 0x8000
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_16_MASK 0x10000
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_17_MASK 0x20000
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_18_MASK 0x40000
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_19_MASK 0x80000
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_20_MASK 0x100000
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_21_MASK 0x200000
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_22_MASK 0x400000
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_23_MASK 0x800000
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_24_MASK 0x1000000
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_25_MASK 0x2000000
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_26_MASK 0x4000000
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_27_MASK 0x8000000
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_28_MASK 0x10000000
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_29_MASK 0x20000000
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_30_MASK 0x40000000
#define MP2_PIC0_LEVEL_1_INTR_TRIGGER_31_MASK 0x80000000

#define MP2_PIC0_LEVEL_1_MASK \
     (MP2_PIC0_LEVEL_1_INTR_TRIGGER_0_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_1_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_2_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_3_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_4_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_5_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_6_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_7_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_8_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_9_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_10_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_11_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_12_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_13_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_14_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_15_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_16_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_17_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_18_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_19_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_20_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_21_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_22_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_23_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_24_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_25_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_26_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_27_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_28_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_29_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_30_MASK | \
      MP2_PIC0_LEVEL_1_INTR_TRIGGER_31_MASK)

#define MP2_PIC0_LEVEL_1_DEFAULT       0x00000000

#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_0(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_0_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_0_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_1(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_1_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_1_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_2(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_2_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_2_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_3(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_3_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_3_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_4(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_4_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_4_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_5(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_5_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_5_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_6(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_6_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_6_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_7(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_7_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_7_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_8(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_8_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_8_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_9(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_9_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_9_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_10(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_10_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_10_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_11(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_11_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_11_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_12(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_12_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_12_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_13(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_13_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_13_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_14(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_14_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_14_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_15(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_15_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_15_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_16(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_16_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_16_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_17(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_17_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_17_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_18(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_18_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_18_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_19(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_19_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_19_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_20(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_20_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_20_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_21(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_21_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_21_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_22(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_22_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_22_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_23(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_23_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_23_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_24(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_24_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_24_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_25(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_25_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_25_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_26(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_26_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_26_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_27(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_27_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_27_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_28(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_28_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_28_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_29(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_29_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_29_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_30(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_30_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_30_SHIFT)
#define MP2_PIC0_LEVEL_1_GET_INTR_TRIGGER_31(mp2_pic0_level_1) \
     ((mp2_pic0_level_1 & MP2_PIC0_LEVEL_1_INTR_TRIGGER_31_MASK) >> MP2_PIC0_LEVEL_1_INTR_TRIGGER_31_SHIFT)

#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_0(mp2_pic0_level_1_reg, intr_trigger_0) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_0_MASK) | (intr_trigger_0 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_0_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_1(mp2_pic0_level_1_reg, intr_trigger_1) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_1_MASK) | (intr_trigger_1 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_1_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_2(mp2_pic0_level_1_reg, intr_trigger_2) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_2_MASK) | (intr_trigger_2 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_2_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_3(mp2_pic0_level_1_reg, intr_trigger_3) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_3_MASK) | (intr_trigger_3 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_3_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_4(mp2_pic0_level_1_reg, intr_trigger_4) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_4_MASK) | (intr_trigger_4 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_4_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_5(mp2_pic0_level_1_reg, intr_trigger_5) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_5_MASK) | (intr_trigger_5 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_5_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_6(mp2_pic0_level_1_reg, intr_trigger_6) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_6_MASK) | (intr_trigger_6 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_6_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_7(mp2_pic0_level_1_reg, intr_trigger_7) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_7_MASK) | (intr_trigger_7 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_7_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_8(mp2_pic0_level_1_reg, intr_trigger_8) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_8_MASK) | (intr_trigger_8 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_8_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_9(mp2_pic0_level_1_reg, intr_trigger_9) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_9_MASK) | (intr_trigger_9 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_9_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_10(mp2_pic0_level_1_reg, intr_trigger_10) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_10_MASK) | (intr_trigger_10 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_10_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_11(mp2_pic0_level_1_reg, intr_trigger_11) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_11_MASK) | (intr_trigger_11 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_11_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_12(mp2_pic0_level_1_reg, intr_trigger_12) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_12_MASK) | (intr_trigger_12 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_12_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_13(mp2_pic0_level_1_reg, intr_trigger_13) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_13_MASK) | (intr_trigger_13 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_13_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_14(mp2_pic0_level_1_reg, intr_trigger_14) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_14_MASK) | (intr_trigger_14 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_14_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_15(mp2_pic0_level_1_reg, intr_trigger_15) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_15_MASK) | (intr_trigger_15 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_15_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_16(mp2_pic0_level_1_reg, intr_trigger_16) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_16_MASK) | (intr_trigger_16 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_16_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_17(mp2_pic0_level_1_reg, intr_trigger_17) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_17_MASK) | (intr_trigger_17 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_17_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_18(mp2_pic0_level_1_reg, intr_trigger_18) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_18_MASK) | (intr_trigger_18 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_18_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_19(mp2_pic0_level_1_reg, intr_trigger_19) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_19_MASK) | (intr_trigger_19 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_19_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_20(mp2_pic0_level_1_reg, intr_trigger_20) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_20_MASK) | (intr_trigger_20 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_20_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_21(mp2_pic0_level_1_reg, intr_trigger_21) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_21_MASK) | (intr_trigger_21 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_21_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_22(mp2_pic0_level_1_reg, intr_trigger_22) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_22_MASK) | (intr_trigger_22 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_22_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_23(mp2_pic0_level_1_reg, intr_trigger_23) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_23_MASK) | (intr_trigger_23 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_23_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_24(mp2_pic0_level_1_reg, intr_trigger_24) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_24_MASK) | (intr_trigger_24 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_24_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_25(mp2_pic0_level_1_reg, intr_trigger_25) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_25_MASK) | (intr_trigger_25 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_25_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_26(mp2_pic0_level_1_reg, intr_trigger_26) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_26_MASK) | (intr_trigger_26 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_26_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_27(mp2_pic0_level_1_reg, intr_trigger_27) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_27_MASK) | (intr_trigger_27 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_27_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_28(mp2_pic0_level_1_reg, intr_trigger_28) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_28_MASK) | (intr_trigger_28 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_28_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_29(mp2_pic0_level_1_reg, intr_trigger_29) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_29_MASK) | (intr_trigger_29 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_29_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_30(mp2_pic0_level_1_reg, intr_trigger_30) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_30_MASK) | (intr_trigger_30 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_30_SHIFT)
#define MP2_PIC0_LEVEL_1_SET_INTR_TRIGGER_31(mp2_pic0_level_1_reg, intr_trigger_31) \
     mp2_pic0_level_1_reg = (mp2_pic0_level_1_reg & ~MP2_PIC0_LEVEL_1_INTR_TRIGGER_31_MASK) | (intr_trigger_31 << MP2_PIC0_LEVEL_1_INTR_TRIGGER_31_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_level_1_t {
          unsigned int intr_trigger_0                 : MP2_PIC0_LEVEL_1_INTR_TRIGGER_0_SIZE;
          unsigned int intr_trigger_1                 : MP2_PIC0_LEVEL_1_INTR_TRIGGER_1_SIZE;
          unsigned int intr_trigger_2                 : MP2_PIC0_LEVEL_1_INTR_TRIGGER_2_SIZE;
          unsigned int intr_trigger_3                 : MP2_PIC0_LEVEL_1_INTR_TRIGGER_3_SIZE;
          unsigned int intr_trigger_4                 : MP2_PIC0_LEVEL_1_INTR_TRIGGER_4_SIZE;
          unsigned int intr_trigger_5                 : MP2_PIC0_LEVEL_1_INTR_TRIGGER_5_SIZE;
          unsigned int intr_trigger_6                 : MP2_PIC0_LEVEL_1_INTR_TRIGGER_6_SIZE;
          unsigned int intr_trigger_7                 : MP2_PIC0_LEVEL_1_INTR_TRIGGER_7_SIZE;
          unsigned int intr_trigger_8                 : MP2_PIC0_LEVEL_1_INTR_TRIGGER_8_SIZE;
          unsigned int intr_trigger_9                 : MP2_PIC0_LEVEL_1_INTR_TRIGGER_9_SIZE;
          unsigned int intr_trigger_10                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_10_SIZE;
          unsigned int intr_trigger_11                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_11_SIZE;
          unsigned int intr_trigger_12                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_12_SIZE;
          unsigned int intr_trigger_13                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_13_SIZE;
          unsigned int intr_trigger_14                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_14_SIZE;
          unsigned int intr_trigger_15                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_15_SIZE;
          unsigned int intr_trigger_16                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_16_SIZE;
          unsigned int intr_trigger_17                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_17_SIZE;
          unsigned int intr_trigger_18                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_18_SIZE;
          unsigned int intr_trigger_19                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_19_SIZE;
          unsigned int intr_trigger_20                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_20_SIZE;
          unsigned int intr_trigger_21                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_21_SIZE;
          unsigned int intr_trigger_22                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_22_SIZE;
          unsigned int intr_trigger_23                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_23_SIZE;
          unsigned int intr_trigger_24                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_24_SIZE;
          unsigned int intr_trigger_25                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_25_SIZE;
          unsigned int intr_trigger_26                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_26_SIZE;
          unsigned int intr_trigger_27                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_27_SIZE;
          unsigned int intr_trigger_28                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_28_SIZE;
          unsigned int intr_trigger_29                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_29_SIZE;
          unsigned int intr_trigger_30                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_30_SIZE;
          unsigned int intr_trigger_31                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_31_SIZE;
     } mp2_pic0_level_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_level_1_t {
          unsigned int intr_trigger_31                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_31_SIZE;
          unsigned int intr_trigger_30                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_30_SIZE;
          unsigned int intr_trigger_29                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_29_SIZE;
          unsigned int intr_trigger_28                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_28_SIZE;
          unsigned int intr_trigger_27                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_27_SIZE;
          unsigned int intr_trigger_26                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_26_SIZE;
          unsigned int intr_trigger_25                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_25_SIZE;
          unsigned int intr_trigger_24                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_24_SIZE;
          unsigned int intr_trigger_23                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_23_SIZE;
          unsigned int intr_trigger_22                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_22_SIZE;
          unsigned int intr_trigger_21                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_21_SIZE;
          unsigned int intr_trigger_20                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_20_SIZE;
          unsigned int intr_trigger_19                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_19_SIZE;
          unsigned int intr_trigger_18                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_18_SIZE;
          unsigned int intr_trigger_17                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_17_SIZE;
          unsigned int intr_trigger_16                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_16_SIZE;
          unsigned int intr_trigger_15                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_15_SIZE;
          unsigned int intr_trigger_14                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_14_SIZE;
          unsigned int intr_trigger_13                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_13_SIZE;
          unsigned int intr_trigger_12                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_12_SIZE;
          unsigned int intr_trigger_11                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_11_SIZE;
          unsigned int intr_trigger_10                : MP2_PIC0_LEVEL_1_INTR_TRIGGER_10_SIZE;
          unsigned int intr_trigger_9                 : MP2_PIC0_LEVEL_1_INTR_TRIGGER_9_SIZE;
          unsigned int intr_trigger_8                 : MP2_PIC0_LEVEL_1_INTR_TRIGGER_8_SIZE;
          unsigned int intr_trigger_7                 : MP2_PIC0_LEVEL_1_INTR_TRIGGER_7_SIZE;
          unsigned int intr_trigger_6                 : MP2_PIC0_LEVEL_1_INTR_TRIGGER_6_SIZE;
          unsigned int intr_trigger_5                 : MP2_PIC0_LEVEL_1_INTR_TRIGGER_5_SIZE;
          unsigned int intr_trigger_4                 : MP2_PIC0_LEVEL_1_INTR_TRIGGER_4_SIZE;
          unsigned int intr_trigger_3                 : MP2_PIC0_LEVEL_1_INTR_TRIGGER_3_SIZE;
          unsigned int intr_trigger_2                 : MP2_PIC0_LEVEL_1_INTR_TRIGGER_2_SIZE;
          unsigned int intr_trigger_1                 : MP2_PIC0_LEVEL_1_INTR_TRIGGER_1_SIZE;
          unsigned int intr_trigger_0                 : MP2_PIC0_LEVEL_1_INTR_TRIGGER_0_SIZE;
     } mp2_pic0_level_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_level_1_t f;
} mp2_pic0_level_1_u;


/*
 * MP2_PIC0_LEVEL_2 struct
 */

#define MP2_PIC0_LEVEL_2_REG_SIZE      32
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_0_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_1_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_2_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_3_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_4_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_5_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_6_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_7_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_8_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_9_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_10_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_11_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_12_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_13_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_14_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_15_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_16_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_17_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_18_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_19_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_20_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_21_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_22_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_23_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_24_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_25_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_26_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_27_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_28_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_29_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_30_SIZE 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_31_SIZE 1

#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_0_SHIFT 0
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_1_SHIFT 1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_2_SHIFT 2
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_3_SHIFT 3
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_4_SHIFT 4
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_5_SHIFT 5
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_6_SHIFT 6
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_7_SHIFT 7
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_8_SHIFT 8
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_9_SHIFT 9
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_10_SHIFT 10
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_11_SHIFT 11
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_12_SHIFT 12
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_13_SHIFT 13
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_14_SHIFT 14
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_15_SHIFT 15
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_16_SHIFT 16
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_17_SHIFT 17
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_18_SHIFT 18
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_19_SHIFT 19
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_20_SHIFT 20
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_21_SHIFT 21
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_22_SHIFT 22
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_23_SHIFT 23
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_24_SHIFT 24
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_25_SHIFT 25
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_26_SHIFT 26
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_27_SHIFT 27
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_28_SHIFT 28
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_29_SHIFT 29
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_30_SHIFT 30
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_31_SHIFT 31

#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_0_MASK 0x1
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_1_MASK 0x2
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_2_MASK 0x4
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_3_MASK 0x8
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_4_MASK 0x10
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_5_MASK 0x20
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_6_MASK 0x40
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_7_MASK 0x80
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_8_MASK 0x100
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_9_MASK 0x200
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_10_MASK 0x400
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_11_MASK 0x800
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_12_MASK 0x1000
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_13_MASK 0x2000
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_14_MASK 0x4000
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_15_MASK 0x8000
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_16_MASK 0x10000
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_17_MASK 0x20000
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_18_MASK 0x40000
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_19_MASK 0x80000
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_20_MASK 0x100000
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_21_MASK 0x200000
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_22_MASK 0x400000
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_23_MASK 0x800000
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_24_MASK 0x1000000
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_25_MASK 0x2000000
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_26_MASK 0x4000000
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_27_MASK 0x8000000
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_28_MASK 0x10000000
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_29_MASK 0x20000000
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_30_MASK 0x40000000
#define MP2_PIC0_LEVEL_2_INTR_TRIGGER_31_MASK 0x80000000

#define MP2_PIC0_LEVEL_2_MASK \
     (MP2_PIC0_LEVEL_2_INTR_TRIGGER_0_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_1_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_2_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_3_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_4_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_5_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_6_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_7_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_8_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_9_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_10_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_11_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_12_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_13_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_14_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_15_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_16_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_17_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_18_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_19_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_20_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_21_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_22_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_23_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_24_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_25_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_26_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_27_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_28_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_29_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_30_MASK | \
      MP2_PIC0_LEVEL_2_INTR_TRIGGER_31_MASK)

#define MP2_PIC0_LEVEL_2_DEFAULT       0x00000000

#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_0(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_0_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_0_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_1(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_1_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_1_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_2(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_2_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_2_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_3(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_3_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_3_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_4(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_4_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_4_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_5(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_5_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_5_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_6(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_6_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_6_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_7(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_7_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_7_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_8(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_8_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_8_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_9(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_9_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_9_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_10(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_10_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_10_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_11(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_11_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_11_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_12(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_12_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_12_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_13(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_13_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_13_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_14(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_14_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_14_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_15(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_15_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_15_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_16(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_16_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_16_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_17(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_17_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_17_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_18(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_18_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_18_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_19(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_19_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_19_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_20(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_20_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_20_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_21(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_21_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_21_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_22(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_22_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_22_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_23(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_23_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_23_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_24(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_24_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_24_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_25(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_25_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_25_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_26(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_26_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_26_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_27(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_27_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_27_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_28(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_28_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_28_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_29(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_29_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_29_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_30(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_30_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_30_SHIFT)
#define MP2_PIC0_LEVEL_2_GET_INTR_TRIGGER_31(mp2_pic0_level_2) \
     ((mp2_pic0_level_2 & MP2_PIC0_LEVEL_2_INTR_TRIGGER_31_MASK) >> MP2_PIC0_LEVEL_2_INTR_TRIGGER_31_SHIFT)

#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_0(mp2_pic0_level_2_reg, intr_trigger_0) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_0_MASK) | (intr_trigger_0 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_0_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_1(mp2_pic0_level_2_reg, intr_trigger_1) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_1_MASK) | (intr_trigger_1 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_1_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_2(mp2_pic0_level_2_reg, intr_trigger_2) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_2_MASK) | (intr_trigger_2 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_2_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_3(mp2_pic0_level_2_reg, intr_trigger_3) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_3_MASK) | (intr_trigger_3 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_3_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_4(mp2_pic0_level_2_reg, intr_trigger_4) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_4_MASK) | (intr_trigger_4 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_4_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_5(mp2_pic0_level_2_reg, intr_trigger_5) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_5_MASK) | (intr_trigger_5 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_5_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_6(mp2_pic0_level_2_reg, intr_trigger_6) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_6_MASK) | (intr_trigger_6 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_6_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_7(mp2_pic0_level_2_reg, intr_trigger_7) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_7_MASK) | (intr_trigger_7 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_7_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_8(mp2_pic0_level_2_reg, intr_trigger_8) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_8_MASK) | (intr_trigger_8 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_8_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_9(mp2_pic0_level_2_reg, intr_trigger_9) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_9_MASK) | (intr_trigger_9 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_9_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_10(mp2_pic0_level_2_reg, intr_trigger_10) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_10_MASK) | (intr_trigger_10 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_10_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_11(mp2_pic0_level_2_reg, intr_trigger_11) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_11_MASK) | (intr_trigger_11 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_11_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_12(mp2_pic0_level_2_reg, intr_trigger_12) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_12_MASK) | (intr_trigger_12 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_12_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_13(mp2_pic0_level_2_reg, intr_trigger_13) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_13_MASK) | (intr_trigger_13 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_13_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_14(mp2_pic0_level_2_reg, intr_trigger_14) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_14_MASK) | (intr_trigger_14 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_14_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_15(mp2_pic0_level_2_reg, intr_trigger_15) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_15_MASK) | (intr_trigger_15 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_15_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_16(mp2_pic0_level_2_reg, intr_trigger_16) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_16_MASK) | (intr_trigger_16 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_16_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_17(mp2_pic0_level_2_reg, intr_trigger_17) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_17_MASK) | (intr_trigger_17 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_17_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_18(mp2_pic0_level_2_reg, intr_trigger_18) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_18_MASK) | (intr_trigger_18 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_18_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_19(mp2_pic0_level_2_reg, intr_trigger_19) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_19_MASK) | (intr_trigger_19 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_19_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_20(mp2_pic0_level_2_reg, intr_trigger_20) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_20_MASK) | (intr_trigger_20 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_20_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_21(mp2_pic0_level_2_reg, intr_trigger_21) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_21_MASK) | (intr_trigger_21 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_21_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_22(mp2_pic0_level_2_reg, intr_trigger_22) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_22_MASK) | (intr_trigger_22 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_22_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_23(mp2_pic0_level_2_reg, intr_trigger_23) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_23_MASK) | (intr_trigger_23 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_23_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_24(mp2_pic0_level_2_reg, intr_trigger_24) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_24_MASK) | (intr_trigger_24 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_24_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_25(mp2_pic0_level_2_reg, intr_trigger_25) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_25_MASK) | (intr_trigger_25 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_25_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_26(mp2_pic0_level_2_reg, intr_trigger_26) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_26_MASK) | (intr_trigger_26 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_26_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_27(mp2_pic0_level_2_reg, intr_trigger_27) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_27_MASK) | (intr_trigger_27 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_27_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_28(mp2_pic0_level_2_reg, intr_trigger_28) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_28_MASK) | (intr_trigger_28 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_28_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_29(mp2_pic0_level_2_reg, intr_trigger_29) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_29_MASK) | (intr_trigger_29 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_29_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_30(mp2_pic0_level_2_reg, intr_trigger_30) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_30_MASK) | (intr_trigger_30 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_30_SHIFT)
#define MP2_PIC0_LEVEL_2_SET_INTR_TRIGGER_31(mp2_pic0_level_2_reg, intr_trigger_31) \
     mp2_pic0_level_2_reg = (mp2_pic0_level_2_reg & ~MP2_PIC0_LEVEL_2_INTR_TRIGGER_31_MASK) | (intr_trigger_31 << MP2_PIC0_LEVEL_2_INTR_TRIGGER_31_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_level_2_t {
          unsigned int intr_trigger_0                 : MP2_PIC0_LEVEL_2_INTR_TRIGGER_0_SIZE;
          unsigned int intr_trigger_1                 : MP2_PIC0_LEVEL_2_INTR_TRIGGER_1_SIZE;
          unsigned int intr_trigger_2                 : MP2_PIC0_LEVEL_2_INTR_TRIGGER_2_SIZE;
          unsigned int intr_trigger_3                 : MP2_PIC0_LEVEL_2_INTR_TRIGGER_3_SIZE;
          unsigned int intr_trigger_4                 : MP2_PIC0_LEVEL_2_INTR_TRIGGER_4_SIZE;
          unsigned int intr_trigger_5                 : MP2_PIC0_LEVEL_2_INTR_TRIGGER_5_SIZE;
          unsigned int intr_trigger_6                 : MP2_PIC0_LEVEL_2_INTR_TRIGGER_6_SIZE;
          unsigned int intr_trigger_7                 : MP2_PIC0_LEVEL_2_INTR_TRIGGER_7_SIZE;
          unsigned int intr_trigger_8                 : MP2_PIC0_LEVEL_2_INTR_TRIGGER_8_SIZE;
          unsigned int intr_trigger_9                 : MP2_PIC0_LEVEL_2_INTR_TRIGGER_9_SIZE;
          unsigned int intr_trigger_10                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_10_SIZE;
          unsigned int intr_trigger_11                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_11_SIZE;
          unsigned int intr_trigger_12                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_12_SIZE;
          unsigned int intr_trigger_13                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_13_SIZE;
          unsigned int intr_trigger_14                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_14_SIZE;
          unsigned int intr_trigger_15                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_15_SIZE;
          unsigned int intr_trigger_16                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_16_SIZE;
          unsigned int intr_trigger_17                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_17_SIZE;
          unsigned int intr_trigger_18                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_18_SIZE;
          unsigned int intr_trigger_19                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_19_SIZE;
          unsigned int intr_trigger_20                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_20_SIZE;
          unsigned int intr_trigger_21                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_21_SIZE;
          unsigned int intr_trigger_22                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_22_SIZE;
          unsigned int intr_trigger_23                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_23_SIZE;
          unsigned int intr_trigger_24                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_24_SIZE;
          unsigned int intr_trigger_25                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_25_SIZE;
          unsigned int intr_trigger_26                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_26_SIZE;
          unsigned int intr_trigger_27                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_27_SIZE;
          unsigned int intr_trigger_28                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_28_SIZE;
          unsigned int intr_trigger_29                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_29_SIZE;
          unsigned int intr_trigger_30                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_30_SIZE;
          unsigned int intr_trigger_31                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_31_SIZE;
     } mp2_pic0_level_2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_level_2_t {
          unsigned int intr_trigger_31                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_31_SIZE;
          unsigned int intr_trigger_30                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_30_SIZE;
          unsigned int intr_trigger_29                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_29_SIZE;
          unsigned int intr_trigger_28                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_28_SIZE;
          unsigned int intr_trigger_27                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_27_SIZE;
          unsigned int intr_trigger_26                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_26_SIZE;
          unsigned int intr_trigger_25                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_25_SIZE;
          unsigned int intr_trigger_24                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_24_SIZE;
          unsigned int intr_trigger_23                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_23_SIZE;
          unsigned int intr_trigger_22                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_22_SIZE;
          unsigned int intr_trigger_21                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_21_SIZE;
          unsigned int intr_trigger_20                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_20_SIZE;
          unsigned int intr_trigger_19                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_19_SIZE;
          unsigned int intr_trigger_18                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_18_SIZE;
          unsigned int intr_trigger_17                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_17_SIZE;
          unsigned int intr_trigger_16                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_16_SIZE;
          unsigned int intr_trigger_15                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_15_SIZE;
          unsigned int intr_trigger_14                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_14_SIZE;
          unsigned int intr_trigger_13                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_13_SIZE;
          unsigned int intr_trigger_12                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_12_SIZE;
          unsigned int intr_trigger_11                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_11_SIZE;
          unsigned int intr_trigger_10                : MP2_PIC0_LEVEL_2_INTR_TRIGGER_10_SIZE;
          unsigned int intr_trigger_9                 : MP2_PIC0_LEVEL_2_INTR_TRIGGER_9_SIZE;
          unsigned int intr_trigger_8                 : MP2_PIC0_LEVEL_2_INTR_TRIGGER_8_SIZE;
          unsigned int intr_trigger_7                 : MP2_PIC0_LEVEL_2_INTR_TRIGGER_7_SIZE;
          unsigned int intr_trigger_6                 : MP2_PIC0_LEVEL_2_INTR_TRIGGER_6_SIZE;
          unsigned int intr_trigger_5                 : MP2_PIC0_LEVEL_2_INTR_TRIGGER_5_SIZE;
          unsigned int intr_trigger_4                 : MP2_PIC0_LEVEL_2_INTR_TRIGGER_4_SIZE;
          unsigned int intr_trigger_3                 : MP2_PIC0_LEVEL_2_INTR_TRIGGER_3_SIZE;
          unsigned int intr_trigger_2                 : MP2_PIC0_LEVEL_2_INTR_TRIGGER_2_SIZE;
          unsigned int intr_trigger_1                 : MP2_PIC0_LEVEL_2_INTR_TRIGGER_1_SIZE;
          unsigned int intr_trigger_0                 : MP2_PIC0_LEVEL_2_INTR_TRIGGER_0_SIZE;
     } mp2_pic0_level_2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_level_2_t f;
} mp2_pic0_level_2_u;


/*
 * MP2_PIC0_LEVEL_3 struct
 */

#define MP2_PIC0_LEVEL_3_REG_SIZE      32
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_0_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_1_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_2_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_3_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_4_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_5_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_6_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_7_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_8_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_9_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_10_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_11_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_12_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_13_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_14_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_15_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_16_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_17_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_18_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_19_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_20_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_21_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_22_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_23_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_24_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_25_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_26_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_27_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_28_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_29_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_30_SIZE 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_31_SIZE 1

#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_0_SHIFT 0
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_1_SHIFT 1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_2_SHIFT 2
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_3_SHIFT 3
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_4_SHIFT 4
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_5_SHIFT 5
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_6_SHIFT 6
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_7_SHIFT 7
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_8_SHIFT 8
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_9_SHIFT 9
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_10_SHIFT 10
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_11_SHIFT 11
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_12_SHIFT 12
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_13_SHIFT 13
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_14_SHIFT 14
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_15_SHIFT 15
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_16_SHIFT 16
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_17_SHIFT 17
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_18_SHIFT 18
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_19_SHIFT 19
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_20_SHIFT 20
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_21_SHIFT 21
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_22_SHIFT 22
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_23_SHIFT 23
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_24_SHIFT 24
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_25_SHIFT 25
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_26_SHIFT 26
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_27_SHIFT 27
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_28_SHIFT 28
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_29_SHIFT 29
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_30_SHIFT 30
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_31_SHIFT 31

#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_0_MASK 0x1
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_1_MASK 0x2
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_2_MASK 0x4
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_3_MASK 0x8
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_4_MASK 0x10
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_5_MASK 0x20
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_6_MASK 0x40
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_7_MASK 0x80
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_8_MASK 0x100
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_9_MASK 0x200
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_10_MASK 0x400
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_11_MASK 0x800
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_12_MASK 0x1000
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_13_MASK 0x2000
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_14_MASK 0x4000
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_15_MASK 0x8000
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_16_MASK 0x10000
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_17_MASK 0x20000
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_18_MASK 0x40000
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_19_MASK 0x80000
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_20_MASK 0x100000
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_21_MASK 0x200000
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_22_MASK 0x400000
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_23_MASK 0x800000
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_24_MASK 0x1000000
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_25_MASK 0x2000000
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_26_MASK 0x4000000
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_27_MASK 0x8000000
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_28_MASK 0x10000000
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_29_MASK 0x20000000
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_30_MASK 0x40000000
#define MP2_PIC0_LEVEL_3_INTR_TRIGGER_31_MASK 0x80000000

#define MP2_PIC0_LEVEL_3_MASK \
     (MP2_PIC0_LEVEL_3_INTR_TRIGGER_0_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_1_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_2_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_3_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_4_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_5_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_6_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_7_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_8_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_9_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_10_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_11_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_12_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_13_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_14_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_15_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_16_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_17_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_18_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_19_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_20_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_21_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_22_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_23_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_24_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_25_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_26_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_27_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_28_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_29_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_30_MASK | \
      MP2_PIC0_LEVEL_3_INTR_TRIGGER_31_MASK)

#define MP2_PIC0_LEVEL_3_DEFAULT       0x00000000

#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_0(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_0_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_0_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_1(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_1_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_1_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_2(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_2_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_2_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_3(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_3_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_3_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_4(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_4_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_4_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_5(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_5_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_5_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_6(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_6_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_6_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_7(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_7_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_7_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_8(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_8_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_8_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_9(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_9_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_9_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_10(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_10_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_10_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_11(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_11_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_11_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_12(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_12_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_12_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_13(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_13_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_13_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_14(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_14_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_14_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_15(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_15_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_15_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_16(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_16_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_16_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_17(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_17_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_17_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_18(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_18_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_18_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_19(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_19_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_19_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_20(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_20_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_20_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_21(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_21_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_21_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_22(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_22_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_22_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_23(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_23_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_23_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_24(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_24_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_24_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_25(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_25_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_25_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_26(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_26_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_26_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_27(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_27_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_27_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_28(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_28_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_28_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_29(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_29_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_29_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_30(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_30_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_30_SHIFT)
#define MP2_PIC0_LEVEL_3_GET_INTR_TRIGGER_31(mp2_pic0_level_3) \
     ((mp2_pic0_level_3 & MP2_PIC0_LEVEL_3_INTR_TRIGGER_31_MASK) >> MP2_PIC0_LEVEL_3_INTR_TRIGGER_31_SHIFT)

#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_0(mp2_pic0_level_3_reg, intr_trigger_0) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_0_MASK) | (intr_trigger_0 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_0_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_1(mp2_pic0_level_3_reg, intr_trigger_1) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_1_MASK) | (intr_trigger_1 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_1_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_2(mp2_pic0_level_3_reg, intr_trigger_2) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_2_MASK) | (intr_trigger_2 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_2_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_3(mp2_pic0_level_3_reg, intr_trigger_3) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_3_MASK) | (intr_trigger_3 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_3_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_4(mp2_pic0_level_3_reg, intr_trigger_4) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_4_MASK) | (intr_trigger_4 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_4_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_5(mp2_pic0_level_3_reg, intr_trigger_5) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_5_MASK) | (intr_trigger_5 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_5_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_6(mp2_pic0_level_3_reg, intr_trigger_6) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_6_MASK) | (intr_trigger_6 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_6_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_7(mp2_pic0_level_3_reg, intr_trigger_7) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_7_MASK) | (intr_trigger_7 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_7_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_8(mp2_pic0_level_3_reg, intr_trigger_8) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_8_MASK) | (intr_trigger_8 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_8_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_9(mp2_pic0_level_3_reg, intr_trigger_9) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_9_MASK) | (intr_trigger_9 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_9_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_10(mp2_pic0_level_3_reg, intr_trigger_10) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_10_MASK) | (intr_trigger_10 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_10_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_11(mp2_pic0_level_3_reg, intr_trigger_11) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_11_MASK) | (intr_trigger_11 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_11_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_12(mp2_pic0_level_3_reg, intr_trigger_12) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_12_MASK) | (intr_trigger_12 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_12_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_13(mp2_pic0_level_3_reg, intr_trigger_13) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_13_MASK) | (intr_trigger_13 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_13_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_14(mp2_pic0_level_3_reg, intr_trigger_14) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_14_MASK) | (intr_trigger_14 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_14_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_15(mp2_pic0_level_3_reg, intr_trigger_15) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_15_MASK) | (intr_trigger_15 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_15_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_16(mp2_pic0_level_3_reg, intr_trigger_16) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_16_MASK) | (intr_trigger_16 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_16_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_17(mp2_pic0_level_3_reg, intr_trigger_17) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_17_MASK) | (intr_trigger_17 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_17_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_18(mp2_pic0_level_3_reg, intr_trigger_18) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_18_MASK) | (intr_trigger_18 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_18_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_19(mp2_pic0_level_3_reg, intr_trigger_19) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_19_MASK) | (intr_trigger_19 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_19_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_20(mp2_pic0_level_3_reg, intr_trigger_20) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_20_MASK) | (intr_trigger_20 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_20_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_21(mp2_pic0_level_3_reg, intr_trigger_21) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_21_MASK) | (intr_trigger_21 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_21_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_22(mp2_pic0_level_3_reg, intr_trigger_22) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_22_MASK) | (intr_trigger_22 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_22_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_23(mp2_pic0_level_3_reg, intr_trigger_23) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_23_MASK) | (intr_trigger_23 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_23_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_24(mp2_pic0_level_3_reg, intr_trigger_24) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_24_MASK) | (intr_trigger_24 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_24_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_25(mp2_pic0_level_3_reg, intr_trigger_25) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_25_MASK) | (intr_trigger_25 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_25_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_26(mp2_pic0_level_3_reg, intr_trigger_26) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_26_MASK) | (intr_trigger_26 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_26_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_27(mp2_pic0_level_3_reg, intr_trigger_27) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_27_MASK) | (intr_trigger_27 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_27_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_28(mp2_pic0_level_3_reg, intr_trigger_28) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_28_MASK) | (intr_trigger_28 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_28_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_29(mp2_pic0_level_3_reg, intr_trigger_29) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_29_MASK) | (intr_trigger_29 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_29_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_30(mp2_pic0_level_3_reg, intr_trigger_30) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_30_MASK) | (intr_trigger_30 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_30_SHIFT)
#define MP2_PIC0_LEVEL_3_SET_INTR_TRIGGER_31(mp2_pic0_level_3_reg, intr_trigger_31) \
     mp2_pic0_level_3_reg = (mp2_pic0_level_3_reg & ~MP2_PIC0_LEVEL_3_INTR_TRIGGER_31_MASK) | (intr_trigger_31 << MP2_PIC0_LEVEL_3_INTR_TRIGGER_31_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_level_3_t {
          unsigned int intr_trigger_0                 : MP2_PIC0_LEVEL_3_INTR_TRIGGER_0_SIZE;
          unsigned int intr_trigger_1                 : MP2_PIC0_LEVEL_3_INTR_TRIGGER_1_SIZE;
          unsigned int intr_trigger_2                 : MP2_PIC0_LEVEL_3_INTR_TRIGGER_2_SIZE;
          unsigned int intr_trigger_3                 : MP2_PIC0_LEVEL_3_INTR_TRIGGER_3_SIZE;
          unsigned int intr_trigger_4                 : MP2_PIC0_LEVEL_3_INTR_TRIGGER_4_SIZE;
          unsigned int intr_trigger_5                 : MP2_PIC0_LEVEL_3_INTR_TRIGGER_5_SIZE;
          unsigned int intr_trigger_6                 : MP2_PIC0_LEVEL_3_INTR_TRIGGER_6_SIZE;
          unsigned int intr_trigger_7                 : MP2_PIC0_LEVEL_3_INTR_TRIGGER_7_SIZE;
          unsigned int intr_trigger_8                 : MP2_PIC0_LEVEL_3_INTR_TRIGGER_8_SIZE;
          unsigned int intr_trigger_9                 : MP2_PIC0_LEVEL_3_INTR_TRIGGER_9_SIZE;
          unsigned int intr_trigger_10                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_10_SIZE;
          unsigned int intr_trigger_11                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_11_SIZE;
          unsigned int intr_trigger_12                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_12_SIZE;
          unsigned int intr_trigger_13                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_13_SIZE;
          unsigned int intr_trigger_14                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_14_SIZE;
          unsigned int intr_trigger_15                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_15_SIZE;
          unsigned int intr_trigger_16                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_16_SIZE;
          unsigned int intr_trigger_17                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_17_SIZE;
          unsigned int intr_trigger_18                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_18_SIZE;
          unsigned int intr_trigger_19                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_19_SIZE;
          unsigned int intr_trigger_20                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_20_SIZE;
          unsigned int intr_trigger_21                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_21_SIZE;
          unsigned int intr_trigger_22                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_22_SIZE;
          unsigned int intr_trigger_23                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_23_SIZE;
          unsigned int intr_trigger_24                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_24_SIZE;
          unsigned int intr_trigger_25                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_25_SIZE;
          unsigned int intr_trigger_26                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_26_SIZE;
          unsigned int intr_trigger_27                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_27_SIZE;
          unsigned int intr_trigger_28                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_28_SIZE;
          unsigned int intr_trigger_29                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_29_SIZE;
          unsigned int intr_trigger_30                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_30_SIZE;
          unsigned int intr_trigger_31                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_31_SIZE;
     } mp2_pic0_level_3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_level_3_t {
          unsigned int intr_trigger_31                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_31_SIZE;
          unsigned int intr_trigger_30                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_30_SIZE;
          unsigned int intr_trigger_29                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_29_SIZE;
          unsigned int intr_trigger_28                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_28_SIZE;
          unsigned int intr_trigger_27                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_27_SIZE;
          unsigned int intr_trigger_26                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_26_SIZE;
          unsigned int intr_trigger_25                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_25_SIZE;
          unsigned int intr_trigger_24                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_24_SIZE;
          unsigned int intr_trigger_23                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_23_SIZE;
          unsigned int intr_trigger_22                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_22_SIZE;
          unsigned int intr_trigger_21                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_21_SIZE;
          unsigned int intr_trigger_20                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_20_SIZE;
          unsigned int intr_trigger_19                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_19_SIZE;
          unsigned int intr_trigger_18                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_18_SIZE;
          unsigned int intr_trigger_17                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_17_SIZE;
          unsigned int intr_trigger_16                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_16_SIZE;
          unsigned int intr_trigger_15                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_15_SIZE;
          unsigned int intr_trigger_14                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_14_SIZE;
          unsigned int intr_trigger_13                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_13_SIZE;
          unsigned int intr_trigger_12                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_12_SIZE;
          unsigned int intr_trigger_11                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_11_SIZE;
          unsigned int intr_trigger_10                : MP2_PIC0_LEVEL_3_INTR_TRIGGER_10_SIZE;
          unsigned int intr_trigger_9                 : MP2_PIC0_LEVEL_3_INTR_TRIGGER_9_SIZE;
          unsigned int intr_trigger_8                 : MP2_PIC0_LEVEL_3_INTR_TRIGGER_8_SIZE;
          unsigned int intr_trigger_7                 : MP2_PIC0_LEVEL_3_INTR_TRIGGER_7_SIZE;
          unsigned int intr_trigger_6                 : MP2_PIC0_LEVEL_3_INTR_TRIGGER_6_SIZE;
          unsigned int intr_trigger_5                 : MP2_PIC0_LEVEL_3_INTR_TRIGGER_5_SIZE;
          unsigned int intr_trigger_4                 : MP2_PIC0_LEVEL_3_INTR_TRIGGER_4_SIZE;
          unsigned int intr_trigger_3                 : MP2_PIC0_LEVEL_3_INTR_TRIGGER_3_SIZE;
          unsigned int intr_trigger_2                 : MP2_PIC0_LEVEL_3_INTR_TRIGGER_2_SIZE;
          unsigned int intr_trigger_1                 : MP2_PIC0_LEVEL_3_INTR_TRIGGER_1_SIZE;
          unsigned int intr_trigger_0                 : MP2_PIC0_LEVEL_3_INTR_TRIGGER_0_SIZE;
     } mp2_pic0_level_3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_level_3_t f;
} mp2_pic0_level_3_u;


/*
 * MP2_PIC0_EDGE_0 struct
 */

#define MP2_PIC0_EDGE_0_REG_SIZE       32
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_0_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_1_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_2_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_3_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_4_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_5_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_6_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_7_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_8_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_9_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_10_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_11_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_12_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_13_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_14_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_15_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_16_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_17_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_18_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_19_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_20_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_21_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_22_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_23_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_24_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_25_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_26_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_27_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_28_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_29_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_30_SIZE 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_31_SIZE 1

#define MP2_PIC0_EDGE_0_INTR_TRIGGER_0_SHIFT 0
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_1_SHIFT 1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_2_SHIFT 2
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_3_SHIFT 3
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_4_SHIFT 4
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_5_SHIFT 5
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_6_SHIFT 6
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_7_SHIFT 7
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_8_SHIFT 8
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_9_SHIFT 9
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_10_SHIFT 10
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_11_SHIFT 11
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_12_SHIFT 12
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_13_SHIFT 13
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_14_SHIFT 14
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_15_SHIFT 15
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_16_SHIFT 16
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_17_SHIFT 17
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_18_SHIFT 18
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_19_SHIFT 19
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_20_SHIFT 20
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_21_SHIFT 21
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_22_SHIFT 22
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_23_SHIFT 23
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_24_SHIFT 24
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_25_SHIFT 25
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_26_SHIFT 26
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_27_SHIFT 27
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_28_SHIFT 28
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_29_SHIFT 29
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_30_SHIFT 30
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_31_SHIFT 31

#define MP2_PIC0_EDGE_0_INTR_TRIGGER_0_MASK 0x1
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_1_MASK 0x2
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_2_MASK 0x4
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_3_MASK 0x8
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_4_MASK 0x10
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_5_MASK 0x20
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_6_MASK 0x40
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_7_MASK 0x80
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_8_MASK 0x100
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_9_MASK 0x200
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_10_MASK 0x400
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_11_MASK 0x800
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_12_MASK 0x1000
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_13_MASK 0x2000
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_14_MASK 0x4000
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_15_MASK 0x8000
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_16_MASK 0x10000
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_17_MASK 0x20000
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_18_MASK 0x40000
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_19_MASK 0x80000
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_20_MASK 0x100000
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_21_MASK 0x200000
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_22_MASK 0x400000
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_23_MASK 0x800000
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_24_MASK 0x1000000
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_25_MASK 0x2000000
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_26_MASK 0x4000000
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_27_MASK 0x8000000
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_28_MASK 0x10000000
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_29_MASK 0x20000000
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_30_MASK 0x40000000
#define MP2_PIC0_EDGE_0_INTR_TRIGGER_31_MASK 0x80000000

#define MP2_PIC0_EDGE_0_MASK \
     (MP2_PIC0_EDGE_0_INTR_TRIGGER_0_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_1_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_2_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_3_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_4_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_5_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_6_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_7_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_8_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_9_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_10_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_11_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_12_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_13_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_14_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_15_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_16_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_17_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_18_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_19_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_20_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_21_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_22_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_23_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_24_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_25_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_26_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_27_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_28_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_29_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_30_MASK | \
      MP2_PIC0_EDGE_0_INTR_TRIGGER_31_MASK)

#define MP2_PIC0_EDGE_0_DEFAULT        0x00000000

#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_0(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_0_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_0_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_1(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_1_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_1_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_2(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_2_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_2_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_3(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_3_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_3_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_4(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_4_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_4_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_5(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_5_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_5_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_6(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_6_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_6_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_7(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_7_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_7_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_8(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_8_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_8_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_9(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_9_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_9_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_10(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_10_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_10_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_11(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_11_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_11_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_12(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_12_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_12_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_13(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_13_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_13_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_14(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_14_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_14_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_15(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_15_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_15_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_16(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_16_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_16_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_17(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_17_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_17_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_18(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_18_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_18_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_19(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_19_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_19_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_20(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_20_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_20_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_21(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_21_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_21_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_22(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_22_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_22_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_23(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_23_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_23_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_24(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_24_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_24_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_25(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_25_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_25_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_26(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_26_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_26_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_27(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_27_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_27_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_28(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_28_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_28_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_29(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_29_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_29_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_30(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_30_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_30_SHIFT)
#define MP2_PIC0_EDGE_0_GET_INTR_TRIGGER_31(mp2_pic0_edge_0) \
     ((mp2_pic0_edge_0 & MP2_PIC0_EDGE_0_INTR_TRIGGER_31_MASK) >> MP2_PIC0_EDGE_0_INTR_TRIGGER_31_SHIFT)

#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_0(mp2_pic0_edge_0_reg, intr_trigger_0) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_0_MASK) | (intr_trigger_0 << MP2_PIC0_EDGE_0_INTR_TRIGGER_0_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_1(mp2_pic0_edge_0_reg, intr_trigger_1) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_1_MASK) | (intr_trigger_1 << MP2_PIC0_EDGE_0_INTR_TRIGGER_1_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_2(mp2_pic0_edge_0_reg, intr_trigger_2) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_2_MASK) | (intr_trigger_2 << MP2_PIC0_EDGE_0_INTR_TRIGGER_2_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_3(mp2_pic0_edge_0_reg, intr_trigger_3) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_3_MASK) | (intr_trigger_3 << MP2_PIC0_EDGE_0_INTR_TRIGGER_3_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_4(mp2_pic0_edge_0_reg, intr_trigger_4) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_4_MASK) | (intr_trigger_4 << MP2_PIC0_EDGE_0_INTR_TRIGGER_4_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_5(mp2_pic0_edge_0_reg, intr_trigger_5) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_5_MASK) | (intr_trigger_5 << MP2_PIC0_EDGE_0_INTR_TRIGGER_5_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_6(mp2_pic0_edge_0_reg, intr_trigger_6) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_6_MASK) | (intr_trigger_6 << MP2_PIC0_EDGE_0_INTR_TRIGGER_6_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_7(mp2_pic0_edge_0_reg, intr_trigger_7) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_7_MASK) | (intr_trigger_7 << MP2_PIC0_EDGE_0_INTR_TRIGGER_7_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_8(mp2_pic0_edge_0_reg, intr_trigger_8) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_8_MASK) | (intr_trigger_8 << MP2_PIC0_EDGE_0_INTR_TRIGGER_8_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_9(mp2_pic0_edge_0_reg, intr_trigger_9) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_9_MASK) | (intr_trigger_9 << MP2_PIC0_EDGE_0_INTR_TRIGGER_9_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_10(mp2_pic0_edge_0_reg, intr_trigger_10) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_10_MASK) | (intr_trigger_10 << MP2_PIC0_EDGE_0_INTR_TRIGGER_10_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_11(mp2_pic0_edge_0_reg, intr_trigger_11) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_11_MASK) | (intr_trigger_11 << MP2_PIC0_EDGE_0_INTR_TRIGGER_11_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_12(mp2_pic0_edge_0_reg, intr_trigger_12) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_12_MASK) | (intr_trigger_12 << MP2_PIC0_EDGE_0_INTR_TRIGGER_12_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_13(mp2_pic0_edge_0_reg, intr_trigger_13) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_13_MASK) | (intr_trigger_13 << MP2_PIC0_EDGE_0_INTR_TRIGGER_13_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_14(mp2_pic0_edge_0_reg, intr_trigger_14) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_14_MASK) | (intr_trigger_14 << MP2_PIC0_EDGE_0_INTR_TRIGGER_14_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_15(mp2_pic0_edge_0_reg, intr_trigger_15) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_15_MASK) | (intr_trigger_15 << MP2_PIC0_EDGE_0_INTR_TRIGGER_15_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_16(mp2_pic0_edge_0_reg, intr_trigger_16) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_16_MASK) | (intr_trigger_16 << MP2_PIC0_EDGE_0_INTR_TRIGGER_16_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_17(mp2_pic0_edge_0_reg, intr_trigger_17) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_17_MASK) | (intr_trigger_17 << MP2_PIC0_EDGE_0_INTR_TRIGGER_17_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_18(mp2_pic0_edge_0_reg, intr_trigger_18) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_18_MASK) | (intr_trigger_18 << MP2_PIC0_EDGE_0_INTR_TRIGGER_18_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_19(mp2_pic0_edge_0_reg, intr_trigger_19) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_19_MASK) | (intr_trigger_19 << MP2_PIC0_EDGE_0_INTR_TRIGGER_19_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_20(mp2_pic0_edge_0_reg, intr_trigger_20) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_20_MASK) | (intr_trigger_20 << MP2_PIC0_EDGE_0_INTR_TRIGGER_20_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_21(mp2_pic0_edge_0_reg, intr_trigger_21) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_21_MASK) | (intr_trigger_21 << MP2_PIC0_EDGE_0_INTR_TRIGGER_21_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_22(mp2_pic0_edge_0_reg, intr_trigger_22) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_22_MASK) | (intr_trigger_22 << MP2_PIC0_EDGE_0_INTR_TRIGGER_22_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_23(mp2_pic0_edge_0_reg, intr_trigger_23) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_23_MASK) | (intr_trigger_23 << MP2_PIC0_EDGE_0_INTR_TRIGGER_23_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_24(mp2_pic0_edge_0_reg, intr_trigger_24) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_24_MASK) | (intr_trigger_24 << MP2_PIC0_EDGE_0_INTR_TRIGGER_24_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_25(mp2_pic0_edge_0_reg, intr_trigger_25) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_25_MASK) | (intr_trigger_25 << MP2_PIC0_EDGE_0_INTR_TRIGGER_25_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_26(mp2_pic0_edge_0_reg, intr_trigger_26) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_26_MASK) | (intr_trigger_26 << MP2_PIC0_EDGE_0_INTR_TRIGGER_26_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_27(mp2_pic0_edge_0_reg, intr_trigger_27) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_27_MASK) | (intr_trigger_27 << MP2_PIC0_EDGE_0_INTR_TRIGGER_27_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_28(mp2_pic0_edge_0_reg, intr_trigger_28) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_28_MASK) | (intr_trigger_28 << MP2_PIC0_EDGE_0_INTR_TRIGGER_28_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_29(mp2_pic0_edge_0_reg, intr_trigger_29) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_29_MASK) | (intr_trigger_29 << MP2_PIC0_EDGE_0_INTR_TRIGGER_29_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_30(mp2_pic0_edge_0_reg, intr_trigger_30) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_30_MASK) | (intr_trigger_30 << MP2_PIC0_EDGE_0_INTR_TRIGGER_30_SHIFT)
#define MP2_PIC0_EDGE_0_SET_INTR_TRIGGER_31(mp2_pic0_edge_0_reg, intr_trigger_31) \
     mp2_pic0_edge_0_reg = (mp2_pic0_edge_0_reg & ~MP2_PIC0_EDGE_0_INTR_TRIGGER_31_MASK) | (intr_trigger_31 << MP2_PIC0_EDGE_0_INTR_TRIGGER_31_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_edge_0_t {
          unsigned int intr_trigger_0                 : MP2_PIC0_EDGE_0_INTR_TRIGGER_0_SIZE;
          unsigned int intr_trigger_1                 : MP2_PIC0_EDGE_0_INTR_TRIGGER_1_SIZE;
          unsigned int intr_trigger_2                 : MP2_PIC0_EDGE_0_INTR_TRIGGER_2_SIZE;
          unsigned int intr_trigger_3                 : MP2_PIC0_EDGE_0_INTR_TRIGGER_3_SIZE;
          unsigned int intr_trigger_4                 : MP2_PIC0_EDGE_0_INTR_TRIGGER_4_SIZE;
          unsigned int intr_trigger_5                 : MP2_PIC0_EDGE_0_INTR_TRIGGER_5_SIZE;
          unsigned int intr_trigger_6                 : MP2_PIC0_EDGE_0_INTR_TRIGGER_6_SIZE;
          unsigned int intr_trigger_7                 : MP2_PIC0_EDGE_0_INTR_TRIGGER_7_SIZE;
          unsigned int intr_trigger_8                 : MP2_PIC0_EDGE_0_INTR_TRIGGER_8_SIZE;
          unsigned int intr_trigger_9                 : MP2_PIC0_EDGE_0_INTR_TRIGGER_9_SIZE;
          unsigned int intr_trigger_10                : MP2_PIC0_EDGE_0_INTR_TRIGGER_10_SIZE;
          unsigned int intr_trigger_11                : MP2_PIC0_EDGE_0_INTR_TRIGGER_11_SIZE;
          unsigned int intr_trigger_12                : MP2_PIC0_EDGE_0_INTR_TRIGGER_12_SIZE;
          unsigned int intr_trigger_13                : MP2_PIC0_EDGE_0_INTR_TRIGGER_13_SIZE;
          unsigned int intr_trigger_14                : MP2_PIC0_EDGE_0_INTR_TRIGGER_14_SIZE;
          unsigned int intr_trigger_15                : MP2_PIC0_EDGE_0_INTR_TRIGGER_15_SIZE;
          unsigned int intr_trigger_16                : MP2_PIC0_EDGE_0_INTR_TRIGGER_16_SIZE;
          unsigned int intr_trigger_17                : MP2_PIC0_EDGE_0_INTR_TRIGGER_17_SIZE;
          unsigned int intr_trigger_18                : MP2_PIC0_EDGE_0_INTR_TRIGGER_18_SIZE;
          unsigned int intr_trigger_19                : MP2_PIC0_EDGE_0_INTR_TRIGGER_19_SIZE;
          unsigned int intr_trigger_20                : MP2_PIC0_EDGE_0_INTR_TRIGGER_20_SIZE;
          unsigned int intr_trigger_21                : MP2_PIC0_EDGE_0_INTR_TRIGGER_21_SIZE;
          unsigned int intr_trigger_22                : MP2_PIC0_EDGE_0_INTR_TRIGGER_22_SIZE;
          unsigned int intr_trigger_23                : MP2_PIC0_EDGE_0_INTR_TRIGGER_23_SIZE;
          unsigned int intr_trigger_24                : MP2_PIC0_EDGE_0_INTR_TRIGGER_24_SIZE;
          unsigned int intr_trigger_25                : MP2_PIC0_EDGE_0_INTR_TRIGGER_25_SIZE;
          unsigned int intr_trigger_26                : MP2_PIC0_EDGE_0_INTR_TRIGGER_26_SIZE;
          unsigned int intr_trigger_27                : MP2_PIC0_EDGE_0_INTR_TRIGGER_27_SIZE;
          unsigned int intr_trigger_28                : MP2_PIC0_EDGE_0_INTR_TRIGGER_28_SIZE;
          unsigned int intr_trigger_29                : MP2_PIC0_EDGE_0_INTR_TRIGGER_29_SIZE;
          unsigned int intr_trigger_30                : MP2_PIC0_EDGE_0_INTR_TRIGGER_30_SIZE;
          unsigned int intr_trigger_31                : MP2_PIC0_EDGE_0_INTR_TRIGGER_31_SIZE;
     } mp2_pic0_edge_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_edge_0_t {
          unsigned int intr_trigger_31                : MP2_PIC0_EDGE_0_INTR_TRIGGER_31_SIZE;
          unsigned int intr_trigger_30                : MP2_PIC0_EDGE_0_INTR_TRIGGER_30_SIZE;
          unsigned int intr_trigger_29                : MP2_PIC0_EDGE_0_INTR_TRIGGER_29_SIZE;
          unsigned int intr_trigger_28                : MP2_PIC0_EDGE_0_INTR_TRIGGER_28_SIZE;
          unsigned int intr_trigger_27                : MP2_PIC0_EDGE_0_INTR_TRIGGER_27_SIZE;
          unsigned int intr_trigger_26                : MP2_PIC0_EDGE_0_INTR_TRIGGER_26_SIZE;
          unsigned int intr_trigger_25                : MP2_PIC0_EDGE_0_INTR_TRIGGER_25_SIZE;
          unsigned int intr_trigger_24                : MP2_PIC0_EDGE_0_INTR_TRIGGER_24_SIZE;
          unsigned int intr_trigger_23                : MP2_PIC0_EDGE_0_INTR_TRIGGER_23_SIZE;
          unsigned int intr_trigger_22                : MP2_PIC0_EDGE_0_INTR_TRIGGER_22_SIZE;
          unsigned int intr_trigger_21                : MP2_PIC0_EDGE_0_INTR_TRIGGER_21_SIZE;
          unsigned int intr_trigger_20                : MP2_PIC0_EDGE_0_INTR_TRIGGER_20_SIZE;
          unsigned int intr_trigger_19                : MP2_PIC0_EDGE_0_INTR_TRIGGER_19_SIZE;
          unsigned int intr_trigger_18                : MP2_PIC0_EDGE_0_INTR_TRIGGER_18_SIZE;
          unsigned int intr_trigger_17                : MP2_PIC0_EDGE_0_INTR_TRIGGER_17_SIZE;
          unsigned int intr_trigger_16                : MP2_PIC0_EDGE_0_INTR_TRIGGER_16_SIZE;
          unsigned int intr_trigger_15                : MP2_PIC0_EDGE_0_INTR_TRIGGER_15_SIZE;
          unsigned int intr_trigger_14                : MP2_PIC0_EDGE_0_INTR_TRIGGER_14_SIZE;
          unsigned int intr_trigger_13                : MP2_PIC0_EDGE_0_INTR_TRIGGER_13_SIZE;
          unsigned int intr_trigger_12                : MP2_PIC0_EDGE_0_INTR_TRIGGER_12_SIZE;
          unsigned int intr_trigger_11                : MP2_PIC0_EDGE_0_INTR_TRIGGER_11_SIZE;
          unsigned int intr_trigger_10                : MP2_PIC0_EDGE_0_INTR_TRIGGER_10_SIZE;
          unsigned int intr_trigger_9                 : MP2_PIC0_EDGE_0_INTR_TRIGGER_9_SIZE;
          unsigned int intr_trigger_8                 : MP2_PIC0_EDGE_0_INTR_TRIGGER_8_SIZE;
          unsigned int intr_trigger_7                 : MP2_PIC0_EDGE_0_INTR_TRIGGER_7_SIZE;
          unsigned int intr_trigger_6                 : MP2_PIC0_EDGE_0_INTR_TRIGGER_6_SIZE;
          unsigned int intr_trigger_5                 : MP2_PIC0_EDGE_0_INTR_TRIGGER_5_SIZE;
          unsigned int intr_trigger_4                 : MP2_PIC0_EDGE_0_INTR_TRIGGER_4_SIZE;
          unsigned int intr_trigger_3                 : MP2_PIC0_EDGE_0_INTR_TRIGGER_3_SIZE;
          unsigned int intr_trigger_2                 : MP2_PIC0_EDGE_0_INTR_TRIGGER_2_SIZE;
          unsigned int intr_trigger_1                 : MP2_PIC0_EDGE_0_INTR_TRIGGER_1_SIZE;
          unsigned int intr_trigger_0                 : MP2_PIC0_EDGE_0_INTR_TRIGGER_0_SIZE;
     } mp2_pic0_edge_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_edge_0_t f;
} mp2_pic0_edge_0_u;


/*
 * MP2_PIC0_EDGE_1 struct
 */

#define MP2_PIC0_EDGE_1_REG_SIZE       32
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_0_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_1_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_2_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_3_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_4_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_5_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_6_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_7_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_8_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_9_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_10_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_11_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_12_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_13_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_14_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_15_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_16_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_17_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_18_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_19_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_20_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_21_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_22_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_23_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_24_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_25_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_26_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_27_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_28_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_29_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_30_SIZE 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_31_SIZE 1

#define MP2_PIC0_EDGE_1_INTR_TRIGGER_0_SHIFT 0
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_1_SHIFT 1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_2_SHIFT 2
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_3_SHIFT 3
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_4_SHIFT 4
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_5_SHIFT 5
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_6_SHIFT 6
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_7_SHIFT 7
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_8_SHIFT 8
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_9_SHIFT 9
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_10_SHIFT 10
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_11_SHIFT 11
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_12_SHIFT 12
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_13_SHIFT 13
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_14_SHIFT 14
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_15_SHIFT 15
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_16_SHIFT 16
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_17_SHIFT 17
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_18_SHIFT 18
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_19_SHIFT 19
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_20_SHIFT 20
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_21_SHIFT 21
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_22_SHIFT 22
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_23_SHIFT 23
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_24_SHIFT 24
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_25_SHIFT 25
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_26_SHIFT 26
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_27_SHIFT 27
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_28_SHIFT 28
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_29_SHIFT 29
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_30_SHIFT 30
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_31_SHIFT 31

#define MP2_PIC0_EDGE_1_INTR_TRIGGER_0_MASK 0x1
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_1_MASK 0x2
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_2_MASK 0x4
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_3_MASK 0x8
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_4_MASK 0x10
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_5_MASK 0x20
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_6_MASK 0x40
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_7_MASK 0x80
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_8_MASK 0x100
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_9_MASK 0x200
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_10_MASK 0x400
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_11_MASK 0x800
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_12_MASK 0x1000
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_13_MASK 0x2000
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_14_MASK 0x4000
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_15_MASK 0x8000
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_16_MASK 0x10000
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_17_MASK 0x20000
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_18_MASK 0x40000
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_19_MASK 0x80000
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_20_MASK 0x100000
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_21_MASK 0x200000
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_22_MASK 0x400000
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_23_MASK 0x800000
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_24_MASK 0x1000000
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_25_MASK 0x2000000
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_26_MASK 0x4000000
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_27_MASK 0x8000000
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_28_MASK 0x10000000
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_29_MASK 0x20000000
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_30_MASK 0x40000000
#define MP2_PIC0_EDGE_1_INTR_TRIGGER_31_MASK 0x80000000

#define MP2_PIC0_EDGE_1_MASK \
     (MP2_PIC0_EDGE_1_INTR_TRIGGER_0_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_1_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_2_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_3_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_4_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_5_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_6_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_7_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_8_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_9_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_10_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_11_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_12_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_13_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_14_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_15_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_16_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_17_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_18_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_19_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_20_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_21_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_22_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_23_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_24_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_25_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_26_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_27_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_28_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_29_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_30_MASK | \
      MP2_PIC0_EDGE_1_INTR_TRIGGER_31_MASK)

#define MP2_PIC0_EDGE_1_DEFAULT        0x00000000

#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_0(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_0_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_0_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_1(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_1_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_1_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_2(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_2_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_2_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_3(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_3_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_3_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_4(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_4_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_4_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_5(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_5_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_5_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_6(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_6_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_6_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_7(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_7_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_7_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_8(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_8_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_8_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_9(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_9_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_9_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_10(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_10_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_10_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_11(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_11_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_11_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_12(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_12_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_12_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_13(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_13_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_13_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_14(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_14_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_14_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_15(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_15_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_15_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_16(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_16_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_16_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_17(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_17_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_17_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_18(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_18_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_18_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_19(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_19_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_19_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_20(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_20_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_20_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_21(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_21_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_21_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_22(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_22_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_22_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_23(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_23_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_23_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_24(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_24_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_24_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_25(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_25_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_25_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_26(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_26_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_26_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_27(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_27_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_27_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_28(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_28_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_28_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_29(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_29_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_29_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_30(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_30_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_30_SHIFT)
#define MP2_PIC0_EDGE_1_GET_INTR_TRIGGER_31(mp2_pic0_edge_1) \
     ((mp2_pic0_edge_1 & MP2_PIC0_EDGE_1_INTR_TRIGGER_31_MASK) >> MP2_PIC0_EDGE_1_INTR_TRIGGER_31_SHIFT)

#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_0(mp2_pic0_edge_1_reg, intr_trigger_0) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_0_MASK) | (intr_trigger_0 << MP2_PIC0_EDGE_1_INTR_TRIGGER_0_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_1(mp2_pic0_edge_1_reg, intr_trigger_1) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_1_MASK) | (intr_trigger_1 << MP2_PIC0_EDGE_1_INTR_TRIGGER_1_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_2(mp2_pic0_edge_1_reg, intr_trigger_2) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_2_MASK) | (intr_trigger_2 << MP2_PIC0_EDGE_1_INTR_TRIGGER_2_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_3(mp2_pic0_edge_1_reg, intr_trigger_3) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_3_MASK) | (intr_trigger_3 << MP2_PIC0_EDGE_1_INTR_TRIGGER_3_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_4(mp2_pic0_edge_1_reg, intr_trigger_4) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_4_MASK) | (intr_trigger_4 << MP2_PIC0_EDGE_1_INTR_TRIGGER_4_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_5(mp2_pic0_edge_1_reg, intr_trigger_5) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_5_MASK) | (intr_trigger_5 << MP2_PIC0_EDGE_1_INTR_TRIGGER_5_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_6(mp2_pic0_edge_1_reg, intr_trigger_6) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_6_MASK) | (intr_trigger_6 << MP2_PIC0_EDGE_1_INTR_TRIGGER_6_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_7(mp2_pic0_edge_1_reg, intr_trigger_7) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_7_MASK) | (intr_trigger_7 << MP2_PIC0_EDGE_1_INTR_TRIGGER_7_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_8(mp2_pic0_edge_1_reg, intr_trigger_8) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_8_MASK) | (intr_trigger_8 << MP2_PIC0_EDGE_1_INTR_TRIGGER_8_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_9(mp2_pic0_edge_1_reg, intr_trigger_9) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_9_MASK) | (intr_trigger_9 << MP2_PIC0_EDGE_1_INTR_TRIGGER_9_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_10(mp2_pic0_edge_1_reg, intr_trigger_10) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_10_MASK) | (intr_trigger_10 << MP2_PIC0_EDGE_1_INTR_TRIGGER_10_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_11(mp2_pic0_edge_1_reg, intr_trigger_11) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_11_MASK) | (intr_trigger_11 << MP2_PIC0_EDGE_1_INTR_TRIGGER_11_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_12(mp2_pic0_edge_1_reg, intr_trigger_12) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_12_MASK) | (intr_trigger_12 << MP2_PIC0_EDGE_1_INTR_TRIGGER_12_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_13(mp2_pic0_edge_1_reg, intr_trigger_13) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_13_MASK) | (intr_trigger_13 << MP2_PIC0_EDGE_1_INTR_TRIGGER_13_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_14(mp2_pic0_edge_1_reg, intr_trigger_14) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_14_MASK) | (intr_trigger_14 << MP2_PIC0_EDGE_1_INTR_TRIGGER_14_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_15(mp2_pic0_edge_1_reg, intr_trigger_15) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_15_MASK) | (intr_trigger_15 << MP2_PIC0_EDGE_1_INTR_TRIGGER_15_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_16(mp2_pic0_edge_1_reg, intr_trigger_16) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_16_MASK) | (intr_trigger_16 << MP2_PIC0_EDGE_1_INTR_TRIGGER_16_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_17(mp2_pic0_edge_1_reg, intr_trigger_17) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_17_MASK) | (intr_trigger_17 << MP2_PIC0_EDGE_1_INTR_TRIGGER_17_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_18(mp2_pic0_edge_1_reg, intr_trigger_18) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_18_MASK) | (intr_trigger_18 << MP2_PIC0_EDGE_1_INTR_TRIGGER_18_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_19(mp2_pic0_edge_1_reg, intr_trigger_19) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_19_MASK) | (intr_trigger_19 << MP2_PIC0_EDGE_1_INTR_TRIGGER_19_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_20(mp2_pic0_edge_1_reg, intr_trigger_20) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_20_MASK) | (intr_trigger_20 << MP2_PIC0_EDGE_1_INTR_TRIGGER_20_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_21(mp2_pic0_edge_1_reg, intr_trigger_21) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_21_MASK) | (intr_trigger_21 << MP2_PIC0_EDGE_1_INTR_TRIGGER_21_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_22(mp2_pic0_edge_1_reg, intr_trigger_22) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_22_MASK) | (intr_trigger_22 << MP2_PIC0_EDGE_1_INTR_TRIGGER_22_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_23(mp2_pic0_edge_1_reg, intr_trigger_23) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_23_MASK) | (intr_trigger_23 << MP2_PIC0_EDGE_1_INTR_TRIGGER_23_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_24(mp2_pic0_edge_1_reg, intr_trigger_24) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_24_MASK) | (intr_trigger_24 << MP2_PIC0_EDGE_1_INTR_TRIGGER_24_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_25(mp2_pic0_edge_1_reg, intr_trigger_25) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_25_MASK) | (intr_trigger_25 << MP2_PIC0_EDGE_1_INTR_TRIGGER_25_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_26(mp2_pic0_edge_1_reg, intr_trigger_26) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_26_MASK) | (intr_trigger_26 << MP2_PIC0_EDGE_1_INTR_TRIGGER_26_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_27(mp2_pic0_edge_1_reg, intr_trigger_27) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_27_MASK) | (intr_trigger_27 << MP2_PIC0_EDGE_1_INTR_TRIGGER_27_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_28(mp2_pic0_edge_1_reg, intr_trigger_28) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_28_MASK) | (intr_trigger_28 << MP2_PIC0_EDGE_1_INTR_TRIGGER_28_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_29(mp2_pic0_edge_1_reg, intr_trigger_29) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_29_MASK) | (intr_trigger_29 << MP2_PIC0_EDGE_1_INTR_TRIGGER_29_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_30(mp2_pic0_edge_1_reg, intr_trigger_30) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_30_MASK) | (intr_trigger_30 << MP2_PIC0_EDGE_1_INTR_TRIGGER_30_SHIFT)
#define MP2_PIC0_EDGE_1_SET_INTR_TRIGGER_31(mp2_pic0_edge_1_reg, intr_trigger_31) \
     mp2_pic0_edge_1_reg = (mp2_pic0_edge_1_reg & ~MP2_PIC0_EDGE_1_INTR_TRIGGER_31_MASK) | (intr_trigger_31 << MP2_PIC0_EDGE_1_INTR_TRIGGER_31_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_edge_1_t {
          unsigned int intr_trigger_0                 : MP2_PIC0_EDGE_1_INTR_TRIGGER_0_SIZE;
          unsigned int intr_trigger_1                 : MP2_PIC0_EDGE_1_INTR_TRIGGER_1_SIZE;
          unsigned int intr_trigger_2                 : MP2_PIC0_EDGE_1_INTR_TRIGGER_2_SIZE;
          unsigned int intr_trigger_3                 : MP2_PIC0_EDGE_1_INTR_TRIGGER_3_SIZE;
          unsigned int intr_trigger_4                 : MP2_PIC0_EDGE_1_INTR_TRIGGER_4_SIZE;
          unsigned int intr_trigger_5                 : MP2_PIC0_EDGE_1_INTR_TRIGGER_5_SIZE;
          unsigned int intr_trigger_6                 : MP2_PIC0_EDGE_1_INTR_TRIGGER_6_SIZE;
          unsigned int intr_trigger_7                 : MP2_PIC0_EDGE_1_INTR_TRIGGER_7_SIZE;
          unsigned int intr_trigger_8                 : MP2_PIC0_EDGE_1_INTR_TRIGGER_8_SIZE;
          unsigned int intr_trigger_9                 : MP2_PIC0_EDGE_1_INTR_TRIGGER_9_SIZE;
          unsigned int intr_trigger_10                : MP2_PIC0_EDGE_1_INTR_TRIGGER_10_SIZE;
          unsigned int intr_trigger_11                : MP2_PIC0_EDGE_1_INTR_TRIGGER_11_SIZE;
          unsigned int intr_trigger_12                : MP2_PIC0_EDGE_1_INTR_TRIGGER_12_SIZE;
          unsigned int intr_trigger_13                : MP2_PIC0_EDGE_1_INTR_TRIGGER_13_SIZE;
          unsigned int intr_trigger_14                : MP2_PIC0_EDGE_1_INTR_TRIGGER_14_SIZE;
          unsigned int intr_trigger_15                : MP2_PIC0_EDGE_1_INTR_TRIGGER_15_SIZE;
          unsigned int intr_trigger_16                : MP2_PIC0_EDGE_1_INTR_TRIGGER_16_SIZE;
          unsigned int intr_trigger_17                : MP2_PIC0_EDGE_1_INTR_TRIGGER_17_SIZE;
          unsigned int intr_trigger_18                : MP2_PIC0_EDGE_1_INTR_TRIGGER_18_SIZE;
          unsigned int intr_trigger_19                : MP2_PIC0_EDGE_1_INTR_TRIGGER_19_SIZE;
          unsigned int intr_trigger_20                : MP2_PIC0_EDGE_1_INTR_TRIGGER_20_SIZE;
          unsigned int intr_trigger_21                : MP2_PIC0_EDGE_1_INTR_TRIGGER_21_SIZE;
          unsigned int intr_trigger_22                : MP2_PIC0_EDGE_1_INTR_TRIGGER_22_SIZE;
          unsigned int intr_trigger_23                : MP2_PIC0_EDGE_1_INTR_TRIGGER_23_SIZE;
          unsigned int intr_trigger_24                : MP2_PIC0_EDGE_1_INTR_TRIGGER_24_SIZE;
          unsigned int intr_trigger_25                : MP2_PIC0_EDGE_1_INTR_TRIGGER_25_SIZE;
          unsigned int intr_trigger_26                : MP2_PIC0_EDGE_1_INTR_TRIGGER_26_SIZE;
          unsigned int intr_trigger_27                : MP2_PIC0_EDGE_1_INTR_TRIGGER_27_SIZE;
          unsigned int intr_trigger_28                : MP2_PIC0_EDGE_1_INTR_TRIGGER_28_SIZE;
          unsigned int intr_trigger_29                : MP2_PIC0_EDGE_1_INTR_TRIGGER_29_SIZE;
          unsigned int intr_trigger_30                : MP2_PIC0_EDGE_1_INTR_TRIGGER_30_SIZE;
          unsigned int intr_trigger_31                : MP2_PIC0_EDGE_1_INTR_TRIGGER_31_SIZE;
     } mp2_pic0_edge_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_edge_1_t {
          unsigned int intr_trigger_31                : MP2_PIC0_EDGE_1_INTR_TRIGGER_31_SIZE;
          unsigned int intr_trigger_30                : MP2_PIC0_EDGE_1_INTR_TRIGGER_30_SIZE;
          unsigned int intr_trigger_29                : MP2_PIC0_EDGE_1_INTR_TRIGGER_29_SIZE;
          unsigned int intr_trigger_28                : MP2_PIC0_EDGE_1_INTR_TRIGGER_28_SIZE;
          unsigned int intr_trigger_27                : MP2_PIC0_EDGE_1_INTR_TRIGGER_27_SIZE;
          unsigned int intr_trigger_26                : MP2_PIC0_EDGE_1_INTR_TRIGGER_26_SIZE;
          unsigned int intr_trigger_25                : MP2_PIC0_EDGE_1_INTR_TRIGGER_25_SIZE;
          unsigned int intr_trigger_24                : MP2_PIC0_EDGE_1_INTR_TRIGGER_24_SIZE;
          unsigned int intr_trigger_23                : MP2_PIC0_EDGE_1_INTR_TRIGGER_23_SIZE;
          unsigned int intr_trigger_22                : MP2_PIC0_EDGE_1_INTR_TRIGGER_22_SIZE;
          unsigned int intr_trigger_21                : MP2_PIC0_EDGE_1_INTR_TRIGGER_21_SIZE;
          unsigned int intr_trigger_20                : MP2_PIC0_EDGE_1_INTR_TRIGGER_20_SIZE;
          unsigned int intr_trigger_19                : MP2_PIC0_EDGE_1_INTR_TRIGGER_19_SIZE;
          unsigned int intr_trigger_18                : MP2_PIC0_EDGE_1_INTR_TRIGGER_18_SIZE;
          unsigned int intr_trigger_17                : MP2_PIC0_EDGE_1_INTR_TRIGGER_17_SIZE;
          unsigned int intr_trigger_16                : MP2_PIC0_EDGE_1_INTR_TRIGGER_16_SIZE;
          unsigned int intr_trigger_15                : MP2_PIC0_EDGE_1_INTR_TRIGGER_15_SIZE;
          unsigned int intr_trigger_14                : MP2_PIC0_EDGE_1_INTR_TRIGGER_14_SIZE;
          unsigned int intr_trigger_13                : MP2_PIC0_EDGE_1_INTR_TRIGGER_13_SIZE;
          unsigned int intr_trigger_12                : MP2_PIC0_EDGE_1_INTR_TRIGGER_12_SIZE;
          unsigned int intr_trigger_11                : MP2_PIC0_EDGE_1_INTR_TRIGGER_11_SIZE;
          unsigned int intr_trigger_10                : MP2_PIC0_EDGE_1_INTR_TRIGGER_10_SIZE;
          unsigned int intr_trigger_9                 : MP2_PIC0_EDGE_1_INTR_TRIGGER_9_SIZE;
          unsigned int intr_trigger_8                 : MP2_PIC0_EDGE_1_INTR_TRIGGER_8_SIZE;
          unsigned int intr_trigger_7                 : MP2_PIC0_EDGE_1_INTR_TRIGGER_7_SIZE;
          unsigned int intr_trigger_6                 : MP2_PIC0_EDGE_1_INTR_TRIGGER_6_SIZE;
          unsigned int intr_trigger_5                 : MP2_PIC0_EDGE_1_INTR_TRIGGER_5_SIZE;
          unsigned int intr_trigger_4                 : MP2_PIC0_EDGE_1_INTR_TRIGGER_4_SIZE;
          unsigned int intr_trigger_3                 : MP2_PIC0_EDGE_1_INTR_TRIGGER_3_SIZE;
          unsigned int intr_trigger_2                 : MP2_PIC0_EDGE_1_INTR_TRIGGER_2_SIZE;
          unsigned int intr_trigger_1                 : MP2_PIC0_EDGE_1_INTR_TRIGGER_1_SIZE;
          unsigned int intr_trigger_0                 : MP2_PIC0_EDGE_1_INTR_TRIGGER_0_SIZE;
     } mp2_pic0_edge_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_edge_1_t f;
} mp2_pic0_edge_1_u;


/*
 * MP2_PIC0_EDGE_2 struct
 */

#define MP2_PIC0_EDGE_2_REG_SIZE       32
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_0_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_1_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_2_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_3_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_4_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_5_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_6_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_7_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_8_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_9_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_10_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_11_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_12_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_13_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_14_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_15_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_16_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_17_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_18_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_19_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_20_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_21_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_22_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_23_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_24_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_25_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_26_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_27_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_28_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_29_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_30_SIZE 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_31_SIZE 1

#define MP2_PIC0_EDGE_2_INTR_TRIGGER_0_SHIFT 0
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_1_SHIFT 1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_2_SHIFT 2
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_3_SHIFT 3
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_4_SHIFT 4
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_5_SHIFT 5
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_6_SHIFT 6
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_7_SHIFT 7
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_8_SHIFT 8
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_9_SHIFT 9
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_10_SHIFT 10
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_11_SHIFT 11
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_12_SHIFT 12
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_13_SHIFT 13
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_14_SHIFT 14
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_15_SHIFT 15
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_16_SHIFT 16
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_17_SHIFT 17
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_18_SHIFT 18
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_19_SHIFT 19
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_20_SHIFT 20
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_21_SHIFT 21
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_22_SHIFT 22
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_23_SHIFT 23
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_24_SHIFT 24
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_25_SHIFT 25
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_26_SHIFT 26
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_27_SHIFT 27
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_28_SHIFT 28
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_29_SHIFT 29
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_30_SHIFT 30
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_31_SHIFT 31

#define MP2_PIC0_EDGE_2_INTR_TRIGGER_0_MASK 0x1
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_1_MASK 0x2
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_2_MASK 0x4
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_3_MASK 0x8
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_4_MASK 0x10
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_5_MASK 0x20
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_6_MASK 0x40
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_7_MASK 0x80
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_8_MASK 0x100
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_9_MASK 0x200
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_10_MASK 0x400
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_11_MASK 0x800
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_12_MASK 0x1000
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_13_MASK 0x2000
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_14_MASK 0x4000
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_15_MASK 0x8000
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_16_MASK 0x10000
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_17_MASK 0x20000
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_18_MASK 0x40000
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_19_MASK 0x80000
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_20_MASK 0x100000
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_21_MASK 0x200000
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_22_MASK 0x400000
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_23_MASK 0x800000
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_24_MASK 0x1000000
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_25_MASK 0x2000000
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_26_MASK 0x4000000
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_27_MASK 0x8000000
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_28_MASK 0x10000000
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_29_MASK 0x20000000
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_30_MASK 0x40000000
#define MP2_PIC0_EDGE_2_INTR_TRIGGER_31_MASK 0x80000000

#define MP2_PIC0_EDGE_2_MASK \
     (MP2_PIC0_EDGE_2_INTR_TRIGGER_0_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_1_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_2_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_3_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_4_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_5_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_6_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_7_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_8_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_9_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_10_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_11_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_12_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_13_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_14_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_15_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_16_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_17_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_18_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_19_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_20_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_21_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_22_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_23_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_24_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_25_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_26_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_27_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_28_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_29_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_30_MASK | \
      MP2_PIC0_EDGE_2_INTR_TRIGGER_31_MASK)

#define MP2_PIC0_EDGE_2_DEFAULT        0x00000000

#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_0(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_0_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_0_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_1(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_1_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_1_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_2(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_2_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_2_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_3(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_3_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_3_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_4(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_4_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_4_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_5(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_5_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_5_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_6(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_6_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_6_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_7(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_7_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_7_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_8(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_8_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_8_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_9(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_9_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_9_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_10(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_10_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_10_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_11(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_11_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_11_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_12(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_12_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_12_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_13(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_13_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_13_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_14(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_14_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_14_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_15(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_15_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_15_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_16(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_16_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_16_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_17(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_17_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_17_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_18(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_18_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_18_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_19(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_19_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_19_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_20(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_20_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_20_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_21(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_21_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_21_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_22(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_22_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_22_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_23(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_23_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_23_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_24(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_24_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_24_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_25(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_25_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_25_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_26(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_26_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_26_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_27(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_27_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_27_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_28(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_28_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_28_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_29(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_29_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_29_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_30(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_30_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_30_SHIFT)
#define MP2_PIC0_EDGE_2_GET_INTR_TRIGGER_31(mp2_pic0_edge_2) \
     ((mp2_pic0_edge_2 & MP2_PIC0_EDGE_2_INTR_TRIGGER_31_MASK) >> MP2_PIC0_EDGE_2_INTR_TRIGGER_31_SHIFT)

#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_0(mp2_pic0_edge_2_reg, intr_trigger_0) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_0_MASK) | (intr_trigger_0 << MP2_PIC0_EDGE_2_INTR_TRIGGER_0_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_1(mp2_pic0_edge_2_reg, intr_trigger_1) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_1_MASK) | (intr_trigger_1 << MP2_PIC0_EDGE_2_INTR_TRIGGER_1_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_2(mp2_pic0_edge_2_reg, intr_trigger_2) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_2_MASK) | (intr_trigger_2 << MP2_PIC0_EDGE_2_INTR_TRIGGER_2_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_3(mp2_pic0_edge_2_reg, intr_trigger_3) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_3_MASK) | (intr_trigger_3 << MP2_PIC0_EDGE_2_INTR_TRIGGER_3_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_4(mp2_pic0_edge_2_reg, intr_trigger_4) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_4_MASK) | (intr_trigger_4 << MP2_PIC0_EDGE_2_INTR_TRIGGER_4_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_5(mp2_pic0_edge_2_reg, intr_trigger_5) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_5_MASK) | (intr_trigger_5 << MP2_PIC0_EDGE_2_INTR_TRIGGER_5_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_6(mp2_pic0_edge_2_reg, intr_trigger_6) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_6_MASK) | (intr_trigger_6 << MP2_PIC0_EDGE_2_INTR_TRIGGER_6_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_7(mp2_pic0_edge_2_reg, intr_trigger_7) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_7_MASK) | (intr_trigger_7 << MP2_PIC0_EDGE_2_INTR_TRIGGER_7_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_8(mp2_pic0_edge_2_reg, intr_trigger_8) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_8_MASK) | (intr_trigger_8 << MP2_PIC0_EDGE_2_INTR_TRIGGER_8_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_9(mp2_pic0_edge_2_reg, intr_trigger_9) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_9_MASK) | (intr_trigger_9 << MP2_PIC0_EDGE_2_INTR_TRIGGER_9_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_10(mp2_pic0_edge_2_reg, intr_trigger_10) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_10_MASK) | (intr_trigger_10 << MP2_PIC0_EDGE_2_INTR_TRIGGER_10_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_11(mp2_pic0_edge_2_reg, intr_trigger_11) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_11_MASK) | (intr_trigger_11 << MP2_PIC0_EDGE_2_INTR_TRIGGER_11_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_12(mp2_pic0_edge_2_reg, intr_trigger_12) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_12_MASK) | (intr_trigger_12 << MP2_PIC0_EDGE_2_INTR_TRIGGER_12_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_13(mp2_pic0_edge_2_reg, intr_trigger_13) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_13_MASK) | (intr_trigger_13 << MP2_PIC0_EDGE_2_INTR_TRIGGER_13_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_14(mp2_pic0_edge_2_reg, intr_trigger_14) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_14_MASK) | (intr_trigger_14 << MP2_PIC0_EDGE_2_INTR_TRIGGER_14_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_15(mp2_pic0_edge_2_reg, intr_trigger_15) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_15_MASK) | (intr_trigger_15 << MP2_PIC0_EDGE_2_INTR_TRIGGER_15_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_16(mp2_pic0_edge_2_reg, intr_trigger_16) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_16_MASK) | (intr_trigger_16 << MP2_PIC0_EDGE_2_INTR_TRIGGER_16_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_17(mp2_pic0_edge_2_reg, intr_trigger_17) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_17_MASK) | (intr_trigger_17 << MP2_PIC0_EDGE_2_INTR_TRIGGER_17_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_18(mp2_pic0_edge_2_reg, intr_trigger_18) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_18_MASK) | (intr_trigger_18 << MP2_PIC0_EDGE_2_INTR_TRIGGER_18_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_19(mp2_pic0_edge_2_reg, intr_trigger_19) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_19_MASK) | (intr_trigger_19 << MP2_PIC0_EDGE_2_INTR_TRIGGER_19_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_20(mp2_pic0_edge_2_reg, intr_trigger_20) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_20_MASK) | (intr_trigger_20 << MP2_PIC0_EDGE_2_INTR_TRIGGER_20_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_21(mp2_pic0_edge_2_reg, intr_trigger_21) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_21_MASK) | (intr_trigger_21 << MP2_PIC0_EDGE_2_INTR_TRIGGER_21_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_22(mp2_pic0_edge_2_reg, intr_trigger_22) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_22_MASK) | (intr_trigger_22 << MP2_PIC0_EDGE_2_INTR_TRIGGER_22_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_23(mp2_pic0_edge_2_reg, intr_trigger_23) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_23_MASK) | (intr_trigger_23 << MP2_PIC0_EDGE_2_INTR_TRIGGER_23_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_24(mp2_pic0_edge_2_reg, intr_trigger_24) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_24_MASK) | (intr_trigger_24 << MP2_PIC0_EDGE_2_INTR_TRIGGER_24_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_25(mp2_pic0_edge_2_reg, intr_trigger_25) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_25_MASK) | (intr_trigger_25 << MP2_PIC0_EDGE_2_INTR_TRIGGER_25_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_26(mp2_pic0_edge_2_reg, intr_trigger_26) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_26_MASK) | (intr_trigger_26 << MP2_PIC0_EDGE_2_INTR_TRIGGER_26_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_27(mp2_pic0_edge_2_reg, intr_trigger_27) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_27_MASK) | (intr_trigger_27 << MP2_PIC0_EDGE_2_INTR_TRIGGER_27_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_28(mp2_pic0_edge_2_reg, intr_trigger_28) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_28_MASK) | (intr_trigger_28 << MP2_PIC0_EDGE_2_INTR_TRIGGER_28_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_29(mp2_pic0_edge_2_reg, intr_trigger_29) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_29_MASK) | (intr_trigger_29 << MP2_PIC0_EDGE_2_INTR_TRIGGER_29_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_30(mp2_pic0_edge_2_reg, intr_trigger_30) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_30_MASK) | (intr_trigger_30 << MP2_PIC0_EDGE_2_INTR_TRIGGER_30_SHIFT)
#define MP2_PIC0_EDGE_2_SET_INTR_TRIGGER_31(mp2_pic0_edge_2_reg, intr_trigger_31) \
     mp2_pic0_edge_2_reg = (mp2_pic0_edge_2_reg & ~MP2_PIC0_EDGE_2_INTR_TRIGGER_31_MASK) | (intr_trigger_31 << MP2_PIC0_EDGE_2_INTR_TRIGGER_31_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_edge_2_t {
          unsigned int intr_trigger_0                 : MP2_PIC0_EDGE_2_INTR_TRIGGER_0_SIZE;
          unsigned int intr_trigger_1                 : MP2_PIC0_EDGE_2_INTR_TRIGGER_1_SIZE;
          unsigned int intr_trigger_2                 : MP2_PIC0_EDGE_2_INTR_TRIGGER_2_SIZE;
          unsigned int intr_trigger_3                 : MP2_PIC0_EDGE_2_INTR_TRIGGER_3_SIZE;
          unsigned int intr_trigger_4                 : MP2_PIC0_EDGE_2_INTR_TRIGGER_4_SIZE;
          unsigned int intr_trigger_5                 : MP2_PIC0_EDGE_2_INTR_TRIGGER_5_SIZE;
          unsigned int intr_trigger_6                 : MP2_PIC0_EDGE_2_INTR_TRIGGER_6_SIZE;
          unsigned int intr_trigger_7                 : MP2_PIC0_EDGE_2_INTR_TRIGGER_7_SIZE;
          unsigned int intr_trigger_8                 : MP2_PIC0_EDGE_2_INTR_TRIGGER_8_SIZE;
          unsigned int intr_trigger_9                 : MP2_PIC0_EDGE_2_INTR_TRIGGER_9_SIZE;
          unsigned int intr_trigger_10                : MP2_PIC0_EDGE_2_INTR_TRIGGER_10_SIZE;
          unsigned int intr_trigger_11                : MP2_PIC0_EDGE_2_INTR_TRIGGER_11_SIZE;
          unsigned int intr_trigger_12                : MP2_PIC0_EDGE_2_INTR_TRIGGER_12_SIZE;
          unsigned int intr_trigger_13                : MP2_PIC0_EDGE_2_INTR_TRIGGER_13_SIZE;
          unsigned int intr_trigger_14                : MP2_PIC0_EDGE_2_INTR_TRIGGER_14_SIZE;
          unsigned int intr_trigger_15                : MP2_PIC0_EDGE_2_INTR_TRIGGER_15_SIZE;
          unsigned int intr_trigger_16                : MP2_PIC0_EDGE_2_INTR_TRIGGER_16_SIZE;
          unsigned int intr_trigger_17                : MP2_PIC0_EDGE_2_INTR_TRIGGER_17_SIZE;
          unsigned int intr_trigger_18                : MP2_PIC0_EDGE_2_INTR_TRIGGER_18_SIZE;
          unsigned int intr_trigger_19                : MP2_PIC0_EDGE_2_INTR_TRIGGER_19_SIZE;
          unsigned int intr_trigger_20                : MP2_PIC0_EDGE_2_INTR_TRIGGER_20_SIZE;
          unsigned int intr_trigger_21                : MP2_PIC0_EDGE_2_INTR_TRIGGER_21_SIZE;
          unsigned int intr_trigger_22                : MP2_PIC0_EDGE_2_INTR_TRIGGER_22_SIZE;
          unsigned int intr_trigger_23                : MP2_PIC0_EDGE_2_INTR_TRIGGER_23_SIZE;
          unsigned int intr_trigger_24                : MP2_PIC0_EDGE_2_INTR_TRIGGER_24_SIZE;
          unsigned int intr_trigger_25                : MP2_PIC0_EDGE_2_INTR_TRIGGER_25_SIZE;
          unsigned int intr_trigger_26                : MP2_PIC0_EDGE_2_INTR_TRIGGER_26_SIZE;
          unsigned int intr_trigger_27                : MP2_PIC0_EDGE_2_INTR_TRIGGER_27_SIZE;
          unsigned int intr_trigger_28                : MP2_PIC0_EDGE_2_INTR_TRIGGER_28_SIZE;
          unsigned int intr_trigger_29                : MP2_PIC0_EDGE_2_INTR_TRIGGER_29_SIZE;
          unsigned int intr_trigger_30                : MP2_PIC0_EDGE_2_INTR_TRIGGER_30_SIZE;
          unsigned int intr_trigger_31                : MP2_PIC0_EDGE_2_INTR_TRIGGER_31_SIZE;
     } mp2_pic0_edge_2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_edge_2_t {
          unsigned int intr_trigger_31                : MP2_PIC0_EDGE_2_INTR_TRIGGER_31_SIZE;
          unsigned int intr_trigger_30                : MP2_PIC0_EDGE_2_INTR_TRIGGER_30_SIZE;
          unsigned int intr_trigger_29                : MP2_PIC0_EDGE_2_INTR_TRIGGER_29_SIZE;
          unsigned int intr_trigger_28                : MP2_PIC0_EDGE_2_INTR_TRIGGER_28_SIZE;
          unsigned int intr_trigger_27                : MP2_PIC0_EDGE_2_INTR_TRIGGER_27_SIZE;
          unsigned int intr_trigger_26                : MP2_PIC0_EDGE_2_INTR_TRIGGER_26_SIZE;
          unsigned int intr_trigger_25                : MP2_PIC0_EDGE_2_INTR_TRIGGER_25_SIZE;
          unsigned int intr_trigger_24                : MP2_PIC0_EDGE_2_INTR_TRIGGER_24_SIZE;
          unsigned int intr_trigger_23                : MP2_PIC0_EDGE_2_INTR_TRIGGER_23_SIZE;
          unsigned int intr_trigger_22                : MP2_PIC0_EDGE_2_INTR_TRIGGER_22_SIZE;
          unsigned int intr_trigger_21                : MP2_PIC0_EDGE_2_INTR_TRIGGER_21_SIZE;
          unsigned int intr_trigger_20                : MP2_PIC0_EDGE_2_INTR_TRIGGER_20_SIZE;
          unsigned int intr_trigger_19                : MP2_PIC0_EDGE_2_INTR_TRIGGER_19_SIZE;
          unsigned int intr_trigger_18                : MP2_PIC0_EDGE_2_INTR_TRIGGER_18_SIZE;
          unsigned int intr_trigger_17                : MP2_PIC0_EDGE_2_INTR_TRIGGER_17_SIZE;
          unsigned int intr_trigger_16                : MP2_PIC0_EDGE_2_INTR_TRIGGER_16_SIZE;
          unsigned int intr_trigger_15                : MP2_PIC0_EDGE_2_INTR_TRIGGER_15_SIZE;
          unsigned int intr_trigger_14                : MP2_PIC0_EDGE_2_INTR_TRIGGER_14_SIZE;
          unsigned int intr_trigger_13                : MP2_PIC0_EDGE_2_INTR_TRIGGER_13_SIZE;
          unsigned int intr_trigger_12                : MP2_PIC0_EDGE_2_INTR_TRIGGER_12_SIZE;
          unsigned int intr_trigger_11                : MP2_PIC0_EDGE_2_INTR_TRIGGER_11_SIZE;
          unsigned int intr_trigger_10                : MP2_PIC0_EDGE_2_INTR_TRIGGER_10_SIZE;
          unsigned int intr_trigger_9                 : MP2_PIC0_EDGE_2_INTR_TRIGGER_9_SIZE;
          unsigned int intr_trigger_8                 : MP2_PIC0_EDGE_2_INTR_TRIGGER_8_SIZE;
          unsigned int intr_trigger_7                 : MP2_PIC0_EDGE_2_INTR_TRIGGER_7_SIZE;
          unsigned int intr_trigger_6                 : MP2_PIC0_EDGE_2_INTR_TRIGGER_6_SIZE;
          unsigned int intr_trigger_5                 : MP2_PIC0_EDGE_2_INTR_TRIGGER_5_SIZE;
          unsigned int intr_trigger_4                 : MP2_PIC0_EDGE_2_INTR_TRIGGER_4_SIZE;
          unsigned int intr_trigger_3                 : MP2_PIC0_EDGE_2_INTR_TRIGGER_3_SIZE;
          unsigned int intr_trigger_2                 : MP2_PIC0_EDGE_2_INTR_TRIGGER_2_SIZE;
          unsigned int intr_trigger_1                 : MP2_PIC0_EDGE_2_INTR_TRIGGER_1_SIZE;
          unsigned int intr_trigger_0                 : MP2_PIC0_EDGE_2_INTR_TRIGGER_0_SIZE;
     } mp2_pic0_edge_2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_edge_2_t f;
} mp2_pic0_edge_2_u;


/*
 * MP2_PIC0_EDGE_3 struct
 */

#define MP2_PIC0_EDGE_3_REG_SIZE       32
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_0_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_1_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_2_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_3_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_4_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_5_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_6_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_7_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_8_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_9_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_10_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_11_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_12_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_13_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_14_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_15_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_16_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_17_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_18_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_19_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_20_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_21_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_22_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_23_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_24_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_25_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_26_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_27_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_28_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_29_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_30_SIZE 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_31_SIZE 1

#define MP2_PIC0_EDGE_3_INTR_TRIGGER_0_SHIFT 0
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_1_SHIFT 1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_2_SHIFT 2
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_3_SHIFT 3
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_4_SHIFT 4
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_5_SHIFT 5
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_6_SHIFT 6
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_7_SHIFT 7
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_8_SHIFT 8
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_9_SHIFT 9
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_10_SHIFT 10
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_11_SHIFT 11
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_12_SHIFT 12
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_13_SHIFT 13
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_14_SHIFT 14
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_15_SHIFT 15
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_16_SHIFT 16
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_17_SHIFT 17
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_18_SHIFT 18
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_19_SHIFT 19
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_20_SHIFT 20
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_21_SHIFT 21
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_22_SHIFT 22
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_23_SHIFT 23
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_24_SHIFT 24
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_25_SHIFT 25
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_26_SHIFT 26
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_27_SHIFT 27
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_28_SHIFT 28
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_29_SHIFT 29
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_30_SHIFT 30
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_31_SHIFT 31

#define MP2_PIC0_EDGE_3_INTR_TRIGGER_0_MASK 0x1
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_1_MASK 0x2
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_2_MASK 0x4
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_3_MASK 0x8
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_4_MASK 0x10
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_5_MASK 0x20
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_6_MASK 0x40
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_7_MASK 0x80
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_8_MASK 0x100
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_9_MASK 0x200
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_10_MASK 0x400
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_11_MASK 0x800
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_12_MASK 0x1000
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_13_MASK 0x2000
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_14_MASK 0x4000
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_15_MASK 0x8000
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_16_MASK 0x10000
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_17_MASK 0x20000
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_18_MASK 0x40000
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_19_MASK 0x80000
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_20_MASK 0x100000
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_21_MASK 0x200000
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_22_MASK 0x400000
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_23_MASK 0x800000
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_24_MASK 0x1000000
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_25_MASK 0x2000000
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_26_MASK 0x4000000
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_27_MASK 0x8000000
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_28_MASK 0x10000000
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_29_MASK 0x20000000
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_30_MASK 0x40000000
#define MP2_PIC0_EDGE_3_INTR_TRIGGER_31_MASK 0x80000000

#define MP2_PIC0_EDGE_3_MASK \
     (MP2_PIC0_EDGE_3_INTR_TRIGGER_0_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_1_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_2_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_3_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_4_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_5_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_6_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_7_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_8_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_9_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_10_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_11_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_12_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_13_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_14_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_15_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_16_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_17_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_18_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_19_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_20_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_21_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_22_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_23_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_24_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_25_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_26_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_27_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_28_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_29_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_30_MASK | \
      MP2_PIC0_EDGE_3_INTR_TRIGGER_31_MASK)

#define MP2_PIC0_EDGE_3_DEFAULT        0x00000000

#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_0(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_0_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_0_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_1(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_1_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_1_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_2(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_2_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_2_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_3(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_3_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_3_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_4(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_4_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_4_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_5(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_5_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_5_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_6(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_6_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_6_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_7(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_7_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_7_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_8(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_8_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_8_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_9(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_9_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_9_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_10(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_10_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_10_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_11(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_11_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_11_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_12(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_12_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_12_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_13(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_13_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_13_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_14(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_14_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_14_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_15(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_15_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_15_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_16(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_16_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_16_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_17(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_17_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_17_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_18(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_18_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_18_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_19(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_19_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_19_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_20(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_20_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_20_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_21(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_21_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_21_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_22(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_22_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_22_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_23(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_23_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_23_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_24(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_24_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_24_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_25(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_25_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_25_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_26(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_26_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_26_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_27(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_27_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_27_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_28(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_28_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_28_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_29(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_29_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_29_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_30(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_30_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_30_SHIFT)
#define MP2_PIC0_EDGE_3_GET_INTR_TRIGGER_31(mp2_pic0_edge_3) \
     ((mp2_pic0_edge_3 & MP2_PIC0_EDGE_3_INTR_TRIGGER_31_MASK) >> MP2_PIC0_EDGE_3_INTR_TRIGGER_31_SHIFT)

#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_0(mp2_pic0_edge_3_reg, intr_trigger_0) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_0_MASK) | (intr_trigger_0 << MP2_PIC0_EDGE_3_INTR_TRIGGER_0_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_1(mp2_pic0_edge_3_reg, intr_trigger_1) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_1_MASK) | (intr_trigger_1 << MP2_PIC0_EDGE_3_INTR_TRIGGER_1_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_2(mp2_pic0_edge_3_reg, intr_trigger_2) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_2_MASK) | (intr_trigger_2 << MP2_PIC0_EDGE_3_INTR_TRIGGER_2_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_3(mp2_pic0_edge_3_reg, intr_trigger_3) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_3_MASK) | (intr_trigger_3 << MP2_PIC0_EDGE_3_INTR_TRIGGER_3_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_4(mp2_pic0_edge_3_reg, intr_trigger_4) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_4_MASK) | (intr_trigger_4 << MP2_PIC0_EDGE_3_INTR_TRIGGER_4_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_5(mp2_pic0_edge_3_reg, intr_trigger_5) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_5_MASK) | (intr_trigger_5 << MP2_PIC0_EDGE_3_INTR_TRIGGER_5_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_6(mp2_pic0_edge_3_reg, intr_trigger_6) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_6_MASK) | (intr_trigger_6 << MP2_PIC0_EDGE_3_INTR_TRIGGER_6_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_7(mp2_pic0_edge_3_reg, intr_trigger_7) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_7_MASK) | (intr_trigger_7 << MP2_PIC0_EDGE_3_INTR_TRIGGER_7_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_8(mp2_pic0_edge_3_reg, intr_trigger_8) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_8_MASK) | (intr_trigger_8 << MP2_PIC0_EDGE_3_INTR_TRIGGER_8_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_9(mp2_pic0_edge_3_reg, intr_trigger_9) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_9_MASK) | (intr_trigger_9 << MP2_PIC0_EDGE_3_INTR_TRIGGER_9_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_10(mp2_pic0_edge_3_reg, intr_trigger_10) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_10_MASK) | (intr_trigger_10 << MP2_PIC0_EDGE_3_INTR_TRIGGER_10_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_11(mp2_pic0_edge_3_reg, intr_trigger_11) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_11_MASK) | (intr_trigger_11 << MP2_PIC0_EDGE_3_INTR_TRIGGER_11_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_12(mp2_pic0_edge_3_reg, intr_trigger_12) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_12_MASK) | (intr_trigger_12 << MP2_PIC0_EDGE_3_INTR_TRIGGER_12_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_13(mp2_pic0_edge_3_reg, intr_trigger_13) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_13_MASK) | (intr_trigger_13 << MP2_PIC0_EDGE_3_INTR_TRIGGER_13_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_14(mp2_pic0_edge_3_reg, intr_trigger_14) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_14_MASK) | (intr_trigger_14 << MP2_PIC0_EDGE_3_INTR_TRIGGER_14_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_15(mp2_pic0_edge_3_reg, intr_trigger_15) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_15_MASK) | (intr_trigger_15 << MP2_PIC0_EDGE_3_INTR_TRIGGER_15_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_16(mp2_pic0_edge_3_reg, intr_trigger_16) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_16_MASK) | (intr_trigger_16 << MP2_PIC0_EDGE_3_INTR_TRIGGER_16_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_17(mp2_pic0_edge_3_reg, intr_trigger_17) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_17_MASK) | (intr_trigger_17 << MP2_PIC0_EDGE_3_INTR_TRIGGER_17_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_18(mp2_pic0_edge_3_reg, intr_trigger_18) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_18_MASK) | (intr_trigger_18 << MP2_PIC0_EDGE_3_INTR_TRIGGER_18_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_19(mp2_pic0_edge_3_reg, intr_trigger_19) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_19_MASK) | (intr_trigger_19 << MP2_PIC0_EDGE_3_INTR_TRIGGER_19_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_20(mp2_pic0_edge_3_reg, intr_trigger_20) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_20_MASK) | (intr_trigger_20 << MP2_PIC0_EDGE_3_INTR_TRIGGER_20_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_21(mp2_pic0_edge_3_reg, intr_trigger_21) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_21_MASK) | (intr_trigger_21 << MP2_PIC0_EDGE_3_INTR_TRIGGER_21_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_22(mp2_pic0_edge_3_reg, intr_trigger_22) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_22_MASK) | (intr_trigger_22 << MP2_PIC0_EDGE_3_INTR_TRIGGER_22_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_23(mp2_pic0_edge_3_reg, intr_trigger_23) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_23_MASK) | (intr_trigger_23 << MP2_PIC0_EDGE_3_INTR_TRIGGER_23_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_24(mp2_pic0_edge_3_reg, intr_trigger_24) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_24_MASK) | (intr_trigger_24 << MP2_PIC0_EDGE_3_INTR_TRIGGER_24_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_25(mp2_pic0_edge_3_reg, intr_trigger_25) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_25_MASK) | (intr_trigger_25 << MP2_PIC0_EDGE_3_INTR_TRIGGER_25_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_26(mp2_pic0_edge_3_reg, intr_trigger_26) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_26_MASK) | (intr_trigger_26 << MP2_PIC0_EDGE_3_INTR_TRIGGER_26_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_27(mp2_pic0_edge_3_reg, intr_trigger_27) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_27_MASK) | (intr_trigger_27 << MP2_PIC0_EDGE_3_INTR_TRIGGER_27_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_28(mp2_pic0_edge_3_reg, intr_trigger_28) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_28_MASK) | (intr_trigger_28 << MP2_PIC0_EDGE_3_INTR_TRIGGER_28_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_29(mp2_pic0_edge_3_reg, intr_trigger_29) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_29_MASK) | (intr_trigger_29 << MP2_PIC0_EDGE_3_INTR_TRIGGER_29_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_30(mp2_pic0_edge_3_reg, intr_trigger_30) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_30_MASK) | (intr_trigger_30 << MP2_PIC0_EDGE_3_INTR_TRIGGER_30_SHIFT)
#define MP2_PIC0_EDGE_3_SET_INTR_TRIGGER_31(mp2_pic0_edge_3_reg, intr_trigger_31) \
     mp2_pic0_edge_3_reg = (mp2_pic0_edge_3_reg & ~MP2_PIC0_EDGE_3_INTR_TRIGGER_31_MASK) | (intr_trigger_31 << MP2_PIC0_EDGE_3_INTR_TRIGGER_31_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_edge_3_t {
          unsigned int intr_trigger_0                 : MP2_PIC0_EDGE_3_INTR_TRIGGER_0_SIZE;
          unsigned int intr_trigger_1                 : MP2_PIC0_EDGE_3_INTR_TRIGGER_1_SIZE;
          unsigned int intr_trigger_2                 : MP2_PIC0_EDGE_3_INTR_TRIGGER_2_SIZE;
          unsigned int intr_trigger_3                 : MP2_PIC0_EDGE_3_INTR_TRIGGER_3_SIZE;
          unsigned int intr_trigger_4                 : MP2_PIC0_EDGE_3_INTR_TRIGGER_4_SIZE;
          unsigned int intr_trigger_5                 : MP2_PIC0_EDGE_3_INTR_TRIGGER_5_SIZE;
          unsigned int intr_trigger_6                 : MP2_PIC0_EDGE_3_INTR_TRIGGER_6_SIZE;
          unsigned int intr_trigger_7                 : MP2_PIC0_EDGE_3_INTR_TRIGGER_7_SIZE;
          unsigned int intr_trigger_8                 : MP2_PIC0_EDGE_3_INTR_TRIGGER_8_SIZE;
          unsigned int intr_trigger_9                 : MP2_PIC0_EDGE_3_INTR_TRIGGER_9_SIZE;
          unsigned int intr_trigger_10                : MP2_PIC0_EDGE_3_INTR_TRIGGER_10_SIZE;
          unsigned int intr_trigger_11                : MP2_PIC0_EDGE_3_INTR_TRIGGER_11_SIZE;
          unsigned int intr_trigger_12                : MP2_PIC0_EDGE_3_INTR_TRIGGER_12_SIZE;
          unsigned int intr_trigger_13                : MP2_PIC0_EDGE_3_INTR_TRIGGER_13_SIZE;
          unsigned int intr_trigger_14                : MP2_PIC0_EDGE_3_INTR_TRIGGER_14_SIZE;
          unsigned int intr_trigger_15                : MP2_PIC0_EDGE_3_INTR_TRIGGER_15_SIZE;
          unsigned int intr_trigger_16                : MP2_PIC0_EDGE_3_INTR_TRIGGER_16_SIZE;
          unsigned int intr_trigger_17                : MP2_PIC0_EDGE_3_INTR_TRIGGER_17_SIZE;
          unsigned int intr_trigger_18                : MP2_PIC0_EDGE_3_INTR_TRIGGER_18_SIZE;
          unsigned int intr_trigger_19                : MP2_PIC0_EDGE_3_INTR_TRIGGER_19_SIZE;
          unsigned int intr_trigger_20                : MP2_PIC0_EDGE_3_INTR_TRIGGER_20_SIZE;
          unsigned int intr_trigger_21                : MP2_PIC0_EDGE_3_INTR_TRIGGER_21_SIZE;
          unsigned int intr_trigger_22                : MP2_PIC0_EDGE_3_INTR_TRIGGER_22_SIZE;
          unsigned int intr_trigger_23                : MP2_PIC0_EDGE_3_INTR_TRIGGER_23_SIZE;
          unsigned int intr_trigger_24                : MP2_PIC0_EDGE_3_INTR_TRIGGER_24_SIZE;
          unsigned int intr_trigger_25                : MP2_PIC0_EDGE_3_INTR_TRIGGER_25_SIZE;
          unsigned int intr_trigger_26                : MP2_PIC0_EDGE_3_INTR_TRIGGER_26_SIZE;
          unsigned int intr_trigger_27                : MP2_PIC0_EDGE_3_INTR_TRIGGER_27_SIZE;
          unsigned int intr_trigger_28                : MP2_PIC0_EDGE_3_INTR_TRIGGER_28_SIZE;
          unsigned int intr_trigger_29                : MP2_PIC0_EDGE_3_INTR_TRIGGER_29_SIZE;
          unsigned int intr_trigger_30                : MP2_PIC0_EDGE_3_INTR_TRIGGER_30_SIZE;
          unsigned int intr_trigger_31                : MP2_PIC0_EDGE_3_INTR_TRIGGER_31_SIZE;
     } mp2_pic0_edge_3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_edge_3_t {
          unsigned int intr_trigger_31                : MP2_PIC0_EDGE_3_INTR_TRIGGER_31_SIZE;
          unsigned int intr_trigger_30                : MP2_PIC0_EDGE_3_INTR_TRIGGER_30_SIZE;
          unsigned int intr_trigger_29                : MP2_PIC0_EDGE_3_INTR_TRIGGER_29_SIZE;
          unsigned int intr_trigger_28                : MP2_PIC0_EDGE_3_INTR_TRIGGER_28_SIZE;
          unsigned int intr_trigger_27                : MP2_PIC0_EDGE_3_INTR_TRIGGER_27_SIZE;
          unsigned int intr_trigger_26                : MP2_PIC0_EDGE_3_INTR_TRIGGER_26_SIZE;
          unsigned int intr_trigger_25                : MP2_PIC0_EDGE_3_INTR_TRIGGER_25_SIZE;
          unsigned int intr_trigger_24                : MP2_PIC0_EDGE_3_INTR_TRIGGER_24_SIZE;
          unsigned int intr_trigger_23                : MP2_PIC0_EDGE_3_INTR_TRIGGER_23_SIZE;
          unsigned int intr_trigger_22                : MP2_PIC0_EDGE_3_INTR_TRIGGER_22_SIZE;
          unsigned int intr_trigger_21                : MP2_PIC0_EDGE_3_INTR_TRIGGER_21_SIZE;
          unsigned int intr_trigger_20                : MP2_PIC0_EDGE_3_INTR_TRIGGER_20_SIZE;
          unsigned int intr_trigger_19                : MP2_PIC0_EDGE_3_INTR_TRIGGER_19_SIZE;
          unsigned int intr_trigger_18                : MP2_PIC0_EDGE_3_INTR_TRIGGER_18_SIZE;
          unsigned int intr_trigger_17                : MP2_PIC0_EDGE_3_INTR_TRIGGER_17_SIZE;
          unsigned int intr_trigger_16                : MP2_PIC0_EDGE_3_INTR_TRIGGER_16_SIZE;
          unsigned int intr_trigger_15                : MP2_PIC0_EDGE_3_INTR_TRIGGER_15_SIZE;
          unsigned int intr_trigger_14                : MP2_PIC0_EDGE_3_INTR_TRIGGER_14_SIZE;
          unsigned int intr_trigger_13                : MP2_PIC0_EDGE_3_INTR_TRIGGER_13_SIZE;
          unsigned int intr_trigger_12                : MP2_PIC0_EDGE_3_INTR_TRIGGER_12_SIZE;
          unsigned int intr_trigger_11                : MP2_PIC0_EDGE_3_INTR_TRIGGER_11_SIZE;
          unsigned int intr_trigger_10                : MP2_PIC0_EDGE_3_INTR_TRIGGER_10_SIZE;
          unsigned int intr_trigger_9                 : MP2_PIC0_EDGE_3_INTR_TRIGGER_9_SIZE;
          unsigned int intr_trigger_8                 : MP2_PIC0_EDGE_3_INTR_TRIGGER_8_SIZE;
          unsigned int intr_trigger_7                 : MP2_PIC0_EDGE_3_INTR_TRIGGER_7_SIZE;
          unsigned int intr_trigger_6                 : MP2_PIC0_EDGE_3_INTR_TRIGGER_6_SIZE;
          unsigned int intr_trigger_5                 : MP2_PIC0_EDGE_3_INTR_TRIGGER_5_SIZE;
          unsigned int intr_trigger_4                 : MP2_PIC0_EDGE_3_INTR_TRIGGER_4_SIZE;
          unsigned int intr_trigger_3                 : MP2_PIC0_EDGE_3_INTR_TRIGGER_3_SIZE;
          unsigned int intr_trigger_2                 : MP2_PIC0_EDGE_3_INTR_TRIGGER_2_SIZE;
          unsigned int intr_trigger_1                 : MP2_PIC0_EDGE_3_INTR_TRIGGER_1_SIZE;
          unsigned int intr_trigger_0                 : MP2_PIC0_EDGE_3_INTR_TRIGGER_0_SIZE;
     } mp2_pic0_edge_3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_edge_3_t f;
} mp2_pic0_edge_3_u;


/*
 * MP2_PIC0_PRIORITY_0 struct
 */

#define MP2_PIC0_PRIORITY_0_REG_SIZE   32
#define MP2_PIC0_PRIORITY_0_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_0_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_0_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_0_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_0_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_0_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_0_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_0_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_0_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_0_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_0_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_0_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_0_MASK \
     (MP2_PIC0_PRIORITY_0_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_0_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_0_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_0_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_0_DEFAULT    0x03020100

#define MP2_PIC0_PRIORITY_0_GET_INTR_PRIORITY_0(mp2_pic0_priority_0) \
     ((mp2_pic0_priority_0 & MP2_PIC0_PRIORITY_0_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_0_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_0_GET_INTR_PRIORITY_1(mp2_pic0_priority_0) \
     ((mp2_pic0_priority_0 & MP2_PIC0_PRIORITY_0_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_0_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_0_GET_INTR_PRIORITY_2(mp2_pic0_priority_0) \
     ((mp2_pic0_priority_0 & MP2_PIC0_PRIORITY_0_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_0_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_0_GET_INTR_PRIORITY_3(mp2_pic0_priority_0) \
     ((mp2_pic0_priority_0 & MP2_PIC0_PRIORITY_0_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_0_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_0_SET_INTR_PRIORITY_0(mp2_pic0_priority_0_reg, intr_priority_0) \
     mp2_pic0_priority_0_reg = (mp2_pic0_priority_0_reg & ~MP2_PIC0_PRIORITY_0_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_0_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_0_SET_INTR_PRIORITY_1(mp2_pic0_priority_0_reg, intr_priority_1) \
     mp2_pic0_priority_0_reg = (mp2_pic0_priority_0_reg & ~MP2_PIC0_PRIORITY_0_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_0_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_0_SET_INTR_PRIORITY_2(mp2_pic0_priority_0_reg, intr_priority_2) \
     mp2_pic0_priority_0_reg = (mp2_pic0_priority_0_reg & ~MP2_PIC0_PRIORITY_0_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_0_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_0_SET_INTR_PRIORITY_3(mp2_pic0_priority_0_reg, intr_priority_3) \
     mp2_pic0_priority_0_reg = (mp2_pic0_priority_0_reg & ~MP2_PIC0_PRIORITY_0_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_0_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_0_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_0_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_0_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_0_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_0_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_0_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_0_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_0_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_0_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_0_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_0_t f;
} mp2_pic0_priority_0_u;


/*
 * MP2_PIC0_PRIORITY_1 struct
 */

#define MP2_PIC0_PRIORITY_1_REG_SIZE   32
#define MP2_PIC0_PRIORITY_1_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_1_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_1_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_1_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_1_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_1_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_1_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_1_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_1_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_1_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_1_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_1_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_1_MASK \
     (MP2_PIC0_PRIORITY_1_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_1_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_1_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_1_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_1_DEFAULT    0x07060504

#define MP2_PIC0_PRIORITY_1_GET_INTR_PRIORITY_0(mp2_pic0_priority_1) \
     ((mp2_pic0_priority_1 & MP2_PIC0_PRIORITY_1_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_1_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_1_GET_INTR_PRIORITY_1(mp2_pic0_priority_1) \
     ((mp2_pic0_priority_1 & MP2_PIC0_PRIORITY_1_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_1_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_1_GET_INTR_PRIORITY_2(mp2_pic0_priority_1) \
     ((mp2_pic0_priority_1 & MP2_PIC0_PRIORITY_1_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_1_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_1_GET_INTR_PRIORITY_3(mp2_pic0_priority_1) \
     ((mp2_pic0_priority_1 & MP2_PIC0_PRIORITY_1_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_1_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_1_SET_INTR_PRIORITY_0(mp2_pic0_priority_1_reg, intr_priority_0) \
     mp2_pic0_priority_1_reg = (mp2_pic0_priority_1_reg & ~MP2_PIC0_PRIORITY_1_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_1_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_1_SET_INTR_PRIORITY_1(mp2_pic0_priority_1_reg, intr_priority_1) \
     mp2_pic0_priority_1_reg = (mp2_pic0_priority_1_reg & ~MP2_PIC0_PRIORITY_1_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_1_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_1_SET_INTR_PRIORITY_2(mp2_pic0_priority_1_reg, intr_priority_2) \
     mp2_pic0_priority_1_reg = (mp2_pic0_priority_1_reg & ~MP2_PIC0_PRIORITY_1_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_1_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_1_SET_INTR_PRIORITY_3(mp2_pic0_priority_1_reg, intr_priority_3) \
     mp2_pic0_priority_1_reg = (mp2_pic0_priority_1_reg & ~MP2_PIC0_PRIORITY_1_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_1_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_1_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_1_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_1_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_1_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_1_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_1_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_1_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_1_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_1_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_1_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_1_t f;
} mp2_pic0_priority_1_u;


/*
 * MP2_PIC0_PRIORITY_2 struct
 */

#define MP2_PIC0_PRIORITY_2_REG_SIZE   32
#define MP2_PIC0_PRIORITY_2_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_2_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_2_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_2_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_2_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_2_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_2_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_2_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_2_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_2_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_2_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_2_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_2_MASK \
     (MP2_PIC0_PRIORITY_2_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_2_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_2_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_2_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_2_DEFAULT    0x0b0a0908

#define MP2_PIC0_PRIORITY_2_GET_INTR_PRIORITY_0(mp2_pic0_priority_2) \
     ((mp2_pic0_priority_2 & MP2_PIC0_PRIORITY_2_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_2_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_2_GET_INTR_PRIORITY_1(mp2_pic0_priority_2) \
     ((mp2_pic0_priority_2 & MP2_PIC0_PRIORITY_2_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_2_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_2_GET_INTR_PRIORITY_2(mp2_pic0_priority_2) \
     ((mp2_pic0_priority_2 & MP2_PIC0_PRIORITY_2_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_2_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_2_GET_INTR_PRIORITY_3(mp2_pic0_priority_2) \
     ((mp2_pic0_priority_2 & MP2_PIC0_PRIORITY_2_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_2_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_2_SET_INTR_PRIORITY_0(mp2_pic0_priority_2_reg, intr_priority_0) \
     mp2_pic0_priority_2_reg = (mp2_pic0_priority_2_reg & ~MP2_PIC0_PRIORITY_2_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_2_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_2_SET_INTR_PRIORITY_1(mp2_pic0_priority_2_reg, intr_priority_1) \
     mp2_pic0_priority_2_reg = (mp2_pic0_priority_2_reg & ~MP2_PIC0_PRIORITY_2_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_2_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_2_SET_INTR_PRIORITY_2(mp2_pic0_priority_2_reg, intr_priority_2) \
     mp2_pic0_priority_2_reg = (mp2_pic0_priority_2_reg & ~MP2_PIC0_PRIORITY_2_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_2_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_2_SET_INTR_PRIORITY_3(mp2_pic0_priority_2_reg, intr_priority_3) \
     mp2_pic0_priority_2_reg = (mp2_pic0_priority_2_reg & ~MP2_PIC0_PRIORITY_2_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_2_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_2_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_2_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_2_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_2_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_2_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_2_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_2_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_2_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_2_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_2_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_2_t f;
} mp2_pic0_priority_2_u;


/*
 * MP2_PIC0_PRIORITY_3 struct
 */

#define MP2_PIC0_PRIORITY_3_REG_SIZE   32
#define MP2_PIC0_PRIORITY_3_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_3_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_3_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_3_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_3_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_3_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_3_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_3_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_3_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_3_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_3_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_3_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_3_MASK \
     (MP2_PIC0_PRIORITY_3_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_3_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_3_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_3_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_3_DEFAULT    0x0f0e0d0c

#define MP2_PIC0_PRIORITY_3_GET_INTR_PRIORITY_0(mp2_pic0_priority_3) \
     ((mp2_pic0_priority_3 & MP2_PIC0_PRIORITY_3_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_3_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_3_GET_INTR_PRIORITY_1(mp2_pic0_priority_3) \
     ((mp2_pic0_priority_3 & MP2_PIC0_PRIORITY_3_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_3_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_3_GET_INTR_PRIORITY_2(mp2_pic0_priority_3) \
     ((mp2_pic0_priority_3 & MP2_PIC0_PRIORITY_3_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_3_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_3_GET_INTR_PRIORITY_3(mp2_pic0_priority_3) \
     ((mp2_pic0_priority_3 & MP2_PIC0_PRIORITY_3_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_3_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_3_SET_INTR_PRIORITY_0(mp2_pic0_priority_3_reg, intr_priority_0) \
     mp2_pic0_priority_3_reg = (mp2_pic0_priority_3_reg & ~MP2_PIC0_PRIORITY_3_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_3_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_3_SET_INTR_PRIORITY_1(mp2_pic0_priority_3_reg, intr_priority_1) \
     mp2_pic0_priority_3_reg = (mp2_pic0_priority_3_reg & ~MP2_PIC0_PRIORITY_3_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_3_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_3_SET_INTR_PRIORITY_2(mp2_pic0_priority_3_reg, intr_priority_2) \
     mp2_pic0_priority_3_reg = (mp2_pic0_priority_3_reg & ~MP2_PIC0_PRIORITY_3_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_3_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_3_SET_INTR_PRIORITY_3(mp2_pic0_priority_3_reg, intr_priority_3) \
     mp2_pic0_priority_3_reg = (mp2_pic0_priority_3_reg & ~MP2_PIC0_PRIORITY_3_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_3_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_3_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_3_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_3_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_3_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_3_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_3_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_3_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_3_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_3_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_3_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_3_t f;
} mp2_pic0_priority_3_u;


/*
 * MP2_PIC0_PRIORITY_4 struct
 */

#define MP2_PIC0_PRIORITY_4_REG_SIZE   32
#define MP2_PIC0_PRIORITY_4_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_4_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_4_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_4_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_4_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_4_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_4_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_4_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_4_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_4_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_4_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_4_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_4_MASK \
     (MP2_PIC0_PRIORITY_4_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_4_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_4_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_4_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_4_DEFAULT    0x13121110

#define MP2_PIC0_PRIORITY_4_GET_INTR_PRIORITY_0(mp2_pic0_priority_4) \
     ((mp2_pic0_priority_4 & MP2_PIC0_PRIORITY_4_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_4_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_4_GET_INTR_PRIORITY_1(mp2_pic0_priority_4) \
     ((mp2_pic0_priority_4 & MP2_PIC0_PRIORITY_4_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_4_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_4_GET_INTR_PRIORITY_2(mp2_pic0_priority_4) \
     ((mp2_pic0_priority_4 & MP2_PIC0_PRIORITY_4_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_4_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_4_GET_INTR_PRIORITY_3(mp2_pic0_priority_4) \
     ((mp2_pic0_priority_4 & MP2_PIC0_PRIORITY_4_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_4_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_4_SET_INTR_PRIORITY_0(mp2_pic0_priority_4_reg, intr_priority_0) \
     mp2_pic0_priority_4_reg = (mp2_pic0_priority_4_reg & ~MP2_PIC0_PRIORITY_4_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_4_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_4_SET_INTR_PRIORITY_1(mp2_pic0_priority_4_reg, intr_priority_1) \
     mp2_pic0_priority_4_reg = (mp2_pic0_priority_4_reg & ~MP2_PIC0_PRIORITY_4_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_4_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_4_SET_INTR_PRIORITY_2(mp2_pic0_priority_4_reg, intr_priority_2) \
     mp2_pic0_priority_4_reg = (mp2_pic0_priority_4_reg & ~MP2_PIC0_PRIORITY_4_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_4_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_4_SET_INTR_PRIORITY_3(mp2_pic0_priority_4_reg, intr_priority_3) \
     mp2_pic0_priority_4_reg = (mp2_pic0_priority_4_reg & ~MP2_PIC0_PRIORITY_4_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_4_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_4_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_4_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_4_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_4_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_4_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_4_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_4_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_4_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_4_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_4_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_4_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_4_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_4_t f;
} mp2_pic0_priority_4_u;


/*
 * MP2_PIC0_PRIORITY_5 struct
 */

#define MP2_PIC0_PRIORITY_5_REG_SIZE   32
#define MP2_PIC0_PRIORITY_5_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_5_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_5_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_5_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_5_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_5_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_5_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_5_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_5_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_5_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_5_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_5_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_5_MASK \
     (MP2_PIC0_PRIORITY_5_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_5_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_5_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_5_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_5_DEFAULT    0x17161514

#define MP2_PIC0_PRIORITY_5_GET_INTR_PRIORITY_0(mp2_pic0_priority_5) \
     ((mp2_pic0_priority_5 & MP2_PIC0_PRIORITY_5_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_5_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_5_GET_INTR_PRIORITY_1(mp2_pic0_priority_5) \
     ((mp2_pic0_priority_5 & MP2_PIC0_PRIORITY_5_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_5_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_5_GET_INTR_PRIORITY_2(mp2_pic0_priority_5) \
     ((mp2_pic0_priority_5 & MP2_PIC0_PRIORITY_5_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_5_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_5_GET_INTR_PRIORITY_3(mp2_pic0_priority_5) \
     ((mp2_pic0_priority_5 & MP2_PIC0_PRIORITY_5_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_5_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_5_SET_INTR_PRIORITY_0(mp2_pic0_priority_5_reg, intr_priority_0) \
     mp2_pic0_priority_5_reg = (mp2_pic0_priority_5_reg & ~MP2_PIC0_PRIORITY_5_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_5_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_5_SET_INTR_PRIORITY_1(mp2_pic0_priority_5_reg, intr_priority_1) \
     mp2_pic0_priority_5_reg = (mp2_pic0_priority_5_reg & ~MP2_PIC0_PRIORITY_5_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_5_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_5_SET_INTR_PRIORITY_2(mp2_pic0_priority_5_reg, intr_priority_2) \
     mp2_pic0_priority_5_reg = (mp2_pic0_priority_5_reg & ~MP2_PIC0_PRIORITY_5_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_5_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_5_SET_INTR_PRIORITY_3(mp2_pic0_priority_5_reg, intr_priority_3) \
     mp2_pic0_priority_5_reg = (mp2_pic0_priority_5_reg & ~MP2_PIC0_PRIORITY_5_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_5_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_5_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_5_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_5_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_5_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_5_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_5_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_5_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_5_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_5_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_5_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_5_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_5_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_5_t f;
} mp2_pic0_priority_5_u;


/*
 * MP2_PIC0_PRIORITY_6 struct
 */

#define MP2_PIC0_PRIORITY_6_REG_SIZE   32
#define MP2_PIC0_PRIORITY_6_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_6_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_6_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_6_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_6_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_6_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_6_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_6_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_6_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_6_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_6_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_6_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_6_MASK \
     (MP2_PIC0_PRIORITY_6_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_6_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_6_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_6_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_6_DEFAULT    0x1b1a1918

#define MP2_PIC0_PRIORITY_6_GET_INTR_PRIORITY_0(mp2_pic0_priority_6) \
     ((mp2_pic0_priority_6 & MP2_PIC0_PRIORITY_6_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_6_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_6_GET_INTR_PRIORITY_1(mp2_pic0_priority_6) \
     ((mp2_pic0_priority_6 & MP2_PIC0_PRIORITY_6_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_6_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_6_GET_INTR_PRIORITY_2(mp2_pic0_priority_6) \
     ((mp2_pic0_priority_6 & MP2_PIC0_PRIORITY_6_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_6_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_6_GET_INTR_PRIORITY_3(mp2_pic0_priority_6) \
     ((mp2_pic0_priority_6 & MP2_PIC0_PRIORITY_6_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_6_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_6_SET_INTR_PRIORITY_0(mp2_pic0_priority_6_reg, intr_priority_0) \
     mp2_pic0_priority_6_reg = (mp2_pic0_priority_6_reg & ~MP2_PIC0_PRIORITY_6_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_6_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_6_SET_INTR_PRIORITY_1(mp2_pic0_priority_6_reg, intr_priority_1) \
     mp2_pic0_priority_6_reg = (mp2_pic0_priority_6_reg & ~MP2_PIC0_PRIORITY_6_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_6_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_6_SET_INTR_PRIORITY_2(mp2_pic0_priority_6_reg, intr_priority_2) \
     mp2_pic0_priority_6_reg = (mp2_pic0_priority_6_reg & ~MP2_PIC0_PRIORITY_6_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_6_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_6_SET_INTR_PRIORITY_3(mp2_pic0_priority_6_reg, intr_priority_3) \
     mp2_pic0_priority_6_reg = (mp2_pic0_priority_6_reg & ~MP2_PIC0_PRIORITY_6_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_6_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_6_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_6_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_6_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_6_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_6_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_6_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_6_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_6_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_6_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_6_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_6_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_6_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_6_t f;
} mp2_pic0_priority_6_u;


/*
 * MP2_PIC0_PRIORITY_7 struct
 */

#define MP2_PIC0_PRIORITY_7_REG_SIZE   32
#define MP2_PIC0_PRIORITY_7_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_7_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_7_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_7_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_7_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_7_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_7_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_7_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_7_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_7_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_7_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_7_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_7_MASK \
     (MP2_PIC0_PRIORITY_7_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_7_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_7_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_7_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_7_DEFAULT    0x1f1e1d1c

#define MP2_PIC0_PRIORITY_7_GET_INTR_PRIORITY_0(mp2_pic0_priority_7) \
     ((mp2_pic0_priority_7 & MP2_PIC0_PRIORITY_7_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_7_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_7_GET_INTR_PRIORITY_1(mp2_pic0_priority_7) \
     ((mp2_pic0_priority_7 & MP2_PIC0_PRIORITY_7_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_7_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_7_GET_INTR_PRIORITY_2(mp2_pic0_priority_7) \
     ((mp2_pic0_priority_7 & MP2_PIC0_PRIORITY_7_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_7_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_7_GET_INTR_PRIORITY_3(mp2_pic0_priority_7) \
     ((mp2_pic0_priority_7 & MP2_PIC0_PRIORITY_7_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_7_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_7_SET_INTR_PRIORITY_0(mp2_pic0_priority_7_reg, intr_priority_0) \
     mp2_pic0_priority_7_reg = (mp2_pic0_priority_7_reg & ~MP2_PIC0_PRIORITY_7_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_7_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_7_SET_INTR_PRIORITY_1(mp2_pic0_priority_7_reg, intr_priority_1) \
     mp2_pic0_priority_7_reg = (mp2_pic0_priority_7_reg & ~MP2_PIC0_PRIORITY_7_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_7_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_7_SET_INTR_PRIORITY_2(mp2_pic0_priority_7_reg, intr_priority_2) \
     mp2_pic0_priority_7_reg = (mp2_pic0_priority_7_reg & ~MP2_PIC0_PRIORITY_7_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_7_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_7_SET_INTR_PRIORITY_3(mp2_pic0_priority_7_reg, intr_priority_3) \
     mp2_pic0_priority_7_reg = (mp2_pic0_priority_7_reg & ~MP2_PIC0_PRIORITY_7_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_7_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_7_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_7_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_7_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_7_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_7_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_7_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_7_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_7_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_7_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_7_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_7_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_7_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_7_t f;
} mp2_pic0_priority_7_u;


/*
 * MP2_PIC0_PRIORITY_8 struct
 */

#define MP2_PIC0_PRIORITY_8_REG_SIZE   32
#define MP2_PIC0_PRIORITY_8_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_8_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_8_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_8_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_8_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_8_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_8_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_8_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_8_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_8_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_8_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_8_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_8_MASK \
     (MP2_PIC0_PRIORITY_8_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_8_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_8_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_8_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_8_DEFAULT    0x23222120

#define MP2_PIC0_PRIORITY_8_GET_INTR_PRIORITY_0(mp2_pic0_priority_8) \
     ((mp2_pic0_priority_8 & MP2_PIC0_PRIORITY_8_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_8_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_8_GET_INTR_PRIORITY_1(mp2_pic0_priority_8) \
     ((mp2_pic0_priority_8 & MP2_PIC0_PRIORITY_8_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_8_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_8_GET_INTR_PRIORITY_2(mp2_pic0_priority_8) \
     ((mp2_pic0_priority_8 & MP2_PIC0_PRIORITY_8_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_8_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_8_GET_INTR_PRIORITY_3(mp2_pic0_priority_8) \
     ((mp2_pic0_priority_8 & MP2_PIC0_PRIORITY_8_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_8_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_8_SET_INTR_PRIORITY_0(mp2_pic0_priority_8_reg, intr_priority_0) \
     mp2_pic0_priority_8_reg = (mp2_pic0_priority_8_reg & ~MP2_PIC0_PRIORITY_8_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_8_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_8_SET_INTR_PRIORITY_1(mp2_pic0_priority_8_reg, intr_priority_1) \
     mp2_pic0_priority_8_reg = (mp2_pic0_priority_8_reg & ~MP2_PIC0_PRIORITY_8_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_8_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_8_SET_INTR_PRIORITY_2(mp2_pic0_priority_8_reg, intr_priority_2) \
     mp2_pic0_priority_8_reg = (mp2_pic0_priority_8_reg & ~MP2_PIC0_PRIORITY_8_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_8_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_8_SET_INTR_PRIORITY_3(mp2_pic0_priority_8_reg, intr_priority_3) \
     mp2_pic0_priority_8_reg = (mp2_pic0_priority_8_reg & ~MP2_PIC0_PRIORITY_8_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_8_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_8_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_8_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_8_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_8_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_8_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_8_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_8_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_8_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_8_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_8_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_8_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_8_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_8_t f;
} mp2_pic0_priority_8_u;


/*
 * MP2_PIC0_PRIORITY_9 struct
 */

#define MP2_PIC0_PRIORITY_9_REG_SIZE   32
#define MP2_PIC0_PRIORITY_9_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_9_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_9_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_9_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_9_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_9_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_9_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_9_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_9_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_9_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_9_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_9_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_9_MASK \
     (MP2_PIC0_PRIORITY_9_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_9_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_9_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_9_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_9_DEFAULT    0x27262524

#define MP2_PIC0_PRIORITY_9_GET_INTR_PRIORITY_0(mp2_pic0_priority_9) \
     ((mp2_pic0_priority_9 & MP2_PIC0_PRIORITY_9_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_9_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_9_GET_INTR_PRIORITY_1(mp2_pic0_priority_9) \
     ((mp2_pic0_priority_9 & MP2_PIC0_PRIORITY_9_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_9_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_9_GET_INTR_PRIORITY_2(mp2_pic0_priority_9) \
     ((mp2_pic0_priority_9 & MP2_PIC0_PRIORITY_9_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_9_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_9_GET_INTR_PRIORITY_3(mp2_pic0_priority_9) \
     ((mp2_pic0_priority_9 & MP2_PIC0_PRIORITY_9_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_9_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_9_SET_INTR_PRIORITY_0(mp2_pic0_priority_9_reg, intr_priority_0) \
     mp2_pic0_priority_9_reg = (mp2_pic0_priority_9_reg & ~MP2_PIC0_PRIORITY_9_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_9_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_9_SET_INTR_PRIORITY_1(mp2_pic0_priority_9_reg, intr_priority_1) \
     mp2_pic0_priority_9_reg = (mp2_pic0_priority_9_reg & ~MP2_PIC0_PRIORITY_9_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_9_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_9_SET_INTR_PRIORITY_2(mp2_pic0_priority_9_reg, intr_priority_2) \
     mp2_pic0_priority_9_reg = (mp2_pic0_priority_9_reg & ~MP2_PIC0_PRIORITY_9_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_9_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_9_SET_INTR_PRIORITY_3(mp2_pic0_priority_9_reg, intr_priority_3) \
     mp2_pic0_priority_9_reg = (mp2_pic0_priority_9_reg & ~MP2_PIC0_PRIORITY_9_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_9_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_9_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_9_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_9_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_9_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_9_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_9_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_9_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_9_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_9_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_9_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_9_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_9_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_9_t f;
} mp2_pic0_priority_9_u;


/*
 * MP2_PIC0_PRIORITY_10 struct
 */

#define MP2_PIC0_PRIORITY_10_REG_SIZE  32
#define MP2_PIC0_PRIORITY_10_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_10_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_10_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_10_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_10_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_10_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_10_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_10_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_10_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_10_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_10_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_10_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_10_MASK \
     (MP2_PIC0_PRIORITY_10_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_10_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_10_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_10_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_10_DEFAULT   0x2b2a2928

#define MP2_PIC0_PRIORITY_10_GET_INTR_PRIORITY_0(mp2_pic0_priority_10) \
     ((mp2_pic0_priority_10 & MP2_PIC0_PRIORITY_10_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_10_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_10_GET_INTR_PRIORITY_1(mp2_pic0_priority_10) \
     ((mp2_pic0_priority_10 & MP2_PIC0_PRIORITY_10_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_10_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_10_GET_INTR_PRIORITY_2(mp2_pic0_priority_10) \
     ((mp2_pic0_priority_10 & MP2_PIC0_PRIORITY_10_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_10_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_10_GET_INTR_PRIORITY_3(mp2_pic0_priority_10) \
     ((mp2_pic0_priority_10 & MP2_PIC0_PRIORITY_10_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_10_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_10_SET_INTR_PRIORITY_0(mp2_pic0_priority_10_reg, intr_priority_0) \
     mp2_pic0_priority_10_reg = (mp2_pic0_priority_10_reg & ~MP2_PIC0_PRIORITY_10_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_10_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_10_SET_INTR_PRIORITY_1(mp2_pic0_priority_10_reg, intr_priority_1) \
     mp2_pic0_priority_10_reg = (mp2_pic0_priority_10_reg & ~MP2_PIC0_PRIORITY_10_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_10_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_10_SET_INTR_PRIORITY_2(mp2_pic0_priority_10_reg, intr_priority_2) \
     mp2_pic0_priority_10_reg = (mp2_pic0_priority_10_reg & ~MP2_PIC0_PRIORITY_10_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_10_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_10_SET_INTR_PRIORITY_3(mp2_pic0_priority_10_reg, intr_priority_3) \
     mp2_pic0_priority_10_reg = (mp2_pic0_priority_10_reg & ~MP2_PIC0_PRIORITY_10_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_10_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_10_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_10_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_10_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_10_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_10_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_10_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_10_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_10_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_10_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_10_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_10_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_10_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_10_t f;
} mp2_pic0_priority_10_u;


/*
 * MP2_PIC0_PRIORITY_11 struct
 */

#define MP2_PIC0_PRIORITY_11_REG_SIZE  32
#define MP2_PIC0_PRIORITY_11_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_11_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_11_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_11_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_11_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_11_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_11_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_11_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_11_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_11_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_11_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_11_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_11_MASK \
     (MP2_PIC0_PRIORITY_11_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_11_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_11_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_11_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_11_DEFAULT   0x2f2e2d2c

#define MP2_PIC0_PRIORITY_11_GET_INTR_PRIORITY_0(mp2_pic0_priority_11) \
     ((mp2_pic0_priority_11 & MP2_PIC0_PRIORITY_11_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_11_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_11_GET_INTR_PRIORITY_1(mp2_pic0_priority_11) \
     ((mp2_pic0_priority_11 & MP2_PIC0_PRIORITY_11_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_11_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_11_GET_INTR_PRIORITY_2(mp2_pic0_priority_11) \
     ((mp2_pic0_priority_11 & MP2_PIC0_PRIORITY_11_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_11_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_11_GET_INTR_PRIORITY_3(mp2_pic0_priority_11) \
     ((mp2_pic0_priority_11 & MP2_PIC0_PRIORITY_11_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_11_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_11_SET_INTR_PRIORITY_0(mp2_pic0_priority_11_reg, intr_priority_0) \
     mp2_pic0_priority_11_reg = (mp2_pic0_priority_11_reg & ~MP2_PIC0_PRIORITY_11_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_11_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_11_SET_INTR_PRIORITY_1(mp2_pic0_priority_11_reg, intr_priority_1) \
     mp2_pic0_priority_11_reg = (mp2_pic0_priority_11_reg & ~MP2_PIC0_PRIORITY_11_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_11_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_11_SET_INTR_PRIORITY_2(mp2_pic0_priority_11_reg, intr_priority_2) \
     mp2_pic0_priority_11_reg = (mp2_pic0_priority_11_reg & ~MP2_PIC0_PRIORITY_11_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_11_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_11_SET_INTR_PRIORITY_3(mp2_pic0_priority_11_reg, intr_priority_3) \
     mp2_pic0_priority_11_reg = (mp2_pic0_priority_11_reg & ~MP2_PIC0_PRIORITY_11_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_11_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_11_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_11_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_11_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_11_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_11_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_11_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_11_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_11_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_11_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_11_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_11_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_11_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_11_t f;
} mp2_pic0_priority_11_u;


/*
 * MP2_PIC0_PRIORITY_12 struct
 */

#define MP2_PIC0_PRIORITY_12_REG_SIZE  32
#define MP2_PIC0_PRIORITY_12_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_12_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_12_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_12_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_12_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_12_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_12_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_12_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_12_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_12_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_12_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_12_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_12_MASK \
     (MP2_PIC0_PRIORITY_12_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_12_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_12_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_12_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_12_DEFAULT   0x33323130

#define MP2_PIC0_PRIORITY_12_GET_INTR_PRIORITY_0(mp2_pic0_priority_12) \
     ((mp2_pic0_priority_12 & MP2_PIC0_PRIORITY_12_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_12_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_12_GET_INTR_PRIORITY_1(mp2_pic0_priority_12) \
     ((mp2_pic0_priority_12 & MP2_PIC0_PRIORITY_12_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_12_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_12_GET_INTR_PRIORITY_2(mp2_pic0_priority_12) \
     ((mp2_pic0_priority_12 & MP2_PIC0_PRIORITY_12_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_12_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_12_GET_INTR_PRIORITY_3(mp2_pic0_priority_12) \
     ((mp2_pic0_priority_12 & MP2_PIC0_PRIORITY_12_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_12_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_12_SET_INTR_PRIORITY_0(mp2_pic0_priority_12_reg, intr_priority_0) \
     mp2_pic0_priority_12_reg = (mp2_pic0_priority_12_reg & ~MP2_PIC0_PRIORITY_12_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_12_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_12_SET_INTR_PRIORITY_1(mp2_pic0_priority_12_reg, intr_priority_1) \
     mp2_pic0_priority_12_reg = (mp2_pic0_priority_12_reg & ~MP2_PIC0_PRIORITY_12_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_12_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_12_SET_INTR_PRIORITY_2(mp2_pic0_priority_12_reg, intr_priority_2) \
     mp2_pic0_priority_12_reg = (mp2_pic0_priority_12_reg & ~MP2_PIC0_PRIORITY_12_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_12_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_12_SET_INTR_PRIORITY_3(mp2_pic0_priority_12_reg, intr_priority_3) \
     mp2_pic0_priority_12_reg = (mp2_pic0_priority_12_reg & ~MP2_PIC0_PRIORITY_12_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_12_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_12_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_12_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_12_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_12_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_12_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_12_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_12_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_12_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_12_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_12_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_12_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_12_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_12_t f;
} mp2_pic0_priority_12_u;


/*
 * MP2_PIC0_PRIORITY_13 struct
 */

#define MP2_PIC0_PRIORITY_13_REG_SIZE  32
#define MP2_PIC0_PRIORITY_13_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_13_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_13_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_13_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_13_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_13_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_13_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_13_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_13_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_13_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_13_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_13_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_13_MASK \
     (MP2_PIC0_PRIORITY_13_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_13_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_13_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_13_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_13_DEFAULT   0x37363534

#define MP2_PIC0_PRIORITY_13_GET_INTR_PRIORITY_0(mp2_pic0_priority_13) \
     ((mp2_pic0_priority_13 & MP2_PIC0_PRIORITY_13_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_13_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_13_GET_INTR_PRIORITY_1(mp2_pic0_priority_13) \
     ((mp2_pic0_priority_13 & MP2_PIC0_PRIORITY_13_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_13_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_13_GET_INTR_PRIORITY_2(mp2_pic0_priority_13) \
     ((mp2_pic0_priority_13 & MP2_PIC0_PRIORITY_13_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_13_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_13_GET_INTR_PRIORITY_3(mp2_pic0_priority_13) \
     ((mp2_pic0_priority_13 & MP2_PIC0_PRIORITY_13_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_13_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_13_SET_INTR_PRIORITY_0(mp2_pic0_priority_13_reg, intr_priority_0) \
     mp2_pic0_priority_13_reg = (mp2_pic0_priority_13_reg & ~MP2_PIC0_PRIORITY_13_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_13_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_13_SET_INTR_PRIORITY_1(mp2_pic0_priority_13_reg, intr_priority_1) \
     mp2_pic0_priority_13_reg = (mp2_pic0_priority_13_reg & ~MP2_PIC0_PRIORITY_13_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_13_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_13_SET_INTR_PRIORITY_2(mp2_pic0_priority_13_reg, intr_priority_2) \
     mp2_pic0_priority_13_reg = (mp2_pic0_priority_13_reg & ~MP2_PIC0_PRIORITY_13_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_13_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_13_SET_INTR_PRIORITY_3(mp2_pic0_priority_13_reg, intr_priority_3) \
     mp2_pic0_priority_13_reg = (mp2_pic0_priority_13_reg & ~MP2_PIC0_PRIORITY_13_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_13_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_13_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_13_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_13_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_13_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_13_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_13_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_13_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_13_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_13_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_13_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_13_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_13_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_13_t f;
} mp2_pic0_priority_13_u;


/*
 * MP2_PIC0_PRIORITY_14 struct
 */

#define MP2_PIC0_PRIORITY_14_REG_SIZE  32
#define MP2_PIC0_PRIORITY_14_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_14_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_14_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_14_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_14_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_14_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_14_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_14_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_14_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_14_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_14_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_14_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_14_MASK \
     (MP2_PIC0_PRIORITY_14_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_14_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_14_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_14_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_14_DEFAULT   0x3b3a3938

#define MP2_PIC0_PRIORITY_14_GET_INTR_PRIORITY_0(mp2_pic0_priority_14) \
     ((mp2_pic0_priority_14 & MP2_PIC0_PRIORITY_14_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_14_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_14_GET_INTR_PRIORITY_1(mp2_pic0_priority_14) \
     ((mp2_pic0_priority_14 & MP2_PIC0_PRIORITY_14_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_14_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_14_GET_INTR_PRIORITY_2(mp2_pic0_priority_14) \
     ((mp2_pic0_priority_14 & MP2_PIC0_PRIORITY_14_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_14_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_14_GET_INTR_PRIORITY_3(mp2_pic0_priority_14) \
     ((mp2_pic0_priority_14 & MP2_PIC0_PRIORITY_14_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_14_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_14_SET_INTR_PRIORITY_0(mp2_pic0_priority_14_reg, intr_priority_0) \
     mp2_pic0_priority_14_reg = (mp2_pic0_priority_14_reg & ~MP2_PIC0_PRIORITY_14_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_14_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_14_SET_INTR_PRIORITY_1(mp2_pic0_priority_14_reg, intr_priority_1) \
     mp2_pic0_priority_14_reg = (mp2_pic0_priority_14_reg & ~MP2_PIC0_PRIORITY_14_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_14_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_14_SET_INTR_PRIORITY_2(mp2_pic0_priority_14_reg, intr_priority_2) \
     mp2_pic0_priority_14_reg = (mp2_pic0_priority_14_reg & ~MP2_PIC0_PRIORITY_14_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_14_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_14_SET_INTR_PRIORITY_3(mp2_pic0_priority_14_reg, intr_priority_3) \
     mp2_pic0_priority_14_reg = (mp2_pic0_priority_14_reg & ~MP2_PIC0_PRIORITY_14_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_14_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_14_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_14_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_14_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_14_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_14_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_14_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_14_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_14_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_14_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_14_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_14_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_14_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_14_t f;
} mp2_pic0_priority_14_u;


/*
 * MP2_PIC0_PRIORITY_15 struct
 */

#define MP2_PIC0_PRIORITY_15_REG_SIZE  32
#define MP2_PIC0_PRIORITY_15_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_15_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_15_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_15_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_15_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_15_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_15_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_15_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_15_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_15_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_15_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_15_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_15_MASK \
     (MP2_PIC0_PRIORITY_15_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_15_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_15_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_15_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_15_DEFAULT   0x3f3e3d3c

#define MP2_PIC0_PRIORITY_15_GET_INTR_PRIORITY_0(mp2_pic0_priority_15) \
     ((mp2_pic0_priority_15 & MP2_PIC0_PRIORITY_15_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_15_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_15_GET_INTR_PRIORITY_1(mp2_pic0_priority_15) \
     ((mp2_pic0_priority_15 & MP2_PIC0_PRIORITY_15_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_15_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_15_GET_INTR_PRIORITY_2(mp2_pic0_priority_15) \
     ((mp2_pic0_priority_15 & MP2_PIC0_PRIORITY_15_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_15_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_15_GET_INTR_PRIORITY_3(mp2_pic0_priority_15) \
     ((mp2_pic0_priority_15 & MP2_PIC0_PRIORITY_15_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_15_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_15_SET_INTR_PRIORITY_0(mp2_pic0_priority_15_reg, intr_priority_0) \
     mp2_pic0_priority_15_reg = (mp2_pic0_priority_15_reg & ~MP2_PIC0_PRIORITY_15_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_15_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_15_SET_INTR_PRIORITY_1(mp2_pic0_priority_15_reg, intr_priority_1) \
     mp2_pic0_priority_15_reg = (mp2_pic0_priority_15_reg & ~MP2_PIC0_PRIORITY_15_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_15_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_15_SET_INTR_PRIORITY_2(mp2_pic0_priority_15_reg, intr_priority_2) \
     mp2_pic0_priority_15_reg = (mp2_pic0_priority_15_reg & ~MP2_PIC0_PRIORITY_15_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_15_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_15_SET_INTR_PRIORITY_3(mp2_pic0_priority_15_reg, intr_priority_3) \
     mp2_pic0_priority_15_reg = (mp2_pic0_priority_15_reg & ~MP2_PIC0_PRIORITY_15_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_15_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_15_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_15_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_15_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_15_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_15_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_15_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_15_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_15_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_15_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_15_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_15_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_15_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_15_t f;
} mp2_pic0_priority_15_u;


/*
 * MP2_PIC0_PRIORITY_16 struct
 */

#define MP2_PIC0_PRIORITY_16_REG_SIZE  32
#define MP2_PIC0_PRIORITY_16_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_16_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_16_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_16_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_16_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_16_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_16_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_16_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_16_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_16_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_16_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_16_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_16_MASK \
     (MP2_PIC0_PRIORITY_16_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_16_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_16_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_16_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_16_DEFAULT   0x43424140

#define MP2_PIC0_PRIORITY_16_GET_INTR_PRIORITY_0(mp2_pic0_priority_16) \
     ((mp2_pic0_priority_16 & MP2_PIC0_PRIORITY_16_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_16_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_16_GET_INTR_PRIORITY_1(mp2_pic0_priority_16) \
     ((mp2_pic0_priority_16 & MP2_PIC0_PRIORITY_16_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_16_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_16_GET_INTR_PRIORITY_2(mp2_pic0_priority_16) \
     ((mp2_pic0_priority_16 & MP2_PIC0_PRIORITY_16_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_16_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_16_GET_INTR_PRIORITY_3(mp2_pic0_priority_16) \
     ((mp2_pic0_priority_16 & MP2_PIC0_PRIORITY_16_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_16_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_16_SET_INTR_PRIORITY_0(mp2_pic0_priority_16_reg, intr_priority_0) \
     mp2_pic0_priority_16_reg = (mp2_pic0_priority_16_reg & ~MP2_PIC0_PRIORITY_16_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_16_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_16_SET_INTR_PRIORITY_1(mp2_pic0_priority_16_reg, intr_priority_1) \
     mp2_pic0_priority_16_reg = (mp2_pic0_priority_16_reg & ~MP2_PIC0_PRIORITY_16_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_16_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_16_SET_INTR_PRIORITY_2(mp2_pic0_priority_16_reg, intr_priority_2) \
     mp2_pic0_priority_16_reg = (mp2_pic0_priority_16_reg & ~MP2_PIC0_PRIORITY_16_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_16_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_16_SET_INTR_PRIORITY_3(mp2_pic0_priority_16_reg, intr_priority_3) \
     mp2_pic0_priority_16_reg = (mp2_pic0_priority_16_reg & ~MP2_PIC0_PRIORITY_16_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_16_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_16_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_16_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_16_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_16_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_16_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_16_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_16_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_16_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_16_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_16_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_16_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_16_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_16_t f;
} mp2_pic0_priority_16_u;


/*
 * MP2_PIC0_PRIORITY_17 struct
 */

#define MP2_PIC0_PRIORITY_17_REG_SIZE  32
#define MP2_PIC0_PRIORITY_17_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_17_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_17_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_17_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_17_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_17_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_17_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_17_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_17_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_17_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_17_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_17_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_17_MASK \
     (MP2_PIC0_PRIORITY_17_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_17_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_17_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_17_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_17_DEFAULT   0x47464544

#define MP2_PIC0_PRIORITY_17_GET_INTR_PRIORITY_0(mp2_pic0_priority_17) \
     ((mp2_pic0_priority_17 & MP2_PIC0_PRIORITY_17_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_17_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_17_GET_INTR_PRIORITY_1(mp2_pic0_priority_17) \
     ((mp2_pic0_priority_17 & MP2_PIC0_PRIORITY_17_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_17_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_17_GET_INTR_PRIORITY_2(mp2_pic0_priority_17) \
     ((mp2_pic0_priority_17 & MP2_PIC0_PRIORITY_17_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_17_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_17_GET_INTR_PRIORITY_3(mp2_pic0_priority_17) \
     ((mp2_pic0_priority_17 & MP2_PIC0_PRIORITY_17_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_17_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_17_SET_INTR_PRIORITY_0(mp2_pic0_priority_17_reg, intr_priority_0) \
     mp2_pic0_priority_17_reg = (mp2_pic0_priority_17_reg & ~MP2_PIC0_PRIORITY_17_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_17_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_17_SET_INTR_PRIORITY_1(mp2_pic0_priority_17_reg, intr_priority_1) \
     mp2_pic0_priority_17_reg = (mp2_pic0_priority_17_reg & ~MP2_PIC0_PRIORITY_17_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_17_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_17_SET_INTR_PRIORITY_2(mp2_pic0_priority_17_reg, intr_priority_2) \
     mp2_pic0_priority_17_reg = (mp2_pic0_priority_17_reg & ~MP2_PIC0_PRIORITY_17_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_17_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_17_SET_INTR_PRIORITY_3(mp2_pic0_priority_17_reg, intr_priority_3) \
     mp2_pic0_priority_17_reg = (mp2_pic0_priority_17_reg & ~MP2_PIC0_PRIORITY_17_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_17_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_17_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_17_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_17_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_17_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_17_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_17_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_17_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_17_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_17_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_17_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_17_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_17_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_17_t f;
} mp2_pic0_priority_17_u;


/*
 * MP2_PIC0_PRIORITY_18 struct
 */

#define MP2_PIC0_PRIORITY_18_REG_SIZE  32
#define MP2_PIC0_PRIORITY_18_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_18_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_18_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_18_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_18_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_18_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_18_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_18_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_18_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_18_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_18_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_18_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_18_MASK \
     (MP2_PIC0_PRIORITY_18_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_18_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_18_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_18_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_18_DEFAULT   0x4b4a4948

#define MP2_PIC0_PRIORITY_18_GET_INTR_PRIORITY_0(mp2_pic0_priority_18) \
     ((mp2_pic0_priority_18 & MP2_PIC0_PRIORITY_18_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_18_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_18_GET_INTR_PRIORITY_1(mp2_pic0_priority_18) \
     ((mp2_pic0_priority_18 & MP2_PIC0_PRIORITY_18_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_18_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_18_GET_INTR_PRIORITY_2(mp2_pic0_priority_18) \
     ((mp2_pic0_priority_18 & MP2_PIC0_PRIORITY_18_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_18_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_18_GET_INTR_PRIORITY_3(mp2_pic0_priority_18) \
     ((mp2_pic0_priority_18 & MP2_PIC0_PRIORITY_18_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_18_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_18_SET_INTR_PRIORITY_0(mp2_pic0_priority_18_reg, intr_priority_0) \
     mp2_pic0_priority_18_reg = (mp2_pic0_priority_18_reg & ~MP2_PIC0_PRIORITY_18_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_18_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_18_SET_INTR_PRIORITY_1(mp2_pic0_priority_18_reg, intr_priority_1) \
     mp2_pic0_priority_18_reg = (mp2_pic0_priority_18_reg & ~MP2_PIC0_PRIORITY_18_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_18_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_18_SET_INTR_PRIORITY_2(mp2_pic0_priority_18_reg, intr_priority_2) \
     mp2_pic0_priority_18_reg = (mp2_pic0_priority_18_reg & ~MP2_PIC0_PRIORITY_18_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_18_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_18_SET_INTR_PRIORITY_3(mp2_pic0_priority_18_reg, intr_priority_3) \
     mp2_pic0_priority_18_reg = (mp2_pic0_priority_18_reg & ~MP2_PIC0_PRIORITY_18_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_18_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_18_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_18_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_18_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_18_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_18_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_18_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_18_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_18_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_18_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_18_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_18_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_18_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_18_t f;
} mp2_pic0_priority_18_u;


/*
 * MP2_PIC0_PRIORITY_19 struct
 */

#define MP2_PIC0_PRIORITY_19_REG_SIZE  32
#define MP2_PIC0_PRIORITY_19_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_19_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_19_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_19_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_19_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_19_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_19_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_19_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_19_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_19_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_19_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_19_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_19_MASK \
     (MP2_PIC0_PRIORITY_19_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_19_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_19_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_19_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_19_DEFAULT   0x4f4e4d4c

#define MP2_PIC0_PRIORITY_19_GET_INTR_PRIORITY_0(mp2_pic0_priority_19) \
     ((mp2_pic0_priority_19 & MP2_PIC0_PRIORITY_19_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_19_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_19_GET_INTR_PRIORITY_1(mp2_pic0_priority_19) \
     ((mp2_pic0_priority_19 & MP2_PIC0_PRIORITY_19_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_19_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_19_GET_INTR_PRIORITY_2(mp2_pic0_priority_19) \
     ((mp2_pic0_priority_19 & MP2_PIC0_PRIORITY_19_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_19_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_19_GET_INTR_PRIORITY_3(mp2_pic0_priority_19) \
     ((mp2_pic0_priority_19 & MP2_PIC0_PRIORITY_19_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_19_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_19_SET_INTR_PRIORITY_0(mp2_pic0_priority_19_reg, intr_priority_0) \
     mp2_pic0_priority_19_reg = (mp2_pic0_priority_19_reg & ~MP2_PIC0_PRIORITY_19_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_19_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_19_SET_INTR_PRIORITY_1(mp2_pic0_priority_19_reg, intr_priority_1) \
     mp2_pic0_priority_19_reg = (mp2_pic0_priority_19_reg & ~MP2_PIC0_PRIORITY_19_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_19_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_19_SET_INTR_PRIORITY_2(mp2_pic0_priority_19_reg, intr_priority_2) \
     mp2_pic0_priority_19_reg = (mp2_pic0_priority_19_reg & ~MP2_PIC0_PRIORITY_19_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_19_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_19_SET_INTR_PRIORITY_3(mp2_pic0_priority_19_reg, intr_priority_3) \
     mp2_pic0_priority_19_reg = (mp2_pic0_priority_19_reg & ~MP2_PIC0_PRIORITY_19_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_19_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_19_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_19_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_19_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_19_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_19_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_19_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_19_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_19_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_19_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_19_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_19_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_19_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_19_t f;
} mp2_pic0_priority_19_u;


/*
 * MP2_PIC0_PRIORITY_20 struct
 */

#define MP2_PIC0_PRIORITY_20_REG_SIZE  32
#define MP2_PIC0_PRIORITY_20_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_20_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_20_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_20_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_20_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_20_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_20_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_20_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_20_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_20_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_20_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_20_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_20_MASK \
     (MP2_PIC0_PRIORITY_20_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_20_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_20_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_20_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_20_DEFAULT   0x53525150

#define MP2_PIC0_PRIORITY_20_GET_INTR_PRIORITY_0(mp2_pic0_priority_20) \
     ((mp2_pic0_priority_20 & MP2_PIC0_PRIORITY_20_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_20_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_20_GET_INTR_PRIORITY_1(mp2_pic0_priority_20) \
     ((mp2_pic0_priority_20 & MP2_PIC0_PRIORITY_20_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_20_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_20_GET_INTR_PRIORITY_2(mp2_pic0_priority_20) \
     ((mp2_pic0_priority_20 & MP2_PIC0_PRIORITY_20_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_20_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_20_GET_INTR_PRIORITY_3(mp2_pic0_priority_20) \
     ((mp2_pic0_priority_20 & MP2_PIC0_PRIORITY_20_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_20_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_20_SET_INTR_PRIORITY_0(mp2_pic0_priority_20_reg, intr_priority_0) \
     mp2_pic0_priority_20_reg = (mp2_pic0_priority_20_reg & ~MP2_PIC0_PRIORITY_20_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_20_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_20_SET_INTR_PRIORITY_1(mp2_pic0_priority_20_reg, intr_priority_1) \
     mp2_pic0_priority_20_reg = (mp2_pic0_priority_20_reg & ~MP2_PIC0_PRIORITY_20_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_20_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_20_SET_INTR_PRIORITY_2(mp2_pic0_priority_20_reg, intr_priority_2) \
     mp2_pic0_priority_20_reg = (mp2_pic0_priority_20_reg & ~MP2_PIC0_PRIORITY_20_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_20_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_20_SET_INTR_PRIORITY_3(mp2_pic0_priority_20_reg, intr_priority_3) \
     mp2_pic0_priority_20_reg = (mp2_pic0_priority_20_reg & ~MP2_PIC0_PRIORITY_20_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_20_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_20_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_20_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_20_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_20_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_20_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_20_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_20_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_20_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_20_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_20_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_20_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_20_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_20_t f;
} mp2_pic0_priority_20_u;


/*
 * MP2_PIC0_PRIORITY_21 struct
 */

#define MP2_PIC0_PRIORITY_21_REG_SIZE  32
#define MP2_PIC0_PRIORITY_21_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_21_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_21_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_21_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_21_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_21_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_21_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_21_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_21_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_21_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_21_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_21_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_21_MASK \
     (MP2_PIC0_PRIORITY_21_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_21_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_21_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_21_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_21_DEFAULT   0x57565554

#define MP2_PIC0_PRIORITY_21_GET_INTR_PRIORITY_0(mp2_pic0_priority_21) \
     ((mp2_pic0_priority_21 & MP2_PIC0_PRIORITY_21_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_21_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_21_GET_INTR_PRIORITY_1(mp2_pic0_priority_21) \
     ((mp2_pic0_priority_21 & MP2_PIC0_PRIORITY_21_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_21_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_21_GET_INTR_PRIORITY_2(mp2_pic0_priority_21) \
     ((mp2_pic0_priority_21 & MP2_PIC0_PRIORITY_21_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_21_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_21_GET_INTR_PRIORITY_3(mp2_pic0_priority_21) \
     ((mp2_pic0_priority_21 & MP2_PIC0_PRIORITY_21_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_21_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_21_SET_INTR_PRIORITY_0(mp2_pic0_priority_21_reg, intr_priority_0) \
     mp2_pic0_priority_21_reg = (mp2_pic0_priority_21_reg & ~MP2_PIC0_PRIORITY_21_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_21_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_21_SET_INTR_PRIORITY_1(mp2_pic0_priority_21_reg, intr_priority_1) \
     mp2_pic0_priority_21_reg = (mp2_pic0_priority_21_reg & ~MP2_PIC0_PRIORITY_21_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_21_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_21_SET_INTR_PRIORITY_2(mp2_pic0_priority_21_reg, intr_priority_2) \
     mp2_pic0_priority_21_reg = (mp2_pic0_priority_21_reg & ~MP2_PIC0_PRIORITY_21_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_21_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_21_SET_INTR_PRIORITY_3(mp2_pic0_priority_21_reg, intr_priority_3) \
     mp2_pic0_priority_21_reg = (mp2_pic0_priority_21_reg & ~MP2_PIC0_PRIORITY_21_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_21_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_21_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_21_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_21_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_21_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_21_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_21_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_21_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_21_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_21_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_21_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_21_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_21_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_21_t f;
} mp2_pic0_priority_21_u;


/*
 * MP2_PIC0_PRIORITY_22 struct
 */

#define MP2_PIC0_PRIORITY_22_REG_SIZE  32
#define MP2_PIC0_PRIORITY_22_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_22_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_22_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_22_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_22_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_22_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_22_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_22_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_22_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_22_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_22_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_22_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_22_MASK \
     (MP2_PIC0_PRIORITY_22_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_22_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_22_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_22_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_22_DEFAULT   0x5b5a5958

#define MP2_PIC0_PRIORITY_22_GET_INTR_PRIORITY_0(mp2_pic0_priority_22) \
     ((mp2_pic0_priority_22 & MP2_PIC0_PRIORITY_22_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_22_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_22_GET_INTR_PRIORITY_1(mp2_pic0_priority_22) \
     ((mp2_pic0_priority_22 & MP2_PIC0_PRIORITY_22_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_22_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_22_GET_INTR_PRIORITY_2(mp2_pic0_priority_22) \
     ((mp2_pic0_priority_22 & MP2_PIC0_PRIORITY_22_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_22_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_22_GET_INTR_PRIORITY_3(mp2_pic0_priority_22) \
     ((mp2_pic0_priority_22 & MP2_PIC0_PRIORITY_22_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_22_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_22_SET_INTR_PRIORITY_0(mp2_pic0_priority_22_reg, intr_priority_0) \
     mp2_pic0_priority_22_reg = (mp2_pic0_priority_22_reg & ~MP2_PIC0_PRIORITY_22_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_22_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_22_SET_INTR_PRIORITY_1(mp2_pic0_priority_22_reg, intr_priority_1) \
     mp2_pic0_priority_22_reg = (mp2_pic0_priority_22_reg & ~MP2_PIC0_PRIORITY_22_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_22_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_22_SET_INTR_PRIORITY_2(mp2_pic0_priority_22_reg, intr_priority_2) \
     mp2_pic0_priority_22_reg = (mp2_pic0_priority_22_reg & ~MP2_PIC0_PRIORITY_22_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_22_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_22_SET_INTR_PRIORITY_3(mp2_pic0_priority_22_reg, intr_priority_3) \
     mp2_pic0_priority_22_reg = (mp2_pic0_priority_22_reg & ~MP2_PIC0_PRIORITY_22_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_22_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_22_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_22_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_22_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_22_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_22_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_22_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_22_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_22_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_22_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_22_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_22_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_22_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_22_t f;
} mp2_pic0_priority_22_u;


/*
 * MP2_PIC0_PRIORITY_23 struct
 */

#define MP2_PIC0_PRIORITY_23_REG_SIZE  32
#define MP2_PIC0_PRIORITY_23_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_23_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_23_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_23_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_23_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_23_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_23_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_23_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_23_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_23_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_23_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_23_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_23_MASK \
     (MP2_PIC0_PRIORITY_23_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_23_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_23_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_23_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_23_DEFAULT   0x5f5e5d5c

#define MP2_PIC0_PRIORITY_23_GET_INTR_PRIORITY_0(mp2_pic0_priority_23) \
     ((mp2_pic0_priority_23 & MP2_PIC0_PRIORITY_23_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_23_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_23_GET_INTR_PRIORITY_1(mp2_pic0_priority_23) \
     ((mp2_pic0_priority_23 & MP2_PIC0_PRIORITY_23_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_23_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_23_GET_INTR_PRIORITY_2(mp2_pic0_priority_23) \
     ((mp2_pic0_priority_23 & MP2_PIC0_PRIORITY_23_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_23_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_23_GET_INTR_PRIORITY_3(mp2_pic0_priority_23) \
     ((mp2_pic0_priority_23 & MP2_PIC0_PRIORITY_23_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_23_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_23_SET_INTR_PRIORITY_0(mp2_pic0_priority_23_reg, intr_priority_0) \
     mp2_pic0_priority_23_reg = (mp2_pic0_priority_23_reg & ~MP2_PIC0_PRIORITY_23_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_23_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_23_SET_INTR_PRIORITY_1(mp2_pic0_priority_23_reg, intr_priority_1) \
     mp2_pic0_priority_23_reg = (mp2_pic0_priority_23_reg & ~MP2_PIC0_PRIORITY_23_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_23_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_23_SET_INTR_PRIORITY_2(mp2_pic0_priority_23_reg, intr_priority_2) \
     mp2_pic0_priority_23_reg = (mp2_pic0_priority_23_reg & ~MP2_PIC0_PRIORITY_23_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_23_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_23_SET_INTR_PRIORITY_3(mp2_pic0_priority_23_reg, intr_priority_3) \
     mp2_pic0_priority_23_reg = (mp2_pic0_priority_23_reg & ~MP2_PIC0_PRIORITY_23_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_23_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_23_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_23_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_23_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_23_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_23_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_23_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_23_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_23_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_23_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_23_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_23_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_23_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_23_t f;
} mp2_pic0_priority_23_u;


/*
 * MP2_PIC0_PRIORITY_24 struct
 */

#define MP2_PIC0_PRIORITY_24_REG_SIZE  32
#define MP2_PIC0_PRIORITY_24_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_24_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_24_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_24_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_24_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_24_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_24_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_24_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_24_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_24_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_24_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_24_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_24_MASK \
     (MP2_PIC0_PRIORITY_24_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_24_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_24_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_24_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_24_DEFAULT   0x63626160

#define MP2_PIC0_PRIORITY_24_GET_INTR_PRIORITY_0(mp2_pic0_priority_24) \
     ((mp2_pic0_priority_24 & MP2_PIC0_PRIORITY_24_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_24_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_24_GET_INTR_PRIORITY_1(mp2_pic0_priority_24) \
     ((mp2_pic0_priority_24 & MP2_PIC0_PRIORITY_24_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_24_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_24_GET_INTR_PRIORITY_2(mp2_pic0_priority_24) \
     ((mp2_pic0_priority_24 & MP2_PIC0_PRIORITY_24_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_24_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_24_GET_INTR_PRIORITY_3(mp2_pic0_priority_24) \
     ((mp2_pic0_priority_24 & MP2_PIC0_PRIORITY_24_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_24_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_24_SET_INTR_PRIORITY_0(mp2_pic0_priority_24_reg, intr_priority_0) \
     mp2_pic0_priority_24_reg = (mp2_pic0_priority_24_reg & ~MP2_PIC0_PRIORITY_24_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_24_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_24_SET_INTR_PRIORITY_1(mp2_pic0_priority_24_reg, intr_priority_1) \
     mp2_pic0_priority_24_reg = (mp2_pic0_priority_24_reg & ~MP2_PIC0_PRIORITY_24_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_24_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_24_SET_INTR_PRIORITY_2(mp2_pic0_priority_24_reg, intr_priority_2) \
     mp2_pic0_priority_24_reg = (mp2_pic0_priority_24_reg & ~MP2_PIC0_PRIORITY_24_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_24_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_24_SET_INTR_PRIORITY_3(mp2_pic0_priority_24_reg, intr_priority_3) \
     mp2_pic0_priority_24_reg = (mp2_pic0_priority_24_reg & ~MP2_PIC0_PRIORITY_24_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_24_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_24_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_24_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_24_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_24_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_24_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_24_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_24_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_24_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_24_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_24_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_24_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_24_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_24_t f;
} mp2_pic0_priority_24_u;


/*
 * MP2_PIC0_PRIORITY_25 struct
 */

#define MP2_PIC0_PRIORITY_25_REG_SIZE  32
#define MP2_PIC0_PRIORITY_25_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_25_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_25_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_25_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_25_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_25_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_25_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_25_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_25_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_25_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_25_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_25_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_25_MASK \
     (MP2_PIC0_PRIORITY_25_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_25_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_25_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_25_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_25_DEFAULT   0x67666564

#define MP2_PIC0_PRIORITY_25_GET_INTR_PRIORITY_0(mp2_pic0_priority_25) \
     ((mp2_pic0_priority_25 & MP2_PIC0_PRIORITY_25_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_25_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_25_GET_INTR_PRIORITY_1(mp2_pic0_priority_25) \
     ((mp2_pic0_priority_25 & MP2_PIC0_PRIORITY_25_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_25_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_25_GET_INTR_PRIORITY_2(mp2_pic0_priority_25) \
     ((mp2_pic0_priority_25 & MP2_PIC0_PRIORITY_25_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_25_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_25_GET_INTR_PRIORITY_3(mp2_pic0_priority_25) \
     ((mp2_pic0_priority_25 & MP2_PIC0_PRIORITY_25_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_25_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_25_SET_INTR_PRIORITY_0(mp2_pic0_priority_25_reg, intr_priority_0) \
     mp2_pic0_priority_25_reg = (mp2_pic0_priority_25_reg & ~MP2_PIC0_PRIORITY_25_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_25_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_25_SET_INTR_PRIORITY_1(mp2_pic0_priority_25_reg, intr_priority_1) \
     mp2_pic0_priority_25_reg = (mp2_pic0_priority_25_reg & ~MP2_PIC0_PRIORITY_25_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_25_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_25_SET_INTR_PRIORITY_2(mp2_pic0_priority_25_reg, intr_priority_2) \
     mp2_pic0_priority_25_reg = (mp2_pic0_priority_25_reg & ~MP2_PIC0_PRIORITY_25_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_25_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_25_SET_INTR_PRIORITY_3(mp2_pic0_priority_25_reg, intr_priority_3) \
     mp2_pic0_priority_25_reg = (mp2_pic0_priority_25_reg & ~MP2_PIC0_PRIORITY_25_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_25_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_25_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_25_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_25_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_25_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_25_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_25_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_25_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_25_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_25_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_25_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_25_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_25_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_25_t f;
} mp2_pic0_priority_25_u;


/*
 * MP2_PIC0_PRIORITY_26 struct
 */

#define MP2_PIC0_PRIORITY_26_REG_SIZE  32
#define MP2_PIC0_PRIORITY_26_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_26_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_26_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_26_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_26_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_26_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_26_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_26_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_26_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_26_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_26_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_26_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_26_MASK \
     (MP2_PIC0_PRIORITY_26_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_26_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_26_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_26_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_26_DEFAULT   0x6b6a6968

#define MP2_PIC0_PRIORITY_26_GET_INTR_PRIORITY_0(mp2_pic0_priority_26) \
     ((mp2_pic0_priority_26 & MP2_PIC0_PRIORITY_26_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_26_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_26_GET_INTR_PRIORITY_1(mp2_pic0_priority_26) \
     ((mp2_pic0_priority_26 & MP2_PIC0_PRIORITY_26_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_26_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_26_GET_INTR_PRIORITY_2(mp2_pic0_priority_26) \
     ((mp2_pic0_priority_26 & MP2_PIC0_PRIORITY_26_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_26_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_26_GET_INTR_PRIORITY_3(mp2_pic0_priority_26) \
     ((mp2_pic0_priority_26 & MP2_PIC0_PRIORITY_26_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_26_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_26_SET_INTR_PRIORITY_0(mp2_pic0_priority_26_reg, intr_priority_0) \
     mp2_pic0_priority_26_reg = (mp2_pic0_priority_26_reg & ~MP2_PIC0_PRIORITY_26_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_26_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_26_SET_INTR_PRIORITY_1(mp2_pic0_priority_26_reg, intr_priority_1) \
     mp2_pic0_priority_26_reg = (mp2_pic0_priority_26_reg & ~MP2_PIC0_PRIORITY_26_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_26_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_26_SET_INTR_PRIORITY_2(mp2_pic0_priority_26_reg, intr_priority_2) \
     mp2_pic0_priority_26_reg = (mp2_pic0_priority_26_reg & ~MP2_PIC0_PRIORITY_26_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_26_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_26_SET_INTR_PRIORITY_3(mp2_pic0_priority_26_reg, intr_priority_3) \
     mp2_pic0_priority_26_reg = (mp2_pic0_priority_26_reg & ~MP2_PIC0_PRIORITY_26_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_26_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_26_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_26_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_26_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_26_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_26_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_26_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_26_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_26_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_26_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_26_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_26_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_26_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_26_t f;
} mp2_pic0_priority_26_u;


/*
 * MP2_PIC0_PRIORITY_27 struct
 */

#define MP2_PIC0_PRIORITY_27_REG_SIZE  32
#define MP2_PIC0_PRIORITY_27_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_27_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_27_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_27_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_27_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_27_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_27_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_27_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_27_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_27_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_27_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_27_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_27_MASK \
     (MP2_PIC0_PRIORITY_27_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_27_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_27_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_27_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_27_DEFAULT   0x6f6e6d6c

#define MP2_PIC0_PRIORITY_27_GET_INTR_PRIORITY_0(mp2_pic0_priority_27) \
     ((mp2_pic0_priority_27 & MP2_PIC0_PRIORITY_27_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_27_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_27_GET_INTR_PRIORITY_1(mp2_pic0_priority_27) \
     ((mp2_pic0_priority_27 & MP2_PIC0_PRIORITY_27_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_27_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_27_GET_INTR_PRIORITY_2(mp2_pic0_priority_27) \
     ((mp2_pic0_priority_27 & MP2_PIC0_PRIORITY_27_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_27_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_27_GET_INTR_PRIORITY_3(mp2_pic0_priority_27) \
     ((mp2_pic0_priority_27 & MP2_PIC0_PRIORITY_27_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_27_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_27_SET_INTR_PRIORITY_0(mp2_pic0_priority_27_reg, intr_priority_0) \
     mp2_pic0_priority_27_reg = (mp2_pic0_priority_27_reg & ~MP2_PIC0_PRIORITY_27_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_27_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_27_SET_INTR_PRIORITY_1(mp2_pic0_priority_27_reg, intr_priority_1) \
     mp2_pic0_priority_27_reg = (mp2_pic0_priority_27_reg & ~MP2_PIC0_PRIORITY_27_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_27_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_27_SET_INTR_PRIORITY_2(mp2_pic0_priority_27_reg, intr_priority_2) \
     mp2_pic0_priority_27_reg = (mp2_pic0_priority_27_reg & ~MP2_PIC0_PRIORITY_27_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_27_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_27_SET_INTR_PRIORITY_3(mp2_pic0_priority_27_reg, intr_priority_3) \
     mp2_pic0_priority_27_reg = (mp2_pic0_priority_27_reg & ~MP2_PIC0_PRIORITY_27_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_27_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_27_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_27_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_27_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_27_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_27_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_27_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_27_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_27_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_27_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_27_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_27_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_27_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_27_t f;
} mp2_pic0_priority_27_u;


/*
 * MP2_PIC0_PRIORITY_28 struct
 */

#define MP2_PIC0_PRIORITY_28_REG_SIZE  32
#define MP2_PIC0_PRIORITY_28_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_28_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_28_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_28_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_28_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_28_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_28_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_28_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_28_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_28_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_28_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_28_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_28_MASK \
     (MP2_PIC0_PRIORITY_28_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_28_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_28_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_28_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_28_DEFAULT   0x73727170

#define MP2_PIC0_PRIORITY_28_GET_INTR_PRIORITY_0(mp2_pic0_priority_28) \
     ((mp2_pic0_priority_28 & MP2_PIC0_PRIORITY_28_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_28_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_28_GET_INTR_PRIORITY_1(mp2_pic0_priority_28) \
     ((mp2_pic0_priority_28 & MP2_PIC0_PRIORITY_28_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_28_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_28_GET_INTR_PRIORITY_2(mp2_pic0_priority_28) \
     ((mp2_pic0_priority_28 & MP2_PIC0_PRIORITY_28_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_28_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_28_GET_INTR_PRIORITY_3(mp2_pic0_priority_28) \
     ((mp2_pic0_priority_28 & MP2_PIC0_PRIORITY_28_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_28_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_28_SET_INTR_PRIORITY_0(mp2_pic0_priority_28_reg, intr_priority_0) \
     mp2_pic0_priority_28_reg = (mp2_pic0_priority_28_reg & ~MP2_PIC0_PRIORITY_28_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_28_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_28_SET_INTR_PRIORITY_1(mp2_pic0_priority_28_reg, intr_priority_1) \
     mp2_pic0_priority_28_reg = (mp2_pic0_priority_28_reg & ~MP2_PIC0_PRIORITY_28_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_28_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_28_SET_INTR_PRIORITY_2(mp2_pic0_priority_28_reg, intr_priority_2) \
     mp2_pic0_priority_28_reg = (mp2_pic0_priority_28_reg & ~MP2_PIC0_PRIORITY_28_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_28_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_28_SET_INTR_PRIORITY_3(mp2_pic0_priority_28_reg, intr_priority_3) \
     mp2_pic0_priority_28_reg = (mp2_pic0_priority_28_reg & ~MP2_PIC0_PRIORITY_28_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_28_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_28_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_28_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_28_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_28_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_28_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_28_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_28_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_28_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_28_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_28_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_28_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_28_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_28_t f;
} mp2_pic0_priority_28_u;


/*
 * MP2_PIC0_PRIORITY_29 struct
 */

#define MP2_PIC0_PRIORITY_29_REG_SIZE  32
#define MP2_PIC0_PRIORITY_29_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_29_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_29_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_29_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_29_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_29_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_29_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_29_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_29_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_29_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_29_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_29_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_29_MASK \
     (MP2_PIC0_PRIORITY_29_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_29_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_29_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_29_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_29_DEFAULT   0x77767574

#define MP2_PIC0_PRIORITY_29_GET_INTR_PRIORITY_0(mp2_pic0_priority_29) \
     ((mp2_pic0_priority_29 & MP2_PIC0_PRIORITY_29_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_29_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_29_GET_INTR_PRIORITY_1(mp2_pic0_priority_29) \
     ((mp2_pic0_priority_29 & MP2_PIC0_PRIORITY_29_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_29_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_29_GET_INTR_PRIORITY_2(mp2_pic0_priority_29) \
     ((mp2_pic0_priority_29 & MP2_PIC0_PRIORITY_29_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_29_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_29_GET_INTR_PRIORITY_3(mp2_pic0_priority_29) \
     ((mp2_pic0_priority_29 & MP2_PIC0_PRIORITY_29_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_29_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_29_SET_INTR_PRIORITY_0(mp2_pic0_priority_29_reg, intr_priority_0) \
     mp2_pic0_priority_29_reg = (mp2_pic0_priority_29_reg & ~MP2_PIC0_PRIORITY_29_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_29_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_29_SET_INTR_PRIORITY_1(mp2_pic0_priority_29_reg, intr_priority_1) \
     mp2_pic0_priority_29_reg = (mp2_pic0_priority_29_reg & ~MP2_PIC0_PRIORITY_29_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_29_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_29_SET_INTR_PRIORITY_2(mp2_pic0_priority_29_reg, intr_priority_2) \
     mp2_pic0_priority_29_reg = (mp2_pic0_priority_29_reg & ~MP2_PIC0_PRIORITY_29_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_29_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_29_SET_INTR_PRIORITY_3(mp2_pic0_priority_29_reg, intr_priority_3) \
     mp2_pic0_priority_29_reg = (mp2_pic0_priority_29_reg & ~MP2_PIC0_PRIORITY_29_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_29_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_29_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_29_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_29_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_29_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_29_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_29_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_29_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_29_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_29_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_29_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_29_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_29_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_29_t f;
} mp2_pic0_priority_29_u;


/*
 * MP2_PIC0_PRIORITY_30 struct
 */

#define MP2_PIC0_PRIORITY_30_REG_SIZE  32
#define MP2_PIC0_PRIORITY_30_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_30_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_30_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_30_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_30_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_30_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_30_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_30_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_30_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_30_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_30_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_30_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_30_MASK \
     (MP2_PIC0_PRIORITY_30_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_30_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_30_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_30_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_30_DEFAULT   0x7b7a7978

#define MP2_PIC0_PRIORITY_30_GET_INTR_PRIORITY_0(mp2_pic0_priority_30) \
     ((mp2_pic0_priority_30 & MP2_PIC0_PRIORITY_30_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_30_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_30_GET_INTR_PRIORITY_1(mp2_pic0_priority_30) \
     ((mp2_pic0_priority_30 & MP2_PIC0_PRIORITY_30_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_30_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_30_GET_INTR_PRIORITY_2(mp2_pic0_priority_30) \
     ((mp2_pic0_priority_30 & MP2_PIC0_PRIORITY_30_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_30_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_30_GET_INTR_PRIORITY_3(mp2_pic0_priority_30) \
     ((mp2_pic0_priority_30 & MP2_PIC0_PRIORITY_30_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_30_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_30_SET_INTR_PRIORITY_0(mp2_pic0_priority_30_reg, intr_priority_0) \
     mp2_pic0_priority_30_reg = (mp2_pic0_priority_30_reg & ~MP2_PIC0_PRIORITY_30_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_30_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_30_SET_INTR_PRIORITY_1(mp2_pic0_priority_30_reg, intr_priority_1) \
     mp2_pic0_priority_30_reg = (mp2_pic0_priority_30_reg & ~MP2_PIC0_PRIORITY_30_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_30_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_30_SET_INTR_PRIORITY_2(mp2_pic0_priority_30_reg, intr_priority_2) \
     mp2_pic0_priority_30_reg = (mp2_pic0_priority_30_reg & ~MP2_PIC0_PRIORITY_30_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_30_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_30_SET_INTR_PRIORITY_3(mp2_pic0_priority_30_reg, intr_priority_3) \
     mp2_pic0_priority_30_reg = (mp2_pic0_priority_30_reg & ~MP2_PIC0_PRIORITY_30_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_30_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_30_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_30_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_30_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_30_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_30_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_30_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_30_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_30_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_30_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_30_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_30_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_30_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_30_t f;
} mp2_pic0_priority_30_u;


/*
 * MP2_PIC0_PRIORITY_31 struct
 */

#define MP2_PIC0_PRIORITY_31_REG_SIZE  32
#define MP2_PIC0_PRIORITY_31_INTR_PRIORITY_0_SIZE 8
#define MP2_PIC0_PRIORITY_31_INTR_PRIORITY_1_SIZE 8
#define MP2_PIC0_PRIORITY_31_INTR_PRIORITY_2_SIZE 8
#define MP2_PIC0_PRIORITY_31_INTR_PRIORITY_3_SIZE 8

#define MP2_PIC0_PRIORITY_31_INTR_PRIORITY_0_SHIFT 0
#define MP2_PIC0_PRIORITY_31_INTR_PRIORITY_1_SHIFT 8
#define MP2_PIC0_PRIORITY_31_INTR_PRIORITY_2_SHIFT 16
#define MP2_PIC0_PRIORITY_31_INTR_PRIORITY_3_SHIFT 24

#define MP2_PIC0_PRIORITY_31_INTR_PRIORITY_0_MASK 0xff
#define MP2_PIC0_PRIORITY_31_INTR_PRIORITY_1_MASK 0xff00
#define MP2_PIC0_PRIORITY_31_INTR_PRIORITY_2_MASK 0xff0000
#define MP2_PIC0_PRIORITY_31_INTR_PRIORITY_3_MASK 0xff000000

#define MP2_PIC0_PRIORITY_31_MASK \
     (MP2_PIC0_PRIORITY_31_INTR_PRIORITY_0_MASK | \
      MP2_PIC0_PRIORITY_31_INTR_PRIORITY_1_MASK | \
      MP2_PIC0_PRIORITY_31_INTR_PRIORITY_2_MASK | \
      MP2_PIC0_PRIORITY_31_INTR_PRIORITY_3_MASK)

#define MP2_PIC0_PRIORITY_31_DEFAULT   0x7f7e7d7c

#define MP2_PIC0_PRIORITY_31_GET_INTR_PRIORITY_0(mp2_pic0_priority_31) \
     ((mp2_pic0_priority_31 & MP2_PIC0_PRIORITY_31_INTR_PRIORITY_0_MASK) >> MP2_PIC0_PRIORITY_31_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_31_GET_INTR_PRIORITY_1(mp2_pic0_priority_31) \
     ((mp2_pic0_priority_31 & MP2_PIC0_PRIORITY_31_INTR_PRIORITY_1_MASK) >> MP2_PIC0_PRIORITY_31_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_31_GET_INTR_PRIORITY_2(mp2_pic0_priority_31) \
     ((mp2_pic0_priority_31 & MP2_PIC0_PRIORITY_31_INTR_PRIORITY_2_MASK) >> MP2_PIC0_PRIORITY_31_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_31_GET_INTR_PRIORITY_3(mp2_pic0_priority_31) \
     ((mp2_pic0_priority_31 & MP2_PIC0_PRIORITY_31_INTR_PRIORITY_3_MASK) >> MP2_PIC0_PRIORITY_31_INTR_PRIORITY_3_SHIFT)

#define MP2_PIC0_PRIORITY_31_SET_INTR_PRIORITY_0(mp2_pic0_priority_31_reg, intr_priority_0) \
     mp2_pic0_priority_31_reg = (mp2_pic0_priority_31_reg & ~MP2_PIC0_PRIORITY_31_INTR_PRIORITY_0_MASK) | (intr_priority_0 << MP2_PIC0_PRIORITY_31_INTR_PRIORITY_0_SHIFT)
#define MP2_PIC0_PRIORITY_31_SET_INTR_PRIORITY_1(mp2_pic0_priority_31_reg, intr_priority_1) \
     mp2_pic0_priority_31_reg = (mp2_pic0_priority_31_reg & ~MP2_PIC0_PRIORITY_31_INTR_PRIORITY_1_MASK) | (intr_priority_1 << MP2_PIC0_PRIORITY_31_INTR_PRIORITY_1_SHIFT)
#define MP2_PIC0_PRIORITY_31_SET_INTR_PRIORITY_2(mp2_pic0_priority_31_reg, intr_priority_2) \
     mp2_pic0_priority_31_reg = (mp2_pic0_priority_31_reg & ~MP2_PIC0_PRIORITY_31_INTR_PRIORITY_2_MASK) | (intr_priority_2 << MP2_PIC0_PRIORITY_31_INTR_PRIORITY_2_SHIFT)
#define MP2_PIC0_PRIORITY_31_SET_INTR_PRIORITY_3(mp2_pic0_priority_31_reg, intr_priority_3) \
     mp2_pic0_priority_31_reg = (mp2_pic0_priority_31_reg & ~MP2_PIC0_PRIORITY_31_INTR_PRIORITY_3_MASK) | (intr_priority_3 << MP2_PIC0_PRIORITY_31_INTR_PRIORITY_3_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_priority_31_t {
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_31_INTR_PRIORITY_0_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_31_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_31_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_31_INTR_PRIORITY_3_SIZE;
     } mp2_pic0_priority_31_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_priority_31_t {
          unsigned int intr_priority_3                : MP2_PIC0_PRIORITY_31_INTR_PRIORITY_3_SIZE;
          unsigned int intr_priority_2                : MP2_PIC0_PRIORITY_31_INTR_PRIORITY_2_SIZE;
          unsigned int intr_priority_1                : MP2_PIC0_PRIORITY_31_INTR_PRIORITY_1_SIZE;
          unsigned int intr_priority_0                : MP2_PIC0_PRIORITY_31_INTR_PRIORITY_0_SIZE;
     } mp2_pic0_priority_31_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_priority_31_t f;
} mp2_pic0_priority_31_u;


/*
 * MP2_PIC0_STATUS_0 struct
 */

#define MP2_PIC0_STATUS_0_REG_SIZE     32
#define MP2_PIC0_STATUS_0_INTR_FLAG_0_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_1_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_2_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_3_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_4_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_5_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_6_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_7_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_8_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_9_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_10_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_11_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_12_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_13_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_14_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_15_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_16_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_17_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_18_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_19_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_20_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_21_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_22_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_23_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_24_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_25_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_26_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_27_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_28_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_29_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_30_SIZE 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_31_SIZE 1

#define MP2_PIC0_STATUS_0_INTR_FLAG_0_SHIFT 0
#define MP2_PIC0_STATUS_0_INTR_FLAG_1_SHIFT 1
#define MP2_PIC0_STATUS_0_INTR_FLAG_2_SHIFT 2
#define MP2_PIC0_STATUS_0_INTR_FLAG_3_SHIFT 3
#define MP2_PIC0_STATUS_0_INTR_FLAG_4_SHIFT 4
#define MP2_PIC0_STATUS_0_INTR_FLAG_5_SHIFT 5
#define MP2_PIC0_STATUS_0_INTR_FLAG_6_SHIFT 6
#define MP2_PIC0_STATUS_0_INTR_FLAG_7_SHIFT 7
#define MP2_PIC0_STATUS_0_INTR_FLAG_8_SHIFT 8
#define MP2_PIC0_STATUS_0_INTR_FLAG_9_SHIFT 9
#define MP2_PIC0_STATUS_0_INTR_FLAG_10_SHIFT 10
#define MP2_PIC0_STATUS_0_INTR_FLAG_11_SHIFT 11
#define MP2_PIC0_STATUS_0_INTR_FLAG_12_SHIFT 12
#define MP2_PIC0_STATUS_0_INTR_FLAG_13_SHIFT 13
#define MP2_PIC0_STATUS_0_INTR_FLAG_14_SHIFT 14
#define MP2_PIC0_STATUS_0_INTR_FLAG_15_SHIFT 15
#define MP2_PIC0_STATUS_0_INTR_FLAG_16_SHIFT 16
#define MP2_PIC0_STATUS_0_INTR_FLAG_17_SHIFT 17
#define MP2_PIC0_STATUS_0_INTR_FLAG_18_SHIFT 18
#define MP2_PIC0_STATUS_0_INTR_FLAG_19_SHIFT 19
#define MP2_PIC0_STATUS_0_INTR_FLAG_20_SHIFT 20
#define MP2_PIC0_STATUS_0_INTR_FLAG_21_SHIFT 21
#define MP2_PIC0_STATUS_0_INTR_FLAG_22_SHIFT 22
#define MP2_PIC0_STATUS_0_INTR_FLAG_23_SHIFT 23
#define MP2_PIC0_STATUS_0_INTR_FLAG_24_SHIFT 24
#define MP2_PIC0_STATUS_0_INTR_FLAG_25_SHIFT 25
#define MP2_PIC0_STATUS_0_INTR_FLAG_26_SHIFT 26
#define MP2_PIC0_STATUS_0_INTR_FLAG_27_SHIFT 27
#define MP2_PIC0_STATUS_0_INTR_FLAG_28_SHIFT 28
#define MP2_PIC0_STATUS_0_INTR_FLAG_29_SHIFT 29
#define MP2_PIC0_STATUS_0_INTR_FLAG_30_SHIFT 30
#define MP2_PIC0_STATUS_0_INTR_FLAG_31_SHIFT 31

#define MP2_PIC0_STATUS_0_INTR_FLAG_0_MASK 0x1
#define MP2_PIC0_STATUS_0_INTR_FLAG_1_MASK 0x2
#define MP2_PIC0_STATUS_0_INTR_FLAG_2_MASK 0x4
#define MP2_PIC0_STATUS_0_INTR_FLAG_3_MASK 0x8
#define MP2_PIC0_STATUS_0_INTR_FLAG_4_MASK 0x10
#define MP2_PIC0_STATUS_0_INTR_FLAG_5_MASK 0x20
#define MP2_PIC0_STATUS_0_INTR_FLAG_6_MASK 0x40
#define MP2_PIC0_STATUS_0_INTR_FLAG_7_MASK 0x80
#define MP2_PIC0_STATUS_0_INTR_FLAG_8_MASK 0x100
#define MP2_PIC0_STATUS_0_INTR_FLAG_9_MASK 0x200
#define MP2_PIC0_STATUS_0_INTR_FLAG_10_MASK 0x400
#define MP2_PIC0_STATUS_0_INTR_FLAG_11_MASK 0x800
#define MP2_PIC0_STATUS_0_INTR_FLAG_12_MASK 0x1000
#define MP2_PIC0_STATUS_0_INTR_FLAG_13_MASK 0x2000
#define MP2_PIC0_STATUS_0_INTR_FLAG_14_MASK 0x4000
#define MP2_PIC0_STATUS_0_INTR_FLAG_15_MASK 0x8000
#define MP2_PIC0_STATUS_0_INTR_FLAG_16_MASK 0x10000
#define MP2_PIC0_STATUS_0_INTR_FLAG_17_MASK 0x20000
#define MP2_PIC0_STATUS_0_INTR_FLAG_18_MASK 0x40000
#define MP2_PIC0_STATUS_0_INTR_FLAG_19_MASK 0x80000
#define MP2_PIC0_STATUS_0_INTR_FLAG_20_MASK 0x100000
#define MP2_PIC0_STATUS_0_INTR_FLAG_21_MASK 0x200000
#define MP2_PIC0_STATUS_0_INTR_FLAG_22_MASK 0x400000
#define MP2_PIC0_STATUS_0_INTR_FLAG_23_MASK 0x800000
#define MP2_PIC0_STATUS_0_INTR_FLAG_24_MASK 0x1000000
#define MP2_PIC0_STATUS_0_INTR_FLAG_25_MASK 0x2000000
#define MP2_PIC0_STATUS_0_INTR_FLAG_26_MASK 0x4000000
#define MP2_PIC0_STATUS_0_INTR_FLAG_27_MASK 0x8000000
#define MP2_PIC0_STATUS_0_INTR_FLAG_28_MASK 0x10000000
#define MP2_PIC0_STATUS_0_INTR_FLAG_29_MASK 0x20000000
#define MP2_PIC0_STATUS_0_INTR_FLAG_30_MASK 0x40000000
#define MP2_PIC0_STATUS_0_INTR_FLAG_31_MASK 0x80000000

#define MP2_PIC0_STATUS_0_MASK \
     (MP2_PIC0_STATUS_0_INTR_FLAG_0_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_1_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_2_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_3_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_4_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_5_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_6_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_7_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_8_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_9_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_10_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_11_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_12_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_13_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_14_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_15_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_16_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_17_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_18_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_19_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_20_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_21_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_22_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_23_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_24_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_25_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_26_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_27_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_28_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_29_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_30_MASK | \
      MP2_PIC0_STATUS_0_INTR_FLAG_31_MASK)

#define MP2_PIC0_STATUS_0_DEFAULT      0x00000000

#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_0(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_0_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_0_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_1(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_1_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_1_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_2(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_2_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_2_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_3(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_3_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_3_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_4(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_4_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_4_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_5(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_5_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_5_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_6(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_6_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_6_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_7(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_7_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_7_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_8(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_8_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_8_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_9(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_9_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_9_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_10(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_10_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_10_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_11(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_11_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_11_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_12(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_12_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_12_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_13(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_13_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_13_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_14(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_14_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_14_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_15(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_15_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_15_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_16(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_16_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_16_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_17(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_17_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_17_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_18(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_18_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_18_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_19(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_19_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_19_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_20(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_20_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_20_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_21(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_21_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_21_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_22(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_22_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_22_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_23(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_23_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_23_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_24(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_24_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_24_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_25(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_25_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_25_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_26(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_26_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_26_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_27(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_27_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_27_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_28(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_28_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_28_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_29(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_29_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_29_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_30(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_30_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_30_SHIFT)
#define MP2_PIC0_STATUS_0_GET_INTR_FLAG_31(mp2_pic0_status_0) \
     ((mp2_pic0_status_0 & MP2_PIC0_STATUS_0_INTR_FLAG_31_MASK) >> MP2_PIC0_STATUS_0_INTR_FLAG_31_SHIFT)

#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_0(mp2_pic0_status_0_reg, intr_flag_0) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_0_MASK) | (intr_flag_0 << MP2_PIC0_STATUS_0_INTR_FLAG_0_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_1(mp2_pic0_status_0_reg, intr_flag_1) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_1_MASK) | (intr_flag_1 << MP2_PIC0_STATUS_0_INTR_FLAG_1_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_2(mp2_pic0_status_0_reg, intr_flag_2) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_2_MASK) | (intr_flag_2 << MP2_PIC0_STATUS_0_INTR_FLAG_2_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_3(mp2_pic0_status_0_reg, intr_flag_3) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_3_MASK) | (intr_flag_3 << MP2_PIC0_STATUS_0_INTR_FLAG_3_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_4(mp2_pic0_status_0_reg, intr_flag_4) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_4_MASK) | (intr_flag_4 << MP2_PIC0_STATUS_0_INTR_FLAG_4_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_5(mp2_pic0_status_0_reg, intr_flag_5) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_5_MASK) | (intr_flag_5 << MP2_PIC0_STATUS_0_INTR_FLAG_5_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_6(mp2_pic0_status_0_reg, intr_flag_6) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_6_MASK) | (intr_flag_6 << MP2_PIC0_STATUS_0_INTR_FLAG_6_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_7(mp2_pic0_status_0_reg, intr_flag_7) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_7_MASK) | (intr_flag_7 << MP2_PIC0_STATUS_0_INTR_FLAG_7_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_8(mp2_pic0_status_0_reg, intr_flag_8) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_8_MASK) | (intr_flag_8 << MP2_PIC0_STATUS_0_INTR_FLAG_8_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_9(mp2_pic0_status_0_reg, intr_flag_9) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_9_MASK) | (intr_flag_9 << MP2_PIC0_STATUS_0_INTR_FLAG_9_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_10(mp2_pic0_status_0_reg, intr_flag_10) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_10_MASK) | (intr_flag_10 << MP2_PIC0_STATUS_0_INTR_FLAG_10_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_11(mp2_pic0_status_0_reg, intr_flag_11) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_11_MASK) | (intr_flag_11 << MP2_PIC0_STATUS_0_INTR_FLAG_11_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_12(mp2_pic0_status_0_reg, intr_flag_12) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_12_MASK) | (intr_flag_12 << MP2_PIC0_STATUS_0_INTR_FLAG_12_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_13(mp2_pic0_status_0_reg, intr_flag_13) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_13_MASK) | (intr_flag_13 << MP2_PIC0_STATUS_0_INTR_FLAG_13_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_14(mp2_pic0_status_0_reg, intr_flag_14) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_14_MASK) | (intr_flag_14 << MP2_PIC0_STATUS_0_INTR_FLAG_14_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_15(mp2_pic0_status_0_reg, intr_flag_15) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_15_MASK) | (intr_flag_15 << MP2_PIC0_STATUS_0_INTR_FLAG_15_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_16(mp2_pic0_status_0_reg, intr_flag_16) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_16_MASK) | (intr_flag_16 << MP2_PIC0_STATUS_0_INTR_FLAG_16_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_17(mp2_pic0_status_0_reg, intr_flag_17) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_17_MASK) | (intr_flag_17 << MP2_PIC0_STATUS_0_INTR_FLAG_17_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_18(mp2_pic0_status_0_reg, intr_flag_18) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_18_MASK) | (intr_flag_18 << MP2_PIC0_STATUS_0_INTR_FLAG_18_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_19(mp2_pic0_status_0_reg, intr_flag_19) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_19_MASK) | (intr_flag_19 << MP2_PIC0_STATUS_0_INTR_FLAG_19_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_20(mp2_pic0_status_0_reg, intr_flag_20) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_20_MASK) | (intr_flag_20 << MP2_PIC0_STATUS_0_INTR_FLAG_20_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_21(mp2_pic0_status_0_reg, intr_flag_21) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_21_MASK) | (intr_flag_21 << MP2_PIC0_STATUS_0_INTR_FLAG_21_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_22(mp2_pic0_status_0_reg, intr_flag_22) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_22_MASK) | (intr_flag_22 << MP2_PIC0_STATUS_0_INTR_FLAG_22_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_23(mp2_pic0_status_0_reg, intr_flag_23) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_23_MASK) | (intr_flag_23 << MP2_PIC0_STATUS_0_INTR_FLAG_23_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_24(mp2_pic0_status_0_reg, intr_flag_24) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_24_MASK) | (intr_flag_24 << MP2_PIC0_STATUS_0_INTR_FLAG_24_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_25(mp2_pic0_status_0_reg, intr_flag_25) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_25_MASK) | (intr_flag_25 << MP2_PIC0_STATUS_0_INTR_FLAG_25_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_26(mp2_pic0_status_0_reg, intr_flag_26) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_26_MASK) | (intr_flag_26 << MP2_PIC0_STATUS_0_INTR_FLAG_26_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_27(mp2_pic0_status_0_reg, intr_flag_27) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_27_MASK) | (intr_flag_27 << MP2_PIC0_STATUS_0_INTR_FLAG_27_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_28(mp2_pic0_status_0_reg, intr_flag_28) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_28_MASK) | (intr_flag_28 << MP2_PIC0_STATUS_0_INTR_FLAG_28_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_29(mp2_pic0_status_0_reg, intr_flag_29) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_29_MASK) | (intr_flag_29 << MP2_PIC0_STATUS_0_INTR_FLAG_29_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_30(mp2_pic0_status_0_reg, intr_flag_30) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_30_MASK) | (intr_flag_30 << MP2_PIC0_STATUS_0_INTR_FLAG_30_SHIFT)
#define MP2_PIC0_STATUS_0_SET_INTR_FLAG_31(mp2_pic0_status_0_reg, intr_flag_31) \
     mp2_pic0_status_0_reg = (mp2_pic0_status_0_reg & ~MP2_PIC0_STATUS_0_INTR_FLAG_31_MASK) | (intr_flag_31 << MP2_PIC0_STATUS_0_INTR_FLAG_31_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_status_0_t {
          unsigned int intr_flag_0                    : MP2_PIC0_STATUS_0_INTR_FLAG_0_SIZE;
          unsigned int intr_flag_1                    : MP2_PIC0_STATUS_0_INTR_FLAG_1_SIZE;
          unsigned int intr_flag_2                    : MP2_PIC0_STATUS_0_INTR_FLAG_2_SIZE;
          unsigned int intr_flag_3                    : MP2_PIC0_STATUS_0_INTR_FLAG_3_SIZE;
          unsigned int intr_flag_4                    : MP2_PIC0_STATUS_0_INTR_FLAG_4_SIZE;
          unsigned int intr_flag_5                    : MP2_PIC0_STATUS_0_INTR_FLAG_5_SIZE;
          unsigned int intr_flag_6                    : MP2_PIC0_STATUS_0_INTR_FLAG_6_SIZE;
          unsigned int intr_flag_7                    : MP2_PIC0_STATUS_0_INTR_FLAG_7_SIZE;
          unsigned int intr_flag_8                    : MP2_PIC0_STATUS_0_INTR_FLAG_8_SIZE;
          unsigned int intr_flag_9                    : MP2_PIC0_STATUS_0_INTR_FLAG_9_SIZE;
          unsigned int intr_flag_10                   : MP2_PIC0_STATUS_0_INTR_FLAG_10_SIZE;
          unsigned int intr_flag_11                   : MP2_PIC0_STATUS_0_INTR_FLAG_11_SIZE;
          unsigned int intr_flag_12                   : MP2_PIC0_STATUS_0_INTR_FLAG_12_SIZE;
          unsigned int intr_flag_13                   : MP2_PIC0_STATUS_0_INTR_FLAG_13_SIZE;
          unsigned int intr_flag_14                   : MP2_PIC0_STATUS_0_INTR_FLAG_14_SIZE;
          unsigned int intr_flag_15                   : MP2_PIC0_STATUS_0_INTR_FLAG_15_SIZE;
          unsigned int intr_flag_16                   : MP2_PIC0_STATUS_0_INTR_FLAG_16_SIZE;
          unsigned int intr_flag_17                   : MP2_PIC0_STATUS_0_INTR_FLAG_17_SIZE;
          unsigned int intr_flag_18                   : MP2_PIC0_STATUS_0_INTR_FLAG_18_SIZE;
          unsigned int intr_flag_19                   : MP2_PIC0_STATUS_0_INTR_FLAG_19_SIZE;
          unsigned int intr_flag_20                   : MP2_PIC0_STATUS_0_INTR_FLAG_20_SIZE;
          unsigned int intr_flag_21                   : MP2_PIC0_STATUS_0_INTR_FLAG_21_SIZE;
          unsigned int intr_flag_22                   : MP2_PIC0_STATUS_0_INTR_FLAG_22_SIZE;
          unsigned int intr_flag_23                   : MP2_PIC0_STATUS_0_INTR_FLAG_23_SIZE;
          unsigned int intr_flag_24                   : MP2_PIC0_STATUS_0_INTR_FLAG_24_SIZE;
          unsigned int intr_flag_25                   : MP2_PIC0_STATUS_0_INTR_FLAG_25_SIZE;
          unsigned int intr_flag_26                   : MP2_PIC0_STATUS_0_INTR_FLAG_26_SIZE;
          unsigned int intr_flag_27                   : MP2_PIC0_STATUS_0_INTR_FLAG_27_SIZE;
          unsigned int intr_flag_28                   : MP2_PIC0_STATUS_0_INTR_FLAG_28_SIZE;
          unsigned int intr_flag_29                   : MP2_PIC0_STATUS_0_INTR_FLAG_29_SIZE;
          unsigned int intr_flag_30                   : MP2_PIC0_STATUS_0_INTR_FLAG_30_SIZE;
          unsigned int intr_flag_31                   : MP2_PIC0_STATUS_0_INTR_FLAG_31_SIZE;
     } mp2_pic0_status_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_status_0_t {
          unsigned int intr_flag_31                   : MP2_PIC0_STATUS_0_INTR_FLAG_31_SIZE;
          unsigned int intr_flag_30                   : MP2_PIC0_STATUS_0_INTR_FLAG_30_SIZE;
          unsigned int intr_flag_29                   : MP2_PIC0_STATUS_0_INTR_FLAG_29_SIZE;
          unsigned int intr_flag_28                   : MP2_PIC0_STATUS_0_INTR_FLAG_28_SIZE;
          unsigned int intr_flag_27                   : MP2_PIC0_STATUS_0_INTR_FLAG_27_SIZE;
          unsigned int intr_flag_26                   : MP2_PIC0_STATUS_0_INTR_FLAG_26_SIZE;
          unsigned int intr_flag_25                   : MP2_PIC0_STATUS_0_INTR_FLAG_25_SIZE;
          unsigned int intr_flag_24                   : MP2_PIC0_STATUS_0_INTR_FLAG_24_SIZE;
          unsigned int intr_flag_23                   : MP2_PIC0_STATUS_0_INTR_FLAG_23_SIZE;
          unsigned int intr_flag_22                   : MP2_PIC0_STATUS_0_INTR_FLAG_22_SIZE;
          unsigned int intr_flag_21                   : MP2_PIC0_STATUS_0_INTR_FLAG_21_SIZE;
          unsigned int intr_flag_20                   : MP2_PIC0_STATUS_0_INTR_FLAG_20_SIZE;
          unsigned int intr_flag_19                   : MP2_PIC0_STATUS_0_INTR_FLAG_19_SIZE;
          unsigned int intr_flag_18                   : MP2_PIC0_STATUS_0_INTR_FLAG_18_SIZE;
          unsigned int intr_flag_17                   : MP2_PIC0_STATUS_0_INTR_FLAG_17_SIZE;
          unsigned int intr_flag_16                   : MP2_PIC0_STATUS_0_INTR_FLAG_16_SIZE;
          unsigned int intr_flag_15                   : MP2_PIC0_STATUS_0_INTR_FLAG_15_SIZE;
          unsigned int intr_flag_14                   : MP2_PIC0_STATUS_0_INTR_FLAG_14_SIZE;
          unsigned int intr_flag_13                   : MP2_PIC0_STATUS_0_INTR_FLAG_13_SIZE;
          unsigned int intr_flag_12                   : MP2_PIC0_STATUS_0_INTR_FLAG_12_SIZE;
          unsigned int intr_flag_11                   : MP2_PIC0_STATUS_0_INTR_FLAG_11_SIZE;
          unsigned int intr_flag_10                   : MP2_PIC0_STATUS_0_INTR_FLAG_10_SIZE;
          unsigned int intr_flag_9                    : MP2_PIC0_STATUS_0_INTR_FLAG_9_SIZE;
          unsigned int intr_flag_8                    : MP2_PIC0_STATUS_0_INTR_FLAG_8_SIZE;
          unsigned int intr_flag_7                    : MP2_PIC0_STATUS_0_INTR_FLAG_7_SIZE;
          unsigned int intr_flag_6                    : MP2_PIC0_STATUS_0_INTR_FLAG_6_SIZE;
          unsigned int intr_flag_5                    : MP2_PIC0_STATUS_0_INTR_FLAG_5_SIZE;
          unsigned int intr_flag_4                    : MP2_PIC0_STATUS_0_INTR_FLAG_4_SIZE;
          unsigned int intr_flag_3                    : MP2_PIC0_STATUS_0_INTR_FLAG_3_SIZE;
          unsigned int intr_flag_2                    : MP2_PIC0_STATUS_0_INTR_FLAG_2_SIZE;
          unsigned int intr_flag_1                    : MP2_PIC0_STATUS_0_INTR_FLAG_1_SIZE;
          unsigned int intr_flag_0                    : MP2_PIC0_STATUS_0_INTR_FLAG_0_SIZE;
     } mp2_pic0_status_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_status_0_t f;
} mp2_pic0_status_0_u;


/*
 * MP2_PIC0_STATUS_1 struct
 */

#define MP2_PIC0_STATUS_1_REG_SIZE     32
#define MP2_PIC0_STATUS_1_INTR_FLAG_0_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_1_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_2_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_3_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_4_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_5_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_6_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_7_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_8_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_9_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_10_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_11_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_12_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_13_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_14_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_15_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_16_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_17_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_18_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_19_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_20_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_21_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_22_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_23_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_24_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_25_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_26_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_27_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_28_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_29_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_30_SIZE 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_31_SIZE 1

#define MP2_PIC0_STATUS_1_INTR_FLAG_0_SHIFT 0
#define MP2_PIC0_STATUS_1_INTR_FLAG_1_SHIFT 1
#define MP2_PIC0_STATUS_1_INTR_FLAG_2_SHIFT 2
#define MP2_PIC0_STATUS_1_INTR_FLAG_3_SHIFT 3
#define MP2_PIC0_STATUS_1_INTR_FLAG_4_SHIFT 4
#define MP2_PIC0_STATUS_1_INTR_FLAG_5_SHIFT 5
#define MP2_PIC0_STATUS_1_INTR_FLAG_6_SHIFT 6
#define MP2_PIC0_STATUS_1_INTR_FLAG_7_SHIFT 7
#define MP2_PIC0_STATUS_1_INTR_FLAG_8_SHIFT 8
#define MP2_PIC0_STATUS_1_INTR_FLAG_9_SHIFT 9
#define MP2_PIC0_STATUS_1_INTR_FLAG_10_SHIFT 10
#define MP2_PIC0_STATUS_1_INTR_FLAG_11_SHIFT 11
#define MP2_PIC0_STATUS_1_INTR_FLAG_12_SHIFT 12
#define MP2_PIC0_STATUS_1_INTR_FLAG_13_SHIFT 13
#define MP2_PIC0_STATUS_1_INTR_FLAG_14_SHIFT 14
#define MP2_PIC0_STATUS_1_INTR_FLAG_15_SHIFT 15
#define MP2_PIC0_STATUS_1_INTR_FLAG_16_SHIFT 16
#define MP2_PIC0_STATUS_1_INTR_FLAG_17_SHIFT 17
#define MP2_PIC0_STATUS_1_INTR_FLAG_18_SHIFT 18
#define MP2_PIC0_STATUS_1_INTR_FLAG_19_SHIFT 19
#define MP2_PIC0_STATUS_1_INTR_FLAG_20_SHIFT 20
#define MP2_PIC0_STATUS_1_INTR_FLAG_21_SHIFT 21
#define MP2_PIC0_STATUS_1_INTR_FLAG_22_SHIFT 22
#define MP2_PIC0_STATUS_1_INTR_FLAG_23_SHIFT 23
#define MP2_PIC0_STATUS_1_INTR_FLAG_24_SHIFT 24
#define MP2_PIC0_STATUS_1_INTR_FLAG_25_SHIFT 25
#define MP2_PIC0_STATUS_1_INTR_FLAG_26_SHIFT 26
#define MP2_PIC0_STATUS_1_INTR_FLAG_27_SHIFT 27
#define MP2_PIC0_STATUS_1_INTR_FLAG_28_SHIFT 28
#define MP2_PIC0_STATUS_1_INTR_FLAG_29_SHIFT 29
#define MP2_PIC0_STATUS_1_INTR_FLAG_30_SHIFT 30
#define MP2_PIC0_STATUS_1_INTR_FLAG_31_SHIFT 31

#define MP2_PIC0_STATUS_1_INTR_FLAG_0_MASK 0x1
#define MP2_PIC0_STATUS_1_INTR_FLAG_1_MASK 0x2
#define MP2_PIC0_STATUS_1_INTR_FLAG_2_MASK 0x4
#define MP2_PIC0_STATUS_1_INTR_FLAG_3_MASK 0x8
#define MP2_PIC0_STATUS_1_INTR_FLAG_4_MASK 0x10
#define MP2_PIC0_STATUS_1_INTR_FLAG_5_MASK 0x20
#define MP2_PIC0_STATUS_1_INTR_FLAG_6_MASK 0x40
#define MP2_PIC0_STATUS_1_INTR_FLAG_7_MASK 0x80
#define MP2_PIC0_STATUS_1_INTR_FLAG_8_MASK 0x100
#define MP2_PIC0_STATUS_1_INTR_FLAG_9_MASK 0x200
#define MP2_PIC0_STATUS_1_INTR_FLAG_10_MASK 0x400
#define MP2_PIC0_STATUS_1_INTR_FLAG_11_MASK 0x800
#define MP2_PIC0_STATUS_1_INTR_FLAG_12_MASK 0x1000
#define MP2_PIC0_STATUS_1_INTR_FLAG_13_MASK 0x2000
#define MP2_PIC0_STATUS_1_INTR_FLAG_14_MASK 0x4000
#define MP2_PIC0_STATUS_1_INTR_FLAG_15_MASK 0x8000
#define MP2_PIC0_STATUS_1_INTR_FLAG_16_MASK 0x10000
#define MP2_PIC0_STATUS_1_INTR_FLAG_17_MASK 0x20000
#define MP2_PIC0_STATUS_1_INTR_FLAG_18_MASK 0x40000
#define MP2_PIC0_STATUS_1_INTR_FLAG_19_MASK 0x80000
#define MP2_PIC0_STATUS_1_INTR_FLAG_20_MASK 0x100000
#define MP2_PIC0_STATUS_1_INTR_FLAG_21_MASK 0x200000
#define MP2_PIC0_STATUS_1_INTR_FLAG_22_MASK 0x400000
#define MP2_PIC0_STATUS_1_INTR_FLAG_23_MASK 0x800000
#define MP2_PIC0_STATUS_1_INTR_FLAG_24_MASK 0x1000000
#define MP2_PIC0_STATUS_1_INTR_FLAG_25_MASK 0x2000000
#define MP2_PIC0_STATUS_1_INTR_FLAG_26_MASK 0x4000000
#define MP2_PIC0_STATUS_1_INTR_FLAG_27_MASK 0x8000000
#define MP2_PIC0_STATUS_1_INTR_FLAG_28_MASK 0x10000000
#define MP2_PIC0_STATUS_1_INTR_FLAG_29_MASK 0x20000000
#define MP2_PIC0_STATUS_1_INTR_FLAG_30_MASK 0x40000000
#define MP2_PIC0_STATUS_1_INTR_FLAG_31_MASK 0x80000000

#define MP2_PIC0_STATUS_1_MASK \
     (MP2_PIC0_STATUS_1_INTR_FLAG_0_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_1_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_2_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_3_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_4_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_5_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_6_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_7_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_8_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_9_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_10_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_11_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_12_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_13_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_14_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_15_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_16_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_17_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_18_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_19_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_20_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_21_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_22_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_23_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_24_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_25_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_26_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_27_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_28_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_29_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_30_MASK | \
      MP2_PIC0_STATUS_1_INTR_FLAG_31_MASK)

#define MP2_PIC0_STATUS_1_DEFAULT      0x00000000

#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_0(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_0_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_0_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_1(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_1_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_1_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_2(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_2_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_2_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_3(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_3_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_3_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_4(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_4_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_4_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_5(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_5_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_5_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_6(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_6_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_6_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_7(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_7_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_7_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_8(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_8_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_8_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_9(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_9_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_9_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_10(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_10_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_10_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_11(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_11_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_11_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_12(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_12_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_12_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_13(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_13_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_13_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_14(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_14_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_14_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_15(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_15_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_15_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_16(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_16_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_16_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_17(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_17_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_17_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_18(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_18_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_18_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_19(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_19_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_19_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_20(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_20_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_20_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_21(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_21_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_21_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_22(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_22_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_22_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_23(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_23_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_23_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_24(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_24_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_24_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_25(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_25_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_25_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_26(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_26_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_26_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_27(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_27_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_27_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_28(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_28_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_28_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_29(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_29_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_29_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_30(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_30_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_30_SHIFT)
#define MP2_PIC0_STATUS_1_GET_INTR_FLAG_31(mp2_pic0_status_1) \
     ((mp2_pic0_status_1 & MP2_PIC0_STATUS_1_INTR_FLAG_31_MASK) >> MP2_PIC0_STATUS_1_INTR_FLAG_31_SHIFT)

#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_0(mp2_pic0_status_1_reg, intr_flag_0) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_0_MASK) | (intr_flag_0 << MP2_PIC0_STATUS_1_INTR_FLAG_0_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_1(mp2_pic0_status_1_reg, intr_flag_1) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_1_MASK) | (intr_flag_1 << MP2_PIC0_STATUS_1_INTR_FLAG_1_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_2(mp2_pic0_status_1_reg, intr_flag_2) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_2_MASK) | (intr_flag_2 << MP2_PIC0_STATUS_1_INTR_FLAG_2_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_3(mp2_pic0_status_1_reg, intr_flag_3) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_3_MASK) | (intr_flag_3 << MP2_PIC0_STATUS_1_INTR_FLAG_3_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_4(mp2_pic0_status_1_reg, intr_flag_4) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_4_MASK) | (intr_flag_4 << MP2_PIC0_STATUS_1_INTR_FLAG_4_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_5(mp2_pic0_status_1_reg, intr_flag_5) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_5_MASK) | (intr_flag_5 << MP2_PIC0_STATUS_1_INTR_FLAG_5_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_6(mp2_pic0_status_1_reg, intr_flag_6) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_6_MASK) | (intr_flag_6 << MP2_PIC0_STATUS_1_INTR_FLAG_6_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_7(mp2_pic0_status_1_reg, intr_flag_7) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_7_MASK) | (intr_flag_7 << MP2_PIC0_STATUS_1_INTR_FLAG_7_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_8(mp2_pic0_status_1_reg, intr_flag_8) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_8_MASK) | (intr_flag_8 << MP2_PIC0_STATUS_1_INTR_FLAG_8_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_9(mp2_pic0_status_1_reg, intr_flag_9) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_9_MASK) | (intr_flag_9 << MP2_PIC0_STATUS_1_INTR_FLAG_9_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_10(mp2_pic0_status_1_reg, intr_flag_10) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_10_MASK) | (intr_flag_10 << MP2_PIC0_STATUS_1_INTR_FLAG_10_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_11(mp2_pic0_status_1_reg, intr_flag_11) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_11_MASK) | (intr_flag_11 << MP2_PIC0_STATUS_1_INTR_FLAG_11_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_12(mp2_pic0_status_1_reg, intr_flag_12) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_12_MASK) | (intr_flag_12 << MP2_PIC0_STATUS_1_INTR_FLAG_12_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_13(mp2_pic0_status_1_reg, intr_flag_13) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_13_MASK) | (intr_flag_13 << MP2_PIC0_STATUS_1_INTR_FLAG_13_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_14(mp2_pic0_status_1_reg, intr_flag_14) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_14_MASK) | (intr_flag_14 << MP2_PIC0_STATUS_1_INTR_FLAG_14_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_15(mp2_pic0_status_1_reg, intr_flag_15) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_15_MASK) | (intr_flag_15 << MP2_PIC0_STATUS_1_INTR_FLAG_15_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_16(mp2_pic0_status_1_reg, intr_flag_16) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_16_MASK) | (intr_flag_16 << MP2_PIC0_STATUS_1_INTR_FLAG_16_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_17(mp2_pic0_status_1_reg, intr_flag_17) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_17_MASK) | (intr_flag_17 << MP2_PIC0_STATUS_1_INTR_FLAG_17_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_18(mp2_pic0_status_1_reg, intr_flag_18) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_18_MASK) | (intr_flag_18 << MP2_PIC0_STATUS_1_INTR_FLAG_18_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_19(mp2_pic0_status_1_reg, intr_flag_19) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_19_MASK) | (intr_flag_19 << MP2_PIC0_STATUS_1_INTR_FLAG_19_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_20(mp2_pic0_status_1_reg, intr_flag_20) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_20_MASK) | (intr_flag_20 << MP2_PIC0_STATUS_1_INTR_FLAG_20_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_21(mp2_pic0_status_1_reg, intr_flag_21) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_21_MASK) | (intr_flag_21 << MP2_PIC0_STATUS_1_INTR_FLAG_21_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_22(mp2_pic0_status_1_reg, intr_flag_22) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_22_MASK) | (intr_flag_22 << MP2_PIC0_STATUS_1_INTR_FLAG_22_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_23(mp2_pic0_status_1_reg, intr_flag_23) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_23_MASK) | (intr_flag_23 << MP2_PIC0_STATUS_1_INTR_FLAG_23_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_24(mp2_pic0_status_1_reg, intr_flag_24) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_24_MASK) | (intr_flag_24 << MP2_PIC0_STATUS_1_INTR_FLAG_24_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_25(mp2_pic0_status_1_reg, intr_flag_25) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_25_MASK) | (intr_flag_25 << MP2_PIC0_STATUS_1_INTR_FLAG_25_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_26(mp2_pic0_status_1_reg, intr_flag_26) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_26_MASK) | (intr_flag_26 << MP2_PIC0_STATUS_1_INTR_FLAG_26_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_27(mp2_pic0_status_1_reg, intr_flag_27) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_27_MASK) | (intr_flag_27 << MP2_PIC0_STATUS_1_INTR_FLAG_27_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_28(mp2_pic0_status_1_reg, intr_flag_28) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_28_MASK) | (intr_flag_28 << MP2_PIC0_STATUS_1_INTR_FLAG_28_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_29(mp2_pic0_status_1_reg, intr_flag_29) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_29_MASK) | (intr_flag_29 << MP2_PIC0_STATUS_1_INTR_FLAG_29_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_30(mp2_pic0_status_1_reg, intr_flag_30) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_30_MASK) | (intr_flag_30 << MP2_PIC0_STATUS_1_INTR_FLAG_30_SHIFT)
#define MP2_PIC0_STATUS_1_SET_INTR_FLAG_31(mp2_pic0_status_1_reg, intr_flag_31) \
     mp2_pic0_status_1_reg = (mp2_pic0_status_1_reg & ~MP2_PIC0_STATUS_1_INTR_FLAG_31_MASK) | (intr_flag_31 << MP2_PIC0_STATUS_1_INTR_FLAG_31_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_status_1_t {
          unsigned int intr_flag_0                    : MP2_PIC0_STATUS_1_INTR_FLAG_0_SIZE;
          unsigned int intr_flag_1                    : MP2_PIC0_STATUS_1_INTR_FLAG_1_SIZE;
          unsigned int intr_flag_2                    : MP2_PIC0_STATUS_1_INTR_FLAG_2_SIZE;
          unsigned int intr_flag_3                    : MP2_PIC0_STATUS_1_INTR_FLAG_3_SIZE;
          unsigned int intr_flag_4                    : MP2_PIC0_STATUS_1_INTR_FLAG_4_SIZE;
          unsigned int intr_flag_5                    : MP2_PIC0_STATUS_1_INTR_FLAG_5_SIZE;
          unsigned int intr_flag_6                    : MP2_PIC0_STATUS_1_INTR_FLAG_6_SIZE;
          unsigned int intr_flag_7                    : MP2_PIC0_STATUS_1_INTR_FLAG_7_SIZE;
          unsigned int intr_flag_8                    : MP2_PIC0_STATUS_1_INTR_FLAG_8_SIZE;
          unsigned int intr_flag_9                    : MP2_PIC0_STATUS_1_INTR_FLAG_9_SIZE;
          unsigned int intr_flag_10                   : MP2_PIC0_STATUS_1_INTR_FLAG_10_SIZE;
          unsigned int intr_flag_11                   : MP2_PIC0_STATUS_1_INTR_FLAG_11_SIZE;
          unsigned int intr_flag_12                   : MP2_PIC0_STATUS_1_INTR_FLAG_12_SIZE;
          unsigned int intr_flag_13                   : MP2_PIC0_STATUS_1_INTR_FLAG_13_SIZE;
          unsigned int intr_flag_14                   : MP2_PIC0_STATUS_1_INTR_FLAG_14_SIZE;
          unsigned int intr_flag_15                   : MP2_PIC0_STATUS_1_INTR_FLAG_15_SIZE;
          unsigned int intr_flag_16                   : MP2_PIC0_STATUS_1_INTR_FLAG_16_SIZE;
          unsigned int intr_flag_17                   : MP2_PIC0_STATUS_1_INTR_FLAG_17_SIZE;
          unsigned int intr_flag_18                   : MP2_PIC0_STATUS_1_INTR_FLAG_18_SIZE;
          unsigned int intr_flag_19                   : MP2_PIC0_STATUS_1_INTR_FLAG_19_SIZE;
          unsigned int intr_flag_20                   : MP2_PIC0_STATUS_1_INTR_FLAG_20_SIZE;
          unsigned int intr_flag_21                   : MP2_PIC0_STATUS_1_INTR_FLAG_21_SIZE;
          unsigned int intr_flag_22                   : MP2_PIC0_STATUS_1_INTR_FLAG_22_SIZE;
          unsigned int intr_flag_23                   : MP2_PIC0_STATUS_1_INTR_FLAG_23_SIZE;
          unsigned int intr_flag_24                   : MP2_PIC0_STATUS_1_INTR_FLAG_24_SIZE;
          unsigned int intr_flag_25                   : MP2_PIC0_STATUS_1_INTR_FLAG_25_SIZE;
          unsigned int intr_flag_26                   : MP2_PIC0_STATUS_1_INTR_FLAG_26_SIZE;
          unsigned int intr_flag_27                   : MP2_PIC0_STATUS_1_INTR_FLAG_27_SIZE;
          unsigned int intr_flag_28                   : MP2_PIC0_STATUS_1_INTR_FLAG_28_SIZE;
          unsigned int intr_flag_29                   : MP2_PIC0_STATUS_1_INTR_FLAG_29_SIZE;
          unsigned int intr_flag_30                   : MP2_PIC0_STATUS_1_INTR_FLAG_30_SIZE;
          unsigned int intr_flag_31                   : MP2_PIC0_STATUS_1_INTR_FLAG_31_SIZE;
     } mp2_pic0_status_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_status_1_t {
          unsigned int intr_flag_31                   : MP2_PIC0_STATUS_1_INTR_FLAG_31_SIZE;
          unsigned int intr_flag_30                   : MP2_PIC0_STATUS_1_INTR_FLAG_30_SIZE;
          unsigned int intr_flag_29                   : MP2_PIC0_STATUS_1_INTR_FLAG_29_SIZE;
          unsigned int intr_flag_28                   : MP2_PIC0_STATUS_1_INTR_FLAG_28_SIZE;
          unsigned int intr_flag_27                   : MP2_PIC0_STATUS_1_INTR_FLAG_27_SIZE;
          unsigned int intr_flag_26                   : MP2_PIC0_STATUS_1_INTR_FLAG_26_SIZE;
          unsigned int intr_flag_25                   : MP2_PIC0_STATUS_1_INTR_FLAG_25_SIZE;
          unsigned int intr_flag_24                   : MP2_PIC0_STATUS_1_INTR_FLAG_24_SIZE;
          unsigned int intr_flag_23                   : MP2_PIC0_STATUS_1_INTR_FLAG_23_SIZE;
          unsigned int intr_flag_22                   : MP2_PIC0_STATUS_1_INTR_FLAG_22_SIZE;
          unsigned int intr_flag_21                   : MP2_PIC0_STATUS_1_INTR_FLAG_21_SIZE;
          unsigned int intr_flag_20                   : MP2_PIC0_STATUS_1_INTR_FLAG_20_SIZE;
          unsigned int intr_flag_19                   : MP2_PIC0_STATUS_1_INTR_FLAG_19_SIZE;
          unsigned int intr_flag_18                   : MP2_PIC0_STATUS_1_INTR_FLAG_18_SIZE;
          unsigned int intr_flag_17                   : MP2_PIC0_STATUS_1_INTR_FLAG_17_SIZE;
          unsigned int intr_flag_16                   : MP2_PIC0_STATUS_1_INTR_FLAG_16_SIZE;
          unsigned int intr_flag_15                   : MP2_PIC0_STATUS_1_INTR_FLAG_15_SIZE;
          unsigned int intr_flag_14                   : MP2_PIC0_STATUS_1_INTR_FLAG_14_SIZE;
          unsigned int intr_flag_13                   : MP2_PIC0_STATUS_1_INTR_FLAG_13_SIZE;
          unsigned int intr_flag_12                   : MP2_PIC0_STATUS_1_INTR_FLAG_12_SIZE;
          unsigned int intr_flag_11                   : MP2_PIC0_STATUS_1_INTR_FLAG_11_SIZE;
          unsigned int intr_flag_10                   : MP2_PIC0_STATUS_1_INTR_FLAG_10_SIZE;
          unsigned int intr_flag_9                    : MP2_PIC0_STATUS_1_INTR_FLAG_9_SIZE;
          unsigned int intr_flag_8                    : MP2_PIC0_STATUS_1_INTR_FLAG_8_SIZE;
          unsigned int intr_flag_7                    : MP2_PIC0_STATUS_1_INTR_FLAG_7_SIZE;
          unsigned int intr_flag_6                    : MP2_PIC0_STATUS_1_INTR_FLAG_6_SIZE;
          unsigned int intr_flag_5                    : MP2_PIC0_STATUS_1_INTR_FLAG_5_SIZE;
          unsigned int intr_flag_4                    : MP2_PIC0_STATUS_1_INTR_FLAG_4_SIZE;
          unsigned int intr_flag_3                    : MP2_PIC0_STATUS_1_INTR_FLAG_3_SIZE;
          unsigned int intr_flag_2                    : MP2_PIC0_STATUS_1_INTR_FLAG_2_SIZE;
          unsigned int intr_flag_1                    : MP2_PIC0_STATUS_1_INTR_FLAG_1_SIZE;
          unsigned int intr_flag_0                    : MP2_PIC0_STATUS_1_INTR_FLAG_0_SIZE;
     } mp2_pic0_status_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_status_1_t f;
} mp2_pic0_status_1_u;


/*
 * MP2_PIC0_STATUS_2 struct
 */

#define MP2_PIC0_STATUS_2_REG_SIZE     32
#define MP2_PIC0_STATUS_2_INTR_FLAG_0_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_1_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_2_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_3_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_4_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_5_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_6_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_7_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_8_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_9_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_10_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_11_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_12_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_13_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_14_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_15_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_16_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_17_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_18_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_19_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_20_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_21_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_22_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_23_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_24_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_25_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_26_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_27_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_28_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_29_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_30_SIZE 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_31_SIZE 1

#define MP2_PIC0_STATUS_2_INTR_FLAG_0_SHIFT 0
#define MP2_PIC0_STATUS_2_INTR_FLAG_1_SHIFT 1
#define MP2_PIC0_STATUS_2_INTR_FLAG_2_SHIFT 2
#define MP2_PIC0_STATUS_2_INTR_FLAG_3_SHIFT 3
#define MP2_PIC0_STATUS_2_INTR_FLAG_4_SHIFT 4
#define MP2_PIC0_STATUS_2_INTR_FLAG_5_SHIFT 5
#define MP2_PIC0_STATUS_2_INTR_FLAG_6_SHIFT 6
#define MP2_PIC0_STATUS_2_INTR_FLAG_7_SHIFT 7
#define MP2_PIC0_STATUS_2_INTR_FLAG_8_SHIFT 8
#define MP2_PIC0_STATUS_2_INTR_FLAG_9_SHIFT 9
#define MP2_PIC0_STATUS_2_INTR_FLAG_10_SHIFT 10
#define MP2_PIC0_STATUS_2_INTR_FLAG_11_SHIFT 11
#define MP2_PIC0_STATUS_2_INTR_FLAG_12_SHIFT 12
#define MP2_PIC0_STATUS_2_INTR_FLAG_13_SHIFT 13
#define MP2_PIC0_STATUS_2_INTR_FLAG_14_SHIFT 14
#define MP2_PIC0_STATUS_2_INTR_FLAG_15_SHIFT 15
#define MP2_PIC0_STATUS_2_INTR_FLAG_16_SHIFT 16
#define MP2_PIC0_STATUS_2_INTR_FLAG_17_SHIFT 17
#define MP2_PIC0_STATUS_2_INTR_FLAG_18_SHIFT 18
#define MP2_PIC0_STATUS_2_INTR_FLAG_19_SHIFT 19
#define MP2_PIC0_STATUS_2_INTR_FLAG_20_SHIFT 20
#define MP2_PIC0_STATUS_2_INTR_FLAG_21_SHIFT 21
#define MP2_PIC0_STATUS_2_INTR_FLAG_22_SHIFT 22
#define MP2_PIC0_STATUS_2_INTR_FLAG_23_SHIFT 23
#define MP2_PIC0_STATUS_2_INTR_FLAG_24_SHIFT 24
#define MP2_PIC0_STATUS_2_INTR_FLAG_25_SHIFT 25
#define MP2_PIC0_STATUS_2_INTR_FLAG_26_SHIFT 26
#define MP2_PIC0_STATUS_2_INTR_FLAG_27_SHIFT 27
#define MP2_PIC0_STATUS_2_INTR_FLAG_28_SHIFT 28
#define MP2_PIC0_STATUS_2_INTR_FLAG_29_SHIFT 29
#define MP2_PIC0_STATUS_2_INTR_FLAG_30_SHIFT 30
#define MP2_PIC0_STATUS_2_INTR_FLAG_31_SHIFT 31

#define MP2_PIC0_STATUS_2_INTR_FLAG_0_MASK 0x1
#define MP2_PIC0_STATUS_2_INTR_FLAG_1_MASK 0x2
#define MP2_PIC0_STATUS_2_INTR_FLAG_2_MASK 0x4
#define MP2_PIC0_STATUS_2_INTR_FLAG_3_MASK 0x8
#define MP2_PIC0_STATUS_2_INTR_FLAG_4_MASK 0x10
#define MP2_PIC0_STATUS_2_INTR_FLAG_5_MASK 0x20
#define MP2_PIC0_STATUS_2_INTR_FLAG_6_MASK 0x40
#define MP2_PIC0_STATUS_2_INTR_FLAG_7_MASK 0x80
#define MP2_PIC0_STATUS_2_INTR_FLAG_8_MASK 0x100
#define MP2_PIC0_STATUS_2_INTR_FLAG_9_MASK 0x200
#define MP2_PIC0_STATUS_2_INTR_FLAG_10_MASK 0x400
#define MP2_PIC0_STATUS_2_INTR_FLAG_11_MASK 0x800
#define MP2_PIC0_STATUS_2_INTR_FLAG_12_MASK 0x1000
#define MP2_PIC0_STATUS_2_INTR_FLAG_13_MASK 0x2000
#define MP2_PIC0_STATUS_2_INTR_FLAG_14_MASK 0x4000
#define MP2_PIC0_STATUS_2_INTR_FLAG_15_MASK 0x8000
#define MP2_PIC0_STATUS_2_INTR_FLAG_16_MASK 0x10000
#define MP2_PIC0_STATUS_2_INTR_FLAG_17_MASK 0x20000
#define MP2_PIC0_STATUS_2_INTR_FLAG_18_MASK 0x40000
#define MP2_PIC0_STATUS_2_INTR_FLAG_19_MASK 0x80000
#define MP2_PIC0_STATUS_2_INTR_FLAG_20_MASK 0x100000
#define MP2_PIC0_STATUS_2_INTR_FLAG_21_MASK 0x200000
#define MP2_PIC0_STATUS_2_INTR_FLAG_22_MASK 0x400000
#define MP2_PIC0_STATUS_2_INTR_FLAG_23_MASK 0x800000
#define MP2_PIC0_STATUS_2_INTR_FLAG_24_MASK 0x1000000
#define MP2_PIC0_STATUS_2_INTR_FLAG_25_MASK 0x2000000
#define MP2_PIC0_STATUS_2_INTR_FLAG_26_MASK 0x4000000
#define MP2_PIC0_STATUS_2_INTR_FLAG_27_MASK 0x8000000
#define MP2_PIC0_STATUS_2_INTR_FLAG_28_MASK 0x10000000
#define MP2_PIC0_STATUS_2_INTR_FLAG_29_MASK 0x20000000
#define MP2_PIC0_STATUS_2_INTR_FLAG_30_MASK 0x40000000
#define MP2_PIC0_STATUS_2_INTR_FLAG_31_MASK 0x80000000

#define MP2_PIC0_STATUS_2_MASK \
     (MP2_PIC0_STATUS_2_INTR_FLAG_0_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_1_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_2_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_3_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_4_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_5_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_6_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_7_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_8_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_9_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_10_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_11_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_12_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_13_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_14_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_15_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_16_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_17_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_18_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_19_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_20_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_21_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_22_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_23_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_24_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_25_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_26_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_27_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_28_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_29_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_30_MASK | \
      MP2_PIC0_STATUS_2_INTR_FLAG_31_MASK)

#define MP2_PIC0_STATUS_2_DEFAULT      0x00000000

#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_0(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_0_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_0_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_1(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_1_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_1_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_2(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_2_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_2_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_3(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_3_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_3_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_4(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_4_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_4_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_5(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_5_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_5_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_6(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_6_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_6_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_7(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_7_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_7_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_8(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_8_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_8_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_9(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_9_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_9_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_10(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_10_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_10_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_11(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_11_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_11_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_12(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_12_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_12_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_13(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_13_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_13_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_14(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_14_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_14_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_15(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_15_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_15_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_16(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_16_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_16_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_17(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_17_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_17_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_18(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_18_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_18_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_19(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_19_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_19_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_20(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_20_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_20_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_21(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_21_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_21_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_22(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_22_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_22_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_23(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_23_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_23_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_24(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_24_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_24_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_25(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_25_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_25_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_26(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_26_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_26_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_27(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_27_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_27_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_28(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_28_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_28_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_29(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_29_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_29_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_30(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_30_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_30_SHIFT)
#define MP2_PIC0_STATUS_2_GET_INTR_FLAG_31(mp2_pic0_status_2) \
     ((mp2_pic0_status_2 & MP2_PIC0_STATUS_2_INTR_FLAG_31_MASK) >> MP2_PIC0_STATUS_2_INTR_FLAG_31_SHIFT)

#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_0(mp2_pic0_status_2_reg, intr_flag_0) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_0_MASK) | (intr_flag_0 << MP2_PIC0_STATUS_2_INTR_FLAG_0_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_1(mp2_pic0_status_2_reg, intr_flag_1) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_1_MASK) | (intr_flag_1 << MP2_PIC0_STATUS_2_INTR_FLAG_1_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_2(mp2_pic0_status_2_reg, intr_flag_2) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_2_MASK) | (intr_flag_2 << MP2_PIC0_STATUS_2_INTR_FLAG_2_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_3(mp2_pic0_status_2_reg, intr_flag_3) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_3_MASK) | (intr_flag_3 << MP2_PIC0_STATUS_2_INTR_FLAG_3_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_4(mp2_pic0_status_2_reg, intr_flag_4) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_4_MASK) | (intr_flag_4 << MP2_PIC0_STATUS_2_INTR_FLAG_4_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_5(mp2_pic0_status_2_reg, intr_flag_5) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_5_MASK) | (intr_flag_5 << MP2_PIC0_STATUS_2_INTR_FLAG_5_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_6(mp2_pic0_status_2_reg, intr_flag_6) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_6_MASK) | (intr_flag_6 << MP2_PIC0_STATUS_2_INTR_FLAG_6_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_7(mp2_pic0_status_2_reg, intr_flag_7) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_7_MASK) | (intr_flag_7 << MP2_PIC0_STATUS_2_INTR_FLAG_7_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_8(mp2_pic0_status_2_reg, intr_flag_8) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_8_MASK) | (intr_flag_8 << MP2_PIC0_STATUS_2_INTR_FLAG_8_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_9(mp2_pic0_status_2_reg, intr_flag_9) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_9_MASK) | (intr_flag_9 << MP2_PIC0_STATUS_2_INTR_FLAG_9_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_10(mp2_pic0_status_2_reg, intr_flag_10) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_10_MASK) | (intr_flag_10 << MP2_PIC0_STATUS_2_INTR_FLAG_10_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_11(mp2_pic0_status_2_reg, intr_flag_11) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_11_MASK) | (intr_flag_11 << MP2_PIC0_STATUS_2_INTR_FLAG_11_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_12(mp2_pic0_status_2_reg, intr_flag_12) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_12_MASK) | (intr_flag_12 << MP2_PIC0_STATUS_2_INTR_FLAG_12_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_13(mp2_pic0_status_2_reg, intr_flag_13) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_13_MASK) | (intr_flag_13 << MP2_PIC0_STATUS_2_INTR_FLAG_13_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_14(mp2_pic0_status_2_reg, intr_flag_14) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_14_MASK) | (intr_flag_14 << MP2_PIC0_STATUS_2_INTR_FLAG_14_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_15(mp2_pic0_status_2_reg, intr_flag_15) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_15_MASK) | (intr_flag_15 << MP2_PIC0_STATUS_2_INTR_FLAG_15_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_16(mp2_pic0_status_2_reg, intr_flag_16) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_16_MASK) | (intr_flag_16 << MP2_PIC0_STATUS_2_INTR_FLAG_16_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_17(mp2_pic0_status_2_reg, intr_flag_17) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_17_MASK) | (intr_flag_17 << MP2_PIC0_STATUS_2_INTR_FLAG_17_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_18(mp2_pic0_status_2_reg, intr_flag_18) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_18_MASK) | (intr_flag_18 << MP2_PIC0_STATUS_2_INTR_FLAG_18_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_19(mp2_pic0_status_2_reg, intr_flag_19) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_19_MASK) | (intr_flag_19 << MP2_PIC0_STATUS_2_INTR_FLAG_19_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_20(mp2_pic0_status_2_reg, intr_flag_20) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_20_MASK) | (intr_flag_20 << MP2_PIC0_STATUS_2_INTR_FLAG_20_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_21(mp2_pic0_status_2_reg, intr_flag_21) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_21_MASK) | (intr_flag_21 << MP2_PIC0_STATUS_2_INTR_FLAG_21_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_22(mp2_pic0_status_2_reg, intr_flag_22) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_22_MASK) | (intr_flag_22 << MP2_PIC0_STATUS_2_INTR_FLAG_22_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_23(mp2_pic0_status_2_reg, intr_flag_23) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_23_MASK) | (intr_flag_23 << MP2_PIC0_STATUS_2_INTR_FLAG_23_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_24(mp2_pic0_status_2_reg, intr_flag_24) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_24_MASK) | (intr_flag_24 << MP2_PIC0_STATUS_2_INTR_FLAG_24_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_25(mp2_pic0_status_2_reg, intr_flag_25) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_25_MASK) | (intr_flag_25 << MP2_PIC0_STATUS_2_INTR_FLAG_25_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_26(mp2_pic0_status_2_reg, intr_flag_26) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_26_MASK) | (intr_flag_26 << MP2_PIC0_STATUS_2_INTR_FLAG_26_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_27(mp2_pic0_status_2_reg, intr_flag_27) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_27_MASK) | (intr_flag_27 << MP2_PIC0_STATUS_2_INTR_FLAG_27_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_28(mp2_pic0_status_2_reg, intr_flag_28) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_28_MASK) | (intr_flag_28 << MP2_PIC0_STATUS_2_INTR_FLAG_28_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_29(mp2_pic0_status_2_reg, intr_flag_29) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_29_MASK) | (intr_flag_29 << MP2_PIC0_STATUS_2_INTR_FLAG_29_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_30(mp2_pic0_status_2_reg, intr_flag_30) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_30_MASK) | (intr_flag_30 << MP2_PIC0_STATUS_2_INTR_FLAG_30_SHIFT)
#define MP2_PIC0_STATUS_2_SET_INTR_FLAG_31(mp2_pic0_status_2_reg, intr_flag_31) \
     mp2_pic0_status_2_reg = (mp2_pic0_status_2_reg & ~MP2_PIC0_STATUS_2_INTR_FLAG_31_MASK) | (intr_flag_31 << MP2_PIC0_STATUS_2_INTR_FLAG_31_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_status_2_t {
          unsigned int intr_flag_0                    : MP2_PIC0_STATUS_2_INTR_FLAG_0_SIZE;
          unsigned int intr_flag_1                    : MP2_PIC0_STATUS_2_INTR_FLAG_1_SIZE;
          unsigned int intr_flag_2                    : MP2_PIC0_STATUS_2_INTR_FLAG_2_SIZE;
          unsigned int intr_flag_3                    : MP2_PIC0_STATUS_2_INTR_FLAG_3_SIZE;
          unsigned int intr_flag_4                    : MP2_PIC0_STATUS_2_INTR_FLAG_4_SIZE;
          unsigned int intr_flag_5                    : MP2_PIC0_STATUS_2_INTR_FLAG_5_SIZE;
          unsigned int intr_flag_6                    : MP2_PIC0_STATUS_2_INTR_FLAG_6_SIZE;
          unsigned int intr_flag_7                    : MP2_PIC0_STATUS_2_INTR_FLAG_7_SIZE;
          unsigned int intr_flag_8                    : MP2_PIC0_STATUS_2_INTR_FLAG_8_SIZE;
          unsigned int intr_flag_9                    : MP2_PIC0_STATUS_2_INTR_FLAG_9_SIZE;
          unsigned int intr_flag_10                   : MP2_PIC0_STATUS_2_INTR_FLAG_10_SIZE;
          unsigned int intr_flag_11                   : MP2_PIC0_STATUS_2_INTR_FLAG_11_SIZE;
          unsigned int intr_flag_12                   : MP2_PIC0_STATUS_2_INTR_FLAG_12_SIZE;
          unsigned int intr_flag_13                   : MP2_PIC0_STATUS_2_INTR_FLAG_13_SIZE;
          unsigned int intr_flag_14                   : MP2_PIC0_STATUS_2_INTR_FLAG_14_SIZE;
          unsigned int intr_flag_15                   : MP2_PIC0_STATUS_2_INTR_FLAG_15_SIZE;
          unsigned int intr_flag_16                   : MP2_PIC0_STATUS_2_INTR_FLAG_16_SIZE;
          unsigned int intr_flag_17                   : MP2_PIC0_STATUS_2_INTR_FLAG_17_SIZE;
          unsigned int intr_flag_18                   : MP2_PIC0_STATUS_2_INTR_FLAG_18_SIZE;
          unsigned int intr_flag_19                   : MP2_PIC0_STATUS_2_INTR_FLAG_19_SIZE;
          unsigned int intr_flag_20                   : MP2_PIC0_STATUS_2_INTR_FLAG_20_SIZE;
          unsigned int intr_flag_21                   : MP2_PIC0_STATUS_2_INTR_FLAG_21_SIZE;
          unsigned int intr_flag_22                   : MP2_PIC0_STATUS_2_INTR_FLAG_22_SIZE;
          unsigned int intr_flag_23                   : MP2_PIC0_STATUS_2_INTR_FLAG_23_SIZE;
          unsigned int intr_flag_24                   : MP2_PIC0_STATUS_2_INTR_FLAG_24_SIZE;
          unsigned int intr_flag_25                   : MP2_PIC0_STATUS_2_INTR_FLAG_25_SIZE;
          unsigned int intr_flag_26                   : MP2_PIC0_STATUS_2_INTR_FLAG_26_SIZE;
          unsigned int intr_flag_27                   : MP2_PIC0_STATUS_2_INTR_FLAG_27_SIZE;
          unsigned int intr_flag_28                   : MP2_PIC0_STATUS_2_INTR_FLAG_28_SIZE;
          unsigned int intr_flag_29                   : MP2_PIC0_STATUS_2_INTR_FLAG_29_SIZE;
          unsigned int intr_flag_30                   : MP2_PIC0_STATUS_2_INTR_FLAG_30_SIZE;
          unsigned int intr_flag_31                   : MP2_PIC0_STATUS_2_INTR_FLAG_31_SIZE;
     } mp2_pic0_status_2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_status_2_t {
          unsigned int intr_flag_31                   : MP2_PIC0_STATUS_2_INTR_FLAG_31_SIZE;
          unsigned int intr_flag_30                   : MP2_PIC0_STATUS_2_INTR_FLAG_30_SIZE;
          unsigned int intr_flag_29                   : MP2_PIC0_STATUS_2_INTR_FLAG_29_SIZE;
          unsigned int intr_flag_28                   : MP2_PIC0_STATUS_2_INTR_FLAG_28_SIZE;
          unsigned int intr_flag_27                   : MP2_PIC0_STATUS_2_INTR_FLAG_27_SIZE;
          unsigned int intr_flag_26                   : MP2_PIC0_STATUS_2_INTR_FLAG_26_SIZE;
          unsigned int intr_flag_25                   : MP2_PIC0_STATUS_2_INTR_FLAG_25_SIZE;
          unsigned int intr_flag_24                   : MP2_PIC0_STATUS_2_INTR_FLAG_24_SIZE;
          unsigned int intr_flag_23                   : MP2_PIC0_STATUS_2_INTR_FLAG_23_SIZE;
          unsigned int intr_flag_22                   : MP2_PIC0_STATUS_2_INTR_FLAG_22_SIZE;
          unsigned int intr_flag_21                   : MP2_PIC0_STATUS_2_INTR_FLAG_21_SIZE;
          unsigned int intr_flag_20                   : MP2_PIC0_STATUS_2_INTR_FLAG_20_SIZE;
          unsigned int intr_flag_19                   : MP2_PIC0_STATUS_2_INTR_FLAG_19_SIZE;
          unsigned int intr_flag_18                   : MP2_PIC0_STATUS_2_INTR_FLAG_18_SIZE;
          unsigned int intr_flag_17                   : MP2_PIC0_STATUS_2_INTR_FLAG_17_SIZE;
          unsigned int intr_flag_16                   : MP2_PIC0_STATUS_2_INTR_FLAG_16_SIZE;
          unsigned int intr_flag_15                   : MP2_PIC0_STATUS_2_INTR_FLAG_15_SIZE;
          unsigned int intr_flag_14                   : MP2_PIC0_STATUS_2_INTR_FLAG_14_SIZE;
          unsigned int intr_flag_13                   : MP2_PIC0_STATUS_2_INTR_FLAG_13_SIZE;
          unsigned int intr_flag_12                   : MP2_PIC0_STATUS_2_INTR_FLAG_12_SIZE;
          unsigned int intr_flag_11                   : MP2_PIC0_STATUS_2_INTR_FLAG_11_SIZE;
          unsigned int intr_flag_10                   : MP2_PIC0_STATUS_2_INTR_FLAG_10_SIZE;
          unsigned int intr_flag_9                    : MP2_PIC0_STATUS_2_INTR_FLAG_9_SIZE;
          unsigned int intr_flag_8                    : MP2_PIC0_STATUS_2_INTR_FLAG_8_SIZE;
          unsigned int intr_flag_7                    : MP2_PIC0_STATUS_2_INTR_FLAG_7_SIZE;
          unsigned int intr_flag_6                    : MP2_PIC0_STATUS_2_INTR_FLAG_6_SIZE;
          unsigned int intr_flag_5                    : MP2_PIC0_STATUS_2_INTR_FLAG_5_SIZE;
          unsigned int intr_flag_4                    : MP2_PIC0_STATUS_2_INTR_FLAG_4_SIZE;
          unsigned int intr_flag_3                    : MP2_PIC0_STATUS_2_INTR_FLAG_3_SIZE;
          unsigned int intr_flag_2                    : MP2_PIC0_STATUS_2_INTR_FLAG_2_SIZE;
          unsigned int intr_flag_1                    : MP2_PIC0_STATUS_2_INTR_FLAG_1_SIZE;
          unsigned int intr_flag_0                    : MP2_PIC0_STATUS_2_INTR_FLAG_0_SIZE;
     } mp2_pic0_status_2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_status_2_t f;
} mp2_pic0_status_2_u;


/*
 * MP2_PIC0_STATUS_3 struct
 */

#define MP2_PIC0_STATUS_3_REG_SIZE     32
#define MP2_PIC0_STATUS_3_INTR_FLAG_0_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_1_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_2_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_3_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_4_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_5_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_6_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_7_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_8_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_9_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_10_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_11_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_12_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_13_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_14_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_15_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_16_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_17_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_18_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_19_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_20_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_21_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_22_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_23_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_24_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_25_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_26_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_27_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_28_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_29_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_30_SIZE 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_31_SIZE 1

#define MP2_PIC0_STATUS_3_INTR_FLAG_0_SHIFT 0
#define MP2_PIC0_STATUS_3_INTR_FLAG_1_SHIFT 1
#define MP2_PIC0_STATUS_3_INTR_FLAG_2_SHIFT 2
#define MP2_PIC0_STATUS_3_INTR_FLAG_3_SHIFT 3
#define MP2_PIC0_STATUS_3_INTR_FLAG_4_SHIFT 4
#define MP2_PIC0_STATUS_3_INTR_FLAG_5_SHIFT 5
#define MP2_PIC0_STATUS_3_INTR_FLAG_6_SHIFT 6
#define MP2_PIC0_STATUS_3_INTR_FLAG_7_SHIFT 7
#define MP2_PIC0_STATUS_3_INTR_FLAG_8_SHIFT 8
#define MP2_PIC0_STATUS_3_INTR_FLAG_9_SHIFT 9
#define MP2_PIC0_STATUS_3_INTR_FLAG_10_SHIFT 10
#define MP2_PIC0_STATUS_3_INTR_FLAG_11_SHIFT 11
#define MP2_PIC0_STATUS_3_INTR_FLAG_12_SHIFT 12
#define MP2_PIC0_STATUS_3_INTR_FLAG_13_SHIFT 13
#define MP2_PIC0_STATUS_3_INTR_FLAG_14_SHIFT 14
#define MP2_PIC0_STATUS_3_INTR_FLAG_15_SHIFT 15
#define MP2_PIC0_STATUS_3_INTR_FLAG_16_SHIFT 16
#define MP2_PIC0_STATUS_3_INTR_FLAG_17_SHIFT 17
#define MP2_PIC0_STATUS_3_INTR_FLAG_18_SHIFT 18
#define MP2_PIC0_STATUS_3_INTR_FLAG_19_SHIFT 19
#define MP2_PIC0_STATUS_3_INTR_FLAG_20_SHIFT 20
#define MP2_PIC0_STATUS_3_INTR_FLAG_21_SHIFT 21
#define MP2_PIC0_STATUS_3_INTR_FLAG_22_SHIFT 22
#define MP2_PIC0_STATUS_3_INTR_FLAG_23_SHIFT 23
#define MP2_PIC0_STATUS_3_INTR_FLAG_24_SHIFT 24
#define MP2_PIC0_STATUS_3_INTR_FLAG_25_SHIFT 25
#define MP2_PIC0_STATUS_3_INTR_FLAG_26_SHIFT 26
#define MP2_PIC0_STATUS_3_INTR_FLAG_27_SHIFT 27
#define MP2_PIC0_STATUS_3_INTR_FLAG_28_SHIFT 28
#define MP2_PIC0_STATUS_3_INTR_FLAG_29_SHIFT 29
#define MP2_PIC0_STATUS_3_INTR_FLAG_30_SHIFT 30
#define MP2_PIC0_STATUS_3_INTR_FLAG_31_SHIFT 31

#define MP2_PIC0_STATUS_3_INTR_FLAG_0_MASK 0x1
#define MP2_PIC0_STATUS_3_INTR_FLAG_1_MASK 0x2
#define MP2_PIC0_STATUS_3_INTR_FLAG_2_MASK 0x4
#define MP2_PIC0_STATUS_3_INTR_FLAG_3_MASK 0x8
#define MP2_PIC0_STATUS_3_INTR_FLAG_4_MASK 0x10
#define MP2_PIC0_STATUS_3_INTR_FLAG_5_MASK 0x20
#define MP2_PIC0_STATUS_3_INTR_FLAG_6_MASK 0x40
#define MP2_PIC0_STATUS_3_INTR_FLAG_7_MASK 0x80
#define MP2_PIC0_STATUS_3_INTR_FLAG_8_MASK 0x100
#define MP2_PIC0_STATUS_3_INTR_FLAG_9_MASK 0x200
#define MP2_PIC0_STATUS_3_INTR_FLAG_10_MASK 0x400
#define MP2_PIC0_STATUS_3_INTR_FLAG_11_MASK 0x800
#define MP2_PIC0_STATUS_3_INTR_FLAG_12_MASK 0x1000
#define MP2_PIC0_STATUS_3_INTR_FLAG_13_MASK 0x2000
#define MP2_PIC0_STATUS_3_INTR_FLAG_14_MASK 0x4000
#define MP2_PIC0_STATUS_3_INTR_FLAG_15_MASK 0x8000
#define MP2_PIC0_STATUS_3_INTR_FLAG_16_MASK 0x10000
#define MP2_PIC0_STATUS_3_INTR_FLAG_17_MASK 0x20000
#define MP2_PIC0_STATUS_3_INTR_FLAG_18_MASK 0x40000
#define MP2_PIC0_STATUS_3_INTR_FLAG_19_MASK 0x80000
#define MP2_PIC0_STATUS_3_INTR_FLAG_20_MASK 0x100000
#define MP2_PIC0_STATUS_3_INTR_FLAG_21_MASK 0x200000
#define MP2_PIC0_STATUS_3_INTR_FLAG_22_MASK 0x400000
#define MP2_PIC0_STATUS_3_INTR_FLAG_23_MASK 0x800000
#define MP2_PIC0_STATUS_3_INTR_FLAG_24_MASK 0x1000000
#define MP2_PIC0_STATUS_3_INTR_FLAG_25_MASK 0x2000000
#define MP2_PIC0_STATUS_3_INTR_FLAG_26_MASK 0x4000000
#define MP2_PIC0_STATUS_3_INTR_FLAG_27_MASK 0x8000000
#define MP2_PIC0_STATUS_3_INTR_FLAG_28_MASK 0x10000000
#define MP2_PIC0_STATUS_3_INTR_FLAG_29_MASK 0x20000000
#define MP2_PIC0_STATUS_3_INTR_FLAG_30_MASK 0x40000000
#define MP2_PIC0_STATUS_3_INTR_FLAG_31_MASK 0x80000000

#define MP2_PIC0_STATUS_3_MASK \
     (MP2_PIC0_STATUS_3_INTR_FLAG_0_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_1_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_2_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_3_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_4_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_5_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_6_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_7_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_8_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_9_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_10_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_11_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_12_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_13_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_14_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_15_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_16_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_17_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_18_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_19_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_20_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_21_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_22_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_23_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_24_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_25_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_26_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_27_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_28_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_29_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_30_MASK | \
      MP2_PIC0_STATUS_3_INTR_FLAG_31_MASK)

#define MP2_PIC0_STATUS_3_DEFAULT      0x00000000

#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_0(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_0_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_0_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_1(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_1_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_1_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_2(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_2_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_2_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_3(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_3_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_3_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_4(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_4_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_4_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_5(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_5_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_5_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_6(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_6_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_6_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_7(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_7_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_7_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_8(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_8_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_8_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_9(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_9_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_9_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_10(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_10_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_10_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_11(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_11_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_11_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_12(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_12_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_12_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_13(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_13_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_13_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_14(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_14_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_14_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_15(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_15_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_15_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_16(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_16_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_16_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_17(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_17_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_17_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_18(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_18_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_18_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_19(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_19_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_19_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_20(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_20_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_20_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_21(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_21_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_21_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_22(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_22_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_22_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_23(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_23_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_23_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_24(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_24_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_24_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_25(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_25_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_25_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_26(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_26_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_26_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_27(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_27_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_27_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_28(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_28_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_28_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_29(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_29_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_29_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_30(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_30_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_30_SHIFT)
#define MP2_PIC0_STATUS_3_GET_INTR_FLAG_31(mp2_pic0_status_3) \
     ((mp2_pic0_status_3 & MP2_PIC0_STATUS_3_INTR_FLAG_31_MASK) >> MP2_PIC0_STATUS_3_INTR_FLAG_31_SHIFT)

#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_0(mp2_pic0_status_3_reg, intr_flag_0) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_0_MASK) | (intr_flag_0 << MP2_PIC0_STATUS_3_INTR_FLAG_0_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_1(mp2_pic0_status_3_reg, intr_flag_1) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_1_MASK) | (intr_flag_1 << MP2_PIC0_STATUS_3_INTR_FLAG_1_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_2(mp2_pic0_status_3_reg, intr_flag_2) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_2_MASK) | (intr_flag_2 << MP2_PIC0_STATUS_3_INTR_FLAG_2_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_3(mp2_pic0_status_3_reg, intr_flag_3) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_3_MASK) | (intr_flag_3 << MP2_PIC0_STATUS_3_INTR_FLAG_3_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_4(mp2_pic0_status_3_reg, intr_flag_4) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_4_MASK) | (intr_flag_4 << MP2_PIC0_STATUS_3_INTR_FLAG_4_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_5(mp2_pic0_status_3_reg, intr_flag_5) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_5_MASK) | (intr_flag_5 << MP2_PIC0_STATUS_3_INTR_FLAG_5_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_6(mp2_pic0_status_3_reg, intr_flag_6) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_6_MASK) | (intr_flag_6 << MP2_PIC0_STATUS_3_INTR_FLAG_6_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_7(mp2_pic0_status_3_reg, intr_flag_7) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_7_MASK) | (intr_flag_7 << MP2_PIC0_STATUS_3_INTR_FLAG_7_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_8(mp2_pic0_status_3_reg, intr_flag_8) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_8_MASK) | (intr_flag_8 << MP2_PIC0_STATUS_3_INTR_FLAG_8_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_9(mp2_pic0_status_3_reg, intr_flag_9) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_9_MASK) | (intr_flag_9 << MP2_PIC0_STATUS_3_INTR_FLAG_9_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_10(mp2_pic0_status_3_reg, intr_flag_10) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_10_MASK) | (intr_flag_10 << MP2_PIC0_STATUS_3_INTR_FLAG_10_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_11(mp2_pic0_status_3_reg, intr_flag_11) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_11_MASK) | (intr_flag_11 << MP2_PIC0_STATUS_3_INTR_FLAG_11_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_12(mp2_pic0_status_3_reg, intr_flag_12) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_12_MASK) | (intr_flag_12 << MP2_PIC0_STATUS_3_INTR_FLAG_12_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_13(mp2_pic0_status_3_reg, intr_flag_13) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_13_MASK) | (intr_flag_13 << MP2_PIC0_STATUS_3_INTR_FLAG_13_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_14(mp2_pic0_status_3_reg, intr_flag_14) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_14_MASK) | (intr_flag_14 << MP2_PIC0_STATUS_3_INTR_FLAG_14_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_15(mp2_pic0_status_3_reg, intr_flag_15) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_15_MASK) | (intr_flag_15 << MP2_PIC0_STATUS_3_INTR_FLAG_15_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_16(mp2_pic0_status_3_reg, intr_flag_16) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_16_MASK) | (intr_flag_16 << MP2_PIC0_STATUS_3_INTR_FLAG_16_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_17(mp2_pic0_status_3_reg, intr_flag_17) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_17_MASK) | (intr_flag_17 << MP2_PIC0_STATUS_3_INTR_FLAG_17_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_18(mp2_pic0_status_3_reg, intr_flag_18) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_18_MASK) | (intr_flag_18 << MP2_PIC0_STATUS_3_INTR_FLAG_18_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_19(mp2_pic0_status_3_reg, intr_flag_19) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_19_MASK) | (intr_flag_19 << MP2_PIC0_STATUS_3_INTR_FLAG_19_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_20(mp2_pic0_status_3_reg, intr_flag_20) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_20_MASK) | (intr_flag_20 << MP2_PIC0_STATUS_3_INTR_FLAG_20_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_21(mp2_pic0_status_3_reg, intr_flag_21) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_21_MASK) | (intr_flag_21 << MP2_PIC0_STATUS_3_INTR_FLAG_21_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_22(mp2_pic0_status_3_reg, intr_flag_22) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_22_MASK) | (intr_flag_22 << MP2_PIC0_STATUS_3_INTR_FLAG_22_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_23(mp2_pic0_status_3_reg, intr_flag_23) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_23_MASK) | (intr_flag_23 << MP2_PIC0_STATUS_3_INTR_FLAG_23_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_24(mp2_pic0_status_3_reg, intr_flag_24) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_24_MASK) | (intr_flag_24 << MP2_PIC0_STATUS_3_INTR_FLAG_24_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_25(mp2_pic0_status_3_reg, intr_flag_25) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_25_MASK) | (intr_flag_25 << MP2_PIC0_STATUS_3_INTR_FLAG_25_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_26(mp2_pic0_status_3_reg, intr_flag_26) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_26_MASK) | (intr_flag_26 << MP2_PIC0_STATUS_3_INTR_FLAG_26_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_27(mp2_pic0_status_3_reg, intr_flag_27) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_27_MASK) | (intr_flag_27 << MP2_PIC0_STATUS_3_INTR_FLAG_27_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_28(mp2_pic0_status_3_reg, intr_flag_28) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_28_MASK) | (intr_flag_28 << MP2_PIC0_STATUS_3_INTR_FLAG_28_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_29(mp2_pic0_status_3_reg, intr_flag_29) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_29_MASK) | (intr_flag_29 << MP2_PIC0_STATUS_3_INTR_FLAG_29_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_30(mp2_pic0_status_3_reg, intr_flag_30) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_30_MASK) | (intr_flag_30 << MP2_PIC0_STATUS_3_INTR_FLAG_30_SHIFT)
#define MP2_PIC0_STATUS_3_SET_INTR_FLAG_31(mp2_pic0_status_3_reg, intr_flag_31) \
     mp2_pic0_status_3_reg = (mp2_pic0_status_3_reg & ~MP2_PIC0_STATUS_3_INTR_FLAG_31_MASK) | (intr_flag_31 << MP2_PIC0_STATUS_3_INTR_FLAG_31_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_status_3_t {
          unsigned int intr_flag_0                    : MP2_PIC0_STATUS_3_INTR_FLAG_0_SIZE;
          unsigned int intr_flag_1                    : MP2_PIC0_STATUS_3_INTR_FLAG_1_SIZE;
          unsigned int intr_flag_2                    : MP2_PIC0_STATUS_3_INTR_FLAG_2_SIZE;
          unsigned int intr_flag_3                    : MP2_PIC0_STATUS_3_INTR_FLAG_3_SIZE;
          unsigned int intr_flag_4                    : MP2_PIC0_STATUS_3_INTR_FLAG_4_SIZE;
          unsigned int intr_flag_5                    : MP2_PIC0_STATUS_3_INTR_FLAG_5_SIZE;
          unsigned int intr_flag_6                    : MP2_PIC0_STATUS_3_INTR_FLAG_6_SIZE;
          unsigned int intr_flag_7                    : MP2_PIC0_STATUS_3_INTR_FLAG_7_SIZE;
          unsigned int intr_flag_8                    : MP2_PIC0_STATUS_3_INTR_FLAG_8_SIZE;
          unsigned int intr_flag_9                    : MP2_PIC0_STATUS_3_INTR_FLAG_9_SIZE;
          unsigned int intr_flag_10                   : MP2_PIC0_STATUS_3_INTR_FLAG_10_SIZE;
          unsigned int intr_flag_11                   : MP2_PIC0_STATUS_3_INTR_FLAG_11_SIZE;
          unsigned int intr_flag_12                   : MP2_PIC0_STATUS_3_INTR_FLAG_12_SIZE;
          unsigned int intr_flag_13                   : MP2_PIC0_STATUS_3_INTR_FLAG_13_SIZE;
          unsigned int intr_flag_14                   : MP2_PIC0_STATUS_3_INTR_FLAG_14_SIZE;
          unsigned int intr_flag_15                   : MP2_PIC0_STATUS_3_INTR_FLAG_15_SIZE;
          unsigned int intr_flag_16                   : MP2_PIC0_STATUS_3_INTR_FLAG_16_SIZE;
          unsigned int intr_flag_17                   : MP2_PIC0_STATUS_3_INTR_FLAG_17_SIZE;
          unsigned int intr_flag_18                   : MP2_PIC0_STATUS_3_INTR_FLAG_18_SIZE;
          unsigned int intr_flag_19                   : MP2_PIC0_STATUS_3_INTR_FLAG_19_SIZE;
          unsigned int intr_flag_20                   : MP2_PIC0_STATUS_3_INTR_FLAG_20_SIZE;
          unsigned int intr_flag_21                   : MP2_PIC0_STATUS_3_INTR_FLAG_21_SIZE;
          unsigned int intr_flag_22                   : MP2_PIC0_STATUS_3_INTR_FLAG_22_SIZE;
          unsigned int intr_flag_23                   : MP2_PIC0_STATUS_3_INTR_FLAG_23_SIZE;
          unsigned int intr_flag_24                   : MP2_PIC0_STATUS_3_INTR_FLAG_24_SIZE;
          unsigned int intr_flag_25                   : MP2_PIC0_STATUS_3_INTR_FLAG_25_SIZE;
          unsigned int intr_flag_26                   : MP2_PIC0_STATUS_3_INTR_FLAG_26_SIZE;
          unsigned int intr_flag_27                   : MP2_PIC0_STATUS_3_INTR_FLAG_27_SIZE;
          unsigned int intr_flag_28                   : MP2_PIC0_STATUS_3_INTR_FLAG_28_SIZE;
          unsigned int intr_flag_29                   : MP2_PIC0_STATUS_3_INTR_FLAG_29_SIZE;
          unsigned int intr_flag_30                   : MP2_PIC0_STATUS_3_INTR_FLAG_30_SIZE;
          unsigned int intr_flag_31                   : MP2_PIC0_STATUS_3_INTR_FLAG_31_SIZE;
     } mp2_pic0_status_3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_status_3_t {
          unsigned int intr_flag_31                   : MP2_PIC0_STATUS_3_INTR_FLAG_31_SIZE;
          unsigned int intr_flag_30                   : MP2_PIC0_STATUS_3_INTR_FLAG_30_SIZE;
          unsigned int intr_flag_29                   : MP2_PIC0_STATUS_3_INTR_FLAG_29_SIZE;
          unsigned int intr_flag_28                   : MP2_PIC0_STATUS_3_INTR_FLAG_28_SIZE;
          unsigned int intr_flag_27                   : MP2_PIC0_STATUS_3_INTR_FLAG_27_SIZE;
          unsigned int intr_flag_26                   : MP2_PIC0_STATUS_3_INTR_FLAG_26_SIZE;
          unsigned int intr_flag_25                   : MP2_PIC0_STATUS_3_INTR_FLAG_25_SIZE;
          unsigned int intr_flag_24                   : MP2_PIC0_STATUS_3_INTR_FLAG_24_SIZE;
          unsigned int intr_flag_23                   : MP2_PIC0_STATUS_3_INTR_FLAG_23_SIZE;
          unsigned int intr_flag_22                   : MP2_PIC0_STATUS_3_INTR_FLAG_22_SIZE;
          unsigned int intr_flag_21                   : MP2_PIC0_STATUS_3_INTR_FLAG_21_SIZE;
          unsigned int intr_flag_20                   : MP2_PIC0_STATUS_3_INTR_FLAG_20_SIZE;
          unsigned int intr_flag_19                   : MP2_PIC0_STATUS_3_INTR_FLAG_19_SIZE;
          unsigned int intr_flag_18                   : MP2_PIC0_STATUS_3_INTR_FLAG_18_SIZE;
          unsigned int intr_flag_17                   : MP2_PIC0_STATUS_3_INTR_FLAG_17_SIZE;
          unsigned int intr_flag_16                   : MP2_PIC0_STATUS_3_INTR_FLAG_16_SIZE;
          unsigned int intr_flag_15                   : MP2_PIC0_STATUS_3_INTR_FLAG_15_SIZE;
          unsigned int intr_flag_14                   : MP2_PIC0_STATUS_3_INTR_FLAG_14_SIZE;
          unsigned int intr_flag_13                   : MP2_PIC0_STATUS_3_INTR_FLAG_13_SIZE;
          unsigned int intr_flag_12                   : MP2_PIC0_STATUS_3_INTR_FLAG_12_SIZE;
          unsigned int intr_flag_11                   : MP2_PIC0_STATUS_3_INTR_FLAG_11_SIZE;
          unsigned int intr_flag_10                   : MP2_PIC0_STATUS_3_INTR_FLAG_10_SIZE;
          unsigned int intr_flag_9                    : MP2_PIC0_STATUS_3_INTR_FLAG_9_SIZE;
          unsigned int intr_flag_8                    : MP2_PIC0_STATUS_3_INTR_FLAG_8_SIZE;
          unsigned int intr_flag_7                    : MP2_PIC0_STATUS_3_INTR_FLAG_7_SIZE;
          unsigned int intr_flag_6                    : MP2_PIC0_STATUS_3_INTR_FLAG_6_SIZE;
          unsigned int intr_flag_5                    : MP2_PIC0_STATUS_3_INTR_FLAG_5_SIZE;
          unsigned int intr_flag_4                    : MP2_PIC0_STATUS_3_INTR_FLAG_4_SIZE;
          unsigned int intr_flag_3                    : MP2_PIC0_STATUS_3_INTR_FLAG_3_SIZE;
          unsigned int intr_flag_2                    : MP2_PIC0_STATUS_3_INTR_FLAG_2_SIZE;
          unsigned int intr_flag_1                    : MP2_PIC0_STATUS_3_INTR_FLAG_1_SIZE;
          unsigned int intr_flag_0                    : MP2_PIC0_STATUS_3_INTR_FLAG_0_SIZE;
     } mp2_pic0_status_3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_status_3_t f;
} mp2_pic0_status_3_u;


/*
 * MP2_PIC0_INTR struct
 */

#define MP2_PIC0_INTR_REG_SIZE         32
#define MP2_PIC0_INTR_INTR_LINE_SIZE   1
#define MP2_PIC0_INTR_RESERVED_SIZE    31

#define MP2_PIC0_INTR_INTR_LINE_SHIFT  0
#define MP2_PIC0_INTR_RESERVED_SHIFT   1

#define MP2_PIC0_INTR_INTR_LINE_MASK   0x1
#define MP2_PIC0_INTR_RESERVED_MASK    0xfffffffe

#define MP2_PIC0_INTR_MASK \
     (MP2_PIC0_INTR_INTR_LINE_MASK | \
      MP2_PIC0_INTR_RESERVED_MASK)

#define MP2_PIC0_INTR_DEFAULT          0x00000001

#define MP2_PIC0_INTR_GET_INTR_LINE(mp2_pic0_intr) \
     ((mp2_pic0_intr & MP2_PIC0_INTR_INTR_LINE_MASK) >> MP2_PIC0_INTR_INTR_LINE_SHIFT)
#define MP2_PIC0_INTR_GET_RESERVED(mp2_pic0_intr) \
     ((mp2_pic0_intr & MP2_PIC0_INTR_RESERVED_MASK) >> MP2_PIC0_INTR_RESERVED_SHIFT)

#define MP2_PIC0_INTR_SET_INTR_LINE(mp2_pic0_intr_reg, intr_line) \
     mp2_pic0_intr_reg = (mp2_pic0_intr_reg & ~MP2_PIC0_INTR_INTR_LINE_MASK) | (intr_line << MP2_PIC0_INTR_INTR_LINE_SHIFT)
#define MP2_PIC0_INTR_SET_RESERVED(mp2_pic0_intr_reg, reserved) \
     mp2_pic0_intr_reg = (mp2_pic0_intr_reg & ~MP2_PIC0_INTR_RESERVED_MASK) | (reserved << MP2_PIC0_INTR_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_intr_t {
          unsigned int intr_line                      : MP2_PIC0_INTR_INTR_LINE_SIZE;
          unsigned int reserved                       : MP2_PIC0_INTR_RESERVED_SIZE;
     } mp2_pic0_intr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_intr_t {
          unsigned int reserved                       : MP2_PIC0_INTR_RESERVED_SIZE;
          unsigned int intr_line                      : MP2_PIC0_INTR_INTR_LINE_SIZE;
     } mp2_pic0_intr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_intr_t f;
} mp2_pic0_intr_u;


/*
 * MP2_PIC0_ID struct
 */

#define MP2_PIC0_ID_REG_SIZE           32
#define MP2_PIC0_ID_INTR_ID_SIZE       8
#define MP2_PIC0_ID_RESERVED_SIZE      24

#define MP2_PIC0_ID_INTR_ID_SHIFT      0
#define MP2_PIC0_ID_RESERVED_SHIFT     8

#define MP2_PIC0_ID_INTR_ID_MASK       0xff
#define MP2_PIC0_ID_RESERVED_MASK      0xffffff00

#define MP2_PIC0_ID_MASK \
     (MP2_PIC0_ID_INTR_ID_MASK | \
      MP2_PIC0_ID_RESERVED_MASK)

#define MP2_PIC0_ID_DEFAULT            0x00000000

#define MP2_PIC0_ID_GET_INTR_ID(mp2_pic0_id) \
     ((mp2_pic0_id & MP2_PIC0_ID_INTR_ID_MASK) >> MP2_PIC0_ID_INTR_ID_SHIFT)
#define MP2_PIC0_ID_GET_RESERVED(mp2_pic0_id) \
     ((mp2_pic0_id & MP2_PIC0_ID_RESERVED_MASK) >> MP2_PIC0_ID_RESERVED_SHIFT)

#define MP2_PIC0_ID_SET_INTR_ID(mp2_pic0_id_reg, intr_id) \
     mp2_pic0_id_reg = (mp2_pic0_id_reg & ~MP2_PIC0_ID_INTR_ID_MASK) | (intr_id << MP2_PIC0_ID_INTR_ID_SHIFT)
#define MP2_PIC0_ID_SET_RESERVED(mp2_pic0_id_reg, reserved) \
     mp2_pic0_id_reg = (mp2_pic0_id_reg & ~MP2_PIC0_ID_RESERVED_MASK) | (reserved << MP2_PIC0_ID_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pic0_id_t {
          unsigned int intr_id                        : MP2_PIC0_ID_INTR_ID_SIZE;
          unsigned int reserved                       : MP2_PIC0_ID_RESERVED_SIZE;
     } mp2_pic0_id_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pic0_id_t {
          unsigned int reserved                       : MP2_PIC0_ID_RESERVED_SIZE;
          unsigned int intr_id                        : MP2_PIC0_ID_INTR_ID_SIZE;
     } mp2_pic0_id_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pic0_id_t f;
} mp2_pic0_id_u;


/*
 * MP2_TIMER_0_CTRL0 struct
 */

#define MP2_TIMER_0_CTRL0_REG_SIZE     32
#define MP2_TIMER_0_CTRL0_START_SIZE   1
#define MP2_TIMER_0_CTRL0_CLEAR_SIZE   1
#define MP2_TIMER_0_CTRL0_DEC_SIZE     1
#define MP2_TIMER_0_CTRL0_PULSE_COUNT_MODE_SIZE 1

#define MP2_TIMER_0_CTRL0_START_SHIFT  0
#define MP2_TIMER_0_CTRL0_CLEAR_SHIFT  8
#define MP2_TIMER_0_CTRL0_DEC_SHIFT    16
#define MP2_TIMER_0_CTRL0_PULSE_COUNT_MODE_SHIFT 24

#define MP2_TIMER_0_CTRL0_START_MASK   0x1
#define MP2_TIMER_0_CTRL0_CLEAR_MASK   0x100
#define MP2_TIMER_0_CTRL0_DEC_MASK     0x10000
#define MP2_TIMER_0_CTRL0_PULSE_COUNT_MODE_MASK 0x1000000

#define MP2_TIMER_0_CTRL0_MASK \
     (MP2_TIMER_0_CTRL0_START_MASK | \
      MP2_TIMER_0_CTRL0_CLEAR_MASK | \
      MP2_TIMER_0_CTRL0_DEC_MASK | \
      MP2_TIMER_0_CTRL0_PULSE_COUNT_MODE_MASK)

#define MP2_TIMER_0_CTRL0_DEFAULT      0x00000000

#define MP2_TIMER_0_CTRL0_GET_START(mp2_timer_0_ctrl0) \
     ((mp2_timer_0_ctrl0 & MP2_TIMER_0_CTRL0_START_MASK) >> MP2_TIMER_0_CTRL0_START_SHIFT)
#define MP2_TIMER_0_CTRL0_GET_CLEAR(mp2_timer_0_ctrl0) \
     ((mp2_timer_0_ctrl0 & MP2_TIMER_0_CTRL0_CLEAR_MASK) >> MP2_TIMER_0_CTRL0_CLEAR_SHIFT)
#define MP2_TIMER_0_CTRL0_GET_DEC(mp2_timer_0_ctrl0) \
     ((mp2_timer_0_ctrl0 & MP2_TIMER_0_CTRL0_DEC_MASK) >> MP2_TIMER_0_CTRL0_DEC_SHIFT)
#define MP2_TIMER_0_CTRL0_GET_PULSE_COUNT_MODE(mp2_timer_0_ctrl0) \
     ((mp2_timer_0_ctrl0 & MP2_TIMER_0_CTRL0_PULSE_COUNT_MODE_MASK) >> MP2_TIMER_0_CTRL0_PULSE_COUNT_MODE_SHIFT)

#define MP2_TIMER_0_CTRL0_SET_START(mp2_timer_0_ctrl0_reg, start) \
     mp2_timer_0_ctrl0_reg = (mp2_timer_0_ctrl0_reg & ~MP2_TIMER_0_CTRL0_START_MASK) | (start << MP2_TIMER_0_CTRL0_START_SHIFT)
#define MP2_TIMER_0_CTRL0_SET_CLEAR(mp2_timer_0_ctrl0_reg, clear) \
     mp2_timer_0_ctrl0_reg = (mp2_timer_0_ctrl0_reg & ~MP2_TIMER_0_CTRL0_CLEAR_MASK) | (clear << MP2_TIMER_0_CTRL0_CLEAR_SHIFT)
#define MP2_TIMER_0_CTRL0_SET_DEC(mp2_timer_0_ctrl0_reg, dec) \
     mp2_timer_0_ctrl0_reg = (mp2_timer_0_ctrl0_reg & ~MP2_TIMER_0_CTRL0_DEC_MASK) | (dec << MP2_TIMER_0_CTRL0_DEC_SHIFT)
#define MP2_TIMER_0_CTRL0_SET_PULSE_COUNT_MODE(mp2_timer_0_ctrl0_reg, pulse_count_mode) \
     mp2_timer_0_ctrl0_reg = (mp2_timer_0_ctrl0_reg & ~MP2_TIMER_0_CTRL0_PULSE_COUNT_MODE_MASK) | (pulse_count_mode << MP2_TIMER_0_CTRL0_PULSE_COUNT_MODE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_0_ctrl0_t {
          unsigned int start                          : MP2_TIMER_0_CTRL0_START_SIZE;
          unsigned int                                : 7;
          unsigned int clear                          : MP2_TIMER_0_CTRL0_CLEAR_SIZE;
          unsigned int                                : 7;
          unsigned int dec                            : MP2_TIMER_0_CTRL0_DEC_SIZE;
          unsigned int                                : 7;
          unsigned int pulse_count_mode               : MP2_TIMER_0_CTRL0_PULSE_COUNT_MODE_SIZE;
          unsigned int                                : 7;
     } mp2_timer_0_ctrl0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_0_ctrl0_t {
          unsigned int                                : 7;
          unsigned int pulse_count_mode               : MP2_TIMER_0_CTRL0_PULSE_COUNT_MODE_SIZE;
          unsigned int                                : 7;
          unsigned int dec                            : MP2_TIMER_0_CTRL0_DEC_SIZE;
          unsigned int                                : 7;
          unsigned int clear                          : MP2_TIMER_0_CTRL0_CLEAR_SIZE;
          unsigned int                                : 7;
          unsigned int start                          : MP2_TIMER_0_CTRL0_START_SIZE;
     } mp2_timer_0_ctrl0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_0_ctrl0_t f;
} mp2_timer_0_ctrl0_u;


/*
 * MP2_TIMER_1_CTRL0 struct
 */

#define MP2_TIMER_1_CTRL0_REG_SIZE     32
#define MP2_TIMER_1_CTRL0_START_SIZE   1
#define MP2_TIMER_1_CTRL0_CLEAR_SIZE   1
#define MP2_TIMER_1_CTRL0_DEC_SIZE     1
#define MP2_TIMER_1_CTRL0_PULSE_COUNT_MODE_SIZE 1

#define MP2_TIMER_1_CTRL0_START_SHIFT  0
#define MP2_TIMER_1_CTRL0_CLEAR_SHIFT  8
#define MP2_TIMER_1_CTRL0_DEC_SHIFT    16
#define MP2_TIMER_1_CTRL0_PULSE_COUNT_MODE_SHIFT 24

#define MP2_TIMER_1_CTRL0_START_MASK   0x1
#define MP2_TIMER_1_CTRL0_CLEAR_MASK   0x100
#define MP2_TIMER_1_CTRL0_DEC_MASK     0x10000
#define MP2_TIMER_1_CTRL0_PULSE_COUNT_MODE_MASK 0x1000000

#define MP2_TIMER_1_CTRL0_MASK \
     (MP2_TIMER_1_CTRL0_START_MASK | \
      MP2_TIMER_1_CTRL0_CLEAR_MASK | \
      MP2_TIMER_1_CTRL0_DEC_MASK | \
      MP2_TIMER_1_CTRL0_PULSE_COUNT_MODE_MASK)

#define MP2_TIMER_1_CTRL0_DEFAULT      0x00000000

#define MP2_TIMER_1_CTRL0_GET_START(mp2_timer_1_ctrl0) \
     ((mp2_timer_1_ctrl0 & MP2_TIMER_1_CTRL0_START_MASK) >> MP2_TIMER_1_CTRL0_START_SHIFT)
#define MP2_TIMER_1_CTRL0_GET_CLEAR(mp2_timer_1_ctrl0) \
     ((mp2_timer_1_ctrl0 & MP2_TIMER_1_CTRL0_CLEAR_MASK) >> MP2_TIMER_1_CTRL0_CLEAR_SHIFT)
#define MP2_TIMER_1_CTRL0_GET_DEC(mp2_timer_1_ctrl0) \
     ((mp2_timer_1_ctrl0 & MP2_TIMER_1_CTRL0_DEC_MASK) >> MP2_TIMER_1_CTRL0_DEC_SHIFT)
#define MP2_TIMER_1_CTRL0_GET_PULSE_COUNT_MODE(mp2_timer_1_ctrl0) \
     ((mp2_timer_1_ctrl0 & MP2_TIMER_1_CTRL0_PULSE_COUNT_MODE_MASK) >> MP2_TIMER_1_CTRL0_PULSE_COUNT_MODE_SHIFT)

#define MP2_TIMER_1_CTRL0_SET_START(mp2_timer_1_ctrl0_reg, start) \
     mp2_timer_1_ctrl0_reg = (mp2_timer_1_ctrl0_reg & ~MP2_TIMER_1_CTRL0_START_MASK) | (start << MP2_TIMER_1_CTRL0_START_SHIFT)
#define MP2_TIMER_1_CTRL0_SET_CLEAR(mp2_timer_1_ctrl0_reg, clear) \
     mp2_timer_1_ctrl0_reg = (mp2_timer_1_ctrl0_reg & ~MP2_TIMER_1_CTRL0_CLEAR_MASK) | (clear << MP2_TIMER_1_CTRL0_CLEAR_SHIFT)
#define MP2_TIMER_1_CTRL0_SET_DEC(mp2_timer_1_ctrl0_reg, dec) \
     mp2_timer_1_ctrl0_reg = (mp2_timer_1_ctrl0_reg & ~MP2_TIMER_1_CTRL0_DEC_MASK) | (dec << MP2_TIMER_1_CTRL0_DEC_SHIFT)
#define MP2_TIMER_1_CTRL0_SET_PULSE_COUNT_MODE(mp2_timer_1_ctrl0_reg, pulse_count_mode) \
     mp2_timer_1_ctrl0_reg = (mp2_timer_1_ctrl0_reg & ~MP2_TIMER_1_CTRL0_PULSE_COUNT_MODE_MASK) | (pulse_count_mode << MP2_TIMER_1_CTRL0_PULSE_COUNT_MODE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_1_ctrl0_t {
          unsigned int start                          : MP2_TIMER_1_CTRL0_START_SIZE;
          unsigned int                                : 7;
          unsigned int clear                          : MP2_TIMER_1_CTRL0_CLEAR_SIZE;
          unsigned int                                : 7;
          unsigned int dec                            : MP2_TIMER_1_CTRL0_DEC_SIZE;
          unsigned int                                : 7;
          unsigned int pulse_count_mode               : MP2_TIMER_1_CTRL0_PULSE_COUNT_MODE_SIZE;
          unsigned int                                : 7;
     } mp2_timer_1_ctrl0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_1_ctrl0_t {
          unsigned int                                : 7;
          unsigned int pulse_count_mode               : MP2_TIMER_1_CTRL0_PULSE_COUNT_MODE_SIZE;
          unsigned int                                : 7;
          unsigned int dec                            : MP2_TIMER_1_CTRL0_DEC_SIZE;
          unsigned int                                : 7;
          unsigned int clear                          : MP2_TIMER_1_CTRL0_CLEAR_SIZE;
          unsigned int                                : 7;
          unsigned int start                          : MP2_TIMER_1_CTRL0_START_SIZE;
     } mp2_timer_1_ctrl0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_1_ctrl0_t f;
} mp2_timer_1_ctrl0_u;


/*
 * MP2_TIMER_2_CTRL0 struct
 */

#define MP2_TIMER_2_CTRL0_REG_SIZE     32
#define MP2_TIMER_2_CTRL0_START_SIZE   1
#define MP2_TIMER_2_CTRL0_CLEAR_SIZE   1
#define MP2_TIMER_2_CTRL0_DEC_SIZE     1
#define MP2_TIMER_2_CTRL0_PULSE_COUNT_MODE_SIZE 1

#define MP2_TIMER_2_CTRL0_START_SHIFT  0
#define MP2_TIMER_2_CTRL0_CLEAR_SHIFT  8
#define MP2_TIMER_2_CTRL0_DEC_SHIFT    16
#define MP2_TIMER_2_CTRL0_PULSE_COUNT_MODE_SHIFT 24

#define MP2_TIMER_2_CTRL0_START_MASK   0x1
#define MP2_TIMER_2_CTRL0_CLEAR_MASK   0x100
#define MP2_TIMER_2_CTRL0_DEC_MASK     0x10000
#define MP2_TIMER_2_CTRL0_PULSE_COUNT_MODE_MASK 0x1000000

#define MP2_TIMER_2_CTRL0_MASK \
     (MP2_TIMER_2_CTRL0_START_MASK | \
      MP2_TIMER_2_CTRL0_CLEAR_MASK | \
      MP2_TIMER_2_CTRL0_DEC_MASK | \
      MP2_TIMER_2_CTRL0_PULSE_COUNT_MODE_MASK)

#define MP2_TIMER_2_CTRL0_DEFAULT      0x00000000

#define MP2_TIMER_2_CTRL0_GET_START(mp2_timer_2_ctrl0) \
     ((mp2_timer_2_ctrl0 & MP2_TIMER_2_CTRL0_START_MASK) >> MP2_TIMER_2_CTRL0_START_SHIFT)
#define MP2_TIMER_2_CTRL0_GET_CLEAR(mp2_timer_2_ctrl0) \
     ((mp2_timer_2_ctrl0 & MP2_TIMER_2_CTRL0_CLEAR_MASK) >> MP2_TIMER_2_CTRL0_CLEAR_SHIFT)
#define MP2_TIMER_2_CTRL0_GET_DEC(mp2_timer_2_ctrl0) \
     ((mp2_timer_2_ctrl0 & MP2_TIMER_2_CTRL0_DEC_MASK) >> MP2_TIMER_2_CTRL0_DEC_SHIFT)
#define MP2_TIMER_2_CTRL0_GET_PULSE_COUNT_MODE(mp2_timer_2_ctrl0) \
     ((mp2_timer_2_ctrl0 & MP2_TIMER_2_CTRL0_PULSE_COUNT_MODE_MASK) >> MP2_TIMER_2_CTRL0_PULSE_COUNT_MODE_SHIFT)

#define MP2_TIMER_2_CTRL0_SET_START(mp2_timer_2_ctrl0_reg, start) \
     mp2_timer_2_ctrl0_reg = (mp2_timer_2_ctrl0_reg & ~MP2_TIMER_2_CTRL0_START_MASK) | (start << MP2_TIMER_2_CTRL0_START_SHIFT)
#define MP2_TIMER_2_CTRL0_SET_CLEAR(mp2_timer_2_ctrl0_reg, clear) \
     mp2_timer_2_ctrl0_reg = (mp2_timer_2_ctrl0_reg & ~MP2_TIMER_2_CTRL0_CLEAR_MASK) | (clear << MP2_TIMER_2_CTRL0_CLEAR_SHIFT)
#define MP2_TIMER_2_CTRL0_SET_DEC(mp2_timer_2_ctrl0_reg, dec) \
     mp2_timer_2_ctrl0_reg = (mp2_timer_2_ctrl0_reg & ~MP2_TIMER_2_CTRL0_DEC_MASK) | (dec << MP2_TIMER_2_CTRL0_DEC_SHIFT)
#define MP2_TIMER_2_CTRL0_SET_PULSE_COUNT_MODE(mp2_timer_2_ctrl0_reg, pulse_count_mode) \
     mp2_timer_2_ctrl0_reg = (mp2_timer_2_ctrl0_reg & ~MP2_TIMER_2_CTRL0_PULSE_COUNT_MODE_MASK) | (pulse_count_mode << MP2_TIMER_2_CTRL0_PULSE_COUNT_MODE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_2_ctrl0_t {
          unsigned int start                          : MP2_TIMER_2_CTRL0_START_SIZE;
          unsigned int                                : 7;
          unsigned int clear                          : MP2_TIMER_2_CTRL0_CLEAR_SIZE;
          unsigned int                                : 7;
          unsigned int dec                            : MP2_TIMER_2_CTRL0_DEC_SIZE;
          unsigned int                                : 7;
          unsigned int pulse_count_mode               : MP2_TIMER_2_CTRL0_PULSE_COUNT_MODE_SIZE;
          unsigned int                                : 7;
     } mp2_timer_2_ctrl0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_2_ctrl0_t {
          unsigned int                                : 7;
          unsigned int pulse_count_mode               : MP2_TIMER_2_CTRL0_PULSE_COUNT_MODE_SIZE;
          unsigned int                                : 7;
          unsigned int dec                            : MP2_TIMER_2_CTRL0_DEC_SIZE;
          unsigned int                                : 7;
          unsigned int clear                          : MP2_TIMER_2_CTRL0_CLEAR_SIZE;
          unsigned int                                : 7;
          unsigned int start                          : MP2_TIMER_2_CTRL0_START_SIZE;
     } mp2_timer_2_ctrl0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_2_ctrl0_t f;
} mp2_timer_2_ctrl0_u;


/*
 * MP2_TIMER_3_CTRL0 struct
 */

#define MP2_TIMER_3_CTRL0_REG_SIZE     32
#define MP2_TIMER_3_CTRL0_START_SIZE   1
#define MP2_TIMER_3_CTRL0_CLEAR_SIZE   1
#define MP2_TIMER_3_CTRL0_DEC_SIZE     1
#define MP2_TIMER_3_CTRL0_PULSE_COUNT_MODE_SIZE 1

#define MP2_TIMER_3_CTRL0_START_SHIFT  0
#define MP2_TIMER_3_CTRL0_CLEAR_SHIFT  8
#define MP2_TIMER_3_CTRL0_DEC_SHIFT    16
#define MP2_TIMER_3_CTRL0_PULSE_COUNT_MODE_SHIFT 24

#define MP2_TIMER_3_CTRL0_START_MASK   0x1
#define MP2_TIMER_3_CTRL0_CLEAR_MASK   0x100
#define MP2_TIMER_3_CTRL0_DEC_MASK     0x10000
#define MP2_TIMER_3_CTRL0_PULSE_COUNT_MODE_MASK 0x1000000

#define MP2_TIMER_3_CTRL0_MASK \
     (MP2_TIMER_3_CTRL0_START_MASK | \
      MP2_TIMER_3_CTRL0_CLEAR_MASK | \
      MP2_TIMER_3_CTRL0_DEC_MASK | \
      MP2_TIMER_3_CTRL0_PULSE_COUNT_MODE_MASK)

#define MP2_TIMER_3_CTRL0_DEFAULT      0x00000000

#define MP2_TIMER_3_CTRL0_GET_START(mp2_timer_3_ctrl0) \
     ((mp2_timer_3_ctrl0 & MP2_TIMER_3_CTRL0_START_MASK) >> MP2_TIMER_3_CTRL0_START_SHIFT)
#define MP2_TIMER_3_CTRL0_GET_CLEAR(mp2_timer_3_ctrl0) \
     ((mp2_timer_3_ctrl0 & MP2_TIMER_3_CTRL0_CLEAR_MASK) >> MP2_TIMER_3_CTRL0_CLEAR_SHIFT)
#define MP2_TIMER_3_CTRL0_GET_DEC(mp2_timer_3_ctrl0) \
     ((mp2_timer_3_ctrl0 & MP2_TIMER_3_CTRL0_DEC_MASK) >> MP2_TIMER_3_CTRL0_DEC_SHIFT)
#define MP2_TIMER_3_CTRL0_GET_PULSE_COUNT_MODE(mp2_timer_3_ctrl0) \
     ((mp2_timer_3_ctrl0 & MP2_TIMER_3_CTRL0_PULSE_COUNT_MODE_MASK) >> MP2_TIMER_3_CTRL0_PULSE_COUNT_MODE_SHIFT)

#define MP2_TIMER_3_CTRL0_SET_START(mp2_timer_3_ctrl0_reg, start) \
     mp2_timer_3_ctrl0_reg = (mp2_timer_3_ctrl0_reg & ~MP2_TIMER_3_CTRL0_START_MASK) | (start << MP2_TIMER_3_CTRL0_START_SHIFT)
#define MP2_TIMER_3_CTRL0_SET_CLEAR(mp2_timer_3_ctrl0_reg, clear) \
     mp2_timer_3_ctrl0_reg = (mp2_timer_3_ctrl0_reg & ~MP2_TIMER_3_CTRL0_CLEAR_MASK) | (clear << MP2_TIMER_3_CTRL0_CLEAR_SHIFT)
#define MP2_TIMER_3_CTRL0_SET_DEC(mp2_timer_3_ctrl0_reg, dec) \
     mp2_timer_3_ctrl0_reg = (mp2_timer_3_ctrl0_reg & ~MP2_TIMER_3_CTRL0_DEC_MASK) | (dec << MP2_TIMER_3_CTRL0_DEC_SHIFT)
#define MP2_TIMER_3_CTRL0_SET_PULSE_COUNT_MODE(mp2_timer_3_ctrl0_reg, pulse_count_mode) \
     mp2_timer_3_ctrl0_reg = (mp2_timer_3_ctrl0_reg & ~MP2_TIMER_3_CTRL0_PULSE_COUNT_MODE_MASK) | (pulse_count_mode << MP2_TIMER_3_CTRL0_PULSE_COUNT_MODE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_3_ctrl0_t {
          unsigned int start                          : MP2_TIMER_3_CTRL0_START_SIZE;
          unsigned int                                : 7;
          unsigned int clear                          : MP2_TIMER_3_CTRL0_CLEAR_SIZE;
          unsigned int                                : 7;
          unsigned int dec                            : MP2_TIMER_3_CTRL0_DEC_SIZE;
          unsigned int                                : 7;
          unsigned int pulse_count_mode               : MP2_TIMER_3_CTRL0_PULSE_COUNT_MODE_SIZE;
          unsigned int                                : 7;
     } mp2_timer_3_ctrl0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_3_ctrl0_t {
          unsigned int                                : 7;
          unsigned int pulse_count_mode               : MP2_TIMER_3_CTRL0_PULSE_COUNT_MODE_SIZE;
          unsigned int                                : 7;
          unsigned int dec                            : MP2_TIMER_3_CTRL0_DEC_SIZE;
          unsigned int                                : 7;
          unsigned int clear                          : MP2_TIMER_3_CTRL0_CLEAR_SIZE;
          unsigned int                                : 7;
          unsigned int start                          : MP2_TIMER_3_CTRL0_START_SIZE;
     } mp2_timer_3_ctrl0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_3_ctrl0_t f;
} mp2_timer_3_ctrl0_u;


/*
 * MP2_TIMER_0_CTRL1 struct
 */

#define MP2_TIMER_0_CTRL1_REG_SIZE     32
#define MP2_TIMER_0_CTRL1_PWM_OUTPUT_EN_SIZE 1
#define MP2_TIMER_0_CTRL1_TIME_SLICE_MODE_EN_SIZE 1
#define MP2_TIMER_0_CTRL1_TIMER_SATURATION_EN_SIZE 1
#define MP2_TIMER_0_CTRL1_RESERVED_SIZE 8

#define MP2_TIMER_0_CTRL1_PWM_OUTPUT_EN_SHIFT 0
#define MP2_TIMER_0_CTRL1_TIME_SLICE_MODE_EN_SHIFT 8
#define MP2_TIMER_0_CTRL1_TIMER_SATURATION_EN_SHIFT 16
#define MP2_TIMER_0_CTRL1_RESERVED_SHIFT 24

#define MP2_TIMER_0_CTRL1_PWM_OUTPUT_EN_MASK 0x1
#define MP2_TIMER_0_CTRL1_TIME_SLICE_MODE_EN_MASK 0x100
#define MP2_TIMER_0_CTRL1_TIMER_SATURATION_EN_MASK 0x10000
#define MP2_TIMER_0_CTRL1_RESERVED_MASK 0xff000000

#define MP2_TIMER_0_CTRL1_MASK \
     (MP2_TIMER_0_CTRL1_PWM_OUTPUT_EN_MASK | \
      MP2_TIMER_0_CTRL1_TIME_SLICE_MODE_EN_MASK | \
      MP2_TIMER_0_CTRL1_TIMER_SATURATION_EN_MASK | \
      MP2_TIMER_0_CTRL1_RESERVED_MASK)

#define MP2_TIMER_0_CTRL1_DEFAULT      0x00000000

#define MP2_TIMER_0_CTRL1_GET_PWM_OUTPUT_EN(mp2_timer_0_ctrl1) \
     ((mp2_timer_0_ctrl1 & MP2_TIMER_0_CTRL1_PWM_OUTPUT_EN_MASK) >> MP2_TIMER_0_CTRL1_PWM_OUTPUT_EN_SHIFT)
#define MP2_TIMER_0_CTRL1_GET_TIME_SLICE_MODE_EN(mp2_timer_0_ctrl1) \
     ((mp2_timer_0_ctrl1 & MP2_TIMER_0_CTRL1_TIME_SLICE_MODE_EN_MASK) >> MP2_TIMER_0_CTRL1_TIME_SLICE_MODE_EN_SHIFT)
#define MP2_TIMER_0_CTRL1_GET_TIMER_SATURATION_EN(mp2_timer_0_ctrl1) \
     ((mp2_timer_0_ctrl1 & MP2_TIMER_0_CTRL1_TIMER_SATURATION_EN_MASK) >> MP2_TIMER_0_CTRL1_TIMER_SATURATION_EN_SHIFT)
#define MP2_TIMER_0_CTRL1_GET_RESERVED(mp2_timer_0_ctrl1) \
     ((mp2_timer_0_ctrl1 & MP2_TIMER_0_CTRL1_RESERVED_MASK) >> MP2_TIMER_0_CTRL1_RESERVED_SHIFT)

#define MP2_TIMER_0_CTRL1_SET_PWM_OUTPUT_EN(mp2_timer_0_ctrl1_reg, pwm_output_en) \
     mp2_timer_0_ctrl1_reg = (mp2_timer_0_ctrl1_reg & ~MP2_TIMER_0_CTRL1_PWM_OUTPUT_EN_MASK) | (pwm_output_en << MP2_TIMER_0_CTRL1_PWM_OUTPUT_EN_SHIFT)
#define MP2_TIMER_0_CTRL1_SET_TIME_SLICE_MODE_EN(mp2_timer_0_ctrl1_reg, time_slice_mode_en) \
     mp2_timer_0_ctrl1_reg = (mp2_timer_0_ctrl1_reg & ~MP2_TIMER_0_CTRL1_TIME_SLICE_MODE_EN_MASK) | (time_slice_mode_en << MP2_TIMER_0_CTRL1_TIME_SLICE_MODE_EN_SHIFT)
#define MP2_TIMER_0_CTRL1_SET_TIMER_SATURATION_EN(mp2_timer_0_ctrl1_reg, timer_saturation_en) \
     mp2_timer_0_ctrl1_reg = (mp2_timer_0_ctrl1_reg & ~MP2_TIMER_0_CTRL1_TIMER_SATURATION_EN_MASK) | (timer_saturation_en << MP2_TIMER_0_CTRL1_TIMER_SATURATION_EN_SHIFT)
#define MP2_TIMER_0_CTRL1_SET_RESERVED(mp2_timer_0_ctrl1_reg, reserved) \
     mp2_timer_0_ctrl1_reg = (mp2_timer_0_ctrl1_reg & ~MP2_TIMER_0_CTRL1_RESERVED_MASK) | (reserved << MP2_TIMER_0_CTRL1_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_0_ctrl1_t {
          unsigned int pwm_output_en                  : MP2_TIMER_0_CTRL1_PWM_OUTPUT_EN_SIZE;
          unsigned int                                : 7;
          unsigned int time_slice_mode_en             : MP2_TIMER_0_CTRL1_TIME_SLICE_MODE_EN_SIZE;
          unsigned int                                : 7;
          unsigned int timer_saturation_en            : MP2_TIMER_0_CTRL1_TIMER_SATURATION_EN_SIZE;
          unsigned int                                : 7;
          unsigned int reserved                       : MP2_TIMER_0_CTRL1_RESERVED_SIZE;
     } mp2_timer_0_ctrl1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_0_ctrl1_t {
          unsigned int reserved                       : MP2_TIMER_0_CTRL1_RESERVED_SIZE;
          unsigned int                                : 7;
          unsigned int timer_saturation_en            : MP2_TIMER_0_CTRL1_TIMER_SATURATION_EN_SIZE;
          unsigned int                                : 7;
          unsigned int time_slice_mode_en             : MP2_TIMER_0_CTRL1_TIME_SLICE_MODE_EN_SIZE;
          unsigned int                                : 7;
          unsigned int pwm_output_en                  : MP2_TIMER_0_CTRL1_PWM_OUTPUT_EN_SIZE;
     } mp2_timer_0_ctrl1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_0_ctrl1_t f;
} mp2_timer_0_ctrl1_u;


/*
 * MP2_TIMER_1_CTRL1 struct
 */

#define MP2_TIMER_1_CTRL1_REG_SIZE     32
#define MP2_TIMER_1_CTRL1_PWM_OUTPUT_EN_SIZE 1
#define MP2_TIMER_1_CTRL1_TIME_SLICE_MODE_EN_SIZE 1
#define MP2_TIMER_1_CTRL1_TIMER_SATURATION_EN_SIZE 1
#define MP2_TIMER_1_CTRL1_RESERVED_SIZE 8

#define MP2_TIMER_1_CTRL1_PWM_OUTPUT_EN_SHIFT 0
#define MP2_TIMER_1_CTRL1_TIME_SLICE_MODE_EN_SHIFT 8
#define MP2_TIMER_1_CTRL1_TIMER_SATURATION_EN_SHIFT 16
#define MP2_TIMER_1_CTRL1_RESERVED_SHIFT 24

#define MP2_TIMER_1_CTRL1_PWM_OUTPUT_EN_MASK 0x1
#define MP2_TIMER_1_CTRL1_TIME_SLICE_MODE_EN_MASK 0x100
#define MP2_TIMER_1_CTRL1_TIMER_SATURATION_EN_MASK 0x10000
#define MP2_TIMER_1_CTRL1_RESERVED_MASK 0xff000000

#define MP2_TIMER_1_CTRL1_MASK \
     (MP2_TIMER_1_CTRL1_PWM_OUTPUT_EN_MASK | \
      MP2_TIMER_1_CTRL1_TIME_SLICE_MODE_EN_MASK | \
      MP2_TIMER_1_CTRL1_TIMER_SATURATION_EN_MASK | \
      MP2_TIMER_1_CTRL1_RESERVED_MASK)

#define MP2_TIMER_1_CTRL1_DEFAULT      0x00000000

#define MP2_TIMER_1_CTRL1_GET_PWM_OUTPUT_EN(mp2_timer_1_ctrl1) \
     ((mp2_timer_1_ctrl1 & MP2_TIMER_1_CTRL1_PWM_OUTPUT_EN_MASK) >> MP2_TIMER_1_CTRL1_PWM_OUTPUT_EN_SHIFT)
#define MP2_TIMER_1_CTRL1_GET_TIME_SLICE_MODE_EN(mp2_timer_1_ctrl1) \
     ((mp2_timer_1_ctrl1 & MP2_TIMER_1_CTRL1_TIME_SLICE_MODE_EN_MASK) >> MP2_TIMER_1_CTRL1_TIME_SLICE_MODE_EN_SHIFT)
#define MP2_TIMER_1_CTRL1_GET_TIMER_SATURATION_EN(mp2_timer_1_ctrl1) \
     ((mp2_timer_1_ctrl1 & MP2_TIMER_1_CTRL1_TIMER_SATURATION_EN_MASK) >> MP2_TIMER_1_CTRL1_TIMER_SATURATION_EN_SHIFT)
#define MP2_TIMER_1_CTRL1_GET_RESERVED(mp2_timer_1_ctrl1) \
     ((mp2_timer_1_ctrl1 & MP2_TIMER_1_CTRL1_RESERVED_MASK) >> MP2_TIMER_1_CTRL1_RESERVED_SHIFT)

#define MP2_TIMER_1_CTRL1_SET_PWM_OUTPUT_EN(mp2_timer_1_ctrl1_reg, pwm_output_en) \
     mp2_timer_1_ctrl1_reg = (mp2_timer_1_ctrl1_reg & ~MP2_TIMER_1_CTRL1_PWM_OUTPUT_EN_MASK) | (pwm_output_en << MP2_TIMER_1_CTRL1_PWM_OUTPUT_EN_SHIFT)
#define MP2_TIMER_1_CTRL1_SET_TIME_SLICE_MODE_EN(mp2_timer_1_ctrl1_reg, time_slice_mode_en) \
     mp2_timer_1_ctrl1_reg = (mp2_timer_1_ctrl1_reg & ~MP2_TIMER_1_CTRL1_TIME_SLICE_MODE_EN_MASK) | (time_slice_mode_en << MP2_TIMER_1_CTRL1_TIME_SLICE_MODE_EN_SHIFT)
#define MP2_TIMER_1_CTRL1_SET_TIMER_SATURATION_EN(mp2_timer_1_ctrl1_reg, timer_saturation_en) \
     mp2_timer_1_ctrl1_reg = (mp2_timer_1_ctrl1_reg & ~MP2_TIMER_1_CTRL1_TIMER_SATURATION_EN_MASK) | (timer_saturation_en << MP2_TIMER_1_CTRL1_TIMER_SATURATION_EN_SHIFT)
#define MP2_TIMER_1_CTRL1_SET_RESERVED(mp2_timer_1_ctrl1_reg, reserved) \
     mp2_timer_1_ctrl1_reg = (mp2_timer_1_ctrl1_reg & ~MP2_TIMER_1_CTRL1_RESERVED_MASK) | (reserved << MP2_TIMER_1_CTRL1_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_1_ctrl1_t {
          unsigned int pwm_output_en                  : MP2_TIMER_1_CTRL1_PWM_OUTPUT_EN_SIZE;
          unsigned int                                : 7;
          unsigned int time_slice_mode_en             : MP2_TIMER_1_CTRL1_TIME_SLICE_MODE_EN_SIZE;
          unsigned int                                : 7;
          unsigned int timer_saturation_en            : MP2_TIMER_1_CTRL1_TIMER_SATURATION_EN_SIZE;
          unsigned int                                : 7;
          unsigned int reserved                       : MP2_TIMER_1_CTRL1_RESERVED_SIZE;
     } mp2_timer_1_ctrl1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_1_ctrl1_t {
          unsigned int reserved                       : MP2_TIMER_1_CTRL1_RESERVED_SIZE;
          unsigned int                                : 7;
          unsigned int timer_saturation_en            : MP2_TIMER_1_CTRL1_TIMER_SATURATION_EN_SIZE;
          unsigned int                                : 7;
          unsigned int time_slice_mode_en             : MP2_TIMER_1_CTRL1_TIME_SLICE_MODE_EN_SIZE;
          unsigned int                                : 7;
          unsigned int pwm_output_en                  : MP2_TIMER_1_CTRL1_PWM_OUTPUT_EN_SIZE;
     } mp2_timer_1_ctrl1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_1_ctrl1_t f;
} mp2_timer_1_ctrl1_u;


/*
 * MP2_TIMER_2_CTRL1 struct
 */

#define MP2_TIMER_2_CTRL1_REG_SIZE     32
#define MP2_TIMER_2_CTRL1_PWM_OUTPUT_EN_SIZE 1
#define MP2_TIMER_2_CTRL1_TIME_SLICE_MODE_EN_SIZE 1
#define MP2_TIMER_2_CTRL1_TIMER_SATURATION_EN_SIZE 1
#define MP2_TIMER_2_CTRL1_RESERVED_SIZE 8

#define MP2_TIMER_2_CTRL1_PWM_OUTPUT_EN_SHIFT 0
#define MP2_TIMER_2_CTRL1_TIME_SLICE_MODE_EN_SHIFT 8
#define MP2_TIMER_2_CTRL1_TIMER_SATURATION_EN_SHIFT 16
#define MP2_TIMER_2_CTRL1_RESERVED_SHIFT 24

#define MP2_TIMER_2_CTRL1_PWM_OUTPUT_EN_MASK 0x1
#define MP2_TIMER_2_CTRL1_TIME_SLICE_MODE_EN_MASK 0x100
#define MP2_TIMER_2_CTRL1_TIMER_SATURATION_EN_MASK 0x10000
#define MP2_TIMER_2_CTRL1_RESERVED_MASK 0xff000000

#define MP2_TIMER_2_CTRL1_MASK \
     (MP2_TIMER_2_CTRL1_PWM_OUTPUT_EN_MASK | \
      MP2_TIMER_2_CTRL1_TIME_SLICE_MODE_EN_MASK | \
      MP2_TIMER_2_CTRL1_TIMER_SATURATION_EN_MASK | \
      MP2_TIMER_2_CTRL1_RESERVED_MASK)

#define MP2_TIMER_2_CTRL1_DEFAULT      0x00000000

#define MP2_TIMER_2_CTRL1_GET_PWM_OUTPUT_EN(mp2_timer_2_ctrl1) \
     ((mp2_timer_2_ctrl1 & MP2_TIMER_2_CTRL1_PWM_OUTPUT_EN_MASK) >> MP2_TIMER_2_CTRL1_PWM_OUTPUT_EN_SHIFT)
#define MP2_TIMER_2_CTRL1_GET_TIME_SLICE_MODE_EN(mp2_timer_2_ctrl1) \
     ((mp2_timer_2_ctrl1 & MP2_TIMER_2_CTRL1_TIME_SLICE_MODE_EN_MASK) >> MP2_TIMER_2_CTRL1_TIME_SLICE_MODE_EN_SHIFT)
#define MP2_TIMER_2_CTRL1_GET_TIMER_SATURATION_EN(mp2_timer_2_ctrl1) \
     ((mp2_timer_2_ctrl1 & MP2_TIMER_2_CTRL1_TIMER_SATURATION_EN_MASK) >> MP2_TIMER_2_CTRL1_TIMER_SATURATION_EN_SHIFT)
#define MP2_TIMER_2_CTRL1_GET_RESERVED(mp2_timer_2_ctrl1) \
     ((mp2_timer_2_ctrl1 & MP2_TIMER_2_CTRL1_RESERVED_MASK) >> MP2_TIMER_2_CTRL1_RESERVED_SHIFT)

#define MP2_TIMER_2_CTRL1_SET_PWM_OUTPUT_EN(mp2_timer_2_ctrl1_reg, pwm_output_en) \
     mp2_timer_2_ctrl1_reg = (mp2_timer_2_ctrl1_reg & ~MP2_TIMER_2_CTRL1_PWM_OUTPUT_EN_MASK) | (pwm_output_en << MP2_TIMER_2_CTRL1_PWM_OUTPUT_EN_SHIFT)
#define MP2_TIMER_2_CTRL1_SET_TIME_SLICE_MODE_EN(mp2_timer_2_ctrl1_reg, time_slice_mode_en) \
     mp2_timer_2_ctrl1_reg = (mp2_timer_2_ctrl1_reg & ~MP2_TIMER_2_CTRL1_TIME_SLICE_MODE_EN_MASK) | (time_slice_mode_en << MP2_TIMER_2_CTRL1_TIME_SLICE_MODE_EN_SHIFT)
#define MP2_TIMER_2_CTRL1_SET_TIMER_SATURATION_EN(mp2_timer_2_ctrl1_reg, timer_saturation_en) \
     mp2_timer_2_ctrl1_reg = (mp2_timer_2_ctrl1_reg & ~MP2_TIMER_2_CTRL1_TIMER_SATURATION_EN_MASK) | (timer_saturation_en << MP2_TIMER_2_CTRL1_TIMER_SATURATION_EN_SHIFT)
#define MP2_TIMER_2_CTRL1_SET_RESERVED(mp2_timer_2_ctrl1_reg, reserved) \
     mp2_timer_2_ctrl1_reg = (mp2_timer_2_ctrl1_reg & ~MP2_TIMER_2_CTRL1_RESERVED_MASK) | (reserved << MP2_TIMER_2_CTRL1_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_2_ctrl1_t {
          unsigned int pwm_output_en                  : MP2_TIMER_2_CTRL1_PWM_OUTPUT_EN_SIZE;
          unsigned int                                : 7;
          unsigned int time_slice_mode_en             : MP2_TIMER_2_CTRL1_TIME_SLICE_MODE_EN_SIZE;
          unsigned int                                : 7;
          unsigned int timer_saturation_en            : MP2_TIMER_2_CTRL1_TIMER_SATURATION_EN_SIZE;
          unsigned int                                : 7;
          unsigned int reserved                       : MP2_TIMER_2_CTRL1_RESERVED_SIZE;
     } mp2_timer_2_ctrl1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_2_ctrl1_t {
          unsigned int reserved                       : MP2_TIMER_2_CTRL1_RESERVED_SIZE;
          unsigned int                                : 7;
          unsigned int timer_saturation_en            : MP2_TIMER_2_CTRL1_TIMER_SATURATION_EN_SIZE;
          unsigned int                                : 7;
          unsigned int time_slice_mode_en             : MP2_TIMER_2_CTRL1_TIME_SLICE_MODE_EN_SIZE;
          unsigned int                                : 7;
          unsigned int pwm_output_en                  : MP2_TIMER_2_CTRL1_PWM_OUTPUT_EN_SIZE;
     } mp2_timer_2_ctrl1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_2_ctrl1_t f;
} mp2_timer_2_ctrl1_u;


/*
 * MP2_TIMER_3_CTRL1 struct
 */

#define MP2_TIMER_3_CTRL1_REG_SIZE     32
#define MP2_TIMER_3_CTRL1_PWM_OUTPUT_EN_SIZE 1
#define MP2_TIMER_3_CTRL1_TIME_SLICE_MODE_EN_SIZE 1
#define MP2_TIMER_3_CTRL1_TIMER_SATURATION_EN_SIZE 1
#define MP2_TIMER_3_CTRL1_RESERVED_SIZE 8

#define MP2_TIMER_3_CTRL1_PWM_OUTPUT_EN_SHIFT 0
#define MP2_TIMER_3_CTRL1_TIME_SLICE_MODE_EN_SHIFT 8
#define MP2_TIMER_3_CTRL1_TIMER_SATURATION_EN_SHIFT 16
#define MP2_TIMER_3_CTRL1_RESERVED_SHIFT 24

#define MP2_TIMER_3_CTRL1_PWM_OUTPUT_EN_MASK 0x1
#define MP2_TIMER_3_CTRL1_TIME_SLICE_MODE_EN_MASK 0x100
#define MP2_TIMER_3_CTRL1_TIMER_SATURATION_EN_MASK 0x10000
#define MP2_TIMER_3_CTRL1_RESERVED_MASK 0xff000000

#define MP2_TIMER_3_CTRL1_MASK \
     (MP2_TIMER_3_CTRL1_PWM_OUTPUT_EN_MASK | \
      MP2_TIMER_3_CTRL1_TIME_SLICE_MODE_EN_MASK | \
      MP2_TIMER_3_CTRL1_TIMER_SATURATION_EN_MASK | \
      MP2_TIMER_3_CTRL1_RESERVED_MASK)

#define MP2_TIMER_3_CTRL1_DEFAULT      0x00000000

#define MP2_TIMER_3_CTRL1_GET_PWM_OUTPUT_EN(mp2_timer_3_ctrl1) \
     ((mp2_timer_3_ctrl1 & MP2_TIMER_3_CTRL1_PWM_OUTPUT_EN_MASK) >> MP2_TIMER_3_CTRL1_PWM_OUTPUT_EN_SHIFT)
#define MP2_TIMER_3_CTRL1_GET_TIME_SLICE_MODE_EN(mp2_timer_3_ctrl1) \
     ((mp2_timer_3_ctrl1 & MP2_TIMER_3_CTRL1_TIME_SLICE_MODE_EN_MASK) >> MP2_TIMER_3_CTRL1_TIME_SLICE_MODE_EN_SHIFT)
#define MP2_TIMER_3_CTRL1_GET_TIMER_SATURATION_EN(mp2_timer_3_ctrl1) \
     ((mp2_timer_3_ctrl1 & MP2_TIMER_3_CTRL1_TIMER_SATURATION_EN_MASK) >> MP2_TIMER_3_CTRL1_TIMER_SATURATION_EN_SHIFT)
#define MP2_TIMER_3_CTRL1_GET_RESERVED(mp2_timer_3_ctrl1) \
     ((mp2_timer_3_ctrl1 & MP2_TIMER_3_CTRL1_RESERVED_MASK) >> MP2_TIMER_3_CTRL1_RESERVED_SHIFT)

#define MP2_TIMER_3_CTRL1_SET_PWM_OUTPUT_EN(mp2_timer_3_ctrl1_reg, pwm_output_en) \
     mp2_timer_3_ctrl1_reg = (mp2_timer_3_ctrl1_reg & ~MP2_TIMER_3_CTRL1_PWM_OUTPUT_EN_MASK) | (pwm_output_en << MP2_TIMER_3_CTRL1_PWM_OUTPUT_EN_SHIFT)
#define MP2_TIMER_3_CTRL1_SET_TIME_SLICE_MODE_EN(mp2_timer_3_ctrl1_reg, time_slice_mode_en) \
     mp2_timer_3_ctrl1_reg = (mp2_timer_3_ctrl1_reg & ~MP2_TIMER_3_CTRL1_TIME_SLICE_MODE_EN_MASK) | (time_slice_mode_en << MP2_TIMER_3_CTRL1_TIME_SLICE_MODE_EN_SHIFT)
#define MP2_TIMER_3_CTRL1_SET_TIMER_SATURATION_EN(mp2_timer_3_ctrl1_reg, timer_saturation_en) \
     mp2_timer_3_ctrl1_reg = (mp2_timer_3_ctrl1_reg & ~MP2_TIMER_3_CTRL1_TIMER_SATURATION_EN_MASK) | (timer_saturation_en << MP2_TIMER_3_CTRL1_TIMER_SATURATION_EN_SHIFT)
#define MP2_TIMER_3_CTRL1_SET_RESERVED(mp2_timer_3_ctrl1_reg, reserved) \
     mp2_timer_3_ctrl1_reg = (mp2_timer_3_ctrl1_reg & ~MP2_TIMER_3_CTRL1_RESERVED_MASK) | (reserved << MP2_TIMER_3_CTRL1_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_3_ctrl1_t {
          unsigned int pwm_output_en                  : MP2_TIMER_3_CTRL1_PWM_OUTPUT_EN_SIZE;
          unsigned int                                : 7;
          unsigned int time_slice_mode_en             : MP2_TIMER_3_CTRL1_TIME_SLICE_MODE_EN_SIZE;
          unsigned int                                : 7;
          unsigned int timer_saturation_en            : MP2_TIMER_3_CTRL1_TIMER_SATURATION_EN_SIZE;
          unsigned int                                : 7;
          unsigned int reserved                       : MP2_TIMER_3_CTRL1_RESERVED_SIZE;
     } mp2_timer_3_ctrl1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_3_ctrl1_t {
          unsigned int reserved                       : MP2_TIMER_3_CTRL1_RESERVED_SIZE;
          unsigned int                                : 7;
          unsigned int timer_saturation_en            : MP2_TIMER_3_CTRL1_TIMER_SATURATION_EN_SIZE;
          unsigned int                                : 7;
          unsigned int time_slice_mode_en             : MP2_TIMER_3_CTRL1_TIME_SLICE_MODE_EN_SIZE;
          unsigned int                                : 7;
          unsigned int pwm_output_en                  : MP2_TIMER_3_CTRL1_PWM_OUTPUT_EN_SIZE;
     } mp2_timer_3_ctrl1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_3_ctrl1_t f;
} mp2_timer_3_ctrl1_u;


/*
 * MP2_TIMER_0_CMP_AUTOINC struct
 */

#define MP2_TIMER_0_CMP_AUTOINC_REG_SIZE 32
#define MP2_TIMER_0_CMP_AUTOINC_AUTOINC_SIZE 4
#define MP2_TIMER_0_CMP_AUTOINC_RESERVED_SIZE 28

#define MP2_TIMER_0_CMP_AUTOINC_AUTOINC_SHIFT 0
#define MP2_TIMER_0_CMP_AUTOINC_RESERVED_SHIFT 4

#define MP2_TIMER_0_CMP_AUTOINC_AUTOINC_MASK 0xf
#define MP2_TIMER_0_CMP_AUTOINC_RESERVED_MASK 0xfffffff0

#define MP2_TIMER_0_CMP_AUTOINC_MASK \
     (MP2_TIMER_0_CMP_AUTOINC_AUTOINC_MASK | \
      MP2_TIMER_0_CMP_AUTOINC_RESERVED_MASK)

#define MP2_TIMER_0_CMP_AUTOINC_DEFAULT 0x00000000

#define MP2_TIMER_0_CMP_AUTOINC_GET_AUTOINC(mp2_timer_0_cmp_autoinc) \
     ((mp2_timer_0_cmp_autoinc & MP2_TIMER_0_CMP_AUTOINC_AUTOINC_MASK) >> MP2_TIMER_0_CMP_AUTOINC_AUTOINC_SHIFT)
#define MP2_TIMER_0_CMP_AUTOINC_GET_RESERVED(mp2_timer_0_cmp_autoinc) \
     ((mp2_timer_0_cmp_autoinc & MP2_TIMER_0_CMP_AUTOINC_RESERVED_MASK) >> MP2_TIMER_0_CMP_AUTOINC_RESERVED_SHIFT)

#define MP2_TIMER_0_CMP_AUTOINC_SET_AUTOINC(mp2_timer_0_cmp_autoinc_reg, autoinc) \
     mp2_timer_0_cmp_autoinc_reg = (mp2_timer_0_cmp_autoinc_reg & ~MP2_TIMER_0_CMP_AUTOINC_AUTOINC_MASK) | (autoinc << MP2_TIMER_0_CMP_AUTOINC_AUTOINC_SHIFT)
#define MP2_TIMER_0_CMP_AUTOINC_SET_RESERVED(mp2_timer_0_cmp_autoinc_reg, reserved) \
     mp2_timer_0_cmp_autoinc_reg = (mp2_timer_0_cmp_autoinc_reg & ~MP2_TIMER_0_CMP_AUTOINC_RESERVED_MASK) | (reserved << MP2_TIMER_0_CMP_AUTOINC_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_0_cmp_autoinc_t {
          unsigned int autoinc                        : MP2_TIMER_0_CMP_AUTOINC_AUTOINC_SIZE;
          unsigned int reserved                       : MP2_TIMER_0_CMP_AUTOINC_RESERVED_SIZE;
     } mp2_timer_0_cmp_autoinc_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_0_cmp_autoinc_t {
          unsigned int reserved                       : MP2_TIMER_0_CMP_AUTOINC_RESERVED_SIZE;
          unsigned int autoinc                        : MP2_TIMER_0_CMP_AUTOINC_AUTOINC_SIZE;
     } mp2_timer_0_cmp_autoinc_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_0_cmp_autoinc_t f;
} mp2_timer_0_cmp_autoinc_u;


/*
 * MP2_TIMER_1_CMP_AUTOINC struct
 */

#define MP2_TIMER_1_CMP_AUTOINC_REG_SIZE 32
#define MP2_TIMER_1_CMP_AUTOINC_AUTOINC_SIZE 4
#define MP2_TIMER_1_CMP_AUTOINC_RESERVED_SIZE 28

#define MP2_TIMER_1_CMP_AUTOINC_AUTOINC_SHIFT 0
#define MP2_TIMER_1_CMP_AUTOINC_RESERVED_SHIFT 4

#define MP2_TIMER_1_CMP_AUTOINC_AUTOINC_MASK 0xf
#define MP2_TIMER_1_CMP_AUTOINC_RESERVED_MASK 0xfffffff0

#define MP2_TIMER_1_CMP_AUTOINC_MASK \
     (MP2_TIMER_1_CMP_AUTOINC_AUTOINC_MASK | \
      MP2_TIMER_1_CMP_AUTOINC_RESERVED_MASK)

#define MP2_TIMER_1_CMP_AUTOINC_DEFAULT 0x00000000

#define MP2_TIMER_1_CMP_AUTOINC_GET_AUTOINC(mp2_timer_1_cmp_autoinc) \
     ((mp2_timer_1_cmp_autoinc & MP2_TIMER_1_CMP_AUTOINC_AUTOINC_MASK) >> MP2_TIMER_1_CMP_AUTOINC_AUTOINC_SHIFT)
#define MP2_TIMER_1_CMP_AUTOINC_GET_RESERVED(mp2_timer_1_cmp_autoinc) \
     ((mp2_timer_1_cmp_autoinc & MP2_TIMER_1_CMP_AUTOINC_RESERVED_MASK) >> MP2_TIMER_1_CMP_AUTOINC_RESERVED_SHIFT)

#define MP2_TIMER_1_CMP_AUTOINC_SET_AUTOINC(mp2_timer_1_cmp_autoinc_reg, autoinc) \
     mp2_timer_1_cmp_autoinc_reg = (mp2_timer_1_cmp_autoinc_reg & ~MP2_TIMER_1_CMP_AUTOINC_AUTOINC_MASK) | (autoinc << MP2_TIMER_1_CMP_AUTOINC_AUTOINC_SHIFT)
#define MP2_TIMER_1_CMP_AUTOINC_SET_RESERVED(mp2_timer_1_cmp_autoinc_reg, reserved) \
     mp2_timer_1_cmp_autoinc_reg = (mp2_timer_1_cmp_autoinc_reg & ~MP2_TIMER_1_CMP_AUTOINC_RESERVED_MASK) | (reserved << MP2_TIMER_1_CMP_AUTOINC_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_1_cmp_autoinc_t {
          unsigned int autoinc                        : MP2_TIMER_1_CMP_AUTOINC_AUTOINC_SIZE;
          unsigned int reserved                       : MP2_TIMER_1_CMP_AUTOINC_RESERVED_SIZE;
     } mp2_timer_1_cmp_autoinc_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_1_cmp_autoinc_t {
          unsigned int reserved                       : MP2_TIMER_1_CMP_AUTOINC_RESERVED_SIZE;
          unsigned int autoinc                        : MP2_TIMER_1_CMP_AUTOINC_AUTOINC_SIZE;
     } mp2_timer_1_cmp_autoinc_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_1_cmp_autoinc_t f;
} mp2_timer_1_cmp_autoinc_u;


/*
 * MP2_TIMER_2_CMP_AUTOINC struct
 */

#define MP2_TIMER_2_CMP_AUTOINC_REG_SIZE 32
#define MP2_TIMER_2_CMP_AUTOINC_AUTOINC_SIZE 4
#define MP2_TIMER_2_CMP_AUTOINC_RESERVED_SIZE 28

#define MP2_TIMER_2_CMP_AUTOINC_AUTOINC_SHIFT 0
#define MP2_TIMER_2_CMP_AUTOINC_RESERVED_SHIFT 4

#define MP2_TIMER_2_CMP_AUTOINC_AUTOINC_MASK 0xf
#define MP2_TIMER_2_CMP_AUTOINC_RESERVED_MASK 0xfffffff0

#define MP2_TIMER_2_CMP_AUTOINC_MASK \
     (MP2_TIMER_2_CMP_AUTOINC_AUTOINC_MASK | \
      MP2_TIMER_2_CMP_AUTOINC_RESERVED_MASK)

#define MP2_TIMER_2_CMP_AUTOINC_DEFAULT 0x00000000

#define MP2_TIMER_2_CMP_AUTOINC_GET_AUTOINC(mp2_timer_2_cmp_autoinc) \
     ((mp2_timer_2_cmp_autoinc & MP2_TIMER_2_CMP_AUTOINC_AUTOINC_MASK) >> MP2_TIMER_2_CMP_AUTOINC_AUTOINC_SHIFT)
#define MP2_TIMER_2_CMP_AUTOINC_GET_RESERVED(mp2_timer_2_cmp_autoinc) \
     ((mp2_timer_2_cmp_autoinc & MP2_TIMER_2_CMP_AUTOINC_RESERVED_MASK) >> MP2_TIMER_2_CMP_AUTOINC_RESERVED_SHIFT)

#define MP2_TIMER_2_CMP_AUTOINC_SET_AUTOINC(mp2_timer_2_cmp_autoinc_reg, autoinc) \
     mp2_timer_2_cmp_autoinc_reg = (mp2_timer_2_cmp_autoinc_reg & ~MP2_TIMER_2_CMP_AUTOINC_AUTOINC_MASK) | (autoinc << MP2_TIMER_2_CMP_AUTOINC_AUTOINC_SHIFT)
#define MP2_TIMER_2_CMP_AUTOINC_SET_RESERVED(mp2_timer_2_cmp_autoinc_reg, reserved) \
     mp2_timer_2_cmp_autoinc_reg = (mp2_timer_2_cmp_autoinc_reg & ~MP2_TIMER_2_CMP_AUTOINC_RESERVED_MASK) | (reserved << MP2_TIMER_2_CMP_AUTOINC_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_2_cmp_autoinc_t {
          unsigned int autoinc                        : MP2_TIMER_2_CMP_AUTOINC_AUTOINC_SIZE;
          unsigned int reserved                       : MP2_TIMER_2_CMP_AUTOINC_RESERVED_SIZE;
     } mp2_timer_2_cmp_autoinc_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_2_cmp_autoinc_t {
          unsigned int reserved                       : MP2_TIMER_2_CMP_AUTOINC_RESERVED_SIZE;
          unsigned int autoinc                        : MP2_TIMER_2_CMP_AUTOINC_AUTOINC_SIZE;
     } mp2_timer_2_cmp_autoinc_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_2_cmp_autoinc_t f;
} mp2_timer_2_cmp_autoinc_u;


/*
 * MP2_TIMER_3_CMP_AUTOINC struct
 */

#define MP2_TIMER_3_CMP_AUTOINC_REG_SIZE 32
#define MP2_TIMER_3_CMP_AUTOINC_AUTOINC_SIZE 4
#define MP2_TIMER_3_CMP_AUTOINC_RESERVED_SIZE 28

#define MP2_TIMER_3_CMP_AUTOINC_AUTOINC_SHIFT 0
#define MP2_TIMER_3_CMP_AUTOINC_RESERVED_SHIFT 4

#define MP2_TIMER_3_CMP_AUTOINC_AUTOINC_MASK 0xf
#define MP2_TIMER_3_CMP_AUTOINC_RESERVED_MASK 0xfffffff0

#define MP2_TIMER_3_CMP_AUTOINC_MASK \
     (MP2_TIMER_3_CMP_AUTOINC_AUTOINC_MASK | \
      MP2_TIMER_3_CMP_AUTOINC_RESERVED_MASK)

#define MP2_TIMER_3_CMP_AUTOINC_DEFAULT 0x00000000

#define MP2_TIMER_3_CMP_AUTOINC_GET_AUTOINC(mp2_timer_3_cmp_autoinc) \
     ((mp2_timer_3_cmp_autoinc & MP2_TIMER_3_CMP_AUTOINC_AUTOINC_MASK) >> MP2_TIMER_3_CMP_AUTOINC_AUTOINC_SHIFT)
#define MP2_TIMER_3_CMP_AUTOINC_GET_RESERVED(mp2_timer_3_cmp_autoinc) \
     ((mp2_timer_3_cmp_autoinc & MP2_TIMER_3_CMP_AUTOINC_RESERVED_MASK) >> MP2_TIMER_3_CMP_AUTOINC_RESERVED_SHIFT)

#define MP2_TIMER_3_CMP_AUTOINC_SET_AUTOINC(mp2_timer_3_cmp_autoinc_reg, autoinc) \
     mp2_timer_3_cmp_autoinc_reg = (mp2_timer_3_cmp_autoinc_reg & ~MP2_TIMER_3_CMP_AUTOINC_AUTOINC_MASK) | (autoinc << MP2_TIMER_3_CMP_AUTOINC_AUTOINC_SHIFT)
#define MP2_TIMER_3_CMP_AUTOINC_SET_RESERVED(mp2_timer_3_cmp_autoinc_reg, reserved) \
     mp2_timer_3_cmp_autoinc_reg = (mp2_timer_3_cmp_autoinc_reg & ~MP2_TIMER_3_CMP_AUTOINC_RESERVED_MASK) | (reserved << MP2_TIMER_3_CMP_AUTOINC_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_3_cmp_autoinc_t {
          unsigned int autoinc                        : MP2_TIMER_3_CMP_AUTOINC_AUTOINC_SIZE;
          unsigned int reserved                       : MP2_TIMER_3_CMP_AUTOINC_RESERVED_SIZE;
     } mp2_timer_3_cmp_autoinc_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_3_cmp_autoinc_t {
          unsigned int reserved                       : MP2_TIMER_3_CMP_AUTOINC_RESERVED_SIZE;
          unsigned int autoinc                        : MP2_TIMER_3_CMP_AUTOINC_AUTOINC_SIZE;
     } mp2_timer_3_cmp_autoinc_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_3_cmp_autoinc_t f;
} mp2_timer_3_cmp_autoinc_u;


/*
 * MP2_TIMER_0_INTEN struct
 */

#define MP2_TIMER_0_INTEN_REG_SIZE     32
#define MP2_TIMER_0_INTEN_INTEN_SIZE   4
#define MP2_TIMER_0_INTEN_RESERVED_SIZE 28

#define MP2_TIMER_0_INTEN_INTEN_SHIFT  0
#define MP2_TIMER_0_INTEN_RESERVED_SHIFT 4

#define MP2_TIMER_0_INTEN_INTEN_MASK   0xf
#define MP2_TIMER_0_INTEN_RESERVED_MASK 0xfffffff0

#define MP2_TIMER_0_INTEN_MASK \
     (MP2_TIMER_0_INTEN_INTEN_MASK | \
      MP2_TIMER_0_INTEN_RESERVED_MASK)

#define MP2_TIMER_0_INTEN_DEFAULT      0x00000000

#define MP2_TIMER_0_INTEN_GET_INTEN(mp2_timer_0_inten) \
     ((mp2_timer_0_inten & MP2_TIMER_0_INTEN_INTEN_MASK) >> MP2_TIMER_0_INTEN_INTEN_SHIFT)
#define MP2_TIMER_0_INTEN_GET_RESERVED(mp2_timer_0_inten) \
     ((mp2_timer_0_inten & MP2_TIMER_0_INTEN_RESERVED_MASK) >> MP2_TIMER_0_INTEN_RESERVED_SHIFT)

#define MP2_TIMER_0_INTEN_SET_INTEN(mp2_timer_0_inten_reg, inten) \
     mp2_timer_0_inten_reg = (mp2_timer_0_inten_reg & ~MP2_TIMER_0_INTEN_INTEN_MASK) | (inten << MP2_TIMER_0_INTEN_INTEN_SHIFT)
#define MP2_TIMER_0_INTEN_SET_RESERVED(mp2_timer_0_inten_reg, reserved) \
     mp2_timer_0_inten_reg = (mp2_timer_0_inten_reg & ~MP2_TIMER_0_INTEN_RESERVED_MASK) | (reserved << MP2_TIMER_0_INTEN_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_0_inten_t {
          unsigned int inten                          : MP2_TIMER_0_INTEN_INTEN_SIZE;
          unsigned int reserved                       : MP2_TIMER_0_INTEN_RESERVED_SIZE;
     } mp2_timer_0_inten_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_0_inten_t {
          unsigned int reserved                       : MP2_TIMER_0_INTEN_RESERVED_SIZE;
          unsigned int inten                          : MP2_TIMER_0_INTEN_INTEN_SIZE;
     } mp2_timer_0_inten_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_0_inten_t f;
} mp2_timer_0_inten_u;


/*
 * MP2_TIMER_1_INTEN struct
 */

#define MP2_TIMER_1_INTEN_REG_SIZE     32
#define MP2_TIMER_1_INTEN_INTEN_SIZE   4
#define MP2_TIMER_1_INTEN_RESERVED_SIZE 28

#define MP2_TIMER_1_INTEN_INTEN_SHIFT  0
#define MP2_TIMER_1_INTEN_RESERVED_SHIFT 4

#define MP2_TIMER_1_INTEN_INTEN_MASK   0xf
#define MP2_TIMER_1_INTEN_RESERVED_MASK 0xfffffff0

#define MP2_TIMER_1_INTEN_MASK \
     (MP2_TIMER_1_INTEN_INTEN_MASK | \
      MP2_TIMER_1_INTEN_RESERVED_MASK)

#define MP2_TIMER_1_INTEN_DEFAULT      0x00000000

#define MP2_TIMER_1_INTEN_GET_INTEN(mp2_timer_1_inten) \
     ((mp2_timer_1_inten & MP2_TIMER_1_INTEN_INTEN_MASK) >> MP2_TIMER_1_INTEN_INTEN_SHIFT)
#define MP2_TIMER_1_INTEN_GET_RESERVED(mp2_timer_1_inten) \
     ((mp2_timer_1_inten & MP2_TIMER_1_INTEN_RESERVED_MASK) >> MP2_TIMER_1_INTEN_RESERVED_SHIFT)

#define MP2_TIMER_1_INTEN_SET_INTEN(mp2_timer_1_inten_reg, inten) \
     mp2_timer_1_inten_reg = (mp2_timer_1_inten_reg & ~MP2_TIMER_1_INTEN_INTEN_MASK) | (inten << MP2_TIMER_1_INTEN_INTEN_SHIFT)
#define MP2_TIMER_1_INTEN_SET_RESERVED(mp2_timer_1_inten_reg, reserved) \
     mp2_timer_1_inten_reg = (mp2_timer_1_inten_reg & ~MP2_TIMER_1_INTEN_RESERVED_MASK) | (reserved << MP2_TIMER_1_INTEN_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_1_inten_t {
          unsigned int inten                          : MP2_TIMER_1_INTEN_INTEN_SIZE;
          unsigned int reserved                       : MP2_TIMER_1_INTEN_RESERVED_SIZE;
     } mp2_timer_1_inten_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_1_inten_t {
          unsigned int reserved                       : MP2_TIMER_1_INTEN_RESERVED_SIZE;
          unsigned int inten                          : MP2_TIMER_1_INTEN_INTEN_SIZE;
     } mp2_timer_1_inten_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_1_inten_t f;
} mp2_timer_1_inten_u;


/*
 * MP2_TIMER_2_INTEN struct
 */

#define MP2_TIMER_2_INTEN_REG_SIZE     32
#define MP2_TIMER_2_INTEN_INTEN_SIZE   4
#define MP2_TIMER_2_INTEN_RESERVED_SIZE 28

#define MP2_TIMER_2_INTEN_INTEN_SHIFT  0
#define MP2_TIMER_2_INTEN_RESERVED_SHIFT 4

#define MP2_TIMER_2_INTEN_INTEN_MASK   0xf
#define MP2_TIMER_2_INTEN_RESERVED_MASK 0xfffffff0

#define MP2_TIMER_2_INTEN_MASK \
     (MP2_TIMER_2_INTEN_INTEN_MASK | \
      MP2_TIMER_2_INTEN_RESERVED_MASK)

#define MP2_TIMER_2_INTEN_DEFAULT      0x00000000

#define MP2_TIMER_2_INTEN_GET_INTEN(mp2_timer_2_inten) \
     ((mp2_timer_2_inten & MP2_TIMER_2_INTEN_INTEN_MASK) >> MP2_TIMER_2_INTEN_INTEN_SHIFT)
#define MP2_TIMER_2_INTEN_GET_RESERVED(mp2_timer_2_inten) \
     ((mp2_timer_2_inten & MP2_TIMER_2_INTEN_RESERVED_MASK) >> MP2_TIMER_2_INTEN_RESERVED_SHIFT)

#define MP2_TIMER_2_INTEN_SET_INTEN(mp2_timer_2_inten_reg, inten) \
     mp2_timer_2_inten_reg = (mp2_timer_2_inten_reg & ~MP2_TIMER_2_INTEN_INTEN_MASK) | (inten << MP2_TIMER_2_INTEN_INTEN_SHIFT)
#define MP2_TIMER_2_INTEN_SET_RESERVED(mp2_timer_2_inten_reg, reserved) \
     mp2_timer_2_inten_reg = (mp2_timer_2_inten_reg & ~MP2_TIMER_2_INTEN_RESERVED_MASK) | (reserved << MP2_TIMER_2_INTEN_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_2_inten_t {
          unsigned int inten                          : MP2_TIMER_2_INTEN_INTEN_SIZE;
          unsigned int reserved                       : MP2_TIMER_2_INTEN_RESERVED_SIZE;
     } mp2_timer_2_inten_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_2_inten_t {
          unsigned int reserved                       : MP2_TIMER_2_INTEN_RESERVED_SIZE;
          unsigned int inten                          : MP2_TIMER_2_INTEN_INTEN_SIZE;
     } mp2_timer_2_inten_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_2_inten_t f;
} mp2_timer_2_inten_u;


/*
 * MP2_TIMER_3_INTEN struct
 */

#define MP2_TIMER_3_INTEN_REG_SIZE     32
#define MP2_TIMER_3_INTEN_INTEN_SIZE   4
#define MP2_TIMER_3_INTEN_RESERVED_SIZE 28

#define MP2_TIMER_3_INTEN_INTEN_SHIFT  0
#define MP2_TIMER_3_INTEN_RESERVED_SHIFT 4

#define MP2_TIMER_3_INTEN_INTEN_MASK   0xf
#define MP2_TIMER_3_INTEN_RESERVED_MASK 0xfffffff0

#define MP2_TIMER_3_INTEN_MASK \
     (MP2_TIMER_3_INTEN_INTEN_MASK | \
      MP2_TIMER_3_INTEN_RESERVED_MASK)

#define MP2_TIMER_3_INTEN_DEFAULT      0x00000000

#define MP2_TIMER_3_INTEN_GET_INTEN(mp2_timer_3_inten) \
     ((mp2_timer_3_inten & MP2_TIMER_3_INTEN_INTEN_MASK) >> MP2_TIMER_3_INTEN_INTEN_SHIFT)
#define MP2_TIMER_3_INTEN_GET_RESERVED(mp2_timer_3_inten) \
     ((mp2_timer_3_inten & MP2_TIMER_3_INTEN_RESERVED_MASK) >> MP2_TIMER_3_INTEN_RESERVED_SHIFT)

#define MP2_TIMER_3_INTEN_SET_INTEN(mp2_timer_3_inten_reg, inten) \
     mp2_timer_3_inten_reg = (mp2_timer_3_inten_reg & ~MP2_TIMER_3_INTEN_INTEN_MASK) | (inten << MP2_TIMER_3_INTEN_INTEN_SHIFT)
#define MP2_TIMER_3_INTEN_SET_RESERVED(mp2_timer_3_inten_reg, reserved) \
     mp2_timer_3_inten_reg = (mp2_timer_3_inten_reg & ~MP2_TIMER_3_INTEN_RESERVED_MASK) | (reserved << MP2_TIMER_3_INTEN_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_3_inten_t {
          unsigned int inten                          : MP2_TIMER_3_INTEN_INTEN_SIZE;
          unsigned int reserved                       : MP2_TIMER_3_INTEN_RESERVED_SIZE;
     } mp2_timer_3_inten_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_3_inten_t {
          unsigned int reserved                       : MP2_TIMER_3_INTEN_RESERVED_SIZE;
          unsigned int inten                          : MP2_TIMER_3_INTEN_INTEN_SIZE;
     } mp2_timer_3_inten_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_3_inten_t f;
} mp2_timer_3_inten_u;


/*
 * MP2_TIMER_OCMP_0_0 struct
 */

#define MP2_TIMER_OCMP_0_0_REG_SIZE    32
#define MP2_TIMER_OCMP_0_0_OCMP_SIZE   32

#define MP2_TIMER_OCMP_0_0_OCMP_SHIFT  0

#define MP2_TIMER_OCMP_0_0_OCMP_MASK   0xffffffff

#define MP2_TIMER_OCMP_0_0_MASK \
     (MP2_TIMER_OCMP_0_0_OCMP_MASK)

#define MP2_TIMER_OCMP_0_0_DEFAULT     0x00000000

#define MP2_TIMER_OCMP_0_0_GET_OCMP(mp2_timer_ocmp_0_0) \
     ((mp2_timer_ocmp_0_0 & MP2_TIMER_OCMP_0_0_OCMP_MASK) >> MP2_TIMER_OCMP_0_0_OCMP_SHIFT)

#define MP2_TIMER_OCMP_0_0_SET_OCMP(mp2_timer_ocmp_0_0_reg, ocmp) \
     mp2_timer_ocmp_0_0_reg = (mp2_timer_ocmp_0_0_reg & ~MP2_TIMER_OCMP_0_0_OCMP_MASK) | (ocmp << MP2_TIMER_OCMP_0_0_OCMP_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_0_0_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_0_0_OCMP_SIZE;
     } mp2_timer_ocmp_0_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_0_0_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_0_0_OCMP_SIZE;
     } mp2_timer_ocmp_0_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_ocmp_0_0_t f;
} mp2_timer_ocmp_0_0_u;


/*
 * MP2_TIMER_OCMP_1_0 struct
 */

#define MP2_TIMER_OCMP_1_0_REG_SIZE    32
#define MP2_TIMER_OCMP_1_0_OCMP_SIZE   32

#define MP2_TIMER_OCMP_1_0_OCMP_SHIFT  0

#define MP2_TIMER_OCMP_1_0_OCMP_MASK   0xffffffff

#define MP2_TIMER_OCMP_1_0_MASK \
     (MP2_TIMER_OCMP_1_0_OCMP_MASK)

#define MP2_TIMER_OCMP_1_0_DEFAULT     0x00000000

#define MP2_TIMER_OCMP_1_0_GET_OCMP(mp2_timer_ocmp_1_0) \
     ((mp2_timer_ocmp_1_0 & MP2_TIMER_OCMP_1_0_OCMP_MASK) >> MP2_TIMER_OCMP_1_0_OCMP_SHIFT)

#define MP2_TIMER_OCMP_1_0_SET_OCMP(mp2_timer_ocmp_1_0_reg, ocmp) \
     mp2_timer_ocmp_1_0_reg = (mp2_timer_ocmp_1_0_reg & ~MP2_TIMER_OCMP_1_0_OCMP_MASK) | (ocmp << MP2_TIMER_OCMP_1_0_OCMP_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_1_0_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_1_0_OCMP_SIZE;
     } mp2_timer_ocmp_1_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_1_0_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_1_0_OCMP_SIZE;
     } mp2_timer_ocmp_1_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_ocmp_1_0_t f;
} mp2_timer_ocmp_1_0_u;


/*
 * MP2_TIMER_OCMP_2_0 struct
 */

#define MP2_TIMER_OCMP_2_0_REG_SIZE    32
#define MP2_TIMER_OCMP_2_0_OCMP_SIZE   32

#define MP2_TIMER_OCMP_2_0_OCMP_SHIFT  0

#define MP2_TIMER_OCMP_2_0_OCMP_MASK   0xffffffff

#define MP2_TIMER_OCMP_2_0_MASK \
     (MP2_TIMER_OCMP_2_0_OCMP_MASK)

#define MP2_TIMER_OCMP_2_0_DEFAULT     0x00000000

#define MP2_TIMER_OCMP_2_0_GET_OCMP(mp2_timer_ocmp_2_0) \
     ((mp2_timer_ocmp_2_0 & MP2_TIMER_OCMP_2_0_OCMP_MASK) >> MP2_TIMER_OCMP_2_0_OCMP_SHIFT)

#define MP2_TIMER_OCMP_2_0_SET_OCMP(mp2_timer_ocmp_2_0_reg, ocmp) \
     mp2_timer_ocmp_2_0_reg = (mp2_timer_ocmp_2_0_reg & ~MP2_TIMER_OCMP_2_0_OCMP_MASK) | (ocmp << MP2_TIMER_OCMP_2_0_OCMP_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_2_0_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_2_0_OCMP_SIZE;
     } mp2_timer_ocmp_2_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_2_0_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_2_0_OCMP_SIZE;
     } mp2_timer_ocmp_2_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_ocmp_2_0_t f;
} mp2_timer_ocmp_2_0_u;


/*
 * MP2_TIMER_OCMP_3_0 struct
 */

#define MP2_TIMER_OCMP_3_0_REG_SIZE    32
#define MP2_TIMER_OCMP_3_0_OCMP_SIZE   32

#define MP2_TIMER_OCMP_3_0_OCMP_SHIFT  0

#define MP2_TIMER_OCMP_3_0_OCMP_MASK   0xffffffff

#define MP2_TIMER_OCMP_3_0_MASK \
     (MP2_TIMER_OCMP_3_0_OCMP_MASK)

#define MP2_TIMER_OCMP_3_0_DEFAULT     0x00000000

#define MP2_TIMER_OCMP_3_0_GET_OCMP(mp2_timer_ocmp_3_0) \
     ((mp2_timer_ocmp_3_0 & MP2_TIMER_OCMP_3_0_OCMP_MASK) >> MP2_TIMER_OCMP_3_0_OCMP_SHIFT)

#define MP2_TIMER_OCMP_3_0_SET_OCMP(mp2_timer_ocmp_3_0_reg, ocmp) \
     mp2_timer_ocmp_3_0_reg = (mp2_timer_ocmp_3_0_reg & ~MP2_TIMER_OCMP_3_0_OCMP_MASK) | (ocmp << MP2_TIMER_OCMP_3_0_OCMP_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_3_0_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_3_0_OCMP_SIZE;
     } mp2_timer_ocmp_3_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_3_0_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_3_0_OCMP_SIZE;
     } mp2_timer_ocmp_3_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_ocmp_3_0_t f;
} mp2_timer_ocmp_3_0_u;


/*
 * MP2_TIMER_OCMP_0_1 struct
 */

#define MP2_TIMER_OCMP_0_1_REG_SIZE    32
#define MP2_TIMER_OCMP_0_1_OCMP_SIZE   32

#define MP2_TIMER_OCMP_0_1_OCMP_SHIFT  0

#define MP2_TIMER_OCMP_0_1_OCMP_MASK   0xffffffff

#define MP2_TIMER_OCMP_0_1_MASK \
     (MP2_TIMER_OCMP_0_1_OCMP_MASK)

#define MP2_TIMER_OCMP_0_1_DEFAULT     0x00000000

#define MP2_TIMER_OCMP_0_1_GET_OCMP(mp2_timer_ocmp_0_1) \
     ((mp2_timer_ocmp_0_1 & MP2_TIMER_OCMP_0_1_OCMP_MASK) >> MP2_TIMER_OCMP_0_1_OCMP_SHIFT)

#define MP2_TIMER_OCMP_0_1_SET_OCMP(mp2_timer_ocmp_0_1_reg, ocmp) \
     mp2_timer_ocmp_0_1_reg = (mp2_timer_ocmp_0_1_reg & ~MP2_TIMER_OCMP_0_1_OCMP_MASK) | (ocmp << MP2_TIMER_OCMP_0_1_OCMP_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_0_1_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_0_1_OCMP_SIZE;
     } mp2_timer_ocmp_0_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_0_1_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_0_1_OCMP_SIZE;
     } mp2_timer_ocmp_0_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_ocmp_0_1_t f;
} mp2_timer_ocmp_0_1_u;


/*
 * MP2_TIMER_OCMP_1_1 struct
 */

#define MP2_TIMER_OCMP_1_1_REG_SIZE    32
#define MP2_TIMER_OCMP_1_1_OCMP_SIZE   32

#define MP2_TIMER_OCMP_1_1_OCMP_SHIFT  0

#define MP2_TIMER_OCMP_1_1_OCMP_MASK   0xffffffff

#define MP2_TIMER_OCMP_1_1_MASK \
     (MP2_TIMER_OCMP_1_1_OCMP_MASK)

#define MP2_TIMER_OCMP_1_1_DEFAULT     0x00000000

#define MP2_TIMER_OCMP_1_1_GET_OCMP(mp2_timer_ocmp_1_1) \
     ((mp2_timer_ocmp_1_1 & MP2_TIMER_OCMP_1_1_OCMP_MASK) >> MP2_TIMER_OCMP_1_1_OCMP_SHIFT)

#define MP2_TIMER_OCMP_1_1_SET_OCMP(mp2_timer_ocmp_1_1_reg, ocmp) \
     mp2_timer_ocmp_1_1_reg = (mp2_timer_ocmp_1_1_reg & ~MP2_TIMER_OCMP_1_1_OCMP_MASK) | (ocmp << MP2_TIMER_OCMP_1_1_OCMP_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_1_1_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_1_1_OCMP_SIZE;
     } mp2_timer_ocmp_1_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_1_1_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_1_1_OCMP_SIZE;
     } mp2_timer_ocmp_1_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_ocmp_1_1_t f;
} mp2_timer_ocmp_1_1_u;


/*
 * MP2_TIMER_OCMP_2_1 struct
 */

#define MP2_TIMER_OCMP_2_1_REG_SIZE    32
#define MP2_TIMER_OCMP_2_1_OCMP_SIZE   32

#define MP2_TIMER_OCMP_2_1_OCMP_SHIFT  0

#define MP2_TIMER_OCMP_2_1_OCMP_MASK   0xffffffff

#define MP2_TIMER_OCMP_2_1_MASK \
     (MP2_TIMER_OCMP_2_1_OCMP_MASK)

#define MP2_TIMER_OCMP_2_1_DEFAULT     0x00000000

#define MP2_TIMER_OCMP_2_1_GET_OCMP(mp2_timer_ocmp_2_1) \
     ((mp2_timer_ocmp_2_1 & MP2_TIMER_OCMP_2_1_OCMP_MASK) >> MP2_TIMER_OCMP_2_1_OCMP_SHIFT)

#define MP2_TIMER_OCMP_2_1_SET_OCMP(mp2_timer_ocmp_2_1_reg, ocmp) \
     mp2_timer_ocmp_2_1_reg = (mp2_timer_ocmp_2_1_reg & ~MP2_TIMER_OCMP_2_1_OCMP_MASK) | (ocmp << MP2_TIMER_OCMP_2_1_OCMP_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_2_1_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_2_1_OCMP_SIZE;
     } mp2_timer_ocmp_2_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_2_1_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_2_1_OCMP_SIZE;
     } mp2_timer_ocmp_2_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_ocmp_2_1_t f;
} mp2_timer_ocmp_2_1_u;


/*
 * MP2_TIMER_OCMP_3_1 struct
 */

#define MP2_TIMER_OCMP_3_1_REG_SIZE    32
#define MP2_TIMER_OCMP_3_1_OCMP_SIZE   32

#define MP2_TIMER_OCMP_3_1_OCMP_SHIFT  0

#define MP2_TIMER_OCMP_3_1_OCMP_MASK   0xffffffff

#define MP2_TIMER_OCMP_3_1_MASK \
     (MP2_TIMER_OCMP_3_1_OCMP_MASK)

#define MP2_TIMER_OCMP_3_1_DEFAULT     0x00000000

#define MP2_TIMER_OCMP_3_1_GET_OCMP(mp2_timer_ocmp_3_1) \
     ((mp2_timer_ocmp_3_1 & MP2_TIMER_OCMP_3_1_OCMP_MASK) >> MP2_TIMER_OCMP_3_1_OCMP_SHIFT)

#define MP2_TIMER_OCMP_3_1_SET_OCMP(mp2_timer_ocmp_3_1_reg, ocmp) \
     mp2_timer_ocmp_3_1_reg = (mp2_timer_ocmp_3_1_reg & ~MP2_TIMER_OCMP_3_1_OCMP_MASK) | (ocmp << MP2_TIMER_OCMP_3_1_OCMP_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_3_1_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_3_1_OCMP_SIZE;
     } mp2_timer_ocmp_3_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_3_1_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_3_1_OCMP_SIZE;
     } mp2_timer_ocmp_3_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_ocmp_3_1_t f;
} mp2_timer_ocmp_3_1_u;


/*
 * MP2_TIMER_OCMP_0_2 struct
 */

#define MP2_TIMER_OCMP_0_2_REG_SIZE    32
#define MP2_TIMER_OCMP_0_2_OCMP_SIZE   32

#define MP2_TIMER_OCMP_0_2_OCMP_SHIFT  0

#define MP2_TIMER_OCMP_0_2_OCMP_MASK   0xffffffff

#define MP2_TIMER_OCMP_0_2_MASK \
     (MP2_TIMER_OCMP_0_2_OCMP_MASK)

#define MP2_TIMER_OCMP_0_2_DEFAULT     0x00000000

#define MP2_TIMER_OCMP_0_2_GET_OCMP(mp2_timer_ocmp_0_2) \
     ((mp2_timer_ocmp_0_2 & MP2_TIMER_OCMP_0_2_OCMP_MASK) >> MP2_TIMER_OCMP_0_2_OCMP_SHIFT)

#define MP2_TIMER_OCMP_0_2_SET_OCMP(mp2_timer_ocmp_0_2_reg, ocmp) \
     mp2_timer_ocmp_0_2_reg = (mp2_timer_ocmp_0_2_reg & ~MP2_TIMER_OCMP_0_2_OCMP_MASK) | (ocmp << MP2_TIMER_OCMP_0_2_OCMP_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_0_2_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_0_2_OCMP_SIZE;
     } mp2_timer_ocmp_0_2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_0_2_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_0_2_OCMP_SIZE;
     } mp2_timer_ocmp_0_2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_ocmp_0_2_t f;
} mp2_timer_ocmp_0_2_u;


/*
 * MP2_TIMER_OCMP_1_2 struct
 */

#define MP2_TIMER_OCMP_1_2_REG_SIZE    32
#define MP2_TIMER_OCMP_1_2_OCMP_SIZE   32

#define MP2_TIMER_OCMP_1_2_OCMP_SHIFT  0

#define MP2_TIMER_OCMP_1_2_OCMP_MASK   0xffffffff

#define MP2_TIMER_OCMP_1_2_MASK \
     (MP2_TIMER_OCMP_1_2_OCMP_MASK)

#define MP2_TIMER_OCMP_1_2_DEFAULT     0x00000000

#define MP2_TIMER_OCMP_1_2_GET_OCMP(mp2_timer_ocmp_1_2) \
     ((mp2_timer_ocmp_1_2 & MP2_TIMER_OCMP_1_2_OCMP_MASK) >> MP2_TIMER_OCMP_1_2_OCMP_SHIFT)

#define MP2_TIMER_OCMP_1_2_SET_OCMP(mp2_timer_ocmp_1_2_reg, ocmp) \
     mp2_timer_ocmp_1_2_reg = (mp2_timer_ocmp_1_2_reg & ~MP2_TIMER_OCMP_1_2_OCMP_MASK) | (ocmp << MP2_TIMER_OCMP_1_2_OCMP_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_1_2_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_1_2_OCMP_SIZE;
     } mp2_timer_ocmp_1_2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_1_2_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_1_2_OCMP_SIZE;
     } mp2_timer_ocmp_1_2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_ocmp_1_2_t f;
} mp2_timer_ocmp_1_2_u;


/*
 * MP2_TIMER_OCMP_2_2 struct
 */

#define MP2_TIMER_OCMP_2_2_REG_SIZE    32
#define MP2_TIMER_OCMP_2_2_OCMP_SIZE   32

#define MP2_TIMER_OCMP_2_2_OCMP_SHIFT  0

#define MP2_TIMER_OCMP_2_2_OCMP_MASK   0xffffffff

#define MP2_TIMER_OCMP_2_2_MASK \
     (MP2_TIMER_OCMP_2_2_OCMP_MASK)

#define MP2_TIMER_OCMP_2_2_DEFAULT     0x00000000

#define MP2_TIMER_OCMP_2_2_GET_OCMP(mp2_timer_ocmp_2_2) \
     ((mp2_timer_ocmp_2_2 & MP2_TIMER_OCMP_2_2_OCMP_MASK) >> MP2_TIMER_OCMP_2_2_OCMP_SHIFT)

#define MP2_TIMER_OCMP_2_2_SET_OCMP(mp2_timer_ocmp_2_2_reg, ocmp) \
     mp2_timer_ocmp_2_2_reg = (mp2_timer_ocmp_2_2_reg & ~MP2_TIMER_OCMP_2_2_OCMP_MASK) | (ocmp << MP2_TIMER_OCMP_2_2_OCMP_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_2_2_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_2_2_OCMP_SIZE;
     } mp2_timer_ocmp_2_2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_2_2_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_2_2_OCMP_SIZE;
     } mp2_timer_ocmp_2_2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_ocmp_2_2_t f;
} mp2_timer_ocmp_2_2_u;


/*
 * MP2_TIMER_OCMP_3_2 struct
 */

#define MP2_TIMER_OCMP_3_2_REG_SIZE    32
#define MP2_TIMER_OCMP_3_2_OCMP_SIZE   32

#define MP2_TIMER_OCMP_3_2_OCMP_SHIFT  0

#define MP2_TIMER_OCMP_3_2_OCMP_MASK   0xffffffff

#define MP2_TIMER_OCMP_3_2_MASK \
     (MP2_TIMER_OCMP_3_2_OCMP_MASK)

#define MP2_TIMER_OCMP_3_2_DEFAULT     0x00000000

#define MP2_TIMER_OCMP_3_2_GET_OCMP(mp2_timer_ocmp_3_2) \
     ((mp2_timer_ocmp_3_2 & MP2_TIMER_OCMP_3_2_OCMP_MASK) >> MP2_TIMER_OCMP_3_2_OCMP_SHIFT)

#define MP2_TIMER_OCMP_3_2_SET_OCMP(mp2_timer_ocmp_3_2_reg, ocmp) \
     mp2_timer_ocmp_3_2_reg = (mp2_timer_ocmp_3_2_reg & ~MP2_TIMER_OCMP_3_2_OCMP_MASK) | (ocmp << MP2_TIMER_OCMP_3_2_OCMP_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_3_2_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_3_2_OCMP_SIZE;
     } mp2_timer_ocmp_3_2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_3_2_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_3_2_OCMP_SIZE;
     } mp2_timer_ocmp_3_2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_ocmp_3_2_t f;
} mp2_timer_ocmp_3_2_u;


/*
 * MP2_TIMER_OCMP_0_3 struct
 */

#define MP2_TIMER_OCMP_0_3_REG_SIZE    32
#define MP2_TIMER_OCMP_0_3_OCMP_SIZE   32

#define MP2_TIMER_OCMP_0_3_OCMP_SHIFT  0

#define MP2_TIMER_OCMP_0_3_OCMP_MASK   0xffffffff

#define MP2_TIMER_OCMP_0_3_MASK \
     (MP2_TIMER_OCMP_0_3_OCMP_MASK)

#define MP2_TIMER_OCMP_0_3_DEFAULT     0x00000000

#define MP2_TIMER_OCMP_0_3_GET_OCMP(mp2_timer_ocmp_0_3) \
     ((mp2_timer_ocmp_0_3 & MP2_TIMER_OCMP_0_3_OCMP_MASK) >> MP2_TIMER_OCMP_0_3_OCMP_SHIFT)

#define MP2_TIMER_OCMP_0_3_SET_OCMP(mp2_timer_ocmp_0_3_reg, ocmp) \
     mp2_timer_ocmp_0_3_reg = (mp2_timer_ocmp_0_3_reg & ~MP2_TIMER_OCMP_0_3_OCMP_MASK) | (ocmp << MP2_TIMER_OCMP_0_3_OCMP_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_0_3_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_0_3_OCMP_SIZE;
     } mp2_timer_ocmp_0_3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_0_3_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_0_3_OCMP_SIZE;
     } mp2_timer_ocmp_0_3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_ocmp_0_3_t f;
} mp2_timer_ocmp_0_3_u;


/*
 * MP2_TIMER_OCMP_1_3 struct
 */

#define MP2_TIMER_OCMP_1_3_REG_SIZE    32
#define MP2_TIMER_OCMP_1_3_OCMP_SIZE   32

#define MP2_TIMER_OCMP_1_3_OCMP_SHIFT  0

#define MP2_TIMER_OCMP_1_3_OCMP_MASK   0xffffffff

#define MP2_TIMER_OCMP_1_3_MASK \
     (MP2_TIMER_OCMP_1_3_OCMP_MASK)

#define MP2_TIMER_OCMP_1_3_DEFAULT     0x00000000

#define MP2_TIMER_OCMP_1_3_GET_OCMP(mp2_timer_ocmp_1_3) \
     ((mp2_timer_ocmp_1_3 & MP2_TIMER_OCMP_1_3_OCMP_MASK) >> MP2_TIMER_OCMP_1_3_OCMP_SHIFT)

#define MP2_TIMER_OCMP_1_3_SET_OCMP(mp2_timer_ocmp_1_3_reg, ocmp) \
     mp2_timer_ocmp_1_3_reg = (mp2_timer_ocmp_1_3_reg & ~MP2_TIMER_OCMP_1_3_OCMP_MASK) | (ocmp << MP2_TIMER_OCMP_1_3_OCMP_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_1_3_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_1_3_OCMP_SIZE;
     } mp2_timer_ocmp_1_3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_1_3_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_1_3_OCMP_SIZE;
     } mp2_timer_ocmp_1_3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_ocmp_1_3_t f;
} mp2_timer_ocmp_1_3_u;


/*
 * MP2_TIMER_OCMP_2_3 struct
 */

#define MP2_TIMER_OCMP_2_3_REG_SIZE    32
#define MP2_TIMER_OCMP_2_3_OCMP_SIZE   32

#define MP2_TIMER_OCMP_2_3_OCMP_SHIFT  0

#define MP2_TIMER_OCMP_2_3_OCMP_MASK   0xffffffff

#define MP2_TIMER_OCMP_2_3_MASK \
     (MP2_TIMER_OCMP_2_3_OCMP_MASK)

#define MP2_TIMER_OCMP_2_3_DEFAULT     0x00000000

#define MP2_TIMER_OCMP_2_3_GET_OCMP(mp2_timer_ocmp_2_3) \
     ((mp2_timer_ocmp_2_3 & MP2_TIMER_OCMP_2_3_OCMP_MASK) >> MP2_TIMER_OCMP_2_3_OCMP_SHIFT)

#define MP2_TIMER_OCMP_2_3_SET_OCMP(mp2_timer_ocmp_2_3_reg, ocmp) \
     mp2_timer_ocmp_2_3_reg = (mp2_timer_ocmp_2_3_reg & ~MP2_TIMER_OCMP_2_3_OCMP_MASK) | (ocmp << MP2_TIMER_OCMP_2_3_OCMP_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_2_3_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_2_3_OCMP_SIZE;
     } mp2_timer_ocmp_2_3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_2_3_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_2_3_OCMP_SIZE;
     } mp2_timer_ocmp_2_3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_ocmp_2_3_t f;
} mp2_timer_ocmp_2_3_u;


/*
 * MP2_TIMER_OCMP_3_3 struct
 */

#define MP2_TIMER_OCMP_3_3_REG_SIZE    32
#define MP2_TIMER_OCMP_3_3_OCMP_SIZE   32

#define MP2_TIMER_OCMP_3_3_OCMP_SHIFT  0

#define MP2_TIMER_OCMP_3_3_OCMP_MASK   0xffffffff

#define MP2_TIMER_OCMP_3_3_MASK \
     (MP2_TIMER_OCMP_3_3_OCMP_MASK)

#define MP2_TIMER_OCMP_3_3_DEFAULT     0x00000000

#define MP2_TIMER_OCMP_3_3_GET_OCMP(mp2_timer_ocmp_3_3) \
     ((mp2_timer_ocmp_3_3 & MP2_TIMER_OCMP_3_3_OCMP_MASK) >> MP2_TIMER_OCMP_3_3_OCMP_SHIFT)

#define MP2_TIMER_OCMP_3_3_SET_OCMP(mp2_timer_ocmp_3_3_reg, ocmp) \
     mp2_timer_ocmp_3_3_reg = (mp2_timer_ocmp_3_3_reg & ~MP2_TIMER_OCMP_3_3_OCMP_MASK) | (ocmp << MP2_TIMER_OCMP_3_3_OCMP_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_3_3_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_3_3_OCMP_SIZE;
     } mp2_timer_ocmp_3_3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_ocmp_3_3_t {
          unsigned int ocmp                           : MP2_TIMER_OCMP_3_3_OCMP_SIZE;
     } mp2_timer_ocmp_3_3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_ocmp_3_3_t f;
} mp2_timer_ocmp_3_3_u;


/*
 * MP2_TIMER_0_CNT struct
 */

#define MP2_TIMER_0_CNT_REG_SIZE       32
#define MP2_TIMER_0_CNT_COUNT_SIZE     32

#define MP2_TIMER_0_CNT_COUNT_SHIFT    0

#define MP2_TIMER_0_CNT_COUNT_MASK     0xffffffff

#define MP2_TIMER_0_CNT_MASK \
     (MP2_TIMER_0_CNT_COUNT_MASK)

#define MP2_TIMER_0_CNT_DEFAULT        0x00000000

#define MP2_TIMER_0_CNT_GET_COUNT(mp2_timer_0_cnt) \
     ((mp2_timer_0_cnt & MP2_TIMER_0_CNT_COUNT_MASK) >> MP2_TIMER_0_CNT_COUNT_SHIFT)

#define MP2_TIMER_0_CNT_SET_COUNT(mp2_timer_0_cnt_reg, count) \
     mp2_timer_0_cnt_reg = (mp2_timer_0_cnt_reg & ~MP2_TIMER_0_CNT_COUNT_MASK) | (count << MP2_TIMER_0_CNT_COUNT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_0_cnt_t {
          unsigned int count                          : MP2_TIMER_0_CNT_COUNT_SIZE;
     } mp2_timer_0_cnt_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_0_cnt_t {
          unsigned int count                          : MP2_TIMER_0_CNT_COUNT_SIZE;
     } mp2_timer_0_cnt_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_0_cnt_t f;
} mp2_timer_0_cnt_u;


/*
 * MP2_TIMER_1_CNT struct
 */

#define MP2_TIMER_1_CNT_REG_SIZE       32
#define MP2_TIMER_1_CNT_COUNT_SIZE     32

#define MP2_TIMER_1_CNT_COUNT_SHIFT    0

#define MP2_TIMER_1_CNT_COUNT_MASK     0xffffffff

#define MP2_TIMER_1_CNT_MASK \
     (MP2_TIMER_1_CNT_COUNT_MASK)

#define MP2_TIMER_1_CNT_DEFAULT        0x00000000

#define MP2_TIMER_1_CNT_GET_COUNT(mp2_timer_1_cnt) \
     ((mp2_timer_1_cnt & MP2_TIMER_1_CNT_COUNT_MASK) >> MP2_TIMER_1_CNT_COUNT_SHIFT)

#define MP2_TIMER_1_CNT_SET_COUNT(mp2_timer_1_cnt_reg, count) \
     mp2_timer_1_cnt_reg = (mp2_timer_1_cnt_reg & ~MP2_TIMER_1_CNT_COUNT_MASK) | (count << MP2_TIMER_1_CNT_COUNT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_1_cnt_t {
          unsigned int count                          : MP2_TIMER_1_CNT_COUNT_SIZE;
     } mp2_timer_1_cnt_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_1_cnt_t {
          unsigned int count                          : MP2_TIMER_1_CNT_COUNT_SIZE;
     } mp2_timer_1_cnt_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_1_cnt_t f;
} mp2_timer_1_cnt_u;


/*
 * MP2_TIMER_2_CNT struct
 */

#define MP2_TIMER_2_CNT_REG_SIZE       32
#define MP2_TIMER_2_CNT_COUNT_SIZE     32

#define MP2_TIMER_2_CNT_COUNT_SHIFT    0

#define MP2_TIMER_2_CNT_COUNT_MASK     0xffffffff

#define MP2_TIMER_2_CNT_MASK \
     (MP2_TIMER_2_CNT_COUNT_MASK)

#define MP2_TIMER_2_CNT_DEFAULT        0x00000000

#define MP2_TIMER_2_CNT_GET_COUNT(mp2_timer_2_cnt) \
     ((mp2_timer_2_cnt & MP2_TIMER_2_CNT_COUNT_MASK) >> MP2_TIMER_2_CNT_COUNT_SHIFT)

#define MP2_TIMER_2_CNT_SET_COUNT(mp2_timer_2_cnt_reg, count) \
     mp2_timer_2_cnt_reg = (mp2_timer_2_cnt_reg & ~MP2_TIMER_2_CNT_COUNT_MASK) | (count << MP2_TIMER_2_CNT_COUNT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_2_cnt_t {
          unsigned int count                          : MP2_TIMER_2_CNT_COUNT_SIZE;
     } mp2_timer_2_cnt_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_2_cnt_t {
          unsigned int count                          : MP2_TIMER_2_CNT_COUNT_SIZE;
     } mp2_timer_2_cnt_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_2_cnt_t f;
} mp2_timer_2_cnt_u;


/*
 * MP2_TIMER_3_CNT struct
 */

#define MP2_TIMER_3_CNT_REG_SIZE       32
#define MP2_TIMER_3_CNT_COUNT_SIZE     32

#define MP2_TIMER_3_CNT_COUNT_SHIFT    0

#define MP2_TIMER_3_CNT_COUNT_MASK     0xffffffff

#define MP2_TIMER_3_CNT_MASK \
     (MP2_TIMER_3_CNT_COUNT_MASK)

#define MP2_TIMER_3_CNT_DEFAULT        0x00000000

#define MP2_TIMER_3_CNT_GET_COUNT(mp2_timer_3_cnt) \
     ((mp2_timer_3_cnt & MP2_TIMER_3_CNT_COUNT_MASK) >> MP2_TIMER_3_CNT_COUNT_SHIFT)

#define MP2_TIMER_3_CNT_SET_COUNT(mp2_timer_3_cnt_reg, count) \
     mp2_timer_3_cnt_reg = (mp2_timer_3_cnt_reg & ~MP2_TIMER_3_CNT_COUNT_MASK) | (count << MP2_TIMER_3_CNT_COUNT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_timer_3_cnt_t {
          unsigned int count                          : MP2_TIMER_3_CNT_COUNT_SIZE;
     } mp2_timer_3_cnt_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_timer_3_cnt_t {
          unsigned int count                          : MP2_TIMER_3_CNT_COUNT_SIZE;
     } mp2_timer_3_cnt_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_timer_3_cnt_t f;
} mp2_timer_3_cnt_u;


/*
 * MP2_P2CMSG_ATTR struct
 */

#define MP2_P2CMSG_ATTR_REG_SIZE       32
#define MP2_P2CMSG_ATTR_MSG_ATTR_SIZE  8

#define MP2_P2CMSG_ATTR_MSG_ATTR_SHIFT 0

#define MP2_P2CMSG_ATTR_MSG_ATTR_MASK  0xff

#define MP2_P2CMSG_ATTR_MASK \
     (MP2_P2CMSG_ATTR_MSG_ATTR_MASK)

#define MP2_P2CMSG_ATTR_DEFAULT        0x00000000

#define MP2_P2CMSG_ATTR_GET_MSG_ATTR(mp2_p2cmsg_attr) \
     ((mp2_p2cmsg_attr & MP2_P2CMSG_ATTR_MSG_ATTR_MASK) >> MP2_P2CMSG_ATTR_MSG_ATTR_SHIFT)

#define MP2_P2CMSG_ATTR_SET_MSG_ATTR(mp2_p2cmsg_attr_reg, msg_attr) \
     mp2_p2cmsg_attr_reg = (mp2_p2cmsg_attr_reg & ~MP2_P2CMSG_ATTR_MSG_ATTR_MASK) | (msg_attr << MP2_P2CMSG_ATTR_MSG_ATTR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_p2cmsg_attr_t {
          unsigned int msg_attr                       : MP2_P2CMSG_ATTR_MSG_ATTR_SIZE;
          unsigned int                                : 24;
     } mp2_p2cmsg_attr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_p2cmsg_attr_t {
          unsigned int                                : 24;
          unsigned int msg_attr                       : MP2_P2CMSG_ATTR_MSG_ATTR_SIZE;
     } mp2_p2cmsg_attr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_p2cmsg_attr_t f;
} mp2_p2cmsg_attr_u;


/*
 * MP2_C2PMSG_ATTR_0 struct
 */

#define MP2_C2PMSG_ATTR_0_REG_SIZE     32
#define MP2_C2PMSG_ATTR_0_MSG_ATTR_SIZE 32

#define MP2_C2PMSG_ATTR_0_MSG_ATTR_SHIFT 0

#define MP2_C2PMSG_ATTR_0_MSG_ATTR_MASK 0xffffffff

#define MP2_C2PMSG_ATTR_0_MASK \
     (MP2_C2PMSG_ATTR_0_MSG_ATTR_MASK)

#define MP2_C2PMSG_ATTR_0_DEFAULT      0x00000000

#define MP2_C2PMSG_ATTR_0_GET_MSG_ATTR(mp2_c2pmsg_attr_0) \
     ((mp2_c2pmsg_attr_0 & MP2_C2PMSG_ATTR_0_MSG_ATTR_MASK) >> MP2_C2PMSG_ATTR_0_MSG_ATTR_SHIFT)

#define MP2_C2PMSG_ATTR_0_SET_MSG_ATTR(mp2_c2pmsg_attr_0_reg, msg_attr) \
     mp2_c2pmsg_attr_0_reg = (mp2_c2pmsg_attr_0_reg & ~MP2_C2PMSG_ATTR_0_MSG_ATTR_MASK) | (msg_attr << MP2_C2PMSG_ATTR_0_MSG_ATTR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_attr_0_t {
          unsigned int msg_attr                       : MP2_C2PMSG_ATTR_0_MSG_ATTR_SIZE;
     } mp2_c2pmsg_attr_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_attr_0_t {
          unsigned int msg_attr                       : MP2_C2PMSG_ATTR_0_MSG_ATTR_SIZE;
     } mp2_c2pmsg_attr_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_attr_0_t f;
} mp2_c2pmsg_attr_0_u;


/*
 * MP2_C2PMSG_ATTR_1 struct
 */

#define MP2_C2PMSG_ATTR_1_REG_SIZE     32
#define MP2_C2PMSG_ATTR_1_MSG_ATTR_SIZE 32

#define MP2_C2PMSG_ATTR_1_MSG_ATTR_SHIFT 0

#define MP2_C2PMSG_ATTR_1_MSG_ATTR_MASK 0xffffffff

#define MP2_C2PMSG_ATTR_1_MASK \
     (MP2_C2PMSG_ATTR_1_MSG_ATTR_MASK)

#define MP2_C2PMSG_ATTR_1_DEFAULT      0x00000000

#define MP2_C2PMSG_ATTR_1_GET_MSG_ATTR(mp2_c2pmsg_attr_1) \
     ((mp2_c2pmsg_attr_1 & MP2_C2PMSG_ATTR_1_MSG_ATTR_MASK) >> MP2_C2PMSG_ATTR_1_MSG_ATTR_SHIFT)

#define MP2_C2PMSG_ATTR_1_SET_MSG_ATTR(mp2_c2pmsg_attr_1_reg, msg_attr) \
     mp2_c2pmsg_attr_1_reg = (mp2_c2pmsg_attr_1_reg & ~MP2_C2PMSG_ATTR_1_MSG_ATTR_MASK) | (msg_attr << MP2_C2PMSG_ATTR_1_MSG_ATTR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_c2pmsg_attr_1_t {
          unsigned int msg_attr                       : MP2_C2PMSG_ATTR_1_MSG_ATTR_SIZE;
     } mp2_c2pmsg_attr_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_c2pmsg_attr_1_t {
          unsigned int msg_attr                       : MP2_C2PMSG_ATTR_1_MSG_ATTR_SIZE;
     } mp2_c2pmsg_attr_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_c2pmsg_attr_1_t f;
} mp2_c2pmsg_attr_1_u;


/*
 * MP2_S2PMSG_ATTR struct
 */

#define MP2_S2PMSG_ATTR_REG_SIZE       32
#define MP2_S2PMSG_ATTR_MSG_ATTR_SIZE  2

#define MP2_S2PMSG_ATTR_MSG_ATTR_SHIFT 0

#define MP2_S2PMSG_ATTR_MSG_ATTR_MASK  0x3

#define MP2_S2PMSG_ATTR_MASK \
     (MP2_S2PMSG_ATTR_MSG_ATTR_MASK)

#define MP2_S2PMSG_ATTR_DEFAULT        0x00000000

#define MP2_S2PMSG_ATTR_GET_MSG_ATTR(mp2_s2pmsg_attr) \
     ((mp2_s2pmsg_attr & MP2_S2PMSG_ATTR_MSG_ATTR_MASK) >> MP2_S2PMSG_ATTR_MSG_ATTR_SHIFT)

#define MP2_S2PMSG_ATTR_SET_MSG_ATTR(mp2_s2pmsg_attr_reg, msg_attr) \
     mp2_s2pmsg_attr_reg = (mp2_s2pmsg_attr_reg & ~MP2_S2PMSG_ATTR_MSG_ATTR_MASK) | (msg_attr << MP2_S2PMSG_ATTR_MSG_ATTR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_s2pmsg_attr_t {
          unsigned int msg_attr                       : MP2_S2PMSG_ATTR_MSG_ATTR_SIZE;
          unsigned int                                : 30;
     } mp2_s2pmsg_attr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_s2pmsg_attr_t {
          unsigned int                                : 30;
          unsigned int msg_attr                       : MP2_S2PMSG_ATTR_MSG_ATTR_SIZE;
     } mp2_s2pmsg_attr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_s2pmsg_attr_t f;
} mp2_s2pmsg_attr_u;


/*
 * MP2_P2SMSG_ATTR struct
 */

#define MP2_P2SMSG_ATTR_REG_SIZE       32
#define MP2_P2SMSG_ATTR_MSG_ATTR_SIZE  8

#define MP2_P2SMSG_ATTR_MSG_ATTR_SHIFT 0

#define MP2_P2SMSG_ATTR_MSG_ATTR_MASK  0xff

#define MP2_P2SMSG_ATTR_MASK \
     (MP2_P2SMSG_ATTR_MSG_ATTR_MASK)

#define MP2_P2SMSG_ATTR_DEFAULT        0x00000000

#define MP2_P2SMSG_ATTR_GET_MSG_ATTR(mp2_p2smsg_attr) \
     ((mp2_p2smsg_attr & MP2_P2SMSG_ATTR_MSG_ATTR_MASK) >> MP2_P2SMSG_ATTR_MSG_ATTR_SHIFT)

#define MP2_P2SMSG_ATTR_SET_MSG_ATTR(mp2_p2smsg_attr_reg, msg_attr) \
     mp2_p2smsg_attr_reg = (mp2_p2smsg_attr_reg & ~MP2_P2SMSG_ATTR_MSG_ATTR_MASK) | (msg_attr << MP2_P2SMSG_ATTR_MSG_ATTR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_p2smsg_attr_t {
          unsigned int msg_attr                       : MP2_P2SMSG_ATTR_MSG_ATTR_SIZE;
          unsigned int                                : 24;
     } mp2_p2smsg_attr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_p2smsg_attr_t {
          unsigned int                                : 24;
          unsigned int msg_attr                       : MP2_P2SMSG_ATTR_MSG_ATTR_SIZE;
     } mp2_p2smsg_attr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_p2smsg_attr_t f;
} mp2_p2smsg_attr_u;


#endif


