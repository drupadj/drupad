// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MP_DMAC_MASK_H)
#define _MP_DMAC_MASK_H

/*****************************************************************************************************************
 *
 *	mp_dmac_mask.h
 *
 *	Register Spec Release:  <unknown>
*
*	 (c) 2000 ATI Technologies Inc.  (unpublished)
*
*	 All rights reserved.  This notice is intended as a precaution against
*	 inadvertent publication and does not imply publication or any waiver
*	 of confidentiality.  The year included in the foregoing notice is the
*	 year of creation of the work.
*
 *****************************************************************************************************************/

/*******************************************************
 * Read and Write Masks
 *******************************************************/

#define DMAC_ACC_VIOLATION_LOG_ADDR_READ_MASK 0xffffffff
#define DMAC_ACC_VIOLATION_LOG_ADDR_WRITE_MASK 0x0

#define DMAC_ACC_VIOLATION_LOG_STATUS_READ_MASK 0xffffff07
#define DMAC_ACC_VIOLATION_LOG_STATUS_WRITE_MASK 0x8

#define DMAC_MISC_CTRL_READ_MASK       0x3
#define DMAC_MISC_CTRL_WRITE_MASK      0x3

#endif


