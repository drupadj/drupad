// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#if !defined (_MP2_MMU_FIDDLE_H)
#define _MP2_MMU_FIDDLE_H

/*****************************************************************************************************************
 *
 *	mp2_mmu_reg.h
 *
 *	Register Spec Release:  <unknown>
 *
 *  Trade secret of Advanced Micro Devices (AMD) Inc.
 *  Unpublished work, Copyright 2012 Advanced Micro Devices (AMD) Inc.
 *
 *  All rights reserved.  This notice is intended as a precaution against
 *  inadvertent publication and does not imply publication or any waiver
 *  of confidentiality.  The year included in the foregoing notice is the
 *  year of creation of the work.
 *
 *****************************************************************************************************************/

//
// Make sure the necessary endian defines are there.
//
#if defined(LITTLEENDIAN_CPU)
#elif defined(BIGENDIAN_CPU)
#else
#error "BIGENDIAN_CPU or LITTLEENDIAN_CPU must be defined"
#endif


/*******************************************************
 * Values
 *******************************************************/


/*******************************************************
 * Structures
 *******************************************************/

/*
 * MP2_MMU_SRAM_ACC_VIOLATION_LOG_ADDR struct
 */

#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_REG_SIZE 32
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SIZE 32

#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SHIFT 0

#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK 0xffffffff

#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_MASK \
     (MP2_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK)

#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_DEFAULT 0x00000000

#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_GET_ADDRESS(mp2_mmu_sram_acc_violation_log_addr) \
     ((mp2_mmu_sram_acc_violation_log_addr & MP2_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK) >> MP2_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SHIFT)

#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_SET_ADDRESS(mp2_mmu_sram_acc_violation_log_addr_reg, address) \
     mp2_mmu_sram_acc_violation_log_addr_reg = (mp2_mmu_sram_acc_violation_log_addr_reg & ~MP2_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_MASK) | (address << MP2_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mmu_sram_acc_violation_log_addr_t {
          unsigned int address                        : MP2_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SIZE;
     } mp2_mmu_sram_acc_violation_log_addr_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mmu_sram_acc_violation_log_addr_t {
          unsigned int address                        : MP2_MMU_SRAM_ACC_VIOLATION_LOG_ADDR_ADDRESS_SIZE;
     } mp2_mmu_sram_acc_violation_log_addr_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mmu_sram_acc_violation_log_addr_t f;
} mp2_mmu_sram_acc_violation_log_addr_u;


/*
 * MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS struct
 */

#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_REG_SIZE 32
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE 1
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SIZE 1
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_RAM1_SIZE 1
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SIZE 1
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE 2
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SIZE 2
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SIZE 7
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SIZE 10
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SIZE 1
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE 1

#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT 0
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SHIFT 1
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_RAM1_SHIFT 2
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SHIFT 3
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT 4
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SHIFT 6
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SHIFT 8
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SHIFT 15
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SHIFT 30
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT 31

#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK 0x1
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_MASK 0x2
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_RAM1_MASK 0x4
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_MASK 0x8
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK 0x30
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_MASK 0xc0
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_MASK 0x7f00
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_MASK 0x1ff8000
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_MASK 0x40000000
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK 0x80000000

#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_MASK \
     (MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK | \
      MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_MASK | \
      MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_RAM1_MASK | \
      MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_MASK | \
      MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK | \
      MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_MASK | \
      MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_MASK | \
      MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_MASK | \
      MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_MASK | \
      MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK)

#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_DEFAULT 0x00000000

#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_DETECTED(mp2_mmu_sram_acc_violation_log_status) \
     ((mp2_mmu_sram_acc_violation_log_status & MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) >> MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_UNSECURE_BAR(mp2_mmu_sram_acc_violation_log_status) \
     ((mp2_mmu_sram_acc_violation_log_status & MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_MASK) >> MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SHIFT)
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_RAM1(mp2_mmu_sram_acc_violation_log_status) \
     ((mp2_mmu_sram_acc_violation_log_status & MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_RAM1_MASK) >> MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_RAM1_SHIFT)
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_OP(mp2_mmu_sram_acc_violation_log_status) \
     ((mp2_mmu_sram_acc_violation_log_status & MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_MASK) >> MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SHIFT)
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_TYPE(mp2_mmu_sram_acc_violation_log_status) \
     ((mp2_mmu_sram_acc_violation_log_status & MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) >> MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_PERMISSION(mp2_mmu_sram_acc_violation_log_status) \
     ((mp2_mmu_sram_acc_violation_log_status & MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_MASK) >> MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SHIFT)
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_AXI_UNIT_ID(mp2_mmu_sram_acc_violation_log_status) \
     ((mp2_mmu_sram_acc_violation_log_status & MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_MASK) >> MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SHIFT)
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_AXI_INIT_ID(mp2_mmu_sram_acc_violation_log_status) \
     ((mp2_mmu_sram_acc_violation_log_status & MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_MASK) >> MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SHIFT)
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_SRAM_NS0_VIOL_CLEAR(mp2_mmu_sram_acc_violation_log_status) \
     ((mp2_mmu_sram_acc_violation_log_status & MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_MASK) >> MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SHIFT)
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_GET_ACC_VIOLATION_LOG_CLEAR(mp2_mmu_sram_acc_violation_log_status) \
     ((mp2_mmu_sram_acc_violation_log_status & MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) >> MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)

#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_DETECTED(mp2_mmu_sram_acc_violation_log_status_reg, acc_violation_detected) \
     mp2_mmu_sram_acc_violation_log_status_reg = (mp2_mmu_sram_acc_violation_log_status_reg & ~MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_MASK) | (acc_violation_detected << MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SHIFT)
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_UNSECURE_BAR(mp2_mmu_sram_acc_violation_log_status_reg, acc_violation_unsecure_bar) \
     mp2_mmu_sram_acc_violation_log_status_reg = (mp2_mmu_sram_acc_violation_log_status_reg & ~MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_MASK) | (acc_violation_unsecure_bar << MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SHIFT)
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_RAM1(mp2_mmu_sram_acc_violation_log_status_reg, acc_violation_ram1) \
     mp2_mmu_sram_acc_violation_log_status_reg = (mp2_mmu_sram_acc_violation_log_status_reg & ~MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_RAM1_MASK) | (acc_violation_ram1 << MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_RAM1_SHIFT)
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_OP(mp2_mmu_sram_acc_violation_log_status_reg, acc_violation_op) \
     mp2_mmu_sram_acc_violation_log_status_reg = (mp2_mmu_sram_acc_violation_log_status_reg & ~MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_MASK) | (acc_violation_op << MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SHIFT)
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_TYPE(mp2_mmu_sram_acc_violation_log_status_reg, acc_violation_type) \
     mp2_mmu_sram_acc_violation_log_status_reg = (mp2_mmu_sram_acc_violation_log_status_reg & ~MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_MASK) | (acc_violation_type << MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SHIFT)
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_PERMISSION(mp2_mmu_sram_acc_violation_log_status_reg, acc_violation_permission) \
     mp2_mmu_sram_acc_violation_log_status_reg = (mp2_mmu_sram_acc_violation_log_status_reg & ~MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_MASK) | (acc_violation_permission << MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SHIFT)
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_AXI_UNIT_ID(mp2_mmu_sram_acc_violation_log_status_reg, acc_violation_axi_unit_id) \
     mp2_mmu_sram_acc_violation_log_status_reg = (mp2_mmu_sram_acc_violation_log_status_reg & ~MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_MASK) | (acc_violation_axi_unit_id << MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SHIFT)
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_AXI_INIT_ID(mp2_mmu_sram_acc_violation_log_status_reg, acc_violation_axi_init_id) \
     mp2_mmu_sram_acc_violation_log_status_reg = (mp2_mmu_sram_acc_violation_log_status_reg & ~MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_MASK) | (acc_violation_axi_init_id << MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SHIFT)
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_SRAM_NS0_VIOL_CLEAR(mp2_mmu_sram_acc_violation_log_status_reg, sram_ns0_viol_clear) \
     mp2_mmu_sram_acc_violation_log_status_reg = (mp2_mmu_sram_acc_violation_log_status_reg & ~MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_MASK) | (sram_ns0_viol_clear << MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SHIFT)
#define MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SET_ACC_VIOLATION_LOG_CLEAR(mp2_mmu_sram_acc_violation_log_status_reg, acc_violation_log_clear) \
     mp2_mmu_sram_acc_violation_log_status_reg = (mp2_mmu_sram_acc_violation_log_status_reg & ~MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_MASK) | (acc_violation_log_clear << MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mmu_sram_acc_violation_log_status_t {
          unsigned int acc_violation_detected         : MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
          unsigned int acc_violation_unsecure_bar     : MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SIZE;
          unsigned int acc_violation_ram1             : MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_RAM1_SIZE;
          unsigned int acc_violation_op               : MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SIZE;
          unsigned int acc_violation_type             : MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
          unsigned int acc_violation_permission       : MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SIZE;
          unsigned int acc_violation_axi_unit_id      : MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SIZE;
          unsigned int acc_violation_axi_init_id      : MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SIZE;
          unsigned int                                : 5;
          unsigned int sram_ns0_viol_clear            : MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SIZE;
          unsigned int acc_violation_log_clear        : MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
     } mp2_mmu_sram_acc_violation_log_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mmu_sram_acc_violation_log_status_t {
          unsigned int acc_violation_log_clear        : MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_LOG_CLEAR_SIZE;
          unsigned int sram_ns0_viol_clear            : MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_SRAM_NS0_VIOL_CLEAR_SIZE;
          unsigned int                                : 5;
          unsigned int acc_violation_axi_init_id      : MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_INIT_ID_SIZE;
          unsigned int acc_violation_axi_unit_id      : MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_AXI_UNIT_ID_SIZE;
          unsigned int acc_violation_permission       : MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_PERMISSION_SIZE;
          unsigned int acc_violation_type             : MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_TYPE_SIZE;
          unsigned int acc_violation_op               : MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_OP_SIZE;
          unsigned int acc_violation_ram1             : MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_RAM1_SIZE;
          unsigned int acc_violation_unsecure_bar     : MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_UNSECURE_BAR_SIZE;
          unsigned int acc_violation_detected         : MP2_MMU_SRAM_ACC_VIOLATION_LOG_STATUS_ACC_VIOLATION_DETECTED_SIZE;
     } mp2_mmu_sram_acc_violation_log_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mmu_sram_acc_violation_log_status_t f;
} mp2_mmu_sram_acc_violation_log_status_u;


/*
 * MP2_MMU_MISC_CNTL struct
 */

#define MP2_MMU_MISC_CNTL_REG_SIZE     32
#define MP2_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SIZE 1
#define MP2_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SIZE 1
#define MP2_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SIZE 1
#define MP2_MMU_MISC_CNTL_CLK_GATE_EN_SIZE 1
#define MP2_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SIZE 1
#define MP2_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SIZE 4
#define MP2_MMU_MISC_CNTL_REGCLK_STATUS_SIZE 1
#define MP2_MMU_MISC_CNTL_SYSCLK_STATUS_SIZE 1

#define MP2_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SHIFT 0
#define MP2_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SHIFT 2
#define MP2_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SHIFT 3
#define MP2_MMU_MISC_CNTL_CLK_GATE_EN_SHIFT 16
#define MP2_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SHIFT 17
#define MP2_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SHIFT 18
#define MP2_MMU_MISC_CNTL_REGCLK_STATUS_SHIFT 22
#define MP2_MMU_MISC_CNTL_SYSCLK_STATUS_SHIFT 23

#define MP2_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_MASK 0x1
#define MP2_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_MASK 0x4
#define MP2_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_MASK 0x8
#define MP2_MMU_MISC_CNTL_CLK_GATE_EN_MASK 0x10000
#define MP2_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_MASK 0x20000
#define MP2_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_MASK 0x3c0000
#define MP2_MMU_MISC_CNTL_REGCLK_STATUS_MASK 0x400000
#define MP2_MMU_MISC_CNTL_SYSCLK_STATUS_MASK 0x800000

#define MP2_MMU_MISC_CNTL_MASK \
     (MP2_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_MASK | \
      MP2_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_MASK | \
      MP2_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_MASK | \
      MP2_MMU_MISC_CNTL_CLK_GATE_EN_MASK | \
      MP2_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_MASK | \
      MP2_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_MASK | \
      MP2_MMU_MISC_CNTL_REGCLK_STATUS_MASK | \
      MP2_MMU_MISC_CNTL_SYSCLK_STATUS_MASK)

#define MP2_MMU_MISC_CNTL_DEFAULT      0x00e00001

#define MP2_MMU_MISC_CNTL_GET_ALLOW_UNPRIVILIGED_REG_ACC(mp2_mmu_misc_cntl) \
     ((mp2_mmu_misc_cntl & MP2_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_MASK) >> MP2_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SHIFT)
#define MP2_MMU_MISC_CNTL_GET_ENABLE_MEM_CHECKS_PSRAM(mp2_mmu_misc_cntl) \
     ((mp2_mmu_misc_cntl & MP2_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_MASK) >> MP2_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SHIFT)
#define MP2_MMU_MISC_CNTL_GET_ENABLE_MEM_CHECKS_CPU(mp2_mmu_misc_cntl) \
     ((mp2_mmu_misc_cntl & MP2_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_MASK) >> MP2_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SHIFT)
#define MP2_MMU_MISC_CNTL_GET_CLK_GATE_EN(mp2_mmu_misc_cntl) \
     ((mp2_mmu_misc_cntl & MP2_MMU_MISC_CNTL_CLK_GATE_EN_MASK) >> MP2_MMU_MISC_CNTL_CLK_GATE_EN_SHIFT)
#define MP2_MMU_MISC_CNTL_GET_CLK_GATE_OVERRIDE(mp2_mmu_misc_cntl) \
     ((mp2_mmu_misc_cntl & MP2_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_MASK) >> MP2_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SHIFT)
#define MP2_MMU_MISC_CNTL_GET_CLK_GATE_TIMEOUT(mp2_mmu_misc_cntl) \
     ((mp2_mmu_misc_cntl & MP2_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_MASK) >> MP2_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SHIFT)
#define MP2_MMU_MISC_CNTL_GET_REGCLK_STATUS(mp2_mmu_misc_cntl) \
     ((mp2_mmu_misc_cntl & MP2_MMU_MISC_CNTL_REGCLK_STATUS_MASK) >> MP2_MMU_MISC_CNTL_REGCLK_STATUS_SHIFT)
#define MP2_MMU_MISC_CNTL_GET_SYSCLK_STATUS(mp2_mmu_misc_cntl) \
     ((mp2_mmu_misc_cntl & MP2_MMU_MISC_CNTL_SYSCLK_STATUS_MASK) >> MP2_MMU_MISC_CNTL_SYSCLK_STATUS_SHIFT)

#define MP2_MMU_MISC_CNTL_SET_ALLOW_UNPRIVILIGED_REG_ACC(mp2_mmu_misc_cntl_reg, allow_unpriviliged_reg_acc) \
     mp2_mmu_misc_cntl_reg = (mp2_mmu_misc_cntl_reg & ~MP2_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_MASK) | (allow_unpriviliged_reg_acc << MP2_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SHIFT)
#define MP2_MMU_MISC_CNTL_SET_ENABLE_MEM_CHECKS_PSRAM(mp2_mmu_misc_cntl_reg, enable_mem_checks_psram) \
     mp2_mmu_misc_cntl_reg = (mp2_mmu_misc_cntl_reg & ~MP2_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_MASK) | (enable_mem_checks_psram << MP2_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SHIFT)
#define MP2_MMU_MISC_CNTL_SET_ENABLE_MEM_CHECKS_CPU(mp2_mmu_misc_cntl_reg, enable_mem_checks_cpu) \
     mp2_mmu_misc_cntl_reg = (mp2_mmu_misc_cntl_reg & ~MP2_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_MASK) | (enable_mem_checks_cpu << MP2_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SHIFT)
#define MP2_MMU_MISC_CNTL_SET_CLK_GATE_EN(mp2_mmu_misc_cntl_reg, clk_gate_en) \
     mp2_mmu_misc_cntl_reg = (mp2_mmu_misc_cntl_reg & ~MP2_MMU_MISC_CNTL_CLK_GATE_EN_MASK) | (clk_gate_en << MP2_MMU_MISC_CNTL_CLK_GATE_EN_SHIFT)
#define MP2_MMU_MISC_CNTL_SET_CLK_GATE_OVERRIDE(mp2_mmu_misc_cntl_reg, clk_gate_override) \
     mp2_mmu_misc_cntl_reg = (mp2_mmu_misc_cntl_reg & ~MP2_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_MASK) | (clk_gate_override << MP2_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SHIFT)
#define MP2_MMU_MISC_CNTL_SET_CLK_GATE_TIMEOUT(mp2_mmu_misc_cntl_reg, clk_gate_timeout) \
     mp2_mmu_misc_cntl_reg = (mp2_mmu_misc_cntl_reg & ~MP2_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_MASK) | (clk_gate_timeout << MP2_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SHIFT)
#define MP2_MMU_MISC_CNTL_SET_REGCLK_STATUS(mp2_mmu_misc_cntl_reg, regclk_status) \
     mp2_mmu_misc_cntl_reg = (mp2_mmu_misc_cntl_reg & ~MP2_MMU_MISC_CNTL_REGCLK_STATUS_MASK) | (regclk_status << MP2_MMU_MISC_CNTL_REGCLK_STATUS_SHIFT)
#define MP2_MMU_MISC_CNTL_SET_SYSCLK_STATUS(mp2_mmu_misc_cntl_reg, sysclk_status) \
     mp2_mmu_misc_cntl_reg = (mp2_mmu_misc_cntl_reg & ~MP2_MMU_MISC_CNTL_SYSCLK_STATUS_MASK) | (sysclk_status << MP2_MMU_MISC_CNTL_SYSCLK_STATUS_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mmu_misc_cntl_t {
          unsigned int allow_unpriviliged_reg_acc     : MP2_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SIZE;
          unsigned int                                : 1;
          unsigned int enable_mem_checks_psram        : MP2_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SIZE;
          unsigned int enable_mem_checks_cpu          : MP2_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SIZE;
          unsigned int                                : 12;
          unsigned int clk_gate_en                    : MP2_MMU_MISC_CNTL_CLK_GATE_EN_SIZE;
          unsigned int clk_gate_override              : MP2_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SIZE;
          unsigned int clk_gate_timeout               : MP2_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SIZE;
          unsigned int regclk_status                  : MP2_MMU_MISC_CNTL_REGCLK_STATUS_SIZE;
          unsigned int sysclk_status                  : MP2_MMU_MISC_CNTL_SYSCLK_STATUS_SIZE;
          unsigned int                                : 8;
     } mp2_mmu_misc_cntl_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mmu_misc_cntl_t {
          unsigned int                                : 8;
          unsigned int sysclk_status                  : MP2_MMU_MISC_CNTL_SYSCLK_STATUS_SIZE;
          unsigned int regclk_status                  : MP2_MMU_MISC_CNTL_REGCLK_STATUS_SIZE;
          unsigned int clk_gate_timeout               : MP2_MMU_MISC_CNTL_CLK_GATE_TIMEOUT_SIZE;
          unsigned int clk_gate_override              : MP2_MMU_MISC_CNTL_CLK_GATE_OVERRIDE_SIZE;
          unsigned int clk_gate_en                    : MP2_MMU_MISC_CNTL_CLK_GATE_EN_SIZE;
          unsigned int                                : 12;
          unsigned int enable_mem_checks_cpu          : MP2_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_CPU_SIZE;
          unsigned int enable_mem_checks_psram        : MP2_MMU_MISC_CNTL_ENABLE_MEM_CHECKS_PSRAM_SIZE;
          unsigned int                                : 1;
          unsigned int allow_unpriviliged_reg_acc     : MP2_MMU_MISC_CNTL_ALLOW_UNPRIVILIGED_REG_ACC_SIZE;
     } mp2_mmu_misc_cntl_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mmu_misc_cntl_t f;
} mp2_mmu_misc_cntl_u;


/*
 * MP2_MMU_ACCESS_ERR_LOG struct
 */

#define MP2_MMU_ACCESS_ERR_LOG_REG_SIZE 32
#define MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SIZE 1
#define MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SIZE 2
#define MP2_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SIZE 1
#define MP2_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SIZE 1
#define MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SIZE 7
#define MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SIZE 10
#define MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SIZE 3

#define MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SHIFT 0
#define MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SHIFT 1
#define MP2_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SHIFT 3
#define MP2_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SHIFT 4
#define MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SHIFT 8
#define MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SHIFT 15
#define MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SHIFT 25

#define MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_MASK 0x1
#define MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_MASK 0x6
#define MP2_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_MASK 0x8
#define MP2_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_MASK 0x10
#define MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_MASK 0x7f00
#define MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_MASK 0x1ff8000
#define MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_MASK 0xe000000

#define MP2_MMU_ACCESS_ERR_LOG_MASK \
     (MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_MASK | \
      MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_MASK | \
      MP2_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_MASK | \
      MP2_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_MASK | \
      MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_MASK | \
      MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_MASK | \
      MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_MASK)

#define MP2_MMU_ACCESS_ERR_LOG_DEFAULT 0x00000000

#define MP2_MMU_ACCESS_ERR_LOG_GET_AXI_ACC_VIOLATION_DETECTED(mp2_mmu_access_err_log) \
     ((mp2_mmu_access_err_log & MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_MASK) >> MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SHIFT)
#define MP2_MMU_ACCESS_ERR_LOG_GET_AXI_ACC_VIOLATION_BLOCK(mp2_mmu_access_err_log) \
     ((mp2_mmu_access_err_log & MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_MASK) >> MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SHIFT)
#define MP2_MMU_ACCESS_ERR_LOG_GET_ACC_VIOLATION_LOG_CLEAR(mp2_mmu_access_err_log) \
     ((mp2_mmu_access_err_log & MP2_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_MASK) >> MP2_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SHIFT)
#define MP2_MMU_ACCESS_ERR_LOG_GET_CFG_NS0_VIOL_CLEAR(mp2_mmu_access_err_log) \
     ((mp2_mmu_access_err_log & MP2_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_MASK) >> MP2_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SHIFT)
#define MP2_MMU_ACCESS_ERR_LOG_GET_AXI_ACC_VIOLATION_AXI_UNIT_ID(mp2_mmu_access_err_log) \
     ((mp2_mmu_access_err_log & MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_MASK) >> MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SHIFT)
#define MP2_MMU_ACCESS_ERR_LOG_GET_AXI_ACC_VIOLATION_AXI_INIT_ID(mp2_mmu_access_err_log) \
     ((mp2_mmu_access_err_log & MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_MASK) >> MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SHIFT)
#define MP2_MMU_ACCESS_ERR_LOG_GET_AXI_ACC_VIOLATION_AXI_PROT(mp2_mmu_access_err_log) \
     ((mp2_mmu_access_err_log & MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_MASK) >> MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SHIFT)

#define MP2_MMU_ACCESS_ERR_LOG_SET_AXI_ACC_VIOLATION_DETECTED(mp2_mmu_access_err_log_reg, axi_acc_violation_detected) \
     mp2_mmu_access_err_log_reg = (mp2_mmu_access_err_log_reg & ~MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_MASK) | (axi_acc_violation_detected << MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SHIFT)
#define MP2_MMU_ACCESS_ERR_LOG_SET_AXI_ACC_VIOLATION_BLOCK(mp2_mmu_access_err_log_reg, axi_acc_violation_block) \
     mp2_mmu_access_err_log_reg = (mp2_mmu_access_err_log_reg & ~MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_MASK) | (axi_acc_violation_block << MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SHIFT)
#define MP2_MMU_ACCESS_ERR_LOG_SET_ACC_VIOLATION_LOG_CLEAR(mp2_mmu_access_err_log_reg, acc_violation_log_clear) \
     mp2_mmu_access_err_log_reg = (mp2_mmu_access_err_log_reg & ~MP2_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_MASK) | (acc_violation_log_clear << MP2_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SHIFT)
#define MP2_MMU_ACCESS_ERR_LOG_SET_CFG_NS0_VIOL_CLEAR(mp2_mmu_access_err_log_reg, cfg_ns0_viol_clear) \
     mp2_mmu_access_err_log_reg = (mp2_mmu_access_err_log_reg & ~MP2_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_MASK) | (cfg_ns0_viol_clear << MP2_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SHIFT)
#define MP2_MMU_ACCESS_ERR_LOG_SET_AXI_ACC_VIOLATION_AXI_UNIT_ID(mp2_mmu_access_err_log_reg, axi_acc_violation_axi_unit_id) \
     mp2_mmu_access_err_log_reg = (mp2_mmu_access_err_log_reg & ~MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_MASK) | (axi_acc_violation_axi_unit_id << MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SHIFT)
#define MP2_MMU_ACCESS_ERR_LOG_SET_AXI_ACC_VIOLATION_AXI_INIT_ID(mp2_mmu_access_err_log_reg, axi_acc_violation_axi_init_id) \
     mp2_mmu_access_err_log_reg = (mp2_mmu_access_err_log_reg & ~MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_MASK) | (axi_acc_violation_axi_init_id << MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SHIFT)
#define MP2_MMU_ACCESS_ERR_LOG_SET_AXI_ACC_VIOLATION_AXI_PROT(mp2_mmu_access_err_log_reg, axi_acc_violation_axi_prot) \
     mp2_mmu_access_err_log_reg = (mp2_mmu_access_err_log_reg & ~MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_MASK) | (axi_acc_violation_axi_prot << MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mmu_access_err_log_t {
          unsigned int axi_acc_violation_detected     : MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SIZE;
          unsigned int axi_acc_violation_block        : MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SIZE;
          unsigned int acc_violation_log_clear        : MP2_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SIZE;
          unsigned int cfg_ns0_viol_clear             : MP2_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SIZE;
          unsigned int                                : 3;
          unsigned int axi_acc_violation_axi_unit_id  : MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SIZE;
          unsigned int axi_acc_violation_axi_init_id  : MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SIZE;
          unsigned int axi_acc_violation_axi_prot     : MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SIZE;
          unsigned int                                : 4;
     } mp2_mmu_access_err_log_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mmu_access_err_log_t {
          unsigned int                                : 4;
          unsigned int axi_acc_violation_axi_prot     : MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_PROT_SIZE;
          unsigned int axi_acc_violation_axi_init_id  : MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_INIT_ID_SIZE;
          unsigned int axi_acc_violation_axi_unit_id  : MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_AXI_UNIT_ID_SIZE;
          unsigned int                                : 3;
          unsigned int cfg_ns0_viol_clear             : MP2_MMU_ACCESS_ERR_LOG_CFG_NS0_VIOL_CLEAR_SIZE;
          unsigned int acc_violation_log_clear        : MP2_MMU_ACCESS_ERR_LOG_ACC_VIOLATION_LOG_CLEAR_SIZE;
          unsigned int axi_acc_violation_block        : MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_BLOCK_SIZE;
          unsigned int axi_acc_violation_detected     : MP2_MMU_ACCESS_ERR_LOG_AXI_ACC_VIOLATION_DETECTED_SIZE;
     } mp2_mmu_access_err_log_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mmu_access_err_log_t f;
} mp2_mmu_access_err_log_u;


/*
 * MP2_MMU_SRAM_UNSECURE_BAR struct
 */

#define MP2_MMU_SRAM_UNSECURE_BAR_REG_SIZE 32
#define MP2_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SIZE 32

#define MP2_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SHIFT 0

#define MP2_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_MASK 0xffffffff

#define MP2_MMU_SRAM_UNSECURE_BAR_MASK \
     (MP2_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_MASK)

#define MP2_MMU_SRAM_UNSECURE_BAR_DEFAULT 0x0003c000

#define MP2_MMU_SRAM_UNSECURE_BAR_GET_SRAM_UNSECURE_BAR(mp2_mmu_sram_unsecure_bar) \
     ((mp2_mmu_sram_unsecure_bar & MP2_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_MASK) >> MP2_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SHIFT)

#define MP2_MMU_SRAM_UNSECURE_BAR_SET_SRAM_UNSECURE_BAR(mp2_mmu_sram_unsecure_bar_reg, sram_unsecure_bar) \
     mp2_mmu_sram_unsecure_bar_reg = (mp2_mmu_sram_unsecure_bar_reg & ~MP2_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_MASK) | (sram_unsecure_bar << MP2_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mmu_sram_unsecure_bar_t {
          unsigned int sram_unsecure_bar              : MP2_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SIZE;
     } mp2_mmu_sram_unsecure_bar_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mmu_sram_unsecure_bar_t {
          unsigned int sram_unsecure_bar              : MP2_MMU_SRAM_UNSECURE_BAR_SRAM_UNSECURE_BAR_SIZE;
     } mp2_mmu_sram_unsecure_bar_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mmu_sram_unsecure_bar_t f;
} mp2_mmu_sram_unsecure_bar_u;


/*
 * MP2_MMU_SCRATCH_0 struct
 */

#define MP2_MMU_SCRATCH_0_REG_SIZE     32
#define MP2_MMU_SCRATCH_0_RESERVED_SIZE 32

#define MP2_MMU_SCRATCH_0_RESERVED_SHIFT 0

#define MP2_MMU_SCRATCH_0_RESERVED_MASK 0xffffffff

#define MP2_MMU_SCRATCH_0_MASK \
     (MP2_MMU_SCRATCH_0_RESERVED_MASK)

#define MP2_MMU_SCRATCH_0_DEFAULT      0x00000000

#define MP2_MMU_SCRATCH_0_GET_RESERVED(mp2_mmu_scratch_0) \
     ((mp2_mmu_scratch_0 & MP2_MMU_SCRATCH_0_RESERVED_MASK) >> MP2_MMU_SCRATCH_0_RESERVED_SHIFT)

#define MP2_MMU_SCRATCH_0_SET_RESERVED(mp2_mmu_scratch_0_reg, reserved) \
     mp2_mmu_scratch_0_reg = (mp2_mmu_scratch_0_reg & ~MP2_MMU_SCRATCH_0_RESERVED_MASK) | (reserved << MP2_MMU_SCRATCH_0_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mmu_scratch_0_t {
          unsigned int reserved                       : MP2_MMU_SCRATCH_0_RESERVED_SIZE;
     } mp2_mmu_scratch_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mmu_scratch_0_t {
          unsigned int reserved                       : MP2_MMU_SCRATCH_0_RESERVED_SIZE;
     } mp2_mmu_scratch_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mmu_scratch_0_t f;
} mp2_mmu_scratch_0_u;


/*
 * MP2_MMU_SCRATCH_1 struct
 */

#define MP2_MMU_SCRATCH_1_REG_SIZE     32
#define MP2_MMU_SCRATCH_1_RESERVED_SIZE 32

#define MP2_MMU_SCRATCH_1_RESERVED_SHIFT 0

#define MP2_MMU_SCRATCH_1_RESERVED_MASK 0xffffffff

#define MP2_MMU_SCRATCH_1_MASK \
     (MP2_MMU_SCRATCH_1_RESERVED_MASK)

#define MP2_MMU_SCRATCH_1_DEFAULT      0x00000000

#define MP2_MMU_SCRATCH_1_GET_RESERVED(mp2_mmu_scratch_1) \
     ((mp2_mmu_scratch_1 & MP2_MMU_SCRATCH_1_RESERVED_MASK) >> MP2_MMU_SCRATCH_1_RESERVED_SHIFT)

#define MP2_MMU_SCRATCH_1_SET_RESERVED(mp2_mmu_scratch_1_reg, reserved) \
     mp2_mmu_scratch_1_reg = (mp2_mmu_scratch_1_reg & ~MP2_MMU_SCRATCH_1_RESERVED_MASK) | (reserved << MP2_MMU_SCRATCH_1_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mmu_scratch_1_t {
          unsigned int reserved                       : MP2_MMU_SCRATCH_1_RESERVED_SIZE;
     } mp2_mmu_scratch_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mmu_scratch_1_t {
          unsigned int reserved                       : MP2_MMU_SCRATCH_1_RESERVED_SIZE;
     } mp2_mmu_scratch_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mmu_scratch_1_t f;
} mp2_mmu_scratch_1_u;


/*
 * MP2_MMU_SCRATCH_2 struct
 */

#define MP2_MMU_SCRATCH_2_REG_SIZE     32
#define MP2_MMU_SCRATCH_2_RESERVED_SIZE 32

#define MP2_MMU_SCRATCH_2_RESERVED_SHIFT 0

#define MP2_MMU_SCRATCH_2_RESERVED_MASK 0xffffffff

#define MP2_MMU_SCRATCH_2_MASK \
     (MP2_MMU_SCRATCH_2_RESERVED_MASK)

#define MP2_MMU_SCRATCH_2_DEFAULT      0x00000000

#define MP2_MMU_SCRATCH_2_GET_RESERVED(mp2_mmu_scratch_2) \
     ((mp2_mmu_scratch_2 & MP2_MMU_SCRATCH_2_RESERVED_MASK) >> MP2_MMU_SCRATCH_2_RESERVED_SHIFT)

#define MP2_MMU_SCRATCH_2_SET_RESERVED(mp2_mmu_scratch_2_reg, reserved) \
     mp2_mmu_scratch_2_reg = (mp2_mmu_scratch_2_reg & ~MP2_MMU_SCRATCH_2_RESERVED_MASK) | (reserved << MP2_MMU_SCRATCH_2_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mmu_scratch_2_t {
          unsigned int reserved                       : MP2_MMU_SCRATCH_2_RESERVED_SIZE;
     } mp2_mmu_scratch_2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mmu_scratch_2_t {
          unsigned int reserved                       : MP2_MMU_SCRATCH_2_RESERVED_SIZE;
     } mp2_mmu_scratch_2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mmu_scratch_2_t f;
} mp2_mmu_scratch_2_u;


/*
 * MP2_MMU_SCRATCH_3 struct
 */

#define MP2_MMU_SCRATCH_3_REG_SIZE     32
#define MP2_MMU_SCRATCH_3_RESERVED_SIZE 32

#define MP2_MMU_SCRATCH_3_RESERVED_SHIFT 0

#define MP2_MMU_SCRATCH_3_RESERVED_MASK 0xffffffff

#define MP2_MMU_SCRATCH_3_MASK \
     (MP2_MMU_SCRATCH_3_RESERVED_MASK)

#define MP2_MMU_SCRATCH_3_DEFAULT      0x00000000

#define MP2_MMU_SCRATCH_3_GET_RESERVED(mp2_mmu_scratch_3) \
     ((mp2_mmu_scratch_3 & MP2_MMU_SCRATCH_3_RESERVED_MASK) >> MP2_MMU_SCRATCH_3_RESERVED_SHIFT)

#define MP2_MMU_SCRATCH_3_SET_RESERVED(mp2_mmu_scratch_3_reg, reserved) \
     mp2_mmu_scratch_3_reg = (mp2_mmu_scratch_3_reg & ~MP2_MMU_SCRATCH_3_RESERVED_MASK) | (reserved << MP2_MMU_SCRATCH_3_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mmu_scratch_3_t {
          unsigned int reserved                       : MP2_MMU_SCRATCH_3_RESERVED_SIZE;
     } mp2_mmu_scratch_3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mmu_scratch_3_t {
          unsigned int reserved                       : MP2_MMU_SCRATCH_3_RESERVED_SIZE;
     } mp2_mmu_scratch_3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mmu_scratch_3_t f;
} mp2_mmu_scratch_3_u;


/*
 * MP2_MMU_SCRATCH_4 struct
 */

#define MP2_MMU_SCRATCH_4_REG_SIZE     32
#define MP2_MMU_SCRATCH_4_RESERVED_SIZE 32

#define MP2_MMU_SCRATCH_4_RESERVED_SHIFT 0

#define MP2_MMU_SCRATCH_4_RESERVED_MASK 0xffffffff

#define MP2_MMU_SCRATCH_4_MASK \
     (MP2_MMU_SCRATCH_4_RESERVED_MASK)

#define MP2_MMU_SCRATCH_4_DEFAULT      0x00000000

#define MP2_MMU_SCRATCH_4_GET_RESERVED(mp2_mmu_scratch_4) \
     ((mp2_mmu_scratch_4 & MP2_MMU_SCRATCH_4_RESERVED_MASK) >> MP2_MMU_SCRATCH_4_RESERVED_SHIFT)

#define MP2_MMU_SCRATCH_4_SET_RESERVED(mp2_mmu_scratch_4_reg, reserved) \
     mp2_mmu_scratch_4_reg = (mp2_mmu_scratch_4_reg & ~MP2_MMU_SCRATCH_4_RESERVED_MASK) | (reserved << MP2_MMU_SCRATCH_4_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mmu_scratch_4_t {
          unsigned int reserved                       : MP2_MMU_SCRATCH_4_RESERVED_SIZE;
     } mp2_mmu_scratch_4_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mmu_scratch_4_t {
          unsigned int reserved                       : MP2_MMU_SCRATCH_4_RESERVED_SIZE;
     } mp2_mmu_scratch_4_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mmu_scratch_4_t f;
} mp2_mmu_scratch_4_u;


/*
 * MP2_MMU_SCRATCH_5 struct
 */

#define MP2_MMU_SCRATCH_5_REG_SIZE     32
#define MP2_MMU_SCRATCH_5_RESERVED_SIZE 32

#define MP2_MMU_SCRATCH_5_RESERVED_SHIFT 0

#define MP2_MMU_SCRATCH_5_RESERVED_MASK 0xffffffff

#define MP2_MMU_SCRATCH_5_MASK \
     (MP2_MMU_SCRATCH_5_RESERVED_MASK)

#define MP2_MMU_SCRATCH_5_DEFAULT      0x00000000

#define MP2_MMU_SCRATCH_5_GET_RESERVED(mp2_mmu_scratch_5) \
     ((mp2_mmu_scratch_5 & MP2_MMU_SCRATCH_5_RESERVED_MASK) >> MP2_MMU_SCRATCH_5_RESERVED_SHIFT)

#define MP2_MMU_SCRATCH_5_SET_RESERVED(mp2_mmu_scratch_5_reg, reserved) \
     mp2_mmu_scratch_5_reg = (mp2_mmu_scratch_5_reg & ~MP2_MMU_SCRATCH_5_RESERVED_MASK) | (reserved << MP2_MMU_SCRATCH_5_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mmu_scratch_5_t {
          unsigned int reserved                       : MP2_MMU_SCRATCH_5_RESERVED_SIZE;
     } mp2_mmu_scratch_5_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mmu_scratch_5_t {
          unsigned int reserved                       : MP2_MMU_SCRATCH_5_RESERVED_SIZE;
     } mp2_mmu_scratch_5_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mmu_scratch_5_t f;
} mp2_mmu_scratch_5_u;


/*
 * MP2_MMU_SCRATCH_6 struct
 */

#define MP2_MMU_SCRATCH_6_REG_SIZE     32
#define MP2_MMU_SCRATCH_6_RESERVED_SIZE 32

#define MP2_MMU_SCRATCH_6_RESERVED_SHIFT 0

#define MP2_MMU_SCRATCH_6_RESERVED_MASK 0xffffffff

#define MP2_MMU_SCRATCH_6_MASK \
     (MP2_MMU_SCRATCH_6_RESERVED_MASK)

#define MP2_MMU_SCRATCH_6_DEFAULT      0x00000000

#define MP2_MMU_SCRATCH_6_GET_RESERVED(mp2_mmu_scratch_6) \
     ((mp2_mmu_scratch_6 & MP2_MMU_SCRATCH_6_RESERVED_MASK) >> MP2_MMU_SCRATCH_6_RESERVED_SHIFT)

#define MP2_MMU_SCRATCH_6_SET_RESERVED(mp2_mmu_scratch_6_reg, reserved) \
     mp2_mmu_scratch_6_reg = (mp2_mmu_scratch_6_reg & ~MP2_MMU_SCRATCH_6_RESERVED_MASK) | (reserved << MP2_MMU_SCRATCH_6_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mmu_scratch_6_t {
          unsigned int reserved                       : MP2_MMU_SCRATCH_6_RESERVED_SIZE;
     } mp2_mmu_scratch_6_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mmu_scratch_6_t {
          unsigned int reserved                       : MP2_MMU_SCRATCH_6_RESERVED_SIZE;
     } mp2_mmu_scratch_6_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mmu_scratch_6_t f;
} mp2_mmu_scratch_6_u;


/*
 * MP2_MMU_SCRATCH_7 struct
 */

#define MP2_MMU_SCRATCH_7_REG_SIZE     32
#define MP2_MMU_SCRATCH_7_RESERVED_SIZE 32

#define MP2_MMU_SCRATCH_7_RESERVED_SHIFT 0

#define MP2_MMU_SCRATCH_7_RESERVED_MASK 0xffffffff

#define MP2_MMU_SCRATCH_7_MASK \
     (MP2_MMU_SCRATCH_7_RESERVED_MASK)

#define MP2_MMU_SCRATCH_7_DEFAULT      0x00000000

#define MP2_MMU_SCRATCH_7_GET_RESERVED(mp2_mmu_scratch_7) \
     ((mp2_mmu_scratch_7 & MP2_MMU_SCRATCH_7_RESERVED_MASK) >> MP2_MMU_SCRATCH_7_RESERVED_SHIFT)

#define MP2_MMU_SCRATCH_7_SET_RESERVED(mp2_mmu_scratch_7_reg, reserved) \
     mp2_mmu_scratch_7_reg = (mp2_mmu_scratch_7_reg & ~MP2_MMU_SCRATCH_7_RESERVED_MASK) | (reserved << MP2_MMU_SCRATCH_7_RESERVED_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_mmu_scratch_7_t {
          unsigned int reserved                       : MP2_MMU_SCRATCH_7_RESERVED_SIZE;
     } mp2_mmu_scratch_7_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_mmu_scratch_7_t {
          unsigned int reserved                       : MP2_MMU_SCRATCH_7_RESERVED_SIZE;
     } mp2_mmu_scratch_7_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_mmu_scratch_7_t f;
} mp2_mmu_scratch_7_u;


/*
 * MP2_PMI_INITID_CONFIG struct
 */

#define MP2_PMI_INITID_CONFIG_REG_SIZE 32
#define MP2_PMI_INITID_CONFIG_DISABLE_PMI_SIZE 1
#define MP2_PMI_INITID_CONFIG_ENABLE_ALL_SIZE 1

#define MP2_PMI_INITID_CONFIG_DISABLE_PMI_SHIFT 0
#define MP2_PMI_INITID_CONFIG_ENABLE_ALL_SHIFT 1

#define MP2_PMI_INITID_CONFIG_DISABLE_PMI_MASK 0x1
#define MP2_PMI_INITID_CONFIG_ENABLE_ALL_MASK 0x2

#define MP2_PMI_INITID_CONFIG_MASK \
     (MP2_PMI_INITID_CONFIG_DISABLE_PMI_MASK | \
      MP2_PMI_INITID_CONFIG_ENABLE_ALL_MASK)

#define MP2_PMI_INITID_CONFIG_DEFAULT  0x00000002

#define MP2_PMI_INITID_CONFIG_GET_DISABLE_PMI(mp2_pmi_initid_config) \
     ((mp2_pmi_initid_config & MP2_PMI_INITID_CONFIG_DISABLE_PMI_MASK) >> MP2_PMI_INITID_CONFIG_DISABLE_PMI_SHIFT)
#define MP2_PMI_INITID_CONFIG_GET_ENABLE_ALL(mp2_pmi_initid_config) \
     ((mp2_pmi_initid_config & MP2_PMI_INITID_CONFIG_ENABLE_ALL_MASK) >> MP2_PMI_INITID_CONFIG_ENABLE_ALL_SHIFT)

#define MP2_PMI_INITID_CONFIG_SET_DISABLE_PMI(mp2_pmi_initid_config_reg, disable_pmi) \
     mp2_pmi_initid_config_reg = (mp2_pmi_initid_config_reg & ~MP2_PMI_INITID_CONFIG_DISABLE_PMI_MASK) | (disable_pmi << MP2_PMI_INITID_CONFIG_DISABLE_PMI_SHIFT)
#define MP2_PMI_INITID_CONFIG_SET_ENABLE_ALL(mp2_pmi_initid_config_reg, enable_all) \
     mp2_pmi_initid_config_reg = (mp2_pmi_initid_config_reg & ~MP2_PMI_INITID_CONFIG_ENABLE_ALL_MASK) | (enable_all << MP2_PMI_INITID_CONFIG_ENABLE_ALL_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_initid_config_t {
          unsigned int disable_pmi                    : MP2_PMI_INITID_CONFIG_DISABLE_PMI_SIZE;
          unsigned int enable_all                     : MP2_PMI_INITID_CONFIG_ENABLE_ALL_SIZE;
          unsigned int                                : 30;
     } mp2_pmi_initid_config_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_initid_config_t {
          unsigned int                                : 30;
          unsigned int enable_all                     : MP2_PMI_INITID_CONFIG_ENABLE_ALL_SIZE;
          unsigned int disable_pmi                    : MP2_PMI_INITID_CONFIG_DISABLE_PMI_SIZE;
     } mp2_pmi_initid_config_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_initid_config_t f;
} mp2_pmi_initid_config_u;


/*
 * MP2_PMI_INITID_0 struct
 */

#define MP2_PMI_INITID_0_REG_SIZE      32
#define MP2_PMI_INITID_0_INITID_SIZE   10
#define MP2_PMI_INITID_0_VALID_SIZE    1

#define MP2_PMI_INITID_0_INITID_SHIFT  0
#define MP2_PMI_INITID_0_VALID_SHIFT   16

#define MP2_PMI_INITID_0_INITID_MASK   0x3ff
#define MP2_PMI_INITID_0_VALID_MASK    0x10000

#define MP2_PMI_INITID_0_MASK \
     (MP2_PMI_INITID_0_INITID_MASK | \
      MP2_PMI_INITID_0_VALID_MASK)

#define MP2_PMI_INITID_0_DEFAULT       0x00000000

#define MP2_PMI_INITID_0_GET_INITID(mp2_pmi_initid_0) \
     ((mp2_pmi_initid_0 & MP2_PMI_INITID_0_INITID_MASK) >> MP2_PMI_INITID_0_INITID_SHIFT)
#define MP2_PMI_INITID_0_GET_VALID(mp2_pmi_initid_0) \
     ((mp2_pmi_initid_0 & MP2_PMI_INITID_0_VALID_MASK) >> MP2_PMI_INITID_0_VALID_SHIFT)

#define MP2_PMI_INITID_0_SET_INITID(mp2_pmi_initid_0_reg, initid) \
     mp2_pmi_initid_0_reg = (mp2_pmi_initid_0_reg & ~MP2_PMI_INITID_0_INITID_MASK) | (initid << MP2_PMI_INITID_0_INITID_SHIFT)
#define MP2_PMI_INITID_0_SET_VALID(mp2_pmi_initid_0_reg, valid) \
     mp2_pmi_initid_0_reg = (mp2_pmi_initid_0_reg & ~MP2_PMI_INITID_0_VALID_MASK) | (valid << MP2_PMI_INITID_0_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_initid_0_t {
          unsigned int initid                         : MP2_PMI_INITID_0_INITID_SIZE;
          unsigned int                                : 6;
          unsigned int valid                          : MP2_PMI_INITID_0_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_pmi_initid_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_initid_0_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_PMI_INITID_0_VALID_SIZE;
          unsigned int                                : 6;
          unsigned int initid                         : MP2_PMI_INITID_0_INITID_SIZE;
     } mp2_pmi_initid_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_initid_0_t f;
} mp2_pmi_initid_0_u;


/*
 * MP2_PMI_INITID_1 struct
 */

#define MP2_PMI_INITID_1_REG_SIZE      32
#define MP2_PMI_INITID_1_INITID_SIZE   10
#define MP2_PMI_INITID_1_VALID_SIZE    1

#define MP2_PMI_INITID_1_INITID_SHIFT  0
#define MP2_PMI_INITID_1_VALID_SHIFT   16

#define MP2_PMI_INITID_1_INITID_MASK   0x3ff
#define MP2_PMI_INITID_1_VALID_MASK    0x10000

#define MP2_PMI_INITID_1_MASK \
     (MP2_PMI_INITID_1_INITID_MASK | \
      MP2_PMI_INITID_1_VALID_MASK)

#define MP2_PMI_INITID_1_DEFAULT       0x00000000

#define MP2_PMI_INITID_1_GET_INITID(mp2_pmi_initid_1) \
     ((mp2_pmi_initid_1 & MP2_PMI_INITID_1_INITID_MASK) >> MP2_PMI_INITID_1_INITID_SHIFT)
#define MP2_PMI_INITID_1_GET_VALID(mp2_pmi_initid_1) \
     ((mp2_pmi_initid_1 & MP2_PMI_INITID_1_VALID_MASK) >> MP2_PMI_INITID_1_VALID_SHIFT)

#define MP2_PMI_INITID_1_SET_INITID(mp2_pmi_initid_1_reg, initid) \
     mp2_pmi_initid_1_reg = (mp2_pmi_initid_1_reg & ~MP2_PMI_INITID_1_INITID_MASK) | (initid << MP2_PMI_INITID_1_INITID_SHIFT)
#define MP2_PMI_INITID_1_SET_VALID(mp2_pmi_initid_1_reg, valid) \
     mp2_pmi_initid_1_reg = (mp2_pmi_initid_1_reg & ~MP2_PMI_INITID_1_VALID_MASK) | (valid << MP2_PMI_INITID_1_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_initid_1_t {
          unsigned int initid                         : MP2_PMI_INITID_1_INITID_SIZE;
          unsigned int                                : 6;
          unsigned int valid                          : MP2_PMI_INITID_1_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_pmi_initid_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_initid_1_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_PMI_INITID_1_VALID_SIZE;
          unsigned int                                : 6;
          unsigned int initid                         : MP2_PMI_INITID_1_INITID_SIZE;
     } mp2_pmi_initid_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_initid_1_t f;
} mp2_pmi_initid_1_u;


/*
 * MP2_PMI_INITID_2 struct
 */

#define MP2_PMI_INITID_2_REG_SIZE      32
#define MP2_PMI_INITID_2_INITID_SIZE   10
#define MP2_PMI_INITID_2_VALID_SIZE    1

#define MP2_PMI_INITID_2_INITID_SHIFT  0
#define MP2_PMI_INITID_2_VALID_SHIFT   16

#define MP2_PMI_INITID_2_INITID_MASK   0x3ff
#define MP2_PMI_INITID_2_VALID_MASK    0x10000

#define MP2_PMI_INITID_2_MASK \
     (MP2_PMI_INITID_2_INITID_MASK | \
      MP2_PMI_INITID_2_VALID_MASK)

#define MP2_PMI_INITID_2_DEFAULT       0x00000000

#define MP2_PMI_INITID_2_GET_INITID(mp2_pmi_initid_2) \
     ((mp2_pmi_initid_2 & MP2_PMI_INITID_2_INITID_MASK) >> MP2_PMI_INITID_2_INITID_SHIFT)
#define MP2_PMI_INITID_2_GET_VALID(mp2_pmi_initid_2) \
     ((mp2_pmi_initid_2 & MP2_PMI_INITID_2_VALID_MASK) >> MP2_PMI_INITID_2_VALID_SHIFT)

#define MP2_PMI_INITID_2_SET_INITID(mp2_pmi_initid_2_reg, initid) \
     mp2_pmi_initid_2_reg = (mp2_pmi_initid_2_reg & ~MP2_PMI_INITID_2_INITID_MASK) | (initid << MP2_PMI_INITID_2_INITID_SHIFT)
#define MP2_PMI_INITID_2_SET_VALID(mp2_pmi_initid_2_reg, valid) \
     mp2_pmi_initid_2_reg = (mp2_pmi_initid_2_reg & ~MP2_PMI_INITID_2_VALID_MASK) | (valid << MP2_PMI_INITID_2_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_initid_2_t {
          unsigned int initid                         : MP2_PMI_INITID_2_INITID_SIZE;
          unsigned int                                : 6;
          unsigned int valid                          : MP2_PMI_INITID_2_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_pmi_initid_2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_initid_2_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_PMI_INITID_2_VALID_SIZE;
          unsigned int                                : 6;
          unsigned int initid                         : MP2_PMI_INITID_2_INITID_SIZE;
     } mp2_pmi_initid_2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_initid_2_t f;
} mp2_pmi_initid_2_u;


/*
 * MP2_PMI_INITID_3 struct
 */

#define MP2_PMI_INITID_3_REG_SIZE      32
#define MP2_PMI_INITID_3_INITID_SIZE   10
#define MP2_PMI_INITID_3_VALID_SIZE    1

#define MP2_PMI_INITID_3_INITID_SHIFT  0
#define MP2_PMI_INITID_3_VALID_SHIFT   16

#define MP2_PMI_INITID_3_INITID_MASK   0x3ff
#define MP2_PMI_INITID_3_VALID_MASK    0x10000

#define MP2_PMI_INITID_3_MASK \
     (MP2_PMI_INITID_3_INITID_MASK | \
      MP2_PMI_INITID_3_VALID_MASK)

#define MP2_PMI_INITID_3_DEFAULT       0x00000000

#define MP2_PMI_INITID_3_GET_INITID(mp2_pmi_initid_3) \
     ((mp2_pmi_initid_3 & MP2_PMI_INITID_3_INITID_MASK) >> MP2_PMI_INITID_3_INITID_SHIFT)
#define MP2_PMI_INITID_3_GET_VALID(mp2_pmi_initid_3) \
     ((mp2_pmi_initid_3 & MP2_PMI_INITID_3_VALID_MASK) >> MP2_PMI_INITID_3_VALID_SHIFT)

#define MP2_PMI_INITID_3_SET_INITID(mp2_pmi_initid_3_reg, initid) \
     mp2_pmi_initid_3_reg = (mp2_pmi_initid_3_reg & ~MP2_PMI_INITID_3_INITID_MASK) | (initid << MP2_PMI_INITID_3_INITID_SHIFT)
#define MP2_PMI_INITID_3_SET_VALID(mp2_pmi_initid_3_reg, valid) \
     mp2_pmi_initid_3_reg = (mp2_pmi_initid_3_reg & ~MP2_PMI_INITID_3_VALID_MASK) | (valid << MP2_PMI_INITID_3_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_initid_3_t {
          unsigned int initid                         : MP2_PMI_INITID_3_INITID_SIZE;
          unsigned int                                : 6;
          unsigned int valid                          : MP2_PMI_INITID_3_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_pmi_initid_3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_initid_3_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_PMI_INITID_3_VALID_SIZE;
          unsigned int                                : 6;
          unsigned int initid                         : MP2_PMI_INITID_3_INITID_SIZE;
     } mp2_pmi_initid_3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_initid_3_t f;
} mp2_pmi_initid_3_u;


/*
 * MP2_PMI_INITID_4 struct
 */

#define MP2_PMI_INITID_4_REG_SIZE      32
#define MP2_PMI_INITID_4_INITID_SIZE   10
#define MP2_PMI_INITID_4_VALID_SIZE    1

#define MP2_PMI_INITID_4_INITID_SHIFT  0
#define MP2_PMI_INITID_4_VALID_SHIFT   16

#define MP2_PMI_INITID_4_INITID_MASK   0x3ff
#define MP2_PMI_INITID_4_VALID_MASK    0x10000

#define MP2_PMI_INITID_4_MASK \
     (MP2_PMI_INITID_4_INITID_MASK | \
      MP2_PMI_INITID_4_VALID_MASK)

#define MP2_PMI_INITID_4_DEFAULT       0x00000000

#define MP2_PMI_INITID_4_GET_INITID(mp2_pmi_initid_4) \
     ((mp2_pmi_initid_4 & MP2_PMI_INITID_4_INITID_MASK) >> MP2_PMI_INITID_4_INITID_SHIFT)
#define MP2_PMI_INITID_4_GET_VALID(mp2_pmi_initid_4) \
     ((mp2_pmi_initid_4 & MP2_PMI_INITID_4_VALID_MASK) >> MP2_PMI_INITID_4_VALID_SHIFT)

#define MP2_PMI_INITID_4_SET_INITID(mp2_pmi_initid_4_reg, initid) \
     mp2_pmi_initid_4_reg = (mp2_pmi_initid_4_reg & ~MP2_PMI_INITID_4_INITID_MASK) | (initid << MP2_PMI_INITID_4_INITID_SHIFT)
#define MP2_PMI_INITID_4_SET_VALID(mp2_pmi_initid_4_reg, valid) \
     mp2_pmi_initid_4_reg = (mp2_pmi_initid_4_reg & ~MP2_PMI_INITID_4_VALID_MASK) | (valid << MP2_PMI_INITID_4_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_initid_4_t {
          unsigned int initid                         : MP2_PMI_INITID_4_INITID_SIZE;
          unsigned int                                : 6;
          unsigned int valid                          : MP2_PMI_INITID_4_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_pmi_initid_4_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_initid_4_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_PMI_INITID_4_VALID_SIZE;
          unsigned int                                : 6;
          unsigned int initid                         : MP2_PMI_INITID_4_INITID_SIZE;
     } mp2_pmi_initid_4_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_initid_4_t f;
} mp2_pmi_initid_4_u;


/*
 * MP2_PMI_INITID_5 struct
 */

#define MP2_PMI_INITID_5_REG_SIZE      32
#define MP2_PMI_INITID_5_INITID_SIZE   10
#define MP2_PMI_INITID_5_VALID_SIZE    1

#define MP2_PMI_INITID_5_INITID_SHIFT  0
#define MP2_PMI_INITID_5_VALID_SHIFT   16

#define MP2_PMI_INITID_5_INITID_MASK   0x3ff
#define MP2_PMI_INITID_5_VALID_MASK    0x10000

#define MP2_PMI_INITID_5_MASK \
     (MP2_PMI_INITID_5_INITID_MASK | \
      MP2_PMI_INITID_5_VALID_MASK)

#define MP2_PMI_INITID_5_DEFAULT       0x00000000

#define MP2_PMI_INITID_5_GET_INITID(mp2_pmi_initid_5) \
     ((mp2_pmi_initid_5 & MP2_PMI_INITID_5_INITID_MASK) >> MP2_PMI_INITID_5_INITID_SHIFT)
#define MP2_PMI_INITID_5_GET_VALID(mp2_pmi_initid_5) \
     ((mp2_pmi_initid_5 & MP2_PMI_INITID_5_VALID_MASK) >> MP2_PMI_INITID_5_VALID_SHIFT)

#define MP2_PMI_INITID_5_SET_INITID(mp2_pmi_initid_5_reg, initid) \
     mp2_pmi_initid_5_reg = (mp2_pmi_initid_5_reg & ~MP2_PMI_INITID_5_INITID_MASK) | (initid << MP2_PMI_INITID_5_INITID_SHIFT)
#define MP2_PMI_INITID_5_SET_VALID(mp2_pmi_initid_5_reg, valid) \
     mp2_pmi_initid_5_reg = (mp2_pmi_initid_5_reg & ~MP2_PMI_INITID_5_VALID_MASK) | (valid << MP2_PMI_INITID_5_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_initid_5_t {
          unsigned int initid                         : MP2_PMI_INITID_5_INITID_SIZE;
          unsigned int                                : 6;
          unsigned int valid                          : MP2_PMI_INITID_5_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_pmi_initid_5_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_initid_5_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_PMI_INITID_5_VALID_SIZE;
          unsigned int                                : 6;
          unsigned int initid                         : MP2_PMI_INITID_5_INITID_SIZE;
     } mp2_pmi_initid_5_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_initid_5_t f;
} mp2_pmi_initid_5_u;


/*
 * MP2_PMI_INITID_6 struct
 */

#define MP2_PMI_INITID_6_REG_SIZE      32
#define MP2_PMI_INITID_6_INITID_SIZE   10
#define MP2_PMI_INITID_6_VALID_SIZE    1

#define MP2_PMI_INITID_6_INITID_SHIFT  0
#define MP2_PMI_INITID_6_VALID_SHIFT   16

#define MP2_PMI_INITID_6_INITID_MASK   0x3ff
#define MP2_PMI_INITID_6_VALID_MASK    0x10000

#define MP2_PMI_INITID_6_MASK \
     (MP2_PMI_INITID_6_INITID_MASK | \
      MP2_PMI_INITID_6_VALID_MASK)

#define MP2_PMI_INITID_6_DEFAULT       0x00000000

#define MP2_PMI_INITID_6_GET_INITID(mp2_pmi_initid_6) \
     ((mp2_pmi_initid_6 & MP2_PMI_INITID_6_INITID_MASK) >> MP2_PMI_INITID_6_INITID_SHIFT)
#define MP2_PMI_INITID_6_GET_VALID(mp2_pmi_initid_6) \
     ((mp2_pmi_initid_6 & MP2_PMI_INITID_6_VALID_MASK) >> MP2_PMI_INITID_6_VALID_SHIFT)

#define MP2_PMI_INITID_6_SET_INITID(mp2_pmi_initid_6_reg, initid) \
     mp2_pmi_initid_6_reg = (mp2_pmi_initid_6_reg & ~MP2_PMI_INITID_6_INITID_MASK) | (initid << MP2_PMI_INITID_6_INITID_SHIFT)
#define MP2_PMI_INITID_6_SET_VALID(mp2_pmi_initid_6_reg, valid) \
     mp2_pmi_initid_6_reg = (mp2_pmi_initid_6_reg & ~MP2_PMI_INITID_6_VALID_MASK) | (valid << MP2_PMI_INITID_6_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_initid_6_t {
          unsigned int initid                         : MP2_PMI_INITID_6_INITID_SIZE;
          unsigned int                                : 6;
          unsigned int valid                          : MP2_PMI_INITID_6_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_pmi_initid_6_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_initid_6_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_PMI_INITID_6_VALID_SIZE;
          unsigned int                                : 6;
          unsigned int initid                         : MP2_PMI_INITID_6_INITID_SIZE;
     } mp2_pmi_initid_6_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_initid_6_t f;
} mp2_pmi_initid_6_u;


/*
 * MP2_PMI_INITID_7 struct
 */

#define MP2_PMI_INITID_7_REG_SIZE      32
#define MP2_PMI_INITID_7_INITID_SIZE   10
#define MP2_PMI_INITID_7_VALID_SIZE    1

#define MP2_PMI_INITID_7_INITID_SHIFT  0
#define MP2_PMI_INITID_7_VALID_SHIFT   16

#define MP2_PMI_INITID_7_INITID_MASK   0x3ff
#define MP2_PMI_INITID_7_VALID_MASK    0x10000

#define MP2_PMI_INITID_7_MASK \
     (MP2_PMI_INITID_7_INITID_MASK | \
      MP2_PMI_INITID_7_VALID_MASK)

#define MP2_PMI_INITID_7_DEFAULT       0x00000000

#define MP2_PMI_INITID_7_GET_INITID(mp2_pmi_initid_7) \
     ((mp2_pmi_initid_7 & MP2_PMI_INITID_7_INITID_MASK) >> MP2_PMI_INITID_7_INITID_SHIFT)
#define MP2_PMI_INITID_7_GET_VALID(mp2_pmi_initid_7) \
     ((mp2_pmi_initid_7 & MP2_PMI_INITID_7_VALID_MASK) >> MP2_PMI_INITID_7_VALID_SHIFT)

#define MP2_PMI_INITID_7_SET_INITID(mp2_pmi_initid_7_reg, initid) \
     mp2_pmi_initid_7_reg = (mp2_pmi_initid_7_reg & ~MP2_PMI_INITID_7_INITID_MASK) | (initid << MP2_PMI_INITID_7_INITID_SHIFT)
#define MP2_PMI_INITID_7_SET_VALID(mp2_pmi_initid_7_reg, valid) \
     mp2_pmi_initid_7_reg = (mp2_pmi_initid_7_reg & ~MP2_PMI_INITID_7_VALID_MASK) | (valid << MP2_PMI_INITID_7_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_initid_7_t {
          unsigned int initid                         : MP2_PMI_INITID_7_INITID_SIZE;
          unsigned int                                : 6;
          unsigned int valid                          : MP2_PMI_INITID_7_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_pmi_initid_7_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_initid_7_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_PMI_INITID_7_VALID_SIZE;
          unsigned int                                : 6;
          unsigned int initid                         : MP2_PMI_INITID_7_INITID_SIZE;
     } mp2_pmi_initid_7_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_initid_7_t f;
} mp2_pmi_initid_7_u;


/*
 * MP2_PMI_INITID_8 struct
 */

#define MP2_PMI_INITID_8_REG_SIZE      32
#define MP2_PMI_INITID_8_INITID_SIZE   10
#define MP2_PMI_INITID_8_VALID_SIZE    1

#define MP2_PMI_INITID_8_INITID_SHIFT  0
#define MP2_PMI_INITID_8_VALID_SHIFT   16

#define MP2_PMI_INITID_8_INITID_MASK   0x3ff
#define MP2_PMI_INITID_8_VALID_MASK    0x10000

#define MP2_PMI_INITID_8_MASK \
     (MP2_PMI_INITID_8_INITID_MASK | \
      MP2_PMI_INITID_8_VALID_MASK)

#define MP2_PMI_INITID_8_DEFAULT       0x00000000

#define MP2_PMI_INITID_8_GET_INITID(mp2_pmi_initid_8) \
     ((mp2_pmi_initid_8 & MP2_PMI_INITID_8_INITID_MASK) >> MP2_PMI_INITID_8_INITID_SHIFT)
#define MP2_PMI_INITID_8_GET_VALID(mp2_pmi_initid_8) \
     ((mp2_pmi_initid_8 & MP2_PMI_INITID_8_VALID_MASK) >> MP2_PMI_INITID_8_VALID_SHIFT)

#define MP2_PMI_INITID_8_SET_INITID(mp2_pmi_initid_8_reg, initid) \
     mp2_pmi_initid_8_reg = (mp2_pmi_initid_8_reg & ~MP2_PMI_INITID_8_INITID_MASK) | (initid << MP2_PMI_INITID_8_INITID_SHIFT)
#define MP2_PMI_INITID_8_SET_VALID(mp2_pmi_initid_8_reg, valid) \
     mp2_pmi_initid_8_reg = (mp2_pmi_initid_8_reg & ~MP2_PMI_INITID_8_VALID_MASK) | (valid << MP2_PMI_INITID_8_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_initid_8_t {
          unsigned int initid                         : MP2_PMI_INITID_8_INITID_SIZE;
          unsigned int                                : 6;
          unsigned int valid                          : MP2_PMI_INITID_8_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_pmi_initid_8_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_initid_8_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_PMI_INITID_8_VALID_SIZE;
          unsigned int                                : 6;
          unsigned int initid                         : MP2_PMI_INITID_8_INITID_SIZE;
     } mp2_pmi_initid_8_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_initid_8_t f;
} mp2_pmi_initid_8_u;


/*
 * MP2_PMI_INITID_9 struct
 */

#define MP2_PMI_INITID_9_REG_SIZE      32
#define MP2_PMI_INITID_9_INITID_SIZE   10
#define MP2_PMI_INITID_9_VALID_SIZE    1

#define MP2_PMI_INITID_9_INITID_SHIFT  0
#define MP2_PMI_INITID_9_VALID_SHIFT   16

#define MP2_PMI_INITID_9_INITID_MASK   0x3ff
#define MP2_PMI_INITID_9_VALID_MASK    0x10000

#define MP2_PMI_INITID_9_MASK \
     (MP2_PMI_INITID_9_INITID_MASK | \
      MP2_PMI_INITID_9_VALID_MASK)

#define MP2_PMI_INITID_9_DEFAULT       0x00000000

#define MP2_PMI_INITID_9_GET_INITID(mp2_pmi_initid_9) \
     ((mp2_pmi_initid_9 & MP2_PMI_INITID_9_INITID_MASK) >> MP2_PMI_INITID_9_INITID_SHIFT)
#define MP2_PMI_INITID_9_GET_VALID(mp2_pmi_initid_9) \
     ((mp2_pmi_initid_9 & MP2_PMI_INITID_9_VALID_MASK) >> MP2_PMI_INITID_9_VALID_SHIFT)

#define MP2_PMI_INITID_9_SET_INITID(mp2_pmi_initid_9_reg, initid) \
     mp2_pmi_initid_9_reg = (mp2_pmi_initid_9_reg & ~MP2_PMI_INITID_9_INITID_MASK) | (initid << MP2_PMI_INITID_9_INITID_SHIFT)
#define MP2_PMI_INITID_9_SET_VALID(mp2_pmi_initid_9_reg, valid) \
     mp2_pmi_initid_9_reg = (mp2_pmi_initid_9_reg & ~MP2_PMI_INITID_9_VALID_MASK) | (valid << MP2_PMI_INITID_9_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_initid_9_t {
          unsigned int initid                         : MP2_PMI_INITID_9_INITID_SIZE;
          unsigned int                                : 6;
          unsigned int valid                          : MP2_PMI_INITID_9_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_pmi_initid_9_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_initid_9_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_PMI_INITID_9_VALID_SIZE;
          unsigned int                                : 6;
          unsigned int initid                         : MP2_PMI_INITID_9_INITID_SIZE;
     } mp2_pmi_initid_9_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_initid_9_t f;
} mp2_pmi_initid_9_u;


/*
 * MP2_PMI_INITID_10 struct
 */

#define MP2_PMI_INITID_10_REG_SIZE     32
#define MP2_PMI_INITID_10_INITID_SIZE  10
#define MP2_PMI_INITID_10_VALID_SIZE   1

#define MP2_PMI_INITID_10_INITID_SHIFT 0
#define MP2_PMI_INITID_10_VALID_SHIFT  16

#define MP2_PMI_INITID_10_INITID_MASK  0x3ff
#define MP2_PMI_INITID_10_VALID_MASK   0x10000

#define MP2_PMI_INITID_10_MASK \
     (MP2_PMI_INITID_10_INITID_MASK | \
      MP2_PMI_INITID_10_VALID_MASK)

#define MP2_PMI_INITID_10_DEFAULT      0x00000000

#define MP2_PMI_INITID_10_GET_INITID(mp2_pmi_initid_10) \
     ((mp2_pmi_initid_10 & MP2_PMI_INITID_10_INITID_MASK) >> MP2_PMI_INITID_10_INITID_SHIFT)
#define MP2_PMI_INITID_10_GET_VALID(mp2_pmi_initid_10) \
     ((mp2_pmi_initid_10 & MP2_PMI_INITID_10_VALID_MASK) >> MP2_PMI_INITID_10_VALID_SHIFT)

#define MP2_PMI_INITID_10_SET_INITID(mp2_pmi_initid_10_reg, initid) \
     mp2_pmi_initid_10_reg = (mp2_pmi_initid_10_reg & ~MP2_PMI_INITID_10_INITID_MASK) | (initid << MP2_PMI_INITID_10_INITID_SHIFT)
#define MP2_PMI_INITID_10_SET_VALID(mp2_pmi_initid_10_reg, valid) \
     mp2_pmi_initid_10_reg = (mp2_pmi_initid_10_reg & ~MP2_PMI_INITID_10_VALID_MASK) | (valid << MP2_PMI_INITID_10_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_initid_10_t {
          unsigned int initid                         : MP2_PMI_INITID_10_INITID_SIZE;
          unsigned int                                : 6;
          unsigned int valid                          : MP2_PMI_INITID_10_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_pmi_initid_10_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_initid_10_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_PMI_INITID_10_VALID_SIZE;
          unsigned int                                : 6;
          unsigned int initid                         : MP2_PMI_INITID_10_INITID_SIZE;
     } mp2_pmi_initid_10_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_initid_10_t f;
} mp2_pmi_initid_10_u;


/*
 * MP2_PMI_INITID_11 struct
 */

#define MP2_PMI_INITID_11_REG_SIZE     32
#define MP2_PMI_INITID_11_INITID_SIZE  10
#define MP2_PMI_INITID_11_VALID_SIZE   1

#define MP2_PMI_INITID_11_INITID_SHIFT 0
#define MP2_PMI_INITID_11_VALID_SHIFT  16

#define MP2_PMI_INITID_11_INITID_MASK  0x3ff
#define MP2_PMI_INITID_11_VALID_MASK   0x10000

#define MP2_PMI_INITID_11_MASK \
     (MP2_PMI_INITID_11_INITID_MASK | \
      MP2_PMI_INITID_11_VALID_MASK)

#define MP2_PMI_INITID_11_DEFAULT      0x00000000

#define MP2_PMI_INITID_11_GET_INITID(mp2_pmi_initid_11) \
     ((mp2_pmi_initid_11 & MP2_PMI_INITID_11_INITID_MASK) >> MP2_PMI_INITID_11_INITID_SHIFT)
#define MP2_PMI_INITID_11_GET_VALID(mp2_pmi_initid_11) \
     ((mp2_pmi_initid_11 & MP2_PMI_INITID_11_VALID_MASK) >> MP2_PMI_INITID_11_VALID_SHIFT)

#define MP2_PMI_INITID_11_SET_INITID(mp2_pmi_initid_11_reg, initid) \
     mp2_pmi_initid_11_reg = (mp2_pmi_initid_11_reg & ~MP2_PMI_INITID_11_INITID_MASK) | (initid << MP2_PMI_INITID_11_INITID_SHIFT)
#define MP2_PMI_INITID_11_SET_VALID(mp2_pmi_initid_11_reg, valid) \
     mp2_pmi_initid_11_reg = (mp2_pmi_initid_11_reg & ~MP2_PMI_INITID_11_VALID_MASK) | (valid << MP2_PMI_INITID_11_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_initid_11_t {
          unsigned int initid                         : MP2_PMI_INITID_11_INITID_SIZE;
          unsigned int                                : 6;
          unsigned int valid                          : MP2_PMI_INITID_11_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_pmi_initid_11_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_initid_11_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_PMI_INITID_11_VALID_SIZE;
          unsigned int                                : 6;
          unsigned int initid                         : MP2_PMI_INITID_11_INITID_SIZE;
     } mp2_pmi_initid_11_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_initid_11_t f;
} mp2_pmi_initid_11_u;


/*
 * MP2_PMI_INITID_12 struct
 */

#define MP2_PMI_INITID_12_REG_SIZE     32
#define MP2_PMI_INITID_12_INITID_SIZE  10
#define MP2_PMI_INITID_12_VALID_SIZE   1

#define MP2_PMI_INITID_12_INITID_SHIFT 0
#define MP2_PMI_INITID_12_VALID_SHIFT  16

#define MP2_PMI_INITID_12_INITID_MASK  0x3ff
#define MP2_PMI_INITID_12_VALID_MASK   0x10000

#define MP2_PMI_INITID_12_MASK \
     (MP2_PMI_INITID_12_INITID_MASK | \
      MP2_PMI_INITID_12_VALID_MASK)

#define MP2_PMI_INITID_12_DEFAULT      0x00000000

#define MP2_PMI_INITID_12_GET_INITID(mp2_pmi_initid_12) \
     ((mp2_pmi_initid_12 & MP2_PMI_INITID_12_INITID_MASK) >> MP2_PMI_INITID_12_INITID_SHIFT)
#define MP2_PMI_INITID_12_GET_VALID(mp2_pmi_initid_12) \
     ((mp2_pmi_initid_12 & MP2_PMI_INITID_12_VALID_MASK) >> MP2_PMI_INITID_12_VALID_SHIFT)

#define MP2_PMI_INITID_12_SET_INITID(mp2_pmi_initid_12_reg, initid) \
     mp2_pmi_initid_12_reg = (mp2_pmi_initid_12_reg & ~MP2_PMI_INITID_12_INITID_MASK) | (initid << MP2_PMI_INITID_12_INITID_SHIFT)
#define MP2_PMI_INITID_12_SET_VALID(mp2_pmi_initid_12_reg, valid) \
     mp2_pmi_initid_12_reg = (mp2_pmi_initid_12_reg & ~MP2_PMI_INITID_12_VALID_MASK) | (valid << MP2_PMI_INITID_12_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_initid_12_t {
          unsigned int initid                         : MP2_PMI_INITID_12_INITID_SIZE;
          unsigned int                                : 6;
          unsigned int valid                          : MP2_PMI_INITID_12_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_pmi_initid_12_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_initid_12_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_PMI_INITID_12_VALID_SIZE;
          unsigned int                                : 6;
          unsigned int initid                         : MP2_PMI_INITID_12_INITID_SIZE;
     } mp2_pmi_initid_12_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_initid_12_t f;
} mp2_pmi_initid_12_u;


/*
 * MP2_PMI_INITID_13 struct
 */

#define MP2_PMI_INITID_13_REG_SIZE     32
#define MP2_PMI_INITID_13_INITID_SIZE  10
#define MP2_PMI_INITID_13_VALID_SIZE   1

#define MP2_PMI_INITID_13_INITID_SHIFT 0
#define MP2_PMI_INITID_13_VALID_SHIFT  16

#define MP2_PMI_INITID_13_INITID_MASK  0x3ff
#define MP2_PMI_INITID_13_VALID_MASK   0x10000

#define MP2_PMI_INITID_13_MASK \
     (MP2_PMI_INITID_13_INITID_MASK | \
      MP2_PMI_INITID_13_VALID_MASK)

#define MP2_PMI_INITID_13_DEFAULT      0x00000000

#define MP2_PMI_INITID_13_GET_INITID(mp2_pmi_initid_13) \
     ((mp2_pmi_initid_13 & MP2_PMI_INITID_13_INITID_MASK) >> MP2_PMI_INITID_13_INITID_SHIFT)
#define MP2_PMI_INITID_13_GET_VALID(mp2_pmi_initid_13) \
     ((mp2_pmi_initid_13 & MP2_PMI_INITID_13_VALID_MASK) >> MP2_PMI_INITID_13_VALID_SHIFT)

#define MP2_PMI_INITID_13_SET_INITID(mp2_pmi_initid_13_reg, initid) \
     mp2_pmi_initid_13_reg = (mp2_pmi_initid_13_reg & ~MP2_PMI_INITID_13_INITID_MASK) | (initid << MP2_PMI_INITID_13_INITID_SHIFT)
#define MP2_PMI_INITID_13_SET_VALID(mp2_pmi_initid_13_reg, valid) \
     mp2_pmi_initid_13_reg = (mp2_pmi_initid_13_reg & ~MP2_PMI_INITID_13_VALID_MASK) | (valid << MP2_PMI_INITID_13_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_initid_13_t {
          unsigned int initid                         : MP2_PMI_INITID_13_INITID_SIZE;
          unsigned int                                : 6;
          unsigned int valid                          : MP2_PMI_INITID_13_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_pmi_initid_13_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_initid_13_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_PMI_INITID_13_VALID_SIZE;
          unsigned int                                : 6;
          unsigned int initid                         : MP2_PMI_INITID_13_INITID_SIZE;
     } mp2_pmi_initid_13_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_initid_13_t f;
} mp2_pmi_initid_13_u;


/*
 * MP2_PMI_INITID_14 struct
 */

#define MP2_PMI_INITID_14_REG_SIZE     32
#define MP2_PMI_INITID_14_INITID_SIZE  10
#define MP2_PMI_INITID_14_VALID_SIZE   1

#define MP2_PMI_INITID_14_INITID_SHIFT 0
#define MP2_PMI_INITID_14_VALID_SHIFT  16

#define MP2_PMI_INITID_14_INITID_MASK  0x3ff
#define MP2_PMI_INITID_14_VALID_MASK   0x10000

#define MP2_PMI_INITID_14_MASK \
     (MP2_PMI_INITID_14_INITID_MASK | \
      MP2_PMI_INITID_14_VALID_MASK)

#define MP2_PMI_INITID_14_DEFAULT      0x00000000

#define MP2_PMI_INITID_14_GET_INITID(mp2_pmi_initid_14) \
     ((mp2_pmi_initid_14 & MP2_PMI_INITID_14_INITID_MASK) >> MP2_PMI_INITID_14_INITID_SHIFT)
#define MP2_PMI_INITID_14_GET_VALID(mp2_pmi_initid_14) \
     ((mp2_pmi_initid_14 & MP2_PMI_INITID_14_VALID_MASK) >> MP2_PMI_INITID_14_VALID_SHIFT)

#define MP2_PMI_INITID_14_SET_INITID(mp2_pmi_initid_14_reg, initid) \
     mp2_pmi_initid_14_reg = (mp2_pmi_initid_14_reg & ~MP2_PMI_INITID_14_INITID_MASK) | (initid << MP2_PMI_INITID_14_INITID_SHIFT)
#define MP2_PMI_INITID_14_SET_VALID(mp2_pmi_initid_14_reg, valid) \
     mp2_pmi_initid_14_reg = (mp2_pmi_initid_14_reg & ~MP2_PMI_INITID_14_VALID_MASK) | (valid << MP2_PMI_INITID_14_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_initid_14_t {
          unsigned int initid                         : MP2_PMI_INITID_14_INITID_SIZE;
          unsigned int                                : 6;
          unsigned int valid                          : MP2_PMI_INITID_14_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_pmi_initid_14_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_initid_14_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_PMI_INITID_14_VALID_SIZE;
          unsigned int                                : 6;
          unsigned int initid                         : MP2_PMI_INITID_14_INITID_SIZE;
     } mp2_pmi_initid_14_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_initid_14_t f;
} mp2_pmi_initid_14_u;


/*
 * MP2_PMI_INITID_15 struct
 */

#define MP2_PMI_INITID_15_REG_SIZE     32
#define MP2_PMI_INITID_15_INITID_SIZE  10
#define MP2_PMI_INITID_15_VALID_SIZE   1

#define MP2_PMI_INITID_15_INITID_SHIFT 0
#define MP2_PMI_INITID_15_VALID_SHIFT  16

#define MP2_PMI_INITID_15_INITID_MASK  0x3ff
#define MP2_PMI_INITID_15_VALID_MASK   0x10000

#define MP2_PMI_INITID_15_MASK \
     (MP2_PMI_INITID_15_INITID_MASK | \
      MP2_PMI_INITID_15_VALID_MASK)

#define MP2_PMI_INITID_15_DEFAULT      0x00000000

#define MP2_PMI_INITID_15_GET_INITID(mp2_pmi_initid_15) \
     ((mp2_pmi_initid_15 & MP2_PMI_INITID_15_INITID_MASK) >> MP2_PMI_INITID_15_INITID_SHIFT)
#define MP2_PMI_INITID_15_GET_VALID(mp2_pmi_initid_15) \
     ((mp2_pmi_initid_15 & MP2_PMI_INITID_15_VALID_MASK) >> MP2_PMI_INITID_15_VALID_SHIFT)

#define MP2_PMI_INITID_15_SET_INITID(mp2_pmi_initid_15_reg, initid) \
     mp2_pmi_initid_15_reg = (mp2_pmi_initid_15_reg & ~MP2_PMI_INITID_15_INITID_MASK) | (initid << MP2_PMI_INITID_15_INITID_SHIFT)
#define MP2_PMI_INITID_15_SET_VALID(mp2_pmi_initid_15_reg, valid) \
     mp2_pmi_initid_15_reg = (mp2_pmi_initid_15_reg & ~MP2_PMI_INITID_15_VALID_MASK) | (valid << MP2_PMI_INITID_15_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_initid_15_t {
          unsigned int initid                         : MP2_PMI_INITID_15_INITID_SIZE;
          unsigned int                                : 6;
          unsigned int valid                          : MP2_PMI_INITID_15_VALID_SIZE;
          unsigned int                                : 15;
     } mp2_pmi_initid_15_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_initid_15_t {
          unsigned int                                : 15;
          unsigned int valid                          : MP2_PMI_INITID_15_VALID_SIZE;
          unsigned int                                : 6;
          unsigned int initid                         : MP2_PMI_INITID_15_INITID_SIZE;
     } mp2_pmi_initid_15_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_initid_15_t f;
} mp2_pmi_initid_15_u;


/*
 * MP2_PMI_0_RELOAD struct
 */

#define MP2_PMI_0_RELOAD_REG_SIZE      32
#define MP2_PMI_0_RELOAD_PMI_PARAMETERS_SIZE 1

#define MP2_PMI_0_RELOAD_PMI_PARAMETERS_SHIFT 0

#define MP2_PMI_0_RELOAD_PMI_PARAMETERS_MASK 0x1

#define MP2_PMI_0_RELOAD_MASK \
     (MP2_PMI_0_RELOAD_PMI_PARAMETERS_MASK)

#define MP2_PMI_0_RELOAD_DEFAULT       0x00000000

#define MP2_PMI_0_RELOAD_GET_PMI_PARAMETERS(mp2_pmi_0_reload) \
     ((mp2_pmi_0_reload & MP2_PMI_0_RELOAD_PMI_PARAMETERS_MASK) >> MP2_PMI_0_RELOAD_PMI_PARAMETERS_SHIFT)

#define MP2_PMI_0_RELOAD_SET_PMI_PARAMETERS(mp2_pmi_0_reload_reg, pmi_parameters) \
     mp2_pmi_0_reload_reg = (mp2_pmi_0_reload_reg & ~MP2_PMI_0_RELOAD_PMI_PARAMETERS_MASK) | (pmi_parameters << MP2_PMI_0_RELOAD_PMI_PARAMETERS_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_0_reload_t {
          unsigned int pmi_parameters                 : MP2_PMI_0_RELOAD_PMI_PARAMETERS_SIZE;
          unsigned int                                : 31;
     } mp2_pmi_0_reload_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_0_reload_t {
          unsigned int                                : 31;
          unsigned int pmi_parameters                 : MP2_PMI_0_RELOAD_PMI_PARAMETERS_SIZE;
     } mp2_pmi_0_reload_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_0_reload_t f;
} mp2_pmi_0_reload_u;


/*
 * MP2_PMI_0_START struct
 */

#define MP2_PMI_0_START_REG_SIZE       32
#define MP2_PMI_0_START_ADDR_SIZE      18
#define MP2_PMI_0_START_ENABLE_SIZE    1

#define MP2_PMI_0_START_ADDR_SHIFT     0
#define MP2_PMI_0_START_ENABLE_SHIFT   31

#define MP2_PMI_0_START_ADDR_MASK      0x3ffff
#define MP2_PMI_0_START_ENABLE_MASK    0x80000000

#define MP2_PMI_0_START_MASK \
     (MP2_PMI_0_START_ADDR_MASK | \
      MP2_PMI_0_START_ENABLE_MASK)

#define MP2_PMI_0_START_DEFAULT        0x8003c000

#define MP2_PMI_0_START_GET_ADDR(mp2_pmi_0_start) \
     ((mp2_pmi_0_start & MP2_PMI_0_START_ADDR_MASK) >> MP2_PMI_0_START_ADDR_SHIFT)
#define MP2_PMI_0_START_GET_ENABLE(mp2_pmi_0_start) \
     ((mp2_pmi_0_start & MP2_PMI_0_START_ENABLE_MASK) >> MP2_PMI_0_START_ENABLE_SHIFT)

#define MP2_PMI_0_START_SET_ADDR(mp2_pmi_0_start_reg, addr) \
     mp2_pmi_0_start_reg = (mp2_pmi_0_start_reg & ~MP2_PMI_0_START_ADDR_MASK) | (addr << MP2_PMI_0_START_ADDR_SHIFT)
#define MP2_PMI_0_START_SET_ENABLE(mp2_pmi_0_start_reg, enable) \
     mp2_pmi_0_start_reg = (mp2_pmi_0_start_reg & ~MP2_PMI_0_START_ENABLE_MASK) | (enable << MP2_PMI_0_START_ENABLE_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_0_start_t {
          unsigned int addr                           : MP2_PMI_0_START_ADDR_SIZE;
          unsigned int                                : 13;
          unsigned int enable                         : MP2_PMI_0_START_ENABLE_SIZE;
     } mp2_pmi_0_start_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_0_start_t {
          unsigned int enable                         : MP2_PMI_0_START_ENABLE_SIZE;
          unsigned int                                : 13;
          unsigned int addr                           : MP2_PMI_0_START_ADDR_SIZE;
     } mp2_pmi_0_start_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_0_start_t f;
} mp2_pmi_0_start_u;


/*
 * MP2_PMI_0_FIFO struct
 */

#define MP2_PMI_0_FIFO_REG_SIZE        32
#define MP2_PMI_0_FIFO_DEPTH_SIZE      12
#define MP2_PMI_0_FIFO_DISABLE_EMPTY_FULL_SIZE 1
#define MP2_PMI_0_FIFO_DISABLE_ROLLOVER_INTR_SIZE 1
#define MP2_PMI_0_FIFO_DISABLE_FIFOFULL_INTR_SIZE 1
#define MP2_PMI_0_FIFO_DISABLE_FULLEMPTY_SLVERR_SIZE 1
#define MP2_PMI_0_FIFO_CLEAR_ROLLOVER_INTR_SIZE 1
#define MP2_PMI_0_FIFO_CLEAR_FIFOFULL_INTR_SIZE 1

#define MP2_PMI_0_FIFO_DEPTH_SHIFT     0
#define MP2_PMI_0_FIFO_DISABLE_EMPTY_FULL_SHIFT 16
#define MP2_PMI_0_FIFO_DISABLE_ROLLOVER_INTR_SHIFT 17
#define MP2_PMI_0_FIFO_DISABLE_FIFOFULL_INTR_SHIFT 18
#define MP2_PMI_0_FIFO_DISABLE_FULLEMPTY_SLVERR_SHIFT 19
#define MP2_PMI_0_FIFO_CLEAR_ROLLOVER_INTR_SHIFT 24
#define MP2_PMI_0_FIFO_CLEAR_FIFOFULL_INTR_SHIFT 25

#define MP2_PMI_0_FIFO_DEPTH_MASK      0xfff
#define MP2_PMI_0_FIFO_DISABLE_EMPTY_FULL_MASK 0x10000
#define MP2_PMI_0_FIFO_DISABLE_ROLLOVER_INTR_MASK 0x20000
#define MP2_PMI_0_FIFO_DISABLE_FIFOFULL_INTR_MASK 0x40000
#define MP2_PMI_0_FIFO_DISABLE_FULLEMPTY_SLVERR_MASK 0x80000
#define MP2_PMI_0_FIFO_CLEAR_ROLLOVER_INTR_MASK 0x1000000
#define MP2_PMI_0_FIFO_CLEAR_FIFOFULL_INTR_MASK 0x2000000

#define MP2_PMI_0_FIFO_MASK \
     (MP2_PMI_0_FIFO_DEPTH_MASK | \
      MP2_PMI_0_FIFO_DISABLE_EMPTY_FULL_MASK | \
      MP2_PMI_0_FIFO_DISABLE_ROLLOVER_INTR_MASK | \
      MP2_PMI_0_FIFO_DISABLE_FIFOFULL_INTR_MASK | \
      MP2_PMI_0_FIFO_DISABLE_FULLEMPTY_SLVERR_MASK | \
      MP2_PMI_0_FIFO_CLEAR_ROLLOVER_INTR_MASK | \
      MP2_PMI_0_FIFO_CLEAR_FIFOFULL_INTR_MASK)

#define MP2_PMI_0_FIFO_DEFAULT         0x0000000b

#define MP2_PMI_0_FIFO_GET_DEPTH(mp2_pmi_0_fifo) \
     ((mp2_pmi_0_fifo & MP2_PMI_0_FIFO_DEPTH_MASK) >> MP2_PMI_0_FIFO_DEPTH_SHIFT)
#define MP2_PMI_0_FIFO_GET_DISABLE_EMPTY_FULL(mp2_pmi_0_fifo) \
     ((mp2_pmi_0_fifo & MP2_PMI_0_FIFO_DISABLE_EMPTY_FULL_MASK) >> MP2_PMI_0_FIFO_DISABLE_EMPTY_FULL_SHIFT)
#define MP2_PMI_0_FIFO_GET_DISABLE_ROLLOVER_INTR(mp2_pmi_0_fifo) \
     ((mp2_pmi_0_fifo & MP2_PMI_0_FIFO_DISABLE_ROLLOVER_INTR_MASK) >> MP2_PMI_0_FIFO_DISABLE_ROLLOVER_INTR_SHIFT)
#define MP2_PMI_0_FIFO_GET_DISABLE_FIFOFULL_INTR(mp2_pmi_0_fifo) \
     ((mp2_pmi_0_fifo & MP2_PMI_0_FIFO_DISABLE_FIFOFULL_INTR_MASK) >> MP2_PMI_0_FIFO_DISABLE_FIFOFULL_INTR_SHIFT)
#define MP2_PMI_0_FIFO_GET_DISABLE_FULLEMPTY_SLVERR(mp2_pmi_0_fifo) \
     ((mp2_pmi_0_fifo & MP2_PMI_0_FIFO_DISABLE_FULLEMPTY_SLVERR_MASK) >> MP2_PMI_0_FIFO_DISABLE_FULLEMPTY_SLVERR_SHIFT)
#define MP2_PMI_0_FIFO_GET_CLEAR_ROLLOVER_INTR(mp2_pmi_0_fifo) \
     ((mp2_pmi_0_fifo & MP2_PMI_0_FIFO_CLEAR_ROLLOVER_INTR_MASK) >> MP2_PMI_0_FIFO_CLEAR_ROLLOVER_INTR_SHIFT)
#define MP2_PMI_0_FIFO_GET_CLEAR_FIFOFULL_INTR(mp2_pmi_0_fifo) \
     ((mp2_pmi_0_fifo & MP2_PMI_0_FIFO_CLEAR_FIFOFULL_INTR_MASK) >> MP2_PMI_0_FIFO_CLEAR_FIFOFULL_INTR_SHIFT)

#define MP2_PMI_0_FIFO_SET_DEPTH(mp2_pmi_0_fifo_reg, depth) \
     mp2_pmi_0_fifo_reg = (mp2_pmi_0_fifo_reg & ~MP2_PMI_0_FIFO_DEPTH_MASK) | (depth << MP2_PMI_0_FIFO_DEPTH_SHIFT)
#define MP2_PMI_0_FIFO_SET_DISABLE_EMPTY_FULL(mp2_pmi_0_fifo_reg, disable_empty_full) \
     mp2_pmi_0_fifo_reg = (mp2_pmi_0_fifo_reg & ~MP2_PMI_0_FIFO_DISABLE_EMPTY_FULL_MASK) | (disable_empty_full << MP2_PMI_0_FIFO_DISABLE_EMPTY_FULL_SHIFT)
#define MP2_PMI_0_FIFO_SET_DISABLE_ROLLOVER_INTR(mp2_pmi_0_fifo_reg, disable_rollover_intr) \
     mp2_pmi_0_fifo_reg = (mp2_pmi_0_fifo_reg & ~MP2_PMI_0_FIFO_DISABLE_ROLLOVER_INTR_MASK) | (disable_rollover_intr << MP2_PMI_0_FIFO_DISABLE_ROLLOVER_INTR_SHIFT)
#define MP2_PMI_0_FIFO_SET_DISABLE_FIFOFULL_INTR(mp2_pmi_0_fifo_reg, disable_fifofull_intr) \
     mp2_pmi_0_fifo_reg = (mp2_pmi_0_fifo_reg & ~MP2_PMI_0_FIFO_DISABLE_FIFOFULL_INTR_MASK) | (disable_fifofull_intr << MP2_PMI_0_FIFO_DISABLE_FIFOFULL_INTR_SHIFT)
#define MP2_PMI_0_FIFO_SET_DISABLE_FULLEMPTY_SLVERR(mp2_pmi_0_fifo_reg, disable_fullempty_slverr) \
     mp2_pmi_0_fifo_reg = (mp2_pmi_0_fifo_reg & ~MP2_PMI_0_FIFO_DISABLE_FULLEMPTY_SLVERR_MASK) | (disable_fullempty_slverr << MP2_PMI_0_FIFO_DISABLE_FULLEMPTY_SLVERR_SHIFT)
#define MP2_PMI_0_FIFO_SET_CLEAR_ROLLOVER_INTR(mp2_pmi_0_fifo_reg, clear_rollover_intr) \
     mp2_pmi_0_fifo_reg = (mp2_pmi_0_fifo_reg & ~MP2_PMI_0_FIFO_CLEAR_ROLLOVER_INTR_MASK) | (clear_rollover_intr << MP2_PMI_0_FIFO_CLEAR_ROLLOVER_INTR_SHIFT)
#define MP2_PMI_0_FIFO_SET_CLEAR_FIFOFULL_INTR(mp2_pmi_0_fifo_reg, clear_fifofull_intr) \
     mp2_pmi_0_fifo_reg = (mp2_pmi_0_fifo_reg & ~MP2_PMI_0_FIFO_CLEAR_FIFOFULL_INTR_MASK) | (clear_fifofull_intr << MP2_PMI_0_FIFO_CLEAR_FIFOFULL_INTR_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_0_fifo_t {
          unsigned int depth                          : MP2_PMI_0_FIFO_DEPTH_SIZE;
          unsigned int                                : 4;
          unsigned int disable_empty_full             : MP2_PMI_0_FIFO_DISABLE_EMPTY_FULL_SIZE;
          unsigned int disable_rollover_intr          : MP2_PMI_0_FIFO_DISABLE_ROLLOVER_INTR_SIZE;
          unsigned int disable_fifofull_intr          : MP2_PMI_0_FIFO_DISABLE_FIFOFULL_INTR_SIZE;
          unsigned int disable_fullempty_slverr       : MP2_PMI_0_FIFO_DISABLE_FULLEMPTY_SLVERR_SIZE;
          unsigned int                                : 4;
          unsigned int clear_rollover_intr            : MP2_PMI_0_FIFO_CLEAR_ROLLOVER_INTR_SIZE;
          unsigned int clear_fifofull_intr            : MP2_PMI_0_FIFO_CLEAR_FIFOFULL_INTR_SIZE;
          unsigned int                                : 6;
     } mp2_pmi_0_fifo_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_0_fifo_t {
          unsigned int                                : 6;
          unsigned int clear_fifofull_intr            : MP2_PMI_0_FIFO_CLEAR_FIFOFULL_INTR_SIZE;
          unsigned int clear_rollover_intr            : MP2_PMI_0_FIFO_CLEAR_ROLLOVER_INTR_SIZE;
          unsigned int                                : 4;
          unsigned int disable_fullempty_slverr       : MP2_PMI_0_FIFO_DISABLE_FULLEMPTY_SLVERR_SIZE;
          unsigned int disable_fifofull_intr          : MP2_PMI_0_FIFO_DISABLE_FIFOFULL_INTR_SIZE;
          unsigned int disable_rollover_intr          : MP2_PMI_0_FIFO_DISABLE_ROLLOVER_INTR_SIZE;
          unsigned int disable_empty_full             : MP2_PMI_0_FIFO_DISABLE_EMPTY_FULL_SIZE;
          unsigned int                                : 4;
          unsigned int depth                          : MP2_PMI_0_FIFO_DEPTH_SIZE;
     } mp2_pmi_0_fifo_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_0_fifo_t f;
} mp2_pmi_0_fifo_u;


/*
 * MP2_POSTCODE_CONFIG struct
 */

#define MP2_POSTCODE_CONFIG_REG_SIZE   32
#define MP2_POSTCODE_CONFIG_IGNORE_IP_CHECK_SIZE 1
#define MP2_POSTCODE_CONFIG_IGNORE_FEATURE_CHECK_SIZE 1

#define MP2_POSTCODE_CONFIG_IGNORE_IP_CHECK_SHIFT 0
#define MP2_POSTCODE_CONFIG_IGNORE_FEATURE_CHECK_SHIFT 1

#define MP2_POSTCODE_CONFIG_IGNORE_IP_CHECK_MASK 0x1
#define MP2_POSTCODE_CONFIG_IGNORE_FEATURE_CHECK_MASK 0x2

#define MP2_POSTCODE_CONFIG_MASK \
     (MP2_POSTCODE_CONFIG_IGNORE_IP_CHECK_MASK | \
      MP2_POSTCODE_CONFIG_IGNORE_FEATURE_CHECK_MASK)

#define MP2_POSTCODE_CONFIG_DEFAULT    0x00000003

#define MP2_POSTCODE_CONFIG_GET_IGNORE_IP_CHECK(mp2_postcode_config) \
     ((mp2_postcode_config & MP2_POSTCODE_CONFIG_IGNORE_IP_CHECK_MASK) >> MP2_POSTCODE_CONFIG_IGNORE_IP_CHECK_SHIFT)
#define MP2_POSTCODE_CONFIG_GET_IGNORE_FEATURE_CHECK(mp2_postcode_config) \
     ((mp2_postcode_config & MP2_POSTCODE_CONFIG_IGNORE_FEATURE_CHECK_MASK) >> MP2_POSTCODE_CONFIG_IGNORE_FEATURE_CHECK_SHIFT)

#define MP2_POSTCODE_CONFIG_SET_IGNORE_IP_CHECK(mp2_postcode_config_reg, ignore_ip_check) \
     mp2_postcode_config_reg = (mp2_postcode_config_reg & ~MP2_POSTCODE_CONFIG_IGNORE_IP_CHECK_MASK) | (ignore_ip_check << MP2_POSTCODE_CONFIG_IGNORE_IP_CHECK_SHIFT)
#define MP2_POSTCODE_CONFIG_SET_IGNORE_FEATURE_CHECK(mp2_postcode_config_reg, ignore_feature_check) \
     mp2_postcode_config_reg = (mp2_postcode_config_reg & ~MP2_POSTCODE_CONFIG_IGNORE_FEATURE_CHECK_MASK) | (ignore_feature_check << MP2_POSTCODE_CONFIG_IGNORE_FEATURE_CHECK_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_config_t {
          unsigned int ignore_ip_check                : MP2_POSTCODE_CONFIG_IGNORE_IP_CHECK_SIZE;
          unsigned int ignore_feature_check           : MP2_POSTCODE_CONFIG_IGNORE_FEATURE_CHECK_SIZE;
          unsigned int                                : 30;
     } mp2_postcode_config_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_config_t {
          unsigned int                                : 30;
          unsigned int ignore_feature_check           : MP2_POSTCODE_CONFIG_IGNORE_FEATURE_CHECK_SIZE;
          unsigned int ignore_ip_check                : MP2_POSTCODE_CONFIG_IGNORE_IP_CHECK_SIZE;
     } mp2_postcode_config_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_config_t f;
} mp2_postcode_config_u;


/*
 * MP2_POSTCODE_IP_0 struct
 */

#define MP2_POSTCODE_IP_0_REG_SIZE     32
#define MP2_POSTCODE_IP_0_IP_SIZE      8
#define MP2_POSTCODE_IP_0_VALID_SIZE   1

#define MP2_POSTCODE_IP_0_IP_SHIFT     0
#define MP2_POSTCODE_IP_0_VALID_SHIFT  8

#define MP2_POSTCODE_IP_0_IP_MASK      0xff
#define MP2_POSTCODE_IP_0_VALID_MASK   0x100

#define MP2_POSTCODE_IP_0_MASK \
     (MP2_POSTCODE_IP_0_IP_MASK | \
      MP2_POSTCODE_IP_0_VALID_MASK)

#define MP2_POSTCODE_IP_0_DEFAULT      0x00000000

#define MP2_POSTCODE_IP_0_GET_IP(mp2_postcode_ip_0) \
     ((mp2_postcode_ip_0 & MP2_POSTCODE_IP_0_IP_MASK) >> MP2_POSTCODE_IP_0_IP_SHIFT)
#define MP2_POSTCODE_IP_0_GET_VALID(mp2_postcode_ip_0) \
     ((mp2_postcode_ip_0 & MP2_POSTCODE_IP_0_VALID_MASK) >> MP2_POSTCODE_IP_0_VALID_SHIFT)

#define MP2_POSTCODE_IP_0_SET_IP(mp2_postcode_ip_0_reg, ip) \
     mp2_postcode_ip_0_reg = (mp2_postcode_ip_0_reg & ~MP2_POSTCODE_IP_0_IP_MASK) | (ip << MP2_POSTCODE_IP_0_IP_SHIFT)
#define MP2_POSTCODE_IP_0_SET_VALID(mp2_postcode_ip_0_reg, valid) \
     mp2_postcode_ip_0_reg = (mp2_postcode_ip_0_reg & ~MP2_POSTCODE_IP_0_VALID_MASK) | (valid << MP2_POSTCODE_IP_0_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_ip_0_t {
          unsigned int ip                             : MP2_POSTCODE_IP_0_IP_SIZE;
          unsigned int valid                          : MP2_POSTCODE_IP_0_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_ip_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_ip_0_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_IP_0_VALID_SIZE;
          unsigned int ip                             : MP2_POSTCODE_IP_0_IP_SIZE;
     } mp2_postcode_ip_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_ip_0_t f;
} mp2_postcode_ip_0_u;


/*
 * MP2_POSTCODE_FEATURE_0 struct
 */

#define MP2_POSTCODE_FEATURE_0_REG_SIZE 32
#define MP2_POSTCODE_FEATURE_0_FEATURE_SIZE 8
#define MP2_POSTCODE_FEATURE_0_VALID_SIZE 1

#define MP2_POSTCODE_FEATURE_0_FEATURE_SHIFT 0
#define MP2_POSTCODE_FEATURE_0_VALID_SHIFT 8

#define MP2_POSTCODE_FEATURE_0_FEATURE_MASK 0xff
#define MP2_POSTCODE_FEATURE_0_VALID_MASK 0x100

#define MP2_POSTCODE_FEATURE_0_MASK \
     (MP2_POSTCODE_FEATURE_0_FEATURE_MASK | \
      MP2_POSTCODE_FEATURE_0_VALID_MASK)

#define MP2_POSTCODE_FEATURE_0_DEFAULT 0x00000000

#define MP2_POSTCODE_FEATURE_0_GET_FEATURE(mp2_postcode_feature_0) \
     ((mp2_postcode_feature_0 & MP2_POSTCODE_FEATURE_0_FEATURE_MASK) >> MP2_POSTCODE_FEATURE_0_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_0_GET_VALID(mp2_postcode_feature_0) \
     ((mp2_postcode_feature_0 & MP2_POSTCODE_FEATURE_0_VALID_MASK) >> MP2_POSTCODE_FEATURE_0_VALID_SHIFT)

#define MP2_POSTCODE_FEATURE_0_SET_FEATURE(mp2_postcode_feature_0_reg, feature) \
     mp2_postcode_feature_0_reg = (mp2_postcode_feature_0_reg & ~MP2_POSTCODE_FEATURE_0_FEATURE_MASK) | (feature << MP2_POSTCODE_FEATURE_0_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_0_SET_VALID(mp2_postcode_feature_0_reg, valid) \
     mp2_postcode_feature_0_reg = (mp2_postcode_feature_0_reg & ~MP2_POSTCODE_FEATURE_0_VALID_MASK) | (valid << MP2_POSTCODE_FEATURE_0_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_feature_0_t {
          unsigned int feature                        : MP2_POSTCODE_FEATURE_0_FEATURE_SIZE;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_0_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_feature_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_feature_0_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_0_VALID_SIZE;
          unsigned int feature                        : MP2_POSTCODE_FEATURE_0_FEATURE_SIZE;
     } mp2_postcode_feature_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_feature_0_t f;
} mp2_postcode_feature_0_u;


/*
 * MP2_POSTCODE_IP_1 struct
 */

#define MP2_POSTCODE_IP_1_REG_SIZE     32
#define MP2_POSTCODE_IP_1_IP_SIZE      8
#define MP2_POSTCODE_IP_1_VALID_SIZE   1

#define MP2_POSTCODE_IP_1_IP_SHIFT     0
#define MP2_POSTCODE_IP_1_VALID_SHIFT  8

#define MP2_POSTCODE_IP_1_IP_MASK      0xff
#define MP2_POSTCODE_IP_1_VALID_MASK   0x100

#define MP2_POSTCODE_IP_1_MASK \
     (MP2_POSTCODE_IP_1_IP_MASK | \
      MP2_POSTCODE_IP_1_VALID_MASK)

#define MP2_POSTCODE_IP_1_DEFAULT      0x00000000

#define MP2_POSTCODE_IP_1_GET_IP(mp2_postcode_ip_1) \
     ((mp2_postcode_ip_1 & MP2_POSTCODE_IP_1_IP_MASK) >> MP2_POSTCODE_IP_1_IP_SHIFT)
#define MP2_POSTCODE_IP_1_GET_VALID(mp2_postcode_ip_1) \
     ((mp2_postcode_ip_1 & MP2_POSTCODE_IP_1_VALID_MASK) >> MP2_POSTCODE_IP_1_VALID_SHIFT)

#define MP2_POSTCODE_IP_1_SET_IP(mp2_postcode_ip_1_reg, ip) \
     mp2_postcode_ip_1_reg = (mp2_postcode_ip_1_reg & ~MP2_POSTCODE_IP_1_IP_MASK) | (ip << MP2_POSTCODE_IP_1_IP_SHIFT)
#define MP2_POSTCODE_IP_1_SET_VALID(mp2_postcode_ip_1_reg, valid) \
     mp2_postcode_ip_1_reg = (mp2_postcode_ip_1_reg & ~MP2_POSTCODE_IP_1_VALID_MASK) | (valid << MP2_POSTCODE_IP_1_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_ip_1_t {
          unsigned int ip                             : MP2_POSTCODE_IP_1_IP_SIZE;
          unsigned int valid                          : MP2_POSTCODE_IP_1_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_ip_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_ip_1_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_IP_1_VALID_SIZE;
          unsigned int ip                             : MP2_POSTCODE_IP_1_IP_SIZE;
     } mp2_postcode_ip_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_ip_1_t f;
} mp2_postcode_ip_1_u;


/*
 * MP2_POSTCODE_FEATURE_1 struct
 */

#define MP2_POSTCODE_FEATURE_1_REG_SIZE 32
#define MP2_POSTCODE_FEATURE_1_FEATURE_SIZE 8
#define MP2_POSTCODE_FEATURE_1_VALID_SIZE 1

#define MP2_POSTCODE_FEATURE_1_FEATURE_SHIFT 0
#define MP2_POSTCODE_FEATURE_1_VALID_SHIFT 8

#define MP2_POSTCODE_FEATURE_1_FEATURE_MASK 0xff
#define MP2_POSTCODE_FEATURE_1_VALID_MASK 0x100

#define MP2_POSTCODE_FEATURE_1_MASK \
     (MP2_POSTCODE_FEATURE_1_FEATURE_MASK | \
      MP2_POSTCODE_FEATURE_1_VALID_MASK)

#define MP2_POSTCODE_FEATURE_1_DEFAULT 0x00000000

#define MP2_POSTCODE_FEATURE_1_GET_FEATURE(mp2_postcode_feature_1) \
     ((mp2_postcode_feature_1 & MP2_POSTCODE_FEATURE_1_FEATURE_MASK) >> MP2_POSTCODE_FEATURE_1_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_1_GET_VALID(mp2_postcode_feature_1) \
     ((mp2_postcode_feature_1 & MP2_POSTCODE_FEATURE_1_VALID_MASK) >> MP2_POSTCODE_FEATURE_1_VALID_SHIFT)

#define MP2_POSTCODE_FEATURE_1_SET_FEATURE(mp2_postcode_feature_1_reg, feature) \
     mp2_postcode_feature_1_reg = (mp2_postcode_feature_1_reg & ~MP2_POSTCODE_FEATURE_1_FEATURE_MASK) | (feature << MP2_POSTCODE_FEATURE_1_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_1_SET_VALID(mp2_postcode_feature_1_reg, valid) \
     mp2_postcode_feature_1_reg = (mp2_postcode_feature_1_reg & ~MP2_POSTCODE_FEATURE_1_VALID_MASK) | (valid << MP2_POSTCODE_FEATURE_1_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_feature_1_t {
          unsigned int feature                        : MP2_POSTCODE_FEATURE_1_FEATURE_SIZE;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_1_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_feature_1_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_feature_1_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_1_VALID_SIZE;
          unsigned int feature                        : MP2_POSTCODE_FEATURE_1_FEATURE_SIZE;
     } mp2_postcode_feature_1_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_feature_1_t f;
} mp2_postcode_feature_1_u;


/*
 * MP2_POSTCODE_IP_2 struct
 */

#define MP2_POSTCODE_IP_2_REG_SIZE     32
#define MP2_POSTCODE_IP_2_IP_SIZE      8
#define MP2_POSTCODE_IP_2_VALID_SIZE   1

#define MP2_POSTCODE_IP_2_IP_SHIFT     0
#define MP2_POSTCODE_IP_2_VALID_SHIFT  8

#define MP2_POSTCODE_IP_2_IP_MASK      0xff
#define MP2_POSTCODE_IP_2_VALID_MASK   0x100

#define MP2_POSTCODE_IP_2_MASK \
     (MP2_POSTCODE_IP_2_IP_MASK | \
      MP2_POSTCODE_IP_2_VALID_MASK)

#define MP2_POSTCODE_IP_2_DEFAULT      0x00000000

#define MP2_POSTCODE_IP_2_GET_IP(mp2_postcode_ip_2) \
     ((mp2_postcode_ip_2 & MP2_POSTCODE_IP_2_IP_MASK) >> MP2_POSTCODE_IP_2_IP_SHIFT)
#define MP2_POSTCODE_IP_2_GET_VALID(mp2_postcode_ip_2) \
     ((mp2_postcode_ip_2 & MP2_POSTCODE_IP_2_VALID_MASK) >> MP2_POSTCODE_IP_2_VALID_SHIFT)

#define MP2_POSTCODE_IP_2_SET_IP(mp2_postcode_ip_2_reg, ip) \
     mp2_postcode_ip_2_reg = (mp2_postcode_ip_2_reg & ~MP2_POSTCODE_IP_2_IP_MASK) | (ip << MP2_POSTCODE_IP_2_IP_SHIFT)
#define MP2_POSTCODE_IP_2_SET_VALID(mp2_postcode_ip_2_reg, valid) \
     mp2_postcode_ip_2_reg = (mp2_postcode_ip_2_reg & ~MP2_POSTCODE_IP_2_VALID_MASK) | (valid << MP2_POSTCODE_IP_2_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_ip_2_t {
          unsigned int ip                             : MP2_POSTCODE_IP_2_IP_SIZE;
          unsigned int valid                          : MP2_POSTCODE_IP_2_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_ip_2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_ip_2_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_IP_2_VALID_SIZE;
          unsigned int ip                             : MP2_POSTCODE_IP_2_IP_SIZE;
     } mp2_postcode_ip_2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_ip_2_t f;
} mp2_postcode_ip_2_u;


/*
 * MP2_POSTCODE_FEATURE_2 struct
 */

#define MP2_POSTCODE_FEATURE_2_REG_SIZE 32
#define MP2_POSTCODE_FEATURE_2_FEATURE_SIZE 8
#define MP2_POSTCODE_FEATURE_2_VALID_SIZE 1

#define MP2_POSTCODE_FEATURE_2_FEATURE_SHIFT 0
#define MP2_POSTCODE_FEATURE_2_VALID_SHIFT 8

#define MP2_POSTCODE_FEATURE_2_FEATURE_MASK 0xff
#define MP2_POSTCODE_FEATURE_2_VALID_MASK 0x100

#define MP2_POSTCODE_FEATURE_2_MASK \
     (MP2_POSTCODE_FEATURE_2_FEATURE_MASK | \
      MP2_POSTCODE_FEATURE_2_VALID_MASK)

#define MP2_POSTCODE_FEATURE_2_DEFAULT 0x00000000

#define MP2_POSTCODE_FEATURE_2_GET_FEATURE(mp2_postcode_feature_2) \
     ((mp2_postcode_feature_2 & MP2_POSTCODE_FEATURE_2_FEATURE_MASK) >> MP2_POSTCODE_FEATURE_2_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_2_GET_VALID(mp2_postcode_feature_2) \
     ((mp2_postcode_feature_2 & MP2_POSTCODE_FEATURE_2_VALID_MASK) >> MP2_POSTCODE_FEATURE_2_VALID_SHIFT)

#define MP2_POSTCODE_FEATURE_2_SET_FEATURE(mp2_postcode_feature_2_reg, feature) \
     mp2_postcode_feature_2_reg = (mp2_postcode_feature_2_reg & ~MP2_POSTCODE_FEATURE_2_FEATURE_MASK) | (feature << MP2_POSTCODE_FEATURE_2_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_2_SET_VALID(mp2_postcode_feature_2_reg, valid) \
     mp2_postcode_feature_2_reg = (mp2_postcode_feature_2_reg & ~MP2_POSTCODE_FEATURE_2_VALID_MASK) | (valid << MP2_POSTCODE_FEATURE_2_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_feature_2_t {
          unsigned int feature                        : MP2_POSTCODE_FEATURE_2_FEATURE_SIZE;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_2_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_feature_2_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_feature_2_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_2_VALID_SIZE;
          unsigned int feature                        : MP2_POSTCODE_FEATURE_2_FEATURE_SIZE;
     } mp2_postcode_feature_2_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_feature_2_t f;
} mp2_postcode_feature_2_u;


/*
 * MP2_POSTCODE_IP_3 struct
 */

#define MP2_POSTCODE_IP_3_REG_SIZE     32
#define MP2_POSTCODE_IP_3_IP_SIZE      8
#define MP2_POSTCODE_IP_3_VALID_SIZE   1

#define MP2_POSTCODE_IP_3_IP_SHIFT     0
#define MP2_POSTCODE_IP_3_VALID_SHIFT  8

#define MP2_POSTCODE_IP_3_IP_MASK      0xff
#define MP2_POSTCODE_IP_3_VALID_MASK   0x100

#define MP2_POSTCODE_IP_3_MASK \
     (MP2_POSTCODE_IP_3_IP_MASK | \
      MP2_POSTCODE_IP_3_VALID_MASK)

#define MP2_POSTCODE_IP_3_DEFAULT      0x00000000

#define MP2_POSTCODE_IP_3_GET_IP(mp2_postcode_ip_3) \
     ((mp2_postcode_ip_3 & MP2_POSTCODE_IP_3_IP_MASK) >> MP2_POSTCODE_IP_3_IP_SHIFT)
#define MP2_POSTCODE_IP_3_GET_VALID(mp2_postcode_ip_3) \
     ((mp2_postcode_ip_3 & MP2_POSTCODE_IP_3_VALID_MASK) >> MP2_POSTCODE_IP_3_VALID_SHIFT)

#define MP2_POSTCODE_IP_3_SET_IP(mp2_postcode_ip_3_reg, ip) \
     mp2_postcode_ip_3_reg = (mp2_postcode_ip_3_reg & ~MP2_POSTCODE_IP_3_IP_MASK) | (ip << MP2_POSTCODE_IP_3_IP_SHIFT)
#define MP2_POSTCODE_IP_3_SET_VALID(mp2_postcode_ip_3_reg, valid) \
     mp2_postcode_ip_3_reg = (mp2_postcode_ip_3_reg & ~MP2_POSTCODE_IP_3_VALID_MASK) | (valid << MP2_POSTCODE_IP_3_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_ip_3_t {
          unsigned int ip                             : MP2_POSTCODE_IP_3_IP_SIZE;
          unsigned int valid                          : MP2_POSTCODE_IP_3_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_ip_3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_ip_3_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_IP_3_VALID_SIZE;
          unsigned int ip                             : MP2_POSTCODE_IP_3_IP_SIZE;
     } mp2_postcode_ip_3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_ip_3_t f;
} mp2_postcode_ip_3_u;


/*
 * MP2_POSTCODE_FEATURE_3 struct
 */

#define MP2_POSTCODE_FEATURE_3_REG_SIZE 32
#define MP2_POSTCODE_FEATURE_3_FEATURE_SIZE 8
#define MP2_POSTCODE_FEATURE_3_VALID_SIZE 1

#define MP2_POSTCODE_FEATURE_3_FEATURE_SHIFT 0
#define MP2_POSTCODE_FEATURE_3_VALID_SHIFT 8

#define MP2_POSTCODE_FEATURE_3_FEATURE_MASK 0xff
#define MP2_POSTCODE_FEATURE_3_VALID_MASK 0x100

#define MP2_POSTCODE_FEATURE_3_MASK \
     (MP2_POSTCODE_FEATURE_3_FEATURE_MASK | \
      MP2_POSTCODE_FEATURE_3_VALID_MASK)

#define MP2_POSTCODE_FEATURE_3_DEFAULT 0x00000000

#define MP2_POSTCODE_FEATURE_3_GET_FEATURE(mp2_postcode_feature_3) \
     ((mp2_postcode_feature_3 & MP2_POSTCODE_FEATURE_3_FEATURE_MASK) >> MP2_POSTCODE_FEATURE_3_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_3_GET_VALID(mp2_postcode_feature_3) \
     ((mp2_postcode_feature_3 & MP2_POSTCODE_FEATURE_3_VALID_MASK) >> MP2_POSTCODE_FEATURE_3_VALID_SHIFT)

#define MP2_POSTCODE_FEATURE_3_SET_FEATURE(mp2_postcode_feature_3_reg, feature) \
     mp2_postcode_feature_3_reg = (mp2_postcode_feature_3_reg & ~MP2_POSTCODE_FEATURE_3_FEATURE_MASK) | (feature << MP2_POSTCODE_FEATURE_3_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_3_SET_VALID(mp2_postcode_feature_3_reg, valid) \
     mp2_postcode_feature_3_reg = (mp2_postcode_feature_3_reg & ~MP2_POSTCODE_FEATURE_3_VALID_MASK) | (valid << MP2_POSTCODE_FEATURE_3_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_feature_3_t {
          unsigned int feature                        : MP2_POSTCODE_FEATURE_3_FEATURE_SIZE;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_3_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_feature_3_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_feature_3_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_3_VALID_SIZE;
          unsigned int feature                        : MP2_POSTCODE_FEATURE_3_FEATURE_SIZE;
     } mp2_postcode_feature_3_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_feature_3_t f;
} mp2_postcode_feature_3_u;


/*
 * MP2_POSTCODE_IP_4 struct
 */

#define MP2_POSTCODE_IP_4_REG_SIZE     32
#define MP2_POSTCODE_IP_4_IP_SIZE      8
#define MP2_POSTCODE_IP_4_VALID_SIZE   1

#define MP2_POSTCODE_IP_4_IP_SHIFT     0
#define MP2_POSTCODE_IP_4_VALID_SHIFT  8

#define MP2_POSTCODE_IP_4_IP_MASK      0xff
#define MP2_POSTCODE_IP_4_VALID_MASK   0x100

#define MP2_POSTCODE_IP_4_MASK \
     (MP2_POSTCODE_IP_4_IP_MASK | \
      MP2_POSTCODE_IP_4_VALID_MASK)

#define MP2_POSTCODE_IP_4_DEFAULT      0x00000000

#define MP2_POSTCODE_IP_4_GET_IP(mp2_postcode_ip_4) \
     ((mp2_postcode_ip_4 & MP2_POSTCODE_IP_4_IP_MASK) >> MP2_POSTCODE_IP_4_IP_SHIFT)
#define MP2_POSTCODE_IP_4_GET_VALID(mp2_postcode_ip_4) \
     ((mp2_postcode_ip_4 & MP2_POSTCODE_IP_4_VALID_MASK) >> MP2_POSTCODE_IP_4_VALID_SHIFT)

#define MP2_POSTCODE_IP_4_SET_IP(mp2_postcode_ip_4_reg, ip) \
     mp2_postcode_ip_4_reg = (mp2_postcode_ip_4_reg & ~MP2_POSTCODE_IP_4_IP_MASK) | (ip << MP2_POSTCODE_IP_4_IP_SHIFT)
#define MP2_POSTCODE_IP_4_SET_VALID(mp2_postcode_ip_4_reg, valid) \
     mp2_postcode_ip_4_reg = (mp2_postcode_ip_4_reg & ~MP2_POSTCODE_IP_4_VALID_MASK) | (valid << MP2_POSTCODE_IP_4_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_ip_4_t {
          unsigned int ip                             : MP2_POSTCODE_IP_4_IP_SIZE;
          unsigned int valid                          : MP2_POSTCODE_IP_4_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_ip_4_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_ip_4_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_IP_4_VALID_SIZE;
          unsigned int ip                             : MP2_POSTCODE_IP_4_IP_SIZE;
     } mp2_postcode_ip_4_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_ip_4_t f;
} mp2_postcode_ip_4_u;


/*
 * MP2_POSTCODE_FEATURE_4 struct
 */

#define MP2_POSTCODE_FEATURE_4_REG_SIZE 32
#define MP2_POSTCODE_FEATURE_4_FEATURE_SIZE 8
#define MP2_POSTCODE_FEATURE_4_VALID_SIZE 1

#define MP2_POSTCODE_FEATURE_4_FEATURE_SHIFT 0
#define MP2_POSTCODE_FEATURE_4_VALID_SHIFT 8

#define MP2_POSTCODE_FEATURE_4_FEATURE_MASK 0xff
#define MP2_POSTCODE_FEATURE_4_VALID_MASK 0x100

#define MP2_POSTCODE_FEATURE_4_MASK \
     (MP2_POSTCODE_FEATURE_4_FEATURE_MASK | \
      MP2_POSTCODE_FEATURE_4_VALID_MASK)

#define MP2_POSTCODE_FEATURE_4_DEFAULT 0x00000000

#define MP2_POSTCODE_FEATURE_4_GET_FEATURE(mp2_postcode_feature_4) \
     ((mp2_postcode_feature_4 & MP2_POSTCODE_FEATURE_4_FEATURE_MASK) >> MP2_POSTCODE_FEATURE_4_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_4_GET_VALID(mp2_postcode_feature_4) \
     ((mp2_postcode_feature_4 & MP2_POSTCODE_FEATURE_4_VALID_MASK) >> MP2_POSTCODE_FEATURE_4_VALID_SHIFT)

#define MP2_POSTCODE_FEATURE_4_SET_FEATURE(mp2_postcode_feature_4_reg, feature) \
     mp2_postcode_feature_4_reg = (mp2_postcode_feature_4_reg & ~MP2_POSTCODE_FEATURE_4_FEATURE_MASK) | (feature << MP2_POSTCODE_FEATURE_4_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_4_SET_VALID(mp2_postcode_feature_4_reg, valid) \
     mp2_postcode_feature_4_reg = (mp2_postcode_feature_4_reg & ~MP2_POSTCODE_FEATURE_4_VALID_MASK) | (valid << MP2_POSTCODE_FEATURE_4_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_feature_4_t {
          unsigned int feature                        : MP2_POSTCODE_FEATURE_4_FEATURE_SIZE;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_4_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_feature_4_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_feature_4_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_4_VALID_SIZE;
          unsigned int feature                        : MP2_POSTCODE_FEATURE_4_FEATURE_SIZE;
     } mp2_postcode_feature_4_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_feature_4_t f;
} mp2_postcode_feature_4_u;


/*
 * MP2_POSTCODE_IP_5 struct
 */

#define MP2_POSTCODE_IP_5_REG_SIZE     32
#define MP2_POSTCODE_IP_5_IP_SIZE      8
#define MP2_POSTCODE_IP_5_VALID_SIZE   1

#define MP2_POSTCODE_IP_5_IP_SHIFT     0
#define MP2_POSTCODE_IP_5_VALID_SHIFT  8

#define MP2_POSTCODE_IP_5_IP_MASK      0xff
#define MP2_POSTCODE_IP_5_VALID_MASK   0x100

#define MP2_POSTCODE_IP_5_MASK \
     (MP2_POSTCODE_IP_5_IP_MASK | \
      MP2_POSTCODE_IP_5_VALID_MASK)

#define MP2_POSTCODE_IP_5_DEFAULT      0x00000000

#define MP2_POSTCODE_IP_5_GET_IP(mp2_postcode_ip_5) \
     ((mp2_postcode_ip_5 & MP2_POSTCODE_IP_5_IP_MASK) >> MP2_POSTCODE_IP_5_IP_SHIFT)
#define MP2_POSTCODE_IP_5_GET_VALID(mp2_postcode_ip_5) \
     ((mp2_postcode_ip_5 & MP2_POSTCODE_IP_5_VALID_MASK) >> MP2_POSTCODE_IP_5_VALID_SHIFT)

#define MP2_POSTCODE_IP_5_SET_IP(mp2_postcode_ip_5_reg, ip) \
     mp2_postcode_ip_5_reg = (mp2_postcode_ip_5_reg & ~MP2_POSTCODE_IP_5_IP_MASK) | (ip << MP2_POSTCODE_IP_5_IP_SHIFT)
#define MP2_POSTCODE_IP_5_SET_VALID(mp2_postcode_ip_5_reg, valid) \
     mp2_postcode_ip_5_reg = (mp2_postcode_ip_5_reg & ~MP2_POSTCODE_IP_5_VALID_MASK) | (valid << MP2_POSTCODE_IP_5_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_ip_5_t {
          unsigned int ip                             : MP2_POSTCODE_IP_5_IP_SIZE;
          unsigned int valid                          : MP2_POSTCODE_IP_5_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_ip_5_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_ip_5_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_IP_5_VALID_SIZE;
          unsigned int ip                             : MP2_POSTCODE_IP_5_IP_SIZE;
     } mp2_postcode_ip_5_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_ip_5_t f;
} mp2_postcode_ip_5_u;


/*
 * MP2_POSTCODE_FEATURE_5 struct
 */

#define MP2_POSTCODE_FEATURE_5_REG_SIZE 32
#define MP2_POSTCODE_FEATURE_5_FEATURE_SIZE 8
#define MP2_POSTCODE_FEATURE_5_VALID_SIZE 1

#define MP2_POSTCODE_FEATURE_5_FEATURE_SHIFT 0
#define MP2_POSTCODE_FEATURE_5_VALID_SHIFT 8

#define MP2_POSTCODE_FEATURE_5_FEATURE_MASK 0xff
#define MP2_POSTCODE_FEATURE_5_VALID_MASK 0x100

#define MP2_POSTCODE_FEATURE_5_MASK \
     (MP2_POSTCODE_FEATURE_5_FEATURE_MASK | \
      MP2_POSTCODE_FEATURE_5_VALID_MASK)

#define MP2_POSTCODE_FEATURE_5_DEFAULT 0x00000000

#define MP2_POSTCODE_FEATURE_5_GET_FEATURE(mp2_postcode_feature_5) \
     ((mp2_postcode_feature_5 & MP2_POSTCODE_FEATURE_5_FEATURE_MASK) >> MP2_POSTCODE_FEATURE_5_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_5_GET_VALID(mp2_postcode_feature_5) \
     ((mp2_postcode_feature_5 & MP2_POSTCODE_FEATURE_5_VALID_MASK) >> MP2_POSTCODE_FEATURE_5_VALID_SHIFT)

#define MP2_POSTCODE_FEATURE_5_SET_FEATURE(mp2_postcode_feature_5_reg, feature) \
     mp2_postcode_feature_5_reg = (mp2_postcode_feature_5_reg & ~MP2_POSTCODE_FEATURE_5_FEATURE_MASK) | (feature << MP2_POSTCODE_FEATURE_5_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_5_SET_VALID(mp2_postcode_feature_5_reg, valid) \
     mp2_postcode_feature_5_reg = (mp2_postcode_feature_5_reg & ~MP2_POSTCODE_FEATURE_5_VALID_MASK) | (valid << MP2_POSTCODE_FEATURE_5_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_feature_5_t {
          unsigned int feature                        : MP2_POSTCODE_FEATURE_5_FEATURE_SIZE;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_5_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_feature_5_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_feature_5_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_5_VALID_SIZE;
          unsigned int feature                        : MP2_POSTCODE_FEATURE_5_FEATURE_SIZE;
     } mp2_postcode_feature_5_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_feature_5_t f;
} mp2_postcode_feature_5_u;


/*
 * MP2_POSTCODE_IP_6 struct
 */

#define MP2_POSTCODE_IP_6_REG_SIZE     32
#define MP2_POSTCODE_IP_6_IP_SIZE      8
#define MP2_POSTCODE_IP_6_VALID_SIZE   1

#define MP2_POSTCODE_IP_6_IP_SHIFT     0
#define MP2_POSTCODE_IP_6_VALID_SHIFT  8

#define MP2_POSTCODE_IP_6_IP_MASK      0xff
#define MP2_POSTCODE_IP_6_VALID_MASK   0x100

#define MP2_POSTCODE_IP_6_MASK \
     (MP2_POSTCODE_IP_6_IP_MASK | \
      MP2_POSTCODE_IP_6_VALID_MASK)

#define MP2_POSTCODE_IP_6_DEFAULT      0x00000000

#define MP2_POSTCODE_IP_6_GET_IP(mp2_postcode_ip_6) \
     ((mp2_postcode_ip_6 & MP2_POSTCODE_IP_6_IP_MASK) >> MP2_POSTCODE_IP_6_IP_SHIFT)
#define MP2_POSTCODE_IP_6_GET_VALID(mp2_postcode_ip_6) \
     ((mp2_postcode_ip_6 & MP2_POSTCODE_IP_6_VALID_MASK) >> MP2_POSTCODE_IP_6_VALID_SHIFT)

#define MP2_POSTCODE_IP_6_SET_IP(mp2_postcode_ip_6_reg, ip) \
     mp2_postcode_ip_6_reg = (mp2_postcode_ip_6_reg & ~MP2_POSTCODE_IP_6_IP_MASK) | (ip << MP2_POSTCODE_IP_6_IP_SHIFT)
#define MP2_POSTCODE_IP_6_SET_VALID(mp2_postcode_ip_6_reg, valid) \
     mp2_postcode_ip_6_reg = (mp2_postcode_ip_6_reg & ~MP2_POSTCODE_IP_6_VALID_MASK) | (valid << MP2_POSTCODE_IP_6_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_ip_6_t {
          unsigned int ip                             : MP2_POSTCODE_IP_6_IP_SIZE;
          unsigned int valid                          : MP2_POSTCODE_IP_6_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_ip_6_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_ip_6_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_IP_6_VALID_SIZE;
          unsigned int ip                             : MP2_POSTCODE_IP_6_IP_SIZE;
     } mp2_postcode_ip_6_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_ip_6_t f;
} mp2_postcode_ip_6_u;


/*
 * MP2_POSTCODE_FEATURE_6 struct
 */

#define MP2_POSTCODE_FEATURE_6_REG_SIZE 32
#define MP2_POSTCODE_FEATURE_6_FEATURE_SIZE 8
#define MP2_POSTCODE_FEATURE_6_VALID_SIZE 1

#define MP2_POSTCODE_FEATURE_6_FEATURE_SHIFT 0
#define MP2_POSTCODE_FEATURE_6_VALID_SHIFT 8

#define MP2_POSTCODE_FEATURE_6_FEATURE_MASK 0xff
#define MP2_POSTCODE_FEATURE_6_VALID_MASK 0x100

#define MP2_POSTCODE_FEATURE_6_MASK \
     (MP2_POSTCODE_FEATURE_6_FEATURE_MASK | \
      MP2_POSTCODE_FEATURE_6_VALID_MASK)

#define MP2_POSTCODE_FEATURE_6_DEFAULT 0x00000000

#define MP2_POSTCODE_FEATURE_6_GET_FEATURE(mp2_postcode_feature_6) \
     ((mp2_postcode_feature_6 & MP2_POSTCODE_FEATURE_6_FEATURE_MASK) >> MP2_POSTCODE_FEATURE_6_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_6_GET_VALID(mp2_postcode_feature_6) \
     ((mp2_postcode_feature_6 & MP2_POSTCODE_FEATURE_6_VALID_MASK) >> MP2_POSTCODE_FEATURE_6_VALID_SHIFT)

#define MP2_POSTCODE_FEATURE_6_SET_FEATURE(mp2_postcode_feature_6_reg, feature) \
     mp2_postcode_feature_6_reg = (mp2_postcode_feature_6_reg & ~MP2_POSTCODE_FEATURE_6_FEATURE_MASK) | (feature << MP2_POSTCODE_FEATURE_6_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_6_SET_VALID(mp2_postcode_feature_6_reg, valid) \
     mp2_postcode_feature_6_reg = (mp2_postcode_feature_6_reg & ~MP2_POSTCODE_FEATURE_6_VALID_MASK) | (valid << MP2_POSTCODE_FEATURE_6_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_feature_6_t {
          unsigned int feature                        : MP2_POSTCODE_FEATURE_6_FEATURE_SIZE;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_6_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_feature_6_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_feature_6_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_6_VALID_SIZE;
          unsigned int feature                        : MP2_POSTCODE_FEATURE_6_FEATURE_SIZE;
     } mp2_postcode_feature_6_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_feature_6_t f;
} mp2_postcode_feature_6_u;


/*
 * MP2_POSTCODE_IP_7 struct
 */

#define MP2_POSTCODE_IP_7_REG_SIZE     32
#define MP2_POSTCODE_IP_7_IP_SIZE      8
#define MP2_POSTCODE_IP_7_VALID_SIZE   1

#define MP2_POSTCODE_IP_7_IP_SHIFT     0
#define MP2_POSTCODE_IP_7_VALID_SHIFT  8

#define MP2_POSTCODE_IP_7_IP_MASK      0xff
#define MP2_POSTCODE_IP_7_VALID_MASK   0x100

#define MP2_POSTCODE_IP_7_MASK \
     (MP2_POSTCODE_IP_7_IP_MASK | \
      MP2_POSTCODE_IP_7_VALID_MASK)

#define MP2_POSTCODE_IP_7_DEFAULT      0x00000000

#define MP2_POSTCODE_IP_7_GET_IP(mp2_postcode_ip_7) \
     ((mp2_postcode_ip_7 & MP2_POSTCODE_IP_7_IP_MASK) >> MP2_POSTCODE_IP_7_IP_SHIFT)
#define MP2_POSTCODE_IP_7_GET_VALID(mp2_postcode_ip_7) \
     ((mp2_postcode_ip_7 & MP2_POSTCODE_IP_7_VALID_MASK) >> MP2_POSTCODE_IP_7_VALID_SHIFT)

#define MP2_POSTCODE_IP_7_SET_IP(mp2_postcode_ip_7_reg, ip) \
     mp2_postcode_ip_7_reg = (mp2_postcode_ip_7_reg & ~MP2_POSTCODE_IP_7_IP_MASK) | (ip << MP2_POSTCODE_IP_7_IP_SHIFT)
#define MP2_POSTCODE_IP_7_SET_VALID(mp2_postcode_ip_7_reg, valid) \
     mp2_postcode_ip_7_reg = (mp2_postcode_ip_7_reg & ~MP2_POSTCODE_IP_7_VALID_MASK) | (valid << MP2_POSTCODE_IP_7_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_ip_7_t {
          unsigned int ip                             : MP2_POSTCODE_IP_7_IP_SIZE;
          unsigned int valid                          : MP2_POSTCODE_IP_7_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_ip_7_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_ip_7_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_IP_7_VALID_SIZE;
          unsigned int ip                             : MP2_POSTCODE_IP_7_IP_SIZE;
     } mp2_postcode_ip_7_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_ip_7_t f;
} mp2_postcode_ip_7_u;


/*
 * MP2_POSTCODE_FEATURE_7 struct
 */

#define MP2_POSTCODE_FEATURE_7_REG_SIZE 32
#define MP2_POSTCODE_FEATURE_7_FEATURE_SIZE 8
#define MP2_POSTCODE_FEATURE_7_VALID_SIZE 1

#define MP2_POSTCODE_FEATURE_7_FEATURE_SHIFT 0
#define MP2_POSTCODE_FEATURE_7_VALID_SHIFT 8

#define MP2_POSTCODE_FEATURE_7_FEATURE_MASK 0xff
#define MP2_POSTCODE_FEATURE_7_VALID_MASK 0x100

#define MP2_POSTCODE_FEATURE_7_MASK \
     (MP2_POSTCODE_FEATURE_7_FEATURE_MASK | \
      MP2_POSTCODE_FEATURE_7_VALID_MASK)

#define MP2_POSTCODE_FEATURE_7_DEFAULT 0x00000000

#define MP2_POSTCODE_FEATURE_7_GET_FEATURE(mp2_postcode_feature_7) \
     ((mp2_postcode_feature_7 & MP2_POSTCODE_FEATURE_7_FEATURE_MASK) >> MP2_POSTCODE_FEATURE_7_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_7_GET_VALID(mp2_postcode_feature_7) \
     ((mp2_postcode_feature_7 & MP2_POSTCODE_FEATURE_7_VALID_MASK) >> MP2_POSTCODE_FEATURE_7_VALID_SHIFT)

#define MP2_POSTCODE_FEATURE_7_SET_FEATURE(mp2_postcode_feature_7_reg, feature) \
     mp2_postcode_feature_7_reg = (mp2_postcode_feature_7_reg & ~MP2_POSTCODE_FEATURE_7_FEATURE_MASK) | (feature << MP2_POSTCODE_FEATURE_7_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_7_SET_VALID(mp2_postcode_feature_7_reg, valid) \
     mp2_postcode_feature_7_reg = (mp2_postcode_feature_7_reg & ~MP2_POSTCODE_FEATURE_7_VALID_MASK) | (valid << MP2_POSTCODE_FEATURE_7_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_feature_7_t {
          unsigned int feature                        : MP2_POSTCODE_FEATURE_7_FEATURE_SIZE;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_7_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_feature_7_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_feature_7_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_7_VALID_SIZE;
          unsigned int feature                        : MP2_POSTCODE_FEATURE_7_FEATURE_SIZE;
     } mp2_postcode_feature_7_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_feature_7_t f;
} mp2_postcode_feature_7_u;


/*
 * MP2_POSTCODE_IP_8 struct
 */

#define MP2_POSTCODE_IP_8_REG_SIZE     32
#define MP2_POSTCODE_IP_8_IP_SIZE      8
#define MP2_POSTCODE_IP_8_VALID_SIZE   1

#define MP2_POSTCODE_IP_8_IP_SHIFT     0
#define MP2_POSTCODE_IP_8_VALID_SHIFT  8

#define MP2_POSTCODE_IP_8_IP_MASK      0xff
#define MP2_POSTCODE_IP_8_VALID_MASK   0x100

#define MP2_POSTCODE_IP_8_MASK \
     (MP2_POSTCODE_IP_8_IP_MASK | \
      MP2_POSTCODE_IP_8_VALID_MASK)

#define MP2_POSTCODE_IP_8_DEFAULT      0x00000000

#define MP2_POSTCODE_IP_8_GET_IP(mp2_postcode_ip_8) \
     ((mp2_postcode_ip_8 & MP2_POSTCODE_IP_8_IP_MASK) >> MP2_POSTCODE_IP_8_IP_SHIFT)
#define MP2_POSTCODE_IP_8_GET_VALID(mp2_postcode_ip_8) \
     ((mp2_postcode_ip_8 & MP2_POSTCODE_IP_8_VALID_MASK) >> MP2_POSTCODE_IP_8_VALID_SHIFT)

#define MP2_POSTCODE_IP_8_SET_IP(mp2_postcode_ip_8_reg, ip) \
     mp2_postcode_ip_8_reg = (mp2_postcode_ip_8_reg & ~MP2_POSTCODE_IP_8_IP_MASK) | (ip << MP2_POSTCODE_IP_8_IP_SHIFT)
#define MP2_POSTCODE_IP_8_SET_VALID(mp2_postcode_ip_8_reg, valid) \
     mp2_postcode_ip_8_reg = (mp2_postcode_ip_8_reg & ~MP2_POSTCODE_IP_8_VALID_MASK) | (valid << MP2_POSTCODE_IP_8_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_ip_8_t {
          unsigned int ip                             : MP2_POSTCODE_IP_8_IP_SIZE;
          unsigned int valid                          : MP2_POSTCODE_IP_8_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_ip_8_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_ip_8_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_IP_8_VALID_SIZE;
          unsigned int ip                             : MP2_POSTCODE_IP_8_IP_SIZE;
     } mp2_postcode_ip_8_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_ip_8_t f;
} mp2_postcode_ip_8_u;


/*
 * MP2_POSTCODE_FEATURE_8 struct
 */

#define MP2_POSTCODE_FEATURE_8_REG_SIZE 32
#define MP2_POSTCODE_FEATURE_8_FEATURE_SIZE 8
#define MP2_POSTCODE_FEATURE_8_VALID_SIZE 1

#define MP2_POSTCODE_FEATURE_8_FEATURE_SHIFT 0
#define MP2_POSTCODE_FEATURE_8_VALID_SHIFT 8

#define MP2_POSTCODE_FEATURE_8_FEATURE_MASK 0xff
#define MP2_POSTCODE_FEATURE_8_VALID_MASK 0x100

#define MP2_POSTCODE_FEATURE_8_MASK \
     (MP2_POSTCODE_FEATURE_8_FEATURE_MASK | \
      MP2_POSTCODE_FEATURE_8_VALID_MASK)

#define MP2_POSTCODE_FEATURE_8_DEFAULT 0x00000000

#define MP2_POSTCODE_FEATURE_8_GET_FEATURE(mp2_postcode_feature_8) \
     ((mp2_postcode_feature_8 & MP2_POSTCODE_FEATURE_8_FEATURE_MASK) >> MP2_POSTCODE_FEATURE_8_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_8_GET_VALID(mp2_postcode_feature_8) \
     ((mp2_postcode_feature_8 & MP2_POSTCODE_FEATURE_8_VALID_MASK) >> MP2_POSTCODE_FEATURE_8_VALID_SHIFT)

#define MP2_POSTCODE_FEATURE_8_SET_FEATURE(mp2_postcode_feature_8_reg, feature) \
     mp2_postcode_feature_8_reg = (mp2_postcode_feature_8_reg & ~MP2_POSTCODE_FEATURE_8_FEATURE_MASK) | (feature << MP2_POSTCODE_FEATURE_8_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_8_SET_VALID(mp2_postcode_feature_8_reg, valid) \
     mp2_postcode_feature_8_reg = (mp2_postcode_feature_8_reg & ~MP2_POSTCODE_FEATURE_8_VALID_MASK) | (valid << MP2_POSTCODE_FEATURE_8_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_feature_8_t {
          unsigned int feature                        : MP2_POSTCODE_FEATURE_8_FEATURE_SIZE;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_8_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_feature_8_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_feature_8_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_8_VALID_SIZE;
          unsigned int feature                        : MP2_POSTCODE_FEATURE_8_FEATURE_SIZE;
     } mp2_postcode_feature_8_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_feature_8_t f;
} mp2_postcode_feature_8_u;


/*
 * MP2_POSTCODE_IP_9 struct
 */

#define MP2_POSTCODE_IP_9_REG_SIZE     32
#define MP2_POSTCODE_IP_9_IP_SIZE      8
#define MP2_POSTCODE_IP_9_VALID_SIZE   1

#define MP2_POSTCODE_IP_9_IP_SHIFT     0
#define MP2_POSTCODE_IP_9_VALID_SHIFT  8

#define MP2_POSTCODE_IP_9_IP_MASK      0xff
#define MP2_POSTCODE_IP_9_VALID_MASK   0x100

#define MP2_POSTCODE_IP_9_MASK \
     (MP2_POSTCODE_IP_9_IP_MASK | \
      MP2_POSTCODE_IP_9_VALID_MASK)

#define MP2_POSTCODE_IP_9_DEFAULT      0x00000000

#define MP2_POSTCODE_IP_9_GET_IP(mp2_postcode_ip_9) \
     ((mp2_postcode_ip_9 & MP2_POSTCODE_IP_9_IP_MASK) >> MP2_POSTCODE_IP_9_IP_SHIFT)
#define MP2_POSTCODE_IP_9_GET_VALID(mp2_postcode_ip_9) \
     ((mp2_postcode_ip_9 & MP2_POSTCODE_IP_9_VALID_MASK) >> MP2_POSTCODE_IP_9_VALID_SHIFT)

#define MP2_POSTCODE_IP_9_SET_IP(mp2_postcode_ip_9_reg, ip) \
     mp2_postcode_ip_9_reg = (mp2_postcode_ip_9_reg & ~MP2_POSTCODE_IP_9_IP_MASK) | (ip << MP2_POSTCODE_IP_9_IP_SHIFT)
#define MP2_POSTCODE_IP_9_SET_VALID(mp2_postcode_ip_9_reg, valid) \
     mp2_postcode_ip_9_reg = (mp2_postcode_ip_9_reg & ~MP2_POSTCODE_IP_9_VALID_MASK) | (valid << MP2_POSTCODE_IP_9_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_ip_9_t {
          unsigned int ip                             : MP2_POSTCODE_IP_9_IP_SIZE;
          unsigned int valid                          : MP2_POSTCODE_IP_9_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_ip_9_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_ip_9_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_IP_9_VALID_SIZE;
          unsigned int ip                             : MP2_POSTCODE_IP_9_IP_SIZE;
     } mp2_postcode_ip_9_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_ip_9_t f;
} mp2_postcode_ip_9_u;


/*
 * MP2_POSTCODE_FEATURE_9 struct
 */

#define MP2_POSTCODE_FEATURE_9_REG_SIZE 32
#define MP2_POSTCODE_FEATURE_9_FEATURE_SIZE 8
#define MP2_POSTCODE_FEATURE_9_VALID_SIZE 1

#define MP2_POSTCODE_FEATURE_9_FEATURE_SHIFT 0
#define MP2_POSTCODE_FEATURE_9_VALID_SHIFT 8

#define MP2_POSTCODE_FEATURE_9_FEATURE_MASK 0xff
#define MP2_POSTCODE_FEATURE_9_VALID_MASK 0x100

#define MP2_POSTCODE_FEATURE_9_MASK \
     (MP2_POSTCODE_FEATURE_9_FEATURE_MASK | \
      MP2_POSTCODE_FEATURE_9_VALID_MASK)

#define MP2_POSTCODE_FEATURE_9_DEFAULT 0x00000000

#define MP2_POSTCODE_FEATURE_9_GET_FEATURE(mp2_postcode_feature_9) \
     ((mp2_postcode_feature_9 & MP2_POSTCODE_FEATURE_9_FEATURE_MASK) >> MP2_POSTCODE_FEATURE_9_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_9_GET_VALID(mp2_postcode_feature_9) \
     ((mp2_postcode_feature_9 & MP2_POSTCODE_FEATURE_9_VALID_MASK) >> MP2_POSTCODE_FEATURE_9_VALID_SHIFT)

#define MP2_POSTCODE_FEATURE_9_SET_FEATURE(mp2_postcode_feature_9_reg, feature) \
     mp2_postcode_feature_9_reg = (mp2_postcode_feature_9_reg & ~MP2_POSTCODE_FEATURE_9_FEATURE_MASK) | (feature << MP2_POSTCODE_FEATURE_9_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_9_SET_VALID(mp2_postcode_feature_9_reg, valid) \
     mp2_postcode_feature_9_reg = (mp2_postcode_feature_9_reg & ~MP2_POSTCODE_FEATURE_9_VALID_MASK) | (valid << MP2_POSTCODE_FEATURE_9_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_feature_9_t {
          unsigned int feature                        : MP2_POSTCODE_FEATURE_9_FEATURE_SIZE;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_9_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_feature_9_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_feature_9_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_9_VALID_SIZE;
          unsigned int feature                        : MP2_POSTCODE_FEATURE_9_FEATURE_SIZE;
     } mp2_postcode_feature_9_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_feature_9_t f;
} mp2_postcode_feature_9_u;


/*
 * MP2_POSTCODE_IP_10 struct
 */

#define MP2_POSTCODE_IP_10_REG_SIZE    32
#define MP2_POSTCODE_IP_10_IP_SIZE     8
#define MP2_POSTCODE_IP_10_VALID_SIZE  1

#define MP2_POSTCODE_IP_10_IP_SHIFT    0
#define MP2_POSTCODE_IP_10_VALID_SHIFT 8

#define MP2_POSTCODE_IP_10_IP_MASK     0xff
#define MP2_POSTCODE_IP_10_VALID_MASK  0x100

#define MP2_POSTCODE_IP_10_MASK \
     (MP2_POSTCODE_IP_10_IP_MASK | \
      MP2_POSTCODE_IP_10_VALID_MASK)

#define MP2_POSTCODE_IP_10_DEFAULT     0x00000000

#define MP2_POSTCODE_IP_10_GET_IP(mp2_postcode_ip_10) \
     ((mp2_postcode_ip_10 & MP2_POSTCODE_IP_10_IP_MASK) >> MP2_POSTCODE_IP_10_IP_SHIFT)
#define MP2_POSTCODE_IP_10_GET_VALID(mp2_postcode_ip_10) \
     ((mp2_postcode_ip_10 & MP2_POSTCODE_IP_10_VALID_MASK) >> MP2_POSTCODE_IP_10_VALID_SHIFT)

#define MP2_POSTCODE_IP_10_SET_IP(mp2_postcode_ip_10_reg, ip) \
     mp2_postcode_ip_10_reg = (mp2_postcode_ip_10_reg & ~MP2_POSTCODE_IP_10_IP_MASK) | (ip << MP2_POSTCODE_IP_10_IP_SHIFT)
#define MP2_POSTCODE_IP_10_SET_VALID(mp2_postcode_ip_10_reg, valid) \
     mp2_postcode_ip_10_reg = (mp2_postcode_ip_10_reg & ~MP2_POSTCODE_IP_10_VALID_MASK) | (valid << MP2_POSTCODE_IP_10_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_ip_10_t {
          unsigned int ip                             : MP2_POSTCODE_IP_10_IP_SIZE;
          unsigned int valid                          : MP2_POSTCODE_IP_10_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_ip_10_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_ip_10_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_IP_10_VALID_SIZE;
          unsigned int ip                             : MP2_POSTCODE_IP_10_IP_SIZE;
     } mp2_postcode_ip_10_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_ip_10_t f;
} mp2_postcode_ip_10_u;


/*
 * MP2_POSTCODE_FEATURE_10 struct
 */

#define MP2_POSTCODE_FEATURE_10_REG_SIZE 32
#define MP2_POSTCODE_FEATURE_10_FEATURE_SIZE 8
#define MP2_POSTCODE_FEATURE_10_VALID_SIZE 1

#define MP2_POSTCODE_FEATURE_10_FEATURE_SHIFT 0
#define MP2_POSTCODE_FEATURE_10_VALID_SHIFT 8

#define MP2_POSTCODE_FEATURE_10_FEATURE_MASK 0xff
#define MP2_POSTCODE_FEATURE_10_VALID_MASK 0x100

#define MP2_POSTCODE_FEATURE_10_MASK \
     (MP2_POSTCODE_FEATURE_10_FEATURE_MASK | \
      MP2_POSTCODE_FEATURE_10_VALID_MASK)

#define MP2_POSTCODE_FEATURE_10_DEFAULT 0x00000000

#define MP2_POSTCODE_FEATURE_10_GET_FEATURE(mp2_postcode_feature_10) \
     ((mp2_postcode_feature_10 & MP2_POSTCODE_FEATURE_10_FEATURE_MASK) >> MP2_POSTCODE_FEATURE_10_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_10_GET_VALID(mp2_postcode_feature_10) \
     ((mp2_postcode_feature_10 & MP2_POSTCODE_FEATURE_10_VALID_MASK) >> MP2_POSTCODE_FEATURE_10_VALID_SHIFT)

#define MP2_POSTCODE_FEATURE_10_SET_FEATURE(mp2_postcode_feature_10_reg, feature) \
     mp2_postcode_feature_10_reg = (mp2_postcode_feature_10_reg & ~MP2_POSTCODE_FEATURE_10_FEATURE_MASK) | (feature << MP2_POSTCODE_FEATURE_10_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_10_SET_VALID(mp2_postcode_feature_10_reg, valid) \
     mp2_postcode_feature_10_reg = (mp2_postcode_feature_10_reg & ~MP2_POSTCODE_FEATURE_10_VALID_MASK) | (valid << MP2_POSTCODE_FEATURE_10_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_feature_10_t {
          unsigned int feature                        : MP2_POSTCODE_FEATURE_10_FEATURE_SIZE;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_10_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_feature_10_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_feature_10_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_10_VALID_SIZE;
          unsigned int feature                        : MP2_POSTCODE_FEATURE_10_FEATURE_SIZE;
     } mp2_postcode_feature_10_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_feature_10_t f;
} mp2_postcode_feature_10_u;


/*
 * MP2_POSTCODE_IP_11 struct
 */

#define MP2_POSTCODE_IP_11_REG_SIZE    32
#define MP2_POSTCODE_IP_11_IP_SIZE     8
#define MP2_POSTCODE_IP_11_VALID_SIZE  1

#define MP2_POSTCODE_IP_11_IP_SHIFT    0
#define MP2_POSTCODE_IP_11_VALID_SHIFT 8

#define MP2_POSTCODE_IP_11_IP_MASK     0xff
#define MP2_POSTCODE_IP_11_VALID_MASK  0x100

#define MP2_POSTCODE_IP_11_MASK \
     (MP2_POSTCODE_IP_11_IP_MASK | \
      MP2_POSTCODE_IP_11_VALID_MASK)

#define MP2_POSTCODE_IP_11_DEFAULT     0x00000000

#define MP2_POSTCODE_IP_11_GET_IP(mp2_postcode_ip_11) \
     ((mp2_postcode_ip_11 & MP2_POSTCODE_IP_11_IP_MASK) >> MP2_POSTCODE_IP_11_IP_SHIFT)
#define MP2_POSTCODE_IP_11_GET_VALID(mp2_postcode_ip_11) \
     ((mp2_postcode_ip_11 & MP2_POSTCODE_IP_11_VALID_MASK) >> MP2_POSTCODE_IP_11_VALID_SHIFT)

#define MP2_POSTCODE_IP_11_SET_IP(mp2_postcode_ip_11_reg, ip) \
     mp2_postcode_ip_11_reg = (mp2_postcode_ip_11_reg & ~MP2_POSTCODE_IP_11_IP_MASK) | (ip << MP2_POSTCODE_IP_11_IP_SHIFT)
#define MP2_POSTCODE_IP_11_SET_VALID(mp2_postcode_ip_11_reg, valid) \
     mp2_postcode_ip_11_reg = (mp2_postcode_ip_11_reg & ~MP2_POSTCODE_IP_11_VALID_MASK) | (valid << MP2_POSTCODE_IP_11_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_ip_11_t {
          unsigned int ip                             : MP2_POSTCODE_IP_11_IP_SIZE;
          unsigned int valid                          : MP2_POSTCODE_IP_11_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_ip_11_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_ip_11_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_IP_11_VALID_SIZE;
          unsigned int ip                             : MP2_POSTCODE_IP_11_IP_SIZE;
     } mp2_postcode_ip_11_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_ip_11_t f;
} mp2_postcode_ip_11_u;


/*
 * MP2_POSTCODE_FEATURE_11 struct
 */

#define MP2_POSTCODE_FEATURE_11_REG_SIZE 32
#define MP2_POSTCODE_FEATURE_11_FEATURE_SIZE 8
#define MP2_POSTCODE_FEATURE_11_VALID_SIZE 1

#define MP2_POSTCODE_FEATURE_11_FEATURE_SHIFT 0
#define MP2_POSTCODE_FEATURE_11_VALID_SHIFT 8

#define MP2_POSTCODE_FEATURE_11_FEATURE_MASK 0xff
#define MP2_POSTCODE_FEATURE_11_VALID_MASK 0x100

#define MP2_POSTCODE_FEATURE_11_MASK \
     (MP2_POSTCODE_FEATURE_11_FEATURE_MASK | \
      MP2_POSTCODE_FEATURE_11_VALID_MASK)

#define MP2_POSTCODE_FEATURE_11_DEFAULT 0x00000000

#define MP2_POSTCODE_FEATURE_11_GET_FEATURE(mp2_postcode_feature_11) \
     ((mp2_postcode_feature_11 & MP2_POSTCODE_FEATURE_11_FEATURE_MASK) >> MP2_POSTCODE_FEATURE_11_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_11_GET_VALID(mp2_postcode_feature_11) \
     ((mp2_postcode_feature_11 & MP2_POSTCODE_FEATURE_11_VALID_MASK) >> MP2_POSTCODE_FEATURE_11_VALID_SHIFT)

#define MP2_POSTCODE_FEATURE_11_SET_FEATURE(mp2_postcode_feature_11_reg, feature) \
     mp2_postcode_feature_11_reg = (mp2_postcode_feature_11_reg & ~MP2_POSTCODE_FEATURE_11_FEATURE_MASK) | (feature << MP2_POSTCODE_FEATURE_11_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_11_SET_VALID(mp2_postcode_feature_11_reg, valid) \
     mp2_postcode_feature_11_reg = (mp2_postcode_feature_11_reg & ~MP2_POSTCODE_FEATURE_11_VALID_MASK) | (valid << MP2_POSTCODE_FEATURE_11_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_feature_11_t {
          unsigned int feature                        : MP2_POSTCODE_FEATURE_11_FEATURE_SIZE;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_11_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_feature_11_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_feature_11_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_11_VALID_SIZE;
          unsigned int feature                        : MP2_POSTCODE_FEATURE_11_FEATURE_SIZE;
     } mp2_postcode_feature_11_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_feature_11_t f;
} mp2_postcode_feature_11_u;


/*
 * MP2_POSTCODE_IP_12 struct
 */

#define MP2_POSTCODE_IP_12_REG_SIZE    32
#define MP2_POSTCODE_IP_12_IP_SIZE     8
#define MP2_POSTCODE_IP_12_VALID_SIZE  1

#define MP2_POSTCODE_IP_12_IP_SHIFT    0
#define MP2_POSTCODE_IP_12_VALID_SHIFT 8

#define MP2_POSTCODE_IP_12_IP_MASK     0xff
#define MP2_POSTCODE_IP_12_VALID_MASK  0x100

#define MP2_POSTCODE_IP_12_MASK \
     (MP2_POSTCODE_IP_12_IP_MASK | \
      MP2_POSTCODE_IP_12_VALID_MASK)

#define MP2_POSTCODE_IP_12_DEFAULT     0x00000000

#define MP2_POSTCODE_IP_12_GET_IP(mp2_postcode_ip_12) \
     ((mp2_postcode_ip_12 & MP2_POSTCODE_IP_12_IP_MASK) >> MP2_POSTCODE_IP_12_IP_SHIFT)
#define MP2_POSTCODE_IP_12_GET_VALID(mp2_postcode_ip_12) \
     ((mp2_postcode_ip_12 & MP2_POSTCODE_IP_12_VALID_MASK) >> MP2_POSTCODE_IP_12_VALID_SHIFT)

#define MP2_POSTCODE_IP_12_SET_IP(mp2_postcode_ip_12_reg, ip) \
     mp2_postcode_ip_12_reg = (mp2_postcode_ip_12_reg & ~MP2_POSTCODE_IP_12_IP_MASK) | (ip << MP2_POSTCODE_IP_12_IP_SHIFT)
#define MP2_POSTCODE_IP_12_SET_VALID(mp2_postcode_ip_12_reg, valid) \
     mp2_postcode_ip_12_reg = (mp2_postcode_ip_12_reg & ~MP2_POSTCODE_IP_12_VALID_MASK) | (valid << MP2_POSTCODE_IP_12_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_ip_12_t {
          unsigned int ip                             : MP2_POSTCODE_IP_12_IP_SIZE;
          unsigned int valid                          : MP2_POSTCODE_IP_12_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_ip_12_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_ip_12_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_IP_12_VALID_SIZE;
          unsigned int ip                             : MP2_POSTCODE_IP_12_IP_SIZE;
     } mp2_postcode_ip_12_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_ip_12_t f;
} mp2_postcode_ip_12_u;


/*
 * MP2_POSTCODE_FEATURE_12 struct
 */

#define MP2_POSTCODE_FEATURE_12_REG_SIZE 32
#define MP2_POSTCODE_FEATURE_12_FEATURE_SIZE 8
#define MP2_POSTCODE_FEATURE_12_VALID_SIZE 1

#define MP2_POSTCODE_FEATURE_12_FEATURE_SHIFT 0
#define MP2_POSTCODE_FEATURE_12_VALID_SHIFT 8

#define MP2_POSTCODE_FEATURE_12_FEATURE_MASK 0xff
#define MP2_POSTCODE_FEATURE_12_VALID_MASK 0x100

#define MP2_POSTCODE_FEATURE_12_MASK \
     (MP2_POSTCODE_FEATURE_12_FEATURE_MASK | \
      MP2_POSTCODE_FEATURE_12_VALID_MASK)

#define MP2_POSTCODE_FEATURE_12_DEFAULT 0x00000000

#define MP2_POSTCODE_FEATURE_12_GET_FEATURE(mp2_postcode_feature_12) \
     ((mp2_postcode_feature_12 & MP2_POSTCODE_FEATURE_12_FEATURE_MASK) >> MP2_POSTCODE_FEATURE_12_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_12_GET_VALID(mp2_postcode_feature_12) \
     ((mp2_postcode_feature_12 & MP2_POSTCODE_FEATURE_12_VALID_MASK) >> MP2_POSTCODE_FEATURE_12_VALID_SHIFT)

#define MP2_POSTCODE_FEATURE_12_SET_FEATURE(mp2_postcode_feature_12_reg, feature) \
     mp2_postcode_feature_12_reg = (mp2_postcode_feature_12_reg & ~MP2_POSTCODE_FEATURE_12_FEATURE_MASK) | (feature << MP2_POSTCODE_FEATURE_12_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_12_SET_VALID(mp2_postcode_feature_12_reg, valid) \
     mp2_postcode_feature_12_reg = (mp2_postcode_feature_12_reg & ~MP2_POSTCODE_FEATURE_12_VALID_MASK) | (valid << MP2_POSTCODE_FEATURE_12_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_feature_12_t {
          unsigned int feature                        : MP2_POSTCODE_FEATURE_12_FEATURE_SIZE;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_12_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_feature_12_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_feature_12_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_12_VALID_SIZE;
          unsigned int feature                        : MP2_POSTCODE_FEATURE_12_FEATURE_SIZE;
     } mp2_postcode_feature_12_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_feature_12_t f;
} mp2_postcode_feature_12_u;


/*
 * MP2_POSTCODE_IP_13 struct
 */

#define MP2_POSTCODE_IP_13_REG_SIZE    32
#define MP2_POSTCODE_IP_13_IP_SIZE     8
#define MP2_POSTCODE_IP_13_VALID_SIZE  1

#define MP2_POSTCODE_IP_13_IP_SHIFT    0
#define MP2_POSTCODE_IP_13_VALID_SHIFT 8

#define MP2_POSTCODE_IP_13_IP_MASK     0xff
#define MP2_POSTCODE_IP_13_VALID_MASK  0x100

#define MP2_POSTCODE_IP_13_MASK \
     (MP2_POSTCODE_IP_13_IP_MASK | \
      MP2_POSTCODE_IP_13_VALID_MASK)

#define MP2_POSTCODE_IP_13_DEFAULT     0x00000000

#define MP2_POSTCODE_IP_13_GET_IP(mp2_postcode_ip_13) \
     ((mp2_postcode_ip_13 & MP2_POSTCODE_IP_13_IP_MASK) >> MP2_POSTCODE_IP_13_IP_SHIFT)
#define MP2_POSTCODE_IP_13_GET_VALID(mp2_postcode_ip_13) \
     ((mp2_postcode_ip_13 & MP2_POSTCODE_IP_13_VALID_MASK) >> MP2_POSTCODE_IP_13_VALID_SHIFT)

#define MP2_POSTCODE_IP_13_SET_IP(mp2_postcode_ip_13_reg, ip) \
     mp2_postcode_ip_13_reg = (mp2_postcode_ip_13_reg & ~MP2_POSTCODE_IP_13_IP_MASK) | (ip << MP2_POSTCODE_IP_13_IP_SHIFT)
#define MP2_POSTCODE_IP_13_SET_VALID(mp2_postcode_ip_13_reg, valid) \
     mp2_postcode_ip_13_reg = (mp2_postcode_ip_13_reg & ~MP2_POSTCODE_IP_13_VALID_MASK) | (valid << MP2_POSTCODE_IP_13_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_ip_13_t {
          unsigned int ip                             : MP2_POSTCODE_IP_13_IP_SIZE;
          unsigned int valid                          : MP2_POSTCODE_IP_13_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_ip_13_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_ip_13_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_IP_13_VALID_SIZE;
          unsigned int ip                             : MP2_POSTCODE_IP_13_IP_SIZE;
     } mp2_postcode_ip_13_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_ip_13_t f;
} mp2_postcode_ip_13_u;


/*
 * MP2_POSTCODE_FEATURE_13 struct
 */

#define MP2_POSTCODE_FEATURE_13_REG_SIZE 32
#define MP2_POSTCODE_FEATURE_13_FEATURE_SIZE 8
#define MP2_POSTCODE_FEATURE_13_VALID_SIZE 1

#define MP2_POSTCODE_FEATURE_13_FEATURE_SHIFT 0
#define MP2_POSTCODE_FEATURE_13_VALID_SHIFT 8

#define MP2_POSTCODE_FEATURE_13_FEATURE_MASK 0xff
#define MP2_POSTCODE_FEATURE_13_VALID_MASK 0x100

#define MP2_POSTCODE_FEATURE_13_MASK \
     (MP2_POSTCODE_FEATURE_13_FEATURE_MASK | \
      MP2_POSTCODE_FEATURE_13_VALID_MASK)

#define MP2_POSTCODE_FEATURE_13_DEFAULT 0x00000000

#define MP2_POSTCODE_FEATURE_13_GET_FEATURE(mp2_postcode_feature_13) \
     ((mp2_postcode_feature_13 & MP2_POSTCODE_FEATURE_13_FEATURE_MASK) >> MP2_POSTCODE_FEATURE_13_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_13_GET_VALID(mp2_postcode_feature_13) \
     ((mp2_postcode_feature_13 & MP2_POSTCODE_FEATURE_13_VALID_MASK) >> MP2_POSTCODE_FEATURE_13_VALID_SHIFT)

#define MP2_POSTCODE_FEATURE_13_SET_FEATURE(mp2_postcode_feature_13_reg, feature) \
     mp2_postcode_feature_13_reg = (mp2_postcode_feature_13_reg & ~MP2_POSTCODE_FEATURE_13_FEATURE_MASK) | (feature << MP2_POSTCODE_FEATURE_13_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_13_SET_VALID(mp2_postcode_feature_13_reg, valid) \
     mp2_postcode_feature_13_reg = (mp2_postcode_feature_13_reg & ~MP2_POSTCODE_FEATURE_13_VALID_MASK) | (valid << MP2_POSTCODE_FEATURE_13_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_feature_13_t {
          unsigned int feature                        : MP2_POSTCODE_FEATURE_13_FEATURE_SIZE;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_13_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_feature_13_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_feature_13_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_13_VALID_SIZE;
          unsigned int feature                        : MP2_POSTCODE_FEATURE_13_FEATURE_SIZE;
     } mp2_postcode_feature_13_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_feature_13_t f;
} mp2_postcode_feature_13_u;


/*
 * MP2_POSTCODE_IP_14 struct
 */

#define MP2_POSTCODE_IP_14_REG_SIZE    32
#define MP2_POSTCODE_IP_14_IP_SIZE     8
#define MP2_POSTCODE_IP_14_VALID_SIZE  1

#define MP2_POSTCODE_IP_14_IP_SHIFT    0
#define MP2_POSTCODE_IP_14_VALID_SHIFT 8

#define MP2_POSTCODE_IP_14_IP_MASK     0xff
#define MP2_POSTCODE_IP_14_VALID_MASK  0x100

#define MP2_POSTCODE_IP_14_MASK \
     (MP2_POSTCODE_IP_14_IP_MASK | \
      MP2_POSTCODE_IP_14_VALID_MASK)

#define MP2_POSTCODE_IP_14_DEFAULT     0x00000000

#define MP2_POSTCODE_IP_14_GET_IP(mp2_postcode_ip_14) \
     ((mp2_postcode_ip_14 & MP2_POSTCODE_IP_14_IP_MASK) >> MP2_POSTCODE_IP_14_IP_SHIFT)
#define MP2_POSTCODE_IP_14_GET_VALID(mp2_postcode_ip_14) \
     ((mp2_postcode_ip_14 & MP2_POSTCODE_IP_14_VALID_MASK) >> MP2_POSTCODE_IP_14_VALID_SHIFT)

#define MP2_POSTCODE_IP_14_SET_IP(mp2_postcode_ip_14_reg, ip) \
     mp2_postcode_ip_14_reg = (mp2_postcode_ip_14_reg & ~MP2_POSTCODE_IP_14_IP_MASK) | (ip << MP2_POSTCODE_IP_14_IP_SHIFT)
#define MP2_POSTCODE_IP_14_SET_VALID(mp2_postcode_ip_14_reg, valid) \
     mp2_postcode_ip_14_reg = (mp2_postcode_ip_14_reg & ~MP2_POSTCODE_IP_14_VALID_MASK) | (valid << MP2_POSTCODE_IP_14_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_ip_14_t {
          unsigned int ip                             : MP2_POSTCODE_IP_14_IP_SIZE;
          unsigned int valid                          : MP2_POSTCODE_IP_14_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_ip_14_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_ip_14_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_IP_14_VALID_SIZE;
          unsigned int ip                             : MP2_POSTCODE_IP_14_IP_SIZE;
     } mp2_postcode_ip_14_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_ip_14_t f;
} mp2_postcode_ip_14_u;


/*
 * MP2_POSTCODE_FEATURE_14 struct
 */

#define MP2_POSTCODE_FEATURE_14_REG_SIZE 32
#define MP2_POSTCODE_FEATURE_14_FEATURE_SIZE 8
#define MP2_POSTCODE_FEATURE_14_VALID_SIZE 1

#define MP2_POSTCODE_FEATURE_14_FEATURE_SHIFT 0
#define MP2_POSTCODE_FEATURE_14_VALID_SHIFT 8

#define MP2_POSTCODE_FEATURE_14_FEATURE_MASK 0xff
#define MP2_POSTCODE_FEATURE_14_VALID_MASK 0x100

#define MP2_POSTCODE_FEATURE_14_MASK \
     (MP2_POSTCODE_FEATURE_14_FEATURE_MASK | \
      MP2_POSTCODE_FEATURE_14_VALID_MASK)

#define MP2_POSTCODE_FEATURE_14_DEFAULT 0x00000000

#define MP2_POSTCODE_FEATURE_14_GET_FEATURE(mp2_postcode_feature_14) \
     ((mp2_postcode_feature_14 & MP2_POSTCODE_FEATURE_14_FEATURE_MASK) >> MP2_POSTCODE_FEATURE_14_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_14_GET_VALID(mp2_postcode_feature_14) \
     ((mp2_postcode_feature_14 & MP2_POSTCODE_FEATURE_14_VALID_MASK) >> MP2_POSTCODE_FEATURE_14_VALID_SHIFT)

#define MP2_POSTCODE_FEATURE_14_SET_FEATURE(mp2_postcode_feature_14_reg, feature) \
     mp2_postcode_feature_14_reg = (mp2_postcode_feature_14_reg & ~MP2_POSTCODE_FEATURE_14_FEATURE_MASK) | (feature << MP2_POSTCODE_FEATURE_14_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_14_SET_VALID(mp2_postcode_feature_14_reg, valid) \
     mp2_postcode_feature_14_reg = (mp2_postcode_feature_14_reg & ~MP2_POSTCODE_FEATURE_14_VALID_MASK) | (valid << MP2_POSTCODE_FEATURE_14_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_feature_14_t {
          unsigned int feature                        : MP2_POSTCODE_FEATURE_14_FEATURE_SIZE;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_14_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_feature_14_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_feature_14_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_14_VALID_SIZE;
          unsigned int feature                        : MP2_POSTCODE_FEATURE_14_FEATURE_SIZE;
     } mp2_postcode_feature_14_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_feature_14_t f;
} mp2_postcode_feature_14_u;


/*
 * MP2_POSTCODE_IP_15 struct
 */

#define MP2_POSTCODE_IP_15_REG_SIZE    32
#define MP2_POSTCODE_IP_15_IP_SIZE     8
#define MP2_POSTCODE_IP_15_VALID_SIZE  1

#define MP2_POSTCODE_IP_15_IP_SHIFT    0
#define MP2_POSTCODE_IP_15_VALID_SHIFT 8

#define MP2_POSTCODE_IP_15_IP_MASK     0xff
#define MP2_POSTCODE_IP_15_VALID_MASK  0x100

#define MP2_POSTCODE_IP_15_MASK \
     (MP2_POSTCODE_IP_15_IP_MASK | \
      MP2_POSTCODE_IP_15_VALID_MASK)

#define MP2_POSTCODE_IP_15_DEFAULT     0x00000000

#define MP2_POSTCODE_IP_15_GET_IP(mp2_postcode_ip_15) \
     ((mp2_postcode_ip_15 & MP2_POSTCODE_IP_15_IP_MASK) >> MP2_POSTCODE_IP_15_IP_SHIFT)
#define MP2_POSTCODE_IP_15_GET_VALID(mp2_postcode_ip_15) \
     ((mp2_postcode_ip_15 & MP2_POSTCODE_IP_15_VALID_MASK) >> MP2_POSTCODE_IP_15_VALID_SHIFT)

#define MP2_POSTCODE_IP_15_SET_IP(mp2_postcode_ip_15_reg, ip) \
     mp2_postcode_ip_15_reg = (mp2_postcode_ip_15_reg & ~MP2_POSTCODE_IP_15_IP_MASK) | (ip << MP2_POSTCODE_IP_15_IP_SHIFT)
#define MP2_POSTCODE_IP_15_SET_VALID(mp2_postcode_ip_15_reg, valid) \
     mp2_postcode_ip_15_reg = (mp2_postcode_ip_15_reg & ~MP2_POSTCODE_IP_15_VALID_MASK) | (valid << MP2_POSTCODE_IP_15_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_ip_15_t {
          unsigned int ip                             : MP2_POSTCODE_IP_15_IP_SIZE;
          unsigned int valid                          : MP2_POSTCODE_IP_15_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_ip_15_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_ip_15_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_IP_15_VALID_SIZE;
          unsigned int ip                             : MP2_POSTCODE_IP_15_IP_SIZE;
     } mp2_postcode_ip_15_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_ip_15_t f;
} mp2_postcode_ip_15_u;


/*
 * MP2_POSTCODE_FEATURE_15 struct
 */

#define MP2_POSTCODE_FEATURE_15_REG_SIZE 32
#define MP2_POSTCODE_FEATURE_15_FEATURE_SIZE 8
#define MP2_POSTCODE_FEATURE_15_VALID_SIZE 1

#define MP2_POSTCODE_FEATURE_15_FEATURE_SHIFT 0
#define MP2_POSTCODE_FEATURE_15_VALID_SHIFT 8

#define MP2_POSTCODE_FEATURE_15_FEATURE_MASK 0xff
#define MP2_POSTCODE_FEATURE_15_VALID_MASK 0x100

#define MP2_POSTCODE_FEATURE_15_MASK \
     (MP2_POSTCODE_FEATURE_15_FEATURE_MASK | \
      MP2_POSTCODE_FEATURE_15_VALID_MASK)

#define MP2_POSTCODE_FEATURE_15_DEFAULT 0x00000000

#define MP2_POSTCODE_FEATURE_15_GET_FEATURE(mp2_postcode_feature_15) \
     ((mp2_postcode_feature_15 & MP2_POSTCODE_FEATURE_15_FEATURE_MASK) >> MP2_POSTCODE_FEATURE_15_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_15_GET_VALID(mp2_postcode_feature_15) \
     ((mp2_postcode_feature_15 & MP2_POSTCODE_FEATURE_15_VALID_MASK) >> MP2_POSTCODE_FEATURE_15_VALID_SHIFT)

#define MP2_POSTCODE_FEATURE_15_SET_FEATURE(mp2_postcode_feature_15_reg, feature) \
     mp2_postcode_feature_15_reg = (mp2_postcode_feature_15_reg & ~MP2_POSTCODE_FEATURE_15_FEATURE_MASK) | (feature << MP2_POSTCODE_FEATURE_15_FEATURE_SHIFT)
#define MP2_POSTCODE_FEATURE_15_SET_VALID(mp2_postcode_feature_15_reg, valid) \
     mp2_postcode_feature_15_reg = (mp2_postcode_feature_15_reg & ~MP2_POSTCODE_FEATURE_15_VALID_MASK) | (valid << MP2_POSTCODE_FEATURE_15_VALID_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_postcode_feature_15_t {
          unsigned int feature                        : MP2_POSTCODE_FEATURE_15_FEATURE_SIZE;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_15_VALID_SIZE;
          unsigned int                                : 23;
     } mp2_postcode_feature_15_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_postcode_feature_15_t {
          unsigned int                                : 23;
          unsigned int valid                          : MP2_POSTCODE_FEATURE_15_VALID_SIZE;
          unsigned int feature                        : MP2_POSTCODE_FEATURE_15_FEATURE_SIZE;
     } mp2_postcode_feature_15_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_postcode_feature_15_t f;
} mp2_postcode_feature_15_u;


/*
 * MP2_PMI_0 struct
 */

#define MP2_PMI_0_REG_SIZE             32
#define MP2_PMI_0_DATA_SIZE            32

#define MP2_PMI_0_DATA_SHIFT           0

#define MP2_PMI_0_DATA_MASK            0xffffffff

#define MP2_PMI_0_MASK \
     (MP2_PMI_0_DATA_MASK)

#define MP2_PMI_0_DEFAULT              0x00000000

#define MP2_PMI_0_GET_DATA(mp2_pmi_0) \
     ((mp2_pmi_0 & MP2_PMI_0_DATA_MASK) >> MP2_PMI_0_DATA_SHIFT)

#define MP2_PMI_0_SET_DATA(mp2_pmi_0_reg, data) \
     mp2_pmi_0_reg = (mp2_pmi_0_reg & ~MP2_PMI_0_DATA_MASK) | (data << MP2_PMI_0_DATA_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_0_t {
          unsigned int data                           : MP2_PMI_0_DATA_SIZE;
     } mp2_pmi_0_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_0_t {
          unsigned int data                           : MP2_PMI_0_DATA_SIZE;
     } mp2_pmi_0_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_0_t f;
} mp2_pmi_0_u;


/*
 * MP2_PMI_0_STATUS struct
 */

#define MP2_PMI_0_STATUS_REG_SIZE      32
#define MP2_PMI_0_STATUS_FULL_SIZE     1
#define MP2_PMI_0_STATUS_EMPTY_SIZE    1

#define MP2_PMI_0_STATUS_FULL_SHIFT    0
#define MP2_PMI_0_STATUS_EMPTY_SHIFT   1

#define MP2_PMI_0_STATUS_FULL_MASK     0x1
#define MP2_PMI_0_STATUS_EMPTY_MASK    0x2

#define MP2_PMI_0_STATUS_MASK \
     (MP2_PMI_0_STATUS_FULL_MASK | \
      MP2_PMI_0_STATUS_EMPTY_MASK)

#define MP2_PMI_0_STATUS_DEFAULT       0x00000002

#define MP2_PMI_0_STATUS_GET_FULL(mp2_pmi_0_status) \
     ((mp2_pmi_0_status & MP2_PMI_0_STATUS_FULL_MASK) >> MP2_PMI_0_STATUS_FULL_SHIFT)
#define MP2_PMI_0_STATUS_GET_EMPTY(mp2_pmi_0_status) \
     ((mp2_pmi_0_status & MP2_PMI_0_STATUS_EMPTY_MASK) >> MP2_PMI_0_STATUS_EMPTY_SHIFT)

#define MP2_PMI_0_STATUS_SET_FULL(mp2_pmi_0_status_reg, full) \
     mp2_pmi_0_status_reg = (mp2_pmi_0_status_reg & ~MP2_PMI_0_STATUS_FULL_MASK) | (full << MP2_PMI_0_STATUS_FULL_SHIFT)
#define MP2_PMI_0_STATUS_SET_EMPTY(mp2_pmi_0_status_reg, empty) \
     mp2_pmi_0_status_reg = (mp2_pmi_0_status_reg & ~MP2_PMI_0_STATUS_EMPTY_MASK) | (empty << MP2_PMI_0_STATUS_EMPTY_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_0_status_t {
          unsigned int full                           : MP2_PMI_0_STATUS_FULL_SIZE;
          unsigned int empty                          : MP2_PMI_0_STATUS_EMPTY_SIZE;
          unsigned int                                : 30;
     } mp2_pmi_0_status_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_0_status_t {
          unsigned int                                : 30;
          unsigned int empty                          : MP2_PMI_0_STATUS_EMPTY_SIZE;
          unsigned int full                           : MP2_PMI_0_STATUS_FULL_SIZE;
     } mp2_pmi_0_status_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_0_status_t f;
} mp2_pmi_0_status_u;


/*
 * MP2_PMI_0_READ_POINTER struct
 */

#define MP2_PMI_0_READ_POINTER_REG_SIZE 32
#define MP2_PMI_0_READ_POINTER_CURRENT_SIZE 18

#define MP2_PMI_0_READ_POINTER_CURRENT_SHIFT 0

#define MP2_PMI_0_READ_POINTER_CURRENT_MASK 0x3ffff

#define MP2_PMI_0_READ_POINTER_MASK \
     (MP2_PMI_0_READ_POINTER_CURRENT_MASK)

#define MP2_PMI_0_READ_POINTER_DEFAULT 0x00000000

#define MP2_PMI_0_READ_POINTER_GET_CURRENT(mp2_pmi_0_read_pointer) \
     ((mp2_pmi_0_read_pointer & MP2_PMI_0_READ_POINTER_CURRENT_MASK) >> MP2_PMI_0_READ_POINTER_CURRENT_SHIFT)

#define MP2_PMI_0_READ_POINTER_SET_CURRENT(mp2_pmi_0_read_pointer_reg, current) \
     mp2_pmi_0_read_pointer_reg = (mp2_pmi_0_read_pointer_reg & ~MP2_PMI_0_READ_POINTER_CURRENT_MASK) | (current << MP2_PMI_0_READ_POINTER_CURRENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_0_read_pointer_t {
          unsigned int current                        : MP2_PMI_0_READ_POINTER_CURRENT_SIZE;
          unsigned int                                : 14;
     } mp2_pmi_0_read_pointer_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_0_read_pointer_t {
          unsigned int                                : 14;
          unsigned int current                        : MP2_PMI_0_READ_POINTER_CURRENT_SIZE;
     } mp2_pmi_0_read_pointer_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_0_read_pointer_t f;
} mp2_pmi_0_read_pointer_u;


/*
 * MP2_PMI_0_WRITE_POINTER struct
 */

#define MP2_PMI_0_WRITE_POINTER_REG_SIZE 32
#define MP2_PMI_0_WRITE_POINTER_CURRENT_SIZE 18

#define MP2_PMI_0_WRITE_POINTER_CURRENT_SHIFT 0

#define MP2_PMI_0_WRITE_POINTER_CURRENT_MASK 0x3ffff

#define MP2_PMI_0_WRITE_POINTER_MASK \
     (MP2_PMI_0_WRITE_POINTER_CURRENT_MASK)

#define MP2_PMI_0_WRITE_POINTER_DEFAULT 0x00000000

#define MP2_PMI_0_WRITE_POINTER_GET_CURRENT(mp2_pmi_0_write_pointer) \
     ((mp2_pmi_0_write_pointer & MP2_PMI_0_WRITE_POINTER_CURRENT_MASK) >> MP2_PMI_0_WRITE_POINTER_CURRENT_SHIFT)

#define MP2_PMI_0_WRITE_POINTER_SET_CURRENT(mp2_pmi_0_write_pointer_reg, current) \
     mp2_pmi_0_write_pointer_reg = (mp2_pmi_0_write_pointer_reg & ~MP2_PMI_0_WRITE_POINTER_CURRENT_MASK) | (current << MP2_PMI_0_WRITE_POINTER_CURRENT_SHIFT)

#if		defined(LITTLEENDIAN_CPU)

     typedef struct _mp2_pmi_0_write_pointer_t {
          unsigned int current                        : MP2_PMI_0_WRITE_POINTER_CURRENT_SIZE;
          unsigned int                                : 14;
     } mp2_pmi_0_write_pointer_t;

#elif		defined(BIGENDIAN_CPU)

     typedef struct _mp2_pmi_0_write_pointer_t {
          unsigned int                                : 14;
          unsigned int current                        : MP2_PMI_0_WRITE_POINTER_CURRENT_SIZE;
     } mp2_pmi_0_write_pointer_t;

#endif

typedef union {
     unsigned int val : 32;
     mp2_pmi_0_write_pointer_t f;
} mp2_pmi_0_write_pointer_u;


#endif


