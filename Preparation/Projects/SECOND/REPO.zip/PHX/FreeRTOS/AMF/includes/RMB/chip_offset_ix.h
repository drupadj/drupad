// Copyright (c) 1994 - 2020 Advanced Micro Devices, Inc. All rights reserved. 

#ifndef _chip_offset_ix_h
#define _chip_offset_ix_h

#ifdef __cplusplus
extern "C" {
#endif  // __cplusplus

/************************************************************************
 *
 * Module Name:  chip_offset_ix.h
 * Project:      mp_design_rembrandt Register indirect
 * Device:       mp_design_rembrandt
 *
 * Description:  Header file for mp_design_rembrandt
 *
 * (c) 2020 ATI Technologies Inc.  (unpublished)
 *
 * All rights reserved.  This notice is intended as a precaution against
 * inadvertent publication and does not imply publication or any waiver
 * of confidentiality.  The year included in the foregoing notice is the
 * year of creation of the work.
 *
 ************************************************************************
 *                                                                      *
 *
 * $$File:       (null)
 * $$ASIC Name:  mp_design_rembrandt
 * $$Regs Rev:   <unknown>
 * $$Date :      Fri May 22 19:38:15 2020

 *
 */



// [DRMDEBUGIND] : Indirect Registers

#define ixDH_TEST                                  0x0000
#define ixKHFS0                                    0x0004
#define ixKHFS1                                    0x0008
#define ixKHFS2                                    0x000C
#define ixKHFS3                                    0x0010
#define ixKSESSION0                                0x0014
#define ixKSESSION1                                0x0018
#define ixKSESSION2                                0x001C
#define ixKSESSION3                                0x0020
#define ixKSIG0                                    0x0024
#define ixKSIG1                                    0x0028
#define ixKSIG2                                    0x002C
#define ixKSIG3                                    0x0030
#define ixEXP0                                     0x0034
#define ixEXP1                                     0x0038
#define ixEXP2                                     0x003C
#define ixEXP3                                     0x0040
#define ixEXP4                                     0x0044
#define ixEXP5                                     0x0048
#define ixEXP6                                     0x004C
#define ixEXP7                                     0x0050
#define ixLX0                                      0x0054
#define ixLX1                                      0x0058
#define ixLX2                                      0x005C
#define ixLX3                                      0x0060
#define ixFAST_AES0                                0x0064
#define ixFAST_AES1                                0x0068
#define ixFAST_AES2                                0x006C
#define ixFAST_AES3                                0x0070
#define ixFAST_AES4                                0x0074
#define ixFAST_AES5                                0x0078
#define ixFAST_AES6                                0x007C
#define ixFAST_AES7                                0x0080
#define ixSLOW_AES0                                0x0084
#define ixSLOW_AES1                                0x0088
#define ixSLOW_AES2                                0x008C
#define ixSLOW_AES3                                0x0090
#define ixCCIPHER_A_IK0                            0x0094
#define ixCCIPHER_A_IK1                            0x0098
#define ixCCIPHER_A_IK2                            0x009C
#define ixCCIPHER_A_IK3                            0x00A0
#define ixCCIPHER_A_S0                             0x00A4
#define ixCCIPHER_A_S1                             0x00A8
#define ixCCIPHER_A_S2                             0x00AC
#define ixCCIPHER_A_S3                             0x00B0
#define ixCCIPHER_A_S4                             0x00B4
#define ixCCIPHER_A_S5                             0x00B8
#define ixCCIPHER_A_S6                             0x00BC
#define ixCCIPHER_A_S7                             0x00C0
#define ixCCIPHER_A_S8                             0x00C4
#define ixCCIPHER_A_S9                             0x00C8
#define ixCCIPHER_A_S10                            0x00CC
#define ixCCIPHER_A_S11                            0x00D0
#define ixCCIPHER_A_S12                            0x00D4
#define ixCCIPHER_A_S13                            0x00D8
#define ixCCIPHER_A_S14                            0x00DC
#define ixCCIPHER_A_S15                            0x00E0
#define ixCCIPHER_A_S16                            0x00E4
#define ixCCIPHER_A_S17                            0x00E8
#define ixCCIPHER_A_S18                            0x00EC
#define ixCCIPHER_A_S19                            0x00F0
#define ixCCIPHER_A_S20                            0x00F4
#define ixCCIPHER_A_S21                            0x00F8
#define ixCCIPHER_A_S22                            0x00FC
#define ixCCIPHER_A_S23                            0x0100
#define ixCCIPHER_A_S24                            0x0104
#define ixCCIPHER_A_S25                            0x0108
#define ixCCIPHER_A_S26                            0x010C
#define ixCCIPHER_A_S27                            0x0110
#define ixCCIPHER_A_S28                            0x0114
#define ixCCIPHER_A_S29                            0x0118
#define ixCCIPHER_A_S30                            0x011C
#define ixCCIPHER_A_S31                            0x0120
#define ixCCIPHER_B_IK0                            0x0124
#define ixCCIPHER_B_IK1                            0x0128
#define ixCCIPHER_B_IK2                            0x012C
#define ixCCIPHER_B_IK3                            0x0130
#define ixCCIPHER_B_S0                             0x0134
#define ixCCIPHER_B_S1                             0x0138
#define ixCCIPHER_B_S2                             0x013C
#define ixCCIPHER_B_S3                             0x0140
#define ixCCIPHER_B_S4                             0x0144
#define ixCCIPHER_B_S5                             0x0148
#define ixCCIPHER_B_S6                             0x014C
#define ixCCIPHER_B_S7                             0x0150
#define ixCCIPHER_B_S8                             0x0154
#define ixCCIPHER_B_S9                             0x0158
#define ixCCIPHER_B_S10                            0x015C
#define ixCCIPHER_B_S11                            0x0160
#define ixCCIPHER_B_S12                            0x0164
#define ixCCIPHER_B_S13                            0x0168
#define ixCCIPHER_B_S14                            0x016C
#define ixCCIPHER_B_S15                            0x0170
#define ixCCIPHER_B_S16                            0x0174
#define ixCCIPHER_B_S17                            0x0178
#define ixCCIPHER_B_S18                            0x017C
#define ixCCIPHER_B_S19                            0x0180
#define ixCCIPHER_B_S20                            0x0184
#define ixCCIPHER_B_S21                            0x0188
#define ixCCIPHER_B_S22                            0x018C
#define ixCCIPHER_B_S23                            0x0190
#define ixCCIPHER_B_S24                            0x0194
#define ixCCIPHER_B_S25                            0x0198
#define ixCCIPHER_B_S26                            0x019C
#define ixCCIPHER_B_S27                            0x01A0
#define ixCCIPHER_B_S28                            0x01A4
#define ixCCIPHER_B_S29                            0x01A8
#define ixCCIPHER_B_S30                            0x01AC
#define ixCCIPHER_B_S31                            0x01B0
#define ixCLIENT2_K0                               0x01B4
#define ixCLIENT2_K1                               0x01B8
#define ixCLIENT2_K2                               0x01BC
#define ixCLIENT2_K3                               0x01C0
#define ixCLIENT2_CK0                              0x01C4
#define ixCLIENT2_CK1                              0x01C8
#define ixCLIENT2_CK2                              0x01CC
#define ixCLIENT2_CK3                              0x01D0
#define ixCLIENT2_CD0                              0x01D4
#define ixCLIENT2_CD1                              0x01D8
#define ixCLIENT2_CD2                              0x01DC
#define ixCLIENT2_CD3                              0x01E0
#define ixCLIENT2_BM                               0x01E4
#define ixCLIENT2_OFFSET                           0x01E8
#define ixCLIENT2_STATUS                           0x01EC
#define ixCLIENT0_K0                               0x01F0
#define ixCLIENT0_K1                               0x01F4
#define ixCLIENT0_K2                               0x01F8
#define ixCLIENT0_K3                               0x01FC
#define ixCLIENT0_CK0                              0x0200
#define ixCLIENT0_CK1                              0x0204
#define ixCLIENT0_CK2                              0x0208
#define ixCLIENT0_CK3                              0x020C
#define ixCLIENT0_CD0                              0x0210
#define ixCLIENT0_CD1                              0x0214
#define ixCLIENT0_CD2                              0x0218
#define ixCLIENT0_CD3                              0x021C
#define ixCLIENT0_BM                               0x0220
#define ixCLIENT0_OFFSET                           0x0224
#define ixCLIENT0_STATUS                           0x0228
#define ixCLIENT1_K0                               0x022C
#define ixCLIENT1_K1                               0x0230
#define ixCLIENT1_K2                               0x0234
#define ixCLIENT1_K3                               0x0238
#define ixCLIENT1_CK0                              0x023C
#define ixCLIENT1_CK1                              0x0240
#define ixCLIENT1_CK2                              0x0244
#define ixCLIENT1_CK3                              0x0248
#define ixCLIENT1_CD0                              0x024C
#define ixCLIENT1_CD1                              0x0250
#define ixCLIENT1_CD2                              0x0254
#define ixCLIENT1_CD3                              0x0258
#define ixCLIENT1_BM                               0x025C
#define ixCLIENT1_OFFSET                           0x0260
#define ixCLIENT1_PORT_STATUS                      0x0264
#define ixKEFUSE0                                  0x0268
#define ixKEFUSE1                                  0x026C
#define ixKEFUSE2                                  0x0270
#define ixKEFUSE3                                  0x0274
#define ixHFS_SEED0                                0x0278
#define ixHFS_SEED1                                0x027C
#define ixHFS_SEED2                                0x0280
#define ixHFS_SEED3                                0x0284
#define ixRINGOSC_MASK                             0x0288
#define ixAUTH_STATE                               0x028C
#define ixCLIENT0_OFFSET_HI                        0x0290
#define ixCLIENT1_OFFSET_HI                        0x0294
#define ixCLIENT2_OFFSET_HI                        0x0298
#define ixSPU_PORT_STATUS                          0x029C
#define ixCLIENT3_OFFSET_HI                        0x02A0
#define ixCLIENT3_K0                               0x02A4
#define ixCLIENT3_K1                               0x02A8
#define ixCLIENT3_K2                               0x02AC
#define ixCLIENT3_K3                               0x02B0
#define ixCLIENT3_CK0                              0x02B4
#define ixCLIENT3_CK1                              0x02B8
#define ixCLIENT3_CK2                              0x02BC
#define ixCLIENT3_CK3                              0x02C0
#define ixCLIENT3_CD0                              0x02C4
#define ixCLIENT3_CD1                              0x02C8
#define ixCLIENT3_CD2                              0x02CC
#define ixCLIENT3_CD3                              0x02D0
#define ixCLIENT3_BM                               0x02D4
#define ixCLIENT3_OFFSET                           0x02D8
#define ixCLIENT3_STATUS                           0x02DC
#define ixCLIENT4_OFFSET_HI                        0x02E0
#define ixCLIENT4_K0                               0x02E4
#define ixCLIENT4_K1                               0x02E8
#define ixCLIENT4_K2                               0x02EC
#define ixCLIENT4_K3                               0x02F0
#define ixCLIENT4_CK0                              0x02F4
#define ixCLIENT4_CK1                              0x02F8
#define ixCLIENT4_CK2                              0x02FC
#define ixCLIENT4_CK3                              0x0300
#define ixCLIENT4_CD0                              0x0304
#define ixCLIENT4_CD1                              0x0308
#define ixCLIENT4_CD2                              0x030C
#define ixCLIENT4_CD3                              0x0310
#define ixCLIENT4_BM                               0x0314
#define ixCLIENT4_OFFSET                           0x0318
#define ixCLIENT4_STATUS                           0x031C

// [DCDEBUGIND] : Indirect Registers

#define ixDRM_DEBUG_INDEX0                         0x0090
#define ixDRM_DEBUG_INDEX1                         0x0091
#define ixDRM_DEBUG_INDEX2                         0x0092
#define ixDRM_DEBUG_INDEX3                         0x0093
#define ixDRM_DEBUG_INDEX4                         0x0094
#define ixDRM_DEBUG_INDEX5                         0x0095
#define ixDRM_DEBUG_INDEX6                         0x0096
#define ixDRM_DEBUG_INDEX7                         0x0097
#define ixDRM_DEBUG_ID                             0x00FB

// [DRMSMNDEBUGIND] : Indirect Registers

#define ixMP0_SMN_DH_TEST                          0x0000

// [DRMSMNDCDEBUGIND] : Indirect Registers

#define ixMP0_SMN_DRM_DEBUG_ID                     0x00FB


#ifdef __cplusplus
}
#endif  // __cplusplus

#endif // _chip_offset_ix_h

