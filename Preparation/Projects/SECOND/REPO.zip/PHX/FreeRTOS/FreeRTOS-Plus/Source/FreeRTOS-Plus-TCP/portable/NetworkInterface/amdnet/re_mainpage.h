/**
 * \file re_mainpage.h
 *
 * \brief Main page documentation file.
 */

/**
 * @mainpage RealTek NIC Driver source code documentation
 *
 * This documentation describes the individual files of the RealTek NIC driver.
 * It explains the data structures used in the driver, various macros and
 * definitions used and also gives brief details about the various functions
 * involved.
 *
 * @section mainpage_files Files
 *
 * This driver has mainly two files
 * 1. NetworkInterface.c
 * 2. realtek_eth.h
 *
 * @section mainpage_file_details File Details
 * \b NetworkInterface.c
 *
 * 	This file has all the routines to probe and claim the hardware, does
 * 	the hardware initialization, allocate and configure the transmit and
 * 	receive descriptors and associated data buffers and book-keeping them.
 *
 * 	This file also has the routine to handle the main transmit and receive
 * 	functions which does the actual job for the transmission and reception
 * 	of the packet.
 *
 * \b realtek_eth.h
 *
 * 	This file has all the data structures (main device structure, hardware
 * 	descriptor structure etc.,) and all associated macros to configure and
 * 	run the hardware as expected.
 *
 */
