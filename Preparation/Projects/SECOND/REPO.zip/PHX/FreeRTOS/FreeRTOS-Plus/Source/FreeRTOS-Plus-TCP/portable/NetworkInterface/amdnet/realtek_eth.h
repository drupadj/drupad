/**
 * @file realtek_eth.h
 * @brief This file has the structures, macros, enums for the Realtek NIC
 *        driver
 *
 * @copyright Copyright 2020 by Advanced Micro Devices Inc. All Rights Reserved
 *
 */

#ifndef FREERTOS_ETH_H
#define FREERTOS_ETH_H

/**
 * @var struct re_private *re_priv
 * Global variable holding the main device structure reference
 *
 */
struct re_private;
struct re_private *re_priv = NULL;

typedef unsigned long long uint64_t;
typedef unsigned int       uint32_t;
typedef unsigned short     uint16_t;
typedef unsigned char      uint8_t;
typedef int bool;

#define RE_CMAC_WRITE_1(reg, val32) CSR_WRITE_1(reg, val32)
#define RE_CMAC_WRITE_2(reg, val32) CSR_WRITE_2(reg, val32)
#define RE_CMAC_WRITE_4(reg, val32) CSR_WRITE_4(reg, val32)
#define RE_CMAC_READ_1(reg) CSR_READ_1(reg)
#define RE_CMAC_READ_2(reg) CSR_READ_2(reg)
#define RE_CMAC_READ_4(reg) CSR_READ_4(reg)

#define BITS_PER_LONG           32

#ifndef true
#define true 1
#endif

#ifndef false
#define false 0
#endif

#define LINK_STATE_UNKNOWN      0       /* link invalid/unknown */
#define LINK_STATE_DOWN         1       /* link is down */
#define LINK_STATE_UP           2       /* link is up */

#define max(a, b)               (a > b? a : b)
#define min(a, b)               (a < b? a : b)

/* PCIE constants */
#define BAR_ADDRESS_MASK        0xFFFFFFF0
#define PCIE_CMD                0x04
#define PCIE_BAR2               0x18

/* Interface flags */
#define IFF_BROADCAST           0x0002  /* (i) broadcast address valid */
#define IFF_PROMISC             0x0100  /* (n) receive all packets */
#define IFF_ALLMULTI            0x0200  /* (n) receive all multicast packets */
#define IFF_SIMPLEX             0x0800  /* (i) can't hear own transmissions */
#define IFF_MULTICAST           0x8000  /* (i) supports multicast */

struct ephy_info {
        unsigned int offset;
        uint16_t mask;
        uint16_t bits;
};

/* Ethernet constants */
#define ETHER_ADDR_LEN          6       /* length of an Ethernet address */
#define ETHER_TYPE_LEN          2       /* length of the Ethernet type field */
#define ETHER_CRC_LEN           4       /* length of the Ethernet CRC */
#define ETHER_HDR_LEN           (ETHER_ADDR_LEN*2+ETHER_TYPE_LEN)
#define ETHER_VLAN_ENCAP_LEN    4       /* len of 802.1Q VLAN encapsulation */
#define ETHER_MIN_LEN           64      /* minimum frame len, including CRC */
#define ETHER_MAX_LEN           1518    /* maximum frame len, including CRC */

#define BIT_31          (1U << 31)
#define BIT_30          (1 << 30)
#define BIT_29          (1 << 29)
#define BIT_28          (1 << 28)
#define BIT_27          (1 << 27)
#define BIT_26          (1 << 26)
#define BIT_25          (1 << 25)
#define BIT_24          (1 << 24)
#define BIT_23          (1 << 23)
#define BIT_22          (1 << 22)
#define BIT_21          (1 << 21)
#define BIT_20          (1 << 20)
#define BIT_19          (1 << 19)
#define BIT_18          (1 << 18)
#define BIT_17          (1 << 17)
#define BIT_16          (1 << 16)
#define BIT_15          (1 << 15)
#define BIT_14          (1 << 14)
#define BIT_13          (1 << 13)
#define BIT_12          (1 << 12)
#define BIT_11          (1 << 11)
#define BIT_10          (1 << 10)
#define BIT_9           (1 << 9)
#define BIT_8           (1 << 8)
#define BIT_7           (1 << 7)
#define BIT_6           (1 << 6)
#define BIT_5           (1 << 5)
#define BIT_4           (1 << 4)
#define BIT_3           (1 << 3)
#define BIT_2           (1 << 2)
#define BIT_1           (1 << 1)
#define BIT_0           (1 << 0)

/* Enable or disable autonegotiation. */
#define AUTONEG_DISABLE         0x00
#define AUTONEG_ENABLE          0x01

#define SPEED_10                10
#define SPEED_100               100
#define SPEED_1000              1000
#define SPEED_2500              2500
#define SPEED_5000              5000
#define SPEED_10000             10000
#define SPEED_14000             14000
#define SPEED_20000             20000
#define SPEED_25000             25000
#define SPEED_40000             40000
#define SPEED_50000             50000
#define SPEED_56000             56000
#define SPEED_100000            100000
#define SPEED_UNKNOWN           -1

/* Duplex, half or full. */
#define DUPLEX_HALF             0x00
#define DUPLEX_FULL             0x01
#define DUPLEX_UNKNOWN          0xff

/* Generic MII registers. */
#define MII_BMCR		0x00    /* Basic mode control register */
#define MII_ADVERTISE           0x04    /* Advertisement control reg   */
#define MII_CTRL1000            0x09    /* 1000BASE-T control          */

/* Basic mode control register. */
#define BMCR_SPEED1000          0x0040  /* MSB of Speed (1000)         */
#define BMCR_FULLDPLX           0x0100  /* Full duplex                 */
#define BMCR_ANRESTART          0x0200  /* Auto negotiation restart    */
#define BMCR_AUTOEN		0x1000  /* autonegotiation enable */
#define BMCR_SPEED100           0x2000  /* Select 100Mbps              */
#define BMCR_RESET		0x8000  /* reset */
#define BMCR_SPEED10            0x0000  /* Select 10Mbps               */

#define ADVERTISE_10HALF        0x0020  /* Try for 10mbps half-duplex  */
#define ADVERTISE_10FULL        0x0040  /* Try for 10mbps full-duplex  */
#define ADVERTISE_100HALF       0x0080  /* Try for 100mbps half-duplex */
#define ADVERTISE_100FULL       0x0100  /* Try for 100mbps full-duplex */
#define ADVERTISE_PAUSE_CAP     0x0400  /* Try for pause               */
#define ADVERTISE_PAUSE_ASYM    0x0800  /* Try for asymetric pause     */
#define ADVERTISE_1000FULL      0x0200  /* Advertise 1000BASE-T full duplex */
#define ADVERTISE_1000HALF      0x0100  /* Advertise 1000BASE-T half duplex */

#define ADVERTISED_10baseT_Half         (1 << 0)
#define ADVERTISED_10baseT_Full         (1 << 1)
#define ADVERTISED_100baseT_Half        (1 << 2)
#define ADVERTISED_100baseT_Full        (1 << 3)
#define ADVERTISED_1000baseT_Half        (1 << 4)
#define ADVERTISED_1000baseT_Full        (1 << 5)

/* Rx buffer size for Normal MTU packets */
#define MJUM9BYTES		(9 * 1024)
#define RL_RX_DESC_BUFLEN_NORM	2048
/* Rx buffers zie for Jumbo MTU packets - Max value is 2^13 - 1 = 8K - 1 and bit 0-2 should be 0 */
#define RL_RX_DESC_BUFLEN_JUMBO	0x1FF8
#define RL_JUMBO_MTU_9K         \
    ((9 * 1024) - ETHER_VLAN_ENCAP_LEN - ETHER_HDR_LEN - ETHER_CRC_LEN)
#define RL_MTU                  \
    (ETHER_MAX_LEN - ETHER_VLAN_ENCAP_LEN - ETHER_HDR_LEN - ETHER_CRC_LEN)

#define RE_DESC_ALIGN		256		/* descriptor alignment */
#define RE_RX_BUFFER_ALIGN	8		/* descriptor alignment */

#ifdef RE_FIXUP_RX
#define	RE_ETHER_ALIGN	RE_RX_BUFFER_ALIGN
#else
#define	RE_ETHER_ALIGN	0
#endif
/**
 * @def REF_CLK_FREQ_MHZ
 * Reference clock rate in MegaHertz
 * @def US_TO_REFCLK
 * Macro to generate a MegaHertz value of 'US' times of reference clock
 * @def MEM_BARRIER
 * Macro that implements a memory barrier for write operations
 * @def ALIGN
 * Macro to align address 'x' to given size 'a'
 * @def DMA_BIT_MASK
 * Macro to generate a bitmask for 'n' bits (Eg: 16 -> 0xFFFF)
 * @def RL_TXRX_BUDGET
 * Number of Transmit/Receive packet to be processed in a stretch
 * @def RL_TX_DESC_CNT
 * Number of descriptors in the hardware transmit descriptor queue
 * @def RL_RX_DESC_CNT
 * Number of descriptors in the hardware receive descriptor queue
 * @def DRAM_AXI_BASE_ADDR
 * Base address of the DRAM
 * @def PHY_RESET_TIMEOUT
 * Time to wait until the PHY Reset state is checked next time
 * @def RL_TIMEOUT
 * Timeout iteration count for Transmit packet
 * @def RL_PHY_TIMEOUT
 * Timeout iteration count for PHY Reset
 *
 */
#define REF_CLK_FREQ_MHZ	25
#define US_TO_REFCLK(US)	(US * REF_CLK_FREQ_MHZ)
#define MEM_BARRIER             __asm__ __volatile__ ("memw")
#define ALIGN(x, a)             (((x) + ((a) - 1)) & ~((a) - 1))
#define DMA_BIT_MASK(n)         (((n) == 64) ? ~0ULL : ((1ULL<<(n))-1))
#define RL_TXRX_BUDGET		64
#define RL_TX_DESC_CNT		64 //256
#define RL_RX_DESC_CNT		64 //256
#define DRAM_AXI_BASE_ADDR	0x4000000 //0x20000000
#define PHY_RESET_TIMEOUT	(10*configTICK_RATE_HZ)
#define RL_TIMEOUT		1000
#define RL_PHY_TIMEOUT		2000
#define OCP_STD_PHY_BASE        0xa400

/* Realtek Register offsets */
#define RL_IDR0			0x0000	/* ID register 0 (station addr) */
#define RL_IDR1			0x0001	/* Must use 32-bit accesses (?) */
#define RL_IDR2			0x0002
#define RL_IDR3			0x0003
#define RL_IDR4			0x0004
#define RL_IDR5			0x0005
#define RL_MAR0			0x0008	/* Multicast hash table */
#define RL_MAR1			0x0009
#define RL_MAR2			0x000A
#define RL_MAR3			0x000B
#define RL_MAR4			0x000C
#define RL_MAR5			0x000D
#define RL_MAR6			0x000E
#define RL_MAR7			0x000F
#define RL_EEE_LED		0x001B
#define RL_TXLIST_ADDR_LO	0x0020	/* 64 bits, 256 byte alignment */
#define RL_TXLIST_ADDR_HI	0x0024	/* 64 bits, 256 byte alignment */
#define RL_COMMAND		0x0037	/* command register */
#define RL_GTXSTART		0x0038	/* 8 bits */
#define RL_IMR			0x003C	/* interrupt mask register */
#define RL_ISR			0x003E	/* interrupt status register */
#define RL_TXCFG		0x0040	/* transmit config */
#define RL_RXCFG		0x0044	/* receive config */
#define RL_TIMERCNT		0x0048	/* timer count register */
#define RL_MISSEDPKT		0x004C	/* missed packet counter */
#define RL_EECMD		0x0050	/* EEPROM command register */
#define RL_CFG0			0x0051	/* config register #0 */
#define RL_CFG1			0x0052	/* config register #1 */
#define RL_CFG2			0x0053	/* config register #2 */
#define RL_CFG3			0x0054	/* config register #3 */
#define RL_CFG4			0x0055	/* config register #4 */
#define RL_CFG5			0x0056	/* config register #5 */
#define RL_MULTIINTR		0x005c
#define RL_PHYAR		0x0060
#define RL_CSIDR		0x0064
#define RL_CSIAR		0x0068
#define RL_GMEDIASTAT		0x006C	/* 8 bits */
#define RL_PMCH			0x006F	/* 8 bits */
#define RL_ERIDR		0x0070
#define RL_ERIAR		0x0074
#define RL_EPHYAR		0x0080
#define RL_MCUACCESS		0x00B0
#define RL_PHYOCPACCESS		0x00B8
#define RL_DLLPR		0x00D0
#define RL_MAXRXPKTLEN		0x00DA	/* 16 bits, chip multiplies by 8 */
#define RL_MCU_CMD		0x00D3
#define RL_CPLUS_CMD		0x00E0	/* 16 bits */
#define RL_INTRMOD		0x00E2	/* 16 bits */
#define RL_RXLIST_ADDR_LO	0x00E4  /* 64 bits, 256 byte alignment */
#define RL_RXLIST_ADDR_HI	0x00E8  /* 64 bits, 256 byte alignment */
#define RL_EARLY_TX_THRESH	0x00EC  /* 16 bits, Unit of 128 bytes */
#define RL_MISC			0x00F0
#define RL_MISC1		0x00F2
#define	RL_CMAC_IBCR0     	0x00F8
#define	RL_CMAC_IBCR2     	0x00F9
#define	RL_CMAC_IBIMR0    	0x00FA
#define	RL_CMAC_IBISR0   	0x00FB

/* CSIAR */
#define CSIAR_WRITE_CMD         0x80000000
#define CSIAR_BYTE_ENABLE       0x0f
#define CSIAR_BYTE_ENABLE_SHIFT 12
#define CSIAR_ADDR_MASK         0x0fff

/* MCU Command */
#define RL_NOW_IS_OOB		(1 << 7)
#define RL_TXFIFO_EMPTY		(1 << 5)
#define RL_RXFIFO_EMPTY		(1 << 4)

/* Ethernet PHY MDI Mode */
#define RE_ETH_PHY_FORCE_MDI 		0
#define RE_ETH_PHY_FORCE_MDIX		1
#define RE_ETH_PHY_AUTO_MDI_MDIX	2

/* RL_COMMAND Register Bits */
#define RL_COMMAND_EMPTY_RXBUF	0x0001
#define RL_COMMAND_TX_ENB	0x0004
#define RL_COMMAND_RX_ENB	0x0008
#define RL_COMMAND_RESET	0x0010
#define RL_COMMAND_STOPREQ	0x0080

/* RL_GTXSTARTTXPOLL Register Bits */
#define RL_TXSTART_SWI		0x01	/* generate TX interrupt */
#define RL_TXSTART_START	0x40	/* start normal queue transmit */
#define RL_TXSTART_HPRIO_START	0x80	/* start hi prio queue transmit */

/* RL_ISR Register Bits */
#define RL_ISR_RX_OK		0x0001
#define RL_ISR_RX_ERR		0x0002
#define RL_ISR_TX_OK		0x0004
#define RL_ISR_TX_ERR		0x0008
#define RL_ISR_RX_OVERRUN	0x0010
#define RL_ISR_PKT_UNDERRUN	0x0020
#define RL_ISR_LINKCHG		0x0020  /* 8169 only */
#define RL_ISR_FIFO_OFLOW	0x0040  /* 8139 only */
#define RL_ISR_TX_DESC_UNAVAIL	0x0080  /* C+ only */
#define RL_ISR_SWI		0x0100  /* C+ only */
#define RL_ISR_CABLE_LEN_CHGD	0x2000
#define RL_ISR_PCS_TIMEOUT	0x4000  /* 8129 only */
#define RL_ISR_TIMEOUT_EXPIRED	0x4000
#define RL_ISR_SYSTEM_ERR	0x8000

#define RL_EVENT_RX		(RL_ISR_RX_OK | RL_ISR_RX_ERR)
#define RL_EVENT_TX		(RL_ISR_TX_OK | RL_ISR_TX_ERR)
#define RL_EVENT_RXTX		(RL_EVENT_RX | RL_EVENT_TX)

#define RL_INTRS_CPLUS	\
    (RL_ISR_RX_OK|RL_ISR_RX_ERR|RL_ISR_TX_ERR|RL_ISR_TX_OK|	\
    RL_ISR_RX_OVERRUN|RL_ISR_PKT_UNDERRUN|RL_ISR_FIFO_OFLOW|	\
    RL_ISR_PCS_TIMEOUT|RL_ISR_SYSTEM_ERR|RL_ISR_TIMEOUT_EXPIRED)

/* RL_TXCFG Register Bits */
#define RL_TXCFG_CLRABRT	0x00000001	/* retransmit aborted pkt */
#define RL_TXCFG_AUTO_FIFO	0x00000080
#define RL_TXCFG_MAXDMA		0x00000700	/* max DMA burst size */
#define RL_TXCFG_QUEUE_EMPTY	0x00000800	/* 8168E-VL or higher */
#define RL_TXCFG_CRCAPPEND	0x00010000	/* CRC append (0 = yes) */
#define RL_TXCFG_LOOPBKTST	0x00060000	/* loopback test */
#define RL_TXCFG_IFG2		0x00080000	/* 8169 only */
#define RL_TXCFG_IFG		0x03000000	/* interframe gap */
#define RL_TXCFG_HWREV		0x7CC00000

#define RL_TXCFG_CONFIG		(RL_TXCFG_IFG | RL_TXCFG_MAXDMA)

/* RL_RXCFG Register Bits */
#define RL_RXCFG_RX_ALLPHYS	0x00000001	/* accept all nodes */
#define RL_RXCFG_RX_INDIV	0x00000002	/* match filter */
#define RL_RXCFG_RX_MULTI	0x00000004	/* accept all multicast */
#define RL_RXCFG_RX_BROAD	0x00000008	/* accept all broadcast */
#define RL_RXCFG_RX_RUNT	0x00000010
#define RL_RXCFG_RX_ERRPKT	0x00000020
#define RX_CONFIG_ACCEPT_MASK	0x0000003F
#define RL_RXCFG_RXDMA_UNLIMITED 0x00000700
#define RL_RXCFG_RXBUF_64	0x00001800
#define RL_RXCFG_RXFIFO_NOTHRESH 0x0000E000
#define RL_RXCFG_RX_LANIO	0x01000000

#define RL_RXCFG_CONFIG		(RL_RXCFG_RXFIFO_NOTHRESH | \
    RL_RXCFG_RXDMA_UNLIMITED | RL_RXCFG_RXBUF_64)

/* RL_EE Register Bits */
#define RL_EEMODE_OFF		0x00
#define RL_EEMODE_AUTOLOAD	0x40
#define RL_EEMODE_PROGRAM	0x80
#define RL_EEMODE_WRITECFG	(0x80|0x40)

/* RL_CFG1 Register Bits */
#define RL_CFG1_PME		0x01
#define RL_CFG1_DRVLOAD		0x20

/* RL_CFG3 Register Bits  */
#define RL_CFG3_WOL_LINK        0x10
#define RL_CFG3_JUMBO_EN0	0x04

/* RL_CFG4 Register Bits */
#define RL_CFG4_JUMBO_EN1	0x02

/* RL_CFG5 Register Bits */
#define RL_CFG5_WOL_BCAST	0x40
#define RL_CFG5_WOL_MCAST	0x20
#define RL_CFG5_WOL_UCAST	0x10
#define RL_CFG5_WOL_LANWAKE	0x02
#define RL_CFG5_PME_STS		0x01

/* RL_PHYAR Register Bits */
#define RL_PHYAR_PHYDATA	0x0000FFFF
#define RL_PHYAR_PHYREG		0x001F0000
#define RL_PHYAR_BUSY		0x80000000

/* RL_GMEDIASTAT Register Bits */
#define RL_GMEDIASTAT_LINK	0x02    /* link up */

/* RL_CPLUS_CMD Register Bits */
#define RL_CPLUSCMD_TXENB	0x0001  /* enable C+ transmit mode */
#define RL_CPLUSCMD_RXENB	0x0002  /* enable C+ receive mode */
#define RL_CPLUSCMD_PCI_MRW	0x0008  /* enable PCI multi-read/write */
#define RL_CPLUSCMD_RXCSUM_ENB	0x0020  /* enable RX checksum offload */
#define RL_CPLUSCMD_VLANSTRIP	0x0040  /* enable VLAN tag stripping */
#define RL_CPLUSCMD_MACSTAT_DIS	0x0080  /* 8168B/C/CP */
#define INTT_1			0x0001

/* RL_ERIAR Register Bits */
#define RL_ERIAR_FLAG		0x80000000
#define RL_ERIAR_WRITE_CMD	0x80000000
#define RL_ERIAR_READ_CMD	0x00000000
#define RL_ERIAR_EXGMAC		0x00000000
#define RL_ERIAR_OOB		0x00020000
#define RL_ERIAR_MASK_0001	0x00001000
#define RL_ERIAR_MASK_0011	0x00003000
#define RL_ERIAR_MASK_0100	0x00004000
#define RL_ERIAR_MASK_0101	0x00005000
#define RL_ERIAR_MASK_1111	0x0000F000

/* RL_MISC Register Bits */
#define RL_MISC_RXDV_GATED_EN	0x00080000

/* RL_OOB Register Bits */
#define RL_OOB_CMD_RESET	0x00
#define RL_OOB_CMD_DRIVER_START	0x05
#define RL_OOB_CMD_DRIVER_STOP	0x06

/* TX descriptor cmd/vlan definitions */
#define RL_TDESC_CMD_FRAGLEN	0x0000FFFF
#define RL_TDESC_CMD_TCPCSUM	0x00010000      /* TCP checksum enable */
#define RL_TDESC_CMD_UDPCSUM	0x00020000      /* UDP checksum enable */
#define RL_TDESC_CMD_IPCSUM	0x00040000      /* IP header checksum enable */
#define RL_TDESC_CMD_MSSVAL	0x07FF0000      /* Large send MSS value */
#define RL_TDESC_CMD_MSSVAL_SHIFT	16      /* Large send MSS value shift */
#define RL_TDESC_CMD_LGSEND	0x08000000      /* TCP large send enb */
#define RL_TDESC_CMD_EOF	0x10000000      /* end of frame marker */
#define RL_TDESC_CMD_SOF	0x20000000      /* start of frame marker */
#define RL_TDESC_CMD_EOR	0x40000000      /* end of ring marker */
#define RL_TDESC_CMD_OWN	0x80000000      /* chip owns descriptor */
#define RL_TDESC_CMD_UDPCSUMV2	0x80000000
#define RL_TDESC_CMD_TCPCSUMV2	0x40000000
#define RL_TDESC_CMD_IPCSUMV2	0x20000000
#define RL_TDESC_CMD_MSSVALV2	0x1FFC0000
#define RL_TDESC_CMD_MSSVALV2_SHIFT	18

/*
 * Error bits are valid only on the last descriptor of a frame
 * (i.e. RL_TDESC_CMD_EOF == 1)
 */
#define RL_TDESC_STAT_COLCNT	0x000F0000      /* collision count */
#define RL_TDESC_STAT_EXCESSCOL	0x00100000      /* excessive collisions */
#define RL_TDESC_STAT_LINKFAIL	0x00200000      /* link faulure */
#define RL_TDESC_STAT_OWINCOL	0x00400000      /* out-of-window collision */
#define RL_TDESC_STAT_TXERRSUM	0x00800000      /* transmit error summary */
#define RL_TDESC_STAT_UNDERRUN	0x02000000      /* TX underrun occurred */
#define RL_TDESC_STAT_OWN	0x80000000

#define RL_TDESC_VLANCTL_TAG	0x00020000      /* Insert VLAN tag */
#define RL_TDESC_VLANCTL_DATA	0x0000FFFF      /* TAG data */

#define RL_TDESC_RSVDMASK	0x3FFFC000

/* RX descriptor cmd/vlan definitions */
#define RL_RDESC_CMD_EOR        0x40000000
#define RL_RDESC_CMD_OWN        0x80000000
#define RL_RDESC_CMD_BUFLEN     0x00001FFF

#define RL_RDESC_STAT_OWN	0x80000000
#define RL_RDESC_STAT_EOR	0x40000000
#define RL_RDESC_STAT_SOF	0x20000000
#define RL_RDESC_STAT_EOF	0x10000000
#define RL_RDESC_STAT_FRALIGN	0x08000000      /* frame alignment error */
#define RL_RDESC_STAT_MCAST	0x04000000      /* multicast pkt received */
#define RL_RDESC_STAT_UCAST	0x02000000      /* unicast pkt received */
#define RL_RDESC_STAT_BCAST	0x01000000      /* broadcast pkt received */
#define RL_RDESC_STAT_BUFOFLOW	0x01000000      /* out of buffer space */
#define RL_RDESC_STAT_FIFOOFLOW	0x00800000      /* FIFO overrun */
#define RL_RDESC_STAT_GIANT	0x00400000      /* pkt > 4096 bytes */
#define RL_RDESC_STAT_RXERRSUM	0x00200000      /* RX error summary */
#define RL_RDESC_STAT_RUNT	0x00100000      /* runt packet received */
#define RL_RDESC_STAT_CRCERR	0x00080000      /* CRC error */
#define RL_RDESC_STAT_PROTOID	0x00030000      /* Protocol type */
#define RL_RDESC_STAT_UDP	0x00020000      /* UDP, 8168C/CP, 8111C/CP */
#define RL_RDESC_STAT_TCP	0x00010000      /* TCP, 8168C/CP, 8111C/CP */
#define RL_RDESC_STAT_IPSUMBAD	0x00008000      /* IP header checksum bad */
#define RL_RDESC_STAT_UDPSUMBAD	0x00004000      /* UDP checksum bad */
#define RL_RDESC_STAT_TCPSUMBAD	0x00002000      /* TCP checksum bad */
#define RL_RDESC_STAT_FRAGLEN	0x00001FFF      /* RX'ed frame/frag len */
#define RL_RDESC_STAT_GFRAGLEN	0x00003FFF      /* RX'ed frame/frag len */
#define RL_RDESC_STAT_ERRS	(RL_RDESC_STAT_GIANT|RL_RDESC_STAT_RUNT| \
    RL_RDESC_STAT_CRCERR)

#define RL_RDESC_VLANCTL_TAG	0x00010000      /* VLAN tag available (rl_vlandata valid)*/
#define RL_RDESC_VLANCTL_DATA	0x0000FFFF      /* TAG data */
#define RL_RDESC_IPV6		0x80000000
#define RL_RDESC_IPV4		0x40000000

/* RL_FLAGS */
#define RL_FLAG_MSI		0x00000001
#define RL_FLAG_AUTOPAD		0x00000002
#define RL_FLAG_PHYWAKE_PM	0x00000004
#define RL_FLAG_PHYWAKE		0x00000008
#define RL_FLAG_JUMBOV2		0x00000010
#define RL_FLAG_PAR		0x00000020
#define RL_FLAG_DESCV2		0x00000040
#define RL_FLAG_MACSTAT		0x00000080
#define RL_FLAG_FASTETHER	0x00000100
#define RL_FLAG_CMDSTOP		0x00000200
#define RL_FLAG_MACRESET	0x00000400
#define RL_FLAG_MSIX		0x00000800
#define RL_FLAG_WOLRXENB	0x00001000
#define RL_FLAG_MACSLEEP	0x00002000
#define RL_FLAG_WAIT_TXPOLL	0x00004000
#define RL_FLAG_CMDSTOP_WAIT_TXQ	0x00008000
#define RL_FLAG_WOL_MANLINK	0x00010000
#define RL_FLAG_EARLYOFF	0x00020000
#define RL_FLAG_8168G_PLUS	0x00040000
#define RL_FLAG_MAGIC_PACKET_V2 0x20000000
#define RL_FLAG_PCIE		0x40000000
#define RL_FLAG_LINK		0x80000000

/**
 * @enum re_flag
 * Flags to reflect state of the helper threads
 *
 */
enum re_flag {
	RE_FLAG_TASK_ENABLED, /*!< Indicates helper tasks are enabled */
	RE_FLAG_TASK_SLOW_PENDING, /*!< Indicates data path slowdown op pending */
	RE_FLAG_TASK_RESET_PENDING, /*!< Indicates device reset op pending */
	RE_FLAG_TASK_PHY_PENDING, /*!< Indicates a phy task is pending */
	RE_FLAG_MAX
};

/**
 * @struct DramAddr
 *
 * @param dram_hi
 * Higher 32 bits of physical address
 * @param dram_low
 * Lower 32 bits of physical address
 *
 */
typedef struct DramAddr {
        uint32_t dram_hi;
        uint32_t dram_lo;
} DramAddr_t;

/**
 * @struct rl_desc
 *
 * @param rl_cmdstat
 * Command and Status related bits
 * @param rl_vlanctl
 * Vlan control related bits
 * @param rl_addr
 * Physical address of the buffer associated with this descriptor
 *
 * Each descriptor is 16 Bytes in length
 */
struct rl_desc {
	uint32_t	rl_cmdstat;
	uint32_t	rl_vlanctl;
	uint64_t	rl_addr;
};

/* Device specific constants */
#define RL_8168			4
#define RL_HWREV_8168EP		0x50000000

/**
 * @struct rl_hwrev
 * Structure to define device type/version details
 *
 * @param rl_rev
 * Indicates the revision of a particular device type
 * @param rl_type
 * Indicates the particular device type
 * @param rl_desc
 * Short description about the device
 * @param rl_max_mtu
 * Maximum Transfer Unit supported by the device
 *
 */
struct rl_hwrev {
	uint32_t                rl_rev;
	int                     rl_type;
	const char              *rl_desc;
	int                     rl_max_mtu;
};

/**
 * @struct rl_hwrevs
 * List of devices (rl_hwrev) supported by this driver
 *
 */
static const struct rl_hwrev re_hwrevs[] = {
	{ RL_HWREV_8168EP, RL_8168, "8168EP", /*RL_NORMAL_MTU*/ RL_JUMBO_MTU_9K},
	{ 0, 0, NULL, 0}
};

enum  {
        EFUSE_NOT_SUPPORT = 0,
        EFUSE_SUPPORT_V1,
        EFUSE_SUPPORT_V2,
        EFUSE_SUPPORT_V3,
        EFUSE_SUPPORT_V4,
};

#define NIC_RAMCODE_VERSION_8168EP (0x0019)

/**
 * @struct re_private
 * Main structure for the device, holding all device and driver configuration
 *
 */
struct re_private {
	void  *mmio_addr;		/* memory map physical address */

	/* Device specific information */
	const struct rl_hwrev   *rl_hwrev;
	uint32_t rl_macrev;
	uint32_t rl_cfg0;
	uint32_t rl_cfg1;
	uint32_t rl_cfg2;
	uint32_t rl_cfg3;
	uint32_t rl_cfg4;
	uint32_t rl_cfg5;
	uint32_t rl_flags;
	uint32_t if_mtu;
	uint32_t if_flags;
	uint32_t rl_txstart;
	uint32_t rl_rxlenmask;
	uint32_t cmdstat_mask;
	uint8_t	rl_type;
	int rl_watchdog_timer;

	/* Tx and Rx Config */
	struct rl_desc *rl_tx_list;	/* 256-aligned Tx descriptor ring */
	struct rl_desc *rl_rx_list;	/* 256-aligned Rx descriptor ring */
	void *rx_databuf[RL_RX_DESC_CNT];	/* Rx data buffers */
	void *tx_databuf[RL_TX_DESC_CNT];	/* Tx data buffers */
	uint64_t rl_tx_list_addr;
	uint64_t rl_rx_list_addr;
	int rl_tx_desccnt;
	int rl_rx_desccnt;
	uint32_t cur_tx;		/* Index into the Tx desc buf of next Rx pkt. */
	uint32_t dirty_tx;
	uint32_t cur_rx;		/* Index into the Rx desc buf of next Rx pkt. */
	uint32_t rx_buf_sz;

	/* Events */
	uint16_t event_slow;
	uint32_t re_flags;

	uint16_t cur_page;
	uint8_t  re_efuse_ver;
        uint16_t re_sw_ram_code_ver;
        uint16_t re_hw_ram_code_ver;
	int re_rx_desc_buf_sz;
	int max_jumbo_frame_size;
	int re_rx_mbuf_sz;
	uint8_t HwSuppDashVer;
	uint8_t re_hw_enable_msi_msix;
	uint8_t re_hw_supp_now_is_oob_ver;
	uint8_t link_state;

	/* Timers */
	TimerHandle_t phy_timer;
	TimerHandle_t task_timer;
	TimerHandle_t poll_timer;
};
#endif
