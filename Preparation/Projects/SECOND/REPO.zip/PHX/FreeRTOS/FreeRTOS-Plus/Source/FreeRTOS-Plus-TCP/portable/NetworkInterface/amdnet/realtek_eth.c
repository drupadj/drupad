/**
 * @file NetworkInterface.c
 * @brief This is the main file for Realtek NIC driver. All Init functions,
 *        Polling functions, Transmit and Receive handling routines are part
 *        of this file
 * @date 30.November.2020
 * @version 1.00.000
 *
 * @copyright Copyright 2020 by Advanced Micro Devices Inc. All Rights Reserved
 *
 */

/*-
 * SPDX-License-Identifier: BSD-4-Clause
 *
 * Copyright (c) 1997, 1998-2003
 *      Bill Paul <wpaul@windriver.com>.  All rights reserved.
 * Copyright (c) 2020
 *      Advanced Micro Devices Inc.,. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by Bill Paul.
 * 4. Neither the name of the author nor the names of any co-contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY Bill Paul AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL Bill Paul OR THE VOICES IN HIS HEAD
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/* General includes */
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <stdio.h>

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

/* FreeRTOS+TCP includes. */
#include "FreeRTOS_IP.h"
#include "FreeRTOS_IP_Private.h"
#include "FreeRTOS_Stream_Buffer.h"
#include "NetworkBufferManagement.h"

/* Xtensa includes */
#include <xtensa/xtruntime.h>
#include <xtensa/hal.h>
//#include <xtensa/sim.h>

/* Common header file */
#include "chip_offset_byte.h"
#include "intr_setup.h"
#include "pci.h"
#include "smn.h"
#include "timer.h"

/* Device specific header file */
#include "realtek_eth.h"
#include "helper.h"

/* Externs */
extern volatile uint8_t gNWWiredShutDwn;
extern uint32_t net_pci_base_addr_lo;
extern volatile uint32_t wlan_base_soc_addr_lo;
extern volatile uint32_t wlan_base_axi_addr;
struct rl_desc *re_tx;     /* 256-aligned Tx descriptor ring */
struct rl_desc *re_rx;     /* 256-aligned Rx descriptor ring */
uint32_t cfg_space_addr_hi;
uint32_t cfg_space_addr_lo;

/* Function prototypes */
BaseType_t re_init( void );
BaseType_t re_network_output(NetworkBufferDescriptor_t * const pxNetworkBuffer,
    BaseType_t bReleaseAfterSend);
BaseType_t re_deinit( void );

static uint32_t re_eri_read_with_oob_base_address(struct re_private *, int, int, int, const uint32_t);
static void re_enable_cfg9346_write(struct re_private *);
static void re_disable_cfg9346_write(struct re_private *);
void MP_WritePciEConfigSpace(struct re_private *, uint16_t, uint32_t);
uint32_t MP_ReadPciEConfigSpace(struct re_private *, uint16_t);
void MP_WritePhyUshort(struct re_private *, uint8_t, uint16_t);
uint16_t MP_ReadPhyUshort(struct re_private *, uint8_t);
void MP_RealWritePhyOcpRegWord(struct re_private *, uint16_t, uint16_t);
uint16_t MP_RealReadPhyOcpRegWord(struct re_private *, uint16_t);
void MP_WritePhyOcpRegWord(struct re_private *, uint16_t , uint8_t, uint16_t);
uint16_t MP_ReadPhyOcpRegWord(struct re_private *, uint16_t, uint8_t);
void MP_WriteMcuAccessRegWord(struct re_private *, uint16_t, uint16_t);
uint16_t MP_ReadMcuAccessRegWord(struct re_private *, uint16_t);
static void re_reset(struct re_private *);
void re_clrwol(struct re_private *);
static void re_hw_start(struct re_private *);

static int msi_disable = 1;
static int msix_disable = 0;
static int prefer_iomap = 0;
//static int eee_enable = 1;
static int eee_enable = 0;
static int phy_power_saving = 1;
static int phy_mdix_mode = RE_ETH_PHY_AUTO_MDI_MDIX;
//static int s5wol = 1;
static int s5wol = 0;
//static int s0_magic_packet = 1;
static int s0_magic_packet = 0;

#define EE_SET(x)					\
	CSR_WRITE_1(RL_EECMD, CSR_READ_1(RL_EECMD) | x)

#define EE_CLR(x)					\
	CSR_WRITE_1(RL_EECMD, CSR_READ_1(RL_EECMD) & ~x)

/**
 * @fn static void re_udelay(unsigned int d)
 * @brief Frees CPU for the specified number of reference clocks
 *
 * @param[in] d
 * Number of reference cycles to delay
 *
 */
static void
re_udelay(unsigned int d)
{
	SysTimeDelay(US_TO_REFCLK(d));
}


static uint16_t MappingPhyOcpAddress(
        struct re_private *tp,
        uint16_t   PageNum,
        uint8_t  RegNum)
{
        uint16_t OcpPhyAddress = 0;
#if 0
        uint16_t OcpPageNum = 0;
        uint8_t OcpRegNum = 0;

        if (PageNum == 0) {
                OcpPageNum = 0x0A40 + (RegNum / 8);
                OcpRegNum = 0x10 + (RegNum % 8);
        } else {
                OcpPageNum = PageNum;
                OcpRegNum = RegNum;
        }

        OcpPageNum <<= 4;

        if (OcpRegNum < 16) {
                OcpPhyAddress = 0;
        } else {
                OcpRegNum -= 16;
                OcpRegNum <<= 1;

                OcpPhyAddress = OcpPageNum + OcpRegNum;
        }
#endif
	OcpPhyAddress = (PageNum + RegNum * 2);
        return OcpPhyAddress;
}

uint16_t MP_RealReadPhyOcpRegWord(
        struct re_private *tp,
        uint16_t OcpRegAddr)
{
        void *ioaddr = tp->mmio_addr;
        uint32_t Timeout = 0, WaitCount = 100;
        uint32_t TmpUlong;
        uint16_t RetVal = 0xffff;

        //TmpUlong = OcpRegAddr / 2;
        //TmpUlong <<= 16;
        //CSR_WRITE_4(RL_PHYOCPACCESS, TmpUlong);
	CSR_WRITE_4(RL_PHYOCPACCESS, OcpRegAddr << 15);

        do {
                re_udelay(1);

                TmpUlong = CSR_READ_4(RL_PHYOCPACCESS);

                Timeout++;
        } while ((!(TmpUlong & RL_PHYAR_BUSY)) && (Timeout < WaitCount));

	if (Timeout == WaitCount) {
		RetVal = (uint16_t)~0;
	} else {
        	RetVal = (uint16_t)TmpUlong;
	}

        return RetVal;
}

uint16_t MP_ReadPhyOcpRegWord(
        struct re_private *tp,
	uint16_t PhyPage,
        uint8_t PhyRegNum)
{

        uint16_t OcpRegAddr;
        uint16_t RetVal = 0xffff;

        OcpRegAddr = MappingPhyOcpAddress(tp, PhyPage, PhyRegNum);

	if (OcpRegAddr & 0xffff0001)
                return 0;
#if 0
        if (OcpRegAddr % 2) {
                uint16_t tmpUshort;

                tmpUshort = MP_RealReadPhyOcpRegWord(tp, OcpRegAddr);
                tmpUshort &= 0xFF00;
                tmpUshort >>= 8;
                RetVal = tmpUshort;


                tmpUshort = MP_RealReadPhyOcpRegWord(tp, OcpRegAddr + 1);
                tmpUshort &= 0x00FF;
                tmpUshort <<= 8;
                RetVal |= tmpUshort;
        } else {
#endif
                RetVal = MP_RealReadPhyOcpRegWord(tp, OcpRegAddr);
#if 0
        }
#endif

        return RetVal;
}

void MP_RealWritePhyOcpRegWord(
        struct re_private *tp,
        uint16_t OcpRegAddr,
        uint16_t RegData)
{
        void *ioaddr = tp->mmio_addr;
        uint32_t Timeout = 0, WaitCount = 100;
        uint32_t TmpUlong;

        //TmpUlong = OcpRegAddr / 2;
        //TmpUlong <<= 16;
        //TmpUlong += RegData;
        //TmpUlong |= BIT_31;

        //CSR_WRITE_4(RL_PHYOCPACCESS, TmpUlong);
	CSR_WRITE_4(RL_PHYOCPACCESS, BIT_31 | (OcpRegAddr << 15) | RegData);

        do {
                re_udelay(1);

                TmpUlong = CSR_READ_4(RL_PHYOCPACCESS);

                Timeout++;
        } while ((TmpUlong & RL_PHYAR_BUSY) && (Timeout < WaitCount));
}

void MP_WritePhyOcpRegWord(
        struct re_private *tp,
	uint16_t PhyPage,
        uint8_t PhyRegNum,
        uint16_t RegData)
{
        uint16_t OcpRegAddr;

        OcpRegAddr = MappingPhyOcpAddress(tp, PhyPage, PhyRegNum);

	if (OcpRegAddr & 0xffff0001)
                return;
#if 0
        if (OcpRegAddr % 2) {
                uint16_t tmpUshort;

                tmpUshort = MP_RealReadPhyOcpRegWord(tp, OcpRegAddr);
                tmpUshort &= 0x00FF;
                tmpUshort |= (RegData <<  8);
                MP_RealWritePhyOcpRegWord(tp, OcpRegAddr, tmpUshort);
                tmpUshort = MP_RealReadPhyOcpRegWord(tp, OcpRegAddr + 1);
                tmpUshort &= 0xFF00;
                tmpUshort |= (RegData >> 8);
                MP_RealWritePhyOcpRegWord(tp, OcpRegAddr + 1, tmpUshort);
        } else {
#endif
                MP_RealWritePhyOcpRegWord(tp, OcpRegAddr, RegData);
#if 0
        }
#endif
}

void MP_WritePhyUshort(struct re_private *tp, uint8_t RegAddr, uint16_t RegData)
{
        uint32_t                TmpUlong=0x80000000;
        uint32_t                Timeout=0;

        if (RegAddr == 0x1F) {
                tp->cur_page = RegData? RegData << 4 : OCP_STD_PHY_BASE;;
        }

	if (tp->cur_page != OCP_STD_PHY_BASE)
                RegAddr -= 0x10;

        //if (RegAddr == 0x1F) {
        //    return;
        //}

        MP_WritePhyOcpRegWord(tp, tp->cur_page, RegAddr, RegData);
}

uint16_t MP_ReadPhyUshort(struct re_private *tp, uint8_t RegAddr)
{
        uint16_t                RegData;
        uint32_t                TmpUlong;
        uint32_t                Timeout=0;

	if (tp->cur_page != OCP_STD_PHY_BASE)
                RegAddr -= 0x10;

        RegData = MP_ReadPhyOcpRegWord(tp, tp->cur_page, RegAddr);
        return RegData;
}

void MP_WriteMcuAccessRegWord(
        struct re_private *tp,
        uint16_t ExtRegAddr,
        uint16_t RegData)
{
        void *ioaddr = tp->mmio_addr;
        //uint32_t TmpUlong;

        //TmpUlong = ExtRegAddr / 2;
        //TmpUlong <<= 16;
        //TmpUlong += RegData;
        //TmpUlong |= BIT_31;

        //CSR_WRITE_4(RL_MCUACCESS, TmpUlong);
        CSR_WRITE_4(RL_MCUACCESS, (BIT_31 | (ExtRegAddr << 15) | RegData));
}

uint16_t MP_ReadMcuAccessRegWord(
        struct re_private *tp,
        uint16_t ExtRegAddr)
{
        void *ioaddr = tp->mmio_addr;
        //uint32_t TmpUlong;
        uint16_t RetVal = 0xffff;

        //TmpUlong = ExtRegAddr / 2;
        //TmpUlong <<= 16;

        //CSR_WRITE_4(RL_MCUACCESS, TmpUlong);
        //TmpUlong = CSR_READ_4(RL_MCUACCESS);
        CSR_WRITE_4(RL_MCUACCESS, ExtRegAddr << 15);
        RetVal = (uint16_t)CSR_READ_4(RL_MCUACCESS);

        return RetVal;
}

void MP_WriteEPhyUshort(struct re_private *tp, uint8_t RegAddr, uint16_t RegData)
{
	void *ioaddr = tp->mmio_addr;
        uint32_t		TmpUlong=0x80000000;
        uint32_t		Timeout=0;

        TmpUlong |= (((uint32_t)RegAddr<<16) | (uint32_t)RegData);

        CSR_WRITE_4(RL_EPHYAR, TmpUlong);

        /* Wait for writing to Phy ok */
        for (Timeout=0; Timeout<5; Timeout++) {
                re_udelay(1000);
                if ((CSR_READ_4(RL_EPHYAR) & RL_PHYAR_BUSY)==0)
                        break;
        }
}

uint16_t MP_ReadEPhyUshort(struct re_private *tp, uint8_t RegAddr)
{
	void *ioaddr = tp->mmio_addr;
        uint16_t		RegData;
        uint32_t		TmpUlong;
        uint32_t		Timeout=0;

        TmpUlong = ((uint32_t)RegAddr << 16);
        CSR_WRITE_4(RL_EPHYAR, TmpUlong);

        /* Wait for writing to Phy ok */
        for (Timeout=0; Timeout<5; Timeout++) {
                re_udelay(1000);
                TmpUlong = CSR_READ_4(RL_EPHYAR);
                if ((TmpUlong & RL_PHYAR_BUSY)!=0)
                        break;
        }

        RegData = (uint16_t)(TmpUlong & 0x0000ffff);

        return RegData;
}


static void
ClearAndSetEthPhyBit(
        struct re_private *tp,
        uint8_t   addr,
        uint16_t   clearmask,
        uint16_t   setmask
)
{
        uint16_t PhyRegValue;
	void *ioaddr = tp->mmio_addr;

        PhyRegValue = MP_ReadPhyUshort(tp, addr);
        PhyRegValue &= ~clearmask;
        PhyRegValue |= setmask;
        MP_WritePhyUshort(tp, addr, PhyRegValue);
}

static void
ClearEthPhyBit(
        struct re_private *tp,
        uint8_t   addr,
        uint16_t   mask
)
{
        ClearAndSetEthPhyBit(tp,
                             addr,
                             mask,
                             0
                            );
}

static void
SetEthPhyBit(
        struct re_private *tp,
        uint8_t   addr,
        uint16_t   mask
)
{
        ClearAndSetEthPhyBit(tp,
                             addr,
                             0,
                             mask
                            );
}

static void
ClearAndSetPCIePhyBit(
        struct re_private *tp,
        uint8_t   addr,
        uint16_t   clearmask,
        uint16_t   setmask
)
{
        uint16_t EphyValue;

        EphyValue = MP_ReadEPhyUshort(tp, addr);
        EphyValue &= ~clearmask;
        EphyValue |= setmask;
        MP_WriteEPhyUshort(tp, addr, EphyValue);
}

static void
ClearPCIePhyBit(
        struct re_private *tp,
        uint8_t   addr,
        uint16_t   mask
)
{
        ClearAndSetPCIePhyBit(tp,
                              addr,
                              mask,
                              0
                             );
}

static void
SetPCIePhyBit(
        struct re_private *tp,
        uint8_t   addr,
        uint16_t   mask
)
{
        ClearAndSetPCIePhyBit(tp,
                              addr,
                              0,
                              mask
                             );
}

/**
 * @fn static inline int test_and_set_bit(long nr, volatile unsigned long *var)
 * @brief Check and set the specified bit in the specified bit array
 *
 * @param[in] nr
 * Bit position to be checked and set if not set
 * @param[in] var
 * Pointer to the bit array
 *
 * Return the old value of the specified bit
 *
 */
static inline int
test_and_set_bit(long nr, volatile unsigned long *var)
{
	unsigned long old, mask;

	mask = 1UL << (nr & (BITS_PER_LONG - 1));
	old = *var;
	taskENTER_CRITICAL();
	*var = *var | mask;
	taskEXIT_CRITICAL();
	return (old & mask) != 0;
}

/**
 * @fn static inline int test_and_clear_bit(long nr, volatile unsigned long *var)
 * @brief Check and clear the specified bit in the specified bit array
 *
 * @param[in] nr
 * Bit position to be checked and cleared if set
 * @param[in] var
 * Pointer to the bit array
 *
 * Return the old value of the specified bit
 *
 */
static inline int
test_and_clear_bit(long nr, volatile unsigned long *var)
{
	unsigned long old, mask;

	mask = 1UL << (nr & (BITS_PER_LONG - 1));
	old = *var;
	taskENTER_CRITICAL();
	*var = *var & ~mask;
	taskEXIT_CRITICAL();
	return (old & mask) != 0;
}

/**
 * @fn static uint64_t re_get_phys_soc_addr(uint32_t axi_addr)
 * @brief Does the memory mapping for the specified virtual address
 *
 * @param[in] axi_addr
 * Virtual address to be memory mapped
 *
 * Return the physical address of the memory mapped region
 *
 */
static uint64_t
re_get_phys_soc_addr(uint32_t axi_addr)
{
	uint32_t axi_base_addr = wlan_base_axi_addr;
	uint32_t dram_hi = 0, dram_lo = wlan_base_soc_addr_lo;
	uint32_t axi_offset = axi_addr - axi_base_addr; 
	uint64_t soc_phys_addr;

	return (((uint64_t)dram_hi << 32ull) + dram_lo + axi_offset);
}

/**
 * @fn static void *re_align(void *data, int size)
 * @brief Aligns the specified memory buffer to specified size
 *
 * @param[in] data
 * Pointer to the data buffer to be aligned
 * @param[in] size
 * Alignment size
 *
 * Returns the pointer to the aligned data buffer
 *
 */
static inline void *
re_align(void *data, int size)
{
	return (void *)ALIGN((long)data, size);
}

/**
 * @fn static void re_gmii_writereg(struct re_private *tp, int reg, uint32_t val)
 * @brief Write the specified PHY register with the specified value
 *
 * @param[in] tp
 * Pointer to device data structure
 * @param[in] reg
 * PHY register to be written
 * @param[in] val
 * Value to be written to the PHY register
 *
 */
//NEEDED -?
static void
re_gmii_writereg(struct re_private *tp, int reg, uint32_t val)
{
#if 0
	void *ioaddr = tp->mmio_addr;
	int i;

	CSR_WRITE_4(RL_PHYAR, 0x80000000 | (reg & 0x1f) << 16 |
	    (val & RL_PHYAR_PHYDATA));

	for (i = 0; i < RL_PHY_TIMEOUT; i++) {
		if (!(CSR_READ_4(RL_PHYAR) & RL_PHYAR_BUSY))
			break;
		re_udelay(25);
	}

	re_udelay(20);

	if (i == RL_PHY_TIMEOUT)
		amf_printf("gmii write timed out!\n");
#endif
}

/**
 * @fn static int re_gmii_readreg(struct re_private *tp, int reg)
 * @brief Read the specified PHY register
 *
 * @param[in] tp
 * Pointer to device data structure
 * @param[in] reg
 * PHY register to be read
 *
 * Return the value of the PHY register
 *
 */
static int
re_gmii_readreg(struct re_private *tp, int reg)
{
	void *ioaddr = tp->mmio_addr;
	int rval;
#if 0
	CSR_WRITE_4(RL_PHYAR, 0x0 | (reg & 0x1f) << 16);

	for (i = 0; i < RL_PHY_TIMEOUT; i++) {
		if (CSR_READ_4(RL_PHYAR) & RL_PHYAR_BUSY)
			break;
		re_udelay(25);
	}

	re_udelay(20);

	//TODO - should this be reverse?
	if (i == RL_PHY_TIMEOUT) {
		amf_printf("gmii read timed out!\n");
		return ((uint32_t)~0);
	} else
		return (CSR_READ_4(RL_PHYAR) & RL_PHYAR_PHYDATA);
#endif

	if (reg == RL_GMEDIASTAT) {
               rval = CSR_READ_1(RL_GMEDIASTAT);
               return (rval);
        }
        return (0);
}

/**
 * @fn static int re_eri_read(struct re_private *tp, int reg)
 * @brief Read the specified ERI register with the specified value
 *
 * @param[in] tp
 * Pointer to device data structure
 * @param[in] reg
 * ERI register to be read
 *
 * Return the value of the specified ERI regiser
 *
 */
static uint32_t re_eri_read(struct re_private *tp, int addr, int type)
{
	uint32_t Timeout = 0, WaitCount = 100;
        void *ioaddr = tp->mmio_addr;

        CSR_WRITE_4(RL_ERIAR, RL_ERIAR_READ_CMD | type | RL_ERIAR_MASK_1111 | addr);

	do {
                re_udelay(100);

		if ((CSR_READ_4(RL_ERIAR) & RL_ERIAR_FLAG))
			break;
                Timeout++;
        } while (Timeout < WaitCount);

	if (Timeout == WaitCount) {
		return ((uint32_t)~0);
	} else {
		return (CSR_READ_4(RL_ERIDR));
	}
}

#if 0
static uint32_t
re_eri_read_with_oob_base_address(struct re_private *tp, int addr, int len,
    int type, const uint32_t base_address)
{
	void *ioaddr = tp->mmio_addr;
        int i, val_shift, shift = 0;
        uint32_t value1 = 0, value2 = 0, mask;
        const uint32_t transformed_base_address = ((base_address & 0x00FFF000) << 6) | (base_address & 0x000FFF);

        if (len > 4 || len <= 0)
                return -1;

        while (len > 0) {
                val_shift = addr % ERIAR_Addr_Align;
                addr = addr & ~0x3;

                CSR_WRITE_4(RL_ERIAR,
                            ERIAR_Read |
                            transformed_base_address |
                            type << ERIAR_Type_shift |
                            ERIAR_ByteEn << ERIAR_ByteEn_shift |
                            addr);

                for (i = 0; i < 10; i++) {
                        re_udelay(100);

                        /* Check if the RTL8168 has completed ERI read */
                        if (CSR_READ_4(RL_ERIAR) & ERIAR_Flag)
                                break;
                }

                if (len == 1)		mask = (0xFF << (val_shift * 8)) & 0xFFFFFFFF;
                else if (len == 2)	mask = (0xFFFF << (val_shift * 8)) & 0xFFFFFFFF;
                else if (len == 3)	mask = (0xFFFFFF << (val_shift * 8)) & 0xFFFFFFFF;
                else			mask = (0xFFFFFFFF << (val_shift * 8)) & 0xFFFFFFFF;

                value1 = CSR_READ_4(RL_ERIDR) & mask;
                value2 |= (value1 >> val_shift * 8) << shift * 8;

                if (len <= 4 - val_shift)
                        len = 0;
                else {
                        len -= (4 - val_shift);
                        shift = 4 - val_shift;
                        addr += 4;
                }
        }

        return value2;
}

static uint32_t re_eri_read(struct re_private *tp, int addr, int len, int type)
{
        return re_eri_read_with_oob_base_address(tp, addr, len, type, 0);
}
#endif

/**
 * @fn static void re_eri_write(struct re_private *tp, int reg, uint32_t val)
 * @brief Write the specified ERI register with the specified value
 *
 * @param[in] tp
 * Pointer to device data structure
 * @param[in] reg
 * ERI register to be written
 * @param[in] value
 * Value to be written to the ERI register
 *
 */
static void re_eri_write(struct re_private *tp, int addr, uint32_t mask,
                          uint32_t val, int type)
{
	uint32_t Timeout = 0, WaitCount = 100;
        void *ioaddr = tp->mmio_addr;

        //BUG_ON((addr & 3) || (mask == 0));
        CSR_WRITE_4(RL_ERIDR, val);
        CSR_WRITE_4(RL_ERIAR, RL_ERIAR_WRITE_CMD | type | mask | addr);

	do {
                re_udelay(100);

		if (!(CSR_READ_4(RL_ERIAR) & RL_ERIAR_FLAG))
			break;
                Timeout++;
        } while (Timeout < WaitCount);

        re_udelay(50);
}

#if 0
static int
re_eri_write_with_oob_base_address(struct re_private *tp, int addr, int len,
    uint32_t value, int type, const uint32_t base_address)
{
	void *ioaddr = tp->mmio_addr;
        int i, val_shift, shift = 0;
        uint32_t value1 = 0, mask;
        const uint32_t transformed_base_address = ((base_address & 0x00FFF000) << 6) | (base_address & 0x000FFF);

        if (len > 4 || len <= 0)
                return -1;

        while (len > 0) {
                val_shift = addr % ERIAR_Addr_Align;
                addr = addr & ~0x3;

                if (len == 1)		mask = (0xFF << (val_shift * 8)) & 0xFFFFFFFF;
                else if (len == 2)	mask = (0xFFFF << (val_shift * 8)) & 0xFFFFFFFF;
                else if (len == 3)	mask = (0xFFFFFF << (val_shift * 8)) & 0xFFFFFFFF;
                else			mask = (0xFFFFFFFF << (val_shift * 8)) & 0xFFFFFFFF;

                value1 = re_eri_read_with_oob_base_address(tp, addr, 4, type, base_address) & ~mask;
                value1 |= ((value << val_shift * 8) >> shift * 8);

                CSR_WRITE_4(RL_ERIDR, value1);
                CSR_WRITE_4(RL_ERIAR,
                            ERIAR_Write |
                            transformed_base_address |
                            type << ERIAR_Type_shift |
                            ERIAR_ByteEn << ERIAR_ByteEn_shift |
                            addr);

                for (i = 0; i < 10; i++) {
                        re_udelay(100);

                        /* Check if the RTL8168 has completed ERI write */
                        if (!(CSR_READ_4(RL_ERIAR) & ERIAR_Flag))
                                break;
                }

                if (len <= 4 - val_shift)
                        len = 0;
                else {
                        len -= (4 - val_shift);
                        shift = 4 - val_shift;
                        addr += 4;
                }
        }

        return 0;
}

static int re_eri_write(struct re_private *tp, int addr, int len, uint32_t value, int type)
{
        return re_eri_write_with_oob_base_address(tp, addr, len, value, type, 0);
}
#endif

/**
 * @fn static inline void re_disown_from_asic(struct rl_desc *desc)
 * @brief Release descriptor from hardware
 *
 * @param[in] desc
 * Pointer to descriptor to be freed from hardware
 *
 */
static inline void
re_disown_from_asic(struct rl_desc *desc)
{
	desc->rl_addr = (0x0badbadbadbadbadull);
	desc->rl_vlanctl = 0;
	desc->rl_cmdstat &= ~(RL_TDESC_CMD_OWN | RL_TDESC_RSVDMASK);
}

/**
 * @fn static inline void re_own_to_asic(struct rl_desc *desc, uint32_t rx_buf_sz)
 * @brief Mark the descriptor to hardware
 *
 * @param[in] desc
 * Pointer to descriptor to be marked to hardware
 * @param[in] rx_buf_sz
 * Size of the buffer associated with the specified descriptor
 *
 */
static inline void
re_own_to_asic(struct rl_desc *desc, uint32_t rx_buf_sz)
{
	uint32_t eor = (desc->rl_cmdstat) & RL_TDESC_CMD_EOR;

	/* Force memory writes to complete before releasing descriptor */
	MEM_BARRIER;

	desc->rl_vlanctl = 0;
	desc->rl_cmdstat = RL_TDESC_CMD_OWN | eor | rx_buf_sz;
}

/**
 * @fn static void re_poll_timer_start(struct re_private *tp)
 * @brief Starts the data path poll timer
 *
 * @param[in] tp
 * Pointer to the device structure
 *
 */
static void
re_poll_timer_start(struct re_private *tp)
{
	BaseType_t xPollTimerStarted;

	xPollTimerStarted = xTimerStart(tp->poll_timer, 0xFFF);
	if (xPollTimerStarted != pdPASS) {
		amf_printf("Poll timer creation failed!\n");
		_exit(-1);
	}
}

/**
 * @fn static void re_poll_timer_stop(struct re_private *tp)
 * @brief Stops the data path poll timer
 *
 * @param[in] tp
 * Pointer to the device structure
 *
 */
static void
re_poll_timer_stop(struct re_private *tp)
{
	BaseType_t xPollTimerStopped;

	xPollTimerStopped = xTimerStop(tp->poll_timer, 0xFFF);
	if (xPollTimerStopped != pdPASS) {
		amf_printf("Poll timer stop failed!\n");
		_exit(-1);
	}
}

/**
 * @fn static void re_check_link_status(struct re_private *tp)
 * @brief Poll the link status
 *
 * @param[in] tp
 * Pointer to the device structure
 *
 */
static void
re_check_link_status(struct re_private *tp)
{
	void *ioaddr = tp->mmio_addr;

	amf_printf("%s: RL_GMEDIASTAT 0x%x\n", __func__, CSR_READ_1(RL_GMEDIASTAT));

	if (CSR_READ_1(RL_GMEDIASTAT) & RL_GMEDIASTAT_LINK) {
		/* This is to cancel a scheduled suspend if there's one. */
		amf_printf("link up\n");
	} else {
		amf_printf("link down\n");
	}
}

/**
 * @fn static void re_hw_reset(struct re_private *tp)
 * @brief Wrapper to reset the hardware
 *
 * @param[in] tp
 * Pointer to the device structure
 *
 * This routine clears the interrupt, clears the pending transmit and receive
 * ops before resetting the hardware.
 *
 */
static void
re_hw_reset(struct re_private *tp)
{
	void *ioaddr = tp->mmio_addr;
	int i;

	/* Disable interrupts */
	CSR_WRITE_2(RL_IMR, 0);

	/* Ack and clear pending interrupts */
	CSR_WRITE_2(RL_ISR, RL_EVENT_RXTX | tp->event_slow);

	MEM_BARRIER;

	/* Stop Rx */
	CSR_WRITE_4(RL_RXCFG, CSR_READ_4(RL_RXCFG) & ~RX_CONFIG_ACCEPT_MASK);

	/* Stop Tx */
	CSR_WRITE_1(RL_COMMAND, CSR_READ_1(RL_COMMAND) | RL_COMMAND_STOPREQ);
	for (i = RL_TIMEOUT; i > 0; i--) {
		if ((CSR_READ_4(RL_TXCFG) & RL_TXCFG_QUEUE_EMPTY) != 0)
			break;
	        re_udelay(100);
	}

	if (i == 0)
		amf_printf("stopping TXQ timed out!\n");

	/* Chip Reset */
	re_reset(tp);
}

/**
 * @fn static void re_tx_clear(struct re_private *tp, uint32_t entry)
 * @brief Clear the specified transmit descriptor
 *
 * @param[in] tp
 * Pointer to the device structure
 * @param[in] entry
 * Index of the transmit descriptor to be cleared
 *
 * This routine frees the data buffers associated to the specified transmit
 * descriptor and release that from the hardware.
 *
 */
static void
re_tx_clear(struct re_private *tp, uint32_t entry)
{
	if(tp->tx_databuf[entry] != NULL) {
		vWlanPortFree(tp->tx_databuf[entry]);
		tp->tx_databuf[entry] = NULL;
	}

	tp->rl_tx_list[entry].rl_cmdstat = 0x00;
	tp->rl_tx_list[entry].rl_vlanctl = 0x00;
	tp->rl_tx_list[entry].rl_addr = 0x00;
}

/**
 * @fn static void re_tx_clear_range(struct re_private *tp)
 * @brief Clears all transmit descriptor
 *
 * @param[in] tp
 * Pointer to the device structure
 *
 * This routine frees all the pending transmit descriptor.
 *
 */
static void
re_tx_clear_range(struct re_private *tp)
{
	unsigned int i;

	for (i = 0; i < RL_TX_DESC_CNT; i++) {
		unsigned int entry = (tp->dirty_tx + i) % RL_TX_DESC_CNT;

		re_tx_clear(tp, entry);
	}

	tp->cur_tx = tp->dirty_tx = 0;
}

/**
 * @fn static void re_reset_work(struct re_private *tp)
 * @brief Helper thread to reset and reinit the hardware
 *
 * @param[in] tp
 * Pointer to the device structure
 *
 * This routine triggers the clearing of pending IO requests, reset the
 * hardware and initialize it again with all helper threads started.
 *
 */
static void
re_reset_work(struct re_private *tp)
{
	uint32_t i;

	re_poll_timer_stop(tp);

	/* Reset HW */
	re_hw_reset(tp);

	/* Init Rx Descs */
	for (i = 0; i < RL_RX_DESC_CNT; i++)
		re_own_to_asic(tp->rl_rx_list + i, tp->rx_buf_sz);
	tp->cur_rx = 0;

	/* Init Tx Descs */
	re_tx_clear_range(tp);

	/* Init HW */
	//re_hw_init(tp);

	/* Start Polling */
	re_poll_timer_start(tp);

	/* Check Link status */
	re_check_link_status(tp);
}

/**
 * @fn static void re_phy_work(struct re_private *tp)
 * @brief Helper thread to poll the phy/link status
 *
 * @param[in] tp
 * Pointer to the device structure
 *
 * This routine polls for any pending PHY reset and checks the link status. If
 * link doesn't come up even after PHY reset, it will trigger a PHY reset again
 *
 */
static void
re_phy_work(struct re_private *tp)
{
	void  *ioaddr = tp->mmio_addr;
	unsigned long timeout = PHY_RESET_TIMEOUT;
	unsigned int val;
	BaseType_t xTaskTimerStarted;

	if (re_gmii_readreg(tp, MII_BMCR) & BMCR_RESET) {
		/*
		 * A busy loop could burn quite a few cycles on nowadays CPU.
		 * Let's delay the execution of the timer for a few ticks.
		 */
		timeout = configTICK_RATE_HZ/10;
		goto out_mod_timer;
	}

	if (CSR_READ_1(RL_GMEDIASTAT) & RL_GMEDIASTAT_LINK)
		return;

	amf_printf("PHY reset until link up\n");

	val = re_gmii_readreg(tp, MII_BMCR) | BMCR_RESET;
	re_gmii_writereg(tp, MII_BMCR, val & 0xffff);

out_mod_timer:
	xTaskTimerStarted = xTimerChangePeriod(tp->phy_timer, timeout, 0xFFF);
	if (xTaskTimerStarted != pdPASS) {
		amf_printf("Failed to re-schedule phy timer!\n");
		_exit(-1);
	}
}

/**
 * @fn static void re_slow_event_work(struct re_private *tp)
 * @brief Helper thread to handle pending IO.
 *
 * @param[in] tp
 * Pointer to the device structure
 *
 * This routine checks and clears the pending interrupts events and polls for
 * pending IO and triggers their handling.
 *
 */
static void
re_slow_event_work(struct re_private *tp)
{
	void *ioaddr = tp->mmio_addr;
	uint16_t status;

	status = (CSR_READ_2(RL_ISR) & tp->event_slow);
	CSR_WRITE_2(RL_ISR, status);
	MEM_BARRIER;

	if (status & RL_ISR_LINKCHG)
		re_check_link_status(tp);


}

/**
 * @fn static inline int re_fragmented_frame(uint32_t status)
 * @brief Checks whether the received frame is fragemented
 *
 * @param[in] status
 * Status (WORD 0) from the receive descriptor
 *
 * Return 1 if the frame is fragmented. Else return 0
 *
 */
static inline int
re_fragmented_frame(uint32_t status)
{
	return (status & (RL_RDESC_STAT_SOF | RL_RDESC_STAT_EOF)) !=
	    (RL_RDESC_STAT_SOF | RL_RDESC_STAT_EOF);
}

/**
 * @fn static void re_try_rx_copy(void *data, int pkt_size, void *pucEthernetBuffer)
 * @brief Copy received packet to upper stack
 *
 * @param[in] data
 * Received data buffer pointer from the descriptor
 * @param[in] pkt_size
 * Size of the received packet
 * @param[in] pucEthernetBuffer
 * Pointer to the upper stack buffer, where the received packet is copied to
 *
 */
static void
re_try_rx_copy(void *data, int pkt_size, void * pucEthernetBuffer)
{
	data = re_align(data, 16);
	memcpy(pucEthernetBuffer, data, pkt_size);
}

/**
 * @fn static void re_schedule_task(struct re_private *tp, enum re_flag flag)
 * @brief Main scheduler routine for all helper threads
 *
 * @param[in] tp
 * Pointer to device data structure.
 * @param[in] flag
 * Event that need to be scheduled.
 *
 */
static void
re_schedule_task(struct re_private *tp, enum re_flag flag)
{
	BaseType_t xTaskTimerStarted;
	//amf_printf("%s\n", __func__);

	if (!test_and_set_bit(flag, (unsigned long*)&tp->re_flags)) {
		xTaskTimerStarted = xTimerStart(tp->task_timer, 0xFFF);
		if (xTaskTimerStarted != pdPASS) {
			amf_printf("Task timer creation failed!\n");
			_exit(-1);
		}
	}
}

/**
 * @fn static void re_process_pkt(struct re_private *tp, unsigned int entry)
 * @brief Main packet processing routine
 *
 * @param[in] tp
 * Pointer to device data structure.
 * @param[in] entry
 * Index to the receive descriptor
 *
 */
static void
re_process_pkt(struct re_private *tp, unsigned int entry)
{
	struct rl_desc *desc = tp->rl_rx_list + entry;
	uint32_t status = desc->rl_cmdstat & tp->cmdstat_mask;
	uint64_t addr = desc->rl_addr;
	int pkt_size = (status & RL_RDESC_STAT_GFRAGLEN) - 4;
	IPStackEvent_t xRxEvent;

	/*
	 * The driver does not support incoming fragmented
	 * frames. They are seen as a symptom of over-mtu
	 * sized frames.
	 */
	if (re_fragmented_frame(status)) {
		//dev->stats.rx_dropped++;
		//dev->stats.rx_length_errors++;
		re_own_to_asic(desc, tp->rx_buf_sz);
		return;
	}

	if ((pkt_size > 0) && (pkt_size <= tp->rx_buf_sz)) {
		/*
		 * Allocate a network buffer descriptor that
		 * points to a buffer large enough to hold the
		 * received frame.  As this is the simple
		 * rather than efficient example the received
		 * data will just be copied into this buffer.
		 */
		NetworkBufferDescriptor_t *pxBufferDescriptor =
		    pxGetNetworkBufferWithDescriptor_wheap(pkt_size, 0);

		if (pxBufferDescriptor != NULL) {
			/*
			 * pxBufferDescriptor->pucEthernetBuffer now
			 * points to an Ethernet buffer large enough to
			 * hold the received data. Copy the received data
			 * into pcNetworkBuffer->pucEthernetBuffer. Here it
			 * is assumed ReceiveData() is a peripheral
			 * driver function that copies the received data
			 * into a buffer passed in as the function’s
			 * parameter. Remember! While is is a simple
			 * robust technique – it is not efficient. An
			 * example that uses a zero copy technique is
			 * provided further down this page.
			 */
			re_try_rx_copy(tp->rx_databuf[entry], pkt_size,
			    pxBufferDescriptor->pucEthernetBuffer);
			pxBufferDescriptor->xDataLength = pkt_size;

			/*
			 * See if the data contained in the received
			 * Ethernet frame needs to be processed.
			 * NOTE! It is preferable to do this in the
			 * interrupt service routine itself, which would
			 * remove the need to unblock this task for
			 * packets that don’t need processing
			 */
			if (eConsiderFrameForProcessing(pxBufferDescriptor->pucEthernetBuffer)
			    == eProcessBuffer) {

				/*
				 * The event about to be sent to
				 * the TCP/IP is an Rx event.
				 */
				xRxEvent.eEventType = eNetworkRxEvent;

				/*
				 * pvData is used to point to the
				 * network buffer descriptor that
				 * now references the received data.
				 */
				xRxEvent.pvData = (void *)pxBufferDescriptor;

				/*
				 * Send the data to the TCP/IP
				 * stack.
				 */
				if(xSendEventStructToIPTask(&xRxEvent, 0) == pdFALSE) {

					/*
					 * The buffer could not be sent to the IP task so the buffer
					 * must be released.
					 * */
					vReleaseNetworkBufferAndDescriptor(pxBufferDescriptor);

					/*
					 * Make a call to the standard trace macro to log the
					 * occurrence.
					 */
					iptraceETHERNET_RX_EVENT_LOST();
				} else {
					/* 
					 * The message was successfully sent to the TCP/IP stack.
					 * Call the standard trace macro to log the occurrence.
					 */
					iptraceNETWORK_INTERFACE_RECEIVE();
				}
			} else {
				/*
				 * The Ethernet frame can be dropped, 
				 * but the Ethernet buffer must be released.
				 */
				vReleaseNetworkBufferAndDescriptor(pxBufferDescriptor);
			}
		} else {
			/*
			 * The event was lost because a network
			 * buffer was not available. Call the
			 * standard trace macro to log the occurrence.
			 */
			iptraceETHERNET_RX_EVENT_LOST();
		}
	} else {

	 	amf_printf("%s: Invalid pkt size %d\n", __func__, pkt_size);
	}

	re_own_to_asic(desc, tp->rx_buf_sz);
}

/**
 * @fn static int re_rxeof(struct re_private *tp, uint32_t budget)
 * @brief Main Receive packet handling routine
 *
 * @param[in] tp
 * Pointer to device data structure.
 * @param[in] budget
 * Number of Receive packet that can be process at a stretch.
 *
 * Returns the number of packets received and processed.
 *
 * This routine goes through the receive descriptors that is returned by hardware
 * to the driver, process them one by one, submits the received packet to the
 * upper stack buffers and then refills the receive buffers and mark it back to the
 * hardware for further packets. It also handles the error packets.
 *
 */
static int
re_rxeof(struct re_private *tp, uint32_t budget)
{
	unsigned int cur_rx, rx_left;
	unsigned int count;
	IPStackEvent_t xRxEvent;

	//amf_printf("%s\n", __func__);

	cur_rx = tp->cur_rx;

	for (rx_left = min(budget, RL_RX_DESC_CNT); rx_left > 0; rx_left--, cur_rx++) {
		unsigned int entry = cur_rx % RL_RX_DESC_CNT;
		struct rl_desc *desc = tp->rl_rx_list + entry;
		uint32_t status;

		status = desc->rl_cmdstat & tp->cmdstat_mask;
		if (status & RL_RDESC_STAT_OWN)
			break;

		/* This barrier is needed to keep us from reading
		 * any other fields out of the Rx descriptor until
		 * we know the status of DescOwn
		 */
		MEM_BARRIER;

		if (status & RL_RDESC_STAT_RXERRSUM) {
			amf_printf( "Rx ERROR. status = %08x\n", status);
			if (status & (RL_RDESC_STAT_GIANT | RL_RDESC_STAT_RUNT)) {
				//dev->stats.rx_length_errors++;
			}

			if (status & RL_RDESC_STAT_CRCERR) {
				//dev->stats.rx_crc_errors++;
			}

			if (status & RL_RDESC_STAT_FIFOOFLOW) {
				re_schedule_task(tp, RE_FLAG_TASK_RESET_PENDING);
				//dev->stats.rx_fifo_errors++;
			}

			if ((status &
			    (RL_RDESC_STAT_RUNT | RL_RDESC_STAT_CRCERR)) &&
			    !(status &
			    (RL_RDESC_STAT_GIANT | RL_RDESC_STAT_FIFOOFLOW)) &&
			    (tp->if_flags & IFF_PROMISC)) {
				re_process_pkt(tp, entry);
			} else {
				re_own_to_asic(desc, tp->rx_buf_sz);
			}
		} else {
			re_process_pkt(tp, entry);
		}
	}

	count = cur_rx - tp->cur_rx;
	tp->cur_rx = cur_rx;

	return count;
}

/**
 * @fn static void re_txeof(struct re_private *tp)
 * @brief Routine to free up and reclaim the transmit buffers
 *
 * @param[in] tp
 * Pointer to device data structure.
 *
 * This routine goes through the transmit descriptors, frees up the buffers associated
 * with the transmitted packets, reclaim the descriptors for further transmit packets
 * and does the book keeping of transmit ring indexes.
 *
 */
static void
re_txeof(struct re_private *tp)
{
	unsigned int dirty_tx, tx_left;

	//amf_printf("%s\n", __func__);

	dirty_tx = tp->dirty_tx;

	MEM_BARRIER;

	tx_left = tp->cur_tx - dirty_tx;

	while (tx_left > 0) {

		unsigned int entry = dirty_tx % RL_TX_DESC_CNT;
		uint32_t status;

		status = tp->rl_tx_list[entry].rl_cmdstat;
		if (status & RL_TDESC_CMD_OWN)
			break;

		/* This barrier is needed to keep us from reading
		 * any other fields out of the Tx descriptor until
		 * we know the status of DescOwn
		 */
		MEM_BARRIER;

		re_tx_clear(tp, entry);

		dirty_tx++;
		tx_left--;
	}

	if (tp->dirty_tx != dirty_tx) {

		tp->dirty_tx = dirty_tx;
		/*
		 * Sync with rtl8111_start_xmit:
		 * - publish dirty_tx ring index (write barrier)
		 * - refresh cur_tx ring index and queue status (read barrier)
		 * May the current thread miss the stopped queue condition,
		 * a racing xmit thread can only have a right view of the
		 * ring status.
		 */
		MEM_BARRIER;

		/*
		 * 8168 hack: TxPoll requests are lost when the Tx packets are
		 * too close. Let's kick an extra TxPoll request when a burst
		 * of start_xmit activity is detected (if it is not detected,
		 * it is slow enough). -- FR
		 */
		if (tp->cur_tx != dirty_tx) {

			void *ioaddr = tp->mmio_addr;

			CSR_WRITE_1(tp->rl_txstart, RL_TXSTART_START);
		}
	}
}

/**
 * @fn static void re_task_timer(TimerHandle_t task_timer)
 * @brief Main helper thread
 *
 * @param[in] task_timer
 * Main task timer
 *
 * This is the main helper thread routine.  Other helper threads are invoked
 * from this routine based on the pending tasks.
 *
 */
static void
re_task_timer(TimerHandle_t task_timer)
{
	static const struct {
		int bitnr;
		void (*action)(struct re_private *);
	} re_work[] = {
		/* XXX - keep rtl_slow_event_work() as first element. */
		{ RE_FLAG_TASK_SLOW_PENDING,	re_slow_event_work },
		{ RE_FLAG_TASK_RESET_PENDING,	re_reset_work },
		{ RE_FLAG_TASK_PHY_PENDING,	re_phy_work }
	};
	struct re_private *tp = (struct re_private *)pvTimerGetTimerID(task_timer);
	int i;

	for (i = 0; i < ARRAY_SIZE(re_work); i++) {
		bool pending;

		pending = test_and_clear_bit(re_work[i].bitnr,
		    (unsigned long*)&tp->re_flags);
		if (pending)
			re_work[i].action(tp);
	}
}

/**
 * @fn static int re_poll(struct re_private *tp, int budget)
 * @brief Main poll routine to process Transmit and Receive events.
 *
 * @param[in] tp
 * Pointer to device data structure
 * @param[in] budget
 * Number of packet that can be process at a stretch.
 *
 * Returns the number of receive packets processed.
 *
 * This is the main poll routine, which reads the interrupt status register to
 * know the pending IO requets and process the receive and transmit events
 * accordingly.
 *
 */
static int
re_poll(struct re_private *tp, int budget)
{
	uint16_t enable_mask = RL_EVENT_RXTX | tp->event_slow;
	void *ioaddr = tp->mmio_addr;
	int work_done= 0;
	uint16_t status;

	status = CSR_READ_2(RL_ISR);
	//amf_printf("%s: status1 0x%x", __func__, status);
	CSR_WRITE_2(RL_ISR, status & ~tp->event_slow);
	MEM_BARRIER;

	if (status & RL_EVENT_RX) {
		//amf_printf("%s: RX status 0x%x", __func__, status);
		work_done = re_rxeof(tp, (uint32_t)budget);
	}

	if (status & RL_EVENT_TX) {
		//amf_printf("%s: TX status 0x%x", __func__, status);
		re_txeof(tp);
	}

	if (status & tp->event_slow) {
		enable_mask &= ~tp->event_slow;
		//amf_printf("%s: slow pending event_slow 0x%x mask 0x%x", __func__, tp->event_slow, enable_mask);
		re_schedule_task(tp, RE_FLAG_TASK_SLOW_PENDING);
	}

	if (work_done < budget) {
		#ifdef PCI_DEV
		rtl_irq_enable(tp, enable_mask);
		#endif
		MEM_BARRIER;
	}

	return work_done;
}

/**
 * @fn static void re_poll_timer(TimerHandle_t poll_timer)
 * @brief Periodic timer for polling
 *
 * @param[in] poll_timer
 * Timer which handles the periodic polling of IO events.
 *
 * Schedules the poll_timer periodically to trigger the poll task to look for
 * transmit and receive ops and handle them accordingly.
 *
 */
static void
re_poll_timer(TimerHandle_t poll_timer)
{
	struct re_private *tp = (struct re_private *)pvTimerGetTimerID(poll_timer);
	void *ioaddr = tp->mmio_addr;
	uint16_t status;

	//amf_printf("timer is called every 1 msec\n");

	status = CSR_READ_2(RL_ISR);
	//amf_printf("%s: status1 0x%x", __func__, status);
	if (status && status != 0xffff) {
		status &= RL_EVENT_RXTX | tp->event_slow;
		if (status) {
			//amf_printf("%s: status2 0x%x", __func__, status);
			re_poll(tp, RL_TXRX_BUDGET);
		}
	}
}

/**
 * @fn static void re_phy_timer(TimerHandle_t phy_timer)
 * @brief Timer for PHY events
 *
 * @param[in] phy_timer
 * Timer which handles the PHY specific operations.
 *
 * Schedules the phy task which will handle the PHY specific operations.
 *
 */
static void
re_phy_timer(TimerHandle_t phy_timer)
{
	struct re_private *tp = (struct re_private *)pvTimerGetTimerID(phy_timer);

	re_schedule_task(tp, RE_FLAG_TASK_PHY_PENDING);
}

/**
 * @fn static int re_check_dash(struct re_private *tp)
 * @brief Check the DASH firmware status
 *
 * @param[in] tp
 * Pointer to device data structure.
 *
 * Return the DASH firmware status
 *
 */
static int
re_check_dash(struct re_private *tp)
{
	amf_printf("%s: Reg 0x128 - 0x%x\n", __func__, re_eri_read(tp, 0x128, RL_ERIAR_OOB));
	return ((re_eri_read(tp, 0x128, RL_ERIAR_OOB) & BIT_0) ? 1 : 0);
}

/**
 * @fn static void re_driver_start(struct re_private *tp)
 * @brief Start the DASH driver
 *
 * @param[in] tp
 * Pointer to device data structure.
 *
 * This routine starts the DASH driver
 *
 */
static void
re_driver_start(struct re_private *tp)
{
	int i;
	uint32_t tmp_value;

	re_eri_write(tp, 0x180, RL_ERIAR_MASK_0001, RL_OOB_CMD_DRIVER_START, RL_ERIAR_OOB);
	tmp_value = re_eri_read(tp, 0x30, RL_ERIAR_OOB);
	tmp_value |= BIT_0;
	re_eri_write(tp, 0x30, RL_ERIAR_MASK_0001, tmp_value, RL_ERIAR_OOB);
	amf_printf("%s: driver_start pass\n", __func__);
}

/**
 * @fn static void re_set_rxmode(struct re_private *tp)
 * @brief Configure the receive settings
 *
 * @param[in] tp
 * Pointer to device data structure.
 *
 * This routine configures what type of packets can be received/dropped
 * and also programs the hash table for packet filtering.
 *
 */
static void
re_set_rxmode(struct re_private *tp)
{
	uint32_t mc_filter[2];  /* Multicast hash filter */
	int rx_mode;
	uint32_t tmp = 0;
	void *ioaddr = tp->mmio_addr;

	rx_mode = (RL_RXCFG_RX_BROAD | RL_RXCFG_RX_MULTI | RL_RXCFG_RX_INDIV |
	    RL_RXCFG_RX_ALLPHYS | RL_RXCFG_RX_ERRPKT | RL_RXCFG_RX_RUNT);
	tmp = (CSR_READ_4(RL_RXCFG) & ~RX_CONFIG_ACCEPT_MASK) | rx_mode;
	tmp &= ~RL_RXCFG_RX_LANIO;
	mc_filter[1] = mc_filter[0] = 0xffffffff;

	CSR_WRITE_4(RL_MAR4, mc_filter[1]);
	CSR_WRITE_4(RL_MAR0, mc_filter[0]);
	CSR_WRITE_4(RL_RXCFG, tmp);
	amf_printf("%s: RXCFG 0x%x\n", __func__, CSR_READ_4(RL_RXCFG));
}

/**
 * @fn static int re_tx_list_init(struct re_private *tp)
 * @brief Initializes the transmit descriptor list
 *
 * @param[in] tp
 * Pointer to device data structure.
 *
 * Return zero on successful Initialization
 *
 * Initializes the transmit descriptor list and associated descriptors
 *
 */
static int
re_tx_list_init(struct re_private *tp)
{
	struct rl_desc *desc;
	int i;

	/* Init indexes of the ring */
	tp->dirty_tx = tp->cur_tx = 0;

	/* Init descriptors to be zero */
	memset(tp->rl_tx_list, 0x0, tp->rl_tx_desccnt * sizeof(struct rl_desc));

	/* Init data buffers of the descriptors to be zero */
	memset(tp->tx_databuf, 0x0, tp->rl_tx_desccnt * sizeof(void *));

	for (i = 0; i < tp->rl_tx_desccnt; i++)
	        tp->tx_databuf[i] = NULL;

	MEM_BARRIER;

	/* Set EOR. */
	desc = tp->rl_tx_list + (tp->rl_tx_desccnt - 1);
	desc->rl_cmdstat |= RL_TDESC_CMD_EOR;

	return (0);
}

/**
 * @fn static void re_free_desc_databuf(struct re_private *tp, void **data_buff,
 *         struct rl_desc *desc)
 * @brief Free the data buffer associated with the receive descriptor
 *
 * @param[in] tp
 * Pointer to device data structure.
 * @param[in] data_buff
 * Pointer to the data buffer associated with the descriptor
 * @param[in] desc
 * Pointer to the receive descriptor to which the above data buffer
 * is associated with.
 *
 * This routine frees the data buffers associated with the receive descriptor
 * and release the descriptor from the hardware.
 *
 */
static void
re_free_desc_databuf(struct re_private *tp, void **data_buff,
    struct rl_desc *desc)
{
	(void)tp;
	vWlanPortFree(*data_buff);
	*data_buff = NULL;
	re_disown_from_asic(desc);
}

/**
 * @fn static void re_free_rx_databufs(struct re_private *tp)
 * @brief Wrapper to free all the data buffer and the descriptors
 *
 * @param[in] tp
 * Pointer to device data structure.
 *
 * This routine is a wrapper to free all the receive data bufs and descriptors
 *
 */
static void
re_free_rx_databufs(struct re_private *tp)
{
	int i;

	for (i = 0; i < tp->rl_rx_desccnt; i++) {

	        if (tp->rx_databuf[i])
	                re_free_desc_databuf(tp, tp->rx_databuf + i,
			    tp->rl_rx_list + i);
	}
}

/**
 * @fn static void *re_newbuf(struct re_private *tp, struct rl_desc *desc,
 *         int buf_sz, bool rx)
 * @brief Allocates the data buffer for the descriptors
 *
 * @param[in] tp
 * Pointer to device data structure.
 * @param[in] desc
 * Pointer to the descriptor to which the new allocated data buffer
 * will be associated with.
 * @param[in] buf_sz
 * Size of the data buffer to be allocated
 * @param[in] rx
 * Indicates whether the data buffer is for transmit or receive descriptor
 *
 * This routine allocates the data buffers for both transmit and receive
 * descriptors
 *
 * Return the pointer to the newly allocated buffer. NULL is failure
 *
 */
static  void *
re_newbuf(struct re_private *tp, struct rl_desc *desc, int buf_sz, bool rx)
{
	void *data;
	uint64_t dram_addr;
	uint32_t mapping;

	data = pvPortWlanMalloc(buf_sz);
	if (!data)
	        return NULL;

	if (rx) {

		if (re_align(data, 16) != data) {
			vWlanPortFree(data);
			data = pvPortWlanMalloc(buf_sz + 15);
			if (!data)
				return NULL;
		}

		mapping = (uint32_t)re_align(data, 16);
	} else {

		mapping = (uint32_t)data;
	}

	dram_addr = re_get_phys_soc_addr(mapping);

	//amf_printf("%s mapping %p dram_addr %llx\n",
	//    __func__, mapping, dram_addr);
	desc->rl_addr = dram_addr;
	if (rx)
		re_own_to_asic(desc, tp->rx_buf_sz);

	return data;
}

/**
 * @fn static int re_rx_list_init(struct re_private *tp, int buf_sz)
 * @brief Initializes the receive descriptor list
 *
 * @param[in] tp
 * Pointer to device data structure.
 *
 * Initializes the receive descriptor list, receive data buffers and associated
 * descriptors
 *
 * Return 0 on success and -1 on failure.
 *
 */
static int
re_rx_list_init(struct re_private *tp, int buf_sz)
{
	struct rl_desc *desc;
	void *data;
	int i;

	/* Init indexes of the ring */
	tp->cur_rx = 0;

	/* Init descriptors to be zero */
	memset(tp->rl_rx_list, 0x0, tp->rl_rx_desccnt * sizeof(struct rl_desc));

	/* Init data buffers of the descriptors to be zero */
	memset(tp->rx_databuf, 0x0, tp->rl_rx_desccnt * sizeof(void *));

	for (i = 0; i < tp->rl_rx_desccnt; i++) {

	        if (tp->rx_databuf[i])
	                continue;

	        data = re_newbuf(tp, tp->rl_rx_list + i, buf_sz, true);
	        if (!data) {
	                re_disown_from_asic(tp->rl_rx_list + i);
	                goto err_out;
	        }

	        tp->rx_databuf[i] = data;
	}

	/* Set EOR. */
	desc = tp->rl_rx_list + (tp->rl_rx_desccnt - 1);
	desc->rl_cmdstat |= RL_RDESC_CMD_EOR;

	return 0;

err_out:
	re_free_rx_databufs(tp);

	return -1;
}

/**
 * @fn static void *re_alloc_aligned_desc_array(uint32_t len)
 * @brief Allocates Transmit and Receive descriptor ring
 *
 * @param[in] len
 * Size of the buffer to be allocated
 *
 * This routines allocates buffers for the transmit and receive descriptor ring
 *
 * Return pointer to the allocated buffer. NULL on failure.
 *
 */
static void *
re_alloc_aligned_desc_array(uint32_t len, uint8_t tx)
{
	void *data;

	data = pvPortWlanMalloc(len);
	if (!data)
	        return NULL;

	if (re_align(data, 256) != data) {
	        vWlanPortFree(data);
	        data = pvPortWlanMalloc(len + 255);
	        if (!data)
	                return NULL;
	}

	if (tx)
	    re_tx = data;
	else
	    re_rx = data;

	data = re_align(data, 256);

	//amf_printf("re_alloc_aligned: 0x%08x\n", data);
	return data;
}

/**
 * @fn static void re_freemem(struct re_private *tp)
 * @brief Frees the transmit and receive descriptor ring.
 *
 * @param[in] tp
 * Pointer to the device data structure
 *
 * This routines frees the transmit and receive descriptor ring buffer
 *
 */
static void
re_freemem(struct re_private *tp)
{
	if (re_tx) {
		vWlanPortFree(re_tx);
		re_tx = NULL;
		tp->rl_tx_list = NULL;
	}

	if (re_rx) {
		vWlanPortFree(re_rx);
		re_rx = NULL;
		tp->rl_rx_list = NULL;
	}
}

/**
 * @fn static int re_allocmem(struct re_private *tp)
 * @brief Wrapper function to allocate the transmit and receive descriptor ring.
 *
 * @param[in] tp
 * Pointer to the device data structure
 *
 * This routines allocates the transmit and receive descriptor ring buffer
 *
 * Return 0 on success and
 */
static int
re_allocmem(struct re_private *tp )
{
	int retval = -1;
	uint32_t rx_list_size, tx_list_size;

	rx_list_size = tp->rl_rx_desccnt * sizeof(struct rl_desc);
	tx_list_size = tp->rl_tx_desccnt * sizeof(struct rl_desc);
	amf_printf("re_allocmem: rx_size %d tx_size %d\n", rx_list_size,
	    tx_list_size);

	/*
	 * Rx and Tx descriptors needs 256 bytes alignment.
	 * dma_alloc_coherent provides more.
	 */
	tp->rl_tx_list = re_alloc_aligned_desc_array(tx_list_size, 1);
	if (!tp->rl_tx_list)
	        goto err;
	tp->rl_tx_list_addr = re_get_phys_soc_addr((uint32_t)tp->rl_tx_list);
	amf_printf("re_allocmem: tx_list_addr 0x%llx\n", tp->rl_tx_list_addr);

	tp->rl_rx_list = re_alloc_aligned_desc_array(rx_list_size, 0);
	if (!tp->rl_rx_list)
	        goto err;
	tp->rl_rx_list_addr = re_get_phys_soc_addr((uint32_t)tp->rl_rx_list);
	amf_printf("re_allocmem: rx_list_addr 0x%llx\n", tp->rl_rx_list_addr);

	return 0;

err:
	re_freemem(tp);

	return retval;
}

/**
 * @fn static void re_stop(struct re_private *tp)
 * @brief Stops the adapter operations
 *
 * @param[in] tp
 * Pointer to the device data structure
 *
 * This routines stops the adapter operations, frees data structures and
 * all associated data buffers.
 *
 */
void
re_stop(struct re_private *tp)
{
	int	i;
	void	*ioaddr = tp->mmio_addr;

	tp->rl_watchdog_timer = 0;

#if 0
	re_stop_timer(tp);
#endif

	/*
	 * Disable accepting frames to put RX MAC into idle state.
	 * Otherwise it's possible to get frames while stop command
	 * execution is in progress and controller can DMA the frame
	 * to already freed RX buffer during that period.
	 */
	CSR_WRITE_4(RL_RXCFG, CSR_READ_4(RL_RXCFG) &
	    ~(RL_RXCFG_RX_ALLPHYS | RL_RXCFG_RX_INDIV | RL_RXCFG_RX_MULTI |
	    RL_RXCFG_RX_BROAD | RL_RXCFG_RX_RUNT | RL_RXCFG_RX_ERRPKT));	
	amf_printf("%s: RL_RXCFG 0x%x\n", __func__, CSR_READ_4(RL_RXCFG));
#if 0
	if ((tp->rl_flags & RL_FLAG_8168G_PLUS) != 0) {
	        /* Enable RXDV gate. */
	        CSR_WRITE_4(RL_MISC, CSR_READ_4(RL_MISC) |
	            RL_MISC_RXDV_GATED_EN);
	}
#endif

	CSR_WRITE_2(RL_IMR, 0x0000);
	CSR_WRITE_2(RL_ISR, 0xFFFF);
	amf_printf("%s: IMR 0x%x ISR 0x%x\n", CSR_READ_2(RL_IMR), CSR_READ_2(RL_ISR));

	/* Chip Reset */
        re_reset(tp);

#if 0
	if ((tp->rl_flags & RL_FLAG_CMDSTOP) != 0) {

	        CSR_WRITE_1(RL_COMMAND, RL_COMMAND_STOPREQ);// | RL_COMMAND_TX_ENB |
	            //RL_COMMAND_RX_ENB);

	        if ((tp->rl_flags & RL_FLAG_CMDSTOP_WAIT_TXQ) != 0) {
	                for (i = RL_TIMEOUT; i > 0; i--) {
	                        if ((CSR_READ_4(RL_TXCFG) &
	                            RL_TXCFG_QUEUE_EMPTY) != 0)
	                                break;
	                        re_udelay(100);
	                }
	                if (i == 0)
	                        amf_printf("stopping TXQ timed out!\n");
	        }
	}
#endif
	re_udelay(1000);
}

/**
 * @fn static void re_timer_init(struct re_private *tp)
 * @brief Initialize all the timers
 *
 * @param[in] tp
 * Pointer to the device data structure
 *
 * This routines initializes all the necessary timers
 *
 */
static void
re_timer_init(struct re_private *tp)
{

	tp->phy_timer = xTimerCreate("PHY TIMER",
	    pdMS_TO_TICKS(configTICK_RATE_HZ/10), //4ms
	    pdFALSE, (void *)tp, re_phy_timer);

	if (tp->phy_timer == NULL) {
	        amf_printf("Failed to create phy_timer\n");
	        _exit(-1);
	}

	tp->poll_timer = xTimerCreate("POLL TIMER", pdMS_TO_TICKS(4), //4ms
	    pdTRUE, (void *)tp, re_poll_timer);

	if (tp->poll_timer == NULL) {
	        amf_printf("Failed to create poll_timer\n");
	        _exit(-1);
	}

	tp->task_timer = xTimerCreate("TASK TIMER", pdMS_TO_TICKS(4), //4ms
	    pdFALSE, (void *)tp, re_task_timer);

	if (tp->task_timer == NULL) {
	        amf_printf("Failed to create task_timer\n");
	        _exit(-1);
	}
}

#define ISRIMR_DASH_TYPE2_TX_DISABLE_IDLE BIT_5
static void Dash2DisableTx(struct re_private *tp)
{
	void *ioaddr = tp->mmio_addr;
	uint16_t WaitCnt;
        uint8_t TmpUchar;

        //Disable oob Tx
        RE_CMAC_WRITE_1(RL_CMAC_IBCR2, RE_CMAC_READ_1(RL_CMAC_IBCR2) & ~(BIT_0));
	amf_printf("%s: RL_CMAC_IBCR2 0x%x", __func__, RE_CMAC_READ_1(RL_CMAC_IBCR2));
        WaitCnt = 0;

        //wait oob tx disable
        do {
		TmpUchar = RE_CMAC_READ_1(RL_CMAC_IBISR0);
	
		//LINUX DIFF - checks for 0x02, but here checks for 0x20
		if (TmpUchar & ISRIMR_DASH_TYPE2_TX_DISABLE_IDLE) {
                	break;
                }

                re_udelay(50);
                WaitCnt++;
	} while(WaitCnt < 2000);

        //Clear ISRIMR_DASH_TYPE2_TX_DISABLE_IDLE
        RE_CMAC_WRITE_1(RL_CMAC_IBISR0,
	    RE_CMAC_READ_1(RL_CMAC_IBISR0) | ISRIMR_DASH_TYPE2_TX_DISABLE_IDLE);
	amf_printf("%s: RL_CMAC_IBISR0 0x%x", __func__, RE_CMAC_READ_1(RL_CMAC_IBISR0));
}

static void Dash2DisableRx(struct re_private *tp)
{
	void *ioaddr = tp->mmio_addr;

	RE_CMAC_WRITE_1(RL_CMAC_IBCR0, RE_CMAC_READ_1(RL_CMAC_IBCR0) & ~(BIT_0));
	amf_printf("%s: RL_CMAC_IBCR0 0x%x", __func__, RE_CMAC_READ_1(RL_CMAC_IBCR0));
}

static void Dash2DisableTxRx(struct re_private *tp)
{
	Dash2DisableTx(tp);
	Dash2DisableRx(tp);
}

static void re_enable_cfg9346_write(struct re_private *tp)
{
	void *ioaddr = tp->mmio_addr;

        EE_SET(RL_EEMODE_WRITECFG);
}

static void re_disable_cfg9346_write(struct re_private *tp)
{
	void *ioaddr = tp->mmio_addr;

        EE_CLR(RL_EEMODE_WRITECFG);
}

static void re_disable_now_is_oob(struct re_private *tp)
{
	void *ioaddr = tp->mmio_addr;

	CSR_WRITE_1(RL_MCU_CMD, CSR_READ_1(RL_MCU_CMD) & ~RL_NOW_IS_OOB);
	amf_printf("%s: MCU_CMD 0x%x\n", __func__, CSR_READ_1(RL_MCU_CMD));
}

static void DisableMcuBPs(struct re_private *tp)
{
        void *ioaddr = tp->mmio_addr;
        re_enable_cfg9346_write(tp);
        CSR_WRITE_1(RL_CFG5, CSR_READ_1(RL_CFG5) & ~BIT_0);
        CSR_WRITE_1(RL_CFG2, CSR_READ_1(RL_CFG2) & ~BIT_7);
        amf_printf("%s: CFG5 0x%x CFG2 0x%x\n", __func__, CSR_READ_1(RL_CFG5), CSR_READ_1(RL_CFG2));
        re_disable_cfg9346_write(tp);

        MP_WriteMcuAccessRegWord(tp, 0xFC28, 0x0000);
        MP_WriteMcuAccessRegWord(tp, 0xFC2A, 0x0000);
        MP_WriteMcuAccessRegWord(tp, 0xFC2C, 0x0000);
        MP_WriteMcuAccessRegWord(tp, 0xFC2E, 0x0000);
        MP_WriteMcuAccessRegWord(tp, 0xFC30, 0x0000);
        MP_WriteMcuAccessRegWord(tp, 0xFC32, 0x0000);
        MP_WriteMcuAccessRegWord(tp, 0xFC34, 0x0000);
        MP_WriteMcuAccessRegWord(tp, 0xFC36, 0x0000);

        re_udelay(3000);

        MP_WriteMcuAccessRegWord(tp, 0xFC26, 0x0000);
}

static void re_set_mac_mcu_8168ep_2(struct re_private *tp)
{
        DisableMcuBPs(tp);

        MP_WriteMcuAccessRegWord(tp, 0xF800, 0xE008);
        MP_WriteMcuAccessRegWord(tp, 0xF802, 0xE017);
        MP_WriteMcuAccessRegWord(tp, 0xF804, 0xE019);
        MP_WriteMcuAccessRegWord(tp, 0xF806, 0xE01B);
        MP_WriteMcuAccessRegWord(tp, 0xF808, 0xE01D);
        MP_WriteMcuAccessRegWord(tp, 0xF80A, 0xE01F);
        MP_WriteMcuAccessRegWord(tp, 0xF80C, 0xE021);
        MP_WriteMcuAccessRegWord(tp, 0xF80E, 0xE023);
        MP_WriteMcuAccessRegWord(tp, 0xF810, 0xC50F);
        MP_WriteMcuAccessRegWord(tp, 0xF812, 0x76A4);
        MP_WriteMcuAccessRegWord(tp, 0xF814, 0x49E3);
        MP_WriteMcuAccessRegWord(tp, 0xF816, 0xF007);
        MP_WriteMcuAccessRegWord(tp, 0xF818, 0x49C0);
        MP_WriteMcuAccessRegWord(tp, 0xF81A, 0xF103);
        MP_WriteMcuAccessRegWord(tp, 0xF81C, 0xC607);
        MP_WriteMcuAccessRegWord(tp, 0xF81E, 0xBE00);
        MP_WriteMcuAccessRegWord(tp, 0xF820, 0xC606);
        MP_WriteMcuAccessRegWord(tp, 0xF822, 0xBE00);
        MP_WriteMcuAccessRegWord(tp, 0xF824, 0xC602);
        MP_WriteMcuAccessRegWord(tp, 0xF826, 0xBE00);
        MP_WriteMcuAccessRegWord(tp, 0xF828, 0x0BDA);
        MP_WriteMcuAccessRegWord(tp, 0xF82A, 0x0BB0);
        MP_WriteMcuAccessRegWord(tp, 0xF82C, 0x0BBA);
        MP_WriteMcuAccessRegWord(tp, 0xF82E, 0xDC00);
        MP_WriteMcuAccessRegWord(tp, 0xF830, 0xC602);
        MP_WriteMcuAccessRegWord(tp, 0xF832, 0xBE00);
        MP_WriteMcuAccessRegWord(tp, 0xF834, 0x0000);
        MP_WriteMcuAccessRegWord(tp, 0xF836, 0xC602);
	MP_WriteMcuAccessRegWord(tp, 0xF838, 0xBE00);
        MP_WriteMcuAccessRegWord(tp, 0xF83A, 0x0000);
        MP_WriteMcuAccessRegWord(tp, 0xF83C, 0xC602);
        MP_WriteMcuAccessRegWord(tp, 0xF83E, 0xBE00);
        MP_WriteMcuAccessRegWord(tp, 0xF840, 0x0000);
        MP_WriteMcuAccessRegWord(tp, 0xF842, 0xC602);
        MP_WriteMcuAccessRegWord(tp, 0xF844, 0xBE00);
        MP_WriteMcuAccessRegWord(tp, 0xF846, 0x0000);
        MP_WriteMcuAccessRegWord(tp, 0xF848, 0xC602);
        MP_WriteMcuAccessRegWord(tp, 0xF84A, 0xBE00);
        MP_WriteMcuAccessRegWord(tp, 0xF84C, 0x0000);
        MP_WriteMcuAccessRegWord(tp, 0xF84E, 0xC602);
        MP_WriteMcuAccessRegWord(tp, 0xF850, 0xBE00);
        MP_WriteMcuAccessRegWord(tp, 0xF852, 0x0000);
        MP_WriteMcuAccessRegWord(tp, 0xF854, 0xC602);
        MP_WriteMcuAccessRegWord(tp, 0xF856, 0xBE00);
        MP_WriteMcuAccessRegWord(tp, 0xF858, 0x0000);

        MP_WriteMcuAccessRegWord(tp, 0xFC26, 0x8000);

        MP_WriteMcuAccessRegWord(tp, 0xFC28, 0x0BB3);
}

static void re_exit_oob(struct re_private *tp)
{
	void *ioaddr = tp->mmio_addr;
        uint16_t data16;
        int i;

	amf_printf("%s: enter\n", __func__);
        re_disable_cfg9346_write(tp);

        Dash2DisableTxRx(tp);

        if (re_check_dash(tp)) {
                amf_printf("%s: check_dash pass\n", __func__);
                re_driver_start(tp);
        }

	tp->cur_page = OCP_STD_PHY_BASE;

	//LINUX DIFF - only Linux has
	CSR_WRITE_4(RL_MISC, CSR_READ_4(RL_MISC) |
                    RL_MISC_RXDV_GATED_EN);
	amf_printf("%s: MISC 0x%x\n", __func__, CSR_READ_4(RL_MISC));

	//LINUX DIFF - only FBSD has
        //CSR_WRITE_1(RL_MISC1, CSR_READ_1(RL_MISC1) | BIT_3);
	//amf_printf("%s: MISC1 0x%x\n", __func__, CSR_READ_1(RL_MISC1));
        //re_udelay(2000);

        for (i = 0; i < 3000; i++) {
        	re_udelay(50);
                if (CSR_READ_4(RL_TXCFG) & BIT_11) {
			amf_printf("%s: TXCFG BIT11 set\n", __func__);
                	break;
		}
	}

	amf_printf("%s: RL_CMD 0x%x\n", __func__, CSR_READ_1(RL_COMMAND));
        if (CSR_READ_1(RL_COMMAND) & (RL_COMMAND_TX_ENB | RL_COMMAND_RX_ENB)) {
		re_udelay(100);
		CSR_WRITE_1(RL_COMMAND, CSR_READ_1(RL_COMMAND) &
		    ~(RL_COMMAND_TX_ENB | RL_COMMAND_RX_ENB));
		amf_printf("%s: CMD TX and RX CLR\n", __func__);
        }

        for (i = 0; i < 3000; i++) {
		re_udelay(50);
		amf_printf("%s: RL_MCU_CMD 0x%x\n", __func__, CSR_READ_1(RL_MCU_CMD));
                if ((CSR_READ_1(RL_MCU_CMD) & (RL_TXFIFO_EMPTY | RL_RXFIFO_EMPTY)) == (RL_TXFIFO_EMPTY | RL_RXFIFO_EMPTY)) {
			amf_printf("%s: MCU CMD TX and RX FIFO EMPTY\n", __func__);
                	break;
		}
	}
        
        re_disable_now_is_oob(tp);

        data16 = MP_ReadMcuAccessRegWord(tp, 0xE8DE) & ~BIT_14;
        MP_WriteMcuAccessRegWord(tp, 0xE8DE, data16);
	//LINUX DIFF - rtl_link_list_ready_cond, check is different
        for (i = 0; i < 10; i++) {
        	re_udelay(100);
                //if (CSR_READ_2(0xD3) & BIT_1) //TODO - linux use D3/bit1
                if (CSR_READ_2(0xD2) & BIT_9) //TODO - fbsd use D2/bit9
                    break;
	}

        data16 = MP_ReadMcuAccessRegWord(tp, 0xE8DE) | BIT_15;
        MP_WriteMcuAccessRegWord(tp, 0xE8DE, data16);
	//LINUX DIFF - rtl_link_list_ready_cond, check is different
        for (i = 0; i < 10; i++) {
                 re_udelay(100);
                 //if (CSR_READ_2(0xD3) & BIT_1) //TODO - linux use D3/bit1
                 if (CSR_READ_2(0xD2) & BIT_9) //TODO - fbsd use D2/bit9
                       break;
        }

        /*
        * Config MAC MCU
        */
	//LINUX DIFF - not there in Linux code 
	re_set_mac_mcu_8168ep_2(tp);

	amf_printf("%s: exit\n", __func__);
}

static void
re_enable_magic_packet(struct re_private *tp)
{
	re_eri_write(tp, 0xDC, RL_ERIAR_MASK_0001,
	    re_eri_read(tp, 0xDC, RL_ERIAR_EXGMAC) | BIT_16, RL_ERIAR_EXGMAC);
	amf_printf("%s: RL_ERIAR_EXGMAC 0x%x\n", __func__, re_eri_read(tp, 0xDC, RL_ERIAR_EXGMAC));
}

static void
re_disable_magic_packet(struct re_private *tp)
{
	re_eri_write(tp, 0xDC, RL_ERIAR_MASK_0001,
	    re_eri_read(tp, 0xDC, RL_ERIAR_EXGMAC) & ~BIT_16, RL_ERIAR_EXGMAC);
	amf_printf("%s: RL_ERIAR_EXGMAC 0x%x\n", __func__, re_eri_read(tp, 0xDC, RL_ERIAR_EXGMAC));
}

static void re_reset(struct re_private *tp)
{
	void *ioaddr = tp->mmio_addr;
        register int		i;

	//LINUX DIFF - only in FBSD
        CSR_WRITE_4(RL_RXCFG, CSR_READ_4(RL_RXCFG)& ~0x3F);
	amf_printf("%s: RXCFG 0x%x\n", __func__, CSR_READ_4(RL_RXCFG));

        re_udelay(2000);
        CSR_WRITE_1(RL_COMMAND, RL_COMMAND_RESET);

        for (i = 0; i < RL_TIMEOUT; i++) {
                re_udelay(10);
                if (!(CSR_READ_1(RL_COMMAND) & RL_COMMAND_RESET))
                        break;
        }

        if (i == RL_TIMEOUT)
                amf_printf("reset never completed!\n");

	amf_printf("%s: exit\n", __func__);
        return;
}

static void re_rar_set(struct re_private *tp, uint8_t *eaddr)
{
	void *ioaddr = tp->mmio_addr;

        re_enable_cfg9346_write(tp);

        CSR_WRITE_1(RL_IDR0, eaddr[0]);
        CSR_WRITE_1(RL_IDR1, eaddr[1]);
        CSR_WRITE_1(RL_IDR2, eaddr[2]);
        CSR_WRITE_1(RL_IDR3, eaddr[3]);
        CSR_WRITE_1(RL_IDR4, eaddr[4]);
        CSR_WRITE_1(RL_IDR5, eaddr[5]);

	amf_printf("%s: MAC3: 0x%02x-0x%02x-0x%02x-0x%02x-0x%02x-0x%02x\n", __func__,
	    CSR_READ_1(RL_IDR0), CSR_READ_1(RL_IDR1), CSR_READ_1(RL_IDR2),
	    CSR_READ_1(RL_IDR3), CSR_READ_1(RL_IDR4), CSR_READ_1(RL_IDR5));

        re_disable_cfg9346_write(tp);
}

static void re_get_hw_mac_address(struct re_private *tp, uint8_t *eaddr)
{
	void *ioaddr = tp->mmio_addr;
        uint16_t re_eeid = 0;
        int i;

	//LINUX DIFF - not in Linux
        //for (i = 0; i < ETHER_ADDR_LEN; i++)
        //        eaddr[i] = CSR_READ_1(RL_IDR0 + i);

	//amf_printf("%s: MAC1: 0x%02x-0x%02x-0x%02x-0x%02x-0x%02x-0x%02x\n", __func__,
	//    eaddr[0], eaddr[1], eaddr[2], eaddr[3], eaddr[4], eaddr[5]);

        *(uint32_t *)&eaddr[0] = re_eri_read(tp, 0xE0, RL_ERIAR_EXGMAC);
        *(uint16_t *)&eaddr[4] = (uint16_t)re_eri_read(tp, 0xE4, RL_ERIAR_EXGMAC);

	amf_printf("%s: MAC2: 0x%02x-0x%02x-0x%02x-0x%02x-0x%02x-0x%02x\n", __func__,
	    eaddr[0], eaddr[1], eaddr[2], eaddr[3], eaddr[4], eaddr[5]);

#if 0 
        if (!is_valid_ether_addr(eaddr)) {
                device_printf(dev,"Invalid ether addr: %6D\n", eaddr, ":");
                random_ether_addr(eaddr);
                device_printf(dev,"Random ether addr: %6D\n", eaddr, ":");
        }
#endif
        re_rar_set(tp, eaddr);
}

static void re_phy_power_up(struct re_private *tp)
{
	void *ioaddr = tp->mmio_addr;
        uint8_t Data8;

        if ((tp->rl_flags & RL_FLAG_PHYWAKE_PM) != 0) {
                CSR_WRITE_1(RL_PMCH, CSR_READ_1(RL_PMCH) | (BIT_6|BIT_7));
		amf_printf("%s: PMCH 0x%x\n", __func__, CSR_READ_1(RL_PMCH));
	}

        MP_WritePhyUshort(tp, 0x1F, 0x0000);

        MP_WritePhyUshort(tp, MII_BMCR, BMCR_AUTOEN);
	amf_printf("%s: BMCR AUTOEN\n", __func__);

        re_udelay(10000);
}

#if 0
bool
re_set_phy_mcu_patch_request(struct re_private *tp)
{
	void *ioaddr = tp->mmio_addr;
        uint16_t PhyRegValue;
        uint16_t WaitCount = 0;
        int i;
        bool bSuccess = true;

        MP_WritePhyUshort(tp, 0x1f, 0x0B82);
        SetEthPhyBit(tp, 0x10, BIT_4);

        MP_WritePhyUshort(tp, 0x1f, 0x0B80);
        WaitCount = 0;
        do {
                PhyRegValue = MP_ReadPhyUshort(tp, 0x10);
                PhyRegValue &= BIT_6;
                re_udelay(50);
                re_udelay(50);
                WaitCount++;
         } while(PhyRegValue != BIT_6 && WaitCount < 1000);

         if (PhyRegValue != BIT_6 && WaitCount == 1000) bSuccess = false;

         MP_WritePhyUshort(tp, 0x1f, 0x0000);
         return bSuccess;
}

bool
re_clear_phy_mcu_patch_request(struct re_private *tp)
{
        uint16_t PhyRegValue;
        uint16_t WaitCount = 0;
        int i;
        bool bSuccess = true;

        MP_WritePhyUshort(tp, 0x1f, 0x0B82);
        ClearEthPhyBit(tp, 0x10, BIT_4);

        MP_WritePhyUshort(tp, 0x1f, 0x0B80);
        WaitCount = 0;
        do {
                PhyRegValue = MP_ReadPhyUshort(tp, 0x10);
                PhyRegValue &= BIT_6;
                re_udelay(50);
                re_udelay(50);
                WaitCount++;
        } while(PhyRegValue != BIT_6 && WaitCount < 1000);

        if (PhyRegValue != BIT_6 && WaitCount == 1000) bSuccess = false;

        MP_WritePhyUshort(tp, 0x1f, 0x0000);

        return bSuccess;
}

static int re_phy_ram_code_check(struct re_private *tp)
{
        uint16_t PhyRegValue;
        int retval = true;

        MP_WritePhyUshort(tp, 0x1F, 0x0000);

        return retval;
}

static int re_hw_phy_mcu_code_ver_matched(struct re_private *tp)
{
        int ram_code_ver_match = 0;

	MP_WritePhyUshort(tp, 0x1F, 0x0A43);
        MP_WritePhyUshort(tp, 0x13, 0x801E);
        tp->re_hw_ram_code_ver = MP_ReadPhyUshort(tp, 0x14);
        MP_WritePhyUshort(tp, 0x1F, 0x0000);
        
	if (tp->re_hw_ram_code_ver == tp->re_sw_ram_code_ver)
                ram_code_ver_match = 1;

	amf_printf("%s: ram code ver, sw 0x%x  hw 0x%x", __func__,
	    tp->re_sw_ram_code_ver, tp->re_hw_ram_code_ver);

        return ram_code_ver_match;        
}

static void re_set_phy_mcu_8168ep_2(struct re_private *tp)
{
        uint16_t PhyRegValue;

        re_set_phy_mcu_patch_request(tp);

        MP_WritePhyUshort(tp,0x1f, 0x0A43);
        MP_WritePhyUshort(tp,0x13, 0x8146);
        MP_WritePhyUshort(tp,0x14, 0x8700);
        MP_WritePhyUshort(tp,0x13, 0xB82E);
        MP_WritePhyUshort(tp,0x14, 0x0001);

        MP_WritePhyUshort(tp, 0x1F, 0x0A43);

        MP_WritePhyUshort(tp, 0x13, 0x83DD);
        MP_WritePhyUshort(tp, 0x14, 0xAF83);
        MP_WritePhyUshort(tp, 0x14, 0xE9AF);
        MP_WritePhyUshort(tp, 0x14, 0x83EE);
        MP_WritePhyUshort(tp, 0x14, 0xAF83);
        MP_WritePhyUshort(tp, 0x14, 0xF1A1);
        MP_WritePhyUshort(tp, 0x14, 0x83F4);
        MP_WritePhyUshort(tp, 0x14, 0xD149);
        MP_WritePhyUshort(tp, 0x14, 0xAF06);
        MP_WritePhyUshort(tp, 0x14, 0x47AF);
        MP_WritePhyUshort(tp, 0x14, 0x0000);
        MP_WritePhyUshort(tp, 0x14, 0xAF00);
        MP_WritePhyUshort(tp, 0x14, 0x00AF);
        MP_WritePhyUshort(tp, 0x14, 0x0000);

        MP_WritePhyUshort(tp, 0x13, 0xB818);
        MP_WritePhyUshort(tp, 0x14, 0x0645);

        MP_WritePhyUshort(tp, 0x13, 0xB81A);
        MP_WritePhyUshort(tp, 0x14, 0x0000);

        MP_WritePhyUshort(tp, 0x13, 0xB81C);
        MP_WritePhyUshort(tp, 0x14, 0x0000);

        MP_WritePhyUshort(tp, 0x13, 0xB81E);
        MP_WritePhyUshort(tp, 0x14, 0x0000);

        MP_WritePhyUshort(tp, 0x13, 0xB832);
        MP_WritePhyUshort(tp, 0x14, 0x0001);

        MP_WritePhyUshort(tp,0x1F, 0x0A43);
        MP_WritePhyUshort(tp,0x13, 0x0000);
        MP_WritePhyUshort(tp,0x14, 0x0000);
        MP_WritePhyUshort(tp,0x1f, 0x0B82);
        PhyRegValue = MP_ReadPhyUshort(tp, 0x17);
        PhyRegValue &= ~(BIT_0);
        MP_WritePhyUshort(tp,0x17, PhyRegValue);
        MP_WritePhyUshort(tp,0x1f, 0x0A43);
        MP_WritePhyUshort(tp,0x13, 0x8146);
        MP_WritePhyUshort(tp,0x14, 0x0000);

        re_clear_phy_mcu_patch_request(tp);
}

static void re_write_hw_phy_mcu_code_ver(struct re_private *tp)
{
	MP_WritePhyUshort(tp, 0x1F, 0x0A43);
        MP_WritePhyUshort(tp, 0x13, 0x801E);
        MP_WritePhyUshort(tp, 0x14, tp->re_sw_ram_code_ver);
        MP_WritePhyUshort(tp, 0x1F, 0x0000);
        tp->re_hw_ram_code_ver = tp->re_sw_ram_code_ver;
	amf_printf("%s: ram code ver, sw 0x%x  hw 0x%x", __func__,
	    tp->re_sw_ram_code_ver, tp->re_hw_ram_code_ver);
}

static void re_init_hw_phy_mcu(struct re_private *tp)
{
        if (re_hw_phy_mcu_code_ver_matched(tp)) return;

        re_set_phy_mcu_8168ep_2(tp);

        re_write_hw_phy_mcu_code_ver(tp);

        MP_WritePhyUshort(tp, 0x1F, 0x0000);
}

static void re_enable_ocp_phy_power_saving(struct re_private *tp)
{
        uint16_t val;

        val = MP_ReadPhyOcpRegWord(tp, 0x0C41, 0x13);
        if (val != 0x0050) {
            re_set_phy_mcu_patch_request(tp);
            MP_WritePhyOcpRegWord(tp, 0x0C41, 0x13, 0x0000);
            MP_WritePhyOcpRegWord(tp, 0x0C41, 0x13, 0x0050);
            re_clear_phy_mcu_patch_request(tp);
        }
}

static void re_disable_ocp_phy_power_saving(struct re_private *tp)
{
        uint16_t val;

        val = MP_ReadPhyOcpRegWord(tp, 0x0C41, 0x13);
        if (val != 0x0500) {
            re_set_phy_mcu_patch_request(tp);
            MP_WritePhyOcpRegWord(tp, 0x0C41, 0x13, 0x0000);
            MP_WritePhyOcpRegWord(tp, 0x0C41, 0x13, 0x0500);
            re_clear_phy_mcu_patch_request(tp);
        }
}

static int re_enable_EEE(struct re_private *tp)
{
        int ret;
        uint16_t data;

        ret = 0;

	data = re_eri_read(tp, 0x1B0, RL_ERIAR_EXGMAC);
        data |= BIT_1 | BIT_0;
        re_eri_write(tp, 0x1B0, RL_ERIAR_MASK_0001, data, RL_ERIAR_EXGMAC);
        MP_WritePhyUshort(tp, 0x1F, 0x0A43);
        data = MP_ReadPhyUshort(tp, 0x11);
        MP_WritePhyUshort(tp, 0x11, data | BIT_4);
        MP_WritePhyUshort(tp, 0x1F, 0x0A5D);
        MP_WritePhyUshort(tp, 0x10, 0x0006);
        MP_WritePhyUshort(tp, 0x1F, 0x0000);

	//OOB_mutex_lock(sc);
        data = MP_ReadMcuAccessRegWord(tp, 0xE052);
        data &= ~BIT_0;
        MP_WriteMcuAccessRegWord(tp, 0xE052, data);
        //OOB_mutex_unlock(sc);
        data = MP_ReadMcuAccessRegWord(tp, 0xE056);
        data &= 0xFF0F;
        data |= (BIT_4 | BIT_5 | BIT_6);
        MP_WriteMcuAccessRegWord(tp, 0xE056, data);
                
	return ret;
}

static int re_disable_EEE(struct re_private *tp)
{
        int ret;
        uint16_t data;

        ret = 0;

	data = re_eri_read(tp, 0x1B0, RL_ERIAR_EXGMAC);
        data &= ~(BIT_1 | BIT_0);
        re_eri_write(tp, 0x1B0, RL_ERIAR_MASK_0001, data, RL_ERIAR_EXGMAC);
        MP_WritePhyUshort(tp, 0x1F, 0x0A43);
        data = MP_ReadPhyUshort(tp, 0x11);
        MP_WritePhyUshort(tp, 0x11, data & ~BIT_4);
        MP_WritePhyUshort(tp, 0x1F, 0x0A5D);
        MP_WritePhyUshort(tp, 0x10, 0x0000);
        MP_WritePhyUshort(tp, 0x1F, 0x0000);

	data = MP_ReadMcuAccessRegWord(tp, 0xE052);
        data &= ~(BIT_0);
        MP_WriteMcuAccessRegWord(tp, 0xE052, data);
       
	return ret;         
}
#endif                
static void re_hw_phy_config(struct re_private *tp)
{
        uint16_t Data, PhyRegValue, TmpUshort;
        uint32_t Data_u32;
        uint16_t dout_tapbin;
        int	i;
#if 0
	//LINUX DIFF - not there
	re_disable_ocp_phy_power_saving(tp);

	re_set_hw_phy_before_init_phy_mcu(tp);

	//LINUX DIFF - not there
        if (false == re_phy_ram_code_check(tp)) {
                re_set_phy_ram_code_check_fail_flag(tp);
                return;
        }

	//LINUX DIFF - not there
        re_init_hw_phy_mcu(tp);
        MP_WritePhyUshort(tp, 0x1F, 0x0000);
#endif

	MP_WritePhyUshort(tp, 0x1F, 0x0BCC);
        ClearEthPhyBit(tp, 0x14, BIT_8);
        MP_WritePhyUshort(tp, 0x1F, 0x0A44);
        SetEthPhyBit(tp, 0x11, BIT_7);
        SetEthPhyBit(tp, 0x11, BIT_6);
        MP_WritePhyUshort(tp, 0x1F, 0x0A43);
        MP_WritePhyUshort(tp, 0x13, 0x8084);
        ClearEthPhyBit(tp, 0x14, (BIT_14 | BIT_13));
        SetEthPhyBit(tp, 0x10, BIT_12);
        SetEthPhyBit(tp, 0x10, BIT_1);
        SetEthPhyBit(tp, 0x10, BIT_0);
        MP_WritePhyUshort(tp, 0x1F, 0x0000);

        MP_WritePhyUshort(tp, 0x1F, 0x0A43);
        MP_WritePhyUshort(tp, 0x13, 0x8012);
        SetEthPhyBit(tp, 0x14, BIT_15);
        MP_WritePhyUshort(tp, 0x1F, 0x0000);

        MP_WritePhyUshort(tp, 0x1F, 0x0C42);
        ClearAndSetEthPhyBit(tp,
                             0x11,
                             BIT_13,
                             BIT_14
                            );
        MP_WritePhyUshort(tp, 0x1F, 0x0000);

        MP_WritePhyUshort(tp, 0x1F, 0x0A43);
        MP_WritePhyUshort(tp, 0x13, 0x80F3);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0x8B00
                            );
        MP_WritePhyUshort(tp, 0x13, 0x80F0);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0x3A00
                            );
        MP_WritePhyUshort(tp, 0x13, 0x80EF);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0x0500
                            );
        MP_WritePhyUshort(tp, 0x13, 0x80F6);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0x6E00
                            );
        MP_WritePhyUshort(tp, 0x13, 0x80EC);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0x6800
                            );
        MP_WritePhyUshort(tp, 0x13, 0x80ED);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0x7C00
                            );
        MP_WritePhyUshort(tp, 0x13, 0x80F2);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0xF400
                            );
        MP_WritePhyUshort(tp, 0x13, 0x80F4);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0x8500
                            );

        MP_WritePhyUshort(tp, 0x1F, 0x0A43);
        MP_WritePhyUshort(tp, 0x13, 0x8110);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0xA800
                            );
        MP_WritePhyUshort(tp, 0x13, 0x810F);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0x1D00
                            );
        MP_WritePhyUshort(tp, 0x13, 0x8111);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0xF500
                            );
        MP_WritePhyUshort(tp, 0x13, 0x8113);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0x6100
                            );
        MP_WritePhyUshort(tp, 0x13, 0x8115);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0x9200
                            );
        MP_WritePhyUshort(tp, 0x13, 0x810E);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0x0400
                            );
        MP_WritePhyUshort(tp, 0x13, 0x810C);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0x7C00
                            );
        MP_WritePhyUshort(tp, 0x13, 0x810B);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0x5A00
                            );

        MP_WritePhyUshort(tp, 0x1F, 0x0A43);
        MP_WritePhyUshort(tp, 0x13, 0x80D1);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0xFF00
                            );
        MP_WritePhyUshort(tp, 0x13, 0x80CD);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0x9E00
                            );
        MP_WritePhyUshort(tp, 0x13, 0x80D3);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0x0E00
                            );
        MP_WritePhyUshort(tp, 0x13, 0x80D5);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0xCA00
                            );
        MP_WritePhyUshort(tp, 0x13, 0x80D7);
        ClearAndSetEthPhyBit(tp,
                             0x14,
                             0xFF00,
                             0x8400
                            );

	/* Force PWM-mode */
        MP_WritePhyUshort(tp, 0x1f, 0x0bcd);
  	MP_WritePhyUshort(tp, 0x14, 0x5065);
        MP_WritePhyUshort(tp, 0x14, 0xd065);
        MP_WritePhyUshort(tp, 0x1f, 0x0bc8);
        MP_WritePhyUshort(tp, 0x12, 0x00ed);
        MP_WritePhyUshort(tp, 0x1f, 0x0bcd);
        MP_WritePhyUshort(tp, 0x14, 0x1065);
        MP_WritePhyUshort(tp, 0x14, 0x9065);
        MP_WritePhyUshort(tp, 0x14, 0x1065);
        MP_WritePhyUshort(tp, 0x1f, 0x0000);

        /* Check ALDPS bit, disable it if enabled */
        MP_WritePhyUshort(tp, 0x1f, 0x0a43);
        if (MP_ReadPhyUshort(tp, 0x10) & 0x0004) {
		ClearEthPhyBit(tp, 0x10, BIT_2);
                //ClearAndSetEthPhyBit(tp,
                //                     0x14,
                //                     0x0004,
                //                     0x0000
                //                    );
	}

#if 0
	//LINUX DIFF - not in linux 
	amf_printf("%s: phy_power_saving %d\n", __func__, phy_power_saving);
        if (phy_power_saving == 1) {
                MP_WritePhyUshort(tp, 0x1F, 0x0A43);
                SetEthPhyBit(tp, 0x10, BIT_2);
                MP_WritePhyUshort(tp, 0x1F, 0x0000);
        } else {
                MP_WritePhyUshort(tp, 0x1F, 0x0A43);
                ClearEthPhyBit(tp, 0x10, BIT_2);
                MP_WritePhyUshort(tp, 0x1F, 0x0000);
                re_udelay(20000);
        }

        MP_WritePhyUshort(tp, 0x1F, 0x0A43);
        MP_WritePhyUshort(tp, 0x13, 0x8011);
        ClearEthPhyBit(tp, 0x14, BIT_14);
        MP_WritePhyUshort(tp, 0x1F, 0x0A40);
        MP_WritePhyUshort(tp, 0x1F, 0x0000);
        MP_WritePhyUshort(tp, 0x00, 0x9200);

	amf_printf("%s: phy_mdix_mode %d\n", __func__, phy_mdix_mode);
	if (phy_mdix_mode == RE_ETH_PHY_FORCE_MDI) {
               //Force MDI
               MP_WritePhyUshort(tp, 0x1F, 0x0A43);
               SetEthPhyBit(tp, 0x10, BIT_8 | BIT_9);
               MP_WritePhyUshort(tp, 0x1F, 0x0000);
        } else if (phy_mdix_mode == RE_ETH_PHY_FORCE_MDIX) {
               //Force MDIX
               MP_WritePhyUshort(tp, 0x1F, 0x0A43);
               ClearEthPhyBit(tp, 0x10, BIT_8);
               SetEthPhyBit(tp, 0x10, BIT_9);
               MP_WritePhyUshort(tp, 0x1F, 0x0000);
        } else {
                //Auto MDI/MDIX
                MP_WritePhyUshort(tp, 0x1F, 0x0A43);
                ClearEthPhyBit(tp, 0x10, BIT_8 | BIT_9);
                MP_WritePhyUshort(tp, 0x1F, 0x0000);
        }

	amf_printf("%s: phy_power_saving %d\n", __func__, phy_power_saving);
	if (phy_power_saving == 1)
                re_enable_ocp_phy_power_saving(tp);

	amf_printf("%s: eee_enable %d\n", __func__, eee_enable);
	if (eee_enable == 1)
                re_enable_EEE(tp);
        else
                re_disable_EEE(tp);
#endif

        MP_WritePhyUshort(tp, 0x1F, 0x0000);

}

void
re_clrwol(struct re_private *tp)
{
	void *ioaddr = tp->mmio_addr;
        uint8_t                 v;
#if 0
        int                     pmc;
        uint16_t                pmstat;

        if (pci_find_cap(sc->dev, PCIY_PMG, &pmc) != 0)
                return;

        /* Disable PME and clear PME status. */
        pmstat = pci_read_config(sc->dev, pmc + PCIR_POWER_STATUS, 2);
        pmstat &= ~PCIM_PSTAT_PMEENABLE;
        pci_write_config(sc->dev, pmc + PCIR_POWER_STATUS, pmstat, 2);
#endif
        /* Enable config register write. */
        re_enable_cfg9346_write(tp);

        v = CSR_READ_1(RL_CFG3);
        v &= ~(RL_CFG3_WOL_LINK);
        CSR_WRITE_1(RL_CFG3, v);
	amf_printf("%s: CFG3 0x%x\n", __func__, CSR_READ_1(RL_CFG3));

        re_disable_magic_packet(tp);

        v = CSR_READ_1(RL_CFG5);
        v &= ~(RL_CFG5_WOL_BCAST | RL_CFG5_WOL_MCAST | RL_CFG5_WOL_UCAST);
        v &= ~RL_CFG5_WOL_LANWAKE;
        CSR_WRITE_1(RL_CFG5, v);
	amf_printf("%s: CFG5 0x%x\n", __func__, CSR_READ_1(RL_CFG5));

        /* Config register write done. */
        re_disable_cfg9346_write(tp);
}

void set_rxbufsize(struct re_private *tp)
{
	void *ioaddr = tp->mmio_addr;

	CSR_WRITE_2(RL_MAXRXPKTLEN, tp->rx_buf_sz+1);
        amf_printf("%s: RL_MAXRXPKTLEN 0x%x\n", __func__, CSR_READ_2(RL_MAXRXPKTLEN));
}

static void re_set_features(struct re_private *tp)
{
        void  *ioaddr = tp->mmio_addr;
        uint32_t rx_config;
	uint16_t cfg;

        rx_config = CSR_READ_4(RL_RXCFG);
        //rx_config |= (RL_RXCFG_RX_ERRPKT | RL_RXCFG_RX_RUNT);
        rx_config &= ~(RL_RXCFG_RX_ERRPKT | RL_RXCFG_RX_RUNT);
        CSR_WRITE_4(RL_RXCFG, rx_config);
	amf_printf("%s: RXCFG 0x%x\n", __func__, CSR_READ_4(RL_RXCFG));

	cfg |= CSR_READ_2(RL_CPLUS_CMD) & ~(RL_CPLUSCMD_VLANSTRIP |
            RL_CPLUSCMD_RXCSUM_ENB);
        cfg |= RL_CPLUSCMD_RXCSUM_ENB;
        //cfg &= ~RL_CPLUSCMD_RXCSUM_ENB;
        cfg |= RL_CPLUSCMD_VLANSTRIP;
        //cfg &= ~RL_CPLUSCMD_VLANSTRIP;
        amf_printf("hw_init: cplus_cmd cfg 0x%x\n", cfg);
        CSR_WRITE_2(RL_CPLUS_CMD, cfg);
	CSR_READ_2(RL_CPLUS_CMD);
        amf_printf("hw_init: CPLUS_CMD 0x%x\n", CSR_READ_2(RL_CPLUS_CMD));
}

//TODO - Is is equal to MP_WritePciEConfigSpace
static void re_csi_write(struct re_private *tp, int addr, int value)
{
	uint32_t Timeout = 0, WaitCount = 10;
        void *ioaddr = tp->mmio_addr;

        CSR_WRITE_4(RL_CSIDR, value);
        CSR_WRITE_4(RL_CSIAR, CSIAR_WRITE_CMD | (addr & CSIAR_ADDR_MASK) |
                CSIAR_BYTE_ENABLE << CSIAR_BYTE_ENABLE_SHIFT);

	do {
                re_udelay(100);

                Timeout++;
        } while (((CSR_READ_4(RL_CSIAR) & 0x80000000) != 0) && (Timeout < WaitCount));

        re_udelay(50);

        //rtl_udelay_loop_wait_low(tp, &rtl_csiar_cond, 10, 100);
}

//TODO - Is is equal to MP_ReadPciEConfigSpace
static uint32_t re_csi_read(struct re_private *tp, int addr)
{
	uint32_t Timeout = 0, WaitCount = 10;
        void *ioaddr = tp->mmio_addr;

        CSR_WRITE_4(RL_CSIAR, (addr & CSIAR_ADDR_MASK) |
                CSIAR_BYTE_ENABLE << CSIAR_BYTE_ENABLE_SHIFT);

	do {
                re_udelay(100);

                Timeout++;
        } while (((CSR_READ_4(RL_CSIAR) & 0x80000000) == 0)&& (Timeout < WaitCount));

        re_udelay(50);

	if (Timeout == WaitCount) {
		return ((uint32_t)~0);
	} else {
		return CSR_READ_4(RL_CSIDR);
	}

        //rtl_udelay_loop_wait_high(tp, &rtl_csiar_cond, 10, 100);
}

static void re_csi_access_enable(struct re_private *tp, uint32_t bits)
{
        uint32_t csi;

        csi = re_csi_read(tp, 0x070c) & 0x00ffffff;
        re_csi_write(tp, 0x070c, csi | bits);
}

static void re_hw_start_phy(struct re_private *tp)
{
        void *ioaddr = tp->mmio_addr;
	uint8_t                data8 = 0;
        uint32_t               Data32 = 0;

	Dash2DisableTxRx(tp);

        CSR_WRITE_4(RL_TXCFG, CSR_READ_4(RL_TXCFG) | RL_TXCFG_AUTO_FIFO);
	amf_printf("%s: TXCFG 0x%x\n", __func__, CSR_READ_4(RL_TXCFG));

	re_eri_write(tp, 0xc8, RL_ERIAR_MASK_0101, 0x00080002, RL_ERIAR_EXGMAC);
        re_eri_write(tp, 0xcc, RL_ERIAR_MASK_0001, 0x2f, RL_ERIAR_EXGMAC);
        re_eri_write(tp, 0xd0, RL_ERIAR_MASK_0001, 0x5f, RL_ERIAR_EXGMAC);
        re_eri_write(tp, 0xe8, RL_ERIAR_MASK_1111, 0x00100006, RL_ERIAR_EXGMAC);

        re_csi_access_enable(tp, 0x17000000);

        //rtl_tx_performance_tweak(pdev, 0x5 << MAX_READ_REQUEST_SHIFT);

	Data32 = re_eri_read(tp, 0xdc, RL_ERIAR_EXGMAC);
        Data32 &= ~BIT_0;
        re_eri_write(tp, 0xdc, 1, Data32, RL_ERIAR_EXGMAC);
        Data32 |= BIT_0;
        re_eri_write(tp, 0xdc, 1, Data32, RL_ERIAR_EXGMAC);
        //re_w0w1_eri(tp, 0xdc, RL_ERIAR_MASK_0001, 0x00, 0x01, RL_ERIAR_EXGMAC);
        //re_w0w1_eri(tp, 0xdc, RL_ERIAR_MASK_0001, 0x01, 0x00, RL_ERIAR_EXGMAC);

        Data32 = re_eri_read(tp, 0xD4, RL_ERIAR_EXGMAC);
        Data32 |= BIT_7 | BIT_8 | BIT_9 | BIT_10 | BIT_11 | BIT_12;
        re_eri_write(tp, 0xD4, RL_ERIAR_MASK_1111, Data32, RL_ERIAR_EXGMAC);
        //re_w0w1_eri(tp, 0xd4, RL_ERIAR_MASK_1111, 0x1f80, 0x00, RL_ERIAR_EXGMAC);

        re_eri_write(tp, 0x5f0, RL_ERIAR_MASK_0011, 0x4f87, RL_ERIAR_EXGMAC);

	//LINUX DIFF - RL_MISC only in Linux
        CSR_WRITE_4(RL_MISC, CSR_READ_4(RL_MISC) & ~RL_MISC_RXDV_GATED_EN);
        CSR_WRITE_1(RL_EARLY_TX_THRESH, 0x27);
        amf_printf("%s: MISC 0x%x EARLY_THRESH 0x%x\n", __func__, CSR_READ_4(RL_MISC),  CSR_READ_1(RL_EARLY_TX_THRESH));

        re_eri_write(tp, 0xc0, RL_ERIAR_MASK_0011, 0x0000, RL_ERIAR_EXGMAC);
        re_eri_write(tp, 0xb8, RL_ERIAR_MASK_0011, 0x0000, RL_ERIAR_EXGMAC);

        /* Adjust EEE LED frequency */
        CSR_WRITE_1(RL_EEE_LED, CSR_READ_1(RL_EEE_LED) & ~0x07);
        amf_printf("%s: EEE_LED 0x%x\n", __func__, CSR_READ_1(RL_EEE_LED));

        Data32 = re_eri_read(tp, 0x2FC, RL_ERIAR_EXGMAC);
        Data32 &= ~0x06;  //FBSD - (BIT_0 | BIT_1 | BIT_2);
        Data32 |= 0x01;   //FBSD - (BIT_0 | BIT_1); //OLD - 0x01
        re_eri_write(tp, 0x2FC, RL_ERIAR_MASK_1111, Data32, RL_ERIAR_EXGMAC);
	//re_w0w1_eri(tp, 0x2fc, RL_ERIAR_MASK_0001, 0x01, 0x06, RL_ERIAR_EXGMAC);

	CSR_WRITE_1(RL_DLLPR, CSR_READ_1(RL_DLLPR) & ~BIT_7);
        amf_printf("%s: DLLPR 0x%x\n", __func__, CSR_READ_1(RL_DLLPR));

	//clear io_rdy_l23
	CSR_WRITE_1(RL_CFG3, CSR_READ_1(RL_CFG3) & ~BIT_1);
}

static void re_ephy_init(struct re_private *tp, const struct ephy_info *e,
                          int len)
{
        uint16_t w;

        while (len-- > 0) {
                w = (MP_ReadEPhyUshort(tp, e->offset) & ~e->mask) | e->bits;
                MP_WriteEPhyUshort(tp, e->offset, w);
                e++;
        }
}

static void re_hw_start(struct re_private *tp)
{
        void *ioaddr = tp->mmio_addr;
	uint32_t data;
	uint16_t cfg;

	re_enable_cfg9346_write(tp);

	CSR_WRITE_1(RL_EARLY_TX_THRESH, 0x3f);
        //CSR_WRITE_1(MaxTxPacketSize, TxPacketMax);
        amf_printf("%s: RL_EARLY_TX_THRESH 0x%x\n", __func__, CSR_READ_1(RL_EARLY_TX_THRESH));

        set_rxbufsize(tp);
        amf_printf("re_init: set_rxbufsize complete\n");

        CSR_WRITE_2(RL_CPLUS_CMD, CSR_READ_2(RL_CPLUS_CMD) | BIT_7 | BIT_0);
        amf_printf("%s: RL_CPLUSCMD 0x%x\n", __func__, CSR_READ_2(RL_CPLUS_CMD));

        CSR_WRITE_2(RL_INTRMOD, 0x5151);

        CSR_WRITE_4(RL_TXLIST_ADDR_HI,
            ((uint64_t)tp->rl_tx_list_addr) >> 32);
        CSR_WRITE_4(RL_TXLIST_ADDR_LO,
            ((uint64_t)tp->rl_tx_list_addr) & DMA_BIT_MASK(32));
        CSR_WRITE_4(RL_RXLIST_ADDR_HI,
            ((uint64_t)tp->rl_rx_list_addr) >> 32);
        CSR_WRITE_4(RL_RXLIST_ADDR_LO,
            ((uint64_t)tp->rl_rx_list_addr) & DMA_BIT_MASK(32));
        amf_printf("%s: Tx HI 0x%x LO 0x%x RX HI 0x%x LO 0x%x\n", __func__,
            CSR_READ_4(RL_TXLIST_ADDR_HI), CSR_READ_4(RL_TXLIST_ADDR_LO),
            CSR_READ_4(RL_RXLIST_ADDR_HI), CSR_READ_4(RL_RXLIST_ADDR_LO));

        CSR_WRITE_4(RL_TXCFG, (RL_TXCFG_MAXDMA | RL_TXCFG_IFG));

        CSR_READ_1(RL_IMR);
	amf_printf("%s: TXCFG 0x%x IMR 0x%x\n", __func__, CSR_READ_4(RL_TXCFG), CSR_READ_1(RL_IMR));

        /* disable aspm and clock request before access ephy */
        CSR_WRITE_1(tp->rl_cfg2, CSR_READ_1(tp->rl_cfg2) & ~BIT_7);
        CSR_WRITE_1(tp->rl_cfg5, CSR_READ_1(tp->rl_cfg5) & ~BIT_0);
        //CSR_WRITE_1(sc, 0xF1, CSR_READ_1(sc, 0xF1) & ~BIT_7); //TODO - only in FBSD
        amf_printf("%s: CFG2 0x%x CFG5 0x%x\n", __func__, CSR_READ_1(tp->rl_cfg2), CSR_READ_1(tp->rl_cfg5));
        MP_WriteEPhyUshort(tp, 0x00, 0x10AB);
        MP_WriteEPhyUshort(tp, 0x19, 0xFC00);
        MP_WriteEPhyUshort(tp, 0x1E, 0x20EB);
        MP_WriteEPhyUshort(tp, 0x0D, 0x1666);

        re_hw_start_phy(tp);

        CSR_WRITE_1(RL_DLLPR, CSR_READ_1(RL_DLLPR) & ~BIT_6);
        CSR_WRITE_1(RL_DLLPR, CSR_READ_1(RL_MISC1) & ~BIT_6); //TODO - is this correct?
        amf_printf("%s: DLLPR 0x%d MISC1 0x%x\n", __func__, CSR_READ_1(RL_DLLPR), CSR_READ_1(RL_MISC1));

        // TODO - confirm MP_ReadMcuAccessRegWord equals r8168_mac_ocp_read
        data = MP_ReadMcuAccessRegWord(tp, 0xd3e2);
        data &= 0xf000;
        data |= 0x0271;
        MP_WriteMcuAccessRegWord(tp, 0xd3e2, data);

        data = MP_ReadMcuAccessRegWord(tp, 0xd3e4);
        data &= 0xff00;
        MP_WriteMcuAccessRegWord(tp, 0xd3e4, data);

        data = MP_ReadMcuAccessRegWord(tp, 0xe860);
        data |= 0x0080;
        MP_WriteMcuAccessRegWord(tp, 0xe860, data);

	re_clrwol(tp);
        amf_printf("re_init: re_clrwol complete\n");

        re_disable_cfg9346_write(tp);
	
        CSR_WRITE_1(RL_COMMAND, RL_COMMAND_TX_ENB | RL_COMMAND_RX_ENB);
        amf_printf("%s: RL_COMMAND 0x%x\n", __func__, CSR_READ_1(RL_COMMAND));

        re_set_rxmode(tp);

        CSR_WRITE_2(RL_MULTIINTR, CSR_READ_2(RL_MULTIINTR) & 0xf000);
        amf_printf("%s: RL_MULTIINTR 0x%x\n", __func__, CSR_READ_1(RL_MULTIINTR));
}

/**
 * @fn static void re_set_jumbo(struct re_private *tp, int jumbo)
 * @brief Configure the Jumbo frame support
 *
 * @param[in] tp
 * Pointer to device data structure.
 * @param[in] jumbo
 * Interface configured for jumbo frames or not
 *
 * This routine configures the setting to enable/disable the jumbo
 * frames support.
 *
 */
static void
re_set_jumbo(struct re_private *tp, int jumbo)
{
        void *ioaddr = tp->mmio_addr;

	re_enable_cfg9346_write(tp);

	amf_printf("%s: jumbo %d CFG3 0x%x CFG4 0x%x\n", __func__, jumbo, CSR_READ_1(tp->rl_cfg3), CSR_READ_1(tp->rl_cfg4));
        if (jumbo != 0) {
                CSR_WRITE_1(tp->rl_cfg3, CSR_READ_1(tp->rl_cfg3) |
                    RL_CFG3_JUMBO_EN0);
                CSR_WRITE_1(tp->rl_cfg4, CSR_READ_1(tp->rl_cfg4) |
                    RL_CFG4_JUMBO_EN1);
        } else {
                CSR_WRITE_1(tp->rl_cfg3, CSR_READ_1(tp->rl_cfg3) &
                    ~RL_CFG3_JUMBO_EN0);
                CSR_WRITE_1(tp->rl_cfg4, CSR_READ_1(tp->rl_cfg4) &
                    ~RL_CFG4_JUMBO_EN1);
        }
	amf_printf("%s: CFG3 0x%x CFG4 0x%x\n", __func__, CSR_READ_1(tp->rl_cfg3), CSR_READ_1(tp->rl_cfg4));

	re_disable_cfg9346_write(tp);
}

static void re_hw_init(struct re_private *tp)
{
        void *ioaddr = tp->mmio_addr;

        amf_printf("%s: s0_magic_packet %d\n", __func__, s0_magic_packet);
        if (s0_magic_packet == 0)
                re_disable_magic_packet(tp);
        else
                re_enable_magic_packet(tp);

        re_enable_cfg9346_write(tp);
        CSR_WRITE_1(RL_CFG5, CSR_READ_1(RL_CFG5) & ~BIT_0);
        CSR_WRITE_1(RL_CFG2, CSR_READ_1(RL_CFG2) & ~BIT_7);
        CSR_WRITE_1(0xF1, CSR_READ_1(0xF1) & ~BIT_7);
        CSR_WRITE_1(RL_CFG2, CSR_READ_1(RL_CFG2) | BIT_5);
        amf_printf("%s: CFG2 0x%x CFG5 0x%x\n", __func__, CSR_READ_1(RL_CFG2), CSR_READ_1(RL_CFG5));
        re_disable_cfg9346_write(tp);

#if 0
        //TODO - check if this needed?
        if (tp->rl_flags & RL_FLAG_PCIE) {
                uint32_t Data32;
                //Set PCIE uncorrectable error status mask pcie 0x108
                Data32 = MP_ReadPciEConfigSpace(tp, 0xF108);
                Data32 |= BIT_20;
                MP_WritePciEConfigSpace(tp, 0xF108, Data32);
        }
#endif
}

static void
re_configure_phy(struct re_private *tp)
{
	int val;
        uint32_t WaitCnt;
	uint8_t autoneg = AUTONEG_ENABLE;
	uint16_t speed = SPEED_1000;
	uint8_t duplex = DUPLEX_FULL;
	uint32_t adv = (ADVERTISED_10baseT_Half | ADVERTISED_10baseT_Full |
                        ADVERTISED_100baseT_Half | ADVERTISED_100baseT_Full |
                        ADVERTISED_1000baseT_Half | ADVERTISED_1000baseT_Full);
        int auto_nego, giga_ctrl, bmcr;
        int rc = -1;

	/* PHY Reset */
	val = MP_ReadPhyUshort(tp, MII_BMCR) | BMCR_RESET;
        MP_WritePhyUshort(tp, MII_BMCR, val & 0xffff);
        do {
                val = MP_ReadPhyUshort(tp, MII_BMCR);

                if (!(val & BMCR_RESET)) {
                        break;
                }

                re_udelay(1000);
                WaitCnt++;
        } while(WaitCnt < 100);
        amf_printf("re_init: phy_reset_complete\n");

        MP_WritePhyUshort(tp, 0x1f, 0x0000);

	/* configure Auto Negotiation */
        if (autoneg == AUTONEG_ENABLE) {

                auto_nego = MP_ReadPhyUshort(tp, MII_ADVERTISE);
                auto_nego &= ~(ADVERTISE_10HALF | ADVERTISE_10FULL |
                                ADVERTISE_100HALF | ADVERTISE_100FULL);

                if (adv & ADVERTISED_10baseT_Half)
                        auto_nego |= ADVERTISE_10HALF;
                if (adv & ADVERTISED_10baseT_Full)
                        auto_nego |= ADVERTISE_10FULL;
                if (adv & ADVERTISED_100baseT_Half)
                        auto_nego |= ADVERTISE_100HALF;
                if (adv & ADVERTISED_100baseT_Full)
                        auto_nego |= ADVERTISE_100FULL;

                auto_nego |= ADVERTISE_PAUSE_CAP | ADVERTISE_PAUSE_ASYM;

                giga_ctrl = MP_ReadPhyUshort(tp, MII_CTRL1000);
                giga_ctrl &= ~(ADVERTISE_1000FULL | ADVERTISE_1000HALF);

		/* The 8100e/8101e/8102e do Fast Ethernet only. */
                if (adv & ADVERTISED_1000baseT_Half)
                      giga_ctrl |= ADVERTISE_1000HALF;
                if (adv & ADVERTISED_1000baseT_Full)
                      giga_ctrl |= ADVERTISE_1000FULL;

                bmcr = BMCR_AUTOEN | BMCR_ANRESTART;

                MP_WritePhyUshort(tp, MII_ADVERTISE, auto_nego);
                MP_WritePhyUshort(tp, MII_CTRL1000, giga_ctrl);
        } else {
                giga_ctrl = 0;

                if (speed == SPEED_10)
                        bmcr = 0;
                else if (speed == SPEED_100)
                        bmcr = BMCR_SPEED100;
                else
                        return;

                if (duplex == DUPLEX_FULL)
                        bmcr |= BMCR_FULLDPLX;
        }

        MP_WritePhyUshort(tp, MII_BMCR, bmcr);
}

/**
 * @fn BaseType_t re_init(struct re_private **tp_var)
 * @brief Wrapper routine to initialize the device
 *
 * @param[in] tp
 * Pointer to the device data structure
 *
 * This routine is a wrapper initialization routine to initialize the hardware,
 * data buffers and everything for the device operation.
 *
 */
BaseType_t
re_init( void )
{
	const struct rl_hwrev *hw_rev;
	struct re_private *tp = NULL;
	void *ioaddr = NULL;
	unsigned char mac_addr[6];
	uint32_t pci_cmd;
	uint32_t hwrev;
	int i, retval, val;
	BaseType_t ret = pdPASS;
  	uint64_t MpmAddress = GetDramPhysicalBaseAddress();
    	uint64_t MimoAddress;
	uint8_t v;
	uint32_t WaitCnt;

	tp = ( struct re_private * ) pvPortWlanMalloc( sizeof( *tp ) );
	if( NULL != tp ) {
		memset( tp, 0, sizeof( *tp ) );
	} else {
		ret = pdFAIL;
		goto out;
	}

	cfg_space_addr_hi = 0xFFFE;
	cfg_space_addr_lo = net_pci_base_addr_lo;
	amf_printf("Cfg space 0x%x-0x%x\n", cfg_space_addr_hi, cfg_space_addr_lo);

	/* Read BAR2 from PCI-E Config space (offset- 0x18) */
	ioaddr = (void *)ReadFchPCIeMMIO(cfg_space_addr_hi,
	    (cfg_space_addr_lo + PCIE_BAR2));
	ioaddr = (void *)((uint32_t)ioaddr & BAR_ADDRESS_MASK);
	amf_printf("BAR 2 address is %8p\n", (uint32_t *) ioaddr);

	/* fix NCC-E000856-045 */
    	MimoAddress = ((uint64_t)ioaddr << 32ull) + cfg_space_addr_lo;
	amf_printf("Mimo 0x%llx Mpm 0x%llx\n", MimoAddress, MpmAddress);

    	if(MimoAddress >= MpmAddress && MimoAddress < (MpmAddress + SHAREDMEMORY_PHYS_OFFSET)) {
	    return -1;
    	}

	/* Enable bus master */
	pci_cmd = ReadFchPCIeMMIO(cfg_space_addr_hi,
	    (cfg_space_addr_lo + PCIE_CMD));
	pci_cmd |= 0x4;
	WriteFchPCIeMMIO(cfg_space_addr_hi, (cfg_space_addr_lo + PCIE_CMD),
	    pci_cmd);
	amf_printf("re_init: bus_master enabled\n");

	tp->mmio_addr = ioaddr;
	tp->re_flags = 0;
	tp->event_slow = RL_ISR_SYSTEM_ERR | RL_ISR_LINKCHG | RL_ISR_RX_OVERRUN; //TODO - check usage of this flag
	tp->cmdstat_mask = ~(RL_RDESC_STAT_BUFOFLOW | RL_RDESC_STAT_FIFOOFLOW);  //TODO - check usage of this flag
	tp->if_flags = IFF_BROADCAST | IFF_SIMPLEX | IFF_MULTICAST |             //TODO - check usage of this flag
	    IFF_ALLMULTI | IFF_PROMISC;

	/* Identify chip attached to board */
	hwrev = CSR_READ_4(RL_TXCFG);
	amf_printf("re_init: hwrev 0x%08x\n", hwrev);
	switch (hwrev & 0x70000000) {
	case 0x00000000:
	case 0x10000000:
		amf_printf("Chip rev. 0x%08x\n", hwrev & 0xfc800000);
		hwrev &= (RL_TXCFG_HWREV | 0x80000000);
		break;
	default:
		amf_printf("Chip rev. 0x%08x\n", hwrev & 0x7c800000);
		tp->rl_macrev = hwrev & 0x00700000;
		hwrev &= RL_TXCFG_HWREV;
		break;
	}

	amf_printf("MAC rev. 0x%08x\n", tp->rl_macrev);
	hw_rev = re_hwrevs;
	while (hw_rev->rl_desc != NULL) {
		if (hw_rev->rl_rev == hwrev) {
			tp->rl_type = hw_rev->rl_type;
			tp->rl_hwrev = hw_rev;
			break;
		}
		hw_rev++;
	}

	if (hw_rev->rl_desc == NULL) {
		amf_printf("Unknown H/W revision: 0x%08x\n", hwrev);
		ret = pdFAIL;
		goto out;
	}

	amf_printf("re_init: rl_rev 0x%08x\n", hw_rev->rl_rev);
	switch (hw_rev->rl_rev) {
	case RL_HWREV_8168EP:
		tp->if_mtu = hw_rev->rl_max_mtu;
		tp->max_jumbo_frame_size = hw_rev->rl_max_mtu;  //TODO - use this and discard if_mtu and rx_buf_sz
		tp->re_rx_mbuf_sz = tp->max_jumbo_frame_size + ETHER_VLAN_ENCAP_LEN + ETHER_HDR_LEN +
		    ETHER_CRC_LEN + 1; //RE_ETHER_ALIGN - use appropriate RE_ETHER_ALIGN value and this re_rx_mbuf_sz. 
		if (tp->re_rx_mbuf_sz > MJUM9BYTES) {
                	tp->max_jumbo_frame_size -= (tp->re_rx_mbuf_sz - MJUM9BYTES);
                	tp->re_rx_mbuf_sz = MJUM9BYTES;
        	}

		tp->rl_flags |= RL_FLAG_DESCV2 | RL_FLAG_PHYWAKE_PM | RL_FLAG_MAGIC_PACKET_V2 | RL_FLAG_PCIE;

		CSR_WRITE_4(RL_RXCFG, 0xCF00);
		amf_printf("%s: if_mtu %d max_jumbo %d re_rx_mbuf_sz %d rl_flags 0x%x RXCFG 0x%x\n",
		    __func__, tp->if_mtu, tp->max_jumbo_frame_size, tp->re_rx_mbuf_sz, tp->rl_flags, CSR_READ_4(RL_RXCFG));
		break;
	default:
		break;
	}
	amf_printf("re_init: rl_flags 0x%08x\n", tp->rl_flags);

	tp->rl_cfg0 = RL_CFG0;
	tp->rl_cfg1 = RL_CFG1;
	tp->rl_cfg2 = RL_CFG2;
	tp->rl_cfg3 = RL_CFG3;
	tp->rl_cfg4 = RL_CFG4;
	tp->rl_cfg5 = RL_CFG5;
	tp->rl_rxlenmask = RL_RDESC_STAT_GFRAGLEN;  //TODO - remove it
	tp->rl_txstart = RL_GTXSTART;
	tp->rl_tx_desccnt = RL_TX_DESC_CNT;
	tp->rl_rx_desccnt = RL_RX_DESC_CNT;
	tp->HwSuppDashVer = 2; //TODO
	tp->re_efuse_ver = EFUSE_SUPPORT_V3; //TODO - not used
	tp->re_hw_enable_msi_msix = true; //TODO
	tp->re_hw_supp_now_is_oob_ver = 1; //TODO
	tp->re_sw_ram_code_ver = NIC_RAMCODE_VERSION_8168EP; //TODO
	tp->link_state = LINK_STATE_UNKNOWN;

	CSR_WRITE_2(RL_IMR, 0);

#if 0   
	if (pci_find_cap(dev, PCIY_EXPRESS, &reg) == 0)
                tp->re_expcap = reg;

	if (sc->re_expcap != 0) {
                uint32_t		cap, ctl;
                cap = pci_read_config(dev, sc->re_expcap +
                                      RE_PCIER_LINK_CAP, 2);
                if ((cap & RE_PCIEM_LINK_CAP_ASPM) != 0) {
                        ctl = pci_read_config(dev, sc->re_expcap +
                                              RE_PCIER_LINK_CTL, 2);
                        if ((ctl & 0x0103) != 0) {
                                ctl &= ~0x0103;
                                pci_write_config(dev, sc->re_expcap +
                                                 RE_PCIER_LINK_CTL, ctl, 2);
                                device_printf(dev, "ASPM disabled\n");
                        }
                } else
                        device_printf(dev, "no ASPM capability\n");
        }
#endif

	re_exit_oob(tp);

	re_hw_init(tp);  //TODO - only in FBSD

        /*
         * Reset the adapter. Only take the lock here as it's needed in
         * order to call re_reset().
         */
        re_reset(tp);

	//LINUX DIFF - later in FBSD
	CSR_WRITE_2(RL_ISR, 0xFFFF);
#if 0
	/* Enable PME. */
	re_enable_cfg9346_write(tp);
	CSR_WRITE_1(tp->rl_cfg1, CSR_READ_1(tp->rl_cfg1) | RL_CFG1_PME);
	CSR_WRITE_1(tp->rl_cfg5, CSR_READ_1(tp->rl_cfg5) & (RL_CFG5_WOL_BCAST |
	    RL_CFG5_WOL_MCAST | RL_CFG5_WOL_UCAST |
	    RL_CFG5_WOL_LANWAKE | RL_CFG5_PME_STS));
	re_disable_cfg9346_write(tp);
	amf_printf("re_init: PME disabled CFG1 0x%x CFG5 0x%x\n", CSR_READ_1(tp->rl_cfg1), CSR_READ_1(tp->rl_cfg5));
#endif
        /* Get station address. */
        re_get_hw_mac_address(tp, mac_addr);

	/* update local MAC address */
	memcpy((void *)ipLOCAL_MAC_ADDRESS, (void *)mac_addr,
	    (size_t)ipMAC_ADDRESS_LENGTH_BYTES);
	amf_printf("re_init: get_hw_mac pass\n");

	retval = re_allocmem(tp);
	if (retval < 0) {
		amf_printf("re_allocmem failed\n");
	        ret = pdFAIL;
	        goto out;
	}
	amf_printf("re_init: re_allocmem complete\n");

	/* Init Rx Rings */
        if (tp->if_mtu > RL_MTU)
                tp->rx_buf_sz = RL_RX_DESC_BUFLEN_JUMBO;
        else
                tp->rx_buf_sz = RL_RX_DESC_BUFLEN_NORM;

	if (re_rx_list_init(tp, tp->rx_buf_sz) != 0) {
                amf_printf("no memory for jumbo RX buffers\n");
                re_stop(tp);
                return -1;
        }

        re_set_jumbo(tp, tp->if_mtu > RL_MTU);
        amf_printf("hw_init: rx list init done\n");

        /* Init Tx Rings */
        re_tx_list_init(tp);
        amf_printf("hw_init: tx list init done\n");

	re_timer_init(tp);
	amf_printf("re_init: timer_init complete\n");

	re_phy_power_up(tp);
	amf_printf("re_init: phy_power_up complete\n");

        re_hw_phy_config(tp);
	amf_printf("re_init: re_hw_phy_config complete\n");

	//LINUX DIFF - not in FBSD
	re_configure_phy(tp);
	amf_printf("re_init: re_configure_phy complete\n");

	re_set_features(tp);
	amf_printf("re_init: set_features complete\n");

	re_hw_start(tp);
	amf_printf("re_init: hw_start_8168 complete\n");

	re_poll_timer_start(tp);
	amf_printf("hw_start pass\n");

	re_check_link_status(tp);
	amf_printf("link_status pass\n");

	re_priv = tp;

	return ret;

out:
	if (tp)
		vWlanPortFree(tp);

	return ret;
}

/**
 * @fn BaseType_t re_deinit( void )
 * @brief Wrapper routine to deinitialize and shutdown the device
 *
 * This routine is a wrapper deinitialization routine to deinitialize the hardware,
 * data buffers and everything for the device operation.
 *
 */
BaseType_t
re_deinit( void )
{
        BaseType_t ret = pdPASS;

        re_stop(re_priv);

	if(re_priv->poll_timer)
	{
                ret = xTimerStop(re_priv->poll_timer, 0);
                if (ret != pdPASS){
                        amf_printf("Poll Timer Stop fail\n");
                }
                else{
                        amf_printf("Poll Timer Stop pass\n");
                        xTimerDelete(re_priv->poll_timer,0);
                }
        }

	if(re_priv->task_timer)
	{
                ret = xTimerStop(re_priv->task_timer, 0);
                if (ret != pdPASS){
	                amf_printf("Task Timer Stop fail\n");
	        }
	        else{
	                amf_printf("Task Timer Stop pass\n");
	                xTimerDelete(re_priv->task_timer,0);
	        }
	}

	if(re_priv->phy_timer)
	{
                ret = xTimerStop(re_priv->phy_timer, 0);
	        if (ret != pdPASS){
	                amf_printf("PHY Timer Stop fail\n");
	        }
	        else{
	                amf_printf("PHY Timer Stop pass\n");
	                xTimerDelete(re_priv->phy_timer,0);
	        }
	}

        re_free_rx_databufs(re_priv);

        re_freemem(re_priv);

        vWlanPortFree(re_priv);

        return ret;
}

/**
 * @fn BaseType_t re_network_output(NetworkBufferDescriptor_t * const pxNetworkBuffer,
 *         BaseType_t bReleaseAfterSend)
 * @brief Transmit entry routine
 *
 * This routine is an entry point for the transmit operations. This routine
 * does all the buffer allocation, descriptor programming and submitting the
 * same to the hardware.
 *
 */
BaseType_t
re_network_output(NetworkBufferDescriptor_t * const pxNetworkBuffer,
    BaseType_t bReleaseAfterSend)
{
	struct re_private *tp = re_priv;
	unsigned int entry = 0;//tp->cur_tx % RL_TX_DESC_CNT;
	struct rl_desc *txd = 0;//tp->rl_tx_list + entry;
	void *ioaddr = 0;//tp->mmio_addr;
	uint32_t status, len, opts[2];
	void *data = NULL;



	if(gNWWiredShutDwn == 1)
	{
		amf_printf("%s  No access after n/w shutdown, returning\n", __func__);
		return pdFALSE;

	}	
 
	if (tp == NULL)
	{
		amf_printf("%s Error: tp is null\n", __func__);
		return pdFALSE;
	}
	entry = tp->cur_tx % RL_TX_DESC_CNT;
	txd = tp->rl_tx_list + entry;
	ioaddr = tp->mmio_addr;

	iptraceNETWORK_INTERFACE_TRANSMIT();

	if (pxNetworkBuffer == NULL ||
	    pxNetworkBuffer->pucEthernetBuffer == NULL ||
	    pxNetworkBuffer->xDataLength == 0) {
		amf_printf("%s Invalid params", __func__);
		return pdFALSE;
	}

	if (txd->rl_cmdstat & RL_TDESC_CMD_OWN) {
		amf_printf("Error: Tx Desc alreay owned\n");
		goto err_stop_0;
	}

	opts[1] = 0;
	opts[0] = RL_TDESC_CMD_OWN;

	tp->tx_databuf[entry] = data = re_newbuf(tp, txd,
	    pxNetworkBuffer->xDataLength, false);

	if(data == NULL) {
		amf_printf("Failed to allocate tx data\n");
		_exit(-1);
	}

	memcpy(data, pxNetworkBuffer->pucEthernetBuffer,
	    pxNetworkBuffer->xDataLength);

	len = pxNetworkBuffer->xDataLength;

	opts[0] |= RL_TDESC_CMD_SOF | RL_TDESC_CMD_EOF;

	txd->rl_vlanctl = opts[1];

	/* Force memory writes to complete before releasing descriptor */
	MEM_BARRIER;

	/* Anti gcc 2.95.3 bugware (sic) */
	status = opts[0] | len |
	    (RL_TDESC_CMD_EOR * !((entry + 1) % RL_TX_DESC_CNT));
	txd->rl_cmdstat = status;

	/* Force all memory writes to complete before notifying device */
	MEM_BARRIER;

	tp->cur_tx += 1;

	CSR_WRITE_1(tp->rl_txstart, RL_TXSTART_START);

	MEM_BARRIER;

	if (bReleaseAfterSend != pdFALSE) {
		/*
		 * We have copied the data out of the FreeRTOS+TCP Ethernet
		 * buffer.  The Ethernet buffer is therefore no longer needed,
		 * and must be freed for re-use.
		 */
		vReleaseNetworkBufferAndDescriptor( pxNetworkBuffer );
	}

	return pdPASS;

err_stop_0:

	return pdFAIL;
}
