/*
FreeRTOS+TCP V2.0.10
Copyright (C) 2017 Amazon.com, Inc. or its affiliates.  All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 http://aws.amazon.com/freertos
 http://www.FreeRTOS.org
*/

/* WinPCap includes. */
//#define HAVE_REMOTE
//#include "pcap.h"

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

/* FreeRTOS+TCP includes. */
#include "FreeRTOS_IP.h"
#include "FreeRTOS_IP_Private.h"
#include "NetworkBufferManagement.h"

/* Thread-safe circular buffers are being used to pass data to and from the PCAP
access functions. */
//#include "Win32-Extensions.h"
//#include "FreeRTOS_Stream_Buffer.h"
#include <string.h>
#include <ctype.h>
#include <xtensa/xtruntime.h>
#include <xtensa/hal.h>
#include <xtensa/sim.h>
#include <xtensa/config/core.h>
#include "command.h"
#include<stdio.h>

/* Sizes of the thread safe circular buffers used to pass data to and from the
WinPCAP Windows threads. */
#define xSEND_BUFFER_SIZE  32768
#define xRECV_BUFFER_SIZE  32768

/* If ipconfigETHERNET_DRIVER_FILTERS_FRAME_TYPES is set to 1, then the Ethernet
driver will filter incoming packets and only pass the stack those packets it
considers need processing. */
#if( ipconfigETHERNET_DRIVER_FILTERS_FRAME_TYPES == 0 )
	#define ipCONSIDER_FRAME_FOR_PROCESSING( pucEthernetBuffer ) eProcessBuffer
#else
	#define ipCONSIDER_FRAME_FOR_PROCESSING( pucEthernetBuffer ) eConsiderFrameForProcessing( ( pucEthernetBuffer ) )
#endif

/* Used to insert test code only. */
#define niDISRUPT_PACKETS	0
#define INTERRUPT_PRIO        1
TaskHandle_t       myIntTaskHandle = NULL;
#if 1
typedef struct STREAM_BUFFER {
	unsigned int len;				/* const value: number of reserved elements */
	unsigned char buf[1500];
} StreamBuffer;
#endif
//static StreamBuffer xSendBuffer[1024];
StreamBuffer xRecvBuffer[10];

/*-----------------------------------------------------------*/
/*
 * A function that simulates Ethernet interrupts by periodically polling the
 * WinPCap interface for new data.
 */
static void Rx_handler( void *p)
{
static unsigned int pkt_cnt[1];
const uint8_t *pucPacketData;
NetworkBufferDescriptor_t *pxNetworkBuffer;
IPStackEvent_t xRxEvent = { eNetworkRxEvent, NULL };
eFrameProcessingResult_t eResult;
static int result;
	for (;;)
	{
		xthal_dcache_region_writeback_inv(xRecvBuffer, sizeof(xRecvBuffer));
		xthal_dcache_region_writeback_inv(pkt_cnt, sizeof(pkt_cnt));
		result = xt_iss_simcall(CMD_RECV,(int)xRecvBuffer, sizeof(xRecvBuffer),( size_t )pkt_cnt, 0, 0);
		if(pkt_cnt[0]){
			for(int i=0; i<pkt_cnt[0]; i++){
//				printf("pkt len=%d\n",xRecvBuffer[i].len);
				if(xRecvBuffer[i].len)
				{
					if(xRecvBuffer[i].len > 16 )
					{
						pucPacketData = xRecvBuffer[i].buf;
						/*printf("\n f/w Rx :");
									for (int i = 0; i < xRecvBuffer[i].len; i++)
										printf( "%X ", xRecvBuffer[i].buf[i]);
									printf("\n");
						*/
						/* Check for minimal size. */
						if( xRecvBuffer[i].len >= sizeof( EthernetHeader_t ) )
						{
							eResult = ipCONSIDER_FRAME_FOR_PROCESSING( pucPacketData );
						}
						else
						{
							
							eResult = eReleaseBuffer;
						}
		
						if( eResult == eProcessBuffer )
						{
							/* Will the data fit into the frame buffer? */
							if(xRecvBuffer[i].len <= ipTOTAL_ETHERNET_FRAME_SIZE )
							{
								//printf("Frame size is :%d\n",ipTOTAL_ETHERNET_FRAME_SIZE);
								/* Obtain a buffer into which the data can be placed.  This
								is only	an interrupt simulator, not a real interrupt, so it
								is ok to call the task level function here, but note that
								some buffer implementations cannot be called from a real
								interrupt. */
								pxNetworkBuffer = pxGetNetworkBufferWithDescriptor( xRecvBuffer[i].len, 0 );
		
								if( pxNetworkBuffer != NULL )
								{
									memcpy( pxNetworkBuffer->pucEthernetBuffer, pucPacketData, xRecvBuffer[i].len );
									pxNetworkBuffer->xDataLength = ( size_t )xRecvBuffer[i].len;
								
									if( pxNetworkBuffer != NULL )
									{
										xRxEvent.pvData = ( void * ) pxNetworkBuffer;
										/* Data was received and stored.  Send a message to
										the IP task to let it know. */
										if( xSendEventStructToIPTask( &xRxEvent, ( TickType_t ) 0 ) == pdFAIL )
										{
											printf("Event to IP Fail\n");
											/* The buffer could not be sent to the stack so
											must be released again.  This is only an
											interrupt simulator, not a real interrupt, so it
											is ok to use the task level function here, but
											note no all buffer implementations will allow
											this function to be executed from a real
											interrupt. */
											vReleaseNetworkBufferAndDescriptor( pxNetworkBuffer );
											iptraceETHERNET_RX_EVENT_LOST();
										}
									}
								
								}
								else
								{
									iptraceETHERNET_RX_EVENT_LOST();
								}
							}
						}
					}
				}
			}
			vTaskDelay(10);
		}
		else
//			printf("sleeping for 1000 ms\n");
			vTaskDelay(1000);
	}
}

BaseType_t xNetworkInterfaceInitialise( void )
{
int result;
	xTaskCreate(Rx_handler, "Int task", 1500, NULL, 1, &myIntTaskHandle);
	return pdPASS;
}

BaseType_t xNetworkInterfaceOutput( NetworkBufferDescriptor_t * const pxNetworkBuffer, BaseType_t bReleaseAfterSend )
{
	unsigned char rxbuf[1500];

	xthal_dcache_region_writeback_inv(rxbuf, sizeof(rxbuf));

	memcpy(rxbuf, pxNetworkBuffer->pucEthernetBuffer, pxNetworkBuffer->xDataLength);
	
	xt_iss_simcall(CMD_SEND, 0, pxNetworkBuffer->xDataLength, 0, (int)rxbuf, 0);


	if( bReleaseAfterSend != pdFALSE )
	{
		vReleaseNetworkBufferAndDescriptor( pxNetworkBuffer );
	}
	return pdPASS;
}

