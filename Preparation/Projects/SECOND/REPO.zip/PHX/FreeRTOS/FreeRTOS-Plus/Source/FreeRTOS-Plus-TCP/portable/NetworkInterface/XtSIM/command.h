#ifndef __COMMAND_H__

#define CMD_SEND		0
#define CMD_RECV		1
#define CMD_SET_INT		2
#define CMD_CLEAR_INT		3
#define CMD_ETH_INIT		4

#define COMM_CLOSE		99

#endif // __COMMAND_H__
