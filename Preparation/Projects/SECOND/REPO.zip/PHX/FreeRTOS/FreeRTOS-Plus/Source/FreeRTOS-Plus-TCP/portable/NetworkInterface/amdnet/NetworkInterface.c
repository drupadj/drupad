/**
 * @file NetworkInterface.c
 * @brief This is the main file for wrapper network driver for AMD LAN and WLAN
 *	  Driver.
 * @date 30.April.2021
 * @version 1.00.000
 *
 * @copyright Copyright 2021 by Advanced Micro Devices Inc. All Rights Reserved
 *
 */

/* General includes */
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <stdio.h>

/* FreeRTOS includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "list.h"
#include "hwgen.h"

/* FreeRTOS+TCP includes. */
#include "FreeRTOS_IP.h"
#include "FreeRTOS_IP_Private.h"
#include "FreeRTOS_Stream_Buffer.h"
#include "NetworkInterface.h"
//#include "NetworkBufferManagement.h"

/* Xtensa includes */
//#include <xtensa/xtruntime.h>
//#include <xtensa/hal.h>
//#include <xtensa/sim.h>

/* NW Driver interface includes. */
#include "os_if_init.h"
#include "os_if_shutdown.h"

/* Extern */
extern uint32_t net_pci_base_addr_lo;
extern uint8_t g_FreeRTOS_NW_UP;
extern uint8_t stop_wlanheapaccess;

extern int amdmac_network_data_tx(NetworkBufferDescriptor_t *pxNetworkBuff);
extern int isassociated(int unused);
extern BaseType_t re_init( void );
extern BaseType_t re_network_output(NetworkBufferDescriptor_t * const pxNetworkBuffer,
    BaseType_t bReleaseAfterSend);
extern BaseType_t re_deinit( void );

uint8_t driver_init_done = 0;

/* Globals */
uint16_t g_did = 0;
uint16_t g_vid = 0;
SemaphoreHandle_t g_ShutdownSem = NULL;
#define PCIE_DIDVID_OFFSET	0x00

/* If ipconfigETHERNET_DRIVER_FILTERS_FRAME_TYPES is set to 1, then the Ethernet
driver will filter incoming packets and only pass the stack those packets it
considers need processing. */
#if( ipconfigETHERNET_DRIVER_FILTERS_FRAME_TYPES == 0 )
#define ipCONSIDER_FRAME_FOR_PROCESSING( pucEthernetBuffer ) eProcessBuffer
#else
#define ipCONSIDER_FRAME_FOR_PROCESSING( pucEthernetBuffer ) eConsiderFrameForProcessing( ( pucEthernetBuffer ) )
#endif

BaseType_t
xWlanNetworkInterfaceOutput( NetworkBufferDescriptor_t * const pxNetworkBuffer,
    BaseType_t xReleaseAfterSend )
{

//      FreeRTOS_printf( ("%s: skb_buff@: 0x%x skb@: 0x%x XDlen: 0x%x len:0x%x release: 0x%x\n",
//              __func__, pxNetworkBuffer, pxNetworkBuffer->pucEthernetBuffer, pxNetworkBuffer->xDataLength, pxNetworkBuffer->len, xReleaseAfterSend ) );
        //os_if_skb_put(pxNetworkBuffer, pxNetworkBuffer->xDataLength);
        pxNetworkBuffer->len = pxNetworkBuffer->xDataLength;
        pxNetworkBuffer->data = pxNetworkBuffer->pucEthernetBuffer;
        pxNetworkBuffer->cb[0] = (uint32_t)xReleaseAfterSend;

        return amdmac_network_data_tx(pxNetworkBuffer);
}

void
vNetworkInterfaceAllocateRAMToBuffers( NetworkBufferDescriptor_t pxNetworkBuffers[ ipconfigNUM_NETWORK_BUFFER_DESCRIPTORS ] )
{
    /* FIX ME. */
}

BaseType_t
xGetPhyLinkStatus( void )
{
        amf_printf("%s: Called ret = %d\n", __func__, isassociated(0));
        return isassociated(0);
}

void xSetDriverInitComplete()
{
        driver_init_done = 1;
}

int xGetDriverInitComplete()
{
        return (int)driver_init_done;
}

BaseType_t
xWlanNetworkInterfaceInitialise( void )
{
        int ret = 0;
        TaskHandle_t pci_task_handler;

        amf_printf("%s Started-> %d\n", __func__, driver_init_done);
        if(!driver_init_done) {
                //wlan_heap_init();
                ret = xTaskCreate(ath11k_pci_freertos_probe, "PCIProbe", PCI_STACK_SIZE,
                                NULL, PCI_TASK_PRIO, &pci_task_handler);
                if ( ret != pdPASS )
                {
                        amf_printf("PCI-Task creation failed\n");
                }
                else
                {
                        amf_printf("PCI-Task Created\n");
                }
        } else {
                ret = pdPASS;
        }

        /* TODO: Check how to indicate link status to the Stack. */
        do {
                if(isassociated(0))
                {
                        amf_printf("Device is connected, Start DHCP\n");
                        break;
                }

                vTaskDelay(100);
        } while(1);

#if 0
        /*
         * Added delay of 3 Secs to make sure that connection is successfully established by WLAN device.
         * TODO: Remove delay once connection is properly sync in WLAN stack.
         */
        amf_printf("Wait for 3 more Seconds before DHCP starts.\n");
        vTaskDelay(3000);
#endif

        amf_printf("%s Done->\n", __func__);
        return ret;
}

BaseType_t
xLanNetworkInterfaceInitialise(void)
{
        BaseType_t ret = pdPASS;

        amf_printf("LAN Init entry\n");

        ret = re_init();
        if (ret != pdPASS){
                amf_printf("LAN Init fail\n");
	}
        else{
                amf_printf("LAN Init pass\n");
	        driver_init_done=1;
	}

        return ret;
}

BaseType_t
xLanNetworkInterfaceOutput(NetworkBufferDescriptor_t * const pxNetworkBuffer,
    BaseType_t bReleaseAfterSend)
{
	return re_network_output(pxNetworkBuffer, bReleaseAfterSend);
}

BaseType_t
xNetworkInterfaceOutput( NetworkBufferDescriptor_t * const pxNetworkBuffer,
    BaseType_t xReleaseAfterSend )
{

    if( xCheckLoopback( pxNetworkBuffer, xReleaseAfterSend ) != 0 )
    {
        /* The packet has been sent back to the IP-task.
         * The IP-task will further handle it.
         * Do not release the descriptor. */
         return pdTRUE;
    }
   
	if ((g_vid == REALTEK_PCI_VID) && (g_did == REALTEK_LAN_DID1)) {
			return xLanNetworkInterfaceOutput(pxNetworkBuffer, xReleaseAfterSend);
	} else if ((g_vid == QUALCOM_PCI_VID) &&
		((g_did == QUALCOM_WLAN_DID1) || (g_did == QUALCOM_WLAN_DID2))) {
			return xWlanNetworkInterfaceOutput(pxNetworkBuffer, xReleaseAfterSend);
	} else {
		amf_printf("Wrong DID_VID: VID: 0x%x, DID: 0x%x\n", g_vid, g_did);
		_exit(-1);
	}
}	

BaseType_t
xNetworkInterfaceInitialise( void )
{
	uint32_t cfg_space_addr_hi;
	uint32_t cfg_space_addr_lo;
	uint32_t didvid;

	cfg_space_addr_hi = 0xFFFE;
	cfg_space_addr_lo = net_pci_base_addr_lo;

	g_ShutdownSem = xSemaphoreCreateCounting(MAX_APP_COUNT, 0);
	if (g_ShutdownSem == NULL)
	{
		amf_printf("%s: Semaphore creation failed\n", __func__);
		return pdFAIL;
	}

    /* Below re-populate of didvid is for non-kvm & x86-not-release case. */
	/* Read BAR2 from PCI-E Config space (offset- 0x18) */
    if ((g_did == 0) || (g_vid == 0))
	{
		didvid = ReadFchPCIeMMIO(cfg_space_addr_hi, (cfg_space_addr_lo + PCIE_DIDVID_OFFSET));
		g_vid = didvid & 0xFFFF;
		g_did = (didvid >> 16) & 0xFFFF;
		amf_printf("%s: Did 0x%x, Vid 0x%x\n", __func__, g_did, g_vid);
	}

	if ((g_vid == REALTEK_PCI_VID) && (g_did == REALTEK_LAN_DID1)) {
		return xLanNetworkInterfaceInitialise();
	} else if ((g_vid == QUALCOM_PCI_VID) &&
                ((g_did == QUALCOM_WLAN_DID1) || (g_did == QUALCOM_WLAN_DID2))) {
		return xWlanNetworkInterfaceInitialise();
	} else {
		amf_printf("Wrong DID_VID: VID: 0x%x, DID: 0x%x\n", g_vid, g_did);
		_exit(-1);
	}
}

/* Return pdPASS in case of Success, else return pdFAIL. */
int AMDNET_Shutdown(void)
{
        int ret = pdFAIL;
        int count = 0, i = 0;
        static int shutdown_done = 0; //Stop multiple shutdown call.

        vTaskEnterCritical();
        for (count = 0; count < SHUTDOWN_RETRY_COUNT; count++)
        {
                /*
                 * As driver init is not done, hence cleaning up is not required.
                 * TODO: put the "driver_init_done" flag declaration in common file for LAN and WLAN.
                 */
                if (!driver_init_done && (SHUTDOWN_RETRY_COUNT != (count + 1)))
                {
                        vTaskDelay(100);
                        continue;
                }

                amf_printf("[%d] %s: Started for did:0x%x vid:0x%x\n",
                           xTaskGetTickCount(), __func__, g_did, g_vid);
                if ((g_vid == REALTEK_PCI_VID) && (g_did == REALTEK_LAN_DID1))
                {
                        ret = re_deinit();
                        if (!ret)
                        {
                                amf_printf("LAN Device Shutdown failed\n");
                                return pdFAIL;
                        }
                        else
                        {
                                amf_printf("LAN Device Shutdown Success.\n");
                                ret = pdPASS;
                        }
                }
                else if ((g_vid == QUALCOM_PCI_VID) &&
                               ((g_did == QUALCOM_WLAN_DID1) || (g_did == QUALCOM_WLAN_DID2)))
                {
                        ret = amdmac_wlan_device_shutdown();
                        if (ret)
                        {
                                amf_printf("amdmac_wlan_device_shutdown failed with err=(%d)\n", ret);
                                return pdFAIL;
                        }
                        else
                        {
                                stop_wlanheapaccess = 1;
                                /* Give the semaphore only if driver shutdown is success. */
                                for (i = 0; i < MAX_APP_COUNT; i++)
                                {
                                    xSemaphoreGive(g_ShutdownSem);
                                }

                                UnmapSysHubTlb(16);
                                amf_printf("amdmac_wlan_device_shutdown Success.\n");
                                ret = pdPASS;
                        }
                }
                else
                {
                        amf_printf("Wrong DID_VID: VID: 0x%x, DID: 0x%x\n", g_vid, g_did);
                        return pdFAIL;
                }

                /* Give the semaphore only if driver shutdown is success. */
                for (i = 0; i < MAX_APP_COUNT; i++)
                {
                        xSemaphoreGive(g_ShutdownSem);
                }

                /* Shutdown completed. Break the execution. */
                shutdown_done = 1;
                break;
        }

        amf_printf("[%d] %s: Completed\n", xTaskGetTickCount(), __func__);
        vTaskExitCritical();

        return ret;
}
