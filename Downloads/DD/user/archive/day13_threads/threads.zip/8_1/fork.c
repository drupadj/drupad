#include <stdio.h>
int main()
{
 fork();
 return 0;
}
